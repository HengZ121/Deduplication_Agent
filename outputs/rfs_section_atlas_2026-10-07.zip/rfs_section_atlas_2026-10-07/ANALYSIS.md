# RFS section atlas

Open index.html for the visual comparison, full sources and pair differences.

## Cross-row exact note matches
Different note IDs are not aligned merely because their titles match. The following resolved bodies nevertheless match exactly:

## Row-by-row analysis

### 1. Summary
Exact matches: No full-section exact matches in this row. Differences within the duplicated wording: The summary wording follows the same pattern, but the RFS category and Fishing qualifier differ. These are similar summaries, not exact full-section duplicates.

### 2. What you need to know
Duplication: No duplicated body content — these nodes are empty headings.

### 3. What you need to know / Linking the ROE and matching employment
Exact matches: No full-section exact matches in this row. Partial duplication: C–E share 6 exact internal block(s) of at least 12 tokens. The excerpt below is one observed match. Differences within the duplicated wording: The explanation contains shared passages, but expanded example tables differ. For example, Quit and Dismissal show E versus M in the first sample ROE row. Duplicated text · C: Only one ROE can be matched to each period of employment listed in NWS. The agent must review the Search / Correct - Results screen in RCM to determine if the ROE in the ROE RFS Action WI is the one with the last day for which paid (LDP) closest to the last day worked (LDW) for one of the periods of employment. The…

### 4. What you need to know / Completing the Resolve Issue section
Exact matches: G / N. Other full sections differ. Partial duplication: C–G share 4 exact internal block(s) of at least 12 tokens. The excerpt below is one observed match. Differences within the duplicated wording: Only G / N are exact full-section matches. The other sections differ in expanded wording or reference structure. Duplicated text · C: If the RFS is contentious and there is an existing ROD, the agent must determine if the information on the ROE contradicts the decision on file. When a ROD is not found or when the information on the ROE contradicts the ROD, the agent indicates that no decision matches the ROE when completing the Resolve Issue section…

### 5. Regional considerations
Duplication: No duplicated body content — these nodes are empty headings.

### 6. What you need to look for
Duplication: No duplicated body content — these nodes are empty headings.

### 7. What you need to look for / In NWS
Exact matches: C / E / G / K / M / N / F / S have identical expanded bodies and reference targets in separate files. Duplicated text · E: What is the serial number and the RFS indicated in the Specific Details tab of the ROE RFS Action WI? What periods of employment are indicated in the Matching POE list of the ROE RFS Action WI? Is there a ROD indicating that the RFS has been adjudicated? If yes, what are the details of the decision? Is there an SROC…

### 8. What you need to look for / In RCM
Exact matches: C / E / G / M. Other full sections differ. Partial duplication: C–K share 3 exact internal block(s) of at least 12 tokens. The excerpt below is one observed match. Differences within the duplicated wording: C / E / G / M match exactly. N differs by a hyphen versus an en dash. K adds four Other categories; F uses different ROE field numbers; S contains only the first three questions. Duplicated text · C: Does the audit trail contain a new value for the RFS in block 16 ?

### 9. What you need to look for / In FTS
Exact matches: C / E / G / K / M / N / F / S have identical expanded bodies and reference targets in separate files. Duplicated text · E: Does the Employer search indicate that the employer operates under another name?

### 10. Step by step
Duplication: No duplicated body content — these nodes are empty headings.

### 11. Step by step / Non-complex
Duplication: No duplicated body content — these nodes are empty headings.

### 12. Step by step / Non-complex / Linking the ROE and matching employment
Exact matches: C / N. Other full sections differ. Partial duplication: C–E share 9 exact internal block(s) of at least 12 tokens. The excerpt below is one observed match. Differences within the duplicated wording: C / N match exactly. Other sections share passages but differ in wording or local step destinations. Duplicated text · C: When comparing the employer’s name on the period of employment and the ROE, you may accept minor spelling differences to the employer’s name. You must also consider that the employer may do business under more than one name (e.g. 123456 ONT INC does business as ABC Company). In this case, you must review the…

### 13. Step by step / Non-complex / Ensuring the reason for separation (RFS) details are correct
Exact matches: No full-section exact matches in this row. Partial duplication: C–E share 5 exact internal block(s) of at least 12 tokens. The excerpt below is one observed match. Differences within the duplicated wording: All eight full sections differ. Their shared instructions surround different RFS condition-to-outcome tables. Duplicated text · C: When actioning an ROE Comments WI, the agent may have moved the comments in block 18 of the ROE to the Additional information field in RCM.

### 14. Step by step / Non-complex / Completing the WI
Exact matches: C / E / G / K / M / N / F / S have identical expanded bodies and reference targets in separate files. Duplicated text · E: Complete the ROE RFS Action WI.

### 15. Step by step / Non-complex / Selecting a special condition for the decision on file
Exact matches: No full-section exact matches in this row. Partial duplication: C–E share 5 exact internal block(s) of at least 12 tokens. The excerpt below is one observed match. Differences within the duplicated wording: None of the seven sections match in full. Shared passages occur within differing decision branches and local step references. Duplicated text · C: If the decision indicates Anticipated Loss of Employment (D-44) , select Anticipated Loss of Employment and enter the disentitlement dates from the decision.

### 16. Policy reference
Duplication: No duplicated body content — these nodes are empty headings.