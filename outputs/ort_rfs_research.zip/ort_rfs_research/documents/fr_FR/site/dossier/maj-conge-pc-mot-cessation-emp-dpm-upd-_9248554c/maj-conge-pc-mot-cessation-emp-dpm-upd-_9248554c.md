# Mise à jour : Congé parental comme le motif de cessation d’emploi dans les demandes de prestations de maternité — Procédures (Niveau 1 et Niveau 2)

Source map: `fr_FR/site/dossier/maj-conge-pc-mot-cessation-emp-dpm-upd-_9248554c/maj-conge-pc-mot-cessation-emp-dpm-upd-_9248554c.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/maj-conge-pc-mot-cessation-emp-dpm-upd-_9248554c/sommaire.dita`

À partir du 28 mars 2026, les demandes de prestations de maternité vont faire l’objet d’une intervention manuelle, ce qui créera un AT Évaluation de la demande (AT EVD) quand le motif de cessation d’emploi (MCE) dans le dernier RE est P - congé parental . 

## Generic

Source topic: `fr_FR/site/dossier/maj-conge-pc-mot-cessation-emp-dpm-upd-_9248554c/generic.dita`

Une mise à jour du système va créer les AT EVD dans les demandes de maternité quand le MCE dans le dernier RE est P - congé parental . Cette modification garantit que le client demande le genre de prestations (GP) correct. Des modifications ont aussi été apportées sur la demande d’AE pour clarifier l’objectif des prestations de maternité afin de réduire le nombre d’erreurs commises par les clients lors de choisir un GP à l’avenir.

Les agents doivent effectuer un recueil de faits auprès de l’employeur pour s’assurer que le MCE dans le RE est correct. Si c’est le cas, un recueil de faits supplémentaire auprès du client est nécessaire pour s’assurer que le GP est correct. Cela s’applique également aux demandes de conversion et renouvellement quand un MCE est P - congé parental . 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/maj-conge-pc-mot-cessation-emp-dpm-upd-_9248554c/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
