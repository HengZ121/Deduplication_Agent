# Archivée : COVID-19 et report de la décision dans une demande pour la prestation d’AE d’urgence

Source map: `fr_FR/site/dossier/covid19_deferral_adjudication_eierbc/covid19_deferral_adjudication_eierbc.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/covid19_deferral_adjudication_eierbc/sommaire.dita`

En raison de la situation liée à la COVID-19, de nombreux utilitaires du système sont exécutés pour traiter automatiquement les demandes comme des demandes de prestation d’AE d’urgence. Par conséquent, quand tous les critères sont satisfaits, rendre une décision sur une question litigieuse peut être reporté pour une demande  de prestation d’AE d’urgence. 

## Generic

Source topic: `fr_FR/site/dossier/covid19_deferral_adjudication_eierbc/generic.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0971.dita) 

Archivée

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0972.dita) 

**Table des matières**

- Ce qu’il faut savoir
         [Ce qu’il faut savoir](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Ce_quil_faut)

- Processus temporaire

- Recueil de fait s
             [Recueil de fait](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Recueil_de_fait)

- Rapport de décision (RD) — Motif de cessation d’emploi (MCE) litigieux
             [Rapport de décision (RD) — Motif de cessation d’emploi (MCE) litigieux](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Rapport_de_decision)

- Rapport de décision (RD) — AT Litige - Décision (DEC) interactif
             [Rapport de décision (RD) — AT Litige - Décision (DEC) interactif](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Rapport_de_decision_1)

- Rapport de décision (RD) — Toutes les autres situations
             [Rapport de décision (RD) — Toutes les autres situations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Rapport_de_decision_2)

- Mesures supplémentaires requises
             [Mesures supplémentaires requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Mesure_supplementaires)

         [Processus temporaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Processus_temporaire)

**Ce qu’il faut savoir**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0973.dita) 

**Demandes initiales**

Quand l’agent détermine que le client remplit les conditions requises pour recevoir la prestation d’AE d’urgence, la décision de toute question litigieuse est reportée.

Le système automatise complètement ces demandes, quand cela est possible, supprime tous les AT qui y sont liés et les traite comme des demandes pour la prestation d’AE d’urgence.

Quand le système ne peut pas automatiser le traitement d’une demande de prestations régulières ou de maladie, l’agent la traite normalement. L’agent :

- ne modifie pas les RE pour correspondre au taux de prestations de 500 $ par semaine;

- ne saisit pas l’indicatif 5 - Utilitaire d’automatisation - Prestations canadienne d’urgence ou 6 - Utilitaire de réévaluation - Prestations canadienne d’urgence (le système le saisit).

Comme le système supprime tous les AT quand la demande est traitée automatiquement comme une demande de prestation d’AE d’urgence, il est maintenant possible pour l’agent de reporter la décision si les critères suivants sont tous satisfaits :

- le client demande des prestations régulières ou de maladie (y compris les demandes où la cliente déclare être enceinte);

- le DPP provisoire est le 8 mars 2020 ou après;

- le dernier jour de travail (DJT) de la dernière période d’emploi est le 21 juin 2019 ou après.

**Demandes renouvelées ou continues**

Quand l’agent détermine que la demande est une demande renouvelée ou continue pour la prestation d’AE d’urgence, la décision est reportée pour toutes les questions litigieuses. L’agent peut repérer ces demandes grâce à l’indicateur Demande PU dans ETI.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0974.dita) 

**Processus temporaire**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0975.dita) 

Quand toutes les conditions ci-dessus sont remplies, reportez la décision en suivant les étapes de ce processus temporaire.

**Recueil de faits**

Aucun recueil de faits n’est requis pour reporter la décision sur une question litigieuse dans le cadre de cette mesure temporaire.

**Rapport de décision (RD) — Motif de cessation d’emploi (MCE) litigieux**

Quand il y a un onglet Résoudre le problème dans l’AT DEC, l’agent ne doit pas indiquer que la décision est reportée, puisque le système impose automatiquement une exclusion. Si le client remplit les conditions requises pour recevoir la prestation d’AE d’urgence, il est important qu’aucune exclusion ne soit imposée au dossier. Compléter l’AT DEC de la façon suivante :

**Départ volontaire ou congédiement**

**Niveau 1**

- Si le client a quitté son emploi volontairement, dans SNCT, à l’onglet Résoudre le problème de l’AT DEC, remplir l’écran Départ volontaire Niveau 1 en choisissant la raison appropriée pour permettre le départ volontaire.

- Si le client a été congédié, dans SNCT, à l’onglet Résoudre le problème de l’AT DEC, remplir l’écran Congédiement Niveau 1 de la façon suivante :

- Choisir Selon les renseignements au dossier, les critères pour rendre une décision au Niveau 1 ont été respectés. L’employeur confirme que le motif de la cessation d’emploi n’est pas attribuable à une faute du client (Politique nationale sur les niveaux de décision) .

- Cliquer Page suivante .

- Dans les 2 cas, créer un autre RD de la façon suivante :

- Commentaires : Saisir « COVID-19 — [nom de l’employeur] — [DJT] — décision reportée. »

- Détails : Saisir « Le client est admissible à la prestation d’AE d’urgence. La décision est reportée. »

- Passer à Mesures supplémentaires requises .
         [Mesures supplémentaires requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Mesure_supplementaires)

**Niveau 2**

- Si le client a quitté son emploi volontairement, dans SNCT, à l’onglet Résoudre le problème de l’AT DEC, remplir l’écran Départ volontaire de la façon suivante :

- Faits pertinents : Saisir « Le client est admissible à la prestation d’AE d’urgence. La décision est reportée. »

- Décision : Choisir Départ volontaire – motif valable démontré .

- Avis écrit : Choisir Non .

- Cliquer Page suivante .

- Si le client a été congédié, dans SNCT, à l’onglet Résoudre le problème de l’AT DEC, remplir l’écran Congédié ou suspendu de la façon suivante :

- Faits pertinents : Saisir « Le client est admissible à la prestation d’AE d’urgence. La décision est reportée. »

- Décision : Choisir Inconduite non prouvée .

- Avis écrit : Choisir Non .

- Cliquer Page suivante .

- Passer à Mesures supplémentaires requises .
         [Mesures supplémentaires requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Mesure_supplementaires)

**Rapport de décision (RD) — AT Litige - Décision (DEC) interactif**

**Formation**

**Niveau 1**

- Dans SNCT, à l’onglet Résoudre le problème de l’AT DEC, remplir l’écran Formation Niveau 1 de la façon suivante :

- Choisir L’évaluation du cours de formation n’est pas requise .

- Cliquer Page suivante .

- Expliquez pourquoi une décision concernant la formation n’est pas nécessaire : Saisir « Le client est admissible à la prestation d’AE d’urgence. »

- Passer à Mesures supplémentaires requises .
         [Mesures supplémentaires requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Mesure_supplementaires)

**Niveau 2**

- Dans SNCT, à l’onglet Résoudre le problème de l’AT DEC, remplir l’écran Formation Niveau 2 de la façon suivante :

- Choisir Le cours de formation n’est pas un litige.

- Cliquer Page suivante.

- Remplir l’écran Le cours de formation n’est pas un litige de la façon suivante :

- Faits pertinents : Saisir « Le client est admissible à la prestation d’AE d’urgence. »

- Cliquer Page suivante.

- Passer à Mesures supplémentaires requises .
         [Mesures supplémentaires requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Mesure_supplementaires)

**Travail indépendant (TI) ou travail agricole**

**Niveau 1**

- Si le client a effectué un TI, dans SNCT, à l’onglet Résoudre le problème de l’AT DEC, remplir l’écran Niveau 1 - Travail indépendant de la façon suivante :

- Choisir Le travail indépendant du prestataire a cessé avant le DPP .

- Entrez la date à laquelle le travail indépendant du prestataire a cessé. (JJ/MM/AAAA) : Saisir le vendredi avant la semaine du DPP.

- Si le client a effectué un travail agricole, dans SNCT, à l’onglet Résoudre le problème de l’AT DEC, remplir l’écran Niveau 1 - Agriculture de la façon suivante :

- Choisir Les activités agricoles du prestataire se sont terminées avant le DPP .

- Entrez la date à laquelle les activités agricoles du prestataire ont cessé. (JJ/MM/AAAA) : Saisir le vendredi avant la semaine du DPP.

- Créer un RD de la façon suivante :

- Commentaires : Saisir « COVID-19 — [question litigieuse] — Décision reportée. »

- Détails : Saisir « Le client est admissible à la prestation d’AE d’urgence. La décision est reportée. »

- Passer à Mesures supplémentaires requises .
         [Mesures supplémentaires requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Mesure_supplementaires)

**Niveau 2**

- Si le client a effectué un TI, dans SNCT, à l’onglet Résoudre le problème de l’AT DEC, remplir l’écran Niveau 2 - Travail indépendant de la façon suivante :

- Choisir Le client n’est pas un travailleur indépendant .

- Cliquer Page suivante .

- Remplir l’écran Le client n’est pas un travailleur indépendant de la façon suivante :

- Faits pertinents : Saisir « Le client est admissible à la prestation d’AE d’urgence. La décision est reportée. »

- Cliquer Page suivante .

- Si le client a effectué un travail agricole, dans SNCT, à l’onglet Résoudre le problème de l’AT DEC, remplir l’écran Niveau 1 - Agriculture de la façon suivante :

- Choisir Le client n’exploite pas une entreprise agricole .

- Cliquer Page suivante .

- Remplir l’écran Le client n’exploite pas une entreprise agricole de la façon suivante :

- Faits pertinents : Saisir « Le client est admissible à la prestation d’AE d’urgence. La décision est reportée. »

- Cliquer Page suivante

- Passer à Mesures supplémentaires requises .
         [Mesures supplémentaires requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/covid19_deferral_adjudication_eierbc#Mesure_supplementaires)

**Rapport de décision (RD) — Toutes les autres situations**

- Dans toutes les autres situations, créer un RD de la façon suivante :

- Commentaires : Saisir « COVID-19 — [question litigieuse] — Décision reportée. »

- Détails : Saisir « Le client est admissible à la prestation d’AE d’urgence. La décision est reportée. »

**Mesures supplémentaires requises**

- Déterminer si l’AT DEC est pour un MCE litigieux :

- Si oui, passer à l’étape 2.

- Si non, passer à l’étape 4.

- Créer un AT À revoir (AR) de la façon suivante :

- Envoyer vers ma charge de travail en suspens : Cocher la case.

- Motif de la mise en suspens : Choisir Autre .

- Commentaires : Saisir « En attendant que la demande soit finalisée. »

- Une fois la demande finalisée, modifier le champ Condition spéciale dans le RE de la façon suivante :

- Si la décision a été reportée dans une demande révisée, dans ETI, choisir la transaction Renouvellement/Révisé (M106) et compléter le numéro d’enregistrement de la façon suivante :

- Demande accordée : Choisir APC - Aucun changement .

- Litigieux : Choisir 1 - Non .

- Complété : Choisir C - Oui .

- Cliquer Mise à jour. 

### Warning

Source topic: `fr_FR/common_notes/note_c_0971.dita`

**Cette page Web a été archivée dans le Web**

MISE À JOUR : 2021-02-03 — Cette page Mises à jour et Nouvelles a été archivée parce que l’information qu’elle contenait n’est plus à jour. La PU AE s’est terminée le 27 septembre 2020.

L’information dont il est indiqué qu’elle est archivée est fournie à des fins de référence, de recherche ou de tenue de documents. Elle n’est pas assujettie aux normes Web du gouvernement du Canada et elle n’a pas été modifiée ou mise à jour depuis son archivage. Pour obtenir cette information dans un autre format, veuillez communiquer avec nous. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0972.dita`

Remarque :

Cette Mise à jour et nouvelles a été créée le 21 mai 2020 et a été mise à jour de la façon suivante :

- 15 juin 2020 : La section Processus temporaire a été mise à jour avec les détails sur les différentes options pour les agents de Niveau 1 et de Niveau 2 quand ils remplissent l’onglet Résoudre le problème dans l’AT Litige - Décision (DEC) pour les questions litigieuses. La section Ce qu’il faut savoir a été mise à jour avec de nouveaux renseignements indiquant que ce processus s’applique seulement aux demandes initiales, renouvelées ou continues pour la prestation d’AE d’urgence.

- 3 février 2020 : Cette page est maintenant archivée. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0973.dita`

Remarque :

Ce processus temporaire ne s’applique pas pour les cas de permis de travail ou de NAS de la série 900. L’agent consulte Mise à jour : COVID-19 et permis de travail pour les NAS de la série 900 — Procédures pour les mesures à prendre dans ces situations.
       [Mise à jour : COVID-19 et permis de travail pour les NAS de la série 900 — Procédures](/fr/site/dossier/updated_covid19_work_permit_900_sin.shtml)

     [Mise à jour : COVID-19 et permis de travail pour les NAS de la série 900 — Procédures](/fr/site/dossier/updated_covid19_work_permit_900_sin.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0974.dita`

Remarque :

L’agent continue à suivre les procédures normales pour déterminer si la décision sur une question litigieuse peut être reportée dans les demandes renouvelées et continues de prestations d’AE dont le DPP est avant le 15 mars 2020. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0975.dita`

Remarque :

Les procédures n’ont pas été mises à jour. Consultez COVID-19 — Modifications aux procédures pour un tableau de procédures touchées.
       [COVID-19 — Modifications aux procédures](/fr/procedure/generic/covidhu.shtml)

     [COVID-19 — Modifications aux procédures](/fr/procedure/generic/covidhu.shtml) 
