# Renseignements : Mesures provisoires additionnelles pour les clients touchés par la perturbation des services postaux de 2024

Source map: `fr_FR/site/dossier/info-add-imca-psd-2024/info-add-imca-psd-2024.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/info-add-imca-psd-2024/sommaire.dita`

Les mesures provisoires pour le recueil de faits et les RE sont en vigueur pour la durée de la perturbation des services postaux. 

## Generic

Source topic: `fr_FR/site/dossier/info-add-imca-psd-2024/generic.dita`

Les mesures suivantes améliorent, mais ne remplacent pas , les procédures existantes et elles complémentent les directives dans Renseignements : Mesures provisoires pour les clients touchés par la perturbation des services postaux de 2024 .
       [Renseignements : Mesures provisoires pour les clients touchés par la perturbation des services postaux de 2024](/fr/site/dossier/info-2024-postal-str-gen.shtml)

**Recueil de faits**

Quand un client, un employeur ou une tierce personne n’a pas de numéro de téléphone avec une messagerie vocale ou de courriel, l’agent déplace l’AT vers En suspens de la façon suivante :

- Motif de la mise en suspens : Choisir Autre .

- Commentaires : Saisir « Perturbation postale. »

- Date à revoir : Saisir la date d’aujourd’hui + 3 jours ouvrables.

L’agent répète le déplacement de l’AT vers En suspens jusqu’à la fin de la perturbation des services postaux, au besoin.

À la fin de la perturbation des services postaux, si le client n’est pas joint lors du recueil de faits ou n’a pas communiqué avec l’agent, l’agent crée et envoie la lettre N-10-00-00. Ensuite, l’agent déplace l’AT vers En suspens pour 10 jours supplémentaires avant de suivre les procédures habituelles.

À la fin de la perturbation des services postaux, lors du recueil de faits avec l’employeur ou de la tierce personne, l’agent crée et envoie la lettre Z-00-00-00. Ensuite, l’agent déplace l’AT vers En suspens pour 10 jours supplémentaires avant de suivre les procédures habituelles.

Il n’y a pas de modification au recueil de faits quand l’agent a laissé un message dans la messagerie vocale ou envoyé un courriel.

**Vérification du RE**

Quand l’agent ne peut pas laisser un message dans la messagerie vocale à l’employeur, ou quand l’employeur ne répond pas au message laissé dans la messagerie vocale, l’agent obtient l’information d’autres sources (p. ex. le client) et corrige le RE, ou il estime les renseignements manquants requis pour corriger le RE.

L’agent crée et envoie la lettre Z-02-00-00 selon les renseignements de la demande, et il choisit tous les attributs requis, y compris les suivants :

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1012.dita) 

L’agent crée et envoie aussi la lettre N06-00-00 selon les renseignements de la demande, et il choisit tous les attributs requis, y compris :

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1013.dita) 

S’il y a un AT RE Correction correspondant, l’agent le complète. S’il n’y a pas d’AT RE Correction correspondant, l’agent suit la tâche appropriée pour le calcul de la demande. L’agent ne renvoie pas le dossier Intégrité pour non-conformité.

**RE provisoire**

Quand un RE est manquant parce qu’il n’a pas été reçu par courrier, l’agent crée un RE provisoire.

L’agent ne tient pas compte des directives pour envoyer une lettre à l’employeur quand il effectue un recueil de faits avec l’employeur. 

### Callout

Source topic: `fr_FR/common_notes/note_c_1012.dita`

- Nom de l’employeur ou tierce personne (1335) .

- Adresse 1 de l’employeur ou tierce personne (1337) .

- Phrase d’ouverture pour Demande / Clarification de RDE / Info MCE (3467) .

- Demande du RDE prestataire .

- Avis de changement à un RDE (3499) :

- Plusieurs changements à un RDE ou

- Un seul changement sur le RDE

- Liste des corrections

- P.j. INS 3413 

### Callout

Source topic: `fr_FR/common_notes/note_c_1013.dita`

- Diverses raisons: PAS RDE – Demande approuvée ou non établie (3231)

- Demande approuvée avec RE(s) non vérifié ou provisoire ou RE(s) avec information manquante .

- RE non-vérifié / REs non-vérifiés / RE provisoire / REs provisoires (2931) : Choisir RE non-vérifié ou REs non-vérifiés , selon le cas.

- RE(s) reçu(s)/Renseignements supplémentaires concernant RE(s) (2933) : Choisir Renseignements supplémentaires concernant RE(s) . 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/info-add-imca-psd-2024/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
