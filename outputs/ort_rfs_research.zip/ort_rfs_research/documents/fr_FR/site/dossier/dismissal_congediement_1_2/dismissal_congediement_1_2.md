# Mise à jour : Congédiement – Procédures (Niveau 1 et Niveau 2)

Source map: `fr_FR/site/dossier/dismissal_congediement_1_2/dismissal_congediement_1_2.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/dismissal_congediement_1_2/sommaire.dita`

Dans le cadre de notre engagement à garder le contenu de l’ORL AE à jour, l’activité Congédiement et certaines procédures ont été mises à jour selon les commentaires des régions. 

## Generic

Source topic: `fr_FR/site/dossier/dismissal_congediement_1_2/generic.dita`

La page de l’activité a été mise à jour afin de préciser que si le client n’a pas fourni le motif du congédiement, l’agent effectue un recueil de faits pour déterminer la procédure à suivre.

L’étape pour déterminer si le motif de cessation d’emploi (MCE) est dans la période de référence (PR) pour une demande renouvelée a été supprimée.

L’étape pour déterminer si le client a été joint lors du recueil de faits dans la tâche Rendre une décision sur un congédiement ou une suspension — Demande renouvelée a été supprimée. Ainsi l’agent consulte la tâche Communiquer verbalement une décision défavorable pour compléter l’écran Communication verbale de la décision à l’onglet Résoudre le problème dans SNCT.

Une étape a été ajoutée pour mettre à jour le champ Condition spéciale du RE dans MSRE pour une demande renouvelée quand un MCE précédemment reporté est maintenant admis.

Les étapes dans la section Revoir les éléments au dossier ont été modifiées afin de mieux correspondre à la Politique nationale sur les niveaux de décision qui s’applique à la tâche Terminer une inadmissibilité D42. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/dismissal_congediement_1_2/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
