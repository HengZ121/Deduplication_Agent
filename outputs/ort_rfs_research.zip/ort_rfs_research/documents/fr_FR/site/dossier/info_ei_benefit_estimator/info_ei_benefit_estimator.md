# Renseignements : Nouvel outil en ligne pour les clients — Estimateur de prestations d’AE 101

Source map: `fr_FR/site/dossier/info_ei_benefit_estimator/info_ei_benefit_estimator.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/info_ei_benefit_estimator/sommaire.dita`

Le 24 octobre 2024, un nouvel outil en ligne pour les clients appelé l’Estimateur de prestations d’AE sera mis en œuvre. Les agents peuvent recevoir des demandes de renseignements de clients au sujet du nouvel outil en ligne. 

## Generic

Source topic: `fr_FR/site/dossier/info_ei_benefit_estimator/generic.dita`

L’Estimateur de prestations d’AE aide les clients à prendre des décisions éclairées concernant leurs demandes d’AE avant de présenter une demande. Cet outil couvre tous les genres de prestations (GP). Il aide également à déterminer quel GP pourrait convenir aux clients, que ce soit pour leur situation actuelle ou future, et à estimer le taux et la durée des prestations hebdomadaires.

L’Estimateur de prestations d’AE :

- est facilement accessible sur Canada.ca ;
         [Canada.ca](https://estimateurae-eiestimator.service.canada.ca/fr)

- prends environ 10 minutes à remplir;

- utilise des règles de calcul simplifiées et n’a pas accès au dossier du client;

- est anonyme et aucun renseignement personnel n’est demandé (y compris le NAS);

- n’enregistre aucun renseignement ni aucun résultat.

S’il est déterminé que le client remplit les conditions requises pour recevoir des prestations, l’estimation du taux de prestation et des semaines d’admissibilité est communiquée au client.

S’il est déterminé que le client ne remplit pas les conditions requises pour recevoir des prestations, une explication est fournie au client.

Dans tous les cas, le client est informé de ce qui suit :

- Les résultats ne sont que des estimations.

- Les clients doivent présenter une demande pour obtenir une décision formelle.

- Le processus pour présenter une demande de prestations, avec un lien vers AW.

- Il est important de présenter une demande d’AE immédiatement après avoir cessé de travailler ou après que la rémunération a été réduite pour éviter de perdre des prestations.

- Il faut environ une heure pour remplir la demande d’AE.

- Il est possible de revenir au début et commencer une nouvelle estimation.

- Les données utilisées par l’outil sont mises à jour régulièrement et que les résultats pourraient changer à l’avenir.

Quand l’agent parle au client, l’agent considère que le montant payé peut différer du montant estimé. L’outil fournit seulement une estimation et ne garantit pas que le client remplit les conditions requises et qu’il est admissible. Les autres facteurs qui peuvent avoir une incidence sur les montants sont les trop-payés (T-P), les pénalités au dossier, le supplément familial (SF), etc. De plus, le taux régional de chômage (TRC) produit par Statistique Canada peut varier au fil du temps. Le TRC (sauf pour les territoires) est des moyennes mobiles sur 3 mois ajustées de façon saisonnière. Par conséquent, le TRC obtenu quand les clients utilisent l’Estimateur de prestations d’AE peut différer du TRC obtenu quand les clients présentent une demande de prestations. Il est également possible que les renseignements que le client saisit dans l’outil ne correspondent pas aux chiffres réels dans les systèmes d’AE. Plusieurs facteurs peuvent avoir une incidence sur le fait de remplir les conditions requises pour recevoir des prestations, y compris le motif de la cessation d’emploi (MCE), une demande antérieure (au cours des 12 derniers mois), la disponibilité et l’assurabilité de l’emploi.

L’Estimateur de prestations d’AE examine les renseignements fournis par le client et utilise des règles de calcul pour estimer le taux de prestation et si le client remplit les conditions requises pour recevoir des prestations. Si le client a travaillé assez d’heures pour remplir ces conditions, l’outil estime le nombre de semaines de prestations que le client peut recevoir et le taux de prestations selon la rémunération.

De plus, les renseignements saisis dans l’Estimateur de prestations d’AE ne sont pas liés au dossier du client et ne peuvent pas être utilisés dans une demande d’AE ni pour un appel d’une décision d’AE.

L’Estimateur de prestations d’AE estime seulement un GP par utilisation. Si le client souhaite examiner plusieurs GP, le client doit utiliser l’outil plusieurs fois. Toutefois, si le client fait une estimation pour des prestations de maternité, la page de résultats fournira des renseignements supplémentaires sur la possibilité de remplir les conditions requises pour recevoir des prestations de maladie et aux prestations parentales, car ces 2 GP sont souvent combinés.

La formation est disponible pour les agents dans SABA :

- Nom du cours : Estimateur de prestations d’assurance-emploi (AE)
         [Estimateur de prestations d’assurance-emploi (AE)](https://esdc.sabacloud.com/Saba/Web_spf/CA1PRD0006/common/ledetail/cours000000000131630/latestversion)

- Numéro du cours : 0000148919 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/info_ei_benefit_estimator/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
