# Information : Inondations au Canada (printemps 2019)

Source map: `fr_FR/site/dossier/information_flooding_canada_spring_2019/information_flooding_canada_spring_2019.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/information_flooding_canada_spring_2019/sommaire.dita`

Des mesures d’urgence ont été mises en place afin d’aider les clients touchés par les inondations au Canada. Les mesures décrites ci-après s’appliquent aux clients qui résident dans les zones inondées et qui sont affectés par le sinistre. 

## Generic

Source topic: `fr_FR/site/dossier/information_flooding_canada_spring_2019/generic.dita`

**Codes de référence**

Des codes de référence ont été émis pour les clients qui sont touchés par les inondations.

- Les clients touchés au Québec doivent utiliser le code 2371011233218211.

- Les clients touchés en Atlantique doivent utiliser le code 1640012019218211.

- Les clients touchés en Ontario doivent utiliser le code 3515012019274315.

- Les clients touchés en Saskatchewan et au Manitoba doivent utiliser le code 4317014317012019.

- Les clients touchés en Alberta doivent utiliser le code 4812014812012019.

- Les clients touchés en Colombie Britanique doivent utiliser le code 5986015986012019.

- Les clients touchés dans les Territoires du Nord-Ouest , Yukon et au Nunavut doivent utiliser le code 4813014813012019

Le code de référence du Québec est valide du 14 avril au 29 juin 2019 et celui de l’Atlantique du 27 avril au 29 juin 2019. Le code de référence de l’Ontario est valide du 27 avril au 31 mai 2019.

Seuls les clients qui demandent des prestations régulières peuvent utiliser ce code. Les clients qui demandent des prestations spéciales ne doivent pas l’utiliser.

Les demandes présentées avec le code de référence du Québec seront traitées par des employés affectés spécialement à cette tâche. Pour la région de l’Atlantique, les demandes soumises avec un code de référence seront assignées normalement.

**Adresse des clients**

Le client doit saisir son adresse permanente dans le champ Adresse du domicile sur sa demande AW. Si le client a été temporairement déplacé à la suite des inondations, il peut saisir une adresse temporaire dans le champ Adresse postale . Cette adresse temporaire pourrait être celle d’un hôtel, d’un centre communautaire, ou autre.

**RE provisoires**

Puisqu’il est possible que les employeurs soient incapables d’émettre des RE, un RE provisoire doit être créé dès que possible pour les clients touchés.

**Motif de cessation d’emploi**

Si le client ne travaille plus en raison de l’évacuation obligatoire, ou parce que l’entreprise est fermée à cause des inondations, on considère le motif de cessation d’emploi comme étant non litigieux. Toutefois, si un client a quitté son emploi ou a pris un congé autorisé à cause des inondations, la décision doit être rendue par un agent de Niveau 2. Il faut suivre les principes normaux de la prise de décision pour déterminer si le client avait un motif valable pour quitter son emploi ou prendre un congé.

**Disponibilité**

La disponibilité d’un client touché peut être accordée par un agent de Niveau 1, sauf si d’autres informations figurant au dossier indiquent que le client pourrait ne pas être disponible. Il faut suivre les principes normaux de la prise de décision. Cependant, l’agent de Niveau 2 doit prendre en considération la situation personnelle du client quand il rendra une décision sur la disponibilité.

**Rémunération**

Certains clients pourraient être admissibles à une aide financière gouvernementale ou provenant d’un organisme de bienfaisance. Ces rémunérations sont considérées comme des sommes de secours et ne constituent pas une rémunération aux fins des prestations. Un agent du Niveau 1 traite ces sommes.

Toute autre somme ou indemnité versée par l’employeur pour venir en aide à ses employés sinistrés doit être évaluée selon les règles habituelles.

**Procédures du Québec**

La région du Québec a créé un document de référence qui contient de l’information liée au traitement pour les agents qui sont responsables des demandes de clients touchés par les inondations au Québec.
       [document de référence](/resources/ort/documents/DEOAE-BREFF-20190425-NoteServiceInondations2019-VF.docx )

**Client en dehors de la région touchée**

Si une demande de prestations est présentée avec le code de référence d’une région, mais que l’adresse résidentielle fournie est en dehors de cette région, la demande sera tout de même calculée selon le code de référence utilisé. Une fois la demande finalisée, elle sera transférée dans la région où le client réside. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/information_flooding_canada_spring_2019/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
