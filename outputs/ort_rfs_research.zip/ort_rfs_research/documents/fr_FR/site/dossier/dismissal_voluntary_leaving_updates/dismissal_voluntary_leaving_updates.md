# Congédiement et Départ volontaire : Mise à jour

Source map: `fr_FR/site/dossier/dismissal_voluntary_leaving_updates/dismissal_voluntary_leaving_updates.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/dismissal_voluntary_leaving_updates/sommaire.dita`

Les tâches des activités Congédiement et Départ volontaire ont été mise à jour afin d’inclure les étapes à prendre lorsqu’une exclusion doit être annulée à la suite d’une nouvelle décision. 

## Generic

Source topic: `fr_FR/site/dossier/dismissal_voluntary_leaving_updates/generic.dita`

Au moment de convertir ou de renouveler une demande, une décision doit être rendue au sujet de tout MCE reporté.

Si la décision concernant le MCE est reportée, une exclusion est saisie dans ETI quand des prestations spéciales sont accordées. Les agents doivent toujours vérifier si un MCE litigieux a fait l’objet d’une décision en vérifiant s’il y a un rapport de décision (RD) dans SNCT. Si une décision a été rendue au sujet du MCE et qu’une exclusion 10 - Congédiement - inconduite prouvée (D10) ou 11 - Abandon volontaire - motif valable non prouvé (D11) figure au dossier, aucune prestation régulière n’est payable pour cette demande.

Si le MCE est désormais accordé, l’agent doit annuler la D10 ou la D11 qui figure au dossier. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/dismissal_voluntary_leaving_updates/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
