# Renseignements : Budget 2021 — Retrait des mesures temporaires

Source map: `fr_FR/site/dossier/budget_2021_temp_measure_rollback/budget_2021_temp_measure_rollback.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/budget_2021_temp_measure_rollback/sommaire.dita`

Les mesures législatives temporaires qui ont été présentées dans le budget 2021 prendront fin le 24 septembre 2022. 

## Generic

Source topic: `fr_FR/site/dossier/budget_2021_temp_measure_rollback/generic.dita`

La fin des mesures temporaires présentées dans le budget 2021 marquera un retour à plusieurs procédures et processus en œuvre avant la pandémie de COVID-19.

Pour les demandes dont le DPP est la s/c 2362 ou après :

- Le client doit répondre aux normes d’admissibilité suivantes dans sa période de référence (PR) pour le genre de prestations (GP) demandé :

- Pour les prestations régulières, une norme variable d’admissibilité (NVA) entre 420 et 700 heures d’emploi assurable selon le taux régional de chômage (TRC).
             [norme variable d’admissibilité](/fr/procedure/generic/additionalresources/ver_reg_ben.shtml)

- Pour les prestations spéciales, un minimum de 600 heures d’emploi assurable ou 3 760 $ de rémunération assurable provenant de la pêche.

- Pour les prestations de pêcheur, une NVA entre 2 500 $ et 4 200 $ de rémunération assurable provenant de la pêche selon le TRC.

- Pour les prestations spéciales pour les travailleurs indépendants, un minimum de 8 092 $ en rémunération nette provenant d’un travail indépendant (TI) (le montant de la rémunération minimale provenant d’un TI change chaque année au début janvier).
             [rémunération nette provenant d’un travail indépendant (TI)](/fr/procedure/task/all_se_earnings.shtml)

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0964.dita)

- Les règles précédentes pour rendre une décision sur une question liée à motif de cessation d’emploi (MCE) s’appliqueront :

- Une décision sera rendue sur toutes les questions litigieuses liées à un MCE dans la PR pour déterminer si la rémunération et les heures assurables devraient être incluses ou exclues du calcul de la demande, ou si une exclusion devrait être imposée.

- Toutes les règles précédentes sur le report d’une décision seront à nouveau en vigueur.

- Une décision continuera d’être requise sur toutes les questions litigieuses liées à un MCE dans la période de prestations (PP).

De plus, à partir du 25 septembre 2022, toutes les indemnités de cessation d’emploi seront réparties dans les demandes et déduites des prestations.

Les procédures, les ressources de formation et les systèmes seront mis à jour en conséquence. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0964.dita`

Remarque :

Quand il y a une violation au dossier, une majoration de la norme d’admissibilité s’applique. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/budget_2021_temp_measure_rollback/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
