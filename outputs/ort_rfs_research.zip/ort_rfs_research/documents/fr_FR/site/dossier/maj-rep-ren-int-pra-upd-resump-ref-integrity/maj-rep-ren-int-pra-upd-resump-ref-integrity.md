# Mise à jour : Reprise des renvois à l’Intégrité — Procédures et ressource additionnelle (Non complexe, Niveau 1 et Niveau 2)

Source map: `fr_FR/site/dossier/maj-rep-ren-int-pra-upd-resump-ref-integrity/maj-rep-ren-int-pra-upd-resump-ref-integrity.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/maj-rep-ren-int-pra-upd-resump-ref-integrity/sommaire.dita`

Depuis mars 2020, en raison de la COVID-19, les agents renvoyaient seulement les dossiers urgents et des questions précises à Intégrité. Intégrité a désormais repris la plupart de ses enquêtes. 

## Generic

Source topic: `fr_FR/site/dossier/maj-rep-ren-int-pra-upd-resump-ref-integrity/generic.dita`

La restriction sur le renvoi des questions à Intégrité a été levée pour toutes les questions, sauf celles liées au travail indépendant (TI). L’agent renvoie la question à Intégrité seulement si la question liée au TI a une incidence sur le versement des prestations futures. Les agents peuvent désormais renvoyer toutes les autres questions à Intégrité en suivant les procédures habituelles.

De plus, à la suite d’une collaboration entre Intégrité et Analyse de rentabilité et gestion de l’information, des modifications ont été apportées à la section Motif de cessation d’emploi (MCE) litigieux non déclaré dans la tâche Déterminer si une question doit être renvoyée à Intégrité . L’agent détermine si un MCE litigieux non déclaré a une incidence sur le travail actuel :

- Si oui, l’agent détermine le genre de prestations (GP) que le client a reçu après le dernier jour travaillé (DJT) du MCE litigieux afin de déterminer les prochaines étapes.

- Si non, l’agent ne renvoie pas le dossier à Intégrité et ne rend pas une décision sur la question. Le MCE déclenche la création d’une enquête par l’un des programmes de détection d’Intégrité. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/maj-rep-ren-int-pra-upd-resump-ref-integrity/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
