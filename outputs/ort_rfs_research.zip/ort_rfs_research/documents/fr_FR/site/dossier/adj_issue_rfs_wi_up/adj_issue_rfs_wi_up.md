# AT Litige - Décision Examen du MCE — Mise à jour de la procédure

Source map: `fr_FR/site/dossier/adj_issue_rfs_wi_up/adj_issue_rfs_wi_up.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/adj_issue_rfs_wi_up/sommaire.dita`

La procédure pour traiter un AT Litige - Décision Examen du MCE : K — Autre a été mise à jour selon les commentaires des régions. 

## Generic

Source topic: `fr_FR/site/dossier/adj_issue_rfs_wi_up/generic.dita`

Quand le recueil de faits révèle que le client continue de travailler à temps partiel, la disponibilité devient un litige qui nécessite une décision. Dans ce cas, l’agent crée un AT Litige – Décision (DEC) Disponibilité avant de mettre à jour le motif de cessation d’emploi (MCE) dans MSRE et de compléter l’AT Litige - Décision Examen du MCE dans SNCT. Cette étape empêche la demande d’être automatisée avant que l’agent rende une décision sur la disponibilité du client.

Une considération régionale a été ajoutée. Dans la région du Québec, les conseillers en expertise opérationnelle et non les chefs d’équipe, suppriment les AT. Si la procédure le nécessite, l’agent utilise l’Outil national de l'expertise opérationnelle (NEXO) pour demander au conseiller en expertise opérationnel de supprimer l’AT DEC. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/adj_issue_rfs_wi_up/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
