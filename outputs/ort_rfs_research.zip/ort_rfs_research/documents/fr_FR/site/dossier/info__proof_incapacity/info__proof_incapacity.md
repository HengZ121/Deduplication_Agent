# Renseignements : Mise à jour de la Politique sur la preuve d’incapacité et détermination de la semaine de guérison et de la semaine de début de l’incapacité dans une demande de prestations de maladie

Source map: `fr_FR/site/dossier/info__proof_incapacity/info__proof_incapacity.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/info__proof_incapacity/sommaire.dita`

Après avoir reçu des demandes de précision sur la formulation et l’interprétation de la Politique sur la preuve d’incapacité , la division de la politique opérationnelle de l’AE a déterminé qu’une mise à jour est nécessaire pour fournir des directives claires et concises. La Politique sur la preuve d’incapacité sera mise à jour le 7 avril 2024, et comprend des modifications sur la façon de déterminer la semaine de guérison et la semaine de début de l’incapacité dans une demande de prestations de maladie.
       [Politique sur la preuve d’incapacité](https://ort-orl.esdc-edsc.canada.ca/fr/policy/nationalpolicy/proof_of_incapacity_policy.shtml) 
       [Politique sur la preuve d’incapacité](https://ort-orl.esdc-edsc.canada.ca/fr/policy/nationalpolicy/proof_of_incapacity_policy.shtml) 

## Generic

Source topic: `fr_FR/site/dossier/info__proof_incapacity/generic.dita`

La prolongation du nombre de semaines de prestations a fourni une plus grande flexibilité aux citoyens canadiens qui nécessitaient des prestations de maladie. Afin de s’assurer de la gérance du compte de l’AE, tout en cherchant un équilibre approprié avec le service au client, la Politique sur la preuve d’incapacité a été mise à jour pour préciser quand un client devrait présenter un certificat médical à la Commission.

Dans une demande de prestations de maladie, quand le motif de cessation d’emploi (MCE) est D - Maladie ou blessure et le client n’ a pas besoin de présenter un certificat médical avant le versement des prestations de maladie, la semaine de guérison sera désormais calculée comme étant le DPP + 8 plutôt que le DPP + 15. Cette modification s’appliquera à toutes les demandes dont le DPP est le 7 avril 2024 (s/c 2442) ou après. Une mise à jour des systèmes mettra en œuvre cette modification.

La Politique sur la preuve d’incapacité sera également mise à jour avec des directives pour déterminer la date de début de l’incapacité dans une demande de prestations de maladie.

Les procédures touchées par cette mise à jour de la politique seront modifiées de façon appropriée le 8 avril 2024.

Même si tous les clients sont tenus d’obtenir un certificat médical pour recevoir des prestations de maladie, AW sera mis à jour le 16 mars 2024 avec des nouveaux messages indiquant si un certificat médical doit être présenté avec la demande d’AE. Ceci permettra aux clients de mieux comprendre quand un certificat médical doit être présenté à la Commission et contribuera à alléger la charge de travail du traitement de l’AE. L’option de téléverser un certificat médical s’affichera seulement dans des cas précis. Cela permettra d’éviter la création d’AT inutiles liés à des certificats médicaux que le client n’avait pas besoin de présenter avec sa demande d’AE. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/info__proof_incapacity/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
