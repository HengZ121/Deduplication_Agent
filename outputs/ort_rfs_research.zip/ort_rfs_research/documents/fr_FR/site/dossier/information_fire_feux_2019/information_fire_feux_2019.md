# Renseignements : Feux de forêt dans l’ouest du Canada et en Ontario — Printemps 2019

Source map: `fr_FR/site/dossier/information_fire_feux_2019/information_fire_feux_2019.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/information_fire_feux_2019/sommaire.dita`

Des mesures d’urgence ont été mises en place afin d’aider les clients touchés par les feux de forêt dans l’ouest du Canada et en Ontario. Les mesures décrites ci-après s’appliquent aux clients qui vivent dans les zones évacuées ou qui sont affectés par le sinistre. 

## Generic

Source topic: `fr_FR/site/dossier/information_fire_feux_2019/generic.dita`

**Codes de référence**

Des codes de référence ont été émis pour les clients qui sont touchés par les feux de forêt :

- Les clients touchés en Alberta doivent utiliser le code 4812014812201900

- Les clients touchés en Colombie-Britannique doivent utiliser le code 5986015986201900

- Les clients touchés en Saskatchewan et au Manitoba doivent utiliser le code 4317014317201900

- Les clients touchés dans les Territoires du Nord-Ouest, au Yukon et au Nunavut doivent utiliser le code 4813014813201900

- Les clients touchés en Ontario doivent utiliser le code 3529012019061119

Seuls les clients qui demandent des prestations régulières peuvent utiliser ces codes. Les clients qui demandent des prestations spéciales ne doivent pas les utiliser.

**Adresse du client**

Le client doit saisir son adresse permanente dans le champ Adresse du domicile sur sa demande AW. Si le client a été temporairement déplacé à cause des feux de forêt, il peut saisir une adresse temporaire dans le champ Adresse postale . Cette adresse temporaire pourrait être celle d’un hôtel, d’un centre communautaire, ou autre.

**RE provisoires**

Puisqu’il est possible que les employeurs soient incapables d’émettre des RE, un RE provisoire doit être créé dès que possible pour les clients touchés.

**Motif de cessation d’emploi**

Si le client ne travaille plus en raison de l’évacuation obligatoire, ou parce que l’entreprise est fermée à cause des feux de forêt, on considère le motif de cessation d’emploi (MCE) comme étant non litigieux. Toutefois, si un client a quitté son emploi ou a pris un congé autorisé à cause des feux de forêt mais sans être directement affecté, un agent de Niveau 2 doit rendre une décision. Il faut suivre les principes normaux de la prise de décision pour déterminer si le client avait un motif valable pour quitter son emploi ou prendre un congé autorisé.

**Disponibilité**

La disponibilité d’un client touché peut être accordée par un agent de Niveau 1, sauf si d’autres informations figurant au dossier indiquent que le client pourrait ne pas être disponible. Il faut suivre les principes normaux de la prise de décision. Cependant, l’agent de Niveau 2 doit prendre en considération la situation personnelle du client quand il rendra une décision sur la disponibilité.

**Rémunération**

Certains clients pourraient être admissibles à une aide financière gouvernementale ou provenant d’un organisme de bienfaisance. Ces rémunérations sont considérées comme des sommes de secours et ne constituent pas une rémunération aux fins des prestations. Un agent du Niveau 1 peut traiter ces sommes.

Toute autre somme ou indemnité versée par l’employeur pour venir en aide à ses employés sinistrés doit être évaluée selon les règles habituelles.

**Évènements majeurs en entreprise**

Les agents doivent s’assurer de consulter régulièrement le Bulletin d’information — Évènements majeurs en entreprise (EME) pour obtenir des renseignements sur les employeurs et groupes d’employés touchés par le sinistre. La région de l’Ontario a créé un évènement dans le bulletin EME relativement aux feux de forêt sous « Ontario Fires 2019 - Pikangikum in Northern Ontario ».

**Clients en dehors des provinces touchées**

Si une demande de prestations est présentée avec le code de référence d’une région, mais que l’adresse résidentielle fournie est en dehors de cette région, la demande est tout de même calculée selon le code de référence utilisé. Une fois la demande finalisée, elle sera transférée dans la région où le client réside.

La région de l’Ouest du Canada et des territoires a formé une équipe pour le traitement des dossiers liés aux feux de forêt. Les agents des autres régions doivent réassigner tous les AT liés au sinistre à la hiérarchie suivante : Serv de trait & paiement nat (STP) / Traitement spécialisé AE / Traitement spécialisé AE - OT / Inoccupé - OT . 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/information_fire_feux_2019/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
