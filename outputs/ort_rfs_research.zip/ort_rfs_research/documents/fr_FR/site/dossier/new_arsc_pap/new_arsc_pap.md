# Nouveauté : Rendre une décision sur le motif de cessation d’emploi dans des conversions — Politique et procédures (Niveau 1 et Niveau 2)

Source map: `fr_FR/site/dossier/new_arsc_pap/new_arsc_pap.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/new_arsc_pap/sommaire.dita`

Les nouvelles directives en matière de politique exigent que l’agent rende des décisions sur les questions litigieuses liées aux motifs de cessation d’emploi (MCE) dans la période de référence (PR) quand un client demande une conversion de prestations spéciales en prestations régulières pour les demandes dont le DPP est entre la s/c 2258 et la s/c 2309. 

## Generic

Source topic: `fr_FR/site/dossier/new_arsc_pap/generic.dita`

Depuis le 27 septembre 2020, les demandes pour les prestations régulières et de maladie automatisées dans le processus spécialisé du TAD étaient établies sans rendre de décision sur les questions litigieuses liées au MCE dans la PR du client. À partir de maintenant, l’agent rend une décision sur toutes les questions liées au MCE dans la période de 12 semaines avant l’arrêt de rémunération (A de R) utilisé pour établir la demande quand les clients demandent une conversion de prestations spéciales en prestations régulières.

Les demandes en cours de conversion de prestations spéciales en prestations régulières qui comprennent un MCE litigieux dans la PR sont indiquées à l’aide d’un traitement manuel 1 - Suspension générale des prestations (TM01) et d’un AT Action à prendre (AP). Pour aider les agents à traiter ces AT, une nouvelle procédure a été élaborée. Cette procédure fournit les directives requises pour mettre en œuvre les nouvelles lignes directices en matière de politique et pour rendre des décisions sur les questions liées au MCE sur lesquelles aucune décision n’a été rendue quand le client a présenté sa demande de prestations initiale.

Les questions liées au MCE pour lesquelles aucune décision n’a été rendue auparavant peuvent être identifiées car le champ Condition spéciale a été laissé vide dans le RE, mais le RE a été inclus dans le calcul initial.

L’agent ne doit pas rendre une décision sur les questions litigieuses liées au MCE dans la PR pour les demandes de prestations de maladie automatisées dans le processus spécialisé du TAD qui font maintenant l’objet d’un nouveau calcul car le client a demandé des prestations régulières à partir du DPP.

**Incidence sur la décision**

Si la décision rendue est négative et qu’une exclusion ou une inadmissibilité s’applique, la date d’entrée en vigueur correspond au début de la semaine de conversion de la demande et non à la date de l’événement. Il peut y avoir des cas où le client a reçu des semaines de prestations régulières avant que le traitement manuel (TM) soit imposé. Dans ces cas, l’exclusion ou l’inadmissibilité entre en vigueur à la semaine d’imposition du TM01. Dans les cas où une décision négative a été rendue et qu’aucun TM n’a été imposé, les exclusions ou inadmissibilités entrent en vigueur au début de la semaine à laquelle la décision a été rendue.

**Remplir à nouveau les conditions requises et nouveau calcul**

Un client qui a accumulé suffisamment d’heures assurables pour établir une période de prestations (PP) depuis la plus récente exclusion est considéré remplir à nouveau les conditions requises et aucune exclusion n’est imposée. Cependant, en raison du crédit unique d’heures assurables, le client doit accumuler 120 heures d’emploi assurable depuis la plus récente exclusion pour remplir à nouveau les conditions requises. Si le client remplit ces conditions, le RE ayant l’exclusion est exclu et aucune exclusion n’est imposée.
       [période de prestations](/fr/procedure/generic/knowledge.shtml#Periode_de_prestations)

Quand l’agent détermine que le client remplit à nouveau les conditions requises après l’événement le plus récent qui a entraîné l’exclusion, l’agent détermine habituellement si un nouveau calcul est requis en examinant les modifications au taux de prestations ou aux semaines d’admissibilité. Comme toutes les demandes dont les DPP est entre la s/c 2258 et la s/c 2309 comprendront 50 semaines d’admissibilité, un nouveau calcul est uniquement requis si le taux de prestations du client est supérieur au taux minimum de 500 $. Par conséquent, une fois qu’une décision a été rendue pour chaque question litigieuse liée au MCE, un nouveau calcul n’ est pas requis si une exclusion a été imposée sur le RE le plus récent ou si le client a un taux de prestations de 500 $. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/new_arsc_pap/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
