# Renseignements : Centre de services aux employeurs et AT Évaluation du relevé d’emploi à compléter

Source map: `fr_FR/site/dossier/info_empl_cont_cent_and_comp_roe_issu_wi/info_empl_cont_cent_and_comp_roe_issu_wi.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/info_empl_cont_cent_and_comp_roe_issu_wi/sommaire.dita`

À compter du 2 mai 2022, un agent du Centre de services aux employeurs pourra mettre à jour et compléter certains AT Évaluation du relevé d’emploi (RE) Correction, Commentaires et MCE litigieux quand il aide des employeurs communiquant avec le centre d’appels. 

## Generic

Source topic: `fr_FR/site/dossier/info_empl_cont_cent_and_comp_roe_issu_wi/generic.dita`

L’agent du Centre de services aux employeurs est responsable de répondre aux questions des employeurs sur la façon de remplir les RE. À partir du 2 mai 2022, il sera également autorisé à corriger certaines erreurs dans les RE qui empêchent la validation.

L’agent du Centre de services aux employeurs recevra des directives, correspondant aux procédures de l’ORL AE, sur la façon de traiter les AT RE Correction, Commentaires et MCE litigieux qui seraient autrement dans la file d’attente de SNCT pour le prochain agent de traitement disponible. Ceci permettra de réduire les appels des employeurs et d’améliorer l’automatisation.

Les procédures actuelles de l’ORL AE ne seront pas modifiées. Si un agent du Centre de services aux employeurs reçoit l’appel d’un employeur et qu’il y a des erreurs empêchant la validation du RE, l’agent corrigera, validera et consignera les modifications apportées au RE dans MSRE. Si un AT est déjà assigné à un agent de traitement, un chef d’équipe du Centre de services aux employeurs sera autorisé à le réassigner à un agent du Centre de services aux employeurs pour que l’AT soit complété. L’agent du Centre de services aux employeurs enverra un courriel à son chef d’équipe (en ajoutant en CC l’agent de traitement à qui l’AT est assigné) et demandera que l’AT lui soit réassigné.

Même si le système valide automatiquement les RE, il arrive parfois que la validation puisse seulement être effectuée quand une modification (p. ex. la suppression d’un commentaire) est faite dans MSRE. Si une erreur est détectée lors de la validation, SNCT ne crée pas automatiquement un AT RE Correction, mais cette erreur empêche TAD de calculer la demande. Si possible, l’agent du Centre de services aux employeurs effectuera toutes les corrections requises pour valider le RE. Toutefois, s’il ne peut pas corriger l’erreur, il créera un AT RE Correction pour un agent de traitement en suivant les procédures habituelles de l’ORL AE. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/info_empl_cont_cent_and_comp_roe_issu_wi/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
