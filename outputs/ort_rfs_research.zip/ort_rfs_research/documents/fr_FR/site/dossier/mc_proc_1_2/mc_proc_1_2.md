# Mise à jour : COVID-19 et certificats médicaux manquants — Procédures (Niveau 1 et Niveau 2)

Source map: `fr_FR/site/dossier/mc_proc_1_2/mc_proc_1_2.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/mc_proc_1_2/sommaire.dita`

En raison de la COVID-19, le gouvernement du Canada a supprimé l’obligation pour les clients de fournir une preuve médicale lorsqu’ils demandent des prestations. 

## Generic

Source topic: `fr_FR/site/dossier/mc_proc_1_2/generic.dita`

[Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1119.dita) 

**Table des matières**

- Ce qu’il faut savoir
         [Ce qu’il faut savoir](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/mc_proc_1_2#cfs)

- Processus temporaire
         [Processus temporaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/mc_proc_1_2#pt)

**Ce qu’il faut savoir**

Habituellement, quand une preuve est nécessaire, le client doit fournir un certificat médical. Le gouvernement a supprimé cette l’exigence pour des périodes précises afin de simplifier le processus d’obtenir des prestations. Ceci réduira le nombre de clients qui doivent consulter leur médecin afin obtenir des prestations. Lorsque les mesures de simplification s’appliquent, les agents ne doivent pas demander aux clients un certificat médical.

**Certificat médical pour les prestations de maladie, pour justifier un motif de cessation d’emploi (MCE) ou en cas de guérison anticpée**

Pour les périodes de prestations (PP) établies entre le 15 mars 2020 (s/c 2230) et le 19 septembre 2021 (s/c 2309), un client n’a plus l’obligation de fournir un certificat médical pour recevoir des prestations de maladie. Cela s’applique également aux demandes de prestations régulières quand un client doit justifier le MCE pour raisons médicales.

Quand un client demande des prestations régulières après avoir reçu des prestations de maladie et déclare une guérison anticipée, aucun certificat médical n’est requis si la date d’entrée en vigueur de la conversion est entre 15 mars 2020 (s/c 2230) et le 19 septembre 2021 (s/c 2309).

Pour les PP établies avant le 15 mars 2020, aucun nouveau certificat médical n’est requis pour verser des prestations de maladie entre le 15 mars 2020 et le 25 septembre 2021.

Toute demande dont le DPP est la s/c 2309 (19 septembre 2021) ou avant sera soumise à la modification temporaire, et les demandes dont le DPP est la s/c 2310 (26 septembre 2021) ou après retourneront aux dispositions standards.

**Certificat médical pour les PDC ou les prestations pour proches aidants**

Pour les demandes de PDC ou de prestations pour proches aidants dont le DPP est entre la s/c 2230 (15 mars 2020) et la s/c 2258 (27 septembre 2020), un client qui demande des PDC ou des prestations pour proches aidants n’a pas besoin de fournir un certificat médical ou une autorisation de délivrer un certificat médical pour être admissible aux prestations. Pour les demandes dont le DPP est la s/c 2259 ou après, le client doit fournir un certificat médical et une autorisation de délivrer un certificat médical selon les procédures habituelles pour recevoir ces prestations.

Pour les PP établies avant le 15 mars 2020, aucun nouveau certificat médical n’est requis pour verser des prestations spéciales dans une demande renouvelée ou de conversion entre la s/c 2230 (15 mars 2020) et la s/c 2258 (27 septembre 2020).

Quand un certificat médical n’est pas fourni, l’agent ajoute un rapport de décision (RD) au dossier pour indiquer qu’aucun certificat médical n’est requis en raison des mesures de simplification.

Toute demande dont le DPP est la s/c 2258 (27 septembre 2020) ou avant sera soumise à la mesure temporaire, et les demandes dont le DPP est la s/c 2259 (04 octobre 2020) ou après retourneront aux dispositions standards.

**Examiner un certificat médical fourni par le client**

Quand un certificat médical est fourni, il doit être examiné pour déterminer l’admissibilité des clients. L’agent rend une décision sur la question selon les procédures habituelles.

**Prestations régulières et de maladie**

Les procédures suivantes ont été mises à jour :

- Convertir une demande de prestations régulières en prestations de maladie
         [Convertir une demande de prestations régulières en prestations de maladie](/fr/procedure/task/conv_regsick.shtml)

- Convertir une demande de prestations régulières en prestations de maladie lorsque le client est dirigé en vertu de la LAE 25 — Demande continue
         [Convertir une demande de prestations régulières en prestations de maladie lorsque le client est dirigé en vertu de la LAE 25 — Demande continue](/fr/procedure/task/conv_regsick_eia25.shtml)

- Convertir des prestations de maternité en prestations de maladie
         [Convertir des prestations de maternité en prestations de maladie](/fr/procedure/task/conv_matsick.shtml)

- Convertir des prestations parentales en prestations de maladie
         [Convertir des prestations parentales en prestations de maladie](/fr/procedure/task/conv_parsick.shtml)

- Renouveler une demande de prestations de maladie
         [Renouveler une demande de prestations de maladie](/fr/procedure/task/renew_sb.shtml)

- Déterminer si un certificat médical est requis ou acceptable — Prestations de maladie
         [Déterminer si un certificat médical est requis ou acceptable — Prestations de maladie](/fr/procedure/task/calc_determining/det_mc_ra.shtml)

- Rendre une décision sur un départ volontaire (Niveau 1) : Raisons médicales — Demande initiale
         [Rendre une décision sur un départ volontaire (Niveau 1) : Raisons médicales — Demande initiale](/fr/procedure/task/vllevel1_mr_ic.shtml)

- Rendre une décision sur un départ volontaire (Niveau 1) : Raisons médicales — Demande continue
         [Rendre une décision sur un départ volontaire (Niveau 1) : Raisons médicales — Demande continue](/fr/procedure/task/voluntary_leaving_medical_reason_l1.shtml)

- Rendre une décision sur un départ volontaire (Niveau 1) : Raisons médicales — Demande renouvelée
         [Rendre une décision sur un départ volontaire (Niveau 1) : Raisons médicales — Demande renouvelée](/fr/procedure/task/vllevel1_mr_rc.shtml)

- Convertir des prestations de maladie en prestations régulières
         [Convertir des prestations de maladie en prestations régulières](/fr/procedure/task/conv_sickreg.shtml)

**PDC**

**Processus temporaire**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0979.dita) 

**Déterminer l’admissibilité**

Pour les nouvelles PP, les PP renouvelées ou converties entre le 15 mars 2020 (s/c 2230) et le 27 septembre 2020 (s/c 2258), l’agent considère que le client est admissible à toute prestation qui aurait été payable si le certificat médical avait été émis. Cela signifie que le patient remplit les conditions suivantes :

- Le patient risque de décéder dans les 26 prochaines semaines.

- Le patient a besoin de soins ou de soutien.

L’agent n’ effectue pas de recueil de faits auprès du client et considère que ces conditions d’admissibilité sont remplies, comme si le certificat médical avait été fourni.

**Déterminer la fenêtre de compassion (FC)**

Quand il n’ y a aucune de FC existante, au lieu d’utiliser des renseignements qui seraient normalement fournis dans un certificat médical, l’agent utilise :

- le DPP pour déterminer le début de la FC des demandes initiales;

- la semaine de renouvellement pour déterminer le début de la FC des demandes renouvelées.

- la semaine où la demande est convertie en PDC pour déterminer le début de la FC lors d’une conversion sur une demande continue.

Quand il y a déjà une FC pour un patient, l’agent suit les procédures habituelles. L’agent marque le nouveau certificat comme un double et ajoute le prestataire au certificat existant.

**Changements aux saisies requises dans SSA**

Pour les PDC, aucune saisie supplémentaire n’est requise à l’écran Annexe - Prestations spéciales , puisque le champ Preuve de compassion est prérempli avec Oui .

**Changements aux saisies de la transaction Entrée des données de Proches aidants/Soins de compassion (MCB1)**

Quand il n’ y a aucune FC existante, suivre les directives suivantes :

- Confirmation du certificat : Choisir O - Approuvé .

- Date de début : Saisir la date de début appropriée. (date de début du DPP, la semaine du renouvellement ou la semaine de conversion)

**Prestations pour proches aidants**

**Processus temporaire**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0979.dita) 

**Déterminer l’admissibilité**

Pour les nouvelles PP, les PP renouvelées ou converties entre le 15 mars 2020 (s/c 2230) et le 27 septembre 2020 (s/c 2258), l’agent considère que le client est admissible à toute prestation qui aurait été payable si le certificat médical avait été émis. Cela signifie que le patient remplit les conditions suivantes :

- La vie du patient est en danger.

- Il y a eu un changement dans l’état de santé de base du patient.

- Le patient a besoin de soins ou de soutien.

L’agent n’ effectue pas de recueil de faits auprès du client et considère que ces conditions d’admissibilité sont remplies, comme si le certificat médical avait été fourni.

**Déterminer la fenêtre de compassion (FC) et la fenêtre pour proches aidants (FPA)**

Quand il n’ y a aucune de FPA existante, au lieu d’utiliser des renseignements qui seraient normalement fournis dans un certificat médical, l’agent utilise :

- le DPP pour déterminer le début de la FPA des demandes initiales;

- la semaine de renouvellement pour déterminer le début de la FPA des demandes renouvelées.

- la semaine où la demande est convertie en proches aidants pour déterminer le début de la FPA lors d’une conversion sur une demande continue.

Quand il y a déjà une FC ou une FPA pour un patient, l’agent suit les procédures habituelles. L’agent marque le nouveau certificat comme un double et ajoute le prestataire au certificat existant.

**Déterminer la date de fin des soins ou du soutien pour les prestations de proches aidants**

Pour calculer la date de fin des soins ou du soutien, l’agent utilise le DPP + 51 semaines pour les demandes initiales, la semaine de renouvellement + 51 semaines pour les demandes renouvelées et la semaine de conversion + 51 semaines pour les demandes de conversions.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1120.dita) 

Lorsque la FPA a été établie avant le 15 mars 2020, et que le client demande des semaines supplémentaires à être payées entre le 15 mars 2020 et le 3 octobre 2020, aucun certificat médical n ’est requis.

Si la date initiale de fin des soins ou du soutien était le 7 mars 2020 ou avant, et que le client demande des semaines supplémentaires à être payées avant le 15 mars 2020, un certificat médical est nécessaire .

**Changements aux saisies requises dans SSA**

Pour les prestations pour proches aidants, à l’écran Annexe - Prestations spéciales , saisir « O » pour oui dans le champ Preuve médicale est fournie? , qui est prérempli avec N pour non, puisque la demande doit être établie comme si le client avait fourni un certificat médical.

**Changements aux saisies de la transaction Entrée des données de Proches aidants/Soins de compassion (MCB1)**

Quand il n’ y a aucune FPA existante, suivre les directives suivantes :

- Confirmation du certificat : Choisir O - Approuvé .

- Date de début : Saisir la date de début appropriée. (date de début du DPP, la semaine du renouvellement ou la semaine de conversion)

Pour les prestations pour proches aidants, suivre les directives suivantes :

- Date de fin des soins/soutien: Saisir l’option appropriée :

- Pour les demandes initiales, saisir le samedi de la semaine correspondant au DPP + 51 semaines.

- Pour les demandes renouvelées, saisir le samedi de la semaine correspondant à la semaine renouvelée + 51 semaines.

- Pour les demandes converties, saisir le samedi de la semaine correspondant à la semaine de conversion + 51 semaines.

Pour les demandes établies avant le 15 mars 2020, lorsqu'un patient a besoin de soins ou de soutien supplémentaires (prolongation de la date de fin des soins ou du soutien) pour des semaines tombant le 15 mars ou plus tard, saisir la date de fin de la FPA dans le champ Date de fin des soins/soutien .

**Obtenir plus de renseignements**

Pour plus de renseignements, l’agent consulte Certificats médicaux pendant la situation liée à la COVID-19 – AP 2020-03 (Notes de service AP) et Dispositions de transition pour la prestation d’urgence — AP 2020-05 (Notes de service AP) .
       [Certificats médicaux pendant la situation liée à la COVID-19 – AP 2020-03 (Notes de service AP)](/fr/policy/bememo/be2020-03.shtml) 
       [Dispositions de transition pour la prestation d’urgence — AP 2020-05 (Notes de service AP)](/fr/policy/bememo/be2020-05.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_1119.dita`

Remarque :

Cette page Mises à jour et Nouvelles a été créée le 3 avril 2020 et a été mise à jour avec les renseignements suivants :

- 27 mai 2020 : La page comprend maintenant les renseignements sur les certificats médicaux pour les PDC et les prestations pour proches aidants. La page Mises à jour et Nouvelles du 6 avril 2020 au sujet des certificats médicaux manquants pour les PDC et les prestations pour proches aidants a été supprimée.

- 4 juin 2020 : La page a été mise à jour pour préciser que l’agent saisit la semaine de guérison dans une transaction Décision initiale (M103) et non à l’écran Annexe - Prestations spéciales dans SSA pour les prestations de maladie.

- 1 er octobre 2020 : La page a été mise à jour pour prolonger la mesure jusqu’au 25 septembre 2021 sauf pour les PDC et prestations pour proche aidant.

- 13 novembre 2020 : La page a été mise à jour pour préciser les renseignements sur les certificats médicaux manquants pour les PDC et les prestations pour proches aidants.

- 4 décembre 2020 : La page a été mise à jour pour indiquer que les procédures pour les prestations régulières et de maladie ont été mises à jour pour correspondre aux mesures actuelles.

- 26 janvier 2021 : La page a été mise à jour pour ajouter des renseignements sur la guérison anticipée. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0979.dita`

Remarque :

Les procédures n’ont pas été mises à jour. Consulter COVID-19 — Modifications aux procédures pour un tableau des procédures touchées.
       [COVID-19 — Modifications aux procédures](/fr/procedure/generic/covidhu.shtml)

     [COVID-19 — Modifications aux procédures](/fr/procedure/generic/covidhu.shtml) 

### Exemple

Source topic: `fr_FR/common_notes/note_c_1120.dita`

Exemple :

- Si une demande est établie avec un DPP dans la s/c 2230 (15 mars 2020), la date de fin des soins ou du soutien est le samedi de la s/c 2281 (13 mars 2021).

- Si une demande est renouvelée avec une semaine de renouvellement dans la s/c 2250, la date de fin des soins ou du soutien est le samedi de la s/c 2301 (31 juillet 2021).

- Si une demande est convertie en proches aidants dans la s/c 2250, la date de fin des soins ou du soutien est le samedi de la s/c 2301 (31 juillet 2021). 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/mc_proc_1_2/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
