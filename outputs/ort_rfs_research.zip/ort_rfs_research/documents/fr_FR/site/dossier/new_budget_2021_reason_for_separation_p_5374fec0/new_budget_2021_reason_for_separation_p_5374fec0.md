# Mise à jour : Budget 2021 et motif de cessation d’emploi — Politique et procédures (Non complexe, Niveau 1 et Niveau 2)

Source map: `fr_FR/site/dossier/new_budget_2021_reason_for_separation_p_5374fec0/new_budget_2021_reason_for_separation_p_5374fec0.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/new_budget_2021_reason_for_separation_p_5374fec0/sommaire.dita`

Dans les demandes initiales dont le DPP est entre la s/c 2310 et la s/c 2361, une décision est seulement rendue sur le motif de cessation d’emploi (MCE) pour la dernière période d’emploi. Cette mesure ne s’applique pas aux demandes de prestations de travailleur indépendant ou de pêcheur. 

## Generic

Source topic: `fr_FR/site/dossier/new_budget_2021_reason_for_separation_p_5374fec0/generic.dita`

Les procédures touchées par les mesures du budget 2021 ont été mises à jour. Toutefois, cette mesure s’applique seulement aux demandes dont le DPP est entre la s/c 2310 et la s/c 2361.

Dans le cadre du budget 2021, une mesure temporaire a été mise en œuvre pour les demandes initiales et les nouveaux calculs. Elle prévoit que toutes les heures d’emploi assurable dans la période de référence (PR) peuvent être utilisées pour remplir les conditions requises pour recevoir des prestations tant que le dernier emploi du client a pris fin sans qu’il y ait eu faute de sa part ou qu’il a fourni une justification valable pour son départ. Aucune décision n’est rendue sur un autre MCE litigieux dans la PR, et tous les RE sont inclus dans le calcul de la demande. Toutefois, si l’agent détermine que le MCE pour la dernière période d’emploi utilisé pour établir la période de prestations (PP) n’est pas autorisé, toutes les heures sont incluses dans le calcul de la demande et l’agent impose une exclusion.

**Modifications du système en vigueur le 13 septembre 2021**

Les modifications suivantes ont été apportées pour prendre en charge la mise en œuvre de la mesure temporaire liée au MCE :

- Le système crée seulement un AT Litige - Décision (DEC) Examen du MCE quand le MCE litigieux :

- de la dernière période d’emploi déclaré dans la demande d’AE est un congédiement, une suspension, un départ volontaire ou un congé autorisé;

- auprès d’un employeur est une grève.

- La nouvelle décision Aucune décision requise - mesures de simplification AE budget 2021 a été ajoutée aux AT DEC Départ volontaire et Congédiement de Niveau 1 dans les demandes initiales de prestations régulières ou spéciales.

- Quand un client déclare un MCE litigieux dans la section Autres employeurs de sa demande d’AE, le système applique les règles de décision automatique. Si le MCE ne peut pas être autorisé en vertu des règles de décision automatique, le système résout automatiquement le litige lié au MCE avec Aucune décision requise - mesures de simplification AE budget 2021 .

- Quand le système résout automatiquement le litige lié au MCE avec Aucune décision requise - mesures de simplification AE budget 2021 , le champ Condition spéciale du RE n’est pas mis à jour, mais ce RE est quand même inclus dans le calcul de la demande.

**Incidence sur les décisions sur les demandes dont le DPP est entre la s/c 2310 et la s/c 2361**

Lors de l’établissement d’une demande initiale, une décision est seulement requise sur le MCE litigieux dans la période d’emploi avec le dernier jour payé (DJP) le plus récent utilisée pour établir la demande. Par conséquent, le système crée un AT DEC quand le dernier MCE déclaré dans la demande d’AE est litigieux. S’il détermine qu’aucune décision n’est requise puisque le MCE pour lequel un AT a été créé n’est pas celui pour la dernière période d’emploi, l’agent résout le litige avec Aucune décision requise - mesures de simplification AE budget 2021 .

Dans les demandes renouvelées et continues de prestations régulières, une décision est requise sur tout MCE litigieux dans la PP.

Dans le cadre des modifications législatives du budget 2021, un client n’a plus à travailler assez d’heures d’emploi assurable depuis l’évènement entraînant l’exclusion pour établir une nouvelle demande initiale de prestations. La LAE 30(1) jusqu’à l’alinéa b) a été mise à jour pour indiquer qu’un client ne remplit pas les conditions requises pour recevoir des prestations régulières s’il a perdu son emploi en raison d’une inconduite ou qu’il a quitté volontairement son emploi sans justification valable, sauf s’il a depuis occupé un autre emploi assurable et présenté une nouvelle demande initiale depuis qu’il a perdu ou quitté son emploi. Cela signifie que l’agent n’utilise pas la norme d’admissibilité commune de 420 heures d’emploi assurable pour déterminer si le client remplit à nouveau les conditions requises après un évènement ayant entraîné une exclusion. Le client doit plutôt avoir travaillé au moins une heure d’emploi assurable depuis l’évènement ayant entraîné l’exclusion et présenté une demande d’AE. Si le MCE depuis l’évènement ayant entraîné l’exclusion est non litigieux ou que la décision de l’autoriser a été rendue, une nouvelle demande peut être établie en utilisant les heures de tous les RE.

Quand un client présente une demande de renouvellement pour des prestations régulières pour réactiver une demande précédemment établie dans laquelle des prestations ont été versées, une décision doit être rendue sur tout nouveau MCE litigieux dans la PP. Si l’agent détermine que le client a perdu son emploi en raison d’une inconduite ou qu’il a quitté volontairement son emploi sans justification valable, l’agent impose une exclusion indéterminée. Toutefois, si le client a travaillé depuis l’évènement entraînant l’exclusion et que le MCE de cet emploi est non litigieux ou que la décision de l’autoriser a été rendue sur celui-ci, l’agent détermine si le client a travaillé assez d’heures d’emploi assurable depuis le DPP initial pour établir une nouvelle demande. Pour déterminer ceci, l’agent utilise les heures du RE ayant entraîné l’exclusion et celles des RE depuis l’exclusion. Si l’agent détermine que le client a assez d’heures pour établir une nouvelle demande, l’agent crée un AT pour terminer la demande afin d’établir une nouvelle demande initiale.

En vertu de cette mesure, l’agent prend seulement un MCE litigieux en considération s’il est pour la période d’emploi la plus récente. Si tel est le cas, aucune décision n’est requise sur d’autre RE dans la PR. Par conséquent, l’agent ne considère pas le report d’autres RE dans la PR.

Si la décision sur un MCE litigieux a entraîné une exclusion indéterminée en suspens dans une demande renouvelée de prestations régulières, l’agent ne peut pas reporter la décision et doit rendre une décision sur tout nouveau MCE litigieux dans la PP.

Quand un client demande des prestations de maladie dans une demande initiale dont le DPP est entre la s/c 2310 et la s/c 2361, une décision sur le MCE pour la dernière période d’emploi peut être reportée, sans tenir compte du MCE des autres RE dans la PR, tant que le client est autrement disponible et remplit les conditions requises pour recevoir des prestations de maladie. De plus, quand un client demande des prestations spéciales autres que de maladie entre la s/c 2310 et la s/c 2361, la décision sur le MCE pour la dernière période d’emploi peut être reportée, sans tenir compte du MCE des autres RE dans la PR.

**Incidence sur les procédures**

Des renseignements sur la façon d’appliquer la mesure du budget 2021 liée au MCE ont été ajoutés aux activités et aux sections Ce qu’il faut savoir et Étapes par étape des tâches suivantes :

- Congédiement (Activité)
         [Congédiement (Activité)](/fr/procedure/activity/dismissal.shtml)

- Rendre une décision sur un congédiement ou une suspension — Demande initiale (Tâche)
         [Rendre une décision sur un congédiement ou une suspension — Demande initiale (Tâche)](/fr/procedure/task/dismissal_ds_ic.shtml)

- Rendre une décision sur un congédiement pour inaptitude — Demande initiale (Tâche)
         [Rendre une décision sur un congédiement pour inaptitude — Demande initiale (Tâche)](/fr/procedure/task/dismissal_ic.shtml)

- Rendre une décision sur un congédiement ou une suspension — Demande renouvelée (Tâche)
         [Rendre une décision sur un congédiement ou une suspension — Demande renouvelée (Tâche)](/fr/procedure/task/dismissal_ds_rc.shtml)

- Départ volontaire (Activité)
         [Départ volontaire (Activité)](/fr/procedure/activity/voluntary_leaving.shtml)

- Rendre une décision sur un départ volontaire : Demande initiale — Niveau 2 (Tâche)
         [Rendre une décision sur un départ volontaire : Demande initiale — Niveau 2 (Tâche)](/fr/procedure/task/vllevel2_ic.shtml)

- Rendre une décision sur un départ volontaire (Niveau 1) : Cours de formation — Demande initiale (Tâche)
         [Rendre une décision sur un départ volontaire (Niveau 1) : Cours de formation — Demande initiale (Tâche)](/fr/procedure/task/vl_course_ic.shtml)

- Rendre une décision sur un départ volontaire (Niveau 1) : Autre emploi — Demande initiale (Tâche)
         [Rendre une décision sur un départ volontaire (Niveau 1) : Autre emploi — Demande initiale (Tâche)](/fr/procedure/task/vllevel1_oe_ic.shtml)

- Rendre une décision sur un départ volontaire (Niveau 1) : Raisons médicales — Demande initiale (Tâche)
         [Rendre une décision sur un départ volontaire (Niveau 1) : Raisons médicales — Demande initiale (Tâche)](/fr/procedure/task/vllevel1_mr_ic.shtml)

- Rendre une décision sur un départ volontaire (Niveau 1) : Suivre une autre personne — Demande initiale (Tâche)
         [Rendre une décision sur un départ volontaire (Niveau 1) : Suivre une autre personne — Demande initiale (Tâche)](/fr/procedure/task/vllevel1_fai_ic.shtml)

- Rendre une décision sur un départ volontaire (Niveau 1) : Compression du personnel — Demande initiale (Tâche)
         [Rendre une décision sur un départ volontaire (Niveau 1) : Compression du personnel — Demande initiale (Tâche)](/fr/procedure/task/vl_wr_ic.shtml)

- Congé autorisé (Activité)
         [Congé autorisé (Activité)](/fr/procedure/activity/leave_absence.shtml)

- Rendre une décision sur un congé autorisé — Niveau 1 (Tâche)
         [Rendre une décision sur un congé autorisé — Niveau 1 (Tâche)](/fr/procedure/task/voluntary_leaving_loa.shtml)

- Rendre une décision sur un congé autorisé — Niveau 2 (Tâche)
         [Rendre une décision sur un congé autorisé — Niveau 2 (Tâche)](/fr/procedure/task/adjudicating_loa_l2.shtml)

- Report de la décision (Activité)
         [Report de la décision (Activité)](/fr/procedure/activity/deferral_adj.shtml)

- Reporter la décision : Demande initiale — Prestations régulières (Tâche)
         [Reporter la décision : Demande initiale — Prestations régulières (Tâche)](/fr/procedure/task/defer_adj_initial_regular_ben.shtml)

- Reporter la décision : Demande initiale — Prestations de maladie (Tâche)
         [Reporter la décision : Demande initiale — Prestations de maladie (Tâche)](/fr/procedure/task/defer_adj_initial_sickness_ben.shtml)

- Reporter la décision : Demande initiale — Prestations spéciales (autre que maladie) (Tâche)
         [Reporter la décision : Demande initiale — Prestations spéciales (autre que maladie) (Tâche)](/fr/procedure/task/defer_adj_initial_special_ben_other_sickness.shtml)

- Reporter la décision : Demande renouvelée — Prestations régulières (Tâche)
         [Reporter la décision : Demande renouvelée — Prestations régulières (Tâche)](/fr/procedure/task/defer_adj_renewal_regular_ben.shtml)

- Examiner le résultat du calcul — RE exclus ou inadmissible (Tâche)
         [Examiner le résultat du calcul — RE exclus ou inadmissible (Tâche)](/fr/procedure/task/calc_reviewing/review_calc_disqual_exclus.shtml)

- Examiner le résultat du calcul — Messages
         [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml)

- Examiner les renseignements pour un RE manquant (Tâche)
         [Examiner les renseignements pour un RE manquant (Tâche)](/fr/procedure/task/calc_determining/missing_roe.shtml)

- Examiner une question en suspens sans AT Litige - Décision (Tâche)
         [Examiner une question en suspens sans AT Litige - Décision (Tâche)](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Annuler une période de prestations (Tâche)
         [Annuler une période de prestations (Tâche)](/fr/procedure/task/benefit_period_cancel.shtml)

- Terminer une période de prestations (Tâche)
         [Terminer une période de prestations (Tâche)](/fr/procedure/task/benefit_period_term.shtml)

Pour plus d'informations, consultez Budget 2021 : Soutenir les Canadiens et les entreprises jusqu’à la relance — AP 2021-03 (Notes de service AP). 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/new_budget_2021_reason_for_separation_p_5374fec0/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
