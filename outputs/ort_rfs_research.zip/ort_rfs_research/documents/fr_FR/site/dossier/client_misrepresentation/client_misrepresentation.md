# Acte délictueux — Mise à jour

Source map: `fr_FR/site/dossier/client_misrepresentation/client_misrepresentation.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/client_misrepresentation/sommaire.dita`

Dans le cadre de notre engagement à garder le contenu de l’ORL AE à jour, les procédures liées aux actes délictueux ont été mises à jour selon les commentaires régionaux. 

## Generic

Source topic: `fr_FR/site/dossier/client_misrepresentation/generic.dita`

Les modifications les plus importantes sont les suivantes :

Quand un dossier comprend plusieurs périodes de prestations (PP), l’agent suit les étapes pour chaque PP. Quand un trop-payé (T-P) total net est basé sur plus d’une PP, l’agent calcule le plafond de la pénalité séparément pour chaque PP. Cette procédure s’applique aussi pour le calcul de la validation légale.

Un nouveau calcul est nécessaire quand l’acte délictueux comprend un motif de cessation d’emploi (MCE) litigieux non déclaré dans la période de référence (PR) et a un impact sur le calcul de la demande. Quand un nouveau calcul est nécessaire, l’agent crée un AT Révision de la demande (RVD) Nouveau calcul et une Note client pour que le Niveau 1 calcule la demande de nouveau.

Quand un client a déclaré une rémunération reçue de plus d’un employeur pour une semaine qui est modifiée, la rémunération des 2 emplois doit être combinée pour cette semaine. Le total correspond au montant à répartir.

L’agent détermine si un arrêt de paiement a été imposé pendant l’enquête et le supprime, au besoin.

Une lettre séparée est nécessaire pour chaque année civile quand il y a plus de 52 semaines de rémunération non déclarée.

Les étapes de la transaction Mémo pour le centre opérationnel (MM06) ont été mises à jour. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/client_misrepresentation/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
