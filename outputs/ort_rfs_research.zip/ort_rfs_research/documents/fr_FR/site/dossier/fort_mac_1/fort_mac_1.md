# Feux de forêt à Fort McMurray - mis à jour le 13 mai 2016

Source map: `fr_FR/site/dossier/fort_mac_1/fort_mac_1.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/fort_mac_1/sommaire.dita`

Des mesures d’urgence ont été mises en place afin d’aider les clients touchés par les feux de forêt à Fort McMurray, en Alberta. Ces changements s’appliquent seulement aux clients qui sont touchés par les feux à Fort McMurray. 

## Generic

Source topic: `fr_FR/site/dossier/fort_mac_1/generic.dita`

[Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1009.dita) 

Le Centre Service Canada de Fort McMurray est actuellement fermé et la livraison du courrier à Fort McMurray est suspendue. Service Canada a créé une ligne téléphonique spécialisée pour fournir de l’information au sujet de l’AE. Les clients touchés peuvent téléphoner au 1-800-808-6352 et choisir l’option « 6 » pour obtenir de l’information.

**Code de référence**

Un code de référence, 4812012016030516, a été émis pour les clients qui sont touchés par les feux. Les demandes présentées avec ce code de référence seront traitées par une unité spécialisée dans la région de l’Ouest du Canada et des territoires. Seuls les clients qui demandent des prestations régulières peuvent utiliser ce code. Les clients qui demandent des prestations spéciales ne devraient pas utiliser le code de référence.

**Non-concordance du Registre d’assurance sociale (RAS)**

S’il est impossible de communiquer avec un client pour valider son identité, la demande ne sera pas retardée. L’AT Validation du RAS (RAS) sera déplacé vers En suspens et, une fois que les conditions à Fort McMurray retourneront à la normale, on communiquera avec le client pour effectuer un suivi concernant la validation du RAS.

**Adresse des clients**

On avise le client de saisir son adresse permanente dans le champ destiné à l’adresse du domicile, peu importe si son adresse permanente se situe à Fort McMurray ou ailleurs. Si le client a été temporairement déplacé à la suite des feux, il peut saisir son adresse temporaire dans le champ pour l’adresse postale. Cette adresse temporaire pourrait s’agit d’un hôtel, d’un abri, etc.

**RE provisoires**

Puisqu’il est possible que les employeurs soient incapables d’émettre des RE, un RE provisoire sera créé dès que possible pour les clients touchés.

**Dépôt direct**

Les clients qui ont fourni des renseignements concernant leur dépôt direct dans une demande antérieure dans une région autre que l’Ouest du Canada et des territoires pourraient devoir mettre à jour leurs renseignements du dépôt direct. Les renseignements du dépôt direct de l’autre région pourraient ne pas être reportés à leur nouvelle demande. Si les agents sont en contact avec l’un des clients touchés, les agents doivent toujours s’assurer que les renseignements au dossier concernant le dépôt direct sont exacts.

**Motif de cessation d’emploi**

Si le client ne travaille plus involontairement en raison de l’évacuation obligatoire, ou parce que l’entreprise est fermée étant donné les feux de forêt à Fort McMurray, on considère le motif de cessation d’emploi comme étant non litigieux et un agent de Niveau 1 peut l’accorder. Toutefois, si un client a quitté son emploi ou a pris un congé autorisé à cause des feux, la décision doit être rendue par un agent de Niveau 2. Il faut suivre les principes normaux de la prise de décision afin de déterminer si le client aurait pu trouver une autre solution raisonnable que de quitter ou de prendre un congé autorisé.

**Disponibilité**

On ne traite pas de la disponibilité du client sur la demande. Ainsi, la disponibilité d’un client touché peut être accordée par un agent de Niveau 1, sauf si d’autres informations figurant au dossier indiquent que le client pourrait ne pas être disponible. Il faut suivre les principes normaux de la prise de décision. Cependant, l’agent de Niveau 2 fera preuve d’indulgence et prendra en considération la situation personnelle du client lorsqu’il rendra une décision sur la disponibilité

**Déclarations du prestataire**

L’agent doit obtenir toute information manquante sur la déclaration du prestataire lorsqu’il communique avec un client touché.

**Mandats de remplacement**

Les clients touchés n’auront plus à attendre 8 jours avant de pouvoir demander un mandat de remplacement. Les demandes de mandats de remplacement seront traitées immédiatement.

**Procédures de l’Ouest du Canada et des territoires**

La région de l’Ouest du Canada et des territoires a créé un site Web (disponible seulement en anglais) qui traite de l’information et des ressources pour les agents qui sont responsables des demandes de clients affectés par les feux de forêt à Fort McMurray.
       [site Web](http://servicecanada.prv/eng/w-t/pps/ins-ass/ops_committee/wildfire_response.shtml)

**Clients en dehors de la région de l’Ouest du Canada et des territoires**

Si un client présente une demande de prestations en utilisant le code de référence et fournit une adresse résidentielle en dehors de la région de l’Ouest du Canada et des territoires, la demande sera tout de même calculée dans la région de l’Ouest du Canada et des territoires. Une fois la demande finalisée, elle sera transférée à la région où le client réside. 

### Info

Source topic: `fr_FR/common_notes/note_c_1009.dita`

**Remarque :**

Les tâches dans l’ORL AE ne seront pas actualisées à mesure que les changements se produisent. L’information ci-incluse remplace toutes directives connexes provenant de l’ORL AE. Veuillez consulter régulièrement cette page pour obtenir d’autres mises à jour. 
