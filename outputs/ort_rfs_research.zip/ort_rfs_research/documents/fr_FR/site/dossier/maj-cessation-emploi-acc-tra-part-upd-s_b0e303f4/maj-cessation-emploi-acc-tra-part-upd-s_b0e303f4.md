# Mise à jour : Traiter une cessation d’emploi faisant partie d’un accord de Travail partagé — Tâche (COPA)

Source map: `fr_FR/site/dossier/maj-cessation-emploi-acc-tra-part-upd-s_b0e303f4/maj-cessation-emploi-acc-tra-part-upd-s_b0e303f4.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/maj-cessation-emploi-acc-tra-part-upd-s_b0e303f4/sommaire.dita`

La tâche Traiter une cessation d’emploi faisant partie d’un accord de Travail partagé a été mise à jour pour inclure des directives quand un agent envoie une transaction Mémo pour le centre opérationnel (MM06) ou un AT COPA Révision (COPA REV) si une autre mesure du COPA est requise pour la semaine dans laquelle la cessation d’emploi s’est produite et qu’une décision a été rendue sur le motif de cessation d’emploi (MCE). 

## Generic

Source topic: `fr_FR/site/dossier/maj-cessation-emploi-acc-tra-part-upd-s_b0e303f4/generic.dita`

## Résumé des modifications

Source topic: `fr_FR/site/dossier/maj-cessation-emploi-acc-tra-part-upd-s_b0e303f4/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
