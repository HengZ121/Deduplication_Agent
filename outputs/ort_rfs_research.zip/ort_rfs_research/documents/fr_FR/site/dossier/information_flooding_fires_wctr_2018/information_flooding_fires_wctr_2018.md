# Renseignements : Mise à jour sur les Inondations et feux de forêt — Région de l’Ouest du Canada et des territoires (printemps 2018)

Source map: `fr_FR/site/dossier/information_flooding_fires_wctr_2018/information_flooding_fires_wctr_2018.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/information_flooding_fires_wctr_2018/sommaire.dita`

Mise à jour le 6 juin 2018 — L’information se trouve maintenant dans la base de données des Évènements majeurs en entreprise.

Des mesures d’urgence ont été mises en place afin d’aider les clients touchés par les inondations ou les feux de forêt dans la région de l’Ouest du Canada et des territoires. Ces changements ne s’appliquent qu’aux clients touchés par les inondations ou les feux de forêt dans la région de l’Ouest du Canada et des territoires. 

## Generic

Source topic: `fr_FR/site/dossier/information_flooding_fires_wctr_2018/generic.dita`

[Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1093.dita) 

**Codes de références**

Des codes de références ont été émis pour faciliter le traitement des demandes pour les clients qui sont touchés par les inondations ou les feux de forêt.

Les codes de référence pour les clients qui sont touchés par les inondations.

```text
| Région | Codes de référence |

| Alberta | 4812-01-4812-002018 |

| Colombie-Britannique | 5910-01-5910-002018 |

| Manitoba | 4317-01-4317-002018 |

| Saskatchewan | 4317-01-4317-002018 |

| Ouest du Canada et territoires | 4813-01-4813-002018 |
```

Les codes de référence pour les clients qui sont touchés par les feux de forêt.

```text
| Région | Codes de référence |

| Alberta | 4812-01-4812-201800 |

| Colombie-Britannique | 5986-01-5986-598600 |

| Manitoba | 4317-01-4317-431700 |

| Saskatchewan | 4317-01-4317-431700 |

| Ouest du Canada et territoires | 4813-01-4813-481300 |
```

Les demandes doivent être présentées avec le code de référence approprié selon la région où le client réside.

Seul le client qui demande des prestations régulières peut utiliser ces codes de références. Le client qui demande des prestations spéciales ne peut pas utiliser ces codes de référence.

**Adresse du client**

L’adresse postale du client doit être mise à jour pour refléter son adresse postale courante. Si le client a été temporairement déplacé à la suite des inondations ou des feux de forêt, il peut saisir son adresse temporaire dans le champ pour l’adresse postale. Cette adresse temporaire pourrait être d’un hôtel, d’un abri, etc.

**Livraison du courrier**

Si le client a besoin de plus de renseignements au sujet de la livraison du courrier, il peut consulter le site internet de Postes Canada ou appeler au 1-888-550-6333.
       [Postes Canada](https://www.canadapost.ca/web/fr/blogs/announcements/list.page?cattype=announcements&cat=servicealerts)

**RE provisoires**

Puisqu’il est possible que les employeurs soient incapables d’émettre des RE, un RE provisoire doit être créé dès que possible pour les clients touchés.

**Dépôt direct**

Le client pourrait devoir mettre à jour ses renseignements du dépôt direct. Si un agent est en contact avec l’un des clients touchés, l’agent doit toujours s’assurer que les renseignements au dossier concernant le dépôt direct sont exacts.

**Motif de cessation d’emploi (MCE)**

Si le client ne travaille plus involontairement en raison de l’évacuation obligatoire, ou parce que l’entreprise est fermée étant donné les inondations et les feux de forêt, on considère le MCE comme étant non litigieux et un agent de Niveau 1 peut l’accorder. Toutefois, si un client a quitté son emploi ou a pris un congé autorisé à cause des inondations, un agent de Niveau 2 doit rendre une décision. Il faut suivre les principes normaux de la prise de décision afin de déterminer si le client aurait pu trouver une autre solution raisonnable que de quitter ou de prendre un congé autorisé.

**Disponibilité**

On ne traite pas de la disponibilité du client sur la demande. Ainsi, la disponibilité d’un client touché peut être accordée par un agent de Niveau 1, sauf si d’autres renseignements figurant au dossier indiquent que le client pourrait ne pas être disponible. Il faut suivre les principes normaux de la prise de décision. Cependant, l’agent de Niveau 2 doit prendre en considération la situation personnelle du client quand il rendra une décision sur la disponibilité. Aucun client ne devrait se voir refuser des prestations si la situation d’urgence est le seul motif expliquant la non-disponibilité.

**Déclaration du prestataire**

L’agent doit obtenir toute information manquante sur la déclaration du prestataire quand il communique avec un client touché. 

### Info

Source topic: `fr_FR/common_notes/note_c_1093.dita`

**Remarque :**

L’agent doit consulter la base de données Évènements majeurs en entreprise pour l’information la plus récente, car des changements y sont continuellement apportés. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/information_flooding_fires_wctr_2018/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
