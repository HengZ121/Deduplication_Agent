# Archivée : COVID-19 et le recueil de faits — Tâche (Tous les niveaux)

Source map: `fr_FR/site/dossier/fact_find_covid19_update/fact_find_covid19_update.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/fact_find_covid19_update/sommaire.dita`

En raison de la COVID-19, le recueil de faits auprès des employeurs a été modifié 

## Generic

Source topic: `fr_FR/site/dossier/fact_find_covid19_update/generic.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1006.dita) 

Archivée

Cette page Web a été archivée dans le Web.
       [Cette page Web a été archivée dans le Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/fact_find_covid19_update#archived)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1007.dita) 

**Table des matières**

- Ce qu’il faut savoir
         [Ce qu’il faut savoir](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/fact_find_covid19_update#Ce_quil_faut)

- Processus temporaire

- Recueil de faits pour des questions liées au RE
             [Recueil de faits pour des questions liées au RE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/fact_find_covid19_update#_Recueil_de_faits)

- Recueil de faits pour d’autres questions
             [Recueil de faits pour d’autres questions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/fact_find_covid19_update#_Recueil_de_faits_1)

         [Processus temporaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/fact_find_covid19_update#Processus_temporaire)

**Ce qu’il faut savoir**

**Recueil de faits pour des questions liées au RE**

À compter d’aujourd’hui, l’agent suit les procédures habituelles de recueil de faits quand il tente de communiquer avec un employeur pour des questions liées au RE, sauf si l’agent confirme que l’entreprise reste fermée en raison de la COVID-19.
       [recueil de faits](/fr/procedure/task/fact_find.shtml)

La confirmation d’une fermeture en raison de la COVID-19 comprend les éléments suivants :

- une indication dans la messagerie vocale de l’employeur;

- des renseignements sur le site web de l’employeur;

- une déclaration du client.

Après avoir confirmé que l’entreprise reste fermée en raison de la COVID-19, l’agent consigne les renseignements dans un RSDP et continue le traitement de la demande en utilisant les renseignements au dossier.

**Renvois à Intégrité**

Même si l’agent suit les procédures habituelles de recueil de faits quand il tente de contacter l’employeur pour toutes les questions liées au RE, l’agent ne renvoie pas un AT à Intégrité si l’employeur ne répond pas à la deuxième lettre Z-02-00-00. L’agent complète plutôt l’AT sans prendre d’autres mesures. Si le RE semble faux, l’agent renvoie la question à Intégrité.

**Recueil de faits pour d’autres questions**

Lors d’un recueil de faits pour toute autre question, l’agent tente une fois de contacter l’employeur. Si l’employeur n’est pas joint lors de la première tentative, l’agent ne laisse pas un message demandant à l’employeur de rappeler. L’agent consigne plutôt la tentative dans un RSDP et continue le traitement de la demande en utilisant les renseignements au dossier.

**Processus temporaire**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0979.dita) 

Si le recueil de faits est pour un RE, passer à Recueil de faits pour des questions liées au RE .
       [Recueil de faits pour des questions liées au RE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/fact_find_covid19_update#_Recueil_de_faits)

Si le recueil de faits est pour toute autre question, passer à Recueil de faits pour d’autres questions .
       [Recueil de faits pour d’autres questions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/fact_find_covid19_update#_Recueil_de_faits_1)

**Recueil de faits pour des questions liées au RE**

Dans SNCT créer un RSDP de la façon suivante :

- Principal problème : Choisir le problème approprié ou Autre (si le problème n’est pas dans le menu).

- Commentaires : Saisir « Mesure de simplification : tentative de communication avec l’employeur — [nom de l’employeur]. »

- Détails : Saisir « Impossible de joindre l’employeur lors de la première tentative. Il y a confirmation que [nom de l’entreprise] est fermé en raison de la COVID-19. La fermeture de l’entreprise a été confirmée par [façon dont la fermeture a été confirmée]. La demande est traitée avec les renseignements au dossier. »

Non complexe : Si l’entreprise de l’employeur reste fermée en raison de la COVID-19, ne pas envoyer la lettre Z-02-00-00. Consigner plutôt les renseignements dans un RSDP et retourner à la tâche initiale.

Niveau 1 : Si l’entreprise de l’employeur reste fermée en raison de la COVID-19, ne pas envoyer la lettre Z-02-00-00. Consigner plutôt les renseignements dans un RSDP et tenter de résoudre les questions avec le client. Consulter les procédures temporaires liées au RE pour résoudre les questions.

**Recueil de faits pour d’autres questions**

Niveau 1 : Si l’employeur n’est pas joint après la première tentative, ne pas envoyez de lettre Z-02-00-00. Documenter simplement le dossier avec un RSDP et tenter de résoudre les questions avec le client. Se référer à la tâche Recueil de faits et utiliser la version du client pour confirmer le motif de cessation d’emploi (MCE), la disponibilité, la rémunération et toute question liée au calcul ou à l’assurabilité.
       [Recueil de faits](/fr/procedure/task/fact_find.shtml)

Niveau 2 : Si l’employeur n’est pas joint après la première tentative, ne pas envoyer de lettre Z-02-00-00. Documenter simplement le dossier avec un RSDP. Utiliser la version du client pour confirmer le MCE ou les questions de disponibilité, et accorder le bénéfice du doute au client, si nécessaire. Documenter dans un rapport de décision (RD) que des mesures de simplification ont été utilisées. La lettre Z-01-00-00 est toujours envoyée à l’employeur quand un MCE litigieux en lien avec l’emploi est autorisé.

COPA : Si l’employeur n’est pas joint après la première tentative, consigner les renseignements dans un RSDP et retourner à la tâche initiale.

Demande de révision : Cette mesure s’applique également lors du traitement d’une demande de révision d’un client. 

### Warning

Source topic: `fr_FR/common_notes/note_c_1006.dita`

**Cette page Web a été archivée dans le Web**

MISE À JOUR : 2020-12-23 — Cette page Mises à jour et Nouvelles a été archivée parce que les mesures temporaires ont été remplacées par de nouvelle mesures. Pour plus de détails, consultez Mise à jour : Mesures de simplification temporaires et recueil de faits auprès des l’employeurs — Procédures (Non complexe, Niveau 1 et Niveau 2) .
       [Mise à jour : Mesures de simplification temporaires et recueil de faits auprès des l’employeurs — Procédures (Non complexe, Niveau 1 et Niveau 2)](/fr/site/dossier/updated_tsmffe.shtml)

L’information dont il est indiqué qu’elle est archivée est fournie à des fins de référence, de recherche ou de tenue de documents. Elle n’est pas assujettie aux normes Web du gouvernement du Canada et elle n’a pas été modifiée ou mise à jour depuis son archivage. Pour obtenir cette information dans un autre format, veuillez communiquer avec nous.

     [Mise à jour : Mesures de simplification temporaires et recueil de faits auprès des l’employeurs — Procédures (Non complexe, Niveau 1 et Niveau 2)](/fr/site/dossier/updated_tsmffe.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_1007.dita`

Remarque :

Cette page Mises à jour et nouvelles a été créée le 20 mars 2020 et mise à jour de la façon suivante :

- 22 juillet 2020 : Les mesures de simplification pour le recueil de faits auprès des employeurs pour des questions liées aux RE ne s’appliquent plus. L’agent consulte Recueil de faits pour toutes les questions liées au RE, sauf si l’entreprise reste fermée en raison de la COVID-19.
         [Recueil de faits](/fr/procedure/task/fact_find.shtml)

     [Recueil de faits](/fr/procedure/task/fact_find.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0979.dita`

Remarque :

Les procédures n’ont pas été mises à jour. Consulter COVID-19 — Modifications aux procédures pour un tableau des procédures touchées.
       [COVID-19 — Modifications aux procédures](/fr/procedure/generic/covidhu.shtml)

     [COVID-19 — Modifications aux procédures](/fr/procedure/generic/covidhu.shtml) 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/fact_find_covid19_update/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
