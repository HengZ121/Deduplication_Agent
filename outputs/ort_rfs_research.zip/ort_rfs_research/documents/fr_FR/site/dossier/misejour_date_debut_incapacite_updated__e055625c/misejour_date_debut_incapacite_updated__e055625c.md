# Mise à jour : Date de début de l’incapacité et date de guérison — Prestations de maladie — Procédures et ressources additionnelles (Niveau 1)

Source map: `fr_FR/site/dossier/misejour_date_debut_incapacite_updated__e055625c/misejour_date_debut_incapacite_updated__e055625c.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/misejour_date_debut_incapacite_updated__e055625c/sommaire.dita`

Selon les rétroactions des régions et de la division de la politique opérationnelle de l’AE, des précisions ont été ajoutées à l’ORL AE pour aider l’agent à déterminer si une date de début de l’incapacité est requise et quelle devrait être cette date, et à déterminer une semaine de guérison dans les demandes de prestations de maladie. 

## Generic

Source topic: `fr_FR/site/dossier/misejour_date_debut_incapacite_updated__e055625c/generic.dita`

Date du début de l’incapacité

Quand le motif de cessation d’emploi (MCE) est D - Maladie ou blessure pour une demande initiale ou renouvelée et que le certificat médical n’a pas besoin d’être présenté, la date de début de l’incapacité est la semaine du DPP ou la semaine du renouvellement. Ceci s’applique même si le client présente un certificat médical qui n’a pas besoin d’être présenté.

Si le client présente un certificat médical pour la prolongation de la période de prestations de maladie et que le certificat médical n’indique pas que la période initiale de maladie se poursuit, une date de début de l’incapacité est nécessaire pour poursuivre le paiement des prestations immédiatement après la semaine de guérison initiale sur la demande.

Les renseignements sur la façon de déterminer la date de début de l’incapacité ont été mis à jour pour s’aligner avec la Politique sur la preuve d’incapacité. S’il n’y a pas d’exclusions ou d’inadmissibilités sur la demande et que le MCE est autre que D, l’agent détermine la date de début de l’incapacité en utilisant les renseignements sur le certificat médical.

Des précisions ont été ajoutées pour expliquer que l’agent utilise la semaine de début de la période d’incapacité pour calculer la semaine de guérisson.

Date de guérison

Quand le certificat médical indique que le client est incapable de travailler jusqu’à une date spécifique, cette date est la dernière journée d’incapacité et la semaine de guérison est le jour suivant.

Quand le MCE est D pour une demande initiale ou renouvelée et qu’il n’y a pas d’exclusions ou d’inadmissibilités, l’agent utilise le DPP ou la semaine de renouvellement comme date de début de l’incapacité lorsqu’il détermine la semaine de guérison, qu’un certificat médical ait été présenté ou non. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/misejour_date_debut_incapacite_updated__e055625c/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
