# Renseignements : Post-PU AE et les renseignements sur la transition vers l’AE et les mesures provisoires

Source map: `fr_FR/site/dossier/information_erb_pu_post_transitition/information_erb_pu_post_transitition.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/information_erb_pu_post_transitition/sommaire.dita`

Le but de cette mise à jour est de fournir aux agents des renseignements sur les changements à venir qui seront mis en œuvre à compter du 27 septembre 2020 en ce qui concerne la transition des prestations d'urgence (PU AE/PCU) à l'assurance-emploi. 

## Generic

Source topic: `fr_FR/site/dossier/information_erb_pu_post_transitition/generic.dita`

**Transition vers l’AE – Post PU AE**

Compte tenu du volume élevé de demandes attendues après la fin de la période PU AE/PCU, des mises à jour des systèmes et des mesures provisoires ont été élaborées. Ces changements seront mis en œuvre pour soutenir les clients pendant cette période de transition et à l'avenir. Bien que des détails et une formation supplémentaires seront fournis avant ces mises à jour, la présente mise à jour vise à donner aux agents un bref aperçu des changements à venir.Les mesures provisioires suivantes seront mises en place :

**Taux regional de chômage**

Comme première étape pour aider les Canadiens admissibles à faire la transition entre la PU AE/PCU et l'AE et à réintégrer la population active, un taux de chômage minimum est utilisé pour toutes les régions économiques de l'AE afin de réduire le nombre d'heures requises pour avoir droit aux prestations régulières de l'AE. Mis en œuvre le 9 août 2020, le taux de chômage minimum pour les 62 régions économiques est maintenant fixé à 13,1 %, à moins que le taux de chômage minimum déclaré pour cette région ne soit plus élevé. Ce changement est en vigueur pour les DPP de la s/c 2251 (9 août 2020) à la s/c 2309 (25 septembre 2021).

**Crédit d’heures**

L'accès aux prestations d’AE est normalement basé sur le nombre d'heures assurables qu'une personne a travaillé au cours de l'année précédant sa demande, ou depuis sa dernière demande. La pandémie a empêché de nombreux Canadiens d'accumuler le nombre d'heures assurables normalement requis, et le gouvernement a pris des mesures pour y remédier. Un crédit unique de 300 heures pour les prestations régulières et de 480 heures pour les prestations spéciales sera automatiquement appliqué aux clients admissibles ayant un DPP de la s/c 2258 (27 septembre 2020) à la s/c 2309 (25 septembre 2021).

En fixant le RRU minimum à 13,1 %, le gouvernement du Canada peut uniformiser les prestations dans tout le pays. Ainsi, les clients auront droit à un minimum de 26 semaines de prestations régulières et utiliseront les 14 meilleures semaines pour calculer le taux des prestations. Il permet également de fixer le nombre d'heures assurables requises à un minimum de 420 heures, ce qui, combiné au crédit d'heures, permet aux personnes d'être admissibles aux prestations d'assurance-emploi avec seulement 120 heures de travail assurable.

**Taux minimum de prestations**

Afin de soutenir davantage les clients et en plus des mesures ci-dessus qui augmenteront l'accès au programme, un taux minimum de 400 $ par semaine ou 240 $ par semaine pour les prestations parentales prolongées sera automatiquement appliqué aux clients admissibles ayant un DPP de la s/c 2258 (27 septembre 2020) à la s/c 2309 (25 septembre 2021).

**Suppresion du DC**

Le délai de carence sera supprimé pour toutes les nouvelles demandes initiales, qu'elles aient ou non reçu la PU AE/PCU de l'AE, pour les demandes ayant un DPP de la s/c 2258 (27 septembre 2020) jusqu'à et y compris un DPP à la s/c 2262 (25 octobre 2020).

**Prolongation de la période de référence (PR)**

Une prolongation automatique de la PR de 28 semaines sera accordée à toutes les demandes ayant un DPP de la s/c 2258 (27 septembre 2020) à la s/c 2309 (25 septembre 2021) lorsque la demande du client est converti de la PU AE / PCU à l’AE.

**Indemnités de cessation d’emploi**

La répartition des indemnités de cessation d’emploi ne sera plus requise pour toute demande dont la date de début de la répartition commencerait le 27 septembre 2020 ou après, jusqu'au 25 septembre 2021, quel que soit le DPP.

**Prolongation de la période de maladie occasionnelle**

Le nombre de semaines de maladie occasionnelle est porté à 15 semaines pour tous les déclarations du prestataire traitées entre le 27 septembre 2020 et le 24 janvier 2021, indépendamment du DPP ou du fait que le clent ait reçu la PU AE ou la PCU.

**Motif de cessation d’emploi**

Des mesures de simplification seront mises en œuvre en ce qui concerne la prise de décision concernant des MCE litigieux sur les nouvelles demandes initiales de prestations régulières et de maladie pour les demandes ayant un DPP de la s/c 2258 (27 septembre 2020) à la s/c 2309 (25 septembre 2021).

**Processus spécalisé du TAD**

Pour soutenir les mesures provisoires, un nouveau processus spécialisé du TAD sera mis en œuvre. Cela permettra aux clients admissibles qui n'ont pas déclaré un retour au travail d'être automatiquement inscrits aux prestations régulières de l’AE sans avoir à remplir une nouvelle demande. Ce nouveau processus permettra également de traiter efficacement les nouvelles demandes initiales de prestations régulières ou de maladie tout en appliquant les mesures provisoires appropriées.

Les procédures relatives aux mesures provisoires énumérées ci-dessus seront mises à jour et de plus amples détails seront fournis une fois que les mesures provisoires seront en vigueur. Surveillez ces titres et mises à jour le 28 septembre 2020.

Bien que ces informations soient les plus récentes, elles sont susceptibles d'être modifiées et des mises à jour seront communiquées au besoin. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/information_erb_pu_post_transitition/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
