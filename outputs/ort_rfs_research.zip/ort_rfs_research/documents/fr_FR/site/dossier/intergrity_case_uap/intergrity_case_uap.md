# Cas d’intégrité – Mise à jour de la page d’activité

Source map: `fr_FR/site/dossier/intergrity_case_uap/intergrity_case_uap.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/intergrity_case_uap/sommaire.dita`

La page d’activité Cas d’intégrité a été mise à jour afin d’y inclure de l’information touchant les meilleures semaines variables. 

## Generic

Source topic: `fr_FR/site/dossier/intergrity_case_uap/generic.dita`

Lorsqu’un client ne fournit pas de renseignements sur les meilleures semaines au moment du calcul initial de la demande et qu’Intégrité obtient les données réelles ce qui peut diminuer ou augmenter le taux de prestations, l’agent n’effectue pas de nouveau calcul avec les données des meilleures semaines. Un nouveau calcul de la demande est effectué seulement dans les cas où une autre situation le justifie (exemple : faux relevé d’emploi, MCE litigieux non déclaré). 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/intergrity_case_uap/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
