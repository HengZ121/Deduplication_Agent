# Mise à jour : Report d’une décision — Aucun avis requis — Procédures et ressource additionnelle (Tous les niveaux)

Source map: `fr_FR/site/dossier/maj_rep_dec_auc_avis_req-update_def_adj_ee5b496a/maj_rep_dec_auc_avis_req-update_def_adj_ee5b496a.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/maj_rep_dec_auc_avis_req-update_def_adj_ee5b496a/sommaire.dita`

Au cours du processus de révision du contenu des lettres SCA, le groupe de travail a décidé de supprimer tous les paragraphes de la lettre D-01-00-00 du système SCA qui contenaient des directives visant à informer les clients des décisions reportées liées aux motifs de cessation d’emploi (MCE), car il n’y a aucune obligation légale d’informer les clients des décisions reportées. Étant donné que le report de la décision liée à un MCE n’est pas une décision, dans un souci de cohérence et afin d’améliorer l’expérience client, toutes les pages de l’ORL AE ont été mises à jour et n’indiquent plus aux agents d’envoyer une lettre pour informer les clients des décisions reportées. 

## Generic

Source topic: `fr_FR/site/dossier/maj_rep_dec_auc_avis_req-update_def_adj_ee5b496a/generic.dita`

Cette mise à jour s’applique aux décisions reportées liées au MCE pour tous les genres de prestations (GP). Les agents continuent de suivre les directives pour consigner le report dans un rapport de décision (RD) dans SNCT quand le critère de report est rempli, mais ils n’ont plus besoin de mettre à jour ou de créer une lettre..

Les décisions dont les clients doivent être informés sont répertoriées dans la page Avis de décision : Exigences — Connaissances .
       [Avis de décision : Exigences — Connaissances](/fr/procedure/generic/additionalresources/notice_decision_ja.shtml)

Si un agent a déjà rédigé ou envoyé une lettre à imprimer qui contient les renseignements relatifs au report, ces lettres peuvent toujours être envoyées. Cependant, aucune lettre contenant des renseignements sur une décision reportée ne doit être créée à compter de la date de publication de cette mise à jour. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/maj_rep_dec_auc_avis_req-update_def_adj_ee5b496a/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
