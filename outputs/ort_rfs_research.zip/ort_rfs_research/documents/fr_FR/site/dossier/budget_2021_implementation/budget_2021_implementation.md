# Mise en œuvre du budget 2021

Source map: `fr_FR/site/dossier/budget_2021_implementation/budget_2021_implementation.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/budget_2021_implementation/sommaire.dita`

Le budget 2021 introduit des mesures législatives temporaires qui entrent en vigueur le 26 septembre 2021 (s/c 2310). Les procédures touchées seront mises à jour d’ici le 27 septembre 2021. 

## Generic

Source topic: `fr_FR/site/dossier/budget_2021_implementation/generic.dita`

Les nouvelles mesures législatives sont les suivantes :

- Norme d’admissibilité commune :

- Les clients ont besoin de 420 heures d’emploi assurable pour établir une demande de prestations régulières ou spéciales dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361).

- Un seuil de rémunération commun et comparable s’applique aux demandes de prestations de pêcheur (2 500 $) et de travailleur indépendant (5 289 $).

- Une majoration des conditions requises en raison de violations s’applique toujours.

- Motif de cessation d’emploi (MCE) :

- Pour les demandes initiales dont le DPP est entre la s/c 2310 et la s/c 2361 (à l’exclusion des prestations de pêcheur et de travailleur indépendant), une décision est seulement rendue sur un MCE litigieux s’il s’agit du dernier RE dans la période de référence (PR).

- Exception : Quand le MCE est une grève ou un lockout, une décision est requise.

- Toutes les heures d’emploi assurable dans la PR sont utilisées pour établir la demande (aucun RE n’est exclu).

- Une décision est requise sur tous les MCE litigieux dans la période de prestations (PP).

- Indemnités de cessation d’emploi :

- Certaines sommes versées en raison d’une cessation d’emploi ne sont pas réparties. Cette mesure s’applique  quand la date de début de la répartition est entre la s/c 2310 et la s/c 2361.

- Taux de prestations minimal :

- Un taux de prestations minimal de 300 $ par semaine (180 $ pour les prestations parentales prolongées) s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et 14 novembre 2021 (s/c 2317).

De plus, le budget 2021 prolonge les mesures temporaires suivantes :

- Travailleurs saisonniers :

- 5 semaines supplémentaires de prestations régulières pour les travailleurs saisonniers dans certaines régions économiques. Cette mesure se terminera le 29 octobre 2022 (s/c 2366).

- Pêcheurs :

- Cette mesure temporaire est prolongée jusqu’au 18 décembre 2021 (s/c 2361). Ceci permet aux pêcheurs indépendants d’établir une PP de pêcheur hivernale pour l’année 2021 selon leur rémunération assurable la plus récente ou celle utilisée pour établir une demande précédente, le montant le plus élevé étant retenu. Les pêcheurs indépendants peuvent profiter de cette mesure une seule fois par genre de demande de pêcheur.

- Travail partagé (TP) :

- La prolongation des améliorations temporaires au programme de TP permet de prolonger les accords de TP et de supprimer la période de restriction pour un accord subséquent.

**Mises à jour des systèmes et des procédures**

Les systèmes seront mis à jour pour prendre en charge ces nouvelles mesures le 11 septembre 2021. Les procédures touchées par ces nouvelles mesures seront mises à jour le 13 septembre 2021, mais s’appliqueront seulement aux demandes dont le DPP provisoire ou final est entre la s/c 2310 et la s/c 2361. Les procédures liées aux mesures prolongées seront mises à jour le 27 septembre 2021.

Les mesures de simplification temporaires (p. ex. sur le recueil de faits, les certificats médicaux,les permis de travail) continuent de s’appliquer jusqu’au 25 septembre 2021.
       [Les mesures de simplification temporaires](/fr/site/dossier/updated_extension_temporary_simplification_measures_l1_l2_ipoc.shtml)

Les dispositions de transition pour les prestations d’urgence (p. ex. le crédit d’heures, le taux de prestations minimal,a règle de 12 semaines pour le MCE) continueront de s’appliquer aux demandes dont le DPP est avant la s/c 2310.
       [Les dispositions de transition pour les prestations d’urgence](/fr/site/dossier/new_erbt_be2020-05.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0963.dita) 

Les procédures indiquent toutes les mesures de simplification qui sont actuellement en vigueur. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0963.dita`

Remarque :

À compter du 11 septembre 2021, le système ne rendra plus de décision automatique sur la formation. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/budget_2021_implementation/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
