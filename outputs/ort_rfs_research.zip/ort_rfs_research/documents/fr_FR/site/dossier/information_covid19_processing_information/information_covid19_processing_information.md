# Renseignements : COVID-19 et le traitement des demandes (Questions et réponses)

Source map: `fr_FR/site/dossier/information_covid19_processing_information/information_covid19_processing_information.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/information_covid19_processing_information/sommaire.dita`

En raison de la COVID-19, des renseignements supplémentaires sont fournis pour faciliter le traitement des demandes. 

## Generic

Source topic: `fr_FR/site/dossier/information_covid19_processing_information/generic.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1066.dita) 

En raison de la COVID-19, des renseignements supplémentaires sont fournis pour faciliter le traitement des demandes.

Les renseignements contenus dans cette mise à jour fournissent aux agents les plus récentes procédures, politiques, directive en lien avec la charge de travail et les renseignements liés aux systèmes pour les aider à traiter les demandes.

Toutefois, puisque la situation évolue constamment, ces renseignements pourraient changer et seront mis à jour, au besoin.

Cette page sera mise à jour régulièrement afin d’y inclure d’autres questions et réponses.

**Table des matières**

- Prestation d’AE d’urgence – Renseignements généraux

- Comment les agents peuvent-ils reconnaître une demande pour la prestation d’AE d’urgence?
             [Comment les agents peuvent-ils reconnaître une demande pour la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_How_can_agents)

- Comment les clients peuvent savoir s’ils doivent déposer une demande auprès de l’Agence du revenu du Canada ou de Service Canada?
             [Comment les clients peuvent savoir s’ils doivent déposer une demande auprès de l’Agence du revenu du Canada ou de Service Canada?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_How_do_clients)

- Est-ce qu’un client ayant une demande de prestation d’AE d’urgence peut demander que sa demande soit établie sous les règles habituelles de l’AE et ainsi obtenir un taux de prestations supérieur à 500$ par semaine?
             [Est-ce qu’un client ayant une demande de prestation d’AE d’urgence peut demander que sa demande soit établie sous les règles habituelles de l’AE et ainsi obtenir un taux de prestations supérieur à 500$ par semaine?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Can_a_client)

- Est-ce que la prestation d’AE d’urgence comptera comme des semaines d’admissibilité régulières d’AE?
             [Est-ce que la prestation d’AE d’urgence comptera comme des semaines d’admissibilité régulières d’AE?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Will_the_EI)

- En quoi consiste le versement unique de 2000$ que les clients recevront?
             [En quoi consiste le versement unique de 2000$ que les clients recevront?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_What_is_the)

- Combien de semaines de la prestation d’AE d’urgence le client peut-il demander?
             [Combien de semaines de la prestation d’AE d’urgence le client peut-il demander?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Combien_de_semaines)

- Est-ce que le paiement unique de 2000$ est émis pour toutes les demandes de prestation d’AE d’urgence?
             [Est-ce que le paiement unique de 2000$ est émis pour toutes les demandes de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Is_the_one-time)

         [Prestation d’AE d’urgence – Renseignements généraux](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#EI_Emergency_Response_gi)

- Prestation d’AE d’urgence – Traitement des demandes

- Que doivent faire les agents avec les RSDP en ébauche lorsque la demande a été complétée comme une demande de prestation d’AE d’urgence?
             [Que doivent faire les agents avec les RSDP en ébauche lorsque la demande a été complétée comme une demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_What_should_agents)

- Est-ce que les demandes précédemment finalisées PPNE dont le DPP était le 15 mars 2020 ou après seront converties en demande de prestation d’AE d’urgence?
             [Est-ce que les demandes précédemment finalisées PPNE dont le DPP était le 15 mars 2020 ou après seront converties en demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_que_les6)

- Où l’agent trouve-t-il des renseignements sur le DPP provisoire d’une demande de base?
             [Où l’agent trouve-t-il des renseignements sur le DPP provisoire d’une demande de base?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#client_dernier_jour)

- Pour quelles raisons une demande de base ne sera pas prise en charge par l’utilitaire de TAD afin d’être établie en tant que demande de prestation d’AE d’urgence?
             [Pour quelles raisons une demande de base ne sera pas prise en charge par l’utilitaire de TAD afin d’être établie en tant que demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#urgence_ae)

- Est-ce que les agents peuvent annuler une inadmissibilité ou une exclusion qui a été impose sur une demande de prestation d’AE d’urgence?
             [Est-ce que les agents peuvent annuler une inadmissibilité ou une exclusion qui a été impose sur une demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#agent_peuvent_annuler)

- Est-ce qu’il y a une période spécifique pendant laquelle un client peut demander la prestation d’AE d’urgence?
             [Est-ce qu’il y a une période spécifique pendant laquelle un client peut demander la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_qu’il_y)

- Est-ce que l’agent doit vérifier l’écran Détails PCU afin de déterminer si le client reçoit la PCU avant d’établir une demande de prestation d’AE d’urgence?
             [Est-ce que l’agent doit vérifier l’écran Détails PCU afin de déterminer si le client reçoit la PCU avant d’établir une demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_que_l’agent)

- Pourquoi l’inadmissibilité 65 - Paiement forfaitaire (2000 $) - Prestations d’urgence (D65) est-elle imposée dans les demandes de prestation d’AE d’urgence?
             [Pourquoi l’inadmissibilité65 - Paiement forfaitaire (2000 $) - Prestations d’urgence (D65)est-elle imposée dans les demandes de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Pourquoi_l’inadmissibilité_65)

- Comment l’inadmissibilité D65 sera-t-elle communiquée aux clients?
             [Comment l’inadmissibilité D65 sera-t-elle communiquée aux clients?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Comment_l’inadmissibilité_65)

- Est-ce que la D65 est imposée sur les demandes où le client a reçu de l’agent de l’ARC?
             [Est-ce que la D65 est imposée sur les demandes où le client a reçu de l’agent de l’ARC?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_que_la)

- Le champ PCU (ARC) est-il mis à jour lorsque le client rembourse l'argent versé?
             [Le champ PCU (ARC) est-il mis à jour lorsque le client rembourse l'argent versé?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Le_champ_PCU)

- Est-ce que les clients, qui étaient en congé de maternité ou parental immédiatement avant le début de la pandémie, sont considérés avoir perdu leur emploi à cause de la COVID-19 s’ils ne peuvent pas reprendre le travail?
             [Est-ce que les clients, qui étaient en congé de maternité ou parental immédiatement avant le début de la pandémie, sont considérés avoir perdu leur emploi à cause de la COVID-19 s’ils ne peuvent pas reprendre le travail?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_que_les2)

         [Prestation d’AE d’urgence – Traitement des demandes](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#ei_rb_pc)

- Après le dernier paiement de la prestation d’AE d’urgence

- Un client doit-il soumettre une nouvelle demande d’AE ou appeler Service Canada après avoir reçu 28 semaines de la prestation d’AE d’urgence?
             [Un client doit-il soumettre une nouvelle demande d’AE ou appeler Service Canada après avoir reçu 28 semaines de la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Un_client_doit-il)

- Un client doit-il soumettre une nouvelle demande d’AE ou appeler Service Canada après avoir reçu 28 semaines de la PCU?
             [Un client doit-il soumettre une nouvelle demande d’AE ou appeler Service Canada après avoir reçu 28 semaines de la PCU?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Un_client_doit-il_1)

         [Après le dernier paiement de la prestation d’AE d’urgence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Après_de_dernier)

- Prestation canadienne d’urgence pour les étudiants

- Qu’est-ce que la Prestation canadienne d’urgence pour les étudiants?
             [Qu’est-ce que la Prestation canadienne d’urgence pour les étudiants?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Qu’est-ce_que_la_pcue)

- Quel montant les étudiants peuvent-ils toucher?
             [Quel montant les étudiants peuvent-ils toucher?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Quel_montant_les)

- Est-ce qu’une demande de Prestation d’urgence de l’AE peut être terminée au profit d’une demande de Prestation canadienne d’urgence pour les étudiants?
             [Est-ce qu’une demande de Prestation d’urgence de l’AE peut être terminée au profit d’une demande de Prestation canadienne d’urgence pour les étudiants?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_qu’une_demande)

         [Prestation canadienne d’urgence pour les étudiants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Prestation_canadienne_d’urgence)

- Subvention salariale d’urgence du Canada

- Qu’est-ce que la Subvention salariale d’urgence du Canada
             [Qu’est-ce que la Subvention salariale d’urgence du Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Qu’est-ce_que_la_1)

- Est-ce qu’un employeur devrait inclure la SSUC dans la rémunération lorsqu’il complète un RE?
             [Est-ce qu’un employeur devrait inclure la SSUC dans la rémunération lorsqu’il complète un RE?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_qu’un_employeur)

- Comment l’employeur devrait attribuer les heures lorsque les employés reçoivent leur salaire habituel, mais ne travaillent pas?
             [Comment l’employeur devrait attribuer les heures lorsque les employés reçoivent leur salaire habituel, mais ne travaillent pas?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#Comment_l’employeur_devrait)

- Comment l’employeur devrait attribuer les heures lorsque les employés moins que le montant de leur salaire habituel?
             [Comment l’employeur devrait attribuer les heures lorsque les employés moins que le montant de leur salaire habituel?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Comment_l’employeur_devrait_1)

         [Subvention salariale d’urgence du Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Subvention_salariale_d’urgence)

- NAS de la série 900

- Est-ce que les clients ayant un NAS de la série 900 peuvent recevoir des prestations si un permis de travail valide n ’est pas au dossier?
             [Est-ce que les clients ayant un NAS de la série 900 peuvent recevoir des prestations si un permis de travail validen’estpasau dossier?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_que_les3)

- Que devrait faire les agents qui ont un article ECAL Assurabilité pour un client qui a un NAS de la série 900?
             [Que devrait faire les agents qui ont un article ECAL Assurabilité pour un client qui a un NAS de la série 900?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Que_devrait_faire)

- Est-ce que les clients qui ont un NAS de la série 900 sont considérés comme étant disponible au travail s’ils ne peuvent pas travailler en raison de la COVID-19?
             [Est-ce que les clients qui ont un NAS de la série 900 sont considérés comme étant disponible au travail s’ilsnepeuventpastravailler en raison de la COVID-19?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_que_les_1)

         [NAS de la série 900](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_NAS_de_la)

- Disponibilité

- Est-ce que les clients doivent être activement à la recherche d’un emploi pendant la pandémie de la COVID-19?
             [Est-ce que les clients doivent être activement à la recherche d’un emploi pendant la pandémie de la COVID-19?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Are_clients_expected)

- Est-ce que les clients qui éprouvent de la difficulté au niveau de la garde de leurs enfants en raison de la COVID-19 sont considérés comme disponibles?
             [Est-ce que les clients qui éprouvent de la difficulté au niveau de la garde de leurs enfants en raison de la COVID-19 sont considérés comme disponibles?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Can_clients_who)

- Est-ce qu’un cours de formation est considéré comme étant une situation litigieuse pour une demande de Prestation d’urgence de l’AE?
             [Est-ce qu’un cours de formation est considéré comme étant une situation litigieuse pour une demande de Prestation d’urgence de l’AE?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Is_training_considered)

- Est-ce qu’un agent peut terminer une inadmissibilité 3-Non disponible (D03) sur une demande dont le DPP est avant le 15 mars 2020, si le cours de formation du client s’est terminé en raison de la COVID-19?
             [Est-ce qu’un agent peut terminer une inadmissibilité3-Non disponible (D03)sur une demande dont le DPP est avant le 15 mars 2020, si le cours de formation du client s’est terminé en raison de la COVID-19?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_qu’un_agent)

         [Disponibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#availability)

- Déclaration du prestataire

- Est-ce que les clients dont la demande a été établie en tant que prestation d’AE d’urgence doivent faire leurs déclarations du prestataire?
             [Est-ce que les clients dont la demande a été établie en tant que prestation d’AE d’urgence doivent faire leurs déclarations du prestataire?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Do_clients_with)

- Comment les renseignements déclarés sur la déclaration du prestataire sont-ils traités par le système?
             [Comment les renseignements déclarés sur la déclaration du prestataire sont-ils traités par le système?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_How_does_the)

- Combien de temps les clients ont-ils pour compléter leur déclaration du prestataire?
             [Combien de temps les clients ont-ils pour compléter leur déclaration du prestataire?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_How_long_do)

- Quelles actions doivent être prises lorsque le client déclare avoir fait une erreur sur une déclaration du prestataire d’une demande de prestation d’AE d’urgence?
             [Quelles actions doivent être prises lorsque le client déclare avoir fait une erreur sur une déclaration du prestataire d’une demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_What_actions_must)

- Comment le client doit compléter sa DP lorsqu’il a été rappelé au travail mais qu’il est capable d’y retourner?
             [Comment le client doit compléter sa DP lorsqu’il a été rappelé au travail mais qu’il est capable d’y retourner?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#DP)

         [Déclaration du prestataire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#claimant_report)

- Rémunération

- Est-ce qu’une répartition de rémunération a un impact sur une demande de prestation d’AE d’urgence?
             [Est-ce qu’une répartition de rémunération a un impact sur une demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Does_allocation_of)

- Est-ce qu’une lettre de répartition de rémunération doit être envoyée au client qui reçoit la prestation d’AE d’urgence?
             [Est-ce qu’une lettre de répartition de rémunération doit être envoyée au client qui reçoit la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_qu’une_lettre)

         [Rémunération](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#earnings)

- Supplément familial

- Est-ce qu’un client ayant une demande de prestation d’AE d’urgence est admissible au supplément familial?
             [Est-ce qu’un client ayant une demande de prestation d’AE d’urgence est admissible au supplément familial?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Is_a_client)

- Le supplément familial s'applique-t-il au versement initial de 2000$?
             [Le supplément familial s'applique-t-il au versement initial de 2000$?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#supplement_family_2000)

         [Supplément familial](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#fs)

- Déductions d’impôts et T4

- Est-ce qu’un client peut demander à ce que des déductions d’impôts soient prélevées des paiements de la prestation d’AE d’urgence?
             [Est-ce qu’un client peut demander à ce que des déductions d’impôts soient prélevées des paiements de la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Can_a_client_4)

- Est-ce que les clients recevront un T4 s’ils ont reçu un paiement de la PCU?
             [Est-ce que les clients recevront un T4 s’ils ont reçu un paiement de la PCU?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Will_clients_receive)

- Est-ce que des déductions d’impôts sont perçus sur les paiements de la prestation d’AE d’urgence?
             [Est-ce que des déductions d’impôts sont perçus sur les paiements de la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_que_des)

         [Déductions d’impôts et T4](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#it_t4)

- Prestations de maternité et la prestation d’AE d’urgence

- Comment les paiements provenant de la prestation d’AE d’urgence affecteront les clients demandant des prestations de maternité ou parentales après la période de la prestation d’AE d’urgence?
             [Comment les paiements provenant de la prestation d’AE d’urgence affecteront les clients demandant des prestations de maternité ou parentales après la période de la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Comment_les_paiements)

- Est-ce que les paiements de la prestation d’AE d’urgence affectent les semaines d’admissibilité aux prestations de maternité ou parentales?
             [Est-ce que les paiements de la prestation d’AE d’urgence affectent les semaines d’admissibilité aux prestations de maternité ou parentales?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_que_les5)

- Est-ce qu’une semaine d’arrivée de placement ou une semaine d’accouchement peut être saisie sur une demande de la prestation d’AE d’urgence?
             [Est-ce qu’une semaine d’arrivée de placement ou une semaine d’accouchement peut être saisie sur une demande de la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_qu’une_semaine)

- Est-ce qu’il y a une équipe spécialisée qui s’occupe du traitement des demandes de prestations de maternité après que la cliente est reçue la Prestation d’urgence de l’AE?
             [Est-ce qu’il y a une équipe spécialisée qui s’occupe du traitement des demandes de prestations de maternité après que la cliente est reçue la Prestation d’urgence de l’AE?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_qu’il_y2)

- Est-ce que la PR est prolongée lorsque la cliente demande des prestations de maternité après avoir reçu des paiements de la prestation d’AE d’urgence?
             [Est-ce que la PR est prolongée lorsque la cliente demande des prestations de maternité après avoir reçu des paiements de la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_que_la2)

         [Prestations de maternité et la prestation d’AE d’urgence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Prestations_de_maternité)

- Hors Canada

- o Est-ce qu’une inadmissibilité doit être imposée pour une situation de hors Canada sur une demande de prestation d’AE d’urgence?
             [o Est-ce qu’une inadmissibilité doit être imposée pour une situation de hors Canada sur une demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Should_a_disentitlement)

         [Hors Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#out_canada)

- Trop payé et paiements en double

- Est-ce que les clients devront rembourser le trop-payé qui a été créé lorsque leur demande a été recalculée comme une demande de prestation d’AE d’urgence (le taux de prestations était de 573$ est maintenant de 500$)?
             [Est-ce que les clients devront rembourser le trop-payé qui a été créé lorsque leur demande a été recalculée comme une demande de prestation d’AE d’urgence (le taux de prestations était de 573$ est maintenant de 500$)?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Will_clients_have)

- Selon quelles circonstances est-ce qu’un client pourrait se voir demander de repayer des paiements reçus de l’ARC pour la PCU?
             [Selon quelles circonstances est-ce qu’un client pourrait se voir demander de repayer des paiements reçus de l’ARC pour la PCU?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Under_what_circumstances)

- Est-ce qu’un client peut repayer ou retourner un paiement de la PCU directement à l’ARC?
             [Est-ce qu’un client peut repayer ou retourner un paiement de la PCU directement à l’ARC?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Can_a_client_repay)

- Est-ce que le client peut repayer ou retourner un paiement de la PCU à Service Canada?
             [Est-ce que le client peut repayer ou retourner un paiement de la PCU à Service Canada?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Can_a_client_choose)

- Comment le client peut-il choisir de repayer un retourner un paiement de la prestation d’AE d’urgence à Service Canada?
             [Comment le client peut-il choisir de repayer un retourner un paiement de la prestation d’AE d’urgence à Service Canada?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Comment_le_client)

         [Trop payé et paiements en double](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#op_dp)

- Postdates et antidates

- Est-ce qu’une demande de prestations régulières ou de maladie peut être postdatée au 15 mars 2020 afin d’être établie comme une demande de prestation d’AE d’urgence?
             [Est-ce qu’une demande de prestations régulières ou de maladie peut être postdatée au 15 mars 2020 afin d’être établie comme une demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Can_a_claim)

- Est-ce qu’un client peut demander une antidate de sa demande de prestation d’AE d’urgence?
             [Est-ce qu’un client peut demander une antidate de sa demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Can_a_client_request)

         [Postdates et antidates](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Postdates)

- Enseignants

- Est-ce qu’une décision doit être prise sur la question de l’enseignement sur une demande de prestation d’AE d’urgence?
             [Est-ce qu’une décision doit être prise sur la question de l’enseignement sur une demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#enseignement)

         [Enseignants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#Enseignants)

- Terminer une demande existante

- Est-ce qu’un client ayant une demande avec un DPP avant le 15 mars 2020, qui pourrait être renouvelée, peut demander la terminaison de cette demande afin de recevoir la prestation d’AE d’urgence?
             [Est-ce qu’un client ayant une demande avec un DPP avant le 15 mars 2020, qui pourrait être renouvelée, peut demander la terminaison de cette demande afin de recevoir la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Can_a_client_bpc)

- Est-ce qu’un client peut demander de terminer une demande de prestation d’AE d’urgence en faveur d’une demande de prestations spéciales de l’AE?
             [Est-ce qu’un client peut demander de terminer une demande de prestation d’AE d’urgence en faveur d’une demande de prestations spéciales de l’AE?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_qu’un_client)

         [Terminer une demande existante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Terminating_an_existing)

- Cours de formation – Cours dirigé et apprenti

- Est-ce qu’un client ayant une approbation sous la Section 25 peut recevoir des paiements de la prestation d’AE d’urgence?
             [Est-ce qu’un client ayant une approbation sous la Section 25 peut recevoir des paiements de la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#Section_25)

- Comment l’autorité désignée peut vérifier si le client reçoit des paiements de la prestation d’AE d’urgence?
             [Comment l’autorité désignée peut vérifier si le client reçoit des paiements de la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#paiements_de_la_prestation)

- Qu’arrive-t-il lorsqu’un client dépose une demande avec un code de référence pour apprenti?
             [Qu’arrive-t-il lorsqu’un client dépose une demande avec un code de référence pour apprenti?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#apprenti)

- Est-ce que les clients participant à un cours de formation dirigé (incluant les apprentis) sont éligibles aux paiements de la Partie II de la LAE?
             [Est-ce que les clients participant à un cours de formation dirigé (incluant les apprentis) sont éligibles aux paiements de la Partie II de la LAE?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#Partie_II)

- Est-ce que les sommes reçues pour de l’assistance financière ont un impact sur une demande de prestation d’AE d’urgence?
             [Est-ce que les sommes reçues pour de l’assistance financière ont un impact sur une demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#assistance)

- Est-ce que l’information sur le projet peut être saisi sur une demande de prestation d’AE d’urgence?
             [Est-ce que l’information sur le projet peut être saisi sur une demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#projet)

- Est-ce que les clients recevant la prestation d’AE d’urgence qui ont été référés comme apprenti peuvent être exempté de compléter leurs DP?
             [Est-ce que les clients recevant la prestation d’AE d’urgence qui ont été référés comme apprenti peuvent être exempté de compléter leurs DP?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#DP2)

         [Cours de formation – Cours dirigé et apprenti](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#Cours_de_formation)

- Délai de carence

- Est-ce que le délai de carence peut être supprimé sur une demande de renouvellement si le délai de carence n’a pas été servi?
             [Est-ce que le délai de carence peut être supprimé sur une demande de renouvellement si le délai de carence n’a pas été servi?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Can_the_WP)

         [Délai de carence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#wp)

- Retirer une demande de la prestation d’AE d’urgence

- Est-ce qu’un client peut retirer sa demande de prestation d’AE d’urgence?
             [Est-ce qu’un client peut retirer sa demande de prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Est-ce_qu’un_client)

         [Retirer une demande de la prestation d’AE d’urgence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#_Retirer_une_demande)

- Travail partagé

- Est-ce qu’un client qui fait partie d’une entente de travail partagé peut toucher la prestation d’AE d’urgence?
             [Est-ce qu’un client qui fait partie d’une entente de travail partagé peut toucher la prestation d’AE d’urgence?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#tp_1)

- Est-ce qu’un employeur ayant une entente valide de travail partagé peut combiner le travail partagé à la Subvention salariale d’urgence du Canada?
             [Est-ce qu’un employeur ayant une entente valide de travail partagé peut combiner le travail partagé à la Subvention salariale d’urgence du Canada?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#tp_2)

- Est-ce que l’employeur doit obtenir le montant exact des prestations de l’AE que chaque employé reçoit?
             [Est-ce que l’employeur doit obtenir le montant exact des prestations de l’AE que chaque employé reçoit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#tp_3)

- Est-ce qu’un employeur peut terminer une entente de travail partagé afin d’obtenir la Subvention salariale d’urgence du Canada?
             [Est-ce qu’un employeur peut terminer une entente de travail partagé afin d’obtenir la Subvention salariale d’urgence du Canada?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#tp_4)

         [Travail partagé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/site/dossier/information_covid19_processing_information#tp)

**Prestation d’AE d’urgence – Renseignements généraux**

**Comment les agents peuvent-ils reconnaître une demande pour la prestation d’AE d’urgence?**

Une fois traitées, ces demandes affichent 5 - Utilitaire d’automatisation COVID-19 ou 6 - Utilitaire de réévaluation COVID-19 dans le champ Renseignements supplémentaires dans ETI.

**Comment les clients peuvent savoir s’ils doivent déposer une demande auprès de l’Agence du revenu du Canada ou de Service Canada?**

Les clients doivent compléter un questionnaire , les réponses fournies permettent ensuite d’orienter le client vers l’option de service qui correspond le mieux à sa situation.
       [questionnaire](https://www.canada.ca/fr/services/prestations/ae/pcusc-application.html)

**Est-ce qu’un client ayant une demande de prestation d’AE d’urgence peut demander que sa demande soit établie sous les règles habituelles de l’AE et ainsi obtenir un taux de prestations supérieur à 500$ par semaine?**

Non. Toutes demandes de prestations régulières ou de maladie ayant un DPP entre le 15 mars 2020 et le 27 septembre 2020 sont considérées comme étant des demandes de prestation d’AE d’urgence et le taux de prestations ne peut être modifié.

**Est-ce que la prestation d’AE d’urgence comptera comme des semaines d’admissibilité régulières d’AE?**

Non. Si les clients demandent encore des prestations d’AE après 28 semaines de versement de la prestation d’AE d’urgence, ces 28 semaines n’auront pas d’incidence sur l’admissibilité régulière du client à des prestations d’AE.

**En quoi consiste le versement unique de 2000$ que les clients recevront?**

Jusqu’au 22 juin 2020, les clients qui étaient admissibles à la prestation d’AE d’urgence recevaient un versement initial de 2 000 $ immédiatement après l’établissement de leur demande. Après le versement initial de 2000$, les clients qui demandent la prestation d’AE d’urgence doivent continuer de remplir les déclarations du prestataire bihebdomadaires pour démontrer leur admissibilité continue aux prestations. Les clients recevront 1000$ pour chaque déclaration du prestataire bihebdomadaire remplie.

En raison de la date du versement initial de 2000 $ et selon le moment où les demandes ont été finalisées, quelques clients pourraient déjà avoir reçu leur premier versement, ou même leurs 2 premiers versements pour la prestation d’AE d’urgence. Ces clients recevront également le versement initial de 2000 $ comme une avance des semaines qui seront payées plus tard dans leur demande. Aucun client ne recevra plus de 28 semaines de prestations.

Les détails du versement initial de 2000 $ s’affiche dans l’écran Détails PCU .

**Est-ce que le paiement unique de 2000$ est émis pour toutes les demandes de prestation d’AE d’urgence?**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1067.dita) 

Avant le 22 juin 2020, chaque lundi, un paiement unique de 2 000$ était émis à tout client qui a présenté une demande de prestation d’AE d’urgence dans la semaine précédente. Ce paiement était considéré comme une avance de paiement sur les 4 dernières semaines d’admissibilité à la prestation d’AE d’urgence.

Le paiement unique n’est pas payé sur les demandes où la cliente déclare être enceinte ou pour les clients qui ont reçu des paiements de la PCU.

**Combien de semaines de la prestation d’AE d’urgence le client peut-il demander?**

28 semaines. Initialement fixé à 16 semaines d’admissibilité, le gouvernement du Canada a annoncé le 16 juin 2020 que la prestation d’AE d’urgence serait portée à 24 semaines. Le 20 août 2020, le gouvernement du Canada a annoncé que la prestation d’AE d’urgence serait portée à 28 semaines., Toutefois, la période pendant laquelle les clients peuvent recevoir les paiements de la prestation d’AE d’urgence reste inchangée. Les clients ont jusqu’au 3 octobre 2020 pour toucher la totalité des 28 semaines de prestations.

**Prestation d’AE d’urgence – Traitement des demandes**

**Que doivent faire les agents avec les RSDP en ébauche lorsque la demande a été complétée comme une demande de prestation d’AE d’urgence?**

Les agents doivent sauvegarder tous documents en ébauche afin de préserver tout recueil de fait préliminaire. Les agents doivent ajouter une Note client indiquant que le recueil de fait est incomplet en raison de l’utilitaire.

**Est-ce que les demandes précédemment finalisées PPNE dont le DPP était le 15 mars 2020 ou après seront converties en demande de prestation d’AE d’urgence?**

Le 29 avril 2020, un utilitaire a permis d’établir des demandes de prestation d’AE d’urgence pour les clients dont la demande avait précédemment été finalisée PPNE 1 ou PPNE 5 et dont le DPP est le 15 mars 2020 ou après.

Si la demande n’a pas été récupérée par l’utilitaire du système avant ou avant d’établir une demande PPNE, l’agent doit consulter COVID-19 et établissement de demandes PPNE comme demandes pour la Prestation d’urgence de l’AE .
       [COVID-19 et établissement de demandes PPNE comme demandes pour la Prestation d’urgence de l’AE](/fr/site/dossier/updated_covid19_establishing_bpne_claim_as_eierbc_l1.shtml)

**Où l’agent trouve-t-il les renseignements sur le DPP provisoire d’une demande de base?**

Les renseignements sur le DPP provisoire peut être trouvé sur la transaction 149-Données d’inscription initiale à l’écran Historique des paiements .

**Pour quelles raisons une demande de base ne sera pas prise en charge par l’utilitaire de TAD afin d’être établie en tant que demande de prestation d’AE d’urgence?**

L’utilitaire de TAD n’automatisera pas la demande si l’une des conditions suivantes est remplie :

- le DPP provisoire dans la transaction 149-Données d’inscription initiale est au ou avant le 1 mars 2020

- le client a déclaré un dernier jour de travail avant le 20 juin 2019 dans la demande AppliWeb*

- la cliente a répondu oui à la question « Êtes-vous enceinte ou accouchez-vous dans les 17 prochaines semaines? »*

- le client a fourni un code de référence dans la demande AppliWeb incluant un code de Travail partagé

- le client est un travailleur frontalier, inter-état ou outre-mer*

- le client est un pêcheur*

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1068.dita) 

**Est-ce que les agents peuvent annuler une inadmissibilité ou une exclusion qui a été impose sur une demande de prestation d’AE d’urgence?**

Oui. Si la demande est une Demande PU , l’agent peut annuler les inadmissibilités ou exclusions suivantes si l’inadmissibilité débute le ou après le 15 mars 2020 :

- 1 - Non en chômage

- 2 - 2 ième catégorie, arrêt de rémunération maladie (non capable)

- 3 - Non disponible

- 10 - Congédiement - inconduite prouvée

- 11 - Abandon volontaire - motif valable non prouvé

- 12 - Détenu dans un établissement pénitencier

- 13 - Hors Canada

- 15 - Procédure de présentation des demandes

- 23 - Enseignant (durant une période de congé)

- 33 - Incapacité prouvée mais prestataire non autrement disponible

- 35 - Prestations parentales conditions de qualification non rencontrées

- 38 - En vacances au Canada

- 42 - Suspension d’un emploi

- 43 - Congé sans solde

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1069.dita) 

L’agent doit créer un RD :

- Commentaires : [saisir Inadmissibilité ou Exclusion] annulée - demande d’assurance-emploi – Prestation d’urgence

- Détails : [saisir Inadmissibilité ou Exclusion] annulée puisqu’il s’agit d’une demande d’assurance-emploi – Prestation d’urgence

**Est-ce qu’il y a une période spécifique pendant laquelle un client peut demander la prestation d’AE d’urgence?**

Oui. La période spécifique pour toucher les 28 semaines de la prestation d’AE d’urgence est du 15 mars 2020 au 3 octobre 2020. Cependant, il n’y a aucune exigence que le client touche les 28 semaines de façon consécutive. Par exemple, un client peut toucher 10 semaines de la prestation d’AE d’urgence, retourner au travail pendant 5 semaines et toucher ensuite les 14 dernières semaines de la prestation d’AE d’urgence après, en autant que les prestations soient touchées dans la période spécifique.

**Est-ce que l’agent doit vérifier l’écran Détails PCU afin de déterminer si le client reçoit la PCU avant d’établir une demande de prestation d’AE d’urgence?**

Oui. Un client ne peut pas recevoir de la PCU et la prestation d’AE d’urgence en même temps. Avant d’établir une demande de prestation d’AE d’urgence, l’agent doit vérifier l’écran Détails PU . Si le client reçoit la PCU, l’agent doit contacter le client afin de lui indiquer de demeurer sur la PCU.

Si la cliente est enceinte et reçoit la PCU, l’agent doit aviser la cliente d’attendre le moment où elle désire recevoir les prestations de maternité avant de déposer une demande.

L’agent consulte COVID-19 et Prestation d’urgence afin de déterminer les actions à prendre.
       [COVID-19 et Prestation d’urgence](/fr/site/dossier/information_covid19_emergency_response_benefits.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1070.dita) 

**Pourquoi l’inadmissibilité 65 - Paiement forfaitaire (2000 $) - Prestations d’urgence (D65) est-elle imposée dans les demandes de prestation d’AE d’urgence?**

Une inadmissibilité D65 est imposée pour justifier l’avance initiale de 2 000 $.

À partir du 8 juin 2020, pour éviter de causer des difficultés financières au client, l’inadmissibilité D65 sera imposée pendant 2 semaines à la fois. Les semaines 13 et 14 sont les premières semaines qui seront comptabilisées.  Les semaines 20 et 21 seront les deux dernières semaines qui seront comptabilisées.

Lorsque l’agent doit déterminer si la deuxième D65 doit être imposée, les deux critères suivants doivent être rencontrés :

- 17 semaines de la prestation d’AE d’urgence doivent avoir été payées

- La première D65 doit avoir été servie

Lorsque le compteur des semaines payées est consulté, l’agent y verra 17 lorsque la deuxième série de D65 sera imposée.  Cependant, s’il doit fournir des explications au client, l’agent doit comprendre que la D65 est imposée pour les semaines 20 et 21 (17 semaines payées + 2 semaines de la D65).

**Comment l’inadmissibilité D65 sera-t-elle communiquée aux clients?**

La communication avec les clients comprendra des courriels et des messages téléphoniques.

**Est-ce que la D65 est imposée sur les demandes où le client a reçu de l’agent de l’ARC?**

Non. Toutes les D65 précédemment imposés sur les demandes où les clients avaient reçu le paiement initial de 2 000 $ de l'ARC ont été annulés.

**Le champ PCU (ARC) est-il mis à jour lorsque le client rembourse l'argent versé?**

Non. Pour le moment, même si le client rembourse l'argent versé par l'ARC, le champ PCU (ARC) ne sera pas mis à jour avec les nouvelles informations. C'est pourquoi la D65 n'est plus imposée pour ces demandes.

**Est-ce que les clients, qui étaient en congé de maternité ou parental immédiatement avant le début de la pandémie, sont considérés avoir perdu leur emploi à cause de la COVID-19 s’ils ne peuvent pas reprendre le travail?**

Oui. Les clients sont considérés avoir cessé de travailler en raison de la COVID-19 s’ils ne peuvent pas reprendre leur travail en raison de la COVID-19 suite à leur congé de maternité ou congé parental. Ces clients devraient déposer une demande auprès de la PCU, cependant si le client a déposé une demande de prestation d’AE d’urgence et rencontre les critères d’admissibilité à la PCU, la demande de prestation d’AE d’urgence sera acceptée.

**Après le dernier paiement de la prestation d’AE d’urgence**

**Un client doit-il soumettre une nouvelle demande d’AE ou appeler Service Canada après avoir reçu 28 semaines de prestation d’AE d’urgence?**

Non. Les clients ne doivent pas présenter une nouvelle demande d’AE. Service Canada utilisera la demande qui a été présentée pour déterminer l’admissibilité à une nouvelle demande d’AE. Service Canada communiquera avec les clients si des renseignements supplémentaires sont nécessaires pour traiter leurs demandes d’AE.

**Un client doit-il soumettre une nouvelle demande d’AE ou appeler Service Canada après avoir reçu 28 semaines de la PCU?**

Oui. Les clients doivent présenter une demande de prestations d’AE pour déterminer leur admissibilité. Il est important que les clients ne présentent pas de demandes d’AE avant d’avoir atteint la fin de leurs 28 semaines de paiement de la PCU. Cela permettra d’éviter les paiements en double et de garantir que leurs demandes d’AE sont établies à partir de la date exacte.

**Prestation canadienne d’urgence pour les étudiants**

**Qu’est-ce que la Prestation canadienne d’urgence pour les étudiants?**

La Prestation canadienne d’urgence pour les étudiants offre un soutien financier aux étudiants de niveau postsecondaire ainsi qu’aux récents diplômés de niveau secondaire et postsecondaire qui ne peuvent pas trouver de travail en raison de la COVID-19.

Cette prestation est destinée aux étudiants qui ne sont pas admissibles à la PCU ou à la Prestation d’urgence de l’AE.

**Quel montant les étudiants peuvent-ils toucher?**

Les étudiants éligibles peuvent recevoir 1250$ pour chaque période de 4 semaines entre mai et août 2020.

Si l'étudiant a un handicap ou des personnes à charge, il peut obtenir un supplément de 750$.

**Est-ce qu’une demande de Prestation d’urgence de l’AE peut être terminée au profit d’une demande de Prestation canadienne d’urgence pour les étudiants?**

Oui. Lorsque le client indique qu’il ne devrait pas recevoir la Prestation d’urgence de l’AE mais bien la Prestation canadienne d’urgence pour les étudiants, l’agent doit déterminer si le client est admissible à la Prestation d’urgence de l’AE.  Si oui, l’agent explique au client qu’il se qualifie et qu’il n ’a pas besoin de déposer une demande auprès de la Prestation canadienne d’urgence pour les étudiants.

Si le client n ’est pas admissible à la Prestation d’urgence de l’AE, l’agent indique au client de contacter l’ARC au 1-800-959-8281. Un processus a été mis en place pour confirmer l’admissibilité à la Prestation canadienne d’urgence pour étudiants et d’établir la demande.  L’agent ne doit prendre aucune mesure pour annuler la demande, mais peut la terminer au moyen d’une transaction M101-7 — Terminer la période de prestations .

**Subvention salariale d’urgence du Canada**

**Qu’est-ce que la Subvention salariale d’urgence du Canada?**

La Subvention salariale d'urgence du Canada (SSUC) est un programme de subvention salariale disponible pour les employeurs qualifiés afin de les aider à payer leurs employés et éviter d'avoir à les licencier.

**Est-ce qu’un employeur devrait inclure la SSUC dans la rémunération lorsqu’il complète un RE?**

Oui. Si l'employé a déjà occupé un emploi assurable, la SSUC doit être inscrite sur le relevé d'emploi avec tous les autres salaires versés par l'employeur.

Les heures associées au montant de la SSUC versée devraient également être inscrites sur le RE.

Si le premier jour payé ou le dernier jour payé tombe dans une période où des montants de la SSUC ont été payés, l'employeur doit inscrire cette date.

En cas de doute sur l'assurabilité de l'emploi, il faut demander une décision d'assurabilité à l'ARC.

**Comment l’employeur devrait attribuer les heures lorsque les employés reçoivent leur salaire habituel, mais ne travaillent pas?**

Lorsque l'employeur paie le salaire normal du client, il doit déclarer, sur le RE, toutes les heures et rémunérations assurables de la même manière que si l'employé travaillait à plein temps.

**Comment l’employeur devrait attribuer les heures lorsque les employés moins que le montant de leur salaire habituel?**

Conformément à l'article 10.1 du RAE, si le seul changement est le salaire, les heures hebdomadaires normales seront déclarées.

Par exemple, si un employeur verse à un employé 75 % de son salaire normal (600$ par semaine au lieu de 800$), mais que son horaire de travail normal de 40 heures par semaine reste inchangé, l’employeur indique 600$ comme rémunération assurable et 40 pour les heures assurables.

**NAS de la série 900**

**Est-ce que les clients ayant un NAS de la série 900 peuvent recevoir des prestations si un permis de travail ou permis d’études valide n’est pas au dossier?**

Oui. Les agents peuvent temporairement accepter une confirmation verbale concernant la validité du permis de travail, du permis d’études ou du statut implicite afin de ne pas retarder l’émission de paiements. Le client doit être aviser de soumettre la preuve le plus rapidement possible. Cette mesure temporaire s’applique autant pour les demandes de prestation d’AE d’urgence et une demande de prestations de l’AE.

L’agent consulte Mise à jour : COVID-19 et permis de travail pour les NAS de la série 900 — Procédures (Niveau 1 et Niveau 2) .
       [Mise à jour : COVID-19 et permis de travail pour les NAS de la série 900 — Procédures (Niveau 1 et Niveau 2)](/fr/site/dossier/updated_covid19_work_permit_900_sin.shtml)

**Que devrait faire les agents qui ont un article ECAL Assurabilité pour un client qui a un NAS de la série 900?**

L’assurabilité de l’emploi d’un client ayant un NAS de la série 900 n’est pas un litige pour les demandes de prestation d’AE d’urgence puisque ces demandes ne sont pas établies sur la base d’heures assurables. Cependant, pour les demandes d’AE, les procédures régulières doivent être suivies.

**Est-ce que les clients qui ont un NAS de la série 900 sont considérés comme étant disponible au travail s’ils ne peuvent pas travailler en raison de la COVID-19?**

Oui. Alors que les clients ayant un NAS de la série 900 sont principalement au Canada pour y travailler, le gouvernement du Canada convient qu’il peut être difficile pour les clients de chercher un emploi lors d’une pandémie.

Aucune inadmissibilité ne doit être imposée si le client éprouve de la difficulté à se trouver un travail ou s’il y a des restrictions au permis de travail.

**Disponibilité**

**Est-ce que les clients doivent être activement à la recherche d’un emploi pendant la pandémie de la COVID-19?**

Le gouvernement du Canada convient qu’il peut être difficile pour les clients de chercher un emploi lors d’une pandémie.

Lorsque le client ne peut pas chercher du travail ou obtenir un emploi à cause de la COVID-19, aucune inadmissibilité ne devrait être imposée pour cette raison, que ce soit sur une demande de prestation d’AE d’urgence ou pour une demande de prestations régulières ou de maladie dont le DPP est avant le 15 mars 2020.

**Est-ce que les clients qui éprouvent de la difficulté au niveau de la garde de leurs enfants en raison de la COVID-19 sont considérés comme disponibles?**

Oui. Le gouvernement du Canada convient qu’il est essentiel pour les parents de prendre soin de leurs enfants qui ne peuvent plus fréquenter les services de garde ou les écoles en raison de la pandémie de la COVID-19.

Aucune inadmissibilité ne devrait être imposée pour cette raison, que ce soit sur une demande de prestation d’AE d’urgence ou pour une demande de prestations régulières ou de maladie dont le DPP est avant le 15 mars 2020.

**Est-ce qu’un cours de formation est considéré comme étant une situation litigieuse pour une demande de prestation d’AE d’urgence?**

Non. Puisque les écoles sont fermées en raison de la pandémie de la COVID-19, les cours de formation ne sont pas considérés comme une situation litigieuse.

Aucune inadmissibilité ne devrait être imposée pour cette raison, que ce soit sur une demande de prestation d’AE d’urgence ou pour une demande de prestations régulières ou de maladie dont le DPP est avant le 15 mars 2020.

**Est-ce qu’un agent peut terminer une inadmissibilité 3-Non disponible (D03) sur une demande dont le DPP est avant le 15 mars 2020, si le cours de formation du client s’est terminé en raison de la COVID-19?**

Oui. Un client dont le cours de formation est suspendu pour une période indéterminée en raison de la pandémie ne devrait pas se voir refuser le droit aux prestations sur le seul fait qu’il allait à l’école avant l’arrêt. L’inadmissibilité 3- Non disponible (D03) peut donc être terminée à la date où le cours a pris fin.

**Déclaration du prestataire**

**Est-ce que les clients dont la demande a été établie en tant que prestation d’AE d’urgence doivent faire leurs déclarations du prestataire?**

Oui, les clients doivent compléter leurs déclarations du prestataire toutes les 2 semaines comme d’habitude.

Puisque plusieurs clients ont déposé une demande de prestations d’AE pour la première fois, ils peuvent ignorer qu’ils doivent compléter des déclarations du prestataire. Un courriel leur est envoyé afin de leur rappeler qu’il est nécessaire de compléter des déclarations du prestataire pour recevoir des paiements. Ces courriels sont envoyés aux clients qui ont fourni une adresse courriel dans leur demande. Des appels sont aussi effectués par des agents qui sont responsables de compléter les DP lorsque le client est rejoint.

**Comment les renseignements déclarés sur la déclaration du prestataire sont-ils traités par le système?**

Si un client déclare des revenus, des jours non disponibles, de la formation ou des jours de maladie, le système ne tient pas compte de ces renseignements quand il détermine si le client est admissible à la Prestations d’urgence de l’AE.

Si un client déclare avoir trouvé du travail ou déclare une semaine entière de travail, le système tient compte de ces renseignements pour déterminer si le client est admissible à la Prestations d’urgence de l’AE.

**Combien de temps les clients ont-ils pour compléter leur déclaration du prestataire?**

Les clients de l’AE ont habituellement 5 semaines pour compléter leurs déclarations du prestataire. Pour les demande identifiées comme une demandes de Prestation canadienne d’urgence, les clients ont 12 semaines pour compléter leurs déclarations du prestataire.

Les déclarations du prestataire initiales pour la période de la PU AE ne peuvent pas être acceptées après le 2 décembre 2020.

**Quelles actions doivent être prises lorsque le client déclare avoir fait une erreur sur une déclaration du prestataire d’une demande de prestation d’AE d’urgence?**

Quand les clients déclarent avoir fait une erreur en complétant leurs déclarations du prestataire, les actions suivantes doit être prises :

- Consulter Modifier une déclaration du prestataire — PU AE .
         [Modifier une déclaration du prestataire — PU AE](/fr/procedure/task/modifying_claimant_report_eierb.shtml)

**Comment le client doit compléter sa DP lorsqu’il a été rappelé au travail mais qu’il est capable d’y retourner?**

Lorsque le client doit compléter sa DP, il doit déclarer s’il était prêt à travailler tous les jours (du lundi au vendredi) et en mesure de le faire pendant chaque semaine inscrite à la déclaration. Le client doit répondre Non s’il est incapable de retourner au travail lorsqu’il est rappelé par son employeur parce que qu’il :

- est malade ou en quarantaine à cause de la COVID-19;

- prend soin de d’autres personnes qui sont en quarantaine ou malades à cause de la COVID-19;

- prend soin d’enfants ou de d’autres personnes à charge dont l’établissement de soins est fermé en raison de la COVID-19.

Ces clients seront quand même admissible à la PCU.

**Rémunération**

**Est-ce qu’une répartition de rémunération a un impact sur une demande de prestation d’AE d’urgence?**

Non. Les répartitions de toutes rémunérations n’ont aucun impact sur une demande de prestation d’AE d’urgence.

Si le client contacte Service Canada concernant une répartition qui demeure à son dossier, l’agent peut supprimer la répartition et toute prolongation de la PP applicable si la demande est considérée comme une demande de prestation d’AE d’urgence.

Bien que la rémunération n’est pas répartie, les clients dont la rémunération dépasse 1 000 $ dans les 4 semaines pour lesquelles la PU AE est versée ne sont pas admissibles aux prestations pour cette période.

**Est-ce qu’une lettre de répartition de rémunération doit être envoyée au client qui reçoit la prestation d’AE d’urgence?**

Non. Les répartitions de toutes rémunérations n’ont aucun impact sur une demande de prestation d’AE d’urgence et aucune lettre ne devrait être envoyée.

**Supplément familial**

**Est-ce qu’un client ayant une demande de prestation d’AE d’urgence est admissible au supplément familial?**

Oui. Si admissible, les clients recevront le supplément familial en plus du montant de 500$ par semaine.

**Le supplément familial s'applique-t-il au versement initial de 2 000 $ ?**

Non. Le paiement initial de 2000$ est un montant fixe qui a été versé pour s'assurer que, peu importe si les Canadiens ont demandé de l'aide par l'entremise de l'ARC ou de Service Canada, leur paiement initial sera le même.  Le taux du supplément familial s'applique uniquement aux paiements de la Prestation d’urgence de l’AE effectués lorsque le client complète ses DP.

**Déductions d’impôts et T4**

**Est-ce qu’un client peut demander à ce que des déductions d’impôts soient prélevées des paiements de la prestation d’AE d’urgence?**

Non. Le Gouvernement du Canada a décidé qu’aucune déduction d’impôt ne serait prélevée des paiements de la prestation d’AE d’urgence.

**Est-ce que les clients recevront un T4 s’ils ont reçu un paiement de la PCU?**

Oui. Puisqu’un paiement de la PCU est imposable, les clients peuvent s’attendre à recevoir un T4 pour les paiements reçus de la PCU.

Afin de d’assurer qu’un T4 ne soit pas émis incorrectement, les clients sont invités à repayer tous paiements de la PCU versés en trop avant le 31 décembre 2020. Si, selon sa situation personnelle, un client a besoin de plus de temps pour rembourser, il doit contacter l’ARC le plus rapidement possible afin prendre une entente de remboursement.

**Est-ce que des déductions d’impôts sont perçus sur les paiements de la prestation d’AE d’urgence?**

Non. Les paiements de la prestation d’AE d’urgence sont imposables, mais aucune déduction d’impôt n’est perçue. Cependant des déductions d’impôts seront prélevées sur une demande initialement établie comme une demande de prestations de l’AE. Quand le système converti la demande en prestation d’AE d’urgence, les déductions d’impôts prélevées sur ces semaines ne sont pas remboursées au client.

**Prestations de maternité et la prestation d’AE d’urgence**

**Comment les paiements provenant de la prestation d’AE d’urgence affecteront les clients demandant des prestations de maternité après la période de la prestation d’AE d’urgence?**

Les clients recevant la prestation d’AE d’urgence peuvent convertir leur demande en prestations de maternité quand cela s’applique à leur situation en autant qu’ils remplissent les conditions d’admissibilité pour ce type de prestations.  Il n’y a aucune exigence à l’effet que les 28 semaines de prestation d’AE d’urgence soit entièrement versées.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1071.dita) 

**Est-ce que les paiements de la prestation d’AE d’urgence affectent les semaines d’admissibilité aux prestations de maternité ou parentales?**

Non. Les paiements de la prestation d’AE d’urgence n’affectent pas les semaines d’admissibilité aux prestations de maternité ou parentales.

Les demandes de prestations de maternité ou parentales sont traitées normalement, et cela peu importe que la demande soit établie avant ou après le 15 mars 2020. Les critères d’admissibilités, incluant les heures nécessaires pour se qualifier, demeurent inchangés.

**Est-ce qu’une semaine d’arrivée de placement ou une semaine d’accouchement peut être saisie sur une demande de prestation d’AE d’urgence?**

Non. L’agent obtiendra un message d’erreur C173: Nouveau calcul non valable quand il fera la saisie d’une semaine d’accouchement (SEM ACC) ou une semaine d’arrivée de placement (SAP).  L’agent doit prendre les mesures suivantes :

- Si la SEM ACC ou la SAP est après la période durant laquelle le client peut demander des prestation d’AE d’urgence, l’agent doit créer un AT A Revoir. La Date d’échéance est la semaine avant la SEM ACC ou la SAP.

- Si la SEM ACC ou la SAP est pendant la période durant laquelle le client peut demander des prestation d’AE d’urgence, l’agent consulter Convertir des demandes de Prestation d’urgence de l’AE en prestations de maternité .
         [Convertir des demandes de Prestation d’urgence de l’AE en prestations de maternité](/fr/procedure/task/covid19_converting_eierbcmb.shtml)

**Est-ce qu’il y a une équipe spécialisée qui s’occupe du traitement des demandes de prestations de maternité après que la cliente est reçue la Prestation d’urgence de l’AE?**

Oui. Une équipe spécialisée de la région de l’Ouest est responsable des conversions. Lorsqu’une demande doit être convertie à des prestations de maternité, l’agent ne complète pas l’AT et ne fait pas la conversion. L’agent réassigne l’AT le dossier de la façon suivante :

- S’il y a un RSDP en ébauche, l’AT est réassigné à l’agent directement.

- S’il n’y a pas de RSDP en ébauche, l’AT est réassigné de la façon suivante :

- Destination – Niveau

- Serv de trait & paiement nat

- Traitement spécialisé AE – OT

- Changement législatif – OT

- DEREMPA – OT

- Complexité : Niveau 1

- Raison : Autre

- Détails : Saisir « Conversion PU AE vers prestations de maternité. »

**Est-ce que la PR est prolongée lorsque la cliente demande des prestations de maternité après avoir reçu des paiements de la prestation d’AE d’urgence?**

Oui. Afin de prendre en compte la période de PU AE ou PCU, la PR est prolongée:

- de 16 semaines si le DPP pour la nouvelle demande est avant le 5 juillet 2020.

- de 24 semaines si le DPP pour la nouvelle demande est entre le 5 juillet 2020 et le 23 août 2020.

- de 28 semaines si le DPP pour la nouvelle demande est le ou après le 30 août 2020.

**Hors Canada**

**Est-ce qu’une inadmissibilité doit être imposée pour une situation de hors Canada sur une demande de prestation d’AE d’urgence?**

Non. Les clients résidants du Canada peuvent être temporairement incapable de retourner au pays en raison de la COVID-19.

Si les clients ayant une demande de prestation d’AE d’urgence sont dans cette situation, les renseignements doivent être consignés dans le dossier, mais aucune inadmissibilité ne doit être imposée.

**Trop payé et paiements en double**

**Est-ce que les clients devront rembourser le trop-payé qui a été créé lorsque leur demande a été recalculée comme une demande de prestation d’AE d’urgence (le taux de prestations était de 573$ est maintenant de 500$)?**

Non. Les trop-payés (TP) créés sur les demandes dont le taux de prestations était initialement supérieur à 500$ sont défalqués. Cependant, les TP demeurent visibles dans ETI, mais il n’y a aucun solde recouvrable.

**Selon quelles circonstances est-ce qu’un client pourrait se voir demander de repayer des paiements reçus de l’ARC pour la PCU?**

Les clients pourraient devoir retourner ou repayer un paiement de PCU s’ils ont :

- retournés travailler plus tôt que prévu, ce qui inclus avoir été payé rétroactivement

- appliqués pour la PCU mais ont réaliser plus tard qu’ils n’étaient pas admissible

- reçus des paiements de la PCU et de la prestation d’AE d’urgence pour la même période

**Est-ce qu’un client peut repayer ou retourner un paiement de la PCU directement à l’ARC?**

Oui. Un client peut retourner ou repayer un paiement de la PCU à l’ARC. Les instructions sur la façon de procéder se trouver ici .
       [ici](https://www.canada.ca/fr/agence-revenu/services/prestations/faire-demande-pcu-aupres-arc.html)

**Est-ce que le client peut repayer ou retourner un paiement de la PCU à Service Canada?**

Oui. Le client qui choisit de repayer ou retourner un paiement de la PCU à Service Canada doit suivre les instructions suivantes :

- Si le client est toujours en possession du chèque, il peut le retourner par la poste à l’adresse suivante:
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1072.dita)

- Si le client a reçu le paiement par dépôt direct ou si le chèque a été encaissé, le client peut payer son compte d’une des deux façons suivantes:

- À leur institution financière

- Chèque ou mandat-poste

- Envoyer leur paiement par chèque ou mandat-poste

- Effectuer le paiement à l’ordre du “Receveur général du Canada”

- Inscrire leur NAS sur le devant du chèque ou du mandat-poste et indiquer que c’est pour le “Remboursement de la PCU”

- Envoyer le chèque ou mandat-poste à l’adresse suivante:
                 [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1072.dita)

Les clients ne doivent pas envoyer d’argent comptant par la poste.

**Comment le client peut-il choisir de repayer un retourner un paiement de la prestation d’AE d’urgence à Service Canada?**

Si le client a encore le chèque original, il peut le retourner à l’adresse ici-bas. Si le client n’a plus le chèque, qu’il l’a déposé ou que le paiement a été reçu par dépôt direct, le client peut transmettre son paiement selon l’une des trois méthodes suivantes :

- Services bancaires en ligne

- Le client doit sélectionner « Emploi et Développement Social Canada » si cette option est disponible sur le site Web de leur institution bancaire.

- Le client doit saisir les 9 chiffres de leur Numéro d’assurance sociale (NAS). Si leur institution financière requière 11 caractères, le client doit ajouter « YY » ou « 00 » à la fin de leur NAS.

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1073.dita)

- À leur institution financière

- Le client soit inscrire son NAS sur le chèque ou mandat et indiquer qu’il s’agit du « remboursement de la PCU ».

- Par la poste

- Le client doit faire parvenir leur paiement par chèque ou mandat à l’ordre du « Receveur général du Canada », inscrire leur NAS et l’envoyer à l’adresse suivante :
             [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1074.dita)

**Postdates et antidates**

**Est-ce qu’une demande de prestations régulières ou de maladie peut être postdatée au 15 mars 2020 afin d’être établie comme une demande de prestation d’AE d’urgence?**

Seule une demande de prestations régulières ou de maladie ayant un DPP provisoire au 8 mars 2020 peut être postdatée au 15 mars 2020.

De nouveaux arrêtés provisoires continuent d’être signés de façon régulière. Ces nouveaux arrêtés peuvent entraîner des demandes d’antidate, en particulier ceux qui sont rétroactifs au 15 mars 2020. On considère qu’il y a un motif valable de retard dans la présentation d’une demande à partir de la date de signature de l’arrêté provisoire approprié jusqu’au 15 mars 2020. Le client doit demander la postdate.

**Est-ce qu’un client peut demander une antidate de sa demande de prestation d’AE d’urgence?**

Oui. Une demande de prestation d’AE d’urgence peut débuter dès le 15 mars 2020, et les clients peuvent présenter une demande pour la prestation d’AE d’urgence jusqu’au 2 décembre 2020.

Un client qui tarde à présenter une demande de prestation d’AE d’urgence, mais qui veut que sa demande commence à une date antérieure, peut demander une antidate afin que le DPP soit le ou après le 15 mars 2020.

Puisque les clients demandant la prestation d’AE d’urgence n’ont pas besoin de présenter leur demande dans les délais prescrits, les demandes d’antidates ne s’appliquent donc pas à la prestation d’AE d’urgence.

**Enseignants**

**Est-ce qu’une décision doit être prise sur la question de l’enseignement sur une demande de prestation d’AE d’urgence?**

Non. La question de l’enseignement n’est pas considérée litigieuse pour les demandes de prestation d’AE d’urgence.

Cependant, la question de l’enseignement doit être statuée pour les clients qui désirent toucher des prestations de maternité, parentales, CCB ou de proches aidants et pour les clients qui renouvellent leur demande d’AE après le 15 mars 2020.

**Terminer une demande existante**

**Est-ce qu’un client ayant une demande avec un DPP avant le 15 mars 2020, qui pourrait être renouvelée, peut demander la terminaison de cette demande afin de recevoir la prestation d’AE d’urgence?**

Oui. Selon les procédures habituelles, lors du renouvellement, il peut être à l’avantage du client d’établir une nouvelle période de prestations (PP) au lieu de renouveler la PP existante. Dans tous les cas, si le client demande la terminaison de sa demande dans le but de recevoir la prestation d’AE d’urgence, les avantages et inconvénients doivent être discutés avec le client puisque la décision de terminer la PP est définitive et ne peut être renversée.

Plus spécifiquement, le client pourrait ne pas avoir assez d’heures afin d’établir une nouvelle demande après les 28 semaines de la prestation d’AE d’urgence aient été payées.  Le client doit comprendre que la décision de terminer la demande est définitive et il ne pourra revenir sur sa décision dans l’éventualité où une nouvelle demande ne peut être établie. Si après cette discussion, le client qui le souhaite peut tout de même demande de terminer la demande existante d’AE au profit d’une demande de la prestation d’AE d’urgence si les critères mentionnés dans la note de service Prestation d’AE d’urgence – AP 2020-04 sont rencontrés.
       [Prestation d’AE d’urgence – AP 2020-04](/fr/policy/bememo/be2020-04.shtml)

**Est-ce qu’un client peut demander de terminer une demande de prestation d’AE d’urgence en faveur d’une demande de prestations spéciales de l’AE?**

Non. Pour le moment, une demande de prestation d’AE d’urgence ne peut pas être terminée autre que pour faire établir une demande de prestations de maternité.

L’agent document le dossier et met l’AE en suspens jusqu’au 28 août 2020.  Si l’information sur la façon de convertir la demande n’est pas fournie le 28 août 2020, l’agent met l’AT en suspens pour un autre 5 jours.

**Cours de formation – Cours dirigé et apprenti**

**Est-ce qu’un client ayant une approbation sous la Section 25 peut recevoir des paiements de la prestation d’AE d’urgence?**

Oui. Il n’y a aucune stipulation dans les arrêtés provisoires qui empêche les clients, ayant été dirigés sur un cours de formation ou pour une formation en apprentissage, de recevoir des paiements de la prestation d’AE d’urgence.

**Comment l’autorité désignée peut vérifier si le client reçoit des paiements de la prestation d’AE d’urgence?**

Le module AccèsEDMT ne fait pas la distinction entre une demande de prestation d’AE d’urgence et une demande de prestations d’AE. Cependant, puisque les demandes de prestation d’AE d’urgence ont toutes les mêmes caractéristiques, elles peuvent être identifiées de la façon suivante :

- Début de la période de prestation : entre le 15 mars 2020 et le 27 septembre 2020

- Genre de demande : Régulière

- Nombre de semaines admissibles : 29

- Taux de prestations : 500$ (plus élevé si le client touche le supplément familial)

**Qu’arrive-t-il lorsqu’un client dépose une demande avec un code de référence pour apprenti?**

Toutes les demandes de prestations régulières ou de maladie déposées avec un code de référence et ayant un DPP entre le 15 mars 2020 et le 27 septembre 2020 sont converties en demande de prestation d’AE d’urgence. L’information sur le projet est saisie au système.

**Est-ce que les clients participant à un cours de formation dirigé (incluant les apprentis) sont éligibles aux paiements de la Partie II de la LAE?**

Non. Le processus d'obtention des approbations nécessaires pour que ces clients puissent bénéficier d'une aide en vertu de la partie II de la LAE est actuellement en cours, mais pour l'instant, ils ne sont pas considérés comme admissibles. De plus amples informations à ce sujet seront communiquées une fois qu'elles auront été reçues.

**Est-ce que les sommes reçues pour de l’assistance financière ont un impact sur une demande de prestation d’AE d’urgence?**

Non. Toute aide financière destinée à couvrir les frais de subsistance de base, les frais de garde d'enfants ou de transport ne sont pas considérés comme rémunération pour les clients qui reçoivent la prestation d’AE d’urgence. Les revenus d'emploi reçus dans le cadre d'un programme financé au titre des accords de transfert du marché du travail sont considérés comme des revenus aux fins de la prestation d’AE d'urgence.

**Est-ce que l’information sur le projet peut être saisi sur une demande de prestation d’AE d’urgence?**

Oui. Lorsque la confirmation est reçue à l’effet que le client a été dirigé sur un cours de formation ou comme apprenti, l’information sur le projet doit être saisie.

L’agent consulte Confirmer un cours de formation dirigé : Prestations régulières ou de pêcheur — Demande continue ou Confirmer la formation en apprentissage — Demande continue pour les détails comment saisir l’information sur le projet.
       [Confirmer un cours de formation dirigé : Prestations régulières ou de pêcheur — Demande continue](/fr/procedure/task/training_cc.shtml) 
       [Confirmer la formation en apprentissage — Demande continue](/fr/procedure/task/training_rcc.shtml)

**Est-ce que les clients recevant la prestation d’AE d’urgence qui ont été référés comme apprenti peuvent être exempté de compléter leurs DP?**

Oui. Les clients dirigés vers une formation en apprentissage et recevant la prestation d’AE d’urgence peuvent être exemptés de compléter leurs DP en autant qu’ils complètent la demande d’exemption de remplir des déclarations du prestataire.

**Délai de carence**

**Est-ce que le délai de carence peut être supprimé sur une demande de renouvellement si le délai de carence n’a pas été servi?**

Oui. Si le délai de carence avait été préalablement reporté et que le client demande maintenant le renouvellement de sa demande en prestations de maladie, le délai de carence peut être supprimé si la semaine de renouvellement est le 15 mars 2020 ou après.

**Retirer une demande de la prestation d’AE d’urgence**

**Est-ce qu’un client peut retirer sa demande de prestation d’AE d’urgence?**

Oui. Si la PP n’est pas encore établie, une demande peut être retirée. Quand la demande est retirée, l’agent annule la demande et le système supprime tous les AT en suspens liés à la demande.

**Travail partagé**

**Est-ce qu’un client qui fait partie d’une entente de travail partagé peut toucher la prestation d’AE d’urgence ?**

Non. Un client ayant une demande de prestation de travail partagé ne peut pas toucher la prestation d’AE d’urgence.

**Est-ce qu’un employeur ayant une entente valide de travail partagé peut combiner le travail partagé à la Subvention salariale d’urgence du Canada?**

Oui. Un employeur peut combiner la Subvention salariale d’urgence du Canada (SSUC) à une entente de travail partagé, cependant l’entente de travail partagé réduit le montant de la subvention que l’employeur reçoit de la SSUC.

**Afin de toucher la Subvention salariale d’urgence du Canada, est-ce que l’employeur doit obtenir le montant exact des prestations de l’AE que chaque employé reçoit?**

Oui. Cependant, afin de protéger les renseignements personnels des clients, Service Canada ne partage pas avec l’employeur les montants d’AE versés aux employés. L’employeur devra contacter chaque employé directement afin d’obtenir les renseignements.

**Est-ce qu’un employeur peut terminer une entente de travail partagé afin d’obtenir la Subvention salariale d’urgence du Canada?**

Oui. L’employeur qui le désire peut mettre fin à l’entente de travail partagé à n’importe quel moment.  Après avoir reçu la SSUC, l’employeur pourra ensuite soumettre une nouvelle entente de travail partagé. 

### Warning

Source topic: `fr_FR/common_notes/note_c_1066.dita`

Mise à jour : 2020-12-03 — Les nouveaux renseignements sont en surbrillance. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_1067.dita`

Remarque :

À partir du lundi 22 juin 2020, le paiement forfaitaire anticipé de 2 000 $ a été arrêté. Les nouveaux clients qui présentent une demande pour la prestation d’AE d’urgence recevront des prestations quand ils rempliront leurs déclarations du prestataire. Une inadmissibilité D65 ne sera pas imposée dans ces demandes. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_1068.dita`

Remarque :

Les clients qui sont pêcheurs, travailleur frontalier, inter-état ou outre-mer, qui ont un dernier jour de travail avant le 21 juin 2019, qui ont fourni un code de référence autre que pour le Travail partagé (TP) ou les clientes enceintes peuvent se qualifier pour la prestation d’AE d’urgence. L’agent doit déterminer si le client se qualifie pour la prestation d’AE d’urgence. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_1069.dita`

Remarque :

Pour les clients ayant un NAS de la série 900, l’agent ne doit pas annuler l’inadmissibilité D3 ou D15 tant qu’une confirmation n’ est pas obtenue quant à la validité du permis de travail ou du permis d’études. Consulter Mise à jour : COVID-19 et permis de travail pour les NAS de la série 900 — Procédures (Niveau 1 et Niveau 2) .
       [Mise à jour : COVID-19 et permis de travail pour les NAS de la série 900 — Procédures (Niveau 1 et Niveau 2)](/fr/site/dossier/updated_covid19_work_permit_900_sin.shtml)

     [Mise à jour : COVID-19 et permis de travail pour les NAS de la série 900 — Procédures (Niveau 1 et Niveau 2)](/fr/site/dossier/updated_covid19_work_permit_900_sin.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_1070.dita`

Remarque :

Si l’agent ne peut pas entrer en contact avec le client, l’agent ne devrait pas établir la demande de Prestation d’urgence de l’AE. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_1071.dita`

Remarque :

Pour le moment, seules les clientes demandant des prestations de maternité peuvent demander la terminaison de leur demande de prestation d’AE d’urgence. L’agent consulte Convertir des demandes de Prestation d’urgence de l’AE en prestations de maternité pour les détails sur la façon de convertir la demande.
       [Convertir des demandes de Prestation d’urgence de l’AE en prestations de maternité](/fr/procedure/task/covid19_converting_eierbcmb.shtml)

     [Convertir des demandes de Prestation d’urgence de l’AE en prestations de maternité](/fr/procedure/task/covid19_converting_eierbcmb.shtml) 

### Callout

Source topic: `fr_FR/common_notes/note_c_1072.dita`

Remises EDSC CP 1122 Matane QC G4W 4S7 

### Remarque

Source topic: `fr_FR/common_notes/note_c_1073.dita`

Remarque :

Puisque chaque institution bancaire est différente, le client doit utiliser son NAS avec les lettres « YY » à la fin, cependant, si les lettres ne sont pas acceptées par le système, le client peut ajouter « 00 ». 

### Callout

Source topic: `fr_FR/common_notes/note_c_1074.dita`

Adresse postale Remises EDSC CP 1122 Matane QC G4W 4S7 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/information_covid19_processing_information/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
