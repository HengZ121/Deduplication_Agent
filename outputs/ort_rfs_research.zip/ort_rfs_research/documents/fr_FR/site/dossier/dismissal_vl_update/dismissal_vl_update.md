# Mise à jour des procédures relatives au congédiement et au départ volontaire.

Source map: `fr_FR/site/dossier/dismissal_vl_update/dismissal_vl_update.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/dismissal_vl_update/sommaire.dita`

Les procédures pour rendre une décision sur un congédiement et un départ volontaire ont été mises à jour dans le but de régler les questions soulevées depuis la mise en œuvre des Solutions d’affaires de l’assurance-emploi du mois de novembre 2015. Des changements et des corrections supplémentaires ont été apportés dans le cadre des efforts continus visant à tenir compte des commentaires reçus et d’améliorer le contenu de l’Outil de référence en ligne de l’AE. 

## Generic

Source topic: `fr_FR/site/dossier/dismissal_vl_update/generic.dita`

Le contenu suivant a été ajouté aux procédures en question :

**Emploi non assurable :**

- L’agent doit rendre une décision sur le motif de cessation d’un emploi qui n’est pas assurable en raison d’une question de lien de dépendance.

- L’agent n’ a pas besoin de rendre une décision sur un congédiement ou une suspension d’un emploi qui n’est pas assurable car le client est embauché en vertu d’un contrat de service ou car le client détient plus de 40 % des actions de l’entreprise. En ce qui concerne les demandes initiales et de renouvellement, les procédures expliquent comment compléter l’AT Litige - Décision (DEC).

**Le motif de cessation d’emploi (MCE) a eu lieu avant la période de référence :**

- Si les faits au dossier indiquent clairement que le MCE a eu lieu avant la période de référence, l’agent de Niveau 2 doit modifier le niveau de complexité de l’AT DEC dans les demandes initiales ou de renouvellement, de sorte que les écrans Résoudre le problème appropriés s’affichent.

**Retraite obligatoire :**

- La législation canadienne sur les droits de la personne interdit la retraite obligatoire. Cette législation couvre la majorité des emplois. Sauf pour de rares exceptions, les employeurs ne peuvent pas démontrer qu’il y a une véritable raison pour expliquer la retraite obligatoire. Une retraite obligatoire ne peut être considérée comme un départ volontaire puisque c’est l’employeur, et non le client, qui a amorcé la cessation d’emploi. Un agent de Niveau 2 doit rendre une décision sur la retraite obligatoire en tant que congédiement.

**Le client souhaite que l’on ne communique pas avec l’employeur :**

- Si le client souhaite que l’on ne communique pas avec l’employeur afin de recueillir des faits, l’agent doit aviser le client quand c’est exigé par la loi. Si le client insiste pour que l’on ne communique pas avec employeur, l’agent doit lui informer que la seule solution est de retirer sa demande de prestations. L’agent doit ensuite consigner les renseignements pertinents au dossier.

**Inconduite des cheminots :**

- Lorsqu’il doit rendre une décision sur un cas d’inconduite d’un cheminot, l’agent doit demander une copie de la transcription d’audience ainsi que tous autres dossiers contenant des preuves concernant la cessation d’emploi. Un cas d’inconduite d’un cheminot peut uniquement être prouvé lorsque l’agent est en mesure d’obtenir la transcription d’audience, ou lorsque le client a fourni suffisamment de renseignements concernant l’infraction du règlement des chemins de fer pour que l’inconduite puisse être prouvée sans la transcription d’audience.

Des précisions et des corrections supplémentaires ont été apportées. Veuillez consulter la description des changements fournie dans le tableau ci-dessous ainsi que les procédures qui s’y appliquent.

Les sections connexes du Manuel des prestations seront bientôt archivées. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/dismissal_vl_update/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
