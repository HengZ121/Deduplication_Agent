# Report de décision — Mise à jour

Source map: `fr_FR/site/dossier/deferral_adj_updates/deferral_adj_updates.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/deferral_adj_updates/sommaire.dita`

Dans le cadre de nos efforts visant à mettre à jour le contenu de l’ORL AE, toutes les procédures de l’activité Report de décision ont été mises à jour selon les commentaires des régions. 

## Generic

Source topic: `fr_FR/site/dossier/deferral_adj_updates/generic.dita`

Chacune des tâches de l’activité Report de décision ont été mises à jour. Voici une liste des principales modifications :

- Le report de décision est maintenant possible pour toute question liée à une décision, si le client a accumulé moins de 420 heures dans la période de référence (PR) et demande des prestations régulières ou de maladie.

- Le report de décision est maintenant possible pour un MCE litigieux survenu avant l’événement entraînant une exclusion indéfinie quand le client est admissible à des prestations spéciales.

- Le report de décision est maintenant possible pour un MCE litigieux si une exclusion indéfinie a été imposée à la suite d’une décision rendue ou d’un report dans la demande initiale.

- La décision sur une demande d’antidate ne peut jamais être reportée. Une décision doit être rendue sur toute demande d’antidate, même si la demande entraîne un PPNE 1 ou 5. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/deferral_adj_updates/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
