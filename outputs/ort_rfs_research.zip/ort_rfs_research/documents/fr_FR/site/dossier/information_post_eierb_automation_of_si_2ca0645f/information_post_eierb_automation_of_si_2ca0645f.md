# Renseignements : Post-prestation d’AE d’urgence et automatisation des prestations de maladie

Source map: `fr_FR/site/dossier/information_post_eierb_automation_of_si_2ca0645f/information_post_eierb_automation_of_si_2ca0645f.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/information_post_eierb_automation_of_si_2ca0645f/sommaire.dita`

À partir du 16 octobre 2020, le CAC a été programmé pour saisir une date de guérison dans les demandes de prestations de maladie, peu importe le motif de cessation d’emploi (MCE). 

## Generic

Source topic: `fr_FR/site/dossier/information_post_eierb_automation_of_si_2ca0645f/generic.dita`

[Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_1100.dita) 

Pour faciliter l’automatisation, CAC saisira les dates de guérison et ne se déclenchera plus dans les demandes de prestations de maladie, peu importe le MCE. Ceci correspond à la suspension du besoin de soumettre le certificat médical, comme indiqué dans la note de service AP 2020-5, ainsi que la possibilité qu’un client déclare 15 semaines de maladie occasionnelle.

La logique actuelle qui guide CAC qui s’applique aux demandes de prestations de maladie avec un MCE D - Maladie s’applique maintenant à toutes les demandes de prestations de maladie. La date de guérison pour les demandes initiales de prestations de maladie correspondra à la DPP + 15, ou la DPP + 8 si la demande est combinée à des prestations de maternité. Cette logique s’applique aux demandes dont le DPP est entre le 27 septembre 2020 (s/c 2258) et le 6 juin 2021 (s/c 2294). 

### Remarque

Source topic: `fr_FR/common_notes/note_c_1100.dita`

Remarque :

Cette page de Mises à jour et nouvelles a été mise à jour le 16 octobre 2020. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/information_post_eierb_automation_of_si_2ca0645f/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
