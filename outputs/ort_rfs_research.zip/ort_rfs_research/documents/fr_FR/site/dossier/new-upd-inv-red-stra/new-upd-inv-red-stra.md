# Nouveauté et mise à jour : Décision non requise dans la période de prestations pour les nouveaux calculs PPNE — Procédures et ressource additionnelle (Niveau 1 et Niveau 2)

Source map: `fr_FR/site/dossier/new-upd-inv-red-stra/new-upd-inv-red-stra.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/new-upd-inv-red-stra/sommaire.dita`

À compter de maintenant, un AT Révision de la demande (RVD) Révisée pourrait ne plus être requis pour un motif de cessation d’emploi (MCE) litigieux dans la période de prestations (PP) pour une demande PPNE établie au moyen d’un nouveau calcul si des conditions précises sont remplies. 

## Generic

Source topic: `fr_FR/site/dossier/new-upd-inv-red-stra/generic.dita`

L’équipe de la Stratégie de stabilisation des inventaires met en œuvre une stratégie pour les demandes révisées sur les questions liées à un MCE litigieux dans la PP pour un nouveau calcul PPNE.

La ressource additionnelle Calculer à nouveau et établir des demandes PPNE : Litige en attente de traitement dans la période de prestations — Instructions a été créée pour fournir les conditions précises qu’une demande doit remplir pour que l’agent traite le nouveau calcul PPNE sans rendre de décision sur un MCE litigieux dans la PP.
       [Calculer à nouveau et établir des demandes PPNE : Litige en attente de traitement dans la période de prestations — Instructions](/fr/procedure/generic/additionalresources/recalc-esta-bpne-claim.shtml)

L’agent ne crée pas un AT RVD ou un rapport de décision (RD) si :

- La date de l’événement lié au MCE litigieux est dans la PP.

- Une des conditions suivantes est remplie :

- Le client ne demande pas de prestations à partir de la semaine du MCE litigieux.

- Le client n’ est pas admissible aux prestations régulières à partir du DPP en raison d’une décision sur un MCE litigieux.

Si un AT lié au MCE litigieux est déjà créé, demander au chef d’équipe d’annuler l’AT RVD Révisée.

Si les conditions ne sont pas remplies pour ne pas considérer le MCE litigieux dans la PP pour un nouveau calcul PPNE, l’agent traite le nouveau calcul selon les directives ci-dessous. Si la décision ne peut pas être rendue au Niveau 1, l’agent impose un traitement manuel 75 - Vérification du motif de cessation d’emploi (TM75) pour arrêter les paiements jusqu’à ce qu’un agent de Niveau 2 examine le dossier.

Si un nouveau calcul PPNE remplit ces conditions, l’agent effectue le nouveau calcul selon les directives suivantes :

- Créer un AT RVD pour le MCE litigieux.

- Compléter l’AT RVD Nouveau calcul PPNE.

L’agent ne déplace pas l’AT RVD Nouveau calcul PPNE vers En suspens en attendant la décision. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/new-upd-inv-red-stra/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
