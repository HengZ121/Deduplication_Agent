# Nouveauté : Cas d’Intégrité : Examen des demandes pour la PU AE quand le client a reçu une rémunération pendant la période de la PU AE — Tâche (Niveau 2)

Source map: `fr_FR/site/dossier/new-ic-rev-eierb-c-i/new-ic-rev-eierb-c-i.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/new-ic-rev-eierb-c-i/sommaire.dita`

De nouvelles procédures ont été ajoutées à l’activité Cas d’Intégrité pour appuyer Intégrité dans l’examen de l’admissibilité des clients à la PU AE reçue quand ils ont eu une rémunération pendant la période de la PU AE. Ces procédures s’appliquent seulement aux agents de Niveau 2 qui font partie de l’équipe traitant les cas d’admissibilité à la PU AE d’Intégrité. 

## Generic

Source topic: `fr_FR/site/dossier/new-ic-rev-eierb-c-i/generic.dita`

L’agent de Niveau 2 reçoit un AT Révision de la demande (RVD) Intégrité - PCU Motif de cessation pour traiter ces cas. L’agent examine chaque période de 2 semaines de la PU AE pour déterminer si le client est admissible aux prestations versées. D’abord, l’agent détermine si le client a eu 7 jours consécutifs sans travail et sans rémunération au cours de la période de la PU AE de 2 semaines examinée. Si oui, le client reste admissible aux prestations payées pour ces 2 semaines. Si non, l’agent détermine si la rémunération du client dépasse 1 000 $ dans une période de 4 semaines.

Si la rémunération du client dépasse 1 000 $ dans une période de 4 semaines, l’agent impose une inadmissibilité 47 - PU AE - Rémunération supérieure à la limite pour une période de 4 semaines (D47) seulement pour la période de la PU AE de 2 semaines examinée. Pour imposer l’inadmissibilité, l’agent consulte la nouvelle tâche sur l’application d’une décision. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/new-ic-rev-eierb-c-i/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
