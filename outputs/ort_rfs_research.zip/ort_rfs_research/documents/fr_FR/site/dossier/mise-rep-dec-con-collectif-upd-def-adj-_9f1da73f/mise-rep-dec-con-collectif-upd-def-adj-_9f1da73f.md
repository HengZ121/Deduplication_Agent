# Mise à jour : Report de la décision sur un conflit collectif — Procédures (Niveau 1 et Niveau 2)

Source map: `fr_FR/site/dossier/mise-rep-dec-con-collectif-upd-def-adj-_9f1da73f/mise-rep-dec-con-collectif-upd-def-adj-_9f1da73f.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/mise-rep-dec-con-collectif-upd-def-adj-_9f1da73f/sommaire.dita`

Selon les directives de la division de la politique opérationnelle de l’AE et la rétroaction des régions, les procédures ont été mises à jour pour clarifier que le motif de cessation d’emploi (MCE) pour une grève ou un lockout (conflit collectif) peut être reporté seulement si la demande est ou sera PPNE. Si la demande est ou peut être établie, le report de la décision est impossible. 

## Generic

Source topic: `fr_FR/site/dossier/mise-rep-dec-con-collectif-upd-def-adj-_9f1da73f/generic.dita`

En cas de conflit collectif, l’agent doit rendre une décision dans les demandes pour tous les genres de prestations (GP), sauf si la demande ne peut pas être établie. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/mise-rep-dec-con-collectif-upd-def-adj-_9f1da73f/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Item | Description | Portée |
``` 
