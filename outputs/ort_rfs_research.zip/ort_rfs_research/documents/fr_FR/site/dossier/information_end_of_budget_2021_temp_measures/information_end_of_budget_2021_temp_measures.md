# Renseignements : Fin des mesures temporaires du budget 2021

Source map: `fr_FR/site/dossier/information_end_of_budget_2021_temp_measures/information_end_of_budget_2021_temp_measures.ditamap`

## Sommaire

Source topic: `fr_FR/site/dossier/information_end_of_budget_2021_temp_measures/sommaire.dita`

Les modifications législatives et réglementaires qui ont été mises en œuvre pour les demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361) se terminent le 24 septembre 2022. 

## Generic

Source topic: `fr_FR/site/dossier/information_end_of_budget_2021_temp_measures/generic.dita`

Le gouvernement du Canada a mis en œuvre la Loi no 1 d’exécution du budget de 2021 , soit le projet de loi C-30, qui modifiait la législation pour simplifier et élargir l’accès aux prestations d’AE pour une période d’un an. Le projet de loi C-30 prévoyait aussi le retour à la législation antérieure à la pandémie à la fin de ces mesures temporaires. De même, les mesures temporaires sur les normes d’admissibilité, les indemnités de cessation d’emploi et les motifs de cessation d’emploi (MCE) se terminent le 24 septembre 2022. L’incidence de la fin de ces mesures temporaires sur les procédures connexes est la suivante :

**Normes d’admissibilité**

Dans le cadre du budget 2021, une norme d’admissibilité commune (NAC) de 420 heures était requise pour établir une demande de prestations régulières ou spéciales quand le DPP était entre la s/c 2310 et la s/c 2361.

Avec la fin de cette mesure temporaire le 24 septembre 2022, les demandes ne seront plus établies selon la NAC. Les normes d’admissibilité pour les demandes dont le DPP est la s/c 2362 ou après sont les suivantes :

- Prestations régulières : La norme variable d’admissibilité (NVA) de la région économique du lieu de résidence habituel du client dans la semaine du DPP est utilisée pour déterminer le nombre d’heures requis pour établir une demande. La NVA est fixée selon le taux régional de chômage (TRC) et exige que le client ait travaillé entre 420 et 700 heures d’emploi assurable dans sa période de référence (PR).

- Prestations spéciales :

- Prestations de maladie : Le client doit remplir l’une des conditions suivantes :

- Le client est de première catégorie (c.-à-d. il a accumulé au moins 600 heures d’emploi assurable dans sa PR).

- Le client est de deuxième catégorie (c.-à-d. il a accumulé moins de 600 heures d’emploi assurable dans sa PR), remplit les conditions de la NVA et son MCE n ’est pas une maladie, une blessure ou une mise en quarantaine.

- Prestations spéciales autres que maladie : Le client doit être de première catégorie (c.-à-d. il a accumulé au moins 600 heures d’emploi assurable dans sa PR).

- Prestations de pêcheur : Quand le pêcheur ne remplit pas les conditions requises pour recevoir des prestations régulières ou spéciales, une demande de pêcheur peut être établie. Le montant de rémunération provenant de la pêche qui est requis pour établir une demande varie selon le TRC de la région où habite le client. La NVA est entre 2 500 $ et 4 200 $ de rémunération assurable provenant de la pêche dans la PR.

- Prestations de maladie : Le pêcheur doit remplir l’une des conditions suivantes :

- Le pêcheur est de première catégorie (c.-à-d. il a accumulé au moins 3 760 $ de rémunération assurable provenant de la pêche dans sa PR).

- Le pêcheur est de deuxième catégorie (c.-à-d. il a accumulé moins de 3 760 $ de rémunération assurable provenant de la pêche dans sa PR), remplit les conditions de la NVA et son MCE n ’est pas une maladie, une blessure ou une mise en quarantaine.

- Prestations spéciales autres que maladie : Le pêcheur doit être de première catégorie (c.-à-d. il a accumulé au moins 3 760 $ de rémunération assurable provenant de la pêche dans sa PR).

- Prestations spéciales pour les travailleurs indépendants : Pour les demandes dont le DPP est entre le 2 janvier 2022 (s/c 2324) et le 18 septembre 2022 (s/c 2361), le client doit avoir un minimum de 5 289 $ de rémunération nette provenant d’un travail indépendant (TI) pour l’année 2021. Toutefois, pour les demandes dont le DPP est entre le 25 septembre 2022 (s/c 2362) et le 25 décembre 2022 (s/c 2375), le montant minimal pour remplir les conditions requises est de 8 092 $ de rémunération nette provenant d’un travail indépendant (TI) pour l’année 2021. En raison de limites de SIP, il ne peut pas y avoir 2 montants minimum pour remplir les conditions requises dans une seule année civile. Par conséquent, une intervention du COPA peut être requise pour calculer ou calculer à nouveau la demande. Un RSDP est créé au dossier des clients touchés, et les agents du Centre de spécialisation ou du COPA traitent les demandes dans SMP ou SIP.

Pour tous les genres de prestations (GP), s’il y a une violation au dossier du client, la majoration des conditions requises peut s’appliquer. L’agent doit s’assurer que toutes les conditions d’admissibilité et les conditions requises sont remplies pour le GP demandé.

**Majoration des conditions requises**

Quand il y a une violation au dossier, une majoration des conditions requises s’applique pour les prestations régulières et spéciales. Pour les demandes dont le DPP est entre la s/c 2310 et la s/c 2361 quand la NAC était en vigueur, la majoration des conditions requises est la suivante :

- 1 - Violation mineure = 525 heures ou 3 200 $ de rémunération provenant de la pêche

- 2 - Violation grave = 630 heures ou 3 800 $ de rémunération provenant de la pêche

- 3 - Violation très grave = 735 heures ou 4 350 $ de rémunération provenant de la pêche

- 4 - Violation subséquente = 840 heures ou 5 100 $ de rémunération provenant de la pêche

Toutefois, à partir du 25 septembre 2022, la majoration des conditions requises dépend de nouveau du TRC et de la catégorie de la violation, comme indiqué dans Violation : Incidence sur le calcul des demandes de prestations régulières et de pêcheur (majoration des conditions requises) — Tableau .
       [Violation : Incidence sur le calcul des demandes de prestations régulières et de pêcheur (majoration des conditions requises) — Tableau](/fr/procedure/generic/additionalresources/increased_entrance_requirements.shtml)

**Incidence de la fin des mesures temporaires sur les inadmissibilités**

Un client dont la demande a un DPP entre la s/c 2310 et la s/c 2361 et a été établie avec 420 heures d’emploi assurable ou plus remplit les conditions requises pour recevoir des prestations. Par conséquent, les inadmissibilités pour un client de deuxième catégorie qui n’avait pas assez d’heures pour remplir les conditions requises pour recevoir des prestations spéciales n’étaient pas imposées puisqu’elles ne s’appliquaient pas.

À partir du 25 septembre 2022, les inadmissibilités suivantes seront à nouveau générées automatiquement pendant le calcul de la demande selon le nombre d’heures d’emploi assurable :

- inadmissibilité 2 - 2ième catégorie, arrêt de rémunération maladie (D2)

- inadmissibilité 25 - Prestations Maternité - Deuxième catégorie (D25)

- inadmissibilité 35 - Prestations parentales conditions de qualification non rencontrées (D35)

- inadmissibilité 51 - Ne rencontre pas les conditions d’admissibilité de prestations de soins de compassion (D51)

- inadmissibilité 61 - Proches aidants d’enfants ou d’adultes - Ne rencontre pas les conditions d’admissibilité (D61)

Un agent pourrait devoir imposer manuellement l’une des inadmissibilités énumérées ci-dessus quand le client n’ a pas accumulé le nombre d’heures requis dans sa PR ou quand une autre condition d’admissibilité n’est pas remplie, comme indiqué dans les procédures appropriées.

**Mise à jour du système**

Le 17 septembre 2022 (à compter de la s/c 2361), le système sera mis à jour pour que toutes les demandes dont le DPP est la s/c 2362 ou après soient calculées selon la NVA ou les 600 heures requises pour les prestations spéciales. S’il y a une violation au dossier du client, la majoration des conditions requises pourrait s’appliquer.

**Indemnités de cessation d’emploi**

Dans le cadre du budget 2021, certaines sommes payées en raison d’une cessation d’emploi n’étaient pas réparties. Les indemnités de cessation d’emploi examinées entre la s/c 2310 et la s/c 2361 n’étaient pas considérées comme une rémunération et n’étaient pas réparties.

À compter du 25 septembre 2022, les indemnités de cessation d’emploi qui n’étaient pas considérées comme une rémunération en vertu des mesures temporaires sont à nouveau considérées comme une rémunération et peuvent prolonger la PP. Pour les nouvelles répartitions dont la date de début est le 25 septembre 2022 ou après, les indemnités de cessation d’emploi sont considérées comme une rémunération et sont réparties dans les demandes initiales, renouvelées et continues. Elles sont aussi prises en considération pour prolonger la PP. Comme indiqué dans le RAE 36(9), la semaine de début de la répartition est considérée comme étant lasemaine de la mise à pied ou de la cessation d’emploi, ou la semaine suivante si la semaine de la mise à pied ou de la cessation d’emploi est une semaine entière de travail (SET).

Si les indemnités de cessation d’emploi sont examinées après le 25 septembre 2022 (s/c 2362), mais que la date de début de la répartition est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361), les mesures temporaires s’appliquent. Par conséquent, ces sommes ne sont pas considérées comme une rémunération et ne prolongent pas la PP.

De plus, le budget 2021 comprenait une mesure pour les sommes versées à la suite d’un congédiement injustifié, un règlement de grief ou une faillite. La LAE 46.01 a été modifiée dans le cadre du budget 2021 et le montant seuil qui était utilisé pour déterminer si un paiement émis dans ces situations serait réparti a été retiré. À compter du 25 septembre 2022, l’agent prendra de nouveau le montant seuil en considération pour déterminer si ces sommes doivent être réparties.

**Mise à jour du système**

Les systèmes seront mis à jour pour effectuer les répartitions et la prolongation de la période de prestations, si nécessaire, lors des calculs initiaux, des renouvellements et des recalculs.  En outre, à partir du 16 septembre 2022, un AT Évaluation de la demande (EVD) sera créé si un client déclare une somme d'argent inacceptable lors d'une séparation ou qu'il n'en connaît pas le montant.

**Motif de cessation d’emploi (MCE)**

Dans le cadre de la mesure temporaire du budget 2021 sur le MCE, les modifications suivantes ont été mises en œuvre pour les demandes initiales dont le DPP est entre la s/c 2310 et la s/c 2361 :

- Une décision était seulement rendue sur le plus récent MCE, s’il était litigieux.

- Toutes les heures d’emploi assurables dans la PR sont utilisées pour remplir les conditions requises pour recevoir des prestations, tant que l’une des situations suivantes s’applique :

- le dernier emploi du client a pris fin sans qu’il y ait eu faute de la part du client;

- le client a fait la preuve que son départ volontaire de son dernier emploi était fondé;

- le client n’a pas perdu son dernier emploi en raison d’une inconduite.

- Une décision n’était rendue sur aucun autre MCE dans la PR puisque le système avait été modifié pour résoudre automatiquement les AT Litige - Décision (DEC) en créant un rapport de décision (RD) qui indique Aucune décision requise .

- À la suite d’une exclusion, le client devait seulement travailler une heure d’emploi assurable après l’évènement entraînant l’exclusion et présenter une demande de prestations pour établir une nouvelle demande initiale.

Les règles pour rendre une décision sur les litiges liés au motif de cessation d’emploi (MCE) qui étaient en vigueur avant la pandémie de COVID-19 seront rétablies pour les demandes dont le DPP est la s/c 2362 ou après. Cela signifie que :

- l’agent rend une décision sur toutes les questions litigieuses liées au MCE dans la PR pour déterminer si la rémunération et les heures assurables provenant de cet emploi doivent être incluses dans le calcul de la demande ou exclues de celui-ci, ou si une exclusion doit être imposée;

- l’agent continue à rendre une décision sur toute question litigieuse liée au MCE dans la PP;

- le client est exclu de recevoir des prestations régulières s’il a perdu son travail en raison d’une inconduite ou s’il l’a quitté volontairement sans fondement, et il doit avoir travaillé assez d’heures dans un emploi assurable depuis cet évènement entraînant une exclusion afin de remplir à nouveau les conditions requises pour recevoir des prestations;

- le client doit avoir travaillé assez d’heures pour remplir à nouveau les conditions et répondre à tous les critères requis avant que l’agent termine ou annule sa demande.

Pour correspondre au retour aux anciennes règles, des AT DEC seront automatiquement créés dans les demandes dont le DPP provisoire est la s/c 2361. L’agent doit rendre une décision sur ces AT en suivant les procédures habituelles (plutôt que les mesures temporaires), puisque la demande peut être finalisée et établie avec un DPP dans la s/c 2362 ou après. Toutefois, si la demande est finalisée avec un DPP la s/c 2361, le système ignorera la décision de l’agent et appliquera la mesure temporaire.

Le 19 septembre 2022, les procédures de l’ORL AE concernant les normes d’admissibilité, les indemnités de cessation d’emploi et les MCE seront mises à jour. 

## Résumé des modifications

Source topic: `fr_FR/site/dossier/information_end_of_budget_2021_temp_measures/resume_des_modifications.dita`

**Résumé des modifications**

```text
| Article | Description | Portée |
``` 
