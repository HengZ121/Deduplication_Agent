# RE : Correction d’une erreur de validation pour un RE régulier — Instructions

Source map: `fr_FR/procedure/generic/correction_reg_1/correction_reg_1.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/correction_reg_1/generic.dita`

**Procédures connexes**

- Compléter un AT RE Correction — RE régulier
         [Compléter un AT RE Correction — RE régulier](/fr/procedure/task/completing_roe_correction_regular.shtml)

- Corriger une erreur pendant le calcul ou un nouveau calcul — RE régulier
         [Corriger une erreur pendant le calcul ou un nouveau calcul — RE régulier](/fr/procedure/task/correcting_roe_error_calculation_regular.shtml)

- Post-PU AE : Compléter un AT Évaluation pour le calcul RE Correction — RE régulier
         [Post-PU AE : Compléter un AT Évaluation pour le calcul RE Correction — RE régulier](/fr/procedure/task/post_eierb_completing_assessment_issue_roe_correction_wi_regular_roe.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0681.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0682.dita) 

Choisir la section du RE qui contient le message d’erreur pour voir une liste en ordre alphabétique des messages rencontrés lors de la correction d’un RE.

- 4 - Nom de l’employeur
         [4 - Nom de l’employeur](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#nom)

- 6 - Genre de période de paie
         [6 - Genre de période de paie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#genre)

- 10 - Premier jour de travail
         [10 - Premier jour de travail](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#premier)

- 11 - Dernier jour payé
         [11 - Dernier jour payé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#dernier)

- 12 - Date de fin de la dernière période de paie
         [12 - Date de fin de la dernière période de paie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#date)

- 14 - Date prévue de rappel
         [14 - Date prévue de rappel](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#rappel)

- 15A - Heures assurables totales
         [15A - Heures assurables totales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#heures)

- 15B - Rémunération assurable totale
         [15B - Rémunération assurable totale](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#totale)

- 15C - Périodes de paie détaillées
         [15C - Périodes de paie détaillées](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#paie)

- 16 - Raison du présent relevé d’emploi
         [16 - Raison du présent relevé d’emploi](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#raison)

- 17A - Paie de vacances
         [17A - Paie de vacances](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#vacances)

- 17B - Jour(s) férié(s)
         [17B - Jour(s) férié(s)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#ferie)

- 17C - Autres sommes
         [17C - Autres sommes](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#autres)

- 19 - Paiements spéciaux
         [19 - Paiements spéciaux](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#paiements)

- Erreurs outrepassables
         [Erreurs outrepassables](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_1#erreurs)

**4 - Nom de l’employeur**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0667.dita) 

- Dans ETI, choisir la recherche Employeur (MN22) et saisir le numéro d’entreprise de l’employeur :

- Si la recherche par numéro d’entreprise affiche le nom de l’employeur, saisir le nom dans le champ Nom de l’employeur .

- Si la recherche par numéro d’entreprise n’ affiche pas le nom de l’employeur, retourner à la tâche principale et communiquer avec l’employeur.

**6 - Genre de période de paie**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0683.dita) 

- Déterminer si la période d’emploi est inférieure à 8 jours :

- Si oui, passer à l’étape 2.

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

- Suivre les directives suivantes :

- Dans le champ Genre de période de paie , choisir Hebdomadaire .

- Modifier la date de la case 12 pour qu’elle corresponde à celle de la case 11 .

- Si la case 15C affiche deux périodes de paie, combiner le montant des périodes de paie et l’inscrire à la période de paie 1 de la case 15C .

- Si le numéro de série du RE commence par un « S », modifier la date de fin de la période de paie de la case 15C pour qu’elle corresponde à celle de la case 11 .

- Retourner à la tâche principale.

**10 - Premier jour de travail**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0684.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

**11 - Dernier jour payé**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0685.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

**12 - Date de fin de la dernière période de paie**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0686.dita) 

- Déterminer si le RE indique l’un des éléments suivants :

- Le genre de période de paie est bimensuel et la fin de la dernière période de paie n’est pas le 15e ou le dernier jour du mois.

- Le genre de période de paie est mensuel et la fin de la dernière période de paie n’est pas le dernier jour du mois.

         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0687.dita)

- Déterminer si la case 15C contient une date de fin de la période de paie valide pour la période de paie 1 :

- Si non, passer à l’étape 3.

- Si oui, utiliser la date de fin de la période de paie indiquée à la période de paie 1 et retourner à la tâche principale.

- Déterminer s’il existe un RE antérieur provenant de cet employeur :

- Si oui, passer à l’étape 4.

- Si non, passer à l’étape 7.

- Déterminer si le RE antérieur contient le même genre de période de paie que celui figurant dans le RE erroné et une date de fin de la dernière période de paie:

- Si oui, passer à l’étape 5

- Si non, passer à l’étape 7.

- Déterminer si le RE antérieur indique la bonne date de fin de la dernière période de paie :

- Si oui, passer à l’étape 6.

- Si non, passer à l’étape 7.

- Suivre les directives suivantes :

- Si le RE est bimensuel et le dernier jour payé du client est antérieur au 16 du mois, modifier la date de la case 12 pour qu’elle corresponde au 15e jour du mois au cours duquel le client a été payé la dernière fois.

- Si le RE est bimensuel et le dernier jour payé du client est le 16e du mois ou après, modifier la date de la case 12 pour qu’elle corresponde au dernier du jour du mois au cours duquel le client a été payé la dernière fois.

- Si le RE est mensuel, modifier la date de la case 12 pour qu’elle corresponde au dernier jour du mois.

- Retourner à la tâche principale.

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0688.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0689.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

**14 - Date prévue de rappel**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0690.dita) 

- Déterminer si le client présente une demande de prestations de maternité ou de prestations parentales :

- Si oui, passer à l’étape 2.

- Si non, choisir Non connue et retourner à la tâche principale.

- Déterminer si la date prévue de rappel figure dans la demande consignée dans SNCT :

- Si oui, saisir la date fournie dans la demande et retourner à la tâche principale.

- Si non , choisir Non connue et retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0691.dita) 

- Choisir Non connue et retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0692.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0693.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

**15A - Heures assurables totales**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0694.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0695.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0696.dita) 

- Supprimer le montant à la case 15A.

- Retourner à la tâche principale.

**15B - Rémunération assurable totale**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0697.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0698.dita) 

- Déterminer si la case 15C est remplie :

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

- Si oui, passer à l’étape 2.

- Déterminer si la case 15C contient un message d’erreur :

- Si non , supprimer le montant de la case 15B et retourner à la tâche principale.

- Si oui, suivre les directives suivantes :

- Contacter l’employeur si les renseignements ne sont pas sur le RE ou dans le dossier.

- Corriger la case 15C .

- Supprimer le montant de la case 15B .

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0699.dita) 

- Déterminer si le montant de la case 15B équivaut au montant total de toutes les sommes assurables versées à la cessation d’emploi :

- Si oui, passer à l’étape 2.

- Si non , passer à l’étape 4.

- Déterminer s’il y a un RE antérieur au dossier qui a été émis par l’employeur et qui est clairement lié aux sommes versées à la cessation d’emploi :

- Si oui, passer à l’étape 3.

- Si non , passer à l’étape 4.

- Déterminer si tous les renseignements figurent sur le RE (les champs Commentaires et Renseignements supplémentaires ) afin d’établir la raison et la date des versements :

- Si non , retourner à la tâche principale et communiquer avec l’employeur pour obtenir des renseignements supplémentaires.

- Si oui, suivre les directives suivantes :

- Ajouter les sommes versées à la cessation d’emploi (assurables et non assurables) au RE antérieur.

- Dans la case liée aux renseignements supplémentaires du RE antérieur, saisir les renseignements concernant la raison justifiant les sommes versées à la cessation d’emploi et les dates des versements.

- Supprimer : Cocher la case.

- Renseignements supplémentaires : Saisir « Le RE a seulement été émis en raison de sommes versées à la cessation d’emploi. Le RE antérieur (numéro de série) a été corrigé. »

- Déterminer si le RE antérieur a servi au calcul d’une période de prestations antérieure, et, le cas échéant, consulter Nouveau calcul .
                 [Nouveau calcul](/fr/procedure/activity/recalculation.shtml)

- Retourner à la tâche principale.

- Déterminer si la case 15C est remplie :

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

- Si oui, passer à l’étape 5.

- Déterminer si la case 15C contient un message d’erreur :

- Si non , supprimer le montant de la case 15B et retourner à la tâche principale.

- Si oui, suivre les directives suivantes :

- Contacter l’employeur si les renseignements ne sont pas sur le RE ou dans le dossier.

- Corriger la case 15C .

- Supprimer le montant de la case 15B .

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0700.dita) 

- Déterminer si la case 15C contient un message d’erreur :

- Si non , supprimer le montant de la case 15B et retourner à la tâche principale.

- Si oui, suivre les directives suivantes :

- Contacter l’employeur si les renseignements ne sont pas sur le RE ou dans le dossier.

- Corriger la case 15C .

- Supprimer le montant de la case 15B .

- Retourner à la tâche principale.

**15C - Périodes de paie détaillées**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0701.dita) 

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0702.dita) 

- Déterminer si le montant de la période de paie 1 de la case 15C équivaut au montant total de toutes les sommes assurables versées à la cessation d’emploi :

- Si non , passer à l’étape 2.

- Si oui, retourner à la tâche principale et communiquer avec l’employeur.

- Déterminer si les champs Renseignements supplémentaires ou Observations indiquent clairement qu’une partie ou l’ensemble des montants figurant à la case 17C ne sont pas assurables :

- Si oui, passer à l’étape 3.

- Si non , passer à l’étape 4.

- Déterminer si une des sommes considérées comme non assurable a été indiquée à tort comme assurable :

- Si non , passer à l’étape 4.

- Si oui, modifier la description des autres sommes figurant à la case 17C pour qu’elle corresponde à l’option des autres sommes non assurables, selon les renseignements indiqués.

- Si l’erreur est réglée, retourner à la tâche principale.

- Si l’erreur n ’est pas réglée, retourner à la tâche principale et communiquer avec l’employeur.

- Déterminer si un seul type de somme figure à la case 17 :

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

- Si oui, passer à l’étape 5.

- Déterminer si le choix indiqué est clairement un type assurable (p. ex. Indemnité de préavis , mais pas Autre ) :

- Si non , passer à l’étape6.

- Si oui, suivre les directives suivantes :

- Ajouter la somme assurable versée à la cessation d’emploi indiquée au montant de la case 15B , de la période de paie 1 et de la case 15C .

- Si l’erreur est réglée, retourner à la tâche principale.

- Si l’erreur n ’est pas réglée, retourner à la tâche principale et communiquer avec l’employeur.

- Déterminer si le choix indiqué est un type qui nécessiterait normalement des précisions (p. ex. Autre ), mais que le RE indique clairement qu’il s’agit d’un montant assurable (p. ex. le champ Renseignements supplémentaires indique que les sommes la case 17C correspondent à une indemnité de retraite):

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

- Si oui, suivre les directives suivantes :

- Ajouter la somme assurable versée à la cessation d’emploi indiquée au montant de la case 15C , de la période de paie 1 et de la case 15B .

- Modifier l’option liée au genre de paiement pour qu’elle corresponde à la rémunération assurable.

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0703.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0704.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0705.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0706.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0707.dita) 

- Déterminer si le montant de la rémunération pour cette période de paie est de 0,00 $ :

- Si oui, passer à l’étape 2.

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

- Déterminer si le montant de la case 15B est erroné :

- Si oui, retourner à la tâche principale et communiquer avec l’employeur

- Si non , saisir 0,00 dans le champ Heures et retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0708.dita) 

- Déterminer si la date identique correspond clairement à une date de fin de période de paie manquante :

- Si oui, saisir la date de la période de paie manquante qui remplace la date répétée et retourner à la tâche principale.

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0709.dita) 

- Déterminer si la date manquante tombe clairement entre deux autres périodes de paie figurant à la case 15C :

- Si oui, saisir la bonne date et retourner à la tâche principale.

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0710.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0711.dita) 

- Déterminer si la date identique correspond clairement à une date de fin de période de paie manquante :

- Si oui, saisir la date de la période de paie manquante qui remplace la date répétée et retourner à la tâche principale.

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0712.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0713.dita) 

- Déterminer si l’employeur a fourni plus de périodes de paie que le maximum permis pour ce genre de période de paie en raison des MSV :

- Si oui, noter les périodes de paie à supprimer et passer à l’étape 3.

- Si non, passer à l’étape 2.

- Compter le nombre de périodes de paie comprises entre le premier jour travaillé et le dernier jour travaillé.

- Si le nombre de périodes de paie entre le premier jour de travail et le dernier jour de travail est supérieur à ce qui a été fourni par l’employeur, communiquer avec l’employeur afin d’obtenir les renseignements manquants liés à la période de paie.

- Si le nombre de périodes de paie entre le premier jour de travail et le dernier jour de travail est inférieur à ce qui a été fourni par l’employeur, communiquer avec l’employeur afin de vérifier que le premier jour de travail est correct.

- Retourner à la tâche principale.

**16 - Raison du présent relevé d’emploi**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0677.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

**17A - Paie de vacances**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0714.dita) 

- Déterminer si le montant est de 0,00$ :

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

- Si oui, suivre les directives suivantes :

- Supprimer le montant.

- Si un motif a été choisi aux fins de justification de la paie de vacances, choisir l’option vide.

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0715.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0716.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0717.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

**17B - Jour(s) férié(s)**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0718.dita) 

- L’agent Non complexe doit retourner à la tâche principale.

- Déterminer si les renseignements indiquent que la date de la rémunération du jour férié est acceptable (p. ex. le client était en congé avec étalement du revenu entre le dernier jour payé et la date que la rémunération des jours fériés a été émise).

- Si non, retourner à la tâche principale et communiquer avec l’employeur.

- Si oui, suivre les directives suivantes :

- Saisir « La date de la rémunération du jour férié est acceptable. » dans le champ Renseignements supplémentaires .

- Noter qu’il faut cocher la case Erreurs outrepassables à côté de « La date du jour férié payé ne doit pas être supérieure au dernier jour payé plus 12 mois. » lorsque le RE est soumis.

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0719.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0720.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0721.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

**17C - Autres sommes**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0722.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0723.dita) 

- Déterminer si le montant est de 0,00$ :

- Si oui et si une option a été choisie, choisir l’option vide et retourner à la tâche principale.

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0724.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0725.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0726.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0727.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0728.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur.

**19 - Paiements spéciaux**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0729.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0730.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0731.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0732.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0733.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0734.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0735.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0736.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0737.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0738.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0739.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0740.dita) 

- Déterminer si le montant est de 0,00 $ :

- Si oui, passer à l’étape 2.

- Si non , retourner à la tâche principale et communiquer avec l’employeur.

- Déterminer si d’autres champs Paiements spéciaux ont été remplis :

- Si oui, retourner à la tâche principale et communiquer avec l’employeur.

- Si non , supprimer le montant et retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0741.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0742.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0743.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0744.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0745.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0746.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0747.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0748.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0749.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0750.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0751.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0752.dita) 

- Retourner à la tâche principale et communiquer avec l’employeur .

**Erreurs outrepassables**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0753.dita) 

- Déterminer s’il est clairement indiqué que le RE est modifié (voir la case 2 du RE ou dans les commentaires de la case 18 ) :

- Si oui, passer à l’étape 3.

- Si non, suivre les directives suivantes :

- L’agent Non complexe doit retourner à la tâche principale.

- L’agent de Niveau 1 doit passer à l’étape 2.

- Déterminer si les renseignements indiquent que le chevauchement est acceptable (p. ex. le client exerce 2 emplois distincts pour l’employeur) :

- Si oui, pour chaque RE qui se chevauche, suivre les directives suivantes :

- Saisir « chevauchement acceptable. » dans le champ Renseignements supplémentaires .

- Noter qu’il faut cocher la case Erreurs outrepassables à côté de « Ce RE chevauche un autre RE qui existe. » lorsque les RE sont soumis.

- Retourner à la tâche principale.

- Si non , retourner à la tâche principale et communiquer avec l’employeur.
             [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0754.dita)

- Déterminer si le RE modifié a servi au calcul d’une période de prestations antérieure :

- Si non , passer à l’étape 4.

- Si oui, retourner à la tâche principale et communiquer avec l’employeur.

- Déterminer si le numéro de série du RE commence par S ou W :

- Si non , saisir le numéro de série du RE original à la case 2 du RE modifié, et retourner à la tâche principale.

- Si oui, suivre les directives suivantes :

- Supprimer : Cocher la case.

- Renseignements supplémentaires : Saisir « Le RE a été modifié grâce au RE [numéro de série du RE modifié. »]

- Retourner à la tâche principale. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0681.dita`

Remarque :

Pour un AT RE Correction, un calcul initial ou un nouveau calcul concernant un RE du gouvernement du Canada qui doit être corrigé, consulter RE émis par le gouvernement du Canada — Instructions .
       [RE émis par le gouvernement du Canada — Instructions](/fr/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [RE émis par le gouvernement du Canada — Instructions](/fr/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0682.dita`

Remarque :

Les solutions de rechange et les mesures à prendre doivent suivre l'ordre donné. 

### Info

Source topic: `fr_FR/common_notes/note_c_0667.dita`

Message d’erreur : « Le nom de l’employeur est requis. » (04X000NM10485) 

### Info

Source topic: `fr_FR/common_notes/note_c_0683.dita`

Message d’erreur : « Un genre de période de paie valide est requis. » (06X000TP10257) 

### Info

Source topic: `fr_FR/common_notes/note_c_0684.dita`

Message d’erreur : « Le premier jour de travail est requis. » (10X000DT10481) 

### Info

Source topic: `fr_FR/common_notes/note_c_0685.dita`

Message d’erreur : « Le dernier jour payé doit être postérieur ou égal au premier jour de travail. » (11X000DT10017) 

### Info

Source topic: `fr_FR/common_notes/note_c_0686.dita`

Message d’erreur : « La date de fin de la dernière période ne peut pas être plus de :

- 6 jours après le dernier jour payé, basé sur une période de paie Hebdomadaire. » (12X000DT10025)

- 13 jours après le dernier jour payé, basé sur une période de paie à la Quinzaine. » (12X000DT10019)

- 15 jours après le dernier jour payé et doit être le 15ième jour ou le dernier jour du mois, basé sur une période de paie Bimensuelle. » (12X000DT10022)

- 15 jours après le dernier jour payé et ne doit pas être le 15ième jour ou le dernier jour du mois (à l’exception du 28 et 29 de février), basé sur une période de paie Bimensuelle non conventionnelle. » (12X000DT10023)

- 27 jours après le dernier jour payé, basé sur 13 périodes de paie par année. » (12X000DT10024)

- 30 jours après le dernier jour payé et doit être le dernier jour du mois, basé sur une période de paie Mensuelle. » (12X000DT10020)

- 30 jours après le dernier jour payé et ne doit pas être le dernier jour du mois (à l’exception du 28 et 29 février), basé sur une période de paie mensuelle non conventionnelle. » (12X000DT10021)

Il importe de savoir que, si une date de fin de la période de paie inexacte figure dans le RE, les heures et la rémunération assurables peuvent avoir été calculées de façon inexacte à partir d’un nombre de période de paie erroné. 

### Callout

Source topic: `fr_FR/common_notes/note_c_0687.dita`

- Si l’une des conditions est remplie, passer à l’étape 2.

- Si aucune condition n’est remplie, passer à l’étape 7. 

### Info

Source topic: `fr_FR/common_notes/note_c_0688.dita`

Message d’erreur : « La date de fin de la dernière période de paie est requise. » (12X000DT10482) 

### Info

Source topic: `fr_FR/common_notes/note_c_0689.dita`

Message d’erreur : « La date de fin de la dernière période de paie doit être postérieure ou égale au dernier jour payé. » (12X000DT10018)

Il importe de savoir que, si une date de fin de la période de paie inexacte figure dans le RE, les heures et la rémunération assurables peuvent avoir été calculées de façon inexacte à partir d’un nombre de période de paie erroné 

### Info

Source topic: `fr_FR/common_notes/note_c_0690.dita`

Message d’erreur : « Une date est requise lorsque le code de la date prévue de rappel est ‘Y – Date prévue de rappel’. » (14X000DT10030) 

### Info

Source topic: `fr_FR/common_notes/note_c_0691.dita`

Message d’erreur : « Un code de la date prévue de rappel valide est requis. » (14X000TP10299) 

### Info

Source topic: `fr_FR/common_notes/note_c_0692.dita`

Message d’erreur : « La date prévue de rappel doit être postérieure au dernier jour payé <LDFWP>. » (14X000DT10029) 

### Info

Source topic: `fr_FR/common_notes/note_c_0693.dita`

Message d’erreur : « Le code de la date prévue de rappel ne peut être ‘Y – Date prévue de rappel’ lorsque la raison du présent relevé d’emploi est :

- E. » (14X000TP10026)

- G. » (14X000TP10027)

- M. » (14X000TP10028)

Le fait qu’une date prévue de rappel soit accompagnée du motif de cessation d’emploi E - Départ volontaire , G - Retraite obligatoire ou M - Congédiement , est contradictoire. Si le recueil de faits a déterminé que le MCE figurant sur le RE est exact, la date prévue de rappel doit être remplacée par Retour non prévu . 

### Info

Source topic: `fr_FR/common_notes/note_c_0694.dita`

Message d’erreur : « Les heures assurables totales ne peuvent dépasser le plus petit de 8 904 ou (dernier jour payé <LDFWP> - premier jour de travail <FDW> + 1) x 24. » (15A000HR10031) Le RE contient un nombre d’heures impossible pour la période d’emploi. Il est possible que l’employeur ait inversé les saisies figurant dans les cases 15A et 15B . 

### Info

Source topic: `fr_FR/common_notes/note_c_0695.dita`

Message d’erreur : « Les heures assurables totales doivent être entre 1 et 8 904 inclusivement (espace ajouté pour la lisibilité seulement). » (15A000HR10459)

Il est possible que l’employeur ait inversé les saisies figurant dans les cases 15A et 15B . 

### Info

Source topic: `fr_FR/common_notes/note_c_0696.dita`

Message d’erreur : « Les heures assurables doivent être égales au total des heures assurables (le total des heures doit toujours être arrondi au chiffre entier suivant). » (15A000HR10032)

Cette erreur apparaît sur les RE de la série S et survient quand le nombre d’heures de la case 15C n’est pas égal au nombre d’heures enregistrées de la case 15A. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0697.dita`

Remarque :

La rémunération assurable totale d’un RE peut aller de 1,00 $ à 9 999 999,99 $. Quand le montant est plus grand que 999 999,99 $, l’agent doit le modifier à 999 999,99 $ dans MSRE.

Remarque : L’agent doit suivre les étapes sous les solutions de rechange 15B et 15C pour s’assurer que le RE respectent les règles de validation de MSRE. 

### Info

Source topic: `fr_FR/common_notes/note_c_0698.dita`

Message d’erreur : « Le montant de la rémunération assurable totale doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement. » (15B000AM10034) Lorsque c’est le cas, le montant doit être confirmé auprès de l’employer. Si l’employeur confirme que le montant est moins que 1,00 $ et plus que 0 $, saisir 1,00 $. Si l’employeur confirme que le montant est supérieur à 999 999,99, l’agent de Niveau 1 qui calcule la demande doit suivre les directives suivantes :

- saisir le montant de la rémunération de la case 15B à 999 999,99 $

- consigner les renseignements dans un RSDP

Remarque : Déterminer la rémunération hebdomadaire normale moyenne (RHNM) et la rémunération moyenne de la dernière semaine de travail (RMDST) selon la rémunération réelle du client. Dans MSRE, dans la section Répartition des sommes , remplir les champs suivants :

- Rémunération hebdomadaire normale moyenne : Saisir le montant de la RHNM tel que calculé.

- Rémunération moyenne de la dernière semaine de travail : Saisir le montant de la RMDST tel que calculé. 

### Info

Source topic: `fr_FR/common_notes/note_c_0699.dita`

Message d’erreur : « La rémunération assurable totale doit inclure la rémunération assurable ainsi que le montant total des sommes assurables de cessation d'emploi fourni. » (15B000AM10033) Cette erreur survient dans les cas suivants :

- Les sommes assurables versées à la cessation d’emploi peuvent avoir été exclues de façon erronée du montant total de la rémunération figurant à la case 15B .

- Les sommes versées à la cessation d’emploi figurant à la case 17 peuvent avoir été considérées par erreur comme des sommes assurables.

- Au lieu d’un RE original modifié, un nouveau RE a été émis par erreur et fait uniquement état de sommes versées après la cessation d’emploi. Il est important de noter que, durant le calcul, si des sommes versées à la cessation d’emploi ont été reçues à une date ultérieure, la raison du versement peut avoir une répercussion sur la date à laquelle les sommes ont été versées. Consulter la procédure Rémunération pour obtenir de plus amples renseignements.
         [Rémunération](/fr/procedure/activity/earnings.shtml)

     [Rémunération](/fr/procedure/activity/earnings.shtml) 

### Info

Source topic: `fr_FR/common_notes/note_c_0700.dita`

Message d’erreur : « La rémunération assurable totale doit être égale à la période d’emploi et ne doit pas dépasser »

- « 7 périodes de paie selon 13 périodes de paie par année. » (15B000AM10430)

- « 7 périodes de paie selon la période de paie Mensuelle. » (15B000AM10426)

- « 7 périodes de paie selon la période de paie Mensuelle non conventionnelle. » (15B000AM10427)

- « 13 périodes de paie selon la période de paie Bimensuelle non conventionnelle. » (15B000AM10429)

- « 14 périodes de paie selon la période de paie à la Quinzaine. » (15B000AM10425)

- « 27 périodes de paie selon la période de paie Hebdomadaire. » (15B000AM10431)

La suppression du montant de la case 15B permet au MSRE de calculer le montant exact de la case 15B selon les saisies de la case 15C . 

### Info

Source topic: `fr_FR/common_notes/note_c_0701.dita`

Message d’erreur : « Le montant de la rémunération assurable de la période de paie 1 doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement).» (15C001AM10041)

Remarque : Si l’employeur confirme que le montant est moins que 1,00 $ et plus que 0 $, saisir 1,00 $. 

### Info

Source topic: `fr_FR/common_notes/note_c_0702.dita`

Message d’erreur : « Le montant de la rémunération assurable de la période de paie 1 doit inclure la rémunération assurable ainsi que le montant total des sommes assurables de cessation d'emploi fourni. » (15C001AM10047)

Les sommes assurables versées à la cessation d’emploi peuvent avoir été reçues au cours d’une période de paie suivant celle dans laquelle tombe le dernier jour de travail du client, et la période de paie 1 peut être inexacte et ne comprendre que les sommes assurables versées à la cessation d’emploi. L’agent doit donc vérifier le dernier jour payé figurant sur le RE, car l’employeur peut l’avoir rempli de façon inexacte en indiquant la date à laquelle des sommes assurables versées en raison d’une cessation d’emploi ont été payées.

Les sommes assurables versées à la cessation d’emploi peuvent avoir été exclues de façon erronée du montant total de la rémunération figurant à la période de paie 1 de la case 15C .

Les sommes versées à la cessation d’emploi figurant à la case 17 peuvent avoir été considérées par erreur comme des sommes assurables.

Au lieu d’un RE original modifié, un nouveau RE a été émis par erreur et fait uniquement état de sommes versées après la cessation d’emploi. Il importe de noter que, durant les calculs, si des sommes versées à la cessation d’emploi ont été reçues à une date ultérieure, la raison du versement peut avoir une répercussion sur la date à laquelle les sommes ont été versées.

Consulter la procédure Rémunération pour obtenir de plus amples renseignements.
       [Rémunération](/fr/procedure/activity/earnings.shtml)

     [Rémunération](/fr/procedure/activity/earnings.shtml) 

### Info

Source topic: `fr_FR/common_notes/note_c_0703.dita`

Message d’erreur : « Le montant de la rémunération assurable de la période de paie <nn> contenant le premier jour de travail doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (15C0nnAM10043 <nn> = numéro de la période de paie)

Le premier jour de travail peut être incorrect, ou au moment de compléter les périodes de paie, l’employeur a peut-être inscrit à la case 15C les heures et la rémunération du premier jour de travail dans une période de paie subséquente.

Exemple :

Le premier jour de travail de l’employé est le 9 août. Le 13 août, l’employeur remplit la feuille de paie de la période du 5 au 11 août, mais l’employé n’est pas officiellement inscrit à la feuille de paie. Les montants de la rémunération de la période du 9 au 11 août est incluse dans la période de paie qui se termine le 18 août. Les détails du RE indiquent incorrectement 0.00 $ en tant que la rémunération de la période de paie qui se termine le 11 août. 

### Info

Source topic: `fr_FR/common_notes/note_c_0704.dita`

Message d’erreur : « Le montant de la rémunération assurable de la période de paie <nn> doit être entre 1.00 et 999 999.99 (espace ajouté pour la lisibilité seulement) inclusivement ou doit être 0.00 lorsqu’il n’y a pas de rémunération assurable. » (15C0nnAM10046 <nn> = période de paie 02 à 53)

Remarque : Si l’employeur confirme que le montant est moins que 1,00$ et plus que 0$, saisir 1,00$. 

### Info

Source topic: `fr_FR/common_notes/note_c_0705.dita`

Message d’erreur : « Les heures assurables de la période de paie 1 doivent être entre 0.01 et 999.99 inclusivement (décimale incluse). » (15C001HR10055)

Cette erreur peut survenir concurremment avec une erreur liée aux sommes assurables versées à la cessation d’emploi si la période de paie 1 contient une rémunération mais aucune heure. Lorsque c’est le cas, corriger-le en premier puisque cela peut permettre de corriger l’autre erreur. 

### Info

Source topic: `fr_FR/common_notes/note_c_0706.dita`

Message d’erreur : « Les heures assurables de la période de paie <nn> contenant le premier jour de travail doivent être entre 0.01 et 999.99 inclusivement (décimale incluse). » (15C0nnHR10056 <nn> = période de paie 02 à 53) 

### Info

Source topic: `fr_FR/common_notes/note_c_0707.dita`

Message d’erreur : « Les heures assurables doivent respecter le format 999.99 (décimale incluse). » (15C0nnHR10316 <nn> = période de paie 02 à 53) 

### Info

Source topic: `fr_FR/common_notes/note_c_0708.dita`

Message d’erreur : « Les dates de fin des périodes de paie doivent toutes être différentes et aucune ne doit être omise. » (15C000DT10446)

Si des corrections ont été apportées à la période de paie, les dossiers de paie de l’employeur peuvent indiquer deux dates identiques de la fin de la période de paie. Il se peut que les renseignements aient pu être saisis deux fois à la case 15C . 

### Info

Source topic: `fr_FR/common_notes/note_c_0709.dita`

Message d’erreur : « La date de fin de la période de paie, le montant et les heures sont requis pour chacune des périodes de paie requises. » (15C0000010036) 

### Info

Source topic: `fr_FR/common_notes/note_c_0710.dita`

Message d’erreur : « La date de fin de la période de paie 1 doit être égale à la date de fin de la dernière période de paie fournie. » (15C001DT10038)

Cette erreur peut survenir concurremment avec une erreur à la case 12 . La correction de l’erreur de la case 12 peut corriger l’erreur de la case 15C . 

### Info

Source topic: `fr_FR/common_notes/note_c_0711.dita`

Message d’erreur : « Les dates de fin de la période de paie doivent être fournies en ordre chronologique en débutant par la date de fin de la dernière période de paie. » (15C000DT10039) 

### Info

Source topic: `fr_FR/common_notes/note_c_0712.dita`

Message d’erreur : « Le nombre de périodes de paie consécutives fourni doit être égal à la période d’emploi et ne doit pas dépasser :

- 7 ou 13 périodes de paie selon la période de paie Mensuelle. » (15C0000010475)

- 7 ou 13 périodes de paie selon la période de paie Mensuelle non conventionnelle. » (15C0000010476)

- 7 ou 14 périodes de paie selon 13 périodes de paie par année. » (15C0000010479)

- 7 périodes de paie selon 13 périodes de paie par année. » (15C0000010442)

- 7 périodes de paie selon la période de paie Mensuelle. » (15C0000010434)

- 7 périodes de paie selon la période de paie Mensuelle non conventionnelle. » (15C0000010436)

- 13 ou 25 périodes de paie selon la période de paie Bimensuelle. » (15C0000010477)

- 13 ou 25 périodes de paie selon la période de paie Bimensuelle non conventionnelle. » (15C0000010478)

- 13 périodes de paie selon la période de paie Bimensuelle. » (15C0000010438)

- 13 périodes de paie selon la période de paie Bimensuelle non conventionnelle. » (15C0000010440)

- 13 périodes de paie selon la période de paie Mensuelle. » (15C0000010435)

- 13 périodes de paie selon la période de paie Mensuelle non conventionnelle. » (15C0000010437)

- 14 ou 27 périodes de paies selon la période de paie à la Quinzaine. » (15C0000010474)

- 14 périodes de paie selon 13 périodes de paie par année. » (15C0000010443)

- 14 périodes de paies selon la période de paie à la Quinzaine. » (15C0000010432)

- 25 périodes de paie selon la période de paie Bimensuelle. » (15C0000010439)

- 25 périodes de paie selon la période de paie Bimensuelle non conventionnelle. » (15C0000010441)

- 27 ou 53 périodes de paie selon la période de paie Hebdomadaire. » (15C0000010480)

- 27 périodes de paie selon la période de paie à la Quinzaine. » (15C0000010433)

- 27 périodes de paie selon la période de paie Hebdomadaire. » (15C0000010444)

- 53 périodes de paie selon la période de paie Hebdomadaire. » (15C0000010445) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0713.dita`

Remarque :

L’employeur peut avoir fourni plus de périodes de paie que nécessaire pour la case 15C afin de fournir des renseignements supplémentaires au sujet de la paie pour le calcul des meilleures semaines variables (MSV). Le nombre de périodes de paie consécutives doit correspondre à la période d’emploi et ne doit pas dépasser le nombre maximum de périodes de paie permis pour ce genre de période de paie. 

### Info

Source topic: `fr_FR/common_notes/note_c_0677.dita`

Message d’erreur : « Une raison valide est requise pour le présent relevé d’emploi. » (16X000TP10065) 

### Info

Source topic: `fr_FR/common_notes/note_c_0714.dita`

Message d’erreur : « Le montant de la paie de vacances doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (17A001AM10097)

Remarque : Si l’employeur confirme que le montant est moins que 1,00$ et plus que 0$, saisir 1,00$. 

### Info

Source topic: `fr_FR/common_notes/note_c_0715.dita`

Message d’erreur : « La date de fin de la paie de vacances est requise lorsque le genre de paie de vacances est ‘Payée pour des vacances’. » (17A001ED10086) 

### Info

Source topic: `fr_FR/common_notes/note_c_0716.dita`

Message d’erreur : « La date de fin de la paie de vacances doit être postérieure ou égale à la date de début de la paie de vacances lorsque le genre de paie de vacances est ‘Payée pour des vacances’. » (17A001ED10090) 

### Info

Source topic: `fr_FR/common_notes/note_c_0717.dita`

Message d’erreur : « La date de début de la paie de vacances est requise lorsque le code de paie de vacances est :

- ‘Anniversaire (payée à la même date chaque année)’. » (17A001SD10080)

- ‘Payée pour des vacances’’. » (17A001SD10079) 

### Info

Source topic: `fr_FR/common_notes/note_c_0718.dita`

Message d’erreur : « La date du jour férié payé <nn> doit être postérieure au dernier jour payé et inférieure ou égale au (dernier jour payé + 12 mois). » (17B0nnDT10101 <nn>= rémunération des jours fériés pour les points 01 à 10)

Même si une date de plus de 12 mois après le dernier jour payé est généralement dû à une erreur qui survient lorsqu’on remplit le RE, parfois la rémunération des jours fériés est versée plus d’un an après le dernier jour payé. Lorsque cette situation se produit et que l’employeur le confirme, l’agent peut contourner l’erreur pour permettre le calcul de la demande. 

### Info

Source topic: `fr_FR/common_notes/note_c_0719.dita`

Message d’erreur : « Le montant de la rémunération du jour férié payé <nn> est requis lorsque la date du jour férié payé est fournie. » (17B0nnAM10103 <nn>= rémunération des jours fériés pour les points 01 à 10)

Remarque : Si l’employeur confirme que le montant est moins que 1,00 $ et plus que 0 $, saisir 1,00 $. 

### Info

Source topic: `fr_FR/common_notes/note_c_0720.dita`

Message d’erreur : « Le montant du jour férié payé <nn> doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (17B0nnAM10105 <nn>= rémunération des jours fériés pour les points 01 à 10)

Remarque : Si l’employeur confirme que le montant est moins que 1,00 $ et plus que 0 $, saisir 1,00 $. 

### Info

Source topic: `fr_FR/common_notes/note_c_0721.dita`

Message d’erreur : « Les dates des jours fériés payés doivent toutes être différentes. » (17B0nnDT10098 <nn>= rémunération des jours fériés pour les points 01 à 10) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0722.dita`

Remarque :

Une mesure provisoire en vertu du Projet pilote 24 s’applique aux indemnités de cessation d’emploi versées en raison d’une cessation d’emploi dans les demandes dont le DPP ou la date de début de la répartition est entre le 30 mars 2025 (s/c 2493) et le 10 octobre 2026 (s/c 2572 ). Quand des indemnités de cessation d’emploi sont versées pour cette période, elles ne sont pas réparties.

Si les sommes sont versées en raison de la cessation d’emploi, l’agent laisse les champs du RE indiquant une date vides et CAC ne répartit pas les sommes. Si les sommes sont versées pour toute autre raison, l’agent saisit les dates appropriées dans le RE et CAC répartit les montants comme d’habitude. 

### Info

Source topic: `fr_FR/common_notes/note_c_0723.dita`

Message d’erreur : « Le montant du versement des autres sommes <nn> doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (17C0nnAM10187 <nn>= autres sommes points 01 à 05)

Remarque : Si l’employeur confirme que le montant est moins que 1,00 $ et plus que 0 $, saisir 1,00 $. 

### Info

Source topic: `fr_FR/common_notes/note_c_0724.dita`

Message d’erreur : La date de fin du versement des autres sommes <nn> est requise lorsque le code des autres sommes :

- ‘B - Prime (pour récompenser le rendement/la productivité)’ est fourni. » (17C0nnED10137 <nn>= autres sommes points 01 à 05)

- ‘H - Honoraires’ est fourni. » (17C0nnED10145 <nn>= autres sommes points 01 à 05)

- ‘W - Paiement provincial/retrait préventif’ est fourni. » (17C0nnED10159 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0725.dita`

Message d’erreur : « La date de fin du versement des autres sommes <nn> doit être entre la date du jour moins 50 ans et la date du jour plus 2 ans inclusivement. » (17C0nnED10162 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0726.dita`

Message d’erreur : « La date de fin du versement des autres sommes <nn> doit être postérieure ou égale à la date de début du versement des autres sommes. » (17C0nnED10163 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0727.dita`

Message d’erreur : « La date de début du versement des autres sommes <nn> est requise lorsque le code des autres sommes :

- ‘B - Prime (événements particuliers)’ est fourni. » (17C0nnSD10109 <nn>= autres sommes points 01 à 05)

- ‘B - Prime (jour férié)’ est fourni. » (17C0nnSD10107 <nn>= autres sommes points 01 à 05)

- ‘B - Prime (pour récompenser le rendement/la productivité)’ est fourni. » (17C0nnSD10108 <nn>= autres sommes points 01 à 05)

- ‘H - Honoraires’ est fourni. » (17C0nnSD10116 <nn>= autres sommes points 01 à 05

- ‘W - Paiement provincial/retrait préventif’ est fourni. » (17C0nnSD10130 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0728.dita`

Message d’erreur : « La date de début versement des autres sommes <nn> doit être entre la date du jour moins 50 ans et la date du jour plus 2 ans inclusivement. » (17C0nnSD10133 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0729.dita`

Message d’erreur : « Le montant du congé de maternité / parental / compassion / prestations pour proches aidants payé est requis lorsque le genre de paiements spéciaux ‘Congé de maternité / parental / compassion / prestations pour proches aidants payé ’ est fourni. » (19X003AM10216) 

### Info

Source topic: `fr_FR/common_notes/note_c_0730.dita`

Message d’erreur : « La date de fin du congé de maternité / parental / compassion / prestations pour proches aidants payé doit être égale au dernier jour payé <LDFWP>. » (19X003AM10210) 

### Info

Source topic: `fr_FR/common_notes/note_c_0731.dita`

Message d’erreur : « La période du congé de maternité / parental / compassion / prestations pour proches aidants payé est requise lorsque le genre de paiements spéciaux ‘Congé de maternité / parental / compassion / prestations pour proches aidants payé’ est fourni. » (19X003AM10224) 

### Info

Source topic: `fr_FR/common_notes/note_c_0732.dita`

Message d’erreur : « La date de début du congé de maternité / parental / compassion / prestations pour proches aidants payé est requise lorsque le genre de paiements spéciaux ‘Congé de maternité / parental / compassion / prestations pour proches aidants ’ est fourni. » (19X003AM10195) 

### Info

Source topic: `fr_FR/common_notes/note_c_0733.dita`

Message d’erreur : « La date de début du congé de maternité / parental / compassion / prestations pour proches aidants payé doit précéder ou être égale au dernier jour payé <LDFWP>. » (19X003SD10198) 

### Info

Source topic: `fr_FR/common_notes/note_c_0734.dita`

Message d’erreur : « Le montant du congé de maladie payé est requis lorsque la date de début du paiement spécial est fournie pour le genre de paiements spéciaux ‘Congé de maladie payé’ est fourni. » (19X001AM10453) 

### Info

Source topic: `fr_FR/common_notes/note_c_0735.dita`

Message d’erreur : « Le montant du congé de maladie payé est requis lorsque le genre de paiements spéciaux ‘Congé de maladie payé’ est fourni. » (19X001AM10212) 

### Info

Source topic: `fr_FR/common_notes/note_c_0736.dita`

Message d’erreur : « La date de fin du congé de maladie payé doit être égale au dernier jour payé <LDFWP>. » (19X001AM10207) 

### Info

Source topic: `fr_FR/common_notes/note_c_0737.dita`

Message d’erreur : « La période du congé de maladie payé est requise lorsque le genre de paiements spéciaux ‘Congé de maladie payé ’ est fourni. » (19X001AM10220) 

### Info

Source topic: `fr_FR/common_notes/note_c_0738.dita`

Message d’erreur : « La date de début du congé de maladie payé est requise lorsque le genre de paiements spéciaux ‘Congé de maladie payé’ est fourni. » (19X001AM10191) 

### Info

Source topic: `fr_FR/common_notes/note_c_0739.dita`

Message d’erreur : « La date de début du congé de maladie payé doit précéder ou être égale au dernier jour payé <LDFWP>. » (19X001SD10196) 

### Info

Source topic: `fr_FR/common_notes/note_c_0740.dita`

Message d’erreur : « Le montant du paiement spécial doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (19X0nnAM10218 <nn>=paiement spécial points 01 à 04)

Remarque : Si l’employeur confirme que le montant est moins que 1,00 $ et plus que 0 $, saisir 1,00 $. 

### Info

Source topic: `fr_FR/common_notes/note_c_0741.dita`

Message d’erreur : « La date de fin du paiement spécial doit être postérieure ou égale à la date de début du paiement spécial. » (19319X0nnED10206 <nn>=paiement spécial points 01 à 04) 

### Info

Source topic: `fr_FR/common_notes/note_c_0742.dita`

Message d’erreur : « Le montant des indemnités d’assurance salaire (AE assurable) est requis lorsque la date de fin du paiement spécial est fournie pour le genre de paiements spéciaux ‘Indemnités d’assurance salaire (AE assurable)’. » (19X002AM10215) 

### Info

Source topic: `fr_FR/common_notes/note_c_0743.dita`

Message d’erreur : « La date de fin des indemnités d’assurance salaire (AE assurable) doit être postérieure ou égale à la date de début des indemnités d’assurance salaire (AE assurable). » (19X002AM10208) 

### Info

Source topic: `fr_FR/common_notes/note_c_0744.dita`

Message d’erreur : « La période des indemnités d’assurance salaire (AE assurable) est requise lorsque le montant des indemnités d’assurance salaire (AE assurable) est fourni pour le genre de paiements spéciaux ‘Indemnités d’assurance salaire (AE assurable)’. » (19X002AM10223) 

### Info

Source topic: `fr_FR/common_notes/note_c_0745.dita`

Message d’erreur : « La période des indemnités d’assurance salaire (AE assurable) est requise lorsque le montant des indemnités d’assurance salaire (AE assurable) est fourni pour le genre de paiements spéciaux ‘Indemnités d’assurance salaire (AE assurable)’. » (19X002AM10450) 

### Info

Source topic: `fr_FR/common_notes/note_c_0746.dita`

Message d’erreur : « La date de début des indemnités d’assurance salaire (AE assurable) est requise lorsque le genre de paiements spéciaux ‘Indemnités d’assurance salaire (AE assurable)’ est fourni. » (19X002AM10194) 

### Info

Source topic: `fr_FR/common_notes/note_c_0747.dita`

Message d’erreur : « Le code de la période des indemnités d’assurance salaire (AE non assurable) est requis lorsque la date de fin des indemnités d’assurance salaire (AE non assurable) est fournie pour le genre de paiements spéciaux indemnités d’assurance salaire (AE non assurable). » (19X004PR10449) 

### Info

Source topic: `fr_FR/common_notes/note_c_0748.dita`

Message d’erreur : « Le montant des indemnités d’assurance salaire (AE non assurable) est requis lorsque la date de fin des indemnités d’assurance salaire (AE non assurable) <nn> est fournie. » (19X004PR10214) 

### Info

Source topic: `fr_FR/common_notes/note_c_0749.dita`

Message d’erreur : « La date de fin des indemnités d’assurance salaire (AE non assurable) doit être postérieure ou égale à la date de début des indemnités d’assurance salaire (AE non assurable). » (19X004PR10209) 

### Info

Source topic: `fr_FR/common_notes/note_c_0750.dita`

Message d’erreur : « La période des indemnités d’assurance salaire (AE non assurable) est requise lorsque le montant du paiement spécial est fourni pour le genre de paiements spéciaux ‘Indemnités d’assurance salaire (AE non assurable)’. » (19X004PR10222) 

### Info

Source topic: `fr_FR/common_notes/note_c_0751.dita`

Message d’erreur : « La date de début des indemnités d’assurance salaire (AE non assurable) est requise lorsque la date de fin des indemnités d’assurance salaire (AE non assurable) <nn> est fournie. » (19X004PR10193) 

### Info

Source topic: `fr_FR/common_notes/note_c_0752.dita`

Message d’erreur : « La date de début des indemnités d’assurance salaire (AE non assurable) doit être postérieure au dernier jour payé <LDFWP>. » (19X004SD10197) 

### Info

Source topic: `fr_FR/common_notes/note_c_0753.dita`

Message d’erreur : « Le premier jour de travail et/ou le dernier jour payé fourni sur ce RE chevauche un autre RE soumis pour cet employé(e). » (9900000010412)

Un RE portant le même numéro d’entreprise que celui figurant dans un autre RE a été émis et ils ont des dates qui se chevauchent.

Cette erreur peut survenir lorsqu’un employeur émet un RE subséquent pour modifier un RE antérieur mais n’inclut pas le numéro de série du RE à modifier dans la case 2 du RE subséquent.

Cette erreur peut également survenir lorsqu’un employeur émet un RE subséquent dont la date du premier jour de travail est identique à celle figurant dans un RE antérieur. Le RE subséquent peut donc contenir des heures et des montants de rémunération qui se trouvent déjà dans le RE antérieur, ce qui peut entraîner une erreur liée à l’admissibilité à des prestations. Le premier jour de travail qui figure dans le RE subséquent doit être corrigé afin d’indiquer le premier jour de travail depuis que le RE antérieur a été émis. L’agent doit aussi vérifier que les heures et les montants de rémunération du RE antérieur ne sont pas inclus dans le RE subséquent.

Même si ce message est généralement dû à une erreur qui survient lorsqu’on remplit le RE, le chevauchement se produit parfois parce qu’un employé occupe 2 différents emplois chez un même employeur (p. ex. le client travaille pendant la journée comme réceptionniste d’école et travaille pour le même employeur en soirée comme concierge). Lorsque cette situation se produit et que l’employeur le confirme, les dates indiquées dans les RE sont exactes. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0754.dita`

Remarque :

Si le premier jour de travail du RE subséquent est incorrect, le RE doit être vérifié afin de confirmer que les montants d’heures et de la rémunération indiqués dans le RE subséquent sont exacts. Les corrections sont apportées au besoin. 
