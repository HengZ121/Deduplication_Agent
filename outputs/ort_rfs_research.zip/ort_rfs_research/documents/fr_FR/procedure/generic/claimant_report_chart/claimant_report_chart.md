# Déclaration du prestataire : Procédures liées aux éléments de la déclaration du prestataire — Instructions

Source map: `fr_FR/procedure/generic/claimant_report_chart/claimant_report_chart.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/claimant_report_chart/generic.dita`

```text
| Déclaration du client | Mesure à prendre |

| hors Canada | Consulter la procédure Hors Canada , puis revenir à ce tableau. [Hors Canada](/fr/procedure/activity/out_canada.shtml) |

| travail et rémunération | Consulter toutes les procédures suivantes qui s’appliquent pour savoir s’il y a d’éventuelles exclusions, puis revenir à ce tableau. - Travail à temps partiel [Travail à temps partiel](/fr/procedure/task/availability_pt.shtml) - Non en chômage [Non en chômage](/fr/procedure/activity/not_unemployed.shtml) - Travail autonome [Travail autonome](/fr/procedure/activity/self_employed.shtml) - Travail agricole [Travail agricole](/fr/procedure/activity/self_employed.shtml#agricole) [Travail à temps partiel](/fr/procedure/task/availability_pt.shtml) [Non en chômage](/fr/procedure/activity/not_unemployed.shtml) [Travail autonome](/fr/procedure/activity/self_employed.shtml) [Travail agricole](/fr/procedure/activity/self_employed.shtml#agricole) |

| arrêt de travail | Consulter toute procédure sur les motifs de cessation d’emploi applicable, puis revenir à ce tableau. - Congédiement [Congédiement](/fr/procedure/activity/dismissal.shtml) - Départ volontaire [Départ volontaire](/fr/procedure/activity/voluntary_leaving.shtml) [Congédiement](/fr/procedure/activity/dismissal.shtml) [Départ volontaire](/fr/procedure/activity/voluntary_leaving.shtml) |

| formation | Consulter la procédure sur la formation applicable, puis revenir à ce tableau. - Formation dirigée [Formation dirigée](/fr/procedure/activity/training.shtml#cfd) - Formation d'apprenti [Formation d'apprenti](/fr/procedure/activity/training.shtml#fea) - Formation non dirigé [Formation non dirigé](/fr/procedure/activity/training.shtml) [Formation dirigée](/fr/procedure/activity/training.shtml#cfd) [Formation d'apprenti](/fr/procedure/activity/training.shtml#fea) [Formation non dirigé](/fr/procedure/activity/training.shtml) |

| non disponible | Consulter toutes les procédures suivantes qui s’appliquent pour savoir s’il y a d’éventuelles exclusions, puis revenir à ce tableau. - Disponibilité [Disponibilité](/fr/procedure/activity/availability.shtml) - Non autrement disponible [Non autrement disponible](/fr/procedure/task/no_available.shtml) - Vacances au Canada [Vacances au Canada](/fr/procedure/activity/vacation.shtml) - Procédures de conversion (p. ex. si le client reçoit des prestations régulières et n’est pas disponible pour travailler, déterminer si d’autres prestations s’appliquent à sa situation) [conversion](/fr/procedure/activity/conversions.shtml) [Disponibilité](/fr/procedure/activity/availability.shtml) [Non autrement disponible](/fr/procedure/task/no_available.shtml) [Vacances au Canada](/fr/procedure/activity/vacation.shtml) [conversion](/fr/procedure/activity/conversions.shtml) |

| maladie | Consulter la procédure Conversion à des prestations de maladie , puis revenir à ce tableau. [Conversion à des prestations de maladie](/fr/procedure/activity/conversions.shtml) |

| autres sommes | Consulter la procédure Rémunération , puis revenir à la procédure sur la déclaration du prestataire pour effectuer la saisie des données. *Si une répartition est saisie, les sommes déclarées ne sont pas codées dans la déclaration. [Rémunération](/fr/procedure/activity/earnings.shtml) |
``` 
