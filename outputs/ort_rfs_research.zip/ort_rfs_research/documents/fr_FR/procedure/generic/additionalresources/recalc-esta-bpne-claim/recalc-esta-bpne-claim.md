# Calculer à nouveau et établir des demandes PPNE : Litige en attente de traitement dans la période de prestations — Instructions

Source map: `fr_FR/procedure/generic/additionalresources/recalc-esta-bpne-claim/recalc-esta-bpne-claim.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/recalc-esta-bpne-claim/ressources_additionnelles.dita`

Sommaire : Au moment d’établir une demande PPNE au moyen d’un nouveau calcul, l’agent détermine s’il y a un litige lié au motif de cessation d’emploi (MCE) en attente de traitement dans la période de prestations (PP) et si une décision est requise.

**Ce qu’il faut savoir**

Quand la question litigieuse dans une demande PPNE qui peut être établie au moyen d’un nouveau calcul est un MCE dans la PP, l’agent peut effectuer le calcul et n’a pas besoin de déplacer l’AT Révision de la demande (RVD) Nouveau calcul PPNE vers En suspens en attendant une décision. Si des conditions précises sont remplies, une décision sur le MCE litigieux n’est pas requise. Si les conditions ne sont pas remplies, un traitement manuel 75 - Vérification du motif de cessation d’emploi (TM75) et un AT Révision de la demande (RVD) Révisée sont requis.

L’agent doit consulter les procédures de nouveau calcul, au besoin.

**Décision non requise pour un motif de cessation d’emploi (MCE) litigieux dans la période de prestations (PP)**

Si l’agent détermine qu’il y a un MCE litigieux dans la PP lors du nouveau calcul d’une demande PPNE 1 - Nombre insuffisant d’heures assurables (N1), 2 - Dernier relevé d’emploi manquant (N2) ou 5 - Nombre insuffisant d’heures assurables / rémunération pêcheurs (N5), aucune décision, aucun AT RVD et aucun rapport de décision (RD) ne sont requis si :

- la date de l’événement lié au MCE litigieux est dans la PP;

- l’ une des conditions suivantes est remplie :

- Le client ne demande pas de prestations à partir de la semaine du MCE litigieux.

- Le client n’ est pas admissible aux prestations régulières à partir du DPP en raison d’une décision sur un MCE litigieux.

**Dernier jour de travail (DJT) ou la date de l’événement lié au motif de cessation d’emploi (MCE) litigieux est dans la période de prestations (PP)**

Le premier jour de travail lié à l’emploi avec le MCE litigieux peut être pendant la période de référence (PR) ou dans la PP. Le fait que le premier jour de travail soit pendant la PR ou la PP n’a aucune incidence sur la décision sur le MCE litigieux dans la PP.

Quand le premier jour de travail est pendant la PR et que le DJT est dans la PP, le Calcul d’assurance-chômage (CAC) tient compte des heures travaillées et de la rémunération sur le RE qui sont dans la PR.

Si les conditions sont remplies pour ne pas rendre une décision sur le MCE litigieux dans la PP, l’agent peut devoir modifier la case Condition Spéciale du RE dans MSRE du MCE litigieux dans la PP à Inconduite - Non prouvée ou Départ volontaire - motif valable , selon le cas. Cette mesure est nécessaire quand il y a un RE dans la PR qui a été exclu du calcul, pour assurer que le résultat du nouveau calcul affiché dans la version Web de SSA est le bon. Une fois que les transactions du nouveau calcul ont été saisies, l’agent modifie la case Condition Spéciale du RE lié au MCE litigieux dans la PP à Vide .

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0571.dita) 

**Client ne demandant pas de prestations à partir de la semaine du motif de cessation d’emploi (MCE) litigieux**

Les renseignements au dossier indiquant que le client ne demande pas de prestations comprennent les suivants :

- Dans ETI, il n’y a pas de déclarations du prestataire en attente de traitement à l’onglet Paiements ni de déclarations du prestataire rejetées à l’onglet Déclarations-E pour la semaine du DJT et après.

- Il n’y a pas de demande de renouvellement ni de nouvelle demande au dossier, et le client n’a pas communiqué avec Service Canada pour demander des renseignements par rapport à la demande.

**Client non admissible aux prestations régulières à partir du DPP en raison d’une décision déjà rendue sur un motif de cessation d’emploi (MCE) litigieux**

Si le client n’est pas admissible aux prestations régulières en raison d’une exclusion 10 - Congédiement - inconduite prouvée (D10) ou 11 - Abandon volontaire — motif valable non prouvé (D11) imposée à partir du DPP dans une demande régulière en raison d’une décision, l’agent ne crée pas d’AT RVD pour un MCE litigieux dans la PP.

**Motif de cessation d’emploi (MCE) litigieux dans la période de prestations (PP) quand les conditions sont remplies et un AT Révision de la demande (RVD) Révisée n’est pas requis**

Quand les conditions ci-dessus sont remplies, l’agent ne crée pas d’AT RVD Révisée et ne rend pas de décision sur le MCE litigieux dans la PP.

Si un AT RVD Révisée a déjà été créé pour demander une décision sur le MCE litigieux dans la PP, l’agent envoie un courriel à son chef d’équipe pour lui demander de supprimer l’AT RVD.

**Traiter l’AT Révision de la demande (RVD) Nouveau calcul PPNE si les conditions ne sont pas remplies et qu’un AT Révision de la demande (RVD) est requis**

S’il y a un MCE litigieux dans la PP qui nécessite une décision de Niveau 2 pour une demande PPNE N2 et qu’il y a des déclarations du prestataire en attente de traitement, l’agent impose une inadmissibilité indéterminée 15 - Procédure de présentation des demandes (D15) à partir du lundi de la semaine de l’événement litigieux pour que le client ne reçoive pas de versement à partir de cette semaine. Une fois la décision rendue, l’agent de Niveau 2 annule l’inadmissibilité D15.

Si les conditions ne sont pas remplies dans tous les autres cas, l’agent traite le nouveau calcul sur une période de 2 jours. Le jour 1, l’agent effectue un nouveau calcul pour établir la demande et pour traiter les déclarations des prestataires en attente de traitement ou rejetés jusqu’à la semaine du MCE litigieux, sans l’inclure. Le jour 2, l’agent impose un traitement manuel TM75 pour arrêter les versements jusqu’à ce que la décision soit rendue. L’agent ne déplace pas l’AT RVD PPNE - Nouveau calcul vers En suspens jusqu’à ce que la décision soit rendue.

**Déclarations du prestataire en attente de traitement, déclarations du prestataire rejetées et aide-mémoires sur les déclarations du prestataire**

Le client peut avoir rempli des déclarations du prestataire liées à la demande PPNE.

Quand la demande a déjà été finalisée PPNE N2 et que le client a rempli des déclarations du prestataire, elles s’affichent dans ETI à l’onglet Paiements . Les déclarations du prestataire ne s’affichent pas comme étant rejetées dans ETI à l’onglet Déclaration-E ou à l’écran Historique des déclarations-é (MD01) . Le client peut continuer à remplir les déclarations du prestataire après que la demande a été finalisée PPNE N2. Lors du nouveau calcul d’une demande PPNE N2, si la semaine du DPP commence avant celle qui s’affiche dans ETI, les déclarations du prestataire en attente de traitement sont rejetées le jour ouvrable suivant.

Si la demande a précédemment été finalisée PPNE N1 ou N5 et que le client a rempli des déclarations du prestataire, elles s’affichent comme étant rejetées dans ETI à l’onglet Déclaration-E ou à l’écran MD01.

Si le client n’ a pas rempli des déclarations du prestataire ou quand elles n’ont pas pu être mises à jour en raison du calcul initial PPNE, un agent peut avoir rempli un aide-mémoire sur les déclarations du prestataire. Dans ETI, l’agent traitant l’AT RVD PPNE - Nouveau calcul saisit les déclarations du prestataire qui sont dans l’aide-mémoire sur les déclarations du prestataire.

Si des déclarations du prestataire ont été rejetées à la suite du calcul initial PPNE N1 ou N5, dans ETI, l’agent traitant l’AT RVD PPNE - Nouveau calcul saisit les déclarations du prestataire rejetées.

**Reporter la décision — Client admissible aux prestations spéciales et exclusion ou inadmissibilité administrative46 - Ne rencontre pas la norme variable - prestations spéciales payables(D46) au dossier**

Si une exclusion D10 ou D11, ou une inadmissibilité administrative D46 est imposée à partir du DPP et que le client demande des prestations spéciales, la décision sur un MCE litigieux dans la PP peut être reportée. L’agent consulte Reporter la décision : Demande établie courante .
       [Reporter la décision : Demande établie courante](/fr/procedure/task/deferring_adj_current_claim.shtml)

**Étape par étape**

- Déterminer si une des conditions suivantes est remplie :

- Le client ne demande pas de prestations à partir de la semaine du MCE litigieux.

- Le client n’ est pas admissible aux prestations régulières à partir du DPP en raison d’une décision sur un MCE litigieux.

- Si oui, passer à l’étape 2.

- Si non, une décision est requise. Passer à l’étape 13.

- Effectuer une des mesures suivantes selon la demande :

- Si la demande est établie pour des prestations régulières ou des prestations spéciales et qu’ aucune exclusion D10 ou D11, ou aucune inadmissibilité administrative D46 n’ est imposée à partir du DPP, passer à l’étape 3.

- Dans la version Web de SSA, effectuer le nouveau calcul pour déterminer si la transaction M161 - Exclusions/Inadmissibilités (M161) avec une exclusion D10 ou D11 est générée selon le MCE litigieux dans la PP :

- Dans SNCT, déterminer s’il y a un RE dans la PR qui a été refusé antérieurement et qui devrait être exclu du calcul de la demande.

- Si oui, passer à l’étape 5.

- Si non, consulter les procédures appropriées de nouveau calcul pour saisir les transactions du nouveau calcul dans la version Web de SSA.

- Lors de la saisie des transactions, choisir Supprimer pour supprimer la transaction M161 - Exclusions/Inadmissibilités (M161) créée par la version Web de SSA. Passer à l’étape 7.

- Dans MSRE, modifier la case Condition spéciale du RE avec le MCE litigieux dans la PP à Inconduite - Non prouvée ou Départ volontaire - motif valable , selon le cas. Consulter les procédures pour saisir les transactions de nouveau calcul dans la version Web de SSA. Ensuite, passer à l’étape 6.

- Une fois que les transactions de nouveau calcul ont été saisies, modifier la case Condition spéciale du RE avec un MCE litigieux dans la PP à Vide . Passer à l’étape 7.

- Dans ETI, à l’onglet En Suspens/Rejet , déterminer si des déclarations du prestataire ont été rejetées :

- Si non, passer à l’étape 8.

- Si oui, passer à l’étape 9.

- Dans SNCT, déterminer si un aide-mémoire sur les déclarations du prestataire a été rempli :

- Si oui, passer à l’étape 9.

- Si non, passer à l’étape 10.

- Consulter Déclaration du prestataire pour saisir dans ETI les déclarations du prestataire rejetées ou les déclarations du prestataire qui sont dans l’aide-mémoire sur les déclarations du prestataire. Passer à l’étape 10.
         [Déclaration du prestataire](/fr/procedure/activity/claimant_report.shtml)

- Dans SNCT, déterminer si un AT RVD Révisée a déjà été créé pour demander une décision sur le même MCE litigieux dans la PP :

- Dans ETI, déterminer s’il y a un numéro d’enregistrement révisé lié à l’AT RVD Révisée :

- Si non, passer à l’étape 12.

- Si oui, dans ETI, choisir la transaction Numéro d’enregistrement (M025, M030, M035) et annuler le numéro d’enregistrement révisé de la façon suivante :

- Action : Choisir Annuler .

- Choisir Mise à jour .

- Passer à l’étape 12.

- Dans Outlook, envoyer un courriel à votre chef d’équipe pour demander la suppression de l’AT RVD Révisée de la façon suivante :

- Objet : Saisir « Suppression d’un AT ».

- Dans le corps du message, saisir :
             [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0572.dita)

- Passer à l’étape 24.

- Dans SNCT, déterminer s’il y a déjà un AT RVD pour la décision requise :

- Si oui et l’AT RVD Révisée est au Niveau 1, réassigner l’AT RVD à vous-même. Passer à l’étape 15.

- Si oui et l’AT RVD Révisée est au Niveau 2, passer à l’étape 16.

- Si non, dans ETI, choisir la transaction Numéro d’enregistrement (M025, M030, M035) et assigner le numéro d’enregistrement de la façon suivante :

- Action : Choisir Attribuer .

- Origine de la demande : Choisir 3 - Poste/Décision révisée .

- Unité de service : Choisir 1 .

- Genre de décision : Choisir 3 - Révisée .

- Créer un article de travail : Ne pas cocher la case.

- Choisir Mise à jour .

- Passer à l’étape 14.

- Dans SNCT, pour chaque litige qui nécessite une décision dans la PP sans un AT, créer un AT RVD Révisée de la façon suivante :

- Genre : Choisir Révisée .

- Numéro d’enregistrement : Saisir le numéro d’enregistrement révisé.

- Complexité : Choisir Niveau 1 .

- Langue : Choisir l’option appropriée.

- CSC : Choisir le Centre Service Canada (CSC) qui s’affiche dans ETI.

- DPP : Saisir le DPP de la demande à calculer à nouveau.

- Date d’enregistrement : Saisir la date de création du numéro d’enregistrement révisé.

- Détails : Saisir les détails de la question litigieuse qui nécessite une décision.

- Choisir Sauvegarder .

- Réassigner l’AT RVD à vous-même.

- Passer à l’étape 15.

- Déterminer si la décision relève de votre autorité en consultant la tâche de décision appropriée :

- Si non, réassigner chaque AT RVD Révisée de la façon suivante :

- Destination : Choisir Prochain utilisateur disponible .

- Complexité : Choisir l’option appropriée.

- Motif : Choisir Impossible de compléter .

- Détails : Saisir « Ne relève pas de l’autorité de l’agent. »

- Choisir OK .

- Passer à l’étape 16.

- Si oui, suivre la tâche appropriée pour rendre une décision sur le litige en attente de traitement. Consulter les procédures appropriées de nouveau calcul pour saisir les transactions du nouveau calcul dans la version Web de SSA et passer à l’étape 24.

- Dans la version Web de SSA, calculer la demande pour déterminer si la transaction M161 - Exclusions/Inadmissibilités (M161) avec une exclusion D10 ou D11 est générée selon le MCE litigieux dans la PP :

- Si oui, passer à l’étape 17.

- Si non, passer à l’étape 19.

- Dans SNCT, déterminer s’il y a un RE dans la PR qui a été refusé antérieurement et qui devrait être exclu du calcul de la demande.

- Si oui, passer à l’étape 18.

- Si non, lors de la saisie des transactions de nouveau calcul, choisir Supprimer pour supprimer la transaction M161 - Exclusions/Inadmissibilités (M161) créée par la version Web de SSA. Passer à l’étape 19.

- Dans MSRE, modifier la case Condition spéciale du RE avec un MCE litigieux dans la PP à Inconduite - Non prouvée ou Départ volontaire - motif valable , selon le cas. Passer à l’étape 19.

- Déterminer la situation qui s’applique :

- Pour l’établissement d’une demande PPNE N2 quand le client a rempli des déclarations du prestataire pour la semaine du MCE litigieux, suivre les directives suivantes :

- Dans la version Web de SSA, effectuer le nouveau calcul. Consulter les procédures appropriées de nouveau calcul, au besoin. Si la version Web de SSA créé la transaction M161 - Exclusions/Inadmissibilités (M161) , choisir Supprimer pour supprimer la transaction.

- Le même jour, dans ETI, imposer une inadmissibilité administrative D15 à partir du lundi de l’événement litigieux pour arrêter les versements jusqu’à ce que la décision soit rendue.

- Créer une note pour l’agent de Niveau 2 expliquant que l’inadmissibilité D15 est imposée pour arrêter les versements jusqu’à ce que la décision soit rendue et qu’une fois la décision rendue, l’agent de Niveau 2 doit annuler l’inadmissibilité D15.

- Passer à l’étape 24.

- Pour l’établissement d’une demande PPNE N1 ou N5 ou une demande PPNE N2 quand le client n’a pas rempli de déclarations du prestataire pour la semaine du MCE litigieux, suivre les directives suivantes :

- Dans la version Web de SSA, le jour 1, effectuer le nouveau calcul. Consulter les procédures appropriées de nouveau calcul, au besoin.

- Si la version Web de SSA créé la transaction M161 - Exclusions/Inadmissibilités (M161) , choisir Supprimer pour supprimer la transaction.

- Passer à l’étape 20.

- Suivre les directives suivantes :

- Dans ETI, saisir les déclarations du prestataire rejetées ou celles qui sont dans l’aide-mémoire sur déclarations du prestataire jusqu’à la semaine avant le MCE litigieux. Pour plus de renseignements, consulter Saisir une déclaration du prestataire . Passer à l’étape 21.
             [Saisir une déclaration du prestataire](/fr/procedure/task/inputting_cr.shtml)

- Dans SNCT, déplacer l’AT RVD PPNE - Nouveau Calcul vers En suspens de la façon suivante :

- Motif de la mise en suspens : Choisir Autre .

- Commentaires : Saisir « Saisies sur 2 jours. »

- Date à revoir : Saisir la date d’aujourd’hui + un jour ouvrable.

- Passer à l’étape 22.

- Dans ETI, le jour 2, choisir la transaction Renouvellement/Révisé (M106) et imposer un traitement manuel TM75 pour arrêter les versements de la façon suivante :

- Numéro d’enregistrement : Laisser ce champ vide. Si un numéro s’affiche, le supprimer.

- Traitement manuel : Choisir 75 - Vérification du motif de cessation d’emploi .

- Choisir Mise à jour .

- Passer à l’étape 23.

- Dans MSRE, si la case Condition spéciale du RE avec un MCE litigieux dans la PP a été précédemment modifié à Inconduite - Non prouvée ou Départ volontaire - motif valable , la modifier à Vide .

- Compléter l’AT RVD PPNE - Nouveau calcul. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0571.dita`

Remarque :

Parfois, les employeurs présentent des RE modifiés avec le même DJT, mais le MCE est devenu litigieux quand un employé a une cessation d’emploi permanente pendant un arrêt de travail temporaire. Dans ces cas, il est important de déterminer dans quelle semaine l’événement litigieux s’est produit avant de suivre les directives suivantes. La semaine de l’événement litigieux détermine la répartition appropriée des indemnités de cessation d’emploi, versés à une date précise. Dans tous les cas, l’agent doit effectuer un recueil de faits. 

### Callout

Source topic: `fr_FR/common_notes/note_c_0572.dita`

« NAS [NAS du client] AT à supprimer : AT RVD Révisée créé le [date de création de l’AT]. Raison de la suppression : Aucune décision n’est requise. » 
