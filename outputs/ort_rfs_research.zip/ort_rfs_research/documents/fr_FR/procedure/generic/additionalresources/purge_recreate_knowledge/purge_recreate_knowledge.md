# Suppression et recréation : Renseignements liés à la suppression d’une demande, aux rapports SDE et aux données complémentaires de SASR — Guide de saisie

Source map: `fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge/purge_recreate_knowledge.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge/ressources_additionnelles.dita`

- Supprimer une demande
         [Supprimer une demande](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#Supprimerunedemande)

- Rapport de S/R dans SDE
         [Rapport de S/R dans SDE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#RapportsdeSR)

- Données complémentaires des prestations spéciales

- Données complémentaires des prestations spéciales qui nécessitent des modifications
             [Données complémentaires des prestations spéciales qui nécessitent des modifications](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#Donneescomplementairesdes1)

- Données complémentaires du RQAP
             [Données complémentaires du RQAP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#Donneescomplementairesdu)

- Établissement et modification des données complémentaires pour les PDC
             [Établissement et modification des données complémentaires pour les PDC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#etablissementetmodification)

- Établissement et modification des données complémentaires pour les prestations pour proches aidants
             [Établissement et modification des données complémentaires pour les prestations pour proches aidants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#prestations_pour_proches_aidants)

- Données complémentaires des prestations spéciales pour les travailleurs indépendants
             [Données complémentaires des prestations spéciales pour les travailleurs indépendants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#Donneescomplementairesdes2)

         [Données complémentaires des prestations spéciales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#Donneescomplementairesdes)

- Données complémentaires des initiatives d’emploi

- Cours de formation non dirigé
             [Cours de formation non dirigé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#coursformation_nondirige)

- Cours de formation dirigé
             [Cours de formation dirigé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#coursformation_dirige)

- Formation en apprentissage
             [Formation en apprentissage](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#formation_apprentissage)

- Programme prestations d’emploi pour travailleurs indépendants
             [Programme prestations d’emploi pour travailleurs indépendants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#programme_empoi_travailleursind)

- Programme de création d’emploi
             [Programme de création d’emploi](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#programme_création)

- Travail partagé (TP)
             [Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#travail_partage_tp)

         [Données complémentaires des initiatives d’emploi](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#donnees_complementaires)

- Travailleurs saisonniers
         [Travailleurs saisonniers](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#travailleurs-saisonniers)

- Demande recréée avec succès
         [Demande recréée avec succès](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#demandesrecreessucces)

- Demande recréée avec des erreurs ou omissions

- Transactions en ligne
             [Transactions en ligne](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#Transactionsenligne)

- La demande doit être supprimée de nouveau
             [La demande doit être supprimée de nouveau](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#Lademandedoit)

         [Demande recréée avec des erreurs ou omissions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/purge_recreate_knowledge#demandesrecreessanssucces)

**Supprimer une demande**

Il y a 2 transactions dans ETI qui suppriment une demande active ou une demande inactive non bloquée de SIP :

- Suppression et recréation - ajustement (Utilisé par le COPA) (M101-8) : Pour supprimer un NAS à la fois.

- Données multiples de contrôle des fichiers de genre 8 - Suppression et recréation - ajustement (T111-8) : Pour supprimer plusieurs NAS à la fois.

Il y a des situations pour lesquelles, au lieu de supprimer la demande, l’agent du COPA doit utiliser la transaction Annulation de demande au Système informatisé de paiement (Utilisé par le COPA) (M101-5) ou la transaction T111 de genre 5 - Annulation de la demande du Système informatisé de paiement (T111-5) pour attribuer à la demande l’état 8 - Convertie au système manuel de paiement . Celles-ci incluent, entre autres, les situations suivantes :

- Une mesure dans une demande de base.

- Une postdate (quand des semaines ont été payées entre l’ancien et le nouveau DPP).

- Une postdate précédente saisie dans SIP.

**Rapports de S/R dans SDE**

Voici une liste des rapports qui sont utilisés pendant S/R :

```text
| Nom du rapport | Description |

| SD5442 [SD5442](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#SD5442) | S/R feuille de travail |

| SD5641 [SD5641](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#SD5641) | Relevés de prestations payées (RPP) des DIST-0080 et 0090 |

| SB1641 [SB1641](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#SB1641) | Prestataires du SMP (Montants du fichier d’impôt SMP) |

| SR1041 [SR1041](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#SR1041) | Liste d’erreurs (rejets de SASR) |

| SD5641SR10 [SD5641SR10](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#SD5641SR10) | Mini RPP de vérification (DIST-0008, 0078, 0508 et 0578) |
```

**SD5442 (S/R feuille de travail)**

La S/R feuille de travail est une reproduction de toutes les données d’une demande supprimée comme elles apparaissent dans SASR. L’agent du COPA utilise cette feuille de travail pour déterminer les modifications à apporter à la demande et effectuer le suivi des modifications qui doivent être saisies dans SASR. Une version électronique de cette feuille de travail est aussi disponible.

**SD5641 (DIST-0090 et DIST-0080)**

Le DIST-0090, comme la S/R feuille de travail, affiche tous les renseignements dans une demande au moment de sa suppression, mais dans le format du RPP traditionnel.

Le DIST-0080 est généré quand une demande recréée est retournée dans SIP avec succès. Le DIST-0080 contient les nouveaux renseignements tels que saisis dans la demande dans SASR. Ils sont identiques aux renseignements figurant dans la demande dans ETI.

**SB1641 (Prestataires du SMP)**

Quand une demande est supprimée de SIP, tous les montants cumulatifs de l’année sont déplacés de SIP vers SMP et apparaissent dans le Fichier d’impôt SMP. Quand des modifications qui doivent être apportées à l’AT COPA Suppression et recréation dans SASR ont une incidence sur les montants cumulatifs de l’année, l’agent du COPA doit ajuster manuellement le fichier d’impôt avant de recréer la demande dans SIP. Si une demande est traitée dans SASR, mais que le Fichier d’impôt SMP contient des erreurs, une erreur fiscale est engendrée.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0552.dita) 

**SR1041 (Liste d’erreur)**

Si un agent du COPA tente de renvoyer une demande dans SIP mais que les exigences de révision ne sont pas remplies, une Liste d’erreur est générée au lieu d’un Mini, et d’autres modifications doivent être apportées dans SASR. La Liste d’erreur fournit les indicatifs d’erreur appropriés, qui sont décrits dans SIEW. Quand il recherche la description de l’indicatif d’erreur dans SIEW, l’agent du COPA doit saisir « S » avant l’indicatif à 3 chiffres. Pour plus de renseignements sur SIEW, l’agent du COPA consulte Système d’indicatifs d’erreur sur le Web (SIEW) .
       [Système d’indicatifs d’erreur sur le Web (SIEW)](http://wecs-siew.prv/home_f.aspx)

**SD5641SR10 (Mini)**

Le Mini fournit un aperçu des résultats de la mise à jour manuelle prévue quand des saisies telles qu’une transaction Renouvellement/Révisé (M106) ont été effectuées dans SIP. Le tableau suivant décrit chaque numéro de distribution de Mini.

```text
| Mini 0008 | Le résultat proposé ne créera pas de nouveau trop-payé (T-P) et n’émettra pas de moins-payé (M-P) si la transaction M106 est saisie, mais peut entraîner l’annulation d’un T-P ou d’autres modifications de la demande. |

| Mini 0078 | Le résultat proposé est la création d’un T-P pour la demande si la transaction M106 est saisie. |

| Mini 0508 | Le résultat proposé est la création d’un M-P pour la demande si la transaction M106 est saisie. |

| Mini 0578 | Le résultat proposé est la création d’un T-P et d’un M-P si la transaction M106 est saisie. |
```

Le numéro de Mini ne suffit pas à établir l’exactitude de la demande recréée. Le Mini doit être examiné en détail et, parfois, comparé au DIST- 0080.

Quand les modifications apportées à la demande sont valides et saisies correctement dans SASR, les résultats du Mini devraient correspondre aux attentes de l’agent du COPA. L’agent du COPA examine toutes les modifications imprévues apportées à la demande sur le Mini et planifier les mesures correctives qui pourraient devoir être prises pour résoudre le problème. Par exemple, l’agent du COPA examine l’année d’imposition associée à l’établissement ou à la modification d’un T-P sur le Mini. L’établissement d’un T-P dans une année fiscale non valide n’est pas rejeté dans le SR1041 (liste d’erreurs). Par conséquent, l’agent du COPA identifie ce résultat inattendu et corrige le dossier avant de faire un nouveau calcul de la demande pour éviter l’établissement d’un T-P incorrect dans PSCD.

**Données complémentaires des prestations spéciales**

Les agents consultent les tableaux suivants sur les prestations spéciales, au besoin :

**Données complémentaires des prestations spéciales qui nécessitent des modifications**

```text
| GP spéciales AE | Données complémentaires et colonnes du SASR | Modifications requises | Mesures supplémentaires |

| Maternité | IT80-2 : DPA (colonne 23) DRA (colonne 27) DB MAT (colonne 31) FIN MAT (colonne 35) EXT MAT (colonne 39) SEM MAT (colonne 40) | - Pour changer le début ou la fin des prestations de maternité, saisir la s/c et, au besoin, remplir le champ EXT MAT . - Si des prestations de maternité sont encore versées, le champ FIN MAT demeure DPA ou DRA + 17 semaines (selon l’option qui offre la plus grande période). - Si moins de 15 semaines de prestations de maternité sont payables et que le nombre de semaines d’admissibilité est atteint avant DPA ou DRA + 17, saisir la s/c de la dernière semaine de prestations de maternité payables dans le champ FIN MAT et saisir l’indicatif 2 - Semaine de fin reportée dans le champ EXT MAT . - Si le nombre de semaines d’admissibilité aux prestations de maternité est atteint, la fin correspond à la s/c de la dernière semaine pendant laquelle des prestations de maternité ont été versées. | Pour obtenir des renseignements supplémentaires sur les données complémentaires de SASR, consulter la Liste de données complémentaires de la suppression et recréation . [Liste de données complémentaires de la suppression et recréation](http://wecs-siew.prv/wecs-siew/reflookup_f.aspx) |

| Parentales | IT80-1 : SEX (colonne 70) IT80-2 : ACT (colonne 42) PAR DEB (colonne 46) PAR FIN (colonne 50) PAR SEM (colonne 54) PAR ENT (colonne 56) PAR IND (colonne 58) IT81-2 : PAR PROL (colonne 92) | Remplir ou modifier la semaine de début des prestations parentales de la façon suivante : - Pour une nouvelle demande de prestations parentales, saisir la s/c du DPP. - Pour un DPP renouvelé pour des prestations parentales, saisir la s/c du renouvellement. - Si des prestations de maternité ont été versées au complet et que des prestations parentales doivent être versées immédiatement après, saisir la s/c suivant la dernière semaine pendant laquelle des prestations de maternité ont été versées. - Si des prestations de maternité sont encore versées et que des prestations parentales doivent être versées immédiatement après, saisir « 9999 ». Remplir ou modifier la semaine de fin des prestations parentales de la façon suivante : - Pour l’admissibilité continue aux prestations parentales, saisir la semaine d’arrivée ou de placement + 52 semaines (si l’indicatif lié aux prestations parentales prolongées est vide [IT81-2 colonne 92]) ou 78 semaines (si l’indicatif lié aux prestations parentales prolongées est 1) + prolongation de genre H + prolongation de la PP pour des prestations spéciales. La prolongation de la PP pour les prestations spéciales s’applique seulement après la fin de la PP initiale. - Si le nombre de semaines d’admissibilité aux prestations parentales est atteint, la fin correspond à la s/c de la dernière semaine pendant laquelle des prestations parentales ont été versées. - Si le nombre de semaines d’admissibilité aux prestations parentales n’est pas atteint, mais que la demande est renouvelée pour un autre GP, saisir la s/c avant celle du renouvellement et saisir l’indicatif 3 - Parentales terminées dans le champ PAR IND . - Si la semaine de début des prestations parentales est 9999, saisir « 9999 » pour la semaine de fin des prestations parentales. Si aucune prestation parentale n’a été versée, mais que le champ PAR ENT est rempli, saisir « 00 » dans le champ PAR SEM . Si une prolongation de la PP pour des prestations spéciales s’applique et que la PP initiale est terminée, choisir l’indicatif 5 - Durée en parentales/Spécial maximum et prolonger la semaine de fin des prestations parentales du nombre de semaines approprié. Si des prestations parentales prolongées s’appliquent, choisir 1 dans le champ Prestations parentales prolongées . Si un retour des prestations parentales prolongées aux prestations parentales standards s’applique, laisser le champ Prestations parentales prolongées vide. | Quand des prestations parentales sont versées ou ont été versées pour une demande, l’indicatif de sexe doit être l’un des suivants : - 5 - Parentales, père adoptif - 6 - Parentales, mère adoptive - 7 - Parentales, père naturel - 8 - Parentales, mère naturelle Une fois que l’indicatif de sexe est modifié pour des prestations parentales, l’indicatif reste le même pendant toute la durée de la demande, peu importe le GP versé. Si l’indicatif 5 est saisi dans le champ PAR IND (colonne 58) des données complémentaires IT80-2, saisir les renseignements appropriés dans le champ SM (colonne 88) correspondant et la nouvelle PP FIN (colonne 14) dans les données complémentaires IT81-2. Consulter Prolongation de la période de prestations pour des prestations spéciales . [Prolongation de la période de prestations pour des prestations spéciales](/fr/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml) Pour obtenir des renseignements supplémentaires sur les données complémentaires de SASR, consulter la Liste de données complémentaires de la suppression et recréation . [Liste de données complémentaires de la suppression et recréation](http://wecs-siew.prv/wecs-siew/reflookup_f.aspx) [Prolongation de la période de prestations pour des prestations spéciales](/fr/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml) [Liste de données complémentaires de la suppression et recréation](http://wecs-siew.prv/wecs-siew/reflookup_f.aspx) |

| Maladie | IT80-2 : SEM MAL (colonne 59) SEM GUE (colonne 61) MAL OCC (colonne 89) | Quand des prestations de maladie sont versées pour une demande, mais que ces prestations seront automatiquement converties en prestations de maternité à la semaine de début de la période de maternité, saisir « 9999 » dans le champ SEM GUE . Quand des semaines de prestations de maladie occasionnelle ont été payées, saisir le nombre de semaines payées. Le compteur dans le champ MAL OCC doit être vide ou afficher un nombre de 1 à 8 pour correspondre au nombre équivalent de semaines de prestations de maladie occasionnelle payées qui ont été initialement traitées à la s/c 2385-5 ou après. | Pour obtenir des renseignements supplémentaires sur les données complémentaires de SASR, consulter la Liste de données complémentaires de la suppression et recréation . [Liste de données complémentaires de la suppression et recréation](http://wecs-siew.prv/wecs-siew/reflookup_f.aspx) |

| PDC | IT81-1 : SEM PC (colonne 111-112) IT86-4 : SEM TRAI (colonne 15) JR (colonne 45) CERT MED (colonne 46) DEB (colonne 56) FIN (colonne 60) ADM (colonne 64) MOD (colonne 66) | Quand des PDC ont été payées ou sont payables, des données complémentaires IT86-4 sont nécessaires pour établir l’admissibilité et la FC complète de 52 semaines. D’autres données complémentaires IT86-4 sont créées chaque fois que l’admissibilité change ou quand le client passe des PDC à un autre GP. Des données complémentaires IT86-4 ne sont pas nécessaires quand une inadmissibilité 53 - Aucune preuve médicale empêche le client de recevoir des PDC pendant une PP. Lors de la création des données complémentaires IT86-4, saisir la même semaine et le même jour qui ont été traités dans les données complémentaires correspondantes (IT85-1, 2 et 3). | Passer à Établissement et modification des données complémentaires pour les PDC pour obtenir plus de renseignements, au besoin. Quand des PDC commencent à être versées ou cessent de l’être pour verser un autre GP, il faut indiquer une semaine de renouvellement dans les données complémentaires IT80-1. Un seul GP peut être complété dans les données complémentaires IT86-4. Si le client demande une combinaison de PDC et de prestations pour proches aidants, envoyer la demande dans SMP. Pour obtenir des renseignements supplémentaires sur les données complémentaires de SASR, consulter la Liste de données complémentaires de la suppression et recréation . [Établissement et modification des données complémentaires pour les PDC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#etablissementetmodification) [Liste de données complémentaires de la suppression et recréation](http://wecs-siew.prv/wecs-siew/reflookup_f.aspx) |

| Prestations pour proches aidants | Prestations pour proches aidants d’enfants : IT81-1 : SEM PAE (colonne 113-114) IT86-4 : SEM TRAI (colonne 15) JR (colonne 67) CERT MED (colonne 68) DEB (colonne 78) FIN (colonne 82) ADM (colonne 86) MOD (colonne 88) Prestations pour proches aidants d’adultes : IT81-1 : SEM PAA (colonne 115-116) IT86-4 : SEM TRAI (colonne 15) JR (colonne 89) CERT MED (colonne 90) DEB (colonne 100) FIN (colonne 104) ADM (colonne 108) MOD (colonne 110) | Les données complémentaires IT86-4 sont requises pour établir l’admissibilité et la fenêtre de proches aidants (FPA) complète de 52 semaines. Créer des données complémentaires IT86-4 supplémentaires pour chaque modification de l’admissibilité ou quand le client change de GP. Les données complémentaires IT86-4 ne sont pas requises quand une inadmissibilité 63 - Proches aidants d’enfants ou d’adultes - Aucune preuve médicale (D63) empêche le client de recevoir des prestations pour proches aidants. Pour créer les données complémentaires IT86-4, saisir la même semaine et le même jour traités dans les données complémentaires IT85-1, 2 et 3. | Passer à Établissement et modification des données complémentaires pour les prestations pour proches aidants pour plus de renseignements, au besoin. Quand des prestations pour proches aidants commencent ou cessent d’être versées afin de verser un autre GP, une semaine de renouvellement est requise dans les données complémentaires IT80-1. Si le client demande une combinaison de prestations pour proches aidants et d’un GP autre que des prestations régulières ou des prestations de maladie, envoyer la demande dans SMP. Pour plus de renseignements supplémentaires sur les données complémentaires de SASR, consulter la Liste de données complémentaires de la suppression et recréation . [Établissement et modification des données complémentaires pour les prestations pour proches aidants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#prestations_pour_proches_aidants) [Liste de données complémentaires de la suppression et recréation](http://wecs-siew.prv/wecs-siew/reflookup_f.aspx) |
```

**Données complémentaires du RQAP**

```text
| RQAP | Données complémentaires et colonnes du SASR | Modifications requises | Renseignements supplémentaires |

| Maternité/Parental | IT80-1 : TOT SEM (colonne 41) IT80-2 : DC SEM1 (colonne 12) IND DC (colonne 16) IT81-1 : MCE (colonne 105) PROV MAT (colonne 107-108) PROV PAR (colonne 109-110) IT82-2 : INADMIS. 1 IN (colonne 12) INADMIS. 1 SMD (colonne 14) INADMIS. 1 JR (colonne 18) INADMIS. 1 SMA (colonne 19) INADMIS. 1 JR (colonne 23) | Valider le nombre total de semaines payées. Ne pas inclure les semaines du RQAP . Si le HM06 indique que le DC est supprimé, choisir 9 - DC supprimer (Régime Québécois d’assurance parentale [RQAP]) dans le champ IND DC . Si la demande commence par des prestations du RQAP, choisir F - Grossesse ou P - Parentals dans le champ MCE . Valider et confirmer le nombre de semaines équivalant aux prestations de maternité et parentales d’AE payées et remplir ou modifier les champs PROV MAT et PROV PAR en conséquence. Dans le champ PROV MAT , le compteur doit afficher un nombre de 1 à 15 afin de refléter le nombre équivalant aux semaines de prestations du RQAP payées. Dans le champ PROV PAR , le compteur doit afficher un nombre de 1 à 35 afin de refléter le nombre équivalant aux semaines de prestations du RQAP payées. Saisir l’inadmissibilité appropriée pour les semaines payées ou payables par le RQAP : - 56 - Prestations Régime québécois d’assurance parentale payées (inadmissibilité définie) - 57 - Prestation d’Assurance-emploi en maternité ou parentales refusées, prestations Régime québécois d’assurance parentale payables par la province (inadmissibilité indéfinie) | Le nombre total de semaines de maternité, de paternité, parentales ou d’adoption du RQAP payées en vertu du régime de base ou du régime particulier s’affiche dans ETI, à l’écran Assurance parentale (Québec) . Régime de base : Une semaine de prestations du RQAP équivaut à une semaine de prestations de maternité ou parentales d’AE Régime particulier : Les renseignements sur les équivalences aux prestations d’AE sont fournis dans les champs L’équivalent pour l’A.E. - Semaines maternités payées et Autres semaines payées . Pour obtenir des renseignements supplémentaires, consulter RQAP — Connaissance . [RQAP — Connaissance](/fr/procedure/generic/additionalresources/qpip_knowledge.shtml#Equivalence) |
```

**Établissement et modification des données complémentaires pour les PDC**

Lors de la création de données complémentaires IT86-4 pour une demande de PDC, remplir les champs suivants, au besoin :
       [IT86-4](http://wecs-siew.prv/wecs-siew/searchdetails_f.aspx?evalid=86-4)

```text
| Mesure à prendre | PDC DEB | PDC FIN | ADM | MOD |

| Établir la FC et l’admissibilité de 52 semaines. Remarque : Il doit toujours y avoir des données complémentaires d’établissement quand des PDC sont payées ou payables. | Début de la FC comme l’établit le certificat. | Début des PDC + 51 semaines pour établir une FC de 52 semaines. | De 1 à 26, selon ce que demande le client. | Vide |

| Renouveler les PDC - Le début des PDC est reporté et un autre GP est payé pendant la FC initiale. | Saisir la semaine de renouvellement pour les PDC. | Saisir la même s/c que celle des données complémentaires IT86-4 précédentes. | Vide | R |

| Arrêter les PDC pour payer un autre GP. Le client n’a pas touché toutes les PDC auxquelles il avait droit. | Saisir la même s/c que le début des PDC dans les données complémentaires IT86-4 précédentes. | Saisir la s/c de la dernière semaine traitée pour les PDC. | Vide | S |

| Modifier la période de PDC pour rétablir les PDC après le traitement d’un autre GP. | Saisir la s/c pour laquelle les PDC ont recommencé. | Saisir la semaine de fin de la FC initiale de 52 semaines. | Saisir le nouveau nombre de semaines d’admissibilité à des PDC (de 1 à 26). | M |

| Fermer la FC en raison du décès du patient. | Saisir la même s/c que le début des PDC dans les données complémentaires IT86-4 précédentes. | Saisir la s/c du décès du membre de la famille. | Saisir le nombre de semaines d’admissibilité à des PDC indiqué dans les données complémentaires IT86-4 précédentes. | D |

| Fermer la FC en raison de la fin des PDC (le client a touché toutes les prestations auxquelles il avait droit). | Saisir la même s/c que le début des PDC dans les données complémentaires IT86-4 précédentes. | Saisir la s/c de la dernière semaine pendant laquelle des PDC ont été payées. | Vide | F |
```

**Établissement et modification des données complémentaires pour les prestations pour proches aidants**

Lors de la création de données complémentaires IT86-4 pour une demande de prestations pour proches aidants, remplir les champs suivants, au besoin :
       [IT86-4](http://wecs-siew.prv/wecs-siew/searchdetails_f.aspx?evalid=86-4)

```text
| Mesure à prendre | PPA DEB | PPA FIN | ADM | MOD |

| Établir la FPA et l’admissibilité de 52 semaines. [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0553.dita) | Début de la FPA comme l’établit le certificat. | Début des prestations pour proches aidants + 51 semaines pour établir une FPA de 52 semaines. | De 1 à 35 semaines pour les prestations pour proches aidants d’enfants ou de 1 à 15 semaines pour les prestations pour proches aidants d’adultes, selon ce que demande le client. | Vide |

| Renouveler les prestations pour proches aidants. Le début des prestations pour proches aidants est reporté et un autre GP est payé pendant la FPA initiale. | Saisir la semaine de renouvellement pour les prestations pour proches aidants. | Saisir la même s/c que celle des données complémentaires IT86-4 précédentes. | Vide | R |

| Arrêter les prestations pour proches aidants pour payer un autre GP. Le client n’a pas touché toutes les prestations pour proches aidants auxquelles il avait droit. | Saisir la même s/c que le début des prestations pour proches aidants dans les données complémentaires IT86-4 précédentes. | Saisir la s/c de la dernière semaine traitée pour les prestations pour proches aidants. | Vide | S |

| Modifier la FPA pour rétablir les prestations pour proches aidants après le traitement d’un autre GP. | Saisir la s/c pour laquelle les prestations pour proches aidants ont recommencé. | Saisir la semaine de fin de la FPA initiale de 52 semaines. | Saisir le nouveau nombre de semaines d’admissibilité aux prestations pour proches aidants (de 1 à 35 semaines ou de 1 à 15 semaines). | M |

| Fermer la FPA en raison du décès du patient. | Saisir la même s/c que le début des prestations pour proches aidants dans les données complémentaires IT86-4 précédentes. | Saisir la s/c du décès du membre de la famille. | Saisir le nombre de semaines d’admissibilité à des prestations pour proches aidants indiqué dans les données complémentaires IT86-4 précédentes. | D |

| Fermer la FPA en raison de la fin des prestations pour proches aidants (le client a touché toutes les prestations auxquelles il avait droit). | Saisir la même s/c que le début des prestations pour proches aidants dans les données complémentaires IT86-4 précédentes. | Saisir la s/c de la dernière semaine pendant laquelle des prestations pour proches aidants ont été payées. | Vide | F |
```

**Données complémentaires des prestations spéciales pour les travailleurs indépendants**

```text
| Numéro des données complémentaires | Champ | Modifications à apporter |

| IT80-1 | CRHC (colonne 12) | Le Centre Service Canada (CSC) doit être l’un des suivants : - Atlantique — 1953 - Québec — 2930 - Ontario — 3978 - Ouest du Canada et territoires — 4758 |

| HR ASS (colonne 26) | Laisser ce champ vide. |

| GD DE (colonne 68) | Choisir le genre de demande (GD) approprié : - 73 - Travailleur autonome - Maladie - 74 - Travailleur autonome - Maternité - 75 - Travailleur autonome - Parentales standard - 77 - Travailleur autonome - Soins de compassion - 78 - Travail autonome - Proches aidants d’enfants (SMP seulement) - 79 - Travail autonome - Parentales prolongées - 90 - Travail autonome - Proches aidants d’adultes (SMP seulement) |

| SEX (colonne 70) | - 1 - Homme - 3 - Femme - 5 - Parentales, père adoptif - 6 - Parentales, mère adoptive - 7 - Parentales, père naturel - 8 - Parentales, mère naturelle |

| DIV SEM (colonne 83) | Le dénominateur correspond toujours à 52. |

| IT81-1 | NUM L’EMP ALNUMRIQ (colonne 64-78) | Laisser ce champ vide. |

| IT81-2 | PP ADM (colonne 12) | Étant donné qu’un travailleur indépendant n’est pas admissible à des prestations régulières, laisser ce champ vide. |

| IND EXEM (colonne 41) | Laisser ce champ vide. |

| IND RSD (colonne 43) | Choisir l’indicatif approprié : - 70 - Demande de base pour travail autonome (généré par le système) - 71 - Demande en travail autonome établie avec rémunérations estimées - 72 - Demande en travail autonome établie avec rémunérations de l’Agence du revenu du Canada (ARC) - 78 - Aucune rémunération en travail autonome demandée initiée auprès de l’ARC |

| IT82-2 | IND ACT (colonne 118) | Ce champ peut être vide. S’il est rempli, l’agent doit saisir « G. » |

| IT85-1 | GE PR (colonne 91) | Choisir le GP approprié : - 73 - Travail autonome - Maladie - 74 - Travail autonome - Maternité - 75 - Travail autonome - Parentale standard adoption - 76 - Travail autonome - Parentale, standard soins d’enfant - 77 - Travail autonome - Soins de compassion - 79 - Travail autonome - Parentales prolongées adoption - 89 - Travail autonome - Parentales prolongées soins d’enfant |

| | D P (colonne 97) | Un travailleur indépendant qui reçoit des prestations spéciales ne peut pas être exempté de remplir des déclarations du prestataire. S’il y a un 1 dans ce champ, le supprimer. |

| IT85-2 | SRC (colonne 106) | S’il y a un N dans ce champ, le supprimer. |

| IT85-3 | GE PR (colonne 91) | Choisir le même GP spéciales pour les travailleurs indépendants dans ce champ que celui des données complémentaires de l’IT85-1. |
```

**Données complémentaires des initiatives d’emploi**

Les agents consultent les tableaux suivants sur les initiatives d’emploi, au besoin :

**Cours de formation non dirigé**

```text
| Numéro des données complémentaires | Champ | Modifications à apporter |

| IT85-1 | STUAE MNT (colonne 35) | Laisser le champ vide ou saisir « 0000. » |

| STUAE IND (colonne 39) | Si le champ STUAE MNT affiche « 0000 », choisir 03 - Cours . |

| GE PR (colonne 91) | Pour un cours de formation non dirigé, choisir 01 - Régulières . |

| IT86-1 | SEM TRAI (colonne 15) PROJ DEBUT (colonne 19) PROJ FIN (colonne 23) | Remplir les champs. |

| STAG ID (colonne 43) | Choisir 90 - Prestataire non dirigé . |
```

**Cours de formation dirigé**

```text
| Numéro des données complémentaires | Champ | Modifications à apporter |

| IT85-1 | STUAE MNT (colonne 35) | Saisir « 0000. » |

| STUAE IND (colonne 39) | Choisir 03 - Cours . |

| GE PR (colonne 91) | Choisir 06 - Formation . |

| IT86-1 | SEM TRAI (colonne 15) PROJ DEBUT (colonne 19) PROJ FIN (colonne 23) | Remplir les champs. Si le champ STAG ID affiche 39 - Initiative sur la formation continue , le champ PROJ DEBUT doit être supérieur à la s/c 2146. Si la semaine de fin de la formation est atteinte, des prestations régulières continuent d’être versées tant que le client n’a pas reçu le montant total auquel il est admissible. Aucune semaine de renouvellement n’est requise. |

| PROJ NO. (colonne 27) | Le numéro de projet doit être composé de 10 chiffres. Si le champ STAG ID affiche 09 - Stagiaire indépendant, partie 1 seulement, 39 - Initiative sur la formation continue ou 53 - Développement des compétences, transfert complet entente relative sur le marché du travail , laisser le champ vide. |

| CRHCP (colonne 33) | Le champ doit correspondre au champ C/R . |

| TAUX (colonne 37) | Laisser le champ vide ou saisir « 000. » Si le champ STAG ID affiche 35 - Développement des compétences - Groupe , saisir « 000. » |

| STAG ID (colonne 43) | Choisir l’indicatif approprié : - 09 - Stagiaire indépendant, partie 1 seulement - 35 - Développement des compétences - Groupe - 39 - Initiative sur la formation continue - 53 - Développement des compétences, transfert complet entente relative sur le marché du travail - 95 - Pancanadien, Développement des compétences - 97 - Développement des compétences pour les Autochtones - 98 - Entente sur le développement des ressources humaines des Autochtones |

| C/R (colonne 45) | Le champ doit correspondre au champ CRHCP . |

| IND CD (colonne 49) | Si le STAG ID n’est pas 39 - Initiative sur la formation continue , saisir « 000000. » Par contre, si la demande est dans la région du Québec, saisir « 123456. » Si le STAG ID est 39 - Initiative sur la formation continue , saisir « 201808. » |
```

**Formation en apprentissage**

```text
| Numéro des données complémentaires | Champ | Modifications à apporter |

| IT80-2 | DC SEM1 (colonne 12) IND DC (colonne 16) | Quand le DC est supprimé pour une formation en apprentissage, choisir 06 - DC supprimé (formation en apprentissage) dans le champ IND DC et saisir « 0000 » dans le champ DC SEM1 . |

| IT81-2 | APP (colonne 36) | Choisir l’indicatif approprié : - 1 - Aucun paiement anticipé : Les déclarations doivent cesser d’être émises après la fin de la formation - 2 - Aucun paiement anticipé : Les déclarations doivent continuer d’être émises après la fin de la formation - 3 - Paiement anticipé : Les déclarations doivent cesser d’être émises dès que la semaine de fin de la formation a été atteinte - 4 - Paiement anticipé : Les déclarations doivent continuer ou cesser d’être émises après la fin de la formation Si le champ affiche 1 ou 3, la demande se termine à la semaine de fin du cours. Quand la semaine de fin du cours est changée, mettre le champ à jour en conséquence pour afficher l’indicatif d’apprenti approprié. |

| IT85-1 | STUAE MNT (colonne 35) | Saisir « 0000. » |

| STUAE IND (colonne 39) | Choisir l’indicatif approprié : - 11 - Apprenti stagiaire - aucun paiements anticipés - 13 - Apprenti stagiaire - paiements anticipés - 15 - Apprenti stagiaire - paiements anticipés accordé mais pas pour cette déclaration |

| GE PR (colonne 91) | Choisir 06 - Formation . |

| IT86-1 | SEM TRAI (colonne 15) PROJ DEBUT (colonne 19) PROJ FIN (colonne 23) | Remplir les champs. |

| PROJ NO. (colonne 27) | Le numéro de projet doit être composé de 10 chiffres. |

| CRHCP (colonne 33) | Le champ doit correspondre au champ C/R . |

| TAUX (colonne 37) | Saisir « 000. » |

| STAG ID (colonne 43) | Choisir l’indicatif approprié : - 20 - Développement des compétences d’apprentis, cogérée ou aucune entente relative sur le marché du travail - 21 - Apprentis Développement des compétences, transfert complet entente relatives la marche du travail |

| C/R (colonne 45) | Le champ doit correspondre au champ CRHCP . |

| IND CD (colonne 49) | Remplir le champ. |
```

**Programme prestations d’emploi pour travailleurs indépendants**

```text
| Numéro des données complémentaires number | Champ | Modifications à apporter |

| IT80-1 | GD DE (colonne 68) | Choisir 02 - Régulières . |

| IT81-2 | IND TD (colonne 60) | Choisir 6 , car le client est exclu à l’interne de remplir des déclarations du prestataire électroniques. |

| IT85-1 | STUAE MNT (colonne 35) | Saisir « 0000. » |

| STUAE IND (colonne 39) | Choisir 12 - Travailleur autonome . |

| GE PR (colonne 91) | Choisir 09 - Travail autonome . |

| IT85-2 | SRC (colonne 106) | Quand des semaines sont insérées ou passent au genre de prestations 09 - Travailleur autonome , modifier le champ SRC en supprimant l’indicatif I, R ou G (déclaration par Internet). |

| IT86-2 | SEM TRAI (colonne 15) TI DEBUT (colonne 19) TI FIN (colonne 23) | Remplir les champs. |

| PROJ NO. (colonne 27) | Le numéro de projet doit être composé de 10 chiffres. |

| CRHCP (colonne 33) | Le champ doit correspondre au champ C/R . |

| ALLOC. BASE DB (colonne 37) ALLOC. BASE FIN (colonne 41) ALLOC. BASE MON (colonne 45) | Laisser les champs vides. S’ils sont remplis, effacer les renseignements. Une fois la demande de retour dans SIP, dans ETI, choisir la transaction Données de projet — Travail indépendant (M171) et saisir à nouveau les renseignements de l’allocation de base. |

| C/R (colonne 85) | Le champ doit correspond au champ CRHCP . |
```

**Programme de création d’emploi**

```text
| Numéro des données complémentaires | Champ | Modifications à apporter |

| IT80-1 | PROJ COM (colonne 74) | Si le champ lié au taux du projet pour un programme de création d’emploi est rempli, le champ PROJ COM doit être dans la portée de 000 à 058. |

| PROJ ET (colonne 77) | Choisir l’indicatif approprié : - 5 - Projet actif pour la création d’emploi - 6 - Projet terminé pour la création d’emploi |

| IT85-1 | GE PR (colonne 91) | Choisir 08 - Création d’emploi . |

| IT86-1 | SEM TRAI (colonne 15) PROJ DEBUT (colonne 19) PROJ FIN (colonne 23) | Remplir les champs. |

| PROJ NO. (colonne 27) | Le numéro de projet doit être composé de 10 chiffres. |

| CRHCP (colonne 33) | Le champ doit correspondre au champ C/R . |

| TAUX (colonne 37) | Saisir « 000. » |

| C/R (colonne 45) | Le champ doit correspond au champ CRHCP . |
```

**Travail partagé (TP)**

```text
| Numéro des données complémentaires | Champ | Modifications à apporter |

| IT80-1 | TM (colonne 39) | Si l’accord de TP est actif, choisir 76 - Travail partagé automatisé . |

| TOT SEM (colonne 41) | Ne pas inclure les semaines traitées comme GP 7 dans ce champ. |

| GD DE (colonne 68) | Si l’état du TP est 1 - Projet actif pour le travail partagé , le GD doit être 02, 06 ou 07. |

| PROJ COM (colonne 74) | Saisir le nombre de semaines traitées (incluant celles non payées) comme GP 7 pour la plus récente période de TP. Si aucun IT85 n’a été traité comme GP 7, saisir « 000. » |

| PROJ ET (colonne 77) | Si l’accord de TP est actif ou s’il n’y a eu aucun renouvellement après l’accord de TP terminé, choisir 1 - Projet actif pour le travail partagé . Si l’accord de TP est terminé et qu’il est suivi d’un renouvellement choisir 2 - Projet terminé pour le travail partagé . |

| IT80-2 | AU DP (colonne 73) SM/JR PAI (colonne 75) | Si le client est exempté de remplir des déclarations du prestataire, remplir ces champs. |

| IT81-1 | PRO SEM1 (colonne 20-23) DERN ENV (colonne 24-27) | Quand les IT85 pour les déclarations du prestataire en attente de traitement sont supprimés, saisir la s/c de la prochaine semaine à traiter dans les 2 champs. |

| IT81-2 | PP FIN (colonne 14) | Calculer la dernière semaine renouvelable (DSR) : DPP + 51 + nombre de semaines de prolongation de la PP + nombre de semaines traitées comme GP 7. Comparer la DSR calculée à la semaine de fin de l’accord de TP. Si la DSR calculée est supérieure à la semaine de fin de l’accord, saisir la DSR calculée. Si la semaine de fin de l’accord est supérieure à la DSR calculée, saisir la semaine de fin de l’accord. Si la DSR ou la semaine de fin de l’accord est supérieure au DPP + 103, saisir le DPP + 103. |

| IND EXEM (colonne 41) | Si l’accord de TP est actif ou s’il n’y a eu aucun renouvellement après la fin de l’accord de TP terminé, choisir 23 - Employé à temps partiel , sinon laisser ce champ vide. |

| IND TD (colonne 60) | Choisir 6 , car le client est exclu à l’interne de remplir des déclarations du prestataire électroniques. |

| IT85-1 | TM (colonne 24) | Choisir 76 - Travail partagé automatisé . S’il faut modifier une déclaration du prestataire, choisir 19 - Déclaration modifiée. |

| MNT STUAE (colonne 35) | Saisir les heures manquées en raison du TP × 10. Par exemple, si le client a manqué 6,5 heures en raison du TP, saisir « 0065. » Si le client a travaillé au moins une demi-heure pour l’employeur participant au TP et n’a manqué aucune heure en raison du TP, saisir « 0000 » et une SET (colonne 54). S’il ne s’agit pas d’une semaine de TP (c.-à-d. une semaine pendant laquelle le client n’a pas travaillé pour l’employeur participant au TP), saisir « 0990. » |

| IND STUAE (colonne 39) | Choisir 01- Travail partagé . |

| SET (colonne 54) | Si « 0000 » a été saisi dans le champ MNT STUAE (colonne 35), choisir 1 - Semaine entière de travail - semaine 1 . Sinon laisser ce champ vide. |

| GE PR (colonne 91) | Si un nombre autre que 0990 a été saisi dans le champ MNT STUAE (colonne 35), choisir 07 - Travail partagé . Si 0990 a été saisi dans le champ MNT STUAE (colonne 35) et si 5 jours de maladie ont été saisis, choisir 10 - Maladie . Si moins de 5 jours de maladie ont été saisis, choisir 01 - Régulières . |

| ID DC (colonne 94) | Si le GP est 7 , choisir 15 - Aucunes semaines comptées comme semaines de prestations payées . Sinon, choisir l’indicatif d’état du DC selon les procédures normales. |

| IT85-2 | SRC (colonne 106) | Si le client est exempté de remplir des déclarations du prestataire, choisir N - Rapport interne aucune DP . Sinon laisser ce champ vide. |

| RÉM-DÉD SEM1 (colonne 107) | Laisser ce champ vide. |

| IT86-1 | SEM TRAI (colonne 15) | La SEM TRAI de l’ accord de TP doit être égale ou antérieure à la première semaine que le TP a été traité. |

| PROJ DEBUT (colonne 19) PROJ FIN (colonne 23) | Saisir la s/c de début et de fin de l’accord de TP. |

| PROJ NO. (colonne 27) | Le numéro de projet doit être composé de 10 chiffres. |

| CRHCP (colonne 33) | Choisir le CSC de référence. |

| T-P HEU (colonne 40) | Saisir les heures hebdomadaires normales (HHN) ×10. Par exemple, si les HHN sont de 37,5, saisir « 375 » et si elles sont de 40, saisir « 400. » |
```

**Travailleurs saisonniers**

Dans le cadre de l’engagement du budget 2018 à aider les travailleurs des industries saisonnières, le projet pilote 21 avait été créé pour fournir jusqu’à 5 semaines supplémentaires (un maximum de 45 semaines) de prestations régulières aux clients qui répondent à la définition de travailleur saisonnier. Cette mesure a depuis été prolongée chaque année, le budget 2024 prolongeant actuellement ces dispositions jusqu’au 24 octobre 2026. La mesure pour les travailleurs saisonniers comprend maintenant les DPP entre la s/c 2471 et la s/c 2574.

En 2023, un projet pilote d’un an a permis d’accorder jusqu’à 4 semaines supplémentaires de prestations régulières aux travailleurs saisonniers, en plus des 5 semaines prévues par la mesure législative temporaire qui est actuellement en œuvre. Cela signifie que le total potentiel de semaines d’admissibilité supplémentaires était de 9. Cette mesure s’applique aux demandes dont le DPP est entre la s/c 2412 et la s/c 2463.

Pour plus de renseignements, l’agent du COPA consulte Travailleurs saisonniers : Renseignements sur les semaines supplémentaires d’admissibilité — Connaissances .
       [Travailleurs saisonniers : Renseignements sur les semaines supplémentaires d’admissibilité — Connaissances](/fr/procedure/generic/additionalresources/sw_info_addi_weeks_entitlement_pp21_knowledge.shtml)

Au besoin, l’agent consulte le tableau suivant :

```text
| Numéro des données complémentaires | Champ | Modifications à apporter |

| IT81-2 | IND SAIS (colonne 90) | Si l’évènement qui déclenche la demande de S/R peut potentiellement avoir une incidence sur des semaines d’admissibilité d’un travailleur saisonnier, saisir « 99 » dans ce champ. Cela déclenche une validation du travail saisonnier qui confirme l’admissibilité du travailleur saisonnier et, au besoin, affiche les semaines d’un travailleur saisonnier dans ETI. Des modifications au DPP actuel, au DPP précédent, aux heures d’emploi assurable ou à la région économique peuvent potentiellement avoir une incidence sur l’état et l’admissibilité d’un travailleur saisonnier. |
```

**Demande recréée avec succès**

Il y a des situations dans lesquelles un agent du COPA pourrait être tenu de saisir des transactions en ligne après que la demande soit recréée avec succès, comme dans les exemples suivants :

- Un nouveau calcul de la demande est initié à l’aide d’une transaction M106 avec un 99 - Mise à jour manuelle dans le champ Nouveau calcul .

- Des déclarations du prestataire sont traitées avec une transaction Émettre paiements (M151/M152) .

- L’exemption de remplir des déclarations du prestataire est établie avec une transaction M106.

- Des déclarations du prestataire en attente de traitement ont été supprimées de SASR et doivent être saisies avec une transaction M151/M152.

- Des transactions en ligne ont été rejetées avec l’indicatif d’erreur C280 quand l’état de la demande (ED) était 99 - Suppression/recréation et doivent être saisies.

- Des inadmissibilités ont été supprimées de SASR, car 7 inadmissibilités ou plus sont en vigueur et doivent être saisies avec une transaction Exclusions/Inadmissibilités (M161).

**Demande recréée avec des erreurs ou omissions**

Quand les Minis révèlent des erreurs ou des omissions dans la demande, l’agent du COPA détermine comment résoudre la situation. Certaines demandes mal recréées peuvent devoir être supprimées de nouveau, tandis que d’autres peuvent simplement nécessiter la saisie d’une transaction dans ETI. La nature de l’erreur ou de l’omission détermine les mesures correctives nécessaires.

**Transactions en ligne**

De nombreuses transactions ETI sont utilisées pour corriger certaines erreurs dans les demandes. Habituellement, les agents de S/R du COPA saisissent la transaction M106 ou traitent des déclarations du prestataire modifiées.

Puisque la transaction M106 force SIP à lire et à examiner tous les renseignements de la demande, il s’agit de la transaction la plus polyvalente et la plus fréquemment utilisée par les agents du COPA pour modifier les demandes et corriger les erreurs. Voici certains exemples de renseignements de demande qu’une transaction M106 peut corriger :

- nombre total de semaines payées;

- inadmissibilités exclues;

- renseignements sur le DC;

- nombre de semaines de prestations spéciales payées;

- mauvais GP, tant que la déclaration du prestataire est codée correctement;

- statut de travailleur saisonnier ou nombre de semaines d’admissibilité.

Un traitement manuel 19 - Déclaration modifiée (TM19) peut être utilisé pour ajouter des renseignements manquants ou corriger des données erronées dans une déclaration du prestataire en particulier.

**La demande doit être supprimée de nouveau**

Voici quelques exemples de situations où la demande doit être supprimée de nouveau :

- les montants versés ou recouvrés sont inexacts;

- des données complémentaires valides, qui comportaient un montant versé ou recouvré, ont été supprimées par erreur;

- l’établissement valide de données complémentaires liées à un T-P de l’AE a été supprimé;

- des données complémentaires ont été recréées, mais les montants de l’accord d’ordonnance familiale sont manquants;

- les champs suivants dans les données complémentaires IT85-1,2 ont été recréés incorrectement, ce qui a engendré une erreur fiscale ou un TP dans une année fiscale non valide :

- PRS MON (colonne 55);

- IMP (colonne 59);

- PR BR PY SM (colonne 61);

- PR BR PY SM2 (colonne 65). 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0552.dita`

Remarque :

Quand les modifications apportées à une demande ont une incidence sur les montants d’une année d’imposition précédente, l’agent du COPA crée un AT COPA Révision (COPA REV) pour que le coordonnateur fiscal régional (CFR) modifie le T4E. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0553.dita`

Remarque :

Il doit toujours y avoir des données complémentaires d’établissement quand des prestations pour proches aidants sont payées ou payables. 
