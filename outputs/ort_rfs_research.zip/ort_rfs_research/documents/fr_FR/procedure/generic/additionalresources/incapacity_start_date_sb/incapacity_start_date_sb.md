# Maladie : Date de début de l’incapacité — Tableau

Source map: `fr_FR/procedure/generic/additionalresources/incapacity_start_date_sb/incapacity_start_date_sb.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/incapacity_start_date_sb/ressources_additionnelles.dita`

Les clients doivent obtenir, à leurs propres frais, un certificat médical acceptable qui couvre chaque semaine durant laquelle ils demandent des prestations de maladie. Le certificat médical doit démontrer qu’un client est incapable de travailler en raison d’une maladie, d’une blessure ou d’une mise en quarantaine. Dans certains cas, le client doit présenter son certificat médical avec la demande. Pour plus de renseignements, l’agent consulte Déterminer si un certificat médical doit être présenté : Prestations de maladie — Demandes initiales ou Déterminer si un certificat médical doit être présenté — Demande renouvelée et demande continue .
       [Déterminer si un certificat médical doit être présenté : Prestations de maladie — Demandes initiales](/fr/procedure/task/calc_determining/det_mc_ra.shtml) 
       [Déterminer si un certificat médical doit être présenté — Demande renouvelée et demande continue](/fr/procedure/task/determining_med_cert_req.shtml)

Si le motif de cessation d’emploi (MCE) est D - Maladie ou blessure dans une demande initiale ou renouvelée et qu’aucun certificat médical n’a besoin d’être présenté, la date de début de l’incapacité est le DPP ou la semaine de renouvellement. Ceci s’applique même si le client présente un certificat médical qui n’a pas besoin d’être présenté. Dans une demande de conversion des prestations régulières aux prestations de maladie, quand aucun certificat médical n’a besoin d’être présenté, la date de début de l’incapacité est la semaine de conversion.

Dans toutes autres situations, si une date de début de l’incapacité est requise, l’agent la détermine à l’aide des renseignements dans le certificat médical. S’il y a une date précise de début de l’incapacité dans le certificat médical, la date de début de l’incapacité est le dimanche de la semaine dans laquelle le client était incapable de travailler pour des raisons médicales.

Si aucune date de début de l’incapacité précise n’est fournie, la date de début de l’incapacité est le dimanche de la semaine la plus hâtive :

- la semaine dans laquelle le médecin ou autre professionnel de la santé a signé le certificat médical;

- la semaine de la consultation médicale.

L’agent détermine la date de début de l’incapacité et utilise la semaine de début de l’incapacité pour ensuite déterminer la semaine de guérison.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0473.dita) 

Si le client présente un certificat médical pour une prolongation des prestations de maladie et que le certificat médical n’indique pas que la période de maladie initiale se poursuit, un autre certificat médical indiquant une date de début de l’incapacité est nécessaire pour continuer le paiement des prestations immédiatement après la date de guérison sur la demande.

Si la date de début de l’incapacité, la date de la signature ou la date de la consultation médicale n’est pas indiquée, le certificat médical n’est pas acceptable. Pour plus de renseignements, l’agent consulte Déterminer si un certificat médical est acceptable .
       [Déterminer si un certificat médical est acceptable](/fr/procedure/task/determining_med_cert_valid.shtml)

```text
| Conditions | Date de début de l’incapacité requise |

| L’une des exclusions et inadmissibilités suivantes s’applique, imposée soit en raison d’un MCE litigieux faisant l’objet d’une décision ou d’un report : - 10 - Congédiement - inconduite prouvée - 11 - Abandon volontaire - motif valable non prouvé - 42 - Suspension d’un emploi - 43 - Congé sans solde - 44 - Perte d’emploi anticipée | Oui |

| Le MCE est autre que D et une inadmissibilité 46 - Ne rencontre pas la norme variable - prestations spéciales payables (D46) s’applique. Une mesure temporaire du budget 2021 s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, une inadmissibilité D46 ne s’applique pas dans ces demandes. | Oui |

| Conversion aux prestations de maladie pendant ou après la réception des prestations de maternité, parentales ou PDC | Oui |

| Conversion des prestations régulières aux prestations de maladie quand les prestations régulières sont épuisées | Oui |

| Le MCE est D et aucun certificat médical ne doit être présenté dans une demande initiale ou renouvelée. | Non (La date de début de l’incapacité est le DPP ou la semaine de renouvellement.) |

| Un certificat médical a été présenté pour une période subséquente d’incapacité et le certificat médical n’indique pas que la maladie initiale se poursuit. | Oui Remarque : Dans ce cas, pour recevoir des prestations de maladie pour la période suivant immédiatement la semaine de guérison initiale, le client doit présenter un autre certificat médical qui couvre la période manquante et indique la date de début de l’incapacité. |

| Toute autre situation | Non |
``` 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0473.dita`

Exemple :

Le certificat médical a été signé par le médecin le mercredi 12 mars 2025 (la s/c 2490-3) et aucune date de début de l’incapacité précise n’a été fournie. Par conséquent, la date de début de l’incapacité est le dimanche 9 mars 2025. En calculant la date de guérison, l’agent utilise la s/c 2490 comme la semaine de début de l’incapacité. 
