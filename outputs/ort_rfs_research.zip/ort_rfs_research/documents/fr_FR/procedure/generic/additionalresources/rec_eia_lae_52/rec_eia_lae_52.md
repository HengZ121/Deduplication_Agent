# Révision en vertu de la LAE 52 et modification d’une décision en vertu de la LAE 111 — Instructions

Source map: `fr_FR/procedure/generic/additionalresources/rec_eia_lae_52/rec_eia_lae_52.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/rec_eia_lae_52/ressources_additionnelles.dita`

Sommaire : Un agent de Niveau 2 peut réviser les demandes et les décisions en vertu de la LAE 52 et modifier ou annuler les décisions en vertu de la LAE 111.

**Table des matières**

- Façons dont un agent peut recevoir une révision ou une modification
         [Façons dont un agent peut recevoir une révision ou une modification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/rec_eia_lae_52#_Façons_dont_un)

- Réviser une demande — LAE 52

- Correction rétroactive ou courante
             [Correction rétroactive ou courante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/rec_eia_lae_52#_Correction_rétroactive_versus)

         [Réviser une demande — LAE 52](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/rec_eia_lae_52#_Réviser_une_demande)

- Modifier ou annuler une décision — LAE 111

- Faits nouveaux
             [Faits nouveaux](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/rec_eia_lae_52#_Faits_nouveaux)

         [Modifier ou annuler une décision — LAE 111](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/rec_eia_lae_52#_Modifier_ou_annuler)

- Consigner la décision
         [Consigner la décision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/rec_eia_lae_52#_Consigner_la_décision)

- Communiquer la décision
         [Communiquer la décision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/rec_eia_lae_52#_Communiquer_la_décision)

- Saisir la décision
         [Saisir la décision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/rec_eia_lae_52#_Saisir_la_décision)

- Processus de révision selon 52 de la LAE
         [Processus de révision selon 52 de la LAE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/rec_eia_lae_52#_Steps_the_officer)

- Processus de modification selon 111 de la LAE
         [Processus de modification selon 111 de la LAE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/rec_eia_lae_52#_Cheminement_du_processus_1)

La législation autorise la Commission à réviser des demandes et des décisions et à modifier ou à annuler des décisions contestées. Un client, un employeur ou toute autre personne visée par une décision peut demander une révision de cette décision.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0560.dita) 

**Recevoir une révision ou une modification**

Un client, un employeur ou toute autre personne visée par une décision peut présenter des renseignements nouveaux ou supplémentaires en :

- communiquant avec le Centre d’appels Service Canada;

- visitant un Centre Service Canada (CSC);

- envoyant ces renseignements par courrier;

- téléversant des documents dans MDSC ou RE Web.

Une révision en vertu de la LAE 52 peut également être initiée à l’interne. Par exemple :

- un conseiller en expertise opérationnelle reçoit une demande de conseils et découvre des lacunes dans le recueil de faits, une erreur dans les transactions ou une autre question qui pourrait avoir une incidence sur la demande;

- des erreurs de traitement de la demande sont découvertes lors de la vérification de la qualité.

Selon que la demande est initiale, renouvelée, continue ou terminée et en fonction de la façon dont les nouveaux renseignements sont reçus, les mesures que l’agent prend pour consigner les renseignements au dossier du client varient :

- S’il s’agit d’une demande initiale ou renouvelée et que l’état Actions de demande est En cours , l’agent consigne les nouveaux renseignements dans un RSDP et réactive l’AT Litige - Décision (DEC) connexe qui a été complété.

- S’il s’agit d’une demande continue ou terminée, l’agent consigne les nouveaux renseignements dans un RSDP et crée un AT Révision de la demande (RVD).

- SNCT peut aussi générer automatiquement un AT RVD quand de nouveaux renseignements sur la demande sont présentés.

De nouveaux renseignements peuvent aussi être consignés dans un AT Action à prendre (AP) ou Rappel (RA).

Le client ou l’employeur peut parfois communiquer avec l’agent directement pour fournir de nouveaux renseignements. Si la décision a déjà été rendue et que l’AT a été complété, l’agent consulte Traiter de nouveaux renseignements fournis par le client ou l’employeur lorsque l’AT a été complété .
       [Traiter de nouveaux renseignements fournis par le client ou l’employeur lorsque l’AT a été complété](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/task/actioning_new_info.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0561.dita) 

**Réviser une demande — LAE 52**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0562.dita) 

La révision en vertu de la LAE 52 porte sur les litiges liés à l’admissibilité ou aux conditions requises (y compris la rémunération) et doit entraîner un trop-payé (T-P) ou un moins-payé (M-P). La révision peut consister à corriger des erreurs, à examiner une demande ou une décision ou à rendre une décision à la suite d’une enquête de l’Intégrité. Elle peut être demandée par un client, un employeur ou toute autre personne visée par une décision. La Commission peut également décider de réviser une demande ou une décision. La révision doit être terminée dans les 36 mois après que les prestations ont été versées ou sont devenues payables. Pour les enquêtes d’Intégrité, le délai est prolongé à 72 mois quand il y a une déclaration fausse ou trompeuse.
       [LAE 52](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-52.html)

Dans le cadre d’une révision, la Commission doit prendre 4 mesures distinctes dans le délai de 36 mois. Si l’une de ces 4 mesures ne peut pas être prise dans ce délai, l’agent ne peut pas réviser la demande. Ces 4 mesures sont les suivantes :
       [4 mesures distinctes](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-17/reexamen-politique.html#a17_3_0)

- décider de réviser ou non la demande ou la décision;

- rendre la nouvelle décision;

- calculer le T-P ou le M-P;

- aviser le client de la décision.

Quand les 4 mesures peuvent être prises dans le délai prévu, l’agent rend la nouvelle décision, l’ajoute à un rapport de décision (RD), saisit la transaction et avise le client. L’agent avise également l’employeur quand celui-ci est une partie intéressée.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0563.dita) 

**Correction rétroactive ou courante**

Une erreur de la Commission se produit quand la Commission dispose de tous les renseignements pertinents pour prendre une décision, mais que la décision finale n’est pas soutenue par les renseignements au dossier. L’erreur peut se produire dans le processus décisionnel ou quand la décision pour empêcher le paiement n’a pas été saisie.

Quand une erreur de la Commission entraîne le versement incorrect de prestations à un client et que ce dernier ne pouvait pas savoir qu’il n’était pas admissible à ces prestations, l’agent effectue la correction à partir de la prochaine semaine à être traitée. Sinon, l’agent corrige l’erreur de façon rétroactive et un T-P est créé. Si la Commission a fait une erreur en refusant des prestations, ces prestations seront versées.

Toutefois, quand l’erreur de la Commission entraîne une décision qui est contraire à la structure de la LAE, l’agent corrige l’erreur de façon rétroactive, même si cela entraîne un T-P est créé.

Une révision rétroactive en vertu de la LAE 52 peut seulement avoir lieu si des prestations ont été :

- versées en moins;

- versées contrairement à la structure de la LAE ;
         [contrairement à la structure de la LAE](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-17/reexamen-politique.html#a17_3_3_2)

- versées en raison d’une déclaration fausse ou trompeuse;

- versées et le client aurait dû savoir qu’il n’y était pas admissible.

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0564.dita) 

**Modifier ou annuler une décision — LAE 111**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0565.dita) 

La modification en vertu de la LAE 111 porte sur les décisions qui doivent être corrigées parce que des faits nouveaux sont présentés, qu’un fait essentiel a été omis ou qu’il a été considéré à tort lors de la prise de décision initiale. Elle peut également entraîner un T-P ou un M-P, et il n’y a pas de délai pour modifier ou annuler une décision en vertu de la LAE 111. Cette révision peut être demandée par un client, un employeur ou toute autre personne visée par la décision.
       [LAE 111](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-111.html)

La modification ou l’annulation d’une décision ne peut pas être effectuée sauf si un agent détermine que l’un de critères suivants de la LAE 111 est rempli :

- Il y a des faits nouveaux au dossier.

- La décision a été rendue sans connaissance d’un fait essentiel.

- La décision a été fondée sur une erreur liée à un fait essentiel.

Quand l’un de ces critères est rempli et que la décision peut être modifiée ou annulée, l’agent rend la nouvelle décision, l’ajoute à un RD, saisit la transaction et avise le client. L’agent avise également l’employeur quand celui-ci est une partie intéressée.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0563.dita) 

**Faits nouveaux**

Les faits nouveaux sont des faits qui se sont produits après qu’une décision a été rendue ou avant une décision, mais qui n’auraient pas pu être découverts par un client qui agit avec diligence . Le fait nouveau doit aussi avoir une incidence fondamentale sur la décision.
       [agit avec diligence](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-17/modification.html#a17_4_2_2)

Sans la connaissance d’un fait essentiel

Sans la connaissance d’un fait essentiel désigne les situations dans lesquelles l’une des situations suivantes se produit :

- Un fait essentiel était au dossier lors de la présentation de la demande, mais il n’a pas été pris en compte.

- L’existence d’un fait essentiel a été signalée par l’une des parties, mais l’agent ne l’a pas demandé ou ne l’a pas pris en considération au moment de rendre la décision.

- Le fait essentiel était disponible avant que la décision ne soit rendue, mais l’agent n’était pas au courant ou n’a pas examiné cette option de façon approfondie en raison d’un recueil de faits insuffisant.

Erreur liée à un fait essentiel

Une erreur liée à un fait essentiel se produit quand un fait était au dossier ou a été consigné par un agent, mais a été mal compris et cette mauvaise compréhension de ce fait a entraîné une décision erronée.

**Consigner la décision**

Dans SNCT, l’agent crée un RD pour consigner si les critères sont remplis pour réviser ou modifier une décision en vertu de la LAE 52 ou 111.

Les RD de révision et de modification devraient comprendre les éléments suivants :

- le litige qui a entraîné la révision;

- les faits pertinents;

- la décision et la justification quant à l’application ou non de la LAE 52 ou de la LAE 111;

- l’incidence de cette décision;

- les références de la LAE, du RAE, de la jurisprudence et du GDA.

Si les critères pour réviser ou modifier une décision sont remplis, un RD distinct est également requis pour la nouvelle décision sur le litige qui a entraîné la révision ou la modification. Quand il y a un onglet Résoudre le problème dans l’AT DEC, l’agent invalide le RD initial.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0566.dita) 

**Communiquer la décision**

Le motif de la révision et son résultat déterminent si une lettre doit être envoyée au client, à l’employeur ou à toute autre personne visée par la décision.

**Client, employeur ou toute autre personne ayant demandé une révision**

Si les critères ne sont pas remplis pour effectuer une révision en vertu de la LAE 52 ou 111, l’agent envoie la lettre A-01-00-00 pour aviser le client qu’une révision n’est pas possible ou la lettre Z-00-00-00 pour aviser l’employeur ou toute autre personne. Dans ces situations, l’agent n’inclut pas le droit de demander une révision dans la lettre.

Si les critères sont remplis pour effectuer une révision en vertu de la LAE 52 ou 111, mais que la décision sur le litige est maintenue , l’agent envoie la lettre A-01-00-00 pour aviser le client de ceci. Si les critères sont remplis et que la décision n’ est pas maintenue, l’agent envoie la lettre de décision appropriée pour aviser le client de cette nouvelle décision seulement quand celle-ci n’est pas à l’avantage du client (D-01-00-00, D-20-16-03, N-00-00-00, etc.). L’envoi d’une lettre au client n’est pas requis quand la révision ou la modification entraîne un M-P parce que le paiement est considéré comme un avis.

Si une nouvelle décision est rendue à l’avantage du client et que l’employeur est considéré comme une partie intéressée, l’agent avise l’employeur que la décision initiale a été modifiée à l’aide de la lettre Z-01-00-00. L’agent indique également à l’employeur son droit de demander une révision en vertu de la LAE 112.

Si une nouvelle décision est rendue et qu’elle n’est pas à l’avantage de toute autre personne visée par celle-ci, l’agent avise cette personne de cette nouvelle décision à l’aide de la lettre Z-00-00-00.

**Révision interne**

Si les critères ne sont pas remplis pour effectuer une révision en vertu de la LAE 52 ou que les critères sont remplis, mais que la décision est maintenue , aucune lettre n’est envoyée.

Si les critères sont remplis pour effectuer une révision en vertu de la LAE 52 et que la décision n ’est pas maintenue, l’agent envoie la lettre de décision appropriée pour aviser le client de cette nouvelle décision seulement quand celle-ci n’est pas à l’avantage du client (D-01-00-00, D-20-16-03, N-00-00-00, etc.). Quand l’employeur est une partie intéressée, l’agent l’avise également.

**Saisir la décision**

Si la révision ou la modification est dans une demande active ou terminée, l’agent saisit les transactions dans ETI. Si la demande est bloquée, l’agent saisit les transactions dans SDB. Sinon, l’agent envoie la transaction Mémo pour le centre opérationnel (MM06) au COPA.

Si les critères ne sont pas remplis pour effectuer une révision ou modifier une décision ou que la décision est maintenue, l’agent complète le numéro d’enregistrement lié à la demande.

**Processus de révision en vertu de la LAE 52**

- Créer le RD pour la décision de procéder à la révision ou non en vertu de la LAE 52. Ensuite, suivre l’une des directives suivantes :

- Si les critères sont remplis pour effectuer la révision, dans le champ Commentaires , saisir « Révision LAE 52 — [Litige] — [Nom de l’employeur] — [Date] — Critères remplis. » Ensuite, passer à l’étape 2.

- Si les critères ne sont pas remplis pour effectuer la révision ou si la décision est maintenue, suivre les directives suivantes :

- Dans le champ Commentaires , saisir « Révision LAE 52 — [Litige] — [Nom de l’employeur] — [Date] — [Critères non remplis ou décision maintenue]. »

- Déterminer si le client, l’employeur ou toute autre personne visée par la décision a demandé la révision ou s’il s’agit d’une révision interne :

- Si le client, l’employeur ou toute autre personne visée par la décision a demandé la révision, passer à l’étape 6.

- S’il s’agit d’une révision interne, passer à l’étape 7.

- Consulter la tâche appropriée uniquement pour rendre une décision sur le litige à réviser et créer un nouveau RD pour celui-ci.

- Dans le champ Commentaires, saisir « Révision LAE 52 — [Litige] — [Nom de l’employeur] — [Date] — Décision [annulée, modifiée ou terminée]. ».

- S’il y a un onglet Résoudre le problème dans le RD initial, invalider ce RD.

- Déterminer l’incidence de la décision de la façon suivante :

- Si la décision entraîne un T-P, consulter Défalcation pour déterminer si le T-P peut être défalqué. Passer à l’étape 4.
             [Défalcation](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/activity/write_off.shtml)

- Si la décision entraîne un M-P, passer à l’étape 5.

- Communiquer verbalement la décision négative au client.
         [Communiquer verbalement](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/task/verbal_communication.shtml)

- Saisir les transactions nécessaires dans les systèmes appropriés pour appliquer la nouvelle décision, y compris l’annulation du traitement manuel (TM) lié au litige faisant l’objet d’une révision.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0567.dita) 

- Dans SCA, créer et envoyer les lettres appropriées.

- Si un T-P est créé, ajouter le message de T-P approprié et indiquer le droit de demander une demande de révision.

- Si les critères ne sont pas remplis pour effectuer la révision ou que la décision initiale est maintenue, compléter le numéro d’enregistrement.

- Compléter l’AT.

**Processus de modification en vertu de la LAE 111**

- Créer le RD pour la décision de procéder à la modification ou non en vertu de la LAE 111. Ensuite, suivre l’une des directives suivantes :

- Si les critères sont remplis pour effectuer la modification, dans le champ Commentaires , saisir « Modification LAE 111 — [Litige] — [Nom de l’employeur] — [Date] — Critères remplis. » Ensuite, passer à l’étape 2.

- Si les critères ne sont pas remplis pour effectuer la modification, o dans le champ Commentaires , saisir « Modification LAE 111 — [Litige] — [Nom de l’employeur] — [Date] — [Critères non remplis ou décision maintenue]. » Ensuite, passer à l’étape 6

- Consulter la tâche appropriée uniquement pour rendre une décision sur le litige à modifier ou à annuler et créer un nouveau RD pour celui-ci.

- Dans le champ Commentaires , saisir « Modification LAE 111 — [Litige] — [Nom de l’employeur] — [Date] — Décision [annulée, maintenue, modifiée ou terminée]. »

- S’il y a un onglet Résoudre le problème dans le RD initial, invalider ce RD.

- Déterminer l’incidence de la décision de la façon suivante :

- Si la décision entraîne un T-P, consulter Défalcation pour déterminer si le T-P peut être défalqué. Passer à l’étape 4.
             [Défalcation](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/activity/write_off.shtml)

- Si la décision entraîne un M-P, passer à l’étape 5.

- Si la décision est maintenue, passer à l’étape 6.

- Communiquer verbalement la décision négative au client.
         [Communiquer verbalement](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/task/verbal_communication.shtml)

- Saisir les transactions nécessaires dans les systèmes appropriés pour appliquer la nouvelle décision, y compris l’annulation du TM lié au litige faisant l’objet d’une révision.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0567.dita) 

- Dans SCA, créer et envoyer les lettres appropriées.

- Si un T-P est créé, ajouter le message de T-P approprié et indiquer le droit de demander une révision.

- Si les critères ne sont pas remplis pour effectuer la modification ou que la décision initiale est maintenue, compléter le numéro d’enregistrement.

- Compléter l’AT.

**Références politiques**

- AP 2007-04 — Simplification de traitement des demandes de prestations : nouvel examen d’une demande
         [AP 2007-04 — Simplification de traitement des demandes de prestations : nouvel examen d’une demande](https://ort-orl.esdc-edsc.canada.ca/fr/policy/bememo/be2007-04.shtml)

- GDA 17 — Réexamen, modification et remboursement des prestations
         [GDA 17 — Réexamen, modification et remboursement des prestations](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-17/table-des-matieres.html)

- LAE 52
         [LAE 52](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-52.html)

- LAE 111
         [LAE 111](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-111.html) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0560.dita`

Remarque :

Même si la LAE 52 permet à la Commission de réviser une demande dans un délai de 36 mois ou de 72 mois quand il y a une fausse déclaration, cette page ne fait référence qu’au délai de 36 mois. L’agent du Niveau 2 qui effectue la vérification postérieure évalue et décide si une déclaration fausse a été faite sciemment. La décision peut entraîner une pénalité ou une violation. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0561.dita`

Remarque :

C’est la responsabilité de l’agent de Niveau 2 qui effectue la vérification postérieure de compléter les AT RVD Intégrité. L’agent de vérification postérieure consulte Cas d’Intégrité pour traiter le dossier.
       [Cas d’Intégrité](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/activity/integrity_case.shtml)

S’il s’agit d’un AT Demande de révision (DDR) ou si une révision en vertu de la LAE 112 a déjà été effectuée pour le même litige et pour la même période, l’agent réassigne l’AT au Centre de traitement des appels (CTA) approprié.

     [Cas d’Intégrité](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/activity/integrity_case.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0562.dita`

Remarque :

Ces renseignements ne s’appliquent pas aux corrections d’erreur liées à la rémunération présentées dans le délai de 36 mois ni à aucun autre genre de corrections d’erreurs présentées dans le délai de 6 semaines. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0563.dita`

Remarque :

Quand la révision entraîne un T-P, l’agent consulte Rendre une décision sur une défalcation pour déterminer si le T-P peut être défalqué.
       [Rendre une décision sur une défalcation](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/task/adjudicating_write_off.shtml)

     [Rendre une décision sur une défalcation](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/task/adjudicating_write_off.shtml) 

### Callout

Source topic: `fr_FR/common_notes/note_c_0564.dita`

Exemple — Correction rétroactive

Le client a été congédié en raison d’une mauvaise utilisation des ressources de l’entreprise. L’agent de Niveau 2 détermine qu’une inconduite a été prouvée et avise verbalement le client qu’une exclusion est imposée dans sa demande.

L’agent envoie une lettre au client confirmant la décision, mais n’impose pas l’exclusion indéterminée 10 - Congédiement - inconduite prouvée dans ETI. Le client reçoit 10 semaines de prestations avant que l’erreur ne soit découverte.

Même si la Commission a commis une erreur en omettant de saisir l’exclusion, le client savait qu’il n’était pas admissible aux prestations. Dans cette situation, l’exclusion est imposée rétroactivement et un T-P est créé.

Exemple — Correction courante

Le client a quitté volontairement son emploi et a fourni le motif de cessation d’emploi (MCE) dans sa demande d’AE. Toutefois, l’agent n’a pas vu le MCE litigieux et a établi la demande.

Le client a reçu 5 semaines de prestations régulières avant que l’erreur ne soit découverte. L’agent rend la décision sur le départ volontaire et détermine que le client n’a pas fait la preuve que celui-ci était fondé.

Puisque le client n’aurait pas pu savoir qu’il n’était pas admissible aux prestations, la correction est faite à partir de la prochaine semaine à traiter, et aucun T-P n’est créé. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0565.dita`

Remarque :

Quand une révision en vertu de la LAE 52 n’est pas possible, l’agent détermine si une modification en vertu de la LAE 111 est possible.
       [LAE 52](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-52.html) 
       [LAE 111](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-111.html)

     [LAE 52](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-52.html) 
     [LAE 111](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-111.html) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0566.dita`

Remarque :

Quand la nouvelle décision entraîne un T-P, un RD est également requis pour la décision sur la défalcation. Pour plus de renseignements, l’agent consulte Rendre une décision sur une défalcation .
       [Rendre une décision sur une défalcation](/fr/procedure/task/adjudicating_write_off.shtml)

     [Rendre une décision sur une défalcation](/fr/procedure/task/adjudicating_write_off.shtml) 

### Info

Source topic: `fr_FR/common_notes/note_c_0567.dita`

Remarque :

Si une décision portant sur un motif de cessation d’emploi est modifiée, le champ Condition spéciale du RE dans MSRE doit être modifié pour correspondre à la bonne décision et le RD original doit être invalidé au SNCT puisque le RE et le RD automatiquement réglé ou statué pourraient être utilisés aux fins d’un nouveau calcul de la demande ou de l’établissement d’un futur DPP. Si ce changement n’est pas effectué, cela pourrait entraîner le versement de prestations inexactes lors du traitement automatique de la demande.

Quand une décision qui a entraîné un T-P est annulée complètement dans une demande archivée ou bloquée qui n’est pas modifiable au moyen de SDB, envoyer les saisies au COPA dans une transaction Mémo pour le centre opérationnel (MM06) . 
