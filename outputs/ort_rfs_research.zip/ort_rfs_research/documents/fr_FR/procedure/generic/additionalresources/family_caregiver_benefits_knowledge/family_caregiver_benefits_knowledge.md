# Proches aidants : Renseignements sur les prestations — Connaissances

Source map: `fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge/family_caregiver_benefits_knowledge.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge/ressources_additionnelles.dita`

Sommaire : Les prestations pour proches aidants assurent un revenu temporaire aux membres de la famille admissibles qui doivent s’absenter du travail pour fournir des soins ou du soutien à un patient gravement malade ou blessé.

**Table des matières**

- Prestations pour proches aidants d’enfants
         [Prestations pour proches aidants d’enfants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#prestationsprochesaidantsenfants)

- Prestations pour proches aidants d’adultes
         [Prestations pour proches aidants d’adultes](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#prestationsprochesaidantsadultes)

- Prestations pour proches aidants d’enfants et prestations pour proches aidants d’adultes dans la même période de prestations (PP)
         [Prestations pour proches aidants d’enfants et prestations pour proches aidants d’adultes dans la même période de prestations (PP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#prestationsprochesaidantsenfantadultemem)

- Enfant gravement malade ou blessé atteint l’âge de 18 ans
         [Enfant gravement malade ou blessé atteint l’âge de 18 ans](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#enfantgravementmalade18ans)

- Traiter des prestations pour proches aidants

- Genre de demande (GD)
             [Genre de demande (GD)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Genre_de_demande)

- Inadmissibilités
             [Inadmissibilités](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Inadmissibilités)

- Antidate
             [Antidate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Antidate)

         [Traiter des prestations pour proches aidants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Traiter_les_demandes)

- Conditions requises
         [Conditions requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#requises)

- Conditions d’admissibilité

- Remplir les conditions avec la norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)
             [Remplir les conditions avec la norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#_remplir_les_condition)

- Fenêtre pour proches aidants (FPA)
             [Fenêtre pour proches aidants (FPA)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Fenêtre_pour_proches)

- Prestations maximales payables
             [Prestations maximales payables](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Prestations_maximales_payables)

- Prolongation de la période de prestations (PP)
             [Prolongation de la période de prestations (PP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Prolongation_de_la)

         [Conditions d’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Conditions_admissibilite)

- Délai de carence (DC )

- Reporter le délai de carence (DC)
             [Reporter le délai de carence (DC)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Report_du_DC)

- Supprimer le délai de carence (DC)
             [Supprimer le délai de carence (DC)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Suppression_du_DC)

         [Délai de carence (DC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Délai_de_carence)

- Document médical

- Prouver que le patient est gravement malade ou blessé
             [Prouver que le patient est gravement malade ou blessé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Prouver_que_le)

- Certificat médical ultérieur
             [Certificat médical ultérieur](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Certificat_médical_ultérieur)

- Fournir des soins ou du soutien
             [Fournir des soins ou du soutien](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Fournir_des_soins)

- Politique sur les nouveau-nés
             [Politique sur les nouveau-nés](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Politique_provisoire_visant)

         [Document médical](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Document_médical)

- Déclarations du prestataire

- Exemption de remplir des déclarations du prestataire
             [Exemption de remplir des déclarations du prestataire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Exemption_de_produire)

         [Déclarations du prestataire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#decpres)

- Questions liées à l’admissibilité

- Motif de cessation d’emploi (MCE) reporté
             [Motif de cessation d’emploi (MCE) reporté](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#MCE_reporté)

- Politique nationale sur les niveaux de décision
             [Politique nationale sur les niveaux de décision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Politique_sur_les)

- Répartition des sommes
             [Répartition des sommes](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Répartition_des_fonds)

- Non autrement disponible
             [Non autrement disponible](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Non_autrement_disponible)

- Partager des prestations
             [Partager des prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Partage_des_prestations)

- Plus d’un patient
             [Plus d’un patient](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#morethanone)

- Formation
             [Formation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#train)

- Hors Canada ou hors la région
             [Hors Canada ou hors la région](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#ouot)

- Enseignants
             [Enseignants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Prolonger_les_prestations)

         [Questions liées à l’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#QLA)

- Combiner des prestations
         [Combiner des prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#combiner)

- Conversions d’un autre genre de prestations (GP) en prestations pour proches aidants
         [Conversions d’un autre genre de prestations (GP) en prestations pour proches aidants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Conversions_d’un_autre)

- Conversions des prestations pour proches aidants en d’autres genres de prestations (GP)
         [Conversions des prestations pour proches aidants en d’autres genres de prestations (GP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Conversion_des_prestations)

**Prestations pour proches aidants d’enfants**

Les prestations pour proches aidants d’enfants assurent un revenu temporaire au client admissible qui doit s’absenter de son travail pour fournir des soins ou du soutien à un patient gravement malade ou blessé âgé de moins de 18 ans quand la fenêtre pour proches aidants (FPA) est établie. Le client peut recevoir un maximum de 35 semaines au cours de toute PP.

L’agent consulte Membre de la famille pour trouver une liste des membres de la famille admissibles et de parents proches et leurs relations au patient gravement malade ou blessé.
       [Membre de la famille](/fr/procedure/generic/additionalresources/definition_fam_mem.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0452.dita) 

**Prestations pour proches aidants d’adultes**

Les prestations pour proches aidants d’adultes assurent un revenu temporaire au client admissible qui doit s’absenter de son travail pour fournir des soins ou du soutien à un patient gravement malade ou blessé âgé de 18 ans ou plus quand la FPA est établie. Le client peut recevoir un maximum de 15 semaines au cours de toute PP.

L’agent consulter Membre de la famille pour trouver une liste des membres de la famille admissibles et de parents proches et leurs relations au patient gravement malade ou blessé.
       [Membre de la famille](/fr/procedure/generic/additionalresources/definition_fam_mem.shtml)

**Prestations pour proches aidants d’enfants et prestations pour proches aidants d’adultes dans la même période de prestations**

Les prestations pour proches aidants d’enfants et les prestations pour proches aidants d’adultes sont traitées comme des genres de prestations (GP) distincts. Chaque GP peut être payé dans une période de prestations (PP) pour son admissibilité maximale si le client remplit les conditions pour chaque GP. Cependant, les 2 GP ne peuvent pas être versés pour le même patient gravement malade ou blessé dans la même PP (voir l’enfant gravement malade ou blessé atteint l’âge de 18 ans).

**Enfant gravement malade ou blessé atteint l’âge de 18 ans**

Si un enfant gravement malade ou blessé atteint l’âge de 18 ans pendant la FPA, le client peut continuer de recevoir des prestations pour proches aidants d’enfants.

**Traiter des prestations pour proches aidants**

Le Centre de spécialisation à Sudbury traite toutes les demandes de prestations pour proches aidants et les agents du COPA dans les 4 régions sont responsables de la partie liée au traitement par le COPA.

Les demandes de prestations pour proches aidants ne sont pas automatisées. Elles sont saisies dans la version Web de SSA et transmises comme à l’habitude. La demande est établie dans SIP.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0453.dita) 

**Genre de demande (GD)**

Il existe 4 GD pour les prestations pour proches aidants :

- 20 - Proches aidants d’enfants

- 21 - Proches aidants d’adultes

- 78 - Travail autonome - Proches aidants d’enfants

- 90 - Travail autonome - Proches aidants d’adultes

**Inadmissibilités**

Quand le client ne fournit pas de soins ou de soutien au patient, l’agent impose une inadmissibilité 61 - Proches aidants d’enfants ou d’adultes - Ne rencontre pas les conditions d’admissibilité (D61).

Quand toutes les semaines ont été payées, l’agent impose une inadmissibilité 62 - Proches aidants d’enfants ou d’adultes - Prestations épuisées (D62).

Quand les exigences liées au certificat médical ne sont pas remplies, l’agent impose une inadmissibilité 63 - Proches aidants d’enfants ou d’adultes - Aucune preuve médicale (D63).

**Antidate**

Les principes du processus décisionnel normaux qui concernent les antidates s’appliquent aux demandes de prestations pour proches aidants. Pour plus de renseignements, l’agent consulter Antidate .
       [Antidate](/fr/procedure/activity/antedate.shtml)

Une antidate pour des prestations pour proches aidants est refusée si :

- au moment où la demande est présentée, des prestations pour proches aidants d’enfants ont été versées pendant 35 semaines;

- au moment où la demande est présentée, des prestations pour proches aidants d’adultes ont été versées pendant 15 semaines;

- la période d’admissibilité a déjà été établie pour un autre client et la demande d’antidate reporterait la semaine marquant le début de la fenêtre de 52 semaines à une date antérieure.

**Conditions requises**

Les conditions requises sont les mêmes que pour les autres prestations spéciales. Le client est admissible aux prestations pour proches aidants si les conditions suivantes sont remplies :

- Le client a subi un arrêt de la rémunération (A de R).

- Le client est de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable. S’il y a une violation à son dossier, une majoration des conditions requises pourrait s’appliquer.
         [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

**Remplir les conditions avec la norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)**

Dans le cadre du budget 2021, le gouvernement du Canada a annoncé qu’une NAC nationale de 420 heures d’emploi assurable s’applique pour établir une demande de prestations régulières ou spéciales. S’il y a une violation au dossier du client, la majoration des conditions requises peut s’appliquer. La NAC s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Pendant cette période, les définitions de clients de première et deuxième catégorie dans la LAE 6(1) sont abrogées. Les clients dont la demande est établie avec 420 heures d’emploi assurable remplissent les conditions requises pour recevoir des prestations spéciales. L’agent s’assure que toutes les autres conditions requises et d’admissibilité sont remplies.
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

**Conditions d’admissibilité**

Le client est admissible aux prestations pour proches aidants si les conditions suivantes sont remplies :

- Le client est un membre de la famille comme il est indiqué dans Membre de la famille .
         [Membre de la famille](/fr/procedure/generic/additionalresources/definition_fam_mem.shtml)

- Le patient gravement malade ou blessé a moins de 18 ans au moment où débute la fenêtre de 52 semaines (prestations pour proches aidants d’enfants).

- Le patient gravement malade ou blessé a 18 ans ou plus au moment où débute la fenêtre de 52 semaines (prestations pour proches aidants d’adultes).

- Le client soumet un certificat médical qui prouve que le patient est gravement malade ou blessé et qu’il a besoin des soins ou du soutien du client.

**Fenêtre pour proches aidants (FPA)**

La FPA de 52 semaines pendant laquelle des prestations sont payables commence à la première des dates suivantes :

- le jour où le médecin ou l’infirmier praticien a signé le premier certificat médical acceptable;

- Quand le certificat médical est émis avant que le client présente une demande de prestations pour proches aidants, la fenêtre de 52 semaines commence :

- le jour de l’examen où le médecin ou l’infirmier praticien confirme que le bénéficiaire de soins est gravement malade ou blessé, qu’il y a un changement considérable à l’état de santé normal du patient et que le patient a besoin de soins ou du soutien d’un membre de sa famille;

- le jour où le médecin ou l’infirmier praticien atteste que les conditions existaient antérieurement.

- Quand le certificat médical est émis après que le client présente une demande de prestations pour proches aidants, la fenêtre de 52 semaines commence :

- le jour de signature du certificat médical par le médecin ou l’infirmier praticien;

- le jour de l’examen où le médecin ou l’infirmier praticien confirme que le bénéficiaire de soins est gravement malade ou blessé, qu’il y a un changement considérable à l’état de santé normal du patient et que le patient a besoin de soins ou du soutien d’un membre de sa famille.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0454.dita) 

**Date de début de la fenêtre pour proches aidants (FPA) pour un nouveau-né**

Si le certificat médical ne précise pas de date de début quand les conditions sont remplies ou si la date fournie correspond à la date de la signature, la date de début de la FPA est déterminée comme suit :

- Si la date à laquelle le médecin ou l’infirmier praticien a signé le certificat médical est de 4 semaines ou moins après la semaine de naissance de l’enfant (semaine de naissance + 4), la date de début de la FPA est la semaine de naissance de l’enfant.

- Si la date à laquelle le médecin ou l’infirmier praticien a signé le certificat médical est de 5 semaines ou plus après la semaine de naissance de l’enfant (semaine de naissance + 5), la date de début de la FPA est la date de signature.

La date de début de la FPA doit toujours être basée sur ce qui est le mieux pour le client. Il peut être nécessaire de rechercher des faits avec le client pour déterminer ce qui est le plus avantageux. Pour plus d’informations, l’agent se réfère aux Prestations pour proches aidants – Nouveau-nés – AP 2025-01 (Note de service AP) .
       [Prestations pour proches aidants – Nouveau-nés – AP 2025-01 (Note de service AP)](/fr/policy/bememo/be2025-01.shtml)

La FPA prend fin à la première des dates suivantes :

- la fenêtre de 52 semaines a expiré;

- les 35 semaines de prestations pour proches aidants d’enfants ou les 15 semaines de prestations pour proches aidants d’adultes ont été payées (à plus d’une personne ou à une seule personne);

- le patient gravement malade ou blessé meurt.

**Prestations maximales payables**

Les clients peuvent recevoir un maximum de 35 semaines de prestations pour proches aidants d’enfants et 15 semaines pour proches aidants d’adultes pendant toute PP. Les clients peuvent partager les prestations pour proches aidants. Les prestations pour proches aidants ne sont pas forcément versées consécutivement. Elles peuvent être versées de façon intermittente pendant la PP ou à l’intérieur de la FPA de 52 semaines, de façon à convenir le mieux aux clients, pourvu que le certificat médical requis prouve la maladie ou la blessure grave du patient durant les semaines demandées.

**Prolongation de la période de prestations (PP)**

La PP peut être prolongée pour un maximum de 104 semaines aux fins du versement de semaines supplémentaires de prestations pour proches aidants quand toutes les conditions sont remplies avant la fin de la PP. Pour plus de renseignements, l’agent consulte Prolongation de la période de prestations . Pour plus de renseignements sur la prolongation de la PP, l’agent consulte Prolongation de la période de prestations pour des prestations spéciales .
       [Prolongation de la période de prestations](/fr/procedure/activity/extension_benefit_period.shtml) 
       [Prolongation de la période de prestations pour des prestations spéciales](/fr/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

**Délai de carence (DC)**

Le client doit observer un DC pour recevoir des prestations pour proches aidants. Dans certaines situations, le DC peut être reporté ou supprimé.

**Reporter le délai de carence (DC)**

Le DC normal d’une semaine s’applique aux prestations pour proches aidants. Dans certains cas, un seul DC est observé pour un même membre de la famille gravement malade.

Le DC peut être reporté quand :

- un autre membre de la famille a reçu le même genre de prestations pour proches aidants pour le même patient et a déjà observé le DC;

- plusieurs membres de la famille demandent des prestations pour le même patient, et un autre membre de la famille observe le DC;

Le DC est reporté jusqu’à la demande d’un autre GP.

**Supprimer le délai de carence (DC)**

Les dispositions actuelles pour supprimer le DC s’appliquent aux demandes de prestations pour proches aidants quand les conditions suivantes sont remplies

- Après son dernier jour de travail (DJT), le client a obtenu un congé de maladie payé (CMP) de son employeur.

- Le client a connu un A de R de son emploi en vertu du RAE 14.2 pour les prestations spéciales.
         [RAE 14.2](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/page-4.html)

**Document médical**

**Prouver que le patient est gravement malade ou blessé**

Pour prouver que le patient est gravement malade ou blessé et qu’il a besoin de soins ou du soutien d’un membre de la famille, le client doit obtenir un certificat médical attestant que l’état de santé normal du patient a changé de façon considérable, et la vie du patient est en danger par suite d’une maladie ou d’une blessure. De plus, le mauvais état de santé de ce patient fait en sorte qu’il requiert les soins ou le soutien d’un membre de la famille. Le certificat médical doit être signé par un médecin ou un infirmier praticien.

Période de soins et de soutien

Si le médecin ou l’infirmier praticien indique que la période de soins ou de soutien est inconnue ou indéterminée, cela ne donne aucune précision sur la durée escomptée des soins ou du soutien dont le patient aura besoin.

Le médecin ou l’infirmier praticien doit fournir la période pendant laquelle le patient nécessite des soins ou du soutien. Si la période correspond à un nombre précis de semaines plutôt qu’à des dates de début et de fin, la période de soins et de soutien commence à la date d’émission du certificat médical.

Le patient ou son représentant doit remplir et signer le formulaire Autorisation de divulguer des renseignements médicaux pour des prestations de compassion et pour proches aidants de l’assurance emploi (INS5257) pour que le médecin ou l’infirmier praticien puisse divulguer les renseignements médicaux.
       [Autorisation de divulguer des renseignements médicaux pour des prestations de compassion et pour proches aidants de l’assurance emploi](http://forms-formulaires.prv/lc/apps/EForms/pdf/fr/SC-INS5242A.pdf)

Un client qui présente une demande de prestations pour proches aidants doit soumettre le formulaire Certificat médical - Prestations d’assurance-emploi pour les proches aidants .
       [Certificat médical - Prestations d’assurance-emploi pour les proches aidants](http://forms-formulaires.prv/eform99/index.cfm?App=Launch&FormID=6856&GroupID=203&LANG=F)

Le patient gravement malade ou blessé ne réside pas toujours au Canada et le client peut devoir quitter le pays pour fournir des soins ou du soutien au patient, quel que soit l’endroit où il habite. Dans ces situations, le client doit quand même soumettre un Certificat médical - Prestations d’assurance-emploi pour les proches aidants rempli par un médecin ou un infirmier praticien.
       [Certificat médical - Prestations d’assurance-emploi pour les proches aidants](http://forms-formulaires.prv/eform99/index.cfm?App=Launch&FormID=6856&GroupID=203&LANG=F)

Pour déterminer si un certificat médical est acceptable, l’agent consulte Déterminer si un certificat médical est acceptable — Prestations pour proches aidants .
       [Déterminer si un certificat médical est acceptable — Prestations pour proches aidants](/fr/procedure/task/determining_pcic_med_cert.shtml)

**Certificat médical ultérieur**

La période pendant laquelle le patient a besoin de soins ou de soutien comprend la période initiale au cours de laquelle le patient est gravement malade ou blessé ainsi que la période de guérison suivant le moment où l’état de santé du patient s’est amélioré, mais que son état n’est pas encore revenu à l’état de santé normal.

Ainsi, le spécialiste peut émettre un deuxième certificat médical afin de permettre au client de toucher des prestations durant la période de guérison du patient.

Un client qui demande des prestations au cours de la période de guérison doit présenter un formulaire Autorisation de divulguer des renseignements médicaux pour des prestations de compassion et pour proches aidants de l’assurance emploi (INS5257) ultérieur et un formulaire Certificat médical - Prestations d’assurance-emploi pour les proches aidants (INS5242B).
       [Autorisation de divulguer des renseignements médicaux pour des prestations de compassion et pour proches aidants de l’assurance emploi](http://forms-formulaires.prv/lc/apps/EForms/pdf/fr/SC-INS5242A.pdf) 
       [Certificat médical - Prestations d’assurance-emploi pour les proches aidants](http://forms-formulaires.prv/lc/apps/EForms/pdf/fr/SC-INS5242B.pdf)

**Fournir des soins ou du soutien**

Un patient peut avoir besoin des soins ou du soutien d’un membre de la famille en raison de son état de santé, et de soutien psychologique ou moral.

La définition des soins et du soutien comprend les situations où le client passe simplement du temps chaque jour auprès du patient gravement malade à son domicile, dans un centre de soins palliatifs ou dans une installation de soins de santé. Le client peut cesser de fournir des soins au patient pendant quelques jours quand il reçoit des prestations pour proches aidants.

Pour déterminer si un client fournit des soins ou du soutien à un patient gravement malade, l’agent consulte Déterminer si un client qui présente une demande de prestations pour proches aidants fournit des soins ou du soutien à patient gravement malade ou blessé .
       [Déterminer si un client qui présente une demande de prestations pour proches aidants fournit des soins ou du soutien à patient gravement malade ou blessé](/fr/procedure/task/determining_pcic_benefit_child.shtml)

**Politique sur les nouveau-nés**

La Politique sur les nouveau-nés fournit des directives quand des prestations pour proches aidants sont demandées pour un nouveau-né.
       [Politique sur les nouveau-nés](/fr/policy/bememo/be2025-01.shtml)

**État de santé de base**

Le certificat médical est accepté même s’il ne confirme pas un changement important dans l’état de santé de base.

Un enfant dont la vie est en danger dès sa naissance en raison d’une maladie ou d’une blessure grave n’a pas d’état de santé de base. Par conséquent, sur le formulaire Certificat médical pour les prestations pour proches aidants de l’assurance-emploi, la réponse à la question 2 de la section B peut être Oui, Non ou laissée en blanc.

**Date de début de la période de prestations pour proches aidants**

Si le certificat médical ne précise pas de date de début quand les conditions sont remplies (vie en danger en raison d’une maladie ou d’une blessure, changement de l’état de santé de base et que des soins ou un soutien sont nécessaires) ou si la date fournie correspond à la date de la signature, la date de début de la FPA est déterminée comme suit :

- Si la date à laquelle le médecin ou l’infirmier praticien a signé le certificat médical est de 4 semaines ou moins après la semaine de naissance de l’enfant (semaine de naissance + 4), la date de début de la FPA est la semaine de naissance de l’enfant.

- Si la date à laquelle le médecin ou l’infirmier praticien a signé le certificat médical est de 5 semaines ou plus après la semaine de naissance de l’enfant (semaine de naissance + 5), la date de début de la FPA est la date de signature.

- La date de début de la FPA doit toujours être basée sur ce qui est le mieux pour le client. Il peut être nécessaire de rechercher des faits avec le client pour déterminer ce qui est le plus avantageux. Pour plus d’informations, l’agent se réfère aux Prestations pour proches aidants – Nouveau-nés – AP 2025-0 1 (Note de service AP).
         [Prestations pour proches aidants – Nouveau-nés – AP 2025-0](/fr/policy/bememo/be2025-01.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0455.dita) 

**Déclarations du prestataire**

Quand la demande est dans SMP, le client doit remplir des déclarations du prestataire papier sauf si une exemption de remplir des déclarations du prestataire est demandée.

**Exemption de remplir des déclarations du prestataire**

Un client peut être exempté de remplir des déclarations du prestataire pendant qu’il reçoit des prestations pour proches aidants. Quand la demande est dans SMP, l’agent envoie une transaction Mémo pour le centre opérationnel (MM06) au COPA demandant de saisir l’indicatif PAS-IND-DP. Pour plus de renseignements, l’agent consulte Saisir une exemption de remplir des déclarations du prestataire . Quand le client ne remplit plus les critères d’admissibilité (p. ex. des prestations pour proches aidants converties en prestations de maladie ou un client déclare travailler à temps partiel). L’agent envoie une transaction MM06 au COPA demandant d’annuler l’indicatif PAS-IND-DP. Pour plus de renseignements, l’agent consulte Annuler une exemption de remplir des déclarations du prestataire .
       [Saisir une exemption de remplir des déclarations du prestataire](/fr/procedure/task/inputting_exemption_rep.shtml) 
       [Annuler une exemption de remplir des déclarations du prestataire](/fr/procedure/task/cancelling_exemption_rep.shtml)

**Questions liées à l’admissibilité**

**Motif de cessation d’emploi (MCE) reporté**

Dans une demande initiale de prestations pour proches aidants, l’agent peut reporter le recueil de faits et la décision concernant un MCE litigieux si certaines conditions sont remplies.

Si une exclusion indéfinie a été imposée à la suite d’une décision rendue dans une demande de renouvellement de prestations pour proches aidants, l’agent peut reporter le recueil de faits et la décision sur un MCE litigieux. Les prestations spéciales sont versées, peu importe si le client a accumulé assez d’heures pour établir une nouvelle demande.

Pour plus de renseignements, l’agent consulte Report de la décision .
       [Report de la décision](/fr/procedure/activity/deferral_adj.shtml)

**Politique nationale sur les niveaux de décision**

Pour déterminer si une décision relève du Niveau 1, l’agent consulte la Politique nationale sur les niveaux de décision .
       [Politique nationale sur les niveaux de décision](/fr/policy/nationalpolicy/levels_decision-annex1.shtml)

Si la décision ne relève pas du Niveau 1, la question peut être renvoyée au Niveau 2 pour qu’une décision soit rendue de la façon suivante :

- Commencer le recueil de faits.

- Saisir la conversion.

- Imposer un traitement manuel pour arrêter le paiement (TM01).

**Répartition des sommes**

Quand un client déclare qu’il reçoit des sommes, l’agent doit déterminer si les sommes reçues doivent être considérées comme étant des revenus aux fins de l’AE. Si l’agent détermine que les sommes sont considérées comme étant des revenus, il consulte Rémunération pour déterminer la façon de répartir ces fonds.
       [Rémunération](/fr/procedure/activity/earnings.shtml)

Travail pendant une période de prestations (TPP)

La rémunération déclarée dans une demande de prestations pour proches aidants sera déduite de la même façon que pour les prestations parentales, de compassion, et régulières selon les dispositions relatives au TPP.

Pour plus de renseignements, l’agent consulte Projet pilote 17 : Augmentation de la rémunération admissible — Calcul de déduction de la rémunération et Projet pilote : Travail pendant une période de prestations — Calcul de déduction de la rémunération .
       [Projet pilote 17 : Augmentation de la rémunération admissible — Calcul de déduction de la rémunération](/fr/procedure/generic/additionalresources/pp_iae_edc.shtml) 
       [Projet pilote : Travail pendant une période de prestations — Calcul de déduction de la rémunération](/fr/procedure/generic/additionalresources/pp_wwoc_edc.shtml)

**Non autrement disponible**

Pour avoir droit aux prestations pour proches aidants, les clients n’ont pas à démontrer qu’ils seraient autrement disponibles ou qu’ils seraient autrement au travail.

**Partager des prestations**

La législation prévoit qu’un ou plusieurs clients admissibles peuvent partager les prestations pour proches aidants pour un patient gravement malade ou blessé. L’agent peut diviser les semaines conformément à l’entente conclue entre les clients. Quand les prestations sont partagées, l’agent doit déterminer si d’autres membres de la famille demandent ou ont demandé des prestations pour proches aidants pour prendre soin du même patient gravement malade, ainsi que le nombre de semaines de prestations demandées par les autres membres de la famille. Quand les clients admissibles ne parviennent pas à une entente, l’agent divise le nombre de semaines restantes d’après les règles prescrites. Pour plus de renseignements, l’agent consulte Rendre une décision sur le partage des prestations pour proches aidants — Désaccord sur le partage des semaines .
       [Rendre une décision sur le partage des prestations pour proches aidants — Désaccord sur le partage des semaines](/fr/procedure/task/adjudicating_na_pcic_bw.shtml)

**Plus d’un patient**

Il peut arriver des situations où il y a plusieurs patients gravement malades ou blessés. Des périodes de 52 semaines distinctes peuvent être établies pour chaque patient gravement malade ou blessé. Le nombre maximal de semaines de prestations payables se définit de la façon suivante :

- un maximum de 35 semaines par enfant ou 15 semaines par adultes durant la FPA de 52 semaines connexe; et

- un maximum de 35 semaines (prestations pour proches aidants d’enfants) ou 15 semaines (prestations pour proches aidants d’adultes) peut être payé durant n’importe quelle PP.

Chaque membre de la famille pourrait établir une PP pour un patient et être payable pour le maximum de semaines pour proches aidants, ou les membres de la famille peuvent également partager les semaines visant chaque patient jusqu’au maximum par patients et par PP.

**Formation**

Un agent de Niveau 1 peut accorder des prestations pour proches aidants quand le client participe à un cours de formation non dirigé en vertu de la LAE 25 si :

- le cours de formation est de moins de 25 heures par semaine;

- le cours de formation n’est pas offert dans un endroit qui oblige le client à vivre éloigné du patient pendant qu’il suit le cours.

Pour plus de renseignements, l’agent consulte Cours de formation .
       [Cours de formation](/fr/procedure/activity/training.shtml)

**Hors Canada ou hors de la région**

Le patient gravement malade ou blessé ne réside pas toujours au Canada, et le client pourrait devoir quitter le pays pour fournir des soins ou du soutien au patient, quel que soit l’endroit où il vit. Dans de tels cas, le client doit quand même soumettre un certificat médical rempli par un médecin ou un infirmier praticien, accompagné du même type de preuve requise pour un patient gravement malade ou blessé résidant au Canada.

Quand le client fournit les renseignements requis et remplit toutes les autres conditions d’admissibilité, les prestations pour proches aidants peuvent être versées pendant que le client est à l’extérieur du Canada ou de la région.

Le client peut cesser de fournir des soins au membre de la famille pendant une brève période (jusqu’à 2 jours) pendant qu’il reçoit des prestations pour proches aidants. Un agent doit rendre une décision sur tous les cas où le client cesse, pendant plus de 2 jours, de fournir des soins au patient gravement malade ou blessé.

**Enseignants**

Comme c’est le cas pour les prestations de maternité, parentales et les PDC, les prestations pour proches aidants sont payables aux enseignants durant les périodes d’enseignement et de congé, pourvu que le client remplisse toutes les autres conditions d’admissibilité pour le versement de ces prestations.

Pour plus de renseignements, l’agent consulte Enseignants .
       [Enseignants](/fr/procedure/activity/teachers.shtml)

**Combiner des prestations**

Des prestations spéciales peuvent être versées en combinaison avec tout autre GP pendant la PP initiale, pourvu que le client prouve son admissibilité à chaque GP et ne dépasse pas l’admissibilité maximale aux prestations .
       [l’admissibilité maximale aux prestations](/fr/procedure/generic/additionalresources/max_ent_ben.shtml)

**PDC et prestations pour proches aidants**

Si l’état de santé du patient gravement malade se dégrade et entraîne une situation de fin de vie, le client recevant les prestations pour proches aidants peut demander et recevoir jusqu’à 26 semaines de PDC une fois que la FPA prend fin (toutes les semaines de prestations ont été versées ou la période de 52 semaines s’est écoulée).

Si les PDC ont d’abord été versées et qu’il y a un nouveau changement important à l’état de santé normal du patient, le client peut recevoir des prestations pour proches aidants. Il n’est pas nécessaire que la fenêtre de compassion prenne fin pour que des prestations pour proches aidants deviennent payables.

Toutefois, un membre de la famille qui continue de recevoir des PDC pour s’occuper du patient n’y sera plus admissible si un autre membre de la famille commence à recevoir des prestations pour proches aidants. Dans de telles situations, l’autre membre de la famille doit convertir sa demande et partager les prestations pour proches aidants ou attendre que la FPA prenne fin (toutes les semaines de prestations ont été versées ou la période de 52 semaines s’est écoulée). Si le client demande des PDC avant que toutes les semaines de prestations pour proches aidants aient été versées ou avant la fin de la FPA, l’agent impose une inadmissibilité 51 - Ne rencontre pas les conditions d’admissibilité de prestations de soins de compassion et envoie la lettre SCA appropriée.

**Conversions d’un autre genre de prestations (GP) en prestations pour proches aidants**

Quand le client demande la conversion d’un GD en prestations pour proches aidants, l’agent saisit les renseignements suivants dans ETI :

- Avec ou sans date d’entrée en vigueur, l’agent fait passer le GD à 20, 21, 78 ou 90.

- Si une inadmissibilité est requise, l’agent saisit l’inadmissibilité appropriée.

- La dernière semaine du GP précédent doit être payée avant que l’agent saisisse les transactions de la conversion.

- Si le GD passe de prestations régulières à prestations pour proches aidants, une semaine de renouvellement doit être saisie par la transaction Proches aidants/Soins de compassion - Admissibilité du prestataire (M112) .

- Si le client a fourni un certificat médical non acceptable ou s’il ne remplit pas les conditions d’admissibilité, aucune transaction MM06 n’est requise. Si le client est admissible aux prestations, l’agent crée une transaction MM06 pour demander au COPA de convertir la demande à SMP et de continuer à verser les prestations.

**Conversions des prestations pour proches aidants en d’autres genres de prestations (GP)**

Les conversions sont effectuées selon la charge de travail liée au traitement et ne doivent pas être assignées ou réassignées au Centre de spécialisation.

Si le client présente une demande de conversion pour des prestations de maladie, parentales ou régulières, l’agent remplit la liste de vérification appropriée avec le client.

Un client qui demande une conversion en PDC doit remplir une demande en ligne. Les PDC peuvent être versées avant le commencement de la FPA ou après qu’elle prend fin, mais les PDC ne peuvent pas être versées pendant une FPA existante pour le même patient. La FPA prend fin quand toutes les semaines des prestations pour proches aidants ont été versées ou quand la fenêtre de 52 semaines prend fin.

Si la cliente présente une demande de conversion pour des prestations de maternité, l’agent vérifie si elle a déjà rempli une demande de prestations de maternité pour ce DPP. Si oui, l’agent consulte l’aide-mémoire pour effectuer la conversion. Sinon, l’agent avise le client de remplir une demande en ligne.

L’agent note et avise le client que si une conversion vers des prestations de maternité, des prestations parentales ou des PDC est effectuée, les versements et les déclarations du prestataire sont traités dans SMP pour le reste de la demande. Dans ce cas, le client doit remplir des déclarations du prestataire papier, sauf si une exemption de remplir des déclarations du prestataire est demandée. Après l’examen de la demande de conversion et des conditions d’admissibilité, l’agent crée une transaction MM06 afin de soumettre la demande de conversion.

Au moment de créer une transaction MM06, l’agent ajoute tous les renseignements nécessaires pour effectuer la conversion. Cela inclut :

- le GP demandé;

- la période pour laquelle les prestations doivent être versées;

- le nombre de semaines demandé (au besoin);

- toute répartition requise, les prolongations de la PP, les inadmissibilités, etc.

- l’exemption de remplir des déclarations du prestataire

**Procédures connexes**

- Déterminer si un certificat médical est acceptable — Prestations pour proches aidants
         [Déterminer si un certificat médical est acceptable — Prestations pour proches aidants](/fr/procedure/task/determining_pcic_med_cert.shtml)

- Déterminer si un client qui présente une demande de prestations pour proches aidants fournit des soins ou du soutien à un membre de la famille gravement malade ou blessé
         [Déterminer si un client qui présente une demande de prestations pour proches aidants fournit des soins ou du soutien à un membre de la famille gravement malade ou blessé](/fr/procedure/task/determining_pcic_benefit_child.shtml)

- Rendre une décision sur le partage des prestations pour proches aidants — Désaccord sur le partage des semaines
         [Rendre une décision sur le partage des prestations pour proches aidants — Désaccord sur le partage des semaines](/fr/procedure/task/adjudicating_na_pcic_bw.shtml)

- Déterminer si le client est admissible aux semaines de prestations pour proches aidants demandées
         [Déterminer si le client est admissible aux semaines de prestations pour proches aidants demandées](/fr/procedure/task/determine_client_fcb_pppa.shtml)

- 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0452.dita`

Remarque :

Avant le 3 décembre 2017, ces prestations étaient connues comme des prestations pour PEGM et n’étaient payables qu’aux parents de l’enfant gravement malade. Elles sont maintenant payables à un membre de la famille de l’enfant.
       [membre de la famille](/fr/procedure/generic/additionalresources/definition_fam_mem.shtml)

     [membre de la famille](/fr/procedure/generic/additionalresources/definition_fam_mem.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0453.dita`

Remarque :

Les demandes de prestations pour proches aidants d’enfants et de prestations pour proches aidants d’adultes traitées initialement dans SMP avant la mise en œuvre de la Phase 2 du Budget 2017 ne sont pas converties au SIP. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0454.dita`

Remarque :

Quand la date de l’examen et la date à laquelle le médecin ou l’infirmier praticien confirme que les conditions existaient antérieurement sont différentes, la date de début de la FPA est la date qui permet au client de recevoir les semaines demandées. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0455.dita`

Remarque :

À condition que toutes les autres exigences soient remplies : le certificat médical est signé, le médecin ou l’infirmer praticien a été validé et l’autorisation est signée par la bonne personne. 
