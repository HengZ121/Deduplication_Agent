# Calcul : Retrait du processus d’attente du TAD — Instructions

Source map: `fr_FR/procedure/generic/additionalresources/removing_initial_claims_acp/removing_initial_claims_acp.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/removing_initial_claims_acp/ressources_additionnelles.dita`

Dans certains cas, un employé à l’administration centrale peut interrompre le processus d’attente du TAD afin d’éviter des paiements erronés ou des retards pour les clients.

Le tableau ci-dessous énumère les seules conditions (1a, 1b, 2, 3, 4, 5, 6, ou 7) qui permettent à un agent de créer un AT À revoir (AR) pour retirer la demande du TAD.

- Avant de créer l’AT AR, l’agent doit s’assurer que tous les documents nécessaires figurent au dossier (p. ex. tous les RE, décision sur l’assurabilité). Si les documents nécessaires ne figurent pas au dossier, l’AT AR est supprimé sans que l’agent soit contacté.

- Les nouveaux faits doivent être consignés dans un RSDP, un AT Action à prendre (AP) ou un AT Rappel (RA), selon les procédures actuelles.

Avant de soumettre la demande, l’agent examine la demande pour s’assurer que toutes les autres mesures en suspens nécessaires au traitement ont été prises.

Les demandes doivent seulement être soumises si l’une des conditions suivantes est remplie. Si une demande ne remplit pas l’une des conditions nécessaires, l’AT AR est supprimé.

```text
| # | Situation | Condition | Tâches connexes de l’ORL AE |

| 1 | Périodes d’emploi déclarées en double dans AW (1a) ou Un seul RE soumis pour plusieurs périodes d’emploi (1b) | Même période d’emploi déclarée plus d’une fois sur la demande - 1a. Le client déclare le même employeur plus d’une fois sur la demande ayant les mêmes dates. ou - 1b. Le client déclare plusieurs périodes d’emploi avec le même employeur, mais l’employeur n’a soumis qu’un RE pour toutes les périodes d’emploi. | Calcul d’une demande [Calcul d’une demande](/fr/procedure/generic/additionalresources/index_calc_claim.shtml) |

| 2 | L’emploi n’est pas assurable et le RE ne sera pas soumis | Emploi non assurable — Le RE ne sera pas soumis - Le client indique qu’un RE sera soumis bientôt, mais l’emploi est par la suite considéré comme non assurable. [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0584.dita) | Assurabilité Congédiement Départ volontaire [Assurabilité](/fr/procedure/activity/asmt_insurability.shtml) [Congédiement](/fr/procedure/activity/dismissal.shtml) [Départ volontaire](/fr/procedure/activity/voluntary_leaving.shtml) |

| 3 | Le dernier jour de travail (DJT) pour le dernier employeur dans AW est plus de 33 jours après le dernier jour payé (DJP) sur le RE | Différence de plus de 33 jours entre le DJT sur la demande AW et le DJP sur le RE - Cette condition s’applique seulement quand le DJT sur la demande d’AE est plus de 33 jours après le DJP sur le RE. Exemple : DJT sur la demande d’AE : 15 février 2016 DJP sur le RE : 3 janvier 2016 (date exacte) [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0585.dita) | Calcul d’une demande [Calcul d’une demande](/fr/procedure/generic/additionalresources/index_calc_claim.shtml) |

| 4 | Le RE ne se situe pas dans la période de référence (PR) | Les dates d’emploi pour « Autres employeurs » ne se situent pas dans la PR - Les dates que le client a fournies dans AW à la section Autres Employeurs se situent dans la PR, mais les dates réelles sur le RE ne se situent pas dans la PR. Exemple : DPP : s/c 2034 (12 juin 2016) PR : 14 juin 2015 au 11 juin 2016 DJT sur la demande d’AE, dans la section Autres employeurs : 16 juin 2015 DJP sur le RE : 3 juin 2015 [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0586.dita) | Calcul d’une demande [Calcul d’une demande](/fr/procedure/generic/additionalresources/index_calc_claim.shtml) |

| 5 | Aucun arrêt de rémunération (A de R) | Le RE a été soumis avec le motif de cessation d’emploi (MCE) K - Autre . L’agent a communiqué avec l’employeur et a déterminé qu’il n’y a pas eu d’A de R avec cet employeur. Une fois que l’AT AR est soumis : - Déplacer l’AT Litige - Décision (DEC) vers En suspens pour 2 jours ouvrables ou jusqu’à ce que l’AT Évaluation de la demande (EVD) soit créé. - Supprimer l’AT DEC (agents autorisés seulement) une fois que l’AT EVD est créé. [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0587.dita) | Traiter un AT Litige - Décision Examen du MCE : K - Autre [Traiter un AT Litige - Décision Examen du MCE : K - Autre](/fr/procedure/task/adj_rfs_review_k_other.shtml) |

| 6 | Antidate accordée | Une antidate a été accordée dans la demande qui est en cours d’automatisation. | Antidate Calcul d’une demande [Antidate Calcul d’une demande](/fr/procedure/generic/additionalresources/index_calc_claim.shtml) |

| 7 | Correction du genre de prestations (GP) | Le client a présenté une demande pour le mauvais GP et la demande est en cours d’automatisation. [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0588.dita) | Corriger le genre de prestations pendant le processus d’automatisation [Corriger le genre de prestations pendant le processus d’automatisation](/fr/procedure/task/correcting_benefit_type_during_automation.shtml) |
```

```text
| Créer un AT AR de la façon suivante : |

| - Commentaires : Choisir Niveau 1 . - Motif : Choisir Autre . - Commentaires: Saisir « TAD. » - Date d’échéance : Saisir la date d’aujourd’hui. - Langue : Choisir l’option appropriée. - Détails : Saisir « [1a, 1b, 2, 3, 4, 5, 6, ou 7] et [non-assigné (NA) ou le nom de l’agent à qui l’AT Évaluation de la demande (EVD) ou Demande spécialisée (DS) doit être assigné]. » - Destination — Niveau : Choisir Canada . - Utilisateur final : Choisir Utilisateur spécifique et saisir « SV-Admin, ACP-TAD. » - Choisir Sauvegarder . |
```

Pour toutes autres situations, l’agent consulte un conseiller en expertise opérationnelle pour déterminer si l’équipe responsable à l’administration centrale doit être contactée. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0584.dita`

Remarque :

Un agent doit quand même examiner les nouveaux faits sur l’assurabilité de l’emploi, effectuer la vérification de l’assurabilité et consigner la décision sur l’assurabilité. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0585.dita`

Remarque :

TAD attend un RE dont le DJP est le 13 janvier 2016 ou plus tard, selon le DJT déclaré dans la section Renseignements sur le dernier employeur dans AW. Si l’agent confirme que le DJT est effectivement le même que celui sur le RE, aucun RE supplémentaire ne sera soumis. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0586.dita`

Remarque :

La PR peut être inférieure à 52 semaines si le client a une demande précédente. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0587.dita`

Remarque :

Si le recueil de faits révèle qu’il n’y a pas eu d’A de R, les documents doivent figurer au dossier. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0588.dita`

Remarque :

Il ne doit pas y avoir d’AT DEC en suspens. 
