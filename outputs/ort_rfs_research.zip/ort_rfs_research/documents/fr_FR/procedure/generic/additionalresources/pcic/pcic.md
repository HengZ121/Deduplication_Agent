# PEGM : Renseignements sur les prestations — Connaissances

Source map: `fr_FR/procedure/generic/additionalresources/pcic/pcic.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/pcic/ressources_additionnelles.dita`

Sommaire : Les prestations pour parents d’enfants gravement malades (PEGM) assurent aux parents admissibles qui doivent s’absenter de leur travail pour fournir des soins ou du soutien à un enfant gravement malade ou blessé, jusqu’à 35 semaines de remplacement de revenu temporaire.

**Table des matières**

- Traiter les demandes de prestations pour PEGM

- Genre de demande
             [Genre de demande](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#claimtype)

- Antidatation
             [Antidatation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#antedate)

         [Traiter les demandes de prestations pour PEGM](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#processing)

- Conditions d’admissibilité

- Fenêtre des prestations pour PEGM
             [Fenêtre des prestations pour PEGM](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#BPwindow)

- Prestations maximales payables
             [Prestations maximales payables](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#max)

- Prolongation de la période de prestations
             [Prolongation de la période de prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#bpext)

- Code PAS-DP
             [Code PAS-DP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#NOCR)

         [Conditions d’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#conditions)

- Délai de carence

- Report du délai de carence
             [Report du délai de carence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#deferralwp)

- Suppression du délai de carence
             [Suppression du délai de carence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#waivingwp)

         [Délai de carence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#wp)

- Document médical

- Prouver que l’enfant est gravement malade ou blessé
             [Prouver que l’enfant est gravement malade ou blessé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#proof)

- Certificat médical ultérieur
             [Certificat médical ultérieur](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#subsequent)

- Fournir des soins ou du soutien
             [Fournir des soins ou du soutien](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#providingcare)

- Politique provisoire visant les nouveau-nés
             [Politique provisoire visant les nouveau-nés](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#interim)

- Inadmissibilités
             [Inadmissibilités](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#disent)

         [Document médical](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#meddoc)

- Questions liées à l’admissibilité

- Motif de cessation d’emploi (MCE) reporté
             [Motif de cessation d’emploi (MCE) reporté](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#deferred)

- Politique sur les niveaux de décision
             [Politique sur les niveaux de décision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#LOD)

- Répartition des sommes
             [Répartition des sommes](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#monies)

- Non autrement disponible
             [Non autrement disponible](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#NOA)

- Partage des prestations
             [Partage des prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#sharing)

- Plus d’un enfant

- Même événement
                 [Même événement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#same)

- Événements non liés
                 [Événements non liés](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#unrelated)

             [Plus d’un enfant](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#morethanone)

         [Questions liées à l’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#Ent)

- Prolonger les prestations pour PEGM

- MM06
             [MM06](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#MM06)

         [Prolonger les prestations pour PEGM](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#Renewal)

- Conversions d’un autre genre de prestations en prestations pour PEGM

- Déclaration du prestataire
             [Déclaration du prestataire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#ConvCR)

- MM06
             [MM06](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#ConveMM06)

         [Conversions d’un autre genre de prestations en prestations pour PEGM](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#another)

- Conversion des prestations pour PEGM en d’autres genres de prestations
         [Conversion des prestations pour PEGM en d’autres genres de prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pcic#fromPCIC)

**Traiter les demandes de prestations pour PEGM**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0542.dita) 

Toutes les demandes de prestations pour PEGM sont traitées au Centre de spécialisation de Sudbury et la portion relative au traitement COPA est complétée par les COPA de chacune des 4 régions.

Les demandes de prestations pour PEGM ne sont pas automatisées; elles sont traitées dans la version Web de SSA et transmises comme d’habitude. Les demandes sont configurées dans SIP, mais aucun paiement n’est versé : la demande est convertie au SMP et toutes les déclarations du prestataire sont traitées par le COPA.

**Genre de demande**

Il existe 2 genres de demandes pour les prestations pour PEGM :

- GD20 - Prestations régulières pour PEGM

- GD78 - Prestations pour PEGM pour travailleurs autonomes

**Antidatation**

Les principes normaux en matière d’évaluation qui concernent les antidatations s’appliquent. L’agent peut consulter Antidate pour obtenir plus de renseignements.
       [Antidate](/fr/procedure/activity/antedate.shtml)

Une antidatation est refusée si :

- au moment où la demande est présentée, des prestations pour PEGM ont été versées pendant 35 semaines; ou

- la période d’admissibilité aux prestations pour PEGM a déjà été établie pour un autre client et la demande d’antidatation reporterait la semaine marquant le début de la fenêtre de 52 semaines à une date antérieure.

**Conditions d’admissibilité**

Les conditions d’admissibilité sont les mêmes que pour d’autres prestations spéciales, et jusqu’à 35 semaines de prestations pour PEGM peuvent être versées par période de prestations si les conditions d’admissibilité suivantes sont remplies :

- Le client a subi un arrêt de la rémunération;

- Le client a au moins 600 heures d’emploi assurable au cours de la période de référence ( prestataire de la première catégorie ). S’il y a une violation au dossier du client, pour déterminer le nombre d’heures requis, consulter Majoration du nombre d’heures d’emploi assurable requis .
         [prestataire de la première catégorie](/fr/procedure/generic/knowledge.shtml#client12) 
         [Majoration du nombre d’heures d’emploi assurable requis](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

- Être le parent légal (y compris un parent adoptif) ou le tuteur légal (au Québec un tuteur légal est aussi nommé titulaire de l’autorité parentale) ou avoir un enfant qui se trouve chez lui en vue d’une adoption;

- Avoir un enfant gravement malade ou blessé de moins de 18 ans au moment où s’ouvre la fenêtre de 52 semaines;

- Le client doit soumettre un certificat médical qui prouve que l’enfant est gravement malade ou blessé et qu’il a besoin des soins ou du soutien de ses parents.

**Fenêtre des prestations pour PEGM**

La fenêtre de 52 semaines pendant laquelle des prestations sont payables débute quand l’une des conditions suivantes est remplie :

- Si la demande est présentée avant que le certificat ne soit émis, à compter de la date à laquelle le médecin spécialiste en titre atteste que l’enfant est gravement malade ou blessé; ou

- Le jour de l’émission du premier certificat médical.

Si plusieurs enfants sont gravement malades ou blessés du fait du même événement, une seule période de 52 semaines peut être établie et des prestations peuvent être versées pendant une période maximum de 35 semaines au cours de cette période de 52 semaines.

Si plusieurs enfants sont gravement malades ou blessés du fait d’événements non reliés, des périodes de 52 semaines distinctes peuvent être établies pour chacun des enfants gravement malades ou blessés. Cependant, le nombre maximum de semaines durant lesquelles des prestations pour PEGM sont payables se définit de la façon suivante :

- 35 semaines par enfant durant la période de 52 semaines connexe; et

- un maximum de 35 semaines de prestations peut être payé pour PEGM durant n’importe quelle période de prestations.

**Prestations maximales payables**

Un maximum de 35 semaines de prestations pour PEGM peut être réclamé pendant toute période de prestations (PP). Les clients peuvent se partager les prestations pour PEGM jusqu’à concurrence de 35 semaines. Les 35 semaines de prestations pour PEGM ne sont pas forcément versées consécutivement : elles peuvent être versées de façon intermittente pendant la PP ou à l’intérieur de la fenêtre de 52 semaines, de façon à convenir le mieux au client, pourvu que la preuve médicale requise atteste du mauvais état de santé de l’enfant durant les semaines demandées.

Les prestations pour PEGM ne peuvent plus être versées si :

- la PP a expiré;

- la fenêtre de 52 semaines a expiré;

- le nombre maximal de semaines de prestations combinées dans cette demande a été payé;
         [nombre maximal de semaines de prestations combinées](/fr/procedure/generic/additionalresources/max_ent_ben.shtml)

- les 35 semaines de prestations pour PEGM ont été payées (à plus d’une personne ou à une seule personne); ou

- l’enfant gravement malade meurt.

**Prolongation de la période de prestations**

La période de prestations (PP) peut être prolongée pour un maximum de 104 semaines aux fins du versement de semaines supplémentaires de prestations maternité lorsque toutes les conditions sont remplies avant la fin de la PP. Pour plus d’information consulter Prolongation de la période de prestations . Pour obtenir des renseignements supplémentaires sur la prolongation de la PP, consulter Prolongation de la période de prestations pour des prestations spéciales — Outil de travail .
       [Prolongation de la période de prestations](/fr/procedure/activity/extension_benefit_period.shtml) 
       [Prolongation de la période de prestations pour des prestations spéciales — Outil de travail](/fr/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

**Code PAS-DP**

L’option PAS-DP est également disponible pour les clients qui demandent des prestations pour PEGM. Le système n’annulera pas automatiquement l’exemption de produire des déclarations quand les critères d’admissibilité ne sont plus remplis (p. ex. des prestations pour PEGM deviennent des prestations de maladie ou un client travaille à temps partiel). Un Mémo pour le centre opérationnel (MM06) doit être envoyé au COPA pour demander l’annulation de l’indicatif d’élimination des déclarations du prestataire.

**Délai de carence**

Un délai de carence (DC) doit être observé pour que les clients touchent des prestations pour PEGM. Dans certaines situations, le DC peut être reporté ou annulé.

**Report du délai de carence**

Le délai de carence (DC) normal de 2 semaines s’applique à ces prestations. Si le premier parent a servi le DC de 2 semaines, le DC de l’autre parent peut être reporté si des prestations sont demandées à l’égard du même enfant.

**Suppression du délai de carence**

Les dispositions actuelles relatives à la suppression du délai de carence s’appliquent aux demandes de prestations pour PEGM lorsque les conditions suivantes sont rencontrées :

- après son dernier jour de travail, le client a reçu une rémunération à titre d’un congé de maladie payé de son employeur; et

- l’arrêt de rémunération donnant lieu à la demande est dû à la nécessité de fournir des soins ou du soutien à un enfant gravement malade ou blessé.

**Document médical**

**Prouver que l’enfant est gravement malade ou blessé**

Pour prouver que l’enfant est gravement malade ou blessé et qu’il a besoin de soins ou du soutien de son parent, le client doit obtenir un certificat médical attestant que l’état de santé habituel de l’enfant a changé de façon considérable, et la vie de l’enfant est en danger par suite d’une maladie ou d’une blessure. De plus, le mauvais état de santé de cet enfant fait en sorte qu’il requiert les soins ou le soutien de ses parents. Le certificat médical doit être signé par un médecin.

**Période de soins et de soutien**

Si le médecin inscrit « inconnue » ou « indéterminée », cela ne donne aucune précision sur la durée escomptée des soins ou du soutien dont l’enfant aura besoin. L’agent doit communiquer avec le client pour obtenir un autre certificat médical qui indique clairement la durée des soins ou du soutien dont l’enfant a besoin.

Le médecin doit fournir la période pendant laquelle l’enfant nécessite des soins ou du soutien. Si la période correspond à un nombre précis de semaines plutôt qu’à des dates de début et de fin, la période de soins et de soutien commence à la date d’émission du certificat médical.

Le formulaire Autorisation à divulguer un certificat médical (INS5242A) doit être rempli et signé par le patient pour que le médecin spécialiste puisse divulguer les renseignements médicaux.
       [Autorisation à divulguer un certificat médical (INS5242A)](https://catalogue.servicecanada.gc.ca/content/EForms/fr/CallForm.html?Lang=fr&PDF=SC-INS5242A.pdf)

Un client qui présente une demande de prestations pour PEGM doit soumettre un certificat médical pour prestations d’assurance-emploi pour parents d’enfants gravement malades (INS5242B) .
       [certificat médical pour prestations d’assurance-emploi pour parents d’enfants gravement malades (INS5242B)](http://forms-formulaires.prv/eform99/index.cfm?App=Launch&FormID=6856&GroupID=203&LANG=F)

L’enfant gravement malade ou blessé ne réside pas toujours au Canada et le client est tenu de quitter le pays pour fournir des soins ou du soutien à l’enfant, quel que soit l’endroit où il habite. Dans ces situations, le client doit quand même soumettre un certificat médical pour prestations d’assurance-emploi pour parents d’enfants gravement malades (INS5242B ) rempli par un médecin spécialiste qui est autorisé à exercer la médecine au Canada à titre de spécialiste.
       [certificat médical pour prestations d’assurance-emploi pour parents d’enfants gravement malades (INS5242B](https://catalogue.servicecanada.gc.ca/content/EForms/fr/CallForm.html?Lang=fr&PDF=SC-INS5242B.pdf)

Pour déterminer si un certificat médical est acceptable, consulter Déterminer si un client qui présente une demande de prestations pour PEGM a fourni un certificat médical acceptable — Demande renouvelée ou continue .
       [Déterminer si un client qui présente une demande de prestations pour PEGM a fourni un certificat médical acceptable — Demande renouvelée ou continue](/fr/procedure/task/determining_pcic_med_cert.shtml)

**Certificat médical ultérieur**

La période pendant laquelle l’enfant aura besoin de soins ou de soutien comprend la période initiale au cours de laquelle l’enfant est gravement malade ou blessé ainsi que la période de rétablissement suivant le moment où l’état de santé de l’enfant s’est amélioré, mais que son état n’est pas encore revenu à l’état de santé normal.

Ainsi, le spécialiste peut émettre un deuxième certificat médical afin de permettre au client de toucher des prestations durant la période de rétablissement de l’enfant (jusqu’à 35 semaines de prestations pour PEGM).

Si un client demande des prestations au cours de la période de rétablissement, il doit présenter un formulaire Autorisation de délivrer un certificat médical (INS5242A) et un formulaire Certificat médical — Prestations pour parents d’enfants gravement malades (INS5242B) .
       [Autorisation de délivrer un certificat médical (INS5242A)](https://catalogue.servicecanada.gc.ca/content/EForms/fr/CallForm.html?Lang=fr&PDF=SC-INS5242A.pdf) 
       [Certificat médical — Prestations pour parents d’enfants gravement malades (INS5242B)](https://catalogue.servicecanada.gc.ca/content/EForms/fr/CallForm.html?Lang=fr&PDF=SC-INS5242B.pdf)

**Fournir des soins ou du soutien**

Un enfant peut avoir besoin des soins ou du soutien d’un parent légal, en raison de son état de santé, et de soutien psychologique ou moral.

La définition des soins et du soutien comprend les situations où le client passe simplement du temps chaque jour auprès de l’enfant gravement malade à son domicile, dans un centre de soins palliatifs ou dans une installation de soins de santé. Cela comprend également les situations où le client peut cesser de fournir des soins à l’enfant pendant 2 jours ou moins, lorsqu’il demande des prestations PEGM.

Pour déterminer si un client fournit des soins ou du soutien à un enfant gravement malade, consulter Déterminer si un client qui présente une demande de prestations pour PEGM apporte des soins ou du soutien à un enfant gravement malade — Demande renouvelée et demande continue .
       [Déterminer si un client qui présente une demande de prestations pour PEGM apporte des soins ou du soutien à un enfant gravement malade — Demande renouvelée et demande continue](/fr/procedure/task/determining_pcic_benefit_child.shtml)

**Politique provisoire visant les nouveau-nés**

En vertu de la politique provisoire, des prestations PEGM peuvent être versées si certaines conditions sont remplies. Il n’existe pas d’état de santé habituel préalable pour un nouveau-né. Ainsi, il est possible de ne pas répondre à la question relative à cet état de santé (question 2 sur le formulaire INS 5242B - PEGM certificat médical), ou la réponse peut être non .

Quand un agent applique la politique provisoire visant les nouveau-nés, toutes les conditions suivantes doivent être remplies :

- Le médecin a répondu oui aux questions 1 et 3;

- Le médecin a répondu oui ou non , ou il n’a pas répondu à la question 2;

- Les renseignements sur le certificat médical indiquent clairement que l’enfant est gravement malade depuis la naissance;

- Le certificat médical fait mention de la période prévue pendant laquelle des soins ou du soutien sont requis.

**Inadmissibilités**

Lorsque les conditions d’admissibilité ne sont pas remplies, l’agent impose une inadmissibilité 61 — Prestations pour parents d’enfants gravement malades — Ne rencontre pas les conditions d’admissibilité (D61).

Lorsque les conditions d’admissibilité ne sont pas remplies, l’agent impose une inadmissibilité 63 — Prestations pour parents d’enfants gravement malades — Aucune preuve médicale (D63).

**Questions relatives à l’admissibilité**

**MCE reporté**

Dans une demande initiale de prestations pour PEGM, le recueil de faits et la décision concernant un MCE litigieux peuvent être reportés si certaines conditions sont remplies.

Si une exclusion indéfinie a été imposée à la suite d’une décision rendue dans une demande de renouvellement de prestations pour PEGM, le recueil de faits et la décision sur un MCE litigieux peuvent être reportés. Les prestations spéciales sont versées, peu importe si le client a accumulé assez d’heures pour établir une nouvelle demande.

Consulter Report de décision pour obtenir des renseignements supplémentaires.
       [Report de décision](/fr/procedure/activity/deferral_adj.shtml)

**Politique sur les niveaux de décision**

Pour déterminer si une décision relève du Niveau 1, consulter la Politique nationale sur les niveaux de décisions .
       [Politique nationale sur les niveaux de décisions](/fr/policy/nationalpolicy/levels_decision-annex1.shtml)

Si la décision ne relève pas du Niveau 1, la question peut être renvoyée au Niveau 2 pour qu’une décision soit rendue de la façon suivante :

- Entreprendre le recueil de faits.

- Saisir la conversion.

- Imposer un traitement manuel pour arrêter le paiement (TM01).

**Répartition des fonds**

Quand un client déclare qu’il reçoit des sommes, l’agent doit déterminer si les sommes reçues doivent être considérées comme étant des revenus aux fins de l’AE. Si l’agent détermine que les sommes sont considérées comme étant des revenus, il doit consulter Rémunération pour déterminer la façon de répartir ces fonds.
       [Rémunération](/fr/procedure/activity/earnings.shtml)

**Non autrement disponible**

Pour avoir droit aux prestations pour PEGM, les clients n’ont pas à démontrer qu’ils seraient « autrement disponibles » ou qu’ils seraient « autrement au travail ».

**Partage des prestations**

La Loi prévoit que les 35 semaines de prestations PEGM en relation avec l’enfant gravement malade peuvent être partagées entre plusieurs clients et que lorsque c’est le cas, ces semaines doivent être divisées conformément à l’entente conclue entre les clients. Lorsque les prestations sont partagées, il faut déterminer si le deuxième parent demande des prestations PEGM ou s’il a déjà demandé ce genre de prestations pour prendre soin du même enfant gravement malade, ainsi que le nombre de semaines de prestations demandées par l’autre parent. Lorsque les clients admissibles ne parviennent pas à une entente, le nombre de semaines restantes sera divisé d’après les règles prescrites. Consulter Rendre une décision sur le partage des PEGM — Demande renouvelée ou continue .
       [Rendre une décision sur le partage des PEGM — Demande renouvelée ou continue](/fr/procedure/task/adjudicating_na_pcic_bw.shtml)

**Plus d’un enfant**

Il peut arriver des situations où plusieurs enfants sont gravement malades ou blessés. Il est important de déterminer si des prestations ont été demandées pour le même événement ou pour des événements non liés.

**Même événement**

Si plusieurs enfants sont gravement malades ou blessés du fait du même événement, une seule période de 52 semaines peut être établie et des prestations peuvent être versées pendant une période maximum de 35 semaines au cours de cette période de 52 semaines.

**Événements non liés**

Si plusieurs enfants sont gravement malades ou blessés du fait d’événements non reliés, des périodes de 52 semaines distinctes peuvent être établies pour chacun des enfants gravement malades ou blessés. Cependant, le nombre maximal de semaines de prestations payables se définit de la façon suivante :

- 35 semaines par enfant durant la période de 52 semaines connexe; et

- un maximum de 35 semaines de prestations peut être payé durant n’importe quelle PP.

Les 2 parents pourraient, chacun, faire établir une PP à l’égard d’un enfant (quand 2 événements non liés sont survenus), et être payables un maximum de 35 semaines chacun. Les 2 parents peuvent également partager les semaines visant chacun des 2enfants, sous réserve du nombre maximal de 35 semaines par enfant et par PP.

**Prolonger les prestations pour PEGM**

Quand le client dépose une demande renouvelée de prestations pour PEGM, l’agent doit saisir les données indiquées ci-dessous dans l’ETI .

- Saisir la semaine d’entrée en vigueur.

- Code d’Action : Saisir « S » si le client demande l’option PAS-DP.

- Si une inadmissibilité est requise, saisir l’inadmissibilité appropriée.

**MM06**

Si le client a soumis un certificat médical invalide ou si les conditions d’admissibilité ne sont pas remplies, aucun Mémo pour le Centre opérationnel (MM06) n’est requis. Quand un client est admissible des prestations, l’agent doit compléter un MM06.

**Conversions d’un autre genre de prestations en prestations pour PEGM**

Quand le client demande la conversion d’un genre de demande (GD) en prestations pour PEGM, l’agent doit saisir les données indiquées ci-dessous dans l’ETI .

- Avec ou sans date d’entrée en vigueur, faire passer le GD de 20 à 78.

- Si une inadmissibilité est requise, saisir l’inadmissibilité appropriée à la semaine pendant laquelle des prestations pour PEGM sont demandées.

**Déclarations du prestataire**

La dernière semaine du genre de prestations précédent doit être payée avant la saisie de transactions de conversion.

**MM06**

Si le client a fourni un certificat médical invalide ou si les conditions d’admissibilité ne sont pas remplies, aucun Mémo pour le Centre opérationnel (MM06) n’est requis. Quand un client est admissible à des prestations, l’agent doit remplir un MM06 pour que le COPA annule la demande du SMP et verse le paiement.

**Conversion des prestations pour PEGM en d’autres genres de prestations**

Si le client présente une demande de conversion pour des prestations de maladie, parentales ou régulières, l’aide-mémoire appropriée, de la ressource additionnelle Aide-mémoires, Formulaires et Gabarits , doit être complétée avec le client.
       [Aide-mémoires, Formulaires et Gabarits](/fr/procedure/generic/ar_index_cft_afg.shtml)

Si le client présente une demande de conversion pour des prestations de maternité, l’agent doit vérifier si le client a rempli une demande de prestations de maternité précédemment pour ce DPP. Si oui, la conversion peut être effectuée au moyen de l’aide-mémoire, de la ressource additionnelle Aide-mémoires, Formulaires et Gabarits . Si non, le client doit être dirigé pour remplir une demande en ligne.
       [Aide-mémoires, Formulaires et Gabarits](/fr/procedure/generic/ar_index_cft_afg.shtml)

Les conversions sont complétées selon la charge de travail liée au traitement et ne doivent pas être assignées ou réassignées au Centre de spécialisation.

Les clients doivent être avisés que si une conversion vers un autre genre de prestations est effectuée, la demande demeure dans SMP pendant toute la durée de la demande, et des déclarations du prestataire (papier) doivent être remplies, à moins d’indication contraire dans les procédures du genre de prestations demandé.

Après l’examen de la demande de conversion et des conditions d’admissibilité, l’agent doit remplir un MM06 afin de soumettre la demande de conversion.

Au moment de remplir un MM06, l’utilisateur doit s’assurer que tous les renseignements nécessaires pour effectuer la conversion sont indiqués. Cela inclut le genre de prestations demandé, la période pendant laquelle les prestations doivent être versées, le nombre de semaines demandé (si applicable), la semaine de guérison pour des prestations de maladie, la dernière semaine renouvelable, toute allocation requise, les prolongations de la PP, les inadmissibilités, etc.

**Procédures connexes**

- Déterminer si un client qui présente une demande de prestations PEGM a soumis un certificat médical acceptable — Demande renouvelée et demande continue
         [Déterminer si un client qui présente une demande de prestations PEGM a soumis un certificat médical acceptable — Demande renouvelée et demande continue](/fr/procedure/task/determining_pcic_med_cert.shtml)

- Déterminer si un client qui présente une demande de prestations PEGM apporte des soins ou du soutien à un enfant gravement malade — Demande renouvelée et demande continue
         [Déterminer si un client qui présente une demande de prestations PEGM apporte des soins ou du soutien à un enfant gravement malade — Demande renouvelée et demande continue](/fr/procedure/task/determining_pcic_benefit_child.shtml)

- Rendre une décision sur le partage des PEGM — Demande renouvelée ou continue
         [Rendre une décision sur le partage des PEGM — Demande renouvelée ou continue](/fr/procedure/task/adjudicating_na_pcic_bw.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0542.dita`

Remarque :

Les prestations PEGM sont remplacées par les prestations pour proches aidants d’enfants le 3 décembre 2017.  Seuls les nouvelles demandes, les renouvellements de demandes ou les demandes continues dont la date de début de la période de prestations pour proches aidants est identique ou postérieure à la date d’entrée en vigueur sont admissibles aux nouvelles prestations et aux droits élargis pour ces prestations. La présente page doit être consultée pour toute demande de prestations d’enfants gravement malade établie avant le 2 décembre 2017. Pour plus d’information concernant les prestations pour proches aidants d’enfants, consulter Prestations pour proches aidants — Connaissances .
       [Prestations pour proches aidants — Connaissances](/fr/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml)

     [Prestations pour proches aidants — Connaissances](/fr/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml) 
