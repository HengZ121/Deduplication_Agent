# Travail partagé : Renseignements sur le traitement des demandes de Travail partagé — Connaissances

Source map: `fr_FR/procedure/generic/additionalresources/knowledge_reltws/knowledge_reltws.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/knowledge_reltws/ressources_additionnelles.dita`

Sommaire : Cette page fournit des renseignements sur la façon de traiter les demandes de Travail partagé (TP) et de naviguer de manière optimale dans l’ORL AE lors du traitement d’un problème concernant une demande de TP.

Table des matières

- Renseignements sur le traitement des demandes de Travail partagé (TP) dans l’ORL AE
         [Renseignements sur le traitement des demandes de Travail partagé (TP) dans l’ORL AE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Informations_sur_le_traitement)

- Programme de Travail partagé (TP)
         [Programme de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Programme_de_travail)

- Communiquer avec le client
         [Communiquer avec le client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#clientcommunication)

- Différences entre les demandes de prestations régulières et de Travail partagé (TP)

- Arrêt de rémunération (A de R)

- RE
                 [RE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Releve_demploi)

             [Arrêt de rémunération (A de R)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Arret_de_emuneration)

- Code de référence
             [Code de référence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Code_de_reference)

- Délai de carence (DC)
             [Délai de carence (DC)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Delai_de_carence)

- Semaine de Travail partagé (TP)
             [Semaine de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Semaine_de_travail)

- Rémunération provenant d’un emploi qui fait partie d’un accord de Travail partagé (TP)
             [Rémunération provenant d’un emploi qui fait partie d’un accord de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Revenus_gagne)

- Heures hebdomadaires normales (HHN)

- Semaine de travail irrégulière
                 [Semaine de travail irrégulière](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#semainetravail)

- Horaire non conventionnel qui comprend des jours de relâche
                 [Horaire non conventionnel qui comprend des jours de relâche](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#horaire)

             [Heures hebdomadaires normales (HHN)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#HHN)

- Disponibilité
             [Disponibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Disponibilite)

- Hors Canada

- Semaine d’inadmissibilité partielle appliquée à une demande de Travail partagé (TP)
                 [Semaine d’inadmissibilité partielle appliquée à une demande de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Semaine_dinadmissibilite_1)

- Déterminer le bon nombre d’heures manquées en raison du Travail partagé (TP) en vue de l’inadmissibilité de semaines partielles hors Canada
                 [Déterminer le bon nombre d’heures manquées en raison du Travail partagé (TP) en vue de l’inadmissibilité de semaines partielles hors Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Determiner_le_bon_nombre)

             [Hors Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#_Hors_Canada)

- Maladie
             [Maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Maladie)

- Maladie occasionnelle
             [Maladie occasionnelle](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#maladie_occasionnelle)

- Durée et prolongation de la période de prestations (PP)
             [Durée et prolongation de la période de prestations (PP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Duree_et_prolongation)

- Règlement des motifs de cessation d’emploi (MCE)
             [Règlement des motifs de cessation d’emploi (MCE)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Reglement_des_motifs)

- Exclusion et inadmissibilité
             [Exclusion et inadmissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Exclusion_et_inadmissibilite)

- Traitement des paiements

- Rapport d’utilisation (RU)
                 [Rapport d’utilisation (RU)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Rapport_dutilisation)

- Déclaration du prestataire
                 [Déclaration du prestataire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Declaration)

- Exemption concernant la déclaration du prestataire
                 [Exemption concernant la déclaration du prestataire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Exemption_concernant)

- STPA
                 [STPA](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#stpa)

- Heures hebdomadaires normales (HHN)
                 [Heures hebdomadaires normales (HHN)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#hhn2)

- Prestations versées
                 [Prestations versées](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Paiement_des_prestations)

             [Traitement des paiements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Traitement_des_paiements)

- Examen administratif
             [Examen administratif](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Revision_administrative)

         [Différences entre les demandes de prestations régulières et de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Differences_entre_les_demandes)

- Traitement des demandes

- Demande de prestations d’AE

- Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit
                 [Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Avis)

             [Demande de prestations d’AE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Demande_de_prestations)

- Automatisation
             [Automatisation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Automatisation)

- Fin de l’accord de Travail partagé (TP)
             [Fin de l’accord de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Fin_de_accord)

- Accord de Travail partagé (TP) subséquent
             [Accord de Travail partagé (TP) subséquent](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#_accord_de_travail_part_sub)

- Fermeture planifiée pendant un accord de Travail partagé (TP)
             [Fermeture planifiée pendant un accord de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Arret_sporadique)

         [Traitement des demandes](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Traitement_des_demandes)

- Travail partagé (TP) au-delà des 104 semaines
         [Travail partagé (TP) au-delà des 104 semaines](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#_travail_part_au_dela_104_semaine)

- Examiner une demande établie après une demande qui a atteint la semaine 104
         [Examiner une demande établie après une demande qui a atteint la semaine 104](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#_examiner_demande_atteint_la_semaine_104)

- Renouvellement d’une demande de Travail partagé (TP)
         [Renouvellement d’une demande de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#ren_tp)

- Responsabilités du coordonnateur régional de Travail partagé (TP)

- Code de référence
             [Code de référence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#ReferenceCode)

- Saisies des dans la transaction Données de projet (M171)
             [Saisies des dans la transaction Données de projet (M171)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#ProjectDataInputs)

- Prolongation de l’accord de Travail partagé (TP)
             [Prolongation de l’accord de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Extensions)

- Examen du rapport US 39241
             [Examen du rapport US 39241](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#SU39241Report)

- Coordonnateurs régionaux de Travail partagé (TP)
             [Coordonnateurs régionaux de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#CoordonnateursRegionauxdeTP)

         [Responsabilités du coordonnateur régional de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#RegionalCoordinatorResponsibilities)

- Rôles et responsabilités
         [Rôles et responsabilités](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#RR)

**Renseignements sur le traitement des demandes de Travail partagé (TP) dans l’ORL AE**

Le traitement ou le règlement d’une demande de TP ne diffère pas considérablement du traitement ou du règlement d’une demande de prestations régulières. Les demandes de TP doivent être considérées comme des demandes de prestations régulières, sauf indication contraire dans ce document. Si aucune particularité ne s’applique au traitement ou au règlement d’une demande de TP, consulter la tâche de prestations régulières correspondante.

     [Exemple : Hors Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0478.dita) 
     [Exemple : Règlement du motif de cessation d’emploi (MCE)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0479.dita) 

**Programme de Travail partagé (TP)**

Le programme de TP fournit de l’aide financière aux employés qui sont admissibles aux prestations régulières et qui ont une semaine de travail réduite. L’employeur peut ainsi garder tous les employés essentiels au lieu d’en mettre à pied un ou plusieurs. Les renseignements sur le programme de TP sont disponibles sur la page du programme de TP à l’adresse suivante Canada.ca . Les employeurs qui ont des questions concernant le programme doivent être redirigés vers ce site. De plus amples renseignements peuvent également être obtenus en composant le numéro de téléphone affiché sur le site : 1-800-367-5693.
       [Canada.ca](https://www.canada.ca/fr/emploi-developpement-social/services/travail-partage.html)

**Communiquer avec le client**

Les demandes de TP sont établies dans la province où se situe l’employeur. Un client qui réside dans une province autre que celle de son employeur doit utiliser le code postal de cet employeur quand il se connecte à Mon dossier Service Canada (MDSC).

**Différences entre les demandes de prestations régulières et de Travail partagé (TP)**

Une demande de TP est établie de la même façon qu’une demande de prestations régulières, mais diffère cependant de plusieurs façons.

**Arrêt de rémunération (A de R)**

Un A de R pour TP se produit au début de la semaine dans laquelle il y a une réduction d’au moins 10 % de la rémunération hebdomadaire normale (RHN) du client. Ceci se produit habituellement dans la première semaine de l’accord de TP.

Un A de R de TP n’est pas considéré comme un A de R spécial.

**RE**

L’agent de programme détermine la date de début de l’accord de TP. Tous les accords de TP commencent le dimanche, et l’agent de programme ordonne à l’employeur d’émettre des RE avec un dernier jour de travail (DJT) dans la semaine précédant la date de début de l’accord de TP. L’employeur remplit un RE pour tous les employés de l’unité de TP.

Le RE est rempli de la manière suivante :

- Case 11 – Dernier jour payé (DJP) : correspond au DJT avant la date de début de l’accord de TP

- Case 14 – Date prévue de rappel : laisser vide

- Case 16 – Motif de l’émission de ce RE : inscrire le code H (Travail partagé)

- Case 17 – Paiements dans la période de paye finale ou à payer à une date ultérieure : laisser vide

**Code de référence**

Le code de référence est un code à 16 chiffres utilisé pour identifier les demandes de TP. Le code de référence est valide 8 semaines à compter de la date de début de l’accord de TP pour les nouveaux accords ou de la date à laquelle les clients sont ajoutés à un accord déjà en vigueur. Quand un client présente une demande d’AE avec un code de référence valide, il reçoit une demande de prestations spécialisée au lieu d’une demande normalisée.

Les renseignements de l’accord de TP doivent être saisis quand un client demande des prestations de TP. Les renseignements sont obtenus à partir du code de référence. Les renseignements de l’accord de TP peuvent être saisis de façon automatique dans ETI à partir des renseignements indiqués dans la demande d’AE du client, ou peuvent être saisis manuellement par un agent.

```text
| Chiffres du code de référence | Renseignements contenus dans le code de référence |

| 1 à 10 | Numéro de projet | Chiffres du numéro de projet |

| 1 à 4 | Centre de traitement de Service Canada |

| 5 et 6 | Code de demande spécialisée pour le TP (03) |

| 7 à 10 | Identifiant unique |

| 11 à 14 | Date de début de l’accord |

| 15 et 16 | Durée de l’accord (semaines) |
```

Après la réception du premier RU, le Numéro du projet est mis à jour automatiquement avec le numéro de l’accord. Si l’agent obtient le numéro de l’accord, il peut être utilisé plutôt que les 10 premiers chiffres du code de référence.

**Délai de carence (DC)**

Le DC est reporté pour que des prestations de TP puissent être versées. Toutefois, le client doit l’observer pour recevoir d’autres genres de prestations. Cette situation peut se produire pendant l’accord de TP (p. ex. le client est malade pendant une semaine de TP). La rémunération reçue pendant le DC est déduite dollar pour dollar, à partir des 3 premières semaines payables des prestations non liées au TP. La rémunération pendant le DC n’est pas retenue des semaines de TP.

Quand le client indique un DJT dans la première semaine de TP avec de la rémunération déclarée supérieure à 125 % du taux de prestations, TAD postdate la semaine de renouvellement à la semaine suivante. Comme la rémunération provenant d’un emploi qui fait partie d’un accord de TP n’est pas déduite dans une semaine de TP, la demande ne doit pas être postdatée. Seule la rémunération reçue en dehors de l’emploi faisant partie d’un accord de TP est considérée comme de la rémunération et est déduite d’une semaine de TP. L’agent corrige la postdate dans ces cas.

**Semaine de Travail partagé (TP)**

Une semaine est traitée comme une semaine de TP quand le client travaille au moins une demi-heure dans le cadre de l’accord de TP pendant la semaine.

Les clients ont droit à des prestations de TP au cours d’une semaine de TP quand il manque au moins une demi-heure de travail en raison du même accord de TP.

Quand la déclaration du prestataire est traitée, le système considère une semaine dans laquelle on ne travaille aucune heure comme une semaine sans TP et détermine si le client est admissible aux prestations régulières ou spéciales. Le DC peut être observé, la rémunération du DC peut être recouvrée et d’autres prestations d’AE peuvent être payables selon les principes normaux d’admissibilité.

**Rémunération provenant d’un emploi qui fait partie d’un accord de Travail partagé (TP)**

La rémunération provenant d’un emploi qui fait partie d’un accord de TP n’est pas déduite dans une semaine de TP. Cela évite que cette rémunération réduise le montant des prestations. Il s’agit des salaires, des congés de maladie payés (CMP), des congés payés, des indemnités d’assurance-salaire et des indemnités pour accidents du travail. Seule la rémunération reçue en dehors de l’emploi faisant partie d’un accord de TP est déduite d’une semaine de TP.

Si l’employeur verse au client un montant forfaitaire ou excédentaire qui dépasse la RHN du client, l’agent détermine si le montant est considéré comme une rémunération. Si c’est le cas, l’agent détermine à quelles semaines la répartition du montant s’applique. Puisque le montant ne peut pas être réparti pendant une semaine traitée comme une semaine de TP, consulter Répartir la rémunération provenant d’un employeur participant au Travail partagé pour connaitre les étapes à suivre.
       [Répartir la rémunération provenant d’un employeur participant au Travail partagé](/fr/procedure/task/allocate_earnings_ws_employer.shtml)

La plupart des lois provinciales sur le travail et des conventions collectives comprennent des conditions qui stipulent qu’un employé doit être payé un nombre minimal d’heures quand il est appelé à travailler. La loi ne permet pas à Service Canada de convertir les heures payées en heures de travail. Les règlements sur le TP ne mentionnent pas les déductions des montants payés par l’employeur participant au TP dans une semaine de TP. Les prestations de TP sont payées selon le nombre d’heures travaillées physiquement et le nombre d’heures manquées en raison du TP, sans compter la rémunération versée.

**Heures hebdomadaires normales (HHN)**

Un agent de programme détermine les HHN des clients participant au TP au début de l’accord de TP. Les HHN sont utilisées pour déterminer le pourcentage de travail manqué par les employés et le montant qui peut leur être versé.

Normalement, les HHN ne changent pas pendant la durée de l’accord de TP. Toutefois, elles sont corrigées si l’agent de programme détermine qu’une erreur a été commise lors de leur établissement. L’agent de programme peut également approuver une modification des HHN au cours d’un accord de TP quand il y a une modification approuvée dans les heures hebdomadaires prévues d’un client. Pour plus de renseignements, l’agent consulte Modifier les heures hebdomadaires normales dans une demande de Travail partagé .
       [Modifier les heures hebdomadaires normales dans une demande de Travail partagé](/fr/procedure/task/modifying_nwh_ws_claim.shtml)

**Semaine de travail irrégulière**

Quand un client travaille selon un horaire différent chaque semaine, l’agent de programme utilise la moyenne des heures travaillées dans les deux dernières années pour déterminer les HHN à inscrire dans le dossier de la demande. Même si la moyenne des HHN est utilisée pour déterminer le paiement dû au client, l’employeur déclare les HHN réelles que le client aurait travaillées si l’accord de TP n’existait pas. Même si les paiements hebdomadaires peuvent paraître incorrects, ils sont moyennés pour la période de l’horaire irrégulier.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0480.dita) 

**Horaire non conventionnel qui comprend des jours de relâche**

Dans de rares cas, les employeurs n’ont pas de jours de relâche réguliers. Il peut aussi avoir une ou des semaines durant lesquelles il n’y a pas de travail. Ces cas sont très complexes et l’agent de programme travaille avec le SOPA à l’administration centrale pour déterminer la façon la plus appropriée dont l’employeur peut remplir le RU et s’assurer que ses employés sont rémunérés correctement pour les heures manquées en raison de l’accord de TP. L’employeur utilise donc généralement une moyenne ou une formule prorata dans le RU et les transmet moins d’une fois par semaine.

**Disponibilité**

Les clients participants au TP sont considérés comme disponibles quand ils sont disponibles pour travailler avec leur employeur participant au TP. Ils ne sont pas tenus d’être disponibles pour travailler auprès d’autres employeurs pendant l’accord de TP. Cependant, les clients doivent être disponibles pour du travail supplémentaire avec l’employeur participant au TP jusqu’à l’atteinte de leurs heures de travail régulières. Si un client était en mesure de travailler, mais n’était pas disponible ou a refusé de travailler, ces heures ne sont pas comptabilisées comme des heures manquées en raison de TP. Par conséquent, les prestations de TP ne sont pas versées pour ces heures. Pour plus de renseignements sur le TP et la disponibilité, l’agent consulte GDA 25.5.2 .
       [GDA 25.5.2](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-25/semaine-travail-partage.html)

Les principes de disponibilité s’appliquent pendant les semaines traitées comme des semaines de non-TP (p. ex. semaines de fermeture ou semaines entières des non-disponibilité).

Les clients participant au TP sont tenus de déclarer leurs absences de leur lieu de résidence quand ces absences ne relèvent pas d’une exigence de l’emploi qui fait partie d’un accord de TP.

**Hors Canada**

Les principes qui s’appliquent aux clients qui touchent des prestations régulières et séjournent à l’extérieur du Canada s’appliquent aussi aux clients participants au TP. Un client qui est tenu d’exercer des tâches pour son employeur à l’extérieur du Canada devient automatiquement inadmissible aux prestations, y compris celles liées au TP. Les exceptions particulières et les délais connexes en vertu de l’article 55 du Règlement s’appliquent également aux demandes de TP.

L’application d’une inadmissibilité partielle diffère en raison de la façon dont le système calcule les prestations pendant les semaines de TP. Une inadmissibilité 13 - Hors Canada (D13) est imposée pour ces semaines, dès que le client informe Service Canada d’une absence du Canada avant le départ. L’agent supprime l’inadmissibilité D13 une fois que les mesures correctives ont été prises concernant l’inadmissibilité partielle. Quand une semaine d’inadmissibilité partielle est imposée pour une question de hors Canada, passer à Semaine d’inadmissibilité partielle appliquée à une demande de Travail partagé .
       [Semaine d’inadmissibilité partielle appliquée à une demande de Travail partagé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#Semaine_dinadmissibilite_1)

**Semaine d’inadmissibilité partielle appliquée à une demande de Travail partagé (TP)**

Les clients participant au TP sont assujettis aux mêmes dispositions liées aux séjours hors Canada (consulter Hors Canada ) que les autres clients. Comme le système ignore l’inadmissibilité partielle lors de la détermination des prestations payables dans une semaine de TP, les heures qui sont déclarées comme étant manquées en raison du TP doivent être examinées et ajustées, au besoin, pour appliquer l’effet équivalent dans une semaine de TP.
       [Hors Canada](/fr/procedure/activity/out_canada.shtml)

Quand une inadmissibilité partielle liée à un séjour hors Canada s'applique à un client participant au TP, l’agent de Niveau 1 est chargé de calculer les semaines partielles et d’apporter le rajustement nécessaire aux déclarations du prestataire, même si le règlement de cette question a été renvoyé à un agent de Niveau 2.

**Déterminer le bon nombre d’heures manquées en raison du Travail partagé (TP) en vue de l’inadmissibilité de semaines partielles hors Canada**

L’agent examine et rajuste, au besoin, les heures manquées en raison du TP pour qu’elles correspondent à l’admissibilité aux prestations.

Pour déterminer le nombre exact d’heures manquées, une ventilation quotidienne des heures déclarées comme manquées en raison du TP est nécessaire. Si cette information n’est pas déjà consignée, l’agent communique avec l’employeur pour obtenir la répartition quotidienne des heures manquées en raison du TP.

Si un client n’est pas admissible à des prestations dans une journée donnée, les heures déclarées comme manquées en raison du TP pour ce jour doivent être supprimées du total hebdomadaire. Si aucune heure n’a été déclarée comme manquée en raison du TP pour la journée (car ce n’était pas un jour de TP ou que l’absence était déjà prise en compte au moment de la déclaration), aucun rajustement n’est nécessaire.

Des rajustements peuvent également être nécessaires pour les périodes pendant lesquelles le client est autorisé à se trouver à l’extérieur du Canada. Pour les périodes admissibles au cours desquelles le client aurait manqué des heures en raison du TP, mais que ces heures n’ont pas été signalées (car l’employeur ne connaissait pas le motif de l’absence du client du Canada), les heures doivent être ajoutées au total hebdomadaire.

Le recueil de faits et le rajustement de l’agent aux heures manquées en raison du TP sur la déclaration du prestataire doivent être documentés dans un RSDP.

L’agent rajuste les heures manquées en raison du TP, au besoin, en examinant le montant indiqué comme Déclaré ou codé pour le Travail partagé dans la fenêtre Détails de paiement dans ETI et en soumettant une déclaration du prestataire modifiée avec le montant rajusté (consulter Modifier une déclaration du prestataire ).
       [Modifier une déclaration du prestataire](/fr/procedure/task/modifying_cr.html)

**Maladie**

Une semaine au cours de laquelle un client ne travaille pas en raison d’une maladie et n’est pas payé est considérée comme une semaine de prestations de maladie. Le client doit être admissible aux prestations de maladie et respecter un DC si ce n’est déjà fait ou s’il n’en est pas dispensé, pour recevoir des prestations.

Quand les clients déclarent moins de 5 jours de maladie dans une semaine où ils ont travaillé une demi-heure ou plus, la semaine est considérée comme une semaine de TP, et les jours de maladie sont ignorés. Le client reçoit le paiement uniquement pour les heures manquées en raison du TP.

Quand un client est exempté de remplir des déclarations du prestataire et que l’employeur déclare moins de 5 jours de maladie dans une semaine pendant laquelle le client n’a pas travaillé pour l’employeur participant au TP, on présume que le client est malade pour la semaine entière.

**Maladie occasionnelle**

Il y a 2 différents compteurs pour les semaines de maladie occasionnelle pour une demande individuelle :

- Maladie occasionnelle consécutive déclarée : Si ce compteur est à 4 semaines consécutives de maladie occasionnelle, que ces semaines aient été payées ou non, et qu’une cinquième semaine de maladie occasionnelle est saisie, la déclaration du prestataire est rejetée avec un indicatif d’erreur C465.

- Total de semaines de maladie occasionnelle versées : Quand 8 semaines de prestation de maladie occasionnelle ont été versées dans une demande, qu’elles soient consécutives ou non, et qu’une neuvième semaine de maladie occasionnelle est saisie, la déclaration du prestataire est rejetée avec un indicatif d’erreur C484.

**Durée et prolongation de la période de prestations (PP)**

Les prestations de TP ne réduisent pas la durée ou le droit aux prestations régulières d’AE. Chaque semaine traitée comme une semaine de TP se traduit par une semaine de prolongation de la PP. La PP est automatiquement prolongée par le système jusqu’à 104 semaines.

Quand le système traite une semaine comme une semaine régulière pendant un accord de TP, la PP n’est pas automatiquement prolongée. Cependant, la semaine est considérée comme une semaine de TP en vue de la prolongation de la PP en raison de la politique et peut aussi prolonger la PP. Ces semaines sont examinées et peuvent être prolongées de façon manuelle au moyen de Prolongation de la période de prestations — Demandes de Travail partagé de plus de 104 semaines quand la demande atteint 104 semaines et qu’une demande ultérieure est établie.
       [Prolongation de la période de prestations — Demandes de Travail partagé de plus de 104 semaines](/fr/procedure/task/extending_bp_ws_cb104w.shtml)

**Règlement des motifs de cessation d’emploi (MCE)**

Le départ volontaire et le congédiement ne sont pas abordés de façon particulière dans la partie de la LAE et du RAE portant sur le TP. Par conséquent, ils sont réglés de la même manière que pour une demande de prestations régulières.

La participation à un accord de TP est volontaire, mais tous les employés d’une unité de TP doivent accepter de réduire leurs heures de travail habituelles et de partager le travail disponible. Toutefois, si un client refuse de participer à un accord de TP et est renvoyé en conséquence, cela n’est pas considéré comme une inconduite. De même, quand un client démissionne au lieu de participer à un accord de TP et c’est la seule ou la principale raison pour le départ, le client n’est pas réputé avoir un motif valable. Le client doit montrer qu’il a exploré toutes les options raisonnables avant de démissionner.

**Exclusion et inadmissibilité**

Les exclusions imposées à la suite d’un départ volontaire ou d’une inconduite ne sont pas suspendues en vue de verser des prestations de TP.

Les autres exclusions ou inadmissibilités exceptionnelles sont automatiquement reportées, à l’exception de : D5, D12, D13, D14, D15, D21, D38, D39, D42, D43 et D48.

Les exclusions et inadmissibilités exceptionnelles reportées pour autoriser le versement des prestations de TP sont réintégrées après la fin de l’accord de TP.

Une semaine durant laquelle le client est inadmissible pour une semaine complète est considérée comme une semaine sans TP (prestations régulières ou spéciales).

Une semaine durant laquelle le client est inadmissible pour une semaine partielle, mais durant laquelle le client a travaillé au moins une demi-heure pour l’employeur participant au TP, est considérée comme une semaine de TP. Le système ignore les inadmissibilités partielles pour les semaines de TP parce que le client est payé selon les heures manquées en raison du TP. Passer à Hors Canada pour les procédures à suivre si l’on impose une inadmissibilité partielle parce que le client est à l’étranger pour une partie de la semaine.
       [Hors Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/knowledge_reltws#_Hors_Canada)

**Traitement des paiements**

**Rapport d’utilisation (RU)**

Chaque semaine, les employeurs remplissent un RU utilisé pour déterminer les prestations payables à leurs employés participant au TP.

Le RU contient le numéro de l’accord, le nom de l’employeur, la date de début de la semaine et les renseignements suivants pour chaque employé :

- NAS

- Nom

- HHN

- Heures travaillées

- Jours N/D ou jours manqués en raison d’une maladie

- Montants du CMP

- Heures manquées en raison du TP

- Autres montants payés

- Commentaires

Le COPA téléverse les renseignements RU et les joint à la déclaration du prestataire pour la même semaine.

**Déclaration du prestataire**

Les déclarations du prestataire sont générées par le système quand le client est en PAS-IND-DP ou quand le client remplit une déclaration du prestataire papier qu’il envoie ensuite par la poste. Les clients participant au TP ne peuvent pas soumettre leurs déclarations par voie électronique.

Les déclarations du prestataire générées pour les clients sur PAS-IND-DP ne contiennent aucun code de paiement et sont traitées en fonction de l’information sur le RU. Quand une modification à la déclaration du prestataire d’un client participant au TP est nécessaire, l’indicatif de paiement TP doit être mentionné.

Quand un client doit de remplir une déclaration du prestataire papier, il doit la remplir d’une façon précise.

```text
| Case | Description |

| 1a | Répondre Non , sauf si le client était hors du Canada entre le lundi et le vendredi. Si c’est le cas, le client doit répondre Oui et indiquer si l’absence était pour moins de 24 heures, excluant les jours de fins de semaine, ainsi que fournir le motif et les dates de départ et d’arrivée de l’absence aux cases 1b et 1c . |

| 2a | Répondre Non , sauf si le client a travaillé pour un employeur autre que l’employeur participant au TP. Si c’est le cas, le client doit répondre Oui et fournir les dates et le total des heures travaillées ainsi que la rémunération brute reçue de l’employeur qui ne participe pas au TP aux cases 2b et 2d |

| 2c | - Si Non , indiquer le nom de l’employeur participant au TP. - Si Oui , indiquer le nom et l’adresse de l’employeur (doivent être différents de l’employeur participant au TP). |

| 2e | Si le client a cessé de travailler pour tout employeur au cours de cette semaine, le motif doit être fourni, peu importe si le client a travaillé pour cet employeur au cours de cette semaine. |

| 3a | Répondre Non , sauf si le client a commencé à travailler à temps plein pour un employeur autre que l’employeur participant au TP. Si c’est le cas, le client doit répondre Oui la date à laquelle il a commencé à travailler à temps plein. |

| 4a | Répondre Non , sauf si le client participe à un cours de formation en personne. Si c’est le cas, le client doit répondre Oui et indiquer le total des heures passées à participer à la formation et le montant et la provenance des allocations de formation, au besoin, dans les cases 4b et 4c . |

| 5a | Répondre Oui , sauf si le client est en vacances, malade ou non disponible pour n’importe quel jour de la déclaration du prestataire. Si c’est le cas, le client doit répondre Non et fournir les dates et la raison de la non-disponibilité aux cases 5b et 5c . Le client indique aussi tout montant provenant d’un régime d’assurance maternité ou maladies, au besoin, à la case 5d . |

| 6a | Répondre Non , sauf si le client a reçu des sommes autres que celles déclarées dans les cases 2d , 4b et 5d qui sont différentes des sommes reçues de l’employeur participant au TP. Si c’est le cas, le client doit répondre Oui et indiquer de qui il a reçu les sommes, pour quelle raison et le montant de ces sommes dans les cases 6b , 6c et 6d . |
```

**Exemption de remplir des déclarations du prestataire**

Quand le client remplit une demande de prestations avec un code de référence de TP, celle-ci est présentée au moyen d’une demande spéciale et est exemptée de déclaration. Dans certains cas, comme le travail indépendant (y compris le travail agricole) ou le travail accompli pour un autre employeur (autre que l’employeur participant au TP), les clients ne peuvent pas être exemptés de remplir des déclarations du prestataire. Les clients qui ne présentent pas une demande avec un code de référence ou qui souhaitent être exemptés après avoir choisi de remplir les déclarations du prestataire peuvent être exemptés plus tard. Consulter Exemption de remplir des déclarations du prestataire pour saisir et annuler les exemptions de remplir des déclarations du prestataire.
       [Exemption de remplir des déclarations du prestataire](/fr/procedure/activity/exemption_reporting.shtml)

**STPA**

STPA permet de combiner automatiquement le RU à une déclaration du prestataire quand il y a un traitement manuel 76 - Travail partagé automatisé (TM76) dans la demande. Un traitement manuel TM76 empêche le traitement des déclarations du prestataire avant de recevoir le RU correspondant et permet à STPA d’automatiser une grande partie du processus de paiement. Il est dans toutes les demandes de TP, sauf celles qui nécessitent une intervention manuelle du COPA.

Quand il y a un traitement manuel TM76 dans une demande de TP, la déclaration du prestataire (y compris les déclarations du prestataire généré par un PAS-IND-DP) est en attente de traitement et la déclaration du client est transférée à STPA. Dans STPA, cette déclaration provenant de la déclaration du prestataire se nomme le dossier du client. STPA essaie de trouver le RU (c.-à-d. le dossier de l’employeur) de la période équivalente qui correspond à la déclaration du prestataire du dossier du client. Une fois qu’une correspondance est trouvée, STPA combine les 2 déclarations, créé une transaction automatisée Traitement manuel - Déclarations du prestataire (T045) et la transfère au système aux fins de traitement.

Le traitement manuel 14 - Travail partagé (TM14) permet au COPA de traiter des demandes de TP complexes sans STPA. Actuellement, le traitement manuel n’est utilisé que si un client participe à plus d’un accord de TP et que le COPA doit contrôler le processus de paiement. Le traitement manuel est nécessaire parce que le client peut seulement être payé pour les heures manquées dans un accord de TP à la fois et le système émet un paiement selon le premier RU reçu. Ce paiement peut ne pas correspondre à l’accord de TP que le client a choisi pour lequel il veut être payé.

**Heures hebdomadaires normales (HHN)**

Les HHN d’un client participant au TP sont déterminées par l’agent de programme au début d’un accord de TP. Les HHN servent à déterminer le pourcentage de travail qu’un employé a manqué et le montant qui serait payable.

Les HHN ne varient pas pendant un accord de TP. Toutefois, les HHN sont corrigées si l’agent de programme détermine qu’une erreur a été commise quand les HHN ont été établies. Consulter Modifier les heures hebdomadaires normales dans une demande de Travail partagé pour plus de renseignements.
       [Modifier les heures hebdomadaires normales dans une demande de Travail partagé](/fr/procedure/task/modifying_nwh_ws_claim.shtml)

**Paiement des prestations**

Les prestations de TP qu’un client reçoit dans une semaine sont déterminées par le taux de prestations du client, les HHN du client et le nombre d’heures déclarées comme manquées en raison du TP dans une semaine. Le client reçoit une proportion du taux de prestations qui est égale aux heures manquées en raison du TP par rapport à ses HHN :

Prestations versées = taux de prestations x heures manquées en raison du TP ÷ HHN

Les sommes versées par l’employeur participant au TP ne sont pas considérées comme des gains et ne sont pas codées si elles sont mentionnées dans le RU. Toutes les autres sommes sont déduites comme d’habitude.

Au besoin, tout recouvrement d’un accord d’ordonnance familiale (AOF) et d’une cession de prestations (CDP) est déduit des prestations de TP payables.

**Examen administratif**

La décision de Service Canada relative à l’approbation ou au refus d’établir un accord de TP n’est pas soumise à un examen administratif. Cela comprend également la modification d’un accord de TP. Toute autre décision concernant l’admissibilité d’un client est soumise à un examen administratif.

**Traitement des demandes**

**Demande de prestations d’assurance-emploi**

Quand les clients participant au TP font une demande en ligne et saisissent un code de référence valide, un formulaire de demande particulier leur est présenté.

Quand les clients participant au TP font une demande en ligne et qu’ils ne saisissent pas de code de référence valide, un formulaire de demande régulier leur est présenté.

**Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit**

Le gabarit Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit est donné à l’employé une fois que l’accord de TP est approuvé. Il contient le code de référence qui doit être déclaré dans la demande, ainsi que la période durant laquelle le client doit présenter sa demande.
       [Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_fr.docx)

**Automatisation**

Le système peut automatiser entièrement les demandes de TP initiales et de renouvellement si les conditions suivantes sont remplies :

- Une demande spécialisée est déposée au moyen d’AW en utilisant un code de référence valide.

- Pour les demandes initiales, le dernier RE avec le MCE de TP et tous les RE pour les employeurs précédents au cours des 52 dernières semaines sont consignés au dossier.

- La demande ne présente pas d’autres conditions empêchant l’automatisation de la demande.

TAD utilise le code de référence pour déterminer certaines saisies :

- chiffres 1 à 10 = le numéro de projet;

- chiffes 11 à 14 = le DPP provisoire ou le DPP et la semaine de début de l’accord de TP;

- chiffres 15 et 16 = le nombre de semaines de TP.

Les HHN du client sont fournies dans les renseignements de la demande.

Si la demande ne peut pas être automatisée, le système crée un AT de demande particulière dans SNCT.

Dans le cas des demandes continues et des demandes de renouvellement qui ne peuvent pas être automatisées, l’agent saisit une transaction Renouvellement/Révisé (M106) avec une date égale à la première semaine de TP comprenant l’indicatif 2,6 ou 7. L’agent ajoute W - Travail partagé - Aucune déclaration à compléter ou H - Travail partagé - déclarations à compléter . Si le code d’action de la demande est manquant pendant le renouvellement, l’agent s’assure que les déclarations du prestataire pour la période précédant la semaine de début de TP ont été traitées. Ensuite, l’agent saisit un traitement manuel TM76 le premier jour et saisit le code le deuxième jour.

Si la dernière semaine de l’accord de TP a été traitée et que le traitement manuel TM76 ne s’applique plus, l’agent annule le traitement manuel.

L’agent peut aussi utiliser le traitement manuel 76R - Travail partagé automatisé Annuler/Suppression des déclarations en suspens (TM76R) si la dernière semaine de l’accord de TP n’est pas encore traitée, s’il y a des déclarations du prestataire en attente de traitement et si un traitement manuel TM76 ne s’applique plus.

Quand la semaine de fin du TP est au-delà du DPP + 103, la transaction Données de projet — Travail partagé (M171) saisie par TAD est rejetée et aucun AT n’est créé. L’agent responsable de surveiller les accords de TP vérifie s’il y a des renseignements manquants dans les demandes des clients, saisit de nouveau la transaction Données de projet (M171) et fixe la date de fin de l’accord pour qu’elle corresponde au DPP + 103.

**Fin de l’accord de Travail partagé (TP)**

Les prestations de TP prennent fin à la date de fin de l’accord ou quand l’accord de TP est terminé avant la date de fin prévue.

Les prestations pour TP peuvent se terminer plus tôt pour les clients individuels, quand le client :

- retourne travailler à plein temps

- quitte l’emploi visé par le TP

- épuise ses prestations

- arrête de se présenter au travail

**Accord de Travail partagé (TP) subséquent**

Si une mesure spéciale permet à l’employeur de conclure un accord de TP subséquent immédiatement après l’accord existant, cet accord est traité comme tout nouvel accord. Le client doit présenter une demande avec un code de référence pour participer à l’accord subséquent. L’agent de programme responsable du TP invite les employeurs à émettre les RE avec une date de fin correspondant au jour de travail avant le nouvel accord.

Un client qui participe à un accord subséquent doit présenter une nouvelle demande si sa demande atteint la fin du DPP (DPP + 103).

**Fermeture planifiée pendant un accord de Travail partagé (TP)**

Les employeurs peuvent devoir cesser leurs activités pendant certaines périodes. Ces périodes de fermeture sont soit approuvées par l’agent de programme, ou l’accord de TP est terminé.

Si l’accord de TP est terminé, tous les participants sont retirés de l’accord de TP et doivent convertir leurs demandes pour recevoir des prestations régulières. Si l’agent de programme ne met pas fin à l’accord et que la période de fermeture est de 4 semaines ou moins, le client peut continuer d’être exempté de remplir des déclarations du prestataire. Si la période de fermeture est supérieure à 4 semaines, le client n’est plus exempté de remplir des déclarations et doit remplir des déclarations du prestataire papier. Le client est assujetti aux mêmes droits et responsabilités qu’un client normal pendant les fermetures planifiées.

Peu importe la durée de la période de fermeture, si l’accord de TP est actif, l’employeur doit remplir un RU pour chaque semaine.

**Accord de Travail partagé (TP) au-delà des 104 semaines**

Chaque semaine qui est traitée comme une semaine de TP prolonge la PP d’une semaine. Le système prolonge la PP une semaine à la fois quand une semaine de TP est traitée, jusqu’à la semaine 104 de la PP, après laquelle le système ne peut plus automatiser d’autres prolongations.

Quand la date de fin de l’accord de TP d’un client est au-delà de la semaine du DPP + 103, l’agent saisit le DPP + 103 comme date de fin. L’agent informe le client par lettre qu’il doit présenter une nouvelle demande de prestations régulières après le traitement de la semaine DPP + 103. L’agent consigne cette décision et les détails de l’accord de TP dans un rapport de décision (RD).

Dans la lettre, les clients sont informés que le code de référence qu’ils ont reçu au début de l’accord a maintenant expiré et qu’il leur est conseillé de présenter une demande sans code de référence. Il est aussi conseillé d’indiquer TP comme MCE dans la demande.

Les clients doivent fournir un RE pour tout travail effectué au cours de leur période de référence (PR), y compris le TP. Le dernier jour du RE du TP doit être le dernier samedi de la demande (p. ex. la semaine 104 de la demande).

Puisque le client présente maintenant une demande pour des prestations régulières, l’agent saisit les transactions requises pour établir la demande comme une demande de TP. Cela comprend la saisie d’un traitement manuel 76 - Travail partagé automatisé (TM76), qui permet de traiter automatiquement les déclarations du prestataire selon la soumission du RU par l’employeur.

De plus, l’agent saisit les données de l’accord de TP dans le RD. La Date de début du projet est saisie comme le DPP de la demande.

Lors d’une demande de prestations régulières, le client n’a pas la possibilité de demander une exemption de remplir des déclarations du prestataire. Dans ce cas, l’agent effectue un recueil de faits auprès du client et lui propose cette option. Au besoin, l’agent saisit le code PAS-IND-DP.

**Examiner une demande établie après une demande qui a atteint la semaine 104**

Quand une demande de TP atteint le DPP + 103 et qu’une nouvelle demande est établie dans les 8 semaines suivantes, la demande s’affiche dans le rapport SU39241 dans SDE .
       [SDE](https://eds-sde.prv/)

Le coordonnateur régional du TP est chargé de veiller à l’examen du rapport. Si le nouveau taux de prestations du client est inférieur à celui de la demande précédente, l’agent communique avec le client et discute des avantages et inconvénients de poursuivre avec la nouvelle demande initiale plutôt que de renouveler la demande précédente.

**Renouvellement d’une demande de Travail partagé (TP)**

Quand un client participant au TP présente une demande d’AE, la semaine de renouvellement est la date de début de l’accord de TP (les chiffres 11 à 14 du code de référence). L’agent antidate le renouvellement à la semaine de début, au besoin.

Quand TAD a incorrectement postdaté la semaine de renouvellement en raison de la rémunération versée par l’employeur participant au TP, l’agent corrige la postdate. La rémunération d’un emploi qui fait partie d’un accord de TP n’est pas déduite dans une semaine de TP.

Quand TAD a créé un genre de répartition W - Rémunération semaine 1 en raison de la rémunération versée pendant la semaine de renouvellement par l’employeur participant au TP, l’agent annule la répartition. La rémunération d’un emploi qui fait partie d’un accord de TP n’est pas déduite dans une semaine de TP.

Si une décision reportée entraîne une exclusion dans une demande de renouvellement, un nouveau DPP est requis pour payer les prestations de TP.

**Responsabilités du coordonnateur régional de Travail partagé (TP)**

**Code de référence**

Dès qu’un accord de TP est conclu, le coordonnateur régional de TP est responsable d’obtenir et de fournir un code de référence et une date d’expiration au spécialiste de services aux citoyens. Un nouveau code de référence est aussi requis quand un ou plusieurs employés sont ajoutés à un accord de TP initial ou prolongé. Quand il ajoute un employé, le coordonnateur fournit un nouveau code de référence et en avise le demandeur. Les chiffres 11 à 14 du code à 16 chiffres correspondent à la s/c de la date du début de l’accord. S’il faut ajouter un employé à l’accord, ces chiffres représentent la s/c de la semaine où l’employé a été ajouté. TAD utilise cette s/c pour établir le DPP provisoire, le DPP ou la semaine de renouvellement.

**Saisies dans la transaction Données de projet (M171)**

Afin de traiter les prestations du TP pour chaque employé, l’employeur remplit une feuille de Renseignements pour l’adhésion au Travail partagé, qui énumère les employés participants et leur NAS. Quand il reçoit cette feuille, le coordonnateur s’assure que la partie supérieure et remplie et l’envoie au traitement.

**Prolongations de l’accord de Travail partagé (TP)**

Quand l’agent de programme approuve la prolongation d’un accord de TP, le coordonnateur régional de TP en est avisé. Le coordonnateur envoie les renseignements requis (p. ex. le gabarit avec le nom de l’employeur, la nouvelle date de fin de l’accord et la feuille de renseignements appropriée) au traitement pour saisir la transaction M171.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0481.dita) 

**Examen du rapport SU 39241**

Les demandes qui ont été traitées jusqu’à la 104e semaine et qui sont suivies par une nouvelle demande (y compris les demandes PPNE) sont identifiées dans le rapport hebdomadaire SU 39241 qui est disponible dans SDE .
       [SDE](https://eds-sde.prv/)

Le coordonnateur régional de TP examine le rapport SU 39241 chaque mardi. Le coordonnateur vérifie le rapport au préalable et supprime les demandes dont le taux de prestations est plus élevé dans la demande active parce qu’aucune mesure n’est requise. Le coordonnateur assure aussi que le rapport est traité chaque semaine pour les demandes dont le taux de prestations est inférieur dans la demande active.

Pour contacter les coordonnateurs TP, envoyez un courriel à : esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca
       [esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca](mailto:ESDC.IEN.AGFQ.EI.AG.BEC.GD-GD.CTEO.CO.AE.CORQ.REI.EDSC@servicecanada.gc.ca)

**Rôles et responsabilités**

Consulter le Tableau des rôles et des responsabilités sur le rôle de l’agent de programme, le spécialiste des services aux citoyens, le COPA ou le coordonnateur régional du TP de l’AE.
       [Tableau des rôles et des responsabilités](https://esdc.prv/fr/service-canada/ae/documents-reference/sopa/travail-partage/roles-responsabilities-tp.shtml) 

### Exemple : Hors Canada

Source topic: `fr_FR/common_notes/note_c_0478.dita`

Exemple : Hors Canada

Consulter les tâches correspondantes lors d’une décision liée à un cas de client participant au TP qui est hors Canada. Avant d’imposer toute inadmissibilité résultante, consulter cette page de connaissances. 

### Exemple : Règlement du motif de cessation d’emploi (MCE)

Source topic: `fr_FR/common_notes/note_c_0479.dita`

Exemple : Règlement du motif de cessation d’emploi (MCE)

Consulter les tâches correspondantes lors de la décision d’un MCE pour un client en TP. Pour des considérations supplémentaires si un client quitte un accord de TP, consulter cette page de connaissances. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0480.dita`

Exemple

Horaire irrégulier de 2 semaines : Semaine 1 : HHN = 45 Semaine 2 : HHN = 35

45 + 35 = 80, 80/2 = moyenne de 40 HHN. 40 HHN sont indiquées dans le dossier de la demande.

Déclaré dans le RU : Semaine 1 : HHN = 45, heures travaillées = 27, heures manquées en raison du TP = 18 Semaine 2 : HHN = 35, heures travaillées = 21, heures manquées en raison du TP = 14

Si SPP peut modifier les HHN dans le dossier de la demande chaque semaine et que le taux de prestations du client est 400 $ par semaine, le paiement au client est : Semaine 1 : (18/45) X 400 $ = 160 $ Semaine 2 : (14/35) X 400 $ = 160 $ Le total pour les 2 semaines est de 320 $

Si les HHN dans le dossier de la demande sont moyennées, le paiement au client est : Semaine 1 : (18/40) X 400 $ = 180 $ Semaine 2 : (14/40) X 400 $ = 140 $ Le total pour les 2 semaines est de 320 $ 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0481.dita`

Remarque :

Au Québec, l’agent de traitement peut accéder aux renseignements sur le TP directement dans l’Outil de référence Travail Partagé, un outil de communication Outlook. Le coordonnateur régional de TP ne doit pas transférer les renseignements sur le TP au traitement. 
