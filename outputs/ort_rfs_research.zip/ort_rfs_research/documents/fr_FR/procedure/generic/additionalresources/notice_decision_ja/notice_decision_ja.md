# Avis de décision : Exigences — Connaissances

Source map: `fr_FR/procedure/generic/additionalresources/notice_decision_ja/notice_decision_ja.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/notice_decision_ja/ressources_additionnelles.dita`

Sommaire : Quand un agent rend une décision, un avis de décision verbal ou écrit peut être requis.

Table des matières

Niveau 1
       [Niveau 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/notice_decision_ja#n1)

- Situations où ni un avis de décision écrit ni une communication verbale n’est nécessaire
         [Situations où ni un avis de décision écrit ni une communication verbale n’est nécessaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/notice_decision_ja#s1f)

- Situations qui ne nécessitent pas d’avis de décision écrit quand il y a eu communication verbale de la décision
         [Situations qui ne nécessitent pas d’avis de décision écrit quand il y a eu communication verbale de la décision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/notice_decision_ja#s2f)

- Situations où un avis de décision écrit est toujours nécessaire
         [Situations où un avis de décision écrit est toujours nécessaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/notice_decision_ja#s3f)

Niveau 2
       [Niveau 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/notice_decision_ja#n2)

- Situations où ni un avis de décision écrit ni une communication verbale n’est nécessaire
         [Situations où ni un avis de décision écrit ni une communication verbale n’est nécessaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/notice_decision_ja#s4f)

- Situations où un avis de décision écrit est toujours nécessaire
         [Situations où un avis de décision écrit est toujours nécessaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/notice_decision_ja#s5f)

**Niveau 1**

**Situations où ni un avis de décision écrit ni une communication verbale n’est nécessaire**

Il existe des situations où une décision ne nécessite pas d’avis de décision écrit ou de communication verbale de la décision.

**Calcul de la demande**

- La demande est finalisée PPNE 2.

- À la suite d’un nouveau calcul, la demande de PPNE devient une demande établie.

- Le DPP est postdaté pour permettre le plein versement des prestations de maternité ou parentales.

- Le DPP est postdaté parce que le client a travaillé une semaine entière dans la semaine de la demande.

- Le DPP est postdaté parce que la rémunération dans la semaine de l’arrêt de rémunération empêche le client d’observer un délai de carence (DC) (au besoin, l’agent peut consulter Délai de carence : Conditions empêchant d’observer un délai de carence — Tableau ).
         [Délai de carence : Conditions empêchant d’observer un délai de carence — Tableau](/fr/procedure/generic/additionalresources/bp_extension_bpc_table.shtml)

- Le DC est reporté dans une demande de prestations parentales, de compassion ou pour proches aidants.

- Une demande d’antidate ou de prolongation de la période de référence ou de la période de prestations (PP) est accordée.

- L’information sur les 14 meilleures semaines fournie par le client n’est pas utilisée ou n’est utilisée qu’en partie.

**Prestations spéciales**

- La cliente est admissible au maximum des prestations de maternité;

- Le client est admissible aux prestations parentales ou de compassion, en partie ou en totalité;

- La cliente est admissible au maximum des prestations de maternité et parentales et il n’y a aucun motif de cessation d’emploi (MCE) litigieux;

- Le client est admissible au régime de prestations supplémentaires de chômage de maternité ou parentales;

- Le MCE est D - Maladie ou Blessure , il n’y a pas de certificat médical au dossier et la semaine de guérison a été calculée comme le DPP + 8 semaines, la semaine de renouvellement + 8 semaines ou la semaine de conversion + 8 semaines (ou DPP + 15 semaines pour un DPP avant la s/c 2442);

- Une inadmissibilité 46 - Ne rencontre pas la norme variable - prestations spéciales payable (D46) est imposée pour empêcher le versement futur des prestations régulières, le MCE n’est pas litigieux et le client demande des prestations de maladie, de maternité, parentales, de compassion ou pour proches aidants. Une mesure temporaire du budget 2021 s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, aucune inadmissibilité 46 - Ne rencontre pas la norme variable - prestations spéciales payables (D46) sera saisie sur ces demandes.

**Rémunération**

- La rémunération de la dernière semaine de travail est répartie sur la première semaine de la PP ou du renouvellement;

- Une pension exemptée a été répartie;

- Une semaine de prestations est non payée en raison d’une semaine entière de travail déclarée, mais le client est toujours sans emploi.

**Autres situations**

- L’annulation d’une inadmissibilité ou d’une exclusion est effectuée et les déclarations du prestataire ont été traitées, ce qui permet le versement des prestations;

- Une décision du Conseil d’appel en assurance-emploi (CAAE) ou du Tribunal de la sécurité (TSS) sociale a été mise en application;

- Les déclarations du prestataire sont modifiées, ce qui permet le versement des prestations pour cette période;

- Une demande de renouvellement est établie et il n’y a pas d’autre décision rendue qui requiert la communication d’une décision.

- La décision sur un MCE litigieux est reportée.

**Situations qui ne nécessitent pas d’avis de décision écrit quand il y a eu communication verbale de la décision**

Que la décision soit liée à une demande initiale, renouvelée ou révisée, la communication verbale d’une décision est suffisante et il n’est pas nécessaire d’envoyer un avis de décision écrit au client quand toutes les conditions suivantes sont remplies :

- Il s’agit d’une décision de Niveau 1 (sauf si elle nécessite un avis écrit);

- La décision peut générer un trop-payé (T-P) mais seulement si le client contacte la Commission pour corriger les renseignements erronés dans les délais prescrits;

- La décision et le T-P établi, s’il y a lieu, sont expliqués verbalement au client;

- Le client est informé qu’aucune lettre ne sera envoyée;

- Le client comprend et est d’accord avec la décision;

- Le droit de demander une révision en vertu de la LAE 112 est expliqué verbalement au client.

Ces conditions s’appliquent aux décisions communiquées verbalement en personne ou par téléphone.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0503.dita) 

**Situations où un avis de décision écrit est toujours nécessaire**

Que la décision soit liée à une demande initiale, renouvelée ou révisée, l’agent doit toujours envoyer un avis de décision de la SCA dans les situations suivantes, même si le client est avisé verbalement de la décision. L’agent peut consulter Communiquer verbalement une décision défavorable pour connaître les prochaines étapes.
       [Communiquer verbalement une décision défavorable](/fr/procedure/task/verbal_communication.shtml)

**Calcul d’une demande**

- Une demande est finalisée PPNE, incluant les situations où le client pourrait être admissible aux prestations spéciales, sauf pour les demandes PPNE 2 et D46;

- Un nouveau calcul entraîne un changement de DPP, d’heures ou de rémunération assurable qui cause un T-P;

- À la suite d’un nouveau calcul, une demande établie devient PPNE (incluant les demandes annulées D14);

- Une inadmissibilité 56 - Prestations du Régime Québécois d’Assurance Parentale est imposée.

- Une demande a été établie et une décision sur une répartition doit être communiquée au client.

- Une demande de prestations de maternité ou parentales a été postdatée parce que le client a présenté la demande avant la fenêtre de prestation.

**Prestations spéciales**

- La cliente est admissible à moins de 15 semaines de prestations de maternité;

- Le client n’est pas admissible aux prestations spéciales;

- Le client est admissible aux prestations pour proches aidants;

- Le client n’est pas admissible aux prestations pour proches aidants;

- La demande initiale, renouvelée ou continue a été approuvée pour une période de prestations de maladie selon un certificat médical.

**Décision sur l’admissibilité aux prestations**

- Le client n’a pu être contacté pour lui communiquer la décision de Niveau 1;

- Le client ne comprend pas ou n’est pas d’accord avec la décision expliquée verbalement;

- Une décision négative de Niveau 2 est rendue;

- Une inadmissibilité 15 - Procédure de présentation des demandes est imposée.

**Lettre à envoyer à l’employeur**

- L’agent doit communiquer le droit de demander une révision en vertu de la LAE 112 à l’employeur dans les situations suivantes :

- un congédiement, si l’inconduite n’a pas été prouvée pour un motif autre qu’inaptitude;

- un départ volontaire, si le client avait un motif valable et les motifs de départs sont reliés à l’emploi;

- un refus d’emploi ou la négligence d’avoir profité d’une occasion d’emploi, si le client a démontré avoir un motif valable et les motifs de refus sont reliés à l’emploi;

- une inadmissibilité n’a pas été imposée ou a pris fin lors de situation de conflit de travail.

- Le client est admissible au régime de prestations supplémentaires de chômage et le client a travaillé pour plus d’un employeur;

**Autres situations**

- La décision est communiquée à une tierce partie autorisée (représentant du client ou interprète);

- Le client demande un avis de décision écrit;

- Le client était initialement d’accord avec la décision quand il a été avisé verbalement, mais exprime son désaccord par la suite. Dans cette situation, l’agent doit documenter dans un RSDP la déclaration du client indiquant qu’il n’est plus d’accord avec la décision. Dès que ce fait est connu par la Commission, l’agent doit envoyer la lettre SCA;

- Initialement, aucune lettre SCA n’a été envoyée et le client désire maintenant une révision de la décision communiquée verbalement, mais n’a pas encore fait la demande. Si le client a déjà fait parvenir sa demande de révision, la lettre SCA ne doit pas être envoyée.

**Niveau 2**

**Situations où ni un avis de décision écrit ni une communication verbale n’est nécessaire**

Il existe des situations où une décision ne nécessite pas d’avis de décision écrit ou de communication verbale de la décision.

**Calcul de la demande**

- Le MCE est D , il n’y a pas de certificat médical au dossier et la semaine de guérison a été calculée comme le DPP + 8 semaines, la semaine de renouvellement + 8 semaines ou la semaine de conversion + 8 semaines (ou DPP + 15 semaines pour un DPP avant la s/c 2442);

- Une demande d’antidate ou de prolongation de la période de référence ou de la période de prestations (PP) est accordée.

**Rémunération**

- La rémunération de la dernière semaine de travail est répartie sur la première semaine de la PP ou du renouvellement;

- Une pension exemptée a été répartie;

- Une semaine de prestations est non payée en raison d’une semaine entière de travail déclarée, mais le client est toujours sans emploi.

**Autres situations**

- L’annulation d’une inadmissibilité ou d’une exclusion est effectuée et que les déclarations du prestataire ont été traitées, ce qui permet le versement des prestations;

- Une décision du CAAE ou du TSS a été mise en application;

- Les déclarations du prestataire sont modifiées, ce qui permet le versement des prestations pour cette période.

- La décision sur un MCE litigieux est reportée.

**Situations où un avis de décision écrit est toujours nécessaire**

Que la décision soit liée à une demande initiale, renouvelée ou révisée, l’agent doit toujours envoyer un avis de décision de la SCA dans les situations suivantes, même si le client est avisé verbalement de la décision. L’agent peut consulter Communiquer verbalement une décision défavorable pour les prochaines étapes :
       [Communiquer verbalement une décision défavorable](/fr/procedure/task/verbal_communication.shtml)

- Une décision négative de Niveau 2 est rendue;

- Une inadmissibilité 15 - Procédure de présentation des demandes (D15) est imposée;

- Un T-P est créé et une pénalité, une violation ou une lettre d’avertissement ont été imposées;

- La décision est communiquée à une tierce partie autorisée (représentant du client ou interprète);

- Le client demande un avis de décision écrit.

- Une demande a été établie et une décision sur une répartition doit être communiquée au client.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0503.dita) 

**Lettre à envoyer à l’employeur**

- L’agent doit communiquer le droit de demander une révision en vertu de la LAE 112 à l’employeur dans les situations suivantes :

- un congédiement, si l’inconduite n’a pas été prouvée pour un motif autre qu’inaptitude;

- un départ volontaire, si le client avait un motif valable et les motifs de départs sont reliés à l’emploi;

- un refus d’emploi ou la négligence d’avoir profité d’une occasion d’emploi, si le client a démontré avoir un motif valable et les motifs de refus sont reliés à l’emploi;

- une inadmissibilité n’a pas été imposée ou a pris fin lors de situation de conflit de travail.

**Création d’un avis SCA**

Quand un avis de décision écrit est requis, la procédure indique le gabarit de lettre à utiliser et les attributs à compléter. Il est aussi indiqué si la lettre doit être sauvegardée ou envoyée.

Certaines lettres de décisions sont maintenant automatisées par le système. Quand la lettre est automatisée par le système, l’agent n’a pas à compléter une deuxième lettre. Quand une lettre automatisée ne peut pas être envoyée par le système, un AT Correspondance (COR) est créé et l’agent doit remplir la lettre. Pour plus d’information sur les AT COR, consulter AT Correspondance . Pour plus d’information sur les lettres automatisées, consulter Solution de correspondance automatisée .
       [AT Correspondance](/fr/procedure/activity/correspondence.shtml) 
       [Solution de correspondance automatisée](https://esdc.prv/fr/service-canada/ae/technologies/correspondance-ae/lettres/index.shtml)

Voici une liste des décisions dont l’avis est automatisé :

- Une demande est établie PPNE N1 ou N6 (lettre B-00-00-00);

- Une demande de prestations de maternité ou parentales est établie et le nombre de semaines de prestations de maternité est inférieur à 15 (lettre N-01-00-00);

- Une demande de renouvellement est établie et une décision sur une répartition doit être communiquée au client (lettre R-01-00-00);

- Une décision positive est rendue sur un MCE litigieux et le droit de demander une révision en vertu de la LAE 112 doit être communiqué à l’employeur (lettre Z-01-00-00). 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0503.dita`

Remarque :

Laisser un message sur un répondeur ou une boîte vocale, ou à une tierce partie n’est pas acceptable et ne constitue pas une communication verbale de la décision. Si un client ne peut pas être joint, l’agent doit envoyer un avis de décision. 
