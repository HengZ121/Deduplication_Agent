# Déclaration du prestataire : Codage de paiement (exclusion interne ou externe) — Guide de saisie

Source map: `fr_FR/procedure/generic/additionalresources/pay_coding_guide/pay_coding_guide.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/pay_coding_guide/ressources_additionnelles.dita`

Quand un client est exclu de remplir des déclarations du prestataire électroniques, il doit remplir une déclaration du prestataire papier pour fournir des renseignements sur chaque semaine pour laquelle il demande des prestations. Pour remplir une déclaration du prestataire pour un client participant au Travail partagé (TP), l’agent du COPA passe à Travail partagé — Guide du codage de paiement .
       [Travail partagé — Guide du codage de paiement](/fr/procedure/generic/additionalresources/pay_coding_guide_ws.shtml)

Quand la demande est dans SMP, l’agent du COPA traite la déclaration du client à l’aide du registre électronique SMP et de la transaction Déclarations du prestataire (T072) . Quand la demande est dans SIP, l’agent utilise la transaction Émettre paiements (M151/M152).
       [Déclarations du prestataire (T072)](/fr/procedure/generic/additionalresources/manual_pay_sys_claimant.shtml)

La déclaration du prestataire papier comprend 6 questions. Selon les réponses fournies par le client, l’agent ou le commis du COPA pourrait devoir prendre des mesures supplémentaires. Quand un client fournit des renseignements devant faire l’objet d’une décision ou ne pouvant pas être traités par l’agent ou le commis, ce dernier envoie un AT Action à prendre (AP) au Niveau 1.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0513.dita) 

Les 6 questions sont les suivantes :

- Étiez-vous à l’extérieur du Canada entre lundi et vendredi?
         [Étiez-vous à l’extérieur du Canada entre lundi et vendredi?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pay_coding_guide#_etiez_vous_exterieur)

- Avez-vous travaillé, y compris un travail à votre compte, même si vous n’avez pas encore été ou ne serez pas rémunéré pour ce travail?
         [Avez-vous travaillé, y compris un travail à votre compte, même si vous n’avez pas encore été ou ne serez pas rémunéré pour ce travail?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pay_coding_guide#Did_you_work)

- Avez-vous commencé à travailler à temps plein?
         [Avez-vous commencé à travailler à temps plein?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pay_coding_guide#Avez-vous_commencé_à)

- Étiez-vous aux études ou suiviez-vous un cours de formation?
         [Étiez-vous aux études ou suiviez-vous un cours de formation?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pay_coding_guide#Étiez-vous_aux_études)

- Étiez-vous prêt et disposé à travailler, et capable de le faire chaque jour?
         [Étiez-vous prêt et disposé à travailler, et capable de le faire chaque jour?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pay_coding_guide#Étiez-vous_prêt_et)

- Avez-vous reçu ou recevrez-vous des sommes autres que celles indiquées dans les parties 2d et 4b?
         [Avez-vous reçu ou recevrez-vous des sommes autres que celles indiquées dans les parties 2d et 4b?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pay_coding_guide#Avez-vous_reçu_ou)

**Étiez-vous à l’extérieur du Canada entre lundi et vendredi?**

La question 1 comprend 3 parties :

- Étiez-vous à l’extérieur du Canada entre lundi et vendredi? (Choisissez « Oui » si vous étiez à l’extérieur du Canada entre lundi et vendredi. Choisissez « Non » si vous étiez à l’extérieur du Canada seulement durant la fin de semaine.) Si « Oui », remplissez la partie 1b.

- Est-ce que votre absence du Canada était pour une durée de plus de 24 heures, à l’exclusion des heures de fin de semaine?

- Pour toute absence du Canada, fournissez les renseignements suivants :

- Date de départ, heure, avant-midi/après-midi

- Date de retour, heure, avant-midi/après-midi

- Raison de l’absence

**Question 1a**

Si le client répond Oui à la question 1a, s’assurer que les parties 1b et 1c sont remplies.

```text
| Réponse | Déclarations du prestataire dans SMP | Déclarations du prestataire dans SIP |

| Registre électronique SMP | Émettre paiements (M151/M152) |

| Non | Passer à la question 2. | Passer à la question 2. |

| Oui | S’il y a une inadmissibilité pour la même période, à l’onglet TC85 : - EI/ND : Saisir le nombre de jours de non-disponibilité pour chaque semaine. À l’onglet FTS - ETI , choisir les options appropriées dans les champs Ind. de paiement , Messages SEM1 ou Messages SEM2 et Hist de paiement (sem1) ou Hist de paiement (sem2) . S’il n ’y a pas d’inadmissibilité au dossier, ne pas traiter la déclaration du prestataire. Consulter Créer un AT Action à prendre (AP) dans la tâche initiale. | S’il y a une inadmissibilité pour la même période : Jour(s) non disponible : Laisser ce champ vide et traiter la déclaration du prestataire. S’il n ’y a pas d’inadmissibilité au dossier, ne pas traiter la déclaration du prestataire. Consulter Créer un AT Action à prendre (AP) dans la tâche initiale. |
```

**Avez-vous travaillé, y compris un travail à votre compte, même si vous n’avez pas encore été ou ne serez pas rémunéré pour ce travail?**

La question 2 comprend 5 parties :

- Avez-vous travaillé, y compris un travail à votre compte, même si vous n’avez pas encore été ou ne serez pas rémunéré pour ce travail? Si « Oui », remplissez les parties 2b, 2c, 2d et 2e.

- Heures totales et dates de travail

- Nom et adresse de l’employeur

- Rémunération brute totale

- Si vous avez cessé de travailler, indiquez la (les) raison(s)

**Genres de rémunération déclarée**

Généralement, le client déclare l’un des genres de rémunération suivants :

- emploi assurable

- pêche
         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0514.dita)

- travail indépendant (TI) (p. ex. garde d’enfants, agent immobilier, chauffeur de taxi)
         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0515.dita)

Toutefois, un client peut déclarer une rémunération provenant de plusieurs sources différentes. Si une décision est requise pour déterminer si la rémunération est assurable, envoyer un AT AP au Niveau 1.

**Question 2a**

Si le client répond Oui à la question 2a, s’assurer que les parties 2b et 2c, 2d et 2e sont remplies.

Déterminer le nombre d’heures travaillées. Si le client a travaillé 35 heures ou plus par semaine (ou 28 heures ou plus pendant une semaine comprenant un jour férié ), coder la semaine comme une SET .
       [jour férié](/fr/procedure/generic/additionalresources/stat_civic_holidays.shtml) 
       [SET](http://wecs-siew.prv/wecs-siew/searchdetails_f.aspx?evalid=R013)

```text
| Réponse | Déclarations du prestataire dans SMP | Déclarations du prestataire dans SIP |

| Registre électronique SMP | Émettre paiements (M151/M152) |

| Non | Vérifier la question 2e. | Vérifier la question 2e. |

| Oui | À l’onglet TC85 : - Rémun. : Saisir la rémunération. - SET : Saisir l’indicatif de SET, au besoin. À l’onglet FTS - ETI , choisir les options appropriées dans les champs Ind. de paiement Messages SEM1 ou Messages SEM2 et Hist de paiement (sem1) ou Hist de paiement (sem2) . | Rémunération : Saisir la rémunération. Semaine entière de travail : Choisir l’indicatif de SET, au besoin. |

| | Remarque : Si le client répond aussi Oui à la question 3, Avez-vous commencé à travailler à temps plein? et qu’il indique avoir : - trouvé du travail le dimanche ou lundi de la semaine 1 : - trouvé du travail le dimanche ou lundi de la semaine 2 : - trouvé du travail après le lundi de la semaine 1 : - trouvé du travail après le lundi de la semaine 2 : - Ajouter la rémunération pour les semaines 1 et 2, au besoin. Choisir 5 - Retour au travail après le lundi de la 2ième semaine de la déclaration dans le champ Retour au travail . Ne pas coder la SET pour la semaine 2. |
```

**Question 2e**

Si le client indique qu’il a cessé de travailler et fournit des renseignements litigieux, envoyer un AT AP au Niveau 1 pour qu’une décision soit rendue. Consulter Créer un AT Action à prendre (AP) dans la tâche initiale.

Voici quelques exemples de renseignements litigieux :

- motif de cessation d’emploi litigieux;

- questions de disponibilité;

- précisions apportées sur des sommes;

- précisions apportées sur de la formation;

- précisions apportées sur l’état de l’emploi (p. ex. TI)

- conflit collectif;

- changement de nom ou d’adresse déclaré;

- changement de NAS déclaré;

- correspondance jointe (p. ex. certificat médical);

- prestations de maladie en prestations régulières;

- période de maternité ou parentale non établie; ou

- tout autre renseignement contradictoire.

**Avez-vous commencé à travailler à temps plein?**

Si le client répond Oui pour indiquer qu’il a commencé à travailler à temps plein pendant la période visée par cette déclaration du prestataire, considérer la date de début indiquée et traiter la déclaration du prestataire à l’aide de l’indicatif de retour au travail (RAT) approprié.
       [retour au travail (RAT)](http://wecs-siew.prv/wecs-siew/searchdetails_f.aspx?evalid=R012)

```text
| Réponse | Déclarations du prestataire dans SMP | Déclarations du prestataire dans SIP |

| Registre électronique SMP | Émettre paiements (M151/M152) |

| Non | Passer à la question 4. | Passer à la question 4. |

| Oui | À l’onglet TC85 : - Ret au travail : Saisir l’option appropriée. - Rémun. : Saisir la rémunération, au besoin. À l’onglet FTS - ETI : - Ind. de paiement : Choisir l’option appropriée. - Hist de paiement (sem1) ou Hist de paiement (sem2) : Choisir 38 - Retour au travail 1 ou 2 . - Déc à émettre : Choisir N . | Rémunération. : Saisir la rémunération, au besoin. Retour au travail : Choisir l’indicatif approprié. |

| Remarque : Si l’indicatif de RAT est : - 1 - Retour au travail le dimanche ou le lundi de la semaine 1 : - 2 - Retour au travail le dimanche ou le lundi de la semaine 2 : - 3 - Retour au travail le dimanche ou le lundi qui suit la semaine 2 : - 4 - Retour au travail après le lundi de la 1ère semaine de la déclaration : - 5 - Retour au travail après le lundi de la 2ième semaine de la déclaration : Si le client indique avoir commencé à travailler à temps plein, consulter Terminer une demande SMP active . [Terminer une demande SMP active](/fr/procedure/task/terminating_active_mps.shtml) [Terminer une demande SMP active](/fr/procedure/task/terminating_active_mps.shtml) |
```

**Étiez-vous aux études ou suiviez-vous un cours de formation?**

La question 4 comprend 3 parties :

- Étiez-vous aux études ou suiviez-vous un cours de formation?

- Si « Oui », indiquez le nombre d’heures d’études ou de formation ainsi que le montant de toute allocation de formation reçue dans la partie 4b. Indiquez qui vous a versé cette allocation dans la partie 4c.

- Allocation de formation et heures totales

- Reçu de

Si le client répond Oui à la question 4a, vérifier le nombre d’heures de présence au cours ou toute allocation de formation reçue dans les parties 4b et 4c. Vérifier aussi l’onglet Projet dans ETI pour tout autre renseignement sur la formation.

Pour une demande SMP, le lien Projet à l’onglet Système manuel doit également être surligné, ce qui indique que la transaction Mise à jour de projet ou d’accord (T077) a été saisie. Cependant, si le client reçoit des prestations spéciales quand il est dirigé en vertu de l’article 25, ne pas saisir une transaction T077 .

Les clients qui sont dirigés vers une formation en vertu de l’article 25 continuent de recevoir des prestations spéciales pourvu qu’ils remplissent les conditions liées aux prestations spéciales. Lors du traitement de ces paiements au moyen de la transaction Déclarations du prestataire (T072) , saisir le bon indicatif de l’état récapitulatif des paiements (ERP) des prestations spéciales dans les champs Hist de paiement (sem1) ou Hist de paiement (sem2) .

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0516.dita) 

```text
| Réponse | Déclarations du prestataire dans SMP | Déclarations du prestataire dans SIP |

| Registre électronique SMP | Émettre paiements (M151/M152) |

| Non | | Passer à la question 5. | Passer à la question 5. |

| Oui | À l’onglet Projet , l’indicatif de la formation est 90 (c.-à-d. non dirigé en vertu de l’article 25). | À l’onglet TC85 : - STUAE : Saisir « 03. » - MNT STUAE : Saisir « 0000 » ou l’allocation de formation, au besoin. À l’onglet FTS - ETI : - Activité de projet : Choisir T -Stagiaire payé au taux d’allocation de formation . - Hist de paiement (sem1) ou Hist de paiement (sem2) : Choisir l’option appropriée. [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0517.dita) | Codage STUAE : Choisir T - Formation et saisir « 0000 » ou l’allocation de formation, au besoin. |

| À l’onglet Projet , l’indicatif de la formation n’est pas 90 (p. ex. 09 , 21 , 39 , 53 ) (c.-à-d. dirigé en vertu de l’article 25). | Pour prestations spéciales seulement À l’onglet FTS - ETI : - Hist de paiement (sem1) ou Hist de paiement (sem2) : Choisir l’option appropriée. Pour tous les autres genres de prestations (GP) À l’onglet TC85 : - STUAE : Saisir « 03. » - MNT STUAE : Saisir « 0000. » À l’onglet FTS - ETI : - Activité de projet : Choisir T - Stagiaire payé au taux d’allocation de formation . - Hist de paiement (sem1) ou Hist de paiement (sem2) : Choisir 6 - Formation . | Codage STUAE : Choisir T - Formation et saisir « 0000. » |

| [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0518.dita) |

| Il n’y a pas d’indicatif de formation à l’onglet Projet . | - Si le client déclare moins de 10 heures de formation par semaine, ne pas coder la formation et traiter la déclaration du prestataire. - Si le client déclare 10 heures ou plus de formation par semaine, consulter Créer un AT Action à prendre (AP) dans la tâche initiale. |
```

**Étiez-vous prêt et disposé à travailler, et capable de le faire chaque jour?**

La question 5 comprend 4 parties :

- Étiez-vous prêt et disposé à travailler, et capable de le faire chaque jour?

- Si « Non », indiquez la (les) date(s) et raison(s) dans les parties 5b et 5c, et remplissez la partie 5d s’il y a lieu.

- Date(s)

- Raison(s)

- Indemnité d’assurance collective-maladie/maternité

Si le client répond Non , examiner la raison et les dates inscrites dans les parties 5b et 5c et vérifier la partie 5d.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0519.dita) 

```text
| Réponse | Déclarations du prestataire dans SMP | Déclarations du prestataire dans SIP |

| Registre électronique SMP | Émettre paiements (M151/M152) |

| Oui | | Passer à la question 6. | Passer à la question 6. |

| Non | Le client déclare des jours de maladie. | Si le GD est 2, 6 ou 7 et que le client déclare 5 jours de maladie, et que la semaine est traitée la s/c 2385-5 ou après et entraine un paiement comme semaine de maladie occasionnelle, à l’onglet MN05 , suivre les directives suivantes : - Mal Occ Payé : Saisir le nombre approprié pour augmenter de 1 semaine, jusqu’à un maximum de 8 semaines. À l’onglet TC85 : - Maladie : Pour chaque semaine, saisir le nombre de jours de maladie. À l’onglet FTS - ETI , choisir les options appropriées dans les champs Ind. de paiement , Messages SEM 1 ou Messages SEM 2 et Hist de paiement (sem1) ou Hist de paiement (sem2) . | Jour(s) de maladie : Pour chaque semaine, choisir le nombre de jours de maladie. |

| [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0520.dita) |

| Le client déclare des prestations de maternité, parentales, de compassion ou pour proches aidants. | À l’onglet TC85 : - EI/ND : Laisser le champ vide. À l’onglet FTS - ETI , choisir les options appropriées dans les champs Ind. de paiement , Messages SEM1 ou Messages SEM2 et Hist de paiement (sem1) ou Hist de paiement (sem2) . | Jour(s) non disponible : Pour chaque semaine, choisir 5 . Remarque : Les prestations pour proches aidants ne peuvent être versées que dans une demande SMP. |

| [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0521.dita) |

| Le client déclare des jours de non-disponibilité. | À l’onglet TC85 : - EI/ND : Pour chaque semaine, saisir le nombre de jours de non-disponibilité. À l’onglet FTS - ETI , choisir les options appropriées dans les champs Ind. de paiement , Messages SEM 1 ou Messages SEM2 et Hist de paiement (sem1) ou Hist de paiement (sem2) . | Jour(s) non disponible : Pour chaque semaine, choisir le nombre de jours de non-disponibilité. |

| Le client déclare être en vacances au Canada entre lundi et vendredi de la période visée par cette déclaration du prestataire. | À l’onglet TC85 : - EI/ND : Pour chaque semaine, saisir le nombre de jours de non-disponibilité. À l’onglet FTS - ETI , choisir les options appropriées dans les champs Ind. de paiement , Messages SEM1 ou Messages SEM2 et Hist de paiement (sem1) ou Hist de paiement (sem2) . | - Jour(s) non disponible : Suivre les directives suivantes : |

| [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0522.dita) |

| Le client déclare être non-disponible pour une autre raison (p. ex. hors Canada, incarcération, fonction de juré, conflit de travail.) | ```text | S’il y a une inadmissibilité pour la même période, à l’onglet TC85 : - EI/ND : Saisir le nombre de jour de non-disponibilité pour chaque semaine. À l’onglet FTS - ETI , choisir les options appropriées dans les champs Ind. de paiement , Messages SEM1 ou Messages SEM2 et Hist de paiement (sem1) ou Hist de paiement (sem2) . S’il n ’y a pas d’inadmissibilité au dossier, ne pas traiter la déclaration du prestataire. Consulter Créer un AT Action à prendre (AP) dans la tâche initiale. | ``` | S’il y a une inadmissibilité pour la même période : Jour(s) non disponible : Laisser ce champ vide et traiter la déclaration du prestataire. S’il n ’y a pas d’inadmissibilité au dossier, ne pas traiter la déclaration du prestataire. Consulter Créer un AT Action à prendre (AP) dans la tâche initiale. |

| S’il y a une inadmissibilité pour la même période, à l’onglet TC85 : - EI/ND : Saisir le nombre de jour de non-disponibilité pour chaque semaine. À l’onglet FTS - ETI , choisir les options appropriées dans les champs Ind. de paiement , Messages SEM1 ou Messages SEM2 et Hist de paiement (sem1) ou Hist de paiement (sem2) . S’il n ’y a pas d’inadmissibilité au dossier, ne pas traiter la déclaration du prestataire. Consulter Créer un AT Action à prendre (AP) dans la tâche initiale. |
```

**Avez-vous reçu ou recevrez-vous des sommes autres que celles indiquées dans les parties 2d et 4b?**

La question 6 comprend 4 parties :

- Avez-vous reçu ou recevrez-vous des sommes autres que celles indiquées dans les parties 2d et 4b?

- Si « Oui », remplissez les parties 6b et 6c en indiquant la source de ces sommes, ainsi que la raison pour laquelle vous les avez reçues. Indiquez le montant total reçu dans la partie 6d.

- Reçu de

- Raison

- Autres sommes brutes totales

Si le client répond Non , retourner à la tâche initiale.

Si le client répond Oui , suivre l’une des directives suivantes :

- Pour les sommes ou les répartitions autres que celles des indemnités d’assurance-salaire (IAS) ou d’un congé de maladie payé (CMP) (p. ex. indicatif de répartition P - Pension-non exemptée ), passer à Sommes ou répartitions autres que celles des indemnités d’assurance-salaire (IAS) ou d’un congé de maladie payé (CMP) .
         [Sommes ou répartitions autres que celles des indemnités d’assurance-salaire (IAS) ou d’un congé de maladie payé (CMP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pay_coding_guide#_Sommes_ou_répartitions)

- Pour les IAS ou les CMP, passer à Sommes déclarées pour des indemnités d’assurance-salaire (IAS) ou un congé de maladie payé (CMP) .
         [Sommes déclarées pour des indemnités d’assurance-salaire (IAS) ou un congé de maladie payé (CMP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/pay_coding_guide#_Sommes_déclarées_pour)

**Sommes ou répartitions autres que celles des indemnités d’assurance-salaire (IAS) ou d’un congé de maladie payé (CMP)**

```text
| | Déclarations du prestataire dans SMP | Déclarations du prestataire dans SIP |

| | Registre électronique SMP | Émettre paiements (M151/M152) |

| Les sommes déclarées sont égales au montant réparti au dossier. | À l’onglet TC85 : - Répartition : Saisir le montant indiqué à l’onglet M175 . | Ne pas coder la répartition. |

| Les sommes déclarées sont supérieures ou inférieures au montant réparti au dossier ou il n’y a pas de répartition au dossier. | Ne pas traiter la déclaration du prestataire. Consulter Créer un AT Action à prendre (AP) dans la tâche initiale. |
```

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0523.dita) 

**Sommes déclarées pour des indemnités d’assurance-salaire (IAS) ou un congé de maladie payé (CMP)**

**Déclarations du prestataire dans SIP**

Les sommes déclarées sont égales au montant réparti au dossier.

Ne pas coder la répartition.

Les sommes déclarées sont supérieures ou inférieures au montant réparti au dossier ou il n’y a pas de répartition au dossier.

Ne pas traiter la déclaration du prestataire. Consulter Créer un AT Action à prendre (AP) dans la tâche initiale.

**Déclarations du prestataire dans SMP**

Le code de réduction du taux de cotisation est 1 - Aucune réduction du taux de cotisation , et le client déclare des IAS ou un CMP.

Déduire 50 % de la rémunération jusqu’au seuil de 90 %, puis à 100 %.

À l’onglet M175 :

- Genre : Choisir l’option appropriée :

- Si le client déclare des IAS, saisir « F. »

- Si le client déclare un CMP, saisir « L. »

À l’onglet TC85 :

- Répartition : Saisir le montant des IAS ou du CMP, ou le montant total des deux.

Le code de réduction du taux de cotisation est 2 - Réduction du taux de cotisation pour un plan d’assurance-salaire , et le client déclare des IAS.

Déduire les IAS à 100 % pour les GP 10, 11, 73 et 74 seulement.

À l’onglet M175 :

- Genre : Saisir « F. »

À l’onglet TC85 :

- STUAE : Saisir « 02. »

- MNT STUAE : Saisir le montant des IAS.

- Répartition : Laisser le champ vide.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0524.dita) 

Le code de réduction du taux de cotisation est 2 - Réduction du taux de cotisation pour un plan d’assurance-salaire , et le client déclare un CMP.

Déduire 50 % de la rémunération jusqu’au seuil de 90 %, puis à 100 %.

À l’onglet M175 :

- Genre : Saisir « L. »

À l’onglet TC85 :

- Répartition : Saisir le montant du CMP.

Le code de réduction du taux de cotisation est 3 - Réduction du taux de cotisation pour un plan de congé de maladie , et le client déclare des IAS.

Déduire 50 % de la rémunération jusqu’au seuil de 90 %, puis à 100 %.

À l’onglet M175 :

- Genre : Saisir « F. »

À l’onglet TC85 :

- Répartition : Saisir le montant des IAS.

Le code de réduction du taux de cotisation est 3 - Réduction du taux de cotisation pour un plan de congé de maladie , et le client déclare un CMP.

Déduire le CMP à 100 % pour les GP 10, 11, 73 et 74 seulement.

À l’onglet M175 :

- Genre : Saisir « L. »

À l’onglet TC85 :

- STUAE : Saisir « 04. »

- MNT STUAE : Saisir le montant du CMP.

- Répartition : Laisser le champ vide.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0524.dita) 

Le code de réduction du taux de cotisation est 4 - Réduction du taux de cotisation pour un plan d’assurance-salaire et congé de maladie , et le client déclare des IAS ou un CMP ou les deux.

Déduire les IAS ou le CMP à 100 % pour les GP 10, 11, 73 et 74 seulement.

À l’onglet M175 :

- Genre : Choisir l’option appropriée :

- Si le client déclare des IAS, saisir « F. »

- Si le client déclare un CMP, saisir « L. »

À l’onglet TC85 :

- STUAE : Saisir « 02. »

- MNT STUAE : Saisir le montant des IAS ou du CMP, ou le montant total des deux.

- Répartition : Laisser le champ vide.

Il n’y a pas de code de réduction du taux de cotisation, le GP est 10, 11, 73 ou 74 et le client déclare des IAS ou un CMP pour la s/c 2147 ou après.

Envoyer un AT AP pour obtenir le code de réduction du taux de cotisation avant de traiter la déclaration du prestataire.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0525.dita) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0513.dita`

Remarque :

Dans la région de l’Ouest du Canada et des Territoires, s’il y a des renseignements devant faire l’objet d’une décision ou ne pouvant pas être traités par l’agent ou le commis du COPA, ce dernier envoie un AT AP pour que l’unité de paiement régionale les examine. Si la partie à examiner de la déclaration du prestataire ne peut pas être traitée par l’unité de paiement régionale, l’agent de l’unité de paiement régionale envoie un AT AP pour qu’un agent de Niveau 1 l’examine et la traite. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0514.dita`

Remarque :

Si un pêcheur déclare des heures travaillées mais aucune rémunération, ne pas les coder comme une semaine entière de travail (SET). 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0515.dita`

Remarque :

Quand une décision a été rendue sur le TI et qu’il a été accordé, 2 - Travailleur indépendant, mais n’est pas sur projet TI s’affiche à l’écran Codage spécial dans ETI. Si 2 - Travailleur indépendant, mais n’est pas sur projet TI ne s’affiche pas dans ETI ou que le client déclare un changement dans l’activité du TI, consulter Créer un AT Action à prendre (AP) dans la tâche initiale. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0516.dita`

Remarque :

Pour les bris scolaires (p. ex. Noël), continuer de les coder comme une formation. Un agent de traitement fournit les autres congés autorisés dans un Mémo pour le centre opérationnel (MM06) . 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0517.dita`

Remarque :

Ne pas choisir 6 - Formation . 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0518.dita`

Remarque :

Si le client déclare une allocation, consulter Créer un AT Action à prendre (AP) dans la tâche initiale. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0519.dita`

Remarque :

En ce qui concerne un client décédé, le RAE 27 autorise le versement de prestations d’AE à une personne qui agit au nom d’un client décédé. Vérifier s’il y a un représentant au dossier. S’il n’y en a pas, ne pas traiter la déclaration du prestataire et envoyer un AT AP au Niveau 1. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0520.dita`

Remarque :

Des prestations de maladie sont payables à un client qui remplit les conditions d’admissibilité pendant un maximum de 15 ou de 26 semaines. Si le DPP est situé à la s/c 2374 ou après, le total maximal de semaines de maladie payables par PP est de 26. Si le DPP est avant la s/c 2374, le total maximal de semaines de maladie payables par PP est de 15. Seuls 5 jours complets et consécutifs, du lundi au vendredi, sont considérés comme une semaine de maladie. Quand un à 4 jours de maladie sont déclarés dans un GD 2, 6 ou 7 et que le compteur de prestations de maladie a déjà atteint le maximum de 15 ou de 26 semaines payées, réduire les prestations d’un cinquième pour chaque journée déclarée.

Quand un client déclare des jours de maladie dans une déclaration du prestataire initiale et qu’il n’y a aucune semaine de guérison dans la demande, seulement 4 semaines consécutives peuvent être déclarées comme prestations de maladie occasionnelle. Quand un client déclare des jours de maladie dans une déclaration du prestataire initiale et qu’il n’y a pas de semaine de guérison dans la demande, et que la déclaration du prestataire est traitée la s/c 2385-5 ou après, seulement un total de 8 semaines de prestations de maladie occasionnelle peut être versé pour un GD 2, 6 ou 7. Pour une demande SMP, si le client continue de se déclarer malade et que le maximum de 15 ou de 26 semaines de prestations de maladie, selon le DPP, n’ont pas été payées, le Centre Service Canada (CSC) doit en être informé. Le COPA ne peut pas traiter la cinquième semaine consécutive de prestations ou la neuvième semaine cumulative payée à moins que le CSC indique que le GD est passé à 3 ou 9 et qu’il y a une semaine de guérison. Consulter Créer un AT Action à prendre (AP) dans la tâche initiale. Toutefois, pour une demande SIP, l’agent saisit la transaction M152, qui génère un indicatif d’erreur C465 pour la cinquième semaine consécutive ou un indicatif d’erreur C484 pour une neuvième semaine cumulative et informe le CSC. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0521.dita`

Remarque :

Les clients qui reçoivent des prestations de maternité, parentales, de compassion et pour proches aidants ne sont pas tenus d’être prêts et disposés à travailler, et capables de le faire chaque jour. Si un client déclare recevoir des prestations de maternité, parentales, de compassion ou pour proches aidants et que le GD figurant au dossier ne correspond pas à l’une de ces prestations, consulter Créer un AT AP dans la tâche initiale. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0522.dita`

Remarque :

Si un client déclare être en vacances pendant 6 semaines ou plus, consulter Créer un AT Action à prendre (AP) dans la tâche initiale. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0523.dita`

Remarque :

L’indicatif de répartition P - Pension-non exemptée est utilisé pour répartir un revenu de pension qui est déduit des prestations. L’indicatif de répartition Q - Pension exemptée est utilisé pour répartir un revenu de pension qui n’ est pas déduit des prestations.

Pour les déclarations du prestataire dans SMP, les pensions dont l’indicatif est Q ne sont pas consignées à l’onglet TC85 ou ETI , mais les pensions dont l’indicatif est P sont consignées à l’onglet approprié.

En ce qui concerne les déclarations du prestataire dans SIP, ne pas inclure les sommes provenant de répartitions dans le champ Répartitions de la transaction Émettre paiements (M151/M152) . 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0524.dita`

Remarque :

Toute autre rémunération est déduite à 50 % jusqu’au seuil de 90 %, puis à 100 %. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0525.dita`

Remarque:

Si le montant déclaré est supérieur au montant de prestations non payables, traiter la déclaration du prestataire comme si le client n’était pas admissible aux prestations pour cette semaine. 
