# Employeur : Saisie de données liées à un évènement majeur en entreprise (utilisateur autorisé) — Instructions

Source map: `fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry/employer_major_event_data_entry.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry/ressources_additionnelles.dita`

Sommaire : Ces instructions s’adressent aux utilisateurs autorisés pour créer, modifier ou désactiver un évènement dans Évènements majeurs en entreprise .
       [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

**Table of contents**

- Contexte
         [Contexte](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Background)

- Renseignements supplémentaires
         [Renseignements supplémentaires](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Addi)

- Rechercher un évènement approuvé dans Évènements majeurs en entreprise (EME)
         [Rechercher un évènement approuvé dans Évènements majeurs en entreprise (EME)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Searching_in_approved)

- Vérifier si un évènement existe
         [Vérifier si un évènement existe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Verifying)

- Présenter une demande de révision et de traduction
         [Présenter une demande de révision et de traduction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Submit_editing_translation)

- Créer un nouvel évènement
         [Créer un nouvel évènement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_CreatingEvent)

- Remplir l’onglet Sommaire de l’employeur
         [Remplir l’onglet Sommaire de l’employeur](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Completing_the_Employer)

- Remplir l’onglet Sommaire de l’évènement
         [Remplir l’onglet Sommaire de l’évènement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Completing_the_Event)

- Remplir les onglets disponibles vs les types d’évènements
         [Remplir les onglets disponibles vs les types d’évènements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Completing_the_additional)

- Modifier un évènement ou le statut de l’évènement
         [Modifier un évènement ou le statut de l’évènement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Modifying_an_event)

- Ajouter une pièce jointe à un évènement
         [Ajouter une pièce jointe à un évènement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_an_attachment)

- Ajouter, modifier ou supprimer un hyperlien à un événement
         [Ajouter, modifier ou supprimer un hyperlien à un événement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_a_hyperlink)

- Ajouter des renseignements sur la rémunération de jours fériés à un événement
         [Ajouter des renseignements sur la rémunération de jours fériés à un événement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_a_statutory)

- Désactiver un évènement et réactiver un évènement désactivé
         [Désactiver un évènement et réactiver un évènement désactivé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Deactivating_an_event)

**Contexte**

L’ Évènements majeurs en entreprise a 2 objectifs :
       [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Permettre à un utilisateur autorisé de créer, modifier ou désactiver un évènement.

- Permettre aux agents de traitement de consulter les renseignements sur les Évènements majeurs en entreprise (EME) approuvés.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0444.dita) 

Quand Évènements majeurs en entreprise s’ouvre et que la langue de préférence est sélectionnée, la page Bulletin d’information — Évènements majeurs en entreprise s’affiche et seulement les évènements approuvés sont affichés.
       [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Les évènements peuvent être filtrés par leur Région , Type d’évènement ou Année à l’aide des menus déroulants correspondants. Les résultats filtrés indiquent un genre d’événement précis, selon ce que l’agent choisit. Par exemple, si l’utilisateur autorisé choisit Ontario du menu déroulant Région , les résultats afficheront seulement les évènements dans la région d’Ontario. Les renseignements dans les colonnes peuvent être triés dans un ordre spécifique en choisissant le titre de la colonne correspondante.

Un évènement peut être trouvé en saisissant le nom de l’employeur dans le champ Rechercher .

Pour consulter tous les évènements, l’utilisateur autorisé choisit Menu , puis choisit Évènements majeurs en entreprise et dans le menu déroulant Vues , choisit Tous les évènements .

En consultant tous les évènements, l’utilisateur autorisé filtre les évènements par Vues , Type d’évènement ou Année en utilisant les menus déroulants correspondants. L’utilisateur autorisé peut choisir d’afficher tous les événements ou un genre d’événement spécifique à l’aide du menu déroulant Vues . Par exemple, si l’utilisateur autorisé choisit Évènements résolus du menu déroulant Vues , le résultat filtré affiche seulement les évènements résolus.

Les évènements suivants doivent toujours être saisis dans la base de données EME :

- Conflits collectifs

- Domaine scolaire

- Réduction volontaire de l’effectif

- Travail partagé

- Faillite

Les évènements suivants peuvent être saisis dans la base de données EME, à la discrétion du personnel régional d’expertise opérationnelle :

- Licenciement massif et relevé d’emploi

- Rémunération

- Heures assurables

- Motifs de cessation

- Fraude majeure

- Situation d’urgence

- Règlement de grief collectif

Les utilisateurs autorisés qui font partie de l’équipe responsable du recueil des faits auprès des commissions scolaires peuvent consulter Domaine scolaire : Saisie de données liées à un évènement majeur en entreprise (utilisateur autorisé) – Instructions .
       [Domaine scolaire : Saisie de données liées à un évènement majeur en entreprise (utilisateur autorisé) – Instructions](/fr/procedure/generic/sb-meede_ds-sdleme.shtml)

**Renseignements supplémentaires**

Envoyer un courriel à la boîte GD suivante pour toute question et saisir « Question EME » à la ligne objet du courriel : esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca .
       [esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca](mailto:esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca)

**Rechercher un évènement approuvé dans Évènements majeurs en entreprise (EME)**

Quand Évènements majeurs en entreprise s’ouvre et que la langue de préférence est sélectionnée, la page Bulletin d’information — Évènements majeurs en entreprise s’affiche et seulement les évènements approuvés sont affichées. Toutefois, les utilisateurs autorisés peuvent rechercher tous les évènements, y compris ceux qui sont approuvés, en attente, rejetés, désactivés ou annulés.
       [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Rechercher un évènement approuvé dans Bulletin d’information — EME de la façon suivante :

- Ouvrir Évènements majeurs en entreprise et choisir Français . La page Bulletin d’information — Évènements majeurs en entreprise s’ouvre et affiche seulement les évènements approuvés.
         [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Saisir le nom de l’employeur ou de l’évènement dans le champ Rechercher .

- Si l’évènement est trouvé, le choisir pour accéder à son contenu et afficher les détails.

**Vérifier si un évènement existe**

Avant de créer un nouvel évènement, l’utilisateur autorisé détermine si l’évènement existe déjà dans la base de données EME pour la même raison et la même période.

Vérifier si un évènement existe de la façon suivante :

- Ouvrir Évènements majeurs en entreprise et choisir Français .
         [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Choisir Menu , puis choisir Évènements majeurs en entreprise .

- Si un évènement existe, choisir l’évènement pour accéder à son contenu et examiner les détails. Pour modifier l’évènement, passer à Modifier un évènement ou le statut de l'évènement .
         [Modifier un évènement ou le statut de l'évènement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Modifier_un_évènement)

- Si aucun évènement n’existe, passer à Créer un évènement .
         [Créer un évènement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_CreatingEvent)

**Présenter une demande de révision et de traduction**

Tout le contenu publié dans le Bulletin d’information — EME doit être disponible dans les 2 langues officielles. Les utilisateurs autorisés présentent une demande de révision et de traduction à l’équipe des Services linguistiques : EDSC.ServicesLinguistiques_TPAE-EIBP_LinguisticServices.ESDC@hrsdc-rhdcc.gc.ca .
       [EDSC.ServicesLinguistiques_TPAE-EIBP_LinguisticServices.ESDC@hrsdc-rhdcc.gc.ca](mailto:EDSC.ServicesLinguistiques_TPAE-EIBP_LinguisticServices.ESDC@hrsdc-rhdcc.gc.ca)

En attendant le texte révisé et traduit, il est important que l’évènement soit publié dès que possible dans le Bulletin d’information — EME.

Si les renseignements n’ont pas encore été traduits et qu’ils sont disponibles seulement dans l’une des langues officielles, l’utilisateur autorisé avise les agents que des renseignements sont disponibles dans l’autre langue en choisissant l’onglet Autre information et en ajoutant une remarque dans le champ approprié.

Aviser l’agent que des renseignements sont disponibles dans l’autre langue de la façon suivante :

- Choisir l’onglet Autre information .

- Si les renseignements sont disponibles seulement en anglais, dans le champ Information additionnelle - Français , saisir « Cet évènement est en cours de traduction. Aucun renseignement n’est actuellement disponible en français, consulter les renseignements en anglais. »

- Si les renseignements sont disponibles seulement en français, dans le champ Information additionnelle - Anglais , saisir « This event is currently being translated. No information is available in English at this time, refer to the information in French. »

**Créer un nouvel évènement**

En créant un nouvel évènement, l’utilisateur autorisé remplit tous les champs obligatoires indiqués d’un astérisque (*) aux onglets Sommaire de l’employeur et Sommaire de l’évènement . L’utilisateur autorisé rempli autant de champs que possible à chaque onglet. Plus on fournit de renseignements, plus la recherche est efficace.

Créer un nouvel évènement de la façon suivante :

- Ouvrir Évènements majeurs en entreprise et choisir Français .
         [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Choisir Menu , puis choisir Nouvel évènement .

- Choisir le genre d’évènement approprié.

- Remplir les champs appropriés à chaque onglet.

- Choisir l’onglet Enregistrer et choisir Enregistrer .

Quand l’utilisateur autorisé crée un nouvel évènement, des onglets particuliers changent, selon le genre d’évènement. Toutefois, chaque évènement a les onglets Sommaire de l’employeur et Sommaire de l’évènement .

**Remplir l’onglet Sommaire de l’employeur**

Employeur (obligatoire)*

Saisir le nom de l’employeur ou de l’évènement.

Adresse 1 (obligatoire)*

Saisir l’adresse de l’employeur.

Adresse 2

Saisir les renseignements (si les renseignements sont fournis) ou laisser ce champ vide.

Ville

Courriel de l’employeur

Nom du premier contact

Province

Code postal

Saisir les renseignements fournis par l’employeur.

Numéro de téléphone

Poste

Numéro d’entreprise de ARC

Saisir les renseignements (si les renseignements sont fournis) ou laisser ce champ vide.

Division / Succursale

Saisir les renseignements (si les renseignements sont fournis) ou laisser ce champ vide.

**Remplir l’onglet Sommaire de l’évènement**

Région (obligatoire) *

Choisir la région appropriée.

Date de début (obligatoire)*

Saisir la date de début de l’évènement.

Date de fin

Saisir la date de fin de l’évènement (si les renseignements sont fournis) ou laisser ce champ vide.

Contact régional

Saisir le nom du contact régional (si les renseignements sont fournis) ou laisser ce champ vide.

Pris en charge par (obligatoire) *

Choisir la région appropriée.

Traitement - Information additionnelle

- Choisir Oui si un document, un hyperlien, des renseignements sur la rémunération de jours fériés est joint ou s’il y a des NAS affichés à l’onglet Information de NAS.

- Choisir Non si aucun de ces renseignements ne sont fourni et aucun NAS s’affiche.

Détails sur le type d’évènement

Affiché uniquement pour le type d’évènement Autre. Saisir la description de l’évènement.

Nombre total d’employés

Nombre d’employés affectés

Saisir le nombre d’employés affectés (si les renseignements sont fournis) ou laisser ce champ vide.

Endroit affecté

Saisir les renseignements (s’ils sont fournis) ou laisser ce champ vide.

Code de référence

Seulement disponible pour certains genres d’évènements. Saisir les renseignements (s’ils sont fournis).

**Remplir les onglets disponibles vs les types d’évènements**

Il y a 13 types d’évènements distincts. En plus des champs inclus aux onglets Sommaire de l’employeur et Sommaire de l’évènement , chaque type d’évènement a les onglets standards suivants :

- Procédures

- Considérations relatives au traitement

- Information de NAS (Si les renseignements de NAS sont fournis, choisir Oui dans le champ Traitement - Information additionnelle à l’onglet Sommaire de l’évènement .)

- Décision

- Autre information

- Renseignements supplémentaires (Si un gabarit, un hyperlien, des renseignements sur la rémunération de jours fériés ou d’autres documents sont fourni, choisir Oui dans le champ Traitement - Information additionnelle à l’onglet Sommaire de l’évènement .)

- Enregistrer

Certains genre d’évènements ont les onglets suivants :

```text
| Type d’évènement | Onglet |

| Faillite | Syndicat/Syndic |

| Règlement de grief collectif | Syndicat/Syndic |

| Rémunération | Rémunération RE et syndicat |

| Situation d’urgence | Renseignements sur le soutien externe |

| Heures assurables | Syndicat/Syndic |

| Conflits collectifs | Conflits collectifs Syndicat/Syndic |

| Fraude majeure | Syndicat/Syndic |

| Licenciement massif et relevé d’emploi | RE et syndicat |

| Motifs de cessation | Syndicat/Syndic |

| Domaine scolaire | RE et syndicat |

| Autre | Syndicat/Syndic |

| Réduction volontaire de l’effectif | Réduction volontaire de l’effectif |

| Travail partagé | RE et syndicat |
```

L’utilisateur autorisé remplit un onglet en le choisissant et en saisissant les renseignements dans les champs appropriés.

Remplir un onglet de la façon suivante :

- Choisir l’onglet approprié.

- Saisir tout renseignement dans les champs et les sections appropriés.

- Choisir l’onglet Enregistrer et choisir Enregistrer .

Pour joindre un document à un évènement, passer à Ajouter une pièce jointe à un événement .
       [Ajouter une pièce jointe à un événement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_an_attachment)

Pour ajouter un hyperlien à un évènement, passer à Ajouter, modifier ou supprimer un hyperlien à un événement .
       [Ajouter, modifier ou supprimer un hyperlien à un événement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_a_hyperlink)

Pour ajouter les renseignements sur la rémunération de jours fériés à un évènement, passer à Ajouter des renseignements sur la rémunération de jours fériés à un événement .
       [Ajouter des renseignements sur la rémunération de jours fériés à un événement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_a_statutory)

Pour modifier les renseignements d’un évènement existent ou pour modifier le statut de l’évènement, passer à Modifier un évènement ou le statut de l’évènement .
       [Modifier un évènement ou le statut de l’évènement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_ModifyingEvent)

Pour désactiver un évènement ou pour réactiver un évènement désactivé, passer à Désactiver un évènement et réactiver un évènement désactivé .
       [Désactiver un évènement et réactiver un évènement désactivé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/employer_major_event_data_entry#_Deactivating_an_event)

**Modifier un évènement ou le statut de l’évènement**

Une fois qu’un évènement est créé, l’utilisateur autorisé modifie le statut de l’évènement à Approuvé . Tous les évènements approuvés s’affichent à la page Bulletin d’information — EME.

Modifier un évènement de la façon suivante :

- Ouvrir Évènements majeurs en entreprise et choisir Français .
         [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Choisir Menu , puis choisir Évènements majeurs en entreprise .

- Saisir le nom de l’évènement dans le champ Rechercher .

- Choisir l’évènement pour accéder à son contenu.

- Approbateur : Choisir Modifier .

- Saisir les renseignements nécessaires aux onglets appropriés.

- Approbateur : Choisir Enregistrer .

Modifier le statut de l’évènement de la façon suivante :

- Ouvrir Évènements majeurs en entreprise et choisir Français .
         [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Choisir Menu , puis choisir Évènements majeurs en entreprise .

- Saisir le nom de l’évènement dans le champ Rechercher .

- Choisir l’évènement pour accéder à son contenu.

- Approbateur : Choisir Modifier .

- Statut : Choisir l’option appropriée.

- Approbateur : Choisir Enregistrer .

**Ajouter une pièce jointe à un événement**

Des pièces jointes peuvent seulement être ajoutés à un évènement existant sous la forme d’un document joint (Word, PDF, etc.). Si un document est de plus de 10 Mo, l’utilisateur autorisé l’ajoute sous forme d’hyperlien au lieu de le joindre.

Ajouter une pièce jointe de la façon suivante :

- Enregistrer chaque document à joindre sur votre ordinateur.

- Ouvrir Évènements majeurs en entreprise et choisir Français .
         [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Choisir Menu , puis choisir Évènements majeurs en entreprise .

- Saisir le nom de l’évènement dans le champ Rechercher .

- Choisir l’évènement pour accéder à son contenu.

- Approbateur : Choisir Modifier .

- Choisir l’onglet Renseignements supplémentaires.

- Dans la section Notes , choisir + .

- Quand la fenêtre Nouvelle note s’ouvre :

- Attacher des fichiers : Saisir le nom du document en utilisant la langue du document.

- Si les renseignements ne sont pas disponibles en anglais, saisir : « No information is available in English, refer to the information in French. »

- Si les renseignements ne sont pas disponibles en français, saisir : « Les renseignements ne sont pas disponibles en français, consulter les renseignements en anglais. »

- Aucun fichier n’est joint : Choisir Aucun fichier n’est joint .

- Quand l’explorateur de votre ordinateur s’ouvre, choisir le document dans l'emplacement qu'il a été enregistré, puis choisir Ouvrir .

- Quand le document s’affiche dans le champ Aucun fichier n’est joint , choisir Enregistrer .

- Si le document est disponible en anglais, répéter les étapes précédentes.

- S’il y a d’autres documents à joindre, répéter les étapes précédentes jusqu’à ce que tout document nécessaire soit joint.

- Choisir l’onglet Sommaire de l’évènement .

- Traitement - Information additionnelle : Choisir Oui .

- Approbateur : Choisir Enregistrer .

- Supprimer tous les documents joints de votre ordinateur.

**Ajouter, modifier ou supprimer un hyperlien à un événement**

L’utilisateur autorisé ajoute, modifie ou supprime un hyperlien, au besoin. Si l’employeur fournit un hyperlien vers un document (p. ex. une convention collective) ou quand une pièce jointe est plus grande que 10 Mo, l’utilisateur autorisé copie et colle le lien dans la section Hyperliens de l’onglet Renseignements supplémentaires . Un hyperlien peut seulement être ajouté à un évènement existant.

Ajouter un hyperlien de la façon suivante :

- Copier l’hyperlien de son emplacement.

- Ouvrir Évènements majeurs en entreprise et choisir Français .
         [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Choisir Menu , puis choisir Évènements majeurs en entreprise .

- Saisir le nom de l’évènement dans le champ Rechercher .

- Choisir l’évènement pour accéder à son contenu.

- Approbateur : Choisir Modifier .

- Choisir l’onglet Renseignements supplémentaires .

- Dans la section Hyperlien , choisir + .

- Quand la fenêtre Nouvelle Hyperlien s’ouvre, coller l’hyperlien en français dans le champ URL - Français .

- Description de l’hyperlien - Français : Saisir le nom du document accédé par l’hyperlien.

- Si l’hyperlien n’est pas disponible en français, saisir : « Les renseignements ne sont pas disponibles en français, consulter les renseignements en anglais. »

- Si l’hyperlien est disponible en anglais, répéter les étapes précédentes pour copier et coller l’hyperlien en anglais dans le champ URL - Anglais de la fenêtre Nouvelle Hyperlien . Saisir le nom anglais de l’hyperlien dans le champ Description de l’hyperlien - Anglais .

- Si les renseignements ne sont pas disponibles en anglais, saisir : « No information is available in English, refer to the information in French. » dans le champ Description de l’hyperlien - Anglais .

- Choisir Enregistrer .

- S’il y a d’autres hyperliens à ajouter, répéter les étapes précédentes jusqu’à ce que tout hyperlien nécessaire soit joint.

- Choisir l’onglet Sommaire de l’évènement .

- Traitement - Information additionnelle : Choisir Oui .

- Approbateur : Choisir Enregistrer .

Au besoin, pour modifier un hyperlien, choisir l’icône Modifier la note de l’hyperlien approprié.

Au besoin, pour supprimer un hyperlien, choisir l’icône Supprimer cette remarque de l’hyperlien approprié.

**Ajouter des renseignements sur la rémunération de jours fériés à un événement**

Les renseignements sur la rémunération de jours fériés peuvent seulement être ajoutés à un évènement existant. Quand l’utilisateur autorisé saisit un montant de rémunération de jours fériés, ce montant est arrondi au dollar le plus près.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0445.dita) 

Saisir les renseignements sur la rémunération de jours fériés de la façon suivante :

- Ouvrir Évènements majeurs en entreprise et choisir Français .
         [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Choisir Menu , puis choisir Évènements majeurs en entreprise .

- Saisir le nom de l’évènement dans le champ Rechercher .

- Choisir l’évènement pour accéder à son contenu.

- Approbateur : Choisir Modifier .

- Choisir l’onglet Renseignements supplémentaires .

- Dans la section Jour férié , choisir + .

- Quand la fenêtre Nouvelle Jour férié s’ouvre, saisir la date du jour férié et le montant de la paie de jour férié dans les champs appropriés.

- Choisir Enregistrer .

- Répéter ces étapes pour chaque montant de paie de jour férié.

- Choisir l’onglet Sommaire de l’évènement .

- Traitement - Information additionnelle : Choisir Oui .

- Approbateur : Choisir Enregistrer .

**Désactiver un évènement et réactiver un évènement désactivé**

Un évènement peut être désactivé, mais peut toujours être consulté par l’utilisateur autorisé dans la base de données EME. Un évènement désactivé n’apparaît pas dans la page Bulletin d’information — Évènements majeurs en entreprise . L’utilisateur autorisé peut réactiver un évènement désactivé.

Désactiver un évènement de la façon suivante :

- Ouvrir Évènements majeurs en entreprise et choisir Français .
         [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Choisir Menu , puis choisir Évènements majeurs en entreprise .

- Choisir Désactiver .

- Cocher la case de l’évènement approprié.

- Plus d’un évènement peut être choisi à la fois.

- Choisir Désactiver .

- Quand la fenêtre Désactiver s’ouvre, choisir le motif d’état approprié et choisir Confirmer .

Réactiver un évènement désactivé de la façon suivante :

- Ouvrir Évènements majeurs en entreprise et choisir Français .
         [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Choisir Menu , puis choisir Évènements majeurs en entreprise .

- Vues : Choisir Évènements résolus .

- Choisir Activer .

- Cocher la case de l’évènement approprié.

- Plus d’un évènement peut être choisi à la fois.

- Choisir Activer .

- Quand la fenêtre Activer s’ouvre, choisir le motif d’état approprié et choisir Confirmer . 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0444.dita`

Remarque :

Un utilisateur autorisé est habituellement désigné par le personnel en expertise opérationnelle régional. Pour plus de renseignements sur qui est un utilisateur autorisé, l’agent envoie un courriel à la personne-ressource de la région appropriée à l’adresse courriel indiquée à la section Renseignements supplémentaires . 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0445.dita`

Remarque :

Lors de la saisie du montant, une virgule doit être utilisée. 
