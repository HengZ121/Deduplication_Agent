# Nouveau calcul : Évaluation — Instructions

Source map: `fr_FR/procedure/generic/additionalresources/recalculation_assessment/recalculation_assessment.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/recalculation_assessment/ressources_additionnelles.dita`

Sommaire : Cette ressource additionnelle a été conçue pour guider les agents dans le processus de nouveau calcul en aidant à déterminer le motif du nouveau calcul, les résultats attendus, si le nouveau calcul est nécessaire, et les transactions nécessaires pour traiter le nouveau calcul.

Table of Contents

- Ce qu’il faut savoir

- Qu’est-ce qu’un nouveau calcul?
             [Qu’est-ce qu’un nouveau calcul?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#Whatisrecalc)

- Évaluer le nouveau calcul
             [Évaluer le nouveau calcul](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#assess_recalc)

- Calcul préliminaire
             [Calcul préliminaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#preliminary_calc)

- Aucune modification au résultat du calcul précédent
             [Aucune modification au résultat du calcul précédent](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#no_change_pcr)

- Modification au résultat du calcul initial
             [Modification au résultat du calcul initial](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#change_init_calc)

- Questions litigieuses dans la période de référence (PR)
             [Questions litigieuses dans la période de référence (PR)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#contentious_qp)

- Questions litigieuses dans la période de prestations (PP)

- Questions litigieuses en dehors de la période de prestations (PP) dans une demande active, terminée ou bloquée
                 [Questions litigieuses en dehors de la période de prestations (PP) dans une demande active, terminée ou bloquée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#contentious_ouside_bp)

- Motif de cessation d’emploi (MCE) litigieux chevauche le DPP et le calcul précédent comportait un RE exclu
                 [Motif de cessation d’emploi (MCE) litigieux chevauche le DPP et le calcul précédent comportait un RE exclu](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#contentious_rfs)

- Demande antérieurement finalisée comme PPNE N1, N2, N5 ou avec une inadmissibilité 15 - Procédure de présentation des demandes (D15) dans une demande établie en raison d’un RE manquant
                 [Demande antérieurement finalisée comme PPNE N1, N2, N5 ou avec une inadmissibilité 15 - Procédure de présentation des demandes (D15) dans une demande établie en raison d’un RE manquant](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#claim_n1_n2_n5)

- Guide de saisie des données de nouveau calcul - version SSA
                 [Guide de saisie des données de nouveau calcul - version SSA](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#recalc_ssa)

             [Questions litigieuses dans la période de prestations (PP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#contentious_bp)

         [Ce qu’il faut savoir](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#wyntk)

- Étape par étape

- Demande PPNE N1 ou N5
             [Demande PPNE N1 ou N5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#bpne_n1_n5)

- Demande initiale établie
             [Demande initiale établie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#ic_estab)

- Nouveau calcul — Aucune modification à la demande
             [Nouveau calcul — Aucune modification à la demande](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#recalc_no_change)

         [Étape par étape](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#sbs)

**Ce qu’il faut savoir**

L’objectif de cette ressource additionnelle est d’aider les agents à déterminer si un nouveau calcul est nécessaire et, si oui, comment examiner une demande pour déterminer les mesures à prendre en fonction des renseignements disponibles.

Les agents utilisent cette ressource additionnelle avec les procédures appropriées. Pour plus de renseignements, l’agent consulte les procédures appropriées.

**Qu’est-ce qu’un nouveau calcul?**

Un nouveau calcul est nécessaire quand de nouveaux renseignements sont reçus dans une demande et qu’ils peuvent avoir une incidence sur le résultat du calcul précédent. L’agent évalue les nouveaux renseignements et, au besoin, effectue un nouveau calcul de la demande à l’aide des procédures de calcul normales pour déterminer si le résultat du calcul est différent. L’agent compare ensuite le résultat du nouveau calcul et celui du calcul précédent pour déterminer les étapes suivantes pour la demande.

**Évaluer le nouveau calcul**

Voici quelques raisons pour lesquelles il est nécessaire de créer un AT Révision de la demande (RVD) Nouveau calcul :

- un RE nouveau

- un RE modifié

- de renseignements nouveaux fournis par le client qui ont une incidence sur le calcul (p. ex. prolongations de la période de référence [PR])

- des renseignements sur les meilleures semaines variables (MSV)

- une antidate

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0573.dita) 

L’agent qui traite le nouveau calcul prend en compte les questions suivantes lors de l’examen du dossier :

- Le client veut-il toujours recevoir des prestations?

- Pourquoi l’AT RVD Nouveau calcul a-t-il été créé?

- Quel était le résultat du calcul précédent?

- Y a-t-il de nouveaux renseignements qui ont une incidence sur le résultat du calcul précédent?

- Quels sont les résultats possibles ou attendus?

- Y a-t-il de nouvelles questions litigieuses pour lesquelles une décision est nécessaire?

- Y a-t-il des différences par rapport au calcul précédent?

- Quelles saisies sont nécessaires pour les modifications requises?

- Est-il nécessaire de communiquer avec le client?

**Calcul préliminaire**

Pour déterminer le motif de création du nouveau calcul et le résultat possible attendu, l’agent peut effectuer un calcul préliminaire dans la version Web de SSA afin de déterminer si des renseignements sont différents.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0574.dita) 

L’agent compare le résultat du calcul précédent à celui du nouveau calcul pour déterminer les renseignements différents. Les différences potentielles incluent les suivantes :

- une modification à la semaine du DPP;

- une modification au genre de prestations (GP), au taux de prestations ou aux semaines d’admissibilité;

- une exclusion nouvelle ou modifiée;

- une inadmissibilité nouvelle ou modifiée;

- une répartition ou une prolongation de la période de prestations (PP) nouvelle ou modifiée.

L’agent utilise un tableau comme celui ci-dessous pour mieux comprendre les renseignements différents après le nouveau calcul.

```text
| Renseignements sur la demande | Résultat du calcul précédent | Résultat du nouveau calcul |

| Semaine du DPP | - | - |

| GP | - | - |

| Taux de prestations | - | - |

| Semaines d’admissibilité | - | - |

| Exclusion | - | - |

| Inadmissibilité | - | - |

| Répartition | - | - |

| Prolongation de la PP | - | - |

| Heures assurables | - | - |

| Rémunération assurable | - | - |
```

**Aucune modification au résultat du calcul précédent**

Après avoir examiné le dossier et effectué un calcul préliminaire dans la version Web de SSA, si le résultat est aucune modification de la demande, l’agent saisit la transaction M103 - Décision initiale (M103) ou M106 - Décision subséquente (M106) pour le nouveau calcul avec APC dans le champ DPP action sur la demande et complète l’AT RVD Nouveau calcul.

**Modification au résultat du calcul initial**

Si le résultat est une modification de la demande, l’agent vérifie s’il y a des questions litigieuses sur lesquelles une décision n’a pas été rendue dans la PR ou la PP, et les traite, au besoin.

S’il n’y a pas de modification du DPP, du nombre de semaines d’admissibilité ou du taux de prestations, mais qu’il y a d’autres modifications qui ne sont pas précisément liées au calcul de la demande (p. ex. une modification de la répartition ou du motif de cessation d’emploi [MCE]), l’agent saisit les transactions dans ETI. La version Web de SSA ne génère pas toujours les bonnes transactions lors d’un nouveau calcul. Par conséquent, si les transactions ne concernent pas le calcul de la demande, il est important que l’agent utilise d’autres ressources telles que le Nouveau calcul SSA Guide de saisie , les procédures et ETI pour s’assurer que les transactions sont correctement examinées et complétées.
       [Nouveau calcul SSA Guide de saisie](https://esdc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml)

**Questions litigieuses dans la période de référence (PR)**

S’il y a des questions litigieuses sur lesquelles une décision n’a pas été rendue dans la PR, l’agent n’a peut-être pas besoin de les traiter. Si la décision n’a pas d’incidence sur le résultat du calcul (c.-à-d. que le client n’est toujours pas admissible), aucune décision n’est requise. L’agent ne crée pas un AT RVD pour les questions litigieuses sur lesquelles une décision n’a pas été rendue et remplit l’AT RVD Nouveau calcul.

Si la question litigieuse a une incidence sur le résultat du calcul (c.-à-d. a une incidence sur l’admissibilité), une décision est requise. L’agent crée un AT RVD pour chaque question litigieuse dans la PR et détermine si la décision peut être reportée en consultant Reporter la décision : Client ne demande pas des prestations . L’agent détermine ensuite si la décision peut être rendue au Niveau 1. Si la décision ne peut pas être reportée ou complétée au Niveau 1, l’agent assigne l’AT RVD à la hiérarchie appropriée de la charge de travail du Niveau 2 dans SNCT et déplace l’AT RVD Nouveau calcul vers En suspens jusqu’à ce que la décision soit rendue.
       [Reporter la décision : Client ne demande pas des prestations](/fr/procedure/task/deferring_adj_current_claim.shtml)

**Questions litigieuses dans la période de prestations (PP)**

S’il y a des questions litigieuses sur lesquelles une décision n’a pas été rendue dans la PP d’un nouveau calcul et que le client n’est pas admissible à aucune prestation dans la demande après le nouveau calcul (p. ex. en raison d’une exclusion antérieure à partir du DPP, d’une inadmissibilité antérieure au dossier, la demande étant PPNE, etc.), il n’est pas nécessaire de rendre une décision. L’agent ne crée pas un AT RVD pour les questions litigieuses sur lesquelles une décision n’a pas été rendue dans la PP et complète l’AT RVD Nouveau calcul sans rendre une décision.

Si le client pouvait être admissible à des prestations après le nouveau calcul, l’agent crée un AT RVD pour chaque question litigieuse et détermine si la décision peut être rendue au Niveau 1. Si la décision ne peut pas être rendue au Niveau 1, l’agent détermine si la question litigieuse a une incidence sur le nouveau calcul :

- Si non, l’agent assigne l’AT RVD à la hiérarchie de la charge de travail de Niveau 2 appropriée dans SNCT, impose un arrêt de paiement et complète l’AT RVD Nouveau calcul.

- Si oui, l’agent déplace l’AT RVD Nouveau calcul vers En suspens jusqu’à ce qu’un agent de Niveau 2 ait rendu une décision.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0575.dita) 

Pour les demandes PPNE qui deviennent qui deviennent établies après un nouveau calcul et qui comportent un MCE litigieux dans la PP, l’agent consulte Calculer à nouveau et établir des demandes PPNE : Litige en attente de traitement dans la période de prestations — Instructions pour déterminer si une décision est requise.
       [Calculer à nouveau et établir des demandes PPNE : Litige en attente de traitement dans la période de prestations — Instructions](/fr/procedure/generic/additionalresources/recalc-esta-bpne-claim.shtml)

**Questions litigieuses en dehors de la période de prestations (PP) dans une demande active, terminée ou bloquée**

Si des questions litigieuses en suspens ou pour lesquelles une décision n’a pas encore été rendue se sont produites en dehors de la PP d’une demande active, terminée ou bloquée pour laquelle l’agent est en train d’effectuer un nouveau calcul, ces questions litigieuses n’ ont pas d’incidence sur le résultat du nouveau calcul. Dans ces situations, l’agent :

- ne crée aucun AT pour la question;

- n’attend pas une décision sur la question;

- effectue le nouveau calcul de la demande.

**Motif de cessation d’emploi (MCE) litigieux chevauche le DPP et le calcul précédent comportait un RE exclu**

S’il y a un RE avec un MCE litigieux pour lequel le premier jour travaillé est dans la PR et le dernier jour de travail (DJT) est dans la PP, le Calcul d’assurance-chômage (CAC) tient compte de la partie du RE qui est dans la PR pour le calcul des heures assurables et la rémunération. Si la décision du RE litigieux dans la PP est reportée ou n’est pas autorisée, CAC impose une exclusion à partir du DPP. Dans cette situation, l’agent détermine s’il y a un RE précédemment exclu. Si oui, CAC tient compte de toutes les heures et la rémunération dans la PR, y compris celles du RE exclu, ce qui cause une erreur de calcul. Pour éviter ceci, l’agent modifie le champ Condition spéciale dans MSRE du RE avec le MCE litigieux dans la PP. Selon le MCE, l’agent choisit Départ volontaire - motif valable ou Mauvaise conduite non prouvée pour éviter que CAC inclut les heures et la rémunération du RE exclu.

Une fois le nouveau calcul terminé, l’agent impose une exclusion manuelle pour le MCE litigieux dans la PP et rétablie le champ Condition spéciale à l’option appropriée, en fonction de la décision.

**Demande antérieurement finalisée comme PPNE N1, N2, N5 ou avec une inadmissibilité 15 - Procédure de présentation des demandes (D15) dans une demande établie en raison d’un RE manquant**

Quand le dernier RE est présenté dans les 90 jours suivant la date à laquelle la demande a été finalisée comme PPNE indicatif 2 - Dernier relevé d’emploi manquant (N2), aucune décision sur le retard à présenter le RE n’est nécessaire. Pour calculer si le RE a été présenté dans les 90 jours, l’agent de Niveau 1 détermine d’abord si la demande a été finalisée par TAD ou par un agent :

- Si TAD a finalisée la demande, l’agent utilise la date dans ETI de la transaction Décision initiale (H103) + 90 jours civils.

- Si un agent a finalisé la demande manuellement, l’agent utilise la date dans ETI de la transaction M103 + 90 jours civils.

Quand le RE est présenté plus de 90 jours après la date à laquelle la demande a été finalisée comme PPNE N2, l’agent consulte la Politique nationale sur les niveaux de décision – Annexe 1 pour déterminer si une décision peut être rendue au Niveau 1 pour le motif du retard. Si la décision ne relève pas du Niveau 1, l’agent crée un AT RVD pour le Niveau 2, l’assigne à la hiérarchie appropriée de la charge de travail du Niveau 2 dans SNCT et déplace l’AT RVD Nouveau calcul vers En suspens jusqu’à ce que la décision soit rendue.
       [Politique nationale sur les niveaux de décision – Annexe 1](/fr/policy/nationalpolicy/levels_decision-annex1.shtml)

Quand la demande a antérieurement été finalisée comme PPNE N1 ou N5, l’agent ne tient pas compte du fait que le RE manquant a été présenté dans les 90 jours. Les demandes antérieurement finalisées comme PPNE N1 ou N5 n’ont pas été établies en raison d’un nombre insuffisant d’heures. Service Canada pourrait être appelé à réviser cette décision quand un RE supplémentaire est présenté. Cette révision se ferait en vertu de la LAE 52 et de ses délais applicables.

**Guide de saisie des données de nouveau calcul - version SSA**

Le Nouveau calcul : SSA — Guide de saisie est un guide de référence important pour le traitement des nouveaux calculs. Il fournit à l’agent les saisies requises selon le genre de nouveau calcul à effectuer afin d’éviter les rejets du système. Il propose également des solutions de contournement pour les divers codes d’erreur qui peuvent apparaître après avoir effectué un nouveau calcul. L’agent doit consulter le guide chaque fois qu’un nouveau calcul est nécessaire.
       [Nouveau calcul : SSA — Guide de saisie](https://intranet.esdc-edsc.canada.ca/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml)

**Étape par étape**

- Dans SNCT, examiner l’AT RVD Nouveau calcul afin de déterminer le motif de création du nouveau calcul.

- Comparer les nouveaux renseignements reçus à ceux utilisés dans le calcul précédent afin de déterminer quelles modifications peuvent être attendues lors du nouveau calcul.

- Dans ETI, examiner la demande pour déterminer le résultat du calcul précédent :

- Si la demande a été établie avec une inadmissibilité D15 pour un RE manquant ou a été antérieurement finalisée comme PPNE N2, passer à l’étape 4.

- Si la demande est PPNE N1 ou N5 et un nouveau RE a été reçu, passer à l’étape 7.

- Si la demande est établie, passer à Demande initiale établie .
             [Demande initiale établie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#ic_estab)

- Dans MSRE, déterminer si le RE qui a entrainé la décision sur la question du DREM ou l’inadmissibilité D15 est au dossier :

- Si oui, passer à l’étape 5.

- Si non, passer à Nouveau calcul — Aucune modification de la demande .
             [Nouveau calcul — Aucune modification de la demande](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#recalc_no_change)

- Déterminer si le RE a été reçu dans les 90 jours suivant la transaction M103 - Décision initiale (M103) initiale :

- Si non, passer à l’étape 6.

- Si oui, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Consulter la procédure appropriée selon le résultat du calcul précédent :

- Si la demande a été finalisée antérieurement avec une inadmissibilité D15 en raison d’un RE manquant, passer à l’étape 2 d’ Examiner une demande qui a été finalisée antérieurement avec une inadmissibilité D15 à cause d’un RE manquant .
             [Examiner une demande qui a été finalisée antérieurement avec une inadmissibilité D15 à cause d’un RE manquant](/en/procedure/task/claim_procedure_term_after_roe.shtml)

- Si la demande a été finalisée PPNE N2, passer à l’étape 3 d’ Examiner une demande qui a été finalisée antérieurement sans le dernier RE .
             [Examiner une demande qui a été finalisée antérieurement sans le dernier RE](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/task/reviewing_claim_twpfwtlroem.shtml)

- Déterminer les prochaines étapes selon le résultat du calcul précédent :

- Si la demande est PPNE N1 ou N5, passer à Demande est PPNE N 1 ou N5 .
             [Demande est PPNE N 1 ou N5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#bpne_n1_n5)

- Si la demande est établie, passer à Demande initiale établie .
             [Demande initiale établie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#ic_estab)

**Demande PPNE N1 ou N5**

- Après avoir examiné les nouveaux renseignements au dossier, effectuer un calcul préliminaire dans la version Web de SSA et déterminer si le résultat du calcul est différent (p. ex. la demande est modifiée de PPNE N1 à PPNE N5, le client maintenant remplit les conditions requises pour recevoir des prestations, les heures sont modifiées, etc.) :

- Si oui, passer à l’étape 2.

- Si non, passer à Nouveau calcul — Aucune modification à la demande .
             [Nouveau calcul — Aucune modification à la demande](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#recalc_no_change)

- Déterminer si le client remplit maintenant les conditions requises :

- Si oui, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Si non, effectuer seulement le nouveau calcul de la demande. Ne pas créer d’AT RVD pour les questions litigieuses qui ont été déterminées. Consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

**Demande initiale établie**

- Après avoir examiné les nouveaux renseignements au dossier, effectuer un calcul préliminaire dans la version Web de SSA et déterminer si le résultat du calcul est différent :

- Si oui, passer à l’étape 2.

- Si non, passer à Nouveau calcul — Aucune modification à la demande .
             [Nouveau calcul — Aucune modification à la demande](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#recalc_no_change)

- Déterminer les prochaines étapes en examinant chaque différence dans le résultat du calcul :

- S’il y a une modification au taux de prestations ou aux semaines d’admissibilité et qu’il n’ y a pas de question litigieuse ou en attente de traitement dans la PR, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- S’il y a une modification au taux de prestations ou aux semaines d’admissibilité et qu’il y a un MCE litigieux dans la PR, passer à l’étape 3.

- S’il y a une modification au taux de prestations à cause des renseignements liés aux MSV, passer à l’étape 5.

- S’il y a une répartition nouvelle ou modifiée ou une prolongation de la PP, passer à l’étape 6.

- S’il y a une modification du DPP, passer à l’étape 8.

- S’il y a un RE avec un MCE litigieux qui est survenu après le DPP et le résultat du nouveau calcul est qu’il faut imposer une exclusion dans la PP, passer à l’étape 10.

- S’il y a une modification à une inadmissibilité précédente, ou une inadmissibilité qui doit être examinée, passer à l’étape 14.

- Si le résultat du calcul fait l’objet de plusieurs modifications, une fois que les étapes d’une modification sont terminées, retourner à la modification suivante énumérée dans cette étape jusqu’à ce que toutes les questions en suspens aient été traitées. Après avoir examiné toutes les questions en suspens, déterminer si un nouveau calcul est toujours nécessaire :

- Si oui, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
                 [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Si non, passer à Nouveau calcul — Aucune modification à la demande .
                 [Nouveau calcul — Aucune modification à la demande](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/additionalresources/recalculation_assessment#recalc_no_change)

- Examiner les renseignements au dossier pour déterminer si une décision sur le MCE litigieux dans la PR a déjà été rendue :

- Si oui, dans MSRE, modifier la condition spéciale dans le RE et, s’il n’y a pas d’autres questions en suspens, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Si non, déterminer s’il y a déjà un AT RVD pour le MCE litigieux :

- Si oui, réassigner l’AT RVD à vous-même.

- Si non, créer un AT RVD pour la décision et l’assigner à vous-même.

- Déterminer si la décision relève de votre niveau en consultant les tâches de report et de décision appropriées :

- Si oui, rendre la décision, et s’il n’y a pas d’autres questions en suspens, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Si non, dans SNCT, réassigner l’AT à la hiérarchie appropriée de la charge de travail du Niveau 2 et déplacer l’AT RVD Nouveau calcul vers En suspens. Quand la décision est rendue, et s’il n’y a pas d’autres questions en suspens, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Déterminer si le taux de prestations sera plus élevé :

- Si oui, et s’il n’y a pas d’autres questions en suspens, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Si non, consulter Examiner le résultat du calcul — Nouveau calcul d’une demande établie pour traiter le nouveau calcul.
             [Examiner le résultat du calcul — Nouveau calcul d’une demande établie](/fr/procedure/task/review_calc_result_recalc_estab_claim.shtml)

- Déterminer si la modification de la répartition ou de la prolongation du PP est bonne. Une vérification peut être nécessaire. Consulter les tâches appropriées sous l’activité Rémunération , au besoin :

- Si oui, passer à l’étape 7.

- Si non, corriger les renseignements et retourner à l’étape 1.

         [Rémunération](/fr/procedure/activity/earnings.shtml)

- Déterminer si la modification de la répartition ou de la prolongation du PP a une incidence sur le DPP, les heures ou la rémunération dans le nouveau calcul :

- Si oui, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul. Consulter la tâche appropriée pour modifier la répartition ou prolongation du PP, au besoin.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Si non, ne pas traiter le nouveau calcul. Les saisies sont effectuées manuellement dans ETI. Consulter les tâches appropriées sous l’activité Rémunération , pour traiter le nouveau calcul.
             [Rémunération](/fr/procedure/activity/earnings.shtml)

- Déterminer le motif pour lequel le DPP est modifié avec le résultat du nouveau calcul en examinant les RE, les indemnités de cessation d’emploi, l’arrêt de rémunération (A de R), la rémunération dernière semaine de travail (RDST) et toutes les décisions au dossier :

- Si le nouveau DPP est mauvais, passer à l’étape 9.

- Si le nouveau DPP est antidaté, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul. Quand le résultat du calcul est transmis, s’assurer que les déclarations du prestataire pour la période couverte par l’antidate sont saisies le même jour.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Si le nouveau DPP est correctement postdaté, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul. Consulter Examiner le résultat du calcul — DPP pour déterminer s’il faut communiquer avec le client.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml) 
             [Examiner le résultat du calcul — DPP](/fr/procedure/task/calc_reviewing/review_calc_bpc.shtml)

- Déterminer si le DPP doit être modifié :

- Si non, le DPP de la demande initiale doit être saisi manuellement dans la version Web de SSA. Retourner à l’étape 1.

- Si oui, le bon DPP doit être saisi manuellement dans la version Web de SSA. Consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Déterminer si le MCE litigieux est survenu avant la dernière semaine renouvelable (DSR) de la demande faisant l’objet d’un nouveau calcul :

- Si non, ignorer le MCE litigieux et retourner à l’étape 1.

- Si oui, passer à l’étape 11.

- Consulter Reporter la décision : Client ne demande pas des prestations pour déterminer s’il est possible de reporter la décision :

- Si oui, reporter la décision et consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Si non, déterminer s’il y a déjà un AT RVD pour le MCE litigieux :

- Si oui, réassigner l’AT RVD à vous-même.

- Si non, créer un AT RVD pour la décision et l’assigner à vous-même.

         [Reporter la décision : Client ne demande pas des prestations](/fr/procedure/task/deferring_adj_current_claim.shtml)

- Déterminer si la décision relève de votre niveau :

- Si non, imposer un traitement manuel 75 - Vérification du motif de cessation d’emploi (TM75), réassigner l’AT RVD à la hiérarchie appropriée de la charge de travail du Niveau 2 et passer à l’étape 13.

- Si oui, rendre la décision et consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Déterminer si la décision de Niveau 2 pourrait avoir une incidence sur le nouveau calcul :

- Si oui, déplacer l’AT RVD vers En suspens. Quand la décision est rendue, et s’il n’y a pas d’autres questions en suspens, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Si non et s’il n’y a pas d’autres questions en suspens, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0576.dita)

- Déterminer le genre d’inadmissibilité qui s’applique :

- S’il s’agit d’une inadmissibilité 2 - 2ième catégorie, arrêt de rémunération maladie (D2) ou une inadmissibilité 46 - Ne rencontre pas la norme variable - prestations spéciales payable (D46), si le client en est maintenant exempté et s’il n’y a pas d’autres questions en suspens, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Pour toutes les autres inadmissibilités, passer à l’étape 15.

- Déterminer si les nouveaux renseignements au dossier sont liés à l’inadmissibilité et si l’inadmissibilité pourrait être potentiellement modifiée ou annulée :

- Si oui, créer un AT RVD et passer à l’étape 16.

- Si non, noter qu’il n’est pas nécessaire de modifier l’inadmissibilité et retourner à l’étape 1.

- Déterminer si la modification ou l’annulation de l’inadmissibilité relève de votre niveau en consultant la Politique sur les niveaux de décision et d’autres tâches appropriées :

- Si oui, noter que lors de la saisie des transactions du nouveau calcul, il est nécessaire de modifier l’inadmissibilité. S’il n’y a pas d’autres questions en suspens, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

- Si non, réassigner l’AT à la hiérarchie appropriée de la charge de travail du Niveau 2 dans SNCT et déplacer l’AT RVD vers En suspens. Quand la décision est rendue, et s’il n’y a pas d’autres questions en suspens, consulter l’activité appropriée dans Calcul d’une demande - Index pour traiter le nouveau calcul.
             [Calcul d’une demande - Index](/fr/procedure/generic/additionalresources/index_calc_claim.shtml)

         [Politique sur les niveaux de décision](/fr/policy/nationalpolicy/levels_decision.shtml)

**Nouveau calcul — Aucune modification à la demande**

- Dans SNCT, créer un rapport de décision (RD) de la façon suivante :

- Commentaires : Saisir « Aucune modification à la demande. »

- Détails : Saisir « Le résultat du calcul précédent n’a pas été modifié. Aucune modification n’est requise pour la demande. »

- Choisir Sauvegarder .

- Dans ETI, choisir la transaction Renouvellement/Révisé (M106) et compléter le numéro d’enregistrement de la façon suivante :

- Demande accordée : Choisir APC - Aucun changement .

- Litigieux : Choisir 1 - Non .

- Complété : Choisir C - Oui .

- Choisir Mise à jour .

- Dans SNCT, compléter l’AT RVD Nouveau calcul. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0573.dita`

Remarque :

Pour qu’un nouveau calcul relève du Niveau 1, le DPP doit être dans le délai de révision de 36 mois. Cependant, un nouveau calcul causé par une antidate autorisée n’est pas sujet aux délais en vertu de la LAE 52 .
       [LAE 52](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-8.html)

Un nouveau calcul qui entraîne une décision sur une antidate est considéré comme une question de procédure plutôt qu’une décision sur l’admissibilité. En effet, la décision est liée à la présentation de la demande et peut donc faire l’objet d’un nouveau calcul en vertu de la LAE 111 .
       [LAE 111](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-15.html#h-212094)

Pour plus de renseignements sur les délais de révision de Niveau 1, l’agent consulte Révision, modification d’une décision et correction d’erreur .
       [Révision, modification d’une décision et correction d’erreur](/fr/procedure/activity/informal_reconsideration.shtml)

     [LAE 52](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-8.html) 
     [LAE 111](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-15.html#h-212094) 
     [Révision, modification d’une décision et correction d’erreur](/fr/procedure/activity/informal_reconsideration.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0574.dita`

Remarque :

Il est important que l’agent examine, corrige et vérifie tous les RE avant d’effectuer le calcul préliminaire dans la version Web de SSA. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0575.dita`

Remarque :

Avant de créer un AT RVD pour le Niveau 2, l’agent détermine si une enquête d’Intégrité est en cours pour la question litigieuse. L’agent peut déterminer ceci avec l’un des indicateurs suivants :

- Un traitement manuel 71 - Cas soumis aux Services de l’intégrité (TM71) est imposé.

- Une inadmissibilité 71 - Cas soumis aux Services de l’intégrité (D71) est imposée.

- Le champ Indicateur d’enregistrement pour un numéro d’enregistrement en suspens a un indicateur d’enregistrement 1 - Services d’intégrité .

- Une lettre N-04-00-00-00 a été envoyée pour demander qu’un certificat médical soit présenté.

- Une lettre commençant par C-00, C-72, C-73 ou C-88 a été envoyée par Intégrité.

- Pour les demandes potentiellement frauduleuses, un RSDP créé par Intégrité pourrait être au dossier indiquant que la demande est en cours d’enquête.

Si une question litigieuse fait l’objet d’une enquête, un agent de Niveau 2 n’est pas tenu de créer un AT RVD, car Intégrité créera un AT RVD Intégrité quand l’enquête sera terminée. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0576.dita`

Remarque :

S’il y a un RE avec un MCE litigieux pour lequel le premier jour travaillé est dans la PR et le DJT est dans la PP et qu’une décision est reportée ou n’est pas autorisée et qu’une exclusion doit être imposée à partir du DPP, déterminer s’il y a un RE dans la PR qui a été exclu du calcul initial. Si oui, pour obtenir le bon résultat du calcul dans la version Web de SSA, mettre à jour le champ Condition spéciale dans MSRE du RE avec le MCE litigieux dans la PP à Départ volontaire - motif valable ou Mauvaise conduite non prouvée , selon le MCE. Cela empêche la version Web de SSA d’inclure les heures et la rémunération du RE exclu. Après avoir saisi le calcul, imposer une exclusion manuelle pour le RE litigieux et modifier le champ Condition spéciale dans MSRE à l’option appropriée, en fonction de la décision. 
