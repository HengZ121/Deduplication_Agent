# RE émis par le gouvernement du Canada — Instructions

Source map: `fr_FR/procedure/generic/additionalresources/roe-issued-gc-ins/roe-issued-gc-ins.ditamap`

## Ressources Additionnelles

Source topic: `fr_FR/procedure/generic/additionalresources/roe-issued-gc-ins/ressources_additionnelles.dita`

Sommaire: Il y a une ligne téléphonique directe pour résoudre des difficultés continues à effectuer le recueil de faits pour les RE provenant du gouvernement du Canada des ministères et organismes desservis par le Centre des services de paye de la fonction publique .
       [ministères et organismes desservis par le Centre des services de paye de la fonction publique](https://www.canada.ca/fr/services-publics-approvisionnement/services/paye-pension/administration-paye/ressources-centre-services-paye/ministeres-organismes-desservis-par-centre-services-paye.html)

**Communiquer avec le Centre des services de paye de la fonction publique**

Les agents communiquent avec le Centre de contact avec la clientèle du Centre de services de paye de la fonction publique au 1-855-686-4729 entre 7 h et 19 h (heure de l’Est), choisissent la langue de leur choix et appuient 6 sur le clavier.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0589.dita) 

L’agent peut être mis en attente avant que la connexion ne soit établie. Avant de commencer le recueil de faits, l’agent doit indiquer qu’il est un agent de l’AE qui appelle de Service Canada et confirmer que l’autre personne en ligne est un préposé au service à la clientèle.

Quand requis, le préposé au service à la clientèle rappellera l’agent AE dans les 24 heures suivant l’obtention des renseignements supplémentaires ou pour confirmer que le problème est réglé. L’agent AE est informé si un problème n’est pas en mesure d’être réglé et a été transmise à une autorité supérieure.

Au besoin, l’agent envoie une lettre au Centre des services de paye de la fonction publique en utilisant l’adresse suivante :

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0590.dita) 

Puisque l’adresse postale est une case postale, l’agent envoie la lettre par courrier ordinaire.

**Calcul initial — RE manquants (Niveau 1)**

L’agent qui traite des AT Évaluation de la demande (EVD) pour les clients employés par les ministères et organismes desservis par le Centre des services de paye de la fonction publique évite de finaliser les demandes comme PPNE 2 ou d’imposer des inadmissibilités 15 - Procédure de présentation des demandes (D15) si le RE manquant n’est pas le dernier RE. Dans ces cas, on détermine que le client n’a pas réussi à obtenir le RE auprès de l’employeur. L’agent doit effectuer un recueil de faits auprès du client pour remplir RE : INS3166 Demande pour RE manquant — Formulaire .
       [ministères et organismes desservis par le Centre des services de paye de la fonction publique](https://www.canada.ca/fr/services-publics-approvisionnement/services/paye-pension/administration-paye/ressources-centre-services-paye/ministeres-organismes-desservis-par-centre-services-paye.html) 
       [RE : INS3166 Demande pour RE manquant — Formulaire](https://catalogue.servicecanada.gc.ca/content/EForms/fr/CallForm.html?Lang=fr&PDF=SC-INS3166.pdf)

Une fois le RE : INS3166 Demande pour RE manquant — Formulaire rempli avec le client, l’agent confirme et vérifie les détails nécessaires de la période de paie pour créer un RE provisoire avec le préposé au service à la clientèle. L’agent demande aussi que le RE manquant soit émis et que le préposé au service à la clientèle transmette la demande au Centre des services de paye de la fonction publique. L’agent ne doit pas attendre pour créer le RE provisoire puisqu’il n’y a pas de délai garanti pour que les employeurs émettent le RE.
       [RE : INS3166 Demande pour RE manquant — Formulaire](https://catalogue.servicecanada.gc.ca/content/EForms/fr/CallForm.html?Lang=fr&PDF=SC-INS3166.pdf)

L’agent consulte Déterminer si un RE provisoire est nécessaire .
       [Déterminer si un RE provisoire est nécessaire](/fr/procedure/task/determining_interim_roe.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0591.dita) 

**Calcul initial — Vérification du RE (Non complexe et Niveau 1)**

L’agent communique avec le Centre de contact avec la clientèle à l’aide de la ligne directe pour demander ou vérifier des renseignements du RE.

**Calcul initial — Motif de cessation d’emploi (Niveau 1 et 2)**

Le préposé au service à la clientèle peut confirmer le code de motif de cessation d’emploi (MCE) sur le RE et fournir des renseignements contextuels, s’ils sont disponibles, sur les circonstances de la cessation d’emploi. Si plus de renseignements concernant le MCE sont requis, le préposé au service à la clientèle peut fournir les coordonnées du gestionnaire local.

**Nouveau Calcul**

Pour un nouveau calcul concernant un RE du gouvernement du Canada qui doit être corrigé consulte Traiter un AT Révision de la demande Nouveau calcul — RE du gouvernement du Canada (Tâche) .
       [Traiter un AT Révision de la demande Nouveau calcul — RE du gouvernement du Canada (Tâche)](/fr/procedure/task/cr_recalc_wi_goc_roe.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0589.dita`

Remarque :

Même si 6 ne fait pas partie des options dans le menu, en l’appuyant, l’agent est dirigé vers un préposé au service à la clientèle, qui se consacre à aider Service Canada avec les corrections du RE. 

### Callout

Source topic: `fr_FR/common_notes/note_c_0590.dita`

Services publics et Approvisionnement Canada Centre des services de paye de la fonction publique : Service du courrier C. P. 6500 Matane (Québec) G4W 0H6 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0591.dita`

Remarque :

Quand il saisit le RE provisoire, l’agent saisit le numéro d’employeur 121491807RP0001. 
