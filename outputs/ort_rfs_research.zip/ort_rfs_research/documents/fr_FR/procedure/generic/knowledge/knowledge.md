# Calcul : Renseignements sur le calcul et l’admissibilité aux prestations — Connaissances

Source map: `fr_FR/procedure/generic/knowledge/knowledge.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/knowledge/generic.dita`

**Table des matières**

- Établir la période de prestations (PP)
         [Établir la période de prestations (PP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Etablissement_de_la_periode_de_prestati)

- Rémunération hebdomadaire normale (RHN) et rémunération dernière semaine de travail (RDST)
         [Rémunération hebdomadaire normale (RHN) et rémunération dernière semaine de travail (RDST)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#RHN)

- Données réelles
         [Données réelles](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#DonneesReelles)

- Arrêt de rémunération (A de R)

- Arrêt de rémunération (A de R) administratif
             [Arrêt de rémunération (A de R) administratif](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#AdRadmin)

- Rémunération n’empêchant pas l’imposition de l’arrêt de rémunération (A de R)
             [Rémunération n’empêchant pas l’imposition de l’arrêt de rémunération (A de R)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Remuneratio_nempechant_pas_limposition)

- Congé avec salaire différé
             [Congé avec salaire différé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Conge_avec_salaire_differe)

- Cumul d’emplois
             [Cumul d’emplois](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Cumul_demplois)

- Réduction des heures de travail
             [Réduction des heures de travail](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Reduction_des_heures_de_travail)

- Périodes de congé
             [Périodes de congé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periodes_de_conge)

- Contrats
             [Contrats](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Contrats)

- Vente d’entreprise
             [Vente d’entreprise](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Vente_dentreprise)

- Faillite
             [Faillite](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Faillite)

- Agent immobilier
             [Agent immobilier](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Agent_immobilier)

         [Arrêt de rémunération (A de R)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration)

- DPP

- Politique administrative
             [Politique administrative](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Regle_administrative)

- Politique sur les postdates
             [Politique sur les postdates](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Politique_nationale_sur)

         [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations)

- Période de référence (PR)

- Prolonger la période de référence (PR)
             [Prolonger la période de référence (PR)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prolonger_la_PR)

         [Période de référence (PR)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

- Base de données sur les régions économiques
         [Base de données sur les régions économiques](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Base_de_données)

- Taux régional de chômage (TRC)

- Dénominateur
             [Dénominateur](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#deno)

- Projet pilote 24 : Mesures pour répondre aux changements majeurs dans les conjonctions économiques
             [Projet pilote 24 : Mesures pour répondre aux changements majeurs dans les conjonctions économiques](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#project_24)

         [Taux régional de chômage (TRC)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Taux_de_chomage_regional)

- Norme d’admissibilité

- Norme variable d’admissibilité (NVA)
             [Norme variable d’admissibilité (NVA)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Norme_variable_dadmissibilite)

- Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)
             [Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Norme_admissibilite_commune)

         [Norme d’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Norme_variable_dadmissibilite)

- Norme d’admissibilité commune
         [Norme d’admissibilité commune](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Norme_d’admissibilité_commune)

- Client de première ou de deuxième catégorie

- Client de première ou de deuxième catégorie — Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)
             [Client de première ou de deuxième catégorie — Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Client_de_premiere_ou_deuxieme_categorie)

         [Client de première ou de deuxième catégorie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#client12)

- Remplir les conditions requises pour recevoir des prestations

- Pêcheurs
             [Pêcheurs](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Pecheurs)

- Norme d’admissibilité commune
             [Norme d’admissibilité commune](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#r_lc_r_nac)

- Crédit unique d’heures
             [Crédit unique d’heures](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Crédit_unique_d’heures)

- Conditions requises
             [Conditions requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Conditions_requises)

- PPNE
             [PPNE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations_non_etablie)

- Organigramme — Conditions requises pour l’établissement d’une PP pour des prestations régulières
             [Organigramme — Conditions requises pour l’établissement d’une PP pour des prestations régulières](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Organigramme)

- Demandes PPNE — Norme d’admissibilité commune (de la s/c 2310 à la s/c 2361)
             [Demandes PPNE — Norme d’admissibilité commune (de la s/c 2310 à la s/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_demande_ppne_norme_adm)

         [Remplir les conditions requises pour recevoir des prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Genres_de_prestataires)

- Majoration des conditions requises

- Majoration des conditions requises — Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)
             [Majoration des conditions requises — Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Majoration_des_conditions_commune)

- Majoration des conditions requises
             [Majoration des conditions requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Majoration2)

- Non-considération de la majoration des conditions requises
             [Non-considération de la majoration des conditions requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Nonconsideration)

         [Majoration des conditions requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Majoration_nombre_dheures_demploi_ass_r)

- Calcul du taux de prestations

- Meilleures semaines variables (MSV)
             [Meilleures semaines variables (MSV)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#msv)

- Supplément familial (SF)
             [Supplément familial (SF)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#supfam)

         [Calcul du taux de prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Calcul)

- Délai de carence (DC)

- Annuler le DC
             [Annuler le DC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Annulation_du_delai_de_carence)

- Reporter le DC
             [Reporter le DC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Le_report_du_delai_de_carence)

         [Délai de carence (DC)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Delai_de_carence)

- Client admissible aux prestations spéciales seulement

- Inadmissibilité 46 - Période de prestations non-établie (PPNE) N5 : Client ordinaire
             [Inadmissibilité 46 - Période de prestations non-établie (PPNE) N5 : Client ordinaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Inadmissibilite_46_PPNE_N5_prest_ordina)

- Inadmissibilité 46 - Période de prestations non-établie (PPNE) N5 : Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)
             [Inadmissibilité 46 - Période de prestations non-établie (PPNE) N5 : Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Inadmissibilité_46)

         [Client admissible aux prestations spéciales seulement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestataire_admissible_prest_spec_seule)

- Prestations régulières

- Conditions requises pour les prestations régulières
             [Conditions requises pour les prestations régulières](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Criteres_requise_pour_prest_reg)

- Critères d’admissibilité aux prestations régulières
             [Critères d’admissibilité aux prestations régulières](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Criteres_dadmissibilite_prest_reguliere)

- Nombre de semaines d’admissibilité aux prestations régulières
             [Nombre de semaines d’admissibilité aux prestations régulières](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Nombre_de_sem_dadmissibilite_regulieres)

         [Prestations régulières](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_regulieres)

- Prestations spéciales
         [Prestations spéciales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_speciales)

- Prestations de maternité

- Conditions requises pour les prestations de maternité
             [Conditions requises pour les prestations de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Conditions_requises_pour_prestation)

- Critères d’admissibilité aux prestations de maternité
             [Critères d’admissibilité aux prestations de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Criteres_dadmissibilite_prest_mat)

- Preuve de grossesse
             [Preuve de grossesse](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Preuve_de_grossesse)

- Fin de grossesse
             [Fin de grossesse](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Fin_de_grossesse)

- Nombre de semaines d’admissibilité aux prestations de maternité
             [Nombre de semaines d’admissibilité aux prestations de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Nombre_de_sem_dadmissibilite_maternite)

- Fenêtre de maternité
             [Fenêtre de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_maternite)

- Prolongation de la fenêtre de maternité
             [Prolongation de la fenêtre de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prolongation_de_la_periode_de_maternite)

- Demander des prestations de maternité
             [Demander des prestations de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Demande_de_prestations_de_maternite)

- Prestations de maternité et de maladie
             [Prestations de maternité et de maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_de_maternite_et_de_maladie)

         [Prestations de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_de_maternite)

- Prestations parentales

- Conditions requises pour les prestations parentales
             [Conditions requises pour les prestations parentales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Conditions_requises_pour_prest_parental)

- Critères d’admissibilité aux prestations parentales
             [Critères d’admissibilité aux prestations parentales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Criteres_dadmissibilite_prestations)

- Parents adoptifs
             [Parents adoptifs](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Parents_adoptifs_Nouvelle_politique_en)

- Parents légalement reconnus
             [Parents légalement reconnus](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Parents_legalement_reconnus)

- Preuve de naissance, d’adoption ou de placement
             [Preuve de naissance, d’adoption ou de placement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Preuve_de_naissance_dadoption_ou_de_pl)

- Placement quand l’enfant sous la garde du client ne peut pas être adopté légalement
             [Placement quand l’enfant sous la garde du client ne peut pas être adopté légalement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Placement_quand_lenfant_sous_la_garde_d)

- Genre de prestations parentales
             [Genre de prestations parentales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Genredeprestations)

- Taux de prestations parentales
             [Taux de prestations parentales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Tauxdeprestations)

- Admissibilité maximale
             [Admissibilité maximale](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Maximale)

- Partage des prestations parentales
             [Partage des prestations parentales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Partage)

- Fenêtre parentale (FP)
             [Fenêtre parentale (FP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Fenetre_parentale)

- Prolongation de la FP
             [Prolongation de la FP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prolongation_FP)

- Terminer des prestations parentales durant la FP — Les conditions d’admissibilité ne sont plus remplies
             [Terminer des prestations parentales durant la FP — Les conditions d’admissibilité ne sont plus remplies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Terminer_des_prestations)

- Prestations parentales et de maladie
             [Prestations parentales et de maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_parentales_et_de_maladie)

         [Prestations parentales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_parentales)

- Prestations de maladie

- Conditions requises pour les prestations de maladie
             [Conditions requises pour les prestations de maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Conditions_requises_pour_prest_mal)

- Critères d’admissibilité aux prestations de maladie
             [Critères d’admissibilité aux prestations de maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Criteres_dadmissibilite_prestations_mal)

- Preuve de l’état de santé du client
             [Preuve de l’état de santé du client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Preuve_de_letat_de_sante_du_client)

- Autrement disponible pour travailler
             [Autrement disponible pour travailler](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Autrement_disponible_pour_travailler)

- Maladie déclarée sur une demande de prestations régulières
             [Maladie déclarée sur une demande de prestations régulières](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Maladie_declaree_sur_une_demande_reguli)

- Nombre maximal de semaines de prestations de maladie
             [Nombre maximal de semaines de prestations de maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Nombre_maximal_semaines_maladie)

         [Prestations de maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_de_maladie)

- Prestations de compassion (PDC)

- Conditions requises pour les prestations de compassion (PDC)
             [Conditions requises pour les prestations de compassion (PDC)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#_Conditions_requises_pour_prest_compassion)

- Critères d’admissibilité aux PDC
             [Critères d’admissibilité aux PDC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Criteres_dadmissibilite_pdc)

- Définition du membre de la famille
             [Définition du membre de la famille](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Definition_du_membre_de_la_famille)

- Définition de soins ou de soutien
             [Définition de soins ou de soutien](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Definition_de_soins_ou_de_soutien)

- Preuve de l’état de santé du patient
             [Preuve de l’état de santé du patient](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Preuve_de_letat_de_sante_du_patient)

- Nombre maximal de semaines de PDC
             [Nombre maximal de semaines de PDC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Nombre_max_semaines_prestation_compassi)

- Fenêtre de compassion (FC)
             [Fenêtre de compassion (FC)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Fenetre_de_compassion)

         [Prestations de compassion (PDC)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_de_compassion)

- Prestations pour proches aidants

- Conditions requises
             [Conditions requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#ConditionsRequises)

- Conditions d’admissibilité
             [Conditions d’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#ConditionsAdmis)

- Inadmissibilités
             [Inadmissibilités](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Inadmiss)

- Nombre maximal de prestations pour proches aidants
             [Nombre maximal de prestations pour proches aidants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#PrestationsMaxPayables)

- Fenêtre pour proches aidants (FPA)
             [Fenêtre pour proches aidants (FPA)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#FPA)

- Définition du membre de la famille
             [Définition du membre de la famille](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#DefinitionMembre)

- Définition de soins ou de soutien
             [Définition de soins ou de soutien](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#DefinitionSoins)

- Preuve de l’état de santé du patient
             [Preuve de l’état de santé du patient](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#DocMed)

- Partage des prestations
             [Partage des prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#PartagePrestations)

- Mémo pour le centre opérationnel (MM06)
             [Mémo pour le centre opérationnel (MM06)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#MM06)

- PAS-IND-DP
             [PAS-IND-DP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#PasIndDp)

         [Prestations pour proches aidants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#PProchesAidants)

- Semaines d’admissibilité payées ou payables
         [Semaines d’admissibilité payées ou payables](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Semaines_dadmissibilite)

- Période de prestations (PP)

- Prolonger la PP
             [Prolonger la PP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prolongation_de_la_PP)

         [Période de prestations (PP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations)

**Établir la période de prestations (PP)**

Afin d’établir une PP , un client doit remplir les 2 conditions suivantes dans la PR :
       [PP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations) 
       [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

- Le client doit avoir subi un arrêt de rémunération (A de R).
         [arrêt de rémunération](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration)

- Le client doit avoir accumulé le nombre requis d’heures d’emploi assurable.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0829.dita) 

Afin de déterminer l’admissibilité du client, il faut comparer les heures d’emploi assurable dans la PR à la norme variable d’admissibilité (NVA).
       [norme variable d’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Norme_variable_dadmissibilite)

Il n’est pas nécessaire que le client ait subi l’A de R au cours du plus récent emploi pour établir une PP.

**Rémunération hebdomadaire normale (RHN) etrémunération dernière semaine de travail (RDST)**

La RHN et la RDST sont utilisées durant le calcul d’une demande pour déterminer quand l’ A de R a eu lieu ainsi que pour déterminer le DPP et la répartition des sommes à la cessation d’emploi.
       [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration) 
       [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations)

En général, la RHN représente la dernière rémunération hebdomadaire brute payée. La RHN peut aussi comprendre des sommes payées sur une base régulière comme les sommes pour les heures supplémentaires, les commissions, les congés (p. ex. vacances ou jours fériés), allocations (p. ex. pour travail en région nordique ou pour la voiture) ou des primes pour des quarts de travail.

La RDST représente la rémunération payée au client durant la dernière semaine civile de cet emploi.

Le CAC calcule automatiquement la moyenne de la RHN et de la RDST pour chaque RE. Les moyennes des montants sont indiquées dans le Fichier historique d’emploi (FHE) de chaque RE et sont utilisées durant le calcul sauf si le client fournit les montants après la présentation de la demande de prestations. Si le client fournit les montants de la RHN et de la RDST après la présentation de la demande, ils sont acceptés tels quels, sauf s’ils ne semblent pas raisonnables ou s’il existe des preuves évidentes du contraire. Les montants fournis par le client sont comparés à la moyenne de la rémunération hebdomadaire assurable calculée à partir du RE (à l’exception des sommes payées à la cessation d’emploi) pour déterminer s’ils semblent raisonnables (p. ex. une différence entre le montant fourni par le client et la moyenne de la RHN calculée à partir du RE ne dépassant pas 10 % ou 75 $ est considérée comme raisonnable). Parfois, les montants fournis qui semblent inexacts peuvent être considérés comme acceptables selon la situation du client ou les circonstances du marché du travail local (p. ex. le client a récemment obtenu une promotion qui a contribué à l’augmentation de sa rémunération normale). Quand les montants fournis semblent raisonnables, l’agent outrepasse les moyennes en saisissant les montants fournis dans MSRE.

Pour obtenir de plus amples renseignements, consulter GDA 5.6.3 — Rémunération hebdomadaire normale provenant de « cet emploi » .
       [GDA 5.6.3 — Rémunération hebdomadaire normale provenant de « cet emploi »](http://www.servicecanada.gc.ca/fra/ae/guide/5_6_0.shtml#a5_6_3)

**Données réelles**

Les données réelles constituent une preuve, sans inclure les renseignements dans un RE, de la rémunération ou des heures réelles accumulées dans un emploi assurable, indépendamment des détails liés aux meilleures semaines variables (MSV). Généralement, les données réelles sont soumises par le client sous forme de talon de paie, mais les preuves de données réelles peuvent être tout renseignement utilisé par le client pour faire le suivi de son historique d’emploi. Les employeurs peuvent aussi soumettre des données réelles sous forme de registres de paie. Les données réelles sont généralement fournies à chaque période de paie.

L’agent demande et utilise les données réelles que dans des circonstances exceptionnelles. Quand le client ou l’employeur fournit des données réelles qui ne sont pas nécessaires, l’agent les retourne sans les utiliser. L’agent ne doit pas demander de données réelles si elles ne sont pas nécessaires. Quand des données réelles sont demandées, l’agent consigne la raison de la demande dans le dossier.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0830.dita) 

Des données réelles sont demandées quand :

- il y a une prolongation de la PR au-delà de la période couverte par le RE;

- le client est PPNE et les données réelles permettent au client d’être admissible (p. ex. le premier jour de travail [PJT] dans le RE est avant la date limite et le client est PPNE avec seulement les heures indiquées dans le RE);

- une inadmissibilité indéfinie est imposée au client, qui pourrait redevenir admissible (p. ex. la date de l’évènement entraînant l’exclusion est entre le PJT et le dernier jour payé [DJP] d’un autre RE).

Quand les données réelles sont nécessaires et reçues, l’agent les saisit dans le fichier historique d’emploi et les utilise pendant le calcul de la demande. Quand des données réelles sont utilisées pendant le calcul de la demande, CAC calcule les heures et la rémunération assurables dans la PR en utilisant la moyenne proportionnelle des heures et de la rémunération qu’il reste dans le RE.

**Arrêt de rémunération (A de R)**

Il y a un A de R :

- quand le client ayant un emploi assurable est mis à pied ou que cet emploi a pris fin et que le client a passé au moins 7 jours consécutifs ou plus sans travailler ni recevoir de rémunération de cet emploi;
         [rémunération](http://www.servicecanada.gc.ca/fra/ae/guide/chp5.shtml)

- dès le dimanche de la semaine où le revenu du client tombe sous le seuil de 60 % de la rémunération hebdomadaire normale (RHN) et que la cessation d’emploi est attribuable à un congé de maladie, de maternité, parental, de soins de compassion ou de proche aidant.
         [rémunération hebdomadaire normale](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#RHN)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0831.dita) 

**Arrêt de rémunération (A de R) administratif**

- On considère avoir satisfait à l’exigence des 7 jours pour un A de R régulier quand l’employeur émet un RE puisqu’il est raisonnablement convaincu que son employé sera sans travail ou rémunération pendant 7 jours consécutifs.
         [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration)

- Si le RE a été émis correctement, même si la mise à pied dure moins de 7 jours consécutifs, on considère quand même que l’A de R s’est produit.

**Rémunération n’empêchant pas l’imposition d’un arrêt de rémunération (A de R)**

Toute somme ayant valeur de rémunération aux fins des prestations empêche l’imposition d’un A de R, sauf les suivantes :

- les indemnités de départ réparties conformément au RAE 36(9)
         [RAE 36(9)](http://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-36.html)

- les indemnités pour retrait préventif

- les indemnités pour accidents du travail (IAT)

- les indemnités d’assurance-salaire (IAS) provenant d’un régime collectif

- les pensions

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0832.dita) 

Pour obtenir de plus amples renseignements sur l’A de R, consulter GDA 2 — Arrêt de rémunération .
       [GDA 2 — Arrêt de rémunération](http://www.servicecanada.gc.ca/fra/ae/guide/chp2.shtml)

**Congé avec salaire différé**

Dans le cas d’un congé avec salaire différé ou d’un congé autofinancé, un A de R ne se produit pas avant la fin de la période de congé, à moins que l’employé ou l’employeur ne rompe le contrat. Par conséquent, l’employé n’est pas considéré être en chômage tant que le contrat se poursuit.

**Cumul d’emplois**

Pour qu’un A de R survienne, il doit y avoir 7 jours consécutifs sans travail ou sans rémunération d’un emploi assurable. Par exemple, un client cumule 2 emplois assurables. Dans le cas du premier emploi, il n’y a pas de changement, mais pour le second emploi, le client passe 7 jours consécutifs sans travailler ni recevoir une rémunération : il y a donc A de R.

**Réduction des heures de travail**

Dans le cas d’une réduction des heures de travail, on ne considère pas qu’un A de R soit survenu. Par exemple, si les heures de travail du client sont réduites et il travaille à temps partiel au lieu de travailler à temps plein, à moins qu’il n’y ait une période de 7 jours consécutifs sans travail et sans rémunération pour cet employeur, on ne considère pas qu’un A de R soit survenu.

**Périodes de congé**

Quand un employé travaille des heures ou des quarts supplémentaires et obtient par la suite une semaine ou plus de congé, il n’y a pas d’A de R pendant la période de congé. Par exemple, si le client travaille normalement une période de 14 jours puis est en congé pendant 10 jours, l’A de R commence le onzième jour de congé.

**Contrats**

Si un contrat stipule que le client est payé pour une période déterminée, peu importe le travail effectué pendant cette période, il n’y a pas d’A de R avant l’échéance de la période visée dans le marché. Par exemple, un client ayant signé un contrat de 3 mois avec son employeur finit sa tâche en 2 mois. Il n’y a pas d’A de R avant la fin du troisième mois.

**Vente d’entreprise**

Quand un employeur perd son emploi à la suite de la vente de l’entreprise, un A de R se produit, même si le nouveau propriétaire continue de l’employer sans que ne passe une période de 7 jours sans travail ni rémunération.

**Faillite**

Quand l’employeur fait faillite, il y a A de R quand le liquidateur des biens du failli prend en charge l’exploitation de l’entreprise. Si l’employé continue de travailler pour un employeur qui fait faillite, il n’y aura pas d’A de R avant que l’employé ne cesse de travailler, même si aucune rémunération n’est versée.

**Agent immobilier**

Aux fins des prestations régulières, il y a un A de R quand le permis d’agent immobilier est remis, suspendu ou annulé. En Ontario, le permis, qui est délivré par un registraire, n’est valide que pour l’employeur qui y est nommé. À la suite de la rupture de la relation employeur-employé, le permis devient invalide.

Aux fins des prestations spéciales, il y a un A de R quand un agent immobilier ne travaille pas en raison de son congé de maladie, de maternité, parental ou de compassion. Son permis d’agent immobilier demeure en vigueur.

**DPP**

Le DPP est la date d’entrée en vigueur ou la date de début de la demande.

Une période de prestations (PP) débute généralement la date la plus tardive des 2 dates suivantes (LAE 10) :
       [période de prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations) 
       [(LAE 10)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-2.html#h-210461)

- le dimanche de la semaine au cours de laquelle survient l’ A de R
         [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration)

- le dimanche de la semaine au cours de laquelle la demande de prestations est présentée

Toutefois, si un client exerce un emploi assurable pendant cette semaine et les heures sont requises pour établir la PP, le DPP est postdaté au dimanche suivant. En de rares occasions, l’agent peut postdater le DPP de plus d’une semaine, mais pas au-delà de la norme variable d’admissibilité (NVA) courante.
       [norme variable d’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Norme_variable_dadmissibilite)

Quand cela avantage le client, le DPP peut être antidaté d’un nombre de semaines équivalant au DC si, au cours de ces semaines, le client a reçu des IAS provenant d’un régime collectif ou des IAT. Le DPP ne peut pas être antidaté au-delà de l’A de R.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0833.dita) 

**Politique administrative**

Quand un client présente une demande de prestations, le DPP est déterminé selon la LAE 10 .
       [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations) 
       [LAE 10](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-2.html#h-210461)

En vertu de la politique administrative, quand un client présente une demande de prestations dans les délais prescrits, l’agent établit la PP dans l’une des semaines suivantes, selon celle qui est la plus avantageuse pour le client :

- la semaine au cours de laquelle l’A de R survient;

- la semaine au cours de laquelle le DJP se produit;

- la dernière semaine pour laquelle des IAS, des IAT, des indemnités pour retrait préventif ou des prestations du RQAP sont versées.

Toutefois, si un DPP postérieur était plus avantageux pour le client, l’agent consulte la Politique sur les postdates pour déterminer si le DPP devrait être postdaté. La politique administrative et la Politique sur les postdates sont 2 politiques distinctes que l’agent applique séparément lors du processus étape par étape.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0834.dita) 

Selon la politique administrative, la demande a été présentée dans les délais prescrits puisque le client l’a présentée dans les 4 semaines civiles de l’A de R. L’agent peut établir le DPP dans la s/c 2275.

Toutefois, dans ce cas, il est avantageux pour le client de postdater la demande en raison de la rémunération dans la dernière semaine de travail. En vertu de la Politique sur les postdates, l’agent postdate le DPP à la s/c 2276.

Pour qu’une demande soit considérée comme présentée dans les délais prescrits, la politique administrative permet au client de présenter sa demande dans les 4 semaines civiles suivant la semaine au cours de laquelle se produit l’un des évènements suivants :

- la semaine au cours de laquelle l’A de R survient;

- la semaine au cours de laquelle le DJP se produit;

- pour les pêcheurs, la date de la fin du voyage (prise fraîche) ou la date de l’achat (prise traitée);

- la dernière semaine pour laquelle des IAS, des IAT, des indemnités pour retrait préventif ou des prestations du RQAP sont versées.

Si un client ne présente pas sa demande dans les délais prescrits, le DPP est le dimanche de la semaine au cours de laquelle le client présente sa demande.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0835.dita) 

La politique administrative s’applique également aux demandes subséquentes. Un client peut présenter une nouvelle demande de prestations une fois que la demande active est épuisée. On appelle cette nouvelle demande une demande subséquente.

Une demande subséquente peut être établie dès la semaine après celle dans laquelle la demande précédente s’est terminée, si la demande d’AE est présentée dans l’un des délais suivants :

- 5 semaines à partir de la semaine pendant laquelle les dernières déclarations du prestataire ont été émises;

- 4 semaines à partir de la semaine pendant laquelle la déclaration du prestataire est traitée dans ETI.

Si le client ne présente pas la demande subséquente dans l’un des délais ci-dessus, la demande subséquente est établie selon les règles générales sur la détermination du DPP.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0836.dita) 

Si un client ne présente pas de demande de prestations dans les délais prescrits, le DPP est le dimanche de la semaine au cours de laquelle le client a présenté la demande.

     [Exemple 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0837.dita) 
     [Exemple 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0838.dita) 

**Politique sur les postdates**

Une demande est considérée comme postdatée quand la PP est établie à une date postérieure à celle que permettrait la LAE 10(1) ou la politique administrative.

Un DPP peut être postdaté jusqu’à 4 semaines, mais ne peut pas être postdaté au-delà de la période de la NVA actuelle. Une demande ne peut pas être postdatée seulement pour qu’un client profite d’une nouvelle loi, à moins d’autorisation ou d’avis contraire par Politique Opérationnelle d’AE.

Une demande initiale ou renouvelée peut être postdatée seulement dans les situations suivantes qui peuvent être avantageuses pour le client :

- Le client a besoin des heures d’emploi assurable de la dernière semaine travaillée pour remplir les conditions requises pour être admissible aux prestations.

- La semaine de l’A de R ou la semaine de la présentation de la demande est une semaine entière de travail (SET).

- En raison d’une rémunération dans la semaine de l’A de R, le client aurait reçu seulement un premier paiement partiel et a demandé que la demande soit postdatée d’une semaine.

- Les indemnités de cessation d’emploi ou la rémunération, ou une combinaison des 2, dans la semaine de l’A de R ou de la présentation de la demande sont égales ou supérieures au taux de prestations.

- Le client a présenté une demande de prestations de maternité ou parentales avant la fenêtre de prestation.

- Le client demande des prestations spéciales et peut recevoir le maximum de semaines admissibles, mais la rémunération dans la première semaine empêche le paiement du plein taux de prestations.

- Le client est un enseignant qui présente une demande de prestations de maternité ou parentales pendant une période de non-enseignement. Le client peut être admissible à un paiement contractuel de l’employeur en plus d’un supplément du régime de prestations supplémentaires de chômage (PSC) pour les prestations de maternité et parentales. Ces sommes constituent une rémunération et empêchent le versement de prestations d’AE pour ces semaines, car elles ne remplissent pas les critères du régime de PSC. Une postdate pourrait être avantageuse pour le client, mais l’agent doit prêter attention aux fenêtres de maternité et parentales pour s’assurer que l’admissibilité maximale reste disponible.

Si un client a travaillé depuis la date de la demande initiale et a besoin de ces heures pour remplir les conditions requises pour recevoir des prestations, l’agent peut utiliser les heures supplémentaires pour établir la PP. Le DPP est basé selon le dernier A de R et le client doit fournir le RE et tout autre renseignement pertinent. Si une décision initiale a déjà été rendue, le client doit présenter une nouvelle demande.

Une demande de prestations de maladie peut être postdatée seulement quand le certificat médical indique une date de guérison précise qui permettra au client de recevoir l’admissibilité entière à ces prestations au taux hebdomadaire complet.

Quand une semaine de guérison saisie est 99-99-9999 (selon le certificat médical qui indique que le client est en phase terminale ou palliative), la version Web de SSA postdate automatiquement la demande d’une semaine s’il y a une rémunération dans la semaine 1. Le DPP d’une demande avec une semaine de guérison indéfinie (selon le certificat médical qui indique que le client est en phase terminale ou palliative) ne doit pas être postdaté en raison de la rémunération dans la semaine 1, sauf si le client a demandé précisément de postdater la demande.

Une demande de prestations spéciales (autres que de prestations de maladie) est seulement postdatée quand il y a des preuves précises (p. ex. la date du RAT) indiquant que cela permettra au client de recevoir ou d’être admissible à recevoir le taux maximal de prestations pour le nombre de semaines demandé ou admissible. Quand les renseignements au dossier (p. ex. la date du RAT, la fin d’une fenêtre de prestations spéciales ou la date de décès du patient) indiquent que la postdatation de la demande ne serait pas avantageuse pour le client de postdater la demande, l’agent ne postdate pas le DPP.

**Période de référence (PR)**

La PR initiale est la plus courte des périodes suivantes :

- la période de 52 semaines qui précède immédiatement le DPP .
         [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations)

- la période qui débute la semaine d’un DPP antérieur et qui se termine la semaine précédant le DPP d’une nouvelle demande.

Dans certains cas, si un client ne pouvait pas travailler pendant la PR, la PR pourrait être prolongée d’une période maximale de 52 semaines (portant ainsi la durée de la PR à un maximum de 104 semaines). La PR ne peut pas être prolongée au-delà de la semaine du DPP d’une demande antérieure.

La première semaine de la PR est la date limite (DL).

Le nombre d’heures d’emploi assurable qui font partie de la PR est pris en compte quand on détermine si le client a suffisamment d’heures pour établir une période de prestations (PP) et le nombre de semaines d’admissibilité. Les meilleures semaines de rémunération qui font partie de la PR sont utilisées pour déterminer le taux de prestations.
       [période de prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations)

**Prolonger la période de référence (PR)**

Conditions pour prolonger la PR

La PR peut être prolongée d’une semaine pour chaque semaine de la PR si le client prouve qu’il remplit les 2 conditions suivantes :
       [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

- Le client n’a pas reçu de prestations d’AE ou du RQAP .
         [RQAP](http://www.rqap.gouv.qc.ca/Index.asp)

- Pendant la semaine, le client n’exerçait pas un emploi assurable pour au moins une des raisons suivantes, même si la raison ne s’applique pas à toute la semaine civile :

- maladie, blessure, mise en quarantaine ou grossesse

- reçoit de l’aide dans le cadre d’une prestation d’emploi (suit un cours de formation dirigé ou une activité de formation liée à son travail)

- reçoit des indemnités pour retrait préventif en vertu d’une loi provinciale

- est détenu dans une prison, un pénitencier ou un autre établissement semblable, et le client n’a pas été déclaré coupable des chefs d’accusation qui ont engendré l’incarcération.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0839.dita) 

Périodes non considérées pour une prolongation de la PR

Les semaines au cours desquelles les situations suivantes se produisent sont considérées comme des semaines de prestations payées ou des semaines comprenant un emploi assurable et ne sont pas considérées pour une prolongation de la PR :

- Au moins 1 $ de prestations d’AE a été payé au client.

- Le client a observé une exclusion déterminée.

- Les prestations ont été utilisées pour rembourser un trop-payé (T-P) ou une pénalité en vertu de la LAE 38.

- Les prestations ont été retenues pour une cession de prestations (CDP).

- Les prestations ont été retenues aux termes d’un accord d’ordonnance familiale (AOF).

- Le client a reçu des prestations provinciales pour une naissance ou une adoption, telles que les prestations du RQAP.

- Le client a reçu une rémunération assurable pour un congé payé par l’employeur.

Aux fins de la prolongation de la PR, les congés payés par l’employeur dont la rémunération est assurable, comme les indemnités d’assurance-salaire (IAS), sont considérés comme un emploi assurable. Par conséquent, toute semaine pendant laquelle le client reçoit une rémunération assurable pour un congé payé n’est pas utilisée pour prolonger la PR, même si le client était incapable de travailler pour des raisons médicales au cours de cette période.

Toutefois, les semaines au cours desquelles le client reçoit une rémunération non assurable pour un congé payé par l’employeur sont considérées pour une prolongation de la PR.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0840.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0841.dita) 

Sauf s’il y a un doute ou si la prolongation est liée à une période d’incarcération, la déclaration du client dans sa demande de prestations est acceptée comme preuve dans le cadre de la prolongation de la PR.

Une prolongation de la PR modifie la DL.

Quand le client est incarcéré le 30 juin 2013 ou après, les preuves suivantes sont nécessaires pour prolonger la PR :

- une lettre provenant de l’établissement où le client a été incarcéré, afin de prouver les dates de l’incarcération

- une lettre de son avocat ou de la cour provinciale, territoriale ou fédérale qui prouve que le client n’a pas été trouvé coupable.
         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0842.dita)

- une lettre ou tout autre type de document confirmant qu’il n’y a pas d’autres chefs d’accusation en suspens pour lesquels le temps d’incarcération sert de crédit
         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0843.dita)

**Base de données sur les régions économiques**

La Base de données sur les régions économiques relie le code postal d’un client à une région économique. La base de données est mise à jour régulièrement pour tenir compte des modifications apportées aux codes postaux et aux régions économiques.

Le Canada est divisé en plusieurs régions économiques, qui sont définies dans le RAE. La région économique utilisée pour calculer une demande est la région où le client réside habituellement pendant la semaine du DPP. Quand une demande est recalculée, la région économique utilisée est la même que celle de la demande initiale.

Quand le code postal d’un client chevauche 2 régions économiques, le client est considéré comme faisant partie de la région économique ayant le TRC le plus élevé, ce qui est toujours en faveur du client.

Le résultat du calcul peut générer une erreur quand le système ne peut pas traiter une modification à la Base de données des régions économiques ou quand la base de données n’est pas disponible.

**Taux régional de chômage (TRC)**

Pour la plupart des clients, le TRC s’utilise afin de déterminer si le client est admissible aux prestations. Le TRC est aussi utilisé pour déterminer le dénominateur national. Statistique Canada détermine le taux de chômage mensuel de chaque région, en intégrant les taux saisonniers et une estimation des taux de chômage des Indiens inscrits vivant dans des réserves. Le TRC applicable à un client est la moyenne des taux de la période de 3 mois précédant la semaine du DPP . Les taux régionaux actuels et historiques peuvent être consultés sur la page Les régions économiques de l’assurance-emploi .
       [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations) 
       [Les régions économiques de l’assurance-emploi](http://srv129.services.gc.ca/eiregions/fra/taux_act.aspx)

En raison de la COVID-19 et du nombre historiquement élevé de Canadiens en difficulté financière, une mesure temporaire est mise en œuvre pour réduire le nombre d’heures nécessaires pour remplir les conditions requises afin d’être admissibles aux prestations. Dans les demandes dont le DPP est entre la s/c 2251 et la s/c 2309, le TRC pour toutes les 62 régions économiques était temporairement fixé à 13,1 %, sauf si le TRC déclaré pour cette région était plus élevé.

Le TRC a une incidence sur la NVA, les semaines d’admissibilité et le dénominateur.

**Dénominateur**

Le TRC détermine le dénominateur à utiliser pendant le calcul du taux de prestations.
       [TRC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Taux_de_chomage_regional) 
       [dénominateur](/fr/procedure/generic/additionalresources/divisor_table_regular.shtml)

**Projet pilote 24 : Mesures pour répondre aux changements majeurs aux conjonctures économiques**

Du 6 avril 2025 au 11 octobre 2025, pour faciliter l’accès aux prestations, une mesure temporaire ajustera le taux de chômage pour les régions avec des taux inférieurs à 13,1 %. Pour toutes les demandes initiales dont le DPP est entre le 6 avril 2025 (s/c 2494) et le 5 octobre 2025 (s/c 2520), le TRC sera mis de la façon suivante :

- Pour toutes les régions économiques qui ont un taux de chômage de 6,1 % ou moins, le TRC minimum ( RAE 17 ) est mis à 7,1 %.
         [RAE 17](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-17.html)

- Pour les régions dont le TRC est de 6,2 % à 12 %, 1 % seront ajoutés au TRC fixe.

- Pour les régions dont le TRC est de 12,1 % à 13 %, le TRC est mis à 13,1 %.

- Pour les régions dont le TRC est de 13,1 % ou plus, il n’y a pas de modification au TRC.

En ajustant le TRC dans les régions où le TRC est inférieur à 6 % ou n’est pas supérieur à 13 %, les clients peuvent être admissibles à plus de semaines de prestations régulières. Le TRC détermine aussi le dénominateur utilisé lors du calcul du taux de prestations. En ajustant le TRC, le client pourrait bénéficier d’un taux de prestations plus élevé parce que le dénominateur diminue lors de l’augmentation du TRC.

**Norme d’admissibilité**

Le nombre d’heures d’emploi assurable requis pour remplir les conditions requises dépend de la norme d’admissibilité en vigueur au moment du DPP.

**Norme variable d’admissibilité (NVA)**

La NVA est le nombre d’heures assurables dans la PR nécessaire pour qu’un client ordinaire qui n’est pas soumis à une majoration des conditions requises puisse établir une période de prestations (PP). Le nombre exact s’appelle la NVA et se trouve dans le tableau Nombre d’heures d’emploi assurable requis .
       [client ordinaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_regulieres) 
       [Nombre d’heures d’emploi assurable requis](/fr/procedure/generic/additionalresources/ver_reg_ben.shtml)

Selon le taux régional de chômage (TRC) en vigueur la semaine du DPP, ce montant se situe entre 420 et 700 heures d’emploi assurable pendant la PR .
       [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

**Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)**

Dans le cadre du budget 2021, le gouvernement du Canada a annoncé qu’une norme d’admissibilité commune nationale de 420 heures d’emploi assurable s’applique pour établir une demande de prestations régulières ou spéciales. Si le client a une violation à son dossier, une majoration des conditions requises pourrait s’appliquer. La norme d’admissibilité commune s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, la norme d’admissibilité n’est pas basée sur le taux régional de chômage (TRC). Toutefois, le TRC continue d’être utilisé pour déterminer le dénominateur et les semaines d’admissibilité selon les heures d’emploi assurable dans la période de référence (PR). Dans cette période, une demande avec moins de 420 heures est finalisée PPNE N1. S’il y a une violation au dossier et que le client ne respecte pas la majoration des conditions requises, la demande est finalisée PPNE N5.
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

**Client depremièreou dedeuxièmecatégorie**

Toutes les heures d’emploi assurable dans la PR , y compris les heures d’un emploi exclu, sont utilisées pour déterminer l’appartenance du client à la première ou à la deuxième catégorie.
       [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

Pour être client de la première catégorie, le client doit avoir accumulé au moins 600 heures d’emploi assurable dans la PR.

Quand le client a accumulé 600 heures d’emploi assurable ou plus dans la PR, mais que certaines de ces heures assurables n’ont pas été prises en compte dans le calcul, le champ Heures assurables : période de référence de l’onglet Taux-Durée d’ETI ne tient pas compte de celles-ci. Dans ce cas, la case Première catégorie sous l’onglet Taux/Durée est cochée pour signaler que le client fait partie de la première catégorie.

Pour être client de la deuxième catégorie, le client doit avoir accumulé moins de 600 heures d’emploi assurable dans la PR, mais doit avoir accumulé le nombre minimum d’heures pour établir une demande de prestations régulières.

Le système code les demandes dont le DPP est entre le 27 septembre 2020 et le 19 septembre 2021 et dans lesquelles le client a reçu un crédit de 300 heures assurables comme étant de première catégorie. Cela signifie qu’un client dont la demande pour la PU AE effectue une transition et qui a moins de 600 heures peut également remplir les conditions requises pour recevoir des prestations spéciales.

**Client de première ou de deuxième catégorie — Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)**

Une mesure temporaire du budget 2021 s’applique aux demandes de prestations régulières et spéciales dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, toutes les demandes établies avec 420 heures d’emploi assurable ou plus sont qualifiées pour des prestations spéciales. Les définitions client de première et de deuxième catégorie ne s’appliquent pas pour la durée de la mesure.

**Remplir les conditions requises pour recevoir des prestations**

Afin de déterminer si un client remplit les conditions requises pour recevoir des prestations, il faut déterminer le nombre d’heures assurables dans la PR .
       [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

En général, un client qui dispose de 700 heures ou plus dans la PR peut remplir les conditions requises pour recevoir tous les GP d’AE : régulières , de maladie , de maternité , parentales , de compassion et pour proches aidants .
       [régulières](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_regulieres) 
       [maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_de_maladie) 
       [maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_de_maternite) 
       [parentales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_parentales) 
       [compassion](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_de_compassion) 
       [proches aidants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#PProchesAidants)

Les clients qui ont accumulé moins de 420 heures assurables dans la PR ne remplissent pas les conditions requises pour recevoir des prestations.

Les clients dont le DPP est le 3 juillet 2016 ou après et qui ont accumulé au moins 420 heures assurables dans la PR doivent remplir les conditions qui s’appliquent aux clients ordinaires pour remplir les conditions requises pour recevoir des prestations.
       [clients ordinaires](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestataire_ordinaire)

**Pêcheurs**

Les conditions d’admissibilité sont différentes pour les pêcheurs. Pour obtenir de plus amples renseignements, consulter GDA 15 .
       [GDA 15](http://www.servicecanada.gc.ca/fra/ae/guide/chp15.shtml)

**Norme d’admissibilité commune**

Dans le cadre du budget 2021, le gouvernement du Canada a annoncé qu’une norme d’admissibilité commune nationale de 420 heures d’emploi assurable s’applique pour établir une demande de prestations régulières ou spéciales. Si le client a une violation à son dossier, une majoration des conditions requises pourrait s’appliquer. La norme d’admissibilité commune s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, la norme d’admissibilité n’est pas basée sur le taux régional de chômage (TRC). Toutefois, le TRC continue d’être utilisé pour déterminer le dénominateur et les semaines d’admissibilité selon les heures d’emploi assurable dans la période de référence (PR).
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

**Crédit unique d’heures**

Pour aider les clients à la fin de la PU AE, les clients dont le DPP est entre le 27 septembre 2020 et le 25 septembre 2021 recevront un crédit unique d’heures assurables.

Les clients qui présentent des demandes de prestations spéciales recevront un crédit de 480 heures. Les clients qui présentent des demandes de prestations régulières recevront un crédit de 300 heures et sont codés par le système comme étant de première catégorie même s’ils ont moins de 600 heures.

CAC génère l’un des messages d’avertissement suivants dans les demandes recevant le crédit d’heures :

- Message d’avertissement 1157 - crédit de 300 heures assurables

- Message d’avertissement 1158 - crédit de 480 heures assurables

Dans la version Web de SSA, l’avertissement s’affiche à l’écran Résultat du calcul dans la section Message .

**Conditions requises**

Afin d’établir une PP, un client ordinaire qui n’est pas assujetti à la majoration des conditions requises doit avoir accumulé entre 420 et 700 heures d’emploi assurable dans la PR. Le nombre exact d’heures requis aux fins de l’admissibilité varie selon la norme variable d’admissibilité (NVA) de la région économique du client qui est en vigueur la semaine du DPP . Quand le lieu de résidence du client est si rapproché de la frontière d’une région économique qu’il devient impossible de savoir lequel des 2 taux régionaux de chômage (TRC) s’applique, le TRC le plus élevé est utilisé.
       [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0844.dita) 

**PPNE**

Quand un client ne remplit pas les conditions requises d’admissibilité, une PP ne peut pas être établie et la demande est PPNE.
       [PP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations)

Les demandes sont PPNE dans 3 situations :

- Le client n’a pas assez d’heures d’emploi assurable (N1, N5, N6, N7).

- Il n’y a pas eu d’ A de R (N8).
         [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration)

- Le dernier RE manque (N2).

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0845.dita) 

**Organigramme — Conditions requises pour l’établissement d’une PP pour des prestations régulières**

**Demandes PPNE — Norme d’admissibilité commune (de la s/c 2310 à la s/c 2361)**

Dans le cadre du budget 2021, le gouvernement du Canada a annoncé qu’une norme d’admissibilité commune nationale de 420 heures d’emploi assurable s’applique pour établir une demande de prestations régulières ou spéciales. Si le client a une violation à son dossier, une majoration des conditions requises pourrait s’appliquer. La norme d’admissibilité commune s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, une demande avec moins de 420 heures est finalisée PPNE N1. S’il y a une violation au dossier et que le client ne respecte pas la majoration des conditions requises, la demande est finalisée PPNE N5.
       [majoration des conditions requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Majoration_nombre_dheures_demploi_ass_r)

**Majoration des conditions requises**

Des violations sont imposées dans des cas de fraude. Si on détermine que le client, ou la personne agissant en son nom, a sciemment produit une déclaration fausse ou frauduleuse qui a entraîné un T-P, une violation peut être imposée sur la demande visée.

Le client qui a été sanctionné au moins une fois d’une violation dans les 260 semaines (5 ans) qui précèdent sa demande initiale de prestations est assujetti à la majoration du nombre des conditions requises en vue de son admissibilité aux prestations.

La valeur totale, réelle ou potentielle, du trop-payé détermine la classification de la violation de la façon suivante :

```text
| Montant du trop-payé | Classification de la violation |

| Moins de 1 000 $ | Mineure |

| Entre 1 000 $ et 4 999 $ | Grave |

| 5 000 $ et plus | Très grave |

| Deuxième violation ou violation subséquente | Subséquente |
```

Selon la catégorie de la violation, les conditions requises sont majorées de la façon suivante :

- violation mineure : 25 %

- violation grave : 50 %

- violation très grave : 75 %

- violation subséquente : 100 %

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0846.dita) 

**Majoration des conditions requises — Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)**

Une mesure temporaire du budget 2021 s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Selon la norme d’admissibilité commune, un client a besoin de 420 heures d’emploi assurable dans sa période de référence (PR) pour remplir les conditions requises pour recevoir des prestations régulières et spéciales, sauf s’il y a une violation au dossier.

Quand une violation est au dossier, la majoration des conditions requises pour recevoir des prestations régulières et spéciales est la suivante, peu importe le taux régional de chômage (TRC) :

1 - Violation mineure = 525 heures

2 - Violation grave = 630 heures

3 - Violation très grave = 735 heures

4 - Violation subséquente = 840 heures

**Majoration des conditions requises**

Il faut considérer les 4 éléments suivants lors de la détermination de la majoration des conditions requises dans une demande :

- la classification de la violation

- les 260 semaines qui précèdent le DPP
         [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations)

- la norme variable d’admissibilité (NVA)
         [norme variable d’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Norme_variable_dadmissibilite)

- les infractions précédemment commises

**Non-considération de la majoration des conditions requises**

La majoration des conditions requises n’est pas considérée dans l’une ou l’autre des situations suivantes :

- L’avis de violation a été émis plus de 260 semaines avant la date à laquelle la demande de prestations initiale a été présentée.

- 2 demandes initiales de prestations ont été établies depuis la date à laquelle l’avis de violation a été émis.

Les demandes pour la PU AE ne sont pas considérées comme des demandes d’AE établies qui permettent au client d’être exempté d’une majoration des conditions requises.

Une violation qualifiée de « subséquente » le demeure pendant les 260 semaines (5 années) qui suivent la date à laquelle elle est ainsi qualifiée ou jusqu’à l’établissement de 2 périodes de prestations subséquentes, selon la plus courte de ces 2 périodes.

Une violation qualifiée de « subséquente » ne peut pas changer de catégorie, à moins qu’elle ne soit infirmée ou annulée suite à un nouvel examen de la décision. Quand une violation antérieure est annulée suite à un nouvel examen de la décision, la violation subséquente est qualifiée à nouveau, devenant une première violation.

**Client remplissant à nouveau les conditions requises**

Quand un client démissionne sans motif valable ou est congédié en raison d’inconduite, les heures d’emploi assurables sont exclues et le client doit travailler le nombre d’heures d’emploi assurable requis après l’imposition de l’exclusion pour avoir droit de nouveau aux prestations.

Dans le cas d’un client qui n’a pas accumulé assez d’heures d’emploi assurable pour que l’exclusion soit enlevée, la demande de prestations est établie à l’aide de toutes les heures d’emploi assurable dans la PR et une exclusion 10 - Congédiement - inconduite prouvée (D10) ou 11 - Abandon volontaire - motif valable non prouvé (D11) est imposée.

Un client qui a accumulé suffisamment d’heures d’emploi assurable depuis l’évènement ayant entraîné l’exclusion pour établir une période de prestations (PP) est considéré comme un client remplissant à nouveau les conditions requises et aucune exclusion n’est imposée.
       [période de prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations)

Une fois qu’il est établi que le client remplit à nouveau les conditions requises, le système calcule les heures d’emploi assurable dans la PR à l’aide des données à cet égard figurant dans les RE sans tenir compte de celles liées au départ volontaire sans motif valable ou au congédiement en raison d’inconduite.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0847.dita) 

**Calcul du taux de prestations**

Le taux de prestations pour les demandes de prestations régulières et spéciales est déterminé selon toutes les rémunérations assurables de tous les RE dans la PR . La rémunération assurable provenant de la pêche est comprise, mais la rémunération provenant d’un emploi que le client a volontairement quitté sans motif valable ou d’un emploi duquel le client a été congédié en raison d’une inconduite est exclue.
       [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

Quand le client ne peut pas être admissible de nouveau, car il n’a pas accumulé assez d’heures assurables depuis un incident entraînant l’exclusion, tous les RE dans la PR sont utilisés pour déterminer le taux de prestations. Pour déterminer le taux de prestations, l’agent utilise aussi les RE provenant d’un emploi que le client a volontairement quitté sans motif valable ou d’un emploi duquel le client a été congédié en raison d’une inconduite.

L’agent utilise le principe des meilleures semaines variables (MSV) pour déterminer la rémunération assurable hebdomadaire moyenne. Si la rémunération assurable hebdomadaire moyenne dépasse la rémunération assurable hebdomadaire maximale , le taux est obtenu en multipliant la rémunération assurable hebdomadaire maximale par 55 % du taux de base ou par 33 % du taux réduit. Si la rémunération assurable hebdomadaire moyenne ne dépasse pas la rémunération assurable hebdomadaire maximale, le taux est obtenu en multipliant la rémunération assurable hebdomadaire moyenne par 55 % pour le taux de base ou par 33 % pour le taux réduit.
       [meilleures semaines variables (MSV)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#msv) 
       [rémunération assurable hebdomadaire maximale](/fr/procedure/generic/additionalresources/max_ben_rate_mwie.shtml#_Tableau_de_la)

Le supplément familial (SF) peut augmenter le taux de prestations. Toutefois, le taux de prestations ne peut pas dépasser le taux de prestations maximal .
       [supplément familial](/fr/procedure/activity/family_supplement.shtml) 
       [taux de prestations maximal](/fr/procedure/generic/additionalresources/max_ben_rate_mwie.shtml)

Un taux de prestations minimal s’applique à toutes les demandes dans les périodes suivantes :

- Pour les demandes dont le DPP est entre la s/c 2258 et la s/c 2309, le taux de prestations minimal est de 300 $ pour les prestations parentales prolongées et de 500 $ pour tous les autres GP. Si le client est admissible au SF, ce montant est ajouté au taux de prestations minimal.

- Pour les demandes dont le DPP est entre la s/c 2310 et la s/c 2317, le taux de prestations minimal est de 180 $ pour les prestations parentales prolongées et de 300 $ pour tous les autres GP. Si le client est admissible au SF, ce montant est ajouté au taux de prestations minimal.

**Meilleures semaines variables (MSV)**

Selon la rémunération comprise dans le calcul du taux de prestations, le principe des MSV utilise la rémunération provenant des semaines qui correspondent au revenu le plus élevé dans la PR pour calculer la rémunération assurable hebdomadaire moyenne. Pour les clients qui ont des régimes de travail irréguliers, le taux de prestations pourrait être plus élevé et mieux correspondre aux conditions de la région économique. Le nombre de semaines utilisé varie de 14 à 22 et est basé sur le dénominateur régional. Si le nombre de semaines avec une rémunération est inférieur au dénominateur, toutes les semaines sont comprises. La rémunération totale des semaines qui sont comprises est divisée par le dénominateur afin d’obtenir la rémunération assurable hebdomadaire moyenne.

Quand un client a une rémunération provenant de la pêche dans la PR, l’agent ne considère que les semaines de rémunération régulière pour déterminer les MSV. Une fois que les semaines de rémunération régulière ont été précisées, toute rémunération provenant de la pêche qui chevauche la PR est ajoutée au total des MSV.

Quand le client ne fournit pas de MSV ou qu’il fournit un nombre de semaines inférieur au dénominateur, la rémunération assurable hebdomadaire moyenne est calculée en fonction de la moyenne proportionnelle des RE, ou de la moyenne proportionnelle en plus des renseignements sur les MSV fournis par le client. CAC vérifie le fichier historique des transactions afin de déterminer quelles sont les MSV de rémunération dans la PR. CAC pourrait trouver des MSV qui diffèrent de celles fournies par le client, s’il y a des semaines dont la rémunération assurable est plus élevée. La somme des MSV qui est déterminée par CAC est la rémunération assurable totale utilisée pour calculer le taux de prestations.

**Incidences de la rémunération assurable sur les MSV**

```text
| Genre de rémunération assurable | Incidences de la rémunération sur les MSV |

| Paie de vacances ou primes de quart | Le calcul des MSV comprend la rémunération accumulée de tous les emplois assurables au cours d’une semaine civile, y compris le pourcentage versé à chaque période de paie à titre de paie de vacances qui correspond à cette semaine civile en question, ainsi que les primes de quart. Quand une période de vacances est prise et qu’elle est payée, elle est répartie sur la période de paie pour laquelle le versement est effectué. Si les semaines font partie de la PR, elles peuvent être utilisées pour déterminer les MSV. |

| Sommes attribuées à la période de paie pour laquelle elles sont versées | Les sommes attribuées à la période de paie pour laquelle elles sont versées, comme les primes, les pourboires contrôlés ou la paie de vacances sans période de congé peuvent être utilisés pour déterminer les MSV si les semaines font partie de la PR. |

| Indemnités de cessation d’emploi assurables | Quand l’agent détermine le montant de la rémunération au cours d’une semaine civile afin de déterminer les MSV, il ne considère pas les indemnités de cessation d’emploi assurables. Le montant de compensation d’indemnités de cessation d’emploi assurable supplémentaires à inclure dans le total de la rémunération assurable pour la période du calcul doit correspondre au montant le moins élevé entre : - le montant réel versé en indemnités de cessation d’emploi assurables; - 18 % de la rémunération totale au cours des MSV utilisées dans le calcul du taux de prestations qui provient de l’emploi donnant lieu à des indemnités de cessation d’emploi assurables. |

| Commissions | Quand la rémunération du client se compose uniquement de commissions, ou d’un salaire et de commissions versées à intervalles irréguliers, la rémunération assurable est répartie proportionnellement sur la plus courte période de ces 2 options : la période d’emploi ou les 52 dernières semaines. Les clients qui sont rémunérés ainsi constituent une exception à la règle de la répartition proportionnelle par période de paie. Bien que le calcul des MSV s’applique, ces clients ne pourront pas en profiter pleinement, car la rémunération de cet emploi sera la même chaque semaine. |
```

**Supplément familial (SF)**

Le supplément familial (SF) permet aux clients admissibles de familles à faible revenu de recevoir un montant supplémentaire qui est ajouté à leurs taux de prestations.

Le SF peut faire augmenter le taux de prestations d’un client jusqu’à 80 % de ses gains assurables. Au fur et à mesure que le revenu familial du client augmente, le montant du SF diminue. Quand le revenu familial net maximal est 25 921 $, aucun supplément n’est versé. En incluant le SF, le taux de prestations du client ne peut pas dépasser le taux de prestations maximal.

Un client est admissible au SF si toutes les conditions suivantes sont remplies :

- Le client ou son conjoint a reçu l’Allocation canadienne pour enfants au cours du mois précédant la date à laquelle il présente une demande de prestations.

- Le revenu familial net au cours de l’année d’imposition de base ne doit pas dépasser 25 921 $.

- Le conjoint ne reçoit pas déjà le SF.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0110.dita) 

L’admissibilité au SF est établie selon le versement de l’Allocation canadienne pour enfants et non selon l’admissibilité à l’Allocation canadienne pour enfants. Par conséquent, si pour quelque motif que ce soit l’Agence du revenu du Canada cesse de verser l’Allocation canadienne pour enfants, le taux de prestations du client reviendra au taux de base sans le SF.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0848.dita) 

Même si les 2 conjoints sont admissibles pour recevoir le SF, ce dernier est versé à un seul des conjoints à la fois. Si les 2 conjoints demandent des prestations d’AE le même jour, le SF est automatiquement attribué à la première demande établie. Les conjoints peuvent décider lequel des 2 recevra le SF en demandant un transfert. Le client qui reçoit le SF doit présenter la demande.

**Délai de carence (DC)**

Le DC est une période d’une semaine où aucune prestation n’est versée au client. Cette disposition peut être comparée à la disposition de franchise des polices d’assurance-incendie et d’assurance-automobile, en vertu desquelles la personne assurée est censée assumer une partie des dommages ou de la perte. Le DC est observé pendant la première semaine civile au cours de laquelle, sans le DC, des prestations auraient été payables au client.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0849.dita) 

Quand on détermine si des prestations auraient été payables au client, il faut prendre en considération d’autres facteurs comme des jours de non-disponibilité, des inadmissibilités, des heures travaillées et de la rémunération (déclarée ainsi que répartie).

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0850.dita) 

Les sommes réparties qui sont considérées comme une rémunération pendant le DC sont déduites des premières semaines de prestations payables. Le même principe s’applique aux jours d’inadmissibilité qui sont convertis en rémunération à cette fin. Pour obtenir de plus amples renseignements, l’agent peut consulter Rémunération et inadmissibilité pendant le délai de carence .
       [Rémunération et inadmissibilité pendant le délai de carence](/fr/procedure/generic/additionalresources/earnings_disentitlements_wp.shtml)

Dans certains cas, le DC peut également être supprimé ou reporté.

**Supprimer le délai de carence (DC)**

Le DC peut parfois être annulé si le client en tire avantage. Le DC peut être supprimé si les conditions suivantes sont remplies :

- Une période de prestations (PP) a été établie en fonction d’un A de R en raison d’une maladie, d’une blessure, d’une mise en quarantaine, d’une grossesse, de la nécessité de s’occuper d’un nouveau-né ou d’un enfant adopté ou de la nécessité de s’occuper d’un membre de famille gravement malade.
         [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration)

- Après son dernier jour de travail, le client reçoit des prestations du RQAP ou a des congés de maladie payés (CMP) par le même employeur que celui pour lequel il travaillait lors de son A de R.

**Projet pilote 24 : Supprimer le délai de carence (DC) pour les DPP entre le 30 mars 2025 et le 10 octobre 2026 (la s/c 2493 à la s/c 2572)**

Une mesure temporaire pour supprimer le DC d’une semaine a été mise en œuvre pour soutenir les clients touchés par des changements majeurs dans la conjoncture économique en raison de l’imposition de droits de douane par les États-Unis. Le DC est supprimé pour toutes les demandes initiales dont le DPP est entre le 30 mars 2025 (s/c 2493) et le 10 octobre 2026 (s/c 2572), peu importe le GP demandé. S’il est avantageux pour le client, le client peut décider d’observer le DC (p. ex. le client doit observer le DC pour recevoir des PSC).

La suppression du DC est automatiquement appliquée à toutes les demandes, sauf les demandes de prestations spéciales dans lesquelles il y a un code de PSC. L’agent doit vérifier et saisir le code de PSC. Lors d’un nouveau calcul d’une demande quand la seule modification est d’ajouter ou de supprimer le régime de PSC du RE, le résultat du calcul indiquera APC - Aucun changement . Dans ce cas, l’agent saisit ou supprime manuellement la suppression du DC.

Un client qui a présent é une demande, remplit les conditions requises et peut recevoir des prestations avant le 30 mars 2025 (s/c 2493) ne peut pas demander de postdater la date de début de sa demande dans le seul but de bénéficier de cette mesure temporaire.

Un client pourrait demander que sa demande commence dans la semaine dans laquelle il a présenté la demande de prestations quand les 2 conditions suivantes sont remplies :

- Le client présente une demande le 30 mars 2025 (s/c 2493) ou après.

- La Politique administrative est appliquée et entraîne un DPP avant le 30 mars 2025 (s/c 2493).

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0851.dita) 

**Reporter le délai de carence (DC)**

Le DC peut être reporté quand plus d’un client présente une demande pour les prestations spéciales suivantes pour le même enfant ou membre de la famille gravement malade :

- Prestations parentales

- PDC

- Prestations pour proches aidants

Un seul DC doit être observé par les clients, ce qui a généralement lieu dans la première demande établie (par un parent, un parent adoptif ou un membre de la famille). Le DC est alors reporté pour le deuxième client qui partage les prestations. Cependant, une fois que l’admissibilité à ces prestations se termine, si le client demande un autre GP, le DC doit alors être observé.

Avant de reporter le DC, l’agent confirme que les conditions de report sont remplies. L’agent doit examiner le dossier de l’autre parent ou du membre de famille afin de déterminer si le client remplit les conditions requises pour un report du DC. Cette validation est autorisée en vertu des règlements sur la protection des renseignements personnels, car le dossier est examiné pour l’administration du programme d’AE.

Pour des prestations parentales, si les renseignements sur l’autre parent n’ont pas été fournis dans la demande d’AE, l’agent effectue un recueil de faits pour les obtenir. Si les renseignements sur l’autre parent ne peuvent être obtenus, la raison doit être consignée dans un RSDP.

Pour les demandes subséquentes, le DC peut être reporté seulement quand les conditions suivantes sont remplies:

- Le client demande des prestations parentales .

- Le client a déjà observé le DC pour cette naissance, pour l’adoption ou pour ce placement.

Cette situation se produit quand le même client établit une demande subséquente à celle pour laquelle le DC a été observé pour les raisons mentionnées ci-dessus, et ce afin de recevoir le solde des prestations payables pour ce GP.

L’agent examine la demande du client et le dossier de l’autre parent ou du membre de famille pour déterminer si le client remplit les conditions requises pour un report du DC. De plus, l’agent détermine si reporter le DC est à l’avantage du client (p. ex. le client a un régime de PSC ou il est admissible pour avoir le DC supprimé).

Si le client demande un autre GP après que son admissibilité à ces prestations spéciales prend fin, il doit alors observer le DC.

Il en est de même en cas de prestations pour TP. Le report du DC ou de sa partie non observée aura lieu en cas de demande de prestations pour TP. Cependant, si une autre demande de prestations est présentée après la fin de l’entente de TP, le DC ou sa partie non observée doit alors être observé.

Si le DC a été annulé pour le premier client pour des prestations parentales, PDC ou prestations pour proches aidants, le deuxième client ne peut pas reporter le DC parce que ce dernier n’a pas déjà été observé relativement au même enfant ou membre de la famille malade. Le deuxième client peut toutefois remplir les conditions qui lui permettent d’annulation du DC.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0657.dita) 

**Client admissible aux prestations spéciales seulement**

Si un client de première catégorie , n’ayant pas commis de violation, présente une demande de prestations régulières et la demande est PPNE, le client ne peut pas convertir sa demande en prestations spéciales (p. ex. prestations de maladie). Il doit présenter une nouvelle demande de prestations. Cela signifie que la date la plus antérieure du nouveau DPP serait celle où le client aurait été admissible aux prestations spéciales. La fin de la PR change à la semaine avant ce nouveau DPP, et non pas à la fin de la PR originale de la demande PPNE. En fonction de la nouvelle PR, il faut déterminer si le client fait toujours partie de la première catégorie (qu’il a au moins 600 heures assurables dans la PR) et par conséquent, qu’il est admissible à des prestations spéciales.
       [première catégorie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#client12) 
       [prestations spéciales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_speciales) 
       [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

Si le client reste PPNE, mais qu’il est admissible aux prestations spéciales, on impose une inadmissibilité administrative pour empêcher le versement des prestations régulières.

**Inadmissibilité 46 - Période de prestations non établie (PPNE) 5**

L’agent impose une inadmissibilité administrative 46 - Ne rencontre pas la norme variable - prestations spéciales payables (D46) pour empêcher le versement de prestations régulières d’AE à un client N5 qui présente une demande pour des prestations spéciales et qui a accumulé au moins 600 heures d’emploi assurable dans la PR.

Bien que le client N5 puisse travailler par la suite et accumuler un nombre suffisant d’heures d’emploi assurable pour remplir les critères mentionnés au RAE 93(5)(a) , des prestations régulières ne sont pas payables , car le client n’y est pas admissible.
       [RAE 93(5)(a)](http://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-93.html)

**Inadmissibilité 46 - Période de prestations non-établie (PPNE) N5 : Norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)**

Une mesure temporaire du budget 2021 s’applique aux demandes de prestations régulières et spéciales dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, toutes les demandes établies avec 420 heures d’emploi assurable ou plus sont qualifiées pour des prestations spéciales, et aucune inadmissibilité D46 n’est imposée.

**Prestations régulières**

Les prestations régulières de l’AE fournissent au travailleur se retrouvant involontairement au chômage des moyens de subsistance temporaire.

**Conditions requises pour les prestations régulières**

Pour remplir les conditions requises pour recevoir des prestations régulières, un client doit :

- avoir présenté une demande de prestations;

- avoir subi un A de R dans sa PR ;
         [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration) 
         [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

- avoir accumulé le nombre requis d’heures d’emploi assurable dans la PR pour faire établir une période de prestations (PP). Si le client a une violation à son dossier, la majoration des conditions requises pourrait s’appliquer;
         [nombre requis d’heures d’emploi assurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Majoration_nombre_dheures_demploi_ass_r) 
         [période de prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations)

**Critères d’admissibilité aux prestations régulières**

Pour être admissible aux prestations régulières, le client doit :

- être prêt et disposé à travailler et capable de le faire;

- être au Canada (la liste des exceptions se trouve dans RAE 55 ).
         [RAE 55](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

**Nombre de semaines d’admissibilité aux prestations régulières**

Le nombre de semaines de prestations régulières payables (admissibilité) est déterminé en fonction :

- du nombre d’heures d’emploi assurable dans la PR; et

- du taux régional de chômage (TRC) de la région où habite le client au DPP .
         [taux régional de chômage](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Taux_de_chomage_regional) 
         [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations)

Pour plus de renseignements sur l’admissibilité maximale aux prestations dans une PP, l’agent peut consulter Admissibilité maximale aux prestations .
       [Admissibilité maximale aux prestations](/fr/procedure/generic/additionalresources/max_ent_ben.shtml)

Les prestations payables doivent être reçues pendant la période de prestations (PP). Une fois que les semaines d’admissibilité sont établies, une semaine de prestations régulières est payable pour chaque semaine où le client :
       [période de prestations](/fr/procedure/generic/knowledge.shtml#Periode_de_prestations)

- est en chômage;

- est prêt et disposé à travailler et capable de le faire;

- n’a pas reçu de rémunération ou d’autres sommes suspendant le versement des prestations;

- n’est pas visé par une inadmissibilité ou une exclusion suspendant le versement des prestations.

Pour prouver que des prestations sont payables, le client doit remplir des déclarations du prestataire. Le client qui reçoit des prestations régulières et qui suit un cours approuvé d’apprentissage pour lequel il a obtenu l’approbation, pourrait participer à l’exemption de remplir des déclarations du prestataire.

**Prestations spéciales**

- prestations de maternité
         [prestations de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_de_maternite)

- prestations parentales
         [prestations parentales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_parentales)

- prestations de maladie
         [prestations de maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_de_maladie)

- prestations de compassion (PDC)
         [prestations de compassion (PDC)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_de_compassion)

- prestations pour parents d’enfants gravement malades (PEGM)
         [prestations pour parents d’enfants gravement malades (PEGM)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_pour_parents_denfants_grave)

- prestations pour proches aidants
         [prestations pour proches aidants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#PProchesAidants)

**Prestations de maternité**

Pour les résidents du Québec, consulter RQAP .
       [RQAP](https://www.rqap.gouv.qc.ca/)

Les prestations de maternité sont versées à titre de compensation pour une période d’invalidité physique empêchant de travailler et associée à la grossesse et à l’accouchement.

**Conditions requises pour les prestations de maternité**

Pour remplir les conditions requises pour recevoir des prestations de maternité, une cliente doit :

- avoir présenté une demande de prestations;

- avoir subi un A de R dans sa PR ;
         [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration) 
         [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

- être de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable. Si la cliente a une violation à son dossier, la majoration des conditions requises pourrait s’appliquer;
         [majoration des conditions requises pourrait s’appliquer;](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Majoration_nombre_dheures_demploi_ass_r)

**Critères d’admissibilité aux prestations de maternité**

Pour être admissible aux prestations de maternité, une cliente doit :

- fournir une preuve de grossesse;

- présenter la demande de prestations dans la fenêtre de maternité.

**Preuve de grossesse**

Pour prouver sa grossesse, la cliente doit :

- présenter une déclaration signée (son attestation à la fin de sa demande présentée en ligne équivaut à sa signature) qui atteste sa grossesse et qui précise sa date prévue de l’accouchement;

- informer Service Canada de la date réelle de l’accouchement le plus tôt possible après la naissance de l’enfant.

**Fin de grossesse**

Si la grossesse prend fin dans les 19 premières semaines de gestation, la demande est traitée comme une demande de prestations de maladie. Toutefois, si la grossesse prend fin après la 19e semaine de gestation, la demande est traitée comme une demande de prestations de maternité.

**Nombre de semaines d’admissibilité aux prestations de maternité**

Les prestations de maternité peuvent être versées jusqu’à concurrence de 15 semaines dans une même période de prestations (PP). Toutefois, ces 15 semaines payables pour une seule et même grossesse peuvent s’étendre sur 2 PP.
       [période de prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations)

Pour prouver que des prestations sont payables, le client doit remplir des déclarations du prestataire. La cliente recevant des prestations de maternité pourrait être exemptée de remplir des déclarations du prestataire.

**Fenêtrede maternité**

La fenêtre de maternité est la période pendant laquelle les prestations de maternité peuvent être payées. La fenêtre commence à la première des dates suivantes :

- 12 semaines avant la date prévue de l’accouchement (date prévue de l’accouchement – 12 semaines);

- la date réelle de l’accouchement.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0852.dita) 

La fenêtre de maternité prend fin à la plus tardive des dates suivantes :

- 17 semaines après la date prévue de l’accouchement (date prévue de l’accouchement + 17 semaines);

- 17 semaines après la date réelle de l’accouchement (date réelle de l’accouchement + 17 semaines).

**Prolongation de lafenêtrede maternité**

La fenêtre de maternité peut être prolongée quand un nouveau-né est hospitalisé durant cette période. La prolongation est équivalente au nombre de semaines d’hospitalisation de l’enfant, jusqu’à un maximum de 52 semaines après la date réelle de l’accouchement (date réelle de l’accouchement + 52 semaines). Toutefois, le nombre de semaines de prestations de maternité payables n’est pas augmenté.

**Demander des prestations de maternité**

Normalement, une demande de prestations de maternité ne peut pas être établie en dehors de la fenêtre de maternité. Cependant, une cliente peut établir une PP pour des prestations de maternité avant la fenêtre de maternité si les conditions suivantes sont remplies :

- La cliente est admissible aux prestations régulières.

- La cliente demande des prestations de maternité dès le début de la demande.

- La cliente observera un DC immédiatement avant le début de la fenêtre de maternité.

Quand ces conditions sont remplies, la cliente peut observer le DC dans la période immédiatement avant la fenêtre de maternité.

**Prestations de maternité et de maladie**

La cliente qui n’est pas en mesure de travailler en raison de son état de santé découlant de la grossesse peut choisir de présenter une demande de prestations de maladie avant celle de prestations de maternité. Si, pendant la durée de la demande, aucune prestation régulière n’est réclamée, la cliente est admissible à la prolongation de la PP qui lui permettra de recevoir toutes les prestations de maternité et parentales.
       [prolongation de la PP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prolongation_de_la_PP)

Afin de recevoir des prestations de maladie, la cliente doit prouver qu’elle serait disponible pour travailler si ce n’était de sa maladie pour la période au cours de laquelle elle souhaite recevoir des prestations de maladie. Cette condition risque d’être difficile à remplir si la cliente a déjà prévu, de concert avec son employeur, de commencer son congé de maternité avant ou pendant la période pour laquelle elle demande des prestations de maladie. Une vérification auprès de l’employeur est peut-être nécessaire.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0853.dita) 

**Prestations parentales**

Pour les résidents du Québec, consulter RQAP .
       [RQAP](https://www.rqap.gouv.qc.ca/)

Les prestations parentales sont offertes aux parents afin qu’ils puissent prendre soin d’un nouveau-né ou d’un enfant adopté. Les prestations peuvent être versées à l’un ou l’autre des parents biologiques ou adoptifs ou être partagées entre les parents. Les clients peuvent également être admissibles aux prestations parentales dans les circonstances suivantes :

- Ils sont parents adoptifs ou ils ont la garde temporaire ou permanente d’un enfant et ils ont démontré leur engagement à l’adoption. Consulter Parents adoptifs — Nouvelle politique en vigueur le 1 janvier 2012 pour plus d’information.
         [Parents adoptifs — Nouvelle politique en vigueur le 1 janvier 2012](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Parents_adoptifs_Nouvelle_politique_en)

- Ils sont dans une union homosexuelle et ils sont soit reconnus légalement (sur le certificat de naissance émis par la province) comme l’autre parent de l’enfant ou ils ont amorcé le processus d’adoption.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0854.dita) 

**Conditions requises pour les prestations parentales**

Pour remplir les conditions requises pour recevoir des prestations parentales, un client doit :

- avoir présenté une demande de prestations;

- avoir subi un A de R dans sa PR ;
         [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration) 
         [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

- être de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable. Si le client a une violation au dossier, la majoration des conditions requises pourrait s’appliquer;
         [majoration des conditions requises pourrait s’appliquer;](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Majoration_nombre_dheures_demploi_ass_r)

**Critères d’admissibilité aux prestations parentales**

Pour être admissible aux prestations parentales, un client doit :

- fournir une preuve de naissance, d’adoption ou de placement;

- présenter la demande de prestations dans la fenêtre parentale (FP);

- s’occuper de l’enfant.

**Parents adoptifs**

En plus des critères d’admissibilité énumérés ci-dessus, les critères suivants doivent être remplis à compter de la date du placement :

- L’enfant a été physiquement confié au client.

- Le client démontre son engagement à adopter l’enfant en vertu des lois régissant l’adoption dans sa province ou son territoire de résidence.

Quand l’adoption n’a pas pu être finalisée :

- L’admissibilité aux prestations parentales se termine le premier dimanche suivant le retrait de l’enfant du foyer d’accueil.

- Les clients ne sont pas tenus de rembourser les prestations qu’ils ont reçues pendant qu’ils avaient la garde de l’enfant.

Le client n’est pas admissible aux prestations parentales si l’enfant ne peut pas être légalement adopté, à moins que le client affirme croire que le placement est permanent et qu’il a l’intention d’adopter l’enfant placé sous sa garde.

Si l’enfant est rendu à la garde de son parent biologique, le parent biologique peut être admissible aux prestations parentales s’il remplit les critères d’admissibilité.

**Parents légalement reconnus**

Le client qui n’est pas le parent biologique ni adoptif de l’enfant peut quand même être reconnu comme étant le parent légal de l’enfant (p. ex. le parent non biologique dans une relation homosexuelle). Si ce client est reconnu à titre de parent légal de l’enfant sur le certificat de naissance provincial ou territorial, le client est admissible aux prestations parentales, si les critères d’admissibilité pour établir la demande sont remplis.

Le client n’est pas admissible aux prestations parentales si le client n’est pas reconnu par la province comme étant un parent légal sur le certificat de naissance, à moins que le processus d’adoption n’ait débuté.

**Preuve de naissance, d’adoption ou de placement**

Les parents doivent fournir une preuve de naissance, d’adoption ou de placement selon leur lien à l’enfant ou aux enfants. Pour plus de renseignements, l’agent peut consulter Parents : Définition — Tableau .
       [Parents : Définition — Tableau](/fr/procedure/generic/parents_definition_table.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0028.dita) 

L’agent impose une inadmissibilité indéfinie 34 - Prestations parentales conditions d’admissibilité non rencontrées (D34) si l’une des conditions suivantes s’applique :

- Il n’y a aucune preuve de placement en vue d’une adoption. Remarque : Si le client atteste qu’il considère le placement comme étant permanent et qu’il a l’intention d’adopter l’enfant, l’attestation est considérée comme une preuve suffisante.

- La DDN ou de placement de l’enfant n’est pas fournie.

- Le client ne prend pas soin de l’enfant.

**Placement quand l’enfant sous la garde du client ne peut pas être adopté légalement**

Dans certaines situations, l’enfant ne peut pas être légalement adopté au moment où il est placé sous la garde du client. Les prestations parentales peuvent être versées à un client qui atteste que c’est son intention d’adopter un enfant placé sous sa garde par un organisme reconnu parce que les circonstances ne permettent pas aux parents légalement reconnus de prendre soin de l’enfant. Une attestation verbale que le client croit que le placement est permanent et qu’il a l’intention d’adopter l’enfant est une preuve acceptable.

Quand l’enfant ne peut pas être adopté légalement à la date de placement, l’agent peut, à tout moment, demander au client de fournir une preuve que l’enfant pour lequel il demande des prestations parentales a été placé sous sa garde par un organisme reconnu.

**Genre de prestations parentales**

Les prestations parentales sont payables soit comme prestations parentales standards au taux de base, soit comme des prestations parentales prolongées à un taux réduit. Le client choisit le genre de prestations parentales qu’il veut recevoir lors de sa demande de prestations parentales. Toutefois, si le premier parent à présenter sa demande de prestations a déjà choisi un genre de prestations parentales, l’autre parent doit choisir le même genre. Même si la demande du deuxième parent est antidatée à une date avant la demande du premier parent, le genre de prestations parentales choisi par le premier parent est le genre de prestations que les 2 parents recevront.

Le genre de prestations parentales choisi ne peut être modifié que si aucune prestation parentale n’a été versée au client ou à l’autre parent. Une fois que des prestations parentales ont été versées dans une demande (même si le versement est de 1 $), le choix du client de recevoir des prestations standards ou prolongées ne peut pas être modifié.

**Taux de prestations parentales**

Les prestations parentales standards sont payables à un taux de prestations de 55 % de la rémunération hebdomadaire assurable du client de première catégorie. Les prestations parentales prolongées sont payables à un taux de prestations de 33 % de la rémunération hebdomadaire assurable du client de première catégorie.

Le SF est calculé de la même manière pour les prestations parentales prolongées que pour les autres GP. Ce montant est ajouté au taux réduit pour les prestations parentales prolongées et peut augmenter le taux de prestations à son maximum de 55 % de la rémunération hebdomadaire assurable maximale. Le client qui reçoit des prestations parentales prolongées peut donc recevoir davantage de SF que le client qui reçoit des prestations parentales standards, car il est moins probable qu’il soit plafonné par le maximum hebdomadaire. De plus, un client qui reçoit des prestations parentales prolongées et qui est admissible pour le SF recevra ce montant plus longtemps et donc un montant plus élevé de SF lui sera versé au cours de la durée de la demande.

Un taux de prestations minimal s’applique à toutes les demandes dans les périodes suivantes :

- Pour les demandes dont le DPP est entre la s/c 2258 et la s/c 2309, le taux de prestations minimal est de 300 $ pour les prestations parentales prolongées et de 500 $ pour tous les autres GP. Si le client est admissible au SF, ce montant est ajouté au taux de prestations minimal.

- Pour les demandes dont le DPP est entre la s/c 2310 et la s/c 2317, le taux de prestations minimal est de 180 $ pour les prestations parentales prolongées et de 300 $ pour tous les autres GP. Si le client est admissible au SF, ce montant est ajouté au taux de prestations minimal.

**Admissibilité maximale**

Un client est admissible à un maximum de 35 semaines de prestations parentales standards ou de 61 semaines de prestations parentales prolongées pour chaque naissance ou placement pour adoption. Le nombre maximal de semaines d’admissibilité correspond au nombre maximal de semaines de prestations parentales qui peuvent être versées dans une PP. Les prestations parentales peuvent être versées pendant 2 PP, mais ne peuvent pas être versées en dehors de la fenêtre parentale (FP). Le nombre d’enfants nés en même temps (jumeaux, triplés, etc.) ou le nombre d’enfants adoptés en même temps n’a pas d’incidence sur le nombre de semaines de prestations parentales auxquelles un client a droit.

L’agent impose une inadmissibilité 35 - Prestations parentales conditions de qualification non rencontrées (D35) si l’une des situations suivantes est présente :

- Le client fait partie de la deuxième catégorie .
         [deuxième catégorie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#client12)

- La demande de prestations n’a pas été présentée dans la FP.

- Les prestations parentales sont épuisées.

- Le maximum du cumul des prestations spéciales (sans prestations régulières) a été payé (l’agent peut consulter Prolongation de la période de prestations pour des prestations spéciales pour le nombre total de semaines durant lesquelles des prestations combinées peuvent être versées).
         [prestations spéciales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Prestations_speciales) 
         [Prolongation de la période de prestations pour des prestations spéciales](/fr/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

- Le maximum du cumul de prestations régulières et de prestations spéciales a été payé. L’agent peut consulter Admissibilité maximale aux prestations .
         [Admissibilité maximale aux prestations](/fr/procedure/generic/additionalresources/max_ent_ben.shtml)

Pour prouver que des prestations sont payables, le client doit remplir des déclarations du prestataire. Un client recevant des prestations parentales peut demander d’être exempté de remplir des déclarations du prestataire.

Un DC peut être reporté si le client reçoit des prestations parentales.
       [DC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Delai_de_carence)

**Partage des prestations parentales**

Les parents peuvent partager les prestations parentales. Pour plus de renseignements et des définitions, l’agent peut consulter Parents : Définition — Tableau .
       [Parents : Définition — Tableau](/fr/procedure/generic/parents_definition_table.shtml)

Le genre de prestations parentales demandé par le premier parent qui a présenté une demande de prestations détermine le genre de prestations parentales auquel tous les parents sont admissibles pour la même naissance, adoption ou placement, quel que soit le parent qui est payé en premier. Lors du recueil de faits auprès des parents qui ont présenté une demande de prestations après le premier parent, l’agent informe les autres parents du genre de prestations auquel ils ont droit. Une fois qu’au moins une semaine de prestations parentales a été versée à l’un des parents, tous les parents demandant des prestations pour la même naissance, adoption ou placement ne sont admissibles qu’au genre de prestations parentales choisi par le premier parent qui a présenté une demande de prestations.

Le maximum de prestations parentales standards partageables est de 40 semaines ou de 69 semaines pour les prestations parentales prolongées pour un enfant né ou placé en une adoption le 17 mars 2019 ou après. Pour les enfants nés ou placés en adoption avant cette date, le maximum des prestations parentales standards partageables est de 35 semaines ou de 61 semaines pour les prestations parentales prolongées. L’admissibilité maximale des demandes de prestations standards pour un client demeure à 35 semaines ou à 61 semaines pour les prestations prolongées. Les clients peuvent modifier le nombre de semaines que chaque parent reçoit à tout moment avant que toutes les prestations ne soient versées. Quand les clients ne s’entendent pas sur le nombre de semaines que chacun recevra, l’agent réassigne la question à un agent de Niveau 2 qui rend une décision sur la division des semaines restantes

**Valider les prestations parentales partagées**

Un Dossier de clients des prestations parentales est créé pour chaque client demandant des prestations parentales. Le Dossier de clients des prestations parentales est constitué du NAS du client, de la semaine d’arrivée ou de placement (SAP) et du NAS de l’autre parent, s’il a été fourni. Une fois que la demande est finalisée, le système lie les Dossiers de clients des prestations parentales pour tous les clients qui partagent des prestations parentales pour le même enfant. Le processus de validation du partage des prestations parentales crée un AT Révision de la demande (RVD) Validation des prestations parentales quand l’une des conditions suivantes est remplie.

- Le genre de prestations parentales dans tous les Dossiers de clients des prestations parentales liés n’est pas le même.

- Le nombre total de semaines parentales demandées dans tous les Dossiers de clients des prestations parentales liés dépasse le nombre maximal de semaines de prestations parentales partageables.

**Fenêtre parentale**

La FP désigne la période pendant laquelle les prestations parentales peuvent être payées. La FP commence et se termine de la façon suivante :

- Semaine de début :

- La semaine d’arrivée ou de placement (SAP) est déterminée par le lien entre le parent et l’enfant. Pour plus de renseignements, l’agent peut consulter Parents : Définition — Tableau .
             [Parents : Définition — Tableau](/fr/procedure/generic/parents_definition_table.shtml)

- Semaine de fin :

- Pour les prestations parentales standards, la semaine de fin tombe 52 semaines après la SAP (SAP + 52);

- Pour les prestations parentales prolongées, la semaine de fin tombe 78 semaines après la SAP (SAP + 78).

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0855.dita) 

**Prolonger la période de prestations et la fenêtre parentale**

L’hospitalisation de l’enfant pour lequel les prestations parentales sont demandées est une raison suffisante pour prolonger la PP et la FP. La PP et la FP sont prolongées selon le nombre de semaines d’hospitalisation de l’enfant, jusqu’à une prolongation maximale de 52 semaines. La PP et la FP peuvent aussi être prolongées pour les membres des Forces canadiennes qui ne sont pas en mesure de recevoir leurs prestations parentales en raison d’une exigence militaire impérative. Pour plus de renseignements, l’agent peut consulter Prolongation de la période de prestations .
       [Prolongation de la période de prestations](/fr/procedure/activity/extension_benefit_period.shtml)

La FP est aussi prolongée quand un client qui est admissible aux prestations parentales est admissible à une prolongation de la PP pour des prestations spéciales. Dans ce cas, la PP et la FP sont prolongées. Pour plus de renseignements, l’agent peut consulter Période de prestations : Prolonger pour des prestations spéciales — Tableau .
       [Période de prestations : Prolonger pour des prestations spéciales — Tableau](/fr/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

**Terminer des prestations parentales durant la FP — Les conditions d’admissibilité ne sont plus remplies**

Le client doit remplir les conditions d’admissibilité pour chaque semaine de prestations parentales demandée. Si l’agent est informé que le client ne prend plus soin de l’enfant pendant la FP, l’agent impose une inadmissibilité définie ou indéfinie D34 à compter du lundi suivant la semaine au cours de laquelle le client n’est plus admissible aux prestations. Pour plus de renseignements, l’agent consulte Déterminer l’admissibilité aux prestations parentales quand le client ne prend plus soin de l’enfant (Tâche) .
       [Déterminer l’admissibilité aux prestations parentales quand le client ne prend plus soin de l’enfant (Tâche)](/fr/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml)

**Prestations parentales et de maladie**

Peu importe la date de DPP , pour toutes les semaines de prestations de maladie demandées durant la semaine du 24 mars 2013 et après, le critère autrement disponible ne s’applique pas quand un client (y compris les pêcheurs) demande une conversion en prestations de maladie alors qu’il reçoit les prestations parentales d’AE ou du RQAP.
       [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations) 
       [autrement disponible](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Autrement_disponible_pour_travailler)

Le client doit fournir un certificat médical acceptable qui indique la date de début de l’incapacité et la durée probable de l’incapacité.
       [certificat médical acceptable](/fr/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

Un client qui est en congé parental de son emploi, mais qui n’a pas demandé des prestations d’AE ou de RQAP, doit tout de même prouver qu’il est autrement disponible ou qu’il serait autrement au travail pour être admissible aux prestations de maladie.

**Prestations de maladie**

Les prestations de maladie sont versées à une personne devenue incapable de travailler en raison d’une maladie, d’une blessure ou d’une mise en quarantaine et qui, si ce n’était de son état de santé, serait disponible pour travailler. Le client peut recevoir jusqu’à 26 semaines de prestations de maladie par PP quand le DPP est la s/c 2374 ou après et jusqu’à 15 semaines de prestations de maladie par PP quand le DPP est la s/c 2373 ou avant.

**Conditions requises pour les prestations de maladie**

Pour remplir les conditions requises pour recevoir des prestations de maladie, un client doit :

- avoir présenté une demande de prestations;

- avoir subi un A de R dans sa PR ;
         [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration) 
         [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

- être de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable;
         [première catégorie](/fr/procedure/generic/knowledge.shtml#client12)

- être de deuxième catégorie (a accumulé moins de 600 heures d’emploi assurable) qui a et avoir travaillé pendant la période minimale requise, selon la norme variable d’admissibilité au cours de la PR, pourvu que le plus récent MCE ne soit pas la maladie, une blessure ou une mise en quarantaine. Si le client a une violation à son dossier, la majoration des conditions requises pourrait s’appliquer;
         [deuxième catégorie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#client12) 
         [norme variable d’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Norme_variable_dadmissibilite) 
         [majoration des conditions requises pourrait s’appliquer;](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Majoration_nombre_dheures_demploi_ass_r)

**Critères d’admissibilité aux prestations de maladie**

Pour être admissible aux prestations de maladie, un client doit :

- fournir la preuve qu’il est incapable de travailler en raison de la maladie;

- fournir la preuve qu’il serait autrement disponible pour travailler.

**Preuve de l’état de santé du client**

**Demandes initiales**

Un certificat médical acceptable rempli par un médecin ou un autre professionnel de la santé approuvé confirmant la maladie du client doit être obtenu pour chaque semaine pour laquelle le client demande des prestations de maladie.
       [acceptable](/fr/procedure/task/determining_med_cert_valid.shtml)

Un client demandant des prestations de maladie à l’aide d’une demande papier est avisé qu’il doit présenter un certificat médical avec la demande. Un client qui présente une demande de prestations de maladie en ligne et qui indique que le MCE du dernier employeur est la maladie est avisé qu’il doit conserver le certificat médical pendant 6 ans puisqu’il peut être demandé à une date ultérieure. Un client présentant une demande de prestations de maladie en ligne et qui indique un MCE autre que la maladie est avisé qu’il doit présenter le certificat médical.

Un client n’a pas toujours besoin de présenter un certificat médical. L’agent doit demander un certificat médical seulement quand le client doit en présenter un. Toutefois, s’il en présente un, l’agent doit l’examiner pour s’assurer qu’il est acceptable et l’utiliser pour déterminer la semaine de guérison.

Un client n’ a pas besoin de présenter de certificat médical si toutes les conditions suivantes sont remplies :

- Le client est de première catégorie (p. ex. le client a travaillé au moins 600 heures d’emploi assurable).

- Le MCE sur le dernier RE est une maladie ou une blessure et le client demande soit des prestations de maladie ou des prestations de maladie combinées avec des prestations de maternité ou le client demande des prestations de maladie dans une demande initiale subséquente , et ce, immédiatement après avoir présenté une demande de renouvellement de prestations de maladie. De plus, le MCE est une maladie sur le dernier RE.

- Aucune des exclusions ou inadmissibilités suivantes ne s’applique à la demande, qu’elles aient été imposées à la suite d’une décision ou d’un report d’une décision sur un MCE litigieux :

- 10 - Congédiement - inconduite prouvée (D10)

- 11 - Abandon volontaire - motif valable non prouvé (D11)

- 42 - Suspension d’un emploi (D42)

- 43 - Congé sans solde (D43)

- 44 - Perte d’emploi anticipée (D44)

Le client doit présenter un certificat médical acceptable dans l’une ou l’autre des situations suivantes :

- Le client est de deuxième catégorie et le MCE pour la période d’emploi la plus récente n’ est pas maladie.

- Le MCE sur le dernier RE n’est pas une maladie.

- Une des exclusions ou inadmissibilités suivantes s’applique à la demande, qu’elles aient été imposées à la suite d’une décision ou d’un report d’une décision sur un MCE litigieux :

- D10

- D11

- D42

- D43

- D44

- Il y a un certificat médical au dossier qui n’est pas acceptable . Ceci s’applique même quand le MCE sur le dernier RE est une maladie ou une blessure et que le client demande soit des prestations de maladie ou des prestations de maladie combinées avec des prestations de maternité.
         [acceptable](/fr/procedure/task/determining_med_cert_valid.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0856.dita) 

**Demandes renouvelées**

Un client qui remplit une demande de renouvellement de prestations de maladie doit obtenir un certificat médical acceptable . Le certificat médical doit prouver l’incapacité du client. Quand le MCE est la maladie, le client est avisé qu’il doit conserver le certificat médical et le présenter sur demande, aux fins de traitement. Le client doit présenter le certificat médical dans l’une ou l’autre des situations suivantes :
       [certificat médical acceptable](/fr/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

- Le MCE pour la période d’emploi la plus récente n’est pas maladie ou blessure.

- Le client est de deuxième catégorie et le MCE pour la période d’emploi la plus récente n’ est pas maladie.

- Une des exclusions ou inadmissibilités suivantes s’applique, à la demande, qu’elles aient été imposées à la suite d’une décision ou d’un report d’une décision sur un MCE litigieux :

- D10

- D11

- D42

- D43

- D44

- L’admissibilité aux prestations régulières est épuisée et le client a demandé des prestations de maladie.

- Une inadmissibilité 16 - Certificat médical non fourni (D16) est imposée dans la demande, car un certificat médical a été demandé, mais n’a pas été présenté.

**Conversions des demandes continues**

**Conversions quand des prestations de maladie occasionnelle ont été payées**

Un client qui reçoit des prestations régulières, y compris des prestations de pêcheur, peut déclarer jusqu’à 4 semaines consécutives de prestations de maladie occasionnelle. Si le client déclare une cinquième semaine de maladie occasionnelle, la déclaration du prestataire est rejetée avec l’indicatif d’erreur C465. Si le client demande des prestations de maladie supplémentaires après 4 semaines consécutives déclarées, que les prestations aient été versées ou non, une conversion en une demande de prestations de maladie est requise.

Un maximum de 8 semaines de prestations de maladie occasionnelle au total peut être payé dans une PP. Si le client déclare une neuvième semaine de maladie occasionnelle, la déclaration du prestataire est rejetée avec l’indicatif d’erreur C484. Un client qui a déjà reçu 8 semaines de prestations de maladie occasionnelle et qui est toujours incapable de travailler doit présenter un certificat médical et demander la conversion de sa demande en prestations de maladie.

L’agent détermine le nombre de semaines de prestations de maladie occasionnelle versées dans une PP en consultant le champ Semaines de maladie occasionnelle à l’onglet Sommaire ou Prest. Spéciales dans ETI. Quand il détermine la semaine de guérison, l’agent doit utiliser uniquement le compteur de semaines de maladie occasionnelle pour obtenir le nombre de semaines de maladie occasionnelle versées.

**Certificat médical doit être présenté**

Un certificat médical doit être présenté pour un client demandant une conversion en prestations de maladie ou une prolongation de la période de maladie si l’une des conditions suivantes est remplie :

- La période de maladie est prolongée quand la période de maladie initiale a été approuvée sans présenter un certificat médical.

- Le maximum de 8 semaines de maladie occasionnelle a été payé.

- Une des exclusions ou inadmissibilités suivantes s’applique, à la demande, qu’elles aient été imposées à la suite d’une décision ou d’un report d’une décision sur un MCE litigieux :

- D10

- D11

- D42

- D43

- D44

- Le client demande des prestations de maladie pendant ou après la réception des prestations de maternité, parentales, du RQAP, prestations pour proches aidants ou des PDC.

- L’admissibilité aux prestations régulières est épuisée et le client a demandé des prestations de maladie.

- Le client est de deuxième catégorie (c.-à-d. que le client a travaillé moins de 600 heures assurables) et le MCE pour la période d’emploi la plus récente n’ est pas maladie.

- Une inadmissibilité D16 a été imposée dans la demande parce qu’un certificat médical a été demandé, mais qu’il n’a pas été présenté.

**Autrement disponible pour travailler**

Un client qui demande des prestations de maladie doit prouver que, n’eût été son invalidité, il serait disponible pour travailler.

Peu importe la date de DPP , pour toutes les semaines de prestations de maladie demandées durant la semaine du 24 mars 2013 et après, le critère autrement disponible ne s’applique pas quand le client (y compris les pêcheurs) demande une conversion en prestations de maladie alors qu’il reçoit des prestations parentales d’AE ou du RQAP. Par contre, un client qui est en congé parental de son emploi, mais qui ne reçoit pas de prestations d’AE ou de RQAP, doit encore prouver qu’il est autrement disponible ou serait autrement au travail pour être admissible aux prestations de maladie.
       [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations)

Quand le client ne prouve pas que, si ce n’était de la maladie, il serait disponible pour travailler pour la période d’invalidité, en tout ou en partie, l’agent impose une inadmissibilité 33 - Incapacité prouvée, mais client non autrement disponible (D33). L’agent impose l’inadmissibilité à compter de la date à laquelle le client ne remplit pas les conditions jusqu’à la fin de la période d’invalidité ou la date à laquelle le client est disponible pour travailler si ce n’était de la maladie.

**Maladie déclarée dans une demande de prestations régulières**

Un client qui remplit les conditions d’admissibilité pour recevoir des prestations de maladie et qui n’a pas reçu le maximum de prestations de maladie peut déclarer jusqu’à 4 semaines consécutives de maladie sans que le versement de ses prestations soit interrompu.

Quand un client se déclare malade pendant 2 semaines consécutives dans la même déclaration du prestataire, le système traite la déclaration du prestataire comme s’il s’agissait d’une demande de prestations de maladie, puis conseille le client de fournir un certificat médical si leur incapacité dure plus de 4 semaines.

Si aucune décision au sujet de la maladie n’est prise lors du traitement de la troisième déclaration du prestataire et que 5 journées de maladie sont déclarées dans la première semaine de la déclaration suivante, ce qui constitue une cinquième semaine consécutive de maladie, la déclaration du prestataire est rejetée avec l’indicatif d’erreur C465.

Un maximum de 8 semaines de prestations de maladie occasionnelle au total peut être payé dans une PP. Si le client déclare une neuvième semaine de prestations de maladie occasionnelle, la déclaration du prestataire est rejetée avec l’indicatif d’erreur C484.

Si le client demande des semaines supplémentaires de prestations de maladie après avoir déclaré 4 semaines consécutives ou le maximum de 8 semaines dans une PP, le genre de demande (GD) doit être converti en prestations de maladie.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0857.dita) 

Quand le client déclare une semaine partielle de maladie après l’épuisement de ses prestations régulières et qu’il n’a pas prouvé son incapacité à travailler en raison d’une maladie, l’agent impose une inadmissibilité 18 - Prestations spéciales demandées, non admissible aux prestations régulières (D18).

**Nombre maximal de semaines de prestations de maladie**

Le client peut recevoir jusqu’à 26 semaines de prestations de maladie par PP quand le DPP est la s/c 2374 ou après et jusqu’à 15 semaines de prestations de maladie par PP quand le DPP est la s/c 2373 ou avant.

Quand un client ne remplit pas toutes les conditions d’admissibilité pour recevoir des prestations régulières (p. ex. le client est encore malade) une fois que le nombre maximal de semaines de prestations de maladie a été versé, l’agent impose une inadmissibilité 22 - Maladie (maximum payé en maladie/spéciales) (D22).

Quand le client a épuisé son admissibilité aux prestations de maladie, les prestations sont réduites d’un cinquième par journée de maladie déclarée subséquemment.

Pour prouver que des prestations sont payables, le client doit remplir des déclarations du prestataire.

**Prestations de compassion (PDC)**

Les PDC offrent au client admissible un soutien du revenu durant la période au cours de laquelle il doit s’absenter de son travail pour prodiguer des soins ou offrir du soutien à un membre de sa famille gravement malade (patient) dont le risque de décès dans une période de 26 semaines est élevé. Les PDC sont offertes depuis le 4 janvier 2004.

Les demandes de PDC sont traitées dans les bureaux responsables de ces prestations . Toutefois, le client peut toujours se rendre au Centre Service Canada le plus près de chez lui pour obtenir des services en personne.
       [bureaux responsables de ces prestations](http://edsc.prv/fr/service-canada/ae/contacts/prestations_compassion.shtml) 
       [Centre Service Canada](http://offices-bureaux.prv/opd/index.cfm?APP=SEARCH&ACT=SEARCH_RC&LANG=F)

**Conditions requises pour les prestations de compassion (PDC)**

Pour remplir les conditions requises pour recevoir des PDC, un client doit :

- avoir présenté une demande de prestations;

- avoir subi un A de R dans sa PR ;
         [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration) 
         [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

- être de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable. Si le client a une violation à son dossier, la majoration des conditions requises pourrait s’appliquer;
         [majoration des conditions requises pourrait s’appliquer;](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Majoration_nombre_dheures_demploi_ass_r)

**Critères d’admissibilité aux PDC**

Pour être admissible aux PDC, un client doit :

- présenter une preuve attestant que le membre de la famille est dans un état grave, risque fort de mourir dans les 26 semaines et requiert les soins ou le soutien d’un ou de plusieurs membres de sa famille;

- fournir des soins ou du soutien à une personne qui est identifiée comme un membre de sa famille;

- demander les PDC dans la fenêtre d’admissibilité de 52 semaines établie pour un patient, à condition que les 26 semaines payables de PDC n’aient pas déjà été payées dans cette fenêtre.

L’agent impose une inadmissibilité 51 - Ne rencontre pas les conditions d’admissibilité de prestations de soins de compassion (D51) quand le client ne remplit pas les critères d’admissibilité. Exception : Si le client omet de présenter une preuve, l’agent impose une inadmissibilité 53 - Prestations de soins de compassion - Aucune preuve médicale (D53).

**Définition du membre de la famille**

Pour les besoins du bénéfice des PDC, le terme membre de la famille qui s’applique au patient, comprend toute personne que le client considère comme un membre de la famille. Le patient doit aussi considérer le client comme étant un membre de la famille . Comme preuve de ce fait, le client doit présenter le formulaire Attestation - Prestations de compassion (INS5223B) signé par le membre de la famille gravement malade ou son représentant.
       [Attestation - Prestations de compassion (INS5223B)](http://forms-formulaires.prv/eform99/index.cfm?App=Launch&FormID=4180&GroupID=203&LANG=F)

**Définition de soins ou de soutien**

Soigner ou soutenir un patient comprend les actions suivantes :

- lui dispense tout ou une partie des soins;

- lui apporte un soutien psychologique ou émotionnel;

- planifie les soins donnés par un tiers soignant.

Pour obtenir de plus amples renseignements, consulter GDA 23.2.4 — Soins et soutien à un membre de la famille gravement malade .
       [GDA 23.2.4 — Soins et soutien à un membre de la famille gravement malade](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-23/prestations-de-compassion.html#a23_2_4)

**Preuve de l’état de santé du patient**

Afin de recevoir des PDC, un client doit présenter un certificat médical acceptable signé par un médecin ou par un spécialiste de la santé qui a traité le patient. Ce certificat médical doit confirmer l’état de santé du patient et doit mentionner que le patient risque de décéder dans les 26 semaines et qu’il requiert les soins ou le soutien d’un ou de plusieurs membres de sa famille. Afin que le certificat soit émis par le médecin, le patient doit accepter de divulguer des renseignements médicaux.
       [certificat médical acceptable](/fr/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

Pour fournir ces renseignements, le client fournit à Service Canada le formulaire Autorisation de divulguer des renseignements médicaux pour des prestations de compassion et pour proches aidants de l’assurance emploi (INS5257) rempli par le patient ou son représentant.
       [Autorisation de divulguer des renseignements médicaux pour des prestations de compassion et pour proches aidants de l’assurance emploi (INS5257)](http://forms-formulaires.prv/lc/content/EForms/fr/Detail.html?Form=INS5257)

Le certificat médical doit être soumis à l’Administration centrale seulement dans les situations suivantes :

- Le certificat est dans une langue autre que le français ou l’anglais.

- L’agent n’est pas certain que les 2 conditions suivantes sont remplies :

- Le patient, qui est gravement malade, risque fort de décéder dans les 26 prochaines semaines.

- Le patient requiert des soins ou du soutien d’au moins un membre de sa famille.

- Un doute subsiste quant à la validité du certificat émis par un médecin ou un spécialiste de la santé.

Un seul certificat médical est requis par patient et par fenêtre de compassion (FC), peu importe le nombre de membres de la famille qui toucheront les prestations à l’égard du patient.

L’agent impose une inadmissibilité D53 dans les situations suivantes :

- Le client omet de présenter le certificat médical.

- Le certificat présenté est invalide.

- Le médecin ou le spécialiste de la santé n’est pas reconnu et le certificat n’est pas approuvé.

**Nombre maximal de semaines de PDC**

Au cours d’une période de prestations (PP), un client admissible peut recevoir un maximum de 26 semaines de PDC pendant une seule ou plus d’une FC à l’égard d’un patient ou de plusieurs patients. Le client peut recevoir un maximum de 26 semaines de PDC au cours d’une FC à l’égard d’un même patient, sans égard au nombre de clients les réclamant.
       [période de prestations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations)

Jusqu’à 26 clients peuvent partager simultanément ou non un maximum de 26 semaines de PDC à l’égard d’un patient au cours de la même FC.

Quand au moins 2 clients présentent une demande de PDC à l’égard d’un même patient et qu’ils s’entendent sur le partage des semaines payables, ces semaines sont partagées selon l’entente qui a été convenue entre eux.

Quand les clients n’arrivent pas à s’entendre, le partage des prestations s’effectue de la façon suivante :

- Si le nombre de semaines impayé est égal au nombre de clients, une semaine est attribuée à chacun d’eux.

- Quand le nombre de semaines impayé est supérieur au nombre de clients, jusqu’à épuisement des semaines payables, une semaine est attribuée à chacun des clients à tour de rôle, en commençant par celui qui a présenté sa demande en premier et en suivant l’ordre chronologique dans lequel les autres clients ont présenté leur demande.

- Si le nombre de semaines non payé est inférieur au nombre de clients, une semaine est attribuée en débutant par le client qui a présenté en premier sa demande puis au second et, ainsi de suite, jusqu’à épuisement des semaines payables.

L’agent impose une inadmissibilité 52 - Prestations de soins de compassion épuisées (D52) dans les situations suivantes :

- 26 semaines de PDC ont été payées au cours de la période de prestations.

- 26 semaines de prestations ont été payées dans la FC.

- Le client est exclu du partage des semaines de PDC.

- Le patient est décédé (en vigueur à compter de la semaine suivant le décès).

Pour prouver que des prestations sont payables, le client doit remplir des déclarations du prestataire. Le client recevant des PDC peut demander une exemption de remplir des déclarations du prestataire.

Un DC peut être reporté si le client reçoit des PDC.
       [DC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Delai_de_carence)

**Fenêtre de compassion (FC)**

La FC est la période de 52 semaines au cours de laquelle 26 semaines de PDC sont payables. Les dates de début et de fin de la FC sont déterminées selon les renseignements qui se trouvent dans le certificat médical du membre de la famille gravement malade.

La FC commence à la date la plus antérieure parmi les suivantes :

- le dimanche de la semaine de la signature du certificat

- le dimanche de la semaine où le diagnostic selon lequel le patient est en phase terminale est posé, quand le certificat fait mention de cette date

- le dimanche de la semaine où, selon les indications du médecin sur le certificat, le patient était devenu en phase terminale avant l’examen médical

L’admissibilité à l’intérieur de la FC de 26 semaines se termine à la date appropriée de la façon suivante :

- le samedi de la semaine pour laquelle la 26e semaine de PDC est versée au client au cours de sa période de compassion concernant un ou plusieurs patients;

- le samedi de la semaine pour laquelle la 26e semaine de PDC est versée, qu’il s’agisse d’un client ou de plusieurs clients qui partagent les PDC au cours de la même FC;

- le samedi de la semaine au cours de laquelle le client cesse de donner des soins ou du soutien au patient;

- le samedi de la semaine à laquelle tombe la 52e semaine de la FC;

- le samedi de la semaine au cours de laquelle le patient est décédé.

La FC ne peut pas être prolongée. Un autre certificat peut permettre une nouvelle fenêtre de 26 semaines au cours de laquelle de PDC peuvent être versées. Toutefois, une FC subséquente ne change pas le nombre de semaines d’admissibilité payable.

**Prestations pour proches aidants**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0490.dita) 

Les prestations pour proches aidants offrent aux clients admissibles un soutien du revenu durant la période où ils doivent s’absenter de leur travail pour fournir des soins ou du soutien à un patient gravement malade ou blessé.

Il y a 2 genres de prestations pour proches aidants : prestations pour proches aidants d’adultes et prestations pour proches aidants d’enfants.

Les conditions d’admissibilité et le calcul du taux de prestations sont identiques pour les 2 genres de prestations pour proches aidants. La différence entre les 2 genres est le nombre maximal de semaines payables et l’âge du patient.

Pour plus de renseignements sur ce GP, l’agent peut consulter Prestations pour proches aidants (Page d’information) .
       [Prestations pour proches aidants (Page d’information)](/fr/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml)

**Conditions requises**

Pour remplir les conditions requises pour recevoir des prestations pour proches aidants, un client doit :

- avoir subi un A de R dans sa PR ;
         [A de R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Arret_de_remuneration) 
         [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_reference)

- être de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable. Si le client a une violation à son dossier, la majoration des conditions requises pourrait s’appliquer .
         [majoration des conditions requises pourrait s’appliquer](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Majoration_nombre_dheures_demploi_ass_r)

**Conditions d’admissibilité**

Les conditions d’admissibilité suivantes doivent également être remplies :

- le client doit être un membre admissible de la famille ou un proche parent;

- le client doit soumettre le formulaire Certificat médical pour prestations pour proches aidants de l’assurance-emploi rempli par un médecin ou un infirmier praticien autorisé;
         [Certificat médical pour prestations pour proches aidants de l’assurance-emploi](http://forms-formulaires.prv/lc/content/EForms/fr/Detail.html?Form=INS5242B)

- le patient ou le représentant du patient doit remplir et signer le formulaire Autorisation de divulguer des renseignements médicaux pour des prestations de compassion et pour proches aidants de l’assurance emploi ;
         [Autorisation de divulguer des renseignements médicaux pour des prestations de compassion et pour proches aidants de l’assurance emploi](http://forms-formulaires.prv/lc/content/EForms/fr/Detail.html?Form=INS5257)

- le patient doit être gravement malade ou blessé et doit requérir les soins ou le soutien d’un membre de sa famille quand la fenêtre de 52 semaines commence;

- le client doit demander des prestations pour proches aidants pendant la fenêtre d’admissibilité de 52 semaines.

**Inadmissibilités**

L’agent impose les inadmissibilités suivantes liées aux prestations pour proches aidants quand le client ne remplit pas les conditions d’admissibilité :

- 61 - Proches aidants d’enfants ou d’adultes - Ne rencontre pas les conditions d’admissibilité (D61)

- 62 - Proches aidants d’enfants ou d’adultes - Prestations épuisées (D62)

- 63 - Proches aidants d’enfants ou d’adultes - Aucune preuve médicale (D63)

**Nombre maximal de prestations pour proches aidants**

Les clients peuvent recevoir un maximum de 35 semaines de prestations pour proches aidants d’enfants et 15 semaines pour proches aidants d’adultes pendant toute période de prestations (PP). Les clients peuvent partager les prestations pour proches aidants.

Les prestations pour proches aidants ne sont pas forcément versées consécutivement. Elles peuvent être versées de façon intermittente pendant la période de prestations (PP) ou à l’intérieur de la fenêtre pour proches aidants (FPA) de 52 semaines, de façon à convenir le mieux aux clients, pourvu que le certificat médical requis prouve la maladie ou la blessure grave du patient durant les semaines demandées.

**Fenêtre pour proches aidants (FPA)**

La FPA désigne la période durant laquelle des prestations pour proches aidants d’adultes ou d’enfants peuvent être payées. Il s’agit d’une fenêtre de 52 semaines durant laquelle des prestations peuvent être payées.

Pour plus de renseignements, l’agent peut consulter Établir la fenêtre pour proches aidants .
       [Établir la fenêtre pour proches aidants](/fr/procedure/task/establishing_fbw_etablir_fpppa.shtml)

**Définition du membre de la famille**

Pour les besoins du bénéfice des prestations pour proches aidants, le terme membre de la famille, qui s’applique au patient, comprend toute personne que le client considère comme un membre de la famille.

L’agent peut consulter Membre de la famille — Définition pour trouver une liste des membres de la famille et de proches parents admissibles.
       [Membre de la famille — Définition](/fr/procedure/generic/additionalresources/definition_fam_mem.shtml)

**Définition de soins ou de soutien**

Soigner ou soutenir un patient comprend les actions suivantes :

- lui dispenser tout ou une partie des soins;

- lui apporter un soutien psychologique ou émotionnel.

L’agent peut consulter GDA 23.2.4 — Soins et soutien à un membre de la famille gravement malade .
       [GDA 23.2.4 — Soins et soutien à un membre de la famille gravement malade](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-23/prestations-de-compassion.html#a23_2_4)

**Preuve de l’état de santé du patient**

Pour prouver que le patient est gravement malade ou blessé et qu’il a besoin de soins ou du soutien d’un membre de la famille, le client doit obtenir un certificat médical acceptable attestant que :
       [certificat médical acceptable](/fr/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

- l’état de santé habituel du patient a changé de façon considérable;

- la vie du patient est en danger par suite d’une maladie ou d’une blessure;

- le mauvais état de santé de ce patient fait en sorte qu’il requiert les soins ou le soutien d’un membre de la famille.

Pour plus de renseignements sur les certificats médicaux acceptables, l’agent peut consulter Déterminer si un certificat médical est acceptable — Prestations pour proches aidants .
       [Déterminer si un certificat médical est acceptable — Prestations pour proches aidants](/fr/procedure/task/determining_pcic_med_cert.shtml)

**Partage des prestations**

Les prestations pour proches aidants peuvent être partagées entre les membres admissibles de la famille selon les limites individuelles de chaque GP. Les prestations pour proches aidants peuvent être partagées en même temps ou séparément pendant la fenêtre de 52 semaines. Pour plus de renseignements sur les membres de la famille admissibles, l’agent peut consulter Membre de la famille — Définition .
       [Membre de la famille — Définition](/fr/procedure/generic/additionalresources/definition_fam_mem.shtml)

Les clients qui partagent les prestations doivent accepter le nombre de semaines demandé par chaque membre de la famille. Seules les semaines de prestations qui n’ont pas été versées peuvent être partagées. Quand les clients ne s’entendent pas sur le partage des prestations, un agent de Niveau 2 décide de la division des semaines restantes.

Pour plus de renseignements, l’agent peut consulter Rendre une décision sur le partage des prestations pour proches aidants — Désaccord sur le partage des semaines .
       [Rendre une décision sur le partage des prestations pour proches aidants — Désaccord sur le partage des semaines](/fr/procedure/task/adjudicating_na_pcic_bw.shtml)

**Mémo pour le centre opérationnel (MM06)**

Quand la demande n’est pas dans SMP, l’agent traite les demandes initiales dans la version Web de SSA, tandis que les demandes renouvelées sont traitées dans ETI. L’agent envoie ensuite un MM06 au COPA. Si la demande figure déjà dans SMP, seul le MM06 est requis.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0858.dita) 

**PAS-IND-DP**

L’indicatif PAS-IND-DP est également disponible pour les prestations pour proches aidants. Le système n’annule pas automatiquement l’exemption de remplir des déclarations du prestataire quand les critères d’admissibilité ne sont plus remplis (p. ex. des prestations pour proches aidants deviennent des prestations de maladie ou un client travaille à temps partiel). L’agent doit envoyer un Mémo pour le centre opérationnel (MM06) au COPA pour demander l’annulation de l’indicatif PAS-IND-DP.

**Semaines d’admissibilité payées ou payables**

On considère qu’une semaine de prestations est payée quand au moins 1 $ de prestations a été versé.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0859.dita) 

On considère qu’une semaine de prestations est payée ou payable quand :

- le client observe une semaine d’exclusion pour une durée déterminée;

- les prestations servent à rembourser un T-P ou une pénalité;

- des prestations sont retenues en raison d’une cession de prestations;

- des prestations sont retenues en vertu d’un accord d’ordonnance familiale;

- des prestations sont retenues pour le compte de l’Agence du revenu du Canada.

**Période de prestations (PP)**

La PP est la période au cours de laquelle le client peut réclamer les semaines de prestations auxquelles il a droit. La PP dure habituellement 52 semaines, comprenant la semaine du DPP .
       [DPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Debut_de_la_periode_de_prestations)

Une PP prend fin quand une des situations suivantes se produit :

- Toutes les semaines d’admissibilité aux prestations régulières payables ont été payées.

- La période de 52 semaines est à échéance et il n’y avait pas de condition de prolonger la PP.

- Le client demande de mettre fin à la PP et y est admissible.

- L’ admissibilité maximale aux prestations a été payée.
         [admissibilité maximale aux prestations](/fr/procedure/generic/additionalresources/max_ent_ben.shtml)

Si le client n’a pas reçu toutes les semaines de prestations auxquelles il a droit dans la PP, les semaines d’admissibilité restantes ne sont pas reportées à une demande subséquente.

**Prolonger la PP**

La Loi sur l’AE permet la prolongation de la PP sous certaines conditions.
       [PP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/knowledge#Periode_de_prestations)

La prolongation de la PP permet à un client de recevoir des semaines de prestations auxquelles il a droit pendant une plus longue période. Toutefois, le nombre de semaines de prestations auquel le client a droit demeure le même, peu importe la prolongation.

Pour de plus amples renseignements sur la prolongation de la PP, consulter Prolongation de la période de prestations .
       [Prolongation de la période de prestations](/fr/procedure/activity/extension_benefit_period.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0829.dita`

Remarque :

Un A de R utilisé pour établir une PP ne peut pas être utilisé pour établir une demande subséquente, à moins que la PP établie précédemment est annulée (consulter Annuler une période de prestations ).
       [Annuler une période de prestations](/fr/procedure/task/benefit_period_cancel.shtml)

     [Annuler une période de prestations](/fr/procedure/task/benefit_period_cancel.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0830.dita`

Remarque :

Quand l’employeur joint couramment des relevés de paie au RE, l’agent communique avec l’employeur et l’informe que les renseignements ne sont pas nécessaires. Puis, l’agent conseille plutôt à l’employeur de remplir la case 15C. Dans ce cas, l’agent vérifie s’il y a une demande précise pour l’utilisation des données réelles dans le calcul. Sinon, l’agent retourne les données réelles en utilisant l’avis approprié. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0831.dita`

Remarque :

Si un RE a été émis en prévoyant que le client ne serait pas rappelé au travail en 7 jours, un A de R est survenu. Toutefois, si le client retourne à cet emploi dans les 7 jours et que la demande n’est pas finalisée, on considère que l’A de R n’a pas eu lieu. La PP n’est pas établie à moins qu’un A de R ait eu lieu à un autre moment dans la PR. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0832.dita`

Remarque :

Une rémunération de jour férié n’empêche pas l’imposition d’un A de R régulier (7 jours sans travailler ni recevoir une rémunération). Toutefois, elle peut empêcher l’imposition d’un A de R spécial qui se produit quand la rémunération est sous le seuil de 60 % de la RHN et la cessation d’emploi est attribuable à un congé de maladie, de maternité, parental, de soins de compassion ou de proche aidant. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0833.dita`

Remarque :

Le budget 2021 a introduit une norme d’admissibilité commune pour tous les DPP entre la s/c 2310 et la s/c 2361. Cependant, un agent ne peut pas postdater le DPP au-delà du taux régional de chômage (TRC) courant. Le TRC continue d’être utilisé pour les semaines d’admissibilité et ainsi que dénominateur . 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0834.dita`

Exemple :

- L’A de R et le DJP surviennent dans la s/c 2275.

- Le client a une rémunération de 1 000 $ dans la dernière semaine de travail.

- Le client a présenté sa demande dans la s/c 2279. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0835.dita`

Exemple :

- Quand une demande d’antidate est autorisée, la demande est considérée comme présentée à la date antérieure. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0836.dita`

Remarque :

Si le client participe au Travail partagé (TP), a fourni un code de référence de TP et a présenté sa demande avant l’expiration du code de référence de TP , le client a présenté la demande dans les délais prescrits.
       [code de référence de TP](/fr/procedure/generic/additionalresources/knowledge_reltws.shtml#Code_de_reference)

     [code de référence de TP](/fr/procedure/generic/additionalresources/knowledge_reltws.shtml#Code_de_reference) 

### Exemple 1

Source topic: `fr_FR/common_notes/note_c_0837.dita`

Exemple 1 :

L’A de R se produit au cours de la s/c 1928 et le client présente sa demande de prestations dans la s/c 1932. Le DPP est dans la s/c 1928, car la demande a été présentée dans les 4 semaines civiles qui suivent l’A de R. Si un DPP postérieur est plus avantageux pour le client, l’agent peut postdater le DPP à une semaine postérieure à la s/c 1928 si les conditions de la Politique sur les postdates sont remplies. 

### Exemple 2

Source topic: `fr_FR/common_notes/note_c_0838.dita`

Exemple 2 :

L’A de R se produit au cours de la s/c 1928 et le client présente sa demande de prestations dans la s/c 1933. Le DPP est à la s/c 1933, car la demande a été présentée plus de 4 semaines civiles après la semaine de l’A de R. Le client doit demander une antidate s’il souhaite que sa période de prestations soit établie à une date antérieure. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0839.dita`

Exemple :

Dans la demande d’AE initiale, le client a déclaré être incapable de travailler pendant la PR pour des raisons médicales du 3 mars 2026 au 9 mars 2026 (s/c 2541-2 à la s/c 2542-1). Le dossier indique les renseignements suivants :

- Le client n’a pas reçu de prestations d’AE ou du RQAP pendant la PR.

- Le RE indique une rémunération durant la période de paie quinzomadaire du 1 mars 2026 au 14 mars 2026.

- Un recueil de faits auprès de l’employeur a confirmé que le client :

- travaille comme gérant de restaurant du mardi au samedi;

- a été incapable de travailler en raison d’une maladie du mardi 3 mars 2026 au lundi 9 mars 2026;

- n’a aucune rémunération assurable pour la semaine civile du 1 mars 2026 au 7 mars 2026 (s/c 2541);

- a une rémunération assurable pour la semaine civile du 8 mars 2026 au 14 mars 2026, puisqu’il est retourné au travail le 10 mars 2026.

Dans cette situation, une prolongation de la PR peut être accordée pour la semaine partielle de maladie dans la s/c 2541, car toutes les conditions requises sont remplies. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0840.dita`

Remarque :

Il n’est pas nécessaire de prolonger la PR si le client a déjà droit au taux maximal de prestations et au nombre maximal de semaines payables. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0841.dita`

Remarque :

Quand une demande dont le DPP est entre le 27 septembre, 2020 (s/c 2258) et le 19 septembre 2021 (s/c 2309) est convertie d’une demande pour la prestation d’AE d’urgence (PU AE) ou pour la Prestation canadienne d’urgence (PCU), une prolongation automatique de 28 semaines de la PR est accordée pour tous les genres de prestations (GP) sauf les prestations de pêcheur et de travail indépendant (TI). 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0842.dita`

Remarque :

Dans ce contexte, l’expression « pas reconnu coupable » fait référence aux clients qui n’ont pas été reconnus coupables ou qui ont été acquittés, ainsi qu’aux situations dans lesquelles les chefs d’accusation ont été retirés ou qu’il y a suspension d’instance depuis plus d’un an, ce qui correspond au délai prescrit pour reprendre les procédures légales. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0843.dita`

Remarque :

Un document de mise en accusation ne constitue pas une preuve valide, car il est créé pour chaque chef d’accusation et, par conséquent, ne démontre pas si d’autres chefs d’accusation sont en suspens. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0844.dita`

Remarque :

Quand un client a accumulé moins d’heures de travail assurable requises par la NVA, la demande n’est pas établie. Toutefois, si le client a accumulé plus de 420 heures assurables au cours de sa PR et que le TRC augmente assez pour que le client puisse être admissible aux prestations, le client doit présenter une nouvelle demande. 

### Callout

Source topic: `fr_FR/common_notes/note_c_0845.dita`

**Genres de PPNE**

- N1 : Le client a travaillé moins de 420 heures d’emploi assurable (le nombre minimum d’heures d’emploi assurable requis pour être admissible) dans la PR .
         [PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#Periode_de_reference)

- N2 : Le dernier RE du client manque.

- N5 : Le client ne remplit pas les critères relatifs à la NVA ou, s’il y a une violation au dossier, la majoration des conditions requises .
         [NVA](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#Norme_variable_dadmissibilite) 
         [majoration des conditions requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#_Majoration_du_nombre)

- N7 : Le client présente une demande de prestations de pêcheur hivernal ou estival pour laquelle le montant total de la rémunération assurable provenant d’un emploi de pêcheur est inférieur à 2 500 $.

- N8 : Le client n’a pas subi d’A de R pendant la PR. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0846.dita`

Remarque :

- Pour obtenir de plus amples renseignements, consulter le tableau de la majoration des conditions requises de LAE 7.1 et Guide 18.10.3 .
         [LAE 7.1](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-7.1.html) 
         [Guide 18.10.3](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-18/violation.html#a18_10_3)

- Peu importe le GP demandé, tous les clients à qui un avis de violation a été émis sont assujettis à la majoration des conditions requises. Les prestations spéciales ne sont pas exclues de cette mesure.
         [prestations spéciales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#Prestations_speciales)

     [LAE 7.1](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-7.1.html) 
     [Guide 18.10.3](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-18/violation.html#a18_10_3) 
     [prestations spéciales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#Prestations_speciales) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0847.dita`

Remarque :

Une mesure temporaire du budget 2021 s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, une décision est seulement requise sur le plus récent RE dans la PR, si le motif de cessation d’emploi (MCE) est litigieux. De plus, la norme d’admissibilité commune de 420 heures d’emploi assurable n’est pas utilisée pour déterminer si le client remplit à nouveau les conditions requises après un évènement ayant entraîné une exclusion. Le client doit plutôt avoir travaillé au moins une heure d’emploi assurable depuis l’évènement ayant entraîné l’exclusion et présenté une demande d’AE.

Si le MCE depuis l’évènement ayant entraîné l’exclusion est non litigieux ou que la décision de l’autoriser a été rendue, une nouvelle demande peut être établie en utilisant les heures de tous les RE. L’exclusion indéterminée imposée en raison de la période d’emploi initiale ne s’applique plus, puisque le nouveau RE de la dernière période d’emploi permet d’établir un nouveau DPP sans exclusion. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0110.dita`

Remarque :

L’ année d’imposition de base correspond à l’année d’imposition qui se termine avant l’année du versement de l’allocation canadienne pour enfants. Par exemple, les versements de juillet 2015 à juin 2016 sont selon le revenu familial net pour l’année d’imposition de base (année d’imposition) 2014. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0848.dita`

Remarque :

Bien que l’Allocation canadienne pour enfants puisse être versée à un client dont le revenu familial net est supérieur à 25 921 $, le revenu familial net maximal pour être admissible au SF est de 25 921 $. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0849.dita`

Remarque :

Si le DPP est la s/c 2062 ou avant, le DC est de 2 semaines. Le client observe la première semaine du DC pendant la première semaine civile au cours de laquelle, sans le DC, des prestations auraient été payables. Une fois que le client a observé la première semaine du DC, la prochaine semaine est considérée comme la deuxième semaine du DC. Dès que la déclaration du prestataire est remplie pour la deuxième semaine du DC, le DC est considéré comme étant observé. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0850.dita`

Remarque :

Une exclusion doit être observée après le DC, sur lequel elle n’a aucun effet. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0851.dita`

Remarque :

Le DC est supprimé pour toutes les demandes dont le DPP est entre :

- le 27 septembre 2020 (s/c 2258) et le 25 octobre 2020 (s/c 2262);

- le 31 janvier 2021 (s/c 2279) et le 19 septembre 2021 (s/c 2309).

Le DC des demandes de prestations de maladie est supprimé pour une période prolongée qui couvre les DPP du 25 septembre 2020 (s/c 2258) au 25 septembre 2021 (s/c 2309). Toutefois, le DC ne sera pas supprimé pour tout client qui reçoit des PSC et qui a présenté une demande de prestations spéciales. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0657.dita`

Remarque :

Si le DC est reporté dans une demande dont le DPP est la s/c 2062 ou avant, le DC demeure 2 semaines même s’il n’est observé qu’après la s/c 2062. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0852.dita`

Remarque :

Avant le 3 décembre 2017, la date de début de la fenêtre de maternité correspondait à 8 semaines avant la date prévue de l’accouchement, ou à la date réelle de l’accouchement. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0853.dita`

Remarque :

Il se peut que certains employeurs aient en place des politiques qui permettent aux employées de commencer leur congé de maternité un nombre déterminé de semaines précédant la date prévue de leur accouchement (p. ex. en Colombie-Britannique, les employées provinciales peuvent commencer leur congé de maternité 6 semaines avant la date prévue de leur accouchement). Dans de telles situations, il est important de ne pas conseiller à une employée de présenter une demande de prestations de maladie avant sa demande de prestations de maternité, sauf si sa situation particulière l’exige. Conseiller, à tort, à une employée de présenter une demande de prestations de maladie peut entraîner les conséquences suivantes :

- Quand une cliente reçoit des prestations de maladie avant de recevoir des prestations de maternité, les responsables du régime d’AE pourraient formuler une supposition quant au « premier payeur ». L’employeur qui participe au Programme de réduction du taux de cotisation d’AE doit verser les prestations le premier, afin de remplir les exigences du Programme. Une employée qui présente une demande de prestations de maladie avant une demande de prestations de maternité pourrait compromettre l’admissibilité de son employeur à la réduction des cotisations qu’il verse.

- Il peut y avoir une incidence sur le versement des prestations de maternité ou parentales versées au titre d’un régime de PSC :

- Si une cliente reçoit des prestations de maladie avant des prestations de maternité, elle pourrait ne plus être admissible aux PSC pour le DC .
             [DC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#Delai_de_carence)

- Les PSC peuvent être versées pour une période déterminée suivant l’arrêt de travail; la période en question peut être considérée comme étant le congé de maternité ou parental. À la fin de la période déterminée, une cliente peut demander à son employeur que son congé soit prolongé. Sa demande peut être accordée, mais le congé ne serait pas compris dans la période au cours de laquelle les PSC doivent être versées. Par conséquent, la cliente pourrait ne pas recevoir la totalité des PSC; il se peut aussi que l’employeur doive verser des PSC pendant le congé prolongé.

C’est pour ces raisons qu’il est important qu’une cliente présente la demande de prestations appropriée à sa situation.

     [DC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#Delai_de_carence) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0854.dita`

Remarque :

Ces situations exigent un recueil de faits supplémentaire par l’agent avant de rendre une décision. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0028.dita`

Remarque :

Si l’adoption soulève des doutes, une preuve de placement peut être exigée. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0855.dita`

Remarque :

Dans certains cas, la FP peut être prolongée pour permettre au client de recevoir les prestations auxquelles il a droit. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0856.dita`

Remarque :

Même si le MCE sur le dernier RE est une maladie, si l’une des exclusions ou inadmissibilités ci-dessus s’applique à la demande, ou si le certificat médical n’est pas acceptable, le client doit présenter un certificat médical acceptable. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0857.dita`

Remarque :

Un client ne doit pas présenter une demande initiale ou de renouvellement de prestations régulières en ayant l’intention de déclarer des journées occasionnelles de maladie à compter du DPP ou de la date de renouvellement. Dans ce cas, si le client n’est pas immédiatement disponible pour travailler, il faut lui indiquer de présenter une demande de prestations de maladie. Les journées occasionnelles de maladie ne doivent être prises en considération que dans le cas de demandes continues de prestations régulières. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0490.dita`

Remarque :

À partir du 3 décembre 2017, les prestations pour PEGM sont remplacées par les prestations pour proches aidants d’enfants. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0858.dita`

Remarque :

Quand il remplit le MM06 , l’agent doit fournir au COPA tous les renseignements nécessaires pour traiter le paiement au moyen de SIP. L’agent choisit 93 - Système manuel de paiement dans le champ Article de travail et 30 - Nouveau renseignement pour une demande au Système manuel de paiement dans le champ Genre de travail . 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0859.dita`

Remarque :

Le nombre de semaines payées de prestations du RQAP correspond à celui des prestations de l’AE payées. Pour de plus amples détails, consulter RQAP .
       [RQAP](http://www.rqap.gouv.qc.ca/Index.asp)

     [RQAP](http://www.rqap.gouv.qc.ca/Index.asp) 
