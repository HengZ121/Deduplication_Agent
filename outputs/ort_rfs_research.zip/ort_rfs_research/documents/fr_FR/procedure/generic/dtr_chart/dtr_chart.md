# Imagerie : Types de document — Tableau

Source map: `fr_FR/procedure/generic/dtr_chart/dtr_chart.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/dtr_chart/generic.dita`

```text
| Type de document | Description | Sous-type de document à imager |

| CAL | Calcul | Les 14 meilleures / petites semaines / meilleures semaines variables (INS 5241) | Preuve d’emploi (INS 3166) |

| Décision relative à l’assurabilité | Demande de prolongation de la période de prestations |

| Gains en provenance de l’employeur | Demande de prolongation de la période de référence |

| Autres gains | Preuve d’incarcération |

| CLT | Info du Client | Demande d’AE papier | Questionnaire sur l’admissibilité |

| Disponibilité | Documents d’immigration |

| Emploi | Changement de nom |

| Pêche | Apprentis - Demande - Aucune déclaration |

| Motif de cessation d’emploi (MCE) | Demande du feuillet T4E |

| Enseignants | Demande « d’envoyer une copie de… » |

| Formation | Demande de terminaison volontaire |

| Antidate | Faillite |

| Autorisation de donner infos sur une demande | TD1 : Déclaration des crédits d’impôt personnels / Modification du statut d’impôt |

| Maladie / Invalidité du client | Désignation d’un représentant (INS3280) ou documents de l’ordonnance d’un tribunal provenant du Bureau du Tuteur et curateur public |

| Modification du genre de demande (à régulier) | État des mandats retournés |

| Preuve d’identité | |

| EUR | Employeur | Renseignements RE | Info sur MCE |

| 3 PI | Info tierce personne | Règlement de griefs | Prestations d’invalidité |

| Entente de remboursement | Indemnisation, accident d’automobile |

| Détails sur le Régime de pension du Canada | Perte de gains versée par un tiers |

| Indemnités des accidents du travail | Demande d’info d’une tierce personne |

| Consentement de divulguer info à une tierce personne | Appel de la décision de l’Agence du revenu du Canada (ARC) et désistement |

| Cession de prestations (INS 3113) | Compensation de l’ARC |

| Faillite personnelle | |

| SPC | Prestations Spéciales | PDC/Maternité/Parentales/Prestations pour proches aidants | Certificats médicaux |

| INT | Intégrité | Système automatisé de données sur la rémunération | Rapports d’enquête officielle |

| Sessions d'information à l’intention des prestataires / Enquêtes sélectives | Assortiment de la rémunération assurable |

| Post-vérification informatique (INS 5097 et INS 5098) | Programme d’avis d’embauche |

| Douanes | Travailleur indépendant / Enquêtes sur l’enregistrement des entreprises / Assortiment de la rémunération des travailleurs indépendant |

| Employeur | Formulaire de recherche d’emploi C-73-00-00 |

| Demande de certificat médical | Médical pour maladie conformité N-04-00-01 |

| APPELS | Appels | Appel au TSS | Demande de révision |

| AUT | Autre | Recouvrement | Courrier non livrable (avec l’enveloppe lorsqu’elle est jointe au courrier non livrable) |
``` 
