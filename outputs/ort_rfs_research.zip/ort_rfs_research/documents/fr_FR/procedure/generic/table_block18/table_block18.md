# RE : Mesures à prendre pour les observations dans la case 18 d’un RE régulier — Instructions

Source map: `fr_FR/procedure/generic/table_block18/table_block18.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/table_block18/generic.dita`

Choisir le genre d’observation indiquée dans le bloc 18 pour déterminer si les observations peuvent être supprimées :

- Observations liées au Coronavirus, à la COVID-19 ou à une quarantaine :

- quand il y a un AT Évaluation du relevé d’emploi (RE) MCE litigieux en suspens pour le même RE
             [quand il y a un AT Évaluation du relevé d’emploi (RE) MCE litigieux en suspens pour le même RE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/table_block18#covid19_1)

- quand il n’y a pas d’AT RE MCE litigieux pour le même RE
             [quand il n’y a pas d’AT RE MCE litigieux pour le même RE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/table_block18#covid19_2)

- Observations liées au motif de cessation d’emploi (MCE) :

- quand il y a un AT RE MCE litigieux en suspens pour le même RE
             [quand il y a un AT RE MCE litigieux en suspens pour le même RE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/table_block18#RFSandWI)

- quand il n’y a pas d’AT RE MCE litigieux pour le même RE
             [quand il n’y a pas d’AT RE MCE litigieux pour le même RE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/table_block18#RFSnoWI)

- Observations liées à la paye de vacances
         [Observations liées à la paye de vacances](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/table_block18#Vac)

- Observations liées à d’autres sommes (autre que la paye de vacances) (p. ex. indemnité de départ, indemnité de préavis, crédits de congé de maladie, primes, etc.)
         [Observations liées à d’autres sommes (autre que la paye de vacances)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/table_block18#OtherMonies)

- Autres observations
         [Autres observations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/table_block18#Misc)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0931.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0932.dita) 
     [Avertissement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0933.dita) 

```text
| Les deux conditions à remplir : | Dans MSRE, remplir les champs suivants : |

| Les observations dans la case 18 indiquent que le MCE est lié à l’une des raisons suivantes : | Le code de MCE dans la case 16 est : | Actions requises | Case 16 MCE : |

| vacances - Commission de la construction du Québec (CCQ) | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir K - Autre . |

| fin de contrat, travail saisonnier ou d’une durée déterminée | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | Les changements seront apportés à partir du SNCT dans l’AT RE MCE litigieux. |

| fin de l’emploi | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| fermeture de l’usine | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| abolition du poste | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| restructuration | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| travail saisonnier | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| pénurie de travail | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| Fermeture ou vacances d’été / Emploi d’été – fin de contrat | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| mise à pied | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| fermeture temporaire ou mise à pied | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| sept jours consécutifs sans travail | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| occasionnel | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| nom du spectacle ou de la production cinématographique | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| changement de fréquence de paye, de type de période de paye | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . Si l’employeur a choisi une sous-option sous le MCE de la case 16, l’indiquer également dans la case Renseignement supplémentaire . |

| changement au niveau de la propriété de l’entreprise ou de nom de la compagnie | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . Si l’employeur a choisi une sous-option sous le MCE de la case 16, l’indiquer également dans la case Renseignement supplémentaire . |

| demandé par Service Canada | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . Si l’employeur a choisi une sous-option sous le MCE de la case 16, l’indiquer également dans la case Renseignement supplémentaire . |

| changement de fournisseur de service de paye | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . Si l’employeur a choisi une sous-option sous le MCE de la case 16, l’indiquer également dans la case Renseignement supplémentaire . |

| faillite | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| autre – Demandé par l’employé | K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| formation en apprentissage telle que : apprenti, cours d’apprenti ou niveau d’apprenti | C, J ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| retour aux études et information sur une formation d’apprenti ou un code de référence | C, J ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| retour aux études et aucune information sur une formation d’apprenti | C ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| congé de maladie non payé | D, K ou N | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| description liée à la maladie ou à l’intervention chirurgicale | D, K ou N | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| retrait préventif | D, F, K, N ou E | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| a quitté son emploi sans préavis | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| retraite | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| démissionné | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| raisons personnelles | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| abandon du poste | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| justifié – congédiement avec justification | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| pour un autre emploi | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| pour suivre son conjoint | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| déménagement de l’employeur | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| pour s’occuper d’une personne à charge | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| pour devenir travailleur indépendant | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| retraite volontaire | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| raisons médicales | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| retour aux études | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| assiduité | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| mauvais rendement | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| ne convient pas aux exigences du poste, etc. | E | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| ne convient pas aux exigences du poste, etc. | K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir M - Congédiement |

| période de probation échouée | K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir M - Congédiement / Terminé avant la fin de la période de probation . |

| congédié durant la période de probation | K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir M - Congédiement / Terminé avant la fin de la période de probation . |
```

```text
| Les deux conditions à remplir : | Dans MSRE, remplir les champs suivants : |

| Les observations dans la case 18 indiquent que le MCE est lié à l’une des raisons suivantes : | Le code de MCE dans la case 16 est : | Actions requises | Case 16 MCE : |

| vacances - Commission de la construction du Québec (CCQ) | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir K - Autre . |

| fin de contrat, travail saisonnier ou d’une durée déterminée | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir A - Manque de travail / Fin de saison ou de contrat . |

| fin de l’emploi | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| fermeture de l’usine | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| abolition du poste | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| restructuration | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| travail saisonnier | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| pénurie de travail | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| Fermeture ou vacances d’été / Emploi d’été – fin de contrat | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| mise à pied | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| fermeture temporaire ou mise à pied | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| sept jours consécutifs sans travail | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| occasionnel | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| nom du spectacle ou de la production cinématographique | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| demandé par Service Canada | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . Si l’employeur a choisi une sous-option sous le MCE de la case 16, l’indiquer également dans la case Renseignement supplémentaire . |

| changement de fréquence de paye, de type de période de paye | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . Si l’employeur a choisi une sous-option sous le MCE de la case 16, l’indiquer également dans la case Renseignement supplémentaire . |

| changement au niveau de la propriété de l’entreprise ou de nom de la compagnie | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . Si l’employeur a choisi une sous-option sous le MCE de la case 16, l’indiquer également dans la case Renseignement supplémentaire . |

| changement de fournisseur de service de paye | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . Si l’employeur a choisi une sous-option sous le MCE de la case 16, l’indiquer également dans la case Renseignement supplémentaire . |

| faillite | A ou K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir A - Manque de travail / Faillite de l’employeur ou mise sous séquestre |

| autre - Demandé par l’employé | K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir K - Autre / À la demande de l’employé(e) . |

| formation en apprentissage telle que : apprenti, cours d’apprenti ou niveau d’apprenti | C ou J | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir J - Formation en apprentissage . |

| retour aux études et information sur une formation d’apprenti ou un code de référence | C ou J | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir J - Formation en apprentissage . |

| retour aux études et aucune information sur une formation d’apprenti | C ou K | Supprimer les observations de la case 18 | MCE : Choisir E - Départ volontaire / Retour aux études . |

| ordonnances et règlements royaux | K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir K - Autre / Forces canadiennes - Ordonnances/ règlements royaux . |

| congé de maladie | D, K ou N | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir D - Maladie ou blessure . |

| congé de maladie non payé | D, K ou N | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir D - Maladie ou blessure . |

| description liée à la maladie ou à l’intervention chirurgicale | D, K ou N | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir D - Maladie ou blessure |

| Retrait préventif | D, F, K, N ou E | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Laisser tel quel. |

| a quitté son emploi sans préavis | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire . |

| retraite | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Laisser tel quel. |

| démissionné | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire . |

| raisons personnelles | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire . |

| abandon du poste | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire . |

| justifié – congédiement avec justification | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir M - Congédiement . |

| pour un autre emploi | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire / Autre emploi . |

| pour suivre son conjoint | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire / Pour accompagner un(e) conjoint(e) . |

| déménagement de l’employeur | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E- Départ volontaire / Déménagement de l’employeur . |

| pour s’occuper d’une personne à charge | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire / Prendre soin d’une personne à charge . |

| pour devenir travailleur indépendant | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire / Pour devenir travailleur indépendant . |

| retraite volontaire | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire / Retraite volontaire . |

| raisons médicales | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire / Raisons médicales . |

| retour aux études | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire / Retour aux études . |

| assiduité | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir M - Congédiement . |

| mauvais rendement | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : choisir M - Congédiement . |

| ne convient pas aux exigences du poste, etc. | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir M - Congédiement . |

| période de probation échouée | K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir M - Congédiement / Congédié avant la fin de la période de probation . |

| congédié durant la période de probation | K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir M - Congédiement / Congédié avant la fin de la période de probation . |
```

```text
| Les conditions suivantes sont satisfaites : | Dans MSRE, remplir les champs suivants tel qu’indiqué : |

| Les observations dans la case 18 indiquent : | La case 17A ou 17C indique : | Actions requises | Case 17A ou 17B option : |

| paye de vacances inclus / émis / versé / payé à chaque paie | 17 A - Paye de vacances comprend un montant. | Supprimer les observations de la case 18 | 17A - Paye de vacances : Choisir Montant versé à chaque paie (le montant sera supprimé). |

| paye de vacances inclus / émis / versé / payé à chaque paie | 17C - Autres sommes (préciser) comprend un montant de paye de vacances et il n’y a pas de montant dans la case 17A . | Supprimer les observations de la case 18 | 17A - Paye de vacances : Choisir Montant versé à chaque paie . 17C - Autres sommes (préciser) : Supprimer le montant indiqué. |

| paye de vacances inclus / émis / versé / payé à chaque paie | | Supprimer les observations de la case 18 | |

| paie de vacances ou 17A est compris dans 15B ou dans PP1 de 15C . | 17 A - Paye de vacances comprend un montant. | Supprimer les observations de la case 18 | 17A - Paye de vacances : Choisir Montant versé parce que l’employé cesse de travailler . |

| paie de vacances comprise dans la case 15B ou la PP1 de 15C . | 17C - Autres sommes (préciser) comprend un montant de paye de vacances et il n’y a pas de montant dans la case 17A . | Supprimer les observations de la case 18 | 17A - Paye de vacances : Choisir Montant versé parce que l’employé cesse de travailler . 17A - montant : Saisir le montant indiqué dans la case 17C . 17C - Autres sommes (préciser) : Supprimer le montant |

| paie de vacances payée au taux de 4 %, 6 %, 8 %, etc. | 17 A - Paye de vacances comprend un montant. | Supprimer les observations de la case 18 | 17A - Paye de vacances : Choisir Payée parce que ne travaille plus |

| paie de vacances payée au taux de 4 %, 6 %, 8 %, etc. | 17C - Autres sommes (préciser) comprend un montant de paye de vacances et il n’y a pas de montant dans la case 17A . | Supprimer les observations de la case 18 | 17A - Paye de vacances : Choisir Payée parce que ne travaille plus ou selon le commentaire indiqué 17A - montant : Saisir le montant indiqué dans la case 17C 17C - Autres sommes (préciser) : Supprimer le montant |

| paie de vacances payée une période de vacances précise | 17 A - Paye de vacances comprend un montant. | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | 17A - Paye de vacances : Choisir Payée pour des vacances . 17A - Date de début : Saisir la date du début des vacances. 17A - Date de fin : Saisir la date de fin des vacances. |

| fermeture générale pour vacances et les dates précises sont fournies | 17 A - Paye de vacances comprend un montant. | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | 17A - Paye de vacances : Choisir Payée pour des vacances . 17A - Date de début : Saisir la date du début des vacances. 17A - Date de fin : Saisir la date de fin des vacances. |

| paie de vacances payée à une date anniversaire | 17 A - Paye de vacances comprend un montant. | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | 17A - Paye de vacances : Choisir Anniversaire (payée à la même date chaque année) . 17A - Date de début : Saisir la date d’anniversaire |
```

```text
| Les deux conditions sont satisfaites : | Dans MSRE, remplir les champs suivants tel qu’indiqué : |

| Les observations dans la case 18 indiquent : | Conditions de la case 17 : | Actions requises : | Options de la case 17 ou de la case 19 : |

| rémunération de jours fériés pour un jour férié en particulier (p. ex. le jour de Noël). | 17B - Jour(s) férié(s) comprend le montant | Supprimer les observations de la case 18 | 17B Date de début : Saisir le jour férié. |

| prime de rendement | 17C - Autres sommes (préciser) comprend le montant de la prime | Supprimer les observations de la case 18 | 17C : Choisir B - Prime / pour récompenser le rendement / La productivité . |

| prime de productivité | 17C - Autres sommes (préciser) comprend le montant de la prime | Supprimer les observations de la case 18 | 17C : Choisir B - Prime / pour récompenser le rendement / La productivité . |

| prime d’engagement - rétention | 17C - Autres sommes (préciser) comprend le montant de la prime | Supprimer les observations de la case 18 | 17C : Choisir B - Prime / engagement/fin de contrat/fin de saison . |

| prime de fin de contrat | 17C - Autres sommes (préciser) comprend le montant de la prime | Supprimer les observations de la case 18 | 17C : Choisir B - Prime / engagement/fin de contrat/fin de saison . |

| prime de fin de saison | 17C - Autres sommes (préciser) comprend le montant de la prime | Supprimer les observations de la case 18 | 17C : Choisir B - Prime / engagement/fin de contrat/fin de saison . |

| prime de fermeture | 17C - Autres sommes (préciser) comprend le montant de la prime | Supprimer les observations de la case 18 | 17C : Choisir B - Prime / engagement/fin de contrat/fin de saison . |

| prime de départ ou de retraite | 17C - Autres sommes (préciser) comprend le montant de la prime | Supprimer les observations de la case 18 | 17C : Choisir B - Prime / départ ou retraite . |

| prime de jours fériés et la date est fournie (p. ex. prime de Noël) | 17C - Autres sommes (préciser) comprend le montant de la prime | Supprimer les observations de la case 18 | 17C : Choisir B - Prime / jours fériés . 17C Date de début : Saisir la date du jour férié. |

| prime d’événement et la date sont fournis (p. ex. signature d’un contrat) | 17C - Autres sommes (préciser) comprend le montant de la prime | Supprimer les observations de la case 18 | 17C : Choisir B - Prime / événements particuliers . 17C Date de début : Saisir la date de l’événement. |

| l’employé a droit à des PSC | | Supprimer les observations de la case 18 | 17C : Choisir l’option appropriée : U - Prestations supplémentaires / PSC maternité/parental/compassion/ prestations pour proches aidants U - Prestations supplémentaires / PSC Mise à pied U - Prestations supplémentaires / PSC Maladie U - Prestations supplémentaires / PSC Formation 17C Nom du payeur : Laisser le champ vide. 17C Rencontre le règlement 38 : Ne pas cocher la case. |

| l’employé a droit à un régime de PSC approuvé par le gouvernement | | Supprimer les observations de la case 18 | 17C : Choisir l’option appropriée : U - Prestations supplémentaires / PSC maternité/parental/compassion/ prestations pour proches aidants U - Prestations supplémentaires / PSC Mise à pied U - Prestations supplémentaires / PSC Maladie U - Prestations supplémentaires / PSC Formation 17C Nom du payeur : Laisser le champ vide. 17C Rencontre le règlement 38 : Ne pas cocher la case. |

| détails relatifs à la pension, y compris les montants, les dates, etc. | Aucun | Laisser les observations dans la case 18 | Laisser cette case vide. |

| détails des sommes à la cessation à la case 18 . Les renseignements fournis indiquent clairement si les sommes assurables payées à la cessation sont comprises dans la case 15B ou dans la PP1 de la case 15C (p. ex. indemnité de départ prime de rétention de 5000.00 $ et une indemnité de préavis de 3000.00 $ sont payés lors de la cessation. L’indemnité de préavis est comprise dans la case 15B .) | | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | 17C : Choisir les sommes à la cessation appropriées dans le menu déroulant, saisir le montant ainsi que les autres détails requis. |

| les détails du congé de maladie payé comprennent le montant et la ou les date(s). | | Supprimer les observations de la case 18 | 19 : Choisir Congé de maladie pay . 19 Date de début : Saisir la date de début du paiement. 19 Date de fin : Saisir la date de fin du paiement. 19 Montant ($) : Saisir le montant 19 Par jour ou Par semaine : choisir le bouton radio approprié. 19 Durée : Saisir le nombre de paiements. |

| les détails du congé de maternité / parental / compassion/proches aidants payé comprennent le montant et la ou les date(s). | | Supprimer les observations de la case 18 | 19 : Choisir Congé de maternité / parental / compassion/proches aidants payé (pas le complément) . 19 Date de début : Saisir la date de début du paiement. 19 Date de fin : Saisir la date de fin du paiement. 19 Montant ($) : Saisir le montant 19 Par jour ou Par semaine : Cocher la case appropriée. 19 Durée : Saisir le nombre de paiements. |

| indemnité d’assurance salaire comprenant le montant et la ou les date(s). Les renseignements fournis indiquent clairement que le montant est assurable à l’AE | | Supprimer les observations de la case 18 | 19: Choisir Indemnités d’assurance salaire (AE assurable) . 19 Date de début : Saisir la date de début du paiement 19 Date de fin : Saisir la date de fin du paiement 19 Montant ($) : Saisir le montant 19 Par jour ou Par semaine : Choisir le bouton radio appropriée. 19 Durée : Saisir le nombre de paiements |

| indemnité d’assurance salaire comprenant le montant et la ou les date(s). Les renseignements fournis indiquent clairement que le montant n’est pas assurable à l’AE | | Supprimer les observations de la case 18 | 19 : Choisir Indemnités d’assurance salaire (AE non assurable) . 19 Date de début : Saisir la date de début du paiement. 19 Date de fin : Saisir la date de fin du paiement. 19 Montant ($) : Saisir le montant 19 Par jour ou Par semaine : Choisir le bouton radio appropriée. 19 Durée : Saisir le nombre de paiements. |

| montant d’indemnités d’assurance-salaire fournis à la case 18, mais NON à la case 19, si l’information fournie n’indique pas clairement que le montant est assurable ou non. | | Laisser les observations dans la case 18 | |

| la mention suivante est inscrite à la case 18 : « Aucune indication sur le genre du paiement spécial inscrit à la case 19.» | | Laisser les observations dans la case 18 | |
```

```text
| Les commentaires dans la case 18indiquent : | Dans MSRE, remplir les champs suivants tel qu’indiqué : |

| Actions requises : | Options des autres cases : |

| il s’agit d’un RE modifié (le numéro de série du RE original est fourni). | Supprimer les observations de la case 18 | Pour les RE qui commencent par la lettre E : 2 - Nº de série du RE modifié ou remplacé : Saisir le numéro de série du RE original fourni. Pour les RE qui commencent par la lettre S, W ou M : Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . |

| une date de retour au travail est fournie | Supprimer les observations de la case 18 | 14 - Date prévue de rappel : Saisir la date prévue de rappel. |

| une date de rappel est fournie | Supprimer les observations de la case 18 | 14 - Date prévue de rappel : Saisir la date prévue de rappel. |

| l’information n ’ayant aucun impact sur le calcul ou l’admissibilité tels que : - Info taux (le taux de salaire horaire est de $) - Commentaires personnels (p. ex. Bonne chance Laurent) Autres information (p. ex. : sera de retour s’il y a du travail) | Supprimer les observations de la case 18 | |
```

```text
| Les 2 conditions à remplir : | Dans MSRE, remplir les champs suivants : |

| Les observations dans la case 18 indiquent que le MCE est lié à l’une des raisons suivantes : | Le code de MCE dans la case 16 est : | Actions requises : | Case 16 MCE : |

| Coronavirus, COVID-19 ou quarantaine | A, D, K ou N | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | Les changements seront apportés à partir du SNCT dans l’AT RE MCE litigieux. |
```

```text
| Les 2 conditions à remplir : | Dans MSRE, remplir les champs suivants : |

| Les observations dans la case 18 indiquent que le MCE est lié à l’une des raisons suivantes : | Le code de MCE dans la case 16 est : | Actions requises : | Case 16 MCE : |

| manque de travail ou l’employeur a entrepris de fermer son entreprise en raison du Coronavirus ou de la COVID-19 | A | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir A - Manque de travail / Fin de saison ou de contrat . |

| maladie ou quarantaine en raison du Coronavirus ou de la COVID-19 | D, K ou N | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir D - Maladie ou blessure . |

| client refuse de se présenter au travail en raison du Coronavirus ou de la COVID-19 | E, K ou M | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir E - Départ volontaire / Raisons médicales . |

| COVID-19, Coronavirus ou l’employé a demandé le RE en raison de la COVID-19 | K | Déplacer les observations de la case 18 vers la case Renseignements supplémentaires . | MCE : Choisir A - Manque de travail / Fin de saison ou de contrat . |
``` 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0931.dita`

Remarque :

Pour les observations dans la case 18 d’un RE TAP d’Air Canada, l’agent consulte le Bulletin d’information — Évènements majeurs en entreprise (EME) .
       [Bulletin d’information — Évènements majeurs en entreprise (EME)](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68)

     [Bulletin d’information — Évènements majeurs en entreprise (EME)](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0932.dita`

Remarque :

Les observations doivent remplir les conditions décrites dans le tableau pour être enlevées. 

### Avertissement

Source topic: `fr_FR/common_notes/note_c_0933.dita`

Avertissement :

Pour les observations liées au MCE, il est important de déterminer s’il y a un AT RE MCE litigieux en suspens pour le même RE et de choisir le tableau approprié.

S’il y a un AT RE MCE litigieux en suspens pour le même RE, il ne faut pas modifier la case 16 dans MSRE à moins qu’un avis contraire soit donné dans la procédure. Au besoin, l’information du MCE est modifiée dans l’AT RE MCE litigieux à partir de SNCT. 
