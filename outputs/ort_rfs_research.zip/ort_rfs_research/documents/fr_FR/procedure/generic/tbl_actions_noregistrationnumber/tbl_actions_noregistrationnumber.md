# Imagerie : Mesures à prendre pour les documents numérisés quand il n’y a pas de numéro d’enregistrement — Instructions

Source map: `fr_FR/procedure/generic/tbl_actions_noregistrationnumber/tbl_actions_noregistrationnumber.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/tbl_actions_noregistrationnumber/generic.dita`

```text
| DOCUMENTS | Nouveau calcul Note de bas de page * [Note de bas de page*](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#fn*) | Révisé Note de bas de page * [Note de bas de page*](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#fn*) | SNCT | IMAGERIE Classement |

| Agence du revenu du Canada (ARC) - Décision sur l’assurabilité | X | | RSDP | Action prise |

| Agence de revenu du Canada (ARC) - Avis de cotisation | | | AT AP | Action prise |

| Agence de revenu du Canada (ARC) - Lettre : les primes de l’AE payées | | | AT AP | Action prise |

| Antidate | | | AT AP | Action prise |

| Autorisation de divulguer des infos | | | RSDP | Services |

| C ertificat de décès / Prestataire décédé | | X | RSDP | Action prise |

| Certificat d’invalidité | | X | RSDP | Action prise |

| C ertificat médical | | X | RSDP | Action prise |

| Changement d’adresse (n’est pas saisi) | | | RSDP | Services |

| Changement de nom (n’est pas saisi) | | | RSDP | Services |

| Conflit collectif | | X | RSDP | Action prise |

| Courrier non livrable | | | ATAP | Action prise |

| D emande d’accès à l’information | | | RSDP | Services |

| Demande d’information (client ou autre) | | | RSDP | Services |

| Demande de prolongation de la période de prestations (PP) | | X | RSDP | Action prise |

| Demande de prolongation de la période de référence (PR) | X | | RSDP | Action prise |

| Demande d’un RE (INS3166 rempli) | X | | RSDP | Action prise |

| Désignation d’un représentant / Documents de l’ordonnance d’un tribunal provenant du Bureau du Tuteur et curateur public | | | RSDP et y inclure le nom du représentant | Services |

| E nquête sur la cession de prestations (CDP) | | | RSDP | Services |

| F aillite | | X | RSDP | Action prise |

| Faillite - Recouvrement de trop-payé (T-P) | | X | RSDP | Action prise |

| Formation | | X | RSDP | Action prise |

| Formulaire qui doit être rempli par un agent | | | RSDP | Services |

| G ains | | X | RSDP | Action prise |

| H ors Canada | | X | RSDP | Action prise |

| I mpôt - Demande de déductions | | | RSDP | Services |

| Incarcération (preuve) | | X | RSDP | Action prise |

| Indemnités des accidents du travail (IAT) | | X | RSDP | Action prise |

| INS5097-5098 (décision rendue) | | X | RSDP | Action prise |

| M andat annulé | | | RSDP | Services |

| Mandat non reçu - Remplacement (INS5207) | | | RSDP | Services |

| Mandat retourné | | | RSDP | Services |

| Mandat volé (INS2221) | | | RSDP | Services |

| Motif de cessation d’emploi (MCE) | | X | RSDP | Action prise |

| Meilleures semaines variable | X | | RSDP | Action prise |

| O mis de se présenter | | X | RSDP | Action prise |

| P ermis de travail (IMM1442 ou IMM1102) | | X | RSDP | Action prise |

| Preuve d’identité (copies) | | | RSDP | Services |

| Questionnaire - Niveau 1 ou 2 | | X | RSDP | Action prise |

| R echerches d’emploi | | X | RSDP | Action prise |

| Règlement de grief | X | | RSDP | Action prise |

| Révision d’une décision | | X | RSDP | Action prise |

| Statut implicite (preuve) | | X | RSDP | Action prise |

| T alons de paye demandés par un agent | X | | RSDP | Action prise |

| V isa de résident temporaire | | X | RSDP | Action prise |
```

**Notes de bas de page**

    Note de bas de page 2 
      Numéro d’enregistrement requis

Retour à la première référence de la note de bas de page *
           [Retour à la première référence de la note de bas de page*](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/tbl_actions_noregistrationnumber#fn*-1-rf) 
