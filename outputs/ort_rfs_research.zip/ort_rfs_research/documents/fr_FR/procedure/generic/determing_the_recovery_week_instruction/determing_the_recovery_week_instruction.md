# Déterminer la semaine de guérison — Instructions

Source map: `fr_FR/procedure/generic/determing_the_recovery_week_instruction/determing_the_recovery_week_instruction.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/determing_the_recovery_week_instruction/generic.dita`

Sommaire : Un client présentant une demande de prestations de maladie doit obtenir un certificat médical prouvant son incapacité à travailler en raison d’une maladie, d’un accident ou d’une mise en quarantaine. Si le client présente un certificat médical, l’agent doit le réviser pour s’assurer qu’il est acceptable et l’utiliser pour déterminer la semaine de guérison.

**Date de fin de l’incapacité**

La date de fin de l’incapacité correspond au dernier jour où le client est incapable de travailler. La période d’incapacité se termine le jour avant la date de guérison. Quand le certificat médical indique que le client est incapable de travailler jusqu’à une date spécifique, cette date est le dernier jour de l’incapacité.

**Date de guérison**

La date de guérison correspond au premier jour où le client est capable de travailler. C’est le jour après la date de fin de l’incapacité. Le certificat médical est utilisé pour déterminer la date de guérison.

**Semaine de guérison**

La semaine de guérison est la semaine jusqu’à laquelle les prestations de maladie sont payables.

S’il y a une date de guérison précise indiquée dans le certificat médical qui est du mardi au samedi, la semaine de guérison est la même semaine.

S’il y a une date de guérison précise indiquée dans le certificat médical qui est un dimanche ou un lundi (c.-à-d. la date de fin de l’incapacité est un samedi ou un dimanche), la semaine de guérison est la semaine précédente.

Lors du passage d’une année civile à l’autre, un médecin ou un autre professionnel de la santé peut écrire la mauvaise année civile dans un certificat médical lié à la période d’incapacité d’un client. Il n’est pas nécessaire de préciser la situation avec le client quand il n’y a aucun doute que cela a été fait par erreur en raison du changement d’année. Cela s’applique aux mois de janvier et février de chaque année.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0805.dita) 

**Déterminer la semaine de guérison**

Quand le client a présenté un certificat médical, l’agent consulte Déterminer si un certificat médical est acceptable avant de déterminer la semaine de guérison. La semaine de guérison est déterminée selon les renseignements du certificat médical, même si le certificat médical au dossier n’était pas demandé. Avant de déterminer la semaine de guérison, l’agent consulte Maladie : Date de début de l’incapacité — Tableau pour déterminer si une date de début de l’incapacité est requise et, si oui, quelle serait la semaine de début de l’incapacité.
       [Déterminer si un certificat médical est acceptable](/fr/procedure/task/determining_med_cert_valid.shtml) 
       [Maladie : Date de début de l’incapacité — Tableau](https://ort-orl.esdc-edsc.canada.ca/fr/procedure/generic/additionalresources/incapacity_start_date_sb.shtml)

**Saisir ou mettre à jour la semaine de guérison**

Pour une demande initiale, l’agent saisit la semaine de guérison dans le champ Date présumée ou réelle de guérison de l’écran Annexe - Prestations spéciales dans la version Web de SSA quand un certificat médical est présenté.

Pour une demande renouvelée ou continue, l’agent met à jour la semaine de guérison dans ETI.

**Déterminer la semaine de guérison dans une demande initiale**

Pour un DPP dans la s/c 2442 ou après, une semaine de guérison du DPP + 8 semaines peut être permise quand le motif de cessation d’emploi (MCE) est D - Maladie ou blessure dans les demandes de prestations de maladie ou pour des demandes de prestations de maladie suivies de prestations de maternité.

Pour un DPP dans la s/c 2441 ou avant, quand le MCE est D , l’agent peut permettre une semaine de guérison du DPP + 15 semaines dans une demande de prestations de maladie ou du DPP + 8 semaines dans une demande de prestations de maladie suivie de prestations de maternité.

**Déterminer la semaine de guérison pour une demande avec une inadmissibilité 16 - Certificat médical non fourni (D16)**

Si un client ne présente pas de certificat médical alors qu’il est demandé pour une demande de prestations de maladie, l’agent impose une inadmissibilité D16. Si le client présente par la suite le certificat médical, l’agent détermine la période d’incapacité à l’aide du certificat médical. Si le certificat médical confirme la totalité de la période d’incapacité que le client a indiquée, l’agent annule l’inadmissibilité D16. Si le certificat médical confirme seulement une partie de la période d’incapacité que le client a indiquée, l’agent modifie l’inadmissibilité D16.

**Déterminer la semaine de guérison d’une demande de prestations pour un client qui reçoit déjà des prestations de maladie**

Quand un client qui reçoit déjà des prestations de maladie présente un certificat médical, l’agent détermine la nouvelle semaine de guérison selon les renseignements du certificat médical.

Si une demande de prestations de maladie a initialement été établie avec une semaine de guérison correspondant au DPP + 8 semaines ou à la semaine de renouvellement + 8 semaines, l’agent ne modifie pas la semaine de guérison initiale quand les 2 conditions suivantes sont remplies :

- Le client présente ensuite un certificat médical sans date de guérison ou indiquant une date de guérison indéterminée, inconnue, incertaine ou indéfinie.

- Appliquer les directives sur la semaine de guérison pour ces situations ([la semaine qui inclut la date de la signature du médecin ou de l’autre professionnel de la santé + 8] ou [la semaine qui inclut la date de la consultation médicale + 8]) entraînerait une semaine de guérison qui est avant le DPP + 8 semaines ou à la semaine de renouvellement + 8 semaines.

Si le client a reçu des prestations de maladie après la date de guérison indiquée, l’agent impose une inadmissibilité D16 pour la période de l’incapacité qui n’est pas indiquée dans le certificat médical.

**Déterminer la semaine de guérison lors de la conversion des prestations régulières en prestations de maladie quand des prestations de maladie occasionnelle ont été versées**

Un client qui reçoit des prestations régulières, y compris des prestations de pêcheur, peut déclarer jusqu’à 4 semaines consécutives de prestations de maladie occasionnelle. Si le client déclare une cinquième semaine de maladie occasionnelle, la déclaration du prestataire est rejetée avec l’indicatif d’erreur C465. Si le client demande des prestations de maladie supplémentaires après avoir déclaré 4 semaines consécutives, que les prestations aient été versées au client ou non, une conversion en une demande de prestations de maladie est requise.

Un maximum de 8 semaines de prestations de maladie occasionnelle au total peut être payé dans une période de prestations (PP). Si le client déclare une neuvième semaine de maladie occasionnelle, la déclaration du prestataire est rejetée avec l’indicatif d’erreur C484. Un client qui a déjà reçu 8 semaines de maladie occasionnelle et qui n’est toujours pas capable de travailler doit présenter un certificat médical et demander une conversion à une demande de prestations de maladie.

Quand un client a déjà reçu des prestations de maladie occasionnelle et demande une conversion en une demande de prestations de maladie, le client n’a pas besoin de présenter un certificat médical si moins de 8 semaines de prestations de maladie occasionnelle ont été versées dans la PP. L’agent détermine la semaine de guérison de la façon suivante :

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0806.dita) 

L’agent détermine le nombre de semaines de prestations de maladie occasionnelle versées dans une PP en consultant le champ Semaines de maladie occasionnelle dans les onglets Sommaire et Prest. Spéciales dans ETI. Quand il détermine la semaine de guérison, l’agent doit utiliser uniquement le compteur de semaines de maladie occasionnelle pour obtenir le nombre de semaines de maladie occasionnelle versées.

**Déterminer la semaine de guérison dans une demande de prestations de maladie suivie de prestations de maternité**

Quand une cliente demande des prestations de maladie immédiatement suivies de prestations de maternité, l’agent consulte le tableau ci-dessous pour déterminer la semaine de guérison. Si la semaine de guérison est dans la fenêtre de maternité, une semaine de début de maternité externe est requise pour verser des prestations de maladie jusqu’à la semaine de guérison. Quand la semaine de début de maternité externe est atteinte, le système convertit automatiquement la demande en prestations de maternité. Si l’agent ne saisit pas de semaine de début de maternité externe, les prestations de maternité commencent automatiquement au début de la fenêtre de maternité.

Une fois que l’agent obtient le résultat du calcul dans la version Web de SSA, dans une demande initiale, l’agent modifie la semaine de guérison à une semaine administrative de guérison indéfinie dans la transaction M103 - Décision initiale (M103) ( Oui doit être indiqué sous Est indéterminée? ). Cela assure que la version Web de SSA ne postdate pas la demande incorrectement. Dans une demande renouvelée ou continue, l’agent saisit une semaine administrative de guérison 99-99-9999 dans la transaction Renouvellement/Révisé (M106) .

Si la semaine de guérison est avant le début de la fenêtre de maternité, l’agent n’ajuste pas la semaine de guérison réelle dans la transaction M103. Dans une demande renouvelée ou continue, l’agent saisit la semaine de guérison réelle dans la transaction M106. Il y aura un écart entre le dernier versement des prestations de maladie et le début des versements des prestations de maternité. Si la cliente n’est toujours pas en mesure de travailler pour des raisons médicales, elle doit présenter un autre certificat médical pour prolonger la semaine de guérison. Si la semaine de guérison ne peut pas être prolongée dans une demande de prestations de maladie, la cliente doit présenter une demande de renouvellement pour des prestations de maternité au début de la fenêtre de maternité.

**Semaine de guérison dans une demande initiale, de renouvellement ou de conversion d’une demande continue**

```text
| Renseignements au dossier | Semaine de guérison |

| Un certificat médical n’ a pas été demandé ou présenté. | Pour une demande initiale, le champ Date présumée ou réelle de guérison de l’écran Annexe - Prestations spéciales dans la version Web de SSA doit être laissé vide. La version Web de SSA calcule la semaine de guérison comme étant le DPP + 8 semaines dans une demande de prestations de maladie ou dans une demande de prestations de maladie suivies de prestations de maternité. Pour une demande renouvelée, la semaine de guérison est la semaine de renouvellement + 8 semaines. Pour une demande de conversion dans laquelle aucune prestation de maladie occasionnelle n’a été versée, la semaine de guérison est la semaine de conversion + 8 semaines. Pour une demande de conversion dans laquelle des prestations de maladie occasionnelles ont été versées, la semaine de guérison est la suivante : [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0807.dita) Un client qui a déjà reçu un total de 8 semaines de prestations de maladie occasionnelle et qui est toujours incapable de travailler doit présenter un certificat médical et demander une conversion à des prestations de maladie. Déterminer le nombre de semaines de prestations de maladie occasionnelle versées dans une PP en consultant le champ Semaines de maladie occasionnelle à l’onglet Sommaire ou Prest. Spéciales dans ETI. Pour déterminer la semaine de guérison, utiliser uniquement le compteur de semaines de maladie occasionnelle pour obtenir le nombre de semaines de maladie occasionnelle versées. Pour des exemples de calcul de la semaine de guérison quand les prestations de maladie ont été versées, consulter les tâches [Convertir des prestations régulières en prestations de maladie](/fr/procedure/task/conv_regsick.shtml) et [Convertir une demande de prestations régulières en prestations de maladie lorsque le client est dirigé en vertu de la LAE 25 — Demande continue](/fr/procedure/task/conv_regsick_eia25.shtml) . [Convertir des prestations régulières en prestations de maladie](/fr/procedure/task/conv_regsick.shtml) [Convertir une demande de prestations régulières en prestations de maladie lorsque le client est dirigé en vertu de la LAE 25 — Demande continue](/fr/procedure/task/conv_regsick_eia25.shtml) |

| Un certificat médical a été demandé, mais n’a pas été présenté (une inadmissibilité D16 indéterminée est requise). | Pour une demande initiale, le champ Date présumée ou réelle de guérison de l’écran Annexe - Prestations spéciales dans la version Web de SSA doit être laissé vide. Lors de la saisie de la demande, saisir manuellement une semaine administrative de guérison indéfinie dans la transaction M103 ( Oui doit être indiqué sous Est indéterminée? ). Pour générer automatiquement l’inadmissibilité D16, saisir la date d’échéance de l’AT lié au calcul dans la version Web de SSA dans le champ Certificat médical — Date d’échéance de l’écran Enregistrement — Information manquante . Si la version Web de SSA ne génère pas automatiquement l’inadmissibilité D16 lors du calcul de la demande, créer manuellement la transaction M161 lors du transfert de la demande. Pour une demande renouvelée ou de conversion dans une demande continue, saisir une semaine administrative de guérison indéfinie 99-99-9999 et imposer une inadmissibilité D16 dans la transaction M106 dans ETI. |

| Un certificat médical a été présenté, qu’il ait été demandé ou non, et n’ indique pas de date de guérison, ou indique une date de guérison indéterminée, inconnue, incertaine ou indéfinie. | La semaine de guérison est calculée comme la semaine de la date de début de l’incapacité (si elle est indiquée dans le certificat médical) + 8 semaines. Si le MCE est D pour une demande initiale ou renouvelée et qu’il n’y pas d’exclusions ou d’inadmissibilités, la semaine de guérison est calculée comme étant DPP + 8 semaines ou semaine de renouvellement + 8 semaines. Dans tous les autres cas, si la date de début de l’incapacité n’est pas indiquée dans le certificat médical, la semaine de guérison est calculée comme étant la plus hâtive des éventualités suivantes : - la semaine qui inclut la date de la signature du médecin ou de l’autre professionnel de la santé + 8 semaines; - la semaine qui inclut la date de la consultation médicale + 8 semaines. Si la demande a été initialement calculée sans certificat médical, ne pas mettre à jour la semaine de guérison, sauf si la semaine de la signature du médecin ou de l’autre professionnel de la santé + 8 semaines ou la semaine de la consultation médicale + 8 semaines est après le DPP + 8 semaines ou la semaine de renouvellement + 8 semaines (elle reste le DPP + 8 semaines ou la semaine de renouvellement + 8 semaines). |

| Le certificat médical indique que le client est en phase terminale ou palliative, ou qu’il est admissible à des prestations d’invalidité du Régime de pensions du Canada (RPC). | La semaine de guérison est indéfinie ( Oui doit être indiqué sous Est indéterminée? ). Quand une semaine de guérison saisie est indéfinie (selon le certificat médical qui indique que le client est en phase terminale ou palliative), la version Web de SSA postdate automatiquement la demande d’une semaine s’il y a une rémunération dans la semaine 1. Il ne faut pas postdater le DPP d’une demande avec une semaine de guérison indéfinie (selon le certificat médical qui indique que le client est en phase terminale ou palliative) en raison de la rémunération dans la semaine 1, sauf si le client a demandé précisément de postdater la demande. |

| Le certificat médical indique une date de guérison précise. | La date de guérison est la date précise indiquée dans le certificat médical. La semaine de guérison est la semaine au cours de laquelle la date de guérison a lieu, sauf si la date de guérison est un dimanche ou un lundi. Dans ce cas, la semaine de guérison est la semaine avant la date de guérison. Si le certificat médical indique une date de réévaluation, celle-ci est également considérée comme une date de guérison précise. |

| Le certificat médical indique que le client est malade pendant une période ou un délai déterminé, ou qu’il guérira dans une période ou un délai déterminé. | La semaine de guérison est calculée comme la semaine de la date de début de l’incapacité (si elle est indiquée dans le certificat médical) + [nombre déterminé ou nombre le plus élevé du délai]. Si la date de début de l’incapacité n’est pas indiquée dans le certificat médical, la semaine de guérison est calculée comme étant la plus hâtive des éventualités suivantes : - la semaine qui inclut la date de la signature du médecin ou de l’autre professionnel de la santé + [nombre déterminé ou nombre le plus élevé du délai]; - la semaine qui inclut la date de la consultation médicale + [nombre déterminé ou le nombre le plus élevé du délai]. |

| Le certificat médical indique que la cliente n’est pas en mesure de travailler pour des raisons médicales jusqu’à la date d’accouchement. | La semaine de guérison est la semaine avant la date d’accouchement prévue. Saisir une semaine administrative de guérison indéfinie dans la transaction M103 d’une demande initiale ( Oui doit être indiqué sous Est indéterminée? ) ou 99-99-9999 dans la transaction M106 d’une demande renouvelée ou continue. Saisir aussi une semaine de début de maternité qui correspond à la date d’accouchement prévue (ou à la date d’accouchement réelle si elle est connue) ou à la date du congé de maternité préétabli. Si le client habite au Québec, ne pas saisir des renseignements de maternité à l’écran Annexe - Prestations spéciales dans la version Web de SSA. |
``` 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0805.dita`

Exemple :

Le médecin ou le professionnel de la santé a rempli un certificat médical en janvier 2023 avec une date de guérison prévue le 31 janvier 2022. Il s’agit d’une erreur évidente, et la date de guérison doit être considérée comme le 31 janvier 2023 . 

### Callout

Source topic: `fr_FR/common_notes/note_c_0806.dita`

[semaine de la conversion] + [8 semaines] – [semaines de maladie occasionnelle] = [semaine de guérison]. 

### Callout

Source topic: `fr_FR/common_notes/note_c_0807.dita`

[semaine de conversion] + [8 semaines] – [semaines de prestations de maladie occasionnelle versées] = [semaine de guérison] 
