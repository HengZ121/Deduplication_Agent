# RE : Correction d’une erreur de validation pour un RE régulier (employeur non joint) — Instructions

Source map: `fr_FR/procedure/generic/correction_reg_2/correction_reg_2.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/correction_reg_2/generic.dita`

**Procédures connexes**

- Corriger une erreur pendant le calcul ou un nouveau calcul — RE régulier
         [Corriger une erreur pendant le calcul ou un nouveau calcul — RE régulier](/fr/procedure/task/correcting_roe_error_calculation_regular.shtml)

- Post-PU AE : Compléter un AT Évaluation pour le calcul RE Correction — RE régulier
         [Post-PU AE : Compléter un AT Évaluation pour le calcul RE Correction — RE régulier](/fr/procedure/task/post_eierb_completing_assessment_issue_roe_correction_wi_regular_roe.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0755.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0681.dita) 

* Les solutions possibles et les mesures à prendre doivent suivre l'ordre donné.

Choisir la section du RE qui contient le message d’erreur pour voir une liste en ordre alphabétique des messages rencontrés lors de la correction d’un RE.

- 4 - Nom de l’employeur
         [4 - Nom de l’employeur](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#nom)

- 6 - Genre de période de paie
         [6 - Genre de période de paie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#genre)

- 10 - Premier jour de travail
         [10 - Premier jour de travail](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#premier)

- 11 - Dernier jour payé
         [11 - Dernier jour payé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#dernier)

- 12 - Date de fin de la dernière période de paie
         [12 - Date de fin de la dernière période de paie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#fin)

- 14 - Date prévue de rappel
         [14 - Date prévue de rappel](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#rappel)

- 15A - Heures assurables totales
         [15A - Heures assurables totales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#heures)

- 15B - Rémunération assurable totale
         [15B - Rémunération assurable totale](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#totale)

- 15C - Périodes de paie détaillées
         [15C - Périodes de paie détaillées](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#paie)

- 16 - Raison du présent relevé d’emploi
         [16 - Raison du présent relevé d’emploi](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#raison)

- 17A -Paie de vacances
         [17A -Paie de vacances](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#vacances)

- 17B - Jour(s) férié(s)
         [17B - Jour(s) férié(s)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#jour)

- 17C - Autres sommes
         [17C - Autres sommes](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#autres)

- Répartition des sommes
         [Répartition des sommes](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#sommes)

- 19 - Paiements spéciaux
         [19 - Paiements spéciaux](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#paiements)

- Erreurs outrepassables
         [Erreurs outrepassables](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/correction_reg_2#erreurs)

**4 - Nom de l’employeur**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0667.dita) 

- Retourner à la tâche principale et communiquer avec le client.

**6 - Genre de période de paie**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0683.dita) 

- Déterminer si MSRE contient un RE antérieur du même employeur :

- Si oui, utiliser le même genre de période de paie que celui figurant sur le RE antérieur et retourner à la tâche principale.

- Si non , passer à l’étape 2.

- Déterminer si la case 15C est remplie :

- Si oui, passer à l’étape 3.

- Si non , retourner à la tâche principale et communiquer avec le client.

- Déterminer le type de RE :

- Si le numéro de série du RE commence par W ou M , passer à l’étape 5.

- Si le numéro de série du RE commence par S , déterminer si la case Nombre de rangées figurant dans MSRE (immédiatement sous le titre de la case 15C ) correspond à 27.

- Si oui, passer à l’étape 4.

- Si non , passer à l’étape 5.

- S’il s’agit d’un autre type de RE, passer à l’étape 4.

- Déterminer si la période visée par le RE est supérieure à 7 mois :

- Si oui, choisir le Genre de période de paie selon le nombre de périodes de paie figurant à la case 15C . Retourner à la tâche principale.
             [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0756.dita)

- Si non , retourner à la tâche principale et communiquer avec le client.

- Déterminer si la période visée par le RE est supérieure à 13 mois :

- Si oui, choisir le Genre de période de paie selon le nombre de périodes de paie figurant à la case 15C . Retourner à la tâche principale.
             [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0757.dita)

- Si non , retourner à la tâche principale et communiquer avec le client.

**10 - Premier jour de travail**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0684.dita) 

- Dans SNCT, déterminer si le client a déclaré un dernier jour payé identique à celui figurant sur le RE :

- Si non , passer à l’étape 2.

- Si oui, déterminer si le client a déclaré un premier jour de travail qui indique une période d’emploi d’au moins 13 mois.

- Si non , passer à l’étape 2.

- Si oui, utiliser le premier jour de travail indiqué sur la demande et retourner à la tâche principale.

- Dans ETI, déterminer si le client a fait l’objet d’une demande antérieure :

- Si non , passer à l’étape 4.

- Si oui, examiner les déclarations électroniques du client pour déterminer s’il a déclaré avoir travaillé pour le même employeur (le numéro de téléphone de l’employeur figurant dans les déclarations sera le même que celui figurant dans la demande ou dans le RE actuel).

- Si oui, passer à l’étape 3.

- Si non , passer à l’étape 4.

- Dans MSRE, déterminer s’il y a un autre RE provenant du même employeur :

- Si oui, passer à l’étape 4.

- Si non , suivre les directives suivantes :

- Utiliser la date du dimanche de la première semaine pour laquelle une rémunération a été déclarée ou la date déclarée à la case liée à l’emploi à temps plein de la déclaration comme premier jour de travail;

- Retourner à la tâche principale.

- Déterminer s’il existe un RE du même employeur pour une période d’emploi précédant celle visée par le RE erroné :

- Si non , passer à l’étape 7.

- Si oui, déterminer si le dernier jour de travail figurant sur le RE antérieur tombe dans l’année précédant le dernier jour de travail figurant dans le RE erroné :

- Si oui, passer à l’étape 5.

- Si non , passer à l’étape 6.

- Déterminer si une date de retour au travail figure sur le RE antérieur :

- Si oui, utiliser la date de retour au travail figurant sur le RE antérieur et retourner à la tâche principale.

- Si non , passer à l’étape 6.

- Si la demande actuelle contient une date déclarée, l’utiliser et retourner à la tâche principale.

- Retourner à la tâche principale et communiquer avec le client.

**11 - Dernier jour payé**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0685.dita) 

- Déterminer si le client a fourni les dates du premier et du dernier jour de travail dans la demande :

- Si non , passer à l’étape 3.

- Si oui, passer à l’étape 2.

- Déterminer s’il y a une raison de remettre en question la validité de la date figurant sur la demande ou si changer le dernier jour de travail à ce jour créerait une nouvelle erreur :

- Si oui, passer à l’étape 3.

- Si non, suivre les directives suivantes :

- Utiliser la date figurant sur la demande.

- Retourner à la tâche principale.

- Déterminer s’il y a une erreur évidente dans l’année consignée (erreur particulièrement courante au début d’une année civile) :

- Si non, retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre les directives suivantes :

- Modifier l’année afin de refléter la date exacte.

- Retourner à la tâche principale.

**12 - Date de fin de la dernière période de paie**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0758.dita) 

- Déterminer si la case 15C contient une date de fin de la période de paie valide pour la période de paie 1 :

- Si non , passer à l’étape 2.

- Si oui, utiliser la date de fin de la période de paie indiquée à la période de paie 1 et retourner à la tâche principale.

- Déterminer s’il existe un RE antérieur provenant de cet employeur :

- Si oui , passer à l’étape 3.

- Si non, passer à l’étape 4.

- Déterminer si le RE antérieur contient le même genre de période de paie que celui figurant dans le RE erroné et une date de fin de la dernière période de paie:

- Si non, passer à l’étape 4.

- Si oui, suivre les directives suivantes :

- Calculer la date de fin de la période de paie au moyen de la date de fin de la période de paie figurant dans le RE antérieur et de la date du dernier jour payé figurant dans le RE erroné.

             [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0759.dita) 

- Retourner à la tâche principale.

- Déterminer le genre de période de paie indiqué :

- S’il s’agit d’une période mensuelle et que la date de fin de la période de paie n’ est pas le dernier jour du mois :

- Remplacer le genre de période de paie par Mensuel non conventionnel et retourner à la tâche principale.

- S’il s’agit d’une période bimensuelle et que la date de fin de la période de paie n’ est ni le quinzième jour ni le dernier jour du mois :

- Remplacer le genre de période de paie par Bimensuel non conventionnel et retourner à la tâche principale.

- S’il s’agit d'une période mensuelle non conventionnelle et que la date de fin de la période de paie est le dernier jour du mois :

- Remplacer le genre de période de paie par Mensuel et retourner à la tâche principale.

- S’il s’agit d’une période bimensuelle non conventionnelle et que la date de fin de la période de paie est le quinzième jour ou le dernier jour du mois :

- Remplacer le genre de période de paie par Bimensuel et retourner à la tâche principale.

- Si aucun de ces choix ne s’applique, retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0688.dita) 

- Déterminer s’il existe un RE antérieur provenant de cet employeur :

- Si oui , passer à l’étape 2.

- Si oui, retourner à la tâche principale et communiquer avec le client.

- Déterminer si le RE antérieur contient le même genre de période de paie que le RE erroné et une date de fin de la période de paie finale :

- Si non, retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre les directives suivantes :

- Calculer la date de fin de la période de paie au moyen de la date de fin de la période de paie figurant dans le RE antérieur et de la date du dernier jour payé figurant dans le RE erroné.

         [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0759.dita) 

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0760.dita) 

- Déterminer si la case 15C contient une date de fin de la période de paie valide pour la période de paie 1 :

- Si non , passer à l’étape 2.

- Si oui, utiliser la date de fin de la période de paie indiquée à la période de paie 1 et retourner à la tâche principale.

- Déterminer s’il existe un RE antérieur provenant de cet employeur :

- Si oui , passer à l’étape 3.

- Si non, passer à l’étape 4.

- Déterminer si le RE antérieur contient le même genre de période de paie que celui figurant dans le RE erroné et une date de fin de la dernière période de paie :

- Si non, passer à l’étape 4.

- Si oui, suivre les directives suivantes :

- Calculer la date de fin de la période de paie au moyen de la date de fin de la période de paie figurant dans le RE antérieur et du dernier jour payé figurant dans le RE erroné.

             [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0761.dita) 

- Retourner à la tâche principale.

- Déterminer le genre de période de paie indiqué :

- S’il s’agit d’une période mensuelle et que la date de fin de la période de paie n’ est pas le dernier jour du mois :

- Remplacer le genre de période de paie par Mensuel non conventionnel et retourner à la tâche principale.

- S’il s’agit d’une période bimensuelle et que la date de fin de la période de paie n’ est ni le quinzième jour ni le dernier jour du mois :

- Remplacer le genre de période de paie par Bimensuel non conventionnel et retourner à la tâche principale.

- S’il s’agit d'une période mensuelle non conventionnelle et que la date de fin de la période de paie est le dernier jour du mois :

- Remplacer le genre de période de paie par Mensuel et retourner à la tâche principale.

- S’il s’agit d’une période bimensuelle non conventionnelle et que la date de fin de la période de paie est le quinzième jour ou le dernier jour du mois :

- Remplacer le genre de période de paie par Bimensuel et retourner à la tâche principale.

- Si aucun de ces choix ne s’applique, retourner à la tâche principale et communiquer avec le client.

**14 - Date prévue de rappel**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0692.dita) 

- Remplacer la date prévue de rappel par Date non connue.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0762.dita) 

- Remplacer la date prévue de rappel par Retour non prévu .

**15A - Heures assurables totales**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0763.dita) 

- Déterminer si toute la période d’emploi précède la période de référence :

- Si non, passer à l’étape 2.

- Si oui, suivre les directives suivantes :

- Déterminer le nombre de semaines d’emploi entières figurant à la case 15A et le multiplier par 35 heures par semaine.

- Déterminer le nombre de jours d’emploi supplémentaires qui ne tombaient pas dans les semaines d’emploi entières et le multiplier par 7 heures par jour.

- Additionner les 2 montants et le saisir à la case 15A .

- Retourner à la tâche principale.

- Déterminer si les cases 10 ou 11 sont erronées :

- Si non , retourner à la tâche principale et communiquer avec le client.

- Si oui, corriger l’une des cases ou les 2 et suivre les directives suivantes :

- Si cela mène à la correction de l’erreur figurant à la case 15A , retourner à la tâche principale.

- Si cela ne mène pas à la correction de l’erreur figurant à la case 15A , retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0764.dita) 

- Déterminer si le client a indiqué le taux de rémunération dans la demande :

- Si oui, passer à l’étape 2.

- Si non , retourner à la tâche principale et communiquer avec le client.

- Déterminer le premier jour qui pourrait être représenté par le montant figurant à la case 15B en retraçant l’évolution de la période d’emploi.
         [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0765.dita)

- Déterminer si le premier jour de travail indiqué est équivalent ou supérieur à la date déterminée ci-dessus :

- Si non , retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre les directives suivantes :

- Diviser le montant de la rémunération figurant à la case 15B par le taux de rémunération pour calculer le nombre d’heures.

- Saisir à la case 15A le nombre d’heures établi.

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0766.dita) 

- Supprimer le montant à la case 15A .

- Retourner à la tâche principale.

**15B - Rémunération assurable totale**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0767.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0768.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0769.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0770.dita) 

- Déterminer si le montant de la case 15B équivaut au montant total de toutes les sommes assurables versées à la cessation d’emploi :

- Si oui, passer à l’étape 2.

- Si non , passer à l’étape 4.

- Déterminer s’il existe un RE antérieur de cet employeur qui est clairement relié aux sommes versées à la cessation d’emploi :

- Si oui, passer à l’étape 3.

- Si non , passer à l’étape 4.

- Déterminer si tous les renseignements sont dans le RE (dans les champs Observations ou Renseignements supplémentaires ) concernant les raisons pour les montants et les dates des sommes versées à la cessation d’emploi :

- Si non , passer à l’étape 4.

- Si oui, suivre les directives suivantes :

- Ajouter les sommes versées à la cessation d’emploi (assurables et non assurables) au RE antérieur.

- Dans le champ Renseignements supplémentaires du RE antérieur, saisir les renseignements concernant la raison justifiant les sommes versées à la cessation d’emploi et les dates des versements.

- (Pour le RE erroné) Supprimer : Cocher la case.

- Renseignements supplémentaires : Saisir « Le RE a seulement été émis en raison de sommes versées à la cessation d’emploi. Le RE antérieur (no de série) a été corrigé. »

- Déterminer si le RE antérieur a servi au calcul de la période de prestations antérieure, et, le cas échéant, enregistrer un nouveau calcul .
                 [nouveau calcul](/fr/procedure/activity/recalculation.shtml)

- Retourner à la tâche principale.

- Déterminer si le champ Renseignements supplémentaires ou la case Commentaires indiquent clairement qu’une partie ou l’ensemble des montants figurant à la case 17C ne sont pas assurables. :

- Si non , passer à l’étape 5.

- Si oui, suivre les directives suivantes :

- Modifier la description des autres sommes figurant à la case 17C pour qu’elle corresponde à l’option « Autres sommes non assurables », selon le champ Renseignements supplémentaires .

- Retourner à la tâche principale.

- Déterminer si un seul type de somme figure à la case 17 :

- Si non , retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre l’une des directives suivantes :

- Si le choix indiqué est clairement un type assurable (p. ex. « Montant tenant lieu de préavis », mais pas « Autre »), ajouter la somme assurable versée à la cessation d’emploi indiquée au montant de la case 15B . Retourner à la tâche principale.

- Si le choix indiqué est un type qui nécessiterait normalement des précisions (p. ex. « Autre »), mais que le champ Renseignements supplémentaires indique clairement qu’il s’agit d’un montant assurable, ajouter la somme assurable versée à la cessation d’emploi indiquée au montant de la case 15B . Retourner à la tâche principale.

**15C - Périodes de paie détaillées**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0771.dita) 

- Déterminer si la rémunération est supérieure à 0,00 $ et inférieure à 1,00 $ :

- Si oui, remplacer le montant par 1,00 $ et retourner à la tâche principale.

- Si non , retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0772.dita) 

- Déterminer si le montant de la case 15B équivaut au montant total de toutes les sommes assurables versées à la cessation d’emploi :

- Si oui, passer à l’étape 2.

- Si non , passer à l’étape 4.

- Déterminer s’il y a un RE antérieur au dossier qui a été émis par l’employeur et qui est clairement lié aux sommes versées à la cessation d’emploi :

- Si oui, passer à l’étape 3.

- Si non , passer à l’étape 4.

- Déterminer si tous les renseignements figurent sur le RE (les champs Observations et Renseignements supplémentaires ) afin d’établir la raison et la date des versements :

- Si non , passer à l’étape 4.

- Si oui, suivre les directives suivantes :

- Ajouter les sommes versées à la cessation d’emploi (assurables et non assurables) au RE antérieur.

- Dans le champ Renseignements supplémentaires du RE antérieur, saisir les renseignements concernant la raison justifiant les sommes versées à la cessation d’emploi et les dates des versements.

- (Pour le RE erroné) Supprimer : Cocher la case.

- Renseignements supplémentaires : Saisir « Le RE a seulement été émis en raison de sommes versées à la cessation d’emploi. Le RE antérieur (numéro de série) a été corrigé. »

- Déterminer si le RE antérieur a servi au calcul de la période de prestations antérieure, et, le cas échéant, consulter Nouveau calcul .
                 [Nouveau calcul](/fr/procedure/activity/recalculation.shtml)

- Retourner à la tâche principale.

- Déterminer si le dernier jour payé de la case 11 tombe dans la période de paie précédant immédiatement la date qui figure à la case 12  :

- Si oui, passer à l’étape 5.

- Si non , déterminer si le dernier jour de travail figurant dans la demande du client tombe dans la période de paie précédant immédiatement celle qui se trouve à la case 12 .

- Si oui, changer la case 11 pour qu’elle corresponde au dernier jour de travail du client.

- Si non , passer à l’étape 6.

- Déterminer si la case 12 indique que la date de la dernière période de paie est invalide :

- Si non , passer à l’étape 6.

- Si oui, suivre les directives suivantes :

- Remplacer la case 12 par la bonne date de fin de la période de paie, selon la date de la case 11 .

- Remplacer les montants indiqués dans chaque période de paie par la période de paie précédente (p. ex. la période de paie 3 devient la période de paie 2).

- Additionner les sommes assurables versées à la cessation d’emploi et indiquer le total à la période de paie 1.

- Déterminer s’il est nécessaire d’ajouter une période de paie supplémentaire à la case 15C , et, le cas échéant, établir le montant estimatif selon le montant le plus bas qui n’est pas de 0,00 $ parmi les périodes de paie restantes de la case 15C.

- Retourner à la tâche principale.

- Déterminer si le champ Renseignements supplémentaires ou la case Commentaires indique clairement qu’une partie ou l’ensemble des montants figurant à la case 17C ne sont pas assurables :

- Si non , passer à l’étape 7.

- Si oui, suivre les directives suivantes :

- Modifier la description des autres sommes figurant à la case 17C pour qu’elle corresponde à l’option des autres sommes non assurables, selon le champ Renseignements supplémentaires ou la case Commentaires .

- Retourner à la tâche principale.

- Déterminer si un seul type de somme figure à la case 17 :

- Si non , retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre l’une des directives suivantes :

- Si le choix indiqué est clairement un type assurable (p. ex. Indemnité de préavis , mais pas Autre ajouter la somme assurable versée à la cessation d’emploi indiquée au montant de la case 15B et de la période de paie 1 de la case 15C . Retourner à la tâche principale.

- Si le choix indiqué est un type qui nécessiterait normalement des précisions (p. ex. Autre ), mais que le champ Renseignements supplémentaires indique clairement qu’il s’agit d’un montant assurable, ajouter la somme assurable versée à la cessation d’emploi indiquée au montant de la case 15B et de la période de paie 1 de la case 15C .

- Retourner à la tâche principale.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0773.dita) 

- Déterminer si 0,00 $ a été déclaré pour la période de paie qui comprend le premier jour de travail :

- Si oui, passer à l’étape 2.

- Si non , passer à l’étape 3.

- Estimer le montant de la rémunération de la période de paie dans laquelle tombe le premier jour de travail de la façon suivante :

- Calculer le nombre de jours de travail inclus dans la période de paie dans laquelle tombe le premier jour de travail.

         [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0774.dita) 

- Établir le taux quotidien estimatif selon les autres périodes de paie ou, si c’est impossible, multiplier le salaire minimum par le nombre d’heures.

- Estimer le montant de la rémunération versée pour la période de paie dans laquelle tombe le premier jour de travail en utilisant le taux quotidien estimatif et le nombre de jours de la période de paie.

         [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0775.dita) 

- Estimer le montant de la rémunération versée pour la période de paie dans laquelle tombe le premier jour de travail en utilisant le taux quotidien estimatif et le nombre de jours de la période de paie.

- Saisir le montant calculé dans la période de paie qui comprend le premier jour de travail.

- Soustraire le même montant de la rémunération versée pour la période de paie suivante.

         [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0776.dita) 

- Retourner à la tâche principale.

- Déterminer si la rémunération est supérieure à 0,00 $ et inférieure à 1,00 $ :

- Si non , retourner à la tâche principale et communiquer avec le client.

- Si oui, remplacer le montant par 1,00 $ et retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0777.dita) 

- Déterminer si la rémunération est supérieure à 0,00 $ et inférieure à 1,00 $ :

- Si oui, remplacer le montant par 1,00 $ et retourner à la tâche principale.

- Si non , retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0705.dita) 

- Déterminer si les heures indiquées dans la période de paie 1 sont 0.00 :

- Si oui, passer à l’étape 2.

- Si non, passer à l’étape 5.

- Déterminer s’il y a des sommes assurables versées à la cessation d’emploi :

- Déterminer si la rémunération équivaut aux sommes assurables versées à la cessation d’emploi :

- Si non, retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre les directives suivantes :

- Ajouter la rémunération de la période de paie 1 à la période de paie 2.

- Remplacer les montants indiqués dans chaque période de paie par la période de paie précédente (p. ex. la période de paie 3 devient la période de paie 2).

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0706.dita) 

- Déterminer si la rémunération est supérieure à 0,00 $ et inférieure à 1,00 $ :

- Si non , retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre les directives suivantes :

- Remplacer les heures par 0.01.

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0707.dita) 

- Déterminer si le montant de la rémunération est indiqué pour la même période de paie :

- Si oui, passer à l’étape 2.

- Si non , déterminer si la rémunération est de 0,00 $.

- Si oui, remplacer le nombre d’heures par 0,00 et retourner à la tâche principale.

- Si non , retourner à la tâche principale et communiquer avec le client.

- Déterminer si la période de l’emploi est détaillée à la case 15C :

- Si oui, calculer le nombre d’heures à l’aide des cases 15A et 15C et retourner à la tâche principale.

- Si non, suivre les directives suivantes :

- Supposer que le montant de la rémunération est exact.

- Remplacer le nombre d’heures par 0,01.

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0708.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0709.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0710.dita) 

- Déterminer si de multiples périodes de paie figurent à la case 15C :

- Si oui, passer à l’étape 2.

- Si non , modifier la date de fin de la période de paie de la case 15C pour qu’elle corresponde à celle de la case 12 et retourner à la tâche principale.

- Déterminer si toutes les dates de fin de la période de paie de la case 15C sont exactes, selon le genre de période de paie:

- Si non , passer à l’étape 3.

- Si oui, modifier la case 12 pour qu’elle corresponde à la date de fin de la période de paie 1 figurant à la case 15C et retourner à la tâche principale.

- Déterminer si la période de paie 1 semble être la seule période erronée :

- Si oui, suivre les directives suivantes :

- En utilisant le genre de période de paie et la date de fin de la période de paie 2, déterminer la date de fin exacte de la période de paie suivant la période de paie 2 et modifier la période de paie 1 pour tenir compte de cette nouvelle date.
                 [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0778.dita)

- Remplacer la case 12 par la nouvelle valeur correspondant à la période de paie 1 de la case 15C .

- Retourner à la tâche principale.

- Si non, suivre les directives suivantes :

- Apporter des corrections lorsqu’il y a des périodes de paie manquantes ou en double figurant à la case 15C .

- Modifier la période de paie 1 de la case 15C pour qu’elle corresponde à la case 12 .

- Si d’autres dates de fin de la période de paie sont maintenant erronées, les rajuster selon la nouvelle valeur figurant à la période de paie 1 de la case 15C et le genre de période de paie.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0779.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0780.dita) 

- Déterminer si la date en double a été saisie en raison d’une date de fin d’une période de paie manquante :

- Si oui, saisir la date de la période de paie manquante au lieu de la date en double et retourner à la tâche principale.

- Si non, retourner à la tâche principale et communiquer avec l’employeur.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0781.dita) 

- Déterminer si le montant de la case 15B est supérieur au total des montants figurant à la case 15C :

- Si oui, passer à l’étape 2.

- Si non , passer à l’étape 3.

- Déterminer si une seule période de paie est vide :

- Si non, retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre les directives suivantes :

- Calculer le montant de la période de paie vide en soustrayant la rémunération totale de la case 15C du montant de la case 15B .

- Retourner à la tâche principale.

- Déterminer si la rémunération totale des périodes de paie requises de la case 15C équivaut au montant de la case 15B :

- Si non , retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre les directives suivantes :

- Enlever le montant des périodes de paie supplémentaires.

- Retourner à la tâche principale.

**16 - Raison du présent relevé d’emploi**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0677.dita) 

- Déterminer si un motif de cessation d’emploi était indiqué dans la demande :

- Si oui, l’utiliser et retourner à la tâche principale.

- Si non , retourner à la tâche principale et communiquer avec le client.

**17A - Paie de vacances**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0782.dita) 

- Déterminer si le montant est inférieur à 1,00$ :

- Si non , retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre les directives suivantes :

- Supprimer le montant.

- Si un motif a été choisi aux fins de justification de la paie de vacances, choisir l’option vide dans le menu déroulant.

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0715.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0716.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0783.dita) 

- Retourner à la tâche principale et communiquer avec le client.

**17B - Jour(s) férié(s)**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0784.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0785.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0786.dita) 

- Déterminer si le montant est inférieur à 1,00 $ :

- Si non , retourner à la tâche principale et communiquer avec le client.

- Si oui, suivre les directives suivantes :

- Supprimer le montant.

- Supprimer la date liée au montant.

- Retourner à la tâche principale.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0721.dita) 

- Retourner à la tâche principale et communiquer avec le client.

**17C - Autres sommes**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0722.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0787.dita) 

- Déterminer si le montant est inférieur à 1,00$ :

- Si oui et qu’une option a été choisie, choisir l’option vide.

- Si non , retourner à la tâche principale et communiquer avec le client

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0788.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0725.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0726.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0727.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0789.dita) 

- Retourner à la tâche principale et communiquer avec le client.

**Répartition des sommes**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0790.dita) 

- Réviser et corriger les erreurs de saisie des données.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0791.dita) 

- Réviser et corriger les erreurs de saisie des données.

**19 - Paiements spéciaux**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0729.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0730.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0731.dita) 

- Déterminer si des détails suffisants concernant le paiement spécial (c.-à-d. le montant et les dates) sont disponibles afin de cocher la case appropriée :

- Si oui, cocher la case appropriée de la période de congé en fonction des détails du paiement spécial. Retourner à la tâche principale.

- Si non, retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0732.dita) 

- Utiliser le jour suivant le dernier jour de travail indiqué dans la demande.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0792.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0734.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0735.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0736.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0737.dita) 

- Déterminer si des détails suffisants concernant le paiement spécial (c.-à-d. le montant et les dates) sont disponibles afin de cocher la case appropriée :

- Si oui, cocher la case appropriée de la période de congé en fonction des détails du paiement spécial. Retourner à la tâche principale.

- Si non, retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0738.dita) 

- Utiliser le jour suivant le dernier jour de travail indiqué dans la demande.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0739.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0793.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0794.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0795.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0796.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0797.dita) 

- Déterminer si des détails suffisants concernant le paiement spécial (c.-à-d. le montant et les dates) sont disponibles afin de cocher la case appropriée :

- Si oui, cocher la case appropriée de la période de congé en fonction des détails du paiement spécial. Retourner à la tâche principale.

- Si non, retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0798.dita) 

- Déterminer si des détails suffisants concernant le paiement spécial (c.-à-d. le montant et les dates) sont disponibles afin de cocher la case appropriée :

- Si oui, cocher la case appropriée de la période de congé en fonction des détails du paiement spécial. Retourner à la tâche principale.

- Si non, retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0799.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0747.dita) 

- Déterminer si des détails suffisants concernant le paiement spécial (c.-à-d. le montant et les dates) sont disponibles afin de cocher la case appropriée :

- Si oui, cocher la case appropriée de la période de congé en fonction des détails du paiement spécial. Retourner à la tâche principale.

- Si non, retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0748.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0749.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0750.dita) 

- Déterminer si des détails suffisants concernant le paiement spécial (c.-à-d. le montant et les dates) sont disponibles afin de cocher la case appropriée :

- Si oui, cocher la case appropriée de la période de congé en fonction des détails du paiement spécial. Retourner à la tâche principale.

- Si non, retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0751.dita) 

- Retourner à la tâche principale et communiquer avec le client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0752.dita) 

- Retourner à la tâche principale et communiquer avec le client.

**Erreurs outrepassables**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0800.dita) 

- Déterminer si la case 15C est remplie dans les deux RE dont les périodes se chevauchent :

- Si oui, passer à l’étape 2.

- Si non , retourner à la tâche principale et communiquer avec le client.

- Déterminer si l’examen des montants des périodes de paie indique clairement que le RE subséquent comprend des renseignements provenant du RE antérieur :

- Si non , retourner à la tâche principale et communiquer avec le client.

- Si oui, dans le RE subséquent, suivre les directives suivantes :

- Supprimer toute période de paie déjà comprise dans le RE antérieur.

- Supprimer toute période de paie indiquant 0.00 $ comme montant de la rémunération qui tombe immédiatement après le dernier jour de travail du RE antérieur.

- À la case 10 , modifier le premier jour de travail afin qu’il corresponde au premier jour de travail de la période de paie la plus ancienne comprenant un montant de rémunération.

- Supprimer le montant de la case 15B .

- Déterminer si des heures figurent à la case 15C :

- Si non , passer à l’étape 4.

- Si oui, suivre les directives suivantes :

- Additionner les heures provenant des périodes de paie restantes.

- Saisir le nombre total d’heures à la case 15A .

- Retourner à la tâche principale.

- Dans SNCT, déterminer si le taux de rémunération figure dans la demande :

- Si oui, passer à l’étape 5.

- Si non , suivre les directives suivantes :

- Communiquer avec le client pour obtenir le taux de rémunération ou le nombre estimatif d’heures avant de poursuivre.

- Si le client a fourni un nombre estimatif d’heures, le saisir à la case 15A et retourner à la tâche principale.

- Si le client a fourni le taux de rémunération, passer à l’étape 5.

- Estimer le nombre d’heures à inscrire à la case 15A de la façon suivante :

- Si le numéro de série du RE commence par W :

- Utiliser le montant total de la rémunération restante figurant à la case 15C et le diviser par le taux de rémunération.

- Saisir ce montant à la case 15A .

- Retourner à la tâche principale.

- Si le numéro de série du RE ne commence pas par W :

- Utiliser le montant total de la rémunération restante figurant à la case 15C et le diviser par le taux de rémunération. Ceci donne le nombre d’heures pour la période visée par le RE qui correspond à la rémunération.

- Déterminer le nombre de jours que la rémunération figurant à la case 15C représente.

- Diviser le nombre d’heures par le nombre de jours pour calculer le nombre quotidien moyen d’heures.

- Déterminer le nombre de jours que le nombre d’heures figurant dans le RE devrait représenter.

- Multiplier le nombre quotidien moyen d’heures par le nombre de jours que le nombre d’heures figurant dans le RE représente.

- Retourner à la tâche principale. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0755.dita`

Remarque :

Ce tableau vous aidera à effectuer certaines corrections en attendant les informations de la part de l’employeur. Un contact avec l’employeur devrait toujours être tenté avant et après avoir suivi les étapes décrites dans ce tableau. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0681.dita`

Remarque :

Pour un AT RE Correction, un calcul initial ou un nouveau calcul concernant un RE du gouvernement du Canada qui doit être corrigé, consulter RE émis par le gouvernement du Canada — Instructions .
       [RE émis par le gouvernement du Canada — Instructions](/fr/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [RE émis par le gouvernement du Canada — Instructions](/fr/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Info

Source topic: `fr_FR/common_notes/note_c_0667.dita`

Message d’erreur : « Le nom de l’employeur est requis. » (04X000NM10485) 

### Info

Source topic: `fr_FR/common_notes/note_c_0683.dita`

Message d’erreur : « Un genre de période de paie valide est requis. » (06X000TP10257) 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0756.dita`

Exemple :

Si le nombre de période de paie est 27, choisir Hebdomadaire. Si le nombre de période de paie est 14, choisir Quinzaine. Si le nombre de période de paie est 7, choisir Mensuel. Si le nombre de période de paie est 13, choisir Bimensuel. Note concernant les périodes de paie Mensuel et Bimensuel : Examiner la date figurant à la case 12 , et si elle ne correspond pas au dernier jour du mois, au quinzième jour du mois ou au dernier jour du mois (s’il s’agit d’une période bimensuelle), la période de paie est non conventionnelle. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0757.dita`

Exemple :

Si le nombre de période de paie est 53 : Choisir Hebdomadaire . Si le nombre de période de paie est 27 : Choisir Quinzaine . Si le nombre de période de paie est 13 : Choisir Mensuel . Si le nombre de période de paie est 25 : Choisir Bimensuel . Si le nombre de période de paie est 14 : Choisir 13 périodes de paie par année . Remarque concernant le genre « Mensuel » et « Bimensuel » : Examiner la date figurant à la case 12 , et si elle ne correspond pas au dernier jour du mois, au quinzième jour du mois ou au dernier jour du mois (s’il s’agit d’une période bimensuelle), la période de paie est non conventionnelle. 

### Info

Source topic: `fr_FR/common_notes/note_c_0684.dita`

Message d’erreur : « Le premier jour de travail est requis. » (10X000DT10481) 

### Info

Source topic: `fr_FR/common_notes/note_c_0685.dita`

Message d’erreur : « Le dernier jour payé doit être postérieur ou égal au premier jour de travail. » (11X000DT10017) 

### Info

Source topic: `fr_FR/common_notes/note_c_0758.dita`

Message d’erreur : « La date de fin de la dernière période ne peut pas être plus de :

- 6 jours après le dernier jour payé, basé sur une période de paie Hebdomadaire. » (12X000DT10025)

- 13 jours après le dernier jour payé, basé sur une période de paie à la Quinzaine. » (12X000DT10019)

- 15 jours après le dernier jour payé et ne doit pas être le 15ième jour ou le dernier jour du mois (à l’exception du 28 et 29 de février), basé sur une période de paie Bimensuelle non conventionnelle. » (12X000DT10023)

- 15 jours après le dernier jour payé et doit être le 15ième jour ou le dernier jour du mois, basé sur une période de paie Bimensuelle. » (12X000DT10022)

- 27 jours après le dernier jour payé, basé sur 13 périodes de paie par année. » (12X000DT10024)

- 30 jours après le dernier jour payé et ne doit pas être le dernier jour du mois (à l’exception du 28 et 29 février), basé sur une période de paie mensuelle non conventionnelle. » (12X000DT10021)

- 30 jours après le dernier jour payé et doit être le dernier jour du mois, basé sur une période de paie Mensuelle. » (12X000DT10020)

Il est important de reconnaître que, si une date de fin de la période de paie inexacte figure dans le RE, les heures et la rémunération assurables peuvent avoir été calculées de façon inexacte à partir d’un nombre de périodes de paie erroné. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0759.dita`

Exemple :

Dernier jour de travail figurant dans le RE erroné : 14 septembre 2012.

Genre de période de paie figurant dans les 2 RE : Bimensuel non conventionnel. Date de fin de la période de paie figurant dans le RE antérieur : 24 mars 2012. Date de fin de la période de paie établie dans le RE erroné : 24 septembre 2012. 

### Info

Source topic: `fr_FR/common_notes/note_c_0688.dita`

Message d’erreur : « La date de fin de la dernière période de paie est requise. » (12X000DT10482) 

### Info

Source topic: `fr_FR/common_notes/note_c_0760.dita`

Message d’erreur : « La date de fin de la dernière période de paie doit être postérieure ou égale au dernier jour payé. » (12X000DT10018)

Il est important de reconnaître que, si une date de fin de la période de paie inexacte figure dans le RE, les heures et la rémunération assurables peuvent avoir été calculées de façon inexacte à partir d’un nombre de périodes de paie erroné. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0761.dita`

Exemple :

Dernier jour de travail figurant dans le RE erroné : 14 septembre 2012. Genre de période de paie figurant dans les deux RE : Bimensuel non conventionnel. Date de fin de la période de paie figurant dans le RE antérieur : 24 mars 2012. Date de fin de la période de paie établie dans le RE erroné : 24 septembre 2012. 

### Info

Source topic: `fr_FR/common_notes/note_c_0692.dita`

Message d’erreur : « La date prévue de rappel doit être postérieure au dernier jour payé <LDFWP>. » (14X000DT10029) 

### Info

Source topic: `fr_FR/common_notes/note_c_0762.dita`

Message d’erreur : « Le code de la date prévue de rappel ne peut être ‘Y – Date prévue de rappel’ lorsque la raison du présent relevé d’emploi est :

- E. » (14X000TP10026)

- G. » (14X000TP10027)

- M. » (14X000TP10028)

Le fait qu’une date prévue de rappel soit accompagnée du motif de cessation d’emploi E - Départ volontaire , G - Retraite obligatoire ou M - Congédiement , est contradictoire. Si le recueil de faits a déterminé que le motif de cessation d’emploi figurant sur le RE est exact, la date prévue de rappel doit être remplacée par Retour non prévu . 

### Info

Source topic: `fr_FR/common_notes/note_c_0763.dita`

Message d’erreur : « Les heures assurables totales ne peuvent dépasser le plus petit de 8 904 ou (dernier jour payé <LDFWP> premier jour de travail <FDW> + 1) x 24. » (15A000HR10031)

Le RE contient un nombre d’heures impossible pour la période d’emploi. Il est possible que l’employeur ait inversé les entrées des cases 15A et 15B . 

### Info

Source topic: `fr_FR/common_notes/note_c_0764.dita`

Message d’erreur : « Les heures assurables totales doivent être entre 1 et 8 904 inclusivement (espace ajouté pour la lisibilité seulement). » (15A000HR10459)

Il est possible que l’employeur ait inversé les entrées des cases 15A et 15B . 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0765.dita`

Exemple :

Genre de période de paie : Mensuel. Date de fin de la dernière période de paie : 30 septembre 2013. Nombre maximal de période de paie devant figurer à la case 15B : 7. Premier jour qui pourrait être représenté par la case 15B : 1er mars 2013. 

### Info

Source topic: `fr_FR/common_notes/note_c_0766.dita`

Message d’erreur : « Les heures assurables doivent être égales au total des heures assurables (le total des heures doit toujours être arrondi au chiffre entier suivant). » (15A000HR10032)

Cette erreur apparaît sur les RE de la série S et survient parce que le nombre d’heures dans la case 15C n’est pas égal au nombre d’heures enregistrées dans la case 15A . 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0767.dita`

Remarque :

La rémunération assurable totale d’un RE peut aller de 1,00 $ à 9,999 999,99 $. Lorsque le montant est plus grand que 999 999,99 $, l’agent doit le modifier à 999 999,99 $ dans MSRE. 

### Info

Source topic: `fr_FR/common_notes/note_c_0768.dita`

Message d’erreur : « Le montant de la rémunération assurable totale doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement. » (15B000AM10034)

Lorsque c’est le cas, le montant doit être confirmé auprès du client. Si le client confirme que le montant est moins que 1,00 $ et plus que 0 $, saisir 1,00 $. Si le client confirme que le montant est supérieur à 999 999,99, l’agent de Niveau 1 qui calcule la demande doit suivre les directives suivantes :

- saisir le montant de la rémunération de la case 15B à 999 999,99 $ consigner les renseignements dans un RSDP 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0769.dita`

Remarque :

Déterminer la rémunération hebdomadaire normale moyenne (RHNM) et la rémunération moyenne de la dernière semaine de travail (RMDST)selon la rémunération réelle du client. Dans MSRE, dans la section Répartition des sommes , remplir les champs suivants :

- Rémunération hebdomadaire normale moyenne : Saisir le montant moyen de la RHNM tel que calculé.

- Rémunération moyenne de la dernière semaine de travail : Saisir le montant de la RMDST tel que calculé.

- Retourner à la tâche principale et communiquer avec le client. 

### Info

Source topic: `fr_FR/common_notes/note_c_0770.dita`

Message d’erreur : « La rémunération assurable totale doit inclure la rémunération assurable ainsi que le montant total des sommes assurables de cessation d'emploi fourni. » (15B000AM10033)

Cette erreur survient dans les cas suivants :

- Les sommes assurables versées à la cessation d’emploi peuvent avoir été exclues de façon erronée du montant total de la rémunération figurant à la case 15B .

- Les sommes versées à la cessation d’emploi figurant à la case 17 peuvent avoir été considérées par erreur comme des sommes assurables.

- Au lieu d’un RE original modifié, un nouveau RE a été émis par erreur et fait uniquement état de sommes versées après la cessation d’emploi. Il est important de noter que, durant le calcul, si des sommes versées à la cessation d’emploi ont été reçues à une date ultérieure, la raison du versement peut avoir une répercussion sur la date à laquelle les sommes ont été versées. Consulter la procédure de Rémunération pour obtenir de plus amples renseignements.
         [Rémunération](/fr/procedure/activity/earnings.shtml)

     [Rémunération](/fr/procedure/activity/earnings.shtml) 

### Info

Source topic: `fr_FR/common_notes/note_c_0771.dita`

Message d’erreur : « Le montant de la rémunération assurable de la période de paie 1 doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (15C001AM10041) 

### Info

Source topic: `fr_FR/common_notes/note_c_0772.dita`

Message d’erreur : « Le montant de la rémunération assurable de la période de paie 1 doit inclure la rémunération assurable ainsi que le montant total des sommes assurables de cessation d'emploi fourni. » (15C001AM10047)

Les sommes assurables versées à la cessation d’emploi peuvent avoir été versées au cours d’une période de paie suivant celle dans laquelle s’inscrit le dernier jour de travail du client, et la période de paie 1 peut être inexacte et ne comprendre que les sommes assurables versées à la cessation d’emploi. L’agent doit donc vérifier le dernier jour payé figurant sur le RE, car l'employeur peut l'avoir rempli de façon inexacte en indiquant la date à laquelle des sommes assurables versées en raison d’une cessation d’emploi ont été payées.

Les sommes assurables versées à la cessation d’emploi peuvent avoir été exclues de façon erronée du montant total de la rémunération figurant à la période de paie 1 de la case 15C .

Les sommes versées à la cessation d’emploi figurant à la case 17 peuvent avoir été considérées par erreur comme des sommes assurables.

Au lieu d’un RE original modifié, un nouveau RE a été émis par erreur et fait uniquement état de sommes versées après la cessation d’emploi. Il est important de noter que, durant le calcul, si des sommes versées à la cessation d’emploi ont été reçues à une date ultérieure, la raison du versement peut avoir une répercussion sur la date à laquelle les sommes ont été versées. Consulter la procédure de Rémunération pour obtenir de plus amples renseignements.
       [Rémunération](/fr/procedure/activity/earnings.shtml)

     [Rémunération](/fr/procedure/activity/earnings.shtml) 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0773.dita`

Message d’erreur : « Le montant de la rémunération assurable de la période de paie <nn> contenant le premier jour de travail doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (15C0nnAM10043 <nn> = numéro de la période de paie)

Le premier jour de travail peut être incorrect, ou au moment de compléter les périodes de paie, l’employeur a peut-être inscrit à la case 15C les heures et la rémunération du premier jour de travail dans une période de paie subséquente.

Exemple :

Le premier jour de travail de l’employé est le 9 août. Le 13 août, l’employeur remplit la feuille de paie de la période du 5 au 11 août, mais l’employé n’est pas officiellement inscrit à la feuille de paie. Les montants de la rémunération de la période du 9 au 11 août est incluse dans la période de paie qui se termine le 18 août. Les détails du RE indiquent incorrectement 0.00 $ en tant que la rémunération de la période de paie qui se termine le 11 août. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0774.dita`

Exemple :

Genre de période de paie : Mensuel Premier jour de travail : 29 septembre 2013. Le premier jour de travail tombe dans la période de paie qui s’étend du 1er au 30 septembre 2013. Nombre de jours de travail pour la période de paie dans laquelle tombe le premier jour de travail : 2 (29 et 30 septembre). 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0775.dita`

Exemple :

Période de paie qui s’étend du 1er au 30 novembre : 30 jours. Rémunération versée pour la période de paie qui s’étend du 1er au 30 novembre : 1 800 $. Taux quotidien moyen : 1 800 $/30 jours = 60 $. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0776.dita`

Exemple :

La période de paie 6 est la période de paie dans laquelle tombe le premier jour de travail. La rémunération versée pour la période de paie 6 est estimée à 100 $. La rémunération versée pour la période de paie 5 est de 0,00 $. La période de paie 4 est de 500 $. La rémunération versée pour la période de paie 4 est de 500 $ - 100 $ : 400 $. 

### Info

Source topic: `fr_FR/common_notes/note_c_0777.dita`

Message d’erreur : « Le montant de la rémunération assurable de la période de paie <nn> doit être entre 1.00 et 999 999.99 (espace ajouté pour la lisibilité seulement) inclusivement ou doit être 0.00 lorsqu’il n’y a pas de rémunération assurable. » (15C0nnAM10046 <nn> = période de paie 02 à 53) 

### Info

Source topic: `fr_FR/common_notes/note_c_0705.dita`

Message d’erreur : « Les heures assurables de la période de paie 1 doivent être entre 0.01 et 999.99 inclusivement (décimale incluse). » (15C001HR10055)

Cette erreur peut survenir concurremment avec une erreur liée aux sommes assurables versées à la cessation d’emploi si la période de paie 1 contient une rémunération mais aucune heure. Lorsque c’est le cas, corriger-le en premier puisque cela peut permettre de corriger l’autre erreur. 

### Info

Source topic: `fr_FR/common_notes/note_c_0706.dita`

Message d’erreur : « Les heures assurables de la période de paie <nn> contenant le premier jour de travail doivent être entre 0.01 et 999.99 inclusivement (décimale incluse). » (15C0nnHR10056 <nn> = période de paie 02 à 53) 

### Info

Source topic: `fr_FR/common_notes/note_c_0707.dita`

Message d’erreur : « Les heures assurables doivent respecter le format 999.99 (décimale incluse). » (15C0nnHR10316 <nn> = période de paie 02 à 53) 

### Info

Source topic: `fr_FR/common_notes/note_c_0708.dita`

Message d’erreur : « Les dates de fin des périodes de paie doivent toutes être différentes et aucune ne doit être omise. » (15C000DT10446)

Si des corrections ont été apportées à la période de paie, les dossiers de paie de l’employeur peuvent indiquer deux dates identiques de la fin de la période de paie. Il se peut que les renseignements aient pu être saisis deux fois à la case 15C . 

### Info

Source topic: `fr_FR/common_notes/note_c_0709.dita`

Message d’erreur : « La date de fin de la période de paie, le montant et les heures sont requis pour chacune des périodes de paie requises. » (15C0000010036) 

### Info

Source topic: `fr_FR/common_notes/note_c_0710.dita`

Message d’erreur : « La date de fin de la période de paie 1 doit être égale à la date de fin de la dernière période de paie fournie. » (15C001DT10038)

Cette erreur peut survenir concurremment avec une erreur à la case 12 . La correction de l’erreur de la case 12 peut corriger l’erreur de la case 15C . 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0778.dita`

Exemple :

Genre de période de paie: Quinzaine. Date de fin de la période de paie 2 : 16 octobre 2013. Date de fin de la prochaine période de paie : 30 octobre 2013. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0779.dita`

Exemple :

Genre de période de paie : Quinzaine. Date de fin de la période de paie de la case 12 : 30 octobre 2013. Date de la fin de période de paie 2 de la case 15C : 17 octobre 2013. Modifier la période de paie 2 pour indiquer la bonne date, à savoir le 16 octobre 2013. Retourner à la tâche principale. 

### Info

Source topic: `fr_FR/common_notes/note_c_0780.dita`

Message d’erreur : « Les dates de fin de la période de paie doivent être fournies en ordre chronologique en débutant par la date de fin de la dernière période de paie. » (15C001DT10039) 

### Info

Source topic: `fr_FR/common_notes/note_c_0781.dita`

Message d’erreur : « Le nombre de périodes de paie consécutives fourni doit être égal à la période d’emploi et ne doit pas dépasser :

- 7 ou 13 périodes de paie selon la période de paie Mensuelle. » (15C0000010475)

- 7 ou 13 périodes de paie selon la période de paie Mensuelle non conventionnelle. » (15C0000010476)

- 7 ou 14 périodes de paie selon 13 périodes de paie par année. » (15C0000010479)

- 7 périodes de paie selon 13 périodes de paie par année. » (15C0000010442)

- 7 périodes de paie selon la période de paie Mensuelle. » (15C0000010434)

- 7 périodes de paie selon la période de paie Mensuelle non conventionnelle. » (15C0000010436)

- 13 ou 25 périodes de paie selon la période de paie Bimensuelle. » (15C0000010477)

- 13 ou 25 périodes de paie selon la période de paie Bimensuelle non conventionnelle. » (15C0000010478)

- 13 périodes de paie selon la période de paie Bimensuelle. » (15C0000010438)

- 13 périodes de paie selon la période de paie Bimensuelle non conventionnelle. » (15C0000010440)

- 13 périodes de paie selon la période de paie Mensuelle. » (15C0000010435)

- 14 périodes de paies selon la période de paie à la Quinzaine. » (15C0000010432)

- 25 périodes de paie selon la période de paie Bimensuelle. » (15C0000010439)

- 25 périodes de paie selon la période de paie Bimensuelle non conventionnelle. » (15C0000010441)

- 27 ou 53 périodes de paie selon la période de paie Hebdomadaire. » (15C0000010480)

- 27 périodes de paie selon la période de paie à la Quinzaine. » (15C0000010433)

- 27 périodes de paie selon la période de paie Hebdomadaire. » (15C0000010444)

- 53 périodes de paie selon la période de paie Hebdomadaire. » (15C0000010445) 

### Info

Source topic: `fr_FR/common_notes/note_c_0677.dita`

Message d’erreur : « Une raison valide est requise pour le présent relevé d’emploi. » (16X000TP10065) 

### Info

Source topic: `fr_FR/common_notes/note_c_0782.dita`

Message d’erreur : « Le montant de la paie de vacances doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (17A001AM10097) 

### Info

Source topic: `fr_FR/common_notes/note_c_0715.dita`

Message d’erreur : « La date de fin de la paie de vacances est requise lorsque le genre de paie de vacances est ‘Payée pour des vacances’. » (17A001ED10086) 

### Info

Source topic: `fr_FR/common_notes/note_c_0716.dita`

Message d’erreur : « La date de fin de la paie de vacances doit être postérieure ou égale à la date de début de la paie de vacances lorsque le genre de paie de vacances est ‘Payée pour des vacances’. » (17A001ED10090) 

### Info

Source topic: `fr_FR/common_notes/note_c_0783.dita`

Message d’erreur : « La date de début de la paie de vacances est requise lorsque le code de paie de vacances est :

- ‘‘Anniversaire (payée à la même date chaque année)’’. » (17A001SD10080)

- ‘‘Payée pour des vacances’’. » (17A001SD10079) 

### Info

Source topic: `fr_FR/common_notes/note_c_0784.dita`

Message d’erreur : « La date du jour férié payé <nn> doit être postérieure au dernier jour payé et inférieure ou égale au (dernier jour payé + 12 mois). » (17B0nnDT10101 <nn>= rémunération des jours fériés pour les points 01 à 10) 

### Info

Source topic: `fr_FR/common_notes/note_c_0785.dita`

Message d’erreur : « Le montant de la rémunération du jour férié payé <nn> est requis lorsque la date du jour férié payé est fournie. » (17B0nnAM10103 <nn>= rémunération des jours fériés pour les points 01 à 10) 

### Info

Source topic: `fr_FR/common_notes/note_c_0786.dita`

Message d’erreur : « Le montant du jour férié payé <nn> doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (17B0nnAM10105 <nn>= rémunération des jours fériés pour les points 01 à 10) 

### Info

Source topic: `fr_FR/common_notes/note_c_0721.dita`

Message d’erreur : « Les dates des jours fériés payés doivent toutes être différentes. » (17B0nnDT10098 <nn>= rémunération des jours fériés pour les points 01 à 10) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0722.dita`

Remarque :

Une mesure provisoire en vertu du Projet pilote 24 s’applique aux indemnités de cessation d’emploi versées en raison d’une cessation d’emploi dans les demandes dont le DPP ou la date de début de la répartition est entre le 30 mars 2025 (s/c 2493) et le 10 octobre 2026 (s/c 2572 ). Quand des indemnités de cessation d’emploi sont versées pour cette période, elles ne sont pas réparties.

Si les sommes sont versées en raison de la cessation d’emploi, l’agent laisse les champs du RE indiquant une date vides et CAC ne répartit pas les sommes. Si les sommes sont versées pour toute autre raison, l’agent saisit les dates appropriées dans le RE et CAC répartit les montants comme d’habitude. 

### Info

Source topic: `fr_FR/common_notes/note_c_0787.dita`

Message d’erreur : « Le montant du versement des autres sommes <nn> doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (17C0nnAM10187 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0788.dita`

‘B - Prime (pour récompenser le rendement/la productivité)’ est fourni. » (17C0nnED10137 <nn>= autres sommes points 01 à 05) ‘H - Honoraires’ est fourni. » (17C0nnED10145 <nn>= autres sommes points 01 à 05) ‘W - Paiement provincial/retrait préventif’ est fourni. » (17C0nnED10159 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0725.dita`

Message d’erreur : « La date de fin du versement des autres sommes <nn> doit être entre la date du jour moins 50 ans et la date du jour plus 2 ans inclusivement. » (17C0nnED10162 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0726.dita`

Message d’erreur : « La date de fin du versement des autres sommes <nn> doit être postérieure ou égale à la date de début du versement des autres sommes. » (17C0nnED10163 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0727.dita`

Message d’erreur : « La date de début du versement des autres sommes <nn> est requise lorsque le code des autres sommes :

- ‘B - Prime (événements particuliers)’ est fourni. » (17C0nnSD10109 <nn>= autres sommes points 01 à 05)

- ‘B - Prime (jour férié)’ est fourni. » (17C0nnSD10107 <nn>= autres sommes points 01 à 05)

- ‘B - Prime (pour récompenser le rendement/la productivité)’ est fourni. » (17C0nnSD10108 <nn>= autres sommes points 01 à 05)

- ‘H - Honoraires’ est fourni. » (17C0nnSD10116 <nn>= autres sommes points 01 à 05

- ‘W - Paiement provincial/retrait préventif’ est fourni. » (17C0nnSD10130 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0789.dita`

Message d’erreur : « La date de début du versement des autres sommes <nn> doit être entre la date du jour moins 50 ans et  la date du jour plus 2 ans inclusivement. » (17C0nnSD10133 <nn>= autres sommes points 01 à 05) 

### Info

Source topic: `fr_FR/common_notes/note_c_0790.dita`

Message d’erreur : « Répartitions des sommes - La rémunération moyenne de la dernière semaine de travail doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (17R000LA10189) 

### Info

Source topic: `fr_FR/common_notes/note_c_0791.dita`

Message d’erreur : « Répartitions des sommes - La rémunération hebdomadaire normale moyenne doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (17R000WA10188) 

### Info

Source topic: `fr_FR/common_notes/note_c_0729.dita`

Message d’erreur : « Le montant du congé de maternité / parental / compassion / prestations pour proches aidants payé est requis lorsque le genre de paiements spéciaux ‘Congé de maternité / parental / compassion / prestations pour proches aidants payé ’ est fourni. » (19X003AM10216) 

### Info

Source topic: `fr_FR/common_notes/note_c_0730.dita`

Message d’erreur : « La date de fin du congé de maternité / parental / compassion / prestations pour proches aidants payé doit être égale au dernier jour payé <LDFWP>. » (19X003AM10210) 

### Info

Source topic: `fr_FR/common_notes/note_c_0731.dita`

Message d’erreur : « La période du congé de maternité / parental / compassion / prestations pour proches aidants payé est requise lorsque le genre de paiements spéciaux ‘Congé de maternité / parental / compassion / prestations pour proches aidants payé’ est fourni. » (19X003AM10224) 

### Info

Source topic: `fr_FR/common_notes/note_c_0732.dita`

Message d’erreur : « La date de début du congé de maternité / parental / compassion / prestations pour proches aidants payé est requise lorsque le genre de paiements spéciaux ‘Congé de maternité / parental / compassion / prestations pour proches aidants ’ est fourni. » (19X003AM10195) 

### Info

Source topic: `fr_FR/common_notes/note_c_0792.dita`

Message d’erreur :« La date de début du congé de maternité / parental / compassion / prestations pour proches aidants payé doit précéder ou être égale au dernier jour payé <LDFWP>. » (19X003SD10198) 

### Info

Source topic: `fr_FR/common_notes/note_c_0734.dita`

Message d’erreur : « Le montant du congé de maladie payé est requis lorsque la date de début du paiement spécial est fournie pour le genre de paiements spéciaux ‘Congé de maladie payé’ est fourni. » (19X001AM10453) 

### Info

Source topic: `fr_FR/common_notes/note_c_0735.dita`

Message d’erreur : « Le montant du congé de maladie payé est requis lorsque le genre de paiements spéciaux ‘Congé de maladie payé’ est fourni. » (19X001AM10212) 

### Info

Source topic: `fr_FR/common_notes/note_c_0736.dita`

Message d’erreur : « La date de fin du congé de maladie payé doit être égale au dernier jour payé <LDFWP>. » (19X001AM10207) 

### Info

Source topic: `fr_FR/common_notes/note_c_0737.dita`

Message d’erreur : « La période du congé de maladie payé est requise lorsque le genre de paiements spéciaux ‘Congé de maladie payé ’ est fourni. » (19X001AM10220) 

### Info

Source topic: `fr_FR/common_notes/note_c_0738.dita`

Message d’erreur : « La date de début du congé de maladie payé est requise lorsque le genre de paiements spéciaux ‘Congé de maladie payé’ est fourni. » (19X001AM10191) 

### Info

Source topic: `fr_FR/common_notes/note_c_0739.dita`

Message d’erreur : « La date de début du congé de maladie payé doit précéder ou être égale au dernier jour payé <LDFWP>. » (19X001SD10196) 

### Info

Source topic: `fr_FR/common_notes/note_c_0793.dita`

Message d’erreur : « Le montant du paiement spécial doit être entre 1.00 et 999 999.99 inclusivement (espace ajouté pour la lisibilité seulement). » (19X0nnAM10218 <nn>=paiement spécial points 01 à 04) 

### Info

Source topic: `fr_FR/common_notes/note_c_0794.dita`

Message d’erreur :« La date de fin du paiement spécial doit être postérieure ou égale à la date de début du paiement spécial. » (19319X0nnED10206 <nn>=paiement spécial points 01 à 04) 

### Info

Source topic: `fr_FR/common_notes/note_c_0795.dita`

Message d’erreur : « Le montant des indemnités d’assurance salaire (AE assurable) est requis lorsque la date de fin du paiement spécial est fournie pour le genre de paiements spéciaux ‘Indemnités d’assurance salaire (AE assurable)’. » (19X002AM10215)

Remarque : Lorsqu’un RE comprend des indemnités d’assurance salaire (AE assurable) à la case 19 , l’agent qui calcule la demande doit consulter le document Examiner le résultat du calcul — Messages afin d’obtenir le résultat du calcul exact dans la version Web de SSA.
       [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml)

     [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml) 

### Info

Source topic: `fr_FR/common_notes/note_c_0796.dita`

Message d’erreur : « La date de fin des indemnités d’assurance salaire (AE assurable) doit être postérieure ou égale à la date de début des indemnités d’assurance salaire (AE assurable). » (19X002AM10208)

Remarque : Lorsqu’un RE comprend des indemnités d’assurance salaire (AE assurable) à la case 19 , l’agent qui calcule la demande doit consulter le document Examiner le résultat du calcul — Messages afin d’obtenir le résultat du calcul exact dans la version Web de SSA.
       [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml)

     [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml) 

### Info

Source topic: `fr_FR/common_notes/note_c_0797.dita`

Message d’erreur : « La période des indemnités d’assurance salaire (AE assurable) est requise lorsque le montant des indemnités d’assurance salaire (AE assurable) est fourni pour le genre de paiements spéciaux ‘Indemnités d’assurance salaire (AE assurable)’. » (19X002AM10223)

Remarque : Lorsqu’un RE comprend des indemnités d’assurance salaire (AE assurable) à la case 19 , l’agent qui calcule la demande doit consulter le document Examiner le résultat du calcul — Messages afin d’obtenir le résultat du calcul exact dans la version Web de SSA.
       [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml)

     [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml) 

### Info

Source topic: `fr_FR/common_notes/note_c_0798.dita`

Message d’erreur : « La période des indemnités d’assurance salaire (AE assurable) est requise lorsque la date de fin des indemnités d’assurance salaire (AE assurable) est fourni pour le genre de paiements spéciaux ‘Indemnités d’assurance salaire (AE assurable)’. » (19X002AM10450)

Remarque : Lorsqu’un RE comprend des indemnités d’assurance salaire (AE assurable) à la case 19 , l’agent qui calcule la demande doit consulter le document Examiner le résultat du calcul — Messages afin d’obtenir le résultat du calcul exact dans la version Web de SSA.
       [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml)

     [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml) 

### Info

Source topic: `fr_FR/common_notes/note_c_0799.dita`

Message d’erreur :  « La date de début des indemnités d’assurance salaire (AE assurable) est requise lorsque le genre de paiements spéciaux ‘Indemnités d’assurance salaire (AE assurable)’ est fourni. » (19X002AM10194)

Remarque : Lorsqu’un RE comprend des indemnités d’assurance salaire (AE assurable) à la case 19 , l’agent qui calcule la demande doit consulter le document Examiner le résultat du calcul — Messages afin d’obtenir le résultat du calcul exact dans la version Web de SSA.
       [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml)

     [Examiner le résultat du calcul — Messages](/fr/procedure/generic/rcr_screen_messages.shtml) 

### Info

Source topic: `fr_FR/common_notes/note_c_0747.dita`

Message d’erreur : « Le code de la période des indemnités d’assurance salaire (AE non assurable) est requis lorsque la date de fin des indemnités d’assurance salaire (AE non assurable) est fournie pour le genre de paiements spéciaux indemnités d’assurance salaire (AE non assurable). » (19X004PR10449) 

### Info

Source topic: `fr_FR/common_notes/note_c_0748.dita`

Message d’erreur : « Le montant des indemnités d’assurance salaire (AE non assurable) est requis lorsque la date de fin des indemnités d’assurance salaire (AE non assurable) <nn> est fournie. » (19X004PR10214) 

### Info

Source topic: `fr_FR/common_notes/note_c_0749.dita`

Message d’erreur : « La date de fin des indemnités d’assurance salaire (AE non assurable) doit être postérieure ou égale à la date de début des indemnités d’assurance salaire (AE non assurable). » (19X004PR10209) 

### Info

Source topic: `fr_FR/common_notes/note_c_0750.dita`

Message d’erreur : « La période des indemnités d’assurance salaire (AE non assurable) est requise lorsque le montant du paiement spécial est fourni pour le genre de paiements spéciaux ‘Indemnités d’assurance salaire (AE non assurable)’. » (19X004PR10222) 

### Info

Source topic: `fr_FR/common_notes/note_c_0751.dita`

Message d’erreur : « La date de début des indemnités d’assurance salaire (AE non assurable) est requise lorsque la date de fin des indemnités d’assurance salaire (AE non assurable) <nn> est fournie. » (19X004PR10193) 

### Info

Source topic: `fr_FR/common_notes/note_c_0752.dita`

Message d’erreur : « La date de début des indemnités d’assurance salaire (AE non assurable) doit être postérieure au dernier jour payé <LDFWP>. » (19X004SD10197) 

### Info

Source topic: `fr_FR/common_notes/note_c_0800.dita`

Message d’erreur : « Le premier jour de travail et/ou le dernier jour payé fourni sur ce RE chevauche un autre RE soumis pour cet employé(e). » (9900000010412)

Un RE portant le même numéro d’entreprise que celui figurant dans un autre RE a été émis et ils contiennent des dates qui se chevauchent.

Cette erreur peut survenir lorsqu’un employeur émet un RE subséquent pour modifier un RE antérieur mais n’inclut pas le numéro de série du RE à modifier dans la case 2 du RE subséquent.

Cette erreur peut également survenir lorsqu’un employeur émet un RE subséquent dont la date du premier jour de travail est identique à celle figurant dans un RE antérieur. Le RE subséquent peut donc contenir des heures et des montants de rémunération qui se trouvent déjà dans le RE antérieur, ce qui peut entraîner une erreur liée à l’admissibilité à des prestations. Le premier jour de travail qui figure dans le RE subséquent doit être corrigé afin d’indiquer le premier jour de travail depuis que le RE antérieur a été émis. L’agent doit aussi vérifier que les heures et les montants de rémunération du RE antérieur ne sont pas inclus dans le RE subséquent.

Même si ce message est généralement dû à une erreur qui survient lorsqu’on remplit le RE, le chevauchement se produit parfois parce qu’un employé occupe 2 différents emplois chez un même employeur (p. ex. le client travaille pendant la journée comme réceptionniste d’école et travaille pour le même employeur en soirée comme concierge). Lorsque cette situation se produit et que l’employeur le confirme, les dates indiquées dans les RE sont exactes. 
