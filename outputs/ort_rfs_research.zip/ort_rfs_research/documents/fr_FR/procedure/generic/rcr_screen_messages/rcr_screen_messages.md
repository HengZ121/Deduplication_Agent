# Examiner le résultat du calcul — Messages

Source map: `fr_FR/procedure/generic/rcr_screen_messages/rcr_screen_messages.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/rcr_screen_messages/generic.dita`

Sommaire : Lors du calcul, la version Web de SSA peut permettre de continuer le calcul, mais afficher des messages indiquant qu’une erreur a pu se produire. L’agent doit examiner ces messages et prendre les mesures nécessaires, au besoin.

**Ce qu’il faut savoir**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0019.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0865.dita) 

Au moment d’utiliser la version Web de SSA pour calculer la demande, si la version Web de SSA affiche à l’écran Résultat de calcul les messages suivants, vous devez examiner ce qu’il faut faire :

- Aucun arrêt de rémunération
         [Aucun arrêt de rémunération](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#aucunarret)

- Aucune semaine de l’ERP ne concorde à la PR
         [Aucune semaine de l’ERP ne concorde à la PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#erp)

- Certificat médical requis …SVP réviser
         [Certificat médical requis …SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#medicale)

- Chevauchement des meilleures semaines - Données réelles requises
         [Chevauchement des meilleures semaines - Données réelles requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#Chevauchement)

- CMP date de début après le DJP - S.V.P. réviser
         [CMP date de début après le DJP - S.V.P. réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#cmp)

- Compassion - Deuxième catégorie
         [Compassion - Deuxième catégorie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#PDC2Cat)

- Crédit 300 heures assurables
         [Crédit 300 heures assurables](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#_Crédit_300_heures)

- Crédit 480 heures assurables
         [Crédit 480 heures assurables](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#_Crédit_480_heures)

- D57 pourrait être requise
         [D57 pourrait être requise](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#D57)

- Date réelle d’accouchement ou date présumé d’accouchement sont inscrites - Est-ce que le début de la fenêtre de maternité externe est requis?
         [Date réelle d’accouchement ou date présumé d’accouchement sont inscrites - Est-ce que le début de la fenêtre de maternité externe est requis?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#date)

- Demande de maladie - DPP à l’intérieur de la fenêtre de maternité
         [Demande de maladie - DPP à l’intérieur de la fenêtre de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#maladie)

- Demande de maternité - DPP n’est pas à l’intérieur de la fenêtre maternité
         [Demande de maternité - DPP n’est pas à l’intérieur de la fenêtre maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#DPPpasdans)

- Demande postdatée - Vérifier l’arrêt de rémunération
         [Demande postdatée - Vérifier l’arrêt de rémunération](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#postdates)

- Demande Subséquente - Rémunérations ou RE après DJT
         [Demande Subséquente - Rémunérations ou RE après DJT](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#djt)

- Départ volontaire/inconduite dans la période de référence, les relevés d’emploi chevauchent - Données réelles peuvent être requises
         [Départ volontaire/inconduite dans la période de référence, les relevés d’emploi chevauchent - Données réelles peuvent être requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#inconduite)

- Données réelles manuelles présentes - Données réelles requises
         [Données réelles manuelles présentes - Données réelles requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#manuelles)

- Données réelles n’ont pas été automatisées
         [Données réelles n’ont pas été automatisées](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#donnes)

- DPA est inscrite - Est-ce que la SDM-EXT est requise
         [DPA est inscrite - Est-ce que la SDM-EXT est requise](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#inscrite)

- DPP est placé après la période courante de la norme variable d’admissibilité applicable - Vérifier le Résultat de calcul
         [DPP est placé après la période courante de la norme variable d’admissibilité applicable - Vérifier le Résultat de calcul](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#nva)

- DPP pas à l’intérieur de la fenêtre compassion
         [DPP pas à l’intérieur de la fenêtre compassion](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#Compassion)

- DPP pas à l’intérieur de la fenêtre parentale
         [DPP pas à l’intérieur de la fenêtre parentale](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#DPPParentale)

- Dû à la prolongation de la période de référence, des heures assurables supplémentaires peuvent être requises
         [Dû à la prolongation de la période de référence, des heures assurables supplémentaires peuvent être requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#prolongation)

- ERP dans la PR - Données réelles n’ont pas été automatisées
         [ERP dans la PR - Données réelles n’ont pas été automatisées](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#erppr)

- Erreur RE - [numéro de série]
         [Erreur RE - [numéro de série]](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#rdeErr)

- État ARC est égal à décédé - SVP réviser
         [État ARC est égal à décédé - SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#arc)

- État de l’accord travail autonome est résiliation. SVP confirmer l’admissibilité
         [État de l’accord travail autonome est résiliation. SVP confirmer l’admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#autonome)

- Exclusion/inadmissibilité est imposée - Peut se qualifier pour prestations spéciales
         [Exclusion/inadmissibilité est imposée - Peut se qualifier pour prestations spéciales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#disentmayqualifyspecial)

- Heures ajoutées pour prolongation automatique de la PR
         [Heures ajoutées pour prolongation automatique de la PR](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#_Heures_ajoutées_par)

- Heures d’admissibilité < 600 - Peut se qualifier pour des prestations spéciales
         [Heures d’admissibilité < 600 - Peut se qualifier pour des prestations spéciales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#Heures_dadmissibilite)

- Indemnités de cessation d’emploi - recueil de faits requis
         [Indemnités de cessation d’emploi - recueil de faits requis](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#cessation)

- La condition spéciale du dernier RE est requise
         [La condition spéciale du dernier RE est requise](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#re_condition_special_requise)

- Le DPP est après la fin de la fenêtre pour proches aidants - SVP réviser
         [Le DPP est après la fin de la fenêtre pour proches aidants - SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#fenetreprocheaidants)

- Le DPP est avant la date de début de la fenêtre pour proches aidants - SVP réviser
         [Le DPP est avant la date de début de la fenêtre pour proches aidants - SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#gravement)

- Le DPP pourrait possiblement être postdaté - SVP réviser
         [Le DPP pourrait possiblement être postdaté - SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#dpp)

- Le total de la moyenne quotidienne > celui sur le RDE. Régler le FHE manuellement
         [Le total de la moyenne quotidienne > celui sur le RDE. Régler le FHE manuellement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#total)

- Maternité différée et délai de carence supprimé - S.V.P. réviser
         [Maternité différée et délai de carence supprimé - S.V.P. réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#maternite)

- Maternité payable < 15 semaines
         [Maternité payable < 15 semaines](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#mat1123)

- Meilleures semaines - Données réelles requises
         [Meilleures semaines - Données réelles requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#meilleures)

- MN05 demande active - Données réelles peuvent être requises
         [MN05 demande active - Données réelles peuvent être requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#mn05)

- MSV < Dénominateur - crédit de rémunération assurable
         [MSV < Dénominateur - crédit de rémunération assurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#denominateur_credit_re_assurable)

- Ne se qualifie pas sur la date antérieure
         [Ne se qualifie pas sur la date antérieure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#qualifie)

- Paiements spéciaux invalides - Indemnités d’assurance salaire (AE assurable)
         [Paiements spéciaux invalides - Indemnités d’assurance salaire (AE assurable)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#paiements)

- Possibilité de semaines restantes payables
         [Possibilité de semaines restantes payables](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#restantes)

- Postdate avec rémunération dans la semaine 1 - transmettre un M175 genre A si nécessaire
         [Postdate avec rémunération dans la semaine 1 - transmettre un M175 genre A si nécessaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#post_ave_rem_sem1)

- Postdate du DPP peut être plus avantageux - une entrée pourrait être requise dans le champ DPP subséquent ou manuel de l’écran Impératif de codage
         [Postdate du DPP peut être plus avantageux - une entrée pourrait être requise dans le champ DPP subséquent ou manuel de l’écran Impératif de codage](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#Post_du_DPP)

- Prestation de compassion non approuvée
         [Prestation de compassion non approuvée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#FenCompassion)

- Prestataire non admissible au DPP subséquent/manuel. La demande a été postdatée
         [Prestataire non admissible au DPP subséquent/manuel. La demande a été postdatée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#Prestataire_non_admissible)

- Prestations parentales - Prestataire de deuxième catégorie
         [Prestations parentales - Prestataire de deuxième catégorie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#PParentales2eCat)

- Prestations proches aidants… de deuxième catégorie
         [Prestations proches aidants… de deuxième catégorie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#ppa-dc)

- Prestations proches aidants - Preuve médical requise. SVP réviser
         [Prestations proches aidants - Preuve médical requise. SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#PPAPreuveRequise)

- Preuve de compassion requise …S.V.P. réviser
         [Preuve de compassion requise …S.V.P. réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#CompassionRequise)

- Preuve de maternité requise…SVP réviser
         [Preuve de maternité requise…SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#preuve1100)

- Preuve de naissance ou d’adoption/de placement requise …SVP réviser
         [Preuve de naissance ou d’adoption/de placement requise …SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#preuve1101)

- Région économique est incorrecte - SVP réviser
         [Région économique est incorrecte - SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#region)

- Relevé(s) d’emploi exclu(s)
         [Relevé(s) d’emploi exclu(s)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#exclu)

- Rémunération assurable augmentée pour le taux de prestations minimal
         [Rémunération assurable augmentée pour le taux de prestations minimal](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#Remuneration_assurable)

- Rémunération dans la semaine 1 a changée, déclarations ont été traitées. Réviser et déterminer si le changement est requis
         [Rémunération dans la semaine 1 a changée, déclarations ont été traitées. Réviser et déterminer si le changement est requis](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#rem_sem_1)

- Rémunérations insuffisantes du RE dans la PR du travail autonome - Données réelles sont requises
         [Rémunérations insuffisantes du RE dans la PR du travail autonome - Données réelles sont requises](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#insuffisantes)

- Répartition annulée - SVP réviser
         [Répartition annulée - SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#svp)

- Semaine de début des prestations parentales est placée après le DPP …S.V.P. réviser
         [Semaine de début des prestations parentales est placée après le DPP …S.V.P. réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#sdpdpp1090)

- Semaine de guérison est inscrite avec une demande de maternité ou parental, SVP réviser
         [Semaine de guérison est inscrite avec une demande de maternité ou parental, SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#semgue)

- Semaine de guérison est inscrite avec une demande régulière, SVP réviser
         [Semaine de guérison est inscrite avec une demande régulière, SVP réviser](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#Sem_gue_non)

- Semaine de guérison requise
         [Semaine de guérison requise](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#guerison)

- Se requalifie comme genre de demande de pêche
         [Se requalifie comme genre de demande de pêche](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#requalifie)

**Niveau 1**

**Aucun arrêt de rémunération (1066)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand l’écran Impératif de codage indique qu’aucun arrêt de rémunération (A de R) n’a eu lieu.

Dans la majorité des cas, les clients ont un A de R quand ils demandent des prestations d’AE. Un A de R peut survenir à tout moment pendant la période de référence (PR).

Quand aucun A de R n’est déterminé, l’agent crée un RD dans SNCT et indique qu’aucun A de R n’a été saisi dans la version Web de SSA.

Quand il n’y a pas de RD au dossier, l’écran Impératif de codage pourrait indiquer par erreur qu’aucun A de R n’a eu lieu. Dans ce cas, l’agent corrige les renseignements à l’écran Impératif de codage et consulte Déterminer s’il existe un arrêt de rémunération avant de poursuivre le calcul de la demande.
       [Déterminer s’il existe un arrêt de rémunération](/fr/procedure/task/calc_determining/interruption_earnings.shtml)

Quand il y a un RD au dossier, l’agent accepte ce message.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0866.dita) 

**Ce qu’il faut faire**

- Dans SNCT, déterminer s’il y a un RD indiquant qu’il n’y a aucun A de R :

- S’il n’y a pas de RD indiquant qu’il n’y a aucun A de R, passer à l’étape 2.

- S’il y a un RD indiquant qu’il n’y a aucun A de R, passer à l’étape 3.

- Dans la version Web de SSA, à partir de l’écran Impératif de codage , remplir le champ suivant :

- Arrêt de rémunération : Choisir Oui .

- Consulter Déterminer s’il existe un arrêt de rémunération .
             [Déterminer s’il existe un arrêt de rémunération](/fr/procedure/task/calc_determining/interruption_earnings.shtml)

- Dans SNCT, déterminer s’il s’agit d’un calcul initial ou un nouveau calcul :

- S’il s’agit d’un calcul initial, passer à l’étape 4.

- S’il s’agit du nouveau calcul d’une période de prestations (PP) déjà établie, passer à Invalider une période de prestations .
             [Invalider une période de prestations](/fr/procedure/task/benefit_period_void.shtml)

- Se souvenir que la transaction M101 - Données de contrôle des fichiers (M101) de genre 7 (M101-7) requise pour annuler la demande doit être transmise après la transaction M103 - Décision initiale (M103) .

- Accepter ce message et passer à l’étape 10 de Examiner le Résultat de calcul .
         [Examiner le Résultat de calcul](/fr/procedure/subactivity/calc_result_ccb.shtml)

**Aucune semaine de l’ERP ne concorde à la PR (1126)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand les conditions suivantes sont remplies :

- Il n’y a aucune demande terminée associée à la période de référence (PR).

- Selon le calcul, la PP peut être établie.

- Le taux de prestations à l’exclusion du supplément familial est inférieur au taux maximum.

- Des données réelles manuelles n’ont pas été saisies dans le Fichier historique d’emploi ou dans tout RE associé à la PR.

Le CAC permet d’examiner l’historique des paiements des demandes terminées pour déterminer toutes les semaines au cours desquelles le client a déclaré des rémunérations d’un montant de 0,00 $ et les tentatives d’importer ces semaines dans le Fichier historique d’emploi du RE pour les semaines qui se trouvent dans la PR.

On détermine les semaines d’interruption d’emploi à l’aide des périodes de paie laissées vides (ou 0,00 $) dans le RE et les semaines où le client a déclaré des rémunérations de 0,00 $ dans le cadre de la demande précédente. Quand il n’y a aucune demande terminée liée à la PR, le système doit se baser uniquement sur la section portant sur la rémunération détaillée du RE afin de déterminer ces semaines.

**Ce qu’il faut faire**

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Certificat médical requis …SVP réviser (1003)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand un certificat médical a été noté comme manquant dans la section Information manquante de l’écran Enregistrement .

Quand un certificat médical doit être présenté, l’agent note à l’écran Enregistrement que cette information manque. En plus du message 1003 - Certificat médical requis …SVP réviser , l’écran Résultat de calcul affiche aussi qu’une inadmissibilité indéterminée 16 - Certificat médical non fourni (D16) est imposée à partir du DPP.

Un rapport de décision (RD) doit être au dossier quand le client est déclaré inadmissible aux prestations spéciales sauf s’il est inadmissible parce qu’il est de deuxième catégorie. Quand un RD est requis, mais qu’il n’est pas au dossier, l’agent retourne à la tâche précédente afin de déterminer si l’inadmissibilité est exacte.

**Ce qu’il faut faire**

- Déterminer si un RD indique que la preuve médicale est en attente de traitement:

- Si non, une inadmissibilité pourrait être imposée par erreur. Passer à l’étape 2.

- Si oui, accepter le message et passer à la procédure suivante .
             [la procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#_Next_procedure)

- Dans la version Web de SSA, dans la section Information manquante de l’écran Enregistrement , suivre les directives suivantes :

- Attestation médicale - Date d’échéance : Supprimer la date d’échéance de l’AT lié au calcul.

- Choisir Sauvegarder .

- Consulter Déterminer si un certificat médical doit être présenté : Prestations de maladie — Demandes initiales .
         [Déterminer si un certificat médical doit être présenté : Prestations de maladie — Demandes initiales](/fr/procedure/task/calc_determining/det_mc_ra.shtml)

**Chevauchement des meilleures semaines - Données réelles requises (1148)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand des RE se chevauchent, qu’il y a des meilleures semaines variables (MSV) dans la période du chevauchement et que toutes les conditions suivantes sont remplies :

- Selon le calcul, il y a suffisamment d’heures pour faire établir une demande, y compris les demandes de prestations spéciales assorties d’une inadmissibilité aux prestations régulières.

- Le taux de prestations déterminé à l’exclusion de tout supplément familial est inférieur au taux de prestations maximum.

- Il y a un questionnaire Meilleures semaines variables dans SNCT sur lequel le client a indiqué l’une des options suivantes :

- plus d’un employeur dans une semaine civile

- un employeur dans une semaine civile pour lequel MSRE contient plus d’un RE.

Comme le système ne peut déterminer le RE sur lequel il faut saisir les renseignements sur les MSV, l’agent doit le faire. Ce message continue d’être affiché même après que les renseignements ont été saisis dans le Fichier historique d’emploi.

L’agent doit s’assurer que les renseignements sur les MSV dans le Fichier historique d’emploi du RE associé correspondent aux renseignements les plus récents obtenus du client. Une fois que l’agent a examiné les renseignements et apporté toutes les corrections nécessaires, il peut accepter ce message et passer à Procédure suivante .
       [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Ce qu’il faut faire**

- Dans SNCT, choisir Systèmes — Afficher questionnaire .

- S’il n’ y a aucun questionnaire des meilleures semaines, passer à l’étape 2.

- S’il y a un questionnaire des meilleures semaines, choisir le questionnaire rempli le plus récent joint à la demande électronique et passer à l’étape 4.

- Déterminer si les renseignements des MSV sont détaillés dans un RSDP ou un AT Action à prendre (AP) (appelé « questionnaire » dans les étapes suivantes) :

- Si non, passer à l’étape 3.

- Si oui, passer à l’étape 4.

- Choisir la section MSV Détails de la Demande électronique (appelée « questionnaire » dans les étapes suivantes) et déterminer si le client a fourni les renseignements sur les MSV.

- Si oui, passer à l’étape 4.

- Si non, passer à l’étape 16.

- Examiner le questionnaire pour déterminer chacun des renseignements suivants :

- le nombre d’employeurs mentionnés pour chaque montant de MSV saisit

- les semaines civiles mentionnées.

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0867.dita)

- Dans MSRE, déterminer s’il existe un RE de l’employeur pour chaque semaine civile mentionnée :

- Si oui, passer à l’étape 6.

- Si non, passer à l’étape 13.

- Déterminer si la case FHE s’affiche à côté du RE :

- Si oui, choisir la case pour ouvrir le Fichier historique d’emploi et passer à l’étape 7.

- Si non, consulter Corriger un RE avant de procéder.
             [Corriger un RE](/fr/procedure/activity/correct_roe.shtml)

- Dans le Fichier historique d’emploi , pour la semaine saisie, déterminer si 0,00 $ est affiché :

- Si non, passer à l’étape 8.

- Si oui, passer à l’étape 11.

- Déterminer si le montant inscrit dans le questionnaire est égal au montant de la s/c correspondante :

- Si non, passer à l’étape 9.

- Si oui, passer à l’étape 11.

- Dans le champ Code de semaine - Rémunérations de la semaine civile correspondante, saisir le montant indiqué dans le questionnaire.

- S’il n’y a pas de point d’exclamation, passer à l’étape 11.

- S’il y a un point d’exclamation, suivre les directives suivantes :

- Raison pour obtenir les données réelles : Choisir Meilleures semaines .

- Choisir Valider .

- Si le point d’exclamation reste visible, passer à l’étape 10.

- Si le point d’exclamation n’est plus visible, passer à l’étape 11.

- Corriger le message d’erreur du Fichier historique d’emploi en utilisant le tableau suivant :

```text
| Message d’erreur | Mesure requise |

| La période de paie du RE est NUL dans 15C. Des données réelles ne peuvent être entrées . | - Supprimer l’entrée des MSV. |

| Les rémunérations pour la période de paie (x) ne peuvent pas être 0,00 car aucun détail n’a été fourni dans la case 15C du RE . | - Vérifier que le montant 0,00 $ n’ a pas été saisi par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |

| Le total des rémunérations des données réels saisi (xx) ne correspond pas au Total des rémunérations déclaré sur le RE 15B (xx) . | Vérifier s’il est possible de corriger l’erreur en supprimant l’entrée de la meilleure semaine variable la moins élevée : - Si l’erreur est corrigée, supprimer tous les montants saisis pour la période de paie et saisir toutes les MSV, à l’exception de l’entrée du montant le moins élevé. - Si l’erreur n’ est pas corrigée, supprimer tous les montants saisis et saisir les MSV pour toutes les périodes de paie, à l’exception de la période de paie causant l’erreur. |

| Le total des heures inscrit (xx) est supérieur au total des heures déclaré (xx) sur le RE . | - Vérifier si un montant erroné a été saisi dans le champ Heures . - Supprimer tous les montants saisis et saisir les bons montants. |

| Les Heures ne peuvent pas excéder 24 heures par jour. La valeur doit être entre 0,00 et (xx) . | - Vérifier qu’ aucun montant n’ a été saisi dans le champ Heures par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |

| Les rémunérations doivent être entre 0,00 et 99999999,99 . | - Saisir le montant en utilisant le bon format. |

| Les Rémunérations pour la première période de paie ne peuvent pas être 0 car ils contiennent le premier jour de travail. Les Heures pour la première période de paie ne peuvent pas être 0 car ils contiennent le premier jour de travail . | - Vérifier que le montant 0,00 $ n’ a pas été saisi par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |

| Les rémunérations pour la période de paie (x) (xx) ne correspondent pas aux rémunérations déclarés dans le 15C sur le RE (xx). Ils doivent être égaux . | Vérifier s’il est possible de corriger l’erreur en supprimant l’entrée de la meilleure semaine variable la moins élevée : - Si l’erreur est corrigée, supprimer tous les montants saisis pour la période de paie et saisir toutes les MSV, à l’exception de l’entrée du montant le moins élevé. - Si l’erreur n’ est pas corrigée, supprimer tous les montants saisis et saisir les MSV pour toutes les périodes de paie, à l’exception de la période de paie causant l’erreur. |

| Les Rémunérations pour la période de paie finale ne peuvent pas être 0 car ils contiennent le dernier jour payé. Les Heures pour la période de paie finale ne peuvent pas être 0 car ils contiennent le dernier jour payé . | - Vérifier que le montant 0,00 $ n’ a pas été saisi par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |
```

- Si l’entrée est encore marquée d’un point d’exclamation, répéter l’étape 10.

- Si l’entrée n’est plus marquée d’un point d’exclamation, passer à l’étape 11.

- Déterminer s’il y a d’autres semaines à saisir pour ce RE :

- Si oui, retourner à l’étape 7 pour saisir la prochaine meilleure semaine variable.

- Si non, passer à l’étape 12.

- Déterminer si des entrées ont été consignées dans le Fichier historique d’emploi du RE :

- Si non, sortir du Fichier historique d’emploi et passer à l’étape 13.

- Si oui, suivre les directives suivantes :

- Si le champ Raison pour obtenir les données réelles est vide, choisir Meilleures semaines .

- Si le champ Valider est en gris, choisir Sauvegarder .

- Si le champ Valider n’est pas en gris, choisir Valider et Sauvegarder .

- Déterminer s’il existe des MSV d’un autre employeur à saisir :

- Si oui, retourner à l’étape 5 pour le prochain employeur.

- Si non, passer à l’étape 14.

- Déterminer si des entrées ont été saisies dans le Fichier historique d’emploi de tout RE :

- Si oui, passer à l’étape 15.

- Si non, passer à l’étape 16.

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**CMP date de début après le DJP - S.V.P réviser (1130)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand les 2 conditions suivantes ont été remplies :

- La case 19 du RE indique un congé de maladie payé ou un congé de maternité/parental.

- La date de début du paiement spécial est ultérieure au dernier jour payé indiqué à la case 11 .

Ce message s’affiche seulement si le RE utilisé dans le calcul indique comme date d’émission le 25 mai 2011 ou une date antérieure étant donné que les modifications aux entrées ont été apportées en date du 26 mai 2011.

**Ce qu’il faut faire**

- Consulter Corriger le RE .
         [Corriger le RE](/fr/procedure/activity/correct_roe.shtml)

**Compassion - Deuxième catégorie (1107)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions sont remplies :

- Le genre de la demande (GD) est PDC.

- Le client est de deuxième catégorie .
         [deuxième catégorie](/fr/procedure/generic/knowledge.shtml)

Pour être admissible aux PDC, le client doit avoir accumulé au moins 600 heures au cours de la PR.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0868.dita) 

**Ce qu’il faut faire**

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Crédit 300 heures assurables (1157)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message dans les demandes initiales de prestations régulières dont le DPP est entre les s/c 2258 et 2309.

À compter du 27 septembre 2020, une mesure temporaire a été mise en œuvre pour indemniser les clients pour les heures de travail qu’ils auraient pu effectuer sans les arrêts liés à la COVID-19.

Un crédit unique de 300 heures est appliqué automatiquement dans toutes les demandes qui remplissent les critères, peu importe si :

- le client remplit les conditions requises pour recevoir des prestations;

- la demande est PPNE;

- le client a plus de 1820 heures.

CAC génère un message d’avertissement 1157 - crédit 300 heures assurables dans toutes les demandes qui reçoivent le crédit d’heures assurables. Il s’affiche à l’écran Résultat de calcul .

**Ce qu’il faut faire**

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#next)

**Crédit 480 heures assurables (1158)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message dans les demandes initiales de prestations spéciales dont le DPP est entre les s/c 2258 et 2309.

À compter du 27 septembre 2020, une mesure temporaire a été mise en œuvre pour indemniser les clients pour les heures de travail qu’ils auraient pu effectuer sans les arrêts liés à la COVID-19.

Un crédit unique de 480 heures est appliqué automatiquement dans toutes les demandes qui remplissent les critères, peu importe si :

- le client remplit les conditions requises pour recevoir des prestations;

- la demande est PPNE;

- le client a plus de 1820 heures.

CAC génère un message d’avertissement 1158 - crédit 480 heures assurables dans toutes les demandes qui reçoivent le crédit d’heures assurables. Il s’affiche à l’écran Résultat de calcul .

**Ce qu’il faut faire**

Accepter ce message et passer à Procédure suivante .
       [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#next)

**D57 pourrait être requise (1120)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- La province d’imposition est le Québec.

- Le Résultat de calcul indique que la demande peut être établie.

- Le champ Date prévue de l’accouchement ou Date réelle de l’accouchement est rempli à l’écran Annexe - Prestations spéciales dans la version Web de SSA.

Quand la version Web de SSA détermine qu’une demande peut être établie pour un client qui réside au Québec, l’agent doit déterminer si le client est admissible au RQAP.

Quand il détermine qu’une demande est prête à calculer, l’agent doit examiner si le client est admissible au RQAP . Si la question a déjà été examinée, l’agent accepte ce message et poursuit le calcul de la demande.
       [examiner si le client est admissible au RQAP](/fr/procedure/task/determining_ccc_wpwpslqpipp.shtml)

**Ce qu’il faut faire**

- Déterminer si l’admissibilité du client au RQAP a déjà été examinée :

- Si elle a été examinée, accepter ce message et passer à Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

- Si elle n’a pas été examinée, consulter Examiner si des prestations sont payées ou payables par le RQAP .
             [Examiner si des prestations sont payées ou payables par le RQAP](/fr/procedure/task/reviewing_bpp_qpip.shtml)

**Date réelle d’accouchement ou date présumé d’accouchement sont inscrites - Est-ce que le début de la fenêtre de maternité externe est requis? (1041)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le GD est régulier ou de maladie.

- La section Prestations spéciales de l’écran Résultat de calcul affiche la semaine de début et de fin des prestations de maternité. Ces dates correspondent à la fenêtre de maternité.

- Le champ Semaine de début de maternité externe n’ est pas rempli à l’écran Annexe - Prestations spéciales dans la version Web de SSA.

- Le DPP se trouve dans la période entre la semaine de début de la maternité moins 3 semaines et la semaine de fin de la maternité + 1.

La demande est automatiquement convertie en prestations de maternité quand toutes les conditions suivantes sont remplies :

- il y a une fenêtre de maternité;

- des prestations de maternité peuvent être versées;

- les déclarations du prestataire sont traitées pour une semaine dans la fenêtre de maternité.

Si le client est admissible à un GP autre que maternité pendant la fenêtre de maternité calculée ou qu’il faut empêcher le versement de prestations de maternité pendant cette fenêtre, dans la version Web de SSA, l’agent doit saisir une date dans le champ Semaine de début de maternité externe pour contourner la fenêtre de maternité calculée.

Si le client n’est pas admissible à un GP autre que maternité pendant la fenêtre de maternité calculée ou qu’il ne faut pas empêcher le versement de prestations de maternité pendant cette fenêtre, il n’est pas nécessaire de saisir une date dans le champ Semaine de début de maternité externe dans la version Web de SSA. L’agent accepte ce message et continue le calcul de la demande.

**Ce qu’il faut faire**

- Déterminer si la question de la date de début de maternité externe a déjà été examinée :

- Si non, consulter Déterminer si les dates de la période de maternité externe sont requises dans une demande initiale .
             [Déterminer si les dates de la période de maternité externe sont requises dans une demande initiale](/fr/procedure/task/determining_emdr.shtml)

- Si oui, passer à l’étape 2.

- Déterminer s’il faut saisir une date dans le champ Semaine de début de maternité externe :

- Si non, accepter le message et passer à l’étape 3.

- Si oui, consulter Modifier les renseignements sur les prestations de maternité sur l’annexe pour les prestations spéciales dans la version Web de SSA .
             [Modifier les renseignements sur les prestations de maternité sur l’annexe pour les prestations spéciales dans la version Web de SSA](/fr/procedure/task/modifying_mat_sb_ssa.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Demande de maladie - DPP à l’intérieur de la fenêtre de maternité (1004)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le GD est prestations de maladie.

- Selon le calcul, il y a suffisamment d’heures pour que la cliente soit admissible aux prestations spéciales.

- La section Prestations spéciales à l’écran Résultat de calcul affiche la semaine de début et de fin des prestations de maternité. Ces dates correspondent à la fenêtre de maternité.

- Le champ Semaine de début de maternité externe à l’écran Annexe - Prestations spéciales dans la version Web de SSA est vide.

- La date du DPP tombe dans la période de maternité.

La demande est automatiquement convertie en prestations de maternité quand toutes les conditions suivantes sont remplies :

- il y a une fenêtre de maternité;

- des prestations de maternité peuvent être versées;

- les déclarations du prestataire sont traitées pour une semaine dans la fenêtre de maternité.

Si le client est admissible à un genre de prestations (GP) autre que maternité pendant la fenêtre de maternité calculée ou qu’il faut empêcher le versement de prestations de maternité pendant cette fenêtre, dans la version Web de SSA, l’agent doit saisir une date dans le champ Semaine de début de maternité externe pour contourner la fenêtre de maternité calculée.

Si le client n’est pas admissible à un GP autre que maternité pendant la fenêtre de maternité calculée ou qu’il ne faut pas empêcher le versement de prestations de maternité pendant cette fenêtre, il n’est pas nécessaire de saisir une date dans le champ Semaine de début de maternité externe dans la version Web de SSA. L’agent accepte ce message et continue le calcul de la demande.

Ce qu’il faut faire

- Déterminer si la question liée à une date de début de maternité externe a été révisée :

- Si oui, passer à l’étape 2.

- Si non, consulter Déterminer si les dates de la période de maternité externe sont requises .
             [Déterminer si les dates de la période de maternité externe sont requises](/fr/procedure/task/determining_emdr.shtml)

- Déterminer si une date est nécessaire dans le champ Semaine de début de maternité externe :

- Si non, accepter ce message et passer à l’étape 3.

- Si oui, consulter Modifier les renseignements sur les prestations de maternité à l’écran Annexe - Prestations spéciales dans la version Web de SSA .
             [Modifier les renseignements sur les prestations de maternité à l’écran Annexe - Prestations spéciales dans la version Web de SSA](/fr/procedure/task/modifying_mat_sb_ssa.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Demande de maternité - DPP n’est pas à l’intérieur de la fenêtre maternité (1008)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le champ Genre de demande à l’écran Impératif de codage indique Maternité .

- La section Prestations spéciales de l’écran Résultat de calcul affiche la semaine de début des prestations de maternité et la semaine de fin. Ces dates correspondent à la fenêtre de maternité.

- Le DPP est à l’extérieur de la fenêtre de maternité.

Si le DPP est après la fenêtre de maternité, ce message s’accompagne du message Maternité payable < 15 semaines .

Les prestations de maternité ne sont payables que durant la fenêtre de maternité.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0869.dita) 

Une cliente qui est admissible aux prestations régulières et qui doit observer un délai de carence (DC) peut établir une demande de prestations de maternité avant la fenêtre de maternité, si la date de début de la demande permet à la cliente d’observer le DC immédiatement après la fenêtre de maternité.

Une cliente qui n’est pas admissible aux prestations régulières ou qui ne doit pas observer de DC peut établir une demande de prestations de maternité dès le début de la fenêtre de maternité.

Une cliente peut établir une PP pour des prestations de maternité au plus tard la dernière semaine de la fenêtre de maternité.

Si la cliente veut établir une demande de prestations de maternité, une date postérieure ou une prolongation de la période de maternité peut s’appliquer. Toutefois, l’agent doit tenir compte de tous les éléments qui peuvent empêcher le paiement des prestations, y compris les répartitions et la date de retour au travail (RAT). Le fait de postdater la demande peut faire en sorte que le DPP tombe dans la fenêtre de maternité. Si la cliente présente une demande de prestations de maternité avant d’être admissible, l’agent, lors de la révision du DPP, doit se souvenir que la postdate peut être nécessaire. Pour plus de renseignements, consulter la Politique sur les postdates . Après que le DPP est déterminé, l’agent accepte ce message et continue le calcul de la demande. Si la cliente présente une demande de prestations de maternité après qu’elle est admissible et qu’une prolongation de la fenêtre de maternité s’applique, l’agent saisit la prolongation manuellement une fois que le Résultat de calcul est accepté.
       [Politique sur les postdates](/fr/policy/nationalpolicy/national_policy_on_postdates.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0870.dita) 

**Ce qu’il faut faire**

- Déterminer l’écran Résultat de calcul affiche le Genre de demande établie :

- Si non, consulter Modifier le genre de prestations dans la version Web de SSA lors du calcul .
             [Modifier le genre de prestations dans la version Web de SSA lors du calcul](/fr/procedure/task/calc_calculating/changing_tentative_ct.shtml)

- Si oui, passer à l’étape 2.

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0871.dita)

- Déterminer si le DPP précède la semaine de début de la maternité :

- Si oui, passer à l’étape 3.

- Si non, passer à l’étape 4.

- Lors de la révision du DPP, se souvenir qu’une postdate à la première semaine à laquelle la cliente est admissible à des prestations de maternité devrait être considérée. Pour plus de renseignements, consulter la Politique sur les postdates . Accepter ce message et passer à l’étape 11.
         [Politique sur les postdates](/fr/policy/nationalpolicy/national_policy_on_postdates.shtml)

- Déterminer si la question de la prolongation de la fenêtre de maternité a été examinée :

- Si oui, passer à l’étape 5.

- Si non, passer à Déterminer si une prolongation de la période de maternité est requise .
             [Déterminer si une prolongation de la période de maternité est requise](/fr/procedure/task/determining_extension_mrr.shtml)

- Déterminer si une prolongation de la fenêtre de maternité est nécessaire :

- Si non, passer à l’étape 6.

- Si oui, accepter ce message et passer à l’étape 11.

- Déterminer si la cliente a présenté sa demande de prestations à temps :

- Si non, passer à l’étape 7.

- Si oui, accepter ce message et passer à l’étape 11.

- Déterminer si la cliente a demandé une antidate ou s’il existe une antidate sous-entendue :

- Si oui, passer à l’étape 8.

- Si non, accepter ce message et passer à l’étape 11.

- Déterminer si une décision sur l’antidate a été rendue :

- Si oui, passer à l’étape 9.

- Si non, consulter Examiner une question en suspens sans AT Litige - Décision .
             [Examiner une question en suspens sans AT Litige - Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Déterminer si l’antidate a été accordée :

- Si oui, passer à l’étape 10.

- Si non, accepter ce message et passer à l’étape 11.

- Déterminer si le DPP à l’écran Résultat de calcul correspond à la date antérieure :

- Si le DPP ne correspond pas à la date antérieure, consulter Saisir une antidate dans la version Web de SSA .
             [Saisir une antidate dans la version Web de SSA](/fr/procedure/task/calc_calculating/input_antedate.shtml)

- Si le DPP correspond à la date antérieure, passer à l’étape 11.

- Passer à Procédure suivante .
         [Procédure suivante](/#suivante)

**Demande postdatée - Vérifier l’arrêt de rémunération (1138)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le GD est prestations spéciales liées au travail autonome.

- Selon le calcul, la rémunération est suffisante pour établir une demande.

- La demande a été postdatée afin qu’elle prenne effet la semaine suivant la semaine de la présentation de la demande.

Le DPP dans le cadre de demandes présentées en vertu de la partie VII (travail autonome [TA]) commence la semaine où le client présente sa demande. Le client déclare dans sa demande électronique qu’il y a eu un arrêt de rémunération (A de R) dans la semaine de la présentation de la demande.
       [demandes présentées en vertu de la partie VII](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/TexteComplet.html#h-44)

Une demande de prestations peut être postdatée.

Exemple 1

- Le client présente sa demande dans la dernière semaine de décembre.

- Le client n’a pas suffisamment de gains dans l’année civile précédente pour faire établir une demande.

- Le client a suffisamment de gains dans l’année en cours pour être admissible dans l’année civile suivante.

- Par conséquent, vous pouvez postdater la demande afin qu’elle prenne effet la première semaine complète de janvier.

Exemple 2

- Il a été déterminé au cours du recueil de faits auprès du client que celui-ci a travaillé pendant une semaine complète dans la semaine de la présentation de la demande. (il peut avoir travaillé le vendredi 13 septembre 2013 et avoir présenté sa demande de prestations le samedi 14 septembre 2013).

- L’A de R a lieu la semaine suivant la semaine de présentation de la demande.

- Par conséquent, la demande est postdatée afin qu’elle prenne effet la semaine du 15 septembre 2013.

Le client doit avoir subi un A de R dans la semaine du DPP pour pouvoir présenter une demande de prestations. Étant donné que la déclaration du client au sujet de l’A de R dans la demande s’applique seulement à la semaine de la présentation de la demande, il faut obtenir la déclaration et la confirmation du client selon lesquelles l’A de R est survenu dans la semaine du DPP.

**Ce qu’il faut faire**

- Déterminer si vous avez l’information confirmant que le client a eu un A de R dans la semaine du DPP :

- Si non, effectuer un recueil de faits auprès du client et passer à l’étape 2.

- Si oui, passer à l’étape 4.

- Déterminer si le client a été contacté pendant le recueil de faits :

- Si le client a été contacté, passer à l’étape 3.

- Si le client n’a pas été contacté ou n’a pas répondu à la lettre N-10-00-00, passer à l’étape 5.

- Dans SNCT, ajouter au RSDP en ébauche créé lors du recueil de faits ou créer un nouveau RSDP de la façon suivante :

- Principal problème : Choisir Calcul .

- Commentaires : Saisir « vérification arrêt de rémunération. »

- Détails : Consigner tout détail relatif au recueil de faits selon la Politique nationale sur le recueil de faits et la documentation .
             [Politique nationale sur le recueil de faits et la documentation](/fr/policy/nationalpolicy/national_policy_factfinding.shtml)

- Choisir Sauvegarder .

- Déterminer si le client a eu un A de R dans la semaine postdatée du DPP:

- Si non, passer à l’étape 5.

- Si oui, accepter le message et passer à l’étape 7.

- Dans la version Web de SSA, à l’écran Impératif de codage , compléter le champ suivant :

- DPP subséquent ou manuel : Saisir le dimanche de la semaine dans laquelle la demande a été soumise.

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Demande Subséquente - Rémunérations ou RE après DJT (1128)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand la condition suivante est remplie :

- La demande est renouvelable/subséquente (y compris les demandes PPNE et les demandes établies au taux de prestations maximum) et l’une des conditions suivantes est remplie :

- L’ État récapitulatif des paiements (ERP) indique une rémunération au cours d’une période qui survient après le DJT comme il est affiché à l’écran Formulaire de la demande dans la version Web de SSA.

- Il y a un RE indiquant un premier jour de travail qui survient après le DJT à l’écran Formulaire de la demande dans la version Web de SSA.

Quand un client présente une demande de prestations, TAD détermine s’il y a une demande renouvelable au dossier. Si la demande peut être renouvelée et qu’il existe 4 semaines ou moins au cours desquelles des prestations peuvent être versées (soit en raison d’une admissibilité ou de la dernière semaine renouvelable), la demande peut être utilisée pour établir une nouvelle demande après que la demande renouvelée a fait l’objet d’un versement complet des prestations. C’est ce qu’on appelle une demande subséquente.

Quand la demande subséquente fait l’objet d’un calcul, le CAC examine l’ERP et MSRE pour déterminer si l’une ou l’autre des conditions ci-dessus est remplie. Si l’une ou les deux conditions est remplie, la demande subséquente n’est pas traitée automatiquement.

Si le client reçoit une rémunération après le DJT, l’agent doit effectuer un recueil de faits, au besoin, et suivre l’une des directives suivantes :

- Si l’emploi est assurable et que les détails sur l’emploi sont accessibles, l’agent crée un RE provisoire.

- Si l’emploi n’est pas assurable, l’agent détermine si une décision doit être rendue sur la question liée au travail indépendant.

- Si l’agent est incapable de déterminer la nature de la rémunération, il annule la demande.

Si un RE est saisi après que l’agent détermine que la demande est prête à être calculée, l’agent doit retourner à Déterminer si la demande est prête à être calculée et examiner la demande.

Si un RE, indiquant un premier jour de travail qui survient après le DJT, figure au dossier et qu’il a déjà été examiné, l’agent poursuit le calcul de la demande.

**Ce qu’il faut faire**

- Dans ETI, déterminer si la rémunération a été déclarée dans les déclarations du prestataire pour une période qui survient après le DJT, comme il est affiché à l’écran Formulaire de la demande dans la version Web de SSA :

- Si oui, passer à l’étape 2.

- Si non, passer à l’étape 10.

- Dans MSRE, déterminer si un RE pour la période avec la rémunération figure au dossier :

- Si non, passer à l’étape 3.

- Si oui, passer à l’étape 11.

- Déterminer si un recueil de faits supplémentaire est nécessaire pour confirmer la nature de la rémunération déclarée :

- Si oui, passer à l’étape 4.

- Si non, passer à l’étape 6.

- Effectuer un recueil de faits auprès du client pour déterminer si la rémunération est liée à un emploi assurable ou à un travail indépendant (pour obtenir plus de renseignements, consulter Rémunération ).
         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0872.dita) 
         [recueil de faits](/fr/procedure/task/fact_find.shtml) 
         [Rémunération](/fr/procedure/activity/earnings.shtml)

- Déterminer si le client a été joint pendant le recueil de faits :

- Si le client a été joint, passer à l’étape 6.

- Si le client n’ a pas été joint ou qu’il n’ a pas répondu à la lettre N-10-00-00, passer à l’étape 12.

- Dans SNCT, ajouter des renseignements au RSDP en ébauche créé lors du recueil de faits ou créer un nouveau RSDP de la façon suivante :

- Principal problème : Choisir Calcul .

- Commentaires : Saisir « RE. »

- Détails : Consigner tout détail relatif au recueil de faits selon la Politique nationale sur le recueil de faits et la documentation .
             [Politique nationale sur le recueil de faits et la documentation](/fr/policy/nationalpolicy/national_policy_factfinding.shtml)

- Choisir Sauvegarder .

- Déterminer si la rémunération est liée à un emploi assurable (pour plus de renseignements, consulter Rémunération ) :

- Si non, passer à l’étape 8.

- Si oui, passer à Déterminer si un RE provisoire est nécessaire .
             [Déterminer si un RE provisoire est nécessaire](/fr/procedure/task/determining_interim_roe.shtml)

         [Rémunération](/fr/procedure/activity/earnings.shtml)

- Déterminer si une partie de la rémunération déclarée a été accumulée au cours d’une période de travail autonome :

- Si oui, passer à l’étape 9.

- Si non, passer à l’étape 10.

- Déterminer si une décision a été rendue sur le travail autonome:

- Si oui, passer à l’étape 10.

- Si non, consulter Examiner une question en suspens sans AT Litige(s) - Décision .
             [Examiner une question en suspens sans AT Litige(s) - Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml&locale=fr_CA)

- Dans MSRE, déterminer si un RE indiquant un premier jour de travail qui survient après le DJT à l’écran Formulaire de la demande dans la version Web de SSA figure au dossier :

- Si no, passer à Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

- Si oui, passer à l’étape 11.

- Déterminer si le RE indiquant un premier jour de travail qui survient après le DJT à l’écran Demande de prestations dans la version Web de SSA a déjà été examiné :

- Si oui, passer à Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

- Si non, consulter Vérifier les RE avant le calcul .
             [Vérifier les RE avant le calcul](/fr/procedure/task/calc_determining/review_roe.shtml)

- Dans ETI, choisir la transaction Données des contrôles des fichiers (M101) - Action sur la demande (M101) et annuler la demande de la façon suivante :

- Choisir Terminer la période de prestations (M101-7) .

- Choisir Mise à jour .

- Choisir la transaction Numéro d’enregistrement (M025, M030 et M035) et annuler le numéro d’enregistrement de la façon suivante :

- Mesure : Choisir Annuler .

- Choisir Mise à jour .

- Dans SNCT, créer un RD de la façon suivante :

- Commentaires : Saisir « Demande subséquente annulée. »

- Détails : Saisir les détails appropriés compte tenu du fait que le client a été joint ou non :

- Si le client n’ a pas été joint, saisir « Impossible de joindre le client. Rémunérations déclarées entre le renouvellement de l’ancienne demande et le début de la demande subséquente. »

- Si le client a été joint, saisir « Le client a été joint, mais il n’a pas été en mesure de fournir les renseignements. On a informé le client qu’il devait obtenir un RE et présenter une nouvelle demande de prestations. Rémunérations déclarées entre le renouvellement de l’ancienne demande et le début de la demande subséquente. »

- Compléter le calcul de l’AT.

**Départ volontaire/inconduite dans la période de référence, les relevés d’emploi chevauchent - Données réelles peuvent être requises (1096)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Un RE litigieux autre que le dernier RE indique l’un des éléments suivants dans le champ Condition spéciale :

- Vide

- Mauvaise conduite prouvée

- Départ volontaire - Motif non valable

- Ce RE chevauche un RE subséquent qui n’est pas litigieux.

- Le CAC ne peut pas déterminer le nombre réel d’heures pendant lesquelles le client a travaillé après le DJT indiqué sur le RE litigieux.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0873.dita) 

**Ce qu’il faut faire**

- Dans SNCT, examiner les RD pour déterminer si le MCE litigieux a fait l’objet d’une décision :

- Si oui, passer à l’étape 2.

- Si non, consulter Examiner une question en suspens sans AT Litige(s) — Décision .
             [Examiner une question en suspens sans AT Litige(s) — Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Dans MSRE, déterminer si les champs Motif de cessation d’emploi et Condition spéciale sur le RE correspondent à la décision du RD :

- Si oui, passer à l’étape 3.

- Si non, corriger le RE et choisir Soumettre . Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
             [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Déterminer si le RE non litigieux subséquent est un RE TAP (le numéro de série commence par un « S »).

- S’il s’agit d’un RE TAP, passer à l’étape 4.

- S’il ne s’agit pas d’un RE TAP, passer à l’étape 6.

- Déterminer si les heures indiquées dans la case 15C du RE TAP sont affichées dans les bonnes périodes de paie du Fichier historique d’emploi :

- Si non, passer à l’étape 5.

- Si oui, passer à l’étape Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0874.dita)

- Copier les renseignements sur les heures pour chaque période de paie inscrite à la case 15C du RE dans le Fichier historique d’emploi . Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Effectuer un recueil de faits auprès de l’employeur afin d’obtenir les heures réelles requises.
         [recueil de faits](/fr/procedure/task/fact_find.shtml)

- Déterminer si l’employeur a été joint durant le recueil de faits :

- Si l’employeur n’ a pas été joint, passer à l’étape 8.

- Si l’employeur a été joint, passer à l’étape 10.

- Effectuer un recueil de faits auprès du client afin d’obtenir les heures réelles requises.
         [recueil de faits](/fr/procedure/task/fact_find.shtml)

- Déterminer si le client a été joint lors du recueil de faits :

- Si le client a été joint, passer à l’étape 10.

- Si le client n’ a pas été joint, passer à l’étape 12.

- Dans SNCT, ajouter des renseignements au RSDP en ébauche créé lors du recueil de faits ou créer un nouveau RSDP de la façon suivante :

- Principal problème : Choisir Calcul .

- Commentaires : Saisir « Heures réelles obtenues pour le calcul » et indiquer la personne qui a fourni les renseignements.

- Détails : Consigner tout détail relatif au recueil de faits selon la Politique nationale sur le recueil de faits et la documentation .
             [Politique nationale sur le recueil de faits et la documentation](/fr/policy/nationalpolicy/national_policy_factfinding.shtml)

- Choisir Sauvegarder .

- Saisir les heures obtenues dans les périodes de paie appropriées du Fichier historique d’emploi .

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

**Procédure suivante**

- Déterminer si le GP demandé pour le calcul est pêcheur :

- Si oui, consulter Traiter le calcul ou le nouveau calcul d’une demande de prestations de pêcheur .
             [Traiter le calcul ou le nouveau calcul d’une demande de prestations de pêcheur](/fr/procedure/activity/calc_fish.shtml)

- Si non, consulter l’étape 2 de Examiner le Résultat de calcul .
             [Examiner le Résultat de calcul](/fr/procedure/subactivity/calc_result_ccb.shtml)

**Données réelles manuelles présentes - Données réelles requises (1149)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand une meilleure semaine variable coïncide avec une semaine qui contient des données réelles manuelles et que toutes les conditions suivantes sont remplies :

- Selon le calcul, il y a suffisamment d’heures pour faire établir une demande, y compris les demandes de prestations spéciales liées à une inadmissibilité aux prestations régulières.

- Le taux de prestations déterminé à l’exclusion de tout supplément familial est inférieur au taux de prestations maximum.

- Il y a un questionnaire Meilleures semaines variables dans SNCT.

- Une saisie manuelle a été effectuée dans le Fichier historique d’emploi d’un RE pour la même semaine qu’une des meilleures semaines variables (MSV) figurant sur le questionnaire électronique Meilleures semaines variables .

Si vous venez tout juste de saisir les renseignements sur les MSV dans le Fichier historique d’emploi à la suite du message « Meilleures semaines - Données réelles requises », vous pouvez accepter ce message sans autre examen et passer à Procédure suivante . Sinon, il faut examiner le Fichier historique d’emploi.
       [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

Vous devez vous assurer que les renseignements sur les MSV dans le Fichier historique d’emploi du RE associé correspondent aux renseignements les plus récents obtenus du client. Une fois que vous avez examiné les renseignements et apporté toutes les corrections nécessaires, vous pouvez accepter ce message et passer à Procédure suivante .
       [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Ce qu’il faut faire**

- Dans SNCT, choisir Systèmes - Afficher questionnaire .

- S’il n’ y a aucun questionnaire des meilleures semaines, passer à l’étape 2.

- S’il y a un questionnaire des meilleures semaines, choisir le questionnaire rempli le plus récent joint à la demande électronique et passer à l’étape 4.

- Déterminer si les renseignements des MSV sont détaillés dans un RSDP ou un AT Action à prendre (AP) (appelé « questionnaire » dans les étapes suivantes) :

- Si non, passer à l’étape 3.

- Si oui, passer à l’étape 4.

- Choisir la section MSV Détails de la Demande électronique (appelée « questionnaire » dans les étapes suivantes) et déterminer si le client a fourni les renseignements sur les MSV.

- Si oui, passer à l’étape 4.

- Si non, passer à l’étape 14.

- Examiner le questionnaire pour déterminer chacun des renseignements suivants :

- le nombre d’employeurs mentionnés pour chaque montant de meilleure semaine variable saisit

- les semaines civiles mentionnées.

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0867.dita)

- Dans MSRE, déterminer s’il existe un RE de l’employeur pour chaque semaine civile mentionnée :

- Si oui, passer à l’étape 6.

- Si non, passer à l’étape 13.

- Déterminer si la case FHE s’affiche à côté du RE :

- Si oui, choisir la case pour ouvrir le Fichier historique d’emploi et passer à l’étape 7.

- Si non, consulter Corriger un RE avant de procéder.
             [Corriger un RE](/fr/procedure/activity/correct_roe.shtml)

- Dans le Fichier historique d’emploi , pour la semaine saisie, déterminer si 0,00 $ est affiché :

- Si non, passer à l’étape 8.

- Si oui, passer à l’étape 10.

- Déterminer si le montant inscrit dans le questionnaire est égal au montant de la s/c correspondante :

- Si non, passer à l’étape 9.

- Si oui, passer à l’étape 11.

- Dans le champ Code de semaine - Rémunérations de la semaine civile correspondante, saisir le montant indiqué dans le questionnaire.

- S’il n’y a pas de point d’exclamation, passer à l’étape 11.

- S’il y a un point d’exclamation, suivre les directives suivantes :

- Raison pour obtenir les données réelles : Choisir Meilleures semaines .

- Choisir Valider .

- Si le point d’exclamation reste visible, passer à l’étape 10.

- Si le point d’exclamation n’est plus visible, passer à l’étape 11.

- Corriger le message d’erreur du Fichier historique d’emploi en utilisant le tableau suivant :

```text
| Message d’erreur | Mesure requise |

| La période de paie du RE est NUL dans 15C. Des données réelles ne peuvent être entrées . | - Supprimer l’entrée des MSV. |

| Les rémunérations pour la période de paie (x) ne peuvent pas être 0,00 car aucun détail n’a été fourni dans la case 15C du RE .. | - Vérifier que le montant 0,00 $ n’ a pas été saisi par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |

| Le total des rémunérations des données réels saisi (xx) ne correspond pas au Total des rémunérations déclaré sur le RE 15B (xx) . | Vérifier s’il est possible de corriger l’erreur en supprimant l’entrée de la meilleure semaine variable la moins élevée : - Si l’erreur est corrigée, supprimer tous les montants saisis pour la période de paie et saisir toutes les MSV, à l’exception de l’entrée du montant le moins élevé. - Si l’erreur n’ est pas corrigée, supprimer tous les montants saisis et saisir les MSV pour toutes les périodes de paie, à l’exception de la période de paie causant l’erreur. |

| Le total des heures inscrit (xx) est supérieur au total des heures déclaré (xx) sur le RE . | - Vérifier si un montant erroné a été saisi dans le champ Heures . - Supprimer tous les montants saisis et saisir les bons montants. |

| Les Heures ne peuvent pas excéder 24 heures par jour. La valeur doit être entre 0,00 et (xx) . | - Vérifier qu’ aucun montant n’ a été saisi dans le champ Heures par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |

| Les rémunérations doivent être entre 0,00 et 99999999,99 . | - Saisir le montant en utilisant le bon format. |

| Les Rémunérations pour la première période de paie ne peuvent pas être 0 car ils contiennent le premier jour de travail. Les Heures pour la première période de paie ne peuvent pas être 0 car ils contiennent le premier jour de travail . | - Vérifier que le montant 0,00 $ n’ a pas été saisi par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |

| Les rémunérations pour la période de paie (x) (xx) ne correspondent pas aux rémunérations déclarés dans le 15C sur le RE (xx). Ils doivent être égaux . | Vérifier s’il est possible de corriger l’erreur en supprimant l’entrée de la meilleure semaine variable la moins élevée : - Si l’erreur est corrigée, supprimer tous les montants saisis pour la période de paie et saisir toutes les MSV, à l’exception de l’entrée du montant le moins élevé. - Si l’erreur n’ est pas corrigée, supprimer tous les montants saisis et saisir les MSV pour toutes les périodes de paie, à l’exception de la période de paie causant l’erreur. |

| Les Rémunérations pour la période de paie finale ne peuvent pas être 0 car ils contiennent le dernier jour payé. Les Heures pour la période de paie finale ne peuvent pas être 0 car ils contiennent le dernier jour payé . | - Vérifier que le montant 0,00 $ n’ a pas été saisi par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |
```

- Si l’entrée est encore marquée d’un point d’exclamation, répéter l’étape 10.

- Si l’entrée n’est plus marquée d’un point d’exclamation, passer à l’étape 11.

- Déterminer s’il y a d’autres semaines à saisir pour ce RE :

- Si oui, retourner à l’étape 7 pour saisir la prochaine meilleure semaine variable.

- Si non, passer à l’étape 12.

- Déterminer si des entrées ont été consignées dans le Fichier historique d’emploi du RE :

- Si non, sortir du Fichier historique d’emploi et passer à l’étape 15.

- Si oui, suivre les directives suivantes :

- Si le champ Raison pour obtenir les données réelles est vide, choisir Meilleures semaines .

- Si le champ Valider est en gris, choisir Sauvegarder .

- Si le champ Valider n’est pas en gris, choisir Valider et Sauvegarder .

- Déterminer s’il existe des MSV d’un autre employeur à saisir :

- Si oui, retourner à l’étape 5 pour le prochain employeur.

- Si non, passer à l’étape 14.

- Déterminer si des entrées ont été saisies dans le Fichier historique d’emploi de tout RE :

- Si oui, passer à l’étape 15.

- Si non, passer à l’étape 16.
             [l’étape](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Données réelles n’ont pas été automatisées (1124)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Il y a une demande précédente qui correspond à la PR.

- Le client a déclaré des gains de 0,00 $ pour une semaine au cours de la PR.

- Les détails de la période de paie du RE empêchent de saisir 0,00 $.

- Selon le calcul, le client a travaillé pendant suffisamment d’heures pour faire établir une demande de prestations.

- Le taux de prestations déterminé est inférieur au taux de prestations maximum à l’exclusion du supplément familial.

Le système examine l’ État récapitulatif des paiements des demandes précédentes. Si le client a reçu des prestations d’AE pour une semaine et a déclaré des gains de 0,00 $, le système tente de saisir ce montant de 0,00 $ pour la semaine dans le Fichier historique d’emploi .

Le message inclus le numéro de série du RE touché.

**Ce qu’il faut faire**

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**DPA est inscrite - Est-ce que la SDM-EXT est requise (1134)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le GP est prestations de maladie.

- Selon le calcul, il y a suffisamment d’heures pour que la cliente soit admissible aux prestations spéciales.

- La section Prestations spéciales de l’écran Résultat de calcul affiche la semaine de début et de fin des prestations de maternité. Ces dates correspondent à la fenêtre de maternité.

- Il n’y a pas de date figurant dans le champ Semaine de début de maternité externe à l’écran Annexe - Prestations spéciales dans la version Web de SSA.

- La semaine de début de la période de maternité est avant la date à laquelle le client peut recevoir le nombre maximal de semaines d’admissibilité aux prestations de maladie.
         [semaines d’admissibilité](/fr/procedure/generic/additionalresources/max_ent_ben.shtml)

La demande est automatiquement convertie en prestations de maternité quand toutes les conditions suivantes sont remplies :

- il y a une fenêtre de maternité;

- des prestations de maternité peuvent être versées;

- les déclarations du prestataire sont traitées pour une semaine dans la fenêtre de maternité.

Si le client est admissible à un GP autre que maternité pendant la fenêtre de maternité calculée ou qu’il faut empêcher le versement de prestations de maternité pendant cette fenêtre, dans la version Web de SSA, l’agent doit saisir une date dans le champ Semaine de début de maternité externe pour contourner la fenêtre de maternité calculée.

Si le client n ’est pas admissible à un GP autre que maternité pendant la fenêtre de maternité calculée ou qu’il ne faut pas empêcher le versement de prestations de maternité pendant cette fenêtre, il n’est pas nécessaire de saisir une date dans le champ Semaine de début de maternité externe dans la version Web de SSA. L’agent accepte ce message et continue le calcul de la demande.

**Ce qu’il faut faire**

- Déterminer si la question liée à une date de début de maternité externe a été révisée :

- Si oui, passer à l’étape 2.

- Si non, consulter à Déterminer si les dates de la période de maternité externe sont requises .
             [Déterminer si les dates de la période de maternité externe sont requises](/fr/procedure/task/determining_emdr.shtml)

- Déterminer si une date est nécessaire dans le champ Semaine de début de maternité externe :

- Si non, accepter ce message et passer à l’étape 3.

- Si oui, consulter Modifier les renseignements sur les prestations de maternité sur l’annexe pour les prestations spéciales dans la version Web de SSA .
             [Modifier les renseignements sur les prestations de maternité sur l’annexe pour les prestations spéciales dans la version Web de SSA](/fr/procedure/task/modifying_mat_sb_ssa.shtml)

- Passer à Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**DPP est placé après la période courante de la norme variable d’admissibilité applicable - Vérifier le Résultat de calcul (1068)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand la norme variable d’admissibilité (NVA) du DPP n’est pas encore connue. Sans la NVA, qui est basée sur le taux régional de chômage de la région économique, la demande ne peut pas être calculée. L’agent doit déplacer l’AT lié au calcul vers En suspens jusqu’à ce que la NVA soit disponible.

**Ce qu’il faut faire**

- Dans SNCT, déplacer l’AT lié au calcul vers En suspens de la façon suivante :

- Motif de la mise en suspens : Choisir Autre .

- Commentaires : Saisir « Impossible de calculer avant que la NVA de ce DPP soit connue. »

- Date à revoir : Saisir le premier jour ouvrable de la semaine suivante.

- Quand l’AT est déplacé vers la charge de travail actuelle, passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

**DPP pas à l’intérieur de la fenêtre compassion (1109)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Selon le calcul, il y a suffisamment d’heures pour faire établir une demande.

- Le GD est PDC.

- La section Prestations spéciales de l’écran Résultat de calcul affiche la semaine de début et de fin de la fenêtre de compassion (FC).

- Le DPP est à l’extérieur de la FC.

Si le calcul est accepté et que ce message s’affiche, la version Web de SSA crée une transaction M161 - Exclusions/Inadmissibilités (M161) pour imposer une inadmissibilité indéterminée 51 - Ne rencontre pas les conditions d’admissibilité de prestations de soins de compassion (D51)  à partir du DPP et saisit un indicatif d’état 4 à la transaction M112 - Prestations de compassion-Admissibilité du prestataire (M112) .

Ce message, s’il y a lieu, apparait même si l’écran Enregistrement affiche que la preuve de compassion est en suspens. Quand une preuve de compassion est en suspens, l’agent ne doit pas saisir la date dans le champ Semaine de début de la fenêtre compassion à l’écran Annexe - Prestations spéciales , puisqu’une inadmissibilité D51 serait imposée incorrectement.

Si le DPP est avant la FC, postdater la demande pourrait rendre le client admissible aux PDC. Lors de la révision du DPP, l’agent doit se souvenir qu’une postdate pourrait être nécessaire. Puis, l’agent accepte ce message et continue le calcul de la demande.

Si le client n’a pas présenté sa demande dans les délais prescrits, l’agent détermine si une antidate s’applique.

**Ce qu’il faut faire**

- Déterminer si un RD contient une preuve de compassion en suspens :

- Si oui, passer à l’étape 2.

- Si non, passer à l’étape 4.

- Dans la version Web de SSA, à l’écran Annexe - Prestations spéciales , enlever la date indiquée dans le champ Semaine de début de la fenêtre compassion .

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Déterminer si le DPP calculé est postérieur à la FC :

- Si oui, passer à l’étape 5.

- Si non, passer à l’étape 10.

- Déterminer si le client a présenté sa demande de prestations dans les délais prescrits :

- Si non, passer à l’étape 6.

- Si oui, accepter ce message et passer à l’étape 11.

- Déterminer si le client a demandé une antidate ou s’il existe une antidate sous-entendue :

- Si oui, passer à l’étape 7.

- Si non, accepter ce message et passer à l’étape 11.

- Déterminer si une décision sur l’antidate a été rendue :

- Si oui, passer à l’étape 8.

- Si non, consulter Examiner une question en suspens sans AT Litige(s) - Décision .
             [Examiner une question en suspens sans AT Litige(s) - Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Déterminer si l’antidate a été accordée :

- Si oui, passer à l’étape 9.

- Si non, accepter ce message et passer à l’étape 11.

- Déterminer si le DPP à l’écran Résultat de calcul correspond à la date antérieure :

- Si oui, accepter ce message et passer à l’étape 11.

- Si non, consulter Saisir une antidate dans la version Web de SSA .
             [Saisir une antidate dans la version Web de SSA](/fr/procedure/task/calc_calculating/input_antedate.shtml)

- Lors de la révision du DPP, se souvenir qu’une postdate à la première semaine à laquelle le client est admissible à des PDC doit être considérée. Accepter ce message.

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**DPP pas à l’intérieur de la fenêtre parentale (1099)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Selon le calcul, il y a suffisamment d’heures pour faire établir une demande (y compris les demandes de prestations spéciales) assorties d’une inadmissibilité aux prestations régulières.

- Le GD est prestations parentales.

- Le DPP est à l’extérieur de la fenêtre parentale (FP).

Si le calcul est accepté et que ce message s’affiche, la version Web de SSA crée une transaction M161 pour imposer une inadmissibilité indéterminée 35 - Prestations parentales - conditions de qualification non rencontrées (D35) à partir du DPP.

Si le DPP est avant la FP, postdater la demande pourrait rendre le client admissible aux prestations parentales. Lors de la révision du DPP, l’agent doit se souvenir qu’une postdate pourrait être nécessaire. Pour plus de renseignements, consulter la Politique sur les postdates . Après que le DPP est déterminé, l’agent accepte ce message et continue le calcul de la demande.
       [Politique sur les postdates](/fr/policy/nationalpolicy/national_policy_on_postdates.shtml)

Si le client n’a pas présenté sa demande dans les délais prescrits, l’agent détermine si une antidate s’applique

**Ce qu’il faut faire**

- Déterminer si le DPP se trouve avant la FP :

- Si non, passer à l’étape 2

- Si oui, passer à l’étape 9.

- Déterminer si la question de la prolongation de la FP a fait l’objet d’une révision :

- Si oui, passer à l’étape 3.

- Si non, passer à Déterminer si une prolongation de la fenêtre parentale est requise lors du calcul d’une demande .
             [Déterminer si une prolongation de la fenêtre parentale est requise lors du calcul d’une demande](/fr/procedure/task/determining_epw_cc.shtml)

- Déterminer si la prolongation de la FP a été saisie :

- Si oui, passer à l’étape 4.

- Si non, consulter Prolonger la période de prestations et la fenêtre parentale en raison de l’hospitalisation de l’enfant dans la version Web de SSA .
             [Prolonger la période de prestations et la fenêtre parentale en raison de l’hospitalisation de l’enfant dans la version Web de SSA](/fr/procedure/task/extending_bp_par_ssa.shtml)

- Déterminer si le client a présenté sa demande de prestations dans les délais prescrits :

- Si non, passer à l’étape 5.

- Si oui, accepter ce message et passer à l’étape 10.

- Déterminer si le client a demandé une antidate ou s’il existe une antidate sous-entendue :

- Si oui, passer à l’étape 6.

- Si non, accepter ce message et passer à l’étape 10.

- Déterminer si une décision sur l’antidate a été rendue :

- Si oui, passer à l’étape 7.

- Si non, consulter Examiner une question en suspens sans AT Litige(s) – Décision .
             [Examiner une question en suspens sans AT Litige(s) – Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Déterminer si l’antidate a été accordée :

- Si oui, passer à l’étape 8.

- Si non, accepter ce message et passer à l’étape 10.

- Déterminer si le DPP à l’écran Résultat de calcul correspond à la date antérieure :

- Si oui, accepter ce message et passer à l’étape 10.

- Si non, consulter Saisir une antidate dans la version Web de SSA .
             [Saisir une antidate dans la version Web de SSA](/fr/procedure/task/calc_calculating/input_antedate.shtml)

- Lors de la révision du DPP, se souvenir qu’une postdate à la première semaine à laquelle le client est admissible à des prestations pour proches aidants devrait être considérée. Pour plus de renseignements, consulter la Politique sur les postdates . Accepter ce message.
         [Politique sur les postdates](/fr/policy/nationalpolicy/national_policy_on_postdates.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Dû à la prolongation de la période de référence, des heures assurables supplémentaires peuvent être requises (1093)**

**Ce qu’il faut savoir**

Ce message est affiché quand toutes les conditions suivantes sont remplies :

- Le résultat de calcul inclut une prolongation de la PR.

- Un RE utilisé dans le calcul de la demande contient les renseignements suivants :

- Un DJT payé après la date limite (DL) initiale de la PR.

- Un premier jour de travail effectué avant la DL initiale de la PR.

- Des gains inscrits à la case 15B qui ont été calculés avec une période débutant après la DL de la PR prolongée.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0875.dita) 

**Ce qu’il faut faire**

- À l’écran Résultat de calcul , déterminer si le taux de prestations et le nombre de semaines d’admissibilité ont atteint leur maximum :

- Si non, passer à l’étape 2.

- Si oui, accepter le message et passer à l’étape 9.

- Effectuer un recueil de faits auprès de l’employeur afin d’obtenir les renseignements suivants :

- les heures supplémentaires

- la rémunération

- si possible, le premier jour de travail au cours de la première période de paie et le DJT au cours de la période de paie la plus récente pour la PR prolongée.

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0876.dita)

- Déterminer si l’employeur a été contacté pendant le recueil de faits :

- Si l’employeur a été contacté, passer à l’étape 5.

- Si l’employeur n’a pas été contacté ou n’a pas répondu à la lettre Z-02-00-00, passer à l’étape 4.

- Faire une tentative pour joindre le client par téléphone afin d’obtenir les renseignements sur les MSV pour la PR prolongée :

- Si vous avez joint le client, passer à l’étape 5.

- Si vous n’avez pas joint le client, dans SCA, créer et imprimer la lettre Q-01-00-00 , avec les attributs suivants :

- Info requise-REF Antidate/Méd ou traitement ext du Canada/Mat-Par/Dépôt Direct/proches aidants/Texte (3596) : Choisir Spécifier l'information requise.

- Texte : Indiquer l'information requise (1545) : Saisir « Nous vous écrivons au sujet de votre demande de prestations de l'assurance-emploi. Nous avons prolongé votre période de référence de [X] semaines, ce qui nous permet de tenir compte de votre emploi assurable du [date de début de la PR] au [date de fin de la PR]. La période de référence est la plus courte entre la période de 52 semaines précédant immédiatement la date de début de votre demande et la période écoulée depuis le début de votre demande précédente. Toutefois, la période de référence peut être prolongée si vous ne receviez pas de prestations de l'assurance-emploi et étiez incapable de travailler pour l'une des raisons précisées dans la Loi sur l'assurance-emploi (par exemple, une maladie, une blessure, une grossesse, un cours autorisé ou une autre activité liée à l'emploi). Veuillez nous fournir votre rémunération et vos heures de travail pour les périodes de paie entre le [date de début de la période supplémentaire requise] et le [date de fin de la période supplémentaire requise]. Vous pouvez soumettre ces renseignements liés à votre emploi à l'aide de Mon dossier Service Canada ou en nous contactant comme indiqué ci-dessous. En nous fournissant ces renseignements, vous pourriez recevoir des semaines supplémentaires de prestations de l'assurance-emploi ou un taux de prestations plus élevé. »

- Passer à l’étape 9.

- Dans SNCT, ajouter au RSDP en ébauche créé lors du recueil de faits ou créer un nouveau RSDP de la façon suivante :

- Principal problème : Choisir Calcul.

- Commentaires : Saisir « renseignements supplémentaires sur l’emploi assurable. »

- Détails : Consigner tout détail relatif au recueil de faits selon la Politique nationale sur le recueil de faits et la documentation .
             [Politique nationale sur le recueil de faits et la documentation](/fr/policy/nationalpolicy/national_policy_factfinding.shtml)

- Choisir Sauvegarder .

- Dans MSRE, pour le RE original, suivre les directives suivantes:

- Case 10 : Saisir le jour après le DJT de la partie prolongée de la PR.

- Dans MSRE, saisir un RE provisoire de la façon suivante:

- Case 4 : Saisir le nom de l’employeur

- Case 5 : Saisir le numéro d’entreprise de l’ARC.

- Case 6 : Saisir le genre de période de paie.

- Case 10 : Saisir le premier jour de travail au cours de la première période de paie de la PR prolongée.

- Case 11 : Saisir le DJT de la partie prolongée de la PR.

- Case 12 : Saisir la date de fin de la dernière période de paie avec la rémunération de la partie prolongée de la PR.

- Case 15A : Saisir le total des heures assurables de la partie prolongée de la PR.

- Case 15B : Saisir le total de la rémunération assurable de la partie prolongée de la PR.

- Case 16 : Choisir A – Manque de travail .

- Renseignements supplémentaires : Saisir « RE provisoire créé pour la partie prolongée de la PR. »

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**ERP dans la PR - Données réelles n’ont pas été automatisées (1127)**

**Ce qu’il faut savoir**

Le message est affiché quand toutes les conditions suivantes sont remplies :

- Selon le calcul, la demande peut être établie.

- Le taux de prestations à l’exclusion du supplément familial est inférieur au taux maximum.

- Des données réelles manuelles n’ont pas été saisies dans le Fichier historique d’emploi ou dans tout RE associé à la PR.

- Il existe une demande terminée et historique des paiements dans la PR, mais le client n’a pas rempli ses déclarations pour les semaines en question ou a déclaré une rémunération qui empêchait le paiement.

On détermine les semaines d’interruption d’emploi à l’aide des périodes de paie laissées vides (ou 0,00 $) dans le RE et des semaines où le client a déclaré des rémunérations de 0,00 $ dans le cadre de la demande précédente.

Ce qu’il faut faire

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Erreur RE - [numéro de série] (2286)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- L’écran Annexe - Prestations spéciales de la version Web de SSA contient des renseignements sur la prolongation de la PR.

- La date limite provisoire ne précède pas le DPP provisoire – 57;

- Il y a un RE en erreur dans la prolongation possible de la PR (entre la date limite provisoire – 5 et la date limite provisoire – 57).

**Ce qu’il faut faire**

- Traiter le RE selon les procédures. Au besoin, consulter Corriger le RE . Une fois le RE corrigé, SSA permettra de continuer le calcul.
         [Corriger le RE](/fr/procedure/activity/correct_roe.shtml)

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

**État ARC est égal à décédé - SVP réviser (1136)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand les conditions suivantes sont remplies :

- Le GP est prestations spéciales pour les travailleurs indépendants.

- Selon le calcul, la demande peut être présentée.

- L’état ARC est 8 (décédé).

Avant de terminer le traitement de la demande, l’agent l’examine afin d’appliquer les procédures appropriées si le client est décédé.

**Ce qu’il faut faire**

- Consulter Client décédé .
         [Client décédé](/fr/procedure/activity/deseased_client.shtml)

**État de l’accord travail autonome est résiliation. SVP confirmer l’admissibilité (1139)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand les 2 conditions suivantes sont :

- Le client présente une demande de prestations spéciales pour travailleurs autonomes.

- L’état de l’accord sur le travail indépendant (TI) est 3 (résiliation).

Un client pourrait choisir de mettre fin à l’accord qu’il a conclu afin d’être visé par la partie VII (prestations pour les travailleurs indépendants). L’accord peut être résilié seulement si aucune prestation n’a été versée au client en vertu de cette partie de la Loi. Même si le client a décidé de mettre fin à l’accord et qu’aucune prestation ne lui a été versée, le client doit continuer à payer des cotisations d’AE pour l’année civile au cours de laquelle l’accord a pris fin. En raison de cette obligation de payer des cotisations, le client est toujours considéré comme couvert et pourrait être admissible à des prestations au cours de l’année civile.
       [partie VII](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/TexteComplet.html#h-44)

La demande de mettre fin à l’accord doit être annulée si le client choisit de demander ces prestations.

Si un client présente une demande de prestations, vous devez discuter avec le client et confirmer auprès de lui son choix de recevoir des prestations et vous assurer que le client comprend qu’une fois que des prestations ont été versées, des cotisations d’AE doivent continuer à être payées aussi longtemps que le client est travailleur indépendant.

**Ce qu’il faut faire**

- Déterminer s’il y a des renseignements au dossier confirmant que le client souhaite recevoir des prestations d’AE :

- Si non, passer à l’étape 2.

- Si oui, passer à l’étape 5.

- Effectuer un recueil de faits auprès du client pour expliquer que l’accord de TI ne peut pas être terminé une fois que des prestations ont été reçues, et pour confirmer que le client veut encore recevoir des prestations.

- Déterminer si le client a été joint pendant le recueil de faits :

- Si le client a été joint, passer à l’étape 4.

- Si le client n’a pas été joint ou n’a pas répondu à la lettre N-10-00-00, passer à l’étape 9.

- Dans SNCT, ajouter des détails au RSDP en ébauche créé lors du recueil de faits ou créer un nouveau RSDP de la façon suivante :

- Principal problème : Choisir Calcul .

- Commentaires : Saisir « accord de TI. »

- Détails : Documenter les renseignements sur le recueil de faits selon la Politique nationale sur le recueil de faits et la documentation.

- Choisir Sauvegarder .

- Déterminer si le client souhaite recevoir des prestations pour travailleurs indépendants :

- Si le client souhaite recevoir des prestations, passer à l’étape 6.

- Si le client ne souhaite pas recevoir des prestations, passer à l’étape 11.

- Dans la version Web de SSA, à l’écran Formulaire de la demande , remplir le champ suivant :

- Travaille à son compte : Choisir Oui .

- Dans la section Détails sur les travailleurs indépendants , annuler la demande de mettre fin à l’accord sur le travail autonome de la façon suivante :

- État de l’accord TA : Choisir Demande de résiliation annulée .

- Choisir Sauvegarder .

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Se souvenir de créer et d’envoyer la lettre F-00-001 dans SCA avec les attributs suivants :

- Texte - texte libre (1612) : Saisir « Après avoir demandé à mettre fin à votre accord de participer au Programme d’assurance-emploi (AE) pour avoir droit à des prestations spéciales en tant que travailleur autonome , vous avez présenté une demande de prestations spéciales d’AE en tant que travailleur autonome . Nous sommes dans l’obligation de vous informer de nouveau que, si vous recevez ces prestations, vous ne pourrez plus être en mesure de mettre fin à votre accord et serez dans l’obligation de continuer de payer des cotisations d’AE sur tout revenu ultérieur découlant d’un travail autonome.

- « Malheureusement, nous sommes incapables de communiquer avec vous et de vous aviser de ces conditions par téléphone. Par conséquent, nous n’ avons pas traité votre demande de prestations.

- « Si vous souhaitez recevoir des prestations spéciales d’AE en tant que travailleur autonome , veuillez communiquer avec nous en composant le 1-800-808-6352 ou par écrit pour demander le rétablissement de votre accord. »

- Dans SNCT, créer un RDSP de la façon suivante :

- Problème : Choisir Autre .

- Commentaires : Saisir « Accord sur le TA résilié - incapable de communiquer avec le client. »

- Détails : Saisir « L’agent n’a pas pu communiquer avec le client le [date de la tentative de communication]. La résiliation de l’accord sur le travail autonome est maintenue. Une lettre a été envoyée au client pour l’informer de communiquer avec Service Canada s’il souhaite recevoir des prestations. »

- Passer à l’étape 12.

- Dans SNCT, créer un RDSP de la façon suivante :

- Problème : Choisir Autre .

- Commentaires : Saisir « Accord sur le TA résilié - le client ne souhaite pas recevoir de prestations. »

- Détails : Saisir « Le client ne souhaite pas recevoir de prestations. La résiliation de l’accord sur le TA est maintenue. On a expliqué les obligations en vertu de l’accord sur le TA [et tout autre fait obtenu], et le client les a comprises. »

- Dans ETI, choisir la transaction Données des contrôles des fichiers (M101) pour annuler la demande de la façon suivante :

- Choisir Terminer la période de prestations .

- Choisir Mise à jour .

- Choisir la transaction Numéro d’enregistrement (M025, M030 et M035) pour annuler le numéro d’enregistrement de la façon suivante :

- Mesure : Choisir Annuler .

- Choisir Mise à jour .

- Dans SNCT, compléter l’AT lié au calcul.

**Exclusion/inadmissibilité est imposée - Peut se qualifier pour des prestations spéciales (1053 & 2080)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le genre de la demande (GD) est prestations régulières.

- Le Résultat de calcul n’est pas PPNE.

- Le client ne remplit pas les conditions requises pour recevoir des prestations régulières.

- Le client peut remplir les conditions requises pour recevoir des prestations spéciales.

Quand ce message s’affiche, la section Exclusions / Inadmissibilités de l’écran Résultat de calcul affiche aussi une des inadmissibilités ou exclusions suivantes liées à un motif de cessation d’emploi (MCE) :

- 10 - Congédiement - inconduite prouvée (D10)

- 11 - Abandon volontaire - motif valable non prouvé (D11)

- 42 - Suspension d’un emploi (D42)

- 43 - Congé sans solde (D43)

- 44 - Perte d’emploi anticipée (D44)

Dans ce cas, l’agent qui fait le calcul de la demande vérifiera chaque RE inadmissible ou exclu en suivant la tâche Examiner le Résultat de calcul — RE exclus ou inadmissible .
       [Examiner le Résultat de calcul — RE exclus ou inadmissible](/fr/procedure/task/calc_reviewing/review_calc_disqual_exclus.shtml)

**Ce qu’il faut faire**

- Dans la feuille de calcul, noter que pendant l’examen du Résultat de calcul, chaque RE inadmissible ou exclu doit être vérifié.

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Heures ajoutées pour prolongation automatique de la PR (1161)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- CAC accorde la prolongation automatique de 28 semaines de la PR.

- Une période d’emploi supérieure à un an qui chevauche la PR prolongée figure au RE.

- CAC a utilisé la moyenne des heures quotidiennes du RE pour calculer les heures manquantes.

Une prolongation automatique de 28 semaines de la PR est accordée à un client quand les conditions suivantes sont remplies :

- Le DPP de la demande est entre le 27 septembre 2020 (s/c 2258) et le 19 septembre 2021 (s/c 2309).

- La demande est convertie d’une demande pour la prestation d’AE d’urgence (PU AE) ou pour la Prestation canadienne d’urgence (PCU).

- Il ne s’agit pas d’une demande de prestations de pêcheur ou de Travail indépendant (TI).

Quand une prolongation automatique de 28 semaines de la PR s’applique et qu’une période d’emploi supérieure à un an qui chevauche la PR prolongée figure au RE, CAC utilise la moyenne des heures quotidiennes sur le RE pour compléter les données manquantes du RE. Ce message d’avertissement n’est qu’à titre de renseignement seulement et n’existe que pour expliquer le nombre total d’heures assurables dans le Résultat de calcul.

Les demandes auxquelles une prolongation automatique de la PR n’a pas été accordée continueront à afficher le message de calcul 1093 - Dû à la prolongation de la période de référence, des heures assurables supplémentaires peuvent être requises ( au besoin) pour aviser l’agent d’obtenir des renseignements supplémentaires sur les périodes de paie.

**Ce qu’il faut faire**

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Heures d’admissibilité < 600 - Peut se qualifier pour des prestations spéciales (1078)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- le GD est régulière ou de pêcheur.

- Le client est de deuxième catégorie .
         [deuxième catégorie](/fr/procedure/generic/knowledge.shtml)

- Des RE ont été exclus du calcul de la demande.

- Le total des heures combinées de tous les RE est supérieur ou égal à 600.

Si le champ Genre de demande indique Régulières , Pêche estivale ou Pêche hivernale à l’écran Impératif de codage et qu’il y a moins de 600 heures assurables dans la PR, mais qu’utiliser tous les RE rendrait le client admissible aux prestations spéciales, l’agent examine les RE utilisés dans le calcul de la demande. Si un RE a été exclu par erreur parce que le MCE n’a pas fait l’objet d’une décision, l’agent examine le MCE et obtient un nouveau résultat de calcul.

**Ce qu’il faut faire**

- Dans MSRE, déterminer quel RE est exclu du calcul.

- Dans SNCT, déterminer s’il y a un RD concernant la décision ou le report du MCE sur le RE exclu :

- S’il y a un RD, passer à l’étape 3.

- S’il n’y a pas de RD, consulter Examiner une question en suspens sans AT Litige(s) - Décision .
             [Examiner une question en suspens sans AT Litige(s) - Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0877.dita)

- Dans MSRE, déterminer si les champs Motif de cessation d’emploi, Condition spéciale et Date de fin (au besoin) du RE correspondent à la décision sur le RD :

- Si oui, passer à l’étape 4.

- Si non, corriger le RE, choisir Soumettre et passer à l’étape 4.

- Déterminer s’il y a un autre RE exclu qui doit être examiné :

- Si oui, retourner à l’étape 2.

- Si non, passer à l’étape 5.

- Déterminer si des changements ont été apportés dans MSRE:

- Si oui, passer à l’étape 6.

- Si non, passer à l’étape 7.

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#_Procédure_suivante)

**Indemnités de cessation d’emploi - recueil de faits requis (1150)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand la case 17C - Autres sommes (Préciser) du RE affiche S - Règlement d’un différend ou O - Autre . L’agent doit examiner ces sommes pour déterminer si elles sont correctement indiquées dans MSRE. Si les sommes sont indiquées correctement dans MSRE, elles seront réparties à la cessation d’emploi et incluses en tant qu’indemnités assurables de cessation d’emploi.

**Ce qu’il faut faire**

- Déterminer si vous avez examiné les sommes affichées dans la case 17C - Autres sommes (Préciser) :

- Si vous n’avez pas examiné les sommes affichées dans la case 17C - Autres sommes (Préciser) , retourner à Vérifier les RE avant le calcul .
             [Vérifier les RE avant le calcul](/fr/procedure/task/calc_determining/review_roe.shtml)

- Si vous avez examiné les sommes affichées dans la case 17C - Autres sommes (Préciser) et déterminé que les sommes doivent être réparties à la cessation d’emploi et incluses en tant qu’indemnités assurables de cessation d’emploi, accepter le message sans prendre aucune mesure supplémentaire et passer à Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0878.dita) 

**La condition spéciale du dernier RE est requise (1163)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le DPP est entre la s/c 2310 et la s/c 2361.

- La demande n ’est pas PPNE.

- Le MCE du dernier RE est potentiellement litigieux (E, G, K, N ou M).

De plus, l’une des conditions suivantes est remplie :

- Le champ Condition spéciale du RE est vide.

- Le champ Condition spéciale du RE indique Évaluation reportée , et le client demande des prestations régulières comme GP.

**Ce qu’il faut faire**

- Dans SNCT, déterminer s’il y a un RD pour la décision ou le report de la décision sur le MCE du dernier RE :

- S’il y a un RD pour la décision rendue sur le MCE, passer à l’étape 2.

- S’il y a un RD pour le report de la décision sur le MCE, passer à l’étape 3.

- S’il n ’y a pas de RD, consulter Examiner une question en suspens sans AT Litige - Décision .
             [Examiner une question en suspens sans AT Litige - Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Dans MSRE, mettre à jour le champ Condition spéciale du RE selon la décision consignée dans le RD. Choisir Soumettre et passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Dans SNCT, choisir le problème lié au MCE approprié (c.-à-d. le RD indiquant Évaluation reportée ). Dans le menu Options décision , choisir Modifier la décision et choisir OK . Passer à l’étape 15 de Déterminer si une demande est prête à être calculée — Prestations régulières .
         [Déterminer si une demande est prête à être calculée — Prestations régulières](/fr/procedure/subactivity/determining_reg_claim_ready.shtml)

**Le DPP est après la fin de la fenêtre pour proches aidants – SVP réviser (1143)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le GD est prestations pour proches aidants.

- Selon le calcul, le client a travaillé pendant suffisamment d’heures pour faire établir une demande.

- L’écran Résultat de calcul affiche une semaine de début et une semaine de fin de la fenêtre pour proches aidants (FPA). Ces dates correspondent à la FPA.

- Le DPP est après la semaine de fin de la FPA.

Quand une demande est établie pour des prestations pour proches aidants après la FPA, les prestations pour proches aidants ne sont pas payables.

Si le calcul est accepté avec ce message, la version Web de SSA crée une transaction M161 avec une inadmissibilité indéterminée D61 à partir du DPP.

Si le client ne présente pas sa demande dans les délais prescrits, l’agent détermine si une antidate s’applique.

Un RD doit être au dossier quand le client est déclaré inadmissible aux prestations spéciales sauf s’il est inadmissible parce qu’il est de deuxième catégorie. Quand un RD est requis, mais qu’il n’est pas au dossier, l’agent retourne à la tâche précédente afin de déterminer si l’inadmissibilité est exacte.

**Ce qu’il faut faire**

- Déterminer si le client a présenté sa demande de prestations dans les délais prescrits :

- Si non, passer à l’étape 2.

- Si oui, accepter ce message et passer à l’étape 6.

- Déterminer si le client a fait une demande d’antidate ou s’il y a une antidate sous-entendue :

- Si oui, passer à l’étape 3.

- Si non, accepter ce message et passer à l’étape 6.

- Déterminer si l’antidate a fait l’objet d’une décision :

- Si oui, passer à l’étape 4.

- Si non, consulter Examiner une question en suspens sans AT Litige(s) - Décision .
             [Examiner une question en suspens sans AT Litige(s) - Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Déterminer si la demande d’antidate a été accordée :

- Si oui, passer à l’étape 5.

- Si non, accepter ce message et passer à l’étape 6.

- Déterminer si le DPP à l’écran Résultat de calcul correspond à la date antérieure :

- Si oui, accepter ce message et passer à l’étape 6.

- Si non, consulter Saisir une antidate dans la version Web de SSA .
             [Saisir une antidate dans la version Web de SSA](/fr/procedure/task/calc_calculating/input_antedate.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Le DPP est avant la date de début de la fenêtre pour proches aidants - SVP réviser (1146)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Selon le calcul, une demande peut être établie.

- Le GD est prestations pour proches aidants.

- L’écran Résultat de calcul affiche une semaine de début et de fin de la fenêtre pour proches aidants (FPA).

- Le DPP est antérieur à la FPA.

Si le calcul est accepté et que ce message s’affiche, la version Web de SSA crée une transaction M161 avec une inadmissibilité indéterminée 61 - Proches aidants d’enfants ou d’adultes - Ne rencontre pas les conditions d’admissibilité (D61) à partir du DPP jusqu’au cinquième jour de la semaine avant le début de la FPA.

La postdate de la demande pourrait rendre le client admissible aux prestations pour proches aidants. Lors de la révision du DPP, l’agent doit se souvenir qu’une postdate pourrait être nécessaire. Puis, l’agent accepte ce message et continue le calcul de la demande.

**Ce qu’il faut faire**

- Lors de la révision du DPP, se souvenir qu’une postdate à la première semaine à laquelle le client est admissible à des PDC devrait être considérée. Accepter ce message.

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Le DPP pourrait possiblement être postdaté – SVP réviser (1137)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le GD est prestations spéciales pour les travailleurs indépendants.

- Le dimanche de la semaine du DPP se trouve au mois de décembre.

- Les rémunérations de TA au cours de la PR sont inférieures au seuil de rémunérations minimales requises (PPNE 3).
         [PR](/fr/procedure/generic/knowledge.shtml) 
         [seuil de rémunérations minimales requises](http://www.servicecanada.gc.ca/fra/sc/ae/ta/admissibilite.shtml)

Le PR est l’année civile avant la semaine du DPP. Un client qui présente une demande au cours du mois de décembre pourrait ne pas avoir accumulé les rémunérations requises au cours de la PR pour être admissible aux prestations pour TA. Cependant, en postdatant la semaine du DPP d’une période allant jusqu’à 4 semaines, le client pourrait avoir les rémunérations requises pour être admissible aux prestations.

**Ce qu’il faut faire**

- Déterminer si un recueil de faits a déjà été effectué pour obtenir des renseignements sur les rémunérations liées au travail indépendant pour l’année au cours de laquelle la demande a été présentée :

- Si non, effectuer un recueil de faits auprès du client pour obtenir des renseignements sur les rémunérations liées au travail indépendant pour l’année civile au cours de laquelle la demande a été présentée et passer à l’étape 2.

- Si oui, passer à l’étape 4.

- Déterminer si le client a été joint pendant le recueil de faits :

- Si le client a été contacté, passer à l’étape 3.

- Si le client n’a pas été contacté ou n’a pas répondu à la lettre N-10-00-00, passer à l’étape 4.

- Dans SNCT, ajouter au RSDP en ébauche créé lors du recueil de faits ou créer un nouveau RSDP de la façon suivante :

- Principal problème : Choisir Calcul .

- Commentaires : Saisir « Vérification des renseignements sur les rémunérations de travail autonome indépendant dans la période de référence. »

- Détails : Consigner tout détail relatif au recueil de faits selon la Politique nationale sur le recueil de faits et la documentation .
             [Politique nationale sur le recueil de faits et la documentation](/fr/policy/nationalpolicy/national_policy_factfinding.shtml)

- Choisir Sauvegarder .

- Déterminer si le client a obtenu les rémunérations minimales requises au cours de l’année civile dans laquelle tombe le mois de décembre de l’année de la demande :

- Si oui, passer à l’étape 5.

- Si non, passer à l’étape 9.

- Dans la version Web de SSA, à partir de l’écran Impératif de codage , compléter le champ suivant :

- DPP subséquent ou manuel : Choisir la date correspondant au dimanche de la première semaine complète de janvier de l’année suivant l’année de la demande.

- Dans la version Web de SSA, à l’écran Formulaire de la demande , remplir le champ suivant :

- Dans la section Détails sur les travailleurs indépendants , remplir les champs suivants :

- Genre de la demande : Choisir le GP s’il n’est pas déjà affiché.

- Rémunération estimée : Saisir le montant de la rémunération estimée que le client a fourni.

- État ARC : Choisir Non évalué .

- Choisir Prochain .

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Créer et envoyer la lettre N-70-00-00 dans SCA avec les attributs suivants :

- PPNE 3/4/8, D73/D74, Rém. estimée, Nouveau-calcul rém. réelle, RE exclu (DV & Congédiement) (3882) : Choisir Demande est PPNE 3 ou Demande est PPNE 3 (avec violation) selon la situation.

- Rémunération de TI requise (3895) : Saisir le montant nécessaire.

- Date du début de la période de référence (4290) : Saisir le premier jour de l’année civile avant le DPP (p. ex. 01-01-2013 si la date du DPP est le 3 août 2014).

- Date de fin de la période de référence (4292) : Saisir le dernier jour de l’année civile avant le DPP (p. ex. 31-12-2013 si la date du DPP est le 3 août 2014)

- Montant de la rémunération tirée d’un travail autonome (3897) : Saisir le montant des gains tels qu’ils s’affichent à l’écran Résultat de calcul .

- Accepter le message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Le total de la moyenne quotidienne > celui sur le RDE. Régler le FHE manuellement (1121)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand le nombre total d’heures du Fichier historique d’emploi est supérieur au nombre d’heures indiqué à la case 15A : Heures du RE.

Le Fichier historique d’emploi affiche le nombre d’heures moyen selon la case 15A : Heures du RE et le nombre de jours de travail indiqué dans le RE.

Le CAC permet de déterminer le nombre d’heures moyen de la façon suivante :

- Toute période de paie d’un montant de 0,00 $ à la case 15C : Détails période de paye n’est pas prise en considération au moment de déterminer le nombre de jours de travail.

- En fonction du nombre d’heures indiqué à la case 15A : Heures et du nombre de jours de travail, le nombre moyen d’heures de travail quotidiennes est calculé, arrondi à deux décimales et affiché dans le Fichier historique d’emploi . En raison de l’arrondissement, le nombre total d’heures, après addition des moyennes quotidiennes, pourrait être supérieur au total indiqué à la case 15A.

Ce message est affiché dans les RE qui pourraient affecter le calcul.

**Ce qu’il faut faire**

- Calculer le nombre total d’heures pour chaque semaine dans le Fichier historique d’emploi .

- Soustraire le montant indiqué à la case 15A : Heures du nombre total indiqué dans le Fichier historique d’emploi .

- Soustraire la différence calculée à l’étape 2 de la première semaine indiquée dans le Fichier historique d’emploi .

- Saisir le montant calculé à l’étape 3 pour les premières semaines indiquées dans le Fichier historique d’emploi .

- Raisons pour les données réelles : Choisir Données réelles fournies par le prestataire . (Ce choix est une solution possible sur le plan administratif.)

- Choisir Valider et Sauvegarder .

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

**Maternité différée et délai de carence supprimé - S.V.P. réviser (1040)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- La section Prestations spéciales de l’écran Résultat de calcul affiche la semaine de début des prestations de maternité et la semaine de fin. Ces dates correspondent à la fenêtre de maternité.

- Le champ Semaine de début de maternité externe est rempli à l’écran Annexe - Prestations spéciales dans la version Web de SSA.

- Le DC est supprimé.

La demande est automatiquement convertie en prestations de maternité quand toutes les conditions suivantes sont remplies :

- il y a une fenêtre de maternité;

- des prestations de maternité peuvent être versées;

- les déclarations du prestataire sont traitées pour une semaine dans la fenêtre de maternité.

Si le client est admissible à un GP autre que maternité pendant la fenêtre de maternité calculée ou qu’il faut empêcher le versement de prestations de maternité pendant cette fenêtre, dans la version Web de SSA, l’agent doit saisir une date dans le champ Semaine de début de maternité externe pour contourner la fenêtre de maternité calculée.

Si le client n’ est pas admissible à un GP autre que maternité pendant la fenêtre de maternité calculée ou qu’il ne faut pas empêcher le versement de prestations de maternité pendant cette fenêtre, il n’est pas nécessaire de saisir une date dans le champ Semaine de début de maternité externe dans la version Web de SSA. L’agent accepte ce message et continue le calcul de la demande.

Bien qu’une cliente pourrait remplir les conditions d’admissibilité pour supprimer le DC , elle pourrait choisir de l’observer. Cette situation peut survenir parce que l’employeur verse un supplément dans le cadre d’une prestation supplémentaire de chômage au cours du délai de carence ou parce que l’autre parent touchera des prestations parentales et qu’il souhaite reporter le DC.
       [DC](/fr/procedure/generic/knowledge.shtml)

**Ce qu’il faut faire**

- Déterminer si le champ Semaine de début de maternité externe est rempli correctement à l’écran Annexe - Prestations spéciales :

- Si oui, passer à l’étape 2.

- Si non, consulter Modifier les renseignements sur les prestations de maternité sur l’annexe pour les prestations spéciales dans la version Web de SSA .
             [Modifier les renseignements sur les prestations de maternité sur l’annexe pour les prestations spéciales dans la version Web de SSA](/fr/procedure/task/modifying_mat_sb_ssa.shtml)

- Déterminer si le délai de carence devrait être supprimé :

- Si non, passer à l’étape 3.

- Si oui, accepter ce message et passer à l’étape 5.

- Dans la version Web de SSA, à partir de l’écran Détermination de la rémunération , remplir le champ suivant :

- Suppression du délai de carence : Choisir 1 - Non .

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Maternité payable < 15 semaines (1123)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- La demande est établie;

- Le GD est prestations de maternité.

- La section Prestations spéciales de l’écran Résultat de calcul affiche la semaine de début des prestations de maternité et la semaine de fin. Ces dates correspondent à la fenêtre de maternité.

- Le client pourrait recevoir moins que 15 semaines de prestations de maternité, selon la semaine de fin de la période de maternité, le délai de carence et la semaine de RAT.

Ce message peut être joint au message 1008 - Demande de maternité - DPP n’est pas à l’intérieur de la fenêtre maternité . Dans ce cas, traiter cette question d’abord.

Les prestations de maternité ne peuvent pas être versées à l’extérieur de la fenêtre de maternité.

Si une date est saisie dans le champ Semaine de fin de maternité externe (p. ex. un client établit une demande subséquente pour recevoir le reste des prestations de maternité), cette date s’affiche comme la fin de la semaine de maternité, à l’écran Résultat de calcul .

Quand une prolongation de la fenêtre de maternité est nécessaire, la prolongation est saisie manuellement dans la M107 une fois que le résultat de calcul est accepté. Dans ce cas, la semaine de fin de la période de maternité qui s’affiche à l’écran Résultat de calcul correspond à la fenêtre de maternité avant qu’elle soit prolongée.

Si le client n’a pas présenté sa demande dans les délais prescrits, l’agent détermine si une antidate s’applique.

**Ce qu’il faut faire**

- Déterminer si le client est payable moins que le nombre maximal de semaines d’admissibilité de prestations de maternité seulement en raison d’une date de RAT indiquée dans le RE :

- Si non, passer à l’étape 2.

- Si oui, accepter le message et passer à l’étape 14.

- Déterminer si une date doit être saisie dans le champ Semaine de fin de maternité externe pour empêcher le paiement de plus de 15 semaines de prestations de maternité pour cette naissance (c.-à-d. il s’agit de l’établissement d’une demande subséquente pour toucher le reste des prestations de maternité pour cette naissance) :

- Si oui, passer à l’étape 3.

- Si non, passer à l’étape 4.

- Déterminer si la date de fin de la fenêtre de maternité est la dernière semaine à laquelle des prestations de maternité doivent être versées à la cliente pour cette naissance (c.-à-d. la cliente peut toucher le reste des prestations de maternité auxquelles elle a droit pour cette naissance durant la fenêtre de maternité indiquée) :

- Si oui, accepter ce message et passer à l’étape 14.

- Si non, consulter Modifier les renseignements sur les prestations de maternité sur l’annexe pour les prestations spéciales dans la version Web de SSA .
             [Modifier les renseignements sur les prestations de maternité sur l’annexe pour les prestations spéciales dans la version Web de SSA](/fr/procedure/task/modifying_mat_sb_ssa.shtml)

- Déterminer si la cliente a indiqué la date prévue et la date réelle de l’accouchement :

- Si non, passer à l’étape 5.

- Si oui, passer à l’étape 9.

- Tenter une fois de communiquer avec la cliente pour un recueil de faits.

- Déterminer si le client a été joint pendant le recueil des faits :

- Si le client a été joint, passer à l’étape 8.

- Si le client n’a pas été joint, passer à l’étape 14.

- Dans SNCT, ajouter des renseignements à l’ébauche du RSDP créé pendant le recueil de faits ou créer un nouveau RSDP de la façon suivante :

- Principal problème : Choisir Calcul .

- Commentaires : Saisir « Renseignement sur la maternité ».

- Détails : Documenter les renseignements sur le recueil de faits selon la Politique nationale sur le recueil de faits et la documentation .
             [Politique nationale sur le recueil de faits et la documentation](https://esdc.prv/fr/service-canada/ae/documents-reference/index.shtml)

- Choisir Sauvegarder .

- Consulter Modifier les renseignements sur les prestations de maternité sur l’annexe pour les prestations spéciales dans la version Web de SSA .
         [Modifier les renseignements sur les prestations de maternité sur l’annexe pour les prestations spéciales dans la version Web de SSA](/fr/procedure/task/modifying_mat_sb_ssa.shtml)

- Déterminer si la cliente a présenté sa demande de prestations à temps :

- Si non, passer à l’étape 10.

- Si oui, passer à l’étape 14.

- Déterminer si la cliente a demandé une antidate ou s’il existe une antidate sous-entendue :

- Si oui, passer à l’étape 11.

- Si non, passer à l’étape 14.

- Déterminer si une décision sur l’antidate a été rendue :

- Si oui, passer à l’étape 12.

- Si non, consulter Examiner une question en suspens sans AT Litige(s) - Décision .
             [Examiner une question en suspens sans AT Litige(s) - Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Déterminer si l’antidate a été accordée :

- Si oui, passer à l’étape 13.

- Si non, passer à l’étape 14.

- Déterminer si le DPP à l’écran Résultat de calcul correspond à la date antérieure :

- Si oui, passer à l’étape 14.

- Si non, consulter Saisir une antidate dans la version Web de SSA .
             [Saisir une antidate dans la version Web de SSA](/fr/procedure/task/calc_calculating/input_antedate.shtml)

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Meilleures semaines - Données réelles requises (1141)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Selon le calcul, il y a suffisamment d’heures pour établir une demande, y compris les demandes de prestations spéciales assorties d’une inadmissibilité aux prestations régulières.

- Le taux de prestations déterminé à l’exclusion de tout supplément familial est inférieur au taux de prestations maximum.

- Le champ Meilleures semaines à l’écran Formulaire de la demande dans la version Web de SSA indique Oui .

- Les renseignements sur les meilleures semaines variables (MSV) ne se trouvent pas dans le Fichier historique d’emploi.

- L’une des conditions suivantes est remplie :

- La période de paie du RE ne suit pas les semaines civiles (commençant le dimanche) et la période d’emploi est supérieure au dénominateur.

- La période de paie du RE suit les semaines civiles, la case 15C n’ est pas remplie et la période d’emploi est supérieure au dénominateur.

- La période de paie du RE suit les semaines civiles, la case 15C est rempli, mais ne couvre pas toute la période d’emploi (jusqu’à un maximum de 53 semaines).

Le taux de prestations est calculé en fonction des semaines durant lesquelles la rémunération était la plus élevée au cours de la PR . Le nombre de semaines est calculé à l’aide du dénominateur régional en vigueur dans la région économique du lieu de résidence habituel du client à la date où la PP commence. Le nombre de semaines utilisées varie de 14 à 22 semaines.
       [PR](/fr/procedure/generic/knowledge.shtml#Periode_de_reference) 
       [dénominateur régional](/fr/procedure/generic/knowledge.shtml#deno)

Vous devez vous assurer que les renseignements des MSV dans le Fichier historique d’emploi du RE lié sont les renseignements les plus récents reçus de la part du client. Ce message continue d’être affiché même après que les renseignements ont été saisis dans le Fichier historique d’emploi.

Le RE est la source la plus fiable d’information quant aux MSV. Les autres sources d’information sont l’historique des paiements d’une demande précédente et les renseignements fournis par le client. Voici l’ordre d’importance des 3 sources d’information :

- le RE

- l’historique des paiements d’une demande précédente

- les renseignements sur les MSV fournis par le client

Le client fournit des renseignements sur les MSV dans le questionnaire électronique relatif aux MSV. Le client peut soumettre un questionnaire papier ou par téléphone. Les renseignements fournis par téléphone ou support papier sont copiés dans un questionnaire dans SNCT. Les renseignements sur les MSV fournis par le client sont acceptés si les conditions suivantes sont remplies :

- Les renseignements semblent raisonnables.

- Les renseignements ne sont pas contredits par un RE et n’indiquent pas « NUL » sur l’ État récapitulatif des paiements (ERP).

- La meilleure semaine variable tombe pendant la période d’emploi visée par le RE.

Si le client fournit une preuve concluante au moyen de talons de chèque selon laquelle une semaine est une meilleure semaine et que le RE montre des renseignements contradictoires pour cette semaine (p. ex. le RE montre des gains de 0,00 $ pendant cette semaine), vous devez effectuer un recueil de faits auprès de l’employeur pour corriger le RE.

Si le client fournit une preuve concluante au moyen de talons de chèque selon laquelle une semaine est une meilleure semaine variable et que des gains de 0,00 $ ont été déclarés dans le cadre d’une demande précédente, saisir cette semaine comme étant une meilleure semaine variable si le RE se trouve au dossier. Si le RE ne se trouve pas au dossier, renvoi à Intégrité pour vérifier s’il existe des rémunérations non déclarées. (Si un RE se trouve au dossier, les rémunérations non déclarées seront repérées dans le cadre d’une vérification postérieure.)
       [renvoi à Intégrité](/fr/procedure/activity/referal_integrity.shtml)

**Ce qu’il faut faire**

- Dans SNCT, choisir Systèmes - Afficher questionnaire .

- S’il n’ y a aucun questionnaire des meilleures semaines, passer à l’étape 2.

- S’il y a un questionnaire des meilleures semaines, choisir le questionnaire rempli le plus récent joint à la demande électronique et passer à l’étape 4.

- Déterminer si les renseignements des MSV sont détaillés dans un RSDP ou un AT Action à prendre (AP) (appelé « questionnaire » dans les étapes suivantes) :

- Si non, passer à l’étape 3.

- Si oui, passer à l’étape 4.

- Choisir la section MSV Détails de la Demande électronique (appelée « questionnaire » dans les étapes suivantes) et déterminer si le client a fourni les renseignements sur les MSV.

- Si oui, passer à l’étape 4.

- Si non, passer à l’étape 16.

- Examiner le questionnaire pour déterminer chacun des renseignements suivants :

- le nombre d’employeurs mentionnés pour chaque montant de meilleure semaine variable saisit

- les semaines civiles mentionnées.

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0867.dita)

- Dans MSRE, déterminer s’il existe un RE de l’employeur pour chaque semaine civile mentionnée :

- Si oui, passer à l’étape 6.

- Si non, passer à l’étape 13.

- Déterminer si la case FHE s’affiche à côté du RE :

- Si oui, choisir la case pour ouvrir le Fichier historique d’emploi et passer à l’étape 7.

- Si non, consulter Corriger un RE avant de procéder.
             [Corriger un RE](/fr/procedure/activity/correct_roe.shtml)

- Dans le Fichier historique d’emploi , pour la semaine saisie, déterminer si 0,00 $ est affiché :

- Si non, passer à l’étape 8.

- Si oui, passer à l’étape 11.

- Déterminer si le montant inscrit dans le questionnaire est égal au montant de la s/c correspondante :

- Si non, passer à l’étape 9.

- Si oui, passer à l’étape 11.

- Dans le champ Code de semaine - Rémunérations de la semaine civile correspondante, saisir le montant indiqué dans le questionnaire.

- S’il y n’a pas de point d’exclamation, passer à l’étape 11.

- S’il y a un point d’exclamation, suivre les directives suivantes :

- Raison pour obtenir les données réelles : Choisir Meilleures semaines .

- Choisir Valider .

- Si le point d’exclamation reste visible, passer à l’étape 10.

- Si le point d’exclamation n’est plus visible, passer à l’étape 11.

- Corriger le message d’erreur du Fichier historique d’emploi en utilisant le tableau suivant :

```text
| Message d’erreur | Mesure requise |

| La période de paie du RE est NUL dans 15C. Des données réelles ne peuvent être entrées . | - Supprimer l’entrée des MSV. |

| Les rémunérations pour la période de paie (x) ne peuvent pas être 0,00 car aucun détail n’a été fourni dans la case 15C du RE . | - Vérifier que le montant 0,00 $ n’ a pas été saisi par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |

| Le total des rémunérations des données réels saisi (xx) ne correspond pas au Total des rémunérations déclaré sur le RE 15B (xx) . | Vérifier s’il est possible de corriger l’erreur en supprimant l’entrée de la meilleure semaine variable la moins élevée : - Si l’erreur est corrigée, supprimer tous les montants saisis pour la période de paie et saisir toutes les MSV, à l’exception de l’entrée du montant le moins élevé. - Si l’erreur n’ est pas corrigée, supprimer tous les montants saisis et saisir les MSV pour toutes les périodes de paie, à l’exception de la période de paie causant l’erreur. |

| Le total des heures inscrit (xx) est supérieur au total des heures déclaré (xx) sur le RE . | - Vérifier si un montant erroné a été saisi dans le champ Heures . - Supprimer tous les montants saisis et saisir les bons montants. |

| Les Heures ne peuvent pas excéder 24 heures par jour. La valeur doit être entre 0,00 et (xx) . | - Vérifier qu’ aucun montant n’ a été saisi dans le champ Heures par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |

| Les rémunérations doivent être entre 0,00 et 99999999,99 . | - Saisir le montant en utilisant le bon format. |

| Les Rémunérations pour la première période de paie ne peuvent pas être 0 car ils contiennent le premier jour de travail. Les Heures pour la première période de paie ne peuvent pas être 0 car ils contiennent le premier jour de travail . | - Vérifier que le montant 0,00 $ n’ a pas été saisi par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |

| Les rémunérations pour la période de paie (x) (xx) ne correspondent pas aux rémunérations déclarés dans le 15C sur le RE (xx). Ils doivent être égaux . | Vérifier s’il est possible de corriger l’erreur en supprimant l’entrée de la meilleure semaine variable la moins élevée : - Si l’erreur est corrigée, supprimer tous les montants saisis pour la période de paie et saisir toutes les MSV, à l’exception de l’entrée du montant le moins élevé. - Si l’erreur n’ est pas corrigée, supprimer tous les montants saisis et saisir les MSV pour toutes les périodes de paie, à l’exception de la période de paie causant l’erreur. |

| Les Rémunérations pour la période de paie finale ne peuvent pas être 0 car ils contiennent le dernier jour payé. Les Heures pour la période de paie finale ne peuvent pas être 0 car ils contiennent le dernier jour payé . | - Vérifier que le montant 0,00 $ n’ a pas été saisi par erreur. - Supprimer tous les montants saisis et saisir les bons montants. |
```

- Si l’entrée est encore marquée d’un point d’exclamation, répéter l’étape 10.

- Si l’entrée n’est plus marquée d’un point d’exclamation, passer à l’étape 11.

- Déterminer s’il y a d’autres semaines à saisir pour ce RE :

- Si oui, retourner à l’étape 7 pour saisir la prochaine meilleure semaine variable.

- Si non, passer à l’étape 12.

- Déterminer si des entrées ont été consignées dans le Fichier historique d’emploi du RE :

- Si non, sortir du Fichier historique d’emploi et passer à l’étape 15.

- Si oui, suivre les directives suivantes :

- Si le champ Raison pour obtenir les données réelles est vide, choisir Meilleures semaines .

- Si le champ Valider est en gris, choisir Sauvegarder .

- Si le champ Valider n’est pas en gris, choisir Valider et Sauvegarder .

- Déterminer s’il existe des MSV d’un autre employeur à saisir :

- Si oui, retourner à l’étape 5 pour le prochain employeur.

- Si non, passer à l’étape 14.

- Déterminer si des entrées ont été saisies dans le Fichier historique d’emploi de tout RE :

- Si oui, passer à l’étape 15.

- Si non, passer à l’étape 16.
             [l’étape](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**MN05 demande active - Données réelles peuvent être requises (1129)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand une demande pour laquelle une demande a précédemment été établie est toujours active comme l’indique l’onglet Sommaire dans ETI. Le système ne peut pas remplir le Fichier historique d’emploi du RE avec les données réelles à moins que la demande précédente n’ait été déplacée vers l’onglet Terminé dans ETI. Même quand des montants ont été saisis dans le Fichier historique d’emploi , ce message s’affichera si la demande précédente est toujours dans l’onglet Sommaire .

La raison pour laquelle la demande précédente n’a pas été déplacée vers l’onglet Terminé pourrait être l’une des suivantes :

- la demande précédente est une demande de base (MA03)

- la demande précédente est PPNE2 (MA22)

- un traitement manuel pour arrêter les paiements (MA01, 02) est imposé

- des déclarations sont mises en attente

- dans le cadre d’une demande active, des déclarations sont en suspens pour les dernières semaines de la demande (renouvellement possible après la demande initiale)

Il ne s’agit pas d’une liste exhaustive. Il faut examiner la demande précédente afin de déterminer la raison pour laquelle la demande précédente n’a pas été déplacée vers l’onglet Terminé .

**Ce qu’il faut faire**

- Dans ETI, examiner la demande précédente afin de déterminer la raison pour laquelle elle n’a pas été déplacée vers l’onglet Terminé et prendre les mesures appropriées pour régler le problème.

- Une fois que le problème concernant la demande précédente a été réglé ou s’il n’y a aucun problème, dans ETI, choisir la transaction Inscription initiale (M149) pour déplacer la demande vers l’onglet Terminé de la façon suivante :

- Terminer demande antérieure : Cocher la case.

- Choisir Mise à jour .

- Dans SNCT, déplacer l’AT lié au calcul vers En suspens de la façon suivante :

- Motif de la mise en suspens : Choisir Autre .

- Commentaires : Saisir « En attente que la demande soit terminée. »

- Date à revoir : Saisir la date d’aujourd’hui plus un jour ouvrable.

- Quand l’AT est déplacé vers la charge de travail actuelle, passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

**MSV < Dénominateur - crédit de rémunération assurable (1159)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand le DPP est entre le 26 septembre 2021 (s/c 2310) et le 14 novembre 2021 (s/c 2317) et que le client a moins de semaines assurables que le dénominateur.

CAC applique la formule suivante pour assurer que le taux de prestations n’est pas touché par le fait d’avoir moins de semaines d’emploi assurables que le dénominateur.

(Dénominateur − nombre de MSV) × Rémunération hebdomadaire moyenne assurable

Cette mesure ne s’applique pas aux demandes de pêcheur ou de TI.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0879.dita) 

**Ce qu’il faut faire**

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Ne se qualifie pas sur la date antérieure (1133)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand le client n’est pas admissible à une date antérieure et les conditions suivantes sont remplies :

- La demande n’est pas PPNE 2 (dernier relevé d’emploi manquant).

- Le champ Antidater au à l’écran Formulaire de la demande de la version Web de SSA a été rempli.

- Le client n’est pas admissible à la date antérieure demandée.

Afin d’accorder une antidate, le client doit être admissible à la date de l’antidate demandée. Quand le client n’est pas admissible pour l’antidate, l’agent détermine si le client est admissible à une date se trouvant entre la semaine demandée de l’antidate et la semaine de présentation de la demande. Une fois que l’agent détermine si le client est admissible à une date ultérieure, l’agent crée un RSDP pour que l’agent rende une décision sur l’antidate et s’assure qu’une décision soit rendue pour la question sur l’antidate.

**Ce qu’il faut faire**

- Vérifier si le client remplit les conditions requises pour recevoir des prestations dans une semaine qui a lieu entre la date affichée dans le champ Antidater au et la semaine de présentation de la demande :

- Si oui, déterminer la première semaine dans laquelle le client remplit les conditions requises et passer à l’étape 2.

- Si non, passer à l’étape 5.

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0880.dita)

- Déterminer si la première semaine dans laquelle le client remplit les conditions requises correspond à la semaine de la présentation de la demande :

- Si la première semaine dans laquelle le client remplit les conditions requises ne correspond pas à la semaine de la présentation de la demande, passer à l’étape 3.

- Si la première semaine dans laquelle le client remplit les conditions requises correspond à la semaine de la présentation de la demande, passer à l’étape 5.

- Dans SNCT, créer un RDSP de la façon suivante :

- Principal problème : Choisir Antidate .

- Commentaires : Saisir « date d’entrée en vigueur de l’antidate. »

- Détails : Saisir « Le client ne remplit pas les conditions requises pour la semaine demandée de l’antidate, mais remplit les conditions requises pour la semaine du [dimanche de la première semaine suivant l’antidate dans laquelle le client remplit les conditions requises]. »

- Dans la version Web de SSA, à l’écran Formulaire de la demande , remplir le champ suivant :

- Antidater au : Saisir le dimanche de la première semaine dans laquelle le client remplit les conditions requises. Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
             [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Dans SNCT, créer un RDSP de la façon suivante :

- Principal problème : Choisir Antidate .

- Commentaires : Saisir « date d’entrée en vigueur de l’antidate. »

- Détails : Saisir « Le client remplit les conditions requises pour aucune semaine à partir de [semaine de l’antidate demandée] à [semaine de présentation de la demande]. »

- Supprimer la date figurant dans le champ Antidater au à l’écran Formulaire de la demande dans la version Web de SSA.

- Déterminer si un AT est en suspens pour la demande d’antidate :

- S’il n’ y a pas d’AT en suspens pour la demande, un AT doit être créé pour la question. Passer à Examiner une question en suspens sans AT Litige(s) — Décision .
             [Examiner une question en suspens sans AT Litige(s) — Décision](/fr/procedure/task/modifying_mat_sb_ssa.shtml)

- S’il a un AT en suspens pour la demande, passer à Examiner des AT en suspens liés au calcul d’une demande .
             [Examiner des AT en suspens liés au calcul d’une demande](/fr/procedure/task/calc_determining/outstandingrelated_wi.shtml)

**Paiements spéciaux invalides - Indemnités d’assurance salaire (AE assurable) (2673)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand la case 19 : Paiements spéciaux de tout RE dans la PR contient une entrée dans la case Indemnités d’assurance salaire (AE assurable) . Même si la case du RE n’est pas surlignée en rouge, une entrée provenant de cette section empêche le calcul.

Pour calculer la demande, l’agent doit enlever toute somme inscrite dans la case Indemnités d’assurance salaire (AE assurable) . Si, lors de la vérification du DPP aux étapes ultérieures, l’agent détermine qu’un paiement d’indemnités d’assurance salaire (IAS) s’applique à partir du DPP, l’agent ajoute une note dans la feuille de calcul. La note indique que lors de l’examen et saisi du calcul, une transaction Répartition (M175) de genre F- Indemnités assurance salaire (M175-F) doit être saisie.

Une fois que la transaction M103 - Décision initiale (M103) est générée par la version Web de SSA, si un montant égal au paiement d’IAS s’affiche dans le champ Rémunération semaine 1 , l’agent le supprime.

**Ce qu’il faut faire**

- Déterminer si vous avez examiné les renseignements sur les IAS pour établir le DPP :

- Si vous avez examiné les renseignements, passer à l’étape 2.

- Si vous n’ avez pas examiné les renseignements, consulter Examiner si des prestations ont été payées ou sont payables d’une autre source .
             [Examiner si des prestations ont été payées ou sont payables d’une autre source](/fr/procedure/task/calc_determining/rev_psl_wli.shtml)

- Dans MSRE, mettre à jour le RE en saisissant les données suivantes dans la section Renseignements supplémentaires :

- Renseignements supplémentaires : Saisir les renseignements qui se trouvent dans la section Indemnités d’assurance salaire (AE assurable) .

- Indemnités d’assurance salaire (AE assurable) : Supprimer les entrées.

- Choisir Valider et Soumettre . S’il y a des erreurs de validation, consulter Corriger un RE avant de procéder.
             [Corriger un RE](/fr/procedure/activity/correct_roe.shtml)

- Dans la feuille de calcul, noter que lors de l’examen du DPP, la Politique administrative peut être requise pour obtenir le DPP exact.

- Déterminer si, lors de l’examen du DPP, des IAS s’appliquent à partir du DPP :

- Si oui, sur la feuille de calcul, noter qu’une transaction Répartition (M175) de genre F - Indemnités assurance salaire (M175-F) doit être saisie lors du calcul. Passer à l’étape 5.

- Si non, passer à l’étape 6.

- Examiner la transaction M103 - Décision initiale (M103) générée par la version Web de SSA et déterminer si un montant égal au paiement d’IAS s’affiche dans le champ Rémunération semaine 1 :

- Si oui, supprimer ce montant. Passer à l’étape 6.

- Si non, passer à l’étape 6.

- Passer à l’étape 9 de Calculer une demande dans  la version Web de SSA .
         [Calculer une demande dans  la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

**Possibilité de semaines restantes payables (1131)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le GD est prestations de pêcheur.

- Une demande précédente est toujours active.

- Le DPP de la nouvelle demande de prestations de pêcheur est postérieur à la dernière semaine traitée de la demande précédente plus une semaine.

Même si le taux de prestations de la nouvelle demande de prestations de pêcheur est supérieur au taux de prestations régulières de la demande précédente, on ne peut mettre fin à la demande de prestations régulières pour activer la demande de prestations de pêcheur si les conditions suivantes sont remplies :

- Il n’y a aucune exclusion pour une période indéterminée dans la demande de prestations régulières.

- La demande de prestations régulières est renouvelable.

Cependant, s’il existe une exclusion pour une période indéterminée dans la demande de prestations régulières, on peut y mettre fin pour activer la nouvelle demande de prestations de pêcheur.

**Ce qu’il faut faire**

- Déterminer s’il s’agit d’une demande de prestations régulières active :

- S’il s’agit d’une demande de prestations régulières, passer à l’étape 2.

- S’il s’agit d’une demande de prestations de pêcheur, passer à l’étape 5.

- Déterminer s’il y a une exclusion pour une période indéterminée dans la demande active :

- S’il n’y a pas d’exclusion pour une période indéterminée dans la demande de prestations, passer à l’étape 3.

- S’il y a une exclusion pour une période indéterminée dans la demande de prestations, passer à l’étape 6.

- Déterminer s’il y a des semaines payables dans la demande de prestations:

- S’il y a des semaines payables dans la demande de prestations, passer à l’étape 4.

- S’il n’y a pas de semaine payable dans la demande de prestations, passer à l’étape 6.

- Consulter Renouvellement pour renouveler la demande active.
         [Renouvellement](/fr/procedure/activity/conversions.shtml)

- Déterminer s’il est avantageux pour le client de terminer l’ancienne demande pour activer la nouvelle : (consulter Terminer une période de prestations .)

- Si ce n’ est pas avantageux pour le client, accepter ce message et passer à l’étape 6.

- Si c’est avantageux pour le client, consulter Terminer une période de prestations .
             [Terminer une période de prestations](/fr/procedure/task/benefit_period_term.shtml)

         [Terminer une période de prestations](/fr/procedure/task/benefit_period_term.shtml)

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#_Procédure_suivante)

**Postdate avec rémunération dans la semaine 1 - transmettre un M175 genre A si nécessaire (1062)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand ces toutes les conditions suivantes sont remplies :

- La demande est établie.

- Le nouveau calcul de la demande initiale est postdaté.

- Il y a une rémunération dans la première semaine de la demande.

Dans ce cas, si la rémunération dans la première semaine de la demande est inférieure à la rémunération dans la première semaine du résultat du nouveau calcul, modifier la rémunération à l’aide d’une transaction Décision subséquente - Répartitions (M175) de genre A (M175-A). Toutefois, si la rémunération dans la première semaine de la demande est supérieure à la rémunération dans la première semaine du résultat du nouveau calcul, aucune mesure n’est requise.

**Ce qu’il faut faire**

- Dans ETI, déterminer si la rémunération dans la première semaine de la demande est inférieure à la rémunération dans la première semaine du résultat du nouveau calcul :

- Si oui, passer à l’étape 2.

- Si non, passer à l’étape 3.

- Dans la feuille de calcul, noter que, lors du nouveau calcul de la demande, la rémunération dans la première semaine doit être modifiée au montant de la rémunération indiquée dans le résultat du nouveau calcul à l’aide d’une transaction Décision subséquente - Répartitions (M175) de genre A (M175-A).

- Accepter le message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Postdate du DPP peut être plus avantageux - une entrée pourrait être requise dans le champ DPP subséquent ou manuel de l’écran Impératif de codage (1054)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le GP est prestations spéciales.

- Une postdate pourrait être avantageuse pour le client pour l’une des raisons suivantes :

- Les heures assurables du client au cours de la semaine de l’A de R sont requises pour être admissibles.

- Le client a reçu une rémunération durant la semaine du DPP et demande que la PP commence à une date ultérieure pour recevoir le maximum de prestations.

- Le client a eu une semaine entière de travail dans la semaine de l’A de R. Cela peut se produire quand le client n’a pas été payé pour cette semaine (p. ex. jours de relâche, faillite).

- Le client est admissible au nombre maximal de semaines permis pour le genre de prestations spéciales demandées, mais la rémunération dans la semaine du DPP empêchera le client de recevoir la totalité des prestations auxquelles il est admissible au taux hebdomadaire complet. Si une date de RAT est indiquée sur le RE, il faut en tenir compte pour déterminer si une demande de prestations spéciales peut être postdatée.

Postdater la demande pourrait être plus avantageux pour le client. Lors de la révision du DPP, l’agent doit se souvenir qu’une postdate pourrait être nécessaire. Puis, l’agent accepte ce message et continue le calcul de la demande.

**Ce qu’il faut faire**

- Lors de la révision du DPP, se souvenir qu’une postdate devrait être considérée si les conditions sont remplies.

- Accepter le message

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#_Procédure_suivante)

**Prestation de compassion non approuvée (1110)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Selon le calcul, il y a suffisamment d’heures pour faire établir la demande (y compris les demandes de prestations spéciales) assortie d’une inadmissibilité aux prestations régulières.

- Le GD est PDC

- La semaine de début de la fenêtre de compassion (FC) n’est pas indiquée à l’annexe prestations spéciales dans la version Web de SSA.

Quand une demande est calculée pour des PDC et qu’un certificat médical acceptable prouve les PDC, une semaine de début doit être saisie dans le champ Semaine de début de la fenêtre compassion à l’écran Annexe - Prestations spéciales .

Ce message, s’il y a lieu, apparait même si l’écran Enregistrement affiche que la preuve de compassion est en suspens. Quand une preuve de compassion est en suspens, l’agent ne doit pas saisir la date dans le champ Semaine de début de la fenêtre compassion à l’écran Annexe - Prestations spéciales , puisqu’une inadmissibilité D51 serait imposée incorrectement.

Un RD doit être au dossier quand le client est déclaré inadmissible aux prestations spéciales sauf s’il est inadmissible parce qu’il est de deuxième catégorie. Quand un RD est requis, mais qu’il n’est pas au dossier, l’agent retourne à la tâche précédente afin de déterminer si l’inadmissibilité est exacte.

**Ce qu’il faut faire**

- Déterminer si un RD indique que la preuve de compassion est en suspens :

- Si oui, accepter le message et passer à l’étape 2.

- Si non, retourner à Déterminer si un certificat médical est acceptable : PDC — Demandes initiales .
             [Déterminer si un certificat médical est acceptable : PDC — Demandes initiales](/fr/procedure/task/calc_determining/medical_cert_ccb.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Prestataire non admissible au DPP subséquent/manuel. La demande a été postdatée (1155)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le DPP est codé dans le champ DPP subséquent ou manuel .

- Le client ne remplit pas les conditions requises à partir du DPP codé dans le champ DPP subséquent ou manuel .

- Le client remplit les conditions requises si le DPP est postdaté.

- Le CAC présente un résultat de calcul avec un DPP postdaté.

Si un DPP subséquent ou manuel entraîne une demande PPNE, le DPP est établi au cours de la semaine suivant l’arrêt de rémunération (A de R) dans les situations suivantes :

- le client a besoin des heures assurables afin d’être admissible aux prestations;

- le client a besoin des heures assurables afin d’être admissible aux prestations spéciales;

- la semaine de l’A de R est une semaine entière de travail;

- la rémunération pendant la semaine de l’A de R est égale ou supérieure au taux de prestations; ou

- le client est admissible au maximum des prestations spéciales.

**Ce qu’il faut faire**

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Prestations parentales - prestataire de deuxième catégorie (1102)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand ces 2 conditions sont remplies

- Le client est de deuxième catégorie .
         [deuxième catégorie](/fr/procedure/generic/knowledge.shtml)

- Le GD est prestations parentales.

Pour être admissible aux prestations parentales, le client doit avoir accumulé au moins 600 heures au cours de la PR.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0868.dita) 

**Ce qu’il faut faire**

- Accepter le message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#_Procédure_suivante)

**Prestations proche aidant… de deuxième catégorie (1144)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand les 2 conditions suivantes sont remplies :

- Le client est de deuxième catégorie .
         [deuxième catégorie](/fr/procedure/generic/knowledge.shtml)

- Le GD est prestations pour proches aidants.

Pour être admissible aux prestations pour proches aidants, le client doit avoir accumulé au moins 600 heures au cours de la PR.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0868.dita) 

**Ce qu’il faut faire**

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Prestations proches aidants - Preuve médicale requise. SVP réviser (1142)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Selon le calcul, une demande peut être établie.

- Le GD est prestations pour proches aidants.

- Le champ Preuve médicale dans la section Proches aidants à l’écran Annexe – Prestations spéciales indique Non .

Quand une preuve médicale n’est pas fournie, le champ Preuve médicale dans la section Proches aidants à l’écran Annexe - Prestations spéciales indique Non . En plus du message Prestations pour proches aidants demandées - preuve médicale requise , l’écran Résultat de calcul dans la version Web de SSA indique aussi qu’une inadmissibilité indéterminée 63 - Proches aidants d’enfants ou d’adultes - aucune preuve médicale (D63) est imposée à partir du DPP.

Un RD doit être au dossier quand le client est déclaré inadmissible aux prestations spéciales sauf s’il est inadmissible parce qu’il est de deuxième catégorie. Quand un RD est requis, mais qu’il n’est pas au dossier, l’agent doit retourner à la tâche précédente afin de déterminer si l’inadmissibilité est exacte.

**Ce qu’il faut faire**

- Déterminer si un RD indique que la preuve médicale est en suspens :

- Si non, une inadmissibilité pourrait être imposée par erreur. Passer à l’étape 2.

- Si oui, accepter le message et passer à Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

- Dans la version Web de SSA, dans la section Information manquante de l’écran Enregistrement , suivre les directives suivantes :

- Certificat médical - Date d’échéance : Supprimer la date d’échéance de l’AT lié au calcul.

- Choisir Sauvegarder .

- Consulter Déterminer si un certificat médical est acceptable — Prestations pour proches aidants .
         [Déterminer si un certificat médical est acceptable — Prestations pour proches aidants](/fr/procedure/task/determining_pcic_med_cert.shtml)

**Preuve de compassion requise …S.V.P. réviser (1106)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand la preuve de compassion est indiquée manquante dans la section Information manquante de l’écran Enregistrement .

Quand le client qui demande des PDC ne fournit pas une preuve de compassion, l’agent doit noter qu’il s’agit d’une information manquante. En plus du message Prestations de compassion demandées - preuve médicale requise , l’écran Résultat de calcul de la version Web de SSA affiche dans le champ Exclusions / Inadmissibilités qu’une inadmissibilité indéterminée 53 - Prestations de soins de compassion - aucune preuve médicale (D53) est imposée à partir du DPP.

Un RD doit être au dossier quand le client est déclaré inadmissible aux prestations spéciales sauf s’il est inadmissible parce qu’il est de deuxième catégorie. Quand un RD est requis, mais qu’il n’est pas au dossier, l’agent retourne à la tâche précédente afin de déterminer si l’inadmissibilité est exacte.

**Ce qu’il faut faire**

- Déterminer si un RD contient une preuve de compassion en suspens :

- Si non, une inadmissibilité peut être imposée par erreur. Passer à l’étape 2.

- Si oui, accepter le message et passer à Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#_Procédure_suivante)

- Dans la version Web de SSA, dans la section Information manquante de l’écran Enregistrement , suivre les directives suivantes :

- Soins de compassion - Date d’échéance : Supprimer la date d’échéance de l’AT lié au calcul.

- Choisir Sauvegarder .

- Consulter Déterminer si un certificat médical est acceptable : PDC — Demandes initiales .
         [Déterminer si un certificat médical est acceptable : PDC — Demandes initiales](/fr/procedure/task/calc_determining/medical_cert_ccb.shtml)

**Preuve de maternité requise…SVP réviser (1100)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand une preuve de maternité manquante a été notée à la section Information manquante de l’écran Enregistrement .

Si une preuve de grossesse est requise , l’agent doit le noter à titre d’information manquante. En plus du message 1100 - Preuve de maternité requise ...S.V.P. réviser , l’écran Résultat de calcul de la version Web de SSA affiche également à la section Exclusions / Inadmissibilités qu’une inadmissibilité indéterminée 15 - Procédure de présentation des demandes (D15) est imposée à partir du DPP.
       [preuve de grossesse est requise](/fr/procedure/generic/knowledge.shtml#Proof_of_pregnancy)

Un RD doit être au dossier quand le client est déclaré inadmissible aux prestations spéciales sauf s’il est inadmissible parce qu’il est de deuxième catégorie. Quand un RD est requis, mais qu’il n’est pas au dossier, l’agent retourne à la tâche précédente afin de déterminer si l’inadmissibilité est exacte.

**Ce qu’il faut faire**

- Déterminer si un RD contient une preuve de maternité est manquante :

- Si non, une inadmissibilité pourrait être imposée par erreur. Passer à l’étape 2.

- Si oui, accepter le message et passer à Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

- Dans la version Web de SSA, dans la section Information manquante de l’écran Enregistrement , suivre les directives suivantes :

- Maternité - Date d’échéance : Supprimer la date d’échéance de l’AT lié au calcul.

- Choisir Sauvegarder .

- Consulter Déterminer si une preuve d’admissibilité aux prestations de maternité est requise .
         [Déterminer si une preuve d’admissibilité aux prestations de maternité est requise](/fr/procedure/task/determining_pembr.shtml)

**Preuve de naissance ou d’adoption/de placement requise …SVP réviser (1101)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand la preuve parentale ou d’adoption est indiquée manquante dans la section Information manquante de l’écran Enregistrement .

Quand le client qui demande des prestations parentales ne fournit pas une preuve de l’accouchement, de l’adoption ou du placement, l’agent doit noter qu’il s’agit d’une information manquante. En plus du message 1101 - Preuve de naissance ou d’adoption/placement requise ...SVP réviser , l’écran Résultat de calcul de la version Web de SSA affiche à la section Exclusions / Inadmissibilités qu’une inadmissibilité indéterminée 34 - Prestations parentales conditions d’admissibilité non rencontrées (D34) est imposée à partir du DPP.

Un RD doit être au dossier quand le client est déclaré inadmissible aux prestations spéciales sauf s’il est inadmissible parce qu’il est de deuxième catégorie. Quand un RD est requis, mais qu’il n’est pas au dossier, l’agent retourne à la tâche précédente afin de déterminer si l’inadmissibilité est exacte.

**Ce qu’il faut faire**

- Déterminer si un RD contient une preuve parentale ou d’adoption est manquante :

- Si non, une inadmissibilité pourrait être imposée par erreur. Passer à l’étape 2.

- Si oui, accepter le message et passer à Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

- Dans la version Web de SSA, dans la section Information manquante de l’écran Enregistrement , suivre les directives suivantes :

- Preuve parentale ou adoption - Date d’échéance : Supprimer la date d’échéance de l’AT lié au calcul.

- Choisir Sauvegarder .

- Consulter Déterminer si une preuve d’admissibilité aux prestations parentales est requise .
         [Déterminer si une preuve d’admissibilité aux prestations parentales est requise](/fr/procedure/task/determining_pepbr.shtml)

**Région économique est incorrecte – SVP réviser (1151)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand l’une des conditions suivantes est remplie :

- Le DPP est supérieur à 1946 et le champ Région économique nouvelle indique l’une des options suivantes :

- 03 - Île-du-Prince-Édouard

- 56 - Yukon

- 57 - Territoires du Nord-Ouest

- 58 - Nunavut

- Le DDP est inférieur à 1947 et le champ Région économique - ancienne indique l’une des options suivantes :

- 59 - Whitehorse

- 60 - Yukon excluant Whitehorse

- 61 - Yellowknife

- 62 - Territoires du Nord-Ouest excluant Yellowknife

- 63 - Iqaluit

- 64 - Nunavut excluant Iqaluit

- 65 - Charlottetown

- 66 - Île-du-Prince-Édouard excluant Charlottetown

**Ce qu’il faut faire**

- Examiner le champ Région économique - nouvelle et déterminer si l’une des options suivantes est affichée :

- 03 - Île-du-Prince-Édouard

- 56 - Yukon

- 57 - Territoires du Nord-Ouest

- 58 - Nunavut

- Si oui, passer à l’étape 2.

- Si non, passer à l’étape 4.

- Dans la base de données Cherchez les régions économiques de l’AE par code postal , saisir le code postal de l’adresse de résidence pour déterminer la région économique.

- Si aucune région économique n’est trouvée, consulter Recherche d’une région économique de l’AE par municipalité ou nom de localité pour déterminer la région économique. Se souvenir du code de la région économique.
             [Recherche d’une région économique de l’AE par municipalité ou nom de localité](http://srv129.services.gc.ca/eiregions/fra/munic_recherche.aspx)

- Si une seule région économique est trouvée, choisir le nom de la région économique affiché et se souvenir du code de la région économique.

- Si plus d’une région économique est trouvée, choisir chaque nom de région économique affiché :

- Si une région économique affiche un taux régional de chômage (TRC) plus élevé qu’une autre, se souvenir du code de la région économique.

- Si les régions économiques affichent le même TRC, se souvenir du code de la première région économique affichée.

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0881.dita) 
         [Cherchez les régions économiques de l’AE par code postal](http://srv129.services.gc.ca/eiregions/fra/codepostal_recherche.aspx)

- Dans la version Web de SSA, à l’écran Nom et adresse , dans le champ Région économique - nouvelle , choisir le code de région économique précédemment noté.

- Examiner le champ Région économique - ancienne et déterminer si l’une des options suivantes est affichée :

- 59 - Whitehorse

- 60 - Yukon excluant Whitehorse

- 61 - Yellowknife

- 62 - Territoires du Nord-Ouest excluant Yellowknife

- 63 - Iqaluit

- 64 - Nunavut excluant Iqaluit

- 65 - Charlottetown

- 66 - Île-du-Prince-Édouard excluant Charlottetown

- Si oui, passer à l’étape 5.

- Si non, passer à l’étape 9.

- Dans la base de données Cherchez les régions économiques de l’AE par code postal , saisir le code postal de l’adresse de résidence pour déterminer la région économique actuelle. Si aucune région économique n’est trouvée, consulter Recherche d’une région économique de l’AE par municipalité ou nom de localité pour déterminer la région économique.
         [Cherchez les régions économiques de l’AE par code postal](http://srv129.services.gc.ca/eiregions/fra/codepostal_recherche.aspx) 
         [Recherche d’une région économique de l’AE par municipalité ou nom de localité](http://srv129.services.gc.ca/eiregions/fra/munic_recherche.aspx)

- Déterminer le nom de la région économique précédente de chaque région économique actuelle trouvée dans la base de données :

```text
| Nom de la région économique actuelle | Nom de la région économique précédente |

| Whitehorse (59) | Yukon (56) |

| Yukon excluant Whitehorse (60) | Yukon (56) |

| Yellowknife (61) | Territoires du Nord-Ouest (57) |

| Territoires du Nord-Ouest excluant Yellowknife (62) | Territoires du Nord-Ouest (57) |

| Iqaluit (63) | Nunavut (58) |

| Nunavut excluant Iqaluit (64) | Nunavut (58) |

| Charlottetown (65) | Île-du-Prince-Édouard (03) |

| Île-du-Prince-Édouard excluant Charlottetown (66) | Île-du-Prince-Édouard (03) |
```

- Si la recherche par code postal affiche plus d’un nom de région économique possible, se souvenir de la région économique précédente possible. Passer à l’étape 7.

- Si la recherche par code postal affiche seulement un nom de région économique, se souvenir de la région économique précédente. Passer à l’étape 8.

- Dans la base de données Taux de chômage des régions économiques de l’AE , saisir la région économique possible pour déterminer le TRC de la semaine du DPP.

- Si une région économique affiche un TRC plus élevé qu’une autre, se souvenir du code de la région économique.

- Si les régions économiques affichent le même TRC, se souvenir du code de la première région économique affichée.

         [Taux de chômage des régions économiques de l’AE](http://srv129.services.gc.ca/eiregions/fra/taux_hist.aspx)

- Dans la version Web de SSA, à l’écran Nom et adresse , dans le champ Région économique - nouvelle , choisir le code de région économique précédemment noté.

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

**Relevé(s) d’emploi exclu(s) (1049)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message seulement quand les 2 conditions suivantes sont remplies :

- Le client est admissible depuis l’événement d’exclusion.

- Le taux de prestations et les semaines d’admissibilité sont inférieurs au maximum.

Un événement d’exclusion se produit quand une client est congédié pour inconduite ou a quitté volontairement son emploi sans motif valable. Si le client a travaillé pendant suffisamment d’heures après un événement d’exclusion pour être admissible à des prestations, une demande peut être établie sans exclusion.

Au moment d’effectuer le calcul dans le cadre d’une demande où le client a travaillé pendant suffisamment d’heures depuis l’événement d’exclusion, les heures et la rémunération indiquées dans le RE associé à l’événement d’exclusion ne sont pas incluses dans le calcul du taux de prestations ou de l’admissibilité si les 2 conditions suivantes sont remplies :

- La case 16 : Motif de cessation (MCE) sur le RE contient un MCE litigieux (E, G, K ou M).

- Le champ Condition spéciale a été laissé en blanc ou est codé de la façon suivante : Mauvaise conduite prouvée ou Départ volontaire - Motif non valable .

Ce RE est exclu du calcul de la demande.

Il pourrait y avoir plus d’un RE exclu. Vous devez examiner chaque RE sur lequel est indiqué un MCE litigieux pour vous assurer que toutes les questions ont fait l’objet d’une évaluation et que les champs Condition spéciale ont été codés de façon appropriée.

**Ce qu’il faut faire**

- Dans MSRE, déterminer quel RE est exclu du calcul.

- Dans SNCT, déterminer s’il y a un RD concernant la décision ou le report du MCE sur le RE exclu :

- S’il y a un RD, passer à l’étape 3.

- S’il n’y a pas de RD, consulter Examiner une question en suspens sans AT Litige(s) — Décision .
             [Examiner une question en suspens sans AT Litige(s) — Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

         [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0882.dita)

- Dans MSRE, déterminer si les champs Motif de cessation d’emploi , Condition spéciale et Date de fin (au besoin) de RE correspondent à la décision du RD :

- Si oui, passer à l’étape 4.

- Si non, corriger le RE, choisir Soumettre et passer à l’étape 4.

- Déterminer s’il y a un autre RE exclu qui doit être examiné :

- Si oui, retourner à l’étape 2.

- Si non, passer à l’étape 5.

- Déterminer si des changements ont été apportés dans MSRE :

- Si oui, passer à l’étape 6.

- Si non, passer à l’étape 7.

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Rémunération assurable augmentée pour le taux de prestations minimal (1160)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand une demande profite de la mesure sur le taux de prestations minimal.

Si un taux de prestations est inférieur au taux de prestations minimal, CAC applique le taux de prestations minimal. Un agent ne peut pas modifier le taux de prestations minimal.

Un taux de prestations minimal s’applique à toutes les demandes dans les périodes suivantes :

- Pour les demandes dont le DPP est entre la s/c 2258 et la s/c 2309, le taux de prestations minimal est de 300 $ pour les prestations parentales prolongées et de 500 $ pour tous les autres GP.

- Pour les demandes dont le DPP est entre la s/c 2310 et la s/c 2317 le taux de prestations minimal est de 180 $ pour les prestations parentales prolongées et de 300 $ pour tous les autres GP.

Un supplément familial (SF) est ajouté au montant du taux de prestations minimal, au besoin.

CAC génère le nouveau message d’avertissement 1160 - Rémunération assurable augmentée pour le taux de prestations minimal dans toutes les demandes touchées par le taux de prestations minimal. Le message d’avertissement s’affiche à l’écran Résultat de calcul .

**Ce qu’il faut faire**

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Rémunération dans la semaine 1 a changée, déclarations ont été traitées. Réviser et déterminer si le changement est requis (1064)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message seulement quand toutes les conditions suivantes sont remplies :

- La demande fait l’objet d’un nouveau calcul.

- Une répartition de la rémunération a été codée dans le champ Rémunération semaine 1 du Résultat de calcul précédent.

- Le nouveau calcul donne un montant de rémunération différent pour cette semaine.

Quand une rémunération est affichée dans le champ Conditions d’admissibilité - Rémunération semaine 1 de l’écran Résultat de calcul et que le résultat est accepté, le montant est affiché dans le champ Rémunération semaine 1 de la transaction générée par la version web de SSA. Une fois que la demande a été établie, la répartition est affichée dans ETI comme un type de répartition W - Rémunération semaine 1 pour la semaine du DPP.

- Si le client déclare un montant inférieur pour la rémunération de cette semaine dans sa déclaration du prestataire, le système utilise le montant codé comme un type de répartition W - Rémunération semaine 1 pour cette semaine.

- Si le client déclare un montant supérieur pour la rémunération de cette semaine dans sa déclaration du prestataire, le système utilise le montant le plus élevé qui a été déclaré dans la déclaration du prestataire comme rémunération pour cette semaine. Le système met aussi à jour le type de répartition W - Rémunération semaine 1 pour cette semaine, afin qu’il corresponde au montant déclaré dans la déclaration du prestataire.

Lors du nouveau calcul d’une demande avec un type de répartition W - Rémunération semaine 1 et le client a soumis une déclaration du prestataire pour cette semaine, l’agent examine la répartition de la rémunération et la déclaration du prestataire pour cette semaine afin de déterminer si la répartition doit être modifiée.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0883.dita) 

**Ce qu’il faut faire**

- Déterminer si la rémunération a été déclarée dans la déclaration du prestataire pour cette semaine :

- Si oui, passer à l’étape 2.

- Si non, passer à l’étape 4.

- Déterminer si la rémunération déclarée dans la déclaration du prestataire pour cette semaine est supérieure au montant de la rémunération indiquée dans le champ Rémunération première semaine du résultat du nouveau calcul :

- Si oui, passer à l’étape 3.

- Si non, passer à l’étape 4.

- Dans la feuille de calcul, noter que si la version Web de SSA génère une répartition de la rémunération pour modifier la rémunération de cette semaine, la répartition ne doit pas être saisie avec le nouveau calcul de la demande. Le montant déclaré par le client dans sa déclaration du prestataire est le bon montant à répartir.

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Rémunérations insuffisantes du RE dans la PR du travail autonome – Données réelles sont requises (1135)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Selon le calcul, la demande peut être établie.

- Le taux de prestations à l’exclusion du supplément familial est inférieur au maximum.

- La rémunération assurable indiquée dans le RE se trouve dans la PR TA.

- La rémunération dans le RE et dans le Fichier historique d’emploi ne représente pas toute la rémunération dans la PR TA.

Si un client présente une demande de prestations et est admissible à des prestations pour travailleurs autonomes (partie VII) , la rémunération assurable indiquée dans les RE produits pour la PR peut faire augmenter le taux de prestations. Toute la rémunération assurable qui se trouve dans la PR du travail autonome (PR du TA) est utilisée pour déterminer le taux de prestations.
       [(partie VII)](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/TexteComplet.html#h-44)

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0884.dita) 

**Ce qu’il faut faire**

- Déterminer si on a tenté d’obtenir auprès du client les renseignements supplémentaires sur la rémunération pour le RE qui se trouve dans la PR TA :

- Si une tentative n’ a pas été effectuée, passer à l’étape 2.

- Si une tentative a été effectuée, passer à l’étape 5.

- Effectuer un recueil de faits auprès du client pour obtenir la rémunération pour les semaines qui ne sont pas indiquées dans le RE.

- Effectuer un recueil de faits auprès du client pour obtenir des renseignements sur la rémunération pour les semaines qui ne figurent pas au RE.

- Déterminer si le client a été joint pendant le recueil des faits :

- Si le client a été joint, passer à l’étape 4.

- Si le client n’ a pas été joint ou s’il n’ a pas répondu à la lettre N-10-00-00, accepter le message et passer à l’étape 8.

- Dans SNCT, ajouter des renseignements à l’ébauche du RSDP créé pendant le recueil de faits ou créer un nouveau RSDP de la façon suivante :

- Principal problème : Choisir Calcul .

- Commentaires : Saisir «Rémunération. »

- Détails : Documenter les renseignements sur le recueil de faits selon la Politique nationale sur le recueil de faits et la documentation .
             [Politique nationale sur le recueil de faits et la documentation](https://esdc.prv/fr/service-canada/ae/documents-reference/index.shtml)

- Choisir Sauvegarder .

- Déterminer si les renseignements supplémentaires sur la rémunération ont été obtenus :

- Si les renseignements ont été obtenus, passer à l’étape 6.

- Si les renseignements n’ont pas été obtenus, accepter le message et passer à l’étape 8.

- Saisir les renseignements supplémentaires sur la rémunération dans le Fichier historique d’emploi du RE.

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Répartition annulée - SVP réviser (1140)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand les 2 conditions suivantes sont remplies :

- Une demande établie fait l’objet d’un nouveau calcul.

- Une répartition (types C, G, P, Q, S et V) est annulée.

Si le calcul est accepté et que ce message s’affiche, la version Web de SSA crée une transaction M107 - Renseignements supplémentaires (M107 ) et remplit le champ Genre d’origine avec X - Annuler pour annuler la répartition.

Il faut examiner la répartition pour s’assurer qu’elle doit effectivement être annulée.

Si la répartition doit être annulée, l’agent accepte ce message et continue le calcul de la demande.

Si la répartition doit rester dans la demande, l’agent doit se souvenir, lors de la révision et de la saisie du calcul, de supprimer la transaction M107 - Renseignements supplémentaires (M107) ou de la modifier pour s’assurer que la répartition reste dans la demande. Puis, l’agent accepte ce message et continue le calcul de la demande.

**Ce qu’il faut faire**

- Déterminer s’il faut annuler ou maintenir la répartition :

- S’il faut maintenir la répartition, passer à l’étape 2.

- S’il faut annuler la répartition, passer à l’étape 3.

- Lors de la vérification et de la saisie du calcul, se souvenir de supprimer ou de modifier la transaction M107 - Renseignements supplémentaires (M107) pour s’assurer que la répartition est appliquée dans la demande.

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Semaine de début des prestations parentales est placée après le DPP …S.V.P. réviser (1090)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- La demande est établie.

- Le GD est prestations parentales.

- La date de début des prestations parentales dépasse (>) le DPP.

Ce message accompagne le message 1099 - Le DPP est à l’extérieur de la fenêtre parentale . Examiner ce message d’abord.

Les prestations parentales ne sont payables que durant la fenêtre parentale.

**Ce qu’il faut faire**

- Accepter ce message et passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Semaine de guérison est inscrite avec une demande de maternité ou parental, SVP réviser (1028)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le GD est prestations de maternité ou parentale.

- Le champ Date présumée ou réelle de guérison est rempli à l’écran Annexe - Prestations spéciales dans la version Web de SSA.

Si le GP saisi dans la version Web de SSA est incorrect, il faut modifier le GP indiqué dans le champ Genre de demande .

Si le GP saisit dans la version Web de SSA est exact et si la date de guérison saisit est incorrecte, il faut enlever la date de guérison pour obtenir un nouveau résultat de calcul.

**Ce qu’il faut faire**

- Dans la version Web de SSA, déterminer si un GP incorrect a été saisit dans le champ Genre de demande à l’écran Impératif de codage :

- Si oui, consulter Modifier le genre de prestations dans la version Web de SSA .
             [Modifier le genre de prestations dans la version Web de SSA](/fr/procedure/task/calc_calculating/changing_tentative_ct.shtml)

- Si non, passer à l’étape 2.

- Dans la version Web de SSA, à l’écran Annexe - Prestations spéciales , remplir le champ suivant :

- Date présumée ou réelle de guérison : Enlever la date de guérison.

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

**Semaine de guérison est inscrite avec une demande régulière, SVP réviser (1027)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- Le GD est prestations régulières.

- Le champ Date présumée ou réelle de guérison est rempli à l’écran Annexe - Prestations spéciales dans la version Web de SSA.

Si le GP saisi dans le champ Genre de demande à l’écran Impératif de codage est incorrect, il faut modifier le GP indiqué.

Si le GP saisi dans le champ Genre de demande est exact, mais qu’une date de guérison incorrecte est saisie, enlever la date de guérison pour obtenir un nouveau résultat de calcul.

**Ce qu’il faut faire**

- Dans la version Web de SSA, déterminer si un GP incorrect a été saisi dans le champ Genre de demande à l’écran Impératif de codage :

- Si non, passer à l’étape 2.

- Si oui, consulter Modifier le genre de prestations dans la version Web de SSA lors du calcul .
             [Modifier le genre de prestations dans la version Web de SSA lors du calcul](/fr/procedure/task/calc_calculating/changing_tentative_ct.shtml)

- Dans la version Web de SSA, à l’écran Annexe - Prestations spéciales , remplir le champ suivant :

- Date présumée ou réelle de guérison : Enlever la date de guérison.

- Passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

**Semaine de guérison requise (1002)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand toutes les conditions suivantes sont remplies :

- La demande est établie ou est PPNE 3 ou 5.

- Le GD est prestations de maladie.

- La semaine de guérison est vide.

Le CAC détermine que la semaine de guérison correspond au DPP + 8 semaines si les conditions suivantes sont remplies :

- Le MCE sur le dernier RE est maladie.

- Il n’y a aucune exclusion pour une période indéterminée imposée en raison d’un congédiement (D10) ou d’un départ volontaire (D11).

- Il n’y a aucune inadmissibilité imposée en raison d’une suspension (D42), d’une période de congé (D43) ou d’une perte prévisible d’emploi (D44).

Si l’une des conditions ci-dessus n’a pas été remplie, le CAC ne peut pas établir la semaine de guérison. Quand la case pour la date de guérison est laissée vide à l’écran Annexe - Prestations spéciales , et qu’il est impossible d’établir la semaine de guérison, la version Web de SSA affiche le message 1002 - Semaine de guérison requise .

Si le client ne fournit pas de certificat médical acceptable ou ne peut en fournir un à la date prévue par le calcul, l’agent :
       [certificat médical acceptable](/fr/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

- saisit le certificat médical manquant à l’écran Enregistrement ;

- calcule la demande.

Si la semaine de guérison a été laissée en blanc intentionnellement et que le certificat médical manquant a été noté à l’écran Enregistrement , le message supplémentaire 1003 - Certificat médical requis …S.V.P. réviser s’affiche. L’agent peut accepter les 2 messages, en notant qu’il faut choisir Oui dans le champ Est indéterminée? dans la transaction M103 ou M106 présentée dans la version Web de SSA.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0885.dita) 

**Ce qu’il faut faire**

- Déterminer si un certificat médical se trouve au dossier :

- Si non, passer à l’étape 2.

- Si oui, passer à l’étape 3.

- Déterminer si le message 1003 - Certificat médical requis …S.V.P. réviser s’affiche :

- Si oui, choisir Oui dans le champ Est indéterminée ? dans la section Semaine de guérison de la transaction M103 - Décision initiale (M103) ou M106 - Décision subséquente (M106) . Accepter ce message et passer à Procédure suivante .
             [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#_Procédure_suivante)

- Si non, consulter Indiquer dans la version Web de SSA que l’information nécessaire pour calculer une demande est manquante .
             [Indiquer dans la version Web de SSA que l’information nécessaire pour calculer une demande est manquante](/fr/procedure/task/calc_calculating/ind_ssa_mcmiss_sb.shtml)

- Déterminer si vous avez examiné le certificat médical :

- Si oui, consulter Modifier les renseignements sur les prestations de maladie à l’écran Annexe — Prestations spéciales dans la version Web de SSA .
             [Modifier les renseignements sur les prestations de maladie à l’écran Annexe — Prestations spéciales dans la version Web de SSA](/fr/procedure/task/calc_calculating/ent_recdate_ssa_sb.shtml)

- Si non, consulter Déterminer si un certificat médical doit être présenté : Prestations de maladie — Demandes initiales .
             [Déterminer si un certificat médical doit être présenté : Prestations de maladie — Demandes initiales](/fr/procedure/task/calc_determining/det_mc_ra.shtml)

- Passer à Procédure suivante .
         [Procédure suivante](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/rcr_screen_messages#suivante)

**Se requalifie comme genre de demande de pêche (1147)**

**Ce qu’il faut savoir**

La version Web de SSA affiche ce message quand que toutes les conditions suivantes sont remplies :

- Il y a une combinaison de RE régulier et de pêcheur.

- Le RE régulier est exclu du calcul.

- Le client est de nouveau admissible aux prestations de pêcheur.

Quand la version Web de SSA détermine incorrectement que le GP est régulier et que le client n’a pas reçu de rémunération, l’agent doit déterminer si le RE a été exclu par erreur. Si le RE est correctement exclu lors du calcul d’une demande de prestations de pêcheur, l’agent doit modifier l’état du RE exclu dans MSRE à Annulé - Non assurable avant de calculer la demande. Une fois la demande calculée, l’agent doit retourner à MSRE et enlever l’état Annulé - Non assurable du RE régulier. Le processus garantit que l’état du RE régulier est exact, au cas où il serait utilisé dans de prochaines demandes.

**Ce qu’il faut faire**

- Déterminer si le message est affiché lors du calcul d’une demande de prestations de pêcheur :

- Si oui, passer à l’étape 2.

- Si non, passer à l’étape 13.

- Dans SNCT, déterminer s’il y a un RD concernant la décision sur le MCE ou le report du MCE du RE exclu :

- S’il n’y a pas de RD, passer à l’étape 3.

- S’il y a un RD, passer à l’étape 8.

- Déterminer s’il s’agit d’un calcul initial ou d’un nouveau calcul :

- S’il s’agit d’un calcul initial, passer à l’étape 4.

- S’il s’agit d’un nouveau calcul, passer à l’étape 5.

- Dans SNCT, créer un AT Litige - Décision (DEC) de la façon suivante :

- Complexité : Choisir Niveau 2 .

- Langue : Choisir l’option appropriée selon la langue préférée du client.

- Utilisateur final : Choisir Prochain utilisateur disponible .

- Problème : Cocher la case appropriée selon le problème.

- Passer à l’étape 7.

- Dans SNCT, créer un AT Révision de la demande (RVD) de la façon suivante :

- Type : Choisir Révisée .

- Problème : Choisir le problème approprié.

- Numéro d’enregistrement : Saisir le numéro d’enregistrement du nouveau calcul.

- Complexité : Choisir Niveau 1 .

- Langue : Choisir l’option appropriée.

- Destination — CSC : Saisir le CSC qui s’affiche dans ETI.

- Date de l’enregistrement de la demande : Saisir la date de l’enregistrement du nouveau calcul.

- Réassigner chaque AT RVD Révisée de la façon suivante :

- Destination: Choisir Moi-même .

- Motif : Choisir Article de travail connexe .

- Détails : Saisir les renseignements de la question nécessitant une décision .

- Dans la feuille de calcul, noter qu’il faut déterminer si la demande est prête à être calculée une fois qu’une décision est rendue sur le RE. Retourner à Traiter le calcul ou le nouveau calcul d’une demande de prestations de pêcheur .
         [Traiter le calcul ou le nouveau calcul d’une demande de prestations de pêcheur](/fr/procedure/activity/calc_fish.shtml)

- Dans MSRE, déterminer si les champs Motif de cessation d’emploi, Condition spéciale et Date de fin (au besoin) du RE correspondent à la décision sur le RD :

- Si oui, passer à l’étape 9.

- Si non, corriger le RE, choisir Soumettre et passer à l’étape 9.

- Déterminer si des changements ont été apportés dans MSRE, la version Web de SSA ou au Fichier historique d’emploi :

- Si non, passer à l’étape 10.

- Si oui, passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
             [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Dans MSRE, dans le RE exclu, modifier l’état du RE de la façon suivante :

- État : Choisir Annulé - Non assurable .

- Choisir Soumettre .

- Dans la feuille de calcul, noter que dans MSRE, il faut changer l’état du RE exclu afin qu’il ne soit plus annulé après que le calcul de la demande soit complété.

- https://cms-sgc.esdc-edsc.canada.ca Calculer une demande dans la version Web de SSA .
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Dans SNCT, déterminer s’il y a un RD concernant la décision ou le report du MCE sur le RE exclu :

- S’il y a un RD, passer à l’étape 14.

- S’il n’y a pas de RD, consulter Examiner une question en suspens sans AT Litige(s) — Décision .
             [Examiner une question en suspens sans AT Litige(s) — Décision](/fr/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Dans MSRE, déterminer si les champs Motif de cessation d’emploi, Condition spéciale et Date de fin (au besoin) du RE correspondent à la décision sur le RD :

- Si non, corriger le RE, choisir Soumettre et passer à l’étape 9 de Calculer une demande dans la version Web de SSA .
             [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Si oui, passer à Traiter le calcul ou le nouveau calcul d’une demande de prestations de pêcheur .
             [Traiter le calcul ou le nouveau calcul d’une demande de prestations de pêcheur](/fr/procedure/activity/calc_fish.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0019.dita`

Remarque :

À moins d’avis contraire, les références aux calculs s’appliquent aussi aux nouveaux calculs. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0865.dita`

Remarque :

Lors du recueil de faits pour un calcul initial ou un nouveau calcul concernant un RE du gouvernement du Canada, consulter RE émis par le gouvernement du Canada — Instructions .
       [RE émis par le gouvernement du Canada — Instructions](/fr/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [RE émis par le gouvernement du Canada — Instructions](/fr/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0866.dita`

Remarque :

Pour annuler la demande, la transaction Décision initiale (M103) doit être saisie avant la transaction M101 - Données de contrôle des fichiers (M101) de genre 7 (M101-7). 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0867.dita`

Remarque :

Pour chaque employeur mentionné, saisir les MSV dans le Fichier historique d’emploi du RE correspondant. S’il y a plus d’un RE d’un employeur qui a été mentionné une seule fois dans la demande, vous assurer que les MSV sont saisies dans le RE approprié de cet employeur. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0868.dita`

Remarque :

S’il est indiqué au dossier du client qu’il a commis une violation, le nombre d’heures requis est supérieur à 600 heures et égal au nombre d’heures requis pour recevoir des prestations régulières. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0869.dita`

Remarque :

Généralement, une prolongation de la fenêtre de maternité se produit dans une demande établie. Si la cliente est admissible à une prolongation de la fenêtre de maternité, il est possible que la semaine de fin de la maternité ne corresponde pas à la semaine de fin de la fenêtre de maternité, car la prolongation sera saisie manuellement à partir d’une transaction M107 après l’acceptation du Résultat de calcul. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0870.dita`

Remarque :

Si la cliente établit cette demande comme une demande subséquente pour le paiement de la balance des prestations de maternité pour cette naissance ou si la cliente interrompt plus tôt ses prestations de maternité (p. ex. pour un RAT), il ne faut pas prolonger la fenêtre de maternité au-delà de la date à laquelle la cliente est admissible à des semaines de prestations de maternité pour cette naissance.

Si la cliente n’a pas présenté sa demande dans les délais prescrits, l’agent détermine si une antidate s’applique. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0871.dita`

Remarque :

Le GD demandé est affiché dans le champ Genre de demande à l’écran Résultat de calcul et ne doit pas être confondu avec le champ Genre de demande imposé . 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0872.dita`

Remarque :

Si la rémunération est liée à un emploi assurable, il faut garder le client au téléphone pendant que l’agent effectue les étapes dans Estimer les renseignements du RE provisoire afin de trouver le profil de l’employeur (dans le but de garantir la légitimité de l’employeur).
       [Estimer les renseignements du RE provisoire](/fr/procedure/task/estimating_interim_roe.shtml)

     [Estimer les renseignements du RE provisoire](/fr/procedure/task/estimating_interim_roe.shtml) 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0873.dita`

Exemple :

Deux RE se trouvent au dossier :

- RE 1 : Du 1er mars au 31 août 2013, MCE = A

- RE 2 : Du 1er janvier au 31 mai 2013, MCE = M et le champ Condition spéciale indique Mauvaise conduite prouvée .

Dans ce cas, le CAC ne peut pas déterminer le nombre d’heures accumulées pendant la période du RE 1 après le DJT indiqué dans le RE 2 (du 1er juin au 31 août 2013). 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0874.dita`

Remarque :

Le nombre d’heures pour chaque période de paie qui s’affiche dans le Fichier historique d’emploi , est automatiquement déterminé en divisant le nombre total d’heures dans la case 15A du RE par le nombre de jours travaillés dans la période d’emploi. Le montant moyen d’heures par période de paie qui s’affiche dans le Fichier historique d’emploi est habituellement différent des heures réelles par période de paie inscrites à la case 15C du RE TAP. Puisque les heures réelles sont facilement accessibles dans le RE TAP, si les montants sont différents, l’agent doit examiner la case 15C et copier les renseignements sur les heures réelles par période de paie dans le Fichier historique d’emploi . 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0875.dita`

Exemple :

Une demande est calculée à la date du DPP soit le 27 septembre, 2015 (s/c 1997) en utilisant le RE qui contient les renseignements suivants: Premier jour de travail : 13 avril 2014. DJT : 28 septembre 2015. Date de fin de la période de paie : 3 octobre 2015. Genre de période de paie : Bimensuel. La DL initiale de la PR était le 28 septembre 2014 (s/c 1945), mais en raison de la prolongation de 15 semaines de la PR, le Résultat de calcul montre que la DL est le 15 juin 2014 (s/c 1930).

La case 15A du RE contient les heures travaillées du 21 septembre 2014 au 28 septembre 2015. En obtenant les heures travaillées entre le 15 juin 2014 et le 20 septembre 2014, le client pourrait être admissible à des semaines d’admissibilité supplémentaires.

La case 15B du RE contient seulement la rémunération accumulée du 22 mars 2015 au 28 septembre 2015. En obtenant la rémunération accumulée entre le 15 juin 2014 et le 21 mars 2015, le client pourrait obtenir un taux de prestation plus élevé en raison des meilleures semaines variables (MSV). 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0876.dita`

Remarque :

Afin qu’il soit plus facile pour l’employeur de fournir les heures supplémentaires, demander que les renseignements soient fournis par période de paie. S’il faut 5 semaines d’heures supplémentaires, demander le nombre de périodes de paie couvrant ces 5 semaines. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0877.dita`

Remarque :

Même s’il a été déterminé qu’il n’y a pas de questions liées à une décision en suspens au moment de déterminer si une demande de prestations est prête à être calculée, un nouveau RE qui doit faire l’objet d’une décision aurait pu être soumis entretemps. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0878.dita`

Remarque :

Une mesure provisoire en vertu du Projet pilote 24 s’applique aux indemnités de cessation d’emploi versées en raison d’une cessation d’emploi dans les demandes dont le DPP ou la date de début de la répartition est entre le 30 mars 2025 (la s/c 2493) et le 10 octobre 2026 (la s/c 2572 ). Quand des indemnités de cessation d’emploi sont versées pour cette période, elles ne sont pas réparties.

Si les sommes sont versées en raison de la cessation d’emploi, l’agent laisse les champs du RE indiquant une date vides et CAC ne répartit pas les sommes. Si les sommes sont versées pour toute autre raison, l’agent saisit les dates appropriées dans le RE et CAC répartit les montants comme d’habitude. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0879.dita`

Exemple :

Le client a travaillé pendant 10 semaines, obtenant une rémunération de 1 000 $

par semaine (total de 10 000 $).

Rémunération hebdomadaire moyenne assurable = 1 000 $

Dénominateur = 14

(14 – 10) × 1 000 $ = 4 000 $

Rémunération totale assurable = 10 000 $ + 4 000 $ = 14 000 $ 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0880.dita`

Remarque :

Pour déterminer si le client remplit les conditions requises dans une semaine qui a lieu entre la semaine de demande d’antidate et la semaine de présentation de la demande, modifier la date indiquée dans le champ Antidater au à l’écran Formulaire de la demande et demander un nouveau résultat de calcul. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0881.dita`

Remarque :

La base de données affiche les taux de chômage de la période courante. Si des taux sont requis pour un DPP d’une période avant la période indiquée dans les résultats de recherche (p. ex. le DPP est antidaté à une période avant celle du taux de chômage courant affiché), consulter Taux de chômage des régions économiques de l’AE pour voir l’historique des taux de chômage de chaque région économique et pour déterminer le code de région économique approprié.
       [Taux de chômage des régions économiques de l’AE](http://srv129.services.gc.ca/eiregions/fra/taux_hist.aspx)

     [Taux de chômage des régions économiques de l’AE](http://srv129.services.gc.ca/eiregions/fra/taux_hist.aspx) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0882.dita`

Remarque :

Même s’il a été déterminé qu’il n’y a pas de questions liées à une décision en suspens au moment de déterminer si une demande de prestations est prête à être calculée, un nouveau RE qui doit faire l’objet d’une décision aurait pu être soumis entre temps. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0883.dita`

Remarque :

Pour modifier un type de répartition W - Rémunération semaine 1 , l’agent utilise un type de répartition A - Rémunération modifiée puisqu’un type de répartition W - Rémunération semaine 1 ne peut pas être modifié. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0884.dita`

Exemple :

DPP : 5 mai 2013 PR TA : Du 1er janvier au 31 décembre 2012

RE pour un emploi assurable à temps partiel :

- Premier jour de travail : 12 février 2012.

- DJT : 16 novembre 2012.

- Date de fin de la période de paie : 17 novembre 2012.

- Type de période de paie : Toutes les deux semaines.

- La case 15B indique la rémunération accumulée du 6 mai au 16 novembre 2012.

- La case 15C n’est pas remplie.

La rémunération n’est pas indiquée pour la période du 12 février 2012 au 5 mai 2012. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0885.dita`

Remarque :

Quand une semaine de guérison indéfinie est saisie à l’écran Annexe - Prestations spéciales , la version Web de SSA postdate la demande, si approprié, parce qu’il détermine que des prestations de maladie peuvent être versées pendant un maximum de 26 semaines. C’est même le cas quand une inadmissibilité D16 est imposée. Saisir à l’écran Enregistrement les renseignements du certificat médical manquant, et laisser en blanc la semaine de guérison assurent la détermination du DPP correct et la création de la transaction D16. 
