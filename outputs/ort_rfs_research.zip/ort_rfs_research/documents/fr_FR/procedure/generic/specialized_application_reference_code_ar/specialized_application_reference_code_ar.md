# Demande spécialisée : Code de référence — Instructions

Source map: `fr_FR/procedure/generic/specialized_application_reference_code_ar/specialized_application_reference_code_ar.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/specialized_application_reference_code_ar/generic.dita`

Table des matières

- Ce qu’il faut savoir

- Composition du code de référence
             [Composition du code de référence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Reference_cCode_sStructure)

- Période de validité et DPP provisoire
             [Période de validité et DPP provisoire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Validity_period_and)

- Industrie automobile

- Attestation du client dans une demande spécialisée pour une demande de l’industrie automobile
                 [Attestation du client dans une demande spécialisée pour une demande de l’industrie automobile](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Client’s_attestation_on_automotive)

- Créer un code de référence 4 - Industrie automobile
                 [Créer un code de référence 4 - Industrie automobile](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Creating_a_4)

             [Industrie automobile](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#AutomotiveIndustry)

- Apprentissage

- Attestation du client dans une demande spécialisée pour une demande d’apprentissage
                 [Attestation du client dans une demande spécialisée pour une demande d’apprentissage](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Client’s_attestation_on_apprenticeship)

- Créer un code de référence 2 - Apprentissage
                 [Créer un code de référence 2 - Apprentissage](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Creating_a_2)

             [Apprentissage](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#Apprenticeship)

- Mise à pied collective temporaire

- Attestation du client dans une demande spécialisée pour une demande de mise à pied collective temporaire
                 [Attestation du client dans une demande spécialisée pour une demande de mise à pied collective temporaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Client’s_attestation_on_short_term)

- Créer un code de référence 1 - Mise à pied temporaire
                 [Créer un code de référence 1 - Mise à pied temporaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Creating_a_1)

             [Mise à pied collective temporaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#ShortTermMassLayoff)

- Travail partagé (TP)

- Attestation du client dans une demande spécialisée pour une demande de Travail partagé (TP)
                 [Attestation du client dans une demande spécialisée pour une demande de Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Client’s_attestation_on_ws)

- Créer un code de référence 3 - Travail partagé
                 [Créer un code de référence 3 - Travail partagé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Creating_a_3)

- Identificateur unique
                 [Identificateur unique](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Unique_identifier)

- Période de validité du code de référence

- Date d’activation
                     [Date d’activation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Activation_date)

- Date d’expiration
                     [Date d’expiration](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Expiration_date)

                 [Période de validité du code de référence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Validity_period_of)

- Ajout d’employés
                 [Ajout d’employés](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Employee_additions)

             [Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#WorkSharing)

         [Ce qu’il faut savoir](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_What_you_need)

- Étape par étape
         [Étape par étape](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#_Step_by_step)

**Ce qu’il faut savoir**

Les codes de référence donnent accès au client à l’une des 4 demandes spécialisées. Les demandes spécialisées diffèrent des demandes régulières, puisqu’elles sont adaptées pour recueillir des renseignements auprès du client dans les situations suivantes :

- un manque de travail dans l’ industrie automobile ;
         [industrie automobile](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#AutomotiveIndustry)

- un renvoi à un programme d’ apprentissage ;
         [apprentissage](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#Apprenticeship)

- une mise à pied collective temporaire ;
         [mise à pied collective temporaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#ShortTermMassLayoff)

- une participation à un accord de Travail partagé (TP) .
         [Travail partagé (TP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/procedure/generic/specialized_application_reference_code_ar#WorkSharing)

L’utilisation des codes de référence dans la demande crée certaines restrictions pour le client :

- Le client peut seulement demander des prestations régulières dans sa demande. Un client demandant des prestations spéciales ne peut pas remplir la demande spécialisée.

- Les renseignements sur le client ne sont pas communiqués aux autorités désignées pour renvoi aux mesures d’emploi en vertu de la LAE 25.

Quand un code de référence est émis pour des situations autres que celles pour lesquelles il a été conçu, les restrictions peuvent avoir une incidence négative sur le client. Par conséquent, l’utilisateur l’émetteur régional crée des codes de référence seulement pour les situations mentionnées dans ce document.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0912.dita) 

Un code de référence est valide pour une période précise. Pour accéder aux demandes spécialisées, le code de référence doit être utilisé entre la date d’activation et la date d’expiration. Un client qui tente d’accéder à une demande spécialisée en dehors de cette période reçoit un message d’avertissement et peut seulement présenter une demande de prestations régulières si le code de référence est invalide.

**Composition du code de référence**

Les codes de référence sont créés à l’onglet Admin dans SNCT. Chaque code de référence est composé de 16 chiffres. Le code de référence comprend les 4 chiffres du Centre Service Canada (CSC) où il a été émis, suivis de 2 chiffres désignant le genre de code de référence et de 10 chiffres liés au genre de demande spécialisée.

Le système remplit les chiffres 1 à 4 du code de référence selon ce qui est indiqué dans le champ CSC et les chiffres 5 et 6 selon ce qui est indiqué dans le champ Demande spécialisée . L’émetteur saisit les chiffres 7 à 10 dans le champ Identificateur unique et les chiffres 11 à 16 dans le champ Chiffres de fin .

Le tableau suivant résume ces renseignements.

```text
| Demande spécialisée | Champ CSC Chiffres 1 à 4 | Champ Demande spécialisée Chiffres 5 et 6 | Champ Identificateur unique Chiffres 7 à 10 | Champ Chiffres de fin Chiffres 11 à 16 |

| Mise à pied collective temporaire | CSC | 01 | Année d’émission | Année et mois d’expiration |

| Industrie automobile | 04 |

| Apprentissage | 02 | Utilisation régionale |

| Travail partagé | 03 | Utilisation régionale | s/c de la date de début de l’accord et durée de l’accord en semaines |
```

**Période de validité et DPP provisoire**

Les clients peuvent utiliser un code de référence durant la période comprise entre les dates indiquées dans les champs Date d’activation et Date d’expiration . Les codes de référence pour les demandes spécialisées autres que pour le TP ont des périodes de validité étendues qui sont liées à la durée d’un événement ou d’un programme. Les codes de référence pour le TP ont des périodes de validité allant jusqu’à 8 semaines. Les codes de référence expirent à minuit (heure normale de l’Est) à la date indiquée dans le champ Date d’expiration .

Les demandes spécialisées de TP sont établies avec un DPP provisoire qui correspond aux chiffres 11 à 14 du code de référence. Les DPP provisoires des autres demandes spécialisées respectent les critères des demandes de prestations régulières.

**Industrie automobile**

Les employés de l’industrie automobile sont habituellement mis à pied pour de courtes périodes et sont autorisés à remplir une demande spécialisée dans AW avec un code de référence. Ce genre de demande nécessite peu de renseignements du client. Il n’y a pas de questions sur les autres employeurs ou les autres sommes.

Un code de référence pour une mise à pied dans l’industrie automobile est normalement créé avec le code 4 - Industrie automobile . Toutefois, si le client doit fournir des renseignements sur d’autres sommes versées, un code 1 - Mise à pied temporaire peut être utilisé.

Le code de référence doit être utilisé quand il y a une date de retour au travail (RAT) prévue. Si la durée de la mise à pied est incertaine ou indéterminée, un code 4 - Industrie automobile ou 1 - Mise à pied temporaire n’est pas créé . La date de RAT prévue peut changer ou la mise à pied peut devenir permanente, toutefois, il est important d’avoir une date de RAT prévue lors de la création du code de référence.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0913.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0914.dita) 

**Attestation du client dans une demande spécialisée pour une demande de l’industrie automobile**

Quand il remplit la demande spécialisée, le client reçoit une attestation indiquant qu’il :

- présente une demande de prestations régulières;

- ne travaille pas chez son dernier employeur en raison d’un manque de travail temporaire;

- est prêt, disposé et capable de travailler lors de cette période de la mise à pied;

- accepterait un emploi du même genre de travail et pour le même salaire que son emploi habituel ou tout emploi convenable pour lequel il a les compétences nécessaires.

**Créer un code de référence 4 - Industrie automobile**

Le code de référence 4 - Industrie automobile remplit les critères suivants :

```text
| ```text | Position des chiffres | Description | Saisie dans SNCT | | 1 à 4 | CSC | Renseignements dans le champ CSC | | 5 et 6 | 04 (code de demande spécialisée pour une demande de l’industrie automobile) | Renseignements dans le champ Demande spécialisée | | 7 à 10 | Année (si le code de référence est valide pour 2 années, l’utilisateur régional utilise l’année pendant laquelle le code de référence a été créé) | Champ Identificateur unique | | 11 à 16 | Année et mois d’expiration du code de référence | Champ Chiffres de fin | ``` |

| Position des chiffres | Description | Saisie dans SNCT |

| 1 à 4 | CSC | Renseignements dans le champ CSC |

| 5 et 6 | 04 (code de demande spécialisée pour une demande de l’industrie automobile) | Renseignements dans le champ Demande spécialisée |

| 7 à 10 | Année (si le code de référence est valide pour 2 années, l’utilisateur régional utilise l’année pendant laquelle le code de référence a été créé) | Champ Identificateur unique |

| 11 à 16 | Année et mois d’expiration du code de référence | Champ Chiffres de fin |
```

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0915.dita) 

**Apprentissage**

Un client dirigé vers un programme d’apprentissage par une autorité désignée reçoit un code de référence pour remplir une demande spécialisée dans AW.

Dans la demande, le client doit fournir les renseignements suivants :

- Nom du cours

- Niveau du cours

- Numéro d’identification du cours

- Date de début du cours

- Date de fin du cours

- Nom de l’établissement d’apprentissage

Le client peut aussi choisir d’être exempté de remplir ses déclarations du prestataire.

Deux questions sont modifiées dans la demande d’apprentissage :

- Retournerez-vous au travail la semaine suivant la fin de votre cours auprès de cet employeur?

- Êtes-vous travailleur autonome ou travaillez-vous pour un employeur autre que celui qui vous envoie à la formation d’apprentissage?

**Attestation du client dans une demande spécialisée pour une demande d’apprentissage**

Quand il remplit la demande spécialisée, le client reçoit une attestation indiquant qu’il :

- présente une demande de prestations régulières;

- ne travaille pas temporairement à temps plein, ou travaille seulement à temps partiel pour le dernier employeur, parce qu’il doit suivre un cours ou un programme d’apprentissage.

**Créer un code de référence 2 - Apprentissage**

Le code de référence 2 - Apprentissage remplit les critères suivants :

```text
| Position des chiffres | Description | Saisie dans SNCT |

| 1 à 4 | CSC | Renseignements dans le champ CSC |

| 5 et 6 | 02 (code de demande spécialisée pour une demande d’apprentissage) | Renseignements dans le champ Demande spécialisée |

| 7 à 10 | Année (si le code de référence est valide pour 2 années, l’émetteur régional utilise l’année pendant laquelle le code de référence a été créé) | Champ Identificateur unique |

| 11 à 16 | Texte libre pour identification (p. ex. année) | Champ Chiffres de fin |
```

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0916.dita) 

**Mise à pied collective temporaire**

Le code de référence 1 - Mise à pied temporaire a été conçu pour les situations de mise à pied collective temporaire dans des industries autres que celle de l’automobile.

Pour une mise à pied collective temporaire, la date de RAT prévue et la période pendant laquelle les employés seront sans travail sont connues. Si la durée de la mise à pied est incertaine ou indéterminée, un code de référence 1 - Mise à pied temporaire n’est pas créé . La date de RAT prévue peut changer ou la mise à pied peut devenir permanente, toutefois, il est important d’avoir une date de RAT prévue lors de la création du code de référence.

De toutes les demandes spécialisées, celle pour la mise à pied collective temporaire est la demande spécialisée qui ressemble le plus à une demande habituelle.

À la suite de consultations avec les régions et les gestionnaires de la charge de travail, il a été décidé que le code de référence 1 - Mise à pied temporaire ne devrait plus être créé dans des situations autres que les situations exceptionnelles de mise à pied dans l’industrie automobile. Cette décision a été prise, puisque la demande ne diffère pas beaucoup de la demande régulière et la majorité des demandes peuvent être automatisées.

**Attestation du client dans une demande spécialisée pour une demande de mise à pied collective temporaire**

Quand il remplit la demande spécialisée, le client reçoit une attestation indiquant qu’il :

- présente une demande de prestations régulières;

- ne travaille pas chez son dernier employeur en raison d’un manque de travail temporaire;

- est prêt, disposé et capable de travailler lors de cette période de la mise à pied;

- accepterait un emploi du même genre de travail et pour le même salaire que son emploi habituel ou tout emploi convenable pour lequel il a les compétences nécessaires.

**Créer un code de référence 1 - Mise à pied temporaire**

Le code de référence 1 - Mise à pied temporaire doit être conforme aux critères suivants :

```text
| Position des chiffres | Description | Saisie dans SNCT |

| 1 à 4 | Centre de traitement Service Canada (CSC Paiement où l’AT est assigné) | Renseignements dans le champ CSC |

| 5 et 6 | 01 (code de demande spécialisée pour une demande de mise à pied temporaire) | Renseignements dans le champ Demande spécialisée |

| 7 à 10 | Année (si le code de référence est valide pour 2 années, l’émetteur régional utilise l’année pendant laquelle le code de référence a été créé) | Champ Identificateur unique |

| 11 à 16 | Année et mois d’expiration du code de référence | Champ Chiffres de fin |
```

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0917.dita) 

**Travail partagé (TP)**

Le coordonnateur régional du TP de l’AE est responsable de l’émission des codes de référence de TP. Un code de référence est requis quand un accord est mis en œuvre et quand d’autres clients sont ajoutés à un accord de TP déjà mis en œuvre. Les employés qui participent à un accord de TP reçoivent un code de référence 3 - Travail partagé au moyen du Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit et doivent présenter une demande spécialisée dans AW à l’aide de ce code de référence durant la période de validité.
       [responsable](http://edsc.prv/fr/service-canada/ae/documents-reference/sopa/travail-partage/roles-responsabilities-tp.shtml) 
       [Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_fr.docx)

La date à laquelle le client est ajouté à un accord (à la date de mise en œuvre ou plus tard) est déterminée par l’agent de programme. La s/c de cette date est saisie par l’émetteur dans le champ Chiffres de fin et correspond aux chiffres 11 à 14 du code de référence. TAD utilise cette date pour remplir le champ Date de début de la transaction Données de projet — Travail partagé (M171) et pour déterminer le DPP provisoire ou la semaine de renouvellement.

L’émetteur saisit aussi la durée de l’accord en semaines dans le champ Chiffres de fin . Ces 2 derniers chiffres correspondent aux chiffres 15 et 16 du code de référence. TAD détermine la date de fin dans la transaction M171 en additionnant la date de début et la durée et en soustrayant 1.

**Attestation du client dans une demande spécialisée pour une demande de Travail partagé (TP)**

Quand il remplit la demande spécialisée, le client reçoit une attestation indiquant qu’il :

- présente une demande de prestations régulières;

- travaille pour son dernier employeur selon une semaine de travail réduite.

**Créer un code de référence 3 - Travail partagé**

Le code de référence 3 - Travail partagé remplit les critères suivants :

```text
| Position des chiffres | Description | Saisie dans SNCT |

| 1 à 4 | CSC | Renseignements dans le champ CSC |

| 5 et 6 | 03 (code de demande spécialisée pour une demande de TP) | Renseignements dans le champ Demande spécialisée |

| 7 à 10 | Identificateur unique (4 chiffres qui ne peuvent pas commencer par 0 selon le format des régions) [Identificateur unique](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#_Unique_identifier) | Champ Identificateur unique |

| 11 à 14 | s/c de la date de début (la semaine de la mise en œuvre de l’accord ou la semaine dans laquelle des employés supplémentaires sont ajoutés à un accord déjà mis en œuvre) | 4 premiers chiffres du champ Chiffres de fin |

| 15 à 16 | Durée de l’accord de TP | 2 derniers chiffres du champ Chiffres de fin |
```

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0918.dita) 

Le système envoie une transaction M171 initiale selon le code de référence et d’AW. Les champs de la transaction sont préremplis de la façon suivante :

- Date de début : chiffres 11 à 14

- Date de fin : date de début du projet + chiffres 15 et 16 – 1

- Projet CSC : chiffres 1 à 4

- Numéro d’accord : valeur temporaire correspondant aux chiffres de 1 à 10

- Heures hebdomadaires : heures déclarées par le client dans AW

**Identificateur unique**

L’identificateur unique à 4 chiffres est assigné à un accord de TP précis et distingue le code de référence des autres codes de référence du TP dont les chiffres sont semblables (c.-à-d. même région, date de début et durée). L’utilisation de l’identificateur unique varie selon les régions.

Une série précise de numéros peut être assignée à chaque émetteur de code de référence selon chaque région (p. ex. les numéros 1111 à 1999 pourraient être assignés à l’émetteur 1). Cela permet à l’émetteur d’utiliser la série de numéros de façon séquentielle tout en s’assurant que les autres émetteurs ne créent pas un identificateur unique en double. Certaines régions utilisent également l’identificateur unique pour désigner l’agent qui recevra tous les AT associés à un accord de TP précis (p. ex. l’agent 1 pourrait être désigné par 1000 ). Une combinaison des 2 utilisations est également possible (p. ex. l’émetteur peut être désigné par les 2 premiers chiffres du code de référence et l’agent par les 2 derniers chiffres).

Dans SNCT, des AT Demande spécialisée (DS) peuvent être assignés à la charge de travail d’un agent en choisissant des codes de référence précis dans le champ Codes de références de la section Interventions liées à une demande — Demandes spécialisées de l’onglet Détails sur le travail du profil de l’agent . Tous les codes de références dans SNCT sont énumérés dans ce champ. Il peut être utile de désigner l’agent qui recevra les AT à l’aide de l’identificateur unique pour aider à trouver le code de référence approprié.

**Période de validité du code de référence**

Pour un code de référence de TP, l’émetteur saisit une période de validité de 8 semaines à compter de la date de mise en œuvre de l’accord ou, dans le cas d’un ajout d’employé à un accord déjà mis en œuvre, à compter de la date à laquelle le client est ajouté à cet accord. La période de validité correspond donc à la période de 8 semaines suivant la semaine de début de l’accord de TP du client. L’émetteur saisit la période de validité en saisissant les dates dans les champs Date d’activation et Date d’expiration .

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0919.dita) 

Si un client présente une demande après cette période, AW ne permet pas l’utilisation du code de référence expiré. Le client peut alors seulement présenter une demande de prestations régulières et doit choisir TP comme motif de cessation d’emploi (MCE). Dans cette situation, la logique de calcul habituelle est utilisée pour déterminer le DPP ou la semaine de renouvellement et l’agent doit saisir manuellement la transaction M171. Si le client souhaite que sa demande commence à une date antérieure, il doit demander une antidate.

**Date d’activation**

Le système empêche l’émetteur de choisir la date actuelle ou une date antérieure :

- La date indiquée dans le champ Date d’activation est la date de demain.

**Date d’expiration**

Le code de référence est valide jusqu’à 8 semaines à partir de la date de début. L’émetteur détermine la date d’expiration en ajoutant 8 semaines à la date de début (chiffres 11 à 14 du code de référence) :

- La date indiquée dans le champ Date d’expiration est le dimanche de la s/c correspondant à la date de début + 8 semaines.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0920.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0921.dita) 

**Ajout d’employés**

Un employeur peut ajouter des employés à un accord de TP déjà mis en œuvre. Un nouveau code de référence est requis pour chaque groupe d’employés ajouté à l’accord de TP dans une semaine précise. Les codes de référence existants ne peuvent pas être donnés à des clients ayant des semaines de début d’accord différentes, même s’ils sont toujours valides.

Les chiffres 11 à 14 du code de référence correspondent à la s/c au cours de laquelle les employés supplémentaires sont ajoutés à l’accord, car le code de référence détermine le DPP provisoire ou la semaine de renouvellement ainsi que les renseignements saisis dans le champ Date de début de la transaction M171.

La durée de l’accord indiquée par les chiffres 15 et 16 est ajustée pour correspondre à la durée restante de l’accord.

La période de validité de 8 semaines pour l’ajout d’employés est déterminée de la même façon que pour les nouveaux accords.

**Étape par étape**

- Dans SNCT, choisir l’onglet Admin , puis choisir Code de référence .

- CSC : Choisir le CSC approprié.

- Choisir Créer et saisir les renseignements suivants :

- Nom français : Saisir un nom pour le code de référence (qui s’affichera dans la liste de résultats de recherche de codes de référence) de la façon suivante :

- Pour les codes de référence de TP, saisir le nom de l’employeur participant au TP.

- Pour l’industrie automobile ou une mise à pied collective temporaire, saisir une description de l’événement.

- Pour l’apprentissage, saisir le nom du programme d’apprentissage.

- Nom anglais : Saisir le nom anglais correspondant, au besoin, ou saisir le même nom qui a été saisi dans le champ Nom français quand une traduction ne s’applique pas.

- Type d’application : Choisir le genre de demande spécialisée approprié.

- Identificateur unique : Saisir le numéro à 4 chiffres selon l’utilisation de la région.

- Chiffres de fin : Saisir le numéro à 6 chiffres selon le genre de code de référence à émettre :

- Pour le TP, saisir les 4 chiffres de la s/c de la date de début. Les chiffres 5 et 6 correspondent à la durée de l’accord de TP, ou le nombre de semaines pendant lesquelles l’employé participera à l’accord de TP. Cela doit être constitué de 2 chiffres (p. ex. 9 semaines sont saisies comme 09).

- Pour l’industrie automobile ou une mise à pied collective temporaire, saisir l’année suivie du mois à 2 chiffres au cours desquels le code de référence expirera.

- Pour l’apprentissage, saisir des chiffres uniques pour identification.

             [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0922.dita)

- Date d’activation : Choisir l’option appropriée :

- Pour un accord de TP, choisir la date de demain.

- Pour toute autre demande spécialisée, choisir la date de début ou d’entrée en vigueur de l’événement.

- Date d’expiration : Choisir l’option appropriée :

- Pour un accord de TP, choisir le dimanche de la s/c de la date de début + 8 semaines.

- Pour toute autre demande spécialisée, choisir la date de fin de l’événement.

             [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0923.dita)

- Description anglaise : Laisser ce champ vide.

- Description française : Choisir l’option appropriée :

- Pour un accord de TP, copier et coller les renseignements sur l’accord du gabarit de l’employeur. Ne pas copier et coller la liste de NAS.

- Pour toute autre demande spécialisée, saisir toutes les directives ou tous les détails pertinents.

             [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0924.dita)

- Choisir Sauvegarder pour obtenir le code de référence nouvellement créé. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0912.dita`

Remarque :

Le niveau et la désignation de l’émetteur régional varie selon la région. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0913.dita`

Exemple :

Une compagnie est forcée de mettre à pied des employés à la suite d’un conflit collectif aux États-Unis, ce qui a une incidence sur la livraison de matériaux. Comme la date de fin du conflit collectif et la date de RAT des employés sont inconnues, les restrictions liées à l’utilisation du code de référence ont une incidence négative sur le client et, par conséquent, le client doit utiliser le processus de demande habituel. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0914.dita`

Remarque :

Comme la plupart des industries automobiles sont en Ontario, la région de l’Ontario traite toutes les demandes de l’industrie automobile pour le Canada. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0915.dita`

Exemple :

3515042022202201 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0916.dita`

Exemple :

1955022022202201 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0917.dita`

Exemple :

2371012022202212 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0918.dita`

Exemple :

4812032018215826 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0919.dita`

Remarque :

Quand la demande pour émettre un code de référence est envoyée au coordonnateur régional du TP de l’AE après la date de début de l’accord, la période de validité sera inférieure à 8 semaines. Les codes de référence ne peuvent pas être émis si une demande est reçue plus de 8 semaines après la semaine de début de l’accord. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0920.dita`

Remarque :

Les codes de référence expirent à minuit (heure normale de l’Est). Quand un code de référence est émis pour un client résidant à l’ouest de ce fuseau horaire, l’émetteur du code de référence ajoute 1 jour à la période de validité, mais ne le mentionne pas dans le Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit .
       [Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_fr.docx)

     [Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_fr.docx) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0921.dita`

Remarque :

La distribution du code de référence aux clients relève des parties liées à l’accord de TP (c.-à-d. Service Canada, l’employeur et les représentants des employés). De nouveaux codes de référence ne sont pas émis aux clients qui n’ont pas reçu un code de référence en même temps que les autres participants. Tant que le code de référence est toujours valide et que leur participation à l’accord de TP a commencé dans la même semaine, le client utilise le même code de référence. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0922.dita`

Remarque :

Pour les codes de référence de TP, il est important de remplir ce champ correctement, puisque TAD utilise ces renseignements pour établir le DPP et saisir les données de projet dans la demande. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0923.dita`

Remarque :

Les codes de référence expirent à minuit (heure normale de l’Est). Quand un code de référence est émis pour un client résidant à l’ouest de ce fuseau horaire, ajouter 1 jour à la période de validité, mais ne pas le noter dans le Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit .
       [Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_fr.docx)

     [Présenter une demande de prestations de l’assurance-emploi pour le Travail partagé — Gabarit](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_fr.docx) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0924.dita`

Remarque :

Dans la région du Québec, les champs de description sont laissés vides. Les renseignements sont disponibles dans l’Outil de référence Travail Partagé. 
