# Appel : Documents à inclure dans le dossier de révision — Aide-mémoire

Source map: `fr_FR/procedure/generic/docs_recon_file/docs_recon_file.ditamap`

## Generic

Source topic: `fr_FR/procedure/generic/docs_recon_file/generic.dita`

Sommaire : Le dossier de révision est un document qui contient tous les renseignements qu’utilise un agent pour rendre une décision au sujet d’une demande de révision en vertu de la LAE 112 .
       [LAE 112](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-112.html)

**Révision en vertu de la LAE 112**

Le dossier de révision est assemblé et envoyé au client à la suite d’une décision défavorable. Le dossier de révision contient tous les renseignements utilisés et pris en considération par la Commission quand elle rend une décision en vertu de la LAE 112 . Sauf indication contraire, l’agent inclut les documents énumérés dans le tableau ci-dessous dans le dossier de révision envoyé au client.
       [LAE 112](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-112.html)

**Appel au Conseil d’appel en assurance-emploi (CAAE) ou au Tribunal de la sécurité sociale (TSS)**

Le dossier de révision est fourni au CAAE ou au TSS, avec l’argumentation de la Commission, quand la Commission est informée d’un appel en vertu de la LAE 113 . Afin de soutenir au mieux la position de la Commission, l’agent doit constituer avec soin le dossier de révision pour s’assurer qu’il contient tous les documents requis.
       [LAE 113](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-113.html)

En fonction du litige en appel ou des participants, l’agent doit inclure certains documents. Le tableau suivant présente les documents nécessaires, selon la situation.

Une fois que le fichier a été constitué, l’agent énumère les documents dans le formulaire Liste des documents faisant partie du dossier de révision (INS2245) dans le même ordre logique qu’ils apparaissent dans le dossier de révision.

```text
| Situation | Documents à inclure dans le dossier de révision |

| Dans tous les cas | L’agent doit inclure : - les pages pertinentes de la demande d’AE (l’agent doit toujours inclure les sections suivantes, en plus des autres pages liées au litige en appel) : - Renseignements personnels - Type de prestations [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0813.dita) - Déclaration d’une tierce personne et attestation [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0814.dita) - Confirmation et Renseignements; [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0815.dita) - la documentation pertinente (RSDP, AT Action à prendre [AP] ou AT Rappel [RA]); - les documents pertinents emmagasinés dans Imagerie ou dans le téléversement de documents; - la demande de révision; - les lettres liées à la décision initiale; - une attestation et une copie de tous les courriels génériques envoyés et liés à la décision initiale et à celle de révision; - les lettres liées à la décision de révision. [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0816.dita) [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0817.dita) L’agent ne doit pas inclure : - la page Renseignements sur l’identité de la demande sauf si l’âge du client est pertinent au litige en appel. Dans ces rares cas, la page est ajoutée, mais tous les autres renseignements confidentiels, tels que le nom de famille du parent à sa naissance, sont biffés. La biffure est expliquée dans l’argumentation. - le rapport de décision (RD), sauf dans le cas d’une décision discrétionnaire (pénalité, violation, rejet d’une demande en retard, exclusions déterminées et RD liés aux révisions en vertu de la LAE 52 ou aux modifications en vertu de la LAE 111 s’ils sont pertinents au litige en appel); - les notes de service internes et les analyses donnant des directives, des avis spécialisés ou des opinions personnelles; - des renseignements relatifs à un emploi antérieur, si le litige en révision concerne le dernier emploi; - des renseignements relatifs à un emploi antérieur, si le litige en révision concerne le dernier emploi; - l’analyse d’une entrevue ou d’une enquête de l’agent d’Intégrité (rapport d’enquête); - les rapports d’enquête automatisée (post-vérification informatique, concordance de la rémunération provenant d’un travail indépendant [TI], concordance de la rémunération assurable); [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0818.dita) - des captures d’écran de la version Web de SSA ou d’ETI, sauf indication contraire pour le litige en appel (p. ex. pour des conflits liés au choix des prestations parentales prolongées ou standards); - les renseignements reçus d’un dénonciateur. |

| GP | Page sommaire |

| Prestations de maternité | Validation des renseignements sur les prestations de maternité |

| Prestations parentales | Validation des renseignements sur les prestations parentales |

| Prestations de maternité et parentales | Validation des renseignements sur les prestations de maternité/parentales |

| Le litige en appel a entraîné un T‑P ou le litige faisant objet de l’appel est le calcul du T‑P | En plus des documents requis pour tous les cas, l’agent doit inclure les éléments suivants : - l’Avis de dette du SMCD; - une copie de la section Correspondance affichant l’Avis de dette dans PSCD; - le RD lié à une révision en vertu de la LAE 52 ou à une modification en vertu de la LAE 111 s’il est pertinent au litige en appel; - tout document pertinent, y compris les RSDP liés à la défalcation; - le RD lié à la défalcation du T-P, s’il est disponible; - la lettre SCA F-00-00-00 communiquant le refus de la défalcation, si disponible. [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0819.dita) [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0820.dita) De plus, l’agent doit inclure une répartition du T‑P dans les situations suivantes : - le client conteste le montant du T‑P; - le montant du T‑P a changé pendant le processus suivant la décision initiale; - le calcul du T‑P est complexe. [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0821.dita) [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0822.dita) [RAE 56](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-56.html) [RAE 56](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-56.html) [Le litige en appel est lié à un motif de cessation d’emploi (MCE)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_tables#MCE) |

| Le litige en appel est lié à un motif de cessation d’emploi (MCE) | En plus des documents requis pour tous les cas, l’agent doit inclure : - tous les RE pertinents (y compris le verso). - Pour les RE papier, l’agent obtient une copie de l’original à partir d’Imagerie. Si le verso n’est pas disponible, l’agent crée une transcription. [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0823.dita) [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0824.dita) |

| Le litige en appel est lié à l’imposition d’une pénalité | En plus des documents requis pour tous les cas, l’agent doit inclure : - une copie du RD démontrant que la Commission a agi de manière judicieuse en exerçant son pouvoir discrétionnaire pour déterminer le montant de la pénalité; - les déclarations du prestataire pertinentes (copie certifiée s’il s’agit d’une copie numérisée); - une copie du Déclaration du prestataire : INS5173 Demande d’exemption de remplir des déclarations du prestataire — Formulaire , si le client est exempté de remplir des déclarations du prestataire; [Déclaration du prestataire : INS5173 Demande d’exemption de remplir des déclarations du prestataire — Formulaire](http://forms-formulaires.prv/lc/content/EForms/fr/CallForm.html?Lang=fr&PDF=SC-INS5173.pdf) - les questions et réponses figurant dans les déclarations du prestataire électroniques (ETI); - ETI – la partie de la demande portant sur les renseignements liés au paiement et le dépôt direct peut être utilisée pour prouver que les mandats liés aux prestations ont été reçus et déposés; - la lettre A-01-00-00 dans SCA – Reconsidération d’une décision qui a été envoyée au client, au besoin; - les Feuilles d’informations sur l’enquête de SNEI; - les Feuilles de Rapport d’entrevue de SNEI (au besoin); - le Rémunération : INS5097 Demande de renseignements sur le registre de paie — Formulaire, au besoin; - le Rémunération : INS5098 Demande de renseignements sur l’emploi — Formulaire, au besoin; - une copie de la section Correspondance , au besoin; - les transcriptions pertinentes. [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0825.dita) L’agent ne doit pas inclure : - l’analyse d’une entrevue ou d’une enquête de l’agent d’Intégrité (rapport d’enquête); - les rapports d’enquête automatisée (post-vérification informatique, concordance de la rémunération provenant d’un TI, concordance de la rémunération assurable). [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0818.dita) [Déclaration du prestataire : INS5173 Demande d’exemption de remplir des déclarations du prestataire — Formulaire](http://forms-formulaires.prv/lc/content/EForms/fr/CallForm.html?Lang=fr&PDF=SC-INS5173.pdf) [LAE 39](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/page-11.html#h-18) |

| Le litige en appel est lié au refus d’une demande de révision en retard | En plus des documents requis pour tous les cas, l’agent doit inclure : - une copie du RD démontrant que la Commission a agi de manière judicieuse en exerçant son pouvoir discrétionnaire pour refuser la demande de révision en retard. L’agent ne doit pas inclure : - les documents liés uniquement à la décision initiale (p. ex. un RSDP qui concerne seulement le litige de fond). |

| Le litige en appel est lié à une décision relative à une PPNE, ou est un litige lié au calcul, tel que le taux de prestations | En plus des documents requis pour tous les cas, l’agent doit inclure : - tous les RE utilisés pour le calcul - Pour les RE papier, l’agent obtient une copie de l’original à partir d’Imagerie. Si le verso n’est pas disponible, l’agent crée une transcription. - la documentation liée à la vérification des RE et aux modifications qui y ont été apportées; - une copie du tableau du taux régional de chômage (TRC) ; [tableau du taux régional de chômage (TRC)](http://srv129.services.gc.ca/eiregions/fra/taux_act.aspx) - une copie des résultats obtenus lors de la recherche effectuée avec le code postal du client à la page Régions économiques de l’assurance-emploi par code postal . [Régions économiques de l’assurance-emploi par code postal](http://srv129.services.gc.ca/eiregions/fra/codepostal_recherche.aspx) L’agent peut aussi inclure : - une copie de la feuille de calcul dans la version Web de SSA (des renseignements supplémentaires pourraient devoir être ajoutés). Si le client conteste le TRC, l’agent doit aussi inclure : - un document de certification obtenu de la Division des appels de l’administration centrale; [Division des appels](mailto:nc-ins-assur_appeals_general_inquiry-gd) - l’ajout du RAE 17(1) dans la section de l’argumentation portant sur la législation. [RAE 17(1)](http://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-17.html) [tableau du taux régional de chômage (TRC)](http://srv129.services.gc.ca/eiregions/fra/taux_act.aspx) [Régions économiques de l’assurance-emploi par code postal](http://srv129.services.gc.ca/eiregions/fra/codepostal_recherche.aspx) [Division des appels](mailto:nc-ins-assur_appeals_general_inquiry-gd) [RAE 17(1)](http://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-17.html) |

| Le litige en appel est lié à un document sur la concordance établie par les douanes (hors Canada) | En plus des documents requis pour tous les cas, l’agent doit inclure : - une copie de la feuille de demande E-311 ; [feuille de demande E-311](https://esdc.prv/en/service-canada/isb/io/bso/documents/e311.xls) - une copie du questionnaire électronique. [feuille de demande E-311](https://esdc.prv/en/service-canada/isb/io/bso/documents/e311.xls) |

| Le litige en appel est lié à la répartition de la rémunération | En plus des documents requis pour tous les cas, l’agent peut inclure : - une copie de la feuille de calcul dans la version Web de SSA (des renseignements supplémentaires pourraient devoir être ajoutés); - une copie du fichier d’historique d’emploi (si le client conteste la rémunération hebdomadaire moyenne). Si la répartition est liée à des sommes versées en vertu de la LAE 45 ou la LAE 46 (règlement d’un grief, jugement d’un tribunal, sentence arbitrale ou règlement pour congédiement abusif) et le versement a été effectué plus de 36 mois après la date de cessation d’emploi, l’agent doit inclure : [LAE 45](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-45.html) [LAE 46](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-46.html) - le RD pour les décisions discrétionnaires rendues en vertu de la LAE 46.01 . [LAE 46.01](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-46.01.html) [LAE 45](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-45.html) [LAE 46](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-46.html) [LAE 46.01](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-46.01.html) |

| Le litige en appel est lié à une exclusion déterminée | En plus des documents requis pour tous les cas, l’agent doit inclure : - une copie du RD démontrant que la Commission a agi de manière judicieuse en exerçant son pouvoir discrétionnaire pour déterminer le nombre de semaines d’exclusion. |

| Le litige en appel est lié au paiement des prestations parentales standards ou prolongées | En plus des documents requis pour tous les cas, l’agent doit inclure : - une copie de la certification MDSC ( Note de service AP-2021-12 ); [Note de service AP-2021-12](/fr/policy/bememo/be2021-11-a.shtml) - une capture d’écran de l’onglet Taux/Durée dans ETI avec l’attestation. [Note de service AP-2021-12](/fr/policy/bememo/be2021-11-a.shtml) |

| Le litige en appel est lié au partage des prestations parentales entre les parents | En plus des documents requis pour tous les cas, l’agent doit inclure : - une copie de la certification MDSC; - une capture d’écran de l’onglet Paiement ou de l’écran Historique de paiement (MHQ1) dans ETI avec le genre et le nombre de semaines de prestations parentales versées à chaque parent (l’agent biffe tout renseignement de l’autre parent, sauf pour le nom et les 3 derniers chiffres du NAS). |

| Le litige en appel est disponibilité pour un étudiant en cours de formation non dirigé à temps plein | En plus des documents requis pour tous les cas, l’agent doit inclure : - tous les RE (y compris le verso) montrant l’historique d’emploi du client dans la période de référence (PR) ou avant la PR. - Pour les RE papier, l’agent obtient une copie de l’original à partir d’Imagerie. Si le verso n’est pas disponible, l’agent crée une transcription. |

| Le litige en appel est lié à une antidate | En plus des documents requis pour tous les cas, l’agent doit inclure : - les pages de la demande d’AE contenant de l’information sur le dernier emploi (dernier jour de travail); - une copie du dernier RE confirmant le dernier jour de travail (démontant que le client a soumis sa demande en retard); - la documentation liée à la demande d’antidate. |

| Le litige en appel est lié à une formalité administrative – déclaration du prestataire soumise en retard | En plus des documents requis pour tous les cas, l’agent doit inclure : - une capture d’écran de l’onglet Paiement (dans les situations où des paiements avaient déjà été émis et que le client a omis de continuer à soumettre ses déclarations en temps opportun) dans ETI; - une capture d’écran de l’Historique des déclaration-é (MD01) dans ETI; - la documentation liée à la demande du client afin que sa déclaration soumise en retard soit considérée comme ayant été soumise plus tôt (dans les délais). |
``` 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0813.dita`

Remarque :

Selon le genre de prestations (GP) choisi par le client, l’agent inclut la page sommaire appropriée comme suit :

```text
| GP | Page sommaire |

| Prestations de maternité | Validation des renseignements sur les prestations de maternité |

| Prestations parentales | Validation des renseignements sur les prestations parentales |

| Prestations de maternité et parentales | Validation des renseignements sur les prestations de maternité/parentales |
``` 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0814.dita`

Remarque :

Si la demande n’inclut pas la Déclaration d’une tierce personne et attestation, les sections suivantes doivent être incluses :

- Droits et responsabilités

- Attestation 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0815.dita`

Remarque :

Généralement, la demande d’AE la plus récente (demande initiale ou renouvelée) est suffisante, à moins qu’un historique plus complet de la demande soit nécessaire. Dans de tels cas, toutes les demandes pertinentes (initiales et renouvelées) doivent être incluses. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0816.dita`

Remarque :

Au besoin, l’agent inclut toujours les transcriptions et les certifications nécessaires. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0817.dita`

Remarque :

L’agent doit également biffer les renseignements qui ne sont pas liés au litige en appel et qui ne doivent pas être communiqués à l’employeur. Si cela est justifié, l’agent peut créer des dossiers de révision distincts. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0818.dita`

Remarque :

Les documents liés à l’enquête qui a été effectuée par la suite constituent la meilleure preuve. Le rapport du Programme d’avis d’embauche peut être nécessaire s’il s’agit de la seule preuve obtenue de l’employeur. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0819.dita`

Remarque :

L’agent s’assure que le texte automatique reg56 est ajouté aux argumentations chaque fois que la question faisant l’objet de l’appel concerne un T-P et une défalcation. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0820.dita`

Remarque :

Dans les situations suivantes, il y a une exception pour les RSDP et RD liés à une défalcation :

- Révision en vertu la LAE 112 : Le dossier de révision envoyé au client à la suite d’une décision défavorable en vertu de la LAE 112 ne contient pas les évaluations du RAE 56 , sauf si le client a formellement demandé une défalcation.
         [RAE 56](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-56.html)

- Appel au TSS : Le dossier de révision pour les appels au TSS en vertu de la LAE 113 contient les évaluations du RAE 56 , que le client ait demandé ou non une défalcation.
         [RAE 56](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-56.html)

     [RAE 56](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-56.html) 
     [RAE 56](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-56.html) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0821.dita`

Remarque :

Il y a une exception. Pour plus de renseignements, l’agent passe à Le litige en appel est lié à un motif de cessation d’emploi (MCE) .
       [Le litige en appel est lié à un motif de cessation d’emploi (MCE)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#MCE)

     [Le litige en appel est lié à un motif de cessation d’emploi (MCE)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#MCE) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0822.dita`

Remarque :

Il est rare que le litige en appel soit un calcul du T-P. La décision qui a entraîné le T-P est probablement le litige en appel. L’agent doit toujours fournir une explication du calcul du T‑P dans l’argumentation et appuyer l’explication avec l’Avis de dette (pour des T‑P simples) ou l’Avis de dette et la répartition du T‑P dans tous les autres cas. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0823.dita`

Remarque :

Si un T-P résulte d’une décision rétroactive liée au MCE et que l’employeur est une partie intéressée, l’agent ne doit pas inclure la copie de l’Avis de dette ou une quelconque référence à un T-P, ces renseignements ne doivent pas être communiqués à l’employeur. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0824.dita`

Remarque :

Si le client interjette un appel à la fois du MCE et du T-P et que l’employeur est une partie intéressée, l’agent doit créer un dossier de révision distinct pour chaque litige. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0825.dita`

Remarque :

Quand un employeur ou une autre personne conteste l’imposition d’une pénalité, selon la LAE 39 , le dossier de révision comprend uniquement les documents liés à la décision contestée. Généralement, les demandes de prestations présentées par les clients ne sont pas incluses.
       [LAE 39](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/page-11.html#h-18)

     [LAE 39](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/page-11.html#h-18) 
