# Code d’accès

Source map: `fr_FR/activity/access_code/access_code.ditamap`

## Sommaire

Source topic: `fr_FR/activity/access_code/sommaire.dita`

Sommaire : Pour assurer la confidentialité des renseignements concernant une demande de prestations, le système émet un code d’accès. Ce code d’accès figure sur le premier relevé de prestations envoyé au client. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/access_code/ce_quil_faut_savoir.dita`

### Untitled section

Source topic: `fr_FR/activity/access_code/untitled_section.dita`

[Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0001.dita) 

- **Alerte COVID-19 — Mise à jour le 24 mars 2021 (Choisir pour plus de détails)**

           [Danger](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0002.dita) 

### Fonctionnalité du code d’accès

Source topic: `fr_FR/activity/access_code/fonctionnalite_du_code_dacces.dita`

Le NAS et le code d’accès permettent au client :

- d’obtenir des renseignements personnels au sujet de sa demande de prestations par l’un des services suivants :

- MDSC-AE

- le Service d’information par téléphone (SIT)

- un Centre Service Canada

- de remplir des déclarations électroniques du prestataire à l’aide du SDT ou du SDI.

     [Avertissement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0003.dita) 

### Remplacer un code d’accès

Source topic: `fr_FR/activity/access_code/remplacer_un_code_dacces.dita`

Un client peut remplacer son propre code d’accès à l’aide du SIT. Quand un client perd ou oublie son code d’accès, il ne peut plus accéder au SIT ni remplir des déclarations électroniques du prestataire. Toutefois, un agent de Service Canada peut remplacer le code d’accès original ou émettre un code d’accès temporaire. Transmettre de nouveau le code d’accès original ou un émettre code d’accès temporaire redonne automatiquement accès au client à ces services. 

### Vérification de sécurité détaillée

Source topic: `fr_FR/activity/access_code/verification_de_securite_detaillee.dita`

Une vérification de sécurité détaillée doit être menée auprès du client avant de lui fournir des renseignements ou d’émettre un code d’accès. L’agent n’accepte pas de demande de code d’accès de la part d’une tierce personne, à moins qu’il s’agisse d’un représentant autorisé. S’il s’agit d’un représentant, l’agent s’assure qu’il n’y a pas de document électronique indiquant que le client est rétabli et n’a plus besoin des services d’un représentant. Dans ETI, l’indicateur « /REP/ » est inscrit à côté du nom des représentants. Pour plus de renseignements, consulter Désignation d’un représentant — Capacité physique ou mentale limitée .
       [Désignation d’un représentant — Capacité physique ou mentale limitée](/fr/procedure/activity/app_rep.shtml) 

### Émettre un code d’accès original ou temporaire

Source topic: `fr_FR/activity/access_code/emettre_un_code_dacces_original_ou_temporaire.dita`

Après avoir effectué la vérification de sécurité détaillée, l’agent émet le code d’accès original et l’envoie par la poste. Cependant, si une déclaration du prestataire est en retard ou imminente (dans les 5 prochains jours ouvrables), l’agent émet un code d’accès temporaire qui doit être remplacé par le client en communiquant avec le SIT. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0001.dita`

Remarque :

Les agents qui ont suivi la formation de Cúram Universal Access consultent les procédures relatives à Cúram .
       [procédures relatives à Cúram](/fr/procedure/generic/procedure-relatives-curam-curam-procedures.shtml)

Une demande dans Cúram peut être repérée dans ETI au moyen d’une icône de verrou (l’indicateur de la demande dans Cúram) trouvée à côté du NAS du client.

     [procédures relatives à Cúram](/fr/procedure/generic/procedure-relatives-curam-curam-procedures.shtml) 

### Danger

Source topic: `fr_FR/common_notes/note_c_0002.dita`

Cette page est touchée par les mesures spéciales liées à la COVID-19. Les changements liées à la COVID-19 ne sont pas en surbrillance. Pour plus de renseignements, l’agent consulte la page Mises à jour et Nouvelles appropriée.

- 24 mars 2021 — Cette procédure a été mise à jour pour inclure les demandes d’AE frauduleuses ( plus de renseignements ).
         [plus de renseignements](/fr/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml)

     [plus de renseignements](/fr/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Avertissement

Source topic: `fr_FR/common_notes/note_c_0003.dita`

Avertissement :

Si des activités frauduleuses sont soupçonnées dans une demande d’AE ou pour la prestation d’AE d’urgence (PU AE), l’agent n’ émet pas le code d’accès. Pour plus de renseignements, l’agent consulte Déterminer si une question doit être renvoyée à Intégrité .
       [Déterminer si une question doit être renvoyée à Intégrité](/fr/procedure/task/determining_issue_referred_integrity.shtml)

     [Déterminer si une question doit être renvoyée à Intégrité](/fr/procedure/task/determining_issue_referred_integrity.shtml) 

## Considérations régionales

Source topic: `fr_FR/activity/access_code/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/access_code/ce_quil_faut_chercher.dita`

### Dans SNCT :

Source topic: `fr_FR/activity/access_code/dans_snct.dita`

- Quels renseignements personnels le client a-t-il saisis à la section Renseignements personnels de sa demande? 

### Dans ETI :

Source topic: `fr_FR/activity/access_code/dans_eti.dita`

- S’agit-il d’une nouvelle demande qui n’a pas été enregistrée?

- Les renseignements personnels du client sont-ils disponibles?

- Le client doit-il produire une déclaration du prestataire dans les 5 prochains jours ouvrables? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/access_code/que_voulez-vous_faire.dita`

## Référence de politique

Source topic: `fr_FR/activity/access_code/reference_de_politique.dita`

 
