# Cours de formation

Source map: `fr_FR/activity/training/training.ditamap`

## Sommaire

Source topic: `fr_FR/activity/training/sommaire.dita`

Sommaire : Un client peut déclarer qu’il suit une formation à tout moment au cours d’une demande active, et une décision est requise pour déterminer s’il a droit à des prestations pendant la période de formation. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/training/ce_quil_faut_savoir.dita`

### Formation déclarée entre le 27 septembre 2020 et le 11 septembre 2021

Source topic: `fr_FR/activity/training/formation_declaree_entre_le_27_septembr_ec9578e3.dita`

Une mesure de transition, en vertu de laquelle TAD rendait une décision automatiquement et autorisait toute formation depuis le 27 septembre 2020, a pris fin le 11 septembre 2021.

Cette mesure visait à éviter tout retard de paiement aux clients qui déclaraient avoir suivi une formation. Les clients doivent pouvoir démontrer qu’ils sont capables et disponibles pour travailler tout en suivant un cours de formation non dirigé.

Service Canada a le pouvoir d’imposer une inadmissibilité 3 - Non disponible (D3) rétroactive si le client n’est pas capable de démontrer sa disponibilité, même si TAD a initialement autorisé la formation. Par conséquent, si le client déclare ne pas être disponible alors qu’il suivait un cours de formation non dirigé, et que des prestations ont précédemment été payées pour cette période, l’agent examine la disponibilité du client. Quand l’agent de Niveau 2 détermine que le client n’a pas démontré sa disponibilité à partir de la date de début du cours, l’agent impose une inadmissibilité D3 rétroactive. L’agent consulte AP 2020-05 —Dispositions de transition pour la prestation d’urgence , ainsi que le GDA 10.3 — Crédibilité et 10.12 — Formation et mesure d’emploi pour plus de renseignements sur la disponibilité.
       [AP 2020-05 —Dispositions de transition pour la prestation d’urgence](/fr/policy/bememo/be2020-05.shtml) 
       [10.3 — Crédibilité](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-10/credibilite.shtml#a10_3_0) 
       [10.12 — Formation et mesure d’emploi](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-10/formation-mesures-demploi.html)

Pour des prestations spéciales, le client doit encore remplir les conditions d’admissibilité pour le genre de prestations (GP) demandé pendant qu’il suit un cours de formation non dirigé. Un client qui suit un cours de formation non dirigé peut fournir des renseignements dans une déclaration du prestataire ou lors d’une conversation avec un agent qui remettent en question son admissibilité aux prestations spéciales. Dans ce cas, l’agent crée un AT pour la question de la formation et suit les procédures de décision normales, même si TAD a initialement permis la formation. 

### Genres de cours de formation

Source topic: `fr_FR/activity/training/genres_de_cours_de_formation.dita`

Il y a 3 principales catégories de formation aux fins de l’AE :

- Le cours de formation non dirigé est un cours ou un programme d’études suivi à l’initiative du client, sans l’approbation ou la recommandation d’une autorité désignée. La formation peut être offerte par un collège, une université ou tout autre fournisseur de formation.

- Le cours de formation dirigé est un cours ou un programme d’études suivi par le client, ou une participation à toute autre activité d’emploi qui est recommandé par une autorité désignée (provinces, territoires ou Service Canada) en vertu de LAE 25 . Le client doit fournir les renseignements suivants :

- le nom et les coordonnées du conseiller en formation ou de l’autorité désignée;

- les dates de début et de fin du cours de formation dirigé

- le nom de l’école ou de l’établissement de formation

         [LAE 25](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-25.html)

- La formation en apprentissage est un programme de formation officiel d’acquisition de compétences dans un métier, qui consiste à allier des périodes de formation en cours d’emploi et de formation en salle de classe et qui mène à la certification de compagnon. Le client doit fournir les renseignements suivants :

- le code de référence à 16 caractères servant à identifier la formation en apprentissage

- les dates de début et de fin de la formation

- le nom de l’école ou de l’établissement de formation

La formation doit être classée avec exactitude pour s’assurer que l’admissibilité du client aux prestations a été déterminée correctement. Quand le client déclare qu’il a été dirigé vers une formation, mais qu’il n’a pas fourni les renseignements requis, l’agent effectue un recueil de faits pour confirmer que le client a réellement été dirigé vers cette formation et obtenir les renseignements manquants. 

### Cours de formation non dirigé

Source topic: `fr_FR/activity/training/cours_de_formation_non_dirige.dita`

La participation à un cours de formation non dirigé peut avoir une incidence sur le fait qu’un client remplisse ou non les conditions d’admissibilité aux GP suivants :

- prestations régulières

- prestations de maladie

- prestations parentales

- PDC

- prestations pour proches aidants

La participation à un cours de formation non dirigé n ’a pas d’incidence sur l’admissibilité d’un client aux prestations de maternité . Il faut cependant suivre les procédures appropriées pour s’assurer que les documents pertinents sont versés au dossier et que la demande est traitée correctement. S’il s’agit d’une demande de PDC ou uniquement de prestations de maternité, un questionnaire électronique n’ est pas créé dans AW quand le client déclare participer à une formation. En plus, MDSC-AE n’affiche pas de lien au questionnaire électronique sur la formation. Par conséquent, on apprend que le client participe à une formation seulement s’il fournit de la documentation ou un questionnaire sur la formation, ou s’il s’adresse directement à un agent.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0161.dita) 

S’il s’agit d’une demande combinée de prestations parentales et de maternité, le questionnaire est créé, et l’agent doit déterminer si le cours de formation a lieu seulement pendant la période de maternité.

Quand des clients recevant des prestations régulières déclarent qu’ils ne sont pas disponibles pour travailler et qu’ils ne souhaitent pas recevoir des prestations d’AE pour la période du cours non dirigé, un agent de Niveau 1 peut imposer une inadmissibilité D3 si :

- la formation est offerte à temps plein pendant des jours de semaine consécutifs pour une période allant jusqu’à 2 semaines

- le client convient qu’aucune prestation ne peut être versée

Quand les clients déclarent qu’ils ne sont pas disponibles pour travailler et ne conviennent pas qu’aucune prestation ne peut être versée, un agent de Niveau 2 doit examiner l’admissibilité.

Un client pourrait déclarer une formation en cours d’emploi reçue par l’entremise d’un employeur :

- Si le client reçoit un salaire de base pour la formation, il s’agit d’une formation en cours d’emploi qui n’est pas évaluée comme un cours de formation non dirigé. Le client doit déclarer le nombre d’heures et la rémunération dans la déclaration du prestataire et ne devrait pas déclarer ces heures comme une formation.

- Si le client ne reçoit pas de salaire pour la formation, il s’agit d’un cours de formation non dirigé qui doit faire l’objet d’une évaluation selon le GP.

Les clients qui déclarent un séjour hors Canada alors qu’ils participent à un cours de formation non dirigé, incluant des périodes où une partie de la formation est en dehors du Canada, doivent répondre aux conditions d’admissibilité afin de recevoir des prestations tout en étant à l’extérieur du Canada. Consulter Hors Canada pour déterminer l’admissibilité d’un client lors d’un séjour hors Canada.
       [Hors Canada](/fr/procedure/activity/out_canada.shtml)

**Initiatives ciblées et cours de formation à court terme**

Les clients qui ont perdu leur emploi ou qui n’ont pas fait partie de la population active pendant une longue période peuvent participer à une initiative ciblée pour les aider à retourner au travail. Les clients peuvent également suivre un cours de formation à court terme pour augmenter leur employabilité sur le marché du travail.

Bien que les initiatives ciblées ne soient pas des cours de formation, les agents établissent la disponibilité d’un client de la même manière qu’avec un client qui suit un cours de formation non dirigé.

Les cours de formation à court terme désignent les cours qui sont offerts dans la région du client. Ils ont pour but de perfectionner les compétences d’un client pour un emploi existant ou d’augmenter l’employabilité d’un client sur le marché du travail. Dans certaines situations, les différentes provinces créent des cours de formation à court terme spéciaux pour aider à développer certaines régions du marché du travail. Ces cours de formation peuvent être approuvés selon des critères particuliers qui sont communiqués quand les cours de formation sont disponibles.

Comme l’objectif des initiatives ciblées et des cours de formation à court terme est d’aider un client à réintégrer le marché du travail, l’agent est plus tolérant quand il rend une décision sur la disponibilité d’un client qui participe à un cours.

L’agent consulte l’outil de travail pour obtenir la liste complète des initiatives ciblées et cours de formation à court terme non dirigés.
       [l’outil de travail](/fr/procedure/generic/additionalresources/shortterm_courses_ti.shtml) 

### Cours de formation dirigé

Source topic: `fr_FR/activity/training/cours_de_formation_dirige.dita`

Le gouvernement du Canada collabore avec les provinces et les territoires pour offrir des programmes d’emploi connus sous le nom de prestations d’emploi et mesures de soutien. Les ententes sur le développement du marché du travail (EDMT) avec la Commission de l’assurance-emploi du Canada définissent le niveau de responsabilité assumé par chaque province ou territoire pour la prestation de ces programmes.
       [Commission de l’assurance-emploi du Canada](https://www.canada.ca/fr/emploi-developpement-social/ministere/portefeuille/commission-assurance-emploi.html)

Les EDMT varient selon les provinces et les territoires. Chaque entente décrit les responsabilités des parties concernées et la façon dont les fonds sont administrés.

Le Programme de formation pour les compétences et l’emploi destiné aux Autochtones permet à divers groupes autochtones d’offrir des programmes d’emploi en lien avec la formation à des membres des communautés autochtones.

Pour qu’elle soit considérée comme une formation approuvée, la formation doit être approuvée par une autorité désignée.

Le module AccèsEDMT du SIPAE est utilisé par l’autorité désignée de la province, le territoire ou le Programme de formation pour les compétences et l’emploi destiné aux Autochtones afin d’obtenir l’état des prestations d’AE du client, de saisir les renseignements sur le cours de formation dirigé ou, dans certains cas, d’indiquer l’intention de diriger le client à l’avenir. L’agent consulte l’Avis d’intention et les renseignements sur la formation proposée dans le module AccèsEDMT . Si le client reçoit des prestations spéciales et qu’il est approuvé en vertu de LAE 25 , l’autorité désignée ne peut pas saisir les renseignements sur le renvoi et doit employer des moyens de communication alternatifs.
       [AccèsEDMT](https://sipae-eibis.service.gc.ca/) 
       [LAE 25](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-25.html)

L’initiative Action Compétences (aussi appelée l’initiative sur la formation continue) permet aux travailleurs de longue date de continuer à recevoir leurs prestations d’AE tout en suivant à leurs frais une formation à temps plein (p. ex. des cours, des programmes d’enseignement et des formations en personne ou virtuelles) pour améliorer leurs qualifications et leurs compétences. Cette initiative permanente s’applique aux clients suivant une formation en date du 5 août 2018 ou après.

Quand un client demande la permission de suivre une formation, l’agent traite cette demande comme si le client demandait à être dirigé vers une formation en vertu de LAE 25 .
       [LAE 25](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-25.html)

S’il est dirigé vers une formation par Service Canada ou par la province ou le territoire dans le cas d’une EDMT, selon la LAE 25 , le client est considéré comme une personne sans emploi, qui est capable de travailler et disponible à cette fin pendant qu’il participe à la formation. En ce qui concerne les prestations spéciales, le client peut continuer de recevoir des prestations spéciales pendant qu’il suit un cours de formation dirigé tant que le client continue de remplir les conditions d’admissibilité pour les prestations spéciales demandées.
       [LAE 25](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-25.html)

Quand une autorité provinciale désignée autorise un client à quitter son emploi pour suivre une formation approuvée, le client reçoit un formulaire intitulé « Demande d’autorisation de quitter un emploi » qu’il doit présenter en même temps que sa demande de prestations d’AE.

**Travailleurs de longue date**

Un client qui déclare suivre une formation à temps plein peut être désigné comme un travailleur de longue date. Si les conditions requises sont remplies, un client qui est désigné comme un travailleur de longue date et qui souhaite suivre une formation à ses frais à temps plein peut être dirigé vers cette formation par Service Canada.

Pour être considéré comme un travailleur de longue date, le client doit remplir les 2 conditions suivantes :

- avoir payé au moins 30 % des cotisations maximales d’AE pendant au moins 7 des 10 dernières années;

- ne pas avoir reçu plus de 35 semaines de prestations régulières au cours des 156 dernières semaines (3 ans) avant le DPP de la demande actuelle.

Service Canada a l’autorité d’autoriser une formation à temps plein pour un travailleur de longue date. Cependant, avant de rendre une décision sur la formation, l’agent rend une décision sur d’autres questions litigieuses pour déterminer si le client est admissible aux prestations. Cela peut aider le client à mieux comprendre le processus décisionnel, car le client peut supposer que dans une situation de cours de formation dirigé, les questions litigieuses sont automatiquement autorisées.

Quand un client est désigné comme un travailleur de longue date, l’agent consulte la procédure appropriée pour rendre une décision sur une formation pour un travailleur de longue date.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0162.dita) 

**Programme prestations d’emploi pour travailleurs indépendants**

Tout cours de formation qu’un client suit pendant qu’il prend part au Programme prestations d’emploi pour travailleurs indépendants est considéré comme une partie intégrante du programme. Aucune décision ne doit être rendue. On informe le client de ne pas déclarer de cours de formation sur ses déclarations du prestataire pendant qu’il participe au programme. Seuls les renseignements relatifs au Programme prestations d’emploi pour travailleurs indépendants sont indiqués à l’onglet Projet dans ETI. 

### Formation en apprentissage

Source topic: `fr_FR/activity/training/formation_en_apprentissage.dita`

L’apprentissage est un programme officiel d’acquisition de compétences dans un métier, qui consiste à allier des périodes de formation en cours d’emploi et de formation en salle de classe et qui mène à la certification de compagnon.

Les provinces et les territoires ont leur propre bureau gouvernemental qui supervise la formation en apprentissage et la certification au sein de leur administration. Habituellement, les apprentis inscrits occupent déjà un emploi à temps plein ou à temps partiel auprès d’un employeur ou d’un syndicat qui accepte de les parrainer et de les former comme des apprentis dans un métier spécialisé en particulier.

Les clients doivent être dirigés vers une formation en apprentissage par une autorité désignée.

Un client peut être un apprenti inscrit auprès de la direction de l’apprentissage de sa province ou de son territoire ou être dirigé vers une formation par une autorité provinciale désignée. Quand une autorité provinciale désignée autorise un client à quitter son emploi pour suivre une formation en apprentissage, le client reçoit un formulaire intitulé « Demande d’autorisation de quitter un emploi » qu’il doit présenter en même temps que sa demande de prestations d’AE.

Quand un client est dirigé vers une formation en apprentissage et qu’il est inscrit à une séance de formation, un code de référence à 16 caractères est fourni par Service Canada ou la province dans le cas d’une EDMT, ou une autorité désignée (direction de l’apprentissage de la province). Ce code doit être utilisé pour présenter une demande de prestations d’AE. Quand le code de référence est saisi, un formulaire de demande spécialisée s’affiche, ce qui permet au TAD de saisir les renseignements sur la formation en apprentissage à l’ onglet Projet dans ETI. Pour déterminer si une demande peut être automatisée, le TAD vérifie aussi si le motif de cessation d’emploi (MCE) dans le RE est J - Formation en apprentissage ou A - Manque de travail . 

### Fin du cours de formation

Source topic: `fr_FR/activity/training/fin_du_cours_de_formation.dita`

Il faut examiner l’admissibilité du client à des prestations à la fin de la formation non approuvée. Une décision pourrait devoir être rendue. Si une inadmissibilité pour une période indéterminée a été imposée pendant la période de formation, il faudra peut-être y mettre fin.

La formation dirigée est approuvée pour une période déterminée et l’autorité désignée fixe la date de fin. Si le client arrête de suivre le cours avant la date de fin sans avoir obtenu l’approbation de l’autorité désignée, il faut examiner l’admissibilité du client à des prestations.

À la fin de la formation en apprentissage, il faut examiner l’admissibilité du client à des prestations, car les clients sont habituellement des employés qui quittent temporairement leur emploi pour suivre la formation en apprentissage. On suppose que les clients retourneront travailler pour l’employeur le plus récent à la fin de la formation. Si le client ne retourne pas travailler, une conversion pourrait être nécessaire. Consulter Conversion et renouvellement .
       [conversion](/fr/procedure/activity/conversions.shtml) 
       [Conversion et renouvellement](/fr/procedure/activity/conversions.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0161.dita`

Remarque :

S’il s’agit d’une demande de PDC, l’agent ne peut pas actuellement créer un AT Litige - Décision (DEC) Formation. Quand le client qui reçoit des PDC déclare une formation, l’agent crée un AT DEC Disponibilité et indique dans le champ Détails que le litige concerne réellement la formation. Cette solution de contournement s’applique jusqu’à ce qu’une mise à jour du système soit effectuée pour permettre :

- au client de déclarer une formation dans sa demande d’AE;

- au client de remplir un questionnaire électronique sur un cours de formation pour une demande de PDC;

- à l’agent de créer un AT DEC Formation dans une demande de PDC. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0162.dita`

Remarque :

Pour déterminer si un client est un travailleur de longue date, l’agent consulte Déterminer si un client est un travailleur de longue date .
       [Déterminer si un client est un travailleur de longue date](/fr/procedure/task/det_client_ltw.shtml)

     [Déterminer si un client est un travailleur de longue date](/fr/procedure/task/det_client_ltw.shtml) 

## Considérations régionales

Source topic: `fr_FR/activity/training/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/training/ce_quil_faut_chercher.dita`

### Dans ETI :

Source topic: `fr_FR/activity/training/dans_eti.dita`

- Quel est le GP?

- S’agit-il d’une demande initiale, renouvelée ou continue?

- Y a-t-il des renseignements sur la formation à l’onglet Projet ? 

### Dans SNCT :

Source topic: `fr_FR/activity/training/dans_snct.dita`

- Y a-t-il un AT DEC (demande initiale ou renouvelée) ou un AT Révision de la demande (RVD) (demande continue) pour la question de la formation?

- Y a-t-il un code de référence valide dans la demande de prestations d’AE ou dans tout RSDP ou AT?

- Y a-t-il des AT, RSDP ou RD indiquant le genre de formation (dirigé, pour les travailleurs de longue date, non dirigé ou apprentissage)? 

### Dans MSRE :

Source topic: `fr_FR/activity/training/dans_msre.dita`

- Le MCE sur le RE est-il J - Apprenti ou A - Manque de travail ? 

### Dans Imagerie :

Source topic: `fr_FR/activity/training/dans_imagerie.dita`

- Y a-t-il des documents en lien avec la formation? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/training/que_voulez-vous_faire.dita`

## Référence de politique

Source topic: `fr_FR/activity/training/reference_de_politique.dita`

 
