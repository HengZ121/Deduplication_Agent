# Congé autorisé

Source map: `fr_FR/activity/leave_absence/leave_absence.ditamap`

## Sommaire

Source topic: `fr_FR/activity/leave_absence/sommaire.dita`

Sommaire : Quand un client prend volontairement un congé autorisé, son admissibilité aux prestations régulières peut être touchée. Une décision est requise pour déterminer si le client avait un motif valable pour prendre un congé autorisé de son emploi. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/leave_absence/ce_quil_faut_savoir.dita`

### Congé autorisé

Source topic: `fr_FR/activity/leave_absence/conge_autorise.dita`

Un congé autorisé est une période d’absence du travail prévue, non payée et autorisée par l’employeur, avec une date de fin ou de retour au travail (RAT). Un congé autorisé est différent des autres périodes d’absence du travail (p. ex. congé de maladie, vacances, congé parental, réaménagement des horaires de travail) puisqu’il est considéré comme une circonstance exceptionnelle plutôt qu’un avantage ou un horaire de travail normal.

Le congé autorisé peut survenir dans une demande initiale, renouvelée ou continue.

Les clients sont chargés de déclarer en temps opportun tout congé autorisé d’un emploi pendant une période de prestations.

Le genre de la demande (GD) détermine le genre d’AT créé pour la question du congé autorisé et les mesures à prendre au moment qu’une décision sur la question doit être rendue. Dans le cas d’une demande initiale ou renouvelée, un AT Litige - Décision (DEC) est créé pour la question du congé autorisé. Dans le cas d’une demande continue, la question du congé autorisé est indiquée dans un AT Révision de la demande (RVD) révisée ou un AT Action à prendre (AP). 

### Rendre une décision sur un congé autorisé

Source topic: `fr_FR/activity/leave_absence/rendre_une_decision_sur_un_conge_autorise.dita`

Les clients qui ne travaillent pas parce qu’ils ont demandé un congé autorisé et qu’il a été accepté sont considérés comme étant temporairement en chômage. Les raisons pour demander le congé autorisé sont assujetties aux mêmes conditions qu’un départ volontaire, car ce sont les actions du client qui provoquent la période de chômage.

L’agent doit déterminer si le client avait un motif valable pour le congé autorisé volontaire.

Il n’y a pas de décision automatisée pour la question du congé autorisé.

**Motif valable**

Un motif est valable si, une fois tous les facteurs pris en compte, le client n’avait aucune autre solution raisonnable que de prendre un congé autorisé de son emploi.

Quand le client a un motif valable pour le congé autorisé, l’agent examine sa disponibilité.

**Aucun motif valable**

Puisque le congé autorisé est une situation temporaire, si l’agent détermine que le client n’avait pas de motif valable pour le congé autorisé, une inadmissibilité est imposée plutôt qu’une exclusion. L’inadmissibilité 43 - Congé sans solde d’un emploi sans motif valable (D43) est imposée afin d’indiquer qu’il s’agit d’un congé autorisé sans motif valable. Si les conditions précédentes pour terminer l’inadmissibilité n’ont pas été remplies à la fin de la demande, l’inadmissibilité est reportée à la prochaine période de prestations (PP).

Quand le client n’a pas de motif valable pour le congé autorisé, des prestations spéciales sont payables pendant un congé non payé. 

### Disponibilité pendant un congé autorisé

Source topic: `fr_FR/activity/leave_absence/disponibilite_pendant_un_conge_autorise.dita`

S’il demande des prestations régulières, le client doit être capable de travailler et disponible pour le faire afin d’être considéré comme admissible. Toutefois, s’il demande des prestations de maladie, le client doit être autrement disponible pour être considéré comme admissible. Si le client n ’est pas autrement disponible, l’agent examine sa disponibilité. 

### Niveaux de décision

Source topic: `fr_FR/activity/leave_absence/niveaux_de_decision.dita`

Quand des conditions précises sont remplies, l’agent de Niveau 1 peut rendre une décision et autoriser un congé autorisé dans une demande initiale. Quand l’agent de Niveau 1 ne peut pas rendre une décision sur la question, les faits sont consignés et le motif de cessation d’emploi (MCE) est renvoyé au Niveau 2 pour décision.

Un RE n’est pas requis pour rendre une décision sur un congé autorisé. 

### Terminer une inadmissibilité Congé sans solde d’un emploi sans motif valable (D43)

Source topic: `fr_FR/activity/leave_absence/terminer_une_inadmissibilite_conge_sans_8ff3e566.dita`

Quand des conditions précises sont remplies, l’agent de Niveau 1 peut terminer une inadmissibilité D43 dans une demande renouvelée.

Quand un client en congé autorisé quitte volontaire son emploi, est congédié ou est mis à pied en raison d’un manque de travail, l’inadmissibilité D43 est terminée le jour avant la date au cours de laquelle la relation entre l’employeur et l’employé prend fin. 

### Rendre une décision sur un motif de cessation d’emploi (MCE) après un congé autorisé

Source topic: `fr_FR/activity/leave_absence/rendre_une_decision_sur_un_motif_de_ces_9b3455a1.dita`

Quand un client quitte son emploi ou est congédié après un congé autorisé, l’admissibilité aux prestations régulières peut être touchée. Une décision est requise pour déterminer si le client est admissible aux prestations. 

### Traiter un AT Litige - Décision (DEC) quand l’emploi n’est pas assurable

Source topic: `fr_FR/activity/leave_absence/traiter_un_at_litige_-_decision_dec_qua_55eaf517.dita`

Une décision sur le congé autorisé n’ est pas requise si l’emploi n’est pas assurable, car soit le client est embauché en vertu d’un contrat de service (travailleur indépendant), soit le client détient plus de 40 % des actions de l’entreprise. Si les faits au dossier indiquent clairement que l’emploi n’est pas assurable pour l’une de ces raisons, l’AT DEC ne doit pas être complété. L’agent suit les Procédures et conditions pour retirer les demandes du processus du TAD . L’agent déplace l’AT DEC vers En suspens jusqu’à ce que l’AT Évaluation de la demande (EVD) ou l’AT Demande spécialisée (DS) soit créé. Un utilisateur autorisé doit ensuite supprimer l’AT DEC.
       [Procédures et conditions pour retirer les demandes du processus du TAD](https://esdc.prv/fr/service-canada/ae/technologies/tad/index.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0126.dita) 

Même si la décision sur le congé n’est pas rendue, l’agent doit être attentif aux problèmes potentiels de disponibilité. 

### Motif de cessation d’emploi (MCE) — Mesures temporaires du budget

Source topic: `fr_FR/activity/leave_absence/motif_de_cessation_demploi_mce__mesures_fe447e72.dita`

**Rendre une décision sur la dernière période d’emploi dans la période de référence — DPP entre la s/c 2310 et la s/c 2361**

Le budget 2021 a introduit une mesure de simplification temporaire à partir du 26 septembre 2021. Pour les demandes dont le DPP est entre la s/c 2310 et la s/c 2361, l’agent rend une décision sur la dernière période d’emploi dans la PR seulement si elle est litigieuse. Si l’agent autorise le dernier MCE, tout autre RE dans la PR, même s’il est litigieux, est utilisé pour calculer la demande. Cependant, si l’agent n’autorise pas le MCE du dernier RE dans la PR, la demande est calculée avec une exclusion.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0081.dita) 

Cette nouvelle mesure ne s’applique pas aux demandes pour travailleurs indépendants et de pêcheur. Si le client qui demande des prestations pour travailleurs indépendants ou de pêcheur a un DPP dans la s/c 2310 ou après, un emploi assurable dans la PR et des RE litigieux, une décision doit être rendue sur ces RE selon les procédures habituelles.

Quand le client déclare un MCE litigieux auprès d’autres employeurs dans la même demande, si TAD n’autorise pas le litige en vertu des règles de décision automatique, le litige est automatiquement résolu et TAD crée un rapport de décision (RD) qui indique Aucune décision requise . La case Condition spéciale du RE n’est pas mise à jour, et le RE est inclus dans le calcul. Aucun AT DEC n’est créé pour le MCE.

Quand il y a plus d’un RE avec le même dernier jour payé (DJP), et qu’une des RE est litigieux alors que l’autre RE ne l’est pas, une décision n’est pas requise et les 2 RE seront inclus dans le calcul.

**Décision non requise : Motif de cessation d’emploi (MCE) au-delà de 12 semaines — DPP entre la s/c 2258 et la s/c 2309**

Les principes de décision dans les demandes initiales ou de nouveau calcul dont le DPP est entre la s/c 2258 et la s/c 2309 s’appliquent seulement au MCE du dernier emploi dans la PR et aux questions liées aux MCE litigieux qui sont dans la période de 12 semaines avant l’A de R utilisé pour établir la demande.

**Décision non requise antérieurement — Processus spécialisé du TAD**

Un nouveau processus spécialisé qui simplifie le traitement des demandes initiales a été présenté le 27 septembre 2020. Les demandes traitées dans ce processus spécialisé du TAD ont été établies sans rendre de décision sur les questions litigieuses liées au MCE dans la période de référence (PR). Il est possible de repérer les questions liées au MCE pour lesquels aucune décision n’a été rendue, car la case Condition spéciale a été laissée vide dans le RE, mais le RE a tout de même été inclus dans le calcul initial.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0092.dita) 

Si aucune décision n’a été rendue sur un MCE litigieux dans la PR dans une demande initiale de prestations régulières lors du processus spécialisé du TAD, il n’est pas nécessaire de rendre une décision sur la demande renouvelée tant que le client demande toujours des prestations régulières. Cependant, il pourrait y avoir un AT DEC en suspens.

S’il existe un AT DEC en suspens pour un MCE litigieux dans la PR, l’agent ne rend pas de décision sur la question. Pour supprimer l’AT DEC en suspens, l’agent envoie une demande à un utilisateur autorisé afin qu’il le supprime.

S’il existe un AT EVD Renouvellement et un AT DEC en suspens pour un MCE litigieux dans la PR, l’agent de Niveau 1 traite l’AT EVD Renouvellement même si l’AT DEC demeure en suspens. L’agent :

- détermine la date d’entrée en vigueur du renouvellement;

- saisit le renouvellement et complète le numéro d’enregistrement;

- complète l’AT EVD Renouvellement.

L’agent complète l’AT EVD Renouvellement avant d’envoyer une demande à un utilisateur autorisé afin qu’il supprime l’AT DEC en suspens.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0127.dita) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0126.dita`

Remarque :

Cela ne s’applique pas aux situations où l’emploi n’est pas assurable en raison d’une question de lien de dépendance. Dans ces situations, il faut rendre une décision sur le congé. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0081.dita`

Remarque :

Pour toutes les demandes initiales dont le DPP provisoire est la s/c 2361, des AT DEC sont créés pour la dernière période d’emploi et pour toute autre période d’emploi litigieuse dans la PR. L’agent suit les procédures habituelles pour rendre une décision sur ces AT, car le DPP final peut être la s/c 2362 ou après. Toutefois, si le DPP final est entre la s/c 2310 et la s/c 2361, le système applique les mesures temporaires du budget 2021. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0092.dita`

Remarque :

Le processus spécialisé du TAD se termine le 16 août 2021. À partir de cette date, TAD crée un AT DEC pour les questions litigieuses liées aux MCE dans la PR, puisqu’il n’établit plus de demandes sans rendre de décision sur celles-ci. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0127.dita`

Remarque :

Une décision doit être rendue pour toute question litigieuse liée au MCE dans la PP. 

## Considérations régionales

Source topic: `fr_FR/activity/leave_absence/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/leave_absence/ce_quil_faut_chercher.dita`

### Dans SNCT :

Source topic: `fr_FR/activity/leave_absence/dans_snct.dita`

- Y a-t-il des RSDP, des AT AP, d’autres AT ou des documents contenant des aide-mémoire ou d’autres précisions concernant le congé? 

### Dans Imagerie :

Source topic: `fr_FR/activity/leave_absence/dans_imagerie.dita`

- Y a-t-il des documents numérisés ayant trait à la demande de congé? (Les documents pourraient avoir été reçus avant que la présentation de la plus récente demande.) 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/leave_absence/que_voulez-vous_faire.dita`

## Référence de politique

Source topic: `fr_FR/activity/leave_absence/reference_de_politique.dita`

 
