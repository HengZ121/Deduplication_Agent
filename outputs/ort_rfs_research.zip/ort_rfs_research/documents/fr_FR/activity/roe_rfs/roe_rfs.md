# AT Évaluation du relevé d’emploi MCE litigieux

Source map: `fr_FR/activity/roe_rfs/roe_rfs.ditamap`

## Sommaire

Source topic: `fr_FR/activity/roe_rfs/sommaire.dita`

Sommaire : Lorsqu’on reçoit un RE qui présente un motif de cessation d’emploi (MCE) litigieux dans une demande électronique initiale, si le système ne peut pas créer de lien entre le RE et une période d’emploi déclarée dans la demande ou déterminer si le MCE doit faire l’objet d’une décision, le système crée un AT RE MCE litigieux. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/roe_rfs/ce_quil_faut_savoir.dita`

### Lier le RE et la période d’emploi correspondante

Source topic: `fr_FR/activity/roe_rfs/lier_le_re_et_la_periode_demploi_correspondante.dita`

Lorsqu’on reçoit un RE qui présente un MCE litigieux, le système vérifie s’il y a une période d’emploi déclarée dans la demande électronique initiale. Si oui, le système crée un lien entre RE et la période d’emploi correspondante et détermine s’il y a un rapport de décision (RD) pour le MCE litigieux ou un AT Litige – Décision (DEC) en suspens. 

### Système incapable de créer un lien

Source topic: `fr_FR/activity/roe_rfs/systeme_incapable_de_creer_un_lien.dita`

Le système crée un AT RE MCE litigieux quand il ne peut pas créer un lien entre le RE et une période d’emploi correspondante. De plus, le système crée un AT RE MCE litigieux quand il crée un lien entre le RE et la période d’emploi correspondante et lorsque les conditions suivantes sont remplies :

- il n’y a pas d’AT DEC en suspens

- il n’y a pas de RD électronique pour la question ou il y a des commentaires dans le RE

Le système crée l’AT RE MCE litigieux au niveau Non complexe seulement, et il ne peut pas être réassigné au Niveau 1 ou au Niveau 2.

**Mesures à prendre par l’agent**

L’agent Non complexe examine le RE et, au besoin, crée un lien vers la période d’emploi correspondante. Lorsqu’il y a une section Résoudre le problème pour l’AT, l’agent Non complexe détermine si le MCE doit être modifié. S’il y a une décision au dossier, l’agent choisit l’option Condition spéciale appropriée, s’il y a lieu. Le système met à jour le RE selon les options choisies par l’agent dans l’AT RE MCE litigieux. Une fois l’AT RE MCE litigieux complété, le système détermine si l’AT DEC doit être réactivé ou créé. Aucune autre mesure n’est requise par l’agent Non complexe. 

## Considérations régionales

Source topic: `fr_FR/activity/roe_rfs/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/roe_rfs/ce_quil_faut_chercher.dita`

### Dans SNCT :

Source topic: `fr_FR/activity/roe_rfs/dans_snct.dita`

- Quel est le MCE affiché dans la section Détails de l’onglet Détails spécifiques de l’AT RE MCE litigieux?

- Si le MCE est Autre , est-ce que le numéro de série du RE débute par Z ou Y (indiquant qu’il s’agit d’un RE de pêcheur)? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/roe_rfs/que_voulez-vous_faire.dita`

## Références politiques

Source topic: `fr_FR/activity/roe_rfs/references_politiques.dita`

 
