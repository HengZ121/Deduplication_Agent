# Post-PU AE — Procédures pour les demandes automatisées dans le processus spécialisé du TAD

Source map: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/post_eierb_assessment_issue_wi_unique_s_774b2eb0.ditamap`

## Sommaire

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/sommaire.dita`

Sommaire : Le 27 septembre 2020, un processus spécialisé du TAD a été mis en place pour simplifier le traitement des demandes initiales de prestations régulières et de maladie. Des AT Évaluation pour le calcul (ECAL) ou des AT Action à prendre (AP) uniques ont été créés quand l’examen par un agent était requis pour les demandes initiales et les demandes en cours de conversion aux prestations régulières. Ce processus temporaire se termine le 16 août 2021. Toutefois, l’agent continue de compléter les AT en suspens créés par le traitement spécialisé du TAD avant le 16 août 2021 en utilisant les procédures de traitement spécialisé. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/ce_quil_faut_savoir.dita`

### Untitled section

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/untitled_section.dita`

- **Alerte COVID-19 — Mise à jour le 28 septembre 2020 (choisir pour plus de renseignements)**

           [Danger](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0142.dita) 

### Processus spécialisé du TAD

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/processus_specialise_du_tad.dita`

Ce processus spécialisé s’applique qu’aux demandes initiales pour des prestations régulières ou de maladie qui rencontrent un critère précis.

Certaines des demandes dans le processus spécialisé du TAD ont une demande papier dans l’ Arbre de visualisation des demandes parce que le client est inscrit automatiquement après avoir épuisé une demande pour la prestation d’AE d’urgence (PU AE). Dans ce cas, l’agent examine la demande pour la PU AE la plus récente quand il complète l’AT.

Le processus d’attente normal du TAD ne s’applique pas au processus spécialisé. Aucun AT Évaluation du relevé d’emploi (RE) n’est créé dans le processus spécialisé du TAD. Trois AT ECAL sont uniques au processus spécialisé du TAD. TAD crée un de ces AT quand l’intervention d’un agent est requise. Ces AT ECAL empêchent le processus spécialisé du TAD de finaliser le calcul jusqu’à ce que l’agent remplit l’AT ECAL. 

### AT Évaluation pour le calcul (ECAL) PPNE

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/at_evaluation_pour_le_calcul_ecal_ppne.dita`

TAD crée un AT ECAL PPNE dans le processus spécialisé du TAD quand le résultat du calcul provisoire est un PPNE N1, N2 ou N5. Un agent de Niveau 1 examine le dossier pour déterminer s’il manque un RE et si un RE provisoire ou les données réelles sont requis. Une fois que l’agent a terminé l’AT ECAL PPNE, TAD calcule et finalise la demande. Seul TAD peut créer cet AT. 

### AT Évaluation pour le calcul (ECAL) RE Correction

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/at_evaluation_pour_le_calcul_ecal_re_correction.dita`

TAD crée un AT ECAL RE Correction quand un RE régulier ou de pêcheur comprend une erreur qui empêche le calcul. L’agent suit la procédure appropriée pour corriger l’erreur et compléter l’AT. Seul TAD peut créer cet AT. 

### RE en double

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/re_en_double.dita`

Si l’erreur du RE indique que le numéro de série a déjà été saisi pour un autre NAS, l’agent consulte Post-PU AE — Corriger un RE signalé en double avec un NAS différent .
       [Post-PU AE — Corriger un RE signalé en double avec un NAS différent](/fr/procedure/task/post_eierb_correcting_roe_flagged_duplicate_roe_different_sin.shtml) 

### RE avec un problème de statut de numéro de série

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/re_avec_un_probleme_de_statut_de_numero_de_serie.dita`

Si l’erreur du RE indique un problème avec le statut du numéro de série, l’agent consulte Post-PU AE — Correction d’un RE signalé avec un problème de numéro de série .
       [Post-PU AE — Correction d’un RE signalé avec un problème de numéro de série](/fr/procedure/task/post_eierb_correcting_roe_flagged_with_a_serial_number_problem.shtml) 

### AT Évaluation pour le calcul (ECAL) RE Commentaires

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/at_evaluation_pour_le_calcul_ecal_re_co_78adc7bd.dita`

TAD crée un AT ECAL RE Commentaires dans le processus spécialisé du TAD quand les commentaires sur un RE de pêcheur ou un RE régulier doivent être révisés. L’agent examine les commentaires, prend les mesures appropriées et complète l’AT. Seul TAD peut créer cet AT. 

### Convertir les demandes automatisées dans le processus spécialisé du TAD

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/convertir_les_demandes_automatisees_dan_9ccf483e.dita`

Les demandes automatisées dans le processus spécialisé du TAD sont établies sans rendre de décision sur les questions litigieuses liées au MCE dans la période de référence (PR) du client. Le champ Condition spéciale du RE est vide ou indique Reporté, et CAC considère le MCE non litigieux à ce moment-là . Par conséquent, le RE potentiellement litigieux est inclus dans le calcul et aucune exclusion n’est imposée.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0143.dita) 

Quand un client demande une conversion de prestations spéciales (y compris les prestations de maladie) en prestations régulières, l’agent examine chaque question liée au MCE pour éviter le versement de prestations auxquelles le client n’est pas admissible. Un AT AP est créé pour que l’agent de Niveau 2 rende une décision sur chaque MCE litigieux dans la période de 12 semaines précédant l’A de R utilisé pour établir la demande (même s’il a antérieurement été considéré comme non litigieux par CAC lors du calcul initial). 

### Danger

Source topic: `fr_FR/common_notes/note_c_0142.dita`

Cette page est touchée par les mesures spéciales liées à la COVID-19. Les changements liés à la COVID-19 ne sont pas en surbrillance. Pour plus de renseignements, l’agent consulte la page Mises à jour et Nouvelles appropriée.

- 28 septembre 2020 — L’activité a été créée ( plus de renseignements ).
         [plus de renseignements](/fr/site/dossier/new_updated_post_eierb_specialized_acp_process.shtml)

- 1er avril 2021 — Cette activité a été mise à jour avec des renseignements sur la façon de rendre une décision sur les questions liées au motif de cessation d’emploi (MCE) quand les clients demandent une conversion de prestations spéciales en prestations régulières.

     [plus de renseignements](/fr/site/dossier/new_updated_post_eierb_specialized_acp_process.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0143.dita`

Remarque :

Le processus spécialisé du TAD se termine le 16 août 2021. À partir de cette date, TAD crée des AT Litige - Décision (DEC) pour les questions litigieuses liées aux MCE dans la PR, puisqu’il n’établit plus de demandes sans rendre de décision sur celles-ci. 

## Considérations régionales

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/ce_quil_faut_chercher.dita`

### Dans SNCT :

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/dans_snct.dita`

- Quelle est la question à l’onglet Détails spécifiques de l’AT ECAL? Y a-t-il des renseignements supplémentaires dans le champ Détails ?

- Est-ce que Motif de Cessation d’emploi est indiqué dans le champ Problème de l’AT AP?

- Si oui, y-a-t-il des renseignements supplémentaires dans le champ Détails ? 

### Dans MSRE :

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/dans_msre.dita`

- S’agit-il d’un RE régulier ou d’un RE de pêcheur? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/que_voulez-vous_faire.dita`

## Références politiques

Source topic: `fr_FR/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/references_politiques.dita`

 
