# Traiter le calcul ou le nouveau calcul d’une demande de prestations de maladie

Source map: `fr_FR/activity/calc_sick/calc_sick.ditamap`

## Sommaire

Source topic: `fr_FR/activity/calc_sick/sommaire.dita`

Sommaire : Quand TAD n’est pas en mesure d’automatiser le calcul d’une demande de prestations de maladie, un agent calcule la demande. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/calc_sick/ce_quil_faut_savoir.dita`

### Untitled section

Source topic: `fr_FR/activity/calc_sick/untitled_section.dita`

[Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0019.dita) 

### Calculer manuellement une demande

Source topic: `fr_FR/activity/calc_sick/calculer_manuellement_une_demande.dita`

Le calcul manuel d’une demande est complexe et doit être fait seulement par un agent qui a suivi la formation nécessaire.

L’agent doit traiter le calcul ou le nouveau calcul d’une demande quand :

- un client présente une demande de prestations sur papier

- TAD n’est pas en mesure de traiter le calcul d’une application électronique

- une demande nécessite un nouveau calcul et que TAD n’est pas en mesure d’automatiser le nouveau calcul 

### Demandes post-prestation d’AE d’urgence (PU AE)

Source topic: `fr_FR/activity/calc_sick/demandes_post-prestation_dae_durgence_pu_ae.dita`

Toute nouvelle demande de prestations de maladie reçue dont le DPP est la s/c 2254 ou après sont traitées en utilisant des mesures temporaires pour accélérer le processus de calcul.

Quand le processus spécialisé du TAD crée un AT ETD, aucun autre AT ne sera créé. L’agent doit examiner la demande la plus récente et déterminer si d’autres mesures sont requises avant de finaliser le calcul.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0045.dita) 

### Calcul ou nouveau calcul

Source topic: `fr_FR/activity/calc_sick/calcul_ou_nouveau_calcul.dita`

Quand un AT Évaluation de la demande (EVD) ou Demande spécialisée (DS) est reçu, l’agent doit effectuer le calcul initial de la demande.

Quand un AT Révision de la demande (RVD) avec un problème lié au nouveau calcul est reçu, l’agent doit effectuer le nouveau calcul d’une demande qui était finalisée. On se sert parfois de recalcul pour parler d’un nouveau calcul. Une fois qu’un calcul initial est bien transmis, un nouveau calcul d’une demande peut être effectué quand de nouveaux renseignements reçus auront une incidence sur le résultat du calcul précédent (p. ex. un RE modifié est émis).

Quand un nouveau calcul est requis pour un cas d’Intégrité, un AT Action à prendre (AP) urgent est créé pour le nouveau calcul. L’agent assigné à cet AT doit effectuer le nouveau calcul.

Le nouveau calcul d’une demande peut avoir une incidence sur :

- la possibilité du client d’établir une période de prestations (PP);
         [période de prestations](/fr/procedure/generic/knowledge.shtml#Etablissement_de_la_periode_de_prestati)

- l’admissibilité du client aux prestations;

- le taux de prestations du client.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0020.dita) 

### Effectuer le nouveau calcul d’une demande touchée par la modification d’un NAS ou d’une région

Source topic: `fr_FR/activity/calc_sick/effectuer_le_nouveau_calcul_dune_demand_69c56db8.dita`

Si le client a déménagé dans une autre région, que son NAS a été modifié, ou les 2, depuis le calcul de la demande initiale, il peut ne pas être possible d’enregistrer le nouveau calcul dans la version Web de SSA. Le nouveau calcul doit être enregistré dans le centre de technologie de l’information (CTI) initial ou sous le NAS précédent, mais il doit être saisi manuellement dans ETI avec le CTI actuel et le nouveau NAS, si applicable.

Pour plus de renseignements, l’agent consulte les annexes B, C et D du Guide de saisie des données de nouveau calcul – version SSA .
       [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Structure des procédures de calcul

Source topic: `fr_FR/activity/calc_sick/structure_des_procedures_de_calcul.dita`

La procédure de calcul est divisée en sous-activités afin de fournir une séquence logique à suivre quand une demande est calculée. Bien que chaque agent ait une séquence préférée qui est aussi correcte, la procédure est structurée afin d’assurer que l’agent effectue toutes les actions nécessaires pour traiter la demande :

- Déterminer si une demande est prête à être calculée.

- Calculer une demande dans la version Web de SSA.

- Examiner le résultat du calcul.

- Examiner et saisir le calcul.

- Communiquer les décisions après le calcul.

Chaque sous-activité comporte des liens menant à des procédures supplémentaires qui peuvent être nécessaires pour terminer le processus de calcul. 

### Gérer l’AT

Source topic: `fr_FR/activity/calc_sick/gerer_lat.dita`

Peu importe la façon dont un agent organise son travail, l’agent à qui est assigné le calcul de la demande doit s’assurer que tout problème est résolu et que tous les faits nécessaires pour calculer la demande sont au dossier avant de compléter le calcul. À moins que les procédures fassent état d’une directive contraire, l’AT EVD ne doit pas être complété tant que toutes les questions n’ont pas été traitées et que tous les AT connexes nécessaires pour finaliser le calcul n’ont pas été complétés. Si le calcul ne peut pas être complété parce qu’il y a un AT connexe en suspens, l’AT du calcul doit être déplacé vers En suspens jusqu’à ce que l’AT connexe soit complété.

Il se peut que des AT liés à une même demande faisant l’objet d’une évaluation soient assignés à divers agents (p. ex. un AT RE Litigieux motif de cessation d’emploi [MCE] est assigné à un agent et un AT EVD est assigné à un autre agent). L’agent complète seulement l’AT qui lui est assigné, sauf si une procédure prévoit le contraire.

Quand il évalue une demande, l’agent à qui a été assigné un AT du calcul doit aussi examiner la Note client afin de déterminer les actions à prendre (p. ex. saisir des transactions, envoyer des lettres).

Quand le calcul est complété, l’agent doit communiquer la décision au client au besoin. 

### Choisir le genre de prestations (GP) approprié

Source topic: `fr_FR/activity/calc_sick/choisir_le_genre_de_prestations_gp_approprie.dita`

Quand l’enregistrement d’une demande crée automatiquement un AT RVD, dans SNCT, le champ Genre de prestations de l’AT RVD est prérempli par Régulier. L’agent met manuellement à jour ce champ avec le GP approprié. Pour une demande initiale ou renouvelée, l’agent choisit le GP indiqué dans la demande d’AE. Pour une demande de conversion dans une demande continue ou toute autre demande de conversion, l’agent choisit le nouveau GP demandé.

Lors de la création d’un AT AP, Rappel (RA), Évaluation pour le calcul (ECAL) ou À revoir (AR), l’agent choisi le GP indiqué dans la demande d’AE. Si le GP a été modifié depuis que le client a présenté sa demande de prestations, l’agent choisit le GP indiqué dans ETI. 

### Remplir les conditions requises pour des prestations de maladie

Source topic: `fr_FR/activity/calc_sick/remplir_les_conditions_requises_pour_de_7eac4026.dita`

Pour remplir les conditions requises pour recevoir des prestations de maladie, un client doit remplir les conditions suivantes :

- Le client a présenté une demande de prestations.

- Le client a subi un arrêt de rémunération (A de R) pendant sa période de référence (PR).
         [arrêt de rémunération (A de R)](/fr/procedure/generic/knowledge.shtml#Arret_de_remuneration) 
         [période de référence](/fr/procedure/generic/knowledge.shtml#Periode_de_reference)

- Le client est de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable.
         [première catégorie](/fr/procedure/generic/knowledge.shtml#client12)

- Le client est de deuxième catégorie (a moins de 600 heures d’emploi assurable) et remplit les conditions requises pour recevoir des prestations régulières avec un MCE autre qu’une maladie, blessure ou mise en quarantaine.
         [deuxième catégorie](/fr/procedure/generic/knowledge.shtml#client12)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0021.dita) 

### Remplir les conditions requises avec la norme d’admissibilité commune (de la s/c 2310 à la s/c 2361)

Source topic: `fr_FR/activity/calc_sick/remplir_les_conditions_requises_avec_la_44b5fc5f.dita`

Dans le cadre du budget 2021, le gouvernement du Canada a annoncé qu’une norme d’admissibilité commune nationale de 420 heures d’emploi assurable s’applique pour établir une demande de prestations régulières ou spéciales. S’il y a une violation au dossier du client, la majoration des conditions requises peut s’appliquer. La norme d’admissibilité commune s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Pendant cette période, les définitions prestataire de première et de deuxième catégorie dans la LAE 6(1) sont abrogées. Les clients dont la demande est établie avec 420 heures d’emploi assurable remplissent les conditions requises pour recevoir des prestations spéciales. L’agent s’assure que toutes les autres conditions requises et d’admissibilité sont remplies.
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Admissibilité aux prestations de maladie

Source topic: `fr_FR/activity/calc_sick/admissibilite_aux_prestations_de_maladie.dita`

Pour être admissible aux prestations de maladie, le client doit :

- fournir un certificat médical qui prouve l’incapacité de travailler en raison d’une maladie;

- prouver qu’il serait autrement disponible pour travailler (c.-à-d. qu’il serait au travail ou en recherche d’emploi si ce n’était de la maladie).

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0046.dita) 

Un client de première catégorie est admissible à des prestations spéciales peu importe le MCE.
       [prestations spéciales](/fr/procedure/generic/knowledge.shtml#Prestations_speciales)

Une inadmissibilité administrative est imposée pour empêcher le paiement de prestations régulières à un client qui est admissible aux prestations spéciales, mais pas aux prestations régulières. 

### Preuve d’incapacité

Source topic: `fr_FR/activity/calc_sick/preuve_dincapacite.dita`

Un client qui demande des prestations de maladie doit être en mesure de fournir un certificat médical qui prouve son incapacité de travailler en raison de maladie.

Un certificat médical rempli par un médecin ou un autre praticien confirmant la maladie du client doit être obtenu pour chaque semaine pour laquelle le client demande des prestations de maladie.

Le client qui présente une demande de prestations de maladie dans AW peut téléverser immédiatement le certificat médical. Si le client ne présente pas le certificat médical et que le dernier MCE est maladie, le client est informé qu’il doit le présenter si la durée de la maladie ou de la blessure est supérieure à 9 semaines. Sinon, le client est avisé qu’il doit conserver le certificat médical pendant 6 ans puisqu’il peut être demandé à une date ultérieure. Si le dernier MCE n’est pas maladie, le client est avisé qu’il doit présenter le certificat médical et qu’il peut le téléverser ultérieurement dans MDSC.

Si un certificat médical est nécessaire et n’est pas fourni, une inadmissibilité 16 - Certificat médical non fourni (D16) doit être imposée sur la demande.

Les agents ne doivent pas demander un certificat médical à moins qu’il soit nécessaire. Si un certificat médical est reçu, mais non exigé, l’agent l’examine et met à jour la date de guérison en fonction des renseignements fournis sur le certificat médical.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0047.dita) 

### Verser des prestations

Source topic: `fr_FR/activity/calc_sick/verser_des_prestations.dita`

Le client peut recevoir jusqu’à 26 semaines de prestations de maladie par PP quand le DPP est la s/c 2374 ou après et jusqu’à 15 semaines de prestations de maladie par PP quand le DPP est la s/c 2373 ou avant.

Une fois que la demande est établie et que l’admissibilité aux prestations de maladie est déterminée, des prestations de maladie sont payables pour chaque semaine pour laquelle le client soumet une déclaration du prestataire et pendant laquelle le client :

- déclare 5 jours de maladie

- est autrement disponible pour travailler

- a fourni la preuve requise pour des prestations de maladie

- n’a pas reçu de rémunération ou de répartition empêchant le versement d’un paiement

- n’a pas fait l’objet d’une inadmissibilité empêchant le paiement 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0019.dita`

Remarque :

À moins d’avis contraire, les références aux calculs s’appliquent aussi aux nouveaux calculs. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0045.dita`

Remarque :

Le processus spécialisé du TAD se termine le 16 août 2021. À partir de cette date, TAD retourne aux processus normaux d’enregistrement et de calcul. Toutefois, l’agent continue de compléter les AT en suspens créés par le processus spécialisé avant le 15 août 2021 en utilisant les procédures spécialisées. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0020.dita`

Remarque :

Quand le nouveau calcul d’une demande est nécessaire, l’agent suit les procédures normales d’évaluation du calcul et consulte Nouveau calcul : Évaluation — Instructions ainsi que le Guide de saisie des données de nouveau calcul – version SSA , au besoin. Une demande qui nécessite un nouveau calcul doit être évaluée de la même façon qu’une demande qui nécessite un calcul initial.
       [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
       [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml)

     [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
     [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0021.dita`

Remarque :

S’il y a une violation au dossier du client, il se peut qu’il y ait une majoration des conditions requises .
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

     [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0046.dita`

Remarque:

Quand un client ne prouve pas qu’il est autrement disponible pour travailler pour la période entière d’incapacité, ou pour une partie de celle-ci, l’agent impose une inadmissibilité 33 - Incapacité prouvée mais prestataire non autrement disponible (D33) de la date à laquelle le critère n’est pas rempli, jusqu’à la fin de la période d’incapacité ou la date à laquelle le client devient autrement disponible pour travailler. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0047.dita`

Remarque:

Quand un certificat médical est téléversé, l’agent ou le client doit remplir un questionnaire électronique Certificat médical. Ce questionnaire électronique n’ est pas une preuve médicale. L’agent ne l’utilise pas pour déterminer une semaine de guérison ou une période d’incapacité. 

## Considérations régionales

Source topic: `fr_FR/activity/calc_sick/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/calc_sick/ce_quil_faut_chercher.dita`

## Que voulez-vous faire?

Source topic: `fr_FR/activity/calc_sick/que_voulez-vous_faire.dita`

- Déterminer si une demande de prestations est prête à être calculée — Prestations de maladie
         [Déterminer si une demande de prestations est prête à être calculée — Prestations de maladie](/fr/procedure/subactivity/det_crc_sb.shtml)

- Calculer une demande dans la version Web de SSA
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Examiner le résultat du calcul
         [Examiner le résultat du calcul](/fr/procedure/subactivity/calc_result_ccb.shtml)

- Réviser et saisir le calcul
         [Réviser et saisir le calcul](/fr/procedure/subactivity/input_calculation_results.shtml)

- Communiquer les décisions après le calcul
         [Communiquer les décisions après le calcul](/fr/procedure/subactivity/communicating_calc_decisions.shtml) 

## Référence de politique

Source topic: `fr_FR/activity/calc_sick/reference_de_politique.dita`

 
