# Certificat médical — Prestations de maladie

Source map: `fr_FR/activity/med_cert_sb/med_cert_sb.ditamap`

## Sommaire

Source topic: `fr_FR/activity/med_cert_sb/sommaire.dita`

Sommaire : Les clients qui demandent des prestations de maladie doivent être en mesure de fournir un certificat médical qui atteste de leur incapacité à travailler. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/med_cert_sb/ce_quil_faut_savoir.dita`

### Déterminer si un certificat médical est acceptable

Source topic: `fr_FR/activity/med_cert_sb/determiner_si_un_certificat_medical_est_7bea54d6.dita`

Les clients doivent obtenir, à leurs propres frais, un certificat médical acceptable pour chaque semaine où ils demandent des prestations de maladie (RAE 40[1]) . Le certificat médical doit démontrer qu’un client est incapable de travailler en raison d’une maladie, d’une blessure ou d’une mise en quarantaine. Le certificat médical doit confirmer l’incapacité. Dans certaines situations, le certificat doit démontrer la date de début et la durée probable de l’incapacité. Le certificat médical doit être signé par un médecin ou par un médecin praticien.
       [certificat médical acceptable](/fr/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml) 
       [(RAE 40[1])](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-40.html) 
       [date de début](/fr/procedure/generic/additionalresources/incapacity_start_date_sb.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0131.dita) 

**Demander la traduction d’un certificat médical**

Un certificat médical acceptable doit être écrit en anglais ou en français. Si le certificat médical est écrit dans une autre langue, l’agent doit l’envoyer pour qu’il soit traduit. Consulter Envoyer un certificat médical pour le faire traduire .
       [Envoyer un certificat médical pour le faire traduire](/fr/procedure/task/med_cert_translation.shtml) 

### Déterminer si un certificat médical est requis

Source topic: `fr_FR/activity/med_cert_sb/determiner_si_un_certificat_medical_est_requis.dita`

Le client ne doit pas toujours présenter le certificat médical pour recevoir des prestations de maladie. Quand il demande des prestations de maladie, le client doit obtenir un certificat médical auprès d’un médecin ou toute autre preuve médicale acceptable, confirmant la maladie ou l’incapacité pendant la période pour laquelle les prestations de maladie sont demandées.

Le client qui présente une demande de prestations de maladie dans AW peut téléverser immédiatement le certificat médical. Si le client ne présente pas le certificat médical et que le dernier MCE est maladie, le client est informé qu’il doit le présenter si la durée de la maladie ou de la blessure est supérieure à 9 semaines. Sinon, le client est avisé qu’il doit conserver le certificat médical pendant 6 ans puisqu’il peut être demandé à une date ultérieure. Un client qui présente une demande de prestations de maladie dans AW qui indique un MCE autre que la maladie est avisé de présenter le certificat médical.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0132.dita) 

Quand le client demande des semaines des prestations de maladie au-delà de la date de guérison qui figure dans la demande ou pour une période pour laquelle une inadmissibilité 16 - Certificat médical non fourni (D16) a été imposée, le client doit fournir un nouveau certificat médical acceptable comme preuve d’incapacité.

**Imposer une inadmissibilité**

Si le client doit présenter un certificat médical acceptable mais il ne le fait pas, l’agent impose une inadmissibilité D16. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0131.dita`

Remarque :

Le client doit assumer les frais associés à l’obtention d’un certificat médical. Si un client ou un médecin fait parvenir une facture à un centre Service Canada pour un certificat médical rempli, l’agent la retourne au client. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0132.dita`

Remarque :

Quand un certificat médical est téléversé, l’agent ou le client doit remplir un questionnaire électronique Certificat médical. Ce questionnaire électronique n’est pas une preuve médicale. L’agent ne l’utilise pas pour déterminer une semaine de guérison ou une période d’incapacité. 

## Considérations régionales

Source topic: `fr_FR/activity/med_cert_sb/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/med_cert_sb/ce_quil_faut_chercher.dita`

### Dans ETI :

Source topic: `fr_FR/activity/med_cert_sb/dans_eti.dita`

- Y a-t-il une D16 au dossier?

- Le client reçoit-il actuellement des prestations de maladie? 

### Dans SNCT :

Source topic: `fr_FR/activity/med_cert_sb/dans_snct.dita`

- Y a-t-il un RSDP ou un AT Action à prendre contenant la transcription d’un certificat médical, ou un certificat médical a-t-il été téléchargé?

- Si oui, y a-t-il une date de début, la durée de l’incapacité ou une date de fin?

- Si oui, le certificat médical est-il écrit en anglais ou en français? 

### Dans Imagerie :

Source topic: `fr_FR/activity/med_cert_sb/dans_imagerie.dita`

- Y a-t-il un certificat médical?

- Si oui, y a-t-il une date de début, la durée de l’incapacité ou une date de fin?

- Si oui, le certificat médical est-il écrit en anglais ou en français? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/med_cert_sb/que_voulez-vous_faire.dita`

## Référence de politique

Source topic: `fr_FR/activity/med_cert_sb/reference_de_politique.dita`

 
