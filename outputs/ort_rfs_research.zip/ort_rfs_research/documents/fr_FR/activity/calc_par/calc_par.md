# Traiter le calcul ou le nouveau calcul d’une demande de prestations parentales

Source map: `fr_FR/activity/calc_par/calc_par.ditamap`

## Sommaire

Source topic: `fr_FR/activity/calc_par/sommaire.dita`

Sommaire : Quand TAD n’est pas en mesure d’automatiser le calcul d’une demande de prestations parentales, la demande doit être calculée par un agent. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/calc_par/ce_quil_faut_savoir.dita`

### Untitled section

Source topic: `fr_FR/activity/calc_par/untitled_section.dita`

[Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0037.dita) 

### Calculer manuellement une demande

Source topic: `fr_FR/activity/calc_par/calculer_manuellement_une_demande.dita`

Le calcul manuel d’une demande est complexe et doit être fait seulement par un agent qui a suivi la formation nécessaire.

L’agent doit traiter le calcul ou le nouveau calcul d’une demande dans les cas suivants quand :

- un client présente une demande de prestations sur papier

- TAD n’est pas en mesure de traiter le calcul d’une application électronique

- une demande nécessite un nouveau calcul et que TAD n’est pas en mesure d’automatiser le nouveau calcul 

### Calcul ou nouveau calcul

Source topic: `fr_FR/activity/calc_par/calcul_ou_nouveau_calcul.dita`

Quand un AT Évaluation de la demande (EVD) ou Demande spécialisée (DS) est reçu, l’agent doit effectuer le calcul initial de la demande.

Quand un AT Révision de la demande (RVD) avec un problème lié au nouveau calcul est reçu, l’agent doit effectuer le nouveau calcul d’une demande qui était finalisée. On se sert parfois de « recalcul » pour parler d’un nouveau calcul. Une fois qu’un calcul initial est bien transmis, un nouveau calcul d’une demande peut être effectué quand de nouveaux renseignements reçus auront une incidence sur le résultat du calcul précédent (p. ex. un RE modifié est émis).

Quand un nouveau calcul est requis pour un cas d’Intégrité, un AT Action à prendre (AP) urgent est créé pour le nouveau calcul. L’agent assigné à cet AT doit effectuer le nouveau calcul.

Le nouveau calcul d’une demande peut avoir une incidence sur :

- la possibilité du client d’établir une période de prestations (PP);
         [période de prestations](/fr/procedure/generic/knowledge.shtml#Etablissement_de_la_periode_de_prestati)

- l’admissibilité du client aux prestations;

- le taux de prestations du client.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0020.dita) 

### Effectuer le nouveau calcul d’une demande touchée par la modification d’un NAS ou d’une région

Source topic: `fr_FR/activity/calc_par/effectuer_le_nouveau_calcul_dune_demand_69c56db8.dita`

Si le client a déménagé dans une autre région, que son NAS a été modifié, ou les 2, depuis le calcul de la demande initiale, il peut ne pas être possible d’enregistrer le nouveau calcul dans la version Web de SSA. Le nouveau calcul doit être enregistré dans le centre de technologie de l’information (CTI) initial ou sous le NAS précédent, mais il doit être saisi manuellement dans ETI avec le CTI actuel et le nouveau NAS, si applicable.

Pour plus de renseignements, l’agent consulte les annexes B, C et D du Guide de saisie des données de nouveau calcul – version SSA .
       [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Structure des procédures de calcul

Source topic: `fr_FR/activity/calc_par/structure_des_procedures_de_calcul.dita`

La procédure de calcul est divisée en sous-activités afin de fournir une séquence logique à suivre quand une demande est calculée. Bien que chaque agent ait une séquence préférée qui est aussi correcte, la procédure est structurée afin d’assurer que l’agent effectue toutes les actions nécessaires pour traiter la demande :

- Déterminer si une demande est prête à être calculée.

- Calculer une demande dans la version Web de SSA.

- Examiner le résultat du calcul.

- Examiner et saisir le calcul.

- Communiquer les décisions après le calcul.

Chaque sous-activité comporte des liens menant à des procédures supplémentaires qui peuvent être nécessaires pour terminer le processus de calcul. 

### Gérer l’AT

Source topic: `fr_FR/activity/calc_par/gerer_lat.dita`

Peu importe la façon dont un agent organise son travail, l’agent à qui est assigné le calcul de la demande doit s’assurer que tout problème est résolu et que tous les faits nécessaires pour calculer la demande sont au dossier avant de compléter le calcul. À moins que les procédures fassent état d’une directive contraire, le calcul ne doit pas être complété tant que tous les AT nécessaires pour finaliser le calcul n’ont pas été complétés. Si le calcul ne peut pas être complété parce qu’il y a un AT connexe en suspens, l’AT du calcul doit être déplacé vers En suspens jusqu’à ce que l’AT connexe soit complété.

Il se peut que des AT liés à une même demande faisant l’objet d’une évaluation soient assignés à divers agents (p. ex. un AT RE Litigieux motif de cessation d’emploi [MCE] est assigné à un agent et un AT EVD est assigné à un autre agent). L’agent complète seulement l’AT qui lui est assigné, sauf si une procédure prévoit le contraire.

Quand il évalue une demande, l’agent à qui a été assigné un AT du calcul doit aussi examiner la Note client afin de déterminer les actions à prendre (p. ex. saisir des transactions, envoyer des lettres).

Quand le calcul est complété, l’agent doit communiquer la décision au client au besoin. 

### Choisir le genre de prestation (GP) approprié

Source topic: `fr_FR/activity/calc_par/choisir_le_genre_de_prestation_gp_approprie.dita`

Quand l’enregistrement d’une demande crée automatiquement un AT RVD, dans SNCT, le champ Genre de prestations de l’AT RVD est prérempli par Régulier. L’agent met manuellement à jour ce champ avec le GP approprié. Pour une demande initiale ou renouvelée, l’agent choisit le GP indiqué dans la demande d’AE. Pour une demande de conversion dans une demande continue ou toute autre demande de conversion, l’agent choisit le nouveau GP demandé.

Lors de la création d’un AT AP, Rappel (RA), Évaluation pour le calcul (ECAL) ou À revoir (AR), l’agent choisi le GP indiqué dans la demande d’AE. Si le GP a été modifié depuis que le client a présenté sa demande de prestations, l’agent choisit le GP indiqué dans ETI. 

### Remplir les conditions requises pour des prestations parentales

Source topic: `fr_FR/activity/calc_par/remplir_les_conditions_requises_pour_de_8afb0201.dita`

Pour remplir les conditions requises pour recevoir des prestations parentales, un client doit remplir les conditions suivantes :

- Le client a présenté une demande de prestations.

- Le client a subi un arrêt de rémunération (A de R) pendant sa période de référence (PR) .
         [arrêt de rémunération (A de R)](/fr/procedure/generic/knowledge.shtml#Arret_de_remuneration) 
         [période de référence (PR)](/fr/procedure/generic/knowledge.shtml#Periode_de_reference)

- Le client est de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable.
         [première catégorie](/fr/procedure/generic/knowledge.shtml#client12)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0038.dita) 

**Remplir les conditions requises avec la norme d’admissibilité commune (de la s/c 2310 à la s/c 2361)**

Dans le cadre du budget 2021, le gouvernement du Canada a annoncé qu’une norme d’admissibilité commune (NAC) nationale de 420 heures d’emploi assurable s’applique pour établir une demande de prestations régulières ou spéciales. S’il y a une violation au dossier du client, la majoration des conditions requises peut s’appliquer. La NAC s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Pendant cette période, les définitions de clients de première et deuxième catégorie dans la LAE 6(1) sont abrogées. Les clients dont la demande est établie avec 420 heures d’emploi assurables remplissent les conditions requises pour recevoir des prestations spéciales. L’agent s’assure que toutes les autres conditions requises et d’admissibilité sont remplies.
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Admissibilité aux prestations spéciales

Source topic: `fr_FR/activity/calc_par/admissibilite_aux_prestations_speciales.dita`

Pour être admissible aux prestations parentales, un client doit remplir les conditions suivantes :

- Le client est en mesure de fournir une preuve de naissance, d’adoption ou de placement.

- Le client demande les prestations dans la fenêtre parentale (FP).

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0039.dita) 

Un client de première catégorie est admissible à des prestations spéciales, peu importe le MCE.

Une inadmissibilité administrative est imposée pour empêcher le paiement de prestations régulières à un client qui est admissible aux prestations spéciales, mais pas aux prestations régulières. 

### Preuve de naissance, d’adoption ou de placement

Source topic: `fr_FR/activity/calc_par/preuve_de_naissance_dadoption_ou_de_placement.dita`

Les parents doivent fournir une preuve de naissance, d’adoption ou de placement selon leur lien à l’enfant ou aux enfants. Pour plus de renseignements, l’agent peut consulter Parents : Définition — Tableau .
       [Parents : Définition — Tableau](/fr/procedure/generic/parents_definition_table.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0028.dita) 

### Fenêtre parentale (FP)

Source topic: `fr_FR/activity/calc_par/fenetre_parentale_fp.dita`

La FP est la période pendant laquelle les prestations parentales peuvent être payées. La FP commence et se termine de la façon suivante :

- Semaine de début :

- La semaine d’arrivée ou de placement (SAP) est déterminée par le lien entre le parent et l’enfant. Pour plus de renseignements, l’agent peut consulter Parents : Définition — Tableau .
             [Parents : Définition — Tableau](/fr/procedure/generic/parents_definition_table.shtml)

- Semaine de fin :

- Pour les prestations parentales standards, la semaine de fin tombe 52 semaines après la SAP (SAP + 52).

- Pour les prestations parentales prolongées, la semaine de fin tombe 78 semaines après la SAP (SAP + 78).

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0033.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0034.dita) 

### Verser des prestations

Source topic: `fr_FR/activity/calc_par/verser_des_prestations.dita`

Les prestations parentales peuvent être versées soit au taux de base soit à un taux réduit pendant une durée prolongée. Le nombre maximal de semaines d’admissibilité aux prestations parentales pour une naissance ou une adoption est différent selon le genre de prestations parentales reçues par le client et si les prestations sont partagées avec d’autres parents légalement reconnus. 

### Admissibilité maximale

Source topic: `fr_FR/activity/calc_par/admissibilite_maximale.dita`

Un client est admissible à un maximum de 35 semaines de prestations parentales standards ou de 61 semaines de prestations parentales prolongées par naissance ou par placement en adoption. L’admissibilité parentale maximale est aussi le nombre maximal de semaines d’admissibilité aux prestations parentales qui peuvent être payées pendant une PP. Les prestations parentales peuvent être versées sur 2 PP, mais pas en dehors de la FP. Le nombre de semaines de prestations parentales auxquelles un client est admissible n’est affecté ni par le nombre d’enfants nés en même temps (jumeaux, triplés, etc.) ni par le nombre d’enfants adoptés au même moment. 

### Partager des prestations parentales

Source topic: `fr_FR/activity/calc_par/partager_des_prestations_parentales.dita`

Les parents peuvent partager les prestations parentales. Pour plus de renseignements et des définitions, l’agent peut consulter Parents : Définition — Tableau .
       [Parents : Définition — Tableau](/fr/procedure/generic/parents_definition_table.shtml)

Le genre de prestations parentales demandé par le premier parent qui a présenté une demande de prestations détermine le genre de prestations parentales auquel tous les parents sont admissibles pour la même naissance, adoption ou placement, quel que soit le parent qui est payé en premier. Lors du recueil de faits auprès des parents qui ont présenté une demande de prestations après le premier parent, l’agent informe les autres parents du genre de prestations auquel ils ont droit. Une fois qu’au moins une semaine de prestations parentales a été versée à l’un des parents, tous les parents demandant des prestations pour la même naissance, adoption ou placement ne sont admissibles qu’au genre de prestations parentales choisi par le premier parent qui a présenté une demande de prestations.

Le maximum de prestations parentales standards partageables est de 40 semaines ou de 69 semaines pour les prestations parentales prolongées pour un enfant né ou placé en adoption le 17 mars 2019 ou après. Pour les enfants nés ou placés en adoption avant cette date, le maximum des prestations parentales standards partageables est de 35 semaines ou de 61 semaines pour les prestations parentales prolongées. L’admissibilité maximale des demandes de prestations standards pour un client demeure à 35 semaines ou à 61 semaines pour les prestations prolongées. Les clients peuvent modifier le nombre de semaines que chaque parent reçoit à tout moment avant que toutes les prestations ne soient versées. Quand les clients ne peuvent pas s’entendre sur le nombre de semaines que chacun recevra, l’agent réassigne la question à un agent de Niveau 2 qui rend une décision sur la division des semaines restantes.

Une fois que la demande est établie et que l’admissibilité aux prestations parentales est déterminée, des prestations de parentales sont payables pour chaque semaine pour laquelle le client soumet une déclaration du prestataire et pendant laquelle le client :

- déclare 5 jours de non-disponibilité

- a fourni la preuve requise pour des prestations de parentales

- n’a pas reçu de rémunération ou de répartition empêchant le versement d’un paiement

- n’a pas fait l’objet d’une inadmissibilité empêchant le paiement

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0040.dita) 

### Valider les prestations parentales partagées

Source topic: `fr_FR/activity/calc_par/valider_les_prestations_parentales_partagees.dita`

Un Dossier de clients des prestations parentales est créé pour chaque client demandant des prestations parentales. Le Dossier de clients des prestations parentales est constitué du NAS du client, de la semaine d’arrivée ou de placement (SAP) et du NAS de l’autre parent, s’il a été fourni. Une fois que la demande est finalisée, le système lie les Dossiers de clients des prestations parentales pour tous les clients qui partagent des prestations parentales pour le même enfant. Le processus de validation du partage des prestations parentales crée un AT Révision de la demande (RVD) Validation des prestations parentales quand l’une des conditions suivantes est remplie

- Le genre de prestations parentales dans tous les Dossiers de clients des prestations parentales liés n’est pas le même.

- Le nombre total de semaines parentales demandées dans tous les Dossiers de clients des prestations parentales liés dépasse le nombre maximal de semaines de prestations parentales partageables. 

### Reporter le délai de carence (DC)

Source topic: `fr_FR/activity/calc_par/reporter_le_delai_de_carence_dc.dita`

Le DC peut être reporté si le client reçoit des prestations parentales. Si l’autre parent a observé un DC pour la même naissance ou évènement ou si le client a observé un DC pour la même naissance ou le même évènement et qu’il présente ensuite une demande de prestations parentales pour les semaines restantes, le DC peut être reporté.
       [DC](/fr/procedure/generic/knowledge.shtml#Delai_de_carence)

Dans la demande d’AE, le client est demandé de fournir les renseignements sur l’autre parent. Si le client fournit les renseignements sur l’autre parent, AW présente les conditions pour reporter le DC et demande au client si les conditions sont remplies.

Si les renseignements sur l’autre parent ne sont pas fournis, AW ne présente pas les conditions pour reporter le DC et ne demande pas au client si les conditions sont remplies. Toutefois, le client peut être admissible au report du DC.

Dans cette situation, l’agent effectue un recueil de faits pour déterminer :

- si le client veut reporter le DC;

- le NAS de l’autre parent;

- si le NAS de l’autre parent ne peut pas être obtenu, la raison pour laquelle il ne peut pas être obtenu.

L’agent examine la demande du client et le dossier de l’autre parent pour déterminer si le client remplit les conditions requises pour reporter le DC (p. ex. le client établit une demande subséquente de prestations parentales et a déjà observé le DC pour la même naissance ou le même évènement). De plus, l’agent détermine si reporter le DC est à l’avantage du client (p. ex. le client a un régime de PSC ou il est admissible pour avoir le DC supprimé).

Si le NAS de l’autre parent ne peut pas être obtenu, l’agent crée un RSDP pour consigner la raison.

L’agent a l’autorité d’examiner le dossier de l’autre parent afin de valider que le client remplit les conditions requises pour un report du DC. Cette validation est autorisée en vertu des règlements sur la protection des renseignements personnels, car le dossier est examiné pour l’administration du programme d’AE. 

### Info

Source topic: `fr_FR/common_notes/note_c_0037.dita`

Remarque : À moins d’avis contraire, les références aux calculs s’appliquent aussi aux nouveaux calculs. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0020.dita`

Remarque :

Quand le nouveau calcul d’une demande est nécessaire, l’agent suit les procédures normales d’évaluation du calcul et consulte Nouveau calcul : Évaluation — Instructions ainsi que le Guide de saisie des données de nouveau calcul – version SSA , au besoin. Une demande qui nécessite un nouveau calcul doit être évaluée de la même façon qu’une demande qui nécessite un calcul initial.
       [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
       [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml)

     [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
     [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0038.dita`

Remarque :

S’il y a une violation au dossier du client, il se peut qu’il y ait une majoration des conditions requises.
       [majoration des conditions requises.](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

     [majoration des conditions requises.](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0039.dita`

Remarque :

La naissance ou l’adoption de plus d’un enfant à la fois est traitée comme s’il n’y avait qu’un seul enfant. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0028.dita`

Remarque :

Si l’adoption soulève des doutes, une preuve de placement peut être exigée. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0033.dita`

Remarque :

Dans certains cas, la FP peut être prolongée pour permettre au client de recevoir les prestations auxquelles il a droit. Pour plus de renseignements, consulter Conditions relatives à la prolongation de la FP .
       [Conditions relatives à la prolongation de la FP](/fr/procedure/generic/knowledge.shtml#Conditions_relatives_prolongation_PP_pa)

     [Conditions relatives à la prolongation de la FP](/fr/procedure/generic/knowledge.shtml#Conditions_relatives_prolongation_PP_pa) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0034.dita`

Remarque :

Le client doit remplir les conditions d’admissibilité pour chaque semaine de prestations parentales demandée. Si l’agent est informé que le client ne prend plus soin de l’enfant pendant la FP, l’agent impose une inadmissibilité définie ou indéfinie 34 - Prestations parentales conditions d’admissibilité non rencontrées (D34) à compter du lundi suivant la semaine au cours de laquelle le client n’est plus admissible aux prestations. Pour plus de renseignements, l’agent consulte Déterminer l’admissibilité aux prestations parentales quand le client ne prend plus soin de l’enfant .
       [Déterminer l’admissibilité aux prestations parentales quand le client ne prend plus soin de l’enfant](/fr/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml)

     [Déterminer l’admissibilité aux prestations parentales quand le client ne prend plus soin de l’enfant](/fr/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0040.dita`

Remarque :

Le client recevant des prestations parentales pourrait être exempté de remplir des déclarations du prestataire. 

## Considérations régionales

Source topic: `fr_FR/activity/calc_par/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/calc_par/ce_quil_faut_chercher.dita`

## Que voulez-vous faire?

Source topic: `fr_FR/activity/calc_par/que_voulez-vous_faire.dita`

Les sous-activités relatives au calcul sont les suivantes :

- Déterminer si une demande de prestations est prête à être calculée — Prestations parentales
         [Déterminer si une demande de prestations est prête à être calculée — Prestations parentales](/fr/procedure/subactivity/detcalc_pb.shtml)

- Calculer une demande dans la version Web de SSA
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Examiner le résultat du calcul
         [Examiner le résultat du calcul](/fr/procedure/subactivity/calc_result_ccb.shtml)

- Réviser et saisir le calcul
         [Réviser et saisir le calcul](/fr/procedure/subactivity/input_calculation_results.shtml)

- Communiquer les décisions après le calcul
         [Communiquer les décisions après le calcul](/fr/procedure/subactivity/communicating_calc_decisions.shtml) 

## Référence de politique

Source topic: `fr_FR/activity/calc_par/reference_de_politique.dita`

 
