# Départ volontaire

Source map: `fr_FR/activity/voluntary_leaving/voluntary_leaving.ditamap`

## Sommaire

Source topic: `fr_FR/activity/voluntary_leaving/sommaire.dita`

Sommaire : Quand un client abandonne volontairement son emploi, cela peut avoir une incidence sur son admissibilité à des prestations régulières. Une décision est requise pour déterminer si le client avait un motif valable pour quitter son emploi. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/voluntary_leaving/ce_quil_faut_savoir.dita`

### Départ volontaire d’un emploi

Source topic: `fr_FR/activity/voluntary_leaving/depart_volontaire_dun_emploi.dita`

Quand un client abandonne volontairement son emploi, il faut déterminer si son départ était justifié par un motif valable. Un motif est valable si, une fois tous les facteurs pris en compte, le client n’avait aucune autre option raisonnable que de quitter son poste. Si l’on détermine que le client a quitté son emploi sans motif valable, il faut imposer une exclusion indéfinie sur la demande de prestations régulières, sauf si le client a accumulé suffisamment d’heures assurables depuis le départ volontaire pour présenter une nouvelle demande. Dans une telle situation, pour une demande initiale, le RE lié au départ volontaire ne doit pas être pris en compte dans le calcul de la demande. Dans une demande renouvelée, le renouvellement est traité sans une exclusion.

Une mesure temporaire du budget 2021 s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, une décision est seulement requise sur le plus récent RE dans la PR, si le MCE est litigieux. De plus, la norme d’admissibilité commune de 420 heures d’emploi assurable n’est pas utilisée pour déterminer si le client remplit à nouveau les conditions requises après un évènement ayant entraîné une exclusion. Le client doit plutôt avoir travaillé au moins une heure d’emploi assurable depuis l’évènement ayant entraîné l’exclusion et présenté une demande d’AE.

Si le MCE depuis l’exclusion dans les demandes dont le DPP est entre la s/c 2310 et la s/c 2361 est soit non litigieux ou a fait l’objet d’une décision et est autorisé, l’agent peut établir une nouvelle demande sans exclusion en utilisant les heures de tous les RE dans la PR.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0167.dita) 

Les clients sont chargés d’aviser la Commission dans les délais prescrits de tout abandon d’emploi pendant une période de prestations. 

### Départ avant une fin d’emploi anticipée

Source topic: `fr_FR/activity/voluntary_leaving/depart_avant_une_fin_demploi_anticipee.dita`

Une exclusion n’ est pas imposée sur la demande de prestations régulières quand le client quitte volontairement son emploi sans motif valable dans les 3 semaines précédant la fin prévue de l’emploi. Dans ce cas, une inadmissibilité est imposée. Une inadmissibilité est également imposée quand le client prend un congé temporaire de son emploi sans motif valable. 

### Motifs de départ d’un emploi

Source topic: `fr_FR/activity/voluntary_leaving/motifs_de_depart_dun_emploi.dita`

Les motifs pour abandonner volontairement un emploi comprennent :

- pour occuper un autre emploi (y compris le TI);

- pour suivre une autre personne;

- pour des raisons médicales;

- pour suivre un cours de formation;

- pour prendre sa retraite (ce qui inclut les compressions du personnel approuvées).

**Retraite obligatoire**

La législation canadienne sur les droits de la personne interdit la retraite obligatoire. Cette législation couvre la majorité des emplois. Sauf pour de rares exceptions, les employeurs ne peuvent pas démontrer qu’il y a une véritable raison pour expliquer la retraite obligatoire.

Selon les recommandations, les employeurs choisissent le MCE G - Retraite obligatoire seulement en cas de retraite obligatoire, et choisissent le MCE E - Départ volontaire en cas de retraite volontaire.

Une retraite obligatoire ne peut être considérée comme un départ volontaire. Si le client n’a pas abandonné volontairement son emploi, la cessation d’emploi a été amorcée par l’employeur. Un agent de Niveau 2 doit rendre une décision sur le MCE en tant que congédiement .
       [congédiement](/fr/procedure/activity/dismissal.shtml) 

### RE

Source topic: `fr_FR/activity/voluntary_leaving/re.dita`

Un RE n’est pas requis pour rendre une décision sur un départ volontaire.

**Traiter une demande**

Un départ volontaire peut survenir dans le cadre d’une demande initiale, renouvelée ou continue. Le genre de demande détermine les mesures à prendre au moment de la prise de décision.

**Décision automatisée**

Quand un client remplit une demande de prestations en ligne, peu importe qu’il s’agisse d’une demande initiale ou renouvelée, il doit indiquer dans le questionnaire électronique la raison pour laquelle il a volontairement abandonné son emploi. Les réponses du client sont utilisées conjointement avec la logique fondée sur la Politique nationale sur les Niveaux de décision afin de déterminer si le départ volontaire peut être réglé de façon automatisée par TAD. À l’heure actuelle, TAD peut rendre une décision sur les raisons de départ suivantes :
       [Politique nationale sur les Niveaux de décision](/fr/policy/nationalpolicy/levels_decision-annex1.shtml)

- pour commencer un nouvel emploi;

- pour quitter un emploi à temps partiel afin d’occuper un emploi à temps plein;

- pour suivre un époux ou un conjoint de fait;

- pour emménager avec un conjoint de fait ou un fiancé;

- pour emménager avec un ou des parent(s) ou un tuteur légal.

Quand TAD rend une décision sur un départ volontaire, un RD est généré automatiquement.

S’il y a un AT DEC pour un MCE litigieux qui se situe après la date de DPP dans une demande dont l’état est En cours (Automatisation) ou En cours (Manuel) , l’agent consulte Rendre une décision sur un départ volontaire : Demande initiale — Niveau 2 . Le système met à jour le champ Condition spéciale du RE quand l’AT DEC est complété. Au besoin, l’agent saisit manuellement l’exclusion dans ETI.
       [Rendre une décision sur un départ volontaire : Demande initiale — Niveau 2](/fr/procedure/task/vllevel2_ic.shtml)

**Niveaux de décision**

Quand TAD ne peut pas rendre une décision sur le départ volontaire, un AT DEC est créé et assigné au niveau approprié, conformément à la Politique nationale sur les niveaux de décision .
       [Politique nationale sur les niveaux de décision](/fr/policy/nationalpolicy/levels_decision-annex1.shtml)

**Examiner une demande initiale ou renouvelée**

Quand un client indique sur sa demande qu’il a déjà fourni les détails du MCE, le questionnaire sur le départ volontaire n’est pas présenté au client. Les mêmes conditions s’appliquent si un client ne déclare pas un MCE litigieux dans sa demande. Dans ce cas, l’agent de Niveau 1 effectue un recueil de faits avec le client afin de déterminer la procédure à suivre. Si le client soumet un motif qui ne relève pas du Niveau 1, l’agent réassigne l’AT au Niveau 2.

**Rendre une décision sur une demande continue**

Pour les demandes continues, l’agent crée le RE manuellement et, au besoin, saisit l’exclusion dans ETI. 

### Motif de cessation d’emploi (MCE) — Mesures temporaires du budget

Source topic: `fr_FR/activity/voluntary_leaving/motif_de_cessation_demploi_mce__mesures_fe447e72.dita`

**Rendre une décision sur la dernière période d’emploi dans la période de référence — DPP entre la s/c 2310 et la s/c 2361**

Le budget 2021 a introduit une mesure de simplification temporaire à partir du 26 septembre 2021. Pour les demandes dont le DPP est entre la s/c 2310 et la s/c 2361, l’agent rend une décision sur la dernière période d’emploi dans la PR seulement si elle est litigieuse. Si l’agent autorise le dernier MCE, tout autre RE dans la PR, même s’il est litigieux, est utilisé pour calculer la demande. Cependant, si l’agent n’autorise pas le MCE du dernier RE dans la PR, la demande est calculée avec une exclusion.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0168.dita) 

Cette nouvelle mesure ne s’applique pas aux demandes de pêcheur et des travailleurs indépendants. Au lieu, si le client a un emploi assurable dans la PR avec un MCE litigieux et un DPP entre la s/c 2310 et la s/c 2361 quand il présente une demande de prestations pour travail indépendant (TI) ou de pêcheur, l’agent doit rendre une décision sur le MCE litigieux selon les procédures habituelles pour rendre une décision.

Quand le client déclare un MCE litigieux auprès d’autres employeurs dans la même demande, si TAD n’autorise pas le litige en vertu des règles de décision automatique, le litige est automatiquement résolu et TAD crée un rapport de décision (RD) qui indique Aucune décision requise . Le champ Condition spéciale du RE n’est pas mis à jour, et le RE est inclus dans le calcul. Aucun AT Litige - Décision (DEC) n’est créé pour le MCE.

Quand il y a plus d’un RE avec le même dernier jour payé (DJP), et qu’une des RE est litigieux alors que l’autre RE ne l’est pas, une décision n’est pas requise et les 2 RE seront inclus dans le calcul.

**Décision non requise : Motif de cessation d’emploi (MCE) au-delà de 12 semaines — DPP entre la s/c 2258 et la s/c 2309**

Les principes de décision dans les demandes initiales ou de nouveau calcul dont le DPP est entre la s/c 2258 et la s/c 2309 s’appliquent seulement au MCE du dernier emploi dans la PR et aux questions liées aux MCE litigieux qui sont dans la période de 12 semaines avant l’A de R utilisé pour établir la demande.

**Décision non requise antérieurement — Processus spécialisé du TAD**

Un nouveau processus spécialisé qui simplifie le traitement des demandes initiales a été présenté le 27 septembre 2020. Les demandes traitées dans ce processus spécialisé du TAD ont été établies sans rendre de décision sur les questions litigieuses liées au MCE dans la PR. Il est possible de repérer les questions liées au MCE pour lesquels aucune décision n'a été rendue, car le champ Condition spéciale a été laissé vide sur le RE, mais le RE a tout de même été inclus dans le calcul initial.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0092.dita) 

Si aucune décision n’a été rendue sur un MCE litigieux dans la PR dans une demande initiale de prestations régulières lors du processus spécialisé du TAD, il n’est pas nécessaire de rendre une décision sur la demande renouvelée tant que le client demande toujours des prestations régulières. Cependant, il pourrait y avoir un AT DEC en suspens.

S’il existe un AT DEC en suspens pour un MCE litigieux dans la PR, l’agent ne rend pas de décision sur la question. Pour supprimer l’AT DEC en suspens, l’agent envoie une demande à un utilisateur autorisé afin qu’il le supprime.

S’il existe un AT EVD Renouvellement et un AT DEC en suspens pour un MCE litigieux dans la PR, l’agent de Niveau 1 traite l’AT EVD Renouvellement même si l’AT DEC demeure en suspens. L’agent :

- détermine la date d’entrée en vigueur du renouvellement;

- saisit le renouvellement et complète le numéro d’enregistrement;

- complète l’AT EVD Renouvellement.

L’agent complète l’AT EVD Renouvellement avant d’envoyer une demande à un utilisateur autorisé afin qu’il supprime l’AT DEC en suspens.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0093.dita) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0167.dita`

Remarque :

Pour des demandes entre la s/c 2310 et la s/c 2361, les RE exclus s’appliquent seulement aux demandes de prestations pour TI et de pêcheur. 

### Note

Source topic: `fr_FR/common_notes/note_c_0168.dita`

Note:

Pour toutes les demandes initiales dont le DPP provisoire est la s/c 2361, des AT DEC sont créés pour la dernière période d’emploi et pour toute autre période d’emploi litigieuse dans la PR. L’agent suit les procédures habituelles pour rendre une décision sur ces AT, car le DPP final peut être la s/c 2362 ou après. Toutefois, si le DPP final est entre la s/c 2310 et la s/c 2361, le système applique les mesures temporaires du budget 2021. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0092.dita`

Remarque :

Le processus spécialisé du TAD se termine le 16 août 2021. À partir de cette date, TAD crée un AT DEC pour les questions litigieuses liées aux MCE dans la PR, puisqu’il n’établit plus de demandes sans rendre de décision sur celles-ci. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0093.dita`

Remarque :

Une décision doit être rendue pour toute question litigieuse liée au MCE dans la période de prestation (PP). 

## Considérations régionales

Source topic: `fr_FR/activity/voluntary_leaving/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/voluntary_leaving/ce_quil_faut_chercher.dita`

### Dans SNCT :

Source topic: `fr_FR/activity/voluntary_leaving/dans_snct.dita`

- La déclaration du client se trouve-t-elle dans la section Départ volontaire de la présente demande ou d’une demande précédente?

- Y a-t-il des RSDP, des AT Action à prendre ou des documents contenant des aide-mémoire ou d’autres précisions concernant le départ volontaire dans la présente demande ou une demande précédente? 

### Dans Imagerie :

Source topic: `fr_FR/activity/voluntary_leaving/dans_imagerie.dita`

- Y a-t-il des documents numérisés ayant trait à la demande de départ volontaire? (Les documents pourraient avoir été reçus avant la présentation de la plus récente demande.) 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/voluntary_leaving/que_voulez-vous_faire.dita`

## Références politiques

Source topic: `fr_FR/activity/voluntary_leaving/references_politiques.dita`

 
