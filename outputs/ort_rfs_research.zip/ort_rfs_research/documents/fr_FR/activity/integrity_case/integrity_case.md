# Cas d’Intégrité

Source map: `fr_FR/activity/integrity_case/integrity_case.ditamap`

## Sommaire

Source topic: `fr_FR/activity/integrity_case/sommaire.dita`

Sommaire : Les enquêteurs consignent les faits d’une enquête et incluent leur recommandation quand il y a des déclarations fausses ou trompeuses ou des actes délictueux qui peuvent avoir une incidence sur l’admissibilité à l’AE et quand une tierce personne a utilisé de façon frauduleuse les renseignements personnels d’un client pour obtenir des prestations. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/integrity_case/ce_quil_faut_savoir.dita`

### Processus décisionnel

Source topic: `fr_FR/activity/integrity_case/processus_decisionnel.dita`

Cette activité indique les étapes à suivre quand il a été déterminé qu’une déclaration fausse ou trompeuse entraîne une exclusion ou une question liée à l’admissibilité aux prestations d’AE. L’agent doit rendre une décision sur la question en suivant les procédures de cette section.

S’il a été déterminé que la déclaration fausse, la déclaration trompeuse ou l’acte délictueux a été fait sciemment par le client, l’agent doit suivre les procédures décrites plus bas pour rendre une décision sur la question liée à l’admissibilité aux prestations d’AE. L’agent doit consulter Acte délictueux afin de déterminer le genre de sanction à imposer. L’agent doit saisir la décision complète après avoir déterminé la sanction.
       [Acte délictueux](/fr/procedure/activity/misrepresentation.shtml) 

### Seuil pour la tenue d’enquêtes

Source topic: `fr_FR/activity/integrity_case/seuil_pour_la_tenue_denquetes.dita`

Le montant de seuil pour la tenue d’enquêtes d’Intégrité est de 400 $. Les enquêtes pour la vérification postérieure automatisée ne seront pas générées quand le trop-payé (T-P) est inférieur à 400 $. Intégrité peut également prendre en considération que d’autres enquêtes sont en règle quand le T-P est inférieur au seuil. Les cas dans lesquels le T-P est inférieur au seuil sont envoyés pour décision seulement quand des exceptions précises sont respectées (divulgation volontaire ou incidence sur une demande active). L’agent n’ est pas tenu de valider le seuil.

L’agent traite tous les AT Révision de la demande (RVD) Intégrité selon les procédures normales même si, après la décision, il a été déterminé que le T-P est inférieur au seuil. 

### Réviser une décision

Source topic: `fr_FR/activity/integrity_case/reviser_une_decision.dita`

La LAE 52 stipule que toute demande de prestations peut être révisée, à condition qu’elle entraîne un T-P ou un moins payé (M-P). Le délai prescrit pour réviser une demande est de 36 mois à partir de la semaine où des prestations ont été payées ou étaient payables. Cette période peut être prolongée à 72 mois s’il y a présence de déclaration fausse ou trompeuse.
       [LAE 52](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-52.html) 

### Déterminer si une fausse déclaration a été faite

Source topic: `fr_FR/activity/integrity_case/determiner_si_une_fausse_declaration_a_ete_faite.dita`

Une fausse déclaration est une déclaration inexacte ou erronée. Il peut s’agir d’une action intentionnelle ou négligente, ou il peut s’agir d’une simple erreur.

Par exemple, un client déclare avoir gagné un salaire de 100 $, mais une enquête ultérieure démontre que le client a vraiment gagné 225 $. À cette étape, l’agent sait seulement que les renseignements fournis par le client sont incorrects. Sans l’explication du client, il est impossible de déterminer si le client a intentionnellement ou sciemment fourni le mauvais montant. Peu importe si c’est intentionnel ou une simple erreur, le client a déclaré le mauvais montant. Par conséquent, la période de révision peut être prolongée à 72 mois. 

### Fausse déclaration faite sciemment

Source topic: `fr_FR/activity/integrity_case/fausse_declaration_faite_sciemment.dita`

Sciemment signifie que l’agent peut raisonnablement conclure que le client savait que les renseignements qu’il fournissait étaient erronés quand il les a fournis ou qu’il ne les a pas déclarés. Il n’y a pas d’élément d’intention dans cette considération. Il n’est pas nécessaire de déterminer un degré de faute. On doit seulement établir qu’il est probable que le client savait que les renseignements fournis n’étaient pas conformes à la réalité. 

### Divulgation volontaire

Source topic: `fr_FR/activity/integrity_case/divulgation_volontaire.dita`

Cette politique encourage les clients, les employeurs et les tierces personnes à se manifester et à divulguer volontairement les actes délictueux. En vertu de cette politique, il y a divulgation volontaire quand une personne admet avoir commis sciemment une fausse déclaration.

Il peut arriver qu’un enquêteur recommande de réviser le dossier sous l’angle de la Politique nationale sur la divulgation volontaire .
       [Politique nationale sur la divulgation volontaire](/fr/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

Il y a 2 critères essentiels pour accepter une divulgation volontaire :

- Il n’y a aucune enquête en cours portant sur la divulgation volontaire au moment où le client admet avoir fait une fausse déclaration.

- Sans la divulgation volontaire, la fausse déclaration aurait entraîné une sanction punitive telle qu’une pénalité, un avertissement ou une poursuite.

Il n’y a pas de limite au nombre de fois qu’un client peut profiter de cette politique de divulgation volontaire.

Quand la divulgation volontaire est acceptée, le client, l’employeur ou une tierce personne bénéficiera des privilèges suivants :

- pas de pénalité, de lettre d’avertissement ou de poursuite;

- pas d’augmentation des normes d’admissibilité à la période de prestations (violation);

- aucun intérêt n’est appliqué au T-P;

- l’acte délictueux n’est pas pris en considération dans la détermination de l’existence d’un acte délictueux répétitif.

Toutefois, le T-P causé par la divulgation volontaire est jugé frauduleux. Il ne peut pas être rayé et il ne disparaît pas en cas de faillite. 

### Responsabilités de l’enquêteur

Source topic: `fr_FR/activity/integrity_case/responsabilites_de_lenqueteur.dita`

L’enquêteur attitré à l’enquête doit recueillir tous les faits et la documentation pertinente en lien avec la question liée à l’admissibilité ou la question litigieuse et soumettre le dossier et des recommandations au Niveau 2. 

### Responsabilités de l’agent de Niveau 2

Source topic: `fr_FR/activity/integrity_case/responsabilites_de_lagent_de_niveau_2.dita`

L’agent de Niveau 2 est responsable du traitement de l’AT RVD Intégrité qui lui est assigné. L’agent doit consulter SNEI pour chaque cas afin d’y retrouver tous les renseignements pertinents pour rendre une décision (p. ex. les déclarations du client, les déclarations de l’employeur ou d’une tierce personne et le rapport d’enquête).

L’agent de Niveau 2 consulte aussi l’Imagerie pour y retrouver toute documentation qui peut être liée au litige identifié.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0120.dita) 

L’agent de Niveau 2 s’assure que tous les faits essentiels sont complets et rend une décision juste et équitable en fonction de ceux-ci. L’agent de Niveau 2 n’est pas lié par la recommandation de l’enquêteur. 

### Rendre une décision sur les motifs de cessation d’emploi (MCE) non déclarés et litigieux

Source topic: `fr_FR/activity/integrity_case/rendre_une_decision_sur_les_motifs_de_c_b5d9b0aa.dita`

L’agent de Niveau 2 rend une décision sur tous les MCE litigieux pendant une période de référence (PR) et une période de prestations (PP) qui font partie de l’enquête d’Intégrité. La décision d’une enquête d’Intégrité ne peut pas être reportée. 

### Retourner un dossier à Intégrité

Source topic: `fr_FR/activity/integrity_case/retourner_un_dossier_a_integrite.dita`

Après avoir effectué un examen complet de l’enquête, si l’agent de Niveau 2 détermine que des faits sont manquants, il doit retourner l’enquête à Intégrité pour qu’un recueil de faits complémentaires soit effectué. Il doit indiquer les renseignements manquants, mais nécessaires pour rendre une décision. L’agent de Niveau 2 ne doit pas rendre de décision si des faits sont manquants ou incomplets.

Les faits ne sont pas considérés comme manquants ou incomplets si l’enquêteur a effectué un suivi auprès du client quand celui-ci ne se présente pas pour une entrevue ou ne répond pas à une demande pour obtenir des renseignements. L’enquêteur n’est pas tenu d’envoyer une lettre de suivi, mais doit tenter à 2 reprises dans 2 jours différents de communiquer avec le client par téléphone. Si l’enquêteur laisse un message dans la messagerie vocale, une seule tentative pour communiquer est requise et l’enquêteur doit donner 48 heures au client pour répondre.

Si l’enquêteur recommande que le cas d’Intégrité soit considéré comme un cas de divulgation volontaire, mais que le genre d’enquête dans SNEI n’est pas correct, l’agent retourne le dossier à Intégrité.

Quand il rend une décision sur un cas de rémunération non déclarée, l’agent de Niveau 2 peut remarquer que l’employeur n’a pas complètement rempli la section sur les autres sommes sur le formulaire INS5097. Dans ce cas, l’agent retourne le cas à Intégrité pour un autre recueil de faits seulement dans la situation suivante :

- L’enquêteur, alors qu’il examine le cas, doit communiquer avec l’employeur pour clarifier d’autres questions au sujet du formulaire INS5097 mais ne demande pas de précisions à propos de la section sur les autres sommes.

Si l’employeur n’a pas rempli la section sur les autres sommes, l’agent de Niveau 2 rend une décision sur le cas, tel quel. Par conséquent, l’on suppose qu’aucune autre somme n’a été versée au client.

Si l’employeur a choisi Oui dans la section sur les autres sommes mais n’a pas fourni de détails, l’agent de Niveau 2 rend une décision sur le cas, tel quel, si l’enquêteur, alors qu’il examinait le cas, n’a pas communiqué avec l’employeur pour clarifier d’autres questions au sujet du formulaire INS5097. 

### Envoyer une demande pour un nouveau calcul

Source topic: `fr_FR/activity/integrity_case/envoyer_une_demande_pour_un_nouveau_calcul.dita`

Quand il s’agit d’une évaluation d’un MCE et qu’un nouveau RE doit être inclus au calcul du taux, une révision rétroactive du calcul de la demande est requise, peu importe l’incidence (création d’un T-P ou d’un M-P) que ce RE a sur le taux de prestations et la durée de la demande.
       [une révision rétroactive](/fr/policy/bememo/be2007-04.shtml)

Dans de telles situations, l’agent de Niveau 2 rend une décision sur le MCE et complète toutes les actions nécessaires liées à l’AT RVD Intégrité. Par la suite, l’agent de Niveau 2 crée un AT RVD afin que l’agent de Niveau 1 puisse réviser le calcul de la demande. 

### Meilleures semaines variables (MSV)

Source topic: `fr_FR/activity/integrity_case/meilleures_semaines_variables_msv.dita`

Si des renseignements supplémentaires contredisent les renseignements utilisés pour établir une demande de prestations en fonction de la politique de calcul du taux de prestations, l’agent révise la demande pour s’assurer que l’admissibilité a été correctement déterminée.

Dans de telles situations, l’agent de Niveau 2 rend une décision sur le MCE et complète toutes les actions nécessaires liées à l’AT RVD Intégrité. Par la suite, l’agent de Niveau 2 crée un AT Action à prendre (AP) pour le Niveau 1 pour un nouveau calcul de la demande.

     [Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0121.dita) 

### Examiner la conformité du programme relatif à la validation de l’adresse du domicile de l’AE

Source topic: `fr_FR/activity/integrity_case/examiner_la_conformite_du_programme_rel_82bbb485.dita`

Les enquêteurs examinent un échantillon de demandes d’AE au hasard pour vérifier si la bonne adresse de domicile a été utilisée pour établir l’admissibilité du client à des prestations d’AE. 

### Examiner la conformité du Programme de réduction du taux de cotisation (PRTC)

Source topic: `fr_FR/activity/integrity_case/examiner_la_conformite_du_programme_de__c4ad4ae0.dita`

Les enquêteurs examinent un échantillon de demandes de prestations de maladie d’AE pour déterminer si les clients ont reçu ou étaient admissibles à un congé de maladie payé ou à une indemnité d’assurance-salaire avec leur employeur.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0122.dita) 

### Examen de conformité de la recherche d’emploi

Source topic: `fr_FR/activity/integrity_case/examen_de_conformite_de_la_recherche_demploi.dita`

Les enquêteurs effectuent des examens de conformité de la recherche d’emploi des clients du programme d’AE sélectionnés afin de déterminer s’ils ont rempli leurs obligations d’être prêts et disposés à travailler, de chercher activement un emploi convenable et de l’accepter, et de tenir un dossier détaillé de leurs efforts de recherche d’emploi. 

### Partager des prestations parentales

Source topic: `fr_FR/activity/integrity_case/partager_des_prestations_parentales.dita`

Les enquêteurs examinent les demandes d’AE qui comprennent des prestations parentales partagées pour déterminer si les clients étaient admissibles aux prestations parentales reçues. Cela s’applique seulement aux clients qui ont partagé des prestations parentales avant septembre 2019. 

### Paiement en double

Source topic: `fr_FR/activity/integrity_case/paiement_en_double.dita`

Les enquêteurs déterminent si un client a reçu le paiement initial et le remplacement de paiement quand le client conteste avoir reçu les 2 paiements et si une demande trace a déjà été traitée. 

### Prestation d’AE d’urgence (PU AE) — Examen de la rémunération

Source topic: `fr_FR/activity/integrity_case/prestation_dae_durgence_pu_ae__examen_d_d9e0a073.dita`

Intégrité examine l’admissibilité des clients à la PU AE qu’ils ont reçue alors qu’ils ont gagné une rémunération pendant la période de la PU AE.

Ces procédures s’appliquent seulement aux agents de Niveau 2 qui font partie de l’équipe chargée des décisions de Niveau 2 traitant les cas de rémunération liée à la PU AE. 

### Demandes d’AE frauduleuses

Source topic: `fr_FR/activity/integrity_case/demandes_dae_frauduleuses.dita`

Les enquêteurs examinent les demandes d’AE potentiellement frauduleuses dans lesquelles une tierce personne a compromis les renseignements personnels du client et les a utilisés pour tenter d’obtenir des prestations. Les enquêteurs créent un AT RVD Intégrité Transition PCU-AE s’il est confirmé qu’une demande d’AE ou des paiements émis dans une demande d’AE sont frauduleux. Ces cas sont traités seulement par les agents faisant partie de l’équipe spécialisée traitant les cas de fraude. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0120.dita`

Exemple :

S’il y a une vérification postérieure pour une correction de rémunération, le formulaire Demande de renseignements sur l’emploi (INS5098) et le formulaire Demande de renseignements-registres de paie (INS5097) peuvent être disponibles dans Imagerie. 

### Exemple

Source topic: `fr_FR/common_notes/note_c_0121.dita`

Exemple :

Le client ne fournit pas de renseignements sur ses meilleures semaines, alors le taux de prestations est calculé à partir de la moyenne proportionnelle des RE. Intégrité obtient les données réelles, ce qui peut diminuer ou augmenter le taux de prestations. L’agent ne calcule pas à nouveau le taux de prestations, car la politique a été appliquée correctement dès le début, et le client n’a pas fourni de renseignements erronés ou trompeurs qui ont été utilisés pour calculer la demande. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0122.dita`

Remarque :

L’examen de conformité du PRTC de l’AE a été suspendu. 

## Considérations régionales

Source topic: `fr_FR/activity/integrity_case/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/integrity_case/ce_quil_faut_chercher.dita`

### Dans SNEI :

Source topic: `fr_FR/activity/integrity_case/dans_snei.dita`

- Quel est le litige indiqué?

- L’enquête est-elle le résultat d’un examen de conformité de programme? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/integrity_case/que_voulez-vous_faire.dita`

## Référence de politique

Source topic: `fr_FR/activity/integrity_case/reference_de_politique.dita`

 
