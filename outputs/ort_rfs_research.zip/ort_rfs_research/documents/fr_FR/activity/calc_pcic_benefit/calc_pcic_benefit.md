# Traiter le calcul ou le nouveau calcul d’une demande de prestations pour proches aidants

Source map: `fr_FR/activity/calc_pcic_benefit/calc_pcic_benefit.ditamap`

## Sommaire

Source topic: `fr_FR/activity/calc_pcic_benefit/sommaire.dita`

Sommaire : Quand un client présente une demande de prestations pour proches aidants (PPA), un agent doit calculer la demande. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/calc_pcic_benefit/ce_quil_faut_savoir.dita`

### Untitled section

Source topic: `fr_FR/activity/calc_pcic_benefit/untitled_section.dita`

[Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0041.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0019.dita) 

### Calculer manuellement une demande

Source topic: `fr_FR/activity/calc_pcic_benefit/calculer_manuellement_une_demande.dita`

Le calcul manuel d’une demande de PPA est complexe et doit être fait seulement par un agent qui a suivi la formation nécessaire.

Un agent traite le calcul ou le nouveau calcul d’une demande quand :

- un client présente une demande de prestations sur papier;

- TAD n’est pas en mesure de traiter le calcul d’une demande électronique;

- une demande nécessite un nouveau calcul et que TAD n’est pas en mesure d’automatiser le nouveau calcul. 

### Calcul ou nouveau calcul

Source topic: `fr_FR/activity/calc_pcic_benefit/calcul_ou_nouveau_calcul.dita`

Quand un AT Évaluation de la demande (EVD) ou Demande spécialisée (DS) est reçu, l’agent doit effectuer le calcul initial de la demande.

Quand un AT Révision de la demande (RVD) avec un problème lié au nouveau calcul est reçu, l’agent doit effectuer le nouveau calcul d’une demande qui était finalisée. On se sert parfois de « recalcul » pour parler d’un nouveau calcul. Une fois qu’un calcul initial est bien transmis, un nouveau calcul d’une demande doit être effectué quand de nouveaux renseignements reçus auront une incidence sur le résultat du calcul précédent (p. ex. un RE modifié est émis).

Quand un nouveau calcul est requis pour un cas d’Intégrité, un AT Action à prendre (AP) urgent est créé pour le nouveau calcul. L’agent assigné à cet AT doit effectuer le nouveau calcul.

Le nouveau calcul d’une demande peut avoir une incidence sur :

- la possibilité du client d’établir une période de prestations (PP);
         [période de prestations](/fr/procedure/generic/knowledge.shtml#Etablissement_de_la_periode_de_prestati)

- l’admissibilité du client aux prestations;

- le taux de prestations du client.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0020.dita) 

### Effectuer le nouveau calcul d’une demande touchée par la modification d’un NAS ou d’une région

Source topic: `fr_FR/activity/calc_pcic_benefit/effectuer_le_nouveau_calcul_dune_demand_69c56db8.dita`

Si le client a déménagé dans une autre région, que son NAS a été modifié, ou les 2, depuis le calcul de la demande initiale, il peut ne pas être possible d’enregistrer le nouveau calcul dans la version Web de SSA. Le nouveau calcul doit être enregistré dans le centre de technologie de l’information (CTI) initial et sous le NAS précédent au besoin, mais il doit être saisi manuellement dans ETI avec le CTI actuel et le nouveau NAS, si applicable.

Pour plus de renseignements, l’agent consulte les annexes B, C et D du Guide de saisie des données de nouveau calcul – version SSA .
       [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Structure des procédures de calcul

Source topic: `fr_FR/activity/calc_pcic_benefit/structure_des_procedures_de_calcul.dita`

La procédure de calcul est divisée en sous-activités afin de fournir une séquence logique à suivre lorsqu’une demande est calculée. Bien que chaque agent ait une séquence préférée qui est aussi correcte, la procédure est structurée afin d’assurer que l’agent effectue toutes les mesures nécessaires pour traiter la demande :

- Déterminer si une demande est prête à être calculée.

- Calculer une demande dans la version Web de SSA.

- Examiner le résultat du calcul.

- Examiner et saisir le calcul.

- Communiquer les décisions après le calcul.

Chaque sous-activité comporte des liens menant à des procédures supplémentaires qui peuvent être nécessaires pour terminer le processus de calcul. 

### Gérer l’AT

Source topic: `fr_FR/activity/calc_pcic_benefit/gerer_lat.dita`

Peu importe la façon dont un agent organise son travail, l’agent à qui est assigné le calcul de la demande doit s’assurer que tout problème est résolu et que tous les faits nécessaires pour calculer la demande sont au dossier avant de compléter le calcul. À moins que les procédures fassent état d’une directive contraire, le calcul ne doit pas être complété tant que tous les AT nécessaires pour finaliser le calcul n’ont pas été complétés. Si le calcul ne peut pas être complété parce qu’il y a un AT connexe en suspens, l’AT du calcul doit être déplacé vers En suspens jusqu’à ce que l’AT connexe soit complété.

Il se peut que des AT liés à une même demande faisant l’objet d’une évaluation soient assignés à divers agents (p. ex. un AT RE Litigieux motif de cessation d’emploi [MCE] est assigné à un agent et un AT EVD est assigné à un autre agent). L’agent complète seulement l’AT qui lui est assigné, sauf si une procédure prévoit le contraire.

Quand il évalue une demande, l’agent à qui a été assigné un AT du calcul doit aussi examiner la Note client afin de déterminer les mesures à prendre (p. ex. saisir des transactions, envoyer des lettres).

Quand le calcul est complété, l’agent doit communiquer la décision au client si nécessaire. 

### Choisir le genre de prestation (GP) approprié

Source topic: `fr_FR/activity/calc_pcic_benefit/choisir_le_genre_de_prestation_gp_approprie.dita`

Quand l’enregistrement d’une demande crée automatiquement un AT RVD, dans SNCT, le champ Genre de prestations de l’AT RVD est prérempli par Régulier. L’agent met manuellement à jour ce champ avec le GP approprié. Pour une demande initiale ou renouvelée, l’agent choisit le GP indiqué dans la demande d’AE. Pour une demande de conversion dans une demande continue ou toute autre demande de conversion, l’agent choisit le nouveau GP demandé.

Lors de la création d’un AT AP, Rappel (RA), Évaluation pour le calcul (ECAL) ou À revoir (AR), l’agent choisi le GP indiqué dans la demande d’AE. Si le GP a été modifié depuis que le client a présenté sa demande de prestations, l’agent choisit le nouveau GP demandé. 

### Partager des renseignements

Source topic: `fr_FR/activity/calc_pcic_benefit/partager_des_renseignements.dita`

Les membres de la famille peuvent partager une demande de PPA pour un même patient.
       [membres de la famille](/fr/procedure/generic/additionalresources/definition_fam_mem.shtml)

Quand un client présente une demande de PPA, il faut informer le client que dans certains cas, les renseignements pourraient être partagés avec d’autres membres de la famille du patient. L’identité du client pourrait être dévoilée aux autres membres de la famille qui ont effectué une demande pour des PPA. De même, le nombre de semaines payées ou payables pourrait également être dévoilé à un membre de la famille qui effectue une demande de PPA.

Si une personne qui n’est pas un client veut savoir si d’autres membres de la famille du patient ont effectué une demande de PPA ou ont reçu des PPA, l’agent doit l’informer que ce renseignement ne peut être dévoilé. Toutefois, si une personne a l’intention de présenter une demande de PPA, le nombre de semaines payables peut être dévoilé. L’agent ne peut pas fournir d’autres renseignements tant que la demande n’a pas été présentée. L’agent ne doit jamais révéler le NAS d’un client . 

### Remplir les conditions requises pour des prestations pour proches aidants (PPA)

Source topic: `fr_FR/activity/calc_pcic_benefit/remplir_les_conditions_requises_pour_de_f2e6e6a0.dita`

Pour remplir les conditions requises pour recevoir des PPA, un client doit remplir les conditions suivantes :

- Le client a présenté une demande de prestations.

- Le client a subi un arrêt de rémunération (A de R) pendant sa période de référence (PR).
         [arrêt de rémunération](/fr/procedure/generic/knowledge.shtml#Arret_de_remuneration) 
         [période de référence](/fr/procedure/generic/knowledge.shtml#Periode_de_reference)

- Le client est de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable.
         [première catégorie](/fr/procedure/generic/knowledge.shtml#client12)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0021.dita) 

**Remplir les conditions requises avec la norme d’admissibilité commune (NAC) (de la s/c 2310 à la s/c 2361)**

Dans le cadre du budget 2021, le gouvernement du Canada a annoncé qu’une NAC nationale de 420 heures d’emploi assurable s’applique pour établir une demande de prestations régulières ou spéciales. Si le client a une violation à son dossier, une majoration des conditions requises pourrait s’appliquer. La NAC s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, les définitions de prestataire de première et de deuxième catégorie dans la LAE 6(1) sont abrogées. Les clients dont la demande est établie avec 420 heures d’emploi assurable remplissent les conditions requises pour recevoir des prestations spéciales. L’agent s’assure que toutes les autres conditions requises et d’admissibilité sont remplies.
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Admissibilité aux prestations pour proches aidants (PPA)

Source topic: `fr_FR/activity/calc_pcic_benefit/admissibilite_aux_prestations_pour_proc_95f5b323.dita`

Pour être admissible aux PPA, un client doit remplir les conditions requises :

- Être un membre de la famille du patient ou considéré comme tel par le patient.

- Fournir un certificat médical signé par un médecin ou un infirmier praticien avec l’information :

- La vie du patient est ou était à risque en raison d’une maladie ou d’une blessure.

- Il y a ou il y a eu un changement considérable de l’état de santé habituel du patient.

- Le patient nécessite des soins ou du soutien d’au moins un membre de sa famille.

- La période prévue pendant laquelle le patient requiert les soins ou le soutien.

- Indique qui peut signer le formulaire d’autorisation de divulguer des renseignements médicaux.

- Fournir des soins ou du soutien au patient dont le nom figure sur le certificat médical.

- Demande des prestations pendant la fenêtre proches aidants (FPA) établie pour le patient.

- Les semaines payables des PPA n’ont pas déjà été payées dans la FPA du patient.

Un client de première catégorie est admissible à des prestations spéciales peu importe le MCE.
       [prestations spéciales](/fr/procedure/generic/knowledge.shtml#Prestations_speciales)

Une inadmissibilité administrative est imposée pour empêcher le paiement de prestations régulières à un client qui est admissible aux prestations spéciales mais pas aux prestations régulières. 

### Certificat médical

Source topic: `fr_FR/activity/calc_pcic_benefit/certificat_medical.dita`

Un client qui présente une demande de PPA doit fournir un certificat médical qui prouve que le membre de sa famille est ou était gravement malade et a besoin de soins et de soutien d’un ou de plusieurs membres de sa famille. Le certificat médical doit être rempli par un médecin ou un infirmier praticien et indiquer une période spécifique pendant laquelle les soins et le soutien des membres de la famille sont requis. Le client doit aussi fournir le formulaire Autorisation de divulguer des renseignements médicaux pour des prestations de compassion et pour proches aidants de l’assurance-emploi (INS5257) .
       [Autorisation de divulguer des renseignements médicaux pour des prestations de compassion et pour proches aidants de l’assurance-emploi (INS5257)](https://catalogue.servicecanada.gc.ca/content/EForms/fr/Detail.html?Form=INS5257)

Il n’est pas toujours nécessaire pour un client de soumettre un certificat médical puisqu’un seul certificat médical est requis par patient et par FPA, peu importe le nombre de membres de la famille qui reçoivent des prestations pour prodiguer des soins ou du soutien au patient. Si un certificat médical est nécessaire et n’est pas fourni ou que les critères d’admissibilité ne sont pas remplis, l’agent impose une inadmissibilité 63 - Prestations pour proches aidants - Aucune preuve médicale sur la demande. Les agents ne doivent pas demander un certificat médical à moins qu’il soit nécessaire. Si un certificat médical est reçu, mais non exigé, l’agent doit l’examiner et mettre à jour le dossier en fonction des renseignements fournis par le certificat médical. 

### Fenêtre pour proches aidants (FPA)

Source topic: `fr_FR/activity/calc_pcic_benefit/fenetre_pour_proches_aidants_fpa.dita`

Quand un certificat médical pouvant être accepté en tant que preuve de la condition médicale du patient est reçu, une FPA est établie pour une période de 52 semaines ou jusqu’au premier des événements suivants : la semaine du décès du patient, la semaine que le PP expire ou que toutes les semaines de PPA ont été payés. Une fois que la FPA est établie, elle ne peut être prolongée. Si des PPA supplémentaires sont requises, une nouvelle FPA peut être établie, à la fin de la FPA initiale.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0042.dita) 

### Verser des prestations

Source topic: `fr_FR/activity/calc_pcic_benefit/verser_des_prestations.dita`

Les PPA pour adultes et les PPA pour enfants sont traitées comme des GP distincts. Si un client remplit les critères pour les deux GP, les deux genres peuvent être versés dans le cadre d’une PP, jusqu’à concurrence du montant maximal auquel il est admissible. Toutefois, un client ne peut pas demander les deux GP (PPA pour adultes et PPA pour enfants) pour le même patient gravement malade ou blessé dans le cadre d’une même PP.

Les PPA (35 semaines pour les enfants et 15 semaines pour les adultes) n’ont pas à être versées consécutivement et peuvent être payées de manière intermittente pendant la PP ou partagées entre les membres de la famille, de la manière qui convient le mieux aux clients.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0043.dita) 

Une fois que la demande est établie et que l’admissibilité aux PPA est déterminée, des PPA sont payable pour chaque semaine pour laquelle le client soumet une déclaration du prestataire et pendant laquelle le client :

- déclare 5 jours de non-disponibilité;

- a fourni la preuve requise pour des PPA;

- n’a pas reçu de rémunération ou de répartition empêchant le versement d’un paiement;

- n’a pas fait l’objet d’une inadmissibilité empêchant le paiement.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0044.dita) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0041.dita`

Remarque :

Les demandes de PPA sont traitées par le centre de spécialisation en Ontario. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0019.dita`

Remarque :

À moins d’avis contraire, les références aux calculs s’appliquent aussi aux nouveaux calculs. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0020.dita`

Remarque :

Quand le nouveau calcul d’une demande est nécessaire, l’agent suit les procédures normales d’évaluation du calcul et consulte Nouveau calcul : Évaluation — Instructions ainsi que le Guide de saisie des données de nouveau calcul – version SSA , au besoin. Une demande qui nécessite un nouveau calcul doit être évaluée de la même façon qu’une demande qui nécessite un calcul initial.
       [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
       [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml)

     [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
     [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0021.dita`

Remarque :

S’il y a une violation au dossier du client, il se peut qu’il y ait une majoration des conditions requises .
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

     [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0042.dita`

Remarque :

Les PDC peuvent être versées soit avant le début de la FPA ou soit après sa fin, mais elles ne peuvent pas être versées pendant une FPA existante, pour le même patient. Toutefois, si les PPA ont été versées en premier et que le patient a connu un nouveau changement important de son état de santé de base, des PDC peuvent être versées. Il n’est pas nécessaire que la FPA soit terminée pour que les PDC puissent être versées. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0043.dita`

Remarque :

Le DC peut être reporté si le client reçoit des PPA.
       [DC](/fr/procedure/generic/knowledge.shtml#Delai_de_carence)

     [DC](/fr/procedure/generic/knowledge.shtml#Delai_de_carence) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0044.dita`

Remarque :

Un client recevant des PPA pourrait être exempté de remplir des déclarations du prestataire. 

## Considérations régionales

Source topic: `fr_FR/activity/calc_pcic_benefit/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/calc_pcic_benefit/ce_quil_faut_chercher.dita`

## Que voulez-vous faire?

Source topic: `fr_FR/activity/calc_pcic_benefit/que_voulez-vous_faire.dita`

- Déterminer si une demande de prestations est prête à être calculée — Prestations pour proches aidants
         [Déterminer si une demande de prestations est prête à être calculée — Prestations pour proches aidants](/fr/procedure/subactivity/detcalc_pcic.shtml)

- Calculer une demande dans la version Web de SSA
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Examiner le résultat du calcul
         [Examiner le résultat du calcul](/fr/procedure/subactivity/calc_result_ccb.shtml)

- Réviser et saisir le calcul
         [Réviser et saisir le calcul](/fr/procedure/subactivity/input_calculation_results.shtml)

- Communiquer les décisions après le calcul
         [Communiquer les décisions après le calcul](/fr/procedure/subactivity/communicating_calc_decisions.shtml) 

## Référence de politique

Source topic: `fr_FR/activity/calc_pcic_benefit/reference_de_politique.dita`

 
