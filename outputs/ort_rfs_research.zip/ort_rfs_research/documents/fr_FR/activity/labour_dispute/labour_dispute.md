# Conflit collectif

Source map: `fr_FR/activity/labour_dispute/labour_dispute.ditamap`

## Sommaire

Source topic: `fr_FR/activity/labour_dispute/sommaire.dita`

Sommaire : Quand un client cesse de travailler en raison d’un conflit collectif, son admissibilité à des prestations peut être touchée. L’agent doit vérifier la décision régionale et, au besoin, rendre une décision sur l’admissibilité aux prestations. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/labour_dispute/ce_quil_faut_savoir.dita`

### Admissibilité aux prestations pendant un conflit collectif

Source topic: `fr_FR/activity/labour_dispute/admissibilite_aux_prestations_pendant_u_24f74567.dita`

Un conflit collectif désigne tout conflit, entre employeurs et employés ou entre employés. Un conflit collectif peut être lié à l’emploi ou au non-emploi, ou aux conditions d'emploi.

Peu importe si le conflit collectif a été initié par une grève ou par un lock-out, l’incidence sur la demande demeure la même. Quand un client perd son emploi ou n’est plus en mesure de retourner au travail en raison d’un arrêt de travail causé par un conflit collectif à son lieu de travail, il n’est pas admissible aux prestations d’AE en vertu de la LAE.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0124.dita) 

### Rendre une décision sur un conflit collectif

Source topic: `fr_FR/activity/labour_dispute/rendre_une_decision_sur_un_conflit_collectif.dita`

Toutes les décisions sur un conflit collectif sont rendues par le coordonnateur régional des conflits collectifs approprié.

Le coordonnateur régional s’assure que le recueil de faits initial est effectué et que les décisions sur les conflits collectifs (p. ex. dates de début et de fin, dates d’inadmissibilité et toute exemption de l’inadmissibilité) sont rendues et affichées dans le Évènements majeurs en entreprise .
       [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Si un conflit collectif n’a pas encore été désigné ni saisi dans le Évènements majeurs en entreprise , l’agent remplit le formulaire Information initiale sur le conflit collectif et l’envoie par courriel au coordonnateur régional des conflits collectifs de la région où se trouve le siège social de l’employeur.
       [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
       [Information initiale sur le conflit collectif](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-F-Final.docx) 
       [coordonnateur régional des conflits collectifs](https://esdc.prv/fr/service-canada/ae/contacts/coordonnateurs_conflits_collectifs.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0125.dita) 

Si le conflit collectif a été affiché dans le Évènements majeurs en entreprise et que l’agent a besoin d’aide pour déterminer l’admissibilité, l’agent communique avec l’Expertise opérationnelle régionale.
       [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Étant donné qu’un conflit collectif est une situation temporaire, l’agent impose une inadmissibilité 5 - Conflit collectif (D5) plutôt qu’une exclusion.

L’inadmissibilité D5 est imposée pour indiquer la période de conflit collectif. Le client est inadmissible pour chaque jour d’arrêt de travail pendant la période de prestation (PP) jusqu’à ce que l’une des situations suivantes se produise :

- Le conflit collectif prend fin.

- Le client occupe régulièrement un emploi assurable ailleurs.

Le client n ’est pas inadmissible aux prestations s’il prouve que toutes les conditions sont respectées :

- Le client ne participe pas au conflit collectif.

- Le client ne finance pas le conflit collectif.

- Le client n’a pas d’intérêt immédiat lié au conflit collectif. 

### Calculer l’inadmissibilité d’un employé à temps partiel

Source topic: `fr_FR/activity/labour_dispute/calculer_linadmissibilite_dun_employe_a_4be348f8.dita`

Quand un client perd son emploi à temps partiel ou n’est pas en mesure de reprendre le travail à temps partiel en raison d’un conflit collectif, l’agent doit calculer le nombre de jours d’inadmissibilité à imposer par semaine.

L’agent doit créer une transaction Mémo pour le centre opérationnel (MM06) pour informer le COPA qu’il faut imposer une inadmissibilité partielle. 

### Niveaux de décision

Source topic: `fr_FR/activity/labour_dispute/niveaux_de_decision.dita`

L’agent de Niveau 1 peut traiter la décision, rendue par le coordonnateur régional, d’imposer une inadmissibilité ou d’accorder des prestations à un client qui perd son emploi en raison d’un arrêt de travail sur son lieu de travail si toutes les conditions suivantes sont remplies :

- La décision est tout à fait évidente.

- Aucun autre recueil de faits n’est nécessaire.

- Selon le recueil de faits relatif à la décision, on sait clairement à qui s’applique la décision.

Si un agent de Niveau 1 ne peut pas appliquer la décision rendue par le coordonnateur régional, l’agent transmet le MCE au Niveau 2 pour qu’une décision soit rendue.

Si le client présente une demande de prestations spéciales ou participe à la formation en vertu de l’Article 25, l’agent réassigne l’AT à un agent de Niveau 2 pour qu’il rende une décision. 

### Terminer une inadmissibilité liée à un conflit collectif

Source topic: `fr_FR/activity/labour_dispute/terminer_une_inadmissibilite_liee_a_un__4e4eefc8.dita`

L’agent termine une inadmissibilité D5 le jour précédant la date de fin du conflit collectif ou le jour précédant la date à laquelle le client a commencé à exercer ailleurs un emploi assurable régulier. Une révision du Évènements majeurs en entreprise est requise.
       [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Quand un client commence à travailler ailleurs pendant un conflit collectif, un agent de Niveau 2 doit décider si l’inadmissibilité D5 peut être terminée. Les 2 conditions suivantes doivent être remplies pour que l’agent puisse terminer l’inadmissibilité D5 :

- L’emploi est assurable.

- Le client exerce un emploi assurable régulier ailleurs qu’à l’endroit où il y a un conflit collectif.

Pour plus de renseignements, consulter le GDA 8 — Conflits collectifs .
       [GDA 8 — Conflits collectifs](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.html) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0124.dita`

Remarque :

Quand le motif de cessation d’emploi (MCE) dans le RE est Grève ou Lock-out , la demande initiale n’est pas automatisée et un AT Évaluation de la demande (EVD) est créé. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0125.dita`

Remarque :

Si le siège social de l’employeur est dans la région de l’Ouest du Canada et des Territoires et qu’un conflit collectif n’ a pas encore été affiché dans le Évènements majeurs en entreprise , les agents dans la région de l’Ouest du Canada et des Territoires envoie le formulaire Information initiale sur le conflit collectif à Technical Expertise Request Application (TERA) (en anglais seulement) et non au coordonnateur régional des conflits collectifs.
       [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
       [Information initiale sur le conflit collectif](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-F-Final.docx)

Les agents de toutes les autres régions envoient le formulaire Information initiale sur le conflit collectif uniquement au coordonnateur régional des conflits collectifs de la région où se trouve le siège social de l’employeur, par l’intermédiaire de la boîte GD du consultant en expertise opérationnelle régional.
       [Information initiale sur le conflit collectif](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-F-Final.docx)

     [Évènements majeurs en entreprise](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
     [Information initiale sur le conflit collectif](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-F-Final.docx) 
     [Information initiale sur le conflit collectif](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-F-Final.docx) 

## Considérations régionales

Source topic: `fr_FR/activity/labour_dispute/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/labour_dispute/ce_quil_faut_chercher.dita`

### Dans SNCT :

Source topic: `fr_FR/activity/labour_dispute/dans_snct.dita`

- Y a-t-il des RSDP, des RD ou des AT contenant des documents liés au conflit collectif?

- Y a-t-il des documents liés au conflit collectif? 

### Dans ETI :

Source topic: `fr_FR/activity/labour_dispute/dans_eti.dita`

- Y a-t-il une inadmissibilité D5 au dossier?

- Y a-t-il un traitement manuel 74 - Conflit collectif (TM74) imposé au dossier? 

### Dans Imagerie :

Source topic: `fr_FR/activity/labour_dispute/dans_imagerie.dita`

- Y a-t-il des documents numérisés liés au conflit collectif? 

### Évènements majeurs en entreprise :

Source topic: `fr_FR/activity/labour_dispute/evenements_majeurs_en_entreprise.dita`

- Y a-t-il des renseignements liés au conflit collectif? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/labour_dispute/que_voulez-vous_faire.dita`

## Référence de politique

Source topic: `fr_FR/activity/labour_dispute/reference_de_politique.dita`

 
