# Traiter le calcul ou le nouveau calcul d’une demande de prestations régulières

Source map: `fr_FR/activity/calculation/calculation.ditamap`

## Sommaire

Source topic: `fr_FR/activity/calculation/sommaire.dita`

Sommaire : Quand TAD n’est pas en mesure d’automatiser le calcul d’une demande de prestations régulières, la demande doit être calculée par un agent. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/calculation/ce_quil_faut_savoir.dita`

### Untitled section

Source topic: `fr_FR/activity/calculation/untitled_section.dita`

[Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0019.dita) 

**Calculer manuellement une demande**

Le calcul manuel d’une demande est complexe et doit être fait seulement par un agent qui a suivi la formation nécessaire.

L’agent doit traiter le calcul ou le nouveau calcul d’une demande quand :

- un client présente une demande de prestations sur papier

- TAD n’est pas en mesure de traiter le calcul d’une application électronique

- une demande nécessite un nouveau calcul et que TAD n’est pas en mesure d’automatiser le nouveau calcul 

### Demandes post-prestation d’AE d’urgence (PU AE)

Source topic: `fr_FR/activity/calculation/demandes_post-prestation_dae_durgence_pu_ae.dita`

Un client qui a reçu les 28 semaines de la PU AE et qui remplit les conditions requises est automatiquement inscrit aux prestations d’AE. Dans SNCT, une demande papier s’affiche dans l’ Arbre de visualisation des demandes pour les demandes inscrites automatiquement. Pour calculer la demande, l’agent utilise la demande la plus récente au dossier, qui peut remonter jusqu’au 4 mars 2020.

Les demandes inscrites automatiquement sont toujours enregistrées en tant que prestations régulières parce que dans la plupart des cas, 28 semaines ou plus se sont écoulées depuis la demande pour la PU AE la plus récente. La demande devrait rester une demande de prestations régulières à moins que les renseignements les plus récents au dossier indiquent le contraire ou que l’agent effectue un recueil de faits et le client demande un autre genre de prestations (GP). Les demandes inscrites automatiquement et complétées dans le processus spécialisé du TAD sont établies comme demandes de prestations régulières.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0045.dita) 

Toutes les nouvelles demandes reçues pour des prestations régulières dont le DPP est la s/c 2258 ou après, y compris toutes les demandes automatiquement inscrites, sont traitées en utilisant les mesures provisoires pour accélérer le processus de calcul.

Quand le processus spécialisé du TAD crée un AT ETD, aucun autre AT ne sera créé. L’agent doit examiner la demande la plus récente et déterminer si d’autres mesures sont requises avant de finaliser le calcul. 

### Calcul ou nouveau calcul

Source topic: `fr_FR/activity/calculation/calcul_ou_nouveau_calcul.dita`

Quand un AT Évaluation de la demande (EVD) ou Demande spécialisée (DS) est reçu, l’agent doit effectuer le calcul initial de la demande.

Quand un AT Révision de la demande (RVD) avec un problème lié au nouveau calcul est reçu, l’agent doit effectuer le nouveau calcul d’une demande qui était finalisée. On se sert parfois de recalcul pour parler d’un nouveau calcul. Une fois qu’un calcul initial est bien transmis, un nouveau calcul d’une demande peut être effectué quand de nouveaux renseignements reçus auront une incidence sur le résultat du calcul précédent (p. ex. un RE modifié est émis).

Quand un nouveau calcul est requis pour un cas d’Intégrité, un AT Action à prendre (AP) urgent est créé pour le nouveau calcul. L’agent assigné à cet AT doit effectuer le nouveau calcul.

Le nouveau calcul d’une demande peut avoir une incidence sur :

- la possibilité du client d’établir une période de prestations (PP);
         [période de prestations](/fr/procedure/generic/knowledge.shtml#Etablissement_de_la_periode_de_prestati)

- l’admissibilité du client aux prestations;

- le taux de prestations du client.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0055.dita) 

### Effectuer le nouveau calcul d’une demande touchée par la modification d’un NAS ou d’une région

Source topic: `fr_FR/activity/calculation/effectuer_le_nouveau_calcul_dune_demand_69c56db8.dita`

Si le client a déménagé dans une autre région, que son NAS a été modifié, ou les 2, depuis le calcul de la demande initiale, il peut ne pas être possible d’enregistrer le nouveau calcul dans la version Web de SSA. Le nouveau calcul doit être enregistré dans le centre de technologie de l’information (CTI) initial ou sous le NAS précédent, mais il doit être saisi manuellement dans ETI avec le CTI actuel et le nouveau NAS, si applicable.

Pour plus de renseignements, l’agent consulte les annexes B, C et D du Guide de saisie des données de nouveau calcul - version SSA .
       [Guide de saisie des données de nouveau calcul - version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Structure des procédures de calcul

Source topic: `fr_FR/activity/calculation/structure_des_procedures_de_calcul.dita`

La procédure de calcul est divisée en sous-activités afin de fournir une séquence logique à suivre lorsqu’une demande est calculée. Bien que chaque agent ait une séquence préférée qui est aussi correcte, la procédure est structurée afin d’assurer que l’agent effectue toutes les actions nécessaires pour traiter la demande :

- Déterminer si une demande est prête à être calculée.

- Calculer une demande dans la version Web de SSA.

- Examiner le résultat du calcul.

- Examiner et saisir le calcul.

- Communiquer les décisions après le calcul.

Chaque sous-activité comporte des liens menant à des procédures supplémentaires qui peuvent être nécessaires pour terminer le processus de calcul. 

### Gérer l’AT

Source topic: `fr_FR/activity/calculation/gerer_lat.dita`

Peu importe la façon qu’un agent organise son travail, l’agent à qui est assigné le calcul de la demande doit s’assurer que tout problème est résolu et que tous les faits nécessaires pour calculer la demande sont au dossier avant de compléter le calcul. À moins que les procédures fassent état d’une directive contraire, le calcul ne doit pas être complété tant que tous les AT nécessaires pour finaliser le calcul n’ont pas été complétés. Si le calcul ne peut pas être complété parce qu’il y a un AT connexe en suspens, l’AT du calcul doit être déplacé vers En suspens jusqu’à ce que l’AT connexe soit complété.

Il se peut que des AT liés à une même demande faisant l’objet d’une évaluation soient assignés à divers agents (p. ex. un AT RE Litigieux motif de cessation d’emploi [MCE] est assigné à un agent et un AT EVD est assigné à un autre agent). L’agent complète seulement l’AT qui lui est assigné, sauf si une procédure prévoit le contraire.

Lorsqu’il évalue une demande, l’agent à qui a été assigné un AT du calcul doit aussi examiner la Note client afin de déterminer les actions à prendre (p. ex. saisir des transactions, envoyer des lettres).

Lorsque le calcul est complété, l’agent doit communiquer la décision au client si nécessaire. 

### Choisir le genre de prestations (GP) approprié

Source topic: `fr_FR/activity/calculation/choisir_le_genre_de_prestations_gp_approprie.dita`

Quand l’enregistrement d’une demande crée automatiquement un AT RVD, dans SNCT, le champ Genre de prestations de l’AT RVD est prérempli par Régulier. L’agent met manuellement à jour ce champ avec le GP approprié. Pour une demande initiale ou renouvelée, l’agent choisit le GP indiqué dans la demande d’AE. Pour une demande de conversion dans une demande continue ou toute autre demande de conversion, l’agent choisit le nouveau GP demandé.

Lors de la création d’un AT AP, Rappel (RA), Évaluation pour le calcul (ECAL) ou À revoir (AR), l’agent choisi le GP indiqué dans la demande d’AE. Si le GP a été modifié depuis que le client a présenté sa demande de prestations, l’agent choisit le GP indiqué dans ETI. 

### Établir une demande de prestations régulières

Source topic: `fr_FR/activity/calculation/etablir_une_demande_de_prestations_regulieres.dita`

Pour établir une demande de prestations régulières, un client doit remplir les conditions suivantes :

- Le client a présenté une demande de prestations.

- Le client a subi un arrêt de rémunération (A de R) pendant sa période de référence (PR).
         [arrêt de rémunération (A de R)](/fr/procedure/generic/knowledge.shtml#Arret_de_remuneration) 
         [période de référence](/fr/procedure/generic/knowledge.shtml#Periode_de_reference)

- Le client a le nombre requis d’heures assurables dans la PR.
         [nombre requis d’heures assurables](http://srv129.services.gc.ca/regions_ae/fra/taux_act.aspx)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0021.dita) 

### Verser des prestations

Source topic: `fr_FR/activity/calculation/verser_des_prestations.dita`

Le nombre de semaines d’admissibilité à des prestations régulières est déterminé par :

- le nombre d’heures assurables dans la PR

- le taux régional de chômage (TRC) dans la région où le client réside au moment du DPP
         [taux régional de chômage (TRC)](/fr/procedure/generic/knowledge.shtml#Taux_de_chomage_regional)

Le nombre de semaines d’admissibilité à des prestations régulières varie entre 14 semaines et un maximum de 45 semaines selon l’ annexe 1 de LAE .
       [annexe 1 de LAE](http://laws-lois.justice.gc.ca/fra/lois/E-5.6/TexteComplet.html#h-72)

Les semaines d’admissibilité à des prestations doivent être payées pendant la PP. Si des semaines de prestations spéciales sont payées pendant une PP, il se peut qu’un client ne reçoive pas toutes les semaines de prestations régulières.

Une fois que la demande est établie et que l’admissibilité aux prestations régulières est déterminée, des prestations régulières sont payables pour chaque semaine pour laquelle le client soumet une déclaration du prestataire et pendant laquelle le client :

- est en chômage

- est prêt et disposé à travailler et capable de le faire

- n’a pas reçu de rémunération ou de répartition empêchant le versement d’un paiement

- n’a pas fait l’objet d’une inadmissibilité ou d’une exclusion empêchant le paiement 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0019.dita`

Remarque :

À moins d’avis contraire, les références aux calculs s’appliquent aussi aux nouveaux calculs. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0045.dita`

Remarque :

Le processus spécialisé du TAD se termine le 16 août 2021. À partir de cette date, TAD retourne aux processus normaux d’enregistrement et de calcul. Toutefois, l’agent continue de compléter les AT en suspens créés par le processus spécialisé avant le 15 août 2021 en utilisant les procédures spécialisées. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0055.dita`

Remarque :

Quand le nouveau calcul d’une demande est nécessaire, l’agent suit les procédures normales d’évaluation du calcul et consulte Nouveau calcul : Évaluation — Instructions ainsi que le Guide de saisie des données de nouveau calcul - version SSA , au besoin. Une demande qui nécessite un nouveau calcul doit être évaluée de la même façon qu’une demande qui nécessite un calcul initial.
       [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
       [Guide de saisie des données de nouveau calcul - version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml)

     [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
     [Guide de saisie des données de nouveau calcul - version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0021.dita`

Remarque :

S’il y a une violation au dossier du client, il se peut qu’il y ait une majoration des conditions requises .
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

     [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

## Considérations régionales

Source topic: `fr_FR/activity/calculation/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/calculation/ce_quil_faut_chercher.dita`

## Que voulez-vous faire?

Source topic: `fr_FR/activity/calculation/que_voulez-vous_faire.dita`

- Déterminer si une demande est prête à être calculée — Prestations régulières
         [Déterminer si une demande est prête à être calculée — Prestations régulières](/fr/procedure/subactivity/determining_reg_claim_ready.shtml)

- Calculer une demande dans la version Web de SSA
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Examiner le résultat du calcul
         [Examiner le résultat du calcul](/fr/procedure/subactivity/calc_result_ccb.shtml)

- Réviser et saisir le calcul
         [Réviser et saisir le calcul](/fr/procedure/subactivity/input_calculation_results.shtml)

- Communiquer les décisions après le calcul
         [Communiquer les décisions après le calcul](/fr/procedure/subactivity/communicating_calc_decisions.shtml) 

## Référence de politique

Source topic: `fr_FR/activity/calculation/reference_de_politique.dita`

 
