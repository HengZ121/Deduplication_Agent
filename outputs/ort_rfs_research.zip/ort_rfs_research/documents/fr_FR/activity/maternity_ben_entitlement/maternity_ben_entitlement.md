# Prestations de maternité — Admissibilité

Source map: `fr_FR/activity/maternity_ben_entitlement/maternity_ben_entitlement.ditamap`

## Sommaire

Source topic: `fr_FR/activity/maternity_ben_entitlement/sommaire.dita`

Sommaire : Une cliente qui demande des prestations de maternité doit démontrer qu’elle est admissible aux prestations de maternité pour une période pendant laquelle elle est physiquement incapable de travailler en raison d’une grossesse ou d’un accouchement. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/maternity_ben_entitlement/ce_quil_faut_savoir.dita`

### Remplir les conditions requises pour les prestations de maternité

Source topic: `fr_FR/activity/maternity_ben_entitlement/remplir_les_conditions_requises_pour_le_789ee638.dita`

Les prestations de maternité sont offertes à une cliente qui s’absente en raison d’une grossesse ou d’un accouchement.

Pour remplir les conditions requises pour recevoir des prestations de maternité, une cliente doit remplir les conditions suivantes :

- avoir demandé des prestations;

- avoir subi un arrêt de rémunération (A de R) dans sa période de référence (PR) ;
         [rémunération (A de R)](/fr/procedure/generic/knowledge.shtml#Arret_de_remuneration) 
         [période de référence (PR)](/fr/procedure/generic/knowledge.shtml#Periode_de_reference)

- être de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et la cliente a au moins 420 heures d’emploi assurable.
         [première catégorie](/fr/procedure/generic/knowledge.shtml#client12)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0128.dita) 

**Remplir les conditions requises avec la norme d’admissibilité commune (de la s/c 2310 à la s/c 2361)**

Dans le cadre du budget 2021, le gouvernement du Canada a annoncé qu’une norme d’admissibilité commune (NAC) nationale de 420 heures d’emploi assurable s’applique pour établir une demande de prestations régulières ou spéciales. S’il y a une violation au dossier du client, la majoration des conditions requises peut s’appliquer. La NAC s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Pendant cette période, les définitions de clients de première et deuxième catégorie dans la LAE 6(1) sont abrogées. Les clients dont la demande est établie avec 420 heures d’emploi assurables remplissent les conditions requises pour recevoir des prestations spéciales. L’agent s’assure que toutes les autres conditions requises et d’admissibilité sont remplies.
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Admissibilité aux prestations de maternité

Source topic: `fr_FR/activity/maternity_ben_entitlement/admissibilite_aux_prestations_de_maternite.dita`

Pour être admissible aux prestations de maternité, une cliente doit fournir la preuve de sa grossesse.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0027.dita) 

Les prestations de maternité ne peuvent plus être versées quand l’une des situations suivantes se produit :

- La période de prestations (PP) est expirée.

- La période maximale d’admissibilité payable pour cette demande a été atteinte.
         [période maximale d’admissibilité](/fr/procedure/generic/additionalresources/max_ent_ben.shtml)

- La fenêtre de maternité est expirée.

- Le nombre maximal de semaines de prestations de maternité a été payé. 

### Preuve de grossesse

Source topic: `fr_FR/activity/maternity_ben_entitlement/preuve_de_grossesse.dita`

Comme preuve de grossesse, la cliente doit fournir une déclaration signée qui atteste sa grossesse et indique la date d’accouchement prévue. L’attestation à la fin d’une demande d’AE est acceptée en tant que déclaration signée. Un Maternité ou parentales : INS5168 Annexe 3 — Formulaire rempli et signé est aussi accepté en tant que preuve de grossesse. Si l’agent remplit le formulaire INS5168 avec la cliente, une attestation verbale n’est pas acceptable. L’agent informe la cliente que les options suivantes lui sont offertes pour remplir le formulaire INS5168 :
       [Maternité ou parentales : INS5168 Annexe 3 — Formulaire](https://catalogue.servicecanada.gc.ca/content/EForms/fr/Detail.html?Form=INS5168)

- en présentant le formulaire en personne

- en imprimant le formulaire en ligne et en l’envoyant par la poste à Service Canada

- en demandant à l’agent d’envoyer le formulaire par la poste à la cliente pour que celle-ci le signe et le retourne.

La cliente doit également aviser Service Canada de la date d’accouchement réelle dès que possible. 

### Fenêtre de maternité

Source topic: `fr_FR/activity/maternity_ben_entitlement/fenetre_de_maternite.dita`

La fenêtre de maternité est la période pendant laquelle les prestations de maternité peuvent être versées. La fenêtre de maternité commence à la première des dates suivantes :

- 12 semaines avant la date d’accouchement prévue (date d’accouchement prévue – 12 semaines);

- la date d’accouchement réelle.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0129.dita) 

La fenêtre de maternité prend fin à la plus tardive des dates suivantes :

- 17 semaines après la date d’accouchement prévue (date d’accouchement prévue + 17 semaines);

- 17 semaines après la date d’accouchement réelle (date d’accouchement réelle + 17 semaines).

**Prolonger la fenêtre de maternité**

Pour permettre à la cliente de recevoir les semaines de prestations de maternité supplémentaires auxquelles elle est admissible, la fenêtre de maternité peut être prolongée d’une semaine pour chaque semaine ou semaine partielle d’hospitalisation du nouveau-né. La prolongation maximale de la fenêtre de maternité est de 52 semaines après la date d’accouchement réelle (date d’accouchement réelle + 52 semaines). Le nombre de semaines d’admissibilité aux prestations de maternité demeure le même. Pour plus de renseignements, l’agent consulte Prolongation de la fenêtre de maternité .
       [Prolongation de la fenêtre de maternité](/fr/procedure/generic/knowledge.shtml#Prolongation_de_la_periode_de_maternite) 

### Demander des prestations de maternité

Source topic: `fr_FR/activity/maternity_ben_entitlement/demander_des_prestations_de_maternite.dita`

Normalement, une demande de prestations de maternité ne peut pas être établie en dehors de la fenêtre de maternité. Cependant, une cliente peut établir une PP pour des prestations de maternité la semaine avant la fenêtre de maternité si toutes les conditions suivantes sont remplies :

- La cliente est admissible aux prestations régulières.

- La cliente demande des prestations de maternité à partir du début de la demande.

- La cliente observe un délai de carence (DC) immédiatement avant la fenêtre de maternité.

Quand toutes ces conditions sont remplies, la cliente peut observer son DC pendant la semaine précédant immédiatement la fenêtre de maternité. 

### Versement de prestations

Source topic: `fr_FR/activity/maternity_ben_entitlement/versement_de_prestations.dita`

Les prestations de maternité peuvent être versées pour un maximum de 15 semaines au cours d’une PP. Les 15 semaines payables pour une seule grossesse peuvent être versées au cours de 2 PP. Les prestations de maternité ne peuvent pas être versées en dehors de la fenêtre de maternité. Si les conditions d’admissibilité sont remplies, le versement de prestations de maternité se fait automatiquement selon la fenêtre de maternité.

Une fois que la demande est établie et qu’il est déterminé que des prestations de maternité sont payables, des prestations de maternité sont payables pour chaque semaine pendant laquelle la cliente présente une déclaration du prestataire et qu’elle :

- déclare 5 jours de non disponibilité;

- a fourni la preuve requise pour des prestations de maternité;

- n’a pas reçu de rémunération ou n’a pas de répartition empêchant le paiement;

- n’a pas fait l’objet d’une inadmissibilité empêchant le paiement. 

### Interruption de la grossesse

Source topic: `fr_FR/activity/maternity_ben_entitlement/interruption_de_la_grossesse.dita`

Quand la grossesse est interrompue dans les 19 premières semaines, la demande est traitée comme une demande de prestations de maladie. Si la grossesse est terminée après la 19e semaine, la demande est traitée comme une demande de prestations de maternité. 

### Prestations de maladie pendant la fenêtre de maternité

Source topic: `fr_FR/activity/maternity_ben_entitlement/prestations_de_maladie_pendant_la_fenet_0d585c8d.dita`

Si une cliente est incapable de travailler pour des raisons médicales et qu’elle est enceinte, elle peut demander des prestations de maladie avant les prestations de maternité. Si aucune prestation régulière n’est versée dans la demande, la cliente peut être admissible à une prolongation de la PP pour recevoir toutes les prestations de maternité et parentales auxquelles elle est admissible.
       [prolongation de la PP](/fr/procedure/generic/knowledge.shtml)

Pour recevoir des prestations de maladie, la cliente doit démontrer qu’elle est autrement disponible pour travailler durant la période pour laquelle elle demande des prestations de maladie. Cela peut être difficile à démontrer si la cliente avait déjà prévu avec son employeur de commencer son congé de maternité avant ou durant la période pour laquelle elle demande des prestations de maladie. Par conséquent, l’agent peut devoir vérifier ces renseignements auprès de l’employeur.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0130.dita) 

### Semaine de début ou semaine de fin de maternité externe

Source topic: `fr_FR/activity/maternity_ben_entitlement/semaine_de_debut_ou_semaine_de_fin_de_m_b9da7ae9.dita`

Quand une cliente est admissible à d’autres prestations durant la fenêtre de maternité, une semaine de début de maternité externe est requise pour empêcher le versement de prestations de maternité. Si la cliente est admissible à moins de 15 semaines de prestations de maternité, comme pour les prestations de maternité chevauchant 2 PP, une semaine de fin de la maternité externe est requise pour empêcher le versement des 15 semaines au complet. 

### Date d’accouchement réelle déclarée

Source topic: `fr_FR/activity/maternity_ben_entitlement/date_daccouchement_reelle_declaree.dita`

Souvent, quand une demande de prestations de maternité est établie, la seule date disponible pour l’agent est la date d’accouchement prévue. Les prestations de maternité sont donc établies avec ces renseignements. Si la date d’accouchement réelle est fournie et qu’elle diffère de la date d’accouchement prévue avec laquelle la demande a été établie, l’agent pourrait devoir saisir plus de renseignements pour s’assurer que la fenêtre de maternité et la fenêtre parentale (FP) sont exactes.

Quand la cliente déclare la date d’accouchement réelle qui est dans une période pendant laquelle des prestations de maladie ont déjà été versées, l’agent détermine si la cliente est autrement disponible. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0128.dita`

Remarque:

S’il y a une violation au dossier du client, il se peut qu’il y ait une majoration des conditions requises .
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

     [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0027.dita`

Remarque :

Si le motif de cessation d’emploi (MCE) dans le dernier RE est P - Congé parental et les prestations de maternité ont été demandées, des recueils de faits supplémentaires sont nécessaires. L’agent communique d’abord avec l’employeur pour vérifier que le MCE dans le RE est correct. Si c’est le cas, l’agent communique ensuite avec le client pour vérifier que le genre de prestations (GP) demandé est correct. Si le client a présenté sa demande pour le mauvais GP, l’agent consulte Déterminer pendant le calcul d’une demande si le client a présenté une demande pour le mauvais genre de prestations .
       [Déterminer pendant le calcul d’une demande si le client a présenté une demande pour le mauvais genre de prestations](/fr/procedure/task/calc_determining/wrong_bt_requested.shtml)

     [Déterminer pendant le calcul d’une demande si le client a présenté une demande pour le mauvais genre de prestations](/fr/procedure/task/calc_determining/wrong_bt_requested.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0129.dita`

Remarque :

Avant le 3 décembre 2017, la date de début de la fenêtre de maternité correspondait à 8 semaines avant la date d’accouchement prévue ou la date d’accouchement réelle. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0130.dita`

Remarque :

Certains employeurs peuvent avoir des politiques qui permettent aux employées de commencer leur congé de maternité un nombre défini de semaines avant leur date d’accouchement prévue (p. ex. en Colombie-Britannique, les employées provinciales peuvent commencer leur congé de maternité 6 semaines avant leur date d’accouchement prévue). Dans ces cas, l’agent ne conseille pas à l’employée de demander des prestations de maladie avant sa demande de prestations de maternité, sauf si sa situation particulière l’exige. Si l’agent conseille incorrectement la cliente, les problèmes suivants peuvent survenir :

- Quand une cliente reçoit des prestations de maladie avant des prestations de maternité, le régime d’AE pourrait devenir le premier payeur. L’employeur qui participe au Programme de réduction du taux de cotisation (PRTC) doit être le premier payeur pour remplir les exigences du programme. Une employée qui demande des prestations de maladie avant des prestations de maternité pourrait donc compromettre l’admissibilité de son employeur au PRTC.

- Il peut y avoir une incidence sur le versement de prestations supplémentaires de chômage (PSC) de maternité ou parentales :

- si une cliente reçoit des prestations de maladie avant des prestations de maternité, elle peut perdre son admissibilité aux versements de PSC pour le DC ;
             [DC](/#Waiting_period)

- les PSC peuvent être payables pour une période déterminée après l’arrêt de travail, car cette période peut être considérée comme congé de maternité ou parental. À la fin de cette période déterminée, une cliente peut obtenir l’approbation de son employeur pour un congé prolongé. Cependant, un congé prolongé serait en dehors la période pendant laquelle les PSC sont payables. Par conséquent, la cliente pourrait ne pas recevoir la totalité des PSC auxquelles elle est admissible, ou l’employeur pourrait être contraint de verser des PSC pendant la période de congé prolongé.

Pour ces raisons, il est important qu’une cliente demande le genre de prestation (GP) approprié à sa situation.

     [DC](/#Waiting_period) 

## Considérations régionales

Source topic: `fr_FR/activity/maternity_ben_entitlement/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/maternity_ben_entitlement/ce_quil_faut_chercher.dita`

### Dans SNCT :

Source topic: `fr_FR/activity/maternity_ben_entitlement/dans_snct.dita`

- Y a-t-il déjà une demande de maternité établie?

- Y a-t-il un AT Action à prendre (AP) ou un AT Révision de la demande (RVD) avec une date d’accouchement réelle fournie? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/maternity_ben_entitlement/que_voulez-vous_faire.dita`

## Référence de politique

Source topic: `fr_FR/activity/maternity_ben_entitlement/reference_de_politique.dita`

 
