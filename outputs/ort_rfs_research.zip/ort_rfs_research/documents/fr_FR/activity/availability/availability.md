# Disponibilité

Source map: `fr_FR/activity/availability/availability.ditamap`

## Sommaire

Source topic: `fr_FR/activity/availability/sommaire.dita`

Sommaire : Tous les clients qui demandent des prestations régulières doivent prouver leur disponibilité pour travailler. Les clients qui demandent des prestations de maladie doivent prouver qu’ils seraient autrement disponibles pour travailler s’ils n’étaient pas malades ou blessés. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/availability/ce_quil_faut_savoir.dita`

### Processus temporaire n’est plus en vigueur — Assouplissement des exigences

Source topic: `fr_FR/activity/availability/processus_temporaire_nest_plus_en_vigue_9fbc88a3.dita`

La mesure de simplification pour l’assouplissement des exigences se termine le 25 septembre 2021. À partir du 26 septembre 2021, l’agent suit les procédures habituelles pour rendre une décision sur tout litige de disponibilité. 

### Travail partagé (TP) et disponibilité

Source topic: `fr_FR/activity/availability/travail_partage_tp_et_disponibilite.dita`

Les mesures spéciales liées à la COVID-19 sur la disponibilité pendant un accord de Travail partagé (TP) ne sont plus en vigueur. Dès maintenant, les heures manquées en raison de situations liées à la COVID-19 ne sont plus comptées comme des heures manquées en raison du TP.

Un client participant au TP est considéré comme disponible pendant toute semaine au cours de laquelle il travaille auprès de son employeur participant au TP. Le client n’est pas tenu d’être disponible pour travailler auprès d’autres employeurs pendant ces semaines. Toutefois, le client doit être disponible pour effectuer du travail supplémentaire auprès de son employeur participant au TP jusqu’à ses heures habituelles de travail. Si un employé avait pu travailler, mais n’était pas disponible ou a refusé de travailler, ces heures ne sont pas comptées comme des heures manquées en raison du TP. Par conséquent, les prestations de TP ne sont pas versées pour ces heures.

Pour plus de renseignements, l’agent consulte la section Disponibilité de Travail partagé : Renseignements sur le traitement des demandes de Travail partagé — Connaissances .
       [Travail partagé : Renseignements sur le traitement des demandes de Travail partagé — Connaissances](/fr/procedure/generic/additionalresources/knowledge_reltws.shtml) 

### AT pour les questions sur la disponibilité

Source topic: `fr_FR/activity/availability/at_pour_les_questions_sur_la_disponibilite.dita`

Selon la situation, différents AT peuvent être créés pour les questions de disponibilité, selon le genre de demande (GD) :

- Quand une question pourrait se poser au sujet de la disponibilité dans une demande initiale ou renouvelée, un AT Litige - Décision (DEC) Disponibilité est créé.

- Quand une question pourrait se poser au sujet de la disponibilité dans une demande continue, un AT Révision de la demande (RVD) Révisée est créé. 

### Présomption de non-disponibilité

Source topic: `fr_FR/activity/availability/presomption_de_non-disponibilite.dita`

Si la question se rapporte à un motif de cessation d’emploi (MCE) litigieux, l’agent ne vérifie pas la disponibilité du client, à moins qu’un élément au dossier soulève une présomption de non-disponibilité.

Voici quelques situations d’une forte présomption de non-disponibilité :

- départ volontaire pour une retraite

- départ volontaire pour des raisons de santé

- départ volontaire pour prendre soin d’un enfant ou d’un proche parent

- départ volontaire suite à la perte de moyen de transport

- départ volontaire pour retour aux études

- congé autorisé

- congédiement pour indisponibilité

- paie de vacances pendant une période de fermeture pour vacances 

### Capacité limitée ou réduite

Source topic: `fr_FR/activity/availability/capacite_limitee_ou_reduite.dita`

Un client dont la capacité de travail est limitée en raison d’une invalidité récente peut toujours être considéré comme disponible et peut être admissible aux prestations régulières si les conditions suivantes sont remplies :

- Le client peut travailler à temps plein.

- Le client est prêt à accepter un emploi convenable.

- Il y a des possibilités raisonnables d’emploi convenable sur le marché du travail.

S’il est peu probable que le client obtienne un emploi convenable en raison de ses restrictions involontaires, la demande doit être examinée pour déterminer si une conversion vers des prestations de maladie est possible ou si une inadmissibilité doit être imposée.

Si le client a déjà une restriction permanente et que sa disponibilité reste inchangée pour ce qui est de ses tâches ou de ses heures de travail, l’agent considère que la disponibilité du client est en ordre. Toutefois, si les tâches ou les heures de travail changent, l’agent évalue la situation selon la définition d’emploi convenable. 

### Litiges liés aux clients autrement disponibles

Source topic: `fr_FR/activity/availability/litiges_lies_aux_clients_autrement_disponibles.dita`

Quand un client demande des prestations de maladie, l’agent vérifie si le client est autrement disponible. Le client doit prouver qu’il serait disponible pour travailler s’il n’était pas malade ou blessé. Une situation qui pousse l’agent à remettre en question la disponibilité d’un client pour des prestations régulières devrait aussi pousser l’agent à remettre en question la capacité du client à prouver qu’il est autrement disponible pour des prestations de maladie.

Exception : Quand un client demande des prestations de maladie tout en recevant et en demeurant admissible aux prestations parentales, aux PDC, aux prestations pour proches aidants ou au RQAP, il est considéré comme autrement disponible. 

### Niveaux de décision

Source topic: `fr_FR/activity/availability/niveaux_de_decision.dita`

Dans certaines conditions indiquées dans les étapes de traitement, les agents de Niveau 1 et de Niveau 2 peuvent rendre une décision sur la disponibilité ou les litiges liés aux clients autrement disponibles. 

### Situations non couvertes dans cette activité

Source topic: `fr_FR/activity/availability/situations_non_couvertes_dans_cette_activite.dita`

Différentes procédures traitent des questions de disponibilité et des litiges liés aux clients autrement disponibles. Pour l’une ou l’autre des situations suivantes, l’agent consulte l’activité appropriée :

- Vacances au Canada
         [Vacances au Canada](/fr/procedure/activity/vacation.shtml)

- Fonctions de juré
         [Fonctions de juré](/fr/procedure/activity/jury_duty.shtml)

- Hors Canada
         [Hors Canada](/fr/procedure/activity/out_canada.shtml)

- Cours de formation
         [Cours de formation](/fr/procedure/activity/training.shtml)

- Incarcération
         [Incarcération](/fr/procedure/activity/incarceration.shtml)

- Travailleur indépendant
         [Travailleur indépendant](/fr/procedure/activity/self_employed.shtml)

- NAS de la série 900
         [NAS de la série 900](/fr/procedure/activity/expired_900.shtml) 

### Client considéré comme disponible

Source topic: `fr_FR/activity/availability/client_considere_comme_disponible.dita`

Certains clients sont considérés comme disponibles même si en réalité ils ne le sont pas. Cela comprend :

- les clients qui sont dirigés vers un cours de formation, un programme d’instruction ou une activité d’emploi;

- les clients qui occupent un emploi dans le cadre d’un programme de TP;

- les pêcheurs (dans certains cas).

Le client qui établit une période de prestations (PP) de pêcheur, que ce soit pour une pêche estivale ou hivernale, est considéré comme étant disponible pour le travail en ce qui a trait à ses activités de pêche. Pendant les périodes mentionnées ci-dessous, aucune inadmissibilité 3 - Non disponible (D3) n’ est imposée, pour la seule raison que le client a participé à des activités de pêche :

- Pêche estivale : à partir de la semaine dans laquelle tombe le 1er octobre jusqu’à la semaine dans laquelle tombe le 15 juin.

- Pêche hivernale : à partir de la semaine dans laquelle tombe le 1er avril jusqu’à la semaine dans laquelle tombe le 15 décembre. 

### Critères juridiques

Source topic: `fr_FR/activity/availability/criteres_juridiques.dita`

**Disponibilité**

Pour déterminer si un client a prouvé sa disponibilité et pour faciliter la prise de décision et le recueil de faits, l’agent de Niveau 2 répond aux questions suivantes :

- Est-ce que l’attitude du client reflète sa volonté de travailler ou tient plutôt de l’insouciance propre à quelqu’un qui ne cherche pas réellement un emploi convenable?

- Est-ce que le client se trouve aux prises avec des empêchements qui entravent sa volonté de travailler?

- Est-ce que le client pose des restrictions préalables à l’acceptation d’un emploi (qui diminuent grandement ses possibilités de l’obtenir)?

- Est-ce que l’incapacité du client de décrocher un emploi convenable a été démontrée par des tentatives de trouver du travail?

**Autrement disponible**

Pour déterminer si un client peut être considéré comme autrement disponible et pour faciliter la prise de décision et le recueil de faits, l’agent détermine si le client serait autrement disponible s’il n’était pas malade ou blessé. 

### Inadmissibilités

Source topic: `fr_FR/activity/availability/inadmissibilites.dita`

Si le client ne peut pas prouver sa disponibilité, l’agent impose une inadmissibilité D3.

Si l’agent ne peut pas joindre un client dont la disponibilité est douteuse, l’agent impose une inadmissibilité D3.

Si le client ne peut pas prouver qu’il est autrement disponible, l’agent impose une inadmissibilité 33 - Incapacité prouvée mais prestataire non autrement disponible (D33).

Si l’agent ne peut pas joindre le client qui ne prouve pas qu’il est autrement disponible, l’agent impose une inadmissibilité D33.

Les clients qui ne prouvent pas qu’ils effectuent des démarches habituelles et raisonnables pour trouver un emploi convenable sont sujets à une inadmissibilité 24 - Négligence d’effectuer une recherche active d’emploi (D24). L’agent impose aussi une inadmissibilité D24 quand les clients ne fournissent pas la preuve exigée de leur recherche d’emploi.

Toutes ces inadmissibilités peuvent être imposées en même temps qu’une autre inadmissibilité ou exclusion aux prestations.

L’inadmissibilité commence et se termine un jour ouvrable (c.-à-d. du lundi au vendredi, y compris les jours fériés). L’agent ne peut pas imposer une inadmissibilité à un client pour une demi-journée. Les circonstances atténuantes ne peuvent pas réduire la durée de l’inadmissibilité.

Une inadmissibilité peut être révisée à tout moment au cours de la demande, soit pour l’annuler, la modifier ou la terminer.

Pour connaître l’incidence d’une inadmissibilité imposée pendant le délai de carence (DC), l’agent consulte Délai de carence : Incidence de la rémunération et des inadmissibilités — Connaissances .
       [Délai de carence : Incidence de la rémunération et des inadmissibilités — Connaissances](/fr/procedure/generic/additionalresources/earnings_disentitlements_wp.shtml) 

### AT Litige - Décision (DEC) Soins d’une personne à charge

Source topic: `fr_FR/activity/availability/at_litige_-_decision_dec_soins_dune_per_16d34eef.dita`

Le système crée un AT DEC Soins d’une personne à charge quand une cliente présente une demande de prestations régulières ou de pêcheur et qu’elle indique avoir donné naissance dans les 17 dernières semaines et qu’elle n’a pris aucune disposition concernant la garde de son enfant. Un agent de Niveau 1 vérifie que la cliente a indiqué le bon genre de prestations (GP) dans la demande. Si la cliente confirme qu’elle demande des prestations régulières ou de pêcheur, l’agent de Niveau 2 rend une décision sur la question de disponibilité causée par l’absence de dispositions concernant la garde de son enfant. 

## Considérations régionales

Source topic: `fr_FR/activity/availability/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/availability/ce_quil_faut_chercher.dita`

### Dans SNCT :

Source topic: `fr_FR/activity/availability/dans_snct.dita`

- Les détails spécifiques ou l’historique de l’AT pour un AT DEC ou un AT RVD comprennent-ils les renseignements sur la disponibilité?

- Y a-t-il un RSDP ou d’autres AT comprenant des renseignements supplémentaires au sujet de la disponibilité?

- Y a-t-il des documents liés à cette question? 

### Dans Imagerie :

Source topic: `fr_FR/activity/availability/dans_imagerie.dita`

- Y a-t-il des documents numérisés qui peuvent fournir des informations supplémentaires concernant la disponibilité? 

### Dans ETI :

Source topic: `fr_FR/activity/availability/dans_eti.dita`

- Y a-t-il déjà une inadmissibilité D3 indéterminée au dossier?

- Y a-t-il déjà une inadmissibilité D33 au dossier?

- Y a-t-il déjà une inadmissibilité D24 au dossier? 

### Comment choisir la procédure à suivre

Source topic: `fr_FR/activity/availability/comment_choisir_la_procedure_a_suivre.dita`

Selon les circonstances, plus d’une procédure sur la disponibilité peut être suivie. Afin de déterminer les mesures appropriées, consulter la section Ce qu’il faut chercher , puis examiner le tableau suivant :
       [Ce qu’il faut chercher](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/activity/availability#Cequilfaut)

```text
| Situation | Tâche appropriée sur la disponibilité |

| Le client a des préférences ou des restrictions qui ont une incidence sur sa disponibilité ou sa recherche d’emploi | Rendre une décision sur la disponibilité — Préférence ou restriction et délai raisonnable [Rendre une décision sur la disponibilité — Préférence ou restriction et délai raisonnable](/fr/procedure/task/availability_adj_res.shtml) |

| Le client soumet de nouvelles informations après l’imposition d’une inadmissibilité D24 | Traiter des nouveaux renseignements lorsqu’une D24 a été imposée [Traiter des nouveaux renseignements lorsqu’une D24 a été imposée](/fr/procedure/task/actioning_new_info_d24.shtml) |

| La déclaration du client est à propos d’une question de disponibilité précise : - non disponible | Rendre une décision sur la non-disponibilité déclarée par le client [Rendre une décision sur la non-disponibilité déclarée par le client](/fr/procedure/task/availability_declared_client.shtml) |

| La déclaration du client est à propos d’une question de disponibilité précise : - présentement employé à temps partiel | Rendre une décision sur la disponibilité — Client travaille à temps partiel [Rendre une décision sur la disponibilité — Client travaille à temps partiel](/fr/procedure/task/availability_pt.shtml) |

| La déclaration du client est à propos d’une question de disponibilité précise : - consacre du temps à des activités personnelles | Rendre une décision sur la disponibilité — Bénévolat ou autres activités personnelles [Rendre une décision sur la disponibilité — Bénévolat ou autres activités personnelles](/fr/procedure/task/availability_personal_act.shtml) |

| Le client est absent de son domicile ou l’était : - en était au Canada seulement | Rendre une décision sur la disponibilité — Absence du domicile en étant au Canada mais pas en vacances [Rendre une décision sur la disponibilité — Absence du domicile en étant au Canada mais pas en vacances](/fr/procedure/task/availability_absence.shtml) |

| Le client était absent : - une inadmissibilité D3 indéterminée est au dossier | Rendre une décision sur la disponibilité — Absence lorsque le client déclare être de retour à son domicile [Rendre une décision sur la disponibilité — Absence lorsque le client déclare être de retour à son domicile](/fr/procedure/task/availability_client_return.shtml) |

| Le client déclare qu’il retourne progressivement au travail après une période de maladie | Rendre une décision sur la disponibilité — Retour au travail progressif [Rendre une décision sur la disponibilité — Retour au travail progressif](/fr/procedure/task/availability_adj_rw.shtml) |

| La cliente présente une demande de prestations régulières ou de pêcheur et n’a pas pris de dispositions pour la garde de son enfant | Traiter un AT Litige - Décision Soins d’une personne à charge [Traiter un AT Litige - Décision Soins d’une personne à charge](/fr/procedure/task/actioning_adj_cc_wi.shtml) |

| Le client a un litige lié au client autrement disponible | Rendre une décision sur la question des clients autrement disponibles — Demande initiale [Rendre une décision sur la question des clients autrement disponibles — Demande initiale](/fr/procedure/task/no_available.shtml) |

| Rendre une décision sur la question des clients autrement disponibles — Demande renouvelée [Rendre une décision sur la question des clients autrement disponibles — Demande renouvelée](/fr/procedure/task/no_available_rc.shtml) |

| Rendre une décision sur la question des clients autrement disponibles — Demande continue [Rendre une décision sur la question des clients autrement disponibles — Demande continue](/fr/procedure/task/no_available_cc.shtml) |
``` 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/availability/que_voulez-vous_faire.dita`

## Référence de politique

Source topic: `fr_FR/activity/availability/reference_de_politique.dita`

 
