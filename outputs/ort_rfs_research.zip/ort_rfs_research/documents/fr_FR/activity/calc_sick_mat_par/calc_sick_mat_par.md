# Traiter le calcul ou le nouveau calcul d’une demande de prestations de maladie, maternité et parentales

Source map: `fr_FR/activity/calc_sick_mat_par/calc_sick_mat_par.ditamap`

## Sommaire

Source topic: `fr_FR/activity/calc_sick_mat_par/sommaire.dita`

Sommaire : Quand TAD n’est pas en mesure d’automatiser le calcul d’une demande d’une combinaison de prestations de maladie et de prestations de maternité, ou d’une combinaison de prestations de maladie, de prestations de maternité et de prestations parentales, un agent calcule la demande. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/calc_sick_mat_par/ce_quil_faut_savoir.dita`

### Untitled section

Source topic: `fr_FR/activity/calc_sick_mat_par/untitled_section.dita`

[Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0019.dita) 

### Calculer manuellement une demande

Source topic: `fr_FR/activity/calc_sick_mat_par/calculer_manuellement_une_demande.dita`

Le calcul manuel d’une demande est complexe et doit être fait seulement par un agent qui a suivi la formation nécessaire.

L’agent doit traiter le calcul ou le nouveau calcul d’une demande dans les cas suivants quand :

- un client présente une demande de prestations sur papier

- TAD n’est pas en mesure de traiter le calcul d’une application électronique

- une demande nécessite un nouveau calcul et que TAD n’est pas en mesure d’automatiser le nouveau calcul 

### Calcul et nouveau calcul

Source topic: `fr_FR/activity/calc_sick_mat_par/calcul_et_nouveau_calcul.dita`

Quand un AT Évaluation de la demande (EVD) ou Demande spécialisée (DS) est reçu, l’agent doit effectuer le calcul initial de la demande.

Quand un AT Révision de la demande (RVD) avec un problème lié au nouveau calcul est reçu, l’agent doit effectuer le nouveau calcul d’une demande qui était finalisée. On se sert parfois de « recalcul » pour parler d’un nouveau calcul. Une fois qu’un calcul initial est bien transmis, un nouveau calcul d’une demande peut être effectué quand de nouveaux renseignements reçus auront une incidence sur le résultat du calcul précédent (p. ex. un RE modifié est émis).

Quand un nouveau calcul est requis pour un cas d’Intégrité, un AT Action à prendre (AP) urgent est créé pour le nouveau calcul. L’agent assigné à cet AT doit effectuer le nouveau calcul.

Le nouveau calcul d’une demande peut avoir une incidence sur :

- la possibilité du client d’établir une période de prestations (PP);
         [période de prestations](/fr/procedure/generic/knowledge.shtml#Etablissement_de_la_periode_de_prestati)

- l’admissibilité du client aux prestations;

- le taux de prestations du client.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0020.dita) 

### Effectuer le nouveau calcul d’une demande touchée par la modification d’un NAS ou d’une région

Source topic: `fr_FR/activity/calc_sick_mat_par/effectuer_le_nouveau_calcul_dune_demand_69c56db8.dita`

Si le client a déménagé dans une autre région, que son NAS a été modifié, ou les 2, depuis le calcul de la demande initiale, il peut ne pas être possible d’enregistrer le nouveau calcul dans la version Web de SSA. Le nouveau calcul doit être enregistré dans le centre de technologie de l’information (CTI) initial ou sous le NAS précédent, mais il doit être saisi manuellement dans ETI avec le CTI actuel et le nouveau NAS, si applicable.

Pour plus de renseignements, l’agent consulte les annexes B, C et D du Guide de saisie des données de nouveau calcul – version SSA .
       [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Structure des procédures de calcul

Source topic: `fr_FR/activity/calc_sick_mat_par/structure_des_procedures_de_calcul.dita`

La procédure de calcul est divisée en sous-activités afin de fournir une séquence logique à suivre quand une demande est calculée. Bien que chaque agent ait une séquence préférée qui est aussi correcte, la procédure est structurée afin d’assurer que l’agent effectue toutes les actions nécessaires pour traiter la demande :

- Déterminer si une demande est prête à être calculée.

- Calculer une demande dans la version Web de SSA.

- Examiner le résultat du calcul.

- Examiner et saisir le calcul.

- Communiquer les décisions après le calcul.

Chaque sous-activité comporte des liens menant à des procédures supplémentaires qui peuvent être nécessaires pour terminer le processus de calcul. 

### Gérer l’AT

Source topic: `fr_FR/activity/calc_sick_mat_par/gerer_lat.dita`

Peu importe la façon dont un agent organise son travail, l’agent à qui est assigné le calcul de la demande doit s’assurer que tout problème est résolu et que tous les faits nécessaires pour calculer la demande sont au dossier avant de compléter le calcul. À moins que les procédures fassent état d’une directive contraire, l’AT EVD ne doit pas être complété tant que toutes les questions n’ont pas été traitées et que tous les AT connexes nécessaires pour finaliser le calcul n’ont pas été complétés. Si le calcul ne peut pas être complété parce qu’il y a un AT connexe en suspens, l’AT du calcul doit être déplacé vers En suspens jusqu’à ce que l’AT connexe soit complété.

Il se peut que des AT liés à une même demande faisant l’objet d’une évaluation soient assignés à divers agents (p. ex. un AT RE Litigieux motif de cessation d’emploi [MCE] est assigné à un agent et un AT EVD est assigné à un autre agent). L’agent complète seulement l’AT qui lui est assigné, sauf si une procédure prévoit le contraire.

Quand il évalue une demande, l’agent à qui a été assigné un AT du calcul doit aussi examiner la Note client afin de déterminer les actions à prendre (p. ex. saisir des transactions, envoyer des lettres).

Quand le calcul est complété, l’agent doit communiquer la décision au client au besoin. 

### Choisir le genre de prestations (GP) approprié

Source topic: `fr_FR/activity/calc_sick_mat_par/choisir_le_genre_de_prestations_gp_approprie.dita`

Quand l’enregistrement d’une demande crée automatiquement un AT RVD, dans SNCT, le champ Genre de prestations de l’AT RVD est prérempli par Régulier. L’agent met manuellement à jour ce champ avec le GP approprié. Pour une demande initiale ou renouvelée, l’agent choisit le GP indiqué dans la demande d’AE. Pour une demande de conversion dans une demande continue ou toute autre demande de conversion, l’agent choisit le nouveau GP demandé.

Lors de la création d’un AT AP, Rappel (RA), Évaluation pour le calcul (ECAL) ou À revoir (AR), l’agent choisi le GP indiqué dans la demande d’AE. Si le GP a été modifié depuis que le client a présenté sa demande de prestations, l’agent choisit le GP indiqué dans ETI. 

### Remplir les conditions requises pour une combinaison de prestations de maladie, de maternité et parentales

Source topic: `fr_FR/activity/calc_sick_mat_par/remplir_les_conditions_requises_pour_un_cc343c3a.dita`

Pour remplir les conditions requises pour recevoir une combinaison de prestations de maladie et de prestations de maternité, ou une combinaison de prestations de maladie, de prestations de maternité et de prestations parentales, un client doit remplir les conditions suivantes :

- Le client a présenté une demande de prestations.

- Le client a subi un arrêt de rémunération (A de R) pendant sa période de référence (PR).
         [arrêt de rémunération (A de R)](/fr/procedure/generic/knowledge.shtml) 
         [période de référence](/fr/procedure/generic/knowledge.shtml)

- Le client est de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable.
         [première catégorie](/fr/procedure/generic/knowledge.shtml#client12)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0048.dita) 

**Remplir les conditions requises avec la norme d’admissibilité commune (de la s/c 2310 à la s/c 2361)**

Dans le cadre du budget 2021, le gouvernement du Canada a annoncé qu’une norme d’admissibilité commune (NAC) nationale de 420 heures d’emploi assurable s’applique pour établir une demande de prestations régulières ou spéciales. S’il y a une violation au dossier du client, la majoration des conditions requises peut s’appliquer. La NAC s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Pendant cette période, les définitions de clients de première et deuxième catégorie dans la LAE 6(1) sont abrogées. Les clients dont la demande est établie avec 420 heures d’emploi assurables remplissent les conditions requises pour recevoir des prestations spéciales. L’agent s’assure que toutes les autres conditions requises et d’admissibilité sont remplies.
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Admissibilité à une combinaison de prestations de maladie, maternité et parentales

Source topic: `fr_FR/activity/calc_sick_mat_par/admissibilite_a_une_combinaison_de_pres_857a1be3.dita`

Pour être admissible à une combinaison de prestations de maladie et de maternité, ou une combinaison de prestations de maladie, de maternité et parentales, le client doit remplir les conditions suivantes :

- Le client est en mesure de fournir un certificat médical qui prouve son incapacité à travailler en raison d’une maladie pour une période au cours de laquelle il souhaite recevoir des prestations de maladie.

- Le client est en mesure de prouver qu’elle aurait été autrement disponible pour travailler pendant la période au cours de laquelle il souhaite recevoir des prestations de maladie (c.-à-d. le client aurait été de retour au travail ou à la recherche d’un emploi n’eut été de la maladie).
         [autrement disponible](/fr/procedure/generic/knowledge.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0049.dita) 

- Le client est en mesure de fournir une preuve de grossesse.

- Le client est en mesure de fournir une preuve de naissance, d’adoption ou de placement.

- Le client demande des prestations dans la fenêtre de maternité ou parentale.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0026.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0027.dita) 

Un client de première catégorie est admissible à des prestations spéciales peu importe le MCE.

Une inadmissibilité administrative est imposée pour empêcher le paiement de prestations régulières à un client qui est admissible aux prestations spéciales, mais pas aux prestations régulières.

**Preuve d’incapacité**

Un client qui demande des prestations de maladie doit être en mesure de fournir un certificat médical qui prouve son incapacité à travailler en raison de maladie.

Un certificat médical rempli par un médecin ou un autre praticien confirmant la maladie du client doit être obtenu pour chaque semaine pour laquelle le client demande des prestations de maladie.

Le client qui présente une demande de prestations de maladie dans AW peut téléverser immédiatement le certificat médical. Si le client ne présente pas le certificat médical et que le dernier MCE est maladie, le client est informé qu’il doit le présenter si la durée de la maladie ou de la blessure est supérieure à 9 semaines. Sinon, le client est avisé qu’il doit conserver le certificat médical pendant 6 ans puisqu’il peut être demandé à une date ultérieure. Si le dernier MCE n’ est pas maladie, le client est avisé qu’il doit présenter le certificat médical et qu’il peut le téléverser ultérieurement dans MDSC.

Si un certificat médical est nécessaire et n’est pas fourni, une inadmissibilité 16 - Certificat médical non fourni (D16) doit être imposée sur la demande.

Les agents ne doivent pas demander un certificat médical à moins qu’il soit nécessaire. Si un certificat médical est reçu, mais non exigé, l’agent l’examine et met à jour la date de guérison en fonction des renseignements fournis sur le certificat médical.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0050.dita) 

**Preuve de grossesse**

Comme preuve de grossesse, la cliente doit fournir une déclaration signée qui atteste la grossesse et indique la date prévue de l’accouchement. L’attestation à la fin de la demande AW est acceptée en tant que déclaration signée. Un Maternité ou parentales : INS5168 Annexe 3 — Formulaire rempli et signé est aussi accepté en tant que preuve de grossesse. Si l’agent remplit le formulaire INS5168 avec la cliente, une attestation verbale n’est pas acceptable. L’agent envoie le formulaire INS5168 par la poste pour que la cliente le signe et le retourne. La cliente doit également aviser Service Canada de la date réelle de l’accouchement aussitôt que possible.
       [Maternité ou parentales : INS5168 Annexe 3 — Formulaire](http://forms-formulaires.prv/lc/content/EForms/fr/CallForm.html?Lang=fr&PDF=SC-INS5168.pdf)

**Preuve de naissance, d’adoption ou de placement**

Les parents doivent fournir une preuve de naissance, d’adoption ou de placement selon leur lien à l’enfant ou aux enfants. Pour plus de renseignements, l’agent peut consulter Parents : Définition — Tableau .
       [Parents : Définition — Tableau](/fr/procedure/generic/parents_definition_table.shtml)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0028.dita) 

### Fenêtre de maternité

Source topic: `fr_FR/activity/calc_sick_mat_par/fenetre_de_maternite.dita`

[Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0051.dita) 

La fenêtre de maternité est la période pendant laquelle des prestations de maternité sont payables.

Elle commence à la plus antérieure des dates suivantes :

- 12 semaines avant la date d’accouchement prévue (date d’accouchement prévue – 12 semaines);

- à la date d’accouchement réelle.

La fenêtre de maternité prend fin à la plus tardive des dates suivantes :

- 17 semaines après la date d’accouchement prévue (date d’accouchement prévue + 17 semaines);

- 17 semaines après la date d’accouchement réelle (date d’accouchement réelle + 17 semaines).

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0031.dita) 

### Fenêtre parentale (FP)

Source topic: `fr_FR/activity/calc_sick_mat_par/fenetre_parentale_fp.dita`

La FP désigne la période pendant laquelle les prestations parentales peuvent être payées. La FP commence et se termine de la façon suivante :

- Semaine de début :

- La semaine d’arrivée ou de placement (SAP) est déterminée par le lien entre le parent et l’enfant. Pour plus de renseignements, l’agent peut consulter Parents : Définition — Tableau .
             [Parents : Définition — Tableau](/fr/procedure/generic/parents_definition_table.shtml)

- Semaine de fin :

- Pour les prestations parentales standards, la semaine de fin tombe 52 semaines après la SAP (SAP + 52).

- Pour les prestations parentales prolongées, la semaine de fin tombe 78 semaines après la SAP(SAP + 78).

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0033.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0034.dita) 

### Verser des prestations

Source topic: `fr_FR/activity/calc_sick_mat_par/verser_des_prestations.dita`

Le client peut recevoir jusqu’à 26 semaines de prestations de maladie par PP quand le DPP est la s/c 2374 ou après et jusqu’à 15 semaines de prestations de maladie par PP quand le DPP est la s/c 2373 ou avant.

Une fois que la demande est établie et que l’admissibilité aux prestations de maladie est déterminée, des prestations de maladie sont payables pour chaque semaine pour laquelle le client soumet une déclaration du prestataire et pendant laquelle le client :

- déclare 5 jours de maladie

- est autrement disponible pour travailler

- a fourni la preuve requise pour des prestations de maladie

- n’a pas reçu de rémunération ou de répartition empêchant le versement d’un paiement

- n’a pas fait l’objet d’une inadmissibilité empêchant le paiement

Les prestations de maternité peuvent être versées jusqu’à concurrence de 15 semaines dans une même PP. Toutefois, ces 15 semaines payables pour une seule et même grossesse peuvent s’étendre sur 2 périodes de prestations. Les prestations de maternité ne soient pas payables à l’extérieur de la fenêtre de maternité. Le versement des prestations de maternité se fera automatiquement selon la fenêtre de maternité si les conditions d’admissibilité sont remplies.

Une fois que la demande est établie et que l’admissibilité aux prestations parentales est déterminée, des prestations de parentales sont payables pour chaque semaine pour laquelle le client soumet une déclaration du prestataire et pendant laquelle le client :

- déclare 5 jours de non-disponibilité

- a fourni la preuve requise pour des prestations de parentales

- n’a pas reçu de rémunération ou de répartition empêchant le versement d’un paiement

- n’a pas fait l’objet d’une inadmissibilité empêchant le paiement

Les prestations parentales peuvent soit être versées au taux de base ou être versées à un taux réduit pour une période prolongée. Le nombre maximal de semaines d’admissibilité aux prestations parentales pour une naissance ou une adoption est différent selon le genre de prestations parentales reçues par le client et si les prestations sont partagées avec d’autres parents légalement reconnus. 

### Admissibilité maximale

Source topic: `fr_FR/activity/calc_sick_mat_par/admissibilite_maximale.dita`

Un client est admissible à un maximum de 35 semaines de prestations parentales standards ou de 61 semaines de prestations parentales prolongées par naissance ou par placement en adoption. L’admissibilité parentale maximale est aussi le nombre maximal de semaines d’admissibilité aux prestations parentales qui peuvent être payées pendant une PP. Les prestations parentales peuvent être versées sur 2 PP, mais pas en dehors de la FP. Le nombre de semaines de prestations parentales auxquelles un client est admissible n’est affecté ni par le nombre d’enfants nés en même temps (jumeaux, triplés, etc.) ni par le nombre d’enfants adoptés au même moment. 

### Partager des prestations parentales

Source topic: `fr_FR/activity/calc_sick_mat_par/partager_des_prestations_parentales.dita`

Les parents peuvent partager les prestations parentales. Pour plus de renseignements et des définitions, l’agent peut consulter Parents : Définition — Tableau .
       [Parents : Définition — Tableau](/fr/procedure/generic/parents_definition_table.shtml)

Le genre de prestations parentales demandé par le premier parent qui a présenté une demande de prestations détermine le genre de prestations parentales auquel tous les parents sont admissibles pour la même naissance, adoption ou placement, quel que soit le parent qui est payé en premier. Lors du recueil de faits auprès des parents qui ont présenté une demande de prestations après le premier parent, l’agent informe les autres parents du genre de prestations auquel ils ont droit. Une fois qu’au moins une semaine de prestations parentales a été versée à l’un des parents, tous les parents demandant des prestations pour la même naissance, adoption ou placement ne sont admissibles qu’au genre de prestations parentales choisi par le premier parent qui a présenté une demande de prestations.

Le maximum de prestations parentales standards partageables est de 40 semaines ou de 69 semaines pour les prestations parentales prolongées pour un enfant né ou placé en adoption le 17 mars 2019 ou après. Pour les enfants nés ou placés en adoption avant cette date, le maximum des prestations parentales standards partageables est de 35 semaines ou de 61 semaines pour les prestations parentales prolongées. L’admissibilité maximale des demandes de prestations standards pour un client demeure à 35 semaines ou à 61 semaines pour les prestations prolongées. Les clients peuvent modifier le nombre de semaines que chaque parent reçoit à tout moment avant que toutes les prestations ne soient versées. Quand les clients ne peuvent pas s’entendre sur le nombre de semaines que chacun recevra, l’agent réassigne la question à un agent de Niveau 2 qui rend une décision sur la division des semaines restantes.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0052.dita) 

Une fois que la demande est établie et que l’admissibilité aux prestations parentales est déterminée, des prestations de parentales sont payables pour chaque semaine pour laquelle le client soumet une déclaration du prestataire et pendant laquelle le client :

- déclare 5 jours de non-disponibilité

- a fourni la preuve requise pour des prestations de parentales

- n’a pas reçu de rémunération ou de répartition empêchant le versement d’un paiement

- n’a pas fait l’objet d’une inadmissibilité empêchant le paiement

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0053.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0054.dita) 

### Valider les prestations parentales partagées

Source topic: `fr_FR/activity/calc_sick_mat_par/valider_les_prestations_parentales_partagees.dita`

Un Dossier de clients des prestations parentales est créé pour chaque client demandant des prestations parentales. Le Dossier de clients des prestations parentales est constitué du NAS du client, de la semaine d’arrivée ou de placement (SAP) et du NAS de l’autre parent, s’il a été fourni. Une fois que la demande est finalisée, le système lie les Dossiers de clients des prestations parentales pour tous les clients qui partagent des prestations parentales pour le même enfant. Le processus de validation du partage des prestations parentales crée un AT Révision de la demande (RVD) Validation des prestations parentales quand l’une des conditions suivantes est remplie :

- Le GP parental dans tous les Dossiers de clients des prestations parentales liés n’est pas le même.

- Le nombre total de semaines parentales demandées dans tous les Dossiers de clients des prestations parentales liés dépasse le nombre maximal de semaines de prestations parentales partageables. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0019.dita`

Remarque :

À moins d’avis contraire, les références aux calculs s’appliquent aussi aux nouveaux calculs. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0020.dita`

Remarque :

Quand le nouveau calcul d’une demande est nécessaire, l’agent suit les procédures normales d’évaluation du calcul et consulte Nouveau calcul : Évaluation — Instructions ainsi que le Guide de saisie des données de nouveau calcul – version SSA , au besoin. Une demande qui nécessite un nouveau calcul doit être évaluée de la même façon qu’une demande qui nécessite un calcul initial.
       [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
       [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml)

     [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
     [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0048.dita`

Remarque :

S’il y a une violation inscrite au dossier du client, il peut y avoir une majoration des conditions requises .
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

     [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0049.dita`

Remarque :

Quand une cliente ne prouve pas qu’elle est autrement disponible pour travailler et que sa demande est dans la fenêtre de maternité ou la fenêtre parentale (FP), l’agent examine la possibilité de payer ces GP. Si la cliente ne prouve pas qu’elle est autrement disponible pour travailler et qu’elle n’est pas admissible aux autres GP, l’agent impose une inadmissibilité 33 - Incapacité prouvée mais client non autrement disponible (D33). 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0026.dita`

Remarque :

La naissance ou l’adoption de plus d’un enfant à la fois est traitée comme une naissance ou une adoption d’un seul enfant. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0027.dita`

Remarque :

Si le motif de cessation d’emploi (MCE) dans le dernier RE est P - Congé parental et les prestations de maternité ont été demandées, des recueils de faits supplémentaires sont nécessaires. L’agent communique d’abord avec l’employeur pour vérifier que le MCE dans le RE est correct. Si c’est le cas, l’agent communique ensuite avec le client pour vérifier que le genre de prestations (GP) demandé est correct. Si le client a présenté sa demande pour le mauvais GP, l’agent consulte Déterminer pendant le calcul d’une demande si le client a présenté une demande pour le mauvais genre de prestations .
       [Déterminer pendant le calcul d’une demande si le client a présenté une demande pour le mauvais genre de prestations](/fr/procedure/task/calc_determining/wrong_bt_requested.shtml)

     [Déterminer pendant le calcul d’une demande si le client a présenté une demande pour le mauvais genre de prestations](/fr/procedure/task/calc_determining/wrong_bt_requested.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0050.dita`

Remarque :

Quand un certificat médical est téléversé, l’agent ou le client doit remplir un questionnaire électronique Certificat médical. Ce questionnaire électronique n’ est pas une preuve médicale. L’agent ne l’utilise pas pour déterminer une semaine de guérison ou une période d’incapacité. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0028.dita`

Remarque :

Si l’adoption soulève des doutes, une preuve de placement peut être exigée. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0051.dita`

Remarque :

Si la grossesse prend fin pendant les 19 premières semaines, la demande est traitée comme une demande de prestations de maladie. Si la grossesse prend fin après la 19e semaine, la demande est traitée comme une demande de prestations de maternité. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0031.dita`

Remarque :

Dans certains cas, la fenêtre de maternité peut être prolongée pour permettre au client de recevoir les prestations auxquelles il a droit. Pour plus de renseignements, consulter Prolonger la fenêtre de maternité .
       [Prolonger la fenêtre de maternité](/fr/procedure/generic/knowledge.shtml#Prolongation_de_la_periode_de_maternite)

     [Prolonger la fenêtre de maternité](/fr/procedure/generic/knowledge.shtml#Prolongation_de_la_periode_de_maternite) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0033.dita`

Remarque :

Dans certains cas, la FP peut être prolongée pour permettre au client de recevoir les prestations auxquelles il a droit. Pour plus de renseignements, consulter Conditions relatives à la prolongation de la FP .
       [Conditions relatives à la prolongation de la FP](/fr/procedure/generic/knowledge.shtml#Conditions_relatives_prolongation_PP_pa)

     [Conditions relatives à la prolongation de la FP](/fr/procedure/generic/knowledge.shtml#Conditions_relatives_prolongation_PP_pa) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0034.dita`

Remarque :

Le client doit remplir les conditions d’admissibilité pour chaque semaine de prestations parentales demandée. Si l’agent est informé que le client ne prend plus soin de l’enfant pendant la FP, l’agent impose une inadmissibilité définie ou indéfinie 34 - Prestations parentales conditions d’admissibilité non rencontrées (D34) à compter du lundi suivant la semaine au cours de laquelle le client n’est plus admissible aux prestations. Pour plus de renseignements, l’agent consulte Déterminer l’admissibilité aux prestations parentales quand le client ne prend plus soin de l’enfant .
       [Déterminer l’admissibilité aux prestations parentales quand le client ne prend plus soin de l’enfant](/fr/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml)

     [Déterminer l’admissibilité aux prestations parentales quand le client ne prend plus soin de l’enfant](/fr/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0052.dita`

Remarque :

Quand une personne enceinte ou qui a accouché récemment présente une demande de prestations de maternité et de prestations parentales, les prestations parentales, si elles sont payables, peuvent débuter au cours de la semaine qui suit la fin de la PP de maternité. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0053.dita`

Remarque :

Un client recevant des prestations de maternité ou des prestations parentales pourrait être exemptée de remplir des déclarations du prestataire. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0054.dita`

Remarque :

Quand le client présente une demande de prestations de maladie avant celle de prestations de maternité et qu’elle ne reçoit aucune prestation régulière pendant la PP, le client peut être admissible à la prolongation de la PP , afin de recevoir toutes les prestations de maternité et parentales auxquelles il est admissible.
       [prolongation de la PP](/fr/procedure/generic/knowledge.shtml#Prolongation_de_la_PP)

     [prolongation de la PP](/fr/procedure/generic/knowledge.shtml#Prolongation_de_la_PP) 

## Considérations régionales

Source topic: `fr_FR/activity/calc_sick_mat_par/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/calc_sick_mat_par/ce_quil_faut_chercher.dita`

## Que voulez-vous faire?

Source topic: `fr_FR/activity/calc_sick_mat_par/que_voulez-vous_faire.dita`

Les sous-activités relatives au calcul sont les suivantes :

- Déterminer si une demande de prestations est prête à être calculée — Prestations de maladie, de maternité et parentales
         [Déterminer si une demande de prestations est prête à être calculée — Prestations de maladie, de maternité et parentales](/fr/procedure/subactivity/detcalc_smp.shtml)

- Calculer une demande dans la version Web de SSA
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Réviser et saisir le calcul
         [Réviser et saisir le calcul](/fr/procedure/subactivity/input_calculation_results.shtml)

- Examiner le résultat du calcul
         [Examiner le résultat du calcul](/fr/procedure/subactivity/calc_result_ccb.shtml)

- Communiquer les décisions après le calcul
         [Communiquer les décisions après le calcul](/fr/procedure/subactivity/communicating_calc_decisions.shtml) 

## Référence de politique

Source topic: `fr_FR/activity/calc_sick_mat_par/reference_de_politique.dita`

 
