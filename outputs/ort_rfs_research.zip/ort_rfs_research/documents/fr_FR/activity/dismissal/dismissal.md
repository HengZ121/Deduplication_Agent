# Congédiement

Source map: `fr_FR/activity/dismissal/dismissal.ditamap`

## Sommaire

Source topic: `fr_FR/activity/dismissal/sommaire.dita`

Sommaire : Quand un client est congédié d’un emploi, le motif de cessation d’emploi (MCE) doit être examiné afin de déterminer si le client est admissible à des prestations. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/dismissal/ce_quil_faut_savoir.dita`

### Niveau 1

Source topic: `fr_FR/activity/dismissal/niveau_1.dita`

Congédiement — Inaptitude

Un agent de Niveau 1 peut rendre la décision d’autoriser un congédiement dans tous les genres de demande (GD) quand :

- le client indique qu’il a été congédié pour inaptitude ou pour un manque de travail; et

- l’employeur, quand il est contacté, confirme que le client n’était pas apte à occuper le poste et qu’il n’y avait pas eu d’inconduite; ou

- un commentaire dans le RE confirme que le congédiement est dû au fait que le client n’était pas apte à occuper le poste, qu’il n’a pas réussi la formation ou qu’il a été congédié au cours de la période de probation; et

- il n’y a aucune autre question litigieuse liée au congédiement qui pourrait empêcher l’agent de Niveau 1 d’autoriser le MCE.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0091.dita) 

L’agent de Niveau 1 peut rendre la décision d’autoriser le congédiement dans une demande initiale ou renouvelée sans effectuer un recueil de faits supplémentaire auprès du client quand :

- le client a travaillé pour l’employeur pendant 12 semaines ou moins; et

- le client n’a pas fourni de détails sur cet emploi dans la demande d’AE; et

- l’employeur, quand il est contacté, confirme que le client n’était pas apte à occuper le poste et qu’il n’y avait pas eu d’inconduite; ou

- un commentaire dans le RE confirme que le congédiement est dû au fait que le client n’était pas apte à occuper le poste, qu’il n’a pas réussi la formation ou qu’il a été congédié au cours de la période de probation; et

- il n’y a aucune autre question litigieuse liée au congédiement qui pourrait empêcher l’agent de Niveau 1 d’autoriser le MCE.

Pour plus de renseignements, l’agent de Niveau 1 consulte Rendre une décision sur un congédiement pour inaptitude — Demande initiale ou Rendre une décision sur un congédiement pour inaptitude — Demande renouvelée .
       [Rendre une décision sur un congédiement pour inaptitude — Demande initiale](/fr/procedure/task/dismissal_ic.shtml) 
       [Rendre une décision sur un congédiement pour inaptitude — Demande renouvelée](/ui/fr/procedure/task/dismissal_rc.shtml)

Si le recueil de faits révèle que le congédiement peut être attribuable à une mauvaise conduite, la décision doit être prise au Niveau 2.

Quand un client indique dans sa demande qu’il a déjà fourni les détails du MCE, le questionnaire sur le congédiement n’est pas présenté au client. Les mêmes conditions s’appliquent si un client ne déclare pas un MCE litigieux dans sa demande. Dans ce cas, l’agent de Niveau 1 effectue un recueil de faits avec le client afin de déterminer la procédure à suivre. Si le client indique un motif qui ne relève pas du Niveau 1, l’agent réassigne l’AT au Niveau 2.

**Suspension—Terminer une inadmissibilité**

Quand un client est suspendu de son emploi en raison d’une inconduite, une inadmissibilité est saisie. Quand une inadmissibilité indéterminée figure au dossier et que le client déclare être disponible pour le travail et ne pose aucune restriction quant à l’acceptation d’un emploi, l’agent de Niveau 1 peut terminer l’inadmissibilité si l’un des critères suivants est rempli :

- la période de suspension a pris fin; ou

- le client a été mis à pied; ou

- le motif pour lequel il n’est pas retourné au travail peut être autorisé au Niveau 1; ou

- le client a accumulé suffisamment d’heures assurables auprès d’un autre employeur après le début de la période de suspension pour remplir les conditions requises pour le GP demandé.

Si le recueil de faits révèle que le client a été congédié ou a quitté l’emploi pour un motif qui ne peut pas être accordé au Niveau 1, un agent de Niveau 2 doit rendre une décision sur la question. 

### Niveau 2

Source topic: `fr_FR/activity/dismissal/niveau_2.dita`

**Inconduite**

Les décisions concernant les cas d’inconduite sont seulement prises au Niveau 2.

**Retraite obligatoire**

La législation canadienne sur les droits de la personne interdit la retraite obligatoire. Cette législation couvre la majorité des emplois. Sauf pour de rares exceptions, les employeurs ne peuvent pas démontrer qu’il y a une véritable raison pour expliquer la retraite obligatoire.

Selon les recommandations, les employeurs choisissent le MCE G - Retraite obligatoire seulement en cas de retraite obligatoire, et choisissent le MCE E - Départ volontaire en cas de retraite volontaire.

Une retraite obligatoire ne peut être considérée comme un départ volontaire. Si le client n’a pas abandonné volontairement son emploi, la cessation d’emploi a été amorcée par l’employeur. Un agent de Niveau 2 doit rendre une décision sur le MCE en tant que congédiement.

**Suspension**

Quand un client est suspendu de son emploi, son MCE fait l’objet d’une décision au Niveau 2. Si l’agent détermine que le client a été suspendu en raison d’une inconduite, l’agent impose une inadmissibilité indéterminée 42 - Suspension d’un emploi (D42). Si l’inadmissibilité survient pendant la PP, l’inadmissibilité commence le jour auquel la suspension survient. Si le client présente une nouvelle demande, l’inadmissibilité commence au DPP. L’inadmissibilité continue pour la durée de la demande, sauf si le client est exempté de l’inadmissibilité.

Une inadmissibilité D42 peut être terminée quand la suspension se termine, si le client a accumulé suffisamment d’heures d’emploi assurables auprès d’un autre employeur depuis le début de la suspension pour avoir droit aux prestations, ou si le client est congédié ou quitte volontairement son emploi. Si le client est congédié ou quitte volontaire son emploi pendant la suspension, l’agent rend une décision sur le MCE avant de terminer l’inadmissibilité.

Si la suspension n’est que dans la période de référence (PR) et que le client est exempté et ne demande pas de prestations pendant la suspension, il n’est pas nécessaire que l’agent rende une décision sur la suspension. Cette règle s’applique à toute suspension dans la PR autre que celle liée au dernier employeur avant le DPP. L’agent consulte Rendre une décision sur un congédiement ou une suspension — Demande initiale afin d’obtenir des directives pour compléter l’AT Litige - Décision (DEC).
       [Rendre une décision sur un congédiement ou une suspension — Demande initiale](/fr/procedure/task/dismissal_ds_ic.shtml)

**Congédiement ou départ volontaire durant une période de suspension**

Pendant une période de suspension, si un client démissionne pour une raison qui ne peut pas être accordée au Niveau 1 ou que le client est congédié par l’employeur, l’agent rend une décision sur le MCE avant de terminer l’inadmissibilité. Les circonstances doivent être examinées afin de déterminer s’il faut imposer une exclusion. Il est également possible que l’exclusion soit rétroactive à la date du début de la suspension. Les décisions concernant les cas de congédiement durant une période de suspension peuvent seulement être prises au Niveau 2.

**Congédiement durant un conflit de travail**

Un recueil de faits supplémentaire doit être effectué quand un client est congédié avant ou pendant un conflit de travail. Si le congédiement s’est produit durant un conflit de travail, une inadmissibilité peut être imposée pour la durée du conflit. Les décisions concernant ces cas peuvent seulement être prises au Niveau 2. 

### Niveaux de décision

Source topic: `fr_FR/activity/dismissal/niveaux_de_decision.dita`

Quand TAD ne peut pas rendre une décision sur le congédiement, un AT DEC est créé et assigné au niveau approprié, conformément à la Politique nationale sur les niveaux de décision .
       [Politique nationale sur les niveaux de décision](/fr/policy/nationalpolicy/levels_decision-annex1.shtml)

S’il y a un AT DEC pour un MCE litigieux qui se situe après la date de DPP dans une demande dont l’état est En cours (Automatisation) ou En cours (Manuel) , l’agent consulte  les procédures de Niveau 2 . Le système met à jour le champ Condition spéciale du RE quand l’AT DEC est complété. Au besoin, l’agent saisit manuellement l’exclusion dans ETI.
       [Niveau 2](/fr/procedure/task/vllevel2_ic.shtml) 

### Motif de cessation d’emploi (MCE) — Mesures temporaires du budget

Source topic: `fr_FR/activity/dismissal/motif_de_cessation_demploi_mce__mesures_fe447e72.dita`

**Rendre une décision sur la dernière période d’emploi dans la période de référence (PR) — DPP entre la s/c 2310 et la s/c 2361**

Le budget 2021 a introduit une mesure de simplification temporaire à partir du 26 septembre 2021. Pour les demandes dont le DPP est entre la s/c 2310 et la s/c 2361, l’agent rend une décision sur la dernière période d’emploi dans la PR seulement si elle est litigieuse. Si l’agent autorise le dernier MCE, tout autre RE dans la PR, même s’il est litigieux, est utilisé pour calculer la demande. Cependant, si l’agent n’autorise pas le MCE du dernier RE dans la PR, la demande est calculée avec une exclusion.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0081.dita) 

Cette nouvelle mesure ne s’applique pas aux demandes pour travailleurs indépendants et de pêcheur. Si le client qui demande des prestations pour travailleurs indépendants ou de pêcheur a un DPP dans la s/c 2310 ou après, un emploi assurable dans la PR et des RE litigieux, une décision doit être rendue sur ces RE selon les procédures habituelles.

Quand le client déclare un MCE litigieux auprès d’autres employeurs dans la même demande, si TAD n’autorise pas le litige en vertu des règles de décision automatique, le litige est automatiquement résolu et TAD crée un rapport de décision (RD) qui indique Aucune décision requise . Le champ Condition spéciale du RE n’est pas mis à jour, et le RE est inclus dans le calcul. Aucun AT DEC n’est créé pour le MCE.

Quand il y a plus d’un RE avec le même dernier jour payé (DJP), et qu’une des RE est litigieux alors que l’autre RE ne l’est pas, une décision n’est pas requise et les 2 RE seront inclus dans le calcul.

**Décision non requise : Motif de cessation d’emploi (MCE) au-delà de 12 semaines — DPP entre la s/c 2258 et la s/c 2309**

Les principes de décision dans les demandes initiales ou de nouveau calcul dont le DPP est entre la s/c 2258 et la s/c 2309 s’appliquent seulement au MCE du dernier emploi dans la PR et aux questions liées aux MCE litigieux qui sont dans la période de 12 semaines avant l’arrêt de rémunération (A de R) utilisé pour établir la demande.

**Décision non requise antérieurement — Processus spécialisé du TAD**

Un nouveau processus spécialisé qui simplifie le traitement des demandes initiales a été présenté le 27 septembre 2020. Les demandes traitées dans ce processus spécialisé du TAD ont été établies sans rendre de décision sur les questions litigieuses liées au MCE dans la PR. Il est possible de repérer les questions liées au MCE pour lesquels aucune décision n’a été rendue, car le champ Condition spéciale a été laissé vide sur le RE, mais le RE a tout de même été inclus dans le calcul initial.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0092.dita) 

Si aucune décision n’a été rendue sur un MCE litigieux dans la PR dans une demande initiale de prestations régulières lors du processus spécialisé du TAD, il n’est pas nécessaire de rendre une décision sur la demande renouvelée tant que le client demande toujours des prestations régulières. Cependant, il pourrait y avoir un AT DEC en suspens.

S’il existe un AT DEC en suspens pour un MCE litigieux dans la PR, l’agent ne rend pas de décision sur la question. Pour supprimer l’AT DEC en suspens, l’agent envoie une demande à un utilisateur autorisé afin qu’il le supprime.

S’il existe un AT EVD Renouvellement et un AT DEC en suspens pour un MCE litigieux dans la PR, l’agent de Niveau 1 traite l’AT EVD Renouvellement même si l’AT DEC demeure en suspens. L’agent :

- détermine la date d’entrée en vigueur du renouvellement;

- saisit le renouvellement et complète le numéro d’enregistrement;

- complète l’AT EVD Renouvellement.

L’agent complète l’AT EVD Renouvellement avant d’envoyer une demande à un utilisateur autorisé afin qu’il supprime l’AT DEC en suspens.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0093.dita) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0091.dita`

Remarque :

Pour les congédiements, la Politique nationale sur les niveaux de décision indique que la confirmation de l’employeur n’est pas requise si la déclaration dans le RE (c.-à-d. un commentaire dans la case 18 - Observations ou l’indicatif M - Congédiement ou suspension / Congédié avant la fin de la période de probation dans la case 16 - Raison du présent relevé d’emploi d’un RE web) indique que le client a été congédié en raison d’une inaptitude, pour ne pas avoir réussi la formation ou dans la période de probation.
       [Politique nationale sur les niveaux de décision](/fr/policy/nationalpolicy/levels_decision-annex1.shtml)

     [Politique nationale sur les niveaux de décision](/fr/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0081.dita`

Remarque :

Pour toutes les demandes initiales dont le DPP provisoire est la s/c 2361, des AT DEC sont créés pour la dernière période d’emploi et pour toute autre période d’emploi litigieuse dans la PR. L’agent suit les procédures habituelles pour rendre une décision sur ces AT, car le DPP final peut être la s/c 2362 ou après. Toutefois, si le DPP final est entre la s/c 2310 et la s/c 2361, le système applique les mesures temporaires du budget 2021. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0092.dita`

Remarque :

Le processus spécialisé du TAD se termine le 16 août 2021. À partir de cette date, TAD crée un AT DEC pour les questions litigieuses liées aux MCE dans la PR, puisqu’il n’établit plus de demandes sans rendre de décision sur celles-ci. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0093.dita`

Remarque :

Une décision doit être rendue pour toute question litigieuse liée au MCE dans la période de prestation (PP). 

## Considérations régionales

Source topic: `fr_FR/activity/dismissal/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/dismissal/ce_quil_faut_chercher.dita`

### Dans SNCT :

Source topic: `fr_FR/activity/dismissal/dans_snct.dita`

- Y a-t-il des RSDP, des AT Action à prendre (AP) ou des documents qui contiennent un aide-mémoire ou des renseignements supplémentaires sur le congédiement ou la suspension? 

### Dans ETI :

Source topic: `fr_FR/activity/dismissal/dans_eti.dita`

- Y a-t-il une demande initiale, continue ou renouvelée? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/dismissal/que_voulez-vous_faire.dita`

## Référence de politique

Source topic: `fr_FR/activity/dismissal/reference_de_politique.dita`

 
