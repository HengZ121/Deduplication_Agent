# Traiter le calcul ou le nouveau calcul d’une demande de PDC

Source map: `fr_FR/activity/calc_ccb/calc_ccb.ditamap`

## Sommaire

Source topic: `fr_FR/activity/calc_ccb/sommaire.dita`

Sommaire : Quand un client présente une demande de PDC, un agent doit calculer la demande. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/calc_ccb/ce_quil_faut_savoir.dita`

### Untitled section

Source topic: `fr_FR/activity/calc_ccb/untitled_section.dita`

[Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0018.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0019.dita) 

### Calculer manuellement une demande

Source topic: `fr_FR/activity/calc_ccb/calculer_manuellement_une_demande.dita`

Les demandes PDC doivent être calculées par un agent puisque TAD n’est pas en mesure de les automatiser. Le calcul manuel d’une demande est complexe et doit être fait seulement par un agent qui a suivi la formation nécessaire.

L’agent doit traiter le calcul ou le nouveau calcul d’une demande quand :

- un client présente une demande de prestations sur papier

- TAD n’est pas en mesure de traiter le calcul d’une application électronique

- une demande nécessite un nouveau calcul et que TAD n’est pas en mesure d’automatiser le nouveau calcul 

### Calcul ou nouveau calcul

Source topic: `fr_FR/activity/calc_ccb/calcul_ou_nouveau_calcul.dita`

Quand un AT Évaluation de la demande (EVD) ou Demande spécialisée (DS) est reçu, l’agent doit effectuer le calcul initial de la demande.

Quand un AT Révision de la demande (RVD) avec un problème lié au nouveau calcul est reçu, l’agent doit effectuer le nouveau calcul d’une demande qui était finalisée. On se sert parfois de « recalcul » pour parler d’un nouveau calcul. Une fois qu’un calcul initial est bien transmis, un nouveau calcul d’une demande peut être effectué quand de nouveaux renseignements reçus auront une incidence sur le résultat du calcul précédent (p. ex. un RE modifié est émis).

Quand un nouveau calcul est requis pour un cas d’Intégrité, un AT Action à prendre (AP) urgent est créé pour le nouveau calcul. L’agent assigné à cet AT doit effectuer le nouveau calcul.

Le nouveau calcul d’une demande peut avoir une incidence sur :

- la possibilité du client d’établir une période de prestations (PP);
         [période de prestations](/fr/procedure/generic/knowledge.shtml#Etablissement_de_la_periode_de_prestati)

- l’admissibilité du client aux prestations;

- le taux de prestations du client.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0020.dita) 

### Effectuer le nouveau calcul d’une demande touchée par la modification d’un NAS ou d’une région

Source topic: `fr_FR/activity/calc_ccb/effectuer_le_nouveau_calcul_dune_demand_69c56db8.dita`

Si le client a déménagé dans une autre région, que son NAS a été modifié, ou les 2, depuis le calcul de la demande initiale, il peut ne pas être possible d’enregistrer le nouveau calcul dans la version Web de SSA. Le nouveau calcul doit être enregistré dans le centre de technologie de l’information (CTI) initial ou sous le NAS précédent, mais il doit être saisi manuellement dans ETI avec le CTI actuel et le nouveau NAS, si applicable.

Pour plus de renseignements, l’agent consulte les annexes B, C et D du Guide de saisie des données de nouveau calcul – version SSA .
       [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Structure des procédures de calcul

Source topic: `fr_FR/activity/calc_ccb/structure_des_procedures_de_calcul.dita`

La procédure de calcul est divisée en sous-activités afin de fournir une séquence logique à suivre lorsqu’une demande est calculée. Bien que chaque agent ait une séquence préférée qui est aussi correcte, la procédure est structurée afin d’assurer que l’agent effectue toutes les actions nécessaires pour traiter la demande :

- Déterminer si une demande est prête à être calculée.

- Calculer une demande dans la version Web de SSA.

- Examiner le résultat du calcul.

- Examiner et saisir le calcul.

- Communiquer les décisions après le calcul.

Chaque sous-activité comporte des liens menant à des procédures supplémentaires qui peuvent être nécessaires pour terminer le processus de calcul. 

### Gérer l’AT

Source topic: `fr_FR/activity/calc_ccb/gerer_lat.dita`

Peu importe la façon dont un agent organise son travail, l’agent à qui est assigné le calcul de la demande doit s’assurer que tout problème est résolu et que tous les faits nécessaires pour calculer la demande sont au dossier avant de compléter le calcul. À moins que les procédures fassent état d’une directive contraire, le calcul ne doit pas être complété tant que tous les AT nécessaires pour finaliser le calcul n’ont pas été complétés. Si le calcul ne peut pas être complété parce qu’il y a un AT connexe en suspens, l’AT du calcul doit être déplacé vers En suspens jusqu’à ce que l’AT connexe soit complété.

Il se peut que des AT liés à une même demande faisant l’objet d’une évaluation soient assignés à divers agents (p. ex. un AT RE Litigieux motif de cessation d’emploi [MCE] est assigné à un agent et un AT EVD est assigné à un autre agent). L’agent complète seulement l’AT qui lui est assigné, sauf si une procédure prévoit le contraire.

Lorsqu’il évalue une demande, l’agent à qui a été assigné un AT du calcul doit aussi examiner la Note client afin de déterminer les actions à prendre (p. ex. saisir des transactions, envoyer des lettres).

Lorsque le calcul est complété, l’agent doit communiquer la décision au client si nécessaire. 

### Choisir le genre de prestation (GP) approprié

Source topic: `fr_FR/activity/calc_ccb/choisir_le_genre_de_prestation_gp_approprie.dita`

Quand l’enregistrement d’une demande crée automatiquement un AT RVD, dans SNCT, le champ Genre de prestations de l’AT RVD est prérempli par Régulier. L’agent met manuellement à jour ce champ avec le GP approprié. Pour une demande initiale ou renouvelée, l’agent choisit le GP indiqué dans la demande d’AE. Pour une demande de conversion dans une demande continue ou toute autre demande de conversion, l’agent choisit le nouveau GP demandé.

Lors de la création d’un AT AP, Rappel (RA), Évaluation pour le calcul (ECAL) ou À revoir (AR), l’agent choisi le GP indiqué dans la demande d’AE. Si le GP a été modifié depuis que le client a présenté sa demande de prestations, l’agent choisit le GP indiqué dans ETI. 

### Partager des renseignements

Source topic: `fr_FR/activity/calc_ccb/partager_des_renseignements.dita`

Jusqu’à 26 clients peuvent partager une demande PDC pour un même patient.

Quand un client présente une demande AW pour des PDC ou présente le formulaire Prestations de compassion - Annexe 5 avec une demande papier pour des PDC, il faut informer le client que dans certains cas, l’information pourrait être partagée avec d’autres membres de la famille du patient. L’identité du client pourrait être dévoilée aux autres membres de la famille qui ont effectué une demande pour des PDC. Le nombre de semaines payées ou payables pourrait également être dévoilé à un membre de la famille qui effectue une demande pour des PDC.

Si une personne qui n’est pas un client veut savoir si d’autres membres de la famille du patient ont effectué une demande ou ont reçu des prestations pour des PDC, l’agent doit l’informer que ce renseignement ne peut être dévoilé. Toutefois, si une personne a l’intention de présenter une demande pour des PDC, le nombre de semaines payables peut être dévoilé. L’agent ne peut pas fournir d’autres renseignements tant que la demande n’a pas été présentée. L’agent ne doit jamais révéler le NAS d’un autre client. 

### Remplir les conditions requises pour des PDC

Source topic: `fr_FR/activity/calc_ccb/remplir_les_conditions_requises_pour_des_pdc.dita`

Pour remplir les conditions requises pour recevoir des PDC, un client doit remplir les conditions suivantes :

- Le client a présenté une demande de prestations.

- Le client a subi un arrêt de rémunération (A de R) pendant sa période de référence (PR).
         [arrêt de rémunération](/fr/procedure/generic/knowledge.shtml#Arret_de_remuneration) 
         [période de référence](/fr/procedure/generic/knowledge.shtml#Periode_de_reference)

- Le client est de première catégorie (a accumulé au moins 600 heures d’emploi assurable) ou le DPP est entre la s/c 2310 et la s/c 2361 et le client a au moins 420 heures d’emploi assurable.
         [première catégorie](/fr/procedure/generic/knowledge.shtml#client12)

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0021.dita) 

**Remplir les conditions requises avec la norme d’admissibilité commune (de la s/c 2310 à la s/c 2361)**

Dans le cadre du budget 2021, le gouvernement du Canada a annoncé qu’une norme d’admissibilité commune nationale de 420 heures d’emploi assurable est requise pour établir une demande de prestations régulières ou spéciales. Si le client a une violation à son dossier, une majoration des conditions requises pourrait s’appliquer. La norme d’admissibilité commune s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, les définitions prestataire de première et de deuxième catégorie dans la LAE 6(1) sont abrogées. Les clients dont la demande est établie avec 420 heures d’emploi assurable remplissent les conditions requises pour recevoir des prestations spéciales. L’agent s’assure que toutes les autres conditions requises et d’admissibilité sont remplies.
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Admissibilité aux PDC

Source topic: `fr_FR/activity/calc_ccb/admissibilite_aux_pdc.dita`

Pour être admissible aux PDC, un client doit remplir les conditions suivantes :

- Le client est en mesure de fournir un certificat médical qui prouve qu’un patient qui est un membre de la famille (comme il est énoncé Membres de la famille ) remplit les 2 conditions suivantes :

- Le patient est gravement malade avec un risque élevé de décéder à l’intérieur d’une période de 26 semaines.

- Le patient requiert les soins ou le soutien d’un ou plusieurs membres de sa famille.

         [Membres de la famille](/fr/procedure/generic/additionalresources/definition_fam_mem.shtml)

- Le client fournit des soins ou du soutien au patient dont le nom figure sur le certificat médical.

- Le client demande des prestations pendant la fenêtre de compassion (FC) établie pour le patient.

- Les 26 semaines payables des PDC n’ont pas déjà été payées dans la FC du patient.

Un client de première catégorie est admissible à des prestations spéciales peu importe le MCE.
       [prestations spéciales](/fr/procedure/generic/knowledge.shtml#Prestations_speciales)

Une inadmissibilité administrative est imposée pour empêcher le paiement de prestations régulières à un client qui est admissible aux prestations spéciales mais pas aux prestations régulières. 

### Certificat médical

Source topic: `fr_FR/activity/calc_ccb/certificat_medical.dita`

Un client qui demande des PDC doit être en mesure de fournir un certificat médical qui prouve que le membre de la famille du client gravement malade (patient) a besoin de soins et de soutien. Le certificat médical doit être rempli par un docteur ou un autre praticien et doit confirmer que le patient risque de décéder dans les 26 semaines et qu’il requiert les soins ou le soutien d’un ou de plusieurs membres de sa famille.

Il n’est pas toujours nécessaire pour un client de soumettre un certificat médical puisqu’un seul certificat médical est requis par patient et par FC, peu importe le nombre de membres de la famille qui reçoive des prestations pour prodiguer des soins ou du soutien au patient. Si un certificat médical est nécessaire et n’est pas fourni, l’agent impose une inadmissibilité 53 - Prestations de soins de compassion - Aucune preuve médicale sur la demande. Si un certificat médical est nécessaire et que le client ne remplit pas les critères d’admissibilité, l’agent impose une inadmissibilité 51 - Ne rencontre pas les conditions d’admissibilité de prestations de soins de compassion sur la demande. Les agents ne doivent pas demander un certificat médical à moins qu’il soit nécessaire. Si un certificat médical est reçu, mais non exigé, l’agent doit l’examiner et mettre à jour le dossier en fonction des renseignements fournis par le certificat médical. 

### Fenêtre de compassion (FC)

Source topic: `fr_FR/activity/calc_ccb/fenetre_de_compassion_fc.dita`

Quand un certificat médical pouvant être accepté en tant que preuve du problème médical du patient est reçu, une FC est établie pour une période de 52 semaines ou jusqu’à la semaine du décès du patient, selon la plus courte de ces périodes. Une fois que la FC est établie, elle ne peut être prolongée. Si des PDC supplémentaires sont requises, une nouvelle FC peut être établie, à la fin de la FC initiale. 

### Verser des prestations

Source topic: `fr_FR/activity/calc_ccb/verser_des_prestations.dita`

Le nombre maximal de semaines de PDC qui peuvent être versées durant une PP est 26 à l’égard d’un patient ou plusieurs patients. Jusqu’à 26 clients peuvent se partager les PDC à l’égard d’un patient. Un maximum de 26 semaines est payable pour un membre de la famille gravement malade. Le versement de PDC doit se faire pendant la FC.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0022.dita) 

Une fois que la demande est établie et que l’admissibilité aux PDC est déterminée, des PDC sont payables pour chaque semaine pour laquelle le client soumet une déclaration du prestataire et pendant laquelle le client :

- déclare 5 jours de non-disponibilité

- a fourni la preuve requise pour des PDC

- n’a pas reçu de rémunération ou de répartition empêchant le versement d’un paiement

- n’a pas fait l’objet d’une inadmissibilité empêchant le paiement

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0023.dita) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0018.dita`

Remarque :

Les demandes de PDC sont traitées dans les bureaux responsables de ces prestations .
       [bureaux responsables de ces prestations](http://edsc.prv/fr/service-canada/ae/contacts/index.shtml)

     [bureaux responsables de ces prestations](http://edsc.prv/fr/service-canada/ae/contacts/index.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0019.dita`

Remarque :

À moins d’avis contraire, les références aux calculs s’appliquent aussi aux nouveaux calculs. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0020.dita`

Remarque :

Quand le nouveau calcul d’une demande est nécessaire, l’agent suit les procédures normales d’évaluation du calcul et consulte Nouveau calcul : Évaluation — Instructions ainsi que le Guide de saisie des données de nouveau calcul – version SSA , au besoin. Une demande qui nécessite un nouveau calcul doit être évaluée de la même façon qu’une demande qui nécessite un calcul initial.
       [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
       [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml)

     [Nouveau calcul : Évaluation — Instructions](/fr/procedure/generic/additionalresources/recalculation_assessment.shtml) 
     [Guide de saisie des données de nouveau calcul – version SSA](https://edsc.prv/fr/service-canada/ae/technologies/spp/guide_saisie_donnes_nouveau_calcul.shtml) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0021.dita`

Remarque :

S’il y a une violation au dossier du client, il se peut qu’il y ait une majoration des conditions requises .
       [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r)

     [majoration des conditions requises](/fr/procedure/generic/knowledge.shtml#Majoration_nombre_dheures_demploi_ass_r) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0022.dita`

Remarque :

Le DC peut être reporté si le client reçoit des PDC.
       [DC](/fr/procedure/generic/knowledge.shtml#Delai_de_carence)

     [DC](/fr/procedure/generic/knowledge.shtml#Delai_de_carence) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0023.dita`

Remarque :

Un client recevant des PDC pourrait être exempté de remplir des déclarations du prestataire. 

## Considérations régionales

Source topic: `fr_FR/activity/calc_ccb/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/calc_ccb/ce_quil_faut_chercher.dita`

## Que voulez-vous faire?

Source topic: `fr_FR/activity/calc_ccb/que_voulez-vous_faire.dita`

- Déterminer si une demande de prestations est prête à être calculée — PDC
         [Déterminer si une demande de prestations est prête à être calculée — PDC](/fr/procedure/subactivity/detcalc_ccb.shtml)

- Calculer une demande dans la version Web de SSA
         [Calculer une demande dans la version Web de SSA](/fr/procedure/subactivity/calc_ssa_sb.shtml)

- Examiner le résultat du calcul
         [Examiner le résultat du calcul](/fr/procedure/subactivity/calc_result_ccb.shtml)

- Réviser et saisir le calcul
         [Réviser et saisir le calcul](/fr/procedure/subactivity/input_calculation_results.shtml)

- Communiquer les décisions après le calcul
         [Communiquer les décisions après le calcul](/fr/procedure/subactivity/communicating_calc_decisions.shtml) 

## Référence de politique

Source topic: `fr_FR/activity/calc_ccb/reference_de_politique.dita`

 
