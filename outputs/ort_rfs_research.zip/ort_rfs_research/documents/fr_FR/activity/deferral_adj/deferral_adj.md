# Report de la décision

Source map: `fr_FR/activity/deferral_adj/deferral_adj.ditamap`

## Sommaire

Source topic: `fr_FR/activity/deferral_adj/sommaire.dita`

Sommaire : Dans certaines situations, la décision sur une question litigieuse peut être reportée. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/deferral_adj/ce_quil_faut_savoir.dita`

### Untitled section

Source topic: `fr_FR/activity/deferral_adj/untitled_section.dita`

Quand un client présente une demande d’AE, il doit remplir les conditions d’admissibilité pour le genre de prestations (GP) qu’il demande. Dans certains cas, l’agent peut reporter une décision sur les questions liées à un motif de cessation d’emploi (MCE) litigieux (y compris un congé autorisé) ou à la disponibilité. 

### Demandes initiales

Source topic: `fr_FR/activity/deferral_adj/demandes_initiales.dita`

Il y a 14 situations dans lesquelles la décision peut être reportée dans une demande initiale :

- toute question liée à une décision quand la demande a été automatisée PPNE 2;

- toute question liée à une décision quand la demande est traitée manuellement PPNE 2 le 27e jour;

- toute question liée à une décision quand la demande a été automatisée PPNE 1 ou 5;

- toute question liée à une décision quand la demande est traitée manuellement PPNE 1 ou 5;

- toute question liée à une décision quand le client a accumulé moins de 420 heures dans la période de référence (PR) et demande des prestations régulières ou de maladie;

- toute question liée à une décision quand le client a accumulé moins de 600 heures dans la PR et demande des prestations spéciales autres que des prestations de maladie;

- le MCE est B - Grève ou Lock-out (conflit collectif) et la demande est PPNE;

- une question liée à un MCE litigieux quand le dernier RE est le seul RE ayant un MCE litigieux dans la PR, le client est autrement disponible pour travailler et remplit les conditions requises pour des prestations de maladie;

- une question liée à un MCE litigieux quand le dernier RE est le seul RE ayant un MCE litigieux dans la PR et le client remplit les conditions requises pour des prestations spéciales autres que les prestations de maladie;

- une question liée à un MCE litigieux avant un événement entraînant une exclusion dans la PR quand le client qui demande des prestations n’a pas accumulé assez d’heures depuis l’événement entraînant l’exclusion pour éliminer l’exclusion indéterminée;

- un MCE litigieux survenu avant l’événement entraînant une exclusion indéterminée quand le client est autrement disponible pour travailler et qu’il remplit les conditions requises pour des prestations de maladie;

- un MCE litigieux survenu avant l’événement entraînant une exclusion indéterminée quand le client remplit les conditions requises pour des prestations spéciales autres que les prestations de maladie.

- un congé autorisé quand :

- le congé autorisé n’ est pas le MCE sur le RE le plus récent;

- le client a commencé un nouvel emploi pendant son congé autorisé de l’emploi précédent;

- le client a cessé de travailler pour le nouvel employeur pour des raisons médicales (le MCE sur le RE le plus récent est D - Maladie ou blessure );

- le client est autrement disponible pour travailler et remplit les conditions requises pour des prestations de maladie.

- un congé autorisé quand :

- le congé autorisé n’ est pas le MCE sur le RE le plus récent.

- le client a commencé un nouvel emploi pendant son congé autorisé de l’emploi précédent.

- le client a cessé de travailler pour le nouvel employeur en raison des motifs liés au GP demandé.

- le MCE sur le RE le plus récent est F , P ou Z .

- le client remplit les conditions requises pour des prestations spéciales.

**Mesures temporaires du budget 2021 :**

- Quand le DPP est entre la s/c 2310 et la s/c 2361, la décision sur un MCE litigieux avant la dernière période d’emploi n’ est pas reportée, puisqu’aucune décision n’est requise sur les MCE litigieux dans la PR avant la dernière période d’emploi. Cette mesure ne s’applique pas aux demandes de prestations de pêcheur et de prestations pour les travailleurs indépendants.

- Quand le DPP est entre la s/c 2310 et la s/c 2361 et qu’il s’agit d’une demande de prestations de maladie, la décision sur le MCE de la dernière période d’emploi peut être reportée, peu importe le MCE dans les autres RE dans la PR, tant que le client est autrement disponible pour travailler et qu’il remplit les conditions requises pour recevoir des prestations de maladie. Cette mesure ne s’applique pas aux demandes de prestations de pêcheur et de prestations pour les travailleurs indépendants.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0081.dita) 
     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0082.dita) 

### Demande autre qu’initiale

Source topic: `fr_FR/activity/deferral_adj/demande_autre_quinitiale.dita`

Dans une demande renouvelée, de conversion ou continue, la décision est reportée dans les situations suivantes :

- pour tous les MCE litigieux quand il y a déjà une exclusion indéterminée pour :

- des prestations régulières, si le client n’a pas accumulé assez d’heures depuis l’événement entraînant une exclusion pour présenter une nouvelle demande initiale;

- des prestations de maladie, si le client est autrement disponible pour travailler;

- tous les cas de prestations de maternité, parentales, PDC et pour proches aidants.

- pour tous les MCE litigieux quand :

- le client remplit les conditions requises pour recevoir des prestations de maladie, de maternité, parentales, PDC et pour proches aidants;

- il y a déjà une inadmissibilité 46 - Ne rencontre pas la norme variable - prestations spéciales payables (D46) indéterminée;

- le client est autrement disponible pour travailler (prestations de maladie seulement).

- pour tous les MCE litigieux quand :

- le client remplit les conditions requises pour recevoir des prestations de maladie, de maternité, parentales, PDC et pour proches aidants;

- le MCE litigieux n’a pas d’incidence sur les prestations déjà versée;

- le client ne demande pas de prestations régulières pour toute période après le MCE litigieux;

- le client est autrement disponible pour travailler (prestations de maladie seulement).

- pour un congé autorisé quand :

- le congé autorisé n’ est pas le MCE sur le RE le plus récent;

- le client a commencé un nouvel emploi pendant son congé autorisé de l’emploi précédent;

- le client a cessé de travailler pour le nouvel employeur pour des raisons médicales;

- le MCE sur le RE le plus récent est D - Maladie ou blessure ;

- s’il n’était pas malade, le client travaillerait pour le nouvel employeur.

- pour un congé autorisé quand :

- le congé autorisé n’ est pas le MCE sur le RE le plus récent;

- le client a commencé un nouvel emploi pendant son congé autorisé de l’emploi précédent;

- le client a cessé de travailler pour le nouvel employeur en raison des motifs liés au GP demandé.

- le MCE sur le RE le plus récent est F , P ou Z ;

- le client remplit les conditions requises pour des prestations spéciales.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0083.dita) 

**Mesures temporaires du budget 2021**

Dans les demandes de prestations régulières, quand le DPP est entre la s/c 2310 et la s/c 2361, l’agent rend une décision sur tout nouveau MCE litigieux dans la période de prestations (PP). La décision ne peut pas être reportée, même s’il y a une exclusion indéterminée pour un MCE litigieux qui n’a pas été autorisé. Cette mesure ne s’applique pas aux demandes de prestations de pêcheur et de prestations pour les travailleurs indépendants. 

### Client ne demande pas des prestations

Source topic: `fr_FR/activity/deferral_adj/client_ne_demande_pas_des_prestations.dita`

Quand un nouveau MCE litigieux est reçu dans une demande établie, peu importe si elle est active ou terminée, l’agent peut reporter la décision si les 2 conditions suivantes sont remplies :

- Le MCE litigieux n’a aucune incidence sur une période pour laquelle des prestations ont déjà été versées.

- Le client ne demande pas de prestations pour une période après le MCE litigieux. 

### Exception — Enquête d’Intégrité

Source topic: `fr_FR/activity/deferral_adj/exception__enquete_dintegrite.dita`

L’agent de Niveau 2 doit rendre une décision sur tous les MCE litigieux qui font partie de l’enquête d’Intégrité. La décision d’une enquête d’Intégrité ne peut pas être reportée. 

### AT Litige — Décision (DEC)

Source topic: `fr_FR/activity/deferral_adj/at_litige__decision_dec.dita`

Quand un litige est identifié dans une demande initiale ou une demande de renouvellement, un AT DEC est créé. Il est impossible de calculer une demande initiale ou la demande de renouvellement ne peut pas être complétée avant que tous les AT DEC soient complétés.

Pour certains AT DEC, il y a un onglet Résoudre le problème , qui comprend les écrans où l’agent consigne la décision. Quand l’AT DEC est complété, SNCT crée un rapport de décision (RD) en fonction des écrans Résoudre le problème . S’il n’y a pas d’onglet Résoudre le problème pour l’AT DEC, l’agent est responsable de créer le RD. Pour tous les AT DEC, l’agent met à jour le champ Condition spéciale du RE, au besoin. 

### Communication

Source topic: `fr_FR/activity/deferral_adj/communication.dita`

Il n’ est pas nécessaire d’envoyer un avis écrit au client concernant le report d’une décision pour toute question litigieuse liée au MCE. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0081.dita`

Remarque :

Pour toutes les demandes initiales dont le DPP provisoire est la s/c 2361, des AT DEC sont créés pour la dernière période d’emploi et pour toute autre période d’emploi litigieuse dans la PR. L’agent suit les procédures habituelles pour rendre une décision sur ces AT, car le DPP final peut être la s/c 2362 ou après. Toutefois, si le DPP final est entre la s/c 2310 et la s/c 2361, le système applique les mesures temporaires du budget 2021. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0082.dita`

Remarque :

L’agent ne peut pas reporter une décision sur un MCE litigieux avant un événement entraînant une exclusion dans la PR si le résultat obtenu est l’exclusion du RE dans le calcul. Dans ce cas, il faut aussi rendre une décision sur tout MCE antérieur puisque des heures et une rémunération pourraient être comptées dans le calcul. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0083.dita`

Remarque :

Une mesure temporaire du budget 2021 s’applique aux demandes dont le DPP est entre le 26 septembre 2021 (s/c 2310) et le 18 septembre 2022 (s/c 2361). Dans cette période, aucune inadmissibilité D46 ne sera saisie dans ces demandes. 

## Considérations régionales

Source topic: `fr_FR/activity/deferral_adj/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/deferral_adj/ce_quil_faut_chercher.dita`

### Dans ETI :

Source topic: `fr_FR/activity/deferral_adj/dans_eti.dita`

- Quel est le GP de la demande?

- S’agit-il d’une demande initiale ou renouvelée? 

### Dans SNCT :

Source topic: `fr_FR/activity/deferral_adj/dans_snct.dita`

- Quel GP est demandé par le client? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/deferral_adj/que_voulez-vous_faire.dita`

## Référence de politique

Source topic: `fr_FR/activity/deferral_adj/reference_de_politique.dita`

 
