# AT Litige - Décision Examen du MCE

Source map: `fr_FR/activity/adj_rfs_review/adj_rfs_review.ditamap`

## Sommaire

Source topic: `fr_FR/activity/adj_rfs_review/sommaire.dita`

Sommaire : Lorsqu’on reçoit un RE régulier qui présente un motif de cessation d’emploi (MCE) K - Autre ou G - Retraite obligatoire , ou lorsqu’on reçoit un RE de pêcheur qui présente un MCE B - Autre , un AT Litige - Décision (DEC) Examen du MCE est créé. Le système ne peut pas créer de lien entre le RE et la période d’emploi correspondante déclarée dans la demande électronique initiale. 

## Ce qu’il faut savoir

Source topic: `fr_FR/activity/adj_rfs_review/ce_quil_faut_savoir.dita`

### Conditions pour créer l’AT

Source topic: `fr_FR/activity/adj_rfs_review/conditions_pour_creer_lat.dita`

Lorsqu’aucune des périodes d’emploi déclarées dans la demande ne présente de MCE litigieux, ou lorsque toutes les périodes d’emploi présentant un MCE litigieux sont déjà liées à un RE, un AT DEC Examen du MCE est créé. 

### Examiner le motif de cessation d’emploi (MCE)

Source topic: `fr_FR/activity/adj_rfs_review/examiner_le_motif_de_cessation_demploi_mce.dita`

Lorsqu’il reçoit un AT DEC Examen du MCE, l’agent de Niveau 1 doit examiner les renseignements au dossier et, au besoin, effectuer un recueil de faits auprès des personnes intéressées afin de déterminer si le MCE est litigieux et s’il doit faire l’objet d’une décision. L’agent doit prendre les mesures appropriées pour s’assurer que le MCE litigieux soit résolu. 

## Considérations régionales

Source topic: `fr_FR/activity/adj_rfs_review/considerations_regionales.dita`

## Ce qu’il faut chercher

Source topic: `fr_FR/activity/adj_rfs_review/ce_quil_faut_chercher.dita`

### Dans SNCT :

Source topic: `fr_FR/activity/adj_rfs_review/dans_snct.dita`

- Quel genre d’AT DEC Examen du MCE a été créé? 

## Que voulez-vous faire?

Source topic: `fr_FR/activity/adj_rfs_review/que_voulez-vous_faire.dita`

## Références politiques

Source topic: `fr_FR/activity/adj_rfs_review/references_politiques.dita`

 
