# Guide de la prestation d’AE d’urgence

Source map: `fr_FR/policy/generic/ei_erb_digest/ei_erb_digest.ditamap`

## Generic

Source topic: `fr_FR/policy/generic/ei_erb_digest/generic.dita`

Table des matières

- Introduction
         [Introduction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#introduction)

- Chapitre 1 : Notions de base
         [Chapitre 1 : Notions de base](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_1)

- Chapitre 2 : Définition de prestataire
         [Chapitre 2 : Définition de prestataire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_2)

- Chapitre 3 : Procédure de présentation de la demande

- 3.1 Forme et modalités alternatives pour présenter une demande pour la PU AE
             [3.1 Forme et modalités alternatives pour présenter une demande pour la PU AE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_3_1)

         [Chapitre 3 : Procédure de présentation de la demande](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_3)

- Chapitre 4 : Admissibilité

- 4.1 Résidence au Canada
             [4.1 Résidence au Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_1)

- 4.2 Cesser d’exercer un emploi pour des raisons liées à la COVID-19
             [4.2 Cesser d’exercer un emploi pour des raisons liées à la COVID-19](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_2)

- 4.3 NAS de la série 900 et permis de travail
             [4.3 NAS de la série 900 et permis de travail](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_3)

- 4.4 Demandes des travailleurs frontaliers, inter-états et outre-mer
             [4.4 Demandes des travailleurs frontaliers, inter-états et outre-mer](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_4)

- 4.5 Inadmissibilité
             [4.5 Inadmissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_5)

- 4.6 Départ volontaire d’un emploi
             [4.6 Départ volontaire d’un emploi](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_6)

- 4.7 Rémunération provenant d’un emploi ou d’un travail indépendant (TI)
             [4.7 Rémunération provenant d’un emploi ou d’un travail indépendant (TI)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_7)

- 4.8 Exigence liée à la perte de rémunération — Application
             [4.8 Exigence liée à la perte de rémunération — Application](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_8)

         [Chapitre 4 : Admissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4)

- Chapitre 5 : Trop-payés (T-P) et défalcations

- 5.1 Erreur de la Commission
             [5.1 Erreur de la Commission](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_5_1)

         [Chapitre 5 : Trop-payés (T-P) et défalcations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_5)

- Chapitre 6 : Révision d’une demande pour la PU AE en vertu de la LAE 52

- 6.1 Politique de révision de la PU AE versée
             [6.1 Politique de révision de la PU AE versée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_6_1)

- 6.2 Réconciliation du paiement anticipé
             [6.2 Réconciliation du paiement anticipé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_6_2)

         [Chapitre 6 : Révision d’une demande pour la PU AE en vertu de la LAE 52](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_6)

- Chapitre 7 : Dispositions administratives
         [Chapitre 7 : Dispositions administratives](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_7)

- Chapitre 8 : Prestations d’emploi et mesures de soutien
         [Chapitre 8 : Prestations d’emploi et mesures de soutien](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_8)

**LAE VIII.4 – Prestation d’assurance-emploi d’urgence**

**Introduction**

Le 25 mars 2020, le gouvernement du Canada a mis en œuvre la Loi sur les mesures d’urgence visant la COVID-19 qui comprenait des mesures visant à fournir un soutien immédiat aux Canadiens, y compris la Prestation canadienne d’urgence (PCU). L’Agence du revenu du Canada (ARC) et Service Canada offraient la PCU parallèlement, en administrant 2 législations distinctes.
       [Loi sur les mesures d’urgence visant la COVID-19](https://laws-lois.justice.gc.ca/fra/LoisAnnuelles/2020_5/)

- Dans le cadre de la Loi sur les mesures d’urgence visant la COVID-19, le gouvernement du Canada a adopté la Loi sur la PCU qui verse un soutien du revenu aux Canadiens admissibles et qui est gérée par l’ARC.

- Afin d’offrir un soutien semblable aux travailleurs qui seraient généralement admissibles au programme d’AE, les modifications apportées à la LAE prévoyaient une nouvelle prestation d’AE d’urgence (PU AE) gérée par Service Canada.

Par souci de simplicité pour les personnes, ces 2 programmes ont été présentés au public comme une seule PCU. L’objectif était de faire en sorte que les Canadiens qui demandent un soutien du revenu par le biais de la Loi sur la PCU ou de la LAE soient traités de la même manière. Pour soutenir la mise en œuvre du programme, les prestataires ont été dirigés vers un portail en ligne unique qui expliquait les critères d’admissibilité à la PCU du gouvernement. Ce portail posait quelques questions précises et orientait les personnes vers le ministère approprié, l’ARC ou Service Canada, par l’intermédiaire duquel ils devaient demander un soutien du revenu. La PU AE par l’intermédiaire de Service Canada était le payeur privilégié pour toute personne qui autrement aurait rempli les conditions requises de l’AE.

Malgré ces efforts, certaines personnes ont fait une demande auprès du « mauvais » ministère (des personnes admissibles à l’AE ont fait une demande à l’ARC, ou des personnes non admissibles à l’AE ont fait une demande à Service Canada). Toutefois, afin de soutenir les Canadiens, le gouvernement a décidé que ces personnes ne seraient pas tenues de présenter une nouvelle demande par l’intermédiaire du « bon » ministère. Les ministères se chargeront plutôt de régler les détails directement, sans interrompre les versements aux clients, tant qu’un client ne reçoit pas plus de 28 semaines de prestations au total (conformément à la LAE 153.11 ).
       [LAE 153.11](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.11.html)

**Chapitre 1 : Notions de base**

Même si la LAE VIII.4 a été introduite en réaction à la pandémie mondiale de COVID-19 le 25 mars 2020, elle est entrée en vigueur rétroactivement le 15 mars 2020. Elle prévoyait l’administration de la PU AE qui a été offerte du 15 mars 2020 au 3 octobre 2020. Les prestations spéciales d’AE (autres que de maladie) ont continué à être administrées en vertu de la LAE I. Toutefois, les nouvelles demandes initiales de prestations d’AE régulières, de maladie et de maladie pour les travailleurs indépendants n’ont pas été établies pendant cette période selon les LAE 153.8(5) et (6) , car la LAE VIII.4 avait préséance sur la LAE I ( LAE 153.3(8) ). De plus, la LAE 153.1310 prévoit précisément que les demandes établies entre le 15 mars 2020 et la date de la signature de l’arrêté provisoire autorisant la LAE VIII.4 sont considérées comme des demandes pour la PU AE.
       [LAE 153.8(5) et (6)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.8.html) 
       [LAE 153.3(8)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.8.html)

Les autres dispositions de la LAE et du RAE s’appliquent seulement à la LAE VIII.4 si elles sont précisées . À noter :

- Le délai de carence (DC) ne s’applique pas à la PU AE.

- Il n’existe pas de dispositions liées à la disponibilité qui s’appliquent à la LAE VIII.4. Pour recevoir la PU AE, il n’est pas nécessaire qu’un client soit prêt et disposé à travailler, et capable de le faire. Cela dit, un client ne peut pas retarder son retour au travail (RAT) s’il n’y a pas d’obstacles à ce retour. Il est entendu qu’un client peut rester à la maison pour s’occuper de son ou ses enfants pendant cette période s’il est tenu de le faire.

- Dans de nombreuses situations, le motif de la cessation d’emploi sera lié à la pandémie de COVID-19. Les clients ne sont pas admissibles à la PU AE s’ils quittent leur emploi volontairement ( Guide la prestation d’AE d’urgence 4.5 ).
         [Guide la prestation d’AE d’urgence 4.5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_5)

- Les critères d’admissibilité à la PU AE n’empêchent pas une personne qui a été congédiée de percevoir cette prestation.

- Les clients ne sont pas tenus de présenter leur demande pour la PU AE dans les délais prescrits; par conséquent, les demandes d’antidate ne s’appliquent pas. Aucun client n’est autorisé à présenter une demande après le 2 décembre 2020.

- Une demande pour la PU AE ne peut pas être envisagée quand un client veut être exempté d’une violation, car il ne s’agit pas d’une demande initiale de prestations en vertu de la LAE I, VII.1 ou VIII. Par conséquent, elle ne peut pas être utilisée comme l’une des 2 demandes d’AE pouvant permettre l’exemption.

- Les déductions liées aux remboursements (cession de prestations [CDP]) ne peuvent être appliquées aux versements de la PU AE puisque cette prestation n’est pas cessible. Toutefois, les déductions liées aux accords d’ordonnance familiale (AOF) s’appliquent.

La LAE 153.10(2) permet aux clients de recevoir à la fois une prestation d’urgence du gouvernement du Canada et une aide financière liée à la COVID-19 d’un gouvernement provincial ou territorial pour la même période.
       [LAE 153.10(2)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.10.html)

La législation sur la PU AE (LAE VIII.4) utilise certaines délégations de pouvoir existantes dans la LAE. Des délégations de pouvoir supplémentaires ont été demandées pour remédier à la création de législation nouvelle ou adaptée dans les arrêtés provisoires. Les niveaux de décision en vigueur s’appliquent à la PU AE.

**Chapitre 2 : Définition de prestataire**

Le terme prestataire est défini dans la LAE 153.5(2) et comprend 4 catégories :
       [LAE 153.5(2)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.5.html)

- Ceux qui ont cessé de travailler en raison de la COVID-19;

- Ceux qui auraient eu une période de prestations (PP) établie pour les prestations régulières ou de maladie d’AE;

- Ceux qui ont épuisé une demande de prestations régulières d’AE et qui n’ont pas pu commencer à travailler en raison de la COVID-19;

- Ceux qui ont épuisé une demande de prestations de pêcheur d’AE et n’ont pas pu commencer à travailler en raison de la COVID-19.

Chaque catégorie de prestataires doit remplir des critères précis selon la LAE 153.9 pour être admissible à la PU AE. Les prestataires peuvent recevoir un paiement de 500 $ pour chaque semaine (jusqu’à 28 semaines) pendant laquelle ils continuent d’être admissibles à la PU AE. La LAE 153.10(3) confirme que le supplément familial (SF) s’applique également aux versements de la PU AE.
       [LAE 153.10(3)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.10.html)

**Chapitre 3 : Procédure de présentation de la demande**

La LAE 153.8(1) indique qu’un client doit présenter une demande pour la PU AE sous la forme et selon les modalités établies par la ministre toutes les 2 semaines. Même si la LAE VIII.4 n’inclut ni le concept d’une demande de prestations initiale ni celui de l’établissement d’une PP, la présentation d’une demande initiale dans AW fait partie de l’administration de la PU AE. Cela fournit à Service Canada les renseignements requis pour commencer les versements de la PU AE, puisque les déclarations du prestataire de 2 semaines servent de confirmation continue de l’admissibilité du client.
       [LAE 153.8(1)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.8.html)

Le client reçoit un taux de prestations hebdomadaire de 500 $ pour un maximum de 28 semaines et doit prouver qu’il remplit les critères d’admissibilité pour chaque période de 2 semaines pour laquelle il demande des prestations. Si le client est incapable de prouver son admissibilité pour une certaine période de 2 semaines, il n’est pas admissible à la PU AE au cours de cette période.

La PU AE peut être versée pour toute période de 2 semaines entre le 15 mars 2020 et le 3 octobre 2020. Puisqu’un client n’est pas tenu de présenter sa demande dans les délais prescrits, aucune demande d’antidate ne s’applique. Toutefois, en vertu de la LAE 153.8(2) , aucune demande ne peut être présentée après le 2 décembre 2020. Le client doit remplir tous les critères d’admissibilité pour la période de 2 semaines. Une inadmissibilité 31 - PU AE ne rencontre pas les conditions d’admissibilité (D31) a été créée pour les périodes d’inadmissibilité à la PU AE.
       [LAE 153.8(2)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.8.html)

La LAE 50 a été adaptée en vertu de la LAE 153.1302 pour s’appliquer à la LAE VIII.4 et autoriser une demande de renseignements supplémentaires quand il faut déterminer si un prestataire est admissible à la PU AE. Si un client omet de fournir ces renseignements, il est considéré comme inadmissible.
       [LAE 50](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/page-13.html) 
       [LAE 153.1302](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.1302.html)

La LAE 153.8(3) et (4) indiquent qu’un client et un employeur sont respectivement tenus de fournir tout renseignement requis lié à une demande pour la PU AE. Ceci autorise la Commission à demander, à un client ou un employeur, des renseignements supplémentaires liés à une demande pour la PU AE.

Quand une demande pour la PU AE est reçue, la Commission est responsable de déterminer si le client est admissible pour la période pour laquelle il présente une demande. La LAE 153.8(7) indique que la Commission doit s’assurer d’informer le client de la décision sur sa demande pour la PU AE. Elle confère également à la Commission le pouvoir de choisir la manière dont le client en est informé.
       [LAE 153.8(7)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.8.html)

**3.1 Forme et modalités alternatives pour présenter une demandepour la PU AE**

La LAE 153.8(1) autorise la ministre à déterminer la forme et les modalités en vertu desquelles une demande peut être établie. La forme et les modalités habituelles pour la PU AE consistaient à remplir des déclarations du prestataire de 2 semaines. Un client peut avoir fait des efforts raisonnables pour présenter une demande pour la PU AE selon la forme et les modalités habituelles (c.-à-d. une déclaration du prestataire de 2 semaines), mais il lui était impossible de le faire pour des raisons indépendantes de sa volonté. Par conséquent, une forme et des modalités alternatives pour présenter une demande pour la PU AE ont été autorisées pour accommoder des catégories précises de prestataires :

- Un client pour lequel un traitement manuel 71 - Cas soumis aux Services de l’intégrité (TM71) (arrêt de paiement) a été imposé dans sa demande et dont le code d’accès a été annulé en raison de soupçons d’une activité frauduleuse dans sa demande pour la PU AE;

- Un client qui a présenté une demande de révision liée à sa demande pour la PU AE avant le 2 décembre 2020, mais pour laquelle une décision n’a pas été rendue avant le 2 décembre 2020;

- Un client qui a subi des retards de traitement indépendants de sa volonté dans sa demande pour la PU AE.

L’utilisation de la forme et des modalités alternatives est rare et ne s’applique pas à la plupart des demandes pour la PU AE. Cette décision relève du Niveau 2, mais elle est seulement rendue par un groupe d’agents spécialement formés. La forme et les modalités alternatives sont seulement prises en considération pour une demande qui remplit les conditions établies pour l’une des catégories précises de prestataires

Si un agent découvre une demande à laquelle il estime que la forme et les modalités alternatives pourraient s’appliquer, il renvoie la demande au conseiller en expertise opérationnelle dans sa région pour un renvoi à la division de la politique opérationnelle de l’AE.

**Chapitre 4 : Admissibilité**

La LAE 153.9(1) énonce les critères d’admissibilité qui s’appliquent à chaque catégorie de prestataires.
       [153.9(1)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.9.html)

```text
| Définition de prestataire | Admissibilité |

| LAE 153.5(2) Pour l’application des LAE 153.6 à 153.13, la définition de prestataire la LAE 2(1) s’entend des personnes suivantes : [153.5(2)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.5.html) [LAE 2(1)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-2.html) - celles qui cessent d’exercer leur emploi — ou d’exécuter un travail pour leur compte — pour des raisons liées à la COVID-19; [153.5(2)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.5.html) [LAE 2(1)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-2.html) | 153.9 (1) Est admissible à la prestation d’urgence de l’AE le prestataire suivant : [153.9 (1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.9.html) - celui qui, à la fois : - réside au Canada, - est âgé d’au moins 15 ans, - a une rémunération assurable, pour l’année 2019 ou au cours des cinquante-deux semaines précédant la date à laquelle il présente une demande en vertu de l’article 153.8, qui s’élève à au moins cinq mille dollars, - cesse d’exercer son emploi — ou d’exécuter un travail pour son compte — pendant au moins sept jours consécutifs compris dans la période de deux semaines pour laquelle il demande la prestation, - n’a aucun revenu provenant d’un emploi qu’il exerce — ou d’un travail qu’il exécute pour son compte —, pour les jours consécutifs pendant lesquels il cesse d’exercer son emploi ou d’exécuter un travail pour son compte; [153.9 (1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.9.html) |

| - aurait pu faire établir une période de prestations ( LAE 7(2) ) le 15 mars 2020 ou après cette date en ce qui concerne l’une des prestations visées à l’alinéa 3(a) (prestations de maladie, prestations de maladie pour travailleurs autonomes et prestations régulières); [LAE 7(2)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/page-3.html) [LAE 7(2)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/page-3.html) | - celui visé à l’alinéa 153.5(2)(b) qui n’a aucun revenu provenant d’un emploi qu’il exerce — ou d’un travail qu’il exécute pour son compte —, pendant au moins sept jours consécutifs compris dans la période de deux semaines pour laquelle il demande la prestation; |

| - celles qui ne peuvent commencer à travailler pour des raisons liées à la COVID-19 et à qui, à un moment donné pendant la période commençant le 29 décembre 2019 et se terminant le 3 octobre 2020, a été versée ou devait être versée au moins l’une des prestations visées à l’alinéa (3)(b) [prestations régulières], si, pendant cette période, selon le cas : - la période de prestations établie à leur profit à l’égard de ces prestations s’est terminée, - toutes ces prestations leur ont été versées, - certaines de ces prestations ne peuvent leur être versées en raison du paragraphe 12(6); | - celui visé à l’alinéa 153.5(2)c) ou d) qui, à la fois : - réside au Canada, - est âgé d’au moins 15 ans, - a une rémunération assurable, pour l’année 2019 ou au cours des cinquante-deux semaines précédant la date à laquelle il présente une demande en vertu de l’article 153.8, qui s’élève à au moins cinq mille dollars, - n’a aucun revenu provenant d’un emploi qu’il exerce — ou d’un travail qu’il exécute pour son compte —, pendant au moins sept jours consécutifs compris dans la période de deux semaines pour laquelle il demande la prestation. |

| - celles qui ne peuvent commencer à travailler pour des raisons liées à la COVID-19 et à qui, à un moment donné pendant la période commençant le 29 décembre 2019 et se terminant le 3 octobre 2020, a été versée ou devait être versée au moins l’une des prestations visées à l’alinéa (3)(c) [prestations de pêcheur], si, pendant cette période, selon le cas : - la période de prestations établie à leur profit à l’égard de ces prestations s’est terminée, - toutes ces prestations leur ont été versées, - certaines de ces prestations ne peuvent leur être versées en raison du paragraphe 8(18) du Règlement sur l’AE (pêche) . [Règlement sur l’AE (pêche)](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-445/) [Règlement sur l’AE (pêche)](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-445/) | - celui visé à l’alinéa 153.5(2)(c) ou d) qui, à la fois : - réside au Canada, - est âgé d’au moins 15 ans, - a une rémunération assurable, pour l’année 2019 ou au cours des cinquante-deux semaines précédant la date à laquelle il présente une demande en vertu de l’article 153.8, qui s’élève à au moins cinq mille dollars, - n’a aucun revenu provenant d’un emploi qu’il exerce — ou d’un travail qu’il exécute pour son compte —, pendant au moins sept jours consécutifs compris dans la période de deux semaines pour laquelle il demande la prestation. |
```

Il est possible qu’un prestataire remplisse les critères pour plus d’une définition. Une fois que l’article de la LAE 153.5(2) à utiliser est déterminé, les critères d’admissibilité correspondants de la LAE 153.9(1) et, au besoin, de la LAE 153.9(4) sont ensuite considérés.

**Scénario 1**

- Période de la demande (déclaration) : du 5 au 18 avril 2020

- Le client est âgé de 14 ans et aura 15 ans le 15 avril 2020.

- Il a 418 heures assurables.

- Il a gagné 5 000 $ en 2019.

- Il réside au Canada.

- Il a cessé de travailler le 3 avril 2020 en raison de la COVID-19 (manque de travail).

- Il n’a aucune rémunération provenant d’un emploi depuis le 3 avril 2020.

- Il répond à la définition de prestataire en vertu de la LAE 153.5(2)a).

Puisque le client n’a pas assez d’heures pour être considéré comme un prestataire en vertu de la LAE 153.5(2)b), il est plutôt considéré comme un prestataire en vertu de la LAE 153.5(2)a). Le client n’est pas admissible à la semaine 1 (du 5 au 11 avril 2020) de sa période de demande de 2 semaines, car il ne remplit pas tous les critères d’admissibilité (il n’a pas 15 ans ou plus).

Le client est admissible à la semaine 2 (du 12 au 18 avril 2020) de sa période de demande de 2 semaines, car il remplit désormais les critères d’admissibilité (il a 15 ans au cours de cette semaine).

**Scénario 2**

- Période de la demande (déclaration) : du 15 mars au 28 mars 2020

- Le client est âgé de 14 ans.

- Il a 1 000 heures assurables.

- Il a gagné 7 000 $ en 2019.

- Il réside au Canada.

- Il a cessé de travailler le 13 mars 2020 en raison de la COVID-19 (manque de travail).

- Il n’a aucune rémunération d’emploi depuis le 13 mars 2020

- Il répond à la définition de prestataire en vertu de la LAE 153.5(2)b), car il aurait pu établir une PP à compter du 15 mars 2020 pour des prestations régulières.

Le client remplit les critères d’admissibilité en vertu de la LAE 153.9(1)b), car il n’a aucune rémunération provenant d’un emploi depuis le 13 mars 2020 et il remplit l’exigence de 7 jours sans rémunération pendant la période de 2 semaines de sa demande de prestations.

Dans ce scénario, le client n’était pas tenu de remplir l’exigence liée à l’âge, car il répondait à la définition de prestataire en vertu de la LAE 153.5(2)b) et remplissait le critère d’admissibilité en vertu de la LAE 153.9(1)b) qui n’a pas les mêmes critères d’admissibilité que les autres articles de la LAE.

Des prestations sont payables au client pour la période de 2 semaines pour laquelle il a présenté une demande.

**4.1 Résidence au Canada**

L’objectif est de permettre à une personne qui s’installe au Canada et qui y vit habituellement, même si ce n’est que pour une période limitée, de recevoir la PU AE. Par conséquent, contrairement aux prestations régulières d’AE, la PU AE est offerte à un client qui se trouve temporairement hors du Canada, si le Canada est son lieu habituel de résidence.

Aux fins de la PU AE, la définition de résidence au Canada doit être appliquée pour chaque période de 2 semaines pour laquelle le client demande la prestation. Un client peut être considéré comme résidant au Canada pendant la durée d’une demande pour la PU AE, mais pas d’une autre. Si les preuves pour déterminer si le client réside ou non au Canada sont équilibrées, le bénéfice du doute est accordé au client.

Ce n’est pas l’endroit où se trouve un client qui permet d’établir s’il réside au Canada. Généralement, l’attachement d’une personne à un pays est mesuré en évaluant les liens de résidence qu’elle a avec ce pays. Toutefois, pour déterminer si une personne réside au Canada, de nombreux facteurs doivent être pris en considération.

Une personne qui est temporairement hors du Canada peut toujours être considérée comme résidant au Canada tant qu’elle maintient des liens importants avec le Canada. De même, une personne peut être considérée comme résidant au Canada pendant la durée de son séjour au Canada même si elle maintient des liens importants à l’étranger, à condition qu’elle ait établi son domicile et ait vécu habituellement dans une partie quelconque du Canada pendant la période pour laquelle elle demande la PU AE.

Voici les considérations qui pourraient étayer la déclaration du client selon laquelle il réside au Canada pendant la durée de sa demande pour la PU AE :

- Le client possède ou loue un logement au Canada où il vit.

- Le client vit dans la maison familiale d’amis ou de parents.

- Le client vit dans un logement fourni par son employeur.

- Le client entretient une maison au Canada (exemple : services publics, assurance, déneigement, etc.).

- Le client a des effets personnels ou des meubles au Canada.

- Le client a une adresse postale ou un numéro de téléphone au Canada.

- Le client est couvert par un régime d’assurance maladie provincial.

- Le client possède un permis de conduire canadien ou un véhicule immatriculé au Canada.

- Le client paie l’impôt sur le revenu en tant que résident du Canada.

- Le client a des membres de sa famille immédiate au Canada.

- Le client travaille au Canada.

- Le client a un compte bancaire au Canada.

**Exemples**

- Des travailleurs étrangers temporaires (NAS de la série 900) qui ont travaillé au Canada, ont cessé de travailler et sont restés au Canada (admissibles).

- Des clients qui résident au Canada quand ils demandent la PU AE et qui quittent le Canada alors qu’ils remplissent des déclarations du prestataire (admissibles et ensuite non admissibles).

- Des clients qui ont une résidence principale au Canada et qui se trouvent hors Canada (admissibles).

**Scénario 1**

- Période de la demande (déclaration) : du 19 avril au 2 mai 2020.

- La cliente est âgée de 39 ans.

- Elle a 395 heures assurables.

- Elle a gagné 18 000 $ en 2019.

- Elle résidait au Canada jusqu’au 20 avril 2020. Elle a déménagé aux États-Unis le 21 avril 2020 pour rester avec sa famille, car elle ne peut pas payer son loyer alors qu’elle ne travaille pas.

- Elle a cessé de travailler le 20 mars 2020 en raison de la COVID-19 (manque de travail).

- Elle n’a eu aucune rémunération provenant d’un emploi depuis le 20 mars 2020.

- Elle répond à la définition de prestataire en vertu de la LAE 153.5(2)a).

Puisque la cliente n’a pas assez d’heures pour être considérée comme une prestataire en vertu de la LAE 153.5(2)b), elle est plutôt considérée comme une prestataire en vertu de la LAE 153.5(2)a). La cliente est admissible à la semaine 1 (19 au 25 avril 2020) de sa période de demande de 2 semaines, car elle remplit les critères d’admissibilité (résidait au Canada) pendant une partie de cette semaine et son admissibilité ne peut pas être déterminée sur une base quotidienne.

La cliente n’est pas admissible à la semaine 2 (26 avril au 2 mai 2020), car elle ne remplit pas les critères d’admissibilité (ne réside pas au Canada) pendant cette période et ne répond pas à la définition de prestataire d’aucune autre catégorie.

**Scénario 2**

- Période de la demande (déclaration) : du 10 au 22 mai 2020

- La cliente est âgée de 35 ans.

- Elle a 1 600 heures assurables.

- Elle a gagné 95 000 $ en 2019.

- Elle a résidé au Canada jusqu’au 13 mai 2020 inclusivement. Elle a déménagé à Londres, en Angleterre, le 14 mai 2020, pour y occuper un nouvel emploi dont le début a été repoussé en raison de la COVID-19.

- Elle a cessé de travailler le 13 mars 2020 en raison de la COVID-19 (manque de travail).

- Elle n’a pas de rémunération provenant d’un emploi depuis le 13 mars 2020.

- Elle répond à la définition de prestataire en vertu de la LAE 153.5(2)(a) et (b).

Pendant que la cliente vit au Canada, elle est admissible à la PU AE en vertu de 2 catégories de prestataires, soit les LAE 153.9(1)(a) et (b).

Quand la cliente déménage à Londres, en Angleterre, elle ne répond plus à la définition de prestataire selon la LAE 153.5(2)(a), car elle ne réside plus au Canada. Toutefois, elle continue de répondre à la définition de prestataire selon la LAE 153.5(2)(b), car elle aurait pu établir une demande de prestations régulières d’AE.

La cliente est admissible aux 2 semaines de sa période de demande de 2 semaines. Tant qu’elle continue à remplir les critères d’admissibilité lors de la présentation d’une demande de prestations, des prestations peuvent continuer à lui être versées, car les critères d’admissibilité selon la LAE 159.9(1)(b) ne requièrent pas qu’elle réside au Canada.

**4.2 Cesser d’exercer un emploi pour des raisons liées à la COVID-19**

Un client est considéré comme ayant cessé de travailler pour des raisons liées à la COVID-19 quand il n’est plus en mesure de travailler, ou de retourner au travail, à cause de la COVID-19. Un client qui a reçu des prestations de maternité, parentales, de compassion ou pour proches aidants et qui n’est plus en mesure de retourner au travail après la fin de ses prestations pour des raisons liées à la COVID-19 est considéré comme ayant cessé de travailler pour des raisons liées à la COVID-19.

**4.3 NAS de la série 900 et permis de travail**

Tout comme les citoyens canadiens et les résidents permanents qui demandent la PU AE, les titulaires d’un NAS de la série 900 doivent remplir les critères d’admissibilité conformément à chaque catégorie de prestataires définie dans la LAE 153.5(2). Chaque catégorie de prestataires doit disposer d’un NAS valide.

Comme les travailleurs étrangers temporaires et les étudiants étrangers sont souvent obligés de quitter le Canada à l’expiration de leur NAS ou de la période couverte par leur permis approprié, une preuve de permis supplémentaire ou d’autorisation de rester légalement au Canada peut être exigée pour prouver l’admissibilité. Il peut en être de même pour considérer la rémunération provenant de l’emploi requis comme étant assurable.

**4.4 Demandes des travailleurs frontaliers, inter-états et outre-mer**

Les clients qui demandent traditionnellement des prestations d’AE et qui sont des travailleurs frontaliers, inter-états et outre-mer peuvent avoir droit à la PU AE.

Un client qui réside aux États-Unis et qui se rend au Canada pour y travailler peut être admissible à la PU AE, s’il fait partie d’une catégorie de prestataires et s’il remplit les critères d’admissibilité correspondants.

Un client qui se rend au Canada pour travailler, mais qui réside aux États-Unis, peut répondre à la définition de prestataire en vertu de la LAE 153.5(2)b), car il peut avoir été en mesure d’établir une PP à compter du 15 mars 2020. Les critères d’admissibilité de la LAE 153.9(1)b) prévoient qu’un client n’ait aucune rémunération provenant d’un emploi ou d’un travail indépendant (TI) pendant au moins 7 jours consécutifs au cours de la période de 2 semaines pour laquelle il demande la prestation. Si le client est considéré comme admissible, on vérifiera, avant le versement, qu’il ne reçoit pas d’autres prestations, car celles-ci peuvent avoir une incidence sur la capacité du client à percevoir la PU AE.

**4.5 Inadmissibilité**

La LAE 153.9(2) explique qu’un client n’est pas admissible à la PU AE si, pour la même période :
       [LAE 153.9(2)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.9.html)

- il reçoit d’autres prestations d’AE;

- il reçoit des prestations en vertu du RQAP;

- il reçoit un paiement de soutien du revenu en application de la Loi sur la prestation canadienne d’urgence; ou

- il reçoit un paiement en application de la Loi sur la prestation canadienne d’urgence pour étudiants.

Les clients qui perçoivent plus d’une prestation pour la même période peuvent se retrouver avec un trop-payé (T-P) et être tenus de rembourser leurs prestations. Les détails des versements de la PCU sont disponibles dans ETI.

Conformément à la LAE 153.9(2.1) , quand une demande est convertie de la PU AE ou d’un programme de soutien du revenu de la Loi sur la prestation canadienne d’urgence à un autre genre de demande de prestation, le client n’est plus admissible aux prestations d’urgence. Cela empêche les clients d’alterner entre les prestations d’urgence et les autres prestations de l’AE.
       [LAE 153.9(2.1)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.9.html)

La LAE 153.121 confirme qu’une PP établie avant le 15 mars 2020 doit être terminée pour que la PU AE puisse être payée.
       [LAE 153.121](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.121.html)

La LAE 153.13 confirme aussi que, quand une PP est établie pour un client qui a reçu la PU AE, les semaines au cours desquelles le client a touché la PU AE ne comptent pas comme des semaines de prestations d’AE versées. Le client pourra recevoir l’intégralité de son admissibilité aux prestations d’AE tant qu’il continue à remplir tous les critères d’admissibilité à la prestation qu’il a demandée.
       [LAE 153.13](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.13.html)

**4.6 Départ volontaire d’un emploi**

La LAE 153.9(3) prévoit qu’un client qui quitte son emploi n’est pas admissible à la PU AE.
       [LAE 153.9(3)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.9.html)

Sur la base des similitudes entre la LAE VIII.4 et la LAE I, combinées à la jurisprudence qui existe sur le concept de « départ volontaire d’un emploi », il est raisonnable de conclure que la LAE 153.9(3) engloberait non seulement les salariés qui « quittent » leur emploi au sens strict du terme, mais aussi ceux qui ont refusé un emploi, ceux qui ont refusé de reprendre un emploi, ou encore ceux qui ont refusé de continuer à travailler tel qu’il est indiqué dans la LAE 29(b.1) .
       [LAE 29(b.1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-29.html)

Une fois qu’il a été établi que le client a quitté volontairement son emploi, la jurisprudence préconiserait que le verdict de départ volontaire tienne compte d’autres concepts de base tels que ceux du motif valable et de la seule solution raisonnable.

Un certain nombre de circonstances ont été définies et contribuent à la détermination d’un motif valable, y compris l’examen des solutions raisonnables :

- la situation qui a conduit au départ volontaire;

- si d’autres mesures ou solutions raisonnables qui auraient pu remédier à la situation existaient ou ont été utilisées;

- les raisons pour lesquelles le client n’a pas utilisé ce qui semble être des solutions raisonnables.

Lors de cette évaluation, le recueil de faits doit être effectué auprès de toutes les parties et, quand la prépondérance des probabilités est égale, le bénéfice du doute est accordé au client.

**Scénarios**

- Refus de reprendre l’emploi : Un client n’est pas admissible à la PU AE s’il refuse de reprendre son ancien emploi (y compris un TI) quand il est raisonnable de le faire et que l’employeur demande son retour. Afin de déterminer si le client a ou non un motif valable de refuser la demande de retour à son ancien emploi, plusieurs facteurs doivent être pris en considération, par exemple : Un prestataire dont le système immunitaire est affaibli, ou qui vit avec une personne dont le système immunitaire est affaibli, peut avoir un motif valable de refuser de retourner au travail. Quand un prestataire a peur de retourner au travail, mais que la crainte alléguée semble être davantage une perception qu’une réalité, le refus peut être sans motif valable. Il faudra examiner les circonstances entourant toute condition dangereuse, réelle ou perçue, ainsi que l’existence de précautions en matière de santé et de sécurité. Outre ces exemples, il peut y avoir d’autres situations liées à la COVID-19 dans lesquelles un prestataire peut refuser de retourner au travail; pour cette raison, chaque cas doit être examiné en fonction des circonstances individuelles du prestataire.

- tous les protocoles de santé et de sécurité recommandés par les responsables de la santé publique ont-ils été respectés sur le lieu de travail? Si non, le client a-t-il fait part de ses préoccupations à l’employeur?

- d’autres options ont-elles été envisagées et abordées avec l’employeur, comme le travail à domicile ou la possibilité d’un poste différent?

- des tentatives raisonnables ont-elles été faites pour trouver d’autres solutions de garde d’enfants si le service de garde d’enfants habituel n’est pas disponible? S’il y a de la place chez le service de garde d’enfants habituel, pourquoi le client a-t-il décidé d’y renoncer?

- y a-t-il des problèmes de santé qui doivent être pris en considération?

- Refus d’accepter une offre d’emploi raisonnable : Un client n’est pas admissible à la PU AE s’il refuse une offre d’emploi raisonnable alors qu’il peut travailler. Quand un emploi raisonnable a été refusé, la Commission doit se demander si le client avait un motif valable de le refuser. Afin de déterminer si le prestataire a ou non un motif valable, plusieurs facteurs doivent être pris en considération, tels que : Une certaine flexibilité peut être accordée pour déterminer ce qui constitue une offre d’emploi raisonnable en raison du climat économique actuel et du fait que les emplois adéquats peuvent être plus rares. Ce que l’on considère comme étant raisonnable variera d’un client à l’autre.

- la nature de la profession par rapport à la profession habituelle du client;

- les conditions de salaire et d’emploi;

- les heures de travail et la possibilité qu’elles entrent en conflit avec les obligations familiales;

- les préoccupations en matière de santé et de sécurité liées à la COVID-19;

- la distance de déplacement et le mode de transport;

- les problèmes de disponibilité liés à la prise en charge d’un enfant ou d’une personne à charge parce que leur établissement de soins est fermé ou qu’ils sont malades ou en quarantaine en raison de la COVID-19.

**4.7 Rémunération provenant d’un emploi ou d’un travail indépendant**

La détermination de la rémunération

Aux fins de la LAE VIII.4, les sommes sont considérées comme une rémunération quand 2 conditions sont remplies : (1) les sommes proviennent d’un emploi ou d’un TI et (2) les sommes ont été gagnées pendant la période pour laquelle la PU AE est versée. Les sommes versées pour un travail effectué avant la période pour laquelle les prestations sont demandées sont donc exclues.

Pour déterminer si un paiement précis constitue une rémunération aux fins de la PU AE, il est nécessaire d’obtenir tous les renseignements pertinents concernant la nature du paiement, son origine et son but.

Les éléments suivants doivent être pris en considération :

- Le paiement provient-il d’un emploi ou d’un TI?

- Quand la somme a-t-elle été gagnée? Est-ce pour la période en cours ou une période de travail antérieure?

- Qui effectue le paiement? S’il s’agit d’une personne autre que l’employeur ou, dans le cas d’un travailleur indépendant, sur la base d’un contrat, y a-t-il un lien direct avec l’emploi ou le travail effectué?

- Pourquoi le paiement est-il effectué? S’agit-il de compenser une perte de rémunération, comme une indemnité de départ?

La rémunération peut comprendre, entre autres, les éléments suivants :

- les salaires

- la rémunération d’entreprise

- les dividendes non admissibles

- les pourboires

- les commissions

- les primes

- la rémunération de jours fériés

- la paie de vacances (quand elle est versée en tant que salaire pendant une période de congé)

- les honoraires (par exemple, les montants nominaux versés aux bénévoles des services d’urgence)

- les redevances (par exemple, si elles ont été reçues en compensation de l’utilisation ou de la permission d’utiliser un droit d’auteur, un brevet, une marque, une formule ou un procédé secret qui provient du travail ou de l’invention de la personne concernée, telles que les redevances versées aux artistes)

- la rémunération non monétaire provenant d’un emploi (par exemple, pour le logement ou les services publics)

- les compléments de salaire payés par l’employeur (les régimes enregistrés de prestations supplémentaires de chômage [PSC] ne s’appliquent pas à la PU AE)

- les indemnités d’assurance-salaire (IAS) assurables

Sont notamment exclus de la rémunération :

- l’argent ou l’aide financière de tout genre lié à la COVID-19 fournie par la province ou le territoire du client, comme les allocations de secours;

- l’aide sociale;

- les indemnités de cessation d’emploi (y compris les indemnités de départ);

- les pensions;

- les prêts d’études;

- les bourses;

- les redevances provenant d’activités d’investissement (y compris les dividendes et les intérêts).

Bien que différent de son traitement habituel aux fins de l’assurance-emploi, afin d’éviter toute confusion pour les clients et pour s’aligner avec l’interprétation de ce qu’est une rémunération en ce qui a trait à l’application de la Loi sur la PCU, les prestations d’invalidité (y compris les indemnités pour accidents du travail [IAT] et les IAS non assurables) sont exclues de la rémunération lors de la détermination de l’admissibilité à la PU AE.
       [prestations d’invalidité](https://www.canada.ca/fr/services/prestations/ae/pcusc-application/questions.html#personnes-handicapees)

Prendre en considération la rémunération dans une demande pour la PU AE

Les critères d’admissibilité de la LAE 153.9(1) comprennent une perte de rémunération. Plus précisément, un client doit avoir cessé de travailler pour au moins 7 jours consécutifs dans la période de 2 semaines pour laquelle il demande des prestations et n’avoir aucune rémunération provenant d’un emploi ou d’un TI pour ces 7 jours. De plus, si un client a présenté une demande pour une période de 2 semaines et qu’il a reçu la PU AE, mais qu’il ne remplissait pas le critère lié à la perte de rémunération de la LAE 153.9(1), la LAE 153.9(4) s’applique alors pour déterminer si le client est admissible à la PU AE pour cette période de 2 semaines.

Dans un effort visant à éviter un T-P pour un client qui ne remplit pas le critère lié à la perte de rémunération, quand un client déclarait initialement un RAT ou une semaine entière de travail (SET), aucune PU AE n’était versée pour cette semaine.

**4.8 Exigence liée à la perte de rémunération – Application**

En vertu de la LAE 153.8(1) , l’admissibilité à la PU AE est déterminée pour des périodes de 2 semaines, peu importe l’ordre dans lequel les déclarations du prestataire ont été présentées.
       [LAE 153.8(1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.8.html)

En ce qui concerne plus précisément le travail et la rémunération, chaque période de 2 semaines est d’abord évaluée en vertu de la LAE 153.9(1) pour déterminer si le client :

- cesse de travailler, qu’il soit employé ou travailleur indépendant, pour au moins 7 jours consécutifs dans la période de 2 semaines pour laquelle il demande des prestations;

- n’a aucune rémunération provenant d’un travail ou d’un TI pour les jours consécutifs pendant lesquels il cesse de travailler.

L’interruption de 7 jours consécutifs peut avoir lieu à n’importe quel moment de la période de 14 jours examinée.

Si ces conditions sont remplies pour la période de 2 semaines examinée, aucune autre évaluation de la rémunération n’est requise et le client est admissible à la PU AE pour cette période.

Si le client ne remplit pas les conditions de la LAE 153.9(1), la LAE 153.9(4) s’applique. Si le client a travaillé ou a eu une rémunération pendant les 2 semaines de la période de 2 semaines examinée, sans interruption de 7 jours consécutifs sans travail ou rémunération, il faut déterminer si sa rémunération totalise 1 000 $ ou moins pendant une période de 4 semaines.

La LAE 153.9(4) mentionne précisément une période de 4 semaines dans laquelle la PU AE est versée . Cela signifie que le paiement de la PU AE a été émis au client et qu’il l’a reçu. Les semaines pour lesquelles le paiement anticipé s’appliquait (avec un code 65 - Montant forfaitaire (2000$) - Prestations d’urgence [D65]) ou a été réconcilié dans une décision antérieure (consulter 6.2 Réconciliation du paiement anticipé ) sont des semaines de la PU AE versée. Les semaines au cours desquelles le paiement a été émis et un T-P a été établi sont considérées comme des semaines de la PU AE versée si le client demeure inadmissible aux prestations pour cette semaine.
       [6.2 Réconciliation du paiement anticipé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_6_2)

Si la LAE 153.9(4) s’applique, la période de 4 semaines prise en considération comprend la période de 2 semaines examinée et les 2 semaines précédentes les plus proches pendant lesquelles la PU AE a été versée.

Exception :

Exception: Si une SET ou un RAT empêche le versement de la PU AE dans la période de 2 semaines examinée, cette semaine non versée est exclue de la période de 4 semaines et les 3 semaines précédentes les plus proches au cours desquelles la PU AE a été versée sont utilisées.

Exemple :

```text
| Semaine | PU AE versée | Période pour laquelle l’admissibilité est examinée | Période de 4 semaines en vertu de la LAE 153.9(4) |

| 15 mars 2020 s/c 2230 | 500 $ | | |

| 22 mars 2020 s/c 2231 | 500 $ | | 4 |

| 29 mars, 2020 s/c 2232 | 500 $ | | 3 |

| 5 avril 2020 s/c 2233 | 500 $ | | 2 |

| 12 avril 2020 s/c 2234 | 500 $ | Semaine 1 de la période de 2 semaines examinée | 1 |

| 19 avril 2020 s/c 2235 | 0 $ | Semaine 2 de la période de 2 semaines examinée | |
```

Puisqu’aucune PU AE n’a été versée dans la semaine du 19 avril 2020 (s/c 2235), cette semaine n’est pas considérée dans la période de 4 semaines.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0276.dita) 

Dans la situation pour laquelle une demande ne contient qu’une semaine seulement (généralement la dernière semaine de la PU AE versée), cette seule semaine est considérée en utilisant la même méthode qu’une période de 2 semaines. Si cette seule semaine n’a pas 7 jours sans travail et sans rémunération, la LAE 153.9(4) s’applique pour déterminer si la rémunération de cette semaine et les 3 semaines précédentes les plus proches dans lesquelles la PU AE a été versée dépasse 1 000 $.

Si le client n’a pas été payé pour des semaines chronologiques consécutives qui précèdent immédiatement, celles-ci sont sautées, et les semaines payées précédentes sont utilisées. Il est possible que certaines semaines soient utilisées dans plus d’une période de 4 semaines (c.-à-d. qu’il peut y avoir des chevauchements).

Déterminer si la rémunération dépasse 1 000 $ dans la période de 4 semaines

Si la rémunération dépasse 1 000 $ dans la période de 4 semaines, le client est inadmissible pour la période de 2 semaines examinée et un T-P s’applique pour cette période. Aucun T-P n’est créé pour les 2 autres semaines utilisées dans la période de 4 semaines, car elles seraient soumises à l’évaluation de la période de 2 semaines dans laquelle elles tombent.

Si la rémunération est de 1 000 $ ou moins, on considère que le client remplit le critère lié à la perte de rémunération de la LAE 153.9(1) et qu’il est admissible à la PU AE versée pour la période de 2 semaines examinée .
       [LAE 153.9(1)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.9.html)

Les scénarios ci-dessous montrent l’application des LAE 153.9(1) et (4).

Scénario 1

Dans ce scénario, le client a reçu la PU AE pour toutes les semaines tout en déclarant une rémunération dans certaines semaines.

Le client est admissible à toutes les semaines de prestations d’AE versées.

```text
| Semaine | PU AE versée | Rémunération | Admissible à la PU AE | Période de 4 semaines |

| 15 mars 2020 s/c 2230 | 500 $ | 0 $ | Oui | |

| 22 mars 2020 s/c 2231 | 500 $ | 0 $ | Oui | |

| Le client est admissible du 15 mars 2020 au 28 mars 2020 en vertu de la LAE 153.9(1), car il a cessé de travailler pour 7 jours consécutifs dans la période de 2 semaines. |

| 29 mars 2020 s/c 2232 | 500 $ | 200 $ | Oui | 4 |

| 5 avril 2020 s/c 2233 | 500 $ | 0 $ | Oui | 3 |

| Le client est admissible du 29 mars 2020 au 11 avril 2020 en vertu de la LAE 153.9(1), car il a cessé de travailler pour 7 jours consécutifs dans la période de 2 semaines. |

| 12 avril 2020 s/c 2234 | 500 $ | 100 $ | Oui | 2 |

| 19 avril 2020 s/c 2235 | 500 $ | 699 $ | Oui | 1 |

| Le client est inadmissible en vertu de la LAE 153.9(1), car il n’a pas cessé de travailler pour 7 jours consécutifs dans la période de 2 semaines. Il est admissible en vertu de la LAE 153.9(4), car sa rémunération dans la période de 4 semaines (du 29 mars 2020 au 25 avril 2020) est inférieure à 1 000 $. |
```

Scénario 2

Dans ce scénario, le client a reçu la PU AE tout en déclarant une rémunération dans certaines semaines. Le client n’a initialement pas été payé au cours d’une semaine dans laquelle il a déclaré une SET, mais il est admissible aux prestations en vertu de la LAE 153.9(1). Puisque la semaine de la SET n’a pas été versée initialement, elle n’est pas considérée dans le calcul de la période de 4 semaines, et la rémunération pendant cette semaine n’est pas considérée pour déterminer si l’exigence liée à la perte de rémunération est remplie.

```text
| Semaine | PU AE versée | Rémunération | Admissible à la PU AE | Période de 4 semaines |

| 19 avril 2020 s/c 2235 | 500 $ | 0 $ | Oui | |

| 26 avril 2020 s/c 2236 | 500 $ | 200 $ | Oui | 4 |

| Le client est admissible en vertu de la LAE 153.9(1), car il a cessé de travailler pour 7 jours consécutifs dans la période de 2 semaines. |

| 3 mai 2020 s/c 2237 | 500 $ | 0 $ | Oui | 3 |

| 10 mai 2020 s/c 2238 | 0 $ | SET (1 200 $) | Oui | |

| La s/c 2238 n’a initialement pas été versée, mais le client est admissible en vertu de la LAE 153.9(1), car il a 7 jours consécutifs sans rémunération dans la période de 2 semaines examinée. Cette semaine ne sera pas considérée dans la période de 4 semaines, car la PU AE n’a pas été versée initialement. La PUAE due pour cette période pourrait être utilisée pour réconcilier la paiement anticipé. Si le client a expressément demandé un réexamen en vertu de s. 112 de LAE pour la SET, le paiement du pourait être émis à titre de paiement au client s’il n’y a pas de dette impayée. |

| 17 mai 2020 s/c 2239 | 500 $ | 400 $ | Oui | 2 |

| 24 mai 2020 s/c 2240 | 500 $ | 300 $ | Oui | 1 |

| Le client est inadmissible en vertu de la LAE 153.9(1), car il n’a pas 7 jours consécutifs sans travail dans la période de 2 semaines. Il est admissible en vertu de la LAE 153.9(4), car sa rémunération dans la période de 4 semaines (les s/c 2240, 2239, 2237 et 2236) est inférieure à 1 000 $. |
```

Scénario 3

Dans ce scénario, le client a reçu la PU AE tout en déclarant une rémunération dans certaines semaines. Le client n’a pas été payé pendant certaines semaines dans lesquelles une SET a été déclarée.

Le client n’est pas admissible à la PU AE reçue dans la période du 17 mai 2020 au 30 mai 2020, car sa rémunération dans la période de 4 semaines examinée pour déterminer son admissibilité pour ces 2 semaines dépasse 1 000 $.

```text
| Semaine | PU AE versée | Rémunération | Admissible à la PU AE | Période de 4 semaines |

| 19 avril 2020 s/c 2235 | 500 $ | 0 $ | Oui | 4 |

| 26 avril 2020 s/c 2236 | 500 $ | 400 $ | Oui | 3 |

| Le prestataire est admissible en vertu de la LAE 153.9(1), car il a cessé de travailler pour 7 jours consécutifs dans la période de 2 semaines. |

| 3 mai 2020 s/c 2237 | 0 $ | SET | Non | |

| 10 mai 2020 s/c 2238 | 0 $ | SET | Non | |

| Le prestataire est inadmissible en vertu de la LAE 153.9(1). La LAE 153.9(4) est considérée, mais elle ne s’applique pas, car aucune PU AE n’a été versée au cours de cette période de 2 semaines. Puisque la PU AE n’a pas été versée au client, ces semaines ne peuvent pas être comptées dans la période de 4 semaines lors de l’examen des semaines de la PU AE versées subséquemment. |

| 17 mai 2020 s/c 2239 | 500 $ | 400 $ | Non | 2 |

| 24 mai 2020 s/c 2240 | 500 $ | 300 $ | Non | 1 |

| Le client est inadmissible pour cette période de 2 semaines seulement. En vertu de la LAE 153.9(1), il n’a pas 7 jours consécutifs de travail et rémunération dans cette période de 2 semaines. Il est inadmissible en vertu de la LAE 153.9(4), car sa rémunération dans la période de 4 semaines (les s/c 2240, 2239, 2236 et 2235) dépasse 1 000 $. |
```

Scénario 4

Dans ce scénario, le client a reçu la PU AE tout en déclarant une rémunération dans certaines semaines. Le scénario montre les périodes de 4 semaines qui se chevauchent. Le client est inadmissible en vertu de la LAE 153.9(4) pour une seule des périodes de 2 semaines examinées.

Le client est admissible dans la période du 19 avril 2020 au 2 mai 2020, car sa rémunération dans la période de 4 semaines prise en considération est inférieure à 1 000 $. Toutefois, le client est inadmissible dans la période du 3 mai 2020 au 16 mai 2020, car sa rémunération dans la période de 4 semaines pour cette demande dépasse 1 000 $.

```text
| Semaine | PU AE versée | Rémunération | Admissible à la PU AE | Première période de 4 semaines | Deuxième période de 4 semaines |

| 5 avril 2020 s/c 2233 | 500 $ | 200 $ | Oui | 4 | |

| 12 avril 2020 s/c 2234 | 500 $ | 0 $ | Oui | 3 | |

| Le client est admissible en vertu de la LAE 153.9(1), car il a cessé de travailler pour 7 jours consécutifs dans la période de 2 semaines. |

| 19 avril 2020 s/c 2235 | 500 $ | 100 $ | Oui | 2 | 4 |

| 26 avril 2020 s/c 2236 | 500 $ | 699 $ | Oui | 1 | 3 |

| En vertu de la LAE 153.9(1), le client n’a pas 7 jours consécutifs sans travail et rémunération dans cette période de 2 semaines. Il est admissible en vertu de la LAE 153.9(4), car sa rémunération dans la période de 4 semaines (s/c 2236, 2235, 2234 et 2233) est inférieure à 1 000 $. |

| 3 mai 2020 s/c 2237 | 500 $ | 999 $ | Non | | 2 |

| 10 mai 2020 s/c 2238 | 500 $ | 999 $ | Non | | 1 |

| Le prestataire est inadmissible pour cette période de 2 semaines. En vertu de la LAE 153.9(1), il n’a pas 7 jours consécutifs sans travail et rémunération dans la période de 2 semaines. Il est inadmissible en vertu de la LAE 153.9(4), car sa rémunération dans la période de 4 semaines (s/c 2238, 2237, 2236 et 2235) dépasse 1 000 $. |
```

Scénario 5

Dans ce scénario, le client a reçu la PU AE tout en déclarant une rémunération dans certaines semaines. Le scénario montre les périodes de 4 semaines qui se chevauchent. Le client est admissible en vertu de la LAE 153.9(4) pour 2 périodes de 2 semaines différentes.

Le client est admissible dans la période du 24 mai au 6 juin 2020, car sa rémunération dans la période de 4 semaines de cette demande est inférieure à 1 000 $. Il est aussi admissible dans la période de la s/c 2242 à la s/c 2243, car sa rémunération dans la période de 4 semaines pour cette demande est inférieure à 1 000 $.

```text
| Semaine | PU AE versée | Rémunération | Admissible à la PU AE | Première période de 4 semaines | Deuxième période de 4 semaines |

| 10 mai 2020 s/c 2238 | 500 $ | 200 $ | Oui | 4 | |

| 17 mai 2020 s/c 2239 | 500 $ | 0 $ | Oui | 3 | |

| Le prestataire est admissible en vertu de la LAE 153.9(1), car il a cessé de travailler pour 7 jours consécutifs dans la période de 2 semaines. |

| 24 mai 2020 s/c 2240 | 500 $ | 100 $ | Oui | 2 | 4 |

| 31 mai 2020 s/c 2241 | 500 $ | 200 $ | Oui | 1 | 3 |

| Le prestataire est inadmissible en vertu de la LAE 153.9(1), car il n’a pas 7 jours consécutifs sans travail et rémunération dans la période de 2 semaines. Il est admissible en vertu de la LAE 153.9(4), car sa rémunération dans la période de 4 semaines (s/c 2241, 2240, 2239 et 2238) est inférieure à 1 000 $. |

| 7 juin 2020 s/c 2242 | 500 $ | 100 $ | Oui | | 2 |

| 14 juin 2020 s/c 2243 | 500 $ | 200 $ | Oui | | 1 |

| Le prestataire est inadmissible en vertu de la LAE 153.9(1), car il n’a pas 7 jours consécutifs sans travail et rémunération dans la période de 2 semaines. Il est admissible en vertu de la LAE 153.9(4), car sa rémunération dans la période de 4 semaines (s/c 2243, 2242, 2241 et 2240) est inférieure à 1 000 $. |
```

Scénario 6

Dans ce scénario, il y a une interruption des déclarations du prestataire en raison d’un renouvellement. Le scénario montre comment la LAE 153.9(4) s’applique quand il y a une période d’une semaine au cours de laquelle un client cesse de demander la PU AE, ainsi que comment la LAE 153.9(4) s’applique quand il y a une interruption entre périodes de demande.

```text
| Semaine | PU AE versée | Rémunération | Admissible à la PU AE payée | Première période de 4 semaines | Deuxième période de 4 semaines |

| 15 mars 2020 s/c 2230 | 500 $ | 0 $ | Oui | | |

| 22 mars 2020 s/c 2231 | 500 $ | 200 $ | Oui | 4 | |

| Le client est admissible en vertu de la LAE 153.9(1), car il a cessé de travailler pour 7 jours consécutifs dans la période de 2 semaines. |

| 29 mars 2020 s/c 2232 | 500 $ | 0 $ | Oui | 3 | |

| 5 avril 2020 s/c 2233 | 500 $ | 500 $ | Oui | 2 | 4 |

| Le client est admissible en vertu de la LAE 153.9(1), car il a cessé de travailler pour 7 jours consécutifs dans la période de 2 semaines. |

| 12 avril 2020 s/c 2234 | 500 $ | 500 $ | Non | 1 | 3 |

| Il y a une interruption des déclarations du prestataire. La s/c 2234 est considérée comme une seule semaine, plutôt que comme une période de 2 semaines. Le client est inadmissible pour cette semaine en vertu de la LAE 153.9(1), car il n’a pas 7 jours consécutifs sans travail et rémunération. Le client est inadmissible pour la s/c 2234 en vertu de la LAE 153.9(4), car sa rémunération dans la période de 4 semaines dépasse 1 000 $. |

| 31 mai 2020 s/c 2241 | 500 $ | 100 $ | Non | | 2 |

| 7 juin 2020 s/c 2242 | 500 $ | 100 $ | Non | | 1 |

| Les s/c 2241 et 2242 sont considérées comme une période de 2 semaines suivant une interruption des déclarations du prestataire. Le client est inadmissible en vertu de la LAE 153.9(1), car il n’a pas 7 jours consécutifs sans travail dans la période de 2 semaines. Il est inadmissible en vertu de la LAE 153.9(4), car sa rémunération dans la période de 4 semaines dépasse 1 000 $. |
```

**Chapitre 5 : Trop-payés et défalcations**

Les LAE 43, 44 et 47 s’appliquent à la PU AE. La LAE 44 a été adaptée en vertu de la LAE 153.1301 et la LAE 43 a été adaptée selon la LAE 153.1306 . Par conséquent, un client est tenu de rembourser, sans délai, tout montant de la PU AE auquel il n’était pas admissible.
       [LAE 43, 44](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-43.html) 
       [47](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-47.html) 
       [153.1301](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.1301.html) 
       [153.1306](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.1306.html)

La LAE 153.1306(1) confère à la Commission le pouvoir de défalquer les T-P de la PU AE si :
       [153.1306(1)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.1306.html)

- la somme ne dépasse pas 100 $;

- le débiteur est décédé;

- le débiteur est un failli libéré;

- le débiteur est un failli non libéré à l’égard duquel le dernier dividende a été payé et le syndic a été libéré;

- le versement excédentaire ne résulte pas d’une erreur du débiteur ni d’une déclaration fausse ou trompeuse de celui-ci, qu’il ait ou non su que la déclaration était fausse ou trompeuse, mais découle :

- d’une décision rétrospective rendue en vertu de la partie IV, ou

- de l’octroi par la Commission d’un montant hebdomadaire de prestation d’AE d’urgence supérieur au montant visé au paragraphe 153.10(1); ou

- la Commission estime, compte tenu des circonstances, que :

- la somme est irrécouvrable,

- le remboursement de la somme imposerait au débiteur des difficultés financières excessives, ou

- les frais administratifs de recouvrement de la somme seraient vraisemblablement égaux ou supérieurs à la somme à recouvrer.

De plus, en vertu de la LAE 153.1306(2) , la portion du montant dû selon la LAE 47 et lié à la PU AE reçue avant que la Commission informe le débiteur du T-P peut être défalqué par la Commission si :
       [153.1306(2)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.1306.html)

- le versement excédentaire ne résulte pas d’une erreur du débiteur ni d’une déclaration fausse ou trompeuse de celui-ci, qu’il ait ou non su que la déclaration était fausse ou trompeuse;

- le T-P est attribuable à l’un des facteurs suivants :

- un retard ou une erreur de la part de la Commission dans le traitement d’une demande pour la PU AE,

- des mesures de contrôle rétrospectives ou un examen rétrospectif entrepris par la Commission,

- une erreur dans le relevé d’emploi établi par l’employeur,

- une erreur dans le calcul, par l’employeur, de la rémunération assurable du débiteur, ou

- le fait d’avoir assuré par erreur l’emploi ou une autre activité du débiteur.

Contrairement au RAE 56(2), la LAE 153.1306(2) ne comprend pas l’exigence que 12 mois doivent s’écouler entre le moment auquel les prestations sont reçues et le moment où la Commission avise le client du T-P.

Service Canada détient le pouvoir délégué pour les défalcations en vertu des LAE 153.1306(1)e) et 153.1306(2). Pour les demandes de défalcation en vertu des LAE 153.1306(1)a) à d) et f), un client ou son représentant légal peut communiquer avec l’ARC pour demander qu’un T-P soit considéré pour la défalcation. L’ARC effectue une évaluation financière de la situation du débiteur, puis recommande si le T-P devrait être défalqué ou non à la Direction générale du dirigeant principal des finances (DGDPF), qui détient le pouvoir délégué pour ces articles.

Il convient également de noter que, si un employeur avait conclu un accord de Travail partagé (TP) et qu’un client participant à cet accord recevait la PU AE, mais que la Commission a continué à verser la PU AE après le début de l’accord de TP, tout T-P entraîné une fois les corrections requises effectuées dans la demande doit être défalqué. Ceci s’explique par le fait que la Commission, en tant que partie à l’accord de TP, était au courant de l’accord, mais qu’il y a eu un retard dans le traitement de ces renseignements par les systèmes de l’AE.

De plus, pour les clients dont la demande de prestations d’AE a été établie le 15 mars 2020 ou après, mais qui sont passés par la suite à la PU AE à la date de la signature des ordonnances provisoires autorisant la LAE VIII.4, tout taux de prestation versé au-delà de 500 $ par semaine est défalqué conformément à la LAE 153.1310c)(ii).

Selon la LAE 153.1307 qui adapte la LAE 112.1, une décision rendue en vertu de la LAE 153.1306 ne peut pas être révisée en vertu de la LAE 112 .
       [LAE 153.1307](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.1307.html) 
       [LAE 112](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-112.html)

**5.1 Erreur de la Commission**

Une erreur de la Commission se produit quand la Commission dispose de tous les renseignements pertinents requis pour rendre une décision, mais que la décision finale n’est pas soutenue par les renseignements. L’erreur peut se produire lors du processus décisionnel ou quand une décision n’est pas saisie dans le système informatique.

Un exemple d’erreur de la Commission serait de continuer à verser la PU AE à un client participant à un accord de TP. Ceci serait considéré comme une erreur de la Commission, car tous les renseignements requis sont disponibles pour la Commission. Toutefois, les versements de la PU AE ont continué plutôt que des prestations de TP.

À l’inverse, le versement de la PU AE à un client qui a indiqué son âge lors de la présentation de sa demande initiale ne constitue pas une erreur de la Commission. Au moment de la demande, la Commission ne sait pas à quelle catégorie de prestataire le prestataire peut être admissible. Un prestataire admissible en vertu de la LAE 153.5(2)a), c) ou d) doit être âgé d’au moins 15 ans, alors qu’il n’y a aucun critère d’âge pour les prestataires en vertu de la LAE 153.5(2)b).

Le client qui remplit une déclaration du prestataire de 2 semaines indiquant qu’il a dépassé le seuil de 1 000 $ pourrait être considéré comme sachant qu’il n’était pas admissible à la PU AE selon l’application initiale de la LAE 153.9(4). De même, le versement de la PU AE alors que le client a déclaré une rémunération dans ses déclarations du prestataire ne constitue pas une erreur de la Commission.

Si une erreur de la Commission a entraîné une décision contraire à la structure de la LAE, la décision doit être corrigée rétroactivement et un T-P doit être établi. L’exigence de répondre à la définition de prestataire selon la LAE 153.5 et les critères d’admissibilité connexes décrits dans la LAE 153.9 sont considérés comme des questions liées à la structure de la LAE.

**Chapitre 6 : Révision d’une demande pour la PU AE en vertu de la LAE 52**

La LAE 52 s’applique à la PU AE et confère à la Commission le pouvoir de réviser une demande de prestations afin de se pencher sur l’admissibilité d’un client et sur le risque de moins-payés (M-P) et de T-P des prestations.
       [LAE 52](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-52.html)

Le processus de révision comprend 4 opérations distinctes qui doivent être réalisées dans les délais établis par la LAE 52. Si l’une des 4 opérations ne peut pas être achevée dans ces délais, la Commission ne peut pas réexaminer la demande. Ces 4 opérations sont les suivantes :

- décider d’exercer ou non son pouvoir discrétionnaire en matière de révision (c.-à-d. si les renseignements présentés justifient une révision; si la révision entraîne un T-P ou un M-P; si elle dispose de suffisamment de temps pour effectuer le travail);

- rendre une nouvelle décision;

- calculer le montant à recouvrer ou à payer; et

- informer le client de la décision.

**6.1 Politique de révision de la PU AE versée**

**6.1.1 Introduction**

La présente politique vise à préciser les cas dans lesquelles une demande pour la PU AE ou une décision rendue sur la demande peut être révisée tout en restant cohérente et équitable.

**6.1.2 Pouvoir législatif**

La révision est le moyen par lequel la LAE tient compte du fait qu’il peut être nécessaire de modifier ou de corriger une demande pour la PU AE. La révision est effectuée pour s’assurer que les clients reçoivent les prestations auxquelles ils étaient admissibles.

La LAE 153.6(1) incorpore par renvoi la LAE 52 et confère ainsi à la Commission le pouvoir de réviser une demande pour la PU AE. Alors que les clients de l’AE, en vertu de la LAE I, doivent remplir les conditions requises pour recevoir des prestations et y être admissibles, les clients de la PU AE, en vertu de la LAE VIII.4, doivent être admissibles à la prestation. La LAE 153.1303 modifie les LAE 52(2) et (4) pour correspondre au concept d’admissibilité.

**6.1.3 Quand la révision doit avoir lieu**

Considérations liées à l’admissibilité

Les personnes doivent remplir les critères d’admissibilité propres à la catégorie de prestataires qui s’applique quand elles demandent des prestations. Ce ne sont pas tous les critères d’admissibilité qui s’appliquent à toutes les catégories de prestataires. Plus de renseignements sur les exigences qui s’appliquent à chaque catégorie de prestataires ainsi que sur les critères d’inadmissibilité figurent au Guide de la prestation d’AE d’urgence 4 .
       [Guide de la prestation d’AE d’urgence 4](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4)

Une demande pour la PU AE pourrait être révisée si l’un des critères d’admissibilité qui s’appliquent n’a pas été rempli. Ce serait semblable à la notion de contraire à la structure de la LAE qui se produit quand un élément nécessaire à l’établissement de la demande d’AE et au versement des prestations est manquant.

Par exemple, une personne appartenant à la catégorie de prestataires en vertu de la LAE 153.5(2)a), c) ou d) doit être âgée d’au moins 15 ans. Si le client n’a pas rempli l’exigence liée à l’âge, ces demandes peuvent être révisées et un T-P établi. En revanche, un client appartenant à la catégorie de prestataires en vertu de la LAE 153.5(2)b) n’est pas tenu de remplir une exigence précise liée à l’âge, et aucune révision ne s’applique à cette demande selon ce critère d’admissibilité.

Considérations liées à l’inadmissibilité

Un client qui a reçu des prestations d’AE, des prestations du Régime québécois d’assurance parentale, la Prestation canadienne d’urgence ou la Prestation canadienne d’urgence pour les étudiants n’est pas admissible à la PU AE pour la même période. Si d’autres prestations étaient versées pour la même période, la demande pour la PU AE pourrait être révisée et le T-P qui s’applique établi. Plus de renseignements sur les critères d’inadmissibilité figurent au Guide de la prestation d’AE d’urgence 4.5 .
       [Guide de la prestation d’AE d’urgence 4.5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_5)

En vertu de la LAE 153.9(1)a) , un client n’est pas admissible à la PU AE s’il quitte son emploi, refuse de reprendre un emploi ou refuse un emploi sans motif valable. Quand le client a quitté son emploi sans motif valable, la demande pour la PU AE pourrait être révisée puisqu’il ne remplit plus cette exigence d’admissibilité. De même, un client recevant la prestation d’AE d’urgence qui refuse d’accepter un travail ou d’y retourner sans motif valable pourrait voir sa demande révisée et un T-P potentiel établi. Le Guide de la prestation d’AE d’urgence 4.6 définit ce qui peut constituer un motif valable en ce qui concerne la PU AE.
       [LAE 153.9(1)a)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.9.html) 
       [Guide de la prestation d’AE d’urgence 4.6](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_6)

Conformément à la LAE 153.9(4), les clients ne sont pas admissibles à la PU AE quand ils reçoivent une rémunération supérieure à 1 000 $ sur une période de 4 semaines. Le Guide de la prestation d’AE d’urgence 4.7 expose la façon dont les périodes de 4 semaines sont déterminées et ce qui est considéré comme une rémunération. Un T-P pourrait être établi si les clients ont reçu la PU AE alors qu’ils n’y étaient pas admissibles en raison de leur rémunération.
       [Guide de la prestation d’AE d’urgence 4.7](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_4_7)

**6.1.4 Moins-payés (M-P)**

Si la Commission a refusé des prestations qui sont maintenant considérées comme payables, elle doit calculer le montant du M-P, informer le client du résultat de la révision et lui remettre le montant dû.

**6.1.5 Délai de révision — 36 mois ou 72 mois**

La LAE 52(1) indique que la Commission peut réviser une demande de prestations dans les 36 mois suivant le versement des prestations ou le moment où elles auraient été payables. Toutefois, le délai de révision peut être prolongé à 72 mois si la Commission décide qu’une déclaration ou une représentation fausse ou trompeuse a été faite en lien avec la demande.

Paiement anticipé

La date à laquelle le paiement anticipé a été payé est utilisée pour déterminer le délai de révision de 36 mois quand il n’y a aucune semaine à laquelle le paiement anticipé s’appliquait. Quand une déclaration du prestataire a été traitée avec un code D65, appliquant ainsi le paiement anticipé à des semaines précises, ces semaines sont considérées comme celles dans lesquelles des prestations sont payables et elles sont utilisées pour déterminer le délai de révision (pour plus de renseignements sur le paiement anticipé, consulter le Guide de la prestation d’AE d’urgence 6.2 ).
       [Guide de la prestation d’AE d’urgence 6.2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/generic/ei_erb_digest#ch_6_2)

**6.1.6 Déclaration fausse ou trompeuse**

Une fausse déclaration est faite quand tout renseignement présenté en lien avec une demande est faux, peu importe l’intention. La LAE VIII.4 ne prévoit pas de pénalités ou d’acte délictueux de fausses déclarations dans le cadre d’une demande pour la PU AE. Ainsi, aucun acte délictueux ou pénalité ne peut être imposé. L’objectif de déterminer si une fausse déclaration a été faite dans le cadre d’une demande pour la PU AE est strictement de s’assurer que le délai de révision appropriée est utilisé. Il s’agit d’une décision discrétionnaire, et l’agent doit remplir un rapport de décision (RD) pour appuyer cette décision.

Les clients sont tenus de savoir ce qu’ils demandent et s’ils remplissent les critères d’admissibilité. Certains clients ont demandé la PU AE par l’intermédiaire de Service Canada, tandis que d’autres l’ont demandée par l’intermédiaire de l’ARC. Le gouvernement a décidé que les prestations doivent être versées le plus rapidement possible et que les renseignements fournis pour les demandes doivent être validés par la suite. Depuis le 1er avril 2020, des renseignements et les critères d’admissibilité sont disponibles au Canada.ca aux Canadiens sur la Prestation canadienne d’urgence (PCU), aussi appelée PU AE quand le client la reçoit de Service Canada. À partir du 25 mai 2020, SDI a aussi été mis à jour avec une page Attestation où le client de la PU AE doit confirmer qu’il remplit les critères d’admissibilité avant de remplir et de présenter ses déclarations du prestataire de 2 semaines en ligne pour les demandes pour la PU AE.
       [Canada.ca](https://www.canada.ca/fr.html)

Les clients ont attesté dans chaque déclaration du prestataire de 2 semaines (demande) qu’ils étaient admissibles aux prestations et, par conséquent, des prestations leur ont été versées. Les demandes de clients qui ont reçu des prestations quand ils étaient inadmissibles ou qui ont fourni de faux renseignements lors de la présentation de leur demande de prestations (en remplissant les déclarations du prestataire de 2 semaines) seront révisées.

Une fausse déclaration n’a pas à être faite sciemment pour que le délai de révision soit prolongé à 72 mois. Le simple fait qu’une erreur a été faite est suffisant pour prolonger le délai de révision.

Il est important de noter qu’une déclaration fausse ou trompeuse doit être présente dans chaque demande (déclaration du prestataire de 2 semaines) dans la période examinée pour justifier la prolongation du délai de révision une fois que 36 mois se sont écoulés.

Si la demande pour la PU AE (déclaration du prestataire) ne comprend pas de fausse déclaration, le délai de révision peut être prolongé jusqu’à 72 mois si le client a fait une fausse déclaration dans sa demande d’AE ou son attestation présentée dans AW et que ceci a entraîné l’établissement de la demande pour la PU AE.

Le fait que les demandes pour la PU AE aient été mises en œuvre par un utilitaire n’entrerait pas en ligne de compte pour déterminer si une révision doit avoir lieu ou non. Cet utilitaire n’est pas différent des systèmes informatiques de demande et de paiement de l’AE.

**6.2 Réconciliation du paiement anticipé**

**6.2.1 Introduction**

Cette politique fournit des lignes directrices sur la réconciliation du paiement anticipé de la PU AE et les circonstances dans lesquelles le T-P peut être compensé.

Alors que la forme et les modalités habituelles d’une demande pour la PU AE étaient la présentation des déclarations du prestataire de 2 semaines, la LAE 153.8(1) autorise aussi le ministre à déterminer la forme et la modalité dans lesquelles une demande est présentée. Cette politique crée une forme et des modalités alternatives pour présenter une demande pour la PU AE afin de démontrer l’admissibilité au paiement anticipé seulement. Aucune somme ne doit être directement émise au client dans le cadre de la PU AE à la suite de cette réconciliation du paiement anticipé. L’échéance législative du 2 décembre 2020 [LAE 153.8(2)] pour présenter une demande pour la PU AE est passée.

La LAE 153.7(1) indique que la PU AE est payable à un client qui présente une demande en vertu de la LAE 153.8 et qui est admissible à cette prestation.
       [153.7(1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.7.html) 
       [LAE 153.8](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.8.html)

La LAE 153.7(1.1) autorise la Commission à payer la PU AE avant le moment normalement prévu pour le faire. Cette section est basée sur le RAE 28 qui autorise la Commission à payer à l’avance des prestations pour une semaine de chômage dans des conditions précises.
       [153.7(1.1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.7.html) 
       [RAE 28](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-28.html)

La façon dont la PU AE est normalement payée est sous forme de remboursements quand le client remplit des déclarations du client de 2 semaines en vertu de la LAE 153.8(1) .
       [LAE 153.8(1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.8.html)

**6.2.2 Contexte**

Pendant la période entre le 15 mars 2020 et le 26 septembre 2020, aucune PP régulières ou de maladie de l’AE n’a été établie [ LAE 153.8(5) ]. Toutes les demandes de prestations régulières ou de maladie établies dans cette période étaient plutôt considérées comme des demandes pour la PU AE [LAE 153.5(2)] et 153.8(1). Un client dont la demande a été finalisée avant le 15 juin 2020 a reçu dès le traitement de sa demande un paiement anticipé de 2 000 $ correspondant à 4 semaines de la PU AE. Ce paiement [autorisé dans la LAE 153.7(1.1)] assurait que, peu importe si les Canadiens présentaient une demande auprès de l’ARC ou de Service Canada, leur paiement initial était le même. Après le paiement anticipé de 2 000 $, le client devait continuer de remplir ses déclarations du prestataire de 2 semaines pour démontrer son admissibilité continue à la PU AE. L’annexe 1 de la note de service Prestation d’AE d’urgence — AP 2020-04 comprend des explications supplémentaires sur le paiement anticipé. Un maximum de 28 semaines était payable pour la PU AE.
       [LAE 153.8(5)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.8.html) 
       [Prestation d’AE d’urgence — AP 2020-04](/fr/policy/bememo/be2020-04.shtml)

Le code administratif D65 a été créé pour empêcher les paiements et ainsi appliquer l’équivalent d’une semaine (500 $) du paiement anticipé reçu à des semaines précises de la PU AE. Une fois que le compteur de semaines payées avait atteint 12 semaines dans une demande pour la PU AE, un code D65 était immédiatement imposé pour les 2 semaines suivantes. Après 17 semaines payées, un deuxième code D65 était immédiatement imposé pour 2 semaines. Toutefois, le code D65 pourrait ou non avoir été observé selon le nombre de semaines que le client a demandées dans ses déclarations du prestataire. Plus de renseignements se trouvent dans Renseignement : COVID-19 — Paiement initial de 2 000 $ et nouveau code D65 .
       [Renseignement : COVID-19 — Paiement initial de 2 000 $ et nouveau code D65](/fr/site/dossier/information_covid19_initial_2000_payment_new_d65.shtml)

La Commission a entrepris une réconciliation du paiement anticipé et tout T-P approprié a été établi. La réconciliation fait en sorte que, pour tout client qui a reçu le paiement anticipé, le nombre de semaines de la PU AE payées correspond au nombre de semaines d’admissibilité, selon les déclarations du prestataire reçues, jusqu’à un maximum de 28 semaines. Les T-P qui en découlent varieront de 500 $ à 2 000 $ selon le nombre de semaines avec un code D65 qui ont été observées. Les Avis de dette pour ces T-P ont été émis à partir du mois de novembre 2021. Si des déclarations du prestataire ont été traitées et que la PU AE était payable dans cette semaine, un code D65 est considéré comme observé. La PU AE n’a pas été payée pour une semaine qui comprenait une inadmissibilité pour la semaine entière, une déclaration d’une SET ou quand le client a effectué un RAT le dimanche ou le lundi de cette semaine.

**6.2.3 Application**

Les renseignements fournis au début de la pandémie peuvent avoir créé de la confusion chez les clients puisque, peu importe s’ils ont présenté une demande auprès de l’ARC ou de Service Canada, ils ont reçu un paiement initial de 2 000 $. Par souci de simplicité, la mesure de soutien immédiat aux Canadiens a été communiquée comme une seule PCU. Toutefois, l’ARC et Service Canada ont administré 2 mesures législatives distinctes qui, tout en se voulant aussi semblables que possible, avaient des règles différentes.

La présentation d’une demande initiale dans AW faisait partie de l’administration de la prestation d’urgence par Service Canada et permettait de fournir à la Commission les renseignements requis pour commencer les versements de la PU AE. Les déclarations du prestataire de 2 semaines ont servi de confirmation continue de l’admissibilité du client, ce qui permettait ensuite de lui verser la prestation. Toutefois, du côté de l’ARC, la demande en soi générait le premier paiement et une demande distincte devait être présentée pour chaque période de 4 semaines suivante. De plus, le modèle de l’ARC a été conçu pour émettre les paiements de façon anticipée, tandis que Service Canada a de son côté des systèmes d’AE qui sont conçus pour émettre les paiements en arrérages.

Même si cela va à l’encontre de l’intention énoncée dans la LAE 153.8(1) , le client n’a peut-être pas compris la nécessité de remplir ses déclarations du prestataire pour confirmer son admissibilité au paiement anticipé. Par ailleurs, un client habitué à l’AE, qui a compris la nécessité de remplir des déclarations du prestataire de 2 semaines ainsi que le lien entre ces déclarations et les versements, a peut-être délibérément omis de remplir ses déclarations du prestataire (pour une partie ou la totalité de la période) pour éviter un T-P.
       [153.8(1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.8.html)

Exemple 1 :

Un client présente une demande auprès de Service Canada le 24 mars 2020 (s/c 2231) :

- Son dernier jour de travail (DJT) est le 20 mars 2020 (s/c 2230).

- Sa demande est finalisée le 4 avril 2020 (s/c 2232).

- Le paiement anticipé de 2 000 $ est émis le 6 avril 2020 (s/c 2233).

- Aucune déclaration du prestataire n’a été remplie.

- Il retourne au travail le 20 avril 2020 (s/c 2235).

Du point de vue du client, il était en chômage pendant 4 semaines, a présenté une demande et a reçu 4 semaines de PU AE (c.-à-d. le 2 000 $ en paiement anticipé). Toutefois, sans les déclarations du prestataire remplies pour toute la période de chômage, la Commission ne peut pas confirmer l’admissibilité du client à la prestation. Si le client avait rempli ses déclarations du prestataire, il aurait reçu 2 000 $ de plus, ce qui équivaut à un paiement total de 4 000 $ pour une période de chômage de 4 semaines (alors que le client était seulement admissible à 2 000 $).

Si le même client avait présenté une demande pour la PCU auprès de l’ARC, le paiement de 2 000 $ aurait été appliqué à la période de 4 semaines du 15 mars au 10 avril. Le client n’aurait pas eu à prendre d’autres mesures.

Exemple 2 :

Un client présente une demande auprès de Service Canada le 24 mars 2020 (s/c 2231) :

- Son DJT est le 20 mars 2020 (s/c 2230).

- Sa demande est finalisée le 4 avril 2020 (s/c 2232).

- Le paiement anticipé de 2 000 $ est émis le 6 avril 2020 (s/c 2233).

- Il a rempli ses déclarations du prestataire du 22 mars 2020 au 18 avril 2020 (c.-à-d. de la s/c 2231 à la s/c 2234, donc pour 4 semaines consécutives).

- Il retourne au travail le 17 mai 2020 (s/c 2239).

Du point de vue du client, il était en chômage pendant 8 semaines, a présenté une demande ainsi que 2 déclarations du prestataire de 2 semaines (c.-à-d. 4 semaines déclarées) et a reçu 8 semaines de PU AE (c.-à-d. le paiement anticipé de 2 000 $ et 2 versements à la quinzaine). Toutefois, sans les déclarations du prestataire remplies pour toute la période de chômage de 8 semaines, la Commission ne peut pas confirmer l’admissibilité du client à la PU AE. Si le client avait rempli ses déclarations du prestataire, il aurait reçu 2 000 $ de plus, ce qui équivaut à un paiement total de 6 000 $ pour une période de chômage de 8 semaines (alors que le client était seulement admissible à 4 000 $).

Si le même client avait présenté une demande pour la PCU auprès de l’ARC, il aurait présenté 2 demandes et reçu 4 000 $ pour les périodes de 4 semaines du 15 mars au 10 avril et du 11 avril au 8 mai. Le client n’aurait pas eu à prendre d’autres mesures.

La LAE 153.7(1) indique qu’un versement de la PU AE est seulement payable à un client qui présente une demande en vertu de la LAE 153.8 . Une application stricte de la LAE aux exemples de demandes pour la PU AE ci-dessus signifierait que ces clients n’ont pas rempli les conditions requises pour être admissibles au paiement anticipé, puisqu’ils n’avaient pas rempli leurs déclarations pour toute la période. Par conséquent, un T-P découlant de la réconciliation du paiement anticipé s’applique.
       [153.7(1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.7.html) 
       [153.8](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.8.html)

Toutefois, l’imposition d’un code D65 aux 2 semaines suivant la 12e semaine payée, puis aux 2 semaines suivant la 17e semaine payée, constituait une décision administrative. Dans l’intérêt du service à la clientèle et afin de réconcilier le paiement anticipé pour les semaines pendant lesquelles le client aurait autrement été admissible, mais pour lesquelles il n’y a pas rempli de déclaration du prestataire, la Commission acceptera les éléments suivants comme preuve d’admissibilité au paiement anticipé et jusqu’à un maximum de 4 semaines de PU AE :

- Le dossier indique que le client ne savait pas qu’il devait remplir des déclarations du prestataire et il est déterminé que le fait de remplir ses déclarations du prestataire aurait entraîné un T-P.

- Le dossier indique que le client savait que le fait de remplir ses déclarations du prestataire aurait donné lieu à d’autres paiements, ce qui aurait entraîné un T-P, et le prestataire a délibérément omis de remplir ses déclarations du prestataire pour cette raison.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0277.dita) 

Tout doit être mis en œuvre pour donner au client la possibilité de déclarer son admissibilité, et le T-P du paiement anticipé doit être réconcilié quand ceci est possible. Cette réconciliation attribue 500 $ du T-P du paiement anticipé à une semaine précise, ce qui fait en sorte que cette semaine est considérée comme étant payée, car le paiement avait déjà été émis.

Les semaines d’admissibilité à la PU AE doivent être dans les 8 semaines de l’une des situations suivantes :

- pour un client dont les déclarations du prestataire n’ont pas été traitées, le DJT indiqué dans la demande ou la date de présentation de la demande;

- la période pour laquelle la dernière déclaration du prestataire a été traitée.

Dans certains cas, un client peut avoir indiqué que son admissibilité commence dans une semaine qui ne correspond pas aux renseignements dans le système. Même si le système de l’AE a été utilisé pour verser la PU AE, les concepts d’une demande de prestations initiale et de l’établissement d’une PP ne faisaient pas partie des dispositions ou des adaptations de la LAE VIII.4 . Par conséquent, un client peut être capable de prouver son admissibilité et considéré comme autrement payable pour une semaine antérieure au DPP dans le système.
       [LAE VIII.4](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-28.html)

Exemple 3 :

Un client présente une demande auprès de Service Canada le 19 mars 2020 (s/c 2230) :

- Son DJT est le 18 mars 2020 (s/c 2230).

- Sa demande est finalisée le 4 avril 2020 (s/c 2232).

- Le DPP est établi le 22 mars 2020 (s/c 2231).

- Le paiement anticipé de 2 000 $ est émis le 6 avril 2020 (s/c 2233).

- Aucune déclaration du prestataire n’a été remplie.

- Il est retourné au travail le 10 avril 2020 (s/c 2233).

- Les rémunérations déclarées lors du recueil de faits pour la réconciliation du T-P du paiement anticipé sont les suivantes :

- Semaine du 15 mars 2020 (s/c 2230) : 500 $

- Semaine du 5 avril 2020 (s/c 2233) : 63 $

Du point de vue du client, il était en chômage pendant 4 semaines, a présenté une demande et a reçu 4 semaines de la PU AE. Toutefois, sans les déclarations du prestataire pour toute la période de chômage, la Commission ne peut pas confirmer l’admissibilité du client à la PU AE. Si le client avait rempli ses déclarations du prestataire, il aurait reçu 2 000 $ de plus, ce qui équivaut à un paiement total de 4 000 $ pour une période de chômage de 4 semaines (alors que le client était seulement admissible à 2 000 $).

Si le même client avait présenté une demande pour la PCU auprès de l’ARC, le paiement de 2 000 $ aurait été appliqué à la période de 4 semaines du 15 mars au 10 avril. Le client n’aurait pas eu à prendre d’autres mesures.

Quand un agent effectue le recueil de faits auprès d’un client pour la réconciliation du T-P du paiement anticipé, le client doit déclarer toute rémunération reçue dans la période pour laquelle il demande que des semaines de la PU AE soient utilisées pour compenser le T-P du paiement anticipé, y compris la PCU ou les sommes versées par l’employeur (p. ex. la Subvention salariale d’urgence du Canada).

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0278.dita) 

Exemple :

Dans cet exemple, le client a présenté ses 2 premières déclarations du prestataire et a reçu 3 semaines de la PU AE. Il a aussi reçu le paiement anticipé de 2 000 $. Comme il n’a pas présenté assez de déclarations du prestataire pour démontrer son admissibilité au paiement anticipé, un T-P de 2 000 $ a été créé. Maintenant, le client souhaite présenter d’autres déclarations du prestataire afin de réconcilier le paiement anticipé.

```text
| Semaine | PU AE initialement versée | Rémunération | Admissible en vertu de la LAE 153.9(1) | Première période de 4 semaines | Deuxième période de 4 semaines | Admissible en vertu de la LAE 153.9(4) | Montant réconcilié |

| 15 mars 2020 (s/c 2230) | 500 $ | 0 $ | Oui | | | | |

| 22 mars 2020 (s/c 2231) | 500 $ | 0 $ | Oui | | | | |

| 29 mars 2020 (s/c 2232) | 500 $ | 0 $ | Oui | 4 | | | |

| 5 avril 2020 (s/c 2233) | 0 $ | 200 $ | Oui | 3 | 4 | | 500 $ |

| Le client est admissible aux prestations pour la s/c 2233 en vertu de la LAE 153.9(1), car il a 7 jours consécutifs sans travail et rémunération pendant cette période de 2 semaines. Il n’a pas reçu la PU AE pour cette semaine et, par conséquent, 500 $ peuvent être réconciliés. |

| 12 avril 2020 (s/c 2234) | 0 $ | 200 $ | Non | 2 | 3 | Oui | 500 $ |

| 19 avril 2020 (s/c 2235) | 0 $ | 200 $ | Non | 1 | 2 | Oui | 500 $ |

| Le client est admissible aux prestations pour les s/c 2234 et 2235 en vertu de la LAE 153.9(4). Il n’a pas 7 jours consécutifs sans travail et rémunération, mais sa rémunération au cours de la période de 4 semaines est inférieure à 1 000 $. Pour chaque semaine, 500 $ peuvent être réconciliés. |

| 26 avril 2020 (s/c 2236) | 0 $ | 200 $ | Non | | 1 | Oui | 500 $ |

| Le client est admissible aux prestations pour la s/c 2236 en vertu de la LAE 153.9(4). Il n’a pas 7 jours consécutifs sans travail et rémunération, mais sa rémunération au cours de la période de 4 semaines est inférieure à 1 000 $. Pour cette semaine, 500 $ peuvent être réconciliés. la s/c 2237n’est pas revue car le T-P du paiement anticipé en trop fait l’objet d’une réconciliation complète. Aucun versement supplémentaire de la PU AE ne peut être effectué. Par conséquent, cette semaine n’est pas traitée. |
```

Si le client déclare une rémunération dans la période pour laquelle il demande de compenser une partie ou la totalité du paiement anticipé, l’agent consulte le Guide de la prestation d’AE d’urgence 4.8 afin de s’assurer que le client remplit l’exigence liée à la perte de rémunération pour être admissible à la PU AE avant d’utiliser ces semaines pour compenser le T-P du paiement anticipé.

Si l’un des autres critères d’admissibilité n’est pas rempli, l’admissibilité du client à la PU AE pourrait être révisée de façon subséquente et le T-P pourrait être établi à nouveau.

Le T-P du paiement anticipé est réconcilié selon le montant initial du T-P. Après la compensation du T-P, si le client a effectué un paiement ou si un recouvrement a été appliqué, tout solde restant est remboursé au client.

La LAE 44 permet à la Commission d’accepter et de conserver des paiements de prestations que le client a volontairement retournés. Le client qui remplit les critères d’admissibilité pour que le T-P du paiement anticipé soit réconcilié est considéré comme ayant prouvé son admissibilité à ces prestations, éliminant la responsabilité de remboursement. La Commission n’a pas le droit de conserver tout montant au-delà de cette responsabilité et, ainsi, le montant excédant doit être remboursé au client.

**6.2.4 Défalcation d’un trop-payé (T-P) du paiement anticipé**

Quand une décision entraîne une T-P de la PU AE, la Commission doit déterminer si une disposition de défalcation s’applique en vertu de la LAE 153.1306.

Puisque l’émission du paiement anticipé relevait de la Commission, les paiements ne sont pas une erreur de la part de la Commission. Il incombait au client de prouver son admissibilité au paiement anticipé en remplissant les déclarations du prestataire. Puisque le T-P découle du fait que le client a reçu plus de prestations que ce à quoi il était admissible selon les déclarations du prestataire remplies, les dispositions de défalcation en vertu de la LAE 153.1306(2) ne s’appliquent pas.

**Chapitre 7 : Dispositions administratives**

La LAE VI s’applique à la LAE VIII.4, avec les adaptations appropriées ( LAE 153.6 (1) et (2) et LAE 153.1305 ).
       [LAE VI](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/page-24.html) 
       [LAE 153.6](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.6.html) 
       [LAE 153.1305](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.1305.html)

La LAE 111 permet à la Commission de modifier ou d’annuler une décision, quand de nouveaux faits sont présentés ou quand une décision a été rendue sans qu’un fait important soit connu ou sur la base d’une erreur concernant un fait important. Cela peut également entraîner un T-P ou un M-P de prestations.
       [LAE 111](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/page-24.html)

Aux fins de la LAE 111 :

- Un fait nouveau est un fait qui soit s’est produit après qu’une décision ait été rendue, soit s’est produit avant une décision, mais n’aurait pas pu être découvert par un client agissant avec diligence. Dans les 2 cas, le fait nouveau doit avoir une incidence fondamentale sur une décision.

- Un fait substantiel est un fait qui est significatif ou essentiel pour la question ou l’affaire en cause; par conséquent, un fait substantiel est toute information qui influence le résultat du processus de prise de décision, ou peut l’influencer.

À ne pas confondre avec la LAE 52, les clients ou les employeurs peuvent également demander une révision formelle en vertu de la LAE 112 quand ils ne sont pas d’accord avec une décision.

Les clients ou les employeurs qui ne sont pas d’accord avec une décision rendue par la Commission ont 30 jours à compter de la date à laquelle la décision leur est communiquée pour présenter une demande de révision. Si la demande de révision n’a pas été présentée dans les 30 jours, le retard doit être justifié. La Commission peut accorder un délai plus long si elle estime qu’il existe une explication raisonnable à la demande de révision tardive.

La révision en vertu de la LAE 112 est un processus législatif dans le cadre duquel les clients ou les employeurs demandent à la Commission de procéder à une révision formelle et exhaustive d’une ou de plusieurs de ses décisions et de rendre une décision définitive. Dès réception d’une demande de révision, la Commission doit réviser les décisions identifiées et aviser le client ou l’employeur du résultat.

Cette décision définitive de la Commission peut être contestée par un appel devant le TSS.

Conformément à la LAE 153.121(2), si une révision en vertu de la LAE 112 entraîne l’établissement d’une PP avant le 15 mars 2020 et que le client a déjà reçu la PU AE, le client est réputé ne pas avoir été admissible à la PU AE. La demande pour la PU AE serait remplacée par une PP de l’AE.

Selon la LAE 113 , un client ou un employeur qui est en désaccord avec une décision qui a été révisée en vertu de la LAE 112 peut présenter un appel auprès du TSS-Division générale. L’appel doit être déposé par écrit et doit être reçu par le Tribunal dans les 30 jours civils suivant la réception de la décision de la révision.
       [LAE 113](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/page-24.html)

Si le prestataire ou l’employeur est en désaccord avec la décision rendue par le TSS-Division générale, il peut présenter un appel auprès du TSS-Division d’appel. Là encore, le Tribunal doit recevoir l’appel dans les 30 jours civils suivant la réception par le client ou l’employeur de la décision de la Division générale.

Une fois que le litige fait l’objet d’un appel auprès du TSS, la Commission ne peut plus réviser un litige en vertu de la LAE 52 ni modifier une décision en vertu de la LAE 111.

**Chapitre 8 : Prestations d’emploi et mesures de soutien**

La LAE II s’applique à la partie VIII.4 ( LAE 153.6[1]b] ).
       [LAE II](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/page-14.html) 
       [LAE 153.6[1]b]](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-153.6.html)

Un client qui reçoit une aide financière dans le cadre des prestations d’emploi (partie II) reste admissible à la PU AE.

Un client qui reçoit la PU AE est un participant assuré ( LAE 58 ).
       [LAE 58](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-58.html) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0276.dita`

Remarque :

S’il n’y a pas de PU AE versée pour aucune des semaines d’une période de 2 semaines en raison d’une SET ou d’un RAT, le client ne remplit pas les conditions énumérées dans la LAE 153.9(1), et la LAE 153.9(4) ne peut pas être appliquée, puisque dans la décision de la Commission de l’assurance-emploi du Canada c. HM (AD-23-50), le Tribunal de la sécurité sociale (TSS)-Division d’appel a confirmé que les 4 semaines à prendre en considération pour la LAE 153.9(4) doivent comprendre la période de 2 semaines pour laquelle l’admissibilité est déterminée. Dans ce cas, comme aucune des semaines n’a été payée, la LAE 153.9(4) ne peut être appliquée et le client ne peut être admissible à la période de 2 semaines en question. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0277.dita`

Remarque :

S’il y a des semaines pendant lesquelles les déclarations du prestataire ont été présentées, mais que la PU AE n’a pas été versée en raison d’une SET, ces semaines doivent être examinées pour déterminer l’admissibilité potentielle avant que de nouvelles déclarations du prestataire soient saisies. Ces semaines peuvent être utilisées pour réconcilier le T-P du paiement anticipé. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0278.dita`

Remarque :

Si le client a reçu la PCU, il n’est pas admissible à la PU AE pour la même période. Dans ce cas, l’agent n’applique pas cette politique [c.-à-d. LAE 153.9(2)c)]. 
