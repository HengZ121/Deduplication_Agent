# Niveaux de décision – Annexe 1

Source map: `fr_FR/policy/nationalpolicy/levels_decision-annex1/levels_decision-annex1.ditamap`

## Introduction

Source topic: `fr_FR/policy/nationalpolicy/levels_decision-annex1/introduction.dita`

**Décisions de Niveau 2 déléguées au Niveau 1**

L’annexe 1 n’énumère pas toutes les décisions de Niveau 1. Il s’agit d’une liste des pouvoirs délégués aux agents de Niveau 2 dans le Tableau de délégation des pouvoirs en matière d’assurance-emploi , qui ont désormais aussi été délégués au Niveau 1 dans le cadre de la Politique sur les niveaux de décision. Pour qu’un agent de Niveau 1 ait le pouvoir de rendre une décision en vertu de cette politique, les conditions précises énumérées dans la politique doivent être remplies et l’agent doit avoir les compétences et la formation requises.
       [Tableau de délégation des pouvoirs en matière d’assurance-emploi](https://iservice.prv/fra/finance/DELEG/vigueur/ae/tableau_delegation_pouvoir_assurance_emploi.pdf)

Les agents renvoient toutes les questions liées aux prestations pour proches aidants et certaines questions liées aux prestations de compassion (PDC) à l’unité de traitement spécialisée appropriée. Cela ne comprend pas les conversions des prestations pour proches aidants ou PDC en un autre genre de prestations (GP).

Mise à jour le 21 octobre 2025

Table des matières

- Antidate — LAE 10; 152.11

- Autoriser une antidate
             [Autoriser une antidate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s1_1)

- Refuser une antidate
             [Refuser une antidate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s1_2)

         [Antidate — LAE 10; 152.11](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s1)

- Procédure de présentation des demandes — LAE 48; 49; 50(1); 152.1; RAE 26

- NAS de la série 900 ― LAE 18; 50
             [NAS de la série 900 ― LAE 18; 50](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s2_1)

- Dernier RE en retard — Demande est PPNE N2 - Dernier RE manquant
             [Dernier RE en retard — Demande est PPNE N2 - Dernier RE manquant](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s2_2)

- D15 — Inadmissibilité
             [D15 — Inadmissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s2_3)

- D48 — Inadmissibilité
             [D48 — Inadmissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s2_4)

- D64 — Inadmissibilité
             [D64 — Inadmissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s2_5)

- Déclarations du prestataire en retard
             [Déclarations du prestataire en retard](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s2_6)

         [Procédure de présentation des demandes — LAE 48; 49; 50(1); 152.1; RAE 26](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s2)

- Disponibilité — LAE 18; 25; 50(8)

- Non-disponibilité déclarée par le client
             [Non-disponibilité déclarée par le client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_1)

- Vacances
             [Vacances](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_2)

- Hors de la région pour un motif autre que des vacances au Canada
             [Hors de la région pour un motif autre que des vacances au Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_3)

- Changement de résidence
             [Changement de résidence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_4)

- Cours de formation et activités d’emploi
             [Cours de formation et activités d’emploi](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_5)

- Fonction de juré
             [Fonction de juré](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_6)

- Emploi à temps partiel
             [Emploi à temps partiel](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_7)

- Emploi pour une semaine partielle — Situations de faillite
             [Emploi pour une semaine partielle — Situations de faillite](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_8)

- Prestations régulières dans la fenêtre de maternité
             [Prestations régulières dans la fenêtre de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_9)

- Autrement disponible — Prestations de maladie
             [Autrement disponible — Prestations de maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_10)

- Retour au travail progressif
             [Retour au travail progressif](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_11)

- Modification de la date de retour au travail
             [Modification de la date de retour au travail](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_12)

- Conversions
             [Conversions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3_13)

         [Disponibilité — LAE 18; 25; 50(8)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s3)

- Conflits collectifs — LAE 36
         [Conflits collectifs — LAE 36](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s4)

- Incarcération — LAE 37(a); 152.2(a)
         [Incarcération — LAE 37(a); 152.2(a)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s5)

- Hors Canada — LAE 37(b); 152.2(b); RAE 55; 55.01

- Période autorisée
             [Période autorisée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s6_1)

- Période de 7 jours autorisée – LAE 52
             [Période de 7 jours autorisée – LAE 52](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s6_2)

- Période de 14 jours autorisée
             [Période de 14 jours autorisée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s6_3)

- Imposer une inadmissibilité après le 7 e jour
             [Imposer une inadmissibilité après le 7ejour](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s6_4)

- Imposer une inadmissibilité après le 14 e jour
             [Imposer une inadmissibilité après le 14ejour](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s6_5)

- Imposer une inadmissibilité pour toute la période
             [Imposer une inadmissibilité pour toute la période](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s6_6)

- Terminer une inadmissibilité
             [Terminer une inadmissibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s6_7)

         [Hors Canada — LAE 37(b); 152.2(b); RAE 55; 55.01](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s6)

- Rémunération et correction d’erreurs — LAE 52, 54 (s); RAE 35; 35(2); 36; 37; 38

- Rémunération autre que celle provenant d’un travail indépendant (TI)
             [Rémunération autre que celle provenant d’un travail indépendant (TI)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s7_1)

- Rémunération provenant d’un TI (y compris les activités agricoles), de profits d’une entreprise ou de commissions
             [Rémunération provenant d’un TI (y compris les activités agricoles), de profits d’une entreprise ou de commissions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s7_2)

- Correction autre que la rémunération
             [Correction autre que la rémunération](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s7_3)

- Correction d’une période d’exemption des déclarations du prestataire
             [Correction d’une période d’exemption des déclarations du prestataire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s7_4)

         [Rémunération et correction d’erreurs — LAE 52, 54 (s); RAE 35; 35(2); 36; 37; 38](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s7)

- Congédiement et suspension — LAE 30; 31

- Congédiement
             [Congédiement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s8_1)

- Suspension
             [Suspension](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s8_2)

         [Congédiement et suspension — LAE 30; 31](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s8)

- Départ volontaire et congé autorisé — LAE 29; 32; 34; RAE 51.1

- Départ volontaire
             [Départ volontaire](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s9_1)

- Période de congé
             [Période de congé](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s9_2)

         [Départ volontaire et congé autorisé — LAE 29; 32; 34; RAE 51.1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s9)

- Non en chômage — LAE 9; 11

- Travail indépendant et activités agricoles
             [Travail indépendant et activités agricoles](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s10_1)

- Non en chômage
             [Non en chômage](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s10_2)

         [Non en chômage — LAE 9; 11](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s10)

- Enseignants demandant des prestations pendant une période de congé scolaire — RAE 33
         [Enseignants demandant des prestations pendant une période de congé scolaire — RAE 33](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s11)

- Prestations parentales et décès de l’enfant ― LAE 23
         [Prestations parentales et décès de l’enfant ― LAE 23](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s12)

- Modification d’une inadmissibilité existante — Prestations spéciales
         [Modification d’une inadmissibilité existante — Prestations spéciales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s13)

- Révision — LAE 52; 112
         [Révision — LAE 52; 112](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s14)

- Demandes de prestation d’urgence de l’AE (PU AE) — LAE 52; 112; 153.5(2) et (3); 153.6(1); 153.9(1), (2) et (4); 153.1303 (Mesure temporaire)
         [Demandes de prestation d’urgence de l’AE (PU AE) — LAE 52; 112; 153.5(2) et (3); 153.6(1); 153.9(1), (2) et (4); 153.1303 (Mesure temporaire)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/levels_decision-annex1#s15)

**1. Antidate – LAE10;152.11**

**Autoriser une antidate**

Un agent de Niveau 1 peut rendre la décision d’autoriser une antidate pour tous les GP quand :

- le seul motif pour lequel le client n’a pas présenté sa demande entre la date de début de la période de prestations (PP) ou de renouvellement demandée et la date réelle de présentation de la demande est que le client recevait une indemnité de départ ou de congédiement et que sa répartition aurait empêché le paiement de prestations pour cette période; et

- le client a présenté la demande initiale dans la période de 52 semaines après la date de début de la PP demandée et remplit les conditions requises pour établir une demande pendant cette semaine; ou

- le client a présenté la demande de renouvellement dans la période de 52 semaines après la date de renouvellement demandée.

Un agent de Niveau 1 peut rendre la décision d’autoriser une antidate pour tous les GP quand :

- le motif pour lequel le client n’a pas présenté la demande entre la date de début de la PP ou de renouvellement demandée et la date réelle de présentation de la demande est l’un des motifs suivants, ou une combinaison de ceux-ci :

- le client ne possède pas l’expérience ou la compréhension du programme de l’AE et des délais prescrits et n’a pas eu de demande dans les 3 années précédant la date de présentation de la demande actuelle;

- le client a peu ou aucune compréhension du français et de l’anglais;

- le client a reçu une offre d’emploi avant l’arrêt de rémunération (A de R), pour un emploi qui commencerait dans la période de 8 semaines après l’A de R, mais le nouvel emploi a été retardé ou ne s’est pas concrétisé. Aucune vérification auprès de l’employeur n’est requise;

- le client attendait que l’employeur émette le RE; et

- un des motifs ou une combinaison des motifs ci-dessus couvre toute la période du retard; et

- le client a présenté la demande initiale dans la période de 8 semaines après la date de début de la PP demandée et remplit les conditions requises pour établir une demande dans cette semaine; ou

- le client a présenté la demande de renouvellement dans la période de 8 semaines après la date de renouvellement demandée.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0332.dita) 

Un agent de Niveau 1 peut rendre la décision d’autoriser une antidate pour une demande de prestations régulières quand :

- la demande était précédemment PPNE 5 et une modification de la NVA a réduit le nombre d’heures requis pour remplir les conditions requises pour recevoir des prestations régulières; et

- le client remplira les conditions requises pour recevoir des prestations régulières selon la modification de la NVA; et

- le client a présenté la demande dans la période de 8 semaines après la date de DPP demandée; et

- le motif pour lequel le client n’a pas présenté de demande de prestations à la suite de la modification de la NVA est qu’il n’était pas au courant de la possibilité de désormais remplir les conditions requises pour recevoir des prestations d’AE.

Un agent de Niveau 1 peut rendre la décision d’autoriser une antidate pour une demande de prestations spéciales quand :

- le motif pour lequel le client n’a pas présenté la demande entre la date de début de la PP ou de renouvellement demandée et la date réelle de présentation de la demande est l’un des motifs suivants, ou une combinaison de ceux-ci :

- le client était malade, blessé ou mis en quarantaine;

- le client attendait une réponse d’une Commission des accidents du travail provinciale, d’une compagnie d’indemnités d’assurance-salaire (IAS) ou d’une compagnie d’assurance;

- pour les PDC et les prestations pour proches aidants : le client fournissait des soins ou du soutien au patient pour lequel le client a demandé des prestations, et il n’y a aucune indication au dossier que quelqu’un d’autre a demandé des prestations liées aux soins ou au soutien du même patient;

- le client ne possède pas l’expérience ou la compréhension du programme de l’AE et des délais prescrits et n’a pas eu de demande dans les 3 années précédant la date de présentation de la demande actuelle;

- le client a peu ou aucune compréhension du français et de l’anglais;

- le client attendait que l’employeur émette le RE; et

- un des motifs ou une combinaison des motifs ci-dessus couvre l’entièreté de la période du retard; et

- le client a présenté la demande initiale dans la période de 8 semaines après la date de début de la PP demandée et remplit les conditions requises pour établir une demande dans cette semaine; ou

- le client a présenté la demande de renouvellement dans la période de 8 semaines après la date de renouvellement demandée.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0332.dita) 

Un agent de Niveau 1 peut rendre la décision d’autoriser une antidate dans une demande de prestations de maladie, de maternité ou parentales quand :

- le seul motif pour lequel le client n’a pas présenté la demande entre la date de début de la PP ou de renouvellement demandée et la date réelle de présentation de la demande est l’un des suivants :

- le client était malade, blessé ou mis en quarantaine; ou

- le client attendait une réponse d’une Commission des accidents du travail provinciale, d’une compagnie d’IAS ou d’une compagnie d’assurance; et

- le client ne demande pas de prestations régulières entre la date de début de la PP ou de renouvellement demandée et la date réelle de présentation de la demande; et

- le client a présenté la demande initiale dans la période de 52 semaines après la date de début de la PP demandée et remplit les conditions requises pour établir une demande dans cette semaine; ou

- le client a présenté la demande de renouvellement dans la période de 52 semaines après la date de renouvellement demandée.

Un agent de Niveau 1 peut rendre la décision d’autoriser une antidate pour une demande de PDC ou de prestations pour proches aidants quand :

- le seul motif pour lequel le client n’a pas présenté la demande entre la date de début de la PP ou de renouvellement demandée et la date réelle de présentation de la demande est que le client fournissait des soins ou du soutien au patient; et

- il n’y a aucune indication au dossier que quelqu’un d’autre a demandé des prestations liées aux soins ou au soutien du même patient; et

- le client ne demande pas de prestations régulières entre la date de début de la PP ou de renouvellement demandée et la date réelle de présentation de la demande; et

- le client a présenté la demande initiale dans la période de 52 semaines après la date de début de la PP demandée et remplit les conditions requises pour établir une demande dans cette semaine; ou

- le client a présenté la demande de renouvellement dans la période de 52 semaines après la date de renouvellement demandée.

**Refuser une antidate**

Un agent de Niveau 1 peut rendre la décision de refuser une antidate quand :

- le client ne remplit pas les conditions requises pour établir une demande à n’importe quel jour entre la date de début de la PP demandée et le DPP.

**2. Procédure de présentation des demandes — LAE48;49;50(1);152.1; RAE26**

**NAS de la série 900 ― LAE18;50**

Un agent de Niveau 1 peut rendre une décision pour autoriser les prestations régulières ou de maladie pour un client ayant un NAS de la série 900 quand :

- le client a un permis de travail ouvert valide; ou

- le client a fourni une preuve de statut conservé d’un permis de travail ouvert; et

- le client demande des prestations régulières, et il est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi; ou

- le client demande des prestations de maladie et il est autrement disponible pour travailler.

Un agent de Niveau 1 peut rendre une décision d’autoriser les prestations de maternité, parentales, pour proches aidants ou des PDC à un client ayant un NAS de la série 900 quand :

- le client a un NAS valide; ou

- le NAS est expiré, mais le client est autorisé à rester au Canada et il reste au Canada.

**Dernier RE en retard — Demande est PPNE N2 - Dernier RE manquant**

Un agent de Niveau 1 peut rendre la décision d’autoriser un dernier RE en retard reçu dans les 90 jours suivant la date à laquelle la demande a été finalisée comme PPNE N2.

Un agent de Niveau 1 peut rendre la décision d’autoriser un dernier RE en retard reçu plus de 90 jours après la date à laquelle la demande a été finalisée comme PPNE N2 quand :

- le RE a été reçu dans les 52 semaines suivant la date à laquelle la demande a été finalisée comme PPNE N2; et

- le client était incapable de présenter le RE pendant toute la période du retard en raison d’une maladie, d’une blessure ou d’une mise en quarantaine; ou

- le client demande des prestations de maternité, parentales, pour proches aidants ou des PDC; ou

- le client était hors de la région ou hors Canada pendant toute la période du retard; et

- le client ne demande aucune prestation pendant toute la période du retard; ou

- le client n’est pas admissible à des prestations en raison d’une répartition de la rémunération et communique avec Service Canada dans les 6 semaines suivant la date de fin de la répartition; ou

- l’employeur a tardé à fournir le RE et il y a des documents au dossier indiquant que le client a demandé l’aide de Service Canada pour obtenir le RE dans les premiers 90 jours suivant la date à laquelle la demande a été finalisée PPNE N2.

**D15 — Inadmissibilité**

**Imposer une inadmissibilité D15**

Un agent de Niveau 1 peut rendre la décision d’imposer une inadmissibilité 15 - Procédure de présentation des demandes (D15) pour avoir omis de présenter un RE ou d’autres renseignements demandés.

**Annuler une inadmissibilité D15**

Un agent de Niveau 1 peut rendre la décision d’annuler une inadmissibilité D15 imposée pour avoir omis de présenter un RE quand il est reçu dans les 90 jours suivant la date à laquelle l’inadmissibilité D15 a été imposée.

Un agent de Niveau 1 peut rendre la décision d’annuler l’inadmissibilité D15 imposée pour avoir omis de présenter un RE quand il est reçu plus de 90 jours suivant la date à laquelle l’inadmissibilité D15 a été imposée quand :

- le RE a été reçu dans les 52 semaines suivant la date à laquelle l’inadmissibilité D15 a été imposée; et

- le client était incapable de présenter le RE pendant toute la période du retard en raison d’une maladie, d’une blessure ou d’une mise en quarantaine; ou

- le client demande des prestations de maternité, parentales, pour proches aidants ou des PDC; ou

- le client n’est pas admissible à des prestations en raison d’une répartition de la rémunération et communique avec Service Canada dans les 6 semaines suivant la date de fin de la répartition; ou

- l’employeur a tardé à fournir le RE et il y a des documents au dossier indiquant que le client a demandé l’aide de Service Canada pour obtenir le RE dans les premiers 90 jours suivant la date à laquelle l’inadmissibilité D15 a été imposée.

Un agent de Niveau 1 peut rendre la décision d’annuler une inadmissibilité D15 imposée pour avoir omis de fournir les renseignements requis autres qu’un RE quand :

- un agent de Niveau 1 a initialement imposé l’inadmissibilité D15; et

- le client communique avec Service Canada dans les 6 semaines suivant la date d’envoi de la lettre D-01-00-01; et

- le client a fourni les renseignements demandés; et

- si le client demande des prestations régulières, il était capable et disponible pour travailler et n’a posé aucune restriction quant à l’acceptation d’un emploi pendant toute la période; ou

- si le client demande des prestations régulières et n’était pas disponible pour travailler, le client a déclaré ne pas être disponible pour travailler.

**Terminer une inadmissibilité D15**

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité D15 imposée pour avoir omis de présenter un RE quand :

- le RE a été reçu dans les 52 semaines suivant la date à laquelle l’inadmissibilité D15 a été imposée; et

- le client était hors de la région ou hors Canada pendant toute la période du retard; et

- le client ne demande aucune prestation pendant toute la période du retard.

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité D15 imposée pour avoir omis de présenter des renseignements demandés autres qu’un RE dans une demande renouvelée quand le motif de l’inadmissibilité ne s’applique plus au moment du renouvellement.

**D48 — Inadmissibilité**

**Imposer une inadmissibilité D48**

Un agent de Niveau 1 peut rendre la décision d’imposer une inadmissibilité 48 - Déménagé-adresse inconnue (D48) pour avoir omis de fournir l’adresse du lieu de résidence habituel.

**Annuler une inadmissibilité D48**

Un agent de Niveau 1 peut rendre la décision d’annuler une inadmissibilité D48 imposée pour avoir omis de fournir l’adresse du lieu de résidence habituel quand :

- un agent de Niveau 1 a initialement imposé l’inadmissibilité D48; et

- le client communique avec Service Canada dans les 6 semaines suivant la date à laquelle l’inadmissibilité D48 a été imposée; et

- le client fournit l’adresse de son lieu de résidence habituel.

**Terminer une inadmissibilité D48**

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité D48 imposée pour avoir omis de fournir l’adresse du lieu de résidence habituel quand :

- le client fournit l’adresse de son lieu de résidence habituel; et

- le client ne demande pas de prestations pour la période pendant laquelle l’inadmissibilité D48 est imposée.

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité D48 imposée pour avoir omis de fournir l’adresse du lieu de résidence habituel si le client fournit la nouvelle adresse au moment de renouveler sa demande.

**D64 — Inadmissibilité**

**Imposer une inadmissibilité D64**

Un agent de Niveau 1 peut rendre la décision d’imposer une inadmissibilité 64 - Renouvellement-Preuve d’identité non fournie (D64) pour avoir omit de fournir les documents d’identité demandés lors de la présentation d’une demande de renouvellement.

**Annuler une inadmissibilité D64**

Un agent de Niveau 1 peut rendre la décision d’annuler une inadmissibilité D64 imposée pour avoir omis de fournir une preuve d’identité quand :

- un agent de Niveau 1 a initialement imposé l’inadmissibilité D64; et

- le client communique avec Service Canada dans les 6 semaines suivant la date à laquelle l’inadmissibilité D64 a été imposée; et

- le client fournit les documents d’identité demandés.

**Terminer une inadmissibilité D64**

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité D64 imposée pour avoir omis de fournir une preuve d’identité quand :

- un agent de Niveau 1 a initialement imposé l’inadmissibilité D64; et

- le client a fourni les documents d’identité demandés; et

- le client ne demande pas de prestations pour la période pendant laquelle l’inadmissibilité D64 est imposée.

**Déclarations du prestataire en retard**

**Répartition**

Un agent de Niveau 1 peut rendre la décision d’autoriser une déclaration du prestataire en retard quand :

- le client n’est pas admissible à aucune prestation en raison d’une répartition de la rémunération; et

- le client communique avec Service Canada dans les 8 semaines suivant la date à laquelle la répartition a pris fin.

**Manque d’expérience en matière d’AE**

Un agent de Niveau 1 peut rendre la décision d’autoriser une déclaration du prestataire en retard quand :

- le motif du retard est dû au manque d’expérience ou de compréhension des procédures d’AE ou des délais prescrits pour présenter les déclarations du prestataire; et

- le client communique avec Service Canada dans les 12 semaines suivant la date de présentation de la demande initiale; et

- la déclaration du prestataire en retard comprend la semaine du DPP.

**Quitter la région ou le Canada**

Un agent de Niveau 1 peut rendre la décision d’autoriser une déclaration du prestataire en retard quand :

- le client a quitté le Canada ou la région avant la date d’échéance de la déclaration du prestataire; et

- le client communique avec Service Canada dans les 8 semaines suivant la date de son retour au Canada; et

- aucun autre motif n’a empêché le client de présenter la déclaration du prestataire avant le départ.

**Retour au travail**

Un agent de Niveau 1 peut rendre la décision d’autoriser une déclaration du prestataire en retard quand :

- la déclaration du prestataire inclut le délai de carence; et

- le retard est dû au fait que le client est retourné au travail au cours de la semaine suivant immédiatement le délai de carence; et

- le client ne demande pas de prestations pour la semaine du RAT; et

- aucun autre motif n’a empêché le client de présenter la déclaration du prestataire avant de retourner au travail.

**Prestations spéciales**

Un agent de Niveau 1 peut rendre la décision d’autoriser une déclaration du prestataire en retard quand :

- le retard est dû à une maladie, une blessure ou une mise en quarantaine du client; et

- aucun autre motif n’a empêché le client de présenter la déclaration du prestataire.

Un agent de Niveau 1 peut rendre la décision d’autoriser une déclaration du prestataire en retard quand :

- le client demande des prestations de maternité, parentales, pour proche aidant ou des PDC pour la période de retard; et

- le client communique avec Service Canada dans les 8 semaines suivant le dernier jour de la période couverte par la déclaration du prestataire.

**3. Disponibilité — LAE18;25;50(8)**

**Non-disponibilité déclarée par le client**

Un agent de Niveau 1 peut rendre la décision d’imposer une inadmissibilité dans la demande pour des motifs de non-disponibilité quand :

- aucune prestation n’a été versée pour la période pendant laquelle le client a déclaré ne pas être disponible; ou

- si des prestations ont été versées, le client a communiqué avec Service Canada afin de corriger les mauvais renseignements dans les 6 semaines suivant la présentation de la déclaration du prestataire; et

- le client accepte qu’aucune prestation ne soit versée pendant la période de non-disponibilité.

Un agent de Niveau 1 peut rendre la décision qu’un client est considéré comme disponible quand :

- le client suit une formation approuvée en vertu de la LAE 25; et
         [LAE 25;](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-25.html)

- une confirmation de l’approbation de la formation, y compris les dates de formation, de l’autorité désignée est disponible dans le dossier du client ou par AccèsEDMT; et

- les dates de la formation approuvée couvrent l’entièreté de la période de non-disponibilité déclarée.

**Vacances**

Un agent de Niveau 1 peut rendre la décision d’imposer une inadmissibilité dans la demande pour des motifs de non-disponibilité quand :

- le client est ou était en vacances (au Canada ou hors Canada); et

- le client n’est ou n’était pas disponible pour travailler; et

- aucune prestation n’a été versée pour la période pendant laquelle le client est ou était en vacances; ou

- si des prestations ont été versées, le client a communiqué avec Service Canada afin de corriger les mauvais renseignements dans les 6 semaines suivant la présentation de la déclaration du prestataire.

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité imposée dans la demande pour un motif de non-disponibilité pendant des vacances quand :

- le client n’est plus en vacances; et

- le client communique avec Service Canada dans les 6 semaines suivant la date de retour; et

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi à compter de la date de son retour.

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité imposée dans une demande de renouvellement pour le motif de non-disponibilité pendant des vacances quand celles-ci se sont terminées avant la date de renouvellement.

**Hors de la région pour un motif autre que des vacances au Canada**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0333.dita) 

Un agent de Niveau 1 peut rendre la décision d’autoriser les prestations pour une durée maximale de 7 jours quand le motif pour quitter la région est :

- pour assister aux funérailles d’un membre de la famille immédiate ou d’un proche parent; ou

- pour rendre visite à un membre de la famille immédiate gravement malade ou blessé; ou

- pour accompagner un membre de la famille immédiate dans un établissement agréé afin qu’il y reçoive un traitement médical qui n’est pas facilement ou immédiatement disponible dans la région de résidence du membre de la famille au Canada; ou

- pour chercher un emploi ou se présenter à un entretien d’embauche; et

- l’absence a duré 7 jours ou moins; et

- aucune prestation n’a été versée; ou

- si des prestations ont été versées, le client communique avec Service Canada dans les 6 semaines suivant la présentation de sa déclaration du prestataire; et

- le client avait pris des dispositions pour être joint en cas d’offres d’emploi et pouvait revenir dans les 48 heures en cas d’offre d’emploi.

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité dans la demande d’un client qui était hors de la région, mais au Canada, quand :

- le client communique avec Service Canada dans les 6 semaines suivant la date de retour dans la région; et

- le motif pour lequel le client était hors de la région est l’un des suivants :

- pour assister aux funérailles d’un membre de la famille immédiate ou d’un proche parent; ou

- pour visiter un membre de la famille immédiate gravement malade ou blessé; ou

- pour accompagner un membre de la famille immédiate dans un établissement agréé afin qu’il y reçoive un traitement médical qui n’est pas facilement ou immédiatement disponible dans la région de résidence du membre de la famille au Canada; ou

- pour chercher un emploi ou se présenter à un entretien d’embauche; et

- le motif de l’absence est la seule question liée à l’admissibilité dans le dossier.

Un agent de Niveau 1 peut rendre la décision de terminer l’inadmissibilité imposée dans une demande renouvelée pour avoir été hors de la région quand l’absence a pris fin avant la date de renouvellement.

**Changement de résidence**

L’agent de Niveau 1 peut considérer un client comme disponible lors de la période de déménagement dans une nouvelle résidence quand :

- il n’y a pas d’inadmissibilité, d’exclusion ou de traitement manuel (TM) en attente de traitement au dossier; et

- le client est capable et disponible pour travailler pendant la période du déménagement et ne pose aucune restriction quant à l’acceptation d’un emploi pendant ou depuis le déménagement; et

- le client n’a pas quitté volontairement son emploi, sans motif valable, pour déménager

**Cours de formation et activités d’emploi**

**Cours de formation non dirigé — Formation qui ne remplit pas les conditions de laLAE 25**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0334.dita) 

Un agent de Niveau 1 peut considérer un client comme disponible et autoriser un cours de formation non dirigé (qui ne remplit pas les conditions de la LAE 25 ) dans une demande de prestations régulières quand :
       [LAE 25](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-25.html)

- le cours de formation est d’une durée de 10 à 14 heures par semaine; et

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi, ni aux heures ou aux jours de disponibilité; et

- le client est prêt à abandonner le cours de formation ou à modifier son horaire de cours pour accepter un emploi à temps plein, si cet horaire devait entrer en conflit avec cet emploi.

- le cours de formation est d’une durée de 15 heures ou plus par semaine; et

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi; et

- toutes les exigences du cours de formation peuvent être remplies hors des heures de travail normales du travail habituel du client; et

- le client est prêt à abandonner le cours de formation ou à modifier son horaire de cours pour accepter un emploi à temps plein, si cet horaire devait entrer en conflit avec cet emploi.

Un agent de Niveau 1 peut considérer un client comme autrement disponible et autoriser un cours de formation non dirigé (qui ne remplit pas les conditions de la LAE 25 ) dans une demande de prestations de maladie quand :
       [LAE 25](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-25.html)

- le cours de formation est d’une durée de 10 à 14 heures par semaine; et

- le client déclare qu’il aurait été capable et disponible pour travailler s’il n’avait pas eu de maladie, de blessure ou de mise en quarantaine; et

- l’intention du client, une fois rétabli, est :

- de retourner à son emploi, car le cours de formation sera terminé avant son rétablissement; ou

- d’abandonner son cours de formation et de retourner à son emploi; ou

- de poursuivre le cours de formation et de retourner à son emploi selon le même horaire et les mêmes conditions qu’avant sa maladie, sa blessure ou sa mise en quarantaine.

- le cours de formation est d’une durée de 15 heures ou plus par semaine; et

- toutes les exigences du cours de formation peuvent être remplies hors des heures de travail normales du travail habituel du client; et

- le client déclare qu’il aurait été capable et disponible pour travailler s’il n’avait pas eu de maladie, de blessure ou de mise en quarantaine; et

- les intentions du client, une fois rétabli, sont :

- de retourner à son emploi, car le cours de formation sera terminé avant son rétablissement; ou

- d’abandonner le cours de formation et de retourner à son emploi; ou

- de poursuivre le cours de formation et de retourner à son emploi selon le même horaire et les mêmes conditions qu’avant sa maladie, sa blessure ou sa mise en quarantaine.

Un agent de Niveau 1 peut rendre la décision d’autoriser le cours de formation non dirigé (qui ne remplit pas les conditions de la LAE 25 ) pendant que le client reçoit des prestations parentales ou pour proches aidants quand :
       [LAE 25](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-25.html)

- le cours de formation est d’une durée de moins de 25 heures par semaine; et

- le client n’a pas besoin de résider loin du membre de la famille qui reçoit ses soins ou son soutien, ou de son enfant, pour suivre le cours de formation.

Un agent de Niveau 1 peut rendre la décision d’autoriser le cours de formation non dirigé (qui ne remplit pas les conditions de la LAE 25 ) pendant que le client reçoit des prestations de PDC quand :
       [LAE 25](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-25.html)

- le cours de formation est d’une durée de moins de 25 heures par semaine.

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité imposée pour la non-disponibilité du client pendant qu’il suivait un cours de formation quand :

- le client abandonne le cours de formation; ou

- le cours de formation est terminé; et

- le client ne demande pas de prestations pour une période de relâche entre les trimestres ou pendant l’année scolaire; et

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi; ou

- une preuve que le client a été dirigé vers le cours de formation en vertu de la LAE 25 est reçue.
         [LAE 25](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-25.html)

**Fin du cours de formation dirigé ou d’une activité d’emploi — LAE27(1.1)**

Un agent de Niveau 1 peut rendre la décision d’autoriser la fin anticipée d’un cours de formation dirigé ou d’une activité d’emploi et le versement de prestations régulières ou de maladie quand :

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi; ou

- le client déclare qu’il aurait été capable et disponible pour travailler s’il n’avait pas eu de maladie, de blessure ou de mise en quarantaine; et

- le motif pour lequel le cours de formation ou l’activité d’emploi a pris fin est l’un des motifs suivants :

- des raisons médicales; ou

- le client a terminé le cours de formation ou l’activité d’emploi avant la semaine de fin prévue; ou

- le client a des problèmes d’assiduité parce qu’il fournit des soins ou du soutien à un proche parent tout en recevant des prestations parentales, pour proches aidants ou des PDC; ou

- le cours de formation ou l’activité d’emploi était supérieur au niveau de compétences du client; ou

- une autorité désignée par Service Canada a déterminé que le cours de formation ou l’activité d’emploi ne convenait pas au client.

**Fonction de juré**

Un agent de Niveau 1 peut rendre la décision d’autoriser les prestations pour la période pendant laquelle le client est appelé à exercer des fonctions de juré.

Un agent de Niveau 1 peut rendre la décision de suspendre une inadmissibilité liée à la disponibilité pour une période pendant laquelle le client est appelé à exercer des fonctions de juré.

**Emploi à temps partiel**

Un agent de Niveau 1 peut considérer un client comme disponible quand :

- le client travaille actuellement à temps partiel; et

- le client est disponible et il est à la recherche d’un autre emploi convenable auprès de cet employeur ou de tout autre employeur; et

- le client est prêt à quitter son emploi à temps partiel pour accepter une offre d’emploi à temps plein.

**Emploi pour une semaine partielle – cas de faillite**

Un agent de Niveau 1 peut rendre la décision d’imposer une inadmissibilité pour une période allant jusqu’à 4 jours pendant la semaine du DPP ou de la semaine de renouvellement quand un client a travaillé, mais qu’il n’a pas reçu toute la rémunération en raison de la faillite de l’employeur.

**Prestations régulières dans la fenêtre de maternité**

Un agent de Niveau 1 peut considérer une cliente comme disponible quand elle demande des prestations régulières pendant la fenêtre de maternité avant la date d’accouchement quand :

- la cliente est mise à pied en raison d’un manque de travail avant ou pendant la fenêtre de maternité; ou

- la cliente recevait des prestations régulières avant le début de la fenêtre de maternité; et

- le congé de maternité de la cliente à son lieu de travail n’était pas prévu pour la période pour laquelle elle demande des prestations régulières; et

- la cliente est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi.

Un agent de Niveau 1 peut considérer une cliente comme disponible quand elle demande des prestations régulières 14 jours ou plus après la date réelle de son accouchement quand :

- la cliente est de deuxième catégorie; et

- la cliente est mise à pied en raison d’un manque de travail; ou

- la cliente recevait des prestations régulières avant la date de son accouchement; et

- le congé de maternité de la cliente à son lieu de travail n’était pas prévu pour la période pour laquelle elle demande des prestations régulières; et

- la cliente est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi.

**Autrement disponible — Prestations de maladie**

Un agent de Niveau 1 peut considérer un client comme autrement disponible dans une demande initiale de prestations de maladie quand :

- le client aurait été capable et disponible pour travailler s’il n’avait pas eu de maladie, de blessure ou de mise en quarantaine; ou

- le client aurait été admissible aux prestations régulières s’il n’avait pas eu de maladie, de blessure ou de mise en quarantaine.

Un agent de Niveau 1 peut considérer un client comme autrement disponible dans une demande continue ou renouvelée pour des prestations de maladie quand :

- le client recevait ou était admissible à des prestations parentales, des prestations pour proches aidants ou des PDC au début de la maladie, de la blessure ou de la mise en quarantaine; et

- l’admissibilité du client aux prestations parentales, aux prestations pour proches aidants ou aux PDC se poursuit jusqu’à la date de guérison ou après; et

- le client présente un certificat médical pour la période d’incapacité, qui indique la date de début de l’incapacité et la date prévue de guérison.

Un agent de Niveau 1 peut considérer une cliente comme autrement disponible quand elle demande des prestations de maladie pendant la fenêtre de maternité avant la date réelle d’accouchement quand :

- la cliente a cessé de travailler en raison d’une maladie; ou

- la cliente recevait des prestations régulières ou de maladie avant le début de la fenêtre de maternité; et

- le congé de maternité n’était pas prévu au lieu de travail de la cliente pendant la période pour laquelle elle demande les prestations de maladie; et

- la cliente aurait été capable et disponible pour travailler, si elle n’avait pas eu de maladie, de blessure ou de mise en quarantaine.

**Retour au travail progressif**

Un agent de Niveau 1 peut rendre la décision de continuer le paiement de prestations de maladie quand :

- le client s’est rétabli dans la mesure où il est capable de travailler, mais pas à temps plein en raison de la maladie ou de la blessure; et

- le client a présenté le certificat médical requis confirmant le retour au travail (RAT) progressif; et

- le client est admissible à des prestations de maladie pour la période lors de laquelle il est incapable de travailler en raison d’une maladie, d’une blessure ou d’une mise en quarantaine.

**Modification de la date de retour au travail**

Un agent de Niveau 1 peut rendre la décision d’annuler la date de RAT pour continuer le paiement de prestations régulières quand :

- le motif pour ne pas retourner au travail peut être autorisé au Niveau 1; et

- il n’y a aucune inadmissibilité, aucune exclusion, ou aucun TM en attente de traitement au dossier; et

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi.

Un agent de Niveau 1 peut rendre la décision d’annuler la date de RAT pour continuer le paiement de prestations de maladie quand :

- le motif pour ne pas retourner au travail est une maladie, une blessure ou une mise en quarantaine; et

- il n’y a aucune inadmissibilité ou aucun TM en attente de traitement au dossier; et

- le client présente un certificat médical dont la période d’incapacité est au-delà de la date de RAT; et

- le client aurait été autrement disponible s’il n’avait pas eu de maladie, de blessure ou de mise en quarantaine.

Un agent de Niveau 1 peut rendre la décision d’annuler la date de RAT pour continuer le paiement de prestations de maternité, parentales, pour proches aidants ou des PDC quand :

- le motif pour ne pas retourner au travail peut être autorisé au Niveau 1; et

- il n’y a aucune inadmissibilité ou aucun TM en attente de traitement au dossier; et

- si le client demande des prestations parentales, pour proches aidants ou des PDC, il continue à fournir des soins ou du soutien au membre de la famille.

Un agent de Niveau 1 peut rendre la décision d’annuler la date de RAT pour convertir la demande vers un autre GP quand :

- le motif pour ne pas retourner au travail peut être autorisé au Niveau 1; et

- le client remplit les conditions requises pour être admissible au GP demandé; et

- le client remplit toutes les conditions liées à la disponibilité ou au client autrement disponible.

**Conversions**

**Prestations spéciales vers des prestations régulières**

Un agent de Niveau 1 peut rendre la décision de convertir une demande de prestations spéciales en prestations régulières quand :

- le client recevait des prestations régulières avant le versement des prestations spéciales; ou

- le motif pour ne pas retourner au travail peut être autorisé au Niveau 1; et

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi.

**Prestations d’apprenti vers des prestations régulières**

Un agent de Niveau 1 peut rendre la décision de convertir une demande de prestations d’apprenti en prestations régulières quand :

- le client a reçu des prestations régulières avant le début de la formation en apprentissage; ou

- le motif pour ne pas retourner au travail peut être autorisé au Niveau 1; et

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi.

**4. Conflits collectifs — LAE36**

Un agent de Niveau 1 peut mettre en œuvre la décision d’imposer une inadmissibilité ou de terminer l’inadmissibilité imposée à un groupe de clients ayant perdu leur emploi en raison d’un arrêt de travail entraîné par un conflit collectif à leur lieu de travail.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0335.dita) 

**5. Incarcération — LAE37(a);152.2(a)**

Un agent de Niveau 1 peut rendre la décision d’imposer une inadmissibilité quand :

- le client est incarcéré; et

- il n’y a pas de conditions permettant au client de s’éloigner de l’établissement; et

- aucune prestation n’a été versée pour la période d’incarcération; ou

- si des prestations ont été versées, le client communique avec Service Canada dans les 6 semaines suivant la présentation de sa déclaration du prestataire couvrant la période de l’incarcération.

Un agent de Niveau 1 peut rendre la décision de terminer l’inadmissibilité quand :

- le client n’est plus incarcéré; et

- le client est capable et disponible pour travailler et il ne pose aucune restriction quant à l’acceptation d’un emploi.

Un agent de Niveau 1 peut rendre la décision de terminer l’inadmissibilité dans une demande renouvelée quand l’incarcération a pris fin avant la date de renouvellement.

**6. Hors Canada — LAE37(b);152.2(b); RAE55;55.01**

**Période autorisée**

Un agent de Niveau 1 peut rendre la décision d’autoriser la période entière pendant laquelle le client est à l’extérieur du Canada quand :

- le client est admissible à des prestations de maternité, parentales, pour proches aidants ou des PDC.

**Période de 7 jours autorisée**

Un agent de Niveau 1 peut rendre la décision d’autoriser le versement de prestations pendant un maximum de 7 jours civils consécutifs alors que le client est hors Canada :

- pour assister aux funérailles d’un membre de la famille immédiate (RAE 55 [2]) ou l’une des personnes définies en vertu du RAE 55 (1)(b) ; ou
         [(RAE 55 [2])](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-55.html) 
         [RAE 55 (1)(b)](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-55.html)

- pour rendre visite à un membre de la famille immédiate (RAE 55[2]) gravement malade ou blessé; ou
         [(RAE 55[2])](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-55.html)

- pour accompagner un membre de la famille immédiate dans un établissement agréé afin qu’il y reçoive un traitement médical qui n’est pas facilement ou immédiatement disponible dans la région de résidence du membre de la famille au Canada; et

- aucune prestation n’a été versée; ou

- si des prestations ont été versées et que le client communique avec Service Canada dans les 6 semaines suivant la présentation de sa déclaration du prestataire; et

- le client a pris des dispositions pour être joint en cas d’offres d’emploi et pouvait revenir dans les 48 heures en cas d’offre d’emploi

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0336.dita) 

**Période de 14 jours autorisée**

Un agent de Niveau 1 peut rendre la décision d’autoriser le versement des prestations pour une période allant jusqu’à 7 jours supplémentaires pendant que le client est hors Canada quand :

- le client rend visite à un membre de la famille immédiate (RAE 55[2]) gravement malade ou blessé; et
         [(RAE 55[2])](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-55.html)

- ce membre de la famille immédiate décède et le client reste hors Canada pour assister à ses funérailles; et

- si des prestations ont été versées, le client communique avec Service Canada dans les 6 semaines suivant la présentation de la déclaration du prestataire; et

- le client a pris des dispositions pour être joint en cas d’offres d’emploi et pouvait revenir dans les 48 heures en cas d’offre d’emploi.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0337.dita) 

**Imposer une inadmissibilité après le 7e jour**

Un agent de Niveau 1 peut rendre la décision d’imposer une inadmissibilité déterminée ou indéterminée pour avoir été hors Canada à partir du 8e jour suivant la date de son départ quand :

- le client doit s’absenter pour assister aux funérailles d’un membre de la famille immédiate (RAE 55(2)) ou l’une des personnes définies dans le RAE 55(1)b) ; ou
         [(RAE 55(2))](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-55.html) 
         [RAE 55(1)b)](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-55.html)

- le client s’absente pour rendre visite à un membre de la famille immédiate (RAE 55(2)) gravement malade ou blessé; ou
         [(RAE 55(2))](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-55.html)

- le client s’absente pour accompagner un membre de la famille immédiate, qui reçoit un traitement médical d’une institution agréé qui n’est pas facilement ou immédiatement accessible dans la région; et

- aucune prestation n’a été versée à partir du 8e jour suivant la date de départ; ou

- si des prestations ont été versées, le client communique avec Service Canada dans les 6 semaines suivant la présentation de la déclaration du prestataire.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0338.dita) 

**Imposer une inadmissibilité après le 14e jour**

Un agent de Niveau 1 peut rendre la décision d’imposer à un client une inadmissibilité déterminée ou indéterminée pour avoir été hors Canada à partir du 15e jour suivant la période de 14 jours précédemment autorisée quand :

- les prestations du client ont été autorisées pour un maximum de 7 jours pour rendre visite à un membre de la famille immédiate (RAE 55[2]) gravement malade ou blessé; et
         [(RAE 55[2])](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-55.html)

- ce membre de la famille immédiate (RAE 55(2)) décède et le client reste hors Canada pour assister à ses funérailles; et
         [(RAE 55(2))](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-55.html)

- aucune prestation n’a été versée à partir du 15e jour; ou

- si des prestations ont été versées, le client communique avec Service Canada dans les 6 semaines suivant la présentation de la déclaration du prestataire.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0339.dita) 

**Imposer une inadmissibilité pour toute la période**

Un agent de Niveau 1 peut rendre la décision d’imposer à un client une inadmissibilité pour avoir été hors Canada à partir du jour suivant la date de départ quand :

- les motifs du client pour son séjour hors Canada ne font pas partie des exceptions prévues en vertu du RAE 55 ; et
         [RAE 55](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-55.html)

- aucune prestation n’a été versée; ou

- si des prestations ont été versées, le client communique avec Service Canada dans les 6 semaines suivant la présentation de la déclaration du prestataire.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0338.dita) 

**Terminer une inadmissibilité**

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité pour avoir été hors Canada quand :

- le client communique avec Service Canada dans les 6 semaines suivant la date de retour; et

- le client déclare être disponible à partir de la date de retour ou après.

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité dans une demande renouvelée pour avoir été hors Canada quand :

- l’inadmissibilité a initialement été imposée parce que le client était hors Canada; et

- l’inadmissibilité ne s’applique plus parce que le client est revenu au Canada avant la date de renouvellement.

**7. Rémunération et Correction d’erreur— LAE ;54(s); RAE35;35(2);36;37;38**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0340.dita) 

**Rémunération autre que celle provenant d’un travail indépendant (TI)**

Un agent de Niveau 1 peut rendre la décision de répartir une rémunération (répartition initiale ou correction) quand :

- il n’y a aucun doute que les sommes payées ou payables sont une rémunération aux fins de l’AE; et

- il n’y a aucun doute quant à la période pour laquelle ces sommes doivent être réparties; et

- la demande de correction est présentée et traitée dans un délai de 36 mois à partir de la semaine pour laquelle les prestations étaient payées ou payables; et

- s'il s’agit d’une correction, il n’y a aucune enquête en cours auprès d’Intégrité au dossier.

**Rémunération provenant d’un TI (y compris les activités agricoles), de profits d’une entreprise ou de commissions**

Un agent de Niveau 1 peut rendre la décision de répartir la rémunération (répartition initiale ou correction) d’un TI (y compris les activités agricoles), de profits d’une entreprise ou de commissions quand :

- le TI est déjà considéré comme étant exercé dans une mesure limitée pour la période pour laquelle la rémunération serait répartie ; ou

- le client a établi une demande en vertu de la PARTIE VII.1 - Prestations pour les travailleurs indépendants; et
         [PARTIE VII.1](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-152.01.html)

- il n’y a aucun doute quant au fait que les sommes payées ou payables constituent une rémunération aux fins de l’AE; et

- il n’y a aucun doute quant à la période sur laquelle ces sommes doivent être réparties; et

- le client fournit sa rémunération nette; et

- la demande de correction est présentée et traitée dans un délai de 36 mois à partir de la semaine pour laquelle les prestations étaient payées ou payables; et

- S’il s’agit d’une correction, il n’y a aucune enquête en cours auprès d’Intégrité au dossier.

**Correction autre que la rémunération**

Un agent de Niveau 1 peut rendre la décision de corriger des renseignements autres que ceux liés à la rémunération quand :

- la demande de correction est présentée dans les 6 semaines suivant le traitement de la déclaration du prestataire initiale.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0341.dita) 

**Correction avec l’exemption des déclarations du prestataire**

Un agent de Niveau 1 peut rendre la décision de corriger des renseignements reçus pour une période durant laquelle le prestataire était exempté de remplir des déclarations du prestataire quand:

- la demande de correction est présentée dans les 6 semaines suivant la semaine de l’émission du dernier paiement de la période d’exemption.

**8. Congédiement et suspension — LAE30;31**

**Congédiement**

Un agent de Niveau 1 peut rendre la décision d’autoriser un congédiement dans tous les genres de demande (GD) quand :

- le client indique qu’il a été congédié pour inaptitude ou pour un manque de travail; et

- l’employeur, quand il est contacté, confirme que le client n’était pas apte à occuper le poste et qu’il n’y avait pas eu d’inconduite; ou

- un commentaire dans le RE confirme que le congédiement est dû au fait que le client n’était pas apte à occuper le poste, qu’il n’a pas réussi la formation ou qu’il a été congédié au cours de la période de probation; et

- il n’y a aucune autre question litigieuse liée au congédiement qui pourrait empêcher l’agent de Niveau 1 d’autoriser le MCE.

Un agent de Niveau 1 peut rendre la décision d’autoriser le congédiement dans une demande initiale ou renouvelée quand :

- le client a travaillé pour l’employeur pendant 12 semaines ou moins; et

- le client n’a pas fourni de détails sur cet emploi dans la demande d’AE; et

- l’employeur, quand il est contacté, confirme que le client n’était pas apte à occuper le poste et qu’il n’y avait pas eu d’inconduite; ou

- un commentaire dans le RE confirme que le congédiement est dû au fait que le client n’était pas apte à occuper le poste, qu’il n’a pas réussi la formation ou qu’il a été congédié au cours de la période de probation; et

- il n’y a aucune autre question litigieuse liée au congédiement qui pourrait empêcher l’agent de Niveau 1 d’autoriser le MCE.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0342.dita) 

**Suspension**

Un agent de Niveau 1 peut rendre la décision dans une demande renouvelée de terminer une inadmissibilité imposée pour une période pendant laquelle le client est suspendu quand :

- la période de suspension a pris fin; ou

- le client a été mis à pied; ou

- le motif pour lequel il n’est pas retourné au travail peut être autorisé au Niveau 1; ou

- le client a accumulé suffisamment d’heures assurables auprès d’un autre employeur après le début de la période de suspension pour remplir les conditions requises pour le GP demandé.

**9. Départ volontaire et congé autorisé — LAE29;32;34; RAE51.1**

**Départ volontaire**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0343.dita) 

**Déménagement du conjoint**

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire en raison du déménagement du conjoint quand :

- la décision de déménager est liée à l’emploi du conjoint; et

- le déménagement dans la nouvelle résidence est prévu pour une période d’au moins un an; et

- le trajet pour se rendre au travail aurait duré une heure ou plus; et

- le client a déménagé dans les 4 semaines suivant son dernier jour de travail (DJT); et

- il n’y a aucune question litigieuse liée au départ volontaire qui empêcherait l’agent de Niveau 1 d’autoriser le MCE.

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire en raison du déménagement d’un conjoint de fait avec lequel le client réside depuis moins d’un an :

- le client ou le conjoint de fait a donné naissance ou adopté un enfant quand ils vivaient ensemble dans une relation conjugale; ou

- la cliente ou la conjointe de fait attend la naissance d’un enfant; et

- la décision de déménager est liée à l’emploi du conjoint de fait; et

- le déménagement dans la nouvelle résidence est prévu pour une période d’au moins un an; et

- le trajet pour se rendre au travail aurait duré une heure ou plus; et

- le client a déménagé dans les 4 semaines suivant son DJT; et

- il n’y a aucune question litigieuse liée au départ volontaire qui empêcherait l’agent de Niveau 1 d’autoriser le MCE.

**Mariage prévu**

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire en raison d’un déménagement en prévision d’un mariage quand :

- le client s’est marié ou a fixé la date de son mariage dans les 4 semaines qui suivent son DJT; et

- le trajet pour se rendre au travail aurait duré une heure ou plus; et

- le client a déménagé dans les 4 semaines suivant le DJT; et

- il n’y a aucune question litigieuse liée au départ volontaire qui empêcherait l’agent de Niveau 1 d’autoriser le MCE.

**Déménagement d’une personne à charge**

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire en raison du déménagement d’un enfant à charge pour des raisons médicales quand :

- la condition médicale de l’enfant à charge oblige le client à déménager; et

- le client présente des documents médicaux confirmant que l’enfant à charge nécessite un traitement dans un centre ou auprès d’un médecin spécialiste hors de la région de résidence habituelle; et

- le déménagement à la nouvelle résidence est prévu pour une période d’au moins un an; et

- le trajet pour se rendre au travail aurait duré une heure ou plus; et

- le client a déménagé dans les 4 semaines suivant son DJT; et

- il n’y a aucune question litigieuse liée au départ volontaire qui empêcherait l’agent de Niveau 1 d’autoriser le MCE.

**Déménagement d’un parent ou d’un tuteur légal**

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire en raison du déménagement d’un parent ou d’un tuteur légal quand :

- le client avait moins de 18 ans immédiatement avant le déménagement; et

- le client habitait avec un parent ou un tuteur légal immédiatement avant le déménagement; et

- le trajet pour se rendre au travail aurait duré une heure ou plus; et

- le client a déménagé dans les 4 semaines suivant son DJT; et

- il n’y a aucune question litigieuse liée au départ volontaire qui empêcherait l’agent de Niveau 1 d’autoriser le MCE.

**Emploi simultané**

Un agent de Niveau 1 peut rendre la décision d’autoriser un départ volontaire pour tous les GD quand :

- le client avait plus d’un emploi en même temps et a quitté volontairement l’un d’eux; et

- l’emploi que le client a gardé était à temps plein et le client ne s’attendait pas à ce qu’il prenne fin.

**Promesse d’emploi**

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire pour accepter un autre emploi permanent dans une demande initiale ou renouvelée quand :

- le client avait une véritable offre d’emploi dont le début était prévu dans les 2 semaines suivant le DJT de l’emploi précédent. Une confirmation de l’employeur éventuel est requise; et

- le client n’a pas commencé le nouvel emploi parce que l’offre a été retirée ou annulée pour des motifs qui ne sont pas liés au client ou à ses actions. Une confirmation de l’employeur éventuel est requise; et

- le client n’a pas été en mesure de retirer sa démission de l’emploi précédent et y retourner; et

- le nouvel emploi devait être permanent; et

- le nombre d’heures hebdomadaire dans le nouvel emploi aurait été égal ou supérieur au nombre d’heures hebdomadaires travaillées dans l’emploi précédent; et

- il n’y a aucune question litigieuse liée au départ volontaire qui empêcherait l’agent de Niveau 1 d’autoriser le MCE.

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire pour accepter un autre emploi temporaire dans une demande initiale ou renouvelée quand :

- le client avait une véritable offre d’emploi dont le début était prévu dans les 2 semaines suivant le DJT de l’emploi précédent. Une confirmation de l’employeur éventuel est requise; et

- le client n’a pas commencé le nouvel emploi parce que l’offre a été retirée ou annulée pour des motifs qui ne sont pas liés au client ou à ses actions. Une confirmation de l’employeur éventuel est requise; et

- le client n’a pas été en mesure de retirer sa démission de l’emploi précédent et y retourner; et

- le client a quitté un emploi temporaire pour un autre emploi temporaire; et

- le nouvel emploi temporaire était censé avoir la même durée ou une durée plus longue que l’emploi temporaire précédent; et

- le nombre d’heures hebdomadaire dans le nouvel emploi aurait été égal ou supérieur au nombre d’heures hebdomadaires travaillées dans l’emploi précédent; et

- il n’y a aucune question litigieuse liée au départ volontaire qui empêcherait l’agent de Niveau 1 d’autoriser le MCE.

**Accepter un autre emploi**

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire pour accepter un autre emploi dans une demande initiale ou renouvelée quand :

- le nouvel emploi a débuté dans les 4 semaines suivant le DJT de l’emploi précédent; et

- le DPP ou la semaine de renouvellement est après la semaine dans laquelle le nouvel emploi a commencé; et

- le nouvel emploi devait être permanent; ou

- si le nouvel emploi est temporaire, il doit durer plus longtemps que l’emploi que le client a quitté; et

- le nombre d’heures hebdomadaire dans le nouvel emploi aurait été égal ou supérieur au nombre d’heures hebdomadaires travaillées dans l’emploi précédent; et

- il n’y a aucune question litigieuse liée au départ volontaire qui empêcherait l’agent de Niveau 1 d’autoriser le MCE.

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire pour accepter un autre emploi dans une demande continue quand :

- le nouvel emploi devait être permanent; et

- il n’y a pas eu plus de 4 jours d’écart entre le premier jour travaillé dans le nouvel emploi et le DJT de l’emploi précédent; ou

- le premier jour de travail dans le nouvel emploi a commencé avant le DJT de l’emploi précédent; et

- le nombre d’heures hebdomadaire dans le nouvel emploi était égal ou supérieur au nombre d’heures hebdomadaires travaillées dans l’emploi précédent; et

- il n’y a aucune question litigieuse liée au départ volontaire qui empêcherait l’agent de Niveau 1 d’autoriser le MCE.

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire d’un emploi temporaire pour accepter un autre emploi temporaire dans une demande continue quand :

- le nouvel emploi temporaire devait durer plus longtemps que l’emploi temporaire précédent; et

- il n’y a pas eu plus de 4 jours d’écart entre le premier jour de travail dans le nouvel emploi et le DJT de l’emploi précédent; ou

- le premier jour de travail du nouvel emploi a commencé avant le DJT de l’emploi précédent; et

- le nombre d’heures hebdomadaire dans le nouvel emploi était égal ou supérieur au nombre d’heures hebdomadaires travaillées dans l’emploi précédent; et

- il n’y a aucune question litigieuse liée au départ volontaire qui empêcherait l’agent de Niveau 1 d’autoriser le MCE.

**Travail indépendant**

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire pour commencer des activités de TI dans une demande initiale ou renouvelée quand :

- les activités de TI ou l’exploitation de l’entreprise ont commencé dans les 2 semaines suivant la date à laquelle le client a quitté son emploi; et

- le client a arrêté les activités de TI ou a cessé l’exploitation de son entreprise; et

- le DPP ou la semaine de renouvellement est après la semaine de début des activités de TI ou de l’entreprise; et

- le client ne demande aucune prestation pendant la période de TI ou d’exploitation de son entreprise; et

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi.

**Réduction des effectifs**

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire qui fait partie d’un programme de réduction des effectifs approuvé en vertu du RAE 51 .
       [RAE 51](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-51.html)

**Cours de formation dirigé ou activité d’emploi**

Un agent de Niveau 1 peut rendre la décision d’autoriser le départ volontaire pour participer à un cours de formation dirigé ou à une activité d’emploi :

- une autorité désignée par Service Canada a dirigé le client vers le cours de formation ou une activité d’emploi avant le départ volontaire; et

- l’autorité désignée a approuvé le départ volontaire; et

- le cours de formation dirigé ou l’activité d’emploi a débuté dans les 2 semaines suivant la date du départ volontaire; et

- le DPP ou la semaine de renouvellement est la même que la semaine du départ volontaire, ou après.

**Raisons médicales**

Un agent de Niveau 1 peut rendre la décision d’autoriser un départ volontaire pour des raisons médicales quand :

- le client a présenté un certificat médical ou un autre document similaire rempli par un médecin ou un autre professionnel de la santé recommandant que le client quitte son emploi. Aucune confirmation de l’employeur n’est requise; ou

- le client a présenté un certificat médical ou un autre document similaire pour une situation médicale temporaire, mais un congé autorisé n’a pas pu être obtenu auprès de l’employeur. L’employeur doit confirmer qu’il n’y avait pas d’autres postes appropriés disponibles pour le client et qu’un congé ne pouvait pas être autorisé.

**Période de congé**

Un agent de Niveau 1 peut rendre la décision d’autoriser une période de congé dans une demande initiale ou renouvelée pour un RE qui n’est pas le dernier RE quand :

- le client ne demande pas de prestations pour la période de congé; et

- le client a repris le travail pour le même employeur après la période de congé et est ensuite mis à pied ou cesse de travailler pour un motif qui peut être autorisé au Niveau 1; ou

- le client n’a pas repris le travail et le MCE peut être autorisé au Niveau 1; ou

- le client a accumulé suffisamment d’heures assurables auprès d’un autre employeur après le début de la période de congé pour remplir les conditions requises pour recevoir des prestations.

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité imposée dans une demande renouvelée pour une période de congé antérieure quand :

- le client a repris le travail auprès du même employeur après la période de congé, puis a été mis à pied ou a cessé de travailler pour un motif qui peut être autorisé au Niveau 1; ou

- le client n’a pas repris le travail pour un motif qui peut être autorisé au Niveau 1; ou

- le client a accumulé suffisamment d’heures assurables auprès d’un autre employeur après le début de la période de congé pour remplir les conditions requises pour recevoir des prestations.

**10. Non en chômage — LAE9;11**

**Travail indépendant et activités agricoles**

Un agent de Niveau 1 peut considérer que le TI est exercé dans une mesure limitée dans une demande initiale quand :

- l’entreprise est fermée de façon définitive; et

- toutes les activités et opérations ont cessé avant le DPP.

Un agent de Niveau 1 peut considérer que le TI (y compris les activités agricoles) est exercé dans une mesure limitée dans une demande renouvelée quand :

- le TI (y compris les activités agricoles) a été préalablement autorisé au Niveau 2 dans la demande initiale; et

- il n’y a eu aucune modification des circonstances et des faits liés au TI (y compris les activités agricoles) depuis la décision dans la demande initiale.

Un agent de Niveau 1 peut considérer que le TI est exercé dans une mesure limitée pour un client qui a travaillé pour un ami ou un membre de la famille quand :

- le client reçoit des prestations régulières; et

- l’ami ou le membre de la famille n’est pas le propriétaire d’une entreprise liée au genre d’activités exercées; et

- le client n’a pas travaillé plus de 3 jours consécutifs; et

- le client n’a pas précédemment déclaré avoir travaillé pour un ami ou un membre de la famille; et

- le client n’a pas lancé une entreprise ou n’est pas propriétaire d’une entreprise; et

- le client est disponible et cherche un emploi à temps plein; et

- le client est prêt à arrêter d’aider l’ami ou le membre de la famille pour accepter un emploi convenable; et

- toute somme gagnée en travaillant pour l’ami ou le membre de la famille a été déclarée et a été payée par cette personne et non par une entreprise.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0344.dita) 

Un agent de Niveau 1 peut considérer que le TI (sans inclure les activités agricoles) est exercé dans une mesure limitée dans une demande de prestations régulières quand :

- le montant total que le client a personnellement investi dans les éléments suivants ne dépasse pas 25 000 $ :

- locaux;

- équipement;

- inventaire;

- réinvestissement; et

- le revenu annuel brut provenant du TI est inférieur ou égal à 10 000 $; et

- aucun employé ne travaille dans l’entreprise; et

- les activités de TI du client ont diminué ou sont restées constantes au cours des 3 dernières années; et

- le client effectuait ses activités de TI pendant qu’il occupait un emploi assurable à temps plein; et

- le client investit moins de 15 heures par semaine dans ses activités de TI; et

- le client ne considère pas le TI comme sa principale source de revenus; et

- le client ne tente pas faire du TI sa principale source de revenus; et

- l’intention du client est de trouver un emploi assurable à temps plein; et

- le client est à la recherche d’un emploi assurable à temps plein.

Un agent de Niveau 1 peut considérer que le TI (sans inclure les activités agricoles) est exercé dans une mesure limitée dans une demande de prestations de maternité, de prestations parentales, pour proche aidant ou de PDC quand :

- le montant total que le client a personnellement investi dans les éléments suivants ne dépasse pas 25 000 $ :

- locaux;

- équipement;

- inventaire;

- réinvestissement; et

- le revenu annuel brut provenant du TI est inférieur ou égal à 10 000 $; et

- aucun employé ne travaille dans l’entreprise; et

- les activités de TI du client ont diminué ou sont restées constantes au cours des 3 dernières années; et

- le client effectuait ses activités de TI pendant qu’il occupait un emploi assurable à temps plein; et

- le client consacre moins de 15 heures par semaine dans ses activités de TI; et

- le client ne considère pas l’activité de TI comme sa principale source de revenus; et

- le client ne tente pas faire du TI sa principale source de revenus; et

- le client demande des prestations parentales et de pouvoir mener des activités de TI dans un lieu qui lui permet de fournir des soins à l’enfant; ou

- le client demande des prestations pour proche aidant ou des PDC et effectue des activités de TI dans un lieu qui lui permet d’offrir des soins ou du soutien au patient.

Un agent de Niveau 1 peut considérer qu’une activité agricole est exercée dans une mesure limitée quand :

- le revenu des activités agricoles provient seulement de la location de terres; ou

- le client n’exploite plus la ferme et les activités agricoles ont cessé avant le DPP.

Un agent de Niveau 1 peut considérer qu’une activité agricole est exercée dans une mesure limitée quand :

- le revenu agricole brut est inférieur ou égal à 25 000 $; et

- le client a exploité la ferme pendant qu’il occupait un emploi assurable à temps plein; et

- les activités de la ferme ont diminuées ou sont restées constantes au cours des 3 dernières années; et

- le client est disponible pour travailler à temps plein pendant les périodes d’avril à septembre et d’octobre à mars; et

- l’agriculture n’est pas la principale source de revenus du client.

**Non en chômage**

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité imposée pour une période pendant laquelle le client travaillait en vertu d’un contrat de louage de services quand :

- le contrat a pris fin; et

- l’inadmissibilité est terminée à compter de la date à laquelle le contrat a pris fin; et

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi.

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité 1 - Non en chômage (D1) dans une demande renouvelée quand :

- l’inadmissibilité D1 a précédemment été imposée puisque le client exerçait un emploi assurable quand il a demandé des prestations; et

- le client confirme qu’il n’est plus employé auprès de cet employeur; et

- le client est capable et disponible pour travailler et ne pose aucune restriction quant à l’acceptation d’un emploi.

**11. Enseignants demandant des prestations pendant une période de congé scolaire — RAE33**

Un agent de Niveau 1 peut rendre la décision d’autoriser les prestations pendant une période de congé scolaire quand :

- le client demande des prestations de maternité, parentales, pour proches aidants ou des PDC; ou

- la totalité de l’emploi d’enseignant du client au cours de la période de référence (PR) était comme suppléant, sur appel ou sur une base occasionnelle au cours de la période d’enseignement; et

- le client n’a pas de contrat signé ou verbal pour une période d’enseignement subséquente; ou

- le client avait un contrat qui a pris fin; et

- le client n’a pas de contrat signé ou verbal pour une période d’enseignement subséquente.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0345.dita) 

**12. Prestations parentales et décès de l’enfant ― LAE23**

Un agent de Niveau 1 peut rendre la décision d’imposer une inadmissibilité 34 - Prestations parentales conditions d’admissibilité non rencontrées (D34) quand :

- l’enfant pour lequel le client demandait des prestations parentales est décédé; et

- le client accepte qu’aucune prestation ne soit versée à compter du lundi suivant la semaine du décès de l’enfant; et

- si des prestations parentales ont été versées après la semaine du décès de l’enfant, le client communique avec Service Canada dans les 6 semaines suivant la date de traitement de la déclaration du prestataire.

Un agent de Niveau 1 peut rendre la décision d’annuler ou de terminer une inadmissibilité D34 imposée en raison du décès d’un enfant quand :

- le client demande un autre GP que des prestations parentales et y est admissible; ou

- le client est admissible aux prestations parentales parce qu’il prend soin d’un autre enfant.

**13. Modification d’une inadmissibilité existante — Prestations spéciales**

Un agent de Niveau 1 peut rendre la décision d’annuler, modifier ou de terminer une inadmissibilité dans une demande continue ou renouvelée de prestations spéciales quand :

- le client est admissible au GP demandé; et

- le client a présenté tous les documents requis pour la période pendant laquelle les prestations spéciales sont demandées; et

- si le client demande des prestations de maladie, l’inadmissibilité n’est pas liée aux questions de client non disponible, non autrement disponible, de TI ou de conflit de travail.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0346.dita) 

Un agent de Niveau 1 peut rendre la décision d’autoriser les prestations spéciales dans une demande continue ou renouvelée quand :

- il y a une exclusion ou inadmissibilité en attente de traitement dans la demande en raison d’un MCE litigieux; et

- le client est admissible à recevoir le GP demandé; et

- le client a présenté tous les documents requis pour la période pendant laquelle les prestations spéciales sont demandées; et

- le client demande des prestations après la semaine du DPP.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0347.dita) 

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité dans une demande de PDC pour autoriser un autre GP dans une demande continue ou renouvelée quand :

- le client demande une conversion de PDC à un autre GP; et

- il y a une inadmissibilité 51 - Ne satisfait pas aux conditions d’admissibilité aux soins de compassion (D51), une inadmissibilité 52 - Prestations de soins de compassion épuisées (D52) ou une inadmissibilité 53 - Prestations de soins de compassion - Aucune preuve médicale (D53) au dossier; et

- la date à partir de laquelle le client demande la conversion est après les semaines de PDC demandées; et

- le client remplit toutes les conditions d’admissibilité pour le GP demandé; et

- si le client demande des prestations régulières ou de maladie, il n’y a aucune inadmissibilité au dossier liée à la disponibilité, aux clients non autrement disponibles, au TI ou à un conflit de travail; et

- si le client demande des prestations régulières, le motif pour ne pas retourner au travail peut être autorisé au Niveau 1; ou

- si le client demande des prestations spéciales, le motif pour ne pas retourner au travail peut être accordé au Niveau 1 et est lié au GP demandé.

Un agent de Niveau 1 peut rendre la décision de terminer une inadmissibilité dans une demande de prestations pour proches aidants pour autoriser un autre GP dans une demande continue ou renouvelée quand :

- le client demande une conversion des prestations pour proche aidant à un autre GP; et

- il y a une inadmissibilité 61 - Proches aidants d’enfants ou d’adultes - Ne rencontre pas les conditions d’admissibilité (D61), une inadmissibilité 62 - Proches aidants d’enfants ou d’adultes - Prestations épuisées (D62) ou une inadmissibilité 63 - Proches aidants d’enfants ou d’adultes - Aucune preuve médicale (D63) au dossier; et

- la date à partir de laquelle le client demande la conversion est après la date la plus tardive entre le nombre de semaines demandées ou la date de soins ou de soutien requis sur le certificat médical; et

- le client remplit les conditions d’admissibilité pour le GP demandé; et

- si le client demande des prestations régulières ou de maladie, il n’y a aucune inadmissibilité au dossier liée à la disponibilité, aux clients non autrement disponibles, à un TI ou à un conflit de travail; et

- si le client demande des prestations régulières, le motif pour ne pas retourner au travail peut être autorisé au Niveau 1; ou

- si des prestations spéciales sont demandées, le motif pour ne pas retourner au travail peut être autorisé au Niveau 1 et est lié au GP demandé.

**14. Révision — LAE52;112**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0348.dita) 

Un agent de Niveau 1 peut rendre la décision de réviser une demande en vertu de la LAE 52 quand :
       [LAE 52](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-52.html)

- la décision initiale a été rendue par un agent de Niveau 1, et qu’il avait l’autorité pour rendre cette décision : et

- la révision est nécessaire parce que de nouveaux renseignements ont été reçus; ou

- la révision est nécessaire pour corriger une erreur qui se veut contraire à la structure de la Loi ; et
         [contraire à la structure de la Loi](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-17/reexamen-politique.html#a17_3_3_2)

- les nouveaux renseignements sont reçus ou l’erreur est découverte et traitée dans le délai de révision de 36 mois; ou

- si les nouveaux renseignements sont reçus après le délai de révision de 36 mois, un RD de Niveau 2 est au dossier, prolongeant le délai à 72 mois.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0349.dita) 

Un agent de Niveau 1 peut rendre la décision de maintenir, de modifier ou d’annuler une décision initiale quand :

- une demande de révision formelle a été reçue en vertu de la LAE 112; et

- l’agent de Niveau 1 avait le pouvoir de rendre la décision initiale et l’a rendue; ou

- un ASP des services d’Intégrité, ou un ASI, a effectué une enquête comprenant une répartition de rémunération, qui n’a pas entraîné de lettre d’avertissement, d’avis de violation ou de pénalité; et

- l’agent rendant la décision a suivi une formation formelle sur les demandes de révision; et

- la demande de révision a été reçue dans le délai prescrit de 30 jours; ou

- si la demande de révision a été retardée, elle a été reçue dans les 120 jours après que l’individu ait été avisé de la décision initiale.

**15. Demandes de prestation d’urgence de l’AE (PU AE) — LAE52;112;153.5(2) et (3);153.6(1);153.9(1), (2) et (4);153.1303(Mesure temporaire)**

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0350.dita) 

Un agent de Niveau 1 peut rendre une décision d’imposer une inadmissibilité 31 - PU AE ne rencontre pas les conditions d’admissibilité (D31) de façon rétroactive dans une demande pour la PU AE quand :

- une lettre de demande de précisions (c.-à-d. C-74-01-03 ou C-74-01-06/07) a été envoyée au client; et

- le client n’a pas répondu à la lettre et celle-ci n’a pas été retournée comme non livrable; ou

- le client a répondu à la lettre et ne conteste pas son inadmissibilité à la PU AE qui lui a été versé; et

- le client n’avait pas 5 000 $ en rémunération assurable en 2019 ou dans les 52 semaines précédant la date à laquelle il a présenté sa demande pour la PU AE; et

- le client n’aurait pas pu établir une PP en vertu de la LAE 153.5(2)(b) ; et
         [LAE 153.5(2)(b)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.5.html)

- la demande pour la PU AE en cours de révision est dans les 36 mois suivant la date à laquelle les prestations ont été payées ou étaient payables; et

- le client ne remplit pas les conditions d’admissibilité pour une partie ou l’entièreté de la période de la demande pour la PU AE; et

- il n’y aucune question litigieuse qui pourrait empêcher l’agent de Niveau 1 d’imposer l’inadmissibilité D31.

Un agent de Niveau 1 peut considérer une demande pour la PU AE en ordre quand :

- le client remplit les conditions d’admissibilité pour la période de 2 semaines de la demande pour la PU AE en :

- répondant à l’une des définitions de prestataire en vertu de la LAE 153.5(2) ; et
             [LAE 153.5(2)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.5.html)

- remplissant les conditions d’admissibilité connexes en vertu de la LAE 153.9(1) ; et
             [LAE 153.9(1)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.9.html)

- il n’y a pas d’autres circonstances qui rendraient le client inadmissible en vertu de la LAE 153.9 .
         [LAE 153.9](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.9.html)

Un agent de Niveau 1 peut rendre la décision d’annuler une inadmissibilité D31 quand :

- l’agent de Niveau 1 a imposé l’inadmissibilité D31 par erreur; et

- le client n’a pas fourni de nouveaux renseignements; et

- l’agent de Niveau 1 a imposé l’inadmissibilité D31 par erreur selon les renseignements disponibles au moment de la décision.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0351.dita) 

Un agent de Niveau 1 peut rendre la décision de maintenir, de modifier ou d’annuler une décision initiale liée à une demande pour la PU AE quand :

- une demande de révision a été reçue en vertu de la LAE 112 ; et
         [LAE 112](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-112.html)

- la demande de révision est liée à une décision dans une demande pour la PU AE en vertu de la LAE 153.5(2) et 153.9(1), (2) ou (4) ; et
         [LAE 153.5(2)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.5.html) 
         [153.9(1), (2) ou (4)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.5.html)

- un agent de Niveau 1 a rendu la décision; ou

- un agent de services aux programmes d’Intégrité ou un agent des services d’Intégrité a rendu la décision dans une enquête liée à la PU AE en vertu de la LAE 153.5(2) et 153.9(1), (2) ou (4) ; et
         [LAE 153.5(2)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.5.html) 
         [153.9(1), (2) ou (4)](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.9.html)

- l’agent qui rend la décision a suivi une formation formelle sur les demandes de révision; et

- la demande de révision a été reçue dans le délai prescrit de 30 jours; ou

- la demande de révision est en retard, mais a été reçue au plus tard 120 jours après la date à laquelle le client a été informé de la décision initiale; et

- il n’y a pas de question litigieuse liée à la demande pour la PU AE qui empêcherait l’agent de Niveau 1 de rendre une décision; et

- il n’y a pas d’enquête d’Intégrité en attente de traitement liée à la PU AE. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0332.dita`

Remarque :

Sauf avis contraire, cette remarque ne s’applique qu’au pouvoir délégué supérieur immédiat et à aucun autre pouvoir délégué. Si le client fournit plusieurs motifs pour le retard dans la présentation de sa demande de prestations, et qu’au moins l’un de ces motifs est dans la liste ci-dessus et couvre toute la période du retard, l’agent de Niveau 1 peut autoriser l’antidate. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0333.dita`

Remarque :

Si le client est hors Canada pour un motif autre que des vacances, l’agent de Niveau 1 consulte la section Hors Canada .
       [Hors Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s6)

     [Hors Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s6) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0334.dita`

Remarque :

Quand un client déclare jusqu’à 9 heures de formation par semaine, un recueil de faits ou un suivi supplémentaire auprès du client n’est pas requis. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0335.dita`

Remarque :

L’agent de Niveau 1 n’a pas le pouvoir de décider d’imposer ou de terminer l’inadmissibilité. L’agent de Niveau 1 a seulement le pouvoir de mettre en œuvre la décision rendue par l’autorité désignée appropriée. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0336.dita`

Remarque :

Quand le client est hors Canada et reçoit des prestations régulières, l’agent responsable de la décision doit aussi rendre une décision sur la disponibilité. L’agent consulte la section Disponibilité de cette politique.
       [Disponibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s3)

     [Disponibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s3) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0337.dita`

Remarque :

Une décision sur la disponibilité doit également être rendue quand le client qui reçoit des prestations régulières se trouve hors Canada. Veuillez consulter la section Disponibilité de la présente politique.
       [Disponibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s3)

Le client n’est admissible à des prestations que pour une durée maximale de 7 jours pour rendre visite à un membre de la famille immédiate gravement malade ou blessé. Les 7 jours supplémentaires pour assister aux funérailles de ce membre de la famille immédiate ne peuvent pas inclure une période précédant son décès. Consulter le paragraphe 10.11.8.1 du Guide de la détermination de l’admissibilité pour obtenir des directives supplémentaires sur la situation décrite ci-dessus et sur le calcul des jours.
       [paragraphe 10.11.8.1 du Guide de la détermination de l’admissibilité](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-10/absence-du-domicile.html#a10_11_8_1)

     [Disponibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s3) 
     [paragraphe 10.11.8.1 du Guide de la détermination de l’admissibilité](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-10/absence-du-domicile.html#a10_11_8_1) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0338.dita`

Remarque :

Une décision sur la disponibilité doit également être rendue quand le client qui reçoit des prestations régulières se trouve hors Canada. Veuillez consulter la section Disponibilité de la présente politique.
       [Disponibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s3)

     [Disponibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s3) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0339.dita`

Remarque :

Une décision sur la disponibilité doit également être rendue quand le client qui reçoit des prestations régulières ou de maladie se trouve hors Canada. Veuillez consulter la section Disponibilité de la présente politique.
       [Disponibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s3)

Consulter le paragraphe 10.11.8.1 du Guide de la détermination de l’admissibilité pour obtenir des directives supplémentaires sur la situation décrite ci-dessus et sur le calcul des jours.
       [paragraphe 10.11.8.1 du Guide de la détermination de l’admissibilité](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-10/absence-du-domicile.html#a10_11_8_1)

     [Disponibilité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s3) 
     [paragraphe 10.11.8.1 du Guide de la détermination de l’admissibilité](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-10/absence-du-domicile.html#a10_11_8_1) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0340.dita`

Remarque :

Cette section de la politique s’applique à la répartition d’une rémunération et la correction d’une déclaration du prestataire. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0341.dita`

Remarque :

Si la demande de correction d’erreur pour les litiges autres que la rémunération, inclus aussi de la rémunération et dépasse le délai de 6 semaines, toute la demande de correction entière (y compris la rémunération) doit être renvoyée au Niveau 2. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0342.dita`

Remarque :

Cette remarque s’applique aux pouvoirs de la section du congédiement. L’agent de Niveau 1 n’a pas besoin de confirmer le motif de congédiement auprès de l’employeur si le commentaire dans le RE est l’un des suivants :

- n’était pas apte à occuper le poste;

- n’a pas réussi la formation;

- a été congédié au cours de la période de probation. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0343.dita`

Remarque :

Les agents rendant des décisions sur les questions liées au départ volontaire doivent différencier l’emploi temporaire et l’emploi permanent de la façon suivante :

- Un emploi temporaire est défini comme étant saisonnier, contractuel ou pour une période déterminée, et comprend une date de fin.

- Un emploi permanent est défini comme étant un emploi durable ou un emploi destiné à durer ou à rester inchangé indéfiniment. Il ne comprend pas de date de fin. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0344.dita`

Remarque :

Quand le client déclare travailler pour un époux, un conjoint de fait ou une personne avec laquelle il entretient une relation amoureuse, l’agent de Niveau 1 réassigne la question au Niveau 2 pour une décision. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0345.dita`

Remarque :

Un agent de Niveau 1 peut autoriser les demandes de prestations de maternité, parentales, pour proches aidants ou de PDC pendant la période d’enseignement. Toutefois, les demandes de prestations régulières ou de maladie présentées par des enseignants sous contrat de service pendant la période d’enseignement doivent être renvoyées à un agent de Niveau 2 pour une décision. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0346.dita`

Remarque :

Un client n’est pas tenu de démontrer un motif valable pour le retard dans la présentation d’un certificat médical. Un agent de Niveau 1 est autorisé à modifier ou à annuler une inadmissibilité existante qui a été imposée pour un certificat médical manquant pour des prestations spéciales, quelle que soit la durée du retard dans la présentation du certificat médical, si les conditions présentées ci-dessus sont remplies. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0347.dita`

Remarque :

Si des prestations de maladie sont demandées et qu’une inadmissibilité a été imposée en raison d’une question de client non disponible (p. ex. un client a quitté volontairement son emploi en raison d’obligations familiales ou a pris un congé afin de suivre un cours de formation non-dirigé), de TI ou de conflit de travail, l’agent de Niveau 1 renvoie la décision au Niveau 2. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0348.dita`

Remarque :

Pour les modifications aux déclarations du prestataire, l’agent consulte la section 7 de cette politique.
       [section 7](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s7)

     [section 7](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes#s7) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0349.dita`

Remarque :

Le délai de révision de 36 mois est calculé à partir de la date à laquelle les prestations ont été versées ou auraient dû être payables. Les erreurs de la Commission sont corrigées à compter de la date courante et aucun T-P ne sera créé, sauf si l’erreur de la Commission a entraîné une décision qui va à l’encontre de la structure de la LAE.

Dans les cas d’un nouveau calcul quand le RE a été présenté en retard, l’agent de Niveau 1 doit d’abord déterminer si le retard peut être autorisé conformément à la politique sur les Niveaux de décision. Si non, une décision de Niveau 2 est requise pour le retard. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0350.dita`

Remarque :

Seuls les agents assignés à une équipe spécialisée traitant les demandes de révision liées à la PU AE ont les pouvoirs suivants.

La LAE 153.8 définit une demande pour la PU AE comme une période de 2 semaines commençant un dimanche entre le 15 mars 2020 et le 3 octobre 2020. Dans le contexte de la PU AE, une demande signifie une période de 2 semaines plutôt qu’une période entière pendant laquelle un client recevait la PU AE.
       [LAE 153.8](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.8.html)

     [LAE 153.8](https://laws-lois.justice.gc.ca/fra/lois/E-5.6/section-153.8.html) 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0351.dita`

Remarque :

Un agent de Niveau 1 ne peut pas utiliser le pouvoir ci-dessus pour rendre une nouvelle décision sur une demande. L’objectif de ce pouvoir est de permettre à un agent de Niveau 1 de corriger une erreur de saisie. Si le client présente de nouveaux renseignements liés à la décision rendue dans sa demande, une révision est nécessaire. Un agent de Niveau 1 ne peut réviser une demande que dans les cas prévus par la Politique sur les niveaux de décision. 

## Contexte

Source topic: `fr_FR/policy/nationalpolicy/levels_decision-annex1/contexte.dita`

## Untitled

Source topic: `fr_FR/policy/nationalpolicy/levels_decision-annex1/untitled.dita`

**** 
