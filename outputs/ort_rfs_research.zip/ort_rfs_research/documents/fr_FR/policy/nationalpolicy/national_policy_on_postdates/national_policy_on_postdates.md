# Politique sur les postdates

Source map: `fr_FR/policy/nationalpolicy/national_policy_on_postdates/national_policy_on_postdates.ditamap`

## Introduction

Source topic: `fr_FR/policy/nationalpolicy/national_policy_on_postdates/introduction.dita`

Table des matières

- 1. Introduction
         [1. Introduction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_on_postdates#intro)

- 2. Objectif de la politique
         [2. Objectif de la politique](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_on_postdates#policy_obj)

- 3. Postdater une demande
         [3. Postdater une demande](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_on_postdates#postdating_claim)

- 4. Politique administrative et postdate

- 4.1 Exemple
             [4.1 Exemple](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_on_postdates#example)

         [4. Politique administrative et postdate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_on_postdates#administrative_policy_posdating)

- 5. Responsabilités

- 5.1 Administration centrale
             [5.1 Administration centrale](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_on_postdates#7_1_nh)

- 5.2 Régions et centres d’appels
             [5.2 Régions et centres d’appels](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_on_postdates#7_2_regions_call_centres)

         [5. Responsabilités](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_on_postdates#responsibilities)

**1. Introduction**

La LAE 10(1) prévoit que la Commission peut établir une période de prestations (PP) conformément aux dispositions suivantes :
       [LAE 10(1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-2.html#h-210461)

- La période de prestations débute, selon le cas :

- le dimanche de la semaine au cours de laquelle survient l’arrêt de rémunération;

- le dimanche de la semaine au cours de laquelle est formulée la demande initiale de prestations, si cette semaine est postérieure à celle de l’arrêt de rémunération.

Par le passé, une interprétation stricte de ces dispositions signifiait qu’un client devrait présenter une nouvelle demande dans tous les cas où il souhaite que sa demande débute à une date ultérieure. Par conséquent, pour offrir un meilleur service aux clients et éliminer le fardeau que représente la présentation d’une nouvelle demande de prestations, la Commission a introduit la Politique sur les postdates.

La Politique sur les postdates ne remplace pas la LAE, mais vise à la compléter. La demande devrait seulement être établie en vertu de la Politique sur les postdates quand cela est avantageux pour le client et quand l’un des cas précis s’applique.

**2. Objectif de la politique**

En vertu de la Politique sur les postdates, le client n’est pas tenu de présenter à nouveau une demande pour que la PP commence à une date ultérieure quand la raison de la postdate est l’un des cas précis indiqués ci-dessous.

**3. Postdater une demande**

On considère qu’une demande a été postdatée quand la PP est établie à une date ultérieure à celle permise par la LAE 10 (1) ou la Politique administrative .
       [Politique administrative](/fr/policy/nationalpolicy/administrative_policy.shtml)

Un DPP peut être postdaté jusqu’à 4 semaines, mais il ne peut pas être postdaté au-delà de la norme variable d’admissibilité (NVA) actuelle. Étant donné qu’une demande renouvelée a déjà un DPP établi, la semaine de renouvellement ne peut être postdatée de plus de 4 semaines.

Une demande ne peut pas être postdatée uniquement pour qu’un client bénéficie d’une nouvelle loi, sauf communication et autorisation contraire par la division de la politique opérationnelle de l’AE.

Les circonstances suivantes établissent quand il peut être avantageux de postdater une demande initiale ou renouvelée; au moins une des conditions suivantes doit être remplie pour postdater une demande :

- Le client a besoin des heures d’emploi assurable de la dernière semaine de travail pour remplir les conditions requises pour recevoir des prestations.

- La semaine d’arrêt de rémunération (A de R) ou la semaine de présentation de la demande est une semaine entière de travail (SET).

- Le client ne serait admissible qu’à un premier paiement partiel en raison de sa rémunération au cours de la semaine d’A de R et a demandé que la demande soit postdatée d’une semaine.

- Les indemnités de cessation d’emploi ou la rémunération, ou une combinaison des 2, au cours de la semaine de l’A de R ou de la semaine de la demande, sont égales ou supérieures au taux de prestations.

- Pour les prestations de maternité et parentales : le client a présenté une demande avant le début de la fenêtre de prestations.

- Pour les prestations spéciales : le client peut recevoir le nombre maximum de semaines auquel il est admissible, mais la rémunération de la première semaine empêche le paiement du taux de prestations complet.

- Pour les enseignants seulement : le client peut être admissible à un paiement contractuel de son employeur, en plus des prestations supplémentaires de chômage (PSC) pour les prestations de maternité et parentales. Les paramètres de paiement varient d’une province à l’autre (pendant les périodes d’enseignement ou de congés scolaires), mais ces sommes particulières sont considérées comme une rémunération et empêchent le versement des prestations d’AE pour ces semaines, puisqu’elles ne remplissent pas les critères des PSC. Une postdate pourrait être avantageuse pour le client, mais il faut porter attention à la fois à la fenêtre de maternité et à la fenêtre parentale pour s’assurer que l’admissibilité maximale reste disponible.

- Pour les pêcheurs seulement : le client a présenté sa demande de pêcheur estivale ou hivernale avant qu’une PP pour ce genre de demande puisse être établie, mais dans la période de NVA actuelle.

- Pour les prestations pour les travailleurs autonomes seulement : le client présente une demande avant que son accord ait été en vigueur pour un an, donc le client n’est pas admissible aux prestations. Si la date à laquelle le client devient admissible aux prestations est dans les 4 semaines à partir de la date à laquelle il a présenté sa demande, la demande peut être postdatée jusqu’à 4 semaines.

Pour éviter que le client ne doive présenter une deuxième demande d’AE, si le client a travaillé depuis la date de présentation de la demande initiale et a besoin de ces heures pour remplir les conditions requises pour recevoir des prestations, les heures supplémentaires peuvent être utilisées pour établir la demande initiale. Afin d’utiliser les heures supplémentaires pour remplir les conditions requises pour recevoir des prestations, le DPP doit être établi selon l’A de R le plus récent, le RE, ainsi que tout autre renseignement pertinent sur l’emploi doit être fourni. Si la décision initiale a déjà été rendue, le client doit présenter une nouvelle demande.

**4. Politique administrative et postdate**

L’établissement d’une demande est un processus étape par étape. Il faut d’abord déterminer si la demande a été présentée dans les délais prescrits ( Politique administrative ). Ensuite, il faut déterminer la semaine dans laquelle la PP devrait être établie.
       [Politique administrative](/fr/policy/nationalpolicy/administrative_policy.shtml)

Lors de l’établissement de la PP, postdater une demande peut être avantageux pour le client. La décision de postdater une demande est une décision distincte qui ne peut être prise que quand le motif pour postdater la demande est l’un des cas précis indiqués ci-dessus. Dans tous les autres cas, le client doit présenter une nouvelle demande.

La Politique administrative et la Politique sur les postdates sont 2 politiques distinctes qui sont souvent confondues et combinées. Il est impératif de faire la distinction entre les 2 pour appliquer correctement chacune d’entre elles.

**4.1 Exemple :**

- L’A de R et le dernier jour payé (DJP) sont survenus à la s/c 2275.

- Le client a demandé des prestations de maladie.

- La rémunération de la s/c 2275 est 450 $.

- Le RE indique que le motif de cessation d’emploi (MCE) est la maladie.

- Le client a fourni un certificat médical avec une date de guérison à la s/c 2293-5.

- Le client a présenté sa demande à la s/c 2278.

- Le taux de prestations est de 550 $.

Selon la Politique administrative, la demande a été présentée dans les délais prescrits, puisque le client l’a présentée dans les 4 semaines civiles suivant l’A de R. Par conséquent, la PP peut être établie à la s/c 2275.

La Politique sur les postdates stipule qu’une demande peut être postdatée dans ce cas parce que :

- Pour les prestations spéciales : le client peut recevoir le nombre maximum de semaines auquel il est admissible, mais la rémunération de la première semaine empêche le paiement du taux de prestations complet.

Dans cet exemple, il serait avantageux pour le client de postdater la demande. Par conséquent, le DPP est postdaté à la s/c 2276.

**5. Responsabilités**

**5.1 Administration centrale**

L’administration centrale est responsable de développer et d’appliquer cette politique. Elle est aussi responsable de développer et de maintenir les processus, les outils et les procédures, mais aussi de développer les formations pour la mise en œuvre de la politique.

**5.2 Régions et centres d’appels**

Les directeurs et gestionnaires des services de traitement et de paiement d’AE régionaux, les directeurs et gestionnaires des Services d’intégrité régionaux et les directeurs et gestionnaires des centres d’appels de l’AE sont responsables d’assurer la mise en œuvre de la politique, et de s’assurer qu’aucune modification ne soit faite sans le consentement du directeur ou de la directrice de la division de la politique opérationnelle de l’AE. 

## Contexte

Source topic: `fr_FR/policy/nationalpolicy/national_policy_on_postdates/contexte.dita`

## Untitled

Source topic: `fr_FR/policy/nationalpolicy/national_policy_on_postdates/untitled.dita`

 
