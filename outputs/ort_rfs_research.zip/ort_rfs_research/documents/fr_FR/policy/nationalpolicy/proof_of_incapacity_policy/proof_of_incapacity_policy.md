# Politique sur la preuve d’incapacité

Source map: `fr_FR/policy/nationalpolicy/proof_of_incapacity_policy/proof_of_incapacity_policy.ditamap`

## Introduction

Source topic: `fr_FR/policy/nationalpolicy/proof_of_incapacity_policy/introduction.dita`

Table of Contents

- 1. Introduction
         [1. Introduction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_1)

- 2. Objectif de la politique
         [2. Objectif de la politique](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_2)

- 3. Déterminer quand un certificat médical doit être présenté

- 3.1 Demandes initiales et renouvelées
             [3.1 Demandes initiales et renouvelées](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_3_1)

- 3.2 Conversion des prestations régulières en prestations de maladie
             [3.2 Conversion des prestations régulières en prestations de maladie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_3_2)

- 3.3 Périodes d’incapacité subséquentes
             [3.3 Périodes d’incapacité subséquentes](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_3_3)

         [3. Déterminer quand un certificat médical doit être présenté](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_3)

- 4. Situations spécifiques dans lesquelles une preuve d’incapacité doit être présentée

- 4.1 Situations spécifiques dans lesquelles un certificat médical doit être présenté
             [4.1 Situations spécifiques dans lesquelles un certificat médical doit être présenté](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_1)

- 4.2 Prestations de maladie avant des prestations de maternité
             [4.2 Prestations de maladie avant des prestations de maternité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_2)

- 4.3 Prestations de maladie pendant ou après le versement d’autres prestations spéciales
             [4.3 Prestations de maladie pendant ou après le versement d’autres prestations spéciales](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_3)

- 4.4 Prestations pour les travailleurs indépendants
             [4.4 Prestations pour les travailleurs indépendants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_4)

- 4.5 Prestations de pêcheur
             [4.5 Prestations de pêcheur](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_5)

         [4. Situations spécifiques dans lesquelles une preuve d’incapacité doit être présentée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_4)

- 5. Date de début de l’incapacité

- 5.1 Déterminer la date de début de l’incapacité
             [5.1 Déterminer la date de début de l’incapacité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_5_1)

- 5.2 Période d’incapacité subséquente — Écarts
             [5.2 Période d’incapacité subséquente — Écarts](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_5_2)

         [5. Date de début de l’incapacité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_5)

- 6. Date de guérison à utiliser quand un certificat médical est présenté

- 6.1 Date de guérison précise indiquée
             [6.1 Date de guérison précise indiquée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_6_1)

- 6.2 Date de guérison indéterminée, inconnue, incertaine ou indéfinie
             [6.2 Date de guérison indéterminée, inconnue, incertaine ou indéfinie](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_6_2)

- 6.3 Phase terminale ou palliative
             [6.3 Phase terminale ou palliative](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_6_3)

         [6. Date de guérison à utiliser quand un certificat médical est présenté](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_6)

- 7. Guérison anticipée et retour au travail (RAT) progressif

- 7.1 Guérison anticipée
             [7.1 Guérison anticipée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_7_1)

- 7.2 Retour au travail (RAT) progressif
             [7.2 Retour au travail (RAT) progressif](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_7_2)

         [7. Guérison anticipée et retour au travail (RAT) progressif](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_7)

- 8. Responsabilités

- 8.1 Administration centrale
             [8.1 Administration centrale](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_8_1)

- 8.2 Régions et centres d’appels
             [8.2 Régions et centres d’appels](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_8_2)

         [8. Responsabilités](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_8)

**1. Introduction**

Le RAE 40 indique qu’un certificat médical doit être présenté pour prouver l’incapacité à travailler.
       [RAE 40](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-40.html)

« 40(1) Les renseignements et la preuve que le prestataire doit fournir à la Commission pour établir son incapacité de travailler par suite d’une maladie, d’une blessure ou d’une mise en quarantaine en application de l’alinéa 18(1)b) ou du paragraphe 152.03(1) de la Loi consistent en un certificat établi par un médecin ou autre professionnel de la santé qui atteste cette incapacité et qui indique la durée probable de la maladie, de la blessure ou de la quarantaine. »

Conformément à cette exigence réglementaire, quand un client présente une demande de prestations de maladie, il doit obtenir et conserver un certificat médical pendant 6 ans pour appuyer leur demande de prestations de maladie d’AE.

L’une des principales constatations de l’ Évaluation des prestations de maladie de l’assurance-emploi est que la majorité des clients n’utilisaient pas le nombre maximal de semaines de prestations de maladie d’AE. En fait, pour ceux qui n’ont pas épuisé leurs prestations, la durée moyenne des prestations de maladie était de 9 semaines. Des constatations comme celle-ci, ainsi que des examens de conformité après paiement effectués par Intégrité dans les demandes de prestations de maladie, ont permis de conclure qu’il y a peu de risques à offrir une certaine souplesse dans le versement des premières semaines de prestations de maladie sans la réception immédiate d’un certificat médical. Cependant, le versement de prestations de maladie pendant de plus longues périodes sans certificat médical augmente le risque de verser des prestations pour lesquelles l’admissibilité du client ne peut pas être prouvée.
       [Évaluation des prestations de maladie de l’assurance-emploi](https://www.canada.ca/fr/emploi-developpement-social/ministere/rapports/evaluations/assurance-emploi-prestations-maladies.html#h2.05)

**2. Objectif de la politique**

Afin de trouver un juste équilibre entre la gérance du compte de l’AE et la prestation des services, cette politique précise :

- combien de semaines de prestations de maladie sont payables au départ sans qu’un certificat médical soit présenté;

- quand le client doit présenter un certificat médical à la Commission;

- quelle date de début de l’incapacité à utiliser quand le certificat médical n’est pas clair;

- comment traiter les écarts entre les périodes d’incapacité;

- quelle semaine de guérison doit être utilisée quand le professionnel de la santé n’indique pas de date de guérison précise dans le certificat médical.

**3. Déterminer quand un certificat médical est requis**

Dans certains cas, un certificat médical n’est pas requis dès le début d’une demande de prestations de maladie. Certains facteurs peuvent atténuer les risques associés à cette politique opérationnelle. Par exemple, les demandes initiales et renouvelées dont le motif de cessation d’emploi (MCE) auprès du dernier employeur est D - Maladie ou blessure réduisent le risque de ne pas demander le certificat médical dès le début de la demande de prestations de maladie puisqu’il y a des preuves corroborantes que le client a aussi demandé un congé de maladie à son employeur. Les examens de conformité pour les demandes de prestations de maladie, dans le cadre desquels des certificats médicaux sont demandés pour les périodes pendant lesquelles des prestations de maladie ont été versées sans certificat médical, continuent d’être effectués par Intégrité.

**3.1 Demandes initiales et renouvelées**

Quand le DPP est le 7 avril 2024 (s/c 2442) et après, un client qui présente une demande initiale ou renouvelée de prestations de maladie n’a pas besoin de présenter un certificat médical quand le MCE auprès du dernier employeur est « D- Maladie ou blessure ». Une semaine de guérison correspondant au DPP + 8 ou à la semaine de renouvellement + 8 peut être autorisée sans la présentation d’un certificat médical, y compris quand des prestations de maladie sont demandées avant des prestations de maternité (consulter la section 4.2 de cette politique pour connaître les considérations supplémentaires pour le versement des prestations de maladie avant les prestations de maternité). Si des prestations de maladie supplémentaires sont requises après la période initiale, un certificat médical doit être présenté pour permettre de prolonger les prestations jusqu’à un maximum de 26 semaines.
       [section 4.2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_2)

Quand le MCE auprès du dernier employeur n’est pas « D », un certificat médical doit être présenté avant le versement de toute semaine de prestations de maladie.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0367.dita) 

**3.2 Conversion des prestations régulières en prestations de maladie**

Lors de la conversion d’une demande de prestations régulières en prestations de maladie, un certificat médical doit être demandé dans les situations suivantes :

- Si aucune semaine de prestations de maladie occasionnelle* n’ a été versée, l’agent autorise, sans demander de certificat médical, une semaine de guérison correspondant à la semaine de conversion + 8 semaines. Après cette période, le client doit présenter un certificat médical pour recevoir des prestations de maladie supplémentaires.

- Si des semaines de prestations de maladie occasionnelle ont été versées avant la demande de conversion (y compris les cas dans lesquels une intervention manuelle a eu lieu après 4 semaines de maladie occasionnelle consécutives), l’agent autorise, sans demander de certificat médical, une semaine de guérison correspondant jusqu’à 8 semaines après la semaine de conversion moins les semaines de maladie occasionnelle déjà versées. Si le client a déjà reçu 8 semaines de maladie occasionnelle, il doit présenter un certificat médical pour recevoir d’autres semaines de prestations de maladie.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0368.dita) 

**3.3 Périodes d’incapacité subséquentes**

Un certificat médical doit être présenté pour toute période de maladie après le DPP, la semaine de renouvellement ou de conversion plus les semaines de prestations de maladie autorisées afin de permettre le versement de prestations de maladie supplémentaires. Ceci s’applique, peu importe le nombre de semaines demandées par le client.

**4. Autres situations dans lesquelles une preuve d’incapacité est requise**

**4.1 Situations précises dans lesquelles un certificat médical est requis**

Un client doit présenter un certificat médical avant le versement des prestations de maladie dans les situations suivantes :

- Un client qui a assez d’heures pour remplir les conditions requises pour recevoir des prestations spéciales, mais pas des prestations régulières, et dont le MCE pour la plus récente période d’emploi n’est pas « D – Maladie ou blessure ».

- Un client qui est exclu de recevoir des prestations régulières ou qui y est inadmissible.

- Un client qui veut recevoir des prestations de maladie après avoir épuisé ses semaines de prestations régulières.

- Un client de deuxième catégorie et dont le MCE pour la plus récente période d’emploi n’est pas « D – Maladie ou blessure ».

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0369.dita) 

**4.2 Prestations de maladie avant des prestations de maternité**

Une cliente peut recevoir des prestations de maladie dans sa fenêtre de maternité tant qu’elle est autrement disponible à travailler. En vertu du GDA 12.3.2 — Prestations de maladie au cours de la période de prestations de maternité , il y a des paramètres précis selon lesquels une cliente peut recevoir des prestations de maladie dans sa fenêtre de maternité. Même si le MCE sur le RE est « D » , les mêmes principes de décision s’appliquent.
       [GDA 12.3.2 — Prestations de maladie au cours de la période de prestations de maternité](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-12/prestations-maternite-prestations-speciales.html#a12_3_2)

Dans tous les cas, quand la cliente remplit les conditions pour recevoir des prestations de maladie avant des prestations de maternité, les prestations de maladie sont seulement payables jusqu’à la semaine avant la semaine d’accouchement, à moins d’indication contraire dans AP 2020-01 — Paiement de prestations de maladie au cours de la semaine de la date prévue de l’accouchement ou de la date réelle de l’accouchement .
       [AP 2020-01 — Paiement de prestations de maladie au cours de la semaine de la date prévue de l’accouchement ou de la date réelle de l’accouchement](/fr/policy/bememo/be2020-01.shtml)

**4.3 Prestations de maladie pendant ou après le versement d’autres prestations spéciales**

Un client qui reçoit des prestations de maternité, parentales, du RQAP, prestations pour proches aidants ou des PDC peut convertir sa demande en prestations de maladie, peu importe son MCE dans les cas suivants :

- Pendant la période de prestations (PP) initiale

- Dans la PP prolongée si des prestations de maladie ont été payées pendant la PP initiale.

Un certificat médical doit être présenté pour toutes les semaines de prestations de maladie demandées dans les situations mentionnée ci-haut.

- AP 2013-07 — Règlement des demandes de prestations de maladie pendant une période de maternité
         [AP 2013-07 — Règlement des demandes de prestations de maladie pendant une période de maternité](/fr/policy/bememo/be2013-07.shtml)

- AP 2013-02 — Prestations de maladie pour les prestataires recevant des prestations parentales
         [AP 2013-02 — Prestations de maladie pour les prestataires recevant des prestations parentales](/fr/policy/bememo/be2013-02.shtml)

- AP 2014-04 — Prestations de maladie pour les prestataires recevant des prestations pour parents d’enfants gravement malades (PEGM) ou de compassion
         [AP 2014-04 — Prestations de maladie pour les prestataires recevant des prestations pour parents d’enfants gravement malades (PEGM) ou de compassion](/fr/policy/bememo/be2014-04.shtml)

**4.4 Prestations pour les travailleurs indépendants**

Un certificat médical doit être présenté pour toutes les semaines de prestations de maladie pour les travailleurs indépendants, car il n’y a pas de validation d’une tierce personne du MCE dans un RE.

**4.5 Prestations de pêcheur**

Un pêcheur voulant recevoir des prestations de maladie, sauf pour une maladie occasionnelle, doit présenter un certificat médical pour toutes les prestations de maladie demandées à tout moment dans sa demande, car il n’y a pas de MCE « D - Maladie ou blessure » dans le RE de pêche pour atténuer le risque.

**5. Date de début de l’incapacité**

**5.1 Déterminer la semaine de début de l’incapacité**

Dans une demande initiale ou renouvelée, quand le MCE est « D » et qu’un certificat médical ne doit pas être présenté, la semaine de début de l’incapacité est la semaine du DPP ou de renouvellement.

Dans toutes les autres situations, la date de début de l’incapacité est le dimanche de la semaine au cours de laquelle le professionnel de la santé indique que le client est devenu inapte à travailler. Si aucune date de début de l’incapacité précise n’est fournie, la date de début de l’incapacité est le dimanche de la semaine au cours de laquelle le client a été vu par le professionnel de la santé ou de la semaine au cours de laquelle le professionnel de la santé a signé le certificat médical (selon la première éventualité).

**5.2 Période d’incapacité subséquente — Écarts**

Quand un certificat médical est fourni pour une période d’incapacité subséquente et que la date de début de l’incapacité n’est pas immédiatement après la semaine de guérison au dossier, s’il n’y a pas d’indication dans le certificat médical que la période d’incapacité continue à partir de la période initiale d’incapacité, le client doit fournir un certificat médical pour l’écart afin de recevoir des prestations pour cette période.

**6. Date de guérison à utiliser quand un certificat médical est présenté**

**6.1 Date de guérison précise indiquée**

Si une date de guérison précise est indiquée dans le certificat médical, celle-ci doit être utilisée.

L’agent ne saisit pas une date de guérison indéfinie ( 9999 ) quand une date de guérison précise est indiquée sur le certificat médical, même si cela dépasse le maximum de 26 semaines.

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0370.dita) 

**6.2 Date de guérison indéterminée, inconnue, incertaine ou indéfinie**

Quand un certificat médical indique une date de guérison indéterminée, inconnue, incertaine ou indéfinie, l’agent autorise une date de guérison de la semaine de début de l’incapacité + 8 (comme définit dans la section 5.1 de la présente politique). Ceci s’applique également à chaque certificat médical qui est présenté par la suite et qui comporte une formulation semblable. L’agent ne doit pas utiliser une date de guérison indéfinie ( 9999 ).
       [section 5.1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/proof_of_incapacity_policy#ch_5_1)

**6.3 Phase terminale ou palliative**

Une maladie est en phase terminale quand elle entraîne la mort. La phase palliative désigne les soins en fin de vie. Quand un certificat médical (initial ou subséquent) indique que le client est en phase terminale ou palliative, l’agent autorise une semaine de guérison indéfinie ( 9999 ), peu importe combien de semaines de prestations de maladie ont déjà été versées. Toutefois, la demande n’est pas postdatée sauf si le client le demande ou qu’il y a une indication au dossier précisant que le client pourra recevoir la totalité des 26 semaines de prestations de maladie.

**7. Guérison anticipée et retour au travail (RAT) progressif**

**7.1 Guérison anticipée**

En tout temps, peu importe si un certificat médical a été demandé ou non, il incombe au client de déclarer une guérison anticipée pour s’assurer qu’il reçoit seulement les prestations auxquelles il est admissible.

Un client qui reçoit des prestations de maladie peut indiquer qu’il est prêt, disposé et apte à travailler et qu’il veut convertir sa demande vers des prestations régulières avant la fin de la période initiale de prestations de maladie autorisée. Si aucun certificat médical n’a été demandé et qu’il n’y a pas de certificat médical au dossier indiquant une date d’incapacité plus longue, aucun certificat médical ne doit être présenté pour prouver la capacité de travailler.

Quand la guérison est avant la date indiquée dans un certificat médical présenté à la Commission, le client doit présenter un certificat médical confirmant sa guérison.

**7.2 Retour au travail (RAT) progressif**

Un client qui n’est pas complètement guéri, mais qui a été autorisé par un professionnel de la santé à retourner graduellement au travail, peut recevoir des prestations de maladie partielles ou des prestations régulières partielles, selon les circonstances de sa guérison ( GDA 10.7.4 — Disponibilité à temps partiel ). Cela dépend du nombre de semaines d’admissibilité restantes, car le client pourrait vouloir utiliser le versement partiel d’un genre de prestations (GP) plutôt que d’un autre, et des prestations pour lesquelles il remplit les conditions d’admissibilité.
       [professionnel de la santé](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-11/incapable-de-travailler.html#a11_2_2) 
       [GDA 10.7.4 — Disponibilité à temps partiel](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-10/heures-obligations-familiales-convictions-religieuses.html#a10_7_4)

Le client doit présenter un certificat médical indiquant l’autorisation du professionnel de la santé pour un RAT progressif et toute restriction. Le certificat médical doit inclure des renseignements comme la durée du RAT progressif, les jours ou les heures pendant lesquels le client peut travailler et les capacités du client ou son absence de capacités. Ces renseignements permettent de rendre une décision et de déterminer la disponibilité du client en fonction de ces limites ( GDA 10.10.0 — Santé et capacités physiques ).
       [GDA 10.10.0 — Santé et capacités physiques](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-10/sante-et-capacites-physiques.html#a10_10_0)

**8. Responsabilités**

**8.1 Administration centrale**

L’administration centrale est responsable d’élaborer et de mettre en œuvre cette politique. Elle est aussi responsable d’élaborer et de maintenir les processus, les outils et les procédures, ainsi que d’élaborer la formation pour la mise en œuvre de cette politique.

**8.2 Régions et centres d’appels**

Les directeurs et gestionnaires des services de traitement et de paiement de l’AE régionaux, les directeurs et gestionnaires des Services d’Intégrité régionaux et les directeurs et gestionnaires des centres d’appels sont responsables d’assurer la mise en œuvre de la politique, et de s’assurer qu’aucune modification ne soit faite sans le consentement de la directrice de la division de la Politique opérationnelle de l’AE. 

### Info

Source topic: `fr_FR/common_notes/note_c_0367.dita`

**Remarque :**

Pour les DPP avant le 7 avril 2024 (s/c 2442), une date de guérison DPP + 15 était autorisé quand le MCE du dernier emploi était « D - Maladie ou blessure ». 

### Info

Source topic: `fr_FR/common_notes/note_c_0368.dita`

*Maladie occasionnelle fait référence aux semaines de prestations de maladie versées au cours d’une demande de prestations régulières ou de pêche. 

### Info

Source topic: `fr_FR/common_notes/note_c_0369.dita`

**Remarque :**

Un client de deuxième catégorie qui cesse de travailler en raison d’une maladie, d’une blessure ou d’une quarantaine n’est pas admissible aux prestations de maladie ( LAE 21[1] ), même s’il présente un certificat médical.
       [LAE 21[1]](https://www.laws-lois.justice.gc.ca/fra/lois/e-5.6/section-21.html)

     [LAE 21[1]](https://www.laws-lois.justice.gc.ca/fra/lois/e-5.6/section-21.html) 

### Callout

Source topic: `fr_FR/common_notes/note_c_0370.dita`

Exemple :

Un client présente un certificat médical qui indique une date de guérison prévue dans 8 mois. La date de guérison est saisie comme 8 mois du DPP, mais le client guérit avant les 8 mois prévus et n’a pas reçu toutes les prestations de maladie auxquelles il était admissible. Si le client présente une demande pour les semaines de prestations de maladies restantes après la date de guérison de 8 mois, il doit présenter un autre certificat médical pour justifier son incapacité. Toutefois, si une date de guérison indéfinie ( 9999 ) était utilisée au lieu de la date de guérison réelle, et que le client présentait une demande pour les semaines de prestations de maladie restantes après la date de guérison initiale de 8 mois, cela pourrait lui permettre de recevoir des prestations de maladie auxquelles il n’est peut-être pas admissible. Il devrait présenter une preuve d’incapacité pour cette nouvelle période. 

## Contexte

Source topic: `fr_FR/policy/nationalpolicy/proof_of_incapacity_policy/contexte.dita`

## Untitled

Source topic: `fr_FR/policy/nationalpolicy/proof_of_incapacity_policy/untitled.dita`

**** 
