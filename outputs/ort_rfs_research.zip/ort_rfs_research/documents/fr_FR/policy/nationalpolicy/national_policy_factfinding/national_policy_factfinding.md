# Politique nationale sur le recueil de faits et la documentation

Source map: `fr_FR/policy/nationalpolicy/national_policy_factfinding/national_policy_factfinding.ditamap`

## Introduction

Source topic: `fr_FR/policy/nationalpolicy/national_policy_factfinding/introduction.dita`

Mise à jour le 22 septembre 2025

Table des matières

- Introduction
         [Introduction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s1)

- Objectifs de la politique
         [Objectifs de la politique](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s2)

- Le recueil de faits : la base d’une décision éclairée

- 3.1 Responsabilités liées au recueil de faits
             [Responsabilités liées au recueil de faits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3_1)

- 3.2 Client, employeur et tierce personne : Qui peut fournir des renseignements?

- 3.2.1 Client
                 [Client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3_2_1)

- 3.2.2 Employeur
                 [Employeur](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3_2_2)

- 3.2.3 Tierce personne (témoin)
                 [Tierce personne (témoin)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3_2_3)

             [Client, employeur et tierce personne : Qui peut fournir des renseignements?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3_2)

- 3.3 Recueil de faits dans les cas de départ volontaire pour des motifs strictement personnels
             [Recueil de faits dans les cas de départ volontaire pour des motifs strictement personnels](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3_3)

- 3.4 Recueil de faits dans les cas de harcèlement sexuel ou d’autres situations délicates
             [Recueil de faits dans les cas de harcèlement sexuel ou d’autres situations délicates](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3_4)

- 3.5 Recueil de faits auprès d’une personne mineure (personne qui n’a pas atteint la majorité)
             [Recueil de faits auprès d’une personne mineure (personne qui n’a pas atteint la majorité)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3_5)

- 3.6 Tentative d’obtenir de la documentation ou d’effectuer un recueil de faits
             [Tentative d’obtenir de la documentation ou d’effectuer un recueil de faits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3_6)

         [Le recueil de faits : la base d’une décision éclairée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3)

- La documentation : la pierre angulaire d’une décision éclairée

- 4.1 Éléments essentiels dans une demande
             [Éléments essentiels dans une demande](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_1)

- 4.2 Obtenir et consigner des renseignements
             [Obtenir et consigner des renseignements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_2)

- 4.3 Documents électroniques et papier

- 4.3.1 Transcription de documents papier en format électronique
                 [Transcription de documents papier en format électronique](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_3_1)

- 4.3.2 Transmettre des documents de façon électronique
                 [Transmettre des documents de façon électronique](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_3_2)

             [Documents électroniques et papier](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_3)

- 4.4 Consigner la décision et la justification
             [Consigner la décision et la justification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_4)

- 4.5 Communication de la décision
             [Communication de la décision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_5)

- 4.6 Langues officielles
             [Langues officielles](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_6)

- 4.7 Confidentialité
             [Confidentialité](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_7)

- 4.8 Protection des informateurs
             [Protection des informateurs](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_8)

         [La documentation : la pierre angulaire d’une décision éclairée](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4)

- Gestion et conservation des renseignements
         [Gestion et conservation des renseignements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s5)

- Responsabilités

- 6.1 Administration centrale
             [Administration centrale](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s6_1)

- 6.2 Régions et centres d’appels
             [Régions et centres d’appels](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s6_2)

         [Responsabilités](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s6)

**1. Introduction**

Service Canada, au nom de la Commission de l’AE du Canada (la Commission), est tenu de recueillir tous les renseignements pertinents pour rendre et appuyer les décisions sur le fait de remplir les conditions requises pour recevoir des prestations d’AE et l’admissibilité à ces dernières. Ne pas obtenir tous les faits et les documents pertinents peut entraîner de mauvaises décisions et créer des demandes de révision inutiles. La Commission est responsable du versement et du non-versement des prestations d’AE. Des preuves insuffisantes ou l’incapacité de produire des preuves entraînent des décisions défavorables pour la Commission de la part du Tribunal de la sécurité sociale (TSS) et des cours fédérales. Cela limite aussi la capacité de la Commission à poursuivre ou pénaliser les clients qui abusent du programme d’AE.

La LAE 48 autorise la Commission à obtenir les renseignements pour déterminer si un client remplit les conditions requises pour recevoir des prestations et est admissible à ces dernières. La LAE 48 exige également que la Commission avise le client de toute décision sur son admissibilité aux prestations. La présente politique établit les lignes directrices pour le recueil de faits et la documentation utilisées dans le processus décisionnel. Elle ne fournit pas de directive sur la façon de gérer des situations particulières.
       [LAE 48](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-48.html) 
       [LAE 48](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-48.html)

Cette politique n’aborde pas les exigences liées à la conservation des documents. L’autorité en matière d’élimination des documents de l’AE appartient à EDSC , qui est à son tour tenu de développer une politique sur la conservation et l’élimination des documents.
       [EDSC](https://iservice.prv/eng/imit/ims/clients/index.shtml) 

## Contexte

Source topic: `fr_FR/policy/nationalpolicy/national_policy_factfinding/contexte.dita`

## 2. Objectifs de la politique

Source topic: `fr_FR/policy/nationalpolicy/national_policy_factfinding/2_objectifs_de_la_politique.dita`

**2. Objectifs de la politique**

Cette politique établit les principes et lignes directrices pour l’obtention et le recueil des renseignements utilisés dans le processus décisionnel. Elle établit un lien entre les méthodes pour consigner les renseignements et les exigences en matière de responsabilité en décrivant ce qui est requis pour appuyer la décision de la Commission à savoir si le client remplit les conditions requises pour recevoir des prestations ou est admissible à ces dernières. En résumé, la Commission doit être en mesure de démontrer la façon dont une décision a été rendue, la raison de cette décision et les bases sur lesquelles elle a été rendue. Les faits utilisés pour appuyer la décision doivent être clairement indiqués.

La politique :

- décrit les principes généraux sur les responsabilités en matière de recueil de faits en tenant compte de la complexité de divers litiges liés à la décision;

- souligne l’importance d’un recueil de faits détaillé pour appuyer chaque décision ayant une incidence sur l’admissibilité d’un client aux prestations;

- fournit des détails sur les exigences pour garantir que les décisions sont correctement consignées;

- garantit que tous les documents qui appuient une décision pour le versement ou non-versement de prestations sont obtenus.

**3. Le recueil de faits : la base d’une décision éclairée**

Le recueil de faits est un élément important du processus décisionnel. La capacité à obtenir des renseignements détaillés des parties concernées est essentielle à ce processus. Pour faciliter l’obtention des renseignements nécessaires, les 5 questions de base (qui, quoi, où, quand, pourquoi) doivent être considérées lors du recueil de faits puisqu’elles aident à élaborer des questions.

Un recueil de faits incomplet peut entraîner une décision non appuyée ou incorrecte. Cela peut aussi créer un délai dans l’établissement d’une demande et générer de la frustration chez le client et l’employeur.

Avant de commencer le recueil de faits, l’agent doit d’abord connaître les questions à examiner et déterminer quels faits sont déjà au dossier. Les faits requis pour rendre une décision peuvent être obtenus, non seulement dans l’AT assigné, mais aussi dans la demande d’AE, le RE, les déclarations du client, de l’employeur ou de tierces personnes (décrit à la section 3.2 ), ou tout autre document à l’appui. Par conséquent, il est essentiel d’examiner l’ensemble du dossier en détail avant de commencer le recueil de faits. Effectuer un examen approfondi de l’ensemble du dossier, des demandes, des documents téléversés ou numérisés et des AT en suspens est la première étape pour se familiariser avec la demande. L’examen de tous les renseignements pertinents avant d’effectuer un recueil de faits permet à l’agent de se préparer et de déterminer les questions supplémentaires qui doivent être posées.
       [section 3.2](https://ort-orl.esdc-edsc.canada.ca/fr/policy/nationalpolicy/national_policy_factfinding.shtml#s3_2)

Les faits utilisés pour rendre une décision doivent être pertinents au litige sur lequel une décision doit être rendue. Pour déterminer ce qui est pertinent, il faut comprendre les principes de la LAE et du RAE tels qu’ils s’appliquent à une question particulière. Souvent, les renseignements fournis pourraient ne pas être pertinents à la question pour laquelle une décision doit être rendue. Si la pertinence des renseignements n’est pas évidente, il peut être nécessaire d’effectuer un recueil de faits supplémentaire.

Avant de poser les premières questions, l’agent doit prendre le temps de s’assurer que le client comprend les conditions requises et les conditions d’admissibilité pour recevoir des prestations d’AE, les raisons pour lesquelles les questions sont posées et la façon dont les renseignements seront utilisés. L’agent doit aussi expliquer quelles autres parties seront contactées (l’employeur) et la façon dont Service Canada procède si le client ne veut pas fournir de renseignements supplémentaires. De même, les autres parties concernées doivent aussi être avisées de la façon dont les renseignements seront utilisés.

Toutes les questions doivent être posées sur un ton approprié et d’une façon qui est facile à comprendre.

L’admissibilité aux prestations est déterminée selon la preuve. La partie à qui incombe le fardeau de la preuve doit fournir une preuve reposant sur les faits pour soutenir sa position. Des preuves documentaires appuyant les faits sont essentielles pour déterminer si le critère du fardeau de la preuve a été satisfait. La Commission est ultimement responsable d’appliquer la LAE. Par conséquent, dans tous les cas, elle est responsable de demander et de consigner les faits sur lesquels est fondée la décision.

Dans les cas où le client a été congédié ou a quitté volontairement son emploi, la LAE 51 stipule que l’employeur et le client doivent avoir la même possibilité de fournir des renseignements. Par conséquent, il ne doit y avoir aucun fait allégué ou élément de preuve au dossier qui n’a pas été présenté au client et à l’employeur pour obtenir des explications ou des précisions. La dernière réfutation doit toujours être donnée au client.
       [LAE 51](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-51.html)

Le recueil de faits est considéré comme étant terminé quand il ne reste aucune question sans réponse et qu’une compréhension complète des événements qui se sont produits est atteinte. Effectuer un bon recueil de faits est le rôle essentiel de l'agent. Si le recueil de faits n’est pas effectué de façon approfondie, cela entraînera des décisions incorrectes, un plus grand nombre de demandes de révision et un mauvais service aux clients.

Les questions suivantes peuvent être utilisées pour déterminer si le recueil de faits est terminé :

- Toutes les parties concernées ont-elles été jointes?

- Toutes les parties ont-elles été informées de la déclaration de l’autre partie et ont-elles eu la possibilité de la réfuter?

- Le client a-t-il eu la possibilité de faire la dernière réfutation?

- Est-ce que la chronologie des événements fut établie?

- Les écarts dans le temps ou les renseignements ont-ils été précisés?

- Les renseignements conduisent-ils à une décision qui peut être appuyée en tenant compte de la prépondérance des probabilités?

Toutes ces questions permettent de répondre aux 5 questions de base (qui, quoi, où, quand, pourquoi) et d’assurer un recueil de faits complet.

Les faits et justifications sont des éléments essentiels de toute décision. Ils démontrent ce sur quoi la décision est fondée, ainsi que les raisons pour lesquelles l’agent rend une décision précise sur une question, et la façon dont il a arrive à cette décision.

Une décision doit être fondée sur la législation de l’AE, et les faits qui appuient cette décision doivent être évidents. La décision est faible si les faits ne sont pas évidents. Quand les faits ne sont pas consignés, on peut conclure logiquement qu’ils n’ont pas été obtenus en premier lieu. Une décision rendue sans faits n’est pas une décision éclairée. Une décision rendue de cette façon peut soulever des questions et être sujette à interprétation puisqu’elle ne repose pas sur des faits. Il pourrait y avoir une apparence de traitement injuste ou que les droits du client n’ont pas été respectés.

**3.1 Responsabilités liées au recueil de faits**

Le niveau décisionnel de l’agent responsable d’effectuer le recueil de faits dépend de la complexité du litige.

Les agents de Niveau 1 sont responsables d’effectuer un recueil de faits sur les litiges qui ne peuvent mener qu’à une seule conclusion possible et évidente, y compris les questions qui relèvent du Niveau 1 selon la Politique nationale sur les niveaux de décision .
       [Politique nationale sur les niveaux de décision](/fr/policy/nationalpolicy/levels_decision.shtml)

Les agents de Niveau 2 sont responsables d’effectuer un recueil de faits sur tous les litiges pour lesquels une décision ne peut pas être rendue au Niveau 1. Les décisions de Niveau 2 sont de nature complexe et nécessitent du jugement et un recueil de faits approfondi.

Dans certains cas, la décision sur un MCE litigieux peut être reportée quand un client demande des prestations spéciales et remplit les conditions requises pour les recevoir, ou quand une période de prestations ne peut pas être établie (PPNE) pour différentes raisons. Dans les cas pour lesquels la décision sur le MCE est reportée, le recueil de faits peut aussi être reporté. Le report d’une décision sur le MCE doit être consigné dans la demande, y compris la raison du report. Un report de décision peut être déterminé par le Niveau 1 ou le Niveau 2, selon la complexité de la question de fond et la raison du report. Les politiques et les procédures opérationnelles doivent être consultées pour déterminer si le report de la décision est approprié.

Lors de l’examen des renseignements et des AT, s’il est déterminé qu’une enquête des services d’Intégrité est requise, la responsabilité d’effectuer un recueil de faits et de le consigner revient aux services d’Intégrité. Aucun recueil de faits supplémentaire ne doit être effectué par les agents du traitement ou du centre d’appels et la question doit immédiatement être renvoyée à Intégrité. Tous les renseignements obtenus doivent être consignés de façon appropriée dans la demande.

Pour les demandes de vérification postérieure envoyées au traitement par les services d’Intégrité, l’agent doit retourner à Intégrité les dossiers dont le recueil de faits est incomplet.

**3.2 Client, employeur et tierce personne : Qui peut fournir des renseignements?**

**3.2.1 Client**

Selon la LAE 2(1) , un prestataire (client) est défini comme une personne qui demande ou a demandé des prestations en vertu de la LAE. La LAE 50(5) stipule que la Commission peut à tout moment exiger d’autres renseignements du client à propos de sa demande de prestations. Le recueil de faits pour obtenir la version des faits du client doit être effectué directement auprès de ce dernier. L’exception à la LAE est le RAE 27 qui permet à un représentant d’agir au nom d’un client si ce dernier souffre d’une déficience intellectuelle, est frappé d’une incapacité ou est décédé.
       [LAE 2(1)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-2.html) 
       [LAE 50(5)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-50.html) 
       [RAE 27](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-27.html)

Une tierce personne peut agir comme interprète pour un client (p. ex. dans le cas d’une barrière linguistique), mais le client doit être avec la tierce personne et toutes les questions doivent être traduites par la tierce personne pour le client. De même, les réponses du client doivent être traduites pour l’agent. Dans ces cas, la tierce personne ne peut pas fournir de réponse au nom du client. Elle peut seulement agir à titre d’interprète.

**3.2.2 Employeur**

La LAE 51 stipule que les employeurs et les clients doivent avoir l’occasion de fournir des renseignements sur les raisons de la perte d’emploi. Quand il y a une perte d’emploi en raison d’une inconduite de la part du client, ou que le client quitte volontairement son emploi, l’employeur doit toujours avoir l’occasion de fournir des renseignements sur l’événement.
       [LAE 51](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-51.html)

La LAE 126(14) accorde à la Commission l’autorité légitime d’obtenir des renseignements liés à l’AE sur une personne en particulier qui a présenté une demande d’AE, ou qui reçoit ou a reçu des prestations d’AE.
       [LAE 126(14)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-126.html)

En vertu de la Loi sur la protection des renseignements personnels et les documents électroniques , au besoin, l’employeur doit être informé que les renseignements personnels d’un individu peuvent être divulgués, à l’insu de l’intéressé ou sans son consentement, à une institution gouvernementale qui a :
       [Loi sur la protection des renseignements personnels et les documents électroniques](https://ort-orl.esdc-edsc.canada.ca/fr/policy/nationalpolicy/pipeda_qa.shtml)

- demandé ces renseignements;

- mentionné la source de son autorité légitime pour les obtenir;

- indiqué que la divulgation est demandée aux fins de l’application des lois canadiennes.

**3.2.3 Tierce personne (témoin)**

Un recueil de faits peut être effectué auprès d’une tierce personne (témoin) pour obtenir sa version des faits si la tierce personne a une connaissance directe de la situation. La déclaration de la tierce personne ne peut pas reposer sur des ouï-dire ou sur le témoignage d’autres personnes impliquées. Il doit s’agir de ce dont la tierce personne a été directement témoin.

Une tierce personne comme un représentant syndical peut aussi fournir un aperçu de l’environnement de travail et des relations entre les employés et la direction. Un représentant syndical peut également avoir une connaissance directe des questions précises.

**3.3 Recueil de faits dans les cas de départ volontaire pour des motifs strictement personnels**

Si le MCE est strictement personnel, mais que des renseignements supplémentaires sont requis pour rendre une décision, l’agent devrait d’abord communiquer avec le client pour effectuer un recueil de faits supplémentaire. Selon les réponses du client, il pourrait ne pas être nécessaire de communiquer avec l’employeur.

Si l’employeur produit un RE indiquant que le client a quitté volontairement son emploi et que le client déclare l’avoir fait pour un motif strictement personnel (p. ex. un retour aux études ou un changement de carrière), il pourrait ne pas être nécessaire de communiquer avec l’employeur pour confirmer ces faits si les 2 conditions suivantes sont remplies :

- les faits sont crédibles et raisonnables;

- selon la situation, il est peu probable que l’employeur détienne des renseignements sur l’existence ou l’absence d’autres solutions raisonnables.

La version des faits de l’employeur serait requise pour les situations dans lesquelles des solutions raisonnables au départ auraient pu être disponibles. Par exemple, si un client a quitté son emploi en raison de problèmes liés à la garde d’enfants, un recueil de faits auprès de l’employeur serait requis pour confirmer si le client a demandé un congé temporaire de son emploi ou une modification à son horaire de travail pour régler ses problèmes de garde d’enfants.

**3.4 Recueil de faits dans les cas de harcèlement sexuel ou d’autres situations délicates**

Si le client indique avoir perdu son emploi en raison de harcèlement sexuel ou d’une autre situation délicate, l’agent doit adapter son recueil de faits aux circonstances précises du cas. La responsabilité de la Commission de permettre au client et à l’employeur de fournir des renseignements sur le MCE s’applique toujours quand des allégations de harcèlement sexuel ont été faites. Toutefois, quand l’employeur doit fournir les renseignements sur le MCE, sa version est acceptée telle quelle et consignée au dossier. En aucun temps lors du recueil de faits, il ne sera révélé à l’employeur la version donnée par le client, sauf si celui-ci accepte une telle divulgation, ou si l’employeur en fait ouvertement mention. Le section 6.5.2 du Guide doit être consulté pour rendre une décision sur ces genres de MCE.
       [section 6.5.2 du Guide](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-6/circonstances-mentionnees-dans-la-loi.html#a6_5_2)

**3.5 Recueil de faits auprès d’une personne mineure (personne qui n’a pas atteint l’âge de la majorité)**

Une personne mineure est une personne qui n’a pas atteint l’âge de la majorité. Il n’y a pas d’âge précis au Canada à partir duquel une personne mineure est considérée comme étant assez mature pour prendre les décisions qui ont une incidence sur elle. Chaque province et territoire canadiens est tenu de déterminer l’âge de la majorité dans cette province ou ce territoire. Aux fins de cette politique uniquement, un mineur est considéré comme une personne de moins de 18 ans.

Dans cette section, le terme parent peut aussi désigner un tuteur légal ou un adulte de confiance.

Quand Service Canada initie le contact avec le mineur pour obtenir des renseignements sur sa demande d’AE, avant d’obtenir tout renseignement, il faut lui offrir d’avoir un parent présent pendant la conversation. Si le recueil de faits auprès du mineur concerne une question litigieuse, le mineur doit être fortement encouragé à être accompagné d’un parent pendant la discussion.

Le mineur n’est pas tenu d’être accompagné d’un parent lors des discussions avec Service Canada. Toutefois, l’offre de présence d’un parent a pour but de s’assurer que le mineur se sent en sécurité lors de ces conversations et qu’il comprend bien les questions qui lui sont posées au cours de l’interaction. Dans tous les cas, l’offre de présence d’un parent et la réponse du mineur doivent être consignées dans un RSDP.

**3.6 Tentative d’obtenir de la documentation ou d’effectuer un recueil de faits**

Dans certaines situations, l’agent est incapable de joindre le client. Dans d’autres situations, le client ou l’employeur refuse de fournir des renseignements, et ce même quand l’agent explique l’incidence du refus de fournir les renseignements demandés. Dans tous les cas, des efforts doivent être faits pour obtenir les renseignements nécessaires et ces efforts doivent être documentés.

La méthode préférée de la Commission pour le recueil de faits et la communication est par téléphone, car il s’agit de la méthode la plus efficace. Un minimum de 2 tentatives, à un intervalle de 24 heures et à différents moments de la journée, sont effectuées et les parties intéressées doivent disposer d’un délai minimum de 24 heures à compter de la dernière tentative pour retourner l’appel de l’agent. Pour considérer un appel téléphonique comme une tentative réussie, l’agent doit parler à la partie intéressée ou lui laisser un message. Chaque tentative doit être consignée au dossier, y compris si un message est laissé.

Si l’agent est incapable de joindre le client par téléphone ou de laisser un message, il doit envoyer une lettre ou un courriel au client pour lui demander de communiquer avec lui. L’agent doit donner 48 heures au client pour répondre à un courriel et 10 jours ouvrables pour répondre à une lettre.

L’agent envoie aussi une lettre quand il ne peut pas joindre l’employeur par téléphone ni lui laisser un message.  Les employeurs disposent de 10 jours ouvrables pour répondre à la lettre.

S’il n’y a pas de retour d’appel à la suite des messages vocaux, du courriel ou de la lettre, l’agent doit procéder à rendre une décision avec les renseignements disponibles au dossier.

La documentation au dossier est souvent utilisée quand un client communique avec Service Canada pour connaître l’état de sa demande. Les notes permettent à l’agent qui examine la demande d’informer le client des mesures qui ont été prises, si un agent tente de joindre le client pour de l’information supplémentaire ou si des documents sont manquants. Si une décision est rendue sans obtenir les déclarations du client ou de l’employeur parce qu’ils ont refusé de fournir des renseignements ou parce qu’il était impossible de les joindre, il est important que le tout soit consigné au dossier pour démontrer que l’agent a tenté d’obtenir les renseignements. Cela renforce la décision et démontre que l’agent a fait preuve de la diligence requise pour obtenir les renseignements.

Si l’employeur est joint, mais qu’il refuse de fournir les renseignements demandés, les conséquences de ce refus doivent lui être expliquées. Si l’employeur ne fournit pas les renseignements demandés, la décision doit être rendue sans l’apport de ce dernier. Il est impératif de consigner la conversation avec l’employeur pour s’assurer que les droits de l’employeur en vertu de la LAE 51 ont été respectés. Dans ces cas, la justification de la décision doit indiquer que l’employeur n’a pas fourni les renseignements demandés et qu’il a été informé des conséquences de cette omission. Le fait que l’employeur n’ait pas fourni de renseignements ne signifie pas que les prestations doivent être automatiquement accordées. La décision doit être rendue en fonction des faits disponibles.
       [LAE 51](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-51.html)

Par exemple, si le client indique avoir été congédié pour avoir commis un vol et admet l’avoir commis, mais qu’il est impossible de joindre l’employeur ou que ce dernier refuse de commenter, les prestations pourraient être refusées sur la base de la déclaration du client. Tous les éléments doivent être pris en considération avant de rendre une décision.

La LAE 50(5) accorde le pouvoir de demander des renseignements supplémentaires à un client au sujet de sa demande d’AE. Si un client ne fournit pas les renseignements supplémentaires demandés, il n’est pas admissible aux prestations et une inadmissibilité 15 - Procédure de présentation des demandes (D15) pour l’omission de fournir un RE ou d’autres renseignements demandés est imposée tant qu’il ne s’est pas conformé. Dans ce contexte, une inadmissibilité D15 peut seulement être imposée quand le client n’a pas fourni les renseignements supplémentaires précis demandés pour prouver son admissibilité aux prestations. Une inadmissibilité générique ne doit pas être imposée simplement parce que les tentatives générales de recherche des faits ont été infructueuses ou parce qu’une ou plusieurs parties refusent de fournir des renseignements supplémentaires sur un litige pour lequel une décision doit être rendue. Dans ces cas, la Commission rend une décision sur la question de fond en utilisant les faits disponibles.
       [LAE 50(5)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-50.html)

Un traitement manuel (TM) est un moyen temporaire utilisé afin d’éviter un trop-payé (T-P) dans une demande continue, plus précisément dans les cas où il y a de fortes raisons de penser que le client pourrait ne pas être admissible aux prestations, mais qu’un recueil de faits supplémentaire est requis pour rendre une décision. Un TM ne doit pas être imposé pour une période prolongée puisqu’aucune décision n’a été communiquée au client et qu’il n’a pas été avisé de son droit de demander une révision.

**4. La documentation : la pierre angulaire d’une décision éclairée**

Une décision doit être bien expliquée pour démontrer qu’elle repose uniquement sur les faits pertinents et qu’elle est une application juste et équitable de la loi. En établissant et en renforçant les principes de base du recueil de faits et de la documentation, l’agent s’assure que toutes les décisions sont prises de manière équitable et transparente. Les décisions doivent pouvoir résister à un examen minutieux dans le cadre de tout type de contrôle, d’audit, d’examen, de révision, de procédure d’appel ou de procédure judiciaire.

Même si le client n’est pas toujours d’accord avec la décision rendue, il est généralement plus satisfait s’il comprend les motifs de la décision et que ses préoccupations et explications ont été entendues et prises en compte. La documentation doit démontrer que le client a été écouté objectivement, qu’il a eu la possibilité de réfuter les renseignements fournis par d’autres parties concernées et que la décision est fondée sur les faits et sans parti pris.

Les principes de justice naturelle sont un terme utilisé dans la communauté juridique pour décrire 2 principes qui sont pris en considération lors de la décision :

- Le premier principe stipule qu’une décision doit être rendue de manière impartiale.

- Le deuxième principe souligne qu’une décision peut être maintenue seulement si la personne directement concernée a eu une chance équitable d’exposer son cas et de répondre à la déclaration de l’autre partie.

Les principes de justice naturelle doivent être appliqués dans les décisions concernant l’admissibilité aux prestations d’AE. Cela permet de s’assurer que toutes les décisions sont justes et impartiales.

Comme il a été mentionné précédemment, la Commission est responsable du paiement et du non-paiement des prestations d’AE. L’absence de documentation peut soulever un doute sur le fait qu’une décision repose sur les preuves présentées. Elle soulève également un doute que l’équité et les principes de justice naturelle n’ont pas été respectés au moment de rendre la décision.

Il est très important d’obtenir des documents qui appuient la décision. Par exemple, si un client est congédié pour ne pas avoir respecté une politique de l’employeur, il faut obtenir de l’employeur des documents démontrant que le client était au courant de la politique, car ceux-ci peuvent appuyer la décision. Si le client fait l’objet d’une accusation criminelle, il est important d’obtenir une copie de toute condition de libération, car cela peut avoir une incidence sur l’emploi ou la disponibilité du client. Tous les efforts doivent être déployés pour obtenir tous les documents pertinents de la part du client et de l’employeur. Si la documentation n’est pas disponible, une décision doit être rendue selon les renseignements recueillis auprès des parties concernées.

Les renseignements obtenus pour appuyer les décisions sur l’admissibilité doivent être recueillis et traités comme indiqué dans l’ Outil de catégorisation de l’information sur iService.
       [Outil de catégorisation de l’information](https://iservice.prv/fra/si/securite/categorisation/index.shtml)

**4.1 Éléments essentiels dans une demande**

Une demande doit contenir une preuve de l’autorisation du paiement des prestations. En termes généraux, cette autorisation signifie une documentation qui démontre :

- qui a présenté une demande de prestations;

- une demande d’AE autorisée par le client, soit par signature électronique en vertu du RAE 91(2) , soit par d’autres moyens acceptables de vérification de l’identité;
         [RAE 91(2)](https://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-91.html)

- les RE;

- qui a autorisé ou refusé le paiement des prestations;

- quelle période a été autorisée ou refusée;

- les raisons pour lesquelles les paiements ont été autorisés, refusés ou rétablis (p. ex. les preuves et la justification des décisions, le cas échéant);

- des documents ou des déclarations valables à l’appui du genre de prestations demandées (p. ex. un certificat médical, quand il est requis, à l’appui du paiement de prestations de maladie ou d’un départ volontaire pour raisons médicales).

Quand les réponses fournies dans la demande indiquent clairement que le client remplit les conditions d’admissibilité, aucune documentation supplémentaire et aucune justification pour la décision d’autoriser les prestations ne sont requises. Par exemple, si un client répond Non à la question Êtes-vous un travailleur indépendant, autre que dans la pêche ou sur une ferme? dans sa demande d’AE, aucun recueil de faits supplémentaire n’est requis pour cette question.

S’il y a des doutes concernant l’admissibilité du client aux prestations ou le fait qu’il remplisse les conditions requises pour les recevoir, des renseignements supplémentaires sont requis.

**4.2 Obtenir et consigner des renseignements**

En général, le RSDP dans SNCT est le moyen approprié pour consigner les renseignements et les déclarations recueillis lors du recueil de faits. D’autres moyens sont parfois utilisés pour consigner les renseignements et seront alors précisés dans les procédures opérationnelles. Les détails requis varient selon la complexité de la décision à rendre. Plus la question est complexe ou la décision controversée, plus le recueil de faits doit être détaillé.

L’agent obtient habituellement des renseignements supplémentaires en effectuant une entrevue téléphonique avec le client, l’employeur et d’autres parties concernées puisque Service Canada utilise surtout cette méthode. C’est le moyen le plus efficace d’obtenir des renseignements détaillés de la part des parties concernées. Si les tentatives de contact avec la partie concernée ont échoué ou si le genre de renseignements requis nécessite un document officiel (p. ex. un certificat médical), d’autres moyens doivent être utilisés, comme l’envoi d’une lettre ou d’un courriel. Les Aide-mémoires et formulaires nationaux de traitement des demandes ont été élaborés pour aider les agents de Niveau 1 à recueillir les renseignements nécessaires afin de rendre une décision. L’utilisation d’aide-mémoires est encouragée pour s’assurer que tous les faits pertinents sont recueillis et consignés dans la demande et que les renseignements peuvent être facilement trouvés lors de l’examen de la demande.
       [Aide-mémoires et formulaires nationaux de traitement des demandes](https://esdc.prv/fr/service-canada/ae/documents-reference/formulaires/aide_memoire_nationales.shtml)

Quand l’agent communique avec le client par téléphone ou qu’il reçoit un appel d’un client, il doit valider l’identité du client pour s’assurer que la vie privée de celui-ci est respectée en vertu de la Loi sur la protection des renseignements personnels 8(1) . La Commission doit s’assurer qu’aucun des renseignements personnels qu’elle détient n’est divulgué sans le consentement du client. C’est pourquoi l’identité du client doit toujours être validée avant de divulguer tout renseignement. Il est impératif que les renseignements personnels du client soient protégés en tout temps.
       [Loi sur la protection des renseignements personnels 8(1)](https://laws-lois.justice.gc.ca/fra/lois/p-21/section-8.html)

Quand un agent effectue un recueil de faits, la conversation doit être consignée de manière approfondie et inclure les renseignements suivants :

- l’identité du client a été validée;

- qui a obtenu et consigné les renseignements;

- qui a été interrogé et, s’il s’agit d’une personne autre que le client, sa relation avec le client ou le nom et le titre de la personne s’il s’agit d’un représentant de l’employeur;

- la date et l’heure de la conversation;

- le but de l’entretien (question);

- les renseignements obtenus (faits).

S’il y a eu des tentatives infructueuses de joindre un client, un employeur ou une tierce personne par téléphone, les renseignements suivants doivent être consignés dans un RSDP :

- le numéro de téléphone appelé;

- les dates et heures des tentatives;

- le but de la tentative (question);

- si un message a été laissé sur une boîte vocale ou à une personne et le nom de la personne qui a pris le message.

Les comptes rendus des conversations doivent être rédigés de manière objective, claire, sur un ton professionnel et sans fautes de frappe, d’orthographe ou de grammaire de base. Le langage neutre et les pronoms de préférence doivent être respectés. Les abréviations et les acronymes ne doivent pas être utilisés, sauf s’ils sont introduits au long au moins une fois dans le document. Le jargon interne de l’AE ne doit pas être utilisé du tout. Les phrases ne sont pas obligatoires. L’écriture sous forme de liste est acceptable, mais pas au détriment du contenu et de la compréhension. Il n’est pas nécessaire que les déclarations soient mot pour mot, mais elles doivent refléter clairement et précisément les discussions qui ont eu lieu entre l’agent et le client, l’employeur ou la tierce personne. Le compte rendu de la conversation peut être rédigé sous forme de récit, de questions et réponses ou de déclaration, en veillant à la cohérence de l’ensemble. Il doit être facile à lire et indiquer clairement qui a fourni les renseignements. Il est recommandé de revoir la déclaration écrite avec la partie visée avant de mettre fin à la conversation afin de s’assurer qu’elle a été correctement consignée. Cela donne également à la partie l’occasion de fournir des renseignements qu’elle n’aurait pas inclus dans sa déclaration. Relire la déclaration avec la partie concernée donne de la crédibilité à cette déclaration si la partie la réfute plus tard.

Chaque entretien doit être consigné dans un RSDP distinct, par exemple, un RSDP pour un appel, 2 RSDP pour 2 appels. Les questions litigieuses différentes (p. ex. départ volontaire ou formation) doivent être consignées dans des RSDP distincts, puisqu’en cas d’une demande de révision ou d’appel au Conseil d’appel en assurance-emploi (CAAE), seuls les renseignements liés à la question en cours de révision ou d’appel doivent être inclus. À défaut de séparer les questions dans différents RSDP, plus de travail est requis pour éliminer les renseignements inutiles. Il y a également un risque accru d’atteinte à la vie privée si les renseignements sont combinés dans un RSDP, puisque des renseignements non pertinents à la demande de révision ou à l’appel pourraient être partagés avec une partie intéressée (p. ex. l’employeur).

Le RSDP doit être rempli et sauvegardé sans délai pour s’assurer que les renseignements correspondent bien aux propos du client ou de l’employeur. Cela renforce aussi la crédibilité des renseignements. Il est aussi important de consigner les tentatives faites pour joindre le client ou l’employeur pour démontrer la diligence de la Commission en cas d’audit, de demande de révision ou d’appel de la décision.

Les opinions ou les interprétations de l’entretien faites par l’agent n’ont pas leur place dans le processus de recueil de faits et de documentation. La crédibilité des déclarations est évaluée au stade de la prise de décision et non quand les renseignements sont consignés. Les conclusions doivent être laissées à l’agent responsable, une fois que tous les faits pertinents et nécessaires ont été obtenus.

Les décisions sur l’admissibilité aux prestations d’AE doivent être fondées sur les renseignements fournis par les parties concernées. Les sites à contenu public (p. ex. les sites de médias sociaux, les articles de journaux) ne doivent pas être consultés pour déterminer l’admissibilité du client aux prestations. S’il existe des renseignements accessibles au public (p. ex. un client a été congédié en raison de commentaires qu’il a faits sur les médias sociaux) qui sont pertinents pour la décision, le client ou l’employeur doit présenter ces renseignements à la Commission à titre de documents à l’appui, comme c’est le cas pour tout autre document à l’appui.

Il est nécessaire de consigner toute correction ou modification apportée. Par exemple, si un RE est jugé incorrect, la correction doit être consignée, car elle peut affecter le résultat du calcul de la demande. La documentation doit clairement indiquer le motif de la correction du RE et la façon dont il a été corrigé, qui a été contacté pour obtenir les renseignements corrigés et quel a été le résultat de la correction. En d’autres termes, il doit y avoir une validation de la correction pour établir le lien entre ce qui est sur le RE initial et la décision réelle prise lors du calcul de la demande. Les employés de Service Canada ne doivent jamais apporter des corrections directement sur un document original, car cela compromettrait la légalité de ce document.

**4.3 Documents électroniques et papier**

Un certain nombre de dispositions de la LAE permettent à la Commission de mener ses activités par voie électronique. La LAE 2(3) confirme que toute référence dans la LAE à tout type de document inclut ceux en format électronique. Aux fins de la présente politique, les références à la documentation comprennent les documents électroniques ainsi que les documents papier.
       [LAE 2(3)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-2.html)

La Loi sur la preuve au Canada impose des contrôles sur la forme sous laquelle les documents sont admissibles dans les procédures judiciaires. En général, les documents papier sont la forme de preuve la plus acceptée. Toutefois, s’il n’est pas possible ou raisonnablement faisable de produire un document papier, la Loi sur la preuve au Canada stipule ce qui est acceptable.
       [Loi sur la preuve au Canada](https://laws-lois.justice.gc.ca/fra/lois/c-5/) 
       [la Loi sur la preuve au Canada](https://laws-lois.justice.gc.ca/fra/lois/c-5/)

Le format électronique est la méthode privilégiée par la Commission pour recueillir et conserver la documentation. Les processus actuels relatifs aux prestations d’AE permettent aux clients de remplir leur demande de prestations et leurs déclarations du prestataire par voie électronique. Les documents et les déclarations sont consignés électroniquement, et les décisions, lettres et avis envoyés aux clients sont stockés électroniquement.

Les systèmes et logiciels de Service Canada ne peuvent pas toujours s’adapter au format du document source reçu. Par exemple, si un employeur envoie un document électronique qui ne peut être ouvert parce que le logiciel requis n’est pas disponible ou en raison de restrictions en vertu de la Directive sur l’utilisation du réseau d’EDSC , des efforts devraient être déployés afin de déterminer si le problème peut être résolu à l’interne. Si ce n’est pas le cas, il faut communiquer avec l’expéditeur pour lui demander d’envoyer le document dans un format qui permettra à Service Canada d’accéder à son contenu.
       [Directive sur l’utilisation du réseau d’EDSC](https://iservice.prv/fra/si/securite/outils_et_ressources/trousse_outils/edsc_directive_utilisation_reseau.shtml)

**4.3.1 Transcription de documents papier en format électronique**

Des processus et des directives ont été élaborés pour permettre la transcription et l’imagerie de la documentation papier (certificats médicaux, RE, formulaires, etc.) dans un format électronique. Les documents transcrits en format électronique peuvent être utilisés pour déterminer si un client remplit les conditions requises pour recevoir des prestations ou est admissible à celles-ci. Consulter la section 5 de la présente politique pour plus de détails sur la gestion des renseignements et la conservation des documents papier.
       [section 5](/fr/policy/nationalpolicy/national_policy_factfinding.shtml#s5)

**4.3.2 Transmettre des documents de façon électronique**

La protection des renseignements est de la plus haute importance. Par conséquent, les fonctions de recueil de faits exercées par Service Canada ne sont pas effectuées par voie électronique, sauf si des canaux sécurisés approuvés sont en place.

Le recueil de faits par courriel ou par message texte est interdit . Toutefois, un gabarit de courriel peut être rempli et envoyé au moyen de SCA dans le seul but de demander un recueil de faits par téléphone avec le client.

L’option Téléversement de documents dans MDSC permet aux clients de présenter leurs documents à l’appui à Service Canada de manière sécurisée et efficace. Si un client demande à envoyer des documents par courriel, il faut plutôt l’encourager à utiliser l’option Téléversement de documents. Actuellement, les employeurs ne sont pas en mesure de téléverser des documents vers Service Canada. La plupart des employeurs préfèrent envoyer les documents par courriel plutôt que par courrier ou par télécopieur.

À l’heure actuelle, les seules voies sécurisées permettant à un employeur de présenter des documents à Service Canada sont le courrier ou la visite en personne à un Centre Service Canada. Les employeurs devraient être dissuadés d’utiliser toute autre méthode de transmission de documents. Des ressources supplémentaires sont disponibles sur la page Sécurité ministérielle concernant la transmission sécurisée de renseignements sensibles.
       [Sécurité ministérielle](https://iservice.prv/fra/si/securite/index.shtml)

Au cours du recueil de faits, une partie concernée peut demander à un agent de s’inscrire pour recevoir des messages électroniques sécurisés liés à une demande de renseignements et de documentation. Les agents ne sont pas autorisés à utiliser ces services de courriel sécurisé et la Directive sur l’utilisation du réseau d’EDSC interdit aux agents d’utiliser une adresse de courriel gouvernementale pour s’inscrire à ces services.
       [Directive sur l’utilisation du réseau d’EDSC](https://iservice.prv/fra/si/securite/outils_et_ressources/trousse_outils/edsc_directive_utilisation_reseau.shtml)

**4.4 Consigner la décision et la justification**

Des documents essentiels, un recueil de faits adéquat et une documentation appropriée sont nécessaires pour appuyer toutes les décisions.

Les décisions varient dans leur complexité et dans la mesure où elles doivent être appuyées par des preuves et par une justification écrite. Il peut parfois être difficile de savoir qui est responsable de rendre la décision. Toutefois, il existe un processus cohérent à suivre pour toutes les décisions. Le Tableau de délégation des pouvoirs en matière d’AE et la Politique nationale sur les niveaux de décision fournissent des indications à ce sujet. Le niveau décisionnel de l’agent qui doit rendre la décision dépend de la description de poste de l’agent, de son autorité en vertu du Tableau de délégation des pouvoirs en matière d’AE et de la Politique nationale sur les niveaux de décision , de sa formation et de la complexité de la question.
       [Tableau de délégation des pouvoirs en matière d’AE](https://iservice.prv/fra/finance/DELEG/vigueur/ae/tableau_delegation_pouvoir_assurance_emploi.pdf) 
       [Politique nationale sur les niveaux de décision](/fr/policy/nationalpolicy/levels_decision.shtml) 
       [Tableau de délégation des pouvoirs en matière d’AE](https://iservice.prv/fra/finance/DELEG/vigueur/ae/tableau_delegation_pouvoir_assurance_emploi.pdf) 
       [Politique nationale sur les niveaux de décision](/fr/policy/nationalpolicy/levels_decision.shtml)

Les décisions de Niveau 1 peuvent nécessiter un rapport de décision (RD). Les procédures opérationnelles doivent être consultées pour déterminer quand un RD est requis au Niveau 1.

Les décisions de Niveau 2 nécessitent un RD. Ces décisions sont fondées sur les renseignements recueillis au moyen d’un recueil de faits auprès de toutes les parties concernées. Une fois le recueil de faits terminé, une décision est rendue en examinant tous les renseignements recueillis et la crédibilité de la source des renseignements, en consultant le GDA, en interprétant la LAE et le RAE, en appliquant la jurisprudence et en faisant preuve de jugement et de discernement. Les justifications doivent indiquer la question sur laquelle une décision a été rendue et expliquer pourquoi celle-ci a été rendue. Le RD doit inclure des références pour appuyer la décision (p. ex. LAE, RAE, GDA, etc.). Il doit également inclure des références à la jurisprudence pertinente et récente, ainsi que tout autre document de référence utilisé pour rendre et appuyer la décision.

La justification doit démontrer que les principes de justice naturelle ont été respectés. Un lien doit être établi entre les faits et la décision rendue. Les sentiments, les opinions et les croyances personnels ne doivent jamais servir à justifier une décision, car la législation doit appuyer la décision.

La justification ne devrait pas être un résumé de tous les éléments de preuve recueillis, mais devrait mettre en évidence les éléments de preuve pertinents. La justification devrait donc être concise, mais comprendre des références, au besoin, au bénéfice du doute, à la crédibilité et aux autres solutions raisonnables, car il s’agit souvent d’éléments essentiels lors de la prise de décision.

Il faut rédiger un RD distinct pour chaque décision individuelle, en veillant à ce que le titre précise le litige, la décision et l’employeur, au besoin. Ceci permet de mieux organiser le dossier et d’accroître l’efficacité. Une décision sur toutes les questions litigieuses doit être rendue, à moins de dispositions contraires dans la politique opérationnelle et dans les procédures. Par exemple, si le client n’est pas admissible en raison du MCE et que la disponibilité est également un litige, une décision doit aussi être rendue sur la disponibilité, quelle que soit la décision rendue sur l’autre question litigieuse. Ceci est important dans le cas où le client présente un appel et obtient l’annulation d’une des décisions.

**4.4.1 Pouvoir discrétionnaire**

Selon le libellé de certains extraits de la LAE 1 , la Commission a l’obligation supplémentaire de fournir une justification détaillée de sa décision dans certains cas. La Cour fédérale a établi que :

- certaines décisions sont rendues en vertu d’un pouvoir discrétionnaire qui appartient uniquement à la Commission;

- le CAAE ne peut pas annuler ou modifier les décisions qui ont été rendues par la Commission en utilisant son pouvoir discrétionnaire, à moins que la Commission ne réussisse pas à démontrer qu’elle a exercé son pouvoir discrétionnaire de manière judicieuse 2 ;

- le test permettant de déterminer si un pouvoir discrétionnaire a été exercé de manière judicieuse se fonde uniquement sur la justification écrite de la décision.

Une décision discrétionnaire doit répondre à des critères encore plus élevés quand il s’agit de consigner la justification de la décision. La justification écrite doit expliquer quels facteurs ont été utilisés pour rendre la décision discrétionnaire et, au besoin, quels facteurs ont été ignorés. La justification doit expliquer en détail comment et pourquoi la décision a été rendue.

Par exemple, quand un acte délictueux est prouvé, la décision d’imposer une pénalité et la détermination du montant de la pénalité sont des décisions discrétionnaires. L’agent doit clairement indiquer dans un RD les faits qui ont été pris en compte et ceux qui ont été exclus pour décider qu’une pénalité est justifiée. L’agent doit également démontrer comment le montant de la pénalité a été calculé afin de montrer que la Commission a rendu cette décision de manière judicieuse.

     [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/common_notes/note_c_0362.dita) 

**4.5 Communication de la décision**

La LAE 48(3) stipule que la Commission est tenue de rendre une décision relative à la demande initiale de prestations du client et d’aviser ce dernier de cette décision. La LAE 53 prévoit que la Commission peut aviser la personne de la manière qu’elle juge adéquate.
       [LAE 48(3)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-48.html) 
       [LAE 53](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-53.html)

La LAE ne prévoit aucune disposition concernant les situations dans lesquelles le client doit être avisé verbalement ou par écrit. Pour assurer l’uniformité de l’application de la LAE 48(3) , la présente politique précise quand un client doit être avisé verbalement ou par écrit d’une décision sur sa demande et informé de son droit de demander une révision :
       [LAE 48(3)](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-48.html)

- Un client doit être avisé verbalement et par écrit d’une décision négative de Niveau 2 et de son droit de révision ou d’appel. L’obligation d’aviser verbalement et par écrit le client de la décision dans ces circonstances vise à s’assurer que le client a eu l’occasion de fournir tout fait qu’il aurait oublié de fournir et qui pourrait avoir une incidence sur la décision rendue sur sa demande. L’avis écrit permet de s’assurer que le client est conscient de son droit de demander une révision et constitue pour la Commission la preuve que la décision et les droits de révision ont été communiqués au client.

- Un client doit être avisé d’une décision de Niveau 1 et de son droit de demander une révision quand cette décision entraîne le non-paiement de prestations. L’avis peut être verbal ou écrit. L’avis doit mentionner le droit du client de demander une révision. Si le client est informé verbalement de cette décision, qu’il est informé de son droit de demander une révision et qu’il est d’accord avec la décision, il n’est pas nécessaire de lui envoyer une lettre, sauf si les procédures le précisent. Si le client ne comprend pas ou n’est pas d’accord avec la décision rendue, l’agent de Niveau 1 envoie un avis écrit au client. La Commission doit être en mesure de démontrer que le client a reçu l’avis et la façon dont il a été transmis. Par conséquent, quand on examine une demande, il doit être facile de voir si le client a reçu un avis verbal ou écrit.

- Un client doit être avisé par écrit de la date de début et de fin de son accord et de son droit de révision quand il opte pour un accord pour les prestations pour les travailleurs indépendants, ou l’annule ou le termine.

Toutes les tentatives pour joindre un client afin de l’aviser verbalement d’une décision négative doivent être consignées dans un RSDP. Quand il est clair lors d’un recueil de faits au Niveau 2 auprès du client, que la question litigieuse ne sera pas autorisée, l’agent de Niveau 2 peut consigner l’avis verbal d’une décision à la fin du même RSDP que celui du recueil de faits lié à cette question. Cela est seulement autorisé quand le client est avisé de la décision négative au cours du même appel téléphonique que le recueil de faits. Dans les cas pour lesquels il y a plus d’un appel téléphonique avec le client, pour effectuer le recueil de faits et ensuite pour l’aviser de la décision, des RSDP distincts sont nécessaires. Dans un RSDP, l’agent de Niveau 2 doit consigner la date et l’heure auxquelles la décision a été communiquée lors de l’appel téléphonique, et si le client a fourni des renseignements supplémentaires au moment de l’avis. Le RSDP doit contenir des renseignements détaillés, comme indiqué à la section 4.2 de cette politique. Il n’est pas acceptable de laisser un message vocal ou un message à une tierce personne, car ceci ne constitue pas une communication verbale de la décision. Dans tous les cas, un avis écrit doit être envoyé au client quand une question litigieuse n’a pas été autorisée. Pour assurer une interprétation appropriée de ce qui est entendu par tentatives de communiquer avec une partie intéressée, consulter la section 3.6 de cette politique.
       [section 4.2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s4_2) 
       [section 3.6](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/fr_FR/policy/nationalpolicy/national_policy_factfinding#s3_6)

Si l’employeur est considéré comme une partie intéressée, il doit être informé par écrit de la décision de la Commission de verser des prestations et de son droit de demander une révision. Les employeurs sont considérés comme des parties intéressées pour les questions d’inconduite et de conflits collectifs, ainsi que pour les questions de départ volontaire et de refus d’un emploi, si les raisons du départ ou du refus sont liées au travail.

**4.6 Langues officielles**

La Partie IV de la Loi sur les langues officielles accorde à tout membre du public au Canada le droit de communiquer avec les institutions fédérales et d’en recevoir les services dans la langue officielle de son choix. Elle établit également que chaque institution fédérale a l’obligation de veiller à ce que tout membre du public puisse communiquer avec son siège ou son administration centrale et en recevoir les services dans l’une ou l’autre des langues officielles, et qu’elle a la même obligation à l’égard de ses autres bureaux ou installations.
       [Partie IV de la Loi sur les langues officielles](https://laws-lois.justice.gc.ca/fra/lois/o-3.01/page-2.html)

Les communications avec un membre du public dans la langue officielle de son choix, qu’elles soient écrites ou orales, ont préséance sur le droit de l’agent de travailler dans la langue officielle de son choix. L’agent doit consigner les renseignements reçus du client dans la langue officielle indiquée dans la demande dans les situations suivantes :

- lors de l’offre de services au client en personne ou par téléphone;

- lors de la communication de la décision à un client.

La langue officielle de communication choisie par le client doit être respectée et prise en considération. Quand un client choisit de communiquer dans une langue officielle autre que celle précisée dans la demande, l’agent doit écrire et consigner les déclarations du client dans la langue utilisée par ce dernier au moment de faire la déclaration. Ceci assurera que le Ministère respecte son obligation en vertu de la Partie IV de la Loi sur les langues officielles .
       [Partie IV de la Loi sur les langues officielles](https://laws-lois.justice.gc.ca/fra/lois/o-3.01/page-2.html)

Les déclarations obtenues d’autres parties (un employeur ou une personne autre que le client) doivent être consignées dans la langue officielle utilisée par la personne fournissant les renseignements, même si elle diffère de la langue officielle choisie par le client.

La Partie V de la Loi sur les langues officielles énonce les circonstances dans lesquelles les employés de certaines régions ont le droit d’utiliser le français ou l’anglais quand ils travaillent au sein d’un ministère fédéral (p. ex. quand ils participent à des réunions, reçoivent des directives ou rédigent des documents internes).
       [Partie V de la Loi sur les langues officielles](https://laws-lois.justice.gc.ca/fra/lois/o-3.01/page-2.html)

Un RD pour une décision non discrétionnaire est considéré comme un document de travail interne créé par un agent dans l’exercice de ses fonctions. L’agent indique et résume dans le RD les faits pertinents, la jurisprudence, les principes de décision et les autres références utilisés pour rendre la décision. Le RD n’est pas un moyen de communication pour transmettre la décision au client. Par conséquent, il n’est pas nécessaire que le RD soit rédigé dans la langue de choix du client ou traduit si ce dernier demande une copie de son dossier en vertu de la Loi sur la protection des renseignements personnels . Toutefois, si un RD est en appui à une décision discrétionnaire, il doit être rédigé dans la langue de choix du client. Des renseignements supplémentaires sur le pouvoir discrétionnaire se trouvent à la section 4.4.1 de la présente politique.
       [Loi sur la protection des renseignements personnels](https://laws-lois.justice.gc.ca/fra/lois/p-21/index.html) 
       [section 4.4.1](/fr/policy/nationalpolicy/national_policy_factfinding.shtml#s4_4_1)

**4.7 Confidentialité**

Même si les renseignements sur les demandes d’AE sont assujettis à la Loi sur la protection des renseignements personnels et à la Loi sur l’accès à l’information , ils ne sont pas classés comme des documents confidentiels. En effet, les détails fournis par le client sur son employeur peuvent être consultés par ce dernier et vice versa dans l’éventualité d’un appel. De plus, les renseignements de la demande peuvent en fait être éventuellement disponibles au public. Dans certaines circonstances, par exemple, des membres du public peuvent assister à l’audience devant le CAAE, la Cour fédérale ou la Cour Suprême.
       [Loi sur la protection des renseignements personnels](http://laws-lois.justice.gc.ca/fra/lois/P-21/index.html) 
       [Loi sur l’accès à l’information](http://laws-lois.justice.gc.ca/fra/lois/A-1/)

La jurisprudence (c.-à-d. les décisions du TSS et CAAE, de la Cour fédérale et de la Cour Suprême), qui renvoie souvent aux renseignements contenus dans les documents d’appel, relève du domaine public.

L’agent doit fournir ces explications sur la confidentialité à toute personne qui fait une déclaration et demande que les renseignements qu’elle a fournis demeurent confidentiels. C’est pourquoi l’agent doit prendre toutes les précautions nécessaires quand il rédige un rapport d’entrevue qui contient des renseignements personnels.

De plus, si le client, l’employeur ou une tierce personne demande que les renseignements qu’il a fournis demeurent confidentiels, l’agent doit l’informer que, ce faisant, les renseignements ne peuvent pas être considérés au moment de rendre la décision, sauf en cas de départ volontaire pour motif de harcèlement sexuel (consulter le GDA 6.4.4 ).
       [GDA 6.4.4](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-6/test-en-matiere-de-justification.html#a6_4_4)

**4.8 Protection des informateurs**

Quand une personne, autre que le client impliqué ou un employé du gouvernement du Canada, fournit des renseignements comprenant une allégation, un doute ou un fait démontrant que cette personne est impliquée dans un acte délictueux ou un abus du programme d’AE, cela est considéré comme une dénonciation d’une tierce personne.

Ces dénonciations par de tierces personnes sont protégées. Tous renseignements qui peuvent révéler l’identité d’un informateur ne doivent jamais être divulgués et doivent être conservés de façon à en éviter la divulgation. Les dénonciations par de tierces personnes et tous les renseignements supplémentaires liés à la dénonciation doivent être consignés sur papier. Ils ne doivent jamais être consignés dans le dossier électronique du client. Les employés de Service Canada doivent utiliser le formulaire Renseignements de tiers (Dénonciation) (INS5204) .
       [Renseignements de tiers (Dénonciation) (INS5204)](http://forms-formulaires.prv/lc/content/EForms/fr/Detail.html?Form=INS5204)

**5. Gestion et conservation des renseignements**

La Commission a la responsabilité de recueillir les renseignements nécessaires pour appuyer les décisions sur les demandes de prestations d’AE. Toutefois, EDSC est responsable de la conservation et de la destruction de la documentation recueillie.
       [EDSC](https://iservice.prv/fra/giti/sgi/clients/index.shtml)

Tous les renseignements, quel que soit le support ou le format, doivent être conservés de manière à garantir leur authenticité, leur exactitude, leur intégrité, leur disponibilité et leur exhaustivité, aussi longtemps que nécessaire. L’incapacité de produire la documentation quand elle est requise pourrait compromettre les décisions et remettre en question la crédibilité de ces dernières. La documentation recueillie fournit la base factuelle pour les révisions et les appels, les vérifications des demandes, ou pour la résolution de tout litige concernant une décision, que ce soit au moyen d’un processus interne, d’un système d’appel ou d’une procédure judiciaire.

La documentation recueillie ou reçue doit être identifiée et conservée conformément aux pratiques et aux principes de saine gestion des documents. La documentation reçue ou créée appartient au ministère et, ultimement, au gouvernement du Canada.

La Politique sur les services et le numérique ainsi que la Directive sur les services et le numérique décrivent les exigences qui doivent être respectées pour la possession, la consultation et la protection des documents. EDSC est le seul responsable de la décision de détruire les documents et du moment de leur destruction.
       [Politique sur les services et le numérique](https://www.tbs-sct.canada.ca/pol/doc-fra.aspx?id=32603) 
       [Directive sur les services et le numérique](https://www.tbs-sct.canada.ca/pol/doc-fra.aspx?id=32601) 
       [EDSC](https://iservice.prv/fra/giti/sgi/clients/index.shtml)

L’accès aux dossiers est accordé selon le principe du besoin de savoir. Par conséquent, les employés ne peuvent avoir accès qu’aux documents dont ils ont besoin pour effectuer leur travail.

**6. Responsabilités**

**6.1 Administration centrale**

L’administration centrale est responsable d’élaborer et d’appliquer cette politique. Elle est aussi responsable de développer et de mettre à jour les processus, les outils et les procédures, ainsi que de développer les formations pour la mise en œuvre de la politique.

**6.2 Régions et centres d’appels**

Les directeurs et gestionnaires des services de traitement et de paiement d’AE régionaux, les directeurs et gestionnaires des services d’Intégrité régionaux et les directeurs et gestionnaires des centres d’appels de l’AE sont responsables d’assurer la mise en œuvre de la politique, et de s’assurer qu’aucune modification ne soit faite sans le consentement explicite du directeur ou de la directrice de la Politique opérationnelle de l’AE. 

### Remarque

Source topic: `fr_FR/common_notes/note_c_0362.dita`

Remarque :

- Les décisions rendues en vertu de la LAE 7.1(4), 28 , 38 , 39 , 41 , 41.1 , 52 , et 111 sont considérées par les cours comme étant rendues en vertu d’un pouvoir discrétionnaire. Une indication à cet effet est que certains de ces articles stipulent « la Commission peut ».
         [LAE 7.1(4),](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-7.1.html) 
         [28](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-28.html) 
         [38](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-7.html#h-211045) 
         [39](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-7.html#h-211045) 
         [41](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-41.html) 
         [41.1](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-41.1.html#docCont) 
         [52](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-52.html) 
         [111](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-111.html)

- McLean ( CAF A-549-99 ), Chartier ( CAF A-42-90 ).
         [CAF A-549-99](https://www.ae.gc.ca/fra/politique/appels/Cour_federale/Cour_d-appel_federale/A054999.shtml) 
         [CAF A-42-90](https://www.ae.gc.ca/fra/politique/appels/Cour_federale/Cour_d-appel_federale/A004290.shtml)

     [LAE 7.1(4),](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-7.1.html) 
     [28](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-28.html) 
     [38](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-7.html#h-211045) 
     [39](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/page-7.html#h-211045) 
     [41](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-41.html) 
     [41.1](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-41.1.html#docCont) 
     [52](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-52.html) 
     [111](https://laws-lois.justice.gc.ca/fra/lois/e-5.6/section-111.html) 
     [CAF A-549-99](https://www.ae.gc.ca/fra/politique/appels/Cour_federale/Cour_d-appel_federale/A054999.shtml) 
     [CAF A-42-90](https://www.ae.gc.ca/fra/politique/appels/Cour_federale/Cour_d-appel_federale/A004290.shtml) 
