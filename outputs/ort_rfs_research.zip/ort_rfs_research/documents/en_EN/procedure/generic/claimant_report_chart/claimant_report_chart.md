# Claimant’s report: Procedures related to claimant's report pieces — Instructions

Source map: `en_EN/procedure/generic/claimant_report_chart/claimant_report_chart.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/claimant_report_chart/generic.dita`

```text
| Client’s statement | Action |

| out of Canada | Consult the Out of Canada procedure and then return to this chart. [Out of Canada](/en/procedure/activity/out_canada.shtml) |

| work and wages | Consult any of the following applicable procedures for possible disentitlements and then return to this chart. - Part-time employment [Part-time employment](/en/procedure/task/availability_pt.shtml) - Not unemployed [Not unemployed](/en/procedure/activity/not_unemployed.shtml) - Self-employment [Self-employment](/en/procedure/activity/self_employed.shtml) - Farming [Farming](/en/procedure/activity/self_employed.shtml#farming) [Part-time employment](/en/procedure/task/availability_pt.shtml) [Not unemployed](/en/procedure/activity/not_unemployed.shtml) [Self-employment](/en/procedure/activity/self_employed.shtml) [Farming](/en/procedure/activity/self_employed.shtml#farming) |

| stopped working | Consult any applicable reason for separation procedure below and then return to this chart. - Dismissal [Dismissal](/en/procedure/activity/dismissal.shtml) - Voluntary leaving [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml) [Dismissal](/en/procedure/activity/dismissal.shtml) [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml) |

| training | Consult the appropriate training procedure and then return to this chart. - Referred training [Referred training](/en/procedure/activity/training.shtml#referredt) - Apprenticeship training [Apprenticeship training](/en/procedure/activity/training.shtml#appenticeships) - Non-referred training [Non-referred training](/en/procedure/activity/training.shtml) [Referred training](/en/procedure/activity/training.shtml#referredt) [Apprenticeship training](/en/procedure/activity/training.shtml#appenticeships) [Non-referred training](/en/procedure/activity/training.shtml) |

| not available | Consult any of the following applicable procedures for possible disentitlements and then return to this chart. - Availability [Availability](/en/procedure/activity/availability.shtml) - Not otherwise available [Not otherwise available](/en/procedure/task/no_available.shtml) - Vacation in Canada [Vacation in Canada](/en/procedure/activity/vacation.shtml) - Conversion procedures (e.g. if the client is collecting regular benefits and not available, determine if another type of benefits is applicable to the client’s situation) [Conversion](/en/procedure/activity/conversions.shtml) [Availability](/en/procedure/activity/availability.shtml) [Not otherwise available](/en/procedure/task/no_available.shtml) [Vacation in Canada](/en/procedure/activity/vacation.shtml) [Conversion](/en/procedure/activity/conversions.shtml) |

| sickness | Consult the Conversion to Sickness procedure and then return to this chart. [Conversion to Sickness](/en/procedure/activity/conversions.shtml) |

| other monies | Consult the Earnings procedure and then return to the claimant’s report procedure for input. *If an allocation is input, the monies declared are not coded on the report. [Earnings](/en/procedure/activity/earnings.shtml) |
``` 
