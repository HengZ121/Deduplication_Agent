# Determining the recovery week — Instructions

Source map: `en_EN/procedure/generic/determing_the_recovery_week_instruction/determing_the_recovery_week_instruction.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/determing_the_recovery_week_instruction/generic.dita`

Summary: Clients requesting sickness benefits must obtain a medical certificate that proves their inability to work due to illness, injury or quarantine. If the client submits a medical certificate, the officer must review it to ensure it is acceptable and use it to determine the recovery week.

**Incapacity end date**

The incapacity end date is the last day on which the client is incapable of working. The period of incapacity ends the day before the recovery date. When the medical certificate indicates that the client is incapable of working until a specific date, that date is the last day of the incapacity.

**Recovery date**

The recovery date is the first day the client is capable of working. This is the day after the incapacity end date. The medical certificate is used to determine the recovery date.

**Recovery week**

The recovery week is the week up to which sickness benefits are payable.

If there is a specific recovery date on the medical certificate that is Tuesday to Saturday, the recovery week is the same week.

If there is a specific recovery date on the medical certificate that is on a Sunday or Monday (i.e. the incapacity end date is a Saturday or Sunday), the recovery week is the preceding week.

During the transition from one calendar year to the next, a doctor or other medical professional may write the calendar year incorrectly on a medical certificate regarding a client’s period of incapacity. It is not necessary to clarify with the client when there is no doubt this was done in error due to the change in the year. This applies to January and February of each year.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0829.dita) 

**Determining the recovery week**

When the client has submitted a medical certificate, the officer refers to Determining if a medical certificate is acceptable before determining the recovery week. The recovery week is determined based on the medical certificate’s information, even if the medical certificate on file was not requested. Before determining the recovery week, the officer refers to Sickness: Incapacity start date — Table to determine if an incapacity start date is required and if yes, what the incapacity start week will be.
       [Determining if a medical certificate is acceptable](/en/procedure/task/determining_med_cert_valid.shtml) 
       [Sickness: Incapacity start date — Table](/en/procedure/generic/additionalresources/incapacity_start_date_sb.shtml)

**Entering or updating the recovery week**

For an initial claim, the officer enters the recovery week in the Estimated or actual date of recovery field on the Annex - Special Benefits screen in SSO when a medical certificate is submitted.

For a renewal or continuing claim, the officer updates the recovery week in FTS.

**Determining the recovery week on an initial claim**

For a BPC in w/c 2442 or later, a recovery week of BPC + 8 weeks can be allowed when the reason for separation (RFS) is D - Illness or injury on claims for sickness benefits or sickness benefits followed by maternity benefits.

For a BPC in w/c 2441 or earlier, when the RFS is D , the officer can allow a recovery week of BPC + 15 weeks on a claim for sickness benefits or BPC + 8 weeks on a claim for sickness benefits followed by maternity benefits.

**Determining the recovery week on a claim with a 16 - No medical certificate submitted disentitlement (D16)**

If a client does not submit a medical certificate when it is requested on a claim for sickness benefits, the officer imposes a D16. If the client subsequently submits the medical certificate, the officer determines the period of incapacity using the medical certificate. If the medical certificate confirms the entire period of incapacity the client indicated, the officer rescinds the D16. If the medical certificate only confirms part of the period of incapacity the client indicated, the officer modifies the D16.

**Determining the recovery week on a claim for a client already receiving sickness benefits**

When a client who is already receiving sickness benefits submits a medical certificate, the officer determines the new recovery week based on the medical certificate information.

If a claim for sickness benefits was initially established with a recovery week of BPC + 8 weeks or renewal week + 8 weeks, the officer does not change the original recovery week when both of the following conditions are met:

- The client subsequently submits a medical certificate with no recovery date, or with a recovery date that is undetermined, unknown, uncertain or indefinite.

- Applying the recovery week guidance for these situations ([the week that includes the date of the doctor or other medical professional’s signature + 8] or [the week that includes the date of the medical consultation + 8]) would result in a recovery week that is earlier than BPC + 8 weeks or renewal week + 8 weeks.

If the client has been paid sickness benefits after the recovery date indicated, the officer imposes a D16 for the period of incapacity that is not indicated on the medical certificate.

**Determining the recovery week on a conversion from regular to sickness benefits when casual sickness benefits have been paid**

A client who is receiving regular benefits, including fishing benefits, can declare up to 4 consecutive weeks of casual sickness benefits. If the client declares a fifth week of casual sickness, the claimant’s report is rejected with the error code C465. If the client requests additional sickness benefits after 4 consecutive weeks have been declared, whether benefits have been paid or not, a conversion to a claim for sickness benefits is required.

A maximum of 8 weeks of casual sickness benefits in total can be paid in a benefit period (BP). If the client declares a ninth week of casual sickness, the claimant’s report is rejected with the error code C484. A client who has already received 8 weeks of casual sickness benefits and who is still incapable of working must submit a medical certificate and request a conversion to a claim for sickness benefits.

When a client has already received casual sickness benefits and requests a conversion to a claim for sickness benefits, the client does not need to submit a medical certificate if fewer than 8 weeks of casual sickness benefits have been paid in the BP. The officer determines the recovery week as follows:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0830.dita) 

The officer determines the number of weeks of casual sickness benefits paid in a BP by referring to the Casual sickness weeks field on the Summary or Special Benefits tab in FTS. When determining the recovery week, the officer must use only the casual sickness weeks counter to obtain the number of weeks of casual sickness benefits paid.

**Determining the recovery week on a claim for sickness benefits followed by maternity benefits**

When a client requests sickness benefits immediately followed by maternity benefits, the officer refers to the chart below to determine the recovery week. If the recovery week is within the maternity window, an external maternity start week is required to pay sickness benefits up to the recovery week. When the external maternity start week is reached, the system automatically converts the claim to maternity benefits. If the officer does not input an external maternity start week, maternity benefits automatically begin at the start of the maternity window.

After the officer obtains a calculation result in SSO, on an initial claim, the officer changes the recovery week to an administrative indefinite recovery week on the M103 - Initial Decision (M103) transaction ( Yes must be indicated under Is Indefinite? ). This ensures that SSO does not postdate the claim incorrectly. On a renewal or continuing claim, the officer inputs an administrative recovery week of 99-99-9999 on the Renewal/Revised (M106) transaction.

If the recovery week is before the start of the maternity window, the officer does not adjust the actual recovery week on the M103 transaction. On a renewal or continuing claim, the officer inputs the actual recovery week on the M106 transaction. There will be a gap between the last payment of sickness benefits and the start of maternity benefits payments. If the client is still incapable of working for medical reasons, the client must submit another medical certificate to extend the recovery week. If the recovery week cannot be extended on a claim for sickness benefits, the client must submit a renewal application for maternity benefits at the start of the maternity window.

**Recovery week on initial, renewal or conversion on a continuing claim**

```text
| Information on file | Recovery week |

| A medical certificate has not been requested or submitted. | For an initial claim, the Estimated or actual date of recovery field on the Annex - Special Benefits screen in SSO must be left blank. SSO calculates the recovery week as BPC + 8 weeks on a claim for sickness benefits or sickness benefits followed by maternity benefits. For a renewal claim, the recovery week is the renewal week + 8 weeks. For a conversion claim in which no casual sickness benefits have been paid, the recovery week is the conversion week + 8 weeks. For a conversion claim in which casual sickness benefits have been paid, the recovery week is as follows: [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0831.dita) A client who has already received a total of 8 weeks of casual sickness benefits and who is still incapable of working must submit a medical certificate and request a conversion to a claim for sickness benefits. Determine the number of weeks of casual sickness benefits paid in a BP by referring to the Casual sickness weeks field on the Summary or Special Benefits tab in FTS. When determining the recovery week, use only the casual sickness weeks counter to obtain the number of weeks of casual sickness benefits paid. For examples of calculating the recovery week when casual sickness benefits have been paid, refer to [Converting a claim from regular to sickness benefits](/en/procedure/task/conv_regsick.shtml) and [Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim](/en/procedure/task/conv_regsick_eia25.shtml) . [Converting a claim from regular to sickness benefits](/en/procedure/task/conv_regsick.shtml) [Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim](/en/procedure/task/conv_regsick_eia25.shtml) |

| A medical certificate was requested but has not been submitted (an indefinite D16 is required). | For an initial claim, the Estimated or actual date of recovery field on the Annex - Special Benefits screen in SSO must must be left blank. When inputting the claim, manually enter an administrative indefinite recovery weekon the M103 ( Yes must be indicated under Is Indefinite? ). To automatically generate the D16, enter the due date of the calculation WI in SSO in the Medical certificate — Due date field on the Registration — Outstanding Information screen. If SSO does not automatically generate the D16 during the calculation of the claim, manually create the M161 transaction when transmitting the claim. For a renewal or conversion on a continuing claim, enter an administrative indefinite recovery week of 99-99-9999 and impose a D16 on the M106 transaction in FTS. |

| A medical certificate has been submitted, whether requested or not, and does not indicate a recovery date, or indicates a recovery date that is undetermined, unknown, uncertain or indefinite. | The recovery week is calculated as the week of the incapacity start date + 8 weeks. If the RFS is D on an initial or renewal claim and there are no disqualifications or disentitlements, the recovery week is calculated as BPC + 8 weeks or renewal week + 8 weeks. In all other cases, if the incapacity start date is not indicated on the medical certificate, the recovery week is calculated as the earliest of the following: - the week that includes the date of the doctor or other medical professional’s signature + 8 weeks; - the week that includes the date of the medical consultation + 8 weeks. If the claim was initially calculated without a medical certificate, do not update the recovery week, unless the week of the doctor or other medical professional’s signature + 8 weeks or the week of the medical consultation +8 weeks is later than BPC + 8 weeks or renewal week + 8 weeks (it remains BPC + 8 weeks or renewal week + 8 weeks). |

| The medical certificate indicates terminal or palliative, or the client is entitled to Canada Pension Plan (CPP) disability benefits. | The recovery week is indefinite ( Yes must be indicated under Is Indefinite? ). When the recovery week entered is indefinite (based on a medical certificate that indicates terminal or palliative), SSO automatically postdates the claim by one week if there are earnings in week 1. Do not postdate the BPC of a claim with an indefinite recovery week (based on a medical certificate that indicates terminal or palliative) due to earnings week 1, unless the client has specifically requested the claim be postdated. |

| The medical certificate indicates a specific recovery date. | The recovery date is the specific date indicated on the medical certificate. The recovery week is the week in which the recovery date occurs unless the recovery date is a Sunday or a Monday. In that case, the recovery week is the week before the recovery date. If the medical indicates a reassessment date, this is also considered a specific recovery date. |

| The medical certificate indicates that the client is sick for a definite period or range of time, or will recover in a definite period or range of time. | The recovery week is calculated as the week of the incapacity start date (if indicated on the medical certificate) + [definite number or highest number in the range of time]. If the incapacity start date is not indicated on the medical certificate, the recovery week is calculated as the earliest of the following: - the week that includes the date of the doctor or the other medical professional’s signature + [definite number or highest number in the range of time]; - the week that includes the date of the medical consultation + [definite number or highest number in the range of time]. |

| The medical certificate indicates the client is incapable of working for medical reasons up to the date of birth (DOB). | The recovery week is the week before the expected DOB. Enter an administrative indefinite recovery week on the M103 transaction on an initial claim ( Yes must be indicated under Is Indefinite? ) or 99-99-9999 on the M106 transaction on a renewal or continuing claim. Also enter an external maternity start week equal to the expected DOB (or the actual DOB, if known) or the date of the prearranged maternity leave. If the client lives in Quebec, do not enter maternity information on the Annex - Special Benefits screen in SSO. |
``` 

### Example

Source topic: `en_EN/common_notes/note_c_0829.dita`

Example:

The doctor or other medical professional completed a medical certificate in January 2023 with a recovery date of January 31, 2022 . This is an obvious error, and the recovery date should be considered January 31, 2023 . 

### Callout

Source topic: `en_EN/common_notes/note_c_0830.dita`

[conversion week] + [8 weeks] – [weeks of paid casual sickness] = [recovery week]. 

### Callout

Source topic: `en_EN/common_notes/note_c_0831.dita`

[conversion week] + [8 weeks] – [weeks of casual sickness benefits paid] = [recovery week] 
