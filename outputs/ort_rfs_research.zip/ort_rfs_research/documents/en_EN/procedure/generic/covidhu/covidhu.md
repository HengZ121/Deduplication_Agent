# COVID-19 — Procedural changes

Source map: `en_EN/procedure/generic/covidhu/covidhu.ditamap`

## Covid-19

Source topic: `en_EN/procedure/generic/covidhu/covid-19.dita`

What you can find here:

- COVID-19 procedural changes

- COVID-19 related Headlines and Updates

Each tab provides a different way of searching and accessing information on COVID-19 procedural changes.

List of procedural changes: List of all procedural changes with a short description and link to the relevant Headlines and Updates.

Headlines and Updates: Chronological list of COVID-19 related Headlines and Updates.

For more information, refer to Transition to Employment Insurance – Questions and answers .
       [Transition to Employment Insurance – Questions and answers](https://www.canada.ca/en/services/benefits/ei/cerb-application/transition/ei-questions.html)

**List of procedural changes**

Click on the link to view the related Headlines and Updates.

       [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0828.dita)

**COVID-19 Headlines and Updates**

The procedures are changing rapidly. If the information in a Headlines and Updates is outdated, the Headlines and Updates will be replaced, and the new Headlines and Updates will have a Note explaining what has changed.

```text
| Date | Subject |

| 2024-08-01 | Information: Workload management measure — Post-EI ERB claims The Workload management measure has been updated to reflect that officers no longer reassign revised WIs with a BPC in the post-EI Emergency Response Benefit (post-EI ERB) period. Only WIs with a BPC that falls in the EI ERB period are reassigned to the 1 - Natl Processing & Payments Svcs (PPS) / Specialized EI Processing / Older Revised Work level in NWS. [Information: Workload management measure — Post-EI ERB claims](/en/site/dossier/infor-wmm-post-eierb.shtml) |

| 2022-08-10 | New: Actioning a Work-Sharing to EI ERB Retro-Conversion — Task (IPOC) A new task has been created to help IPOC officers convert a Work-Sharing (WS) claim back to EI Emergency Response Benefit (EI ERB) when the EI ERB claim was converted to WS in error. [New: Actioning a Work-Sharing to EI ERB Retro-Conversion — Task (IPOC)](/en/site/dossier/new_act_a_work_shar_to_ei-erb_retro_conv.shtml) |

| 2022-06-28 | Information: Relief for students with CERB or EI ERB overpayments (June 2022) Students with Canada Emergency Response Benefit (CERB) or Employment Insurance Emergency Response Benefit (EI ERB) overpayments (OPs) who can show that they would have met the eligibility criteria for the Canada Emergency Student Benefit (CESB) do not have to repay amounts equivalent to the benefits they could have received under CESB. [Information: Relief for students with CERB or EI ERB overpayments (June 2022)](/en/site/dossier/info_relief_for_stud_with_cerb_or_erb_overp.shtml) |

| 2022-06-09 | Online Reference Tool (CMS) Access: ort-editor Updated: Removal of the page Modifying a claimant’s report — EI ERB — Task (Level 1, Level 2 and IPOC) Following an unfavourable Social Security Tribunal (SST) decision about EI Emergency Response Benefit (EI ERB) eligibility for clients who were also receiving an income, significant changes to the Modifying a claimant’s report — EI ERB task are required. Since the information on this page is currently inaccurate, the task will be temporarily removed.Following an unfavourable Social Security Tribunal (SST) decision about EI Emergency Response Benefit (EI ERB) eligibility for clients who were also receiving an income, significant changes to the Modifying a claimant’s report — EI ERB task are required. Since the information on this page is currently inaccurate, the task will be temporarily removed. [Online Reference Tool (CMS) Access: ort-editor Updated: Removal of the page Modifying a claimant’s report — EI ERB — Task (Level 1, Level 2 and IPOC)](/en/site/dossier/updated_removal_of_page_modifying_a_claimant_report_eierb.shtml) |

| 2022-05-09 | Updated: EI ERB claims and $2 000 advance payment adjustments — Task (IPOC) The task EI ERB claims and $2 000 advance payment adjustments — IPOC has been updated to include instructions on removing the $2 000 advance payment when it was issued to a third party. [Updated: EI ERB claims and $2 000 advance payment adjustments — Task (IPOC)](/en/site/dossier/updt_eierb_claims_2000_adv_paym_adj_ipoc.shtml) |

| 2022-02-17 | Updated: Informal reconsideration of the EI ERB advance payment — Policy and procedures (Level 1) As part of ongoing efforts to improve the content of the EI ORT, changes have been made to the Reconciling the EI ERB advance payment — Level 1 task. [Updated: Informal reconsideration of the EI ERB advance payment — Policy and procedures (Level 1)](/en/site/dossier/updated_informal_reconsideration_of_the_eierb_advance_payment.shtml) |

| 2022-02-14 | Information: COVID-19 and external communication strategy To facilitate transition to EI benefits after delivering the Canada Emergency Response Benefit (CERB) or the EI Emergency Response Benefit (EI ERB), the Government of Canada is introducing an external communication strategy to provide information to clients and employers. [Information: COVID-19 and external communication strategy](/en/site/dossier/information_covid19_external_communicatioin_strategy.shtml) |

| 2022-02-09 | Updated: Emergency Response Benefit transition provisions — Policy and procedures (Level 1 and Level 2) Following the BE 2020-05 — Emergency Response Benefit Transition Provisions update, changes have been made in the EI ORT to clarify when the temporary measure for self-employed fishers applies. [Updated: Emergency Response Benefit transition provisions — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/updated_emergency_response_benefit_l1_l2.shtml) |

| 2022-01-27 | Updated: EI ERB claims and $2 000 advance payment adjustments — Task (IPOC) The task has been updated to provide IPOC officers with instruction on actioning an Operational Centre Memo (MM06) transaction related to error code B112 in BCS. [Updated: EI ERB claims and $2 000 advance payment adjustments — Task (IPOC)](/en/site/dossier/updated_ei_erb_claims_2000_advance_payment_adjustments_ipoc.shtml) |

| 2021-12-15 | New: Processing an EI ERB repayment — Procedures (Level 1) Many clients repaid the EI Emergency Response Benefit (EI ERB) payments they received to Service Canada. These repayments must be reconciled, which means that an overpayment (OP) must be created in order for National Accounts Receivable to apply the repayment. [New: Processing an EI ERB repayment — Procedures (Level 1)](/en/site/dossier/new_processing_ei_erb_repayement_proc_l1.shtml) |

| 2021-12-10 | New: EI ERB claims and $2 000 advance payment adjustments — Procedures (IPOC) As part of the advance payment reconciliation process, a new task has been created to replace the current COVID-19 and $2 000 advance payment adjustment procedures. [New: EI ERB claims and $2 000 advance payment adjustments — Procedures (IPOC)](/en/site/dossier/new_ei_erb_and_2000_advance_payment_adjustments_procedure_ipoc.shtml) |

| 2021-11-26 | New: Reconciling an EI ERB advance payment — Policy and procedures (Level 1) Overpayments (OPs) established when eligibility to part or all of the $2 000 advance EI Emergency Response Benefit (EI ERB) payment has not been proven may be reconsidered when clients provide new information. [New: Reconciling an EI ERB advance payment — Policy and procedures (Level 1)](/en/site/dossier/new_rec_ei_erb_adv_pay_proc.shtml) |

| 2021-11-24 | Updated: Modifying a claimant’s report — EI ERB claim — Procedures (Level 1) Based on new guidance received from EI Operational Policy Division, a change has been made to how officers modify claimant’s reports on an EI Emergency Response Benefit (EI ERB) claim if a client has declared a full work week (FWW). [Updated: Modifying a claimant’s report — EI ERB claim — Procedures (Level 1)](/en/site/dossier/updated_modifying_claimant_report_ei_erb_proc_l1.shtml) |

| 2021-11-09 | Information: EI ERB advance payment reconciliation Starting in November 2021, the system will determine if the $2 000 advance EI Emergency Response Benefit (EI ERB) payment corresponds to 4 weeks of non payment later in the claim. Weeks of non payment are identified by a served 65 - Lump Sum Payment ($2000) - Canadian Emergency Response code (D65). If a D65 was either not present or not served, an overpayment (OP) is created on the EI ERB claim for all or part of the $2 000 advance payment. [Information: EI ERB advance payment reconciliation](/en/site/dossier/info_ei_erb_advance_payment_reconciliation.shtml) |

| 2021-09-14 | Information: Clients enquiring about the Canada Recovery Benefit after exhausting their EI benefits The maximum number of weeks of the Canada Recovery Benefit (CRB) that clients can receive has been increased by an additional 4 weeks. Because the benefit periods (BPs) for post-EI Emergency Response Benefit (EI ERB) claims are ending in the coming weeks, the agent may receive enquiries from clients about applying for the additional weeks of the CRB. [Information: Clients enquiring about the Canada Recovery Benefit after exhausting their EI benefits](/en/site/dossier/information_enquiring_canada_recovery_benefit_exhausting_ei_benefits.shtml) |

| 2021-08-18 | Information: Recent attempts to identify client EI Access codes and preventative measures put in place In August 2021, the Government of Canada was made aware that there may have been random attempts by unknown sources to identify EI access codes associated with some client’s files. As a preventative measure, the access codes have been reset on impacted files to ensure the security and privacy of clients. |

| 2021-08-13 | New and updated: Referral to Integrity and fraudulent claims — Procedures and additional resource (All levels) To better organize information about referrals to Integrity and EI and EI ERB claim fraud, the Headlines and Updates page Referral to Integrity and fraudulent EI and EI ERB claims is now an additional resource. [New and updated: Referral to Integrity and fraudulent claims — Procedures and additional resource (All levels)](/en/site/dossier/new_updated_referral_to_integrity_fraudulent_claim_procedure_ar_all_level.shtml) |

| 2021-08-10 | Information: Post-EI ERB and Fishing reconsideration letter — Winter fishing To support clients when the EI Emergency Response Benefit (EI ERB) ended, a one-time credit of hours was given. Fishers who also worked in insurable employment received this credit and their claims may have been established as regular EI claims instead of a fishing claim. A letter is being sent out to these clients to determine if they would like their benefits changed from EI regular to EI fishing. [Information: Post-EI ERB and Fishing reconsideration letter — Winter fishing](/en/site/dossier/information_post_eierb_fishing_reconsideration_letter.shtml) |

| 2021-08-03 | Updated: Post-EI ERB interim fishing ROE — Task (Level 1) The task Entering an interim ROE has been updated to include additional information about when an interim ROE can be created to establish a BPNE fishing claim. [Updated: Post-EI ERB interim fishing ROE — Task (Level 1)](/en/site/dossier/updated_post_eierb_interim_fishing_roe.shtml) |

| 2021-08-03 | Information: Government Extends COVID-19 Benefits and Business Supports to Support Stronger Economic Recovery The Government of Canada announced on July 30,2021 that COVID-19 support measures for Canadians and Canadian businesses are extended. [Information: Government Extends COVID-19 Benefits and Business Supports to Support Stronger Economic Recovery](/en/site/dossier/information_covid_19_benefits_and_business_supports.shtml) |

| 2021-07-08 | Information: MSCA functions disabled Starting June 2021, a client registering for or logging in to MSCA must complete multi-factor authentication. One of the options for completing the multi-factor authentication was to use an authenticator application. However, the authenticator application has been disabled. [Information: MSCA functions disabled](/en/site/dossier/updated_msca_function_disabled.shtml) |

| 2021-07-06 | Information: Actioning enquiries from clients who can no longer apply for the Canada Recovery Benefit Effective July 4, 2021, a systems update will prevent some clients who were previously able to apply for and receive the Canada Recovery Benefit (CRB) from continuing to apply for additional weeks of the CRB. [Information: Actioning enquiries from clients who can no longer apply for the Canada Recovery Benefit](/en/site/dossier/information_actioning_enquiries_from_client_who_cant_apply_for_crb.shtml) |

| 2021-04-29 | New: Otherwise available and quarantine after travel — Policy and procedures (Level 1 and Level 2) Each EI case involving a quarantine after travel should be reviewed and adjudicated based on the particular facts of the case. The EI program is designed to provide temporary financial assistance to workers who have lost their job or are unable to work for reasons outside their control. [New: Otherwise available and quarantine after travel — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/new_amqurc.shtml) |

| 2021-04-16 | Updated: Extension of temporary simplification measures — Procedures (Level 1, Level 2 and IPOC) To continue supporting Canadians during the third wave of the COVID-19 pandemic, simplification measures are being extended until September 25, 2021. [Updated: Extension of temporary simplification measures — Procedures (Level 1, Level 2 and IPOC)](/en/site/dossier/updated_extension_temporary_simplification_measures_l1_l2_ipoc.shtml) |

| 2021-04-15 | Updated: Clarification on EI ERB and disability benefits — Policy and procedures (Level 1 and Level 2) The EI-ERB Digest has been updated to clarify that, for the purposes of determining eligibility to EI ERB, disability benefits (including worker’s compensation benefits and wage loss insurance) are excluded from income when determining the $1,000 over four weeks. [Updated: Clarification on EI ERB and disability benefits — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/updated_clarification_eierb_db.shtml) |

| 2021-04-06 | Updated: COVID-19 and initial $2 000 payment adjustments — Procedures (Level 1, Level 2 and IPOC) When a change to the EI Emergency Response Benefit (EI ERB) initial $2 000 payment is required, the agent sends the information on an Operational Centre Memo (MM06) transaction. IPOC is responsible for ensuring the appropriate actions are taken to update the EI ERB data. The Innovation, Information and Technology Branch is responsible to adjusting the initial $2 000 payment. [Updated: COVID-19 and initial $2 000 payment adjustments — Procedures (Level 1, Level 2 and IPOC)](/en/site/dossier/covid19_pay_adj.shtml) |

| 2021-04-01 | Updated: Post EI-ERB and adjudicating reasons for separation — Policy and procedures (Level 1 and Level 2) Effective September 27, 2020, when the EI Emergency Response Benefit (EI ERB) ends, claims whose BPC is w/c 2258 or later and that meet specific criteria for regular and sickness benefits are temporarily being processed through a new specialized ACP process and are established without adjudicating contentious reason for separation (RFS) issues in the qualifying period (QP). A transitional measure related to RFS adjudication is also being implemented as of September 27, 2020. This measure applies to initial claims in the normal ACP process whose BPC is w/c 2258 or later. For these claims, the RFS adjudication principles apply only to contentious ROEs that fall in the 12-week period before the interruption of earnings (I of E) on the client’s last ROE in the QP. [Updated: Post EI-ERB and adjudicating reasons for separation — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/updated_post_eierb_adjudicating_reason_for_separation_policy_procedure_l1_l2.shtml) |

| 2021-04-01 | New: Adjudicating reasons for separation on conversions — Policy and procedures (Level 1 and Level 2) New Policy guidance requires that the agent adjudicate contentious reason for separation (RFS) issues in the qualifying period (QP) when a client requests a conversion from special to regular benefits on claims with a BPC between w/c 2258 and w/c 2309. [New: Adjudicating reasons for separation on conversions — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/new_arsc_pap.shtml) |

| 2021-04-01 | New: Enquiries from clients who are prevented from applying for recovery benefits administered by the Canada Revenue Agency — Procedures and additional resource (Level 1 and Level 2) A new procedure has been developed to address enquiries from clients who have been prevented from applying for benefits administered by the Canada Revenue Agency (CRA) and who have been referred to EI. [New: Enquiries from clients who are prevented from applying for recovery benefits administered by the Canada Revenue Agency — Procedures and additional resource (Level 1 and Level 2)](/en/site/dossier/new_enquiries_from_client_who_are_prevented_from_applying_rb_administered_by_cra.shtml) |

| 2021-03-22 | New and updated: EI special benefits for the self-employed and minimum earnings — Policy and procedures (Level 1 and Level 2) Effective March 21, 2021, an amendment to the EI Act has reduced to $5 000 the minimum self-employed earnings required to qualify for special benefits. This applies to all claims with a BPC between January 3, 2021 (w/c 2272) and September 19, 2021 (w/c 2309). Two additional resources have been updated to reflect the information in BE Memo 2021-02 – Additional Regular Benefits and Access to Benefits for Self-employed persons. [New and updated: EI special benefits for the self-employed and minimum earnings — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/updated_bseme_ad_pp.shtml) |

| 2021-03-10 | Updated: Family supplement — Tasks (IPOC) The task Actioning the LM10242/5 family supplement monthly report — IPOC has been updated. [Updated: Family supplement — Tasks (IPOC)](/en/site/dossier/updated_family_supplement.shtml) |

| 2021-02-26 | Updated: Post-EI ERB and interim fishing ROE — Procedures (Level 1) The Entering an interim ROE task has been updated to provide information on bypassing the sending of the automated letter when the a Fishing claim remains BPNE. [Updated: Post-EI ERB and interim fishing ROE — Procedures (Level 1)](/en/site/dossier/updated_post_eierb_ifroe.shtml) |

| 2021-02-23 | New: Post-EI ERB and antedates to the EI ERB period — Policy and procedures (Level 1, Level 2 and IPOC) If clients request regular or sickness benefits after December 2, 2020 and if an antedated BPC is allowed to the period when only EI Emergency Response Benefit (EI ERB) claims were being established (i.e. between March 15, 2020 and September 26, 2020), they will receive regular or sickness benefits under normal EI rules. [New: Post-EI ERB and antedates to the EI ERB period — Policy and procedures (Level 1, Level 2 and IPOC)](/en/site/dossier/new_post_eierb_antedates_eiorbp.shtml) |

| 2021-02-23 | Information: Post-EI ERB and Fishing reconsideration letter — Summer fishing To support clients when the EI Emergency Response Benefit (EI ERB) ended, a one-time credit of hours was given. Fishers who also worked in insurable employment received this credit and their claims may have been established as regular EI claims instead of a fishing claim. A letter is being sent out to these clients to determine if they would like their benefits changed from EI regular to EI fishing. [Information: Post-EI ERB and Fishing reconsideration letter — Summer fishing](/en/site/dossier/eierbf_puaep.shtml) |

| 2021-02-19 | Information: Increase to number of weeks for EI regular benefits and recovery benefits The Government of Canada announced today its intent to introduce regulatory and legislative amendments to increase the number of weeks of benefits available for the Canada Recovery Benefit (CRB), the Canada Recovery Sickness Benefit (CRSB), the Canada Recovery Caregiving Benefit (CRCB) and EI regular benefits. [Information: Increase to number of weeks for EI regular benefits and recovery benefits](/en/site/dossier/information_increase_to_number_of_weeks_ei_regular_benefit_recovery_benefit.shtml) |

| 2021-02-12 | New: Reason for separation adjudication on renewals — Policy and procedures (Level 1 and Level 2) Adjudication of contentious reason for separation (RFS) issues in the qualifying period (QP) of claims processed through the specialized process is not required on renewal claims as long as the client is still requesting regular benefits. [New: Reason for separation adjudication on renewals — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/new_rfsaor_policy_procedures.shtml) |

| 2021-02-11 | Updated: Issuing and amending T4Es — Procedures and additional resource (IPOC) Minor changes have been made to some T4E procedures and to an additional resource for the regional tax coordinators (RTCs). [Updated: Issuing and amending T4Es — Procedures and additional resource (IPOC)](/en/site/dossier/updated_iaat4e_1.shtml) |

| 2021-02-09 | Updated: Post-EI ERB and cancelling EI ERB claims for failing to provide proof of identification — Task (Level 1) The Cancelling a claim when the client does not provide proof of identity — Initial claim task has been updated with instructions to void an EI Emergency Response Benefit (EI ERB) claim when the client submits a new application in which the SIR non-match elements are the same as those on an EI ERB application that was not automatically enrolled and for which the client’s identity is not validated. [Updated: Post-EI ERB and cancelling EI ERB claims for failing to provide proof of identification — Task (Level 1)](/en/site/dossier/updated_post_eierb_cancelling_eierb.shtml) |

| 2021-02-09 | Information: Canada Emergency Response Benefit and Self-employment income Clarifications are being provided on the required $5000 earnings threshold to qualify for the Canada Emergency Response Benefit. [Information: Canada Emergency Response Benefit and Self-employment income](/en/site/dossier/cerb_se-pcu_ti.shtml) |

| 2021-02-08 | Updated: Post-EI ERB and N8 for Assessment Issue BPNE WIs — Task (Level 1) The Post-EI ERB — Completing an Assessment Issue BPNE WI task has been updated to include a workaround for claims when the clients has no interruption of earnings (I of E) and the claim result should be BPNE N8. [Updated: Post-EI ERB and N8 for Assessment Issue BPNE WIs — Task (Level 1)](/en/site/dossier/updated_post_eierb_n8_aibpne.shtml) |

| 2021-02-04 | Information: EI ERB and payment reconciliation Clients who received the EI Emergency Response Benefit (EI ERB) will have their claims reviewed to ensure that all payments, including the initial payment, are reconcile to the EI ERB claim. [Information: EI ERB and payment reconciliation](/en/site/dossier/information_eierb_pr.shtml) |

| 2021-02-01 | Information: T4E Enquiry – Workload strategy T4E will be available Monday, February 1st, 2021 in My Service Canada Account (MSCA). As ESDC is expecting a high volume of T4E enquiries, a workload strategy has been put in place to mitigate the impact on Regional Tax Coordinator (RTC)s workload in IPOC and to address client inquiries in a timely manner. [Information: T4E Enquiry – Workload strategy](/en/site/dossier/information_t4e_enquiry_workload_strategy.shtml) |

| 2021-02-01 | New: Temporary measures and waiting period waiver — Policy and procedures (All levels) The waiting period (WP) will be automatically waived on all claims with a BPC between January 31, 2021 (w/c 2276) and September 19, 2021 (w/c2309). However, the WP will not be waived for clients who are receiving supplemental unemployment benefits (SUB) and who apply for special benefits. [New: Temporary measures and waiting period waiver — Policy and procedures (All levels)](/en/site/dossier/new_temporary_measures_waiting_period_waiver_policy_procedure.shtml) |

| 2021-01-28 | Updated: Reinstating EI ERB claims after proof of identity is received — Task (Level 1) When an EI Emergency Response Benefit (EI ERB) claim must be reinstated because proof of identity is provided, the agent tries to rescind the 14 - Void benefit period disentitlement (D14) in BCS, regardless of whether the initial $2 000 was paid. If the overpayment (OP)When an EI Emergency Response Benefit (EI ERB) claim must be reinstated because proof of identity is provided, the agent tries to rescind the 14 - Void benefit period disentitlement (D14) in BCS, regardless of whether the initial $2 000 was paid. If the overpayment (OP) has been fully or partially recovered before rescinding the D14, the BCS input is rejected and the agent sends an Operational Centre Memo (MM06) transaction to IPOC. has been fully or partially recovered before rescinding the D14, the BCS input is rejected and the agent sends an Operational Centre Memo (MM06) transaction to IPOC. [Updated: Reinstating EI ERB claims after proof of identity is received — Task (Level 1)](/en/site/dossier/updated_reierbc_apir_l1.shtml) |

| 2021-01-26 | Updated: Issuing and amending T4Es — Procedures and additional resources (IPOC) The tax procedures for regional tax coordinators (RTCs) have been updated due to the implementation of projects and legislative changes. In addition, the tasks Issuing a manual T4E and Actioning the yearly tax reports have been combined into one task: Issuing a manual T4E. [Updated: Issuing and amending T4Es — Procedures and additional resources (IPOC)](/en/site/dossier/updated_iat4e_paar.shtml) |

| 2021-01-26 | Updated: COVID 19 and missing medical certificates — Procedures (Level 1 and Level 2) Due to COVID-19, the Government of Canada has removed the requirement for clients to submit a medical certificate when requesting benefits. [Updated: COVID 19 and missing medical certificates — Procedures (Level 1 and Level 2)](/en/site/dossier/mc_proc_1_2.shtml) |

| 2021-01-25 | Information: BC Recovery Benefit In response to COVID-19, families and single parents who qualify can receive a one-time, tax-free payment of up to $1 000 from the Government of British Colombia, and individuals who qualify can receive up to $500. This payment is not considered earnings for benefit purposes and should not be declared on claimant’s reports or allocated to an EI claim. [Information: BC Recovery Benefit](/en/site/dossier/information_bc_recovery_benefit.shtml) |

| 2021-01-15 | Updated: T4E — New box 37 and the EI ERB — Additional resource (All levels) The T4E: Detailed box description — Table additional resource has been updated to provide more information on the new box 37 related to the Canada Training Credit. The descriptions of box 14 and box 15 have also been updated to include information about the EI Emergency Response Benefit (EI ERB). [Updated: T4E — New box 37 and the EI ERB — Additional resource (All levels)](/en/site/dossier/updated_new_box_37_eierb_ar.shtml) |

| 2021-01-12 | Updated: COVID 19 : EI ERB claim conversion and APRS inputs — Procedures and additional resource (IPOC) FTS no longer accepts codes 5 - Automation Utility - Canada Emergency Response Benefits and 6 - Reassessment Utility - Canada Emergency Response Benefits in the Supplementary Claim Information field. To support IPOC agents when converting a non-established EI ERB claim, the task Processing a claim conversion — Purge and recreate has been updated with EI ERB information. [Updated: COVID 19 : EI ERB claim conversion and APRS inputs — Procedures and additional resource (IPOC)](/en/site/dossier/updated_covid19_eierb_claim_conversion_aprs_inputs_procedure_ar.shtml) |

| 2021-01-07 | Updated: Tax adjustment on an EI ERB claim and overpayment message code 146 — Procedures (IPOC) IPOC agents must determine if the 2020 T4E has to be amended when adjusting an EI Emergency Response Benefit (EI ERB) claim. Also, the overpayment (OP) message code 146 - You are no longer entitled to the advanced payment of Canada Emergency Response Benefits you have received. This caused an overpayment. is now available in the drop-down menu of the EI Account Establishment (DE013) screen in DARS. The procedures have been updated accordingly. [Updated: Tax adjustment on an EI ERB claim and overpayment message code 146 — Procedures (IPOC)](/en/site/dossier/updated_tax_adjustment_eierb_overpayment_message_code.shtml) |

| 2021-01-06 | Updated: Temporary simplification measures and 900-series SINs — Procedures (Non-complex, Level 1 and Level 2) In order to continue to support Canadians during the transition to EI benefits, simplification measures are being implemented until March 31, 2021. [Updated: Temporary simplification measures and 900-series SINs — Procedures (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_temporary_simplification_measures_900_series_sin_l1_l2.shtml) |

| 2020-12-23 | Updated: Temporary simplification measures and fact-finding with employers — Procedures (Non-complex, Level 1 and Level 2) In order to continue to support Canadians during the transition to EI benefits, simplification measures are implemented until March 31, 2021. [Updated: Temporary simplification measures and fact-finding with employers — Procedures (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_tsmffe.shtml) |

| 2020-12-23 | Updated: Temporary simplification measures and availability — Procedures (Level 1 and Level 2) To continue supporting Canadians during the transition to EI benefits, simplification measures are being implemented until March 31, 2021. [Updated: Temporary simplification measures and availability — Procedures (Level 1 and Level 2)](/en/site/dossier/updated_tsmav_l1l2.shtml) |

| 2020-12-23 | Information: Renewing an Existing EI Claim Following the Payment of CERB by the CRA The purpose of this communication is to clarify the legislation regarding a claimant’s ability to renew a previously established EI claim after they have been paid the Canada Emergency Response Benefit (CERB) by the Canada Revenue Agency (CRA). [Information: Renewing an Existing EI Claim Following the Payment of CERB by the CRA](/en/site/dossier/information_reeicfp_cerb.shtml) |

| 2020-12-21 | Information: Email about MSCA Clients who provided an email address and received benefits in 2020 got an email about registering for MSCA to receive their T4Es. [Information: Email about MSCA](/en/site/dossier/information_email_about_msca_dec_2020.shtml) |

| 2020-12-17 | Information: EI ERB claims and lump-sum family supplement payments Clients entitled to a family supplement (FS) on their EI Emergency Response Benefit (EI ERB) claim and who received the initial $2 000 lump-sum payment will also receive a lump-sum FS payment to top up the 4 weeks when the 65 - Lump Sum Payment ($2000) - Canadian Emergency Response code (D65) was imposed. [Information: EI ERB claims and lump-sum family supplement payments](/en/site/dossier/information_eierb_calsfsp.shtml) |

| 2020-12-15 | Updated: COVID-19 and the new overpayment message code — Procedures and additional resource (All levels) Information on how to use the new overpayment (OP) message code 146 when the initial $2 000 payment must be adjusted has been added to the additional resource Overpayment: Message codes — Table and the task COVID-19: Converting EI ERB claims to special benefits — Purge and recreate. [Updated: COVID-19 and the new overpayment message code — Procedures and additional resource (All levels)](/en/site/dossier/updated_covid19_new_overpayment_message_code_procedure_ar.shtml) |

| 2020-12-14 | Information: December 2020 FTS update On December 12, 2020, FTS will be updated with the following changes: [Information: December 2020 FTS update](/en/site/dossier/information_december_2020_fts.shtml) |

| 2020-12-04 | Information: Last day to claim EI Emergency Response Benefit Clients have until December 2, 2020 to complete claimant’s reports in order to collect EI ERB. [Information: Last day to claim EI Emergency Response Benefit](/en/site/dossier/information_lac_erb.shtml) |

| 2020-12-04 | New: Post-EI ERB and applying the administrative rule — Procedures and additional resource (Level 1 and Level 2) Agents are reminded to apply the 4-calendar-week administrative rule for clients applying for benefits who received the Canada Emergency Response Benefit (CERB) paid by the Canada Revenue Agency (CRA). [New: Post-EI ERB and applying the administrative rule — Procedures and additional resource (Level 1 and Level 2)](/en/site/dossier/new_post_eierb_applying_administrative_rule_procedures_ar_l1_l2.shtml) |

| 2020-12-03 | New: Inputting or modifying claimant’s reports for EI ERB clients — Procedures and additional resources (Level 1) Tasks and additional resources for inputting and modifying claimant’s reports for clients receiving the EI Emergency Response Benefit (EI ERB) are now available on the EI ORT. Claimant’s reports for EI ERB clients are assessed 4 weeks at a time. When inputting claimant’s reports for a client, the agent determines: whether monies are considered earnings; the dates of the 4-week period; whether the client’s earnings exceed $1 000 in that period. [New: Inputting or modifying claimant’s reports for EI ERB clients — Procedures and additional resources (Level 1)](/en/site/dossier/new_inputting_or_modifying_claimant_reports_for_eierb_clients.shtml) |

| 2020-12-03 | Updated: COVID-19 and processing a report blocked by a renewal week — Procedures (Level 1) Due to Covid-19, clients filing duplicate applications result in the renewal week automating and blocking payment for earlier weeks. [Updated: COVID-19 and processing a report blocked by a renewal week — Procedures (Level 1)](/en/site/dossier/updated_covid19_processing_report_blocked_by_renewal_week_l1_ipoc.shtml) |

| 2020-12-03 | Information: COVID-19 and processing information (Questions and answers) Due to COVID-19, additional information to support claim processing is provided. [Information: COVID-19 and processing information (Questions and answers)](/en/site/dossier/information_covid19_processing_information.shtml) |

| 2020-11-26 | Updated: Post-EI ERB — New benefits administered by the Canada Revenue Agency To continue to support Canadians, the Government of Canada is introducing 3 new taxable recovery benefits that take effect on September 27, 2020. Clients may ask agents how this affects their benefits and if they can apply for these recovery benefits. [Updated: Post-EI ERB — New benefits administered by the Canada Revenue Agency](/en/site/dossier/information_post_eierb_new_benefit_administrated_by_cra.shtml) |

| 2020-11-25 | Information: Post-EI ERB first payer and the Canada Recovery Benefit When a client is receiving the Canada Recovery Benefit (CRB) administered by the Canada Revenue Agency (CRA), but is actually entitled to establish an EI claim, the EI claim must be established and the client must receive the weeks of entitlement through Service Canada. [Information: Post-EI ERB first payer and the Canada Recovery Benefit](/en/site/dossier/information_post_eierb_first_payer_and_the_canada_recovery_benefit.shtml) |

| 2020-11-24 | Post-EI ERB Interim ROE — Task (Level 1) The Entering an interim ROE task was updated to include BPC dates affected by the transitional measure for self-employed fishers. [Post-EI ERB Interim ROE — Task (Level 1)](/en/site/dossier/post_ei_erb_interrim_roe.shtml) |

| 2020-11-24 | Updated: Post-EI ERB and reviewing adjudication during calculation — Task (Level 1) Following regional contributions, a note was added to the task Reviewing an outstanding issue with no Adjudication Issue WI to provide additional instructions for claims from the ACP specialized process. [Updated: Post-EI ERB and reviewing adjudication during calculation — Task (Level 1)](/en/site/dossier/updated_post_eierb_reviewing_adjudication_during_calculation.shtml) |

| 2020-11-20 | Updated: Post-EI ERB and fact-finding for ASMT BPNE WI’s — Procedures (Level 1) To help agents process ASMT BPNE WIs more efficiently, the Post-EI ERB — Completing an Assessment Issue BPNE WI task has been updated. Agents are now referred to the Fact-finding task when trying to reach a client. Agents make only one attempt to reach the employer to obtain a missing ROE, unless an ROE: INS3166 Request for missing ROE — Form is on file. [Updated: Post-EI ERB and fact-finding for ASMT BPNE WI’s — Procedures (Level 1)](/en/site/dossier/updated_post_eierb_fact_finding_asmt_bpne_wi_level1.shtml) |

| 2020-11-16 | Updated: Post-EI ERB claims and increased entrance requirements — Procedures and additional resources (Level 1 and Level 2) EI Emergency Response Benefit (EI ERB) claims are not considered established EI claims that allow the client to gain relief from increased entrance requirements. When validating, if one or 2 BPCs were affected by a violation, the agent does not consider the EI ERB claim as one of the BPC affected. [Updated: Post-EI ERB claims and increased entrance requirements — Procedures and additional resources (Level 1 and Level 2)](/en/site/dossier/updated_post_eierb_claims_increased_entrance_requirements.shtml) |

| 2020-11-09 | Updated: Post-EI ERB and working while on claim — Additional resource (All levels) Earnings deductions for all post-EI Emergency Response Benefit (EI ERB) claims to which a minimum benefit rate has been applied are calculated using the adjusted average weekly insurable earnings and not the true normal weekly insurable earnings. [Updated: Post-EI ERB and working while on claim — Additional resource (All levels)](/en/site/dossier/updated_post_eierb_working_while_on_claim_ar_all_levels.shtml) |

| 2020-11-09 | Updated: Clarification on adjudicating training — Policy and procedures (Level 1 and Level 2) The transitional measure for adjudicating training has changed. If the client reports not being available while attending non-referred training, the agent follows the normal adjudication procedures even if ACP previously allowed the training. [Updated: Clarification on adjudicating training — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/updated_clarification_adjudicating_training_policy_procedure_l1_l2.shtml) |

| 2020-11-05 | Updated: Post-EI ERB and the ASMT BPNE WI — Procedures (Level 1) The steps in the Post-EI ERB – Completing an Assessment Issue BPNE WI task have been modified and now include directions for potential fishing claims. [Updated: Post-EI ERB and the ASMT BPNE WI — Procedures (Level 1)](/en/site/dossier/updated_post_ei_erb_asmt_bpne_wi_level1.shtml) |

| 2020-11-04 | Information: COVID-19 — EI ERB and new status code in DARS When an account type 1345 - EI Emergency response Benefits or 1346 - CERB Advance Payment is established in DARS, a utility changes the status code to a new one. [Information: COVID-19 — EI ERB and new status code in DARS](/en/site/dossier/information_covid19_ei_erb_new_status_code_in_dars.shtml) |

| 2020-10-30 | Information: Viewing EI ERB lump-sum payment information in FTS Effective October 31, 2020, FTS displays payment information for the initial $2 000 lump-sum payment, equivalent to 4 weeks of the EI Emergency Response Benefit (EI ERB), paid to eligible clients before June 22, 2020. [Information: Viewing EI ERB lump-sum payment information in FTS](/en/site/dossier/information_viewing_eierb_lsi.shtml) |

| 2020-10-27 | Updated: Post EI-ERB and adjudicating reasons for separation — Procedures (Level 1 and Level 2) The end date of the reason for separation (RFS) transitional measure has been added to all of the RFS tasks. In addition, RFS procedures now advise the Level 1 agent to create a manual record of decision (ROD) when adjudication is not required because the contentious issue is more than 12 weeks before the client’s most recent interruption of earnings (I of E) in the qualifying period (QP). [Updated: Post EI-ERB and adjudicating reasons for separation — Procedures (Level 1 and Level 2)](/en/site/dossier/updated_post_eierb_adj_reasons_for_separation.shtml) |

| 2020-10-26 | Updated: COVID-19 and the new DARS account type — Procedures and additional resource (All levels) October 26 th , 2020, a new DARS account type 1346 - CERB Advance Payment is available to identify and separate an overpayment (OP) when an adjustment to the initial $2 000 payment results in the establishment of an OP in DARS. [Updated: COVID-19 and the new DARS account type — Procedures and additional resource (All levels)](/en/site/dossier/updated_covid19_new_dars_account_type_procedures_ar.shtml) |

| 2020-10-21 | Updated: Post-EI ERB and undeliverable privacy letters — Task (Non-complex and Level 1) Due to possible fraudulent EI Emergency Response Benefit (EI ERB) claims, privacy letters were sent to clients. The Actioning the receipt of undeliverable mail task has been updated with instructions to send an email providing the client’s SIN and type of ACS letter to the Incident Management and Legislative Disclosures unit if the agent receives an undeliverable privacy letter. [Updated: Post-EI ERB and undeliverable privacy letters — Task (Non-complex and Level 1)](/en/site/dossier/updated_post_eierb_undeliverable_privacy_letters.shtml) |

| 2020-10-16 | Updated: Post-EI ERB and failure to provide proof of identity — Procedures (Non-complex and Level 1) When the EI Emergency Response Benefit (EI ERB) ends, clients who meet the criteria for the auto-enrollment process and whose new BPC was established using the same application that was used to establish the EI ERB claim must validate their identity for both claims when there is a Social Insurance Registry (SIR) non-match. [Updated: Post-EI ERB and failure to provide proof of identity — Procedures (Non-complex and Level 1)](/en/site/dossier/updated_peierb_fppi.shtml) |

| 2020-10-16 | Information: Post-EI ERB and automation of sickness benefits Effective October 16, 2020, the UIC has been programmed to input a recovery date on sickness claims regardless of the reason for separation (RFS). [Information: Post-EI ERB and automation of sickness benefits](/en/site/dossier/information_post_eierb_automation_of_sickness_benefits.shtml) |

| 2020-10-16 | Updated: Post-EI ERB and waiting period waiver for sickness benefits — Procedures and additional resource (Level 1) The waiting period (WP) waiver measure has been extended for all sickness claims with a BPC between September 27, 2020 (w/c 2258) and September 25, 2021 (w/c 2309). [Updated: Post-EI ERB and waiting period waiver for sickness benefits — Procedures and additional resource (Level 1)](/en/site/dossier/updated_post_eierb_waiting_period_waiver_for_sickness_benefit.shtml) |

| 2020-10-14 | Updated: Post-EI ERB and deferred adjudication of reason for separation — Procedures (Level 1 and Level 2) As part of the transition to EI, UIC does not impose a disqualification if adjudication of the reason for separation (RFS) is deferred on initial claims when the BPC is between September 27, 2020 (w/c 2258) and September 25, 2021 (w/c 2309). [Updated: Post-EI ERB and deferred adjudication of reason for separation — Procedures (Level 1 and Level 2)](/en/site/dossier/updated_post_eierb_deferred_adjudication_reason_separation.shtml) |

| 2020-10-14 | Updated: Post-EI ERB Interim fishing ROE — Task (Level 1) The Entering an interim ROE task was updated to include additional information about how an interim ROE is created for a BPNE fishing claim. [Updated: Post-EI ERB Interim fishing ROE — Task (Level 1)](/en/site/dossier/updated_interim_fishing_roe_l1.shtml) |

| 2020-10-05 | Updated: Post-EI ERB and removing claims from automation — Additional resource (Level 1) The Calculation: Removal from the ACP wait process — Instructions additional resource has been updated with a note explaining that claims in the specialized ACP process cannot be removed from automation. The Reminder (REM) WI created to remove a claim from automation is deleted if the claim is in the specialized ACP process. [Updated: Post-EI ERB and removing claims from automation — Additional resource (Level 1)](/en/site/dossier/updated_post_eierb_removing_claims_from_automation_ar.shtml) |

| 2020-09-27 | Updated: Post-EI ERB hours credit — Procedures and additional resources (Non-complex, Level 1 and Level 2) To support clients when the EI Emergency Response Benefit (EI ERB) ends, clients whose BPC is between September 27, 2020 and September 25, 2021 will receive a one-time credit of insurable hours. [Updated: Post-EI ERB hours credit — Procedures and additional resources (Non-complex, Level 1 and Level 2)](/en/site/dossier/post_ei_erb_hc_ch.shtml) |

| 2020-09-27 | New and updated: Post-EI ERB and fishing claims — Additional resources (Level 1 and IPOC) To support clients when the EI Emergency Response Benefit (EI ERB) ends, simplification measures are implemented to process fishing claims. [New and updated: Post-EI ERB and fishing claims — Additional resources (Level 1 and IPOC)](/en/site/dossier/new_updated_post_eierb_fishing_claims_ar_l1_ipoc.shtml) |

| 2020-09-27 | New and updated: Post-EI ERB and Specialized ACP process — Procedures (All levels) Procedures have been updated to support the specialized ACP process implemented on September 27, 2020 to streamline the processing of regular and sickness benefits. [New and updated: Post-EI ERB and Specialized ACP process — Procedures (All levels)](/en/site/dossier/new_updated_post_eierb_specialized_acp_process.shtml) |

| 2020-09-27 | Updated: Post-EI ERB and qualifying period extension — Tasks (Level 1) To support clients when the EI Emergency Response Benefit (EI ERB) ends, there will be an automatic 28-week qualifying period (QP) extension on all claims converted from EI ERB or the Canada Emergency Response Benefit (CERB) with a BPC between September 27, 2020 (w/c 2258) and September 19, 2021 (w/c 2309). [Updated: Post-EI ERB and qualifying period extension — Tasks (Level 1)](/en/site/dossier/updated_peierb_qpe.shtml) |

| 2020-09-27 | Updated: Post-EI ERB and Variable best weeks in AW — Procedures and additional resource (Level 1) Effective September 28, 2020, the variable best weeks (VBW) question on the application will no longer appear to clients. [Updated: Post-EI ERB and Variable best weeks in AW — Procedures and additional resource (Level 1)](/en/site/dossier/updated_variable_best_weeks_aw_procedure_ar.shtml) |

| 2020-09-27 | Updated: Post-EI ERB and minimum benefit rate — Additional resources (All levels) To support clients when the EI Emergency Response Benefit (EI ERB) ends, all claims with a BPC in w/c 2258 – w/c 2309 will have a minimum benefit rate applied to the claim. [Updated: Post-EI ERB and minimum benefit rate — Additional resources (All levels)](/en/site/dossier/updated_post_eierb_min_br_ar.shtml) |

| 2020-09-27 | Updated: Post-EI ERB and Allocation of monies — Procedures (Level 1, Level 2 and IPOC) To support clients when the EI Emergency Response Benefit (EI ERB) ends, some monies are temporarily not being allocated. [Updated: Post-EI ERB and Allocation of monies — Procedures (Level 1, Level 2 and IPOC)](/en/site/dossier/eierb_sm_puae_ic.shtml) |

| 2020-09-27 | Updated: Post-EI ERB and regional rate of unemployment — Additional resources (Level 1, Level 2 and IPOC) To support clients when the EI Emergency Response Benefit (EI ERB) ends, a minimum national regional rate of unemployment (RRU) will be temporarily implemented. [Updated: Post-EI ERB and regional rate of unemployment — Additional resources (Level 1, Level 2 and IPOC)](/en/site/dossier/updated_post_eierb_rru.shtml) |

| 2020-09-27 | New: Emergency Response Benefit Transition Provisions – BE 2020-05 — Policy and procedures (Level 1 and Level 2) The purpose of this memorandum is to describe the interim orders made on August 28, 2020 and September 27, 2020 by the Minister of Employment and Social Development amending the EI Act for the purpose of implementing temporary transition measures from the ERB/CERB to EI benefits. [New: Emergency Response Benefit Transition Provisions – BE 2020-05 — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/new_erbt_be2020-05.shtml) |

| 2020-09-23 | Updated: EI Emergency Response Benefit — BE Memo 2020-04 BE Memo 2020-04 has been updated to include information to streamline language and provide additional information on write-off and work-sharing. [Updated: EI Emergency Response Benefit — BE Memo 2020-04](/en/site/dossier/be2020-04_be_ap.shtml) |

| 2020-09-17 | Information: Post-EI ERB and Information on upcoming transition to EI and interim measures The purpose of this update is to provide agents with information related to upcoming changes that will be implemented effective September 27, 2020 related to the transition from Emergency Response Benefits (ERB/CERB) to Employment Insurance. [Information: Post-EI ERB and Information on upcoming transition to EI and interim measures](/en/site/dossier/information_erb_pu_post_transitition.shtml) |

| 2020-09-02 | Information: Updates to the EIORT— COVID-19 information pages and transition to EI To respond to the rapidly changing procedures in the context of the COVID-19 pandemic, the EI ORT underwent several changes in order to offer the latest procedural changes in a timely manner. Now that the EI Emergency Response Benefit (EI ERB) program is coming to an end and we are transitioning back to EI, the EIORT will be undergoing other changes. [Information: Updates to the EIORT— COVID-19 information pages and transition to EI](/en/site/dossier/information_ueiort_covid19.shtml) |

| 2020-08-20 | Information: Post-EI ERB: Transition to the EI program and new temporary support benefits On August 20, 2020, the Government of Canada announced that new measures will be implemented on September 27, 2020 to help Canadians access EI benefits more easily. Additionally, three new taxable recovery benefits, administered by the Canada Revenue Agency (CRA), will be introduced to support workers who are not eligible for EI. To prepare for this transition, the Canada Emergency Response Benefit will be extended. [Information: Post-EI ERB: Transition to the EI program and new temporary support benefits](/en/site/dossier/temp_support_benefit.shtml) |

| 2020-07-21 | Information: COVID-19 — Initial $2000 payment and new D65 Effective June 8, 2020, a new 65 - Lump Sum Payment ($2000) - Canadian Emergency Response was introduced to ensure that clients who received a $2000 initial payment at the beginning of their EI Emergency Response Benefit claim will not be paid more than the 24-week entitlement. [Information: COVID-19 — Initial $2000 payment and new D65](/en/site/dossier/information_covid19_initial_2000_payment_new_d65.shtml) |

| 2020-05-15 | Updated: COVID-19 and assignment of benefits — Procedures (IPOC) According to the COVID-19 Emergency Response Act, an assignment of benefits (AOB) cannot be input for weeks in which emergency response benefits are paid or payable. There are also changes to the requirement for a wet signature on the Assignment of benefits: INS3113 Request from social services agency — Form. [Updated: COVID-19 and assignment of benefits — Procedures (IPOC)](/en/site/dossier/updated_covid19_aob.shtml) |

| 2021-04-23 | Archived: New and updated: Referral to Integrity and fraudulent EI and EI ERB claims — Procedures and additional resource (All levels) This Headlines and Updates page has been created to combine 3 previous Headlines and Updates pages on referrals to Integrity and fraudulent EI and EI Emergency Response Benefit (EI ERB) applications. The 3 previous Headlines and Updates pages have been removed. [Archived: New and updated: Referral to Integrity and fraudulent EI and EI ERB claims — Procedures and additional resource (All levels)](/en/site/dossier/new_updated_referral_integrity_fraudulent_ei_eierb_claim_procedure_ar.shtml) |

| 2021-01-06 | Archived: Updated: COVID-19 and antedating an EI Emergency Response Benefit claim — Policy and procedures (Level 1, Level 2 and IPOC) New interim orders that amend the EIA to help agents administer the EI Emergency Response Benefit (EI ERB) have been created. These changes may prompt antedate requests. In alignment with policy, the procedures for processing antedates for EI ERB claims have been updated. [Archived: Updated: COVID-19 and antedating an EI Emergency Response Benefit claim — Policy and procedures (Level 1, Level 2 and IPOC)](/en/site/dossier/updated_covid19_antedating_ei_emergency_response_benefit_claim.shtml) |

| 2020-11-10 | Archived: Updated: COVID-19 and impacts of suspending CPS recoupments — Additional resource (IPOC) Due to COVID-19, CPS recoupments are suspended which has multiple impacts on IPOC. An additional resource explaining these impacts has been published. [Archived: Updated: COVID-19 and impacts of suspending CPS recoupments — Additional resource (IPOC)](/en/site/dossier/new_impact_suspending_cps_recoupments_covid19_ar_ipoc.shtml) |

| 2020-04-06 | Archived: Updated: Employer bankruptcies and grievance settlements — Tasks (Level 1, Level 2 and IPOC) Effective immediately, agents action WIs related to employer bankruptcies and grievance settlements under EIA 46 using the following workarounds. [Archived: Updated: Employer bankruptcies and grievance settlements — Tasks (Level 1, Level 2 and IPOC)](/en/site/dossier/updated_ebags_ll1l2.shtml) [EIA 46](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-46.shtml) |

| 2020-08-27 | Archived: New and updated: COVID-19 and conversion from EI ERB or CERB to special benefits (other than sickness) — Tasks (Level 1, Level 2 and IPOC) Starting now, agents can now convert EI ERB or CERB claims to special benefits (other than sickness). Three new tasks have been created and updates to existing tasks have been made. One new IPOC task has been created. [Archived: New and updated: COVID-19 and conversion from EI ERB or CERB to special benefits (other than sickness) — Tasks (Level 1, Level 2 and IPOC)](/en/site/dossier/new_updated_covid19_conversion_eierb_special_benefits.shtml) |

| 2020-03-30 | Archived: New: Cancelling, terminating and voiding a claim — Procedures (Level 1 and IPOC) Due to COVID-19, and as a result of Canada Revenue Agency (CRA) and Service Canada temporary measures to suspend overpayment (OP) recoupments, certain procedures where an overpayment is established by IPOC and after recouped on the new or renewal claim by CPS are changed until further notice. [Archived: New: Cancelling, terminating and voiding a claim — Procedures (Level 1 and IPOC)](/en/site/dossier/new_cancelling_terminating_voiding_claim_procedures_level1_ipoc.shtml) |

| 2020-06-02 | Archived: Information: EI Emergency Response Benefit and IPOC activities Due to the COVID-19 situation and the new EI Emergency Response Benefit, several IPOC activities are impacted by temporary measures. [Archived: Information: EI Emergency Response Benefit and IPOC activities](/en/site/dossier/information_ei_erbipoc.shtml) |

| 2020-03-25 | Archived: New: COVID-19 — Work-Sharing and Availability — Procedures and additional resource (All levels) As a result of simplification measures related to the COVID-19 crisis, a change was made to the process of sporadic shutdowns during a Work-Sharing (WS) agreement. [Archived: New: COVID-19 — Work-Sharing and Availability — Procedures and additional resource (All levels)](/en/site/dossier/updated_covid_19_work_sharing_availability.shtml) |

| 2021-03-01 | Archived: Updated: Post-EI ERB and extending casual sickness weeks — Tasks (Level 1, Level 2 and IPOC) Starting September 27 2020, clients can declare up to 15 consecutive weeks of casual sickness on their claimant’s reports. [Archived: Updated: Post-EI ERB and extending casual sickness weeks — Tasks (Level 1, Level 2 and IPOC)](/en/site/dossier/updated_post_eierb_extend_casual_sickness_weeks.shtml) |

| 2020-09-14 | Archived: Information: COVID-19 and Work-Sharing Due to COVID-19, the Government of Canada has approved additional measures to improve access to the Work-Sharing (WS) program. [Archived: Information: COVID-19 and Work-Sharing](/en/site/dossier/information_covid19_work_sharing.shtml) |

| 2020-07-08 | Archived: Information: COVID-19 and reopening of Service Canada Centres Due to the COVID-19 situation, Service Canada Centre (SCC) doors closed to the public in March. Government of Canada announced the gradual and safe reopening of up to 90 SCC across the country as of July 8, 2020. [Archived: Information: COVID-19 and reopening of Service Canada Centres](/en/site/dossier/information_covid19_service_restriction_offered_scc.shtml) |

| 2021-03-15 | Archived: Post-EI ERB claims processing and potential fraud — Procedures (Non-complex, Level 1 and Level 2) Effective immediately, if there is an outstanding Claim Review (CR) Integrity ERB Earnings WI on file, the agent moves all WIs related to the new EI claim to Pending until the CR Integrity ERB Earnings WI is completed. If there is no outstanding CR Integrity ERB Earnings WI, but there is a 71 - Integrity Services case manual action (MA71) imposed on an EI Emergency Response Benefit (EI ERB) claim, the agent thoroughly reviews the EI application to ensure that the application is not fraudulent. If the agent doubts the authenticity of the application, the agent reviews the application for specific fraud indicators, then either continues processing the EI claim or refers it to Integrity. [Archived: Post-EI ERB claims processing and potential fraud — Procedures (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_peierb_cppc.shtml) |

| 2020-10-16 | Archived: Referring potentially fraudulent EI ERB claims to Integrity — Procedures (All levels) A client may report that an EI ERB claim is fraudulent. In these situations, the agent does not input a change of address or direct deposit, and does not issue a temporary access code. The agent forwards the information to Integrity’s General Delivery mailbox and imposes a 71 - Integrity Services case manual action (MA71) to prevent further payment of benefits. The agent documents the details of the situation on an SROC in NWS. [Archived: Referring potentially fraudulent EI ERB claims to Integrity — Procedures (All levels)](/en/site/dossier/eierb_ref_integrity.shtml) |

| 2020-05-20 | Archived: COVID-19 and referrals to Integrity Due to COVID-19, effective immediately, only urgent issues must be referred to Integrity. [Archived: COVID-19 and referrals to Integrity](/en/site/dossier/covid_19_referrals_integrity.shtml) |

| 2020-09-17 | Archived: COVID-19 and returned payments — Task (Level 1 and IPOC) Due to COVID-19 and the EI Emergency Response Benefit, the volume of returned payments has significantly increased and temporary measures are being implemented. [Archived: COVID-19 and returned payments — Task (Level 1 and IPOC)](/en/site/dossier/new_covid19_returned_payments_task.shtml) |

| 2020-08-05 | Archived: COVID-19 and SIR Non-Match WIs — Procedures (Non-complex and Level 1) Due to COVID-19, SIR non-match validation has been simplified. [Archived: COVID-19 and SIR Non-Match WIs — Procedures (Non-complex and Level 1)](/en/site/dossier/updated_covid19_sirnmwi.shtml) |

| 2020-09-23 | Archived: COVID-19 and establishing BPNE claims as EI Emergency Response Benefit claims — Procedures (Level 1) Due to the COVID-19 situation, temporary measures have been implemented that allow agents to establish BPNE claims as EI Emergency Response Benefit claims. Agents can now also recalculate claims that were previously finalized BPNE 1 or BPNE 5 to EI Emergency Response Benefit claims. [Archived: COVID-19 and establishing BPNE claims as EI Emergency Response Benefit claims — Procedures (Level 1)](/en/site/dossier/updated_covid19_establishing_bpne_claim_as_eierbc_l1.shtml) |

| 2020-12-03 | Archived: COVID-19 and Emergency Response Benefit Due to COVID-19, the Government of Canada is introducing the Canada Emergency Response Benefit (CERB) and the EI Emergency Response Benefit (EI ERB). [Archived: COVID-19 and Emergency Response Benefit](/en/site/dossier/information_covid19_emergency_response_benefits.shtml) |

| 2020-06-15 | Archived: COVID-19 and deferral of adjudication on an EI Emergency Response Benefit claim Due to the COVID-19 situation, several system utilities are run to automatically process claims as EI Emergency Response Benefit claims. Therefore, when all criteria are met, deferral of adjudication is allowed on all contentious issues on claims for the EI Emergency Response Benefit. [Archived: COVID-19 and deferral of adjudication on an EI Emergency Response Benefit claim](/en/site/dossier/covid19_deferral_adjudication_eierbc.shtml) |

| 2020-08-24 | Archived: COVID-19 and work permits for 900-series SIN — Procedures (Level 1 and Level 2) Due to COVID-19, the 900-series SIN procedures have been simplified. [Archived: COVID-19 and work permits for 900-series SIN — Procedures (Level 1 and Level 2)](/en/site/dossier/updated_covid19_work_permit_900_sin.shtml) |

| 2020-07-22 | Archived: COVID-19 and fact-finding — Task (All levels) Due to COVID-19, fact-finding with employers has changed. [Archived: COVID-19 and fact-finding — Task (All levels)](/en/site/dossier/fact_find_covid19_update.shtml) |

| 2020-06-17 | Archived: COVID-19 and availability — Procedures (Level 1 and Level 2) Due to COVID-19, the Government of Canada has adopted measures to demonstrate flexibility on the interpretation for the availability entitlement principles. [Archived: COVID-19 and availability — Procedures (Level 1 and Level 2)](/en/site/dossier/avail_covid19_l2_l2.shtml) |

| 2020-11-09 | Archived: Post-EI ERB and training adjudication — Policy and procedures (Level 1 and Level 2) To support clients when the EI Emergency Response Benefit (EI ERB) ends, a transitional measure was implemented to allow all training declared by clients between September 27, 2020 and September 25, 2021 for all claim types (CTs) and benefit types (BTs). [Archived: Post-EI ERB and training adjudication — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/updated_post_eierb_training_adjudication.shtml) |

| 2020-10-01 | Archived: COVID-19 and reviewing medical certificates for CCB and family caregiver benefits — Procedures (Level 1 and Level 2) In section 58 of the COVID-19 Emergency Response Act , the requirement to obtain and provide Service Canada with a medical certificate to support a claim for CCB and family caregiver benefits has been removed. However, when a client does provide a medical certificate, it must be reviewed. [Archived: COVID-19 and reviewing medical certificates for CCB and family caregiver benefits — Procedures (Level 1 and Level 2)](/en/site/dossier/covid19_review_mc_ccb_fc.shtml) |

| 2020-09-27 | Archived: Post-EI ERB and waiting period waiver — Procedures (Level 1) To support clients when the EI Emergency Response Benefit (EI ERB) ends, the waiting period (WP) will be automatically waived on all claims with a BPC between September 25, 2020 (w/c 2258) and October 25, 2020 (w/c2262). However, the WP will not be waived for clients who are receiving supplemental unemployment benefits (SUB) and who apply for special benefits. [Archived: Post-EI ERB and waiting period waiver — Procedures (Level 1)](/en/site/dossier/post_ei_erb_wp_waiver.shtml) |

| 2020-05-08 | Archived: COVID-19 and waiving the waiting period Due to COVID-19, the Government of Canada has approved waiving the one-week waiting period (WP) for clients who apply and qualify to receive sickness or regular benefits. [Archived: COVID-19 and waiving the waiting period](/en/site/dossier/information_coronavirus.shtml) |

| 2020-09-03 | Archived: COVID-19 and recoupment (All levels) Due to COVID-19, the Government of Canada has suspended overpayment (OP) recoupment until further notice. When an OP is established, the agent enters additional information in the notice of decision letter. This applies to both processing and reconsideration agents. [Archived: COVID-19 and recoupment (All levels)](/en/site/dossier/information_ei_debt_recoupment_activities_suspended.shtml) |

| 2020-07-31 | Archived: Notices of Debt and monthly statement of accounts — COVID-19 Due to the COVID-19 situation and the previously announced suspension of overpayment (OP) recoupments on EI claims, the Chief Financial Officer branch has implemented further measures to align with collection actions. [Archived: Notices of Debt and monthly statement of accounts — COVID-19](/en/site/dossier/information_notices_debt_monthly_statement_accounts_covid19.shtml) |

| 2020-07-23 | Archived: COVID-19 and Cancelling, voiding, terminating or withdrawing claims — Procedures (Level 1, Level 2 and IPOC) Due to COVID-19, a client can request to cancel, void, terminate or withdraw an EI claim or an EI Emergency Response Benefit claim. [Archived: COVID-19 and Cancelling, voiding, terminating or withdrawing claims — Procedures (Level 1, Level 2 and IPOC)](/en/site/dossier/covid19_cvtw_claim.shtml) |

| 2020-07-21 | Archived: COVID-19, D39 disentitlement and conversion to maternity benefits — Task (Level 1 and Level 2) Due to COVID-19, a D39 disentitlement is imposed on claims with an expected date of confinement. The agent must not rescind the D39 disentitlement. A new task to convert EI Emergency Response Benefit claims to maternity benefits has been created. [Archived: COVID-19, D39 disentitlement and conversion to maternity benefits — Task (Level 1 and Level 2)](/en/site/dossier/new_covid19_d39_disentitlement_conversion_maternity_benefits.shtml) |

| 2020-05-05 | Archived: COVID-19 and missing ROEs — Procedures (Level 1) Due to COVID-19, the Reviewing information for a missing ROE , Determining if an interim ROE is required , Estimating interim ROE information and Entering an interim ROE tasks have been updated to provide the temporary measures required when a client submits an application with a missing ROE. [Archived: COVID-19 and missing ROEs — Procedures (Level 1)](/en/site/dossier/updated_missing_roe_procedure_level1.shtml) [Reviewing information for a missing ROE](/en/procedure/task/calc_determining/missing_roe.shtml) [Determining if an interim ROE is required](/en/procedure/task/determining_interim_roe.shtml) [Estimating interim ROE information](/en/procedure/task/estimating_interim_roe.shtml) [Entering an interim ROE](/en/procedure/task/entering_interim_roe.shtml) |

| 2020-06-17 | Archived: COVID-19 and printing documents while teleworking — Procedures (All levels) Since many agents are teleworking because of the COVID-19 situation, a temporary procedure has been created to help them when they need to print documents. [Archived: COVID-19 and printing documents while teleworking — Procedures (All levels)](/en/site/dossier/updated_covid19_printing_documents_wt.shtml) |

| 2020-05-19 | Archived: COVID-19 and Pay History — Additional resources (IPOC) Due to COVID-19 and the Emergency Response Benefit, a new field has been added to the header of the Pay History Modification (PHM1) and Pay History (MHQ1) screens and new Pay History description codes have been created. [Archived: COVID-19 and Pay History — Additional resources (IPOC)](/en/site/dossier/updated_fts_pay_history_ar.shtml) |

| 2020-05-01 | Archived: COVID-19 and otherwise available — Policy and procedures (Level 1 and Level 2) Due to the COVID-19 situation, a temporary simplification measure has been implemented allowing Level 1 agents to impose a 33 - Incapacity proven but not otherwise available disentitlement (D33) on sickness claims for the same period as a 13 - Outside Canada (D13) disentitlement when clients return from a planned vacation outside of Canada on or after March 14, 2020. [Archived: COVID-19 and otherwise available — Policy and procedures (Level 1 and Level 2)](/en/site/dossier/updated_covid19_otherwise_available_policy_procedure.shtml) |

| 2020-05-25 | Archived: COVID-19 and the Canada Emergency Wage Subsidy Due to COVID-19, eligible employer whose business has been affected by COVID-19, may be eligible for a wage subsidy. [Archived: COVID-19 and the Canada Emergency Wage Subsidy](/en/site/dossier/information_covd19_canada_emergency_wage_subsidy.shtml) |

| 2020-05-25 | Archived: COVID-19 and undelivered access codes — Procedures (Non-complex and Level 1) Due to the COVID-19 situation, temporary measures have been implemented for agents who are processing undeliverable access codes. [Archived: COVID-19 and undelivered access codes — Procedures (Non-complex and Level 1)](/en/site/dossier/updated_covid19_uac_ncl1.shtml) |

| 2020-03-23 | Archived: COVID-19 and ROEs — Procedures and additional resource (Non-complex) Due to COVID-19, the task Completing an ROE Issue RFS Action WI: K - Other and the instructions ROE: Actions required for comments found in block 18 of a regular ROE have been updated to provide the measures to take when the ROE includes comments related to COVID-19. [Archived: COVID-19 and ROEs — Procedures and additional resource (Non-complex)](/en/site/dossier/update_covid19_nc_roe.shtml) |

| 2020-07-13 | Archived: COVID-19 and processing of CA Renewal WI When a client files a new application, ACP incorrectly identifies this claim as a renewal claim when the Last week processed field is empty. [Archived: COVID-19 and processing of CA Renewal WI](/en/site/dossier/information_covid19_processing_ca_renewal_wi.shtml) |

| 2020-05-06 | Archived: EIA 25 — Adjudication of early course end date — Task (Level 1 and Level 2) Due to COVID-19, the requirements for adjudicating early departure from referred training approved under EIA 25 and availability are relaxed. This guidance is in effect from March 09, 2020 to the day the state of emergency is lifted. This includes federal, provincial, territorial and municipal levels. [Archived: EIA 25 — Adjudication of early course end date — Task (Level 1 and Level 2)](/en/site/dossier/updated_eia25_aeced.shtml) |

| 2020-04-08 | Archived: COVID-19 and Double payments (EI Emergency Response Benefit and Canada Emergency Response Benefit) In COVID-19 situations, clients may have applied and received payments from both the EI Emergency Response Benefit and the Canada Emergency Response Benefit. [Archived: COVID-19 and Double payments (EI Emergency Response Benefit and Canada Emergency Response Benefit)](/en/site/dossier/cv19_cerb_erb.shtml) |
``` 

### Callout

Source topic: `en_EN/common_notes/note_c_0828.dita`

**Procedural changes**

Search by Complexity level Show all Non-complex Level 1 Level 2 IPOC Search by Category Show all EI ERB Post EI ERB Submit Reset

IMPORTANT ALL POST EI ERB HAS NON BREAKING SPACE

To narrow down the search results, enter one or more keywords in the Filter items field.

```text
| Measure | Complexity level | Category |

| 900-series SINs — Guidance for work permits [900-series SINs — Guidance for work permits](/en/site/dossier/updated_extension_temporary_simplification_measures_l1_l2_ipoc.shtml#900-sin) | Level 1 Level 2 | EI ERB |

| ACP — New specialized process [ACP — New specialized process](/en/site/dossier/new_updated_post_eierb_specialized_acp_process.shtml#main-content) | Non-complex Level 1 Level 2 IPOC | Post EI ERB |

| Antedate — New processes [Antedate — New processes](/en/site/dossier/updated_covid19_antedating_ei_emergency_response_benefit_claim.shtml#main-content) | Level 1 Level 2 IPOC | EI ERB |

| Assignment of benefits — New temporary process [Assignment of benefits — New temporary process](/en/site/dossier/updated_covid19_aob.shtml#main-content) | IPOC | EI ERB Post EI ERB |

| Availability — Requirements relaxed (includes otherwise available) [Availability — Requirements relaxed (includes otherwise available)](/en/site/dossier/updated_extension_temporary_simplification_measures_l1_l2_ipoc.shtml#availability) | Level 1 Level 2 | EI ERB |

| Bankruptcy — MM06 used in more situations [Bankruptcy — MM06 used in more situations](/en/site/dossier/updated_ebags_ll1l2.shtml#What_You_Need) | Level 1 Level 2 IPOC | EI ERB Post EI ERB |

| Benefit rate — Minimum benefit rate implemented [Benefit rate — Minimum benefit rate implemented](/en/site/dossier/updated_post_eierb_min_br_ar.shtml#main-content) | Non-complex Level 1 Level 2 IPOC | Post EI ERB |

| Claimant`s report — Blocked by renewal week [Claimant`s report — Blocked by renewal week](/en/site/dossier/updated_covid19_processing_report_blocked_by_renewal_week_l1_ipoc.shtml#What_You_Need) | Level 1 IPOC | EI ERB |

| DARS – New account type [DARS – New account type](/en/site/dossier/updated_covid19_new_dars_account_type_procedures_ar.shtml#main-content) | Non-complex Level 1 Level 2 IPOC | EI ERB |

| Earnings — Monies on separation not allocated [Earnings — Monies on separation not allocated](/en/site/dossier/eierb_sm_puae_ic.shtml#main-content) | Level 1 Level 2 IPOC | Post EI ERB |

| EI Emergency Response Benefit — Impacts on IPOC [EI Emergency Response Benefit — Impacts on IPOC](/en/site/dossier/information_ei_erbipoc.shtml#main-content) | IPOC | EI ERB |

| Fact-finding: Employer — One attempt only [Fact-finding: Employer — One attempt only](/en/site/dossier/updated_extension_temporary_simplification_measures_l1_l2_ipoc.shtml#fact-finding) | Non-complex Level 1 Level 2 IPOC | EI ERB Post EI ERB |

| Fishing claims – Interim ROEs [Fishing claims – Interim ROEs](/en/site/dossier/updated_interim_fishing_roe_l1.shtml) | Level 1 | Post EI ERB |

| Grievance settlements — MM06 used in more situations [Grievance settlements — MM06 used in more situations](/en/site/dossier/updated_ebags_ll1l2.shtml#main-content) | Level 1 Level 2 IPOC | EI ERB Post EI ERB |

| Insurable hours — One time credit [Insurable hours — One time credit](/en/site/dossier/post_ei_erb_hc_ch.shtml#main-content) | Non-complex Level 1 Level 2 | Post EI ERB |

| Integrity referrals – Potentially fraudulent claims [Integrity referrals – Potentially fraudulent claims](/en/site/dossier/new_updated_referral_integrity_fraudulent_ei_eierb_claim_procedure_ar.shtml#main-content) | Non-complex Level 1 Level 2 IPOC | EI ERB |

| Medical certificate — Not required [Medical certificate — Not required](/en/site/dossier/mc_proc_1_2.shtml#wyntk) | Level 1 Level 2 | EI ERB |

| Overpayment (OP) — Impact of suspending recoupment on IPOC [Overpayment (OP) — Impact of suspending recoupment on IPOC](/en/site/dossier/new_impact_suspending_cps_recoupments_covid19_ar_ipoc.shtml#main-content) | IPOC | EI ERB Post EI ERB |

| Overpayment (OP) — Process for cancelled and terminated claims [Overpayment (OP) — Process for cancelled and terminated claims](/en/site/dossier/new_cancelling_terminating_voiding_claim_procedures_level1_ipoc.shtml#main-content) | Level 1 IPOC | EI ERB Post EI ERB |

| Qualifying period — Automatic extensions [Qualifying period — Automatic extensions](/en/site/dossier/updated_peierb_qpe.shtml#main-content) | Level 1 | Post EI ERB |

| Regional rate of unemployment — minimum rate implemented [Regional rate of unemployment — minimum rate implemented](/en/site/dossier/updated_post_eierb_rru.shtml#main-content) | Level 1 Level 2 IPOC | Post EI ERB |

| Returned cheque payments — New process [Returned cheque payments — New process](/en/site/dossier/new_covid19_returned_payments_task.shtml#main-content) | Level 1 IPOC | EI ERB Post EI ERB |

| Returned direct deposit payments — New process [Returned direct deposit payments — New process](/en/site/dossier/new_covid19_returned_payments_task.shtml#archived) | Level 1 IPOC | EI ERB Post EI ERB |

| RFS — Not adjudicated [RFS — Not adjudicated](/en/site/dossier/updated_post_eierb_adjudicating_reason_for_separation_policy_procedure_l1_l2.shtml#dossierTable) | Level 1 Level 2 | Post EI ERB |

| Sickness — 15 weeks casual sick [Sickness — 15 weeks casual sick](/en/site/dossier/updated_post_eierb_extend_casual_sickness_weeks.shtml#main-content) | Level 1 Level 2 IPOC | Post EI ERB |

| SIR Non-match – Process for auto enrolled claims [SIR Non-match – Process for auto enrolled claims](/en/site/dossier/updated_peierb_fppi.shtml#main-content) | Non-complex Level 1 | Post EI ERB |

| Special benefits — Converting EI ERB to special benefits (other than sickness) [Special benefits — Converting EI ERB to special benefits (other than sickness)](/en/site/dossier/new_updated_covid19_conversion_eierb_special_benefits.shtml#main-content) | Level 1 Level 2 IPOC | EI ERB |

| Training — New process for non-referred training [Training — New process for non-referred training](/en/site/dossier/updated_clarification_adjudicating_training_policy_procedure_l1_l2.shtml#change_eiort) | Level 1 Level 2 | Post EI ERB |

| Undeliverable mail – Returned privacy letters [Undeliverable mail – Returned privacy letters](/en/site/dossier/updated_post_eierb_undeliverable_privacy_letters.shtml#main-content) | Non-complex Level 1 | EI ERB |

| VBW — Removed from Appliweb applications [VBW — Removed from Appliweb applications](/en/site/dossier/updated_variable_best_weeks_aw_procedure_ar.shtml#main-content) | Level 1 | Post EI ERB |

| Waiting period – Waived for sickness benefits [Waiting period – Waived for sickness benefits](/en/site/dossier/updated_post_eierb_waiting_period_waiver_for_sickness_benefit.shtml) | Level 1 | Post EI ERB |

| Work-Sharing (WS) — Shutdowns not actioned regardless of duration [Work-Sharing (WS) — Shutdowns not actioned regardless of duration](/en/site/dossier/updated_covid_19_work_sharing_availability.shtml) | Non-complex Level 1 Level 2 IPOC | EI ERB Post EI ERB |

| Work-Sharing (WS) — Availability requirements relaxed during shutdown [Work-Sharing (WS) — Availability requirements relaxed during shutdown](/en/site/dossier/updated_covid_19_work_sharing_availability.shtml#availability) | Non-complex Level 1 Level 2 IPOC | EI ERB Post EI ERB |
``` 
