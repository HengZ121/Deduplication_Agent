# ROE: RCM validation error correction for a regular ROE (employer not reached) — Instructions

Source map: `en_EN/procedure/generic/correction_reg_2/correction_reg_2.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/correction_reg_2/generic.dita`

**Related Procedures**

- Correcting an error during calculation or recalculation — Regular ROE
         [Correcting an error during calculation or recalculation — Regular ROE](/en/procedure/task/correcting_roe_error_calculation_regular.shtml)

- Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE
         [Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE](/en/procedure/task/post_eierb_completing_assessment_issue_roe_correction_wi_regular_roe.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0750.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0674.dita) 

*Workarounds and actions must be completed in the order given.

Select the section of the ROE in which the error message appears to see an alphabetical list of messages encountered when correcting an ROE.

- 4 - Employer’s name
         [4 - Employer’s name](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#name)

- 6 - Pay period type
         [6 - Pay period type](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#PP)

- 10 - First day worked
         [10 - First day worked](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#FDW)

- 11 - Last day for which paid
         [11 - Last day for which paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#LDP)

- 12 - Final pay period ending date
         [12 - Final pay period ending date](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#FPPED)

- 14 - Expected date of recall
         [14 - Expected date of recall](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#recall)

- 15A - Total insurable hours
         [15A - Total insurable hours](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#InsHrs)

- 15B - Total insurable earnings
         [15B - Total insurable earnings](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#InsMoney)

- 15C - Pay period details
         [15C - Pay period details](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#PPs)

- 16 - Reason for issuing this record of employment
         [16 - Reason for issuing this record of employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#RFS)

- 17A - Vacation pay
         [17A - Vacation pay](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#VP)

- 17B - Statutory holiday pay for
         [17B - Statutory holiday pay for](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#Stat)

- 17C - Other monies
         [17C - Other monies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#Other)

- Allocation of monies
         [Allocation of monies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#Alloc)

- 19 - Special payments
         [19 - Special payments](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#Special)

- Overridable errors
         [Overridable errors](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_2#overridable)

**4 - Employer’s name**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0659.dita) 

Return to the main task and contact the client.

**6 - Pay period type**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0751.dita) 

- Determine if RCM contains a previous ROE from the same employer:

- If yes, use the same pay period type as in the previous ROE and return to the main task.

- If no , go to step 2.

- Determine if block 15C is completed:

- If yes, go to step 3.

- If no , return to the main task and contact the client.

- Determine the ROE type:

- If the serial number of the ROE begins with W or M , go to step 5.

- If the serial number of the ROE begins with S , determine if the Number of rows block in RCM (immediately below the block 15C heading) is 27:

- If yes, got to step 4.

- If no , go to step 5.

- If this is any other ROE type, go to step 4.

- Determine if the ROE covers a period of more than 7 months:

- If yes, select the Pay period type based on the number of pay periods completed in block 15C . Return to the main task.
             [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0752.dita)

- If no, return to the main task and contact the client.

- Determine if the ROE covers a period of more than 13 months:

- If yes, select the pay period type based on the number of pay periods listed in block 15C . Return to the main task.
             [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0753.dita)

- If no, return to the main task and contact the client.

**10 - First day worked**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0754.dita) 

- In NWS, determine if the client has declared the same last day for which paid as indicated on the ROE:

- If no , go to step 2.

- If yes, determine if the client has declared a first day worked indicating a period of employment of at least 13 months.

- If yes, use the first day worked indicated on the application and return to the main task.

- If no , go to step 2.

- In FTS, determine if the client has had a previous claim:

- If no , go to step 4.

- If yes, review the client’s electronic declarations to determine if work has been reported for that same employer (employer phone number reported on the declarations will be same as on the application or current ROE).

- If yes, go to step 3.

- If no , go to step 4.

- In RCM, determine if there is another ROE from the same employer:

- If yes, go to step 4.

- If no, do the following:

- Use the earlier of the Sunday of the first week in which earnings were declared or the date declared in Full time job box of the declaration as the first day worked.

- Return to the main task.

- Determine if an ROE from that same employer exists with a period of employment before the ROE in error:

- If no , go to step 7.

- If yes, determine if the previous ROE has a last day worked within a year of the last day worked of the ROE in error.

- If yes, go to step 5.

- If no , go to step 6.

- Determine if the previous ROE has a return to work date:

- If yes, use the return to work date on the previous ROE and return to the main task.

- If no , go to step 6.

- If the current application contains a declared date, use it and return to the main task.

- Return to the main task and contact the client.

**11 - Last day for which paid**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0755.dita) 

- Determine if the client has provided a first day and last day worked on the application:

- If no , go to step 3.

- If yes, go to step 2.

- Determine if there is a reason to doubt the date provided on the application or if changing the last day for which paid to this date would create a new error:

- If yes, go to step 3.

- If no, do the following:

- Use the date on the application.

- Return to the main task.

- Determine if there is an obvious error in the documented year (especially common at the beginning of a calendar year):

- If no, return to the main task and contact the client.

- If yes, do the following:

- Change the year to reflect the correct date.

- Return to the main task.

**12 - Final pay period ending date**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0756.dita) 

- Determine if block 15C contains a valid pay period end date in pay period 1:

- If no , go to step 2.

- If yes, use the pay period ending date indicated pay period 1 and return to the main task.

- Determine if a previous ROE exists for this employer:

- If yes, go to step 3.

- If no , go to step 4.

- Determine if the previous ROE contains the same pay period type as the ROE in error and a final pay period ending date.

- If no, go to step 4.

- If yes, do the following:

- Calculate the pay period ending date using the pay period ending date of the previous ROE and the last day paid on the ROE in error.
                 [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0757.dita)

- Return to the main task.

- Determine the pay period type indicated:

- If monthly and the pay period ending date is not the last day of the month:

- Change the pay period type to Monthly non-standard and return to the main task.

- If semi-monthly and the pay period ending date is not the fifteenth or the last day of the month:

- Change the pay period type to Semi-monthly non-standard and return to the main task.

- If monthly non-standard and the pay period ending date is the last day of the month:

- Change the pay period type to Monthly and return to the main task.

- If semi-monthly non-standard and the pay period ending date is the fifteenth or the last day of the month:

- Change the pay period type to Semi-Monthly and return to the main task.

- If none of the above applies, return to the main task and contact the client.

         [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0758.dita)

- Determine if a previous ROE exists for this employer:

- If yes, go to step 2.

- If no , return to the main task and contact the client.

- Determine if the previous ROE contains the same pay period type as the ROE in error and a final pay period ending date:

- If no, return to the main task and contact the client.

- If yes, do the following:

- Calculate the pay period ending date using the pay period ending date of the previous ROE and the last day paid on the ROE in error.
                 [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0757.dita)

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0759.dita) 

- Determine if block 15C contains a valid pay period end date in pay period 1:

- If no , go to step 2.

- If yes, use the pay period ending date indicated in pay period 1 and return to the main task.

- Determine if a previous ROE exists for this employer:

- If yes, go to step 3.

- If no , go to step 4.

- Determine if the previous ROE contains the same pay period type as the ROE in error and a final pay period ending date:

- If no, go to step 4.

- If yes, do the following:

- Calculate the pay period ending date using the pay period ending date of the previous ROE and the last day paid on the ROE in error.
                 [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0757.dita)

- Return to the main task.

- Determine the pay period type indicated:

- If monthly and the pay period ending date is not the last day of the month:

- Change the pay period type to Monthly non-standard and return to the main task.

- If semi-monthly and the pay period ending date is not the fifteenth or the last day of the month:

- Change the pay period type to Semi-monthly non-standard and return to the main task.

- If monthly non-standard and the pay period ending date is the last day of the month:

- Change the pay period type to Monthly and return to the main task.

- If semi-monthly non-standard and the pay period ending date is the fifteenth or the last day of the month:

- Change the pay period type to Semi-Monthly and return to the main task.

- If none of the above, return to the main task and contact the client.

**14 - Expected date of recall**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0760.dita) 

- Change the expected date of recall to Unknown .

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0761.dita) 

- Change the expected date of recall to Not returning .

**15A - Total insurable hours**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0762.dita) 

- Determine if the period of employment falls entirely before the qualifying period:

- If no, go to step 2.

- If yes, do the following:

- Determine the number of full weeks of employment which are contained in block 15A and multiply by 35 hours per week.

- Determine the number of additional days of employment which did not fall into full weeks of employment and multiply by 7 hours per day.

- Add the 2 amounts together and type this into block 15A .

- Return to the main task.

- Determine if either block 10 or block 11 is in error:

- If no , return to the main task and contact the client.

- If yes, correct either or both and do the following:

- If this corrects the error for block 15A , return to the main task.

- If this does not correct the error for block 15A , return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0763.dita) 

- Determine if the client has indicated his rate of pay on the application:

- If yes, go to step 2.

- If no , return to the main task and contact the client.

- Determine the first day that could possibly be represented by the amount in block 15B by plotting the period of employment.
         [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0764.dita)

- Determine if the first day worked indicated is equal to or later than the date determined above:

- If no , return to the main task and contact the client.

- If yes, do the following:

- Divide the earnings in block 15B by the rate of pay to obtain the hours .

- Type the hours determined into block 15A .

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0765.dita) 

- Delete the amount in block 15A.

- Return to the main task.

**15B - Total insurable earnings**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0766.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0767.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0768.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0769.dita) 

- Determine if the block 15B equals the total of all insurable separation monies:

- If yes, go to step 2.

- If no , go to step 4.

- Determine if there is a previous ROE on file issued by the employer that is clearly related to the separation monies:

- If yes, go to step 3.

- If no , go to step 4.

- Determine if all the information is on the ROE (in the Comments or Additional information fields) to establish the reason and dates the monies were paid:

- If no , go to step 4.

- If yes, do the following:

- Add the separation monies, insurable and non-insurable, to the previous ROE.

- Type in the Additional information field of the previous ROE, the information about the reason for the separation monies and the dates the monies were paid.

- (For the ROE in error) Delete: Check the box.

- Additional information: Type “ROE issued only for separation monies. Previous ROE (serial number corrected).”

- Determine if the previous ROE was used in the calculation of a prior benefit period and if so, go to Recalculation .
                 [Recalculation](/en/procedure/activity/recalculation.shtml)

- Return to the main task.

- Determine if the Additional information or Comments fields clearly state that some or all of the selections in block 17C are not insurable:

- If no , go to step 5.

- If yes, do the following:

- Change the other monies description in block 17C to reflect the correct non-insurable other monies option as indicated in the Additional information field.

- Return to the main task.

- Determine if only one type of monies listed in block 17 :

- If no , return to the main task and contact the client.

- If yes, do one of the following:

- If the selection indicated is clearly an insurable type (e.g. “Pay in Lieu” but not “Other”), add the insurable separation monies indicated to the amount in block 15B . Return to the main task.

- If the selection indicated is a type which would normally require clarification (e.g. “Other”) but is clearly indicated in the Additional information field as insurable, add the insurable separation monies indicated to the amount in block 15B . Return to the main task.

**15C - Pay period details**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0770.dita) 

- Determine if the earnings are greater than $0.00 and less than $1.00:

- If yes, change to $1.00 and return to the main task.

- If no , return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0771.dita) 

- Determine if block 15B equals the total of all insurable separation monies:

- If yes, go to step 2.

- If no , go to step 4.

- Determine if there is a previous ROE on file issued by the employer that is clearly related to the separation monies:

- If yes, go to step 3.

- If no , go to step 4.

- Determine if all the information is on the ROE (in the Comments or Additional information fields) to establish the reason and dates the monies were paid:

- If no , go to step 4.

- If yes, do the following:

- Add the separation monies, insurable and non-insurable, to the previous ROE.

- In the Additional information field of the previous ROE, enter the information about the reason for the separation monies and the dates the monies were paid.

- (For the ROE in error) Delete: Check the box.

- Additional information: Type “ROE issued only for separation monies. Previous ROE (serial number) corrected.”

- Determine if the previous ROE was used in the calculation of a prior benefit period and if so, refer to Recalculation .
                 [Recalculation](/en/procedure/activity/recalculation.shtml)

- Return to the main task.

- Determine if the last day paid in block 11 falls in the pay period immediately before the date that is in block 12 :

- If yes, go to step 5.

- If no , determine if the last day worked on the client’s application falls in the pay period immediately before the pay period that is in block 12 .

- If yes, change block 11 to equal the last day worked of the client.

- If no , go to step 6.

- Determine if block 12 indicates that the final pay period ending date is invalid:

- If no , go to step 6.

- If yes, do the following:

- Change block 12 to equal the correct pay period ending date based on the date in block 11 .

- Move the amounts indicated in each pay period back one pay period (e.g. pay period 3 becomes pay period 2).

- Add the insurable separation monies into pay period 1.

- Determine if an additional pay period is now required in block 15C and if yes, estimate it based on the lowest amount that is not $0.00 in the balance of block 15C .

- Return to the main task.

- Determine if the Additional information field or Comments block clearly state that some or all of the selections in block 17C are not insurable:

- If no , go to step 7.

- If yes, do the following:

- Change the other monies description in block 17C to reflect the correct non-insurable other monies option as indicated in the Additional Information field or Comments block.

- Return to the main task.

- Determine if only one type of monies is listed in block 17 :

- If no , return to the main task and contact the client.

- If yes, do one of the following:

- If the selection indicated is clearly an insurable type (e.g. Pay in lieu of notice but not Other ), add the insurable separation monies indicated to the amount in block 15C , pay period 1 and block 15B . Return to the main task.

- If the selection indicated is a type which would normally require clarification (e.g. Other ) but is clearly indicated in the Additional Information field as insurable, add the insurable separation monies indicated to the amount in block 15C pay period 1 and block 15B .

- Return to the main task.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0772.dita) 

- Determine if $0.00 was reported in the pay period which includes the first day worked:

- If yes, go to step 2.

- If no , go to step 3.

- Estimate the earnings for the pay period in which the first day worked falls as follows:

- Calculate the number of days of work contained in the pay period in which first day worked falls.
             [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0773.dita)

- Estimate the daily rate based on the other pay periods or, failing that, use the minimum wage multiplied by the number of hours.
             [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0774.dita)

- Estimate the earnings for the pay period in which the first day worked falls by using the estimated daily rate and the number of days in the pay period.

- Enter the amount calculated into the pay period which includes the first day worked.

- Subtract the same amount calculated from the next pay period containing earnings.
             [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0775.dita)

- Return to the main task.

- Determine if the earnings are greater than $0.00 and less than $1.00:

- If no , return to the main task and contact the client.

- If yes, change to $1.00 and return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0776.dita) 

- Determine if the earnings are greater than $0.00 and less than $1.00:

- If yes, change to $1.00 and return to the main task.

- If no , return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0777.dita) 

- Determine if the hours in pay period are 0.00:

- If yes, go to step 2.

- If no, go to step 5.

- Determine if there are insurable separation monies:

- If yes, go to step 3.

- If no, enter 0.01 hours in pay period 1.

- Determine if the earnings are equal to the insurable separation monies:

- If no, return to the main task and contact the client.

- If yes, do the following:

- Add the earnings from pay period 1 to pay period 2.

- Move the amounts indicated in each pay period back one pay period (e.g. pay period 3 becomes pay period 2).

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0778.dita) 

- Determine if the earnings are greater than $0.00 and less than $1.00:

- If no , return to the main task and contact the client.

- If yes, do the following:

- Change the hours to 0.01.

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0779.dita) 

- Determine if earnings are indicated in the same pay period:

- If yes, go to step 2.

- If no , determine if earnings are $0.00:

- If yes, change hours to 0.00 and return to the main task.

- If no , return to the main task and contact the client.

- Determine if the entire period of employment is detailed in block 15C :

- If yes, calculate the hours using block 15A and block 15C and return to the main task.

- If no , do the following:

- Assume the earnings are correct.

- Change the Hours field to 0.01

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0780.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0781.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0782.dita) 

- Determine if there are multiple pay periods detailed in block 15C :

- If yes, go to step 2.

- If no , change the pay period ending date in block 15C to equal block 12 and return to the main task.

- Determine if all of the pay period ending dates in block 15C appear correct based on the pay period type:

- If no , go to step 3.

- If yes, change block 12 to equal the pay period ending date in pay period 1 of block 15C and return to the main task.

- Determine if pay period 1 appears to be the only one in error:

- If yes, do the following:

- Using the pay period type and the pay period ending date in pay period 2, determine the correct next pay period ending date after pay period 2 and change pay period 1 to reflect this new date.
                 [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0783.dita)

- Change block 12 to the new value for block 15C pay period 1.

- Return to the main task.

- If no, do the following :

- Make any correction for missing or duplicate pay periods in block 15C .

- Change pay period 1 in block 15C to equal block 12 .

- If the other pay period ending dates are now in error, adjust each based on the new value in pay period 1 of block 15C and the pay period type.
                 [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0784.dita)

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0785.dita) 

- Determine if the duplicate date was input due to a missing pay period ending date:

- If yes, input the missing pay period date in place of the duplicate date and return to the main task.

- If no , return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0786.dita) 

- Determine if block 15B is a greater amount than the total of the amounts listed in block 15C :

- If yes, go to step 2.

- If no , go to step 3.

- Determine if only one pay period is blank:

- If no, return to the main task and contact the client.

- If yes, do the following:

- Calculate the blank pay period amount by subtracting the total earnings listed in block 15C from the amount in block 15B .

- Return to the main task.

- Determine if the total earnings in the required pay periods in block 15C equal block 15B :

- If no , return to the main task and contact the client.

- If yes, do the following:

- Remove the amount in the extra pay periods.

- Return to the main task.

**16 - Reason for issuing this record of employment**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0669.dita) 

- Determine if a reason for separation was indicated on the application:

- If yes, use it and return to the main task.

- If no , return to the main task and contact the client.

**17A - Vacation pay**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0787.dita) 

- Determine if the amount is less than $1.00:

- If no , return to the main task and contact the client.

- If yes, do the following:

- Remove the amount.

- If a reason was selected for the vacation pay, select the blank option from the drop-down list.

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0788.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0789.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0790.dita) 

- "‘Anniversary (paid on a specific date each year)’." (17A001SD10080)

- "‘Paid for a vacation leave period’." (17A001SD10079)

- Return to the main task and contact the client.

**17B - Statutory holiday pay for**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0791.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0792.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0793.dita) 

- Determine if the amount is less than $1.00:

- If no , return to the main task and contact the client.

- If yes, do the following :

- Remove the amount.

- Remove the related date.

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0794.dita) 

- Return to the main task and contact the client.

**17C - Other monies**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0717.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0795.dita) 

- Determine if the amount is less than $1.00:

- If yes and if an option was chosen, select the blank option.

- If no , return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0796.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0797.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0798.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0799.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0800.dita) 

- Return to the main task and contact the client.

**Allocation of monies**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0801.dita) 

- Review and correct data entry errors.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0802.dita) 

- Review and correct data entry errors.

**19 - Special payments**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0803.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0804.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0805.dita) 

- Determine if sufficient special payment details (i.e. amount and dates) are available to check the appropriate box:

- If yes, check the appropriate box of the leave period based on the details of the special payment. Return to the main task.

- If no, return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0806.dita) 

- Use the day after the last day worked on the application.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0807.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0808.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0809.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0810.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0811.dita) 

- Determine if sufficient special payment details (i.e. amount and dates) are available to check the appropriate box:

- If yes, check the appropriate box of the leave period based on the details of the special payment. Return to the main task.

- If no, return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0812.dita) 

- Use the day after the last day worked on the application.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0813.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0814.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0815.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0816.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0817.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0818.dita) 

- Determine if sufficient special payment details (i.e. amount and dates) are available to check the appropriate box:

- If yes, check the appropriate box of the applicable leave period based on the details of the special payment. Return to the main task.

- If no, return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0819.dita) 

- Determine if sufficient special payment details (i.e. amount and dates) are available to check the appropriate box:

- If yes, check the appropriate box of the applicable leave period based on the details of the special payment. Return to the main task.

- If no, return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0820.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0821.dita) 

- Determine if sufficient special payment details (i.e. amount and dates) are available to check the appropriate box:

- If yes, check the appropriate box of the applicable leave period based on the details of the special payment. Return to the main task.

- If no, return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0822.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0823.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0745.dita) 

- Determine if sufficient special payment details (i.e. amount and dates) are available to check the appropriate box:

- If yes, check the appropriate box of the applicable leave period based on the details of the special payment. Return to the main task.

- If no, return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0746.dita) 

- Return to the main task and contact the client.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0747.dita) 

- Return to the main task and contact the client.

**Overridable errors**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0824.dita) 

- Determine if block 15C is completed on both overlapping ROEs:

- If yes, go to step 2.

- If no , return to the main task and contact the client.

- Determine if it is clear by reviewing the pay period amounts that the subsequent ROE includes information from the previous ROE:

- If no , return to the main task and contact the client.

- If yes, on the subsequent ROE, do the following:

- Remove any pay period already included on the previous ROE.

- Remove any pay periods with $0.00 earnings which occurred immediately after the last day worked of the previous ROE.

- In block 10 , change the first day worked to indicate the first day worked of the oldest pay period remaining with earnings.

- Remove the amount from block 15B.

- Determine if hours are present in block 15C :

- If no , go to step 4.

- If yes, on the subsequent ROE, do the following:

- Total the hours from the remaining pay periods.

- Enter the total hours in block 15A .

- Return to the main task.

- In NWS, determine if the rate of pay is on the application:

- If yes, go to step 5.

- If no, do the following :

- Contact the client to obtain the rate of pay or an estimate of hours before proceeding.

- If the client has provided an estimate of hours, on the subsequent ROE, enter these in block 15A and return to the main task.

- If the client has provided the rate of pay, go to step 5.

- Estimate the hours for block 15A of the subsequent ROE as follows:

- If the serial number of the ROE begins with W , do the following:

- Use the total earnings remaining in block 15C and divide them by the rate of pay.

- Enter this amount in block 15A .

- Return to the main task.

- If the serial number of the ROE is not W , do the following:

- Use the total earnings remaining in block 15C and divide them by the rate of pay. This gives the number of hours for the period covered by the ROE for earnings.

- Determine how many days are represented by the earnings in block 15C .

- Divide the number of hours by the number of days to calculate the average daily hours.

- Determine how many days should be represented by the ROE for the hours.

- Multiply the average daily hours by the number of days represented by the ROE for the hours.

- Return to the main task. 

### Note

Source topic: `en_EN/common_notes/note_c_0750.dita`

Note:

This chart is to assist you in making corrections while awaiting contact from the employer. Follow-up with the employer should always be attempted before and after taking the steps outlined in this chart. 

### Note

Source topic: `en_EN/common_notes/note_c_0674.dita`

Note:

For an ROE Correction WI, an initial calculation or a recalculation using a Government of Canada ROE that requires correction, refer to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Info

Source topic: `en_EN/common_notes/note_c_0659.dita`

Error message : “Employer’s name is required.” (04X000NM10485) 

### Info

Source topic: `en_EN/common_notes/note_c_0751.dita`

Error message : “A valid entry in the pay period type must be provided.” (06X000TP10257) 

### Example

Source topic: `en_EN/common_notes/note_c_0752.dita`

Example:

If the number of pay periods is 27, select Weekly . If the number of pay periods is 14, select Bi-weekly . If the number of pay periods is 7, select Monthly . If the number of pay periods is 13, select Semi-Monthly . Note for Monthly and Semi-Monthly pay periods: Review date in block 12 and if the day is not the last day of the month for Monthly or the fifteenth or last day of the month for Semi-monthly , the pay period is non-standard. 

### Example

Source topic: `en_EN/common_notes/note_c_0753.dita`

Example:

If the number of pay periods is 53, select Weekly . If the number of ay periods is 27, select Bi-Weekly . If the number of pay periods is 13, select Monthly . If the number of pay periods is 25, select Semi-Monthly . If the number of pay periods is 14, 13 pay periods a year . Note for Monthly and Semi-monthly : Review the date in block 12 and if the day is not the last day of the month for Monthly or the fifteenth or last day of the month for Semi-monthly , the pay period is non-standard. 

### Info

Source topic: `en_EN/common_notes/note_c_0754.dita`

Error message : “First day worked is required.” (10X000DT10481) 

### Info

Source topic: `en_EN/common_notes/note_c_0755.dita`

Error message : “Last day for which paid must be later than or equal to the first day worked.” (11X000DT10017) 

### Info

Source topic: `en_EN/common_notes/note_c_0756.dita`

Error message : “Final pay period ending date cannot be more than:

- 6 days after the last day for which paid, based on a Weekly pay period type.” (12X000DT10025)

- 13 days after the last day for which paid, based on a Bi-weekly pay period type.” (12X000DT10019)

- 15 days after the last day for which paid and cannot be the 15th or the last day of the month (except for the 28th or 29th of February), based on a Semi-Monthly non-standard pay period type.” (12X000DT10023)

- 15 days after the last day for which paid and must be the 15th or the last day of the month, based on a Semi-Monthly pay period type.” (12X000DT10022)

- 27 days after the last day for which paid, based on 13 pay periods per year.” (12X000DT10024)

- 30 days after the last day for which paid and cannot be the last day of the month (except for the 28th or 29th of February), based on a Monthly Non-Standard pay period type.” (12X000DT10021)

- 30 days after the last day for which paid and must be the last day of the month, based on a Monthly pay period type.” (12X000DT10020)

It is important to know that if the ROE was completed with an incorrect pay period ending date, the insurable hours and earnings may have been incorrectly calculated using the wrong number of pay periods. 

### Example

Source topic: `en_EN/common_notes/note_c_0757.dita`

Example:

Last day worked on ROE in error: September 14/12. Pay period type on both ROEs: Semi-monthly non-standard. Pay period ending date on previous ROE: March 24/12. Calculated pay period ending date for ROE in error: September 24/12. 

### Info

Source topic: `en_EN/common_notes/note_c_0758.dita`

Error message : “Final pay period ending date is required.” (12X000DT10482) 

### Info

Source topic: `en_EN/common_notes/note_c_0759.dita`

Error message : “Final pay period ending date must be later than or equal to the last day for which paid.” (12X000DT10018)

It is important to know that if the ROE was completed with an incorrect pay period ending date, the insurable hours and earnings may have been incorrectly calculated using the wrong number of pay periods. 

### Info

Source topic: `en_EN/common_notes/note_c_0760.dita`

Error message : “Expected date of recall must be later than the last day for which paid <LDFWP>.” (14X000DT10029) 

### Info

Source topic: `en_EN/common_notes/note_c_0761.dita`

Error message : “The expected date of recall code cannot be ‘Y – Expected date of recall’ if the reason for issuing the ROE code is:

- E.” (14X000TP10026)

- G.” (14X000TP10027)

- M.” (14X000TP10028)

An expected date of recall with a reason for separation of E - Quit , G - Mandatory retirement or M - Dismissal is contradictory. If fact-finding has determined that the reason for separation on the ROE is correct, the expected date of recall option must be changed to Not returning . 

### Info

Source topic: `en_EN/common_notes/note_c_0762.dita`

Error message : “Total Insurable hours cannot exceed the lesser of 8,904 or (Last day for which paid <LDFWP> - first day worked <FDW> + 1) x 24.” (15A000HR10031)

The ROE contains an impossible amount of hours for the period of employment. The employer may have reversed the entries for blocks 15A and 15B . 

### Info

Source topic: `en_EN/common_notes/note_c_0763.dita`

Error message : “Total Insurable hours must be from 1 to 8,904 inclusive (comma added for readability only).” (15A000HR10459)

The employer may have reversed the entries in blocks 15A and block 15B . 

### Example

Source topic: `en_EN/common_notes/note_c_0764.dita`

Example:

Pay period type: Monthly. Final pay period ending date: September 30, 2013. Maximum required pay periods to be contained in block 15B : 7. The first day possibly represented by block 15B : March 1, 2013. 

### Info

Source topic: `en_EN/common_notes/note_c_0765.dita`

Error message: “The Insurable hours must be equal to the total of the insurable hours (the total of the hours must always be rounded up to the next whole number).” (15A000HR10032) This error appears on S series ROE’s and is caused by the number of hours in block 15C not equating to the number of hours recorded in block 15A. 

### Note

Source topic: `en_EN/common_notes/note_c_0766.dita`

Note:

Total insurable earnings on an ROE can be from $1.00 to $9,999,999.99.  When the amount on the ROE is higher than $999,999.99, the agent must modify the amount to $999,999.99 in RCM. 

### Info

Source topic: `en_EN/common_notes/note_c_0767.dita`

Error message : “Total insurable earnings amount must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (15B000AM10034)

When this occurs, the amount must be confirmed with the client. If the client confirms that the amount is less than $1.00 but greater than $0, enter $1.00. If the client confirms the total insurable earnings are greater than $999,999.99, the Level 1 agent who is calculating the claim must do the following:

- enter the earnings amount in block 15B to $999.999.99

- document the information on an SROC 

### Note

Source topic: `en_EN/common_notes/note_c_0768.dita`

Note:

Determine the average normal weekly earnings (ANWE) and average earnings in the last week worked (AELWW) according to the client’s real earnings. In RCM, in the Allocation of monies section, complete the following fields:

- Average normal weekly earnings: Enter the ANWE amount as calculated.

- Average earnings last week worked: Enter the AELWW amount as calculated.

- Return to the main task. 

### Info

Source topic: `en_EN/common_notes/note_c_0769.dita`

Error message : “Total insurable earnings amount must include insurable earnings as well as the total amount of insurable separation monies provided.” (15B000AM10033) This error occurs under the following instances:

- Insurable separation monies may have been incorrectly excluded from the total earnings amount in block 15B .

- Separation monies in block 17 may have been selected as insurable in error.

- A new ROE was incorrectly issued solely for separation monies paid after the fact rather than an amended original. It is important to note during calculation that if separation monies were issued at a later date, the reason for the payment as it may have an effect on the date of the allocation. Refer to the Earnings procedure for more details.
         [Earnings](/en/procedure/activity/earnings.shtml)

     [Earnings](/en/procedure/activity/earnings.shtml) 

### Info

Source topic: `en_EN/common_notes/note_c_0770.dita`

Error message : “Insurable earnings amount in pay period 1 must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (15C001AM10041) 

### Info

Source topic: `en_EN/common_notes/note_c_0771.dita`

Error message : “Insurable earnings amount in pay period 1 must include insurable earnings as well as the total amount of insurable separation monies provided.” (15C001AM10047)

Insurable separation monies may have been paid in a pay period after the pay period in which the client last worked and pay period 1 may incorrectly contain only the insurable separation monies. When this happens, the agent must examine the last day paid on the ROE as the employer may have incorrectly completed it as the day the separation monies were paid.

Insurable separation monies may have been incorrectly excluded from the total earnings amount in pay period 1 of block 15C .

Separation monies in block 17 may have been selected as insurable in error.

A new ROE was incorrectly issued solely for separation monies paid after the fact rather than an amended original. It is important to note during calculation that if separation monies were issued at a later date, the reason for the payment can have an effect on the date of the allocation. Refer to the Earnings procedure for more details.
       [Earnings](/en/procedure/activity/earnings.shtml)

     [Earnings](/en/procedure/activity/earnings.shtml) 

### Example

Source topic: `en_EN/common_notes/note_c_0772.dita`

Error message : “Insurable earnings amount in pay period <nn> containing the first day worked must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (15C0nnAM10043 <nn>=pay period number 01-53)

The first day worked may be incorrect or when completing the pay periods in block 15C , the employer may have included the hours and earnings for the first day worked in a subsequent pay period.

Example:

The employee has a first day worked of August 9. On August 13 the employer completes the payroll for the period of August 5 to 11 but does not yet have the employee officially on the payroll. The August 9 to 11 earnings are included in the pay period ending August 18. The ROE is then incorrectly completed showing the earnings for the pay period ending August 11 as $0.00. 

### Example

Source topic: `en_EN/common_notes/note_c_0773.dita`

Example:

Pay period type: Monthly First day worked: September 29, 2013. First day worked falls into the pay period from September 1, 2013 to September 30, 2013. Number of days worked in the pay period in which first day worked falls: 2 (September 29 and 30). 

### Example

Source topic: `en_EN/common_notes/note_c_0774.dita`

Example:

Pay period from November 1 to 30: 30 days. Earnings from November 1 to 30 pay period: $1 800. Average daily rate: $1 800/30 days = $60. 

### Example

Source topic: `en_EN/common_notes/note_c_0775.dita`

Example:

Pay period 6 is the pay period in which the first day worked falls. Earnings for pay period 6 estimated at $100. Pay period 5 is $0.00. Pay period 4 is $500. Pay period 4 earnings is $500 - $100: $400. 

### Info

Source topic: `en_EN/common_notes/note_c_0776.dita`

Error message : “Insurable earnings amount in pay period <nn> must be from 1.00 to 999,999.99 (comma added for readability only) inclusive or must be 0.00 when there are no insurable earnings.” (15C0nnAM10046 <nn>=pay period 02 to 53) 

### Info

Source topic: `en_EN/common_notes/note_c_0777.dita`

Error message : “Insurable hours in pay period 1 must be from 0.01 to 999.99 inclusive (decimal included).” (15C001HR10055)

This error may appear in conjunction with an error related to insurable separation monies if pay period 1 has earnings and no hours. When it does, correct it first as that may resolve this error. 

### Info

Source topic: `en_EN/common_notes/note_c_0778.dita`

Error message : “Insurable hours in pay period <nn> containing the First day worked must be from 0.01 and 999.99 inclusive (decimal included).” (15C0nnHR10056 <nn>=pay period 02 to 53) 

### Info

Source topic: `en_EN/common_notes/note_c_0779.dita`

Error message : “Insurable Hours must be in the format of 999.99.” (15C0nnHR10316 <nn>=pay period 02 to 53) 

### Info

Source topic: `en_EN/common_notes/note_c_0780.dita`

Error message : “Pay period end dates must all be different and none must be omitted.” (15C000DT10446) An employer’s payroll records may display 2 identical pay period ending dates if corrections were made to the pay period. The information may then have been incorrectly used as 2 entries in block 15C . 

### Info

Source topic: `en_EN/common_notes/note_c_0781.dita`

Error message : “Pay period ending date, amount and hours must be provided for each pay period required.” (15C0000010036) 

### Info

Source topic: `en_EN/common_notes/note_c_0782.dita`

Error message : “Pay period ending date in pay period 1 must be equal to the final pay period ending date provided.” (15C001DT10038)

This error may occur in conjunction with an error in block 12 . Correcting the error in block 12 may resolve the error in block 15C . 

### Example

Source topic: `en_EN/common_notes/note_c_0783.dita`

Example:

Pay period type: biweekly. Pay period ending date in pay period 2: October 16, 2013. Next pay period ending date: October 30, 2013. 

### Example

Source topic: `en_EN/common_notes/note_c_0784.dita`

Example:

Pay period type: Bi-weekly. Pay period ending date in block 12: October 30, 2013. Pay period ending date in block 15C pay period 2: October 17, 2013. Change pay period 2 to be the correct date of October 16, 2013. 

### Info

Source topic: `en_EN/common_notes/note_c_0785.dita`

Error message : “Pay period ending dates must be provided in chronological order starting with the final pay period ending date.” (15C000DT10039) 

### Info

Source topic: `en_EN/common_notes/note_c_0786.dita`

Error message : “The number of consecutive pay periods must be equal to the period of employment and must not exceed:

- 7 or 13 pay periods for a Monthly pay period type.” (15C0000010475)

- 7 or 13 pay periods for a Monthly non-standard pay period type.” (15C0000010476)

- 7 or 14 pay periods for 13 pay periods per year type.” (15C0000010479)

- 7 pay periods for 13 pay periods per year type.” (15C0000010442)

- 7 pay periods for a Monthly non-standard pay period type.” (15C0000010436)

- 7 pay periods for a Monthly pay period type.” (15C0000010434)

- 13 or 25 pay periods for a Semi-Monthly pay period type.” (15C0000010477)

- 13 or 25 pay periods for a Semi-Monthly non-standard pay period type.” (15C0000010478)

- 13 pay periods for a Monthly non-standard pay period type.” (15C0000010437)

- 13 pay periods for a Monthly pay period type.” (15C0000010435)

- 13 pay periods for a Semi-Monthly non-standard pay period type.” (15C0000010440)

- 13 pay periods for a Semi-Monthly pay period type.” (15C0000010438)

- 14 or 27 pay periods for a Bi-weekly pay period type.” (15C0000010474)

- 14 pay periods for 13 pay periods per year type.” (15C0000010443)

- 14 pay periods for a Bi-weekly pay period type.” (15C0000010432)

- 25 pay periods for a Semi-Monthly non-standard pay period type.” (15C0000010441)

- 25 pay periods for a Semi-Monthly pay period type.” (15C0000010439)

- 27 or 53 pay periods for a Weekly pay period type.” (15C0000010480)

- 27 pay periods for a Bi-weekly pay period type.” (15C0000010433)

- 27 pay periods for a Weekly pay period type.” (15C0000010444)

- 53 pay periods for a Weekly pay period type.” (15C0000010445) 

### Info

Source topic: `en_EN/common_notes/note_c_0669.dita`

Error message : “A valid Reason for issuing this ROE must be provided.” (16X000TP10065) 

### Info

Source topic: `en_EN/common_notes/note_c_0787.dita`

Error message : “The vacation pay amount must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (17A001AM10097) 

### Info

Source topic: `en_EN/common_notes/note_c_0788.dita`

Error message : “The vacation pay end date is required when the vacation pay type is ‘Paid for a vacation leave period’.” (17A001ED10086) 

### Info

Source topic: `en_EN/common_notes/note_c_0789.dita`

Error message : “The vacation pay end date must be later than or equal to the vacation pay start date when the vacation pay type is ‘Paid for a vacation leave period’.” (17A001ED10090) 

### Info

Source topic: `en_EN/common_notes/note_c_0790.dita`

Error message : “The vacation pay start date is required when vacation pay code is: 

### Info

Source topic: `en_EN/common_notes/note_c_0791.dita`

Error message : “Statutory holiday paid for date <nn> must be later than the last day for which paid and earlier than or equal to (last day for which paid + 12 months).” (17B0nnDT10101 <nn>=statutory holiday pay for item number 01 to 10) 

### Info

Source topic: `en_EN/common_notes/note_c_0792.dita`

Error message : “Statutory holiday pay amount <nn> is required when corresponding statutory holiday paid for date is provided.” (17B0nnAM10103 <nn>=statutory holiday pay for item number 01 to 10) 

### Info

Source topic: `en_EN/common_notes/note_c_0793.dita`

Error message : “Statutory holiday paid for amount <nn> must be from 1.00 to 999,999.99 inclusive (Comma added for readability only).” (17B0nnAM10105 <nn>=statutory holiday pay for item number 01 to 10) 

### Info

Source topic: `en_EN/common_notes/note_c_0794.dita`

Error message : “Statutory holiday pay dates must all be different.” (17B0nnDT10098 <nn>=statutory holiday pay for item number 01 to 10) 

### Note

Source topic: `en_EN/common_notes/note_c_0717.dita`

Note:

A temporary measure under Pilot Project No. 24 applies to separation monies paid due to a separation from employment on claims with a BPC or allocation start date between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). When separation monies are paid for that period, they are not allocated.

If the monies are paid because of the separation, the officer leaves the date fields of the ROE blank and UIC does not allocate the monies. If the monies are paid for any other reason, the officer enters the appropriate dates in the ROE, and UIC allocates the amounts as usual. 

### Info

Source topic: `en_EN/common_notes/note_c_0795.dita`

Error message : “Other monies amount <nn> must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (17C0nnAM10187 <nn>= other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0796.dita`

Error message : “Other monies end date <nn> is required when other monies code:

- ‘B - Bonus (Production / Incentive)’ is provided.” (17C0nnED10137 <nn>=other monies item number 01 to 05)

- ‘H - Honorariums’ is provided.” (17C0nnED10145 <nn>=other monies item number 01 to 05)

- ‘W - Provincial payment / Preventative withdrawal’ is provided.” (17C0nnED10159 <nn>=other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0797.dita`

Error message : “Other monies end date <nn> must be from the current date minus 50 years and the current date plus 2 years inclusive.” (17C0nnED10162 <nn>=other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0798.dita`

Error message : “Other monies end date <nn> must be later than or equal to the other monies start date.” (17C0nnED10163 <nn>=other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0799.dita`

Error message : “Other monies start date <nn> is required when other monies code:

- ‘B - Bonus (Event)’ is provided.” (17C0nnSD10109 <nn>=other monies item number 01 to 05)

- ‘B - Bonus (Holiday)’ is provided.” (17C0nnSD10107 <nn>=other monies item number 01 to 05)

- ‘B - Bonus (Production / Incentive)’ is provided.” (17C0nnSD10108 <nn>=other monies item number 01 to 05)

- ‘H - Honorariums’ is provided.” (17C0nnSD10116 <nn>=other monies item number 01 to 05)

- ‘W - Provincial payment / Preventative withdrawal’ is provided.” (17C0nnSD10130 <nn>=other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0800.dita`

Error message : “Other monies start date <nn>) must be from the current date minus 50 years and the current date plus 2 years inclusive.” (17C0nnSD10133 <nn>=other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0801.dita`

Error message : “Allocation of Monies - Average Earnings Last Week Worked amount must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (17R000LA10189) 

### Info

Source topic: `en_EN/common_notes/note_c_0802.dita`

Error message : “Allocation of Monies - Average Normal Weekly Earnings amount must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (17R000WA10188) 

### Info

Source topic: `en_EN/common_notes/note_c_0803.dita`

Error message : “Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave amount is required when special payment type ‘Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave’ is provided.” (19X003AM10216) 

### Info

Source topic: `en_EN/common_notes/note_c_0804.dita`

Error message : “Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave end date must be equal to the last day for which paid <LDFWP>.” (19X003AM10210) 

### Info

Source topic: `en_EN/common_notes/note_c_0805.dita`

Error message : “Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave period is required when special payment type ‘Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave’ is provided.” (19X003AM10224) 

### Info

Source topic: `en_EN/common_notes/note_c_0806.dita`

Error message : “Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave start date is required when special payment type ‘Paid Maternity / Parental / Compassionate Care / Family caregiver benefits’ is provided.” (19X003AM10195) 

### Info

Source topic: `en_EN/common_notes/note_c_0807.dita`

Error message : “Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave start date must be earlier than or equal to the last day for which paid <LDFWP>.” (19X003SD10198) 

### Info

Source topic: `en_EN/common_notes/note_c_0808.dita`

Error message : “Paid Sick Leave amount is required when special payment start date is provided for special payment type ‘Paid Sick Leave” (19X001AM10453) 

### Info

Source topic: `en_EN/common_notes/note_c_0809.dita`

Error message : “Paid Sick Leave amount is required when special payment type ‘Paid Sick Leave’ is provided.” (19X001AM10212) 

### Info

Source topic: `en_EN/common_notes/note_c_0810.dita`

Error message : “Paid Sick Leave end date must be equal to the last day for which paid <LDFWP>.” (19X001AM10207) 

### Info

Source topic: `en_EN/common_notes/note_c_0811.dita`

Error message : “Paid Sick Leave period is required when special payment type ‘Paid Sick Leave’ is provided.” (19X001AM10220) 

### Info

Source topic: `en_EN/common_notes/note_c_0812.dita`

Error message : “Paid Sick Leave start date is required when special payment type ‘Paid Sick Leave’ is provided.” (19X001AM10191) 

### Info

Source topic: `en_EN/common_notes/note_c_0813.dita`

Error message : “Paid Sick Leave start date must be earlier than or equal to the last day for which paid <LDFWP>.” (19X001SD10196) 

### Info

Source topic: `en_EN/common_notes/note_c_0814.dita`

Error message : “Special payment amount must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (19X0nnAM10218 <nn>=special payment item number 01 to 04) 

### Info

Source topic: `en_EN/common_notes/note_c_0815.dita`

Error message : “Special payment end date must be later than or equal to the special payments start date.” (19319X0nnED10206 <nn>=special payments item number 01 to 04) 

### Info

Source topic: `en_EN/common_notes/note_c_0816.dita`

Error message : “Wage Loss Indemnity (EI insurable) amount is required when special payment end date is provided for special payment type ‘Wage Loss Indemnity (EI insurable)’.” (19X002AM10215)

Note: When an ROE contains wage loss indemnity (EI Insurable) in block 19 , the agent calculating the claim must refer to the Reviewing the calculation result - Messages to obtain the correct calculation result in SSO.
       [Reviewing the calculation result - Messages](/en/procedure/generic/rcr_screen_messages.shtml#invalidsp)

     [Reviewing the calculation result - Messages](/en/procedure/generic/rcr_screen_messages.shtml#invalidsp) 

### Info

Source topic: `en_EN/common_notes/note_c_0817.dita`

Error message : “Wage Loss Indemnity (EI insurable) end date must be later than or equal to Wage Loss Indemnity (EI insurable) start date.” (19X002AM10208)

Note: When an ROE contains wage loss indemnity (EI Insurable) in block 19 , the agent calculating the claim must refer to the Reviewing the calculation result - Messages to obtain the correct calculation result in SSO.
       [Reviewing the calculation result - Messages](/en/procedure/generic/rcr_screen_messages.shtml#invalidsp)

     [Reviewing the calculation result - Messages](/en/procedure/generic/rcr_screen_messages.shtml#invalidsp) 

### Info

Source topic: `en_EN/common_notes/note_c_0818.dita`

Error message : “Wage Loss Indemnity (EI insurable) period is required when Wage loss indemnity (EI insurable) amount is provided for special payment type ‘Wage Loss Indemnity (EI insurable)’.” (19X002AM10223)

Note: When an ROE contains wage loss indemnity (EI Insurable) in block 19 , the agent calculating the claim must refer to the Reviewing the calculation result - Messages to obtain the correct calculation result in SSO.
       [Reviewing the calculation result - Messages](/en/procedure/generic/rcr_screen_messages.shtml#invalidsp)

     [Reviewing the calculation result - Messages](/en/procedure/generic/rcr_screen_messages.shtml#invalidsp) 

### Info

Source topic: `en_EN/common_notes/note_c_0819.dita`

Error message : “Wage Loss Indemnity (EI insurable) period is required when Wage loss indemnity (EI insurable) end date is provided for special payment type Wage loss indemnity (EI insurable).” (19X002AM10450)

Note: When an ROE contains wage loss indemnity (EI Insurable) in block 19 , the agent calculating the claim must refer to the Reviewing the calculation result - Messages to obtain the correct calculation result in SSO.
       [Reviewing the calculation result - Messages](/en/procedure/generic/rcr_screen_messages.shtml#invalidsp)

     [Reviewing the calculation result - Messages](/en/procedure/generic/rcr_screen_messages.shtml#invalidsp) 

### Info

Source topic: `en_EN/common_notes/note_c_0820.dita`

Error message : “Wage Loss Indemnity (EI insurable) start date is required when special payment type ‘Wage loss indemnity (EI insurable)’ is provided.” (19X002AM10194)

Note: When an ROE contains wage loss indemnity (EI Insurable) in block 19 , the agent calculating the claim must refer to the Reviewing the calculation result - Messages to obtain the correct calculation result in SSO.
       [Reviewing the calculation result - Messages](/en/procedure/generic/rcr_screen_messages.shtml#invalidsp)

     [Reviewing the calculation result - Messages](/en/procedure/generic/rcr_screen_messages.shtml#invalidsp) 

### Info

Source topic: `en_EN/common_notes/note_c_0821.dita`

Error message : “Wage loss indemnity (EI not insurable) period is required when Wage loss indemnity (EI not insurable) end date is provided for special payment type Wage loss indemnity (EI not insurable).” (19X004PR10449) 

### Info

Source topic: `en_EN/common_notes/note_c_0822.dita`

Error message : “Wage loss indemnity (Not EI insurable) amount is required when Wage loss indemnity (Not EI insurable) end date is provided.” (19X004PR10214) 

### Info

Source topic: `en_EN/common_notes/note_c_0823.dita`

Error message : “Wage loss indemnity (Not EI insurable) end date must be later than or equal to Wage Loss Indemnity (Not EI insurable) start date.” (19X004PR10209) 

### Info

Source topic: `en_EN/common_notes/note_c_0745.dita`

Error message : “Wage loss indemnity (Not EI insurable) period is required when special payment amount is provided for special payment type ‘Wage Loss Indemnity (Not EI insurable)’.” (19X004PR10222) 

### Info

Source topic: `en_EN/common_notes/note_c_0746.dita`

Error message : “Wage loss indemnity (Not EI insurable) start date is required when ‘Wage loss indemnity (Not EI insurable)’ end date is provided.” (19X004PR10193) 

### Info

Source topic: `en_EN/common_notes/note_c_0747.dita`

Error message : “Wage loss indemnity (Not EI insurable) start date must be later than the last day for which paid <LDFWP>.” (19X004SD10197) 

### Info

Source topic: `en_EN/common_notes/note_c_0824.dita`

Error message : “First Day Worked or the Last Day for Which Paid provided on this ROE overlaps an ROE issued to this employee.” (9900000010412)

An ROE was issued with the same business number as another ROE and they have overlapping dates.

This error can occur when an employer issues a subsequent ROE to amend a previous ROE but does not include the serial number of the ROE being amended in block 2 of the subsequent ROE.

This error can also occur when an employer issues a subsequent ROE using the same first day worked as a previous ROE. When this happens, the subsequent ROE may contain hours and earnings already included on the previous ROE, which may lead to incorrect benefit entitlement. The first day worked on the subsequent ROE must be corrected to indicate the first day worked since the previous ROE was issued. The agent must also ensure hours and earnings from the previous ROE are not included in the subsequent ROE.

Although this error is generally due to an error when completing the ROE, on occasion the overlap occurs because an employee is employed by the same employer in 2 different jobs (e.g. the client works during the day as a school receptionist and works for the same employer in the evenings as a janitor). When this situation occurs and is confirmed with the employer, the dates indicated on the ROEs are correct. 
