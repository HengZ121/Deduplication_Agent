# ROE: RCM validation error correction for a regular ROE — Instructions

Source map: `en_EN/procedure/generic/correction_reg_1/correction_reg_1.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/correction_reg_1/generic.dita`

**Related Procedures**

- Completing an ROE Correction WI — Regular ROE
         [Completing an ROE Correction WI — Regular ROE](/en/procedure/task/completing_roe_correction_regular.shtml)

- Correcting an error during calculation or recalculation — Regular ROE
         [Correcting an error during calculation or recalculation — Regular ROE](/en/procedure/task/correcting_roe_error_calculation_regular.shtml)

- Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE
         [Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE](/en/procedure/task/post_eierb_completing_assessment_issue_roe_correction_wi_regular_roe.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0674.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0675.dita) 

Select the section of the ROE in which the error message appears to see an alphabetical list of messages encountered when correcting an ROE.

- 4 - Employer’s name
         [4 - Employer’s name](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#ername)

- 6 - Pay period type
         [6 - Pay period type](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#pptype)

- 10 - First day worked
         [10 - First day worked](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#fdw)

- 11 - Last day for which paid
         [11 - Last day for which paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#ldp)

- 12 - Final pay period ending date
         [12 - Final pay period ending date](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#fpped)

- 14 - Expected date of recall
         [14 - Expected date of recall](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#recall)

- 15A - Total insurable hours
         [15A - Total insurable hours](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#hrs)

- 15B - Total insurable earnings
         [15B - Total insurable earnings](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#earnings)

- 15C - Pay period details
         [15C - Pay period details](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#ppdetails)

- 16 - Reason for issuing this record of employment
         [16 - Reason for issuing this record of employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#rfs)

- 17A - Vacation pay
         [17A - Vacation pay](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#vp)

- 17B - Statutory holiday pay for
         [17B - Statutory holiday pay for](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#statpay)

- 17C - Other monies
         [17C - Other monies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#other)

- 19 - Special payments
         [19 - Special payments](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#special)

- Overridable errors
         [Overridable errors](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/correction_reg_1#overridable)

**4 - Employer’s name**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0676.dita) 

- In FTS, select the Employer (MN22) search and type the employer’s business number:

- If the search by business number displays the employer’s name, type it in the Employer’s name field.

- If the search by business number does not display the employer’s name, return to the main task and contact the employer.

**6 - Pay period type**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0677.dita) 

- Determine if the period of employment is less than 8 days:

- If yes, go to step 2.

- If no , return to the main task and contact the employer.

- Do the following:

- In the Pay period type field, select Weekly .

- Change the date in block 12 to equal block 11 .

- If block 15C displays 2 pay periods, combine the pay period amounts into pay period 1 in block 15C .

- If the ROE serial number begins with an “S”, change the pay period ending date in block 15C to equal block 11 .

- Return to the main task.

**10 - First day worked**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0678.dita) 

- Return to the main task and contact the employer.

**11 - Last day for which paid**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0679.dita) 

- Return to the main task and contact the employer.

**12 - Final pay period ending date**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0680.dita) 

- Determine if the ROE indicates one of the following:

- The pay period type is semi-monthly and the final pay period ending date is not the 15th or last day of the month.

- The pay period type is monthly and the final pay period ending date is not the last day of the month.

         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0681.dita)

- Determine if block 15C contains a valid pay period end date in pay period 1:

- If no , go to step 3.

- If yes, use the pay period ending date indicated pay period 1 and return to the main task.

- Determine if a previous ROE exists for this employer:

- If yes, go to step 4.

- If no, go to step 7.

- Determine if the previous ROE contains the same pay period type as the ROE in error and a final pay period ending date.

- If yes, go to step 5.

- If no, go to step 7.

- Determine if the previous ROE indicates a correct final pay period ending date:

- If yes, go to step 6.

- If no , go to step 7.

- Do the following:

- If the ROE is semi-monthly and the client’s last day paid is before the 16th of the month, change the date in block 12 to equal the 15th day of the month in which the client was last paid.

- If the ROE is semi-monthly and the client’s last day paid is on or after the 16th of the month, change the date in block 12 to equal the last day of the month in which the client was last paid.

- If the ROE is monthly, change the date in block 12 to equal the last day of the month.

- Return to the main task.

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0682.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0683.dita) 

- Return to the main task and contact the employer.

**14 - Expected date of recall**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0684.dita) 

- Determine if the client is applying for maternity or parental benefits:

- If yes, go to step 2.

- If no , select Unknown and return to the main task.

- Determine if the expected date of recall is on the application in NWS:

- If yes, enter the date provided on the application and return to the main task.

- If no , select Unknown and return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0685.dita) 

- Select Unknown and return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0686.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0687.dita) 

- Return to the main task and contact the employer.

**15A - Total insurable hours**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0688.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0689.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0690.dita) 

- Delete the amount in block 15A

- Return to the main task

**15B - Total insurable earnings**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0691.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0692.dita) 

- Determine if block 15C is completed:

- If no , return to the main task and contact the employer.

- If yes, go to step 2.

- Determine if block 15C contains an error message:

- If no , remove the amount from block 15B and return to the main task.

- If yes, do the following:

- Contact the employer if the information is not on the ROE or in file.

- Correct block 15C .

- Remove the amount from block 15B .

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0693.dita) 

- Determine if the block 15B equals the total of all insurable separation monies:

- If yes, go to step 2.

- If no , go to step 4.

- Determine if there is a previous ROE on file issued by the employer that is clearly related to the separation monies:

- If yes, go to step 3.

- If no , go to step 4.

- Determine if all the information is on the ROE (in the Comments or Additional information fields) to establish the reason and dates the monies were paid:

- If no , return to the main task and contact the employer to obtain additional information.

- If yes, do the following:

- Add the insurable separation monies to the previous ROE.

- In the Additional information field of the previous ROE, enter the information about the reason for the separation monies and the dates the monies were paid.

- Delete: Check the box (for the ROE in error).

- Additional information: Type “ROE issued only for separation monies. Previous ROE (serial number corrected).”

- Determine if the previous ROE was used in the calculation of a prior benefit period and if so, refer to Recalculation .
                 [Recalculation](/en/procedure/activity/recalculation.shtml)

- Return to the main task.

- Determine if block 15C is completed:

- If no , return to the main task and contact the employer.

- If yes, go to step 5.

- Determine if block 15C contains an error message:

- If no , remove the amount from block 15B and return to the main task.

- If yes, do the following:

- Contact the employer if the information is not on the ROE or in file.

- Correct block 15C .

- Remove the amount from block 15B .

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0694.dita) 

- Determine if block 15C also contains an error message:

- If no , remove the amount from block 15B and return to the main task.

- If yes, do the following:

- Contact the employer if the information is not on the ROE or on file.

- Correct block 15C .

- Remove the amount from block 15B .

- Return to the main task.

**15C - Pay period details**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0695.dita) 

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0696.dita) 

- Determine if the block 15C pay period 1 equals the total of all insurable separation monies:

- If no , go to step 2.

- If yes, return to the main task and contact the employer.

- Determine if the Additional information field or the Comments field clearly states that some or all of the selections in block 17C are not insurable:

- If yes, go to step 3.

- If no , go to step 4.

- Determine if any of the monies indicated as non-insurable were incorrectly selected as an insurable type:

- If no , go to step 4.

- If yes, change the other monies description in block 17C to reflect the correct non-insurable other monies option as per the information indicated.

- If the error is resolved, return to the main task.

- If the error is not resolved, return to the main task and contact the employer.

- Determine if only one type of monies is listed in block 17 :

- If no , return to the main task and contact the employer.

- If yes, go to step 5.

- Determine if the selection indicated is clearly an insurable type (e.g. Pay in Lieu but not Other ):

- If no , go to step 6.

- If yes, do the following:

- Add the insurable separation monies indicated to the amount in block 15C , pay period 1 and block 15B .

- If the error is resolved, return to the main task.

- If the error is not resolved, return to the main task and contact the employer.

- Determine if the selection indicated is an insurable type that normally requires clarification (e.g. Other ), but that the ROE clearly states that it is an insurable amount (e.g. the Additional Information field indicates the monies in block 17C are a retiring allowance):

- If no , return to the main task and contact the employer.

- If yes, do the following:

- Add the insurable separation monies indicated to the amount in block 15C pay period 1 and block 15B .

- Change the type option to reflect the correct insurable earnings.

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0697.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0698.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0699.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0700.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0701.dita) 

- Determine if the earnings for that pay period are $0.00:

- If yes, go step 2.

- If no , return to the main task and contact the employer.

- Determine if block 15B is in error:

- If yes, return to the main task and contact the employer.

- If no , enter 0.00 in the Hours field and return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0702.dita) 

- Determine if the duplicate date was input due to a missing pay period ending date:

- If yes, enter the missing pay period date in place of the duplicate date and return to the main task.

- If no , return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0703.dita) 

- Determine if the missing date clearly falls between 2 other pay periods listed in block 15C :

- If yes, enter the correct date and return to the main task.

- If no , return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0704.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0705.dita) 

- Determine if the duplicate date was input due to a missing pay period ending date:

- If yes, enter the missing pay period date in place of the duplicate date and return to the main task.

- If no , return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0706.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0707.dita) 

- Determine if the employer provided more pay periods than the maximum allowed for that pay period type due to VBW:

- If yes, make a note of the pay periods to be removed, and go to step 3.

- If no, go to step 2.

- Count the number of pay periods that fall between the first day worked and the last day worked.

- If the number of pay periods between the first day worked and the last day worked is greater than what was provided by the employer, contact the employer to obtain the missing pay period information.

- If the number of pay periods between the first day worked and the last day worked is less than what was provided by the employer, contact the employer to verify the first day worked is correct.

- Return to the main task.

**16 - Reason for issuing this record of employment**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0708.dita) 

- Return to the main task and contact the employer.

**17A - Vacation pay**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0709.dita) 

- Determine if the amount is $0.00:

- If no , return to the main task and contact the employer.

- If yes, do the following:

- Remove the amount.

- If a reason was selected for the vacation pay, select the blank option.

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0710.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0711.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0712.dita) 

- Return to the main task and contact the employer.

**17B - Statutory holiday pay for**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0713.dita) 

- Non-complex officers must return to the main task.

- Determine if the information indicates that the statutory holiday paid for date is acceptable.

- If no , return to the main task and contact the employer.

- If yes, do the following:

- Type “Statutory holiday paid for date is acceptable.” in the Additional information field.

- Make note that you must check the Overrideable errors box next to “Statutory Holiday Paid For Date cannot be later than the Last Day For Which Paid Date plus 12 months.” when the ROE is submitted.

- Return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0714.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0715.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0716.dita) 

- Return to the main task and contact the employer.

**17C - Other monies**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0717.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0718.dita) 

- Determine if the amount is $0.00:

- If yes and an option was selected, select the blank option and return to the main task.

- If no , return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0719.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0720.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0721.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0722.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0723.dita) 

- Return to the main task and contact the employer.

**19 - Special payments**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0724.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0725.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0726.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0727.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0728.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0729.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0730.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0731.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0732.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0733.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0734.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0735.dita) 

- Determine if the amount is $0.00:

- If yes, go to step 2.

- If no , return to the main task and contact the employer.

- Determine if any other Special payment fields are completed:

- If yes, return to the main task and contact the employer.

- If no , remove the amount and return to the main task.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0736.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0737.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0738.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0739.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0740.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0741.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0742.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0743.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0744.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0745.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0746.dita) 

- Return to the main task and contact the employer.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0747.dita) 

- Return to the main task and contact the employer.

**Overridable errors**

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0748.dita) 

- Determine if one ROE clearly indicates that it is amended (see box 2 or the comments in box 18 ):

- If yes, go to step 3.

- If no , do the following:

- Non-complex officers must return to the main task.

- Level 1 officers must go to step 2.

- Determine if the information indicates that the overlap is acceptable (e.g. client works at 2 separate jobs for the employer):

- If yes, for each overlapping ROE, do the following:

- Type “overlap acceptable.” in the Additional information field.

- Make note that you must check the Overrideable errors box next to “This ROE overlaps an existing ROE.” when the ROEs are submitted.

- Return to the main task.

- If no , return to the main task and contact the employer.
             [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0749.dita)

- Determine if the ROE being amended was used in the calculation of a prior benefit period:

- If no , go to step 4.

- If yes, return to the main task and contact the employer.

- Determine if the serial number of the ROE begins with S or W:

- If no , complete block 2 of the amended ROE with the serial number of the original ROE and return to the main task.

- If yes, do the following:

- Delete: Check the box (of the original ROE).

- Additional information: Type “ROE has been amended with ROE [serial number of amending ROE].”

- Return to the main task. 

### Note

Source topic: `en_EN/common_notes/note_c_0674.dita`

Note:

For an ROE Correction WI, an initial calculation or a recalculation using a Government of Canada ROE that requires correction, refer to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0675.dita`

Note:

Workarounds and actions must be completed in the order given. 

### Info

Source topic: `en_EN/common_notes/note_c_0676.dita`

Error message: “Employer’s name is required.” (04X000NM10485) 

### Info

Source topic: `en_EN/common_notes/note_c_0677.dita`

Error message: “A valid pay period type must be provided.” (06X000TP10257) 

### Info

Source topic: `en_EN/common_notes/note_c_0678.dita`

Error message: “First day worked is required.” (10X000DT10481) 

### Info

Source topic: `en_EN/common_notes/note_c_0679.dita`

Error message: “Last day for which paid must be later than or equal to the first day worked.” (11X000DT10017) 

### Info

Source topic: `en_EN/common_notes/note_c_0680.dita`

Error message: “Final pay period ending date cannot be more than:

- 6 days after the last day for which paid, based on a Weekly pay period type.” (12X000DT10025)

- 13 days after the last day for which paid, based on a Bi-weekly pay period type.” (12X000DT10019)

- 15 days after the last day for which paid and cannot be the 15th or the last day of the month (except for the 28th or 29th of February), based on a Semi-Monthly non-standard pay period type.” (12X000DT10023)

- 15 days after the last day for which paid and must be the 15th or the last day of the month, based on a Semi-Monthly pay period type.” (12X000DT10022)

- 27 days after the last day for which paid, based on 13 pay periods per year.” (12X000DT10024)

- 30 days after the last day for which paid and cannot be the last day of the month (except for the 28th or 29th of February), based on a Monthly Non-Standard pay period type.” (12X000DT10021)

- 30 days after the last day for which paid and must be the last day of the month, based on a Monthly pay period type.” (12X000DT10020)

It is important to know that if the ROE was completed with an incorrect pay period ending date, the insurable hours and earnings may have been incorrectly calculated using the wrong number of pay periods. 

### Callout

Source topic: `en_EN/common_notes/note_c_0681.dita`

- If either of these conditions is met, go to step 2.

- If neither of these conditions is met, go to step 7. 

### Info

Source topic: `en_EN/common_notes/note_c_0682.dita`

Error message: “Final pay period ending date is required.” (12X000DT10482) 

### Info

Source topic: `en_EN/common_notes/note_c_0683.dita`

Error message: “Final pay period ending date must be later than or equal to the last day for which paid.” (12X000DT10018)

It is important to know that if the ROE was completed with an incorrect pay period ending date, the insurable hours and earnings may have been incorrectly calculated using the wrong number of pay periods. 

### Info

Source topic: `en_EN/common_notes/note_c_0684.dita`

Error message: “A date is required when the expected date of recall code is ‘Y – Expected date of recall’.” (14X000DT10030) 

### Info

Source topic: `en_EN/common_notes/note_c_0685.dita`

Error message: “A valid expected date of recall code must be provided.” (14X000TP10299) 

### Info

Source topic: `en_EN/common_notes/note_c_0686.dita`

Error message: “Expected date of recall must be later than the last day for which paid <LDFWP>.” (14X000DT10029) 

### Info

Source topic: `en_EN/common_notes/note_c_0687.dita`

Error message: “The expected date of recall code cannot be ‘Y – Expected date of recall’ if the reason for issuing the ROE code is:

- E.” (14X000TP10026)

- G.” (14X000TP10027)

- M.” (14X000TP10028)

An expected date of recall with a reason for separation of E - Quit , G - Mandatory retirement or M - Dismissal is contradictory. If fact-finding has determined that the RFS on the ROE is correct, the expected date of recall option must be changed to Not returning . 

### Info

Source topic: `en_EN/common_notes/note_c_0688.dita`

Error message: “Total Insurable hours cannot exceed the lesser of 8,904 or (Last day for which paid <LDFWP> – first day worked <FDW> + 1) x 24.” (15A000HR10031)

The ROE contains an impossible amount of hours for the period of employment. The employer may have reversed the inputs for block 15A and block 15B . 

### Info

Source topic: `en_EN/common_notes/note_c_0689.dita`

Error message: “Total Insurable hours must be from 1 to 8,904 inclusive (comma added for readability only).” (15A000HR10459)

The employer may have reversed the inputs in block 15A and block 15B . 

### Info

Source topic: `en_EN/common_notes/note_c_0690.dita`

Error message: “The Insurable hours must be equal to the total of the insurable hours (the total of the hours must always be rounded up to the next whole number).” (15A000HR10032)

This error appears on S series ROE’s and it is caused by the number of hours in block 15C not equating to the number of hours recorded in block 15A. 

### Note

Source topic: `en_EN/common_notes/note_c_0691.dita`

Note:

Total insurable earnings on an ROE can be from $1.00 to $9,999,999.99. When the amount on the ROE is higher than $999,999.99, the officer must modify the amount to $999,999.99 in RCM.

Note: Officers must follow the steps under workarounds 15B and 15C to ensure that the ROE passes the RCM validation rules. 

### Info

Source topic: `en_EN/common_notes/note_c_0692.dita`

Error message: “Total insurable earnings amount must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (15B000AM10034)

When this occurs, the amount must be confirmed with the employer. If the employer confirms that the amount is less than $1.00 but greater than $0, enter $1.00. If the employer confirms the total insurable earnings are greater than $999,999.99, the Level 1 officer who is calculating the claim must do the following:

- enter the earnings amount in block 15B as $999,999.99

- document the information on an SROC

Note: Determine the average normal weekly earnings (ANWE) and average earnings in the last week worked (AELWW) according to the client’s real earnings. In RCM, in the Allocation of monies section, complete the following fields:

- Normal weekly earnings: Enter the ANWE amount as calculated.

- Earnings last week worked: Enter the AELWW amount as calculated. 

### Info

Source topic: `en_EN/common_notes/note_c_0693.dita`

Error message: “Total insurable earnings amount must include insurable earnings as well as the total amount of insurable separation monies provided.” (15B000AM10033)

This error occurs under the following instances:

- Insurable separation monies may have been incorrectly excluded from the total earnings amount in block 15B .

- Separation monies in block 17 may have been selected as insurable in error.

- A new ROE was incorrectly issued solely for separation monies paid after the fact rather than an amended original ROE. It is important to note during calculation that if separation monies were issued at a later date, the reason for the payment as it may have an effect on the date of the allocation. Refer to the Earnings procedure for more details.
         [Earnings](/en/procedure/activity/earnings.shtml)

     [Earnings](/en/procedure/activity/earnings.shtml) 

### Info

Source topic: `en_EN/common_notes/note_c_0694.dita`

Error message: “Total insurable earnings must be equal to the period of employment and must not exceed the last:

- 7 pay periods for a 13 pay periods per year pay period type.” (15B000AM10430)

- 7 pay periods for a Monthly non-standard pay period type.” (15B000AM10427)

- 7 pay periods for a Monthly pay period type.” (15B000AM10426)

- 13 pay periods for a Semi-Monthly non-standard pay period type.” (15B000AM10429)

- 13 pay periods for a Semi-Monthly pay period type.” (15B000AM10428)

- 14 pay periods for a Bi-weekly pay period type.” (15B000AM10425)

- 27 pay periods for a Weekly pay period type.” (15B000AM10431)

Removing the amount from block 15B allows RCM to calculate the correct amount for block 15B based on the inputs in block 15C . 

### Info

Source topic: `en_EN/common_notes/note_c_0695.dita`

Error message: “Insurable earnings amount in pay period 1 must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (15C001AM10041)

Note : If the employer confirms that the amount is less than $1.00 but greater than $0, enter $1.00. 

### Info

Source topic: `en_EN/common_notes/note_c_0696.dita`

Error message: “Insurable earnings amount in pay period 1 must include insurable earnings as well as the total amount of insurable separation monies provided.” (15C001AM10047)

Insurable separation monies may have been paid in a pay period after the pay period in which the client last worked and pay period 1 may incorrectly contain only the insured separation monies. When this happens, the officer must examine the last day paid on the ROE as the employer may have incorrectly completed it as the day the separation monies were paid.

Insurable separation monies may have been incorrectly excluded from the total earning amount in pay period 1 of block 15C .

Separation monies in block 17 may have been selected as insurable in error.

A new ROE was incorrectly issued solely for separation monies paid after the fact rather than an amended original. It is important to note during calculation that if separation monies were issued at a later date, the reason for the payment as it may have an effect on the date of the allocation. Refer to the Earnings procedure for more details.
       [Earnings](/en/procedure/activity/earnings.shtml)

     [Earnings](/en/procedure/activity/earnings.shtml) 

### Info

Source topic: `en_EN/common_notes/note_c_0697.dita`

Error message: “Insurable earnings amount in pay period <nn> containing the first day worked must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (15C0nnAM10043 <nn>=pay period number 01 to 53)

The first day worked may be incorrect or when completing the pay period in block 15C , the employer may have included the hours and earnings for the first day worked in a subsequent pay period.

Example:

The employee has a first day worked of August 9. On August 13, the employer completes the payroll for the period of August 5 to 11 but does not yet have the employee officially on the payroll. The August 9 to 11 earnings are paid on the pay run and included in the pay period ending August 18. The ROE is then incorrectly completed showing the earnings for the pay period ending August 11 as $0.00. 

### Info

Source topic: `en_EN/common_notes/note_c_0698.dita`

Error message: “Insurable earnings amount in pay period <nn> must be from 1.00 to 999,999.99 (comma added for readability only) inclusive or must be 0.00 when there are no insurable earnings.” (15C0nnAM10046 <nn>=pay period number 02 to 53)

Note: If the employer confirms that the amount is less than $1.00 but greater than $0, enter $1.00. 

### Info

Source topic: `en_EN/common_notes/note_c_0699.dita`

Error message: “Insurable hours in pay period 1 must be from 0.01 to 999.99 inclusive (decimal included).” (15C001HR10055)

This error may appear in conjunction with an error related to insurable separation monies if pay period 1 has earnings and no hours. When it does, correct it first as that may resolve this error. 

### Info

Source topic: `en_EN/common_notes/note_c_0700.dita`

Error message: “Insurable hours in pay period <nn> containing the First day worked must be from 0.01 and 999.99 inclusive (decimal included).” (15C0nnHR10056 <nn>=pay period number 02-53) 

### Info

Source topic: `en_EN/common_notes/note_c_0701.dita`

Error message: “Insurable Hours must be in the format of 999.99.” (15C0nnHR10316 <nn>=pay period number 02 to 53) 

### Info

Source topic: `en_EN/common_notes/note_c_0702.dita`

Error message: “Pay period end dates must all be different and none must be omitted.” (15C000DT10446)

An employer’s payroll records may display 2 identical pay period ending dates if corrections were made to the pay period. The information may then have been incorrectly used as two inputs in block 15C . 

### Info

Source topic: `en_EN/common_notes/note_c_0703.dita`

Error message: “Pay period ending date, amount and hours must be provided for each pay period required.” (15C0000010036) 

### Info

Source topic: `en_EN/common_notes/note_c_0704.dita`

Error message: “Pay period ending date in pay period 1 must be equal to the final pay period ending date provided.” (15C001DT10038)

This error may occur in conjunction with an error in block 12 . Correcting the error in block 12 may resolve the error in block 15C . 

### Info

Source topic: `en_EN/common_notes/note_c_0705.dita`

Error message: “Pay period ending dates must be provided in chronological order starting with the final pay period ending date.” (15C000DT10039) 

### Info

Source topic: `en_EN/common_notes/note_c_0706.dita`

Error message: “The number of consecutive pay periods must be equal to the period of employment and must not exceed:

- 7 or 13 pay periods for a Monthly pay period type.” (15C0000010475)

- 7 or 13 pay periods for a Monthly non-standard pay period type.” (15C0000010476)

- 7 or 14 pay periods for 13 pay periods per year type.” (15C0000010479)

- 7 pay periods for 13 pay periods per year type.” (15C0000010442)

- 7 pay periods for a Monthly non-standard pay period type.” (15C0000010436)

- 7 pay periods for a Monthly pay period type.” (15C0000010434)

- 13 or 25 pay periods for a Semi-Monthly pay period type.” (15C0000010477)

- 13 or 25 pay periods for a Semi-Monthly non-standard pay period type.” (15C0000010478)

- 13 pay periods for a Monthly non-standard pay period type.” (15C0000010437)

- 13 pay periods for a Monthly pay period type.” (15C0000010435)

- 13 pay periods for a Semi-Monthly non-standard pay period type.” (15C0000010440)

- 13 pay periods for a Semi-Monthly pay period type.” (15C0000010438)

- 14 or 27 pay periods for a Bi-weekly pay period type.” (15C0000010474)

- 14 pay periods for 13 pay periods per year type.” (15C0000010443)

- 14 pay periods for a Bi-weekly pay period type.” (15C0000010432)

- 25 pay periods for a Semi-Monthly non-standard pay period type.” (15C0000010441)

- 25 pay periods for a Semi-Monthly pay period type.” (15C0000010439)

- 27 or 53 pay periods for a Weekly pay period type.” (15C0000010480)

- 27 pay periods for a Bi-weekly pay period type.” (15C0000010433)

- 27 pay periods for a Weekly pay period type.” (15C0000010444)

- 53 pay periods for a Weekly pay period type.” (15C0000010445) 

### Note

Source topic: `en_EN/common_notes/note_c_0707.dita`

Note:

The employer may have provided more pay periods than required for block 15C in order to provide additional pay information for variable best weeks (VBW) calculation. The number of consecutive pay periods must be equal to the period of employment and must not exceed the maximum number of pay periods allowed for that pay period type. 

### Info

Source topic: `en_EN/common_notes/note_c_0708.dita`

Error message: “A valid Reason for issuing this ROE must be provided.” (16X000TP10065) 

### Info

Source topic: `en_EN/common_notes/note_c_0709.dita`

Error message: “The vacation pay amount must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (17A001AM10097)

Note : If the employer confirms that the amount is less than $1.00 but greater than $0, enter $1.00. 

### Info

Source topic: `en_EN/common_notes/note_c_0710.dita`

Error message: “The vacation pay end date is required when the vacation pay type is ‘Paid for a vacation leave period’.” (17A001ED10086) 

### Info

Source topic: `en_EN/common_notes/note_c_0711.dita`

Error message: “The vacation pay end date must be later than or equal to the vacation pay start date when the vacation pay type is ‘Paid for a vacation leave period’.” (17A001ED10090) 

### Info

Source topic: `en_EN/common_notes/note_c_0712.dita`

Error message: “The vacation pay start date is required when vacation pay code is:

- ‘Anniversary (paid on a specific date each year)’.” (17A001SD10080)

- ‘Paid for a vacation leave period’.” (17A001SD10079) 

### Info

Source topic: `en_EN/common_notes/note_c_0713.dita`

Error message: “Statutory holiday paid for date <nn> must be later than the last day for which paid and earlier than or equal to (last day for which paid + 12 months).” (17B0nnDT10101 <nn>=statutory holiday pay for item number 01 to 10)

Although a date more than 12 months after the last day for which paid is generally due to an error when completing the ROE, on occasion the statutory holiday pay is actually paid for a date more than a year after the last day paid. When this situation occurs and is confirmed with the employer, the officer can override the error to allow calculation of the claim. 

### Info

Source topic: `en_EN/common_notes/note_c_0714.dita`

Error message: “Statutory holiday pay amount <nn> is required when corresponding statutory holiday paid for date is provided.” (17B0nnAM10103 <nn>=statutory holiday pay for item number 01 to 10)

Note: If the employer confirms that the amount is less than $1.00 but greater than $0, enter $1.00. 

### Info

Source topic: `en_EN/common_notes/note_c_0715.dita`

Error message: “Statutory holiday paid for amount <nn> must be from 1.00 to 999,999.99 inclusive (Comma added for readability only).” (17B0nnAM10105 <nn>=statutory holiday pay for item number 01 to 10)

Note: If the employer confirms that the amount is less than $1.00 but greater than $0, enter $1.00. 

### Info

Source topic: `en_EN/common_notes/note_c_0716.dita`

Error message: “Statutory holiday pay dates must all be different.” (17B0nnDT10098 <nn>=statutory holiday pay for item number 01 to 10) 

### Note

Source topic: `en_EN/common_notes/note_c_0717.dita`

Note:

A temporary measure under Pilot Project No. 24 applies to separation monies paid due to a separation from employment on claims with a BPC or allocation start date between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). When separation monies are paid for that period, they are not allocated.

If the monies are paid because of the separation, the officer leaves the date fields of the ROE blank and UIC does not allocate the monies. If the monies are paid for any other reason, the officer enters the appropriate dates in the ROE, and UIC allocates the amounts as usual. 

### Info

Source topic: `en_EN/common_notes/note_c_0718.dita`

Error message: “Other monies amount <nn> must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (17C0nnAM10187 <nn>= other monies item number 01 to 05)

Note: If the employer confirms that the amount is less than $1.00 but greater than $0, enter $1.00. 

### Info

Source topic: `en_EN/common_notes/note_c_0719.dita`

Error message: “Other monies end date <nn> is required when other monies code:

- ‘B - Bonus (Production / Incentive)’ is provided.” (17C0nnED10137 <nn>=other monies item number 01 to 05)

- ‘H - Honorariums’ is provided.” (17C0nnED10145 <nn>=other monies item number 01 to 05)

- ‘W - Provincial payment / Preventative withdrawal’ is provided.” (17C0nnED10159 <nn>=other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0720.dita`

Error message: “Other monies end date <nn> must be from the current date minus 50 years and the current date plus 2 years inclusive.” (17C0nnED10162 <nn>=other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0721.dita`

Error message: “Other monies end date <nn> must be later than or equal to the other monies start date.” (17C0nnED10163 <nn>=other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0722.dita`

Error message: “Other monies start date <nn> is required when other monies code:

- ‘B - Bonus (Event)’ is provided.” (17C0nnSD10109 <nn>=other monies item number 01 to 05)

- ‘B - Bonus (Holiday)’ is provided.” (17C0nnSD10107 <nn>=other monies item number 01 to 05)

- ‘B - Bonus (Production / Incentive)’ is provided.” (17C0nnSD10108 <nn>=other monies item number 01 to 05)

- ‘H - Honorariums’ is provided.” (17C0nnSD10116 <nn>=other monies item number 01 to 05)

- ‘W - Provincial payment / Preventative withdrawal’ is provided.” (17C0nnSD10130 <nn>=other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0723.dita`

Error message: “Other monies start date <nn>) must be from the current date minus 50 years and the current date plus 2 years inclusive.” (17C0nnSD10133 <nn>=other monies item number 01 to 05) 

### Info

Source topic: `en_EN/common_notes/note_c_0724.dita`

Error message: “Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave amount is required when special payment type ‘Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave’ is provided.” (19X003AM10216) 

### Info

Source topic: `en_EN/common_notes/note_c_0725.dita`

Error message: “Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave end date must be equal to the last day for which paid <LDFWP>.” (19X003AM10210) 

### Info

Source topic: `en_EN/common_notes/note_c_0726.dita`

Error message: “Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave period is required when special payment type ‘Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave’ is provided.” (19X003AM10224) 

### Info

Source topic: `en_EN/common_notes/note_c_0727.dita`

Error message: “Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave start date is required when special payment type ‘Paid Maternity / Parental / Compassionate Care / Family caregiver benefits’ is provided.” (19X003AM10195) 

### Info

Source topic: `en_EN/common_notes/note_c_0728.dita`

Error message: “Paid Maternity / Parental / Compassionate Care / Family caregiver benefits leave start date must be earlier than or equal to the last day for which paid <LDFWP>.” (19X003SD10198) 

### Info

Source topic: `en_EN/common_notes/note_c_0729.dita`

Error message: “Paid Sick Leave amount is required when special payment start date is provided for special payment type ‘Paid Sick Leave’.” (19X001AM10453) 

### Info

Source topic: `en_EN/common_notes/note_c_0730.dita`

Error message: “Paid Sick Leave amount is required when special payment type ‘Paid Sick Leave’ is provided.” (19X001AM10212) 

### Info

Source topic: `en_EN/common_notes/note_c_0731.dita`

Error message: “Paid Sick Leave end date must be equal to the last day for which paid <LDFWP>.” (19X001AM10207) 

### Info

Source topic: `en_EN/common_notes/note_c_0732.dita`

Error message: “Paid Sick Leave period is required when special payment type ‘Paid Sick Leave’ is provided.” (19X001AM10220) 

### Info

Source topic: `en_EN/common_notes/note_c_0733.dita`

Error message: “Paid Sick Leave start date is required when special payment type ‘Paid Sick Leave’ is provided.” (19X001AM10191) 

### Info

Source topic: `en_EN/common_notes/note_c_0734.dita`

Error message: “Paid Sick Leave start date must be earlier than or equal to the last day for which paid <LDFWP>.” (19X001SD10196) 

### Info

Source topic: `en_EN/common_notes/note_c_0735.dita`

Error message: “Special payment amount must be from 1.00 to 999,999.99 inclusive (comma added for readability only).” (19X0nnAM10218 <nn>=special payment item number 01 to 04)

Note: If the employer confirms that the amount is less than $1.00 but greater than $0, enter $1.00. 

### Info

Source topic: `en_EN/common_notes/note_c_0736.dita`

Error message: “Special payment end date must be later than or equal to the special payments start date.” (19319X0nnED10206 <nn>=special payments item number 01 to 04) 

### Info

Source topic: `en_EN/common_notes/note_c_0737.dita`

Error message: “Wage Loss Indemnity (EI insurable) amount is required when special payment end date is provided for special payment type ‘Wage Loss Indemnity (EI insurable)’.” (19X002AM10215) 

### Info

Source topic: `en_EN/common_notes/note_c_0738.dita`

Error message: “Wage Loss Indemnity (EI insurable) end date must be later than or equal to Wage Loss Indemnity (EI insurable) start date.” (19X002AM10208) 

### Info

Source topic: `en_EN/common_notes/note_c_0739.dita`

Error message: “Wage Loss Indemnity (EI insurable) period is required when Wage loss indemnity (EI insurable) amount is provided for special payment type ‘Wage Loss Indemnity (EI insurable)’.” (19X002AM10223) 

### Info

Source topic: `en_EN/common_notes/note_c_0740.dita`

Error message: “Wage Loss Indemnity (EI insurable) period is required when Wage loss indemnity (EI insurable) end date is provided for special payment type Wage loss indemnity (EI insurable).” (19X002AM10450) 

### Info

Source topic: `en_EN/common_notes/note_c_0741.dita`

Error message: “Wage Loss Indemnity (EI insurable) start date is required when special payment type ‘Wage loss indemnity (EI insurable)’ is provided.” (19X002AM10194) 

### Info

Source topic: `en_EN/common_notes/note_c_0742.dita`

Error message: “Wage loss indemnity (EI not insurable) period is required when Wage loss indemnity (EI not insurable) end date is provided for special payment type Wage loss indemnity (EI not insurable).” (19X004PR10449) 

### Info

Source topic: `en_EN/common_notes/note_c_0743.dita`

Error message: “Wage loss indemnity (Not EI insurable) amount is required when Wage loss indemnity (Not EI insurable) end date is provided.” (19X004PR10214) 

### Info

Source topic: `en_EN/common_notes/note_c_0744.dita`

Error message: “Wage loss indemnity (Not EI insurable) end date must be later than or equal to Wage Loss Indemnity (Not EI insurable) start date.” (19X004PR10209) 

### Info

Source topic: `en_EN/common_notes/note_c_0745.dita`

Error message : “Wage loss indemnity (Not EI insurable) period is required when special payment amount is provided for special payment type ‘Wage Loss Indemnity (Not EI insurable)’.” (19X004PR10222) 

### Info

Source topic: `en_EN/common_notes/note_c_0746.dita`

Error message : “Wage loss indemnity (Not EI insurable) start date is required when ‘Wage loss indemnity (Not EI insurable)’ end date is provided.” (19X004PR10193) 

### Info

Source topic: `en_EN/common_notes/note_c_0747.dita`

Error message : “Wage loss indemnity (Not EI insurable) start date must be later than the last day for which paid <LDFWP>.” (19X004SD10197) 

### Info

Source topic: `en_EN/common_notes/note_c_0748.dita`

Error message: “First Day Worked or the Last Day for Which Paid provided on this ROE overlaps an ROE issued to this employee.” (9900000010412)

An ROE was issued with the same business number as another ROE and they have overlapping dates.

This error can occur when an employer issues a subsequent ROE to amend a previous ROE but does not include the serial number of the ROE being amended in block 2 of the subsequent ROE.

This error can also occur when an employer issues a subsequent ROE using the same first day worked as a previous ROE. When this happens, the subsequent ROE may contain hours and earnings already included on the previous ROE, which may lead to incorrect benefit entitlement. The first day worked on the subsequent ROE must be corrected to indicate the first day worked since the previous ROE was issued. The officer must also ensure hours and earnings from the previous ROE are not included in the subsequent ROE.

Although this error is generally due to an error when completing the ROE, on occasion the overlap occurs because an employee is employed by the same employer in 2 different jobs (e.g. the client works during the day as a school receptionist and works for the same employer in the evenings as a janitor). When this situation occurs and is confirmed with the employer, the dates indicated on the ROEs are correct. 

### Note

Source topic: `en_EN/common_notes/note_c_0749.dita`

Note:

If the first day worked on the subsequent ROE is incorrect, the ROE must be verified to ensure the hours and earnings indicated on the subsequent ROE are correct and corrections are made as required. 
