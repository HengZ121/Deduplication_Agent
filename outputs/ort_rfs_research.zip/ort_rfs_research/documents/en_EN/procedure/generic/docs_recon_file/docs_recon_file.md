# Appeal: Documents to include in the reconsideration file — Checklist

Source map: `en_EN/procedure/generic/docs_recon_file/docs_recon_file.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/docs_recon_file/generic.dita`

Summary: The reconsideration file is a document that combines all of the information used by an officer to make a decision on a request for reconsideration under EIA 112 .
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

**Reconsideration under EIA 112**

The reconsideration file is assembled and sent to the client following a negative decision. The reconsideration file contains all the information used and considered by the Commission when rendering a decision under EIA 112 . Unless otherwise directed, the officer includes the documents listed in the table below in the reconsideration file being sent to the client.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

**Appeal to the Employment Insurance Board of Appeal (EI BOA) or Social Security Tribunal (SST)**

The reconsideration file is provided to the EI BOA or SST, along with the Commission’s representations, when the Commission is notified of an appeal under EIA 113 . To best support the Commission’s position, the officer must take care when assembling the reconsideration file to ensure that all necessary documents are included.
       [EIA 113](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-113.html)

Depending on the issue under appeal or the participants in the appeal, the officer must include certain documents. The following table outlines the documents required, depending on the situation.

Once the file is compiled, the officer lists the documents on the List of documents included in the Reconsideration file (INS2245) form in the same logical order as they appear in the reconsideration file.

```text
| Situation | Documents to include in the reconsideration file |

| In all cases | The officer must include: - the relevant pages of the EI application (always include the following sections in addition to other pages related to the issue under appeal): - Personal Information - Benefit Type [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0836.dita) - Third Party Declaration and Attestation [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0837.dita) - Confirmation and Information; [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0838.dita) - all relevant documentation (SROCs, Action Item [AI] or Call Back [CB] WIs); - all relevant documents stored in Imaging or document upload; - the request for reconsideration; - any letters related to the original decision; - an attestation and copy of all generic emails sent related to the original and reconsideration decisions; - the letters related to the reconsideration decision. [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0839.dita) [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0840.dita) The officer must not include: - the Identity Information page of the application unless the client’s age is relevant to the issue under appeal. In these rare circumstances, the page is added but any other sensitive information such as the parent’s last name at birth is redacted. The redaction is explained in the representations. - the record of decision (ROD), except in the case of discretionary decisions (penalty, violation, denial of a delayed request, definite disqualifications and RODs related to reconsiderations under EIA 52 or amendments under EIA 111 if they are relevant to the issue under appeal); - internal memos and claims analyses providing guidance, expertise or personal opinions; - previous employment information, if the reviewed issue relates to the last employment; - the Integrity officer’s analysis of an interview or investigation (Report of Investigation); - automated investigation printouts (computer post-audit, self-employment [SE] earnings match, insured earnings match); [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0841.dita) - SSO or FTS screen printouts, unless specifically indicated for the issue under appeal (e.g. for disputes involving the selection of standard or extended parental benefits); - information received from an informant. |

| BT | Summary page |

| Maternity benefits | Validation of maternity benefits information |

| Parental benefits | Validation of parental benefits information |

| Maternity and parental benefits | Validation of maternity or parental benefits information |

| The issue under appeal resulted in an OP or the issue under review is the OP calculation | In addition to the documents required in all cases, the officer must include the following: - the Notice of Debt from DARS; - a copy of the Correspondence section showing the Notice of Debt from PSCD; - the ROD related to a reconsideration under EIA 52 or an amendment under EIA 111 if it is relevant to the issue under appeal; - all relevant documents, including SROCs related to the write-off; - the ROD related to the write-off of the OP, if available; - the ACS F-00-00-00 letter communicating the denial of the write-off, if available. [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0842.dita) [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0843.dita) In addition, the officer must include a breakdown of the OP in the following situations: - the client disputes the OP amount; - the OP amount changed during the process after the initial decision; - the OP calculation is complex. [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0844.dita) [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0845.dita) [EIR 56](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-56.html) [EIR 56](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-56.html) [The issue under appeal relates to a reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#RFS) |

| The issue under appeal relates to a reason for separation (RFS) | In addition to the documents required in all cases, the officer must include: - all relevant ROEs (including the back page). - For paper ROEs, the officer obtains a copy of the original from Imaging. If the back page is unavailable, the officer creates a transcript. [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0846.dita) [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0847.dita) |

| The issue under appeal is the imposition of a penalty | In addition to the documents required in all cases, the officer must include: - a copy of the ROD demonstrating that the Commission acted in a judicious manner in exercising its discretion in determining the penalty amount; - any related claimant’s reports (certified copy if imaged); - a copy of the Claimant’s report: INS5173 Request for exemption from reporting — Form , if the client is exempt from reporting; [Claimant’s report: INS5173 Request for exemption from reporting — Form](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5173.pdf) - electronic claimant’s report questions and answers (FTS); - the FTS - Payment information and the Direct Deposit portion of the application can be used to prove that warrants were received and deposited; - the ACS letter A-01-00-00- Reconsideration of Decision that was sent to the client, if necessary; - the Investigation Information Sheet from NIIS; - the Report of Interview Sheet from NIIS (if necessary); - the Earnings: INS5097 Request for payroll information — Form, if necessary; - the Earnings: INS5098 Request for clarification of employment information — Form, if necessary; - a copy of the Correspondence section, if necessary; - all related transcripts. [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0848.dita) The officer must not include: - the Integrity officer’s analysis of an interview or investigation (Report of Investigation); - automated investigation printouts (computer post audit, SE earnings match, insured earnings match). [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0841.dita) [Claimant’s report: INS5173 Request for exemption from reporting — Form](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5173.pdf) [EIA 39](http://www.servicecanada.gc.ca/eng/ei/legislation/ei_act_part1_11.shtml#a39) |

| The issue under appeal is the denial of a delayed request for reconsideration | In addition to the documents required in all cases, the officer must include: - a copy of the ROD demonstrating that the Commission acted in a judicious manner in exercising its discretion in denying the delayed request. The officer must not include: - any documents related only to the original decision (e.g. an SROC that deals only with the substantive issue). |

| The issue under appeal is a BPNE decision or is another calculation issue, such as the benefit rate | In addition to the documents required in all cases, the officer must include: - all ROEs used for calculation; - For paper ROEs, the officer obtains a copy of the original from Imaging. If the back page is unavailable, the officer creates a transcript. - all documentation relating to verification and changes on the ROEs; - a copy of the regional rate of unemployment (RRU) table ; [regional rate of unemployment (RRU) table](http://srv129.services.gc.ca/eiregions/eng/rates_cur.aspx) - a copy of the results obtained from the search performed with the client’s postal code on the EI Economic Region by Postal Code page. [EI Economic Region by Postal Code](http://srv129.services.gc.ca/eiregions/eng/postalcode_search.aspx) The officer can also include: - a copy of the SSO calculation worksheet (additional information may need to be added). If the client disputes the RRU, the officer must also include: - a certification document obtained from the Appeals Division at National Headquarters; [Appeals Division](hmailto:NC-INS-ASSUR_APPEALS_GENERAL_INQUIRY-GD) - the addition of EIR - 17(1) to the legislation section of the representations. [EIR - 17(1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-17.html) [regional rate of unemployment (RRU) table](http://srv129.services.gc.ca/eiregions/eng/rates_cur.aspx) [EI Economic Region by Postal Code](http://srv129.services.gc.ca/eiregions/eng/postalcode_search.aspx) [Appeals Division](hmailto:NC-INS-ASSUR_APPEALS_GENERAL_INQUIRY-GD) [EIR - 17(1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-17.html) |

| The issue under appeal relates to a Customs match (out of Canada) | In addition to the documents required in all cases, the officer must include: - a copy of the E-311 request sheet ; [E-311 request sheet](https://esdc.prv/en/service-canada/isb/io/bso/documents/e311.xls) - a copy of the electronic questionnaire. [E-311 request sheet](https://esdc.prv/en/service-canada/isb/io/bso/documents/e311.xls) |

| The issue under appeal is the allocation of earnings | In addition to the documents required in all cases, the officer can include: - a copy of the SSO calculation worksheet (additional information may need to be added); - a copy of the Employment History File (if the client is disputing the average weekly earnings). If the allocation relates to monies paid according to EIA 45 or EIA 46 (grievance settlement, court judgment, labour arbitration award or wrongful dismissal settlement) and the payment was made more than 36 months after the date of separation from employment, the officer must include: [EIA 45](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-45.html) [EIA 46](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-46.html) - the ROD for the discretionary decisions rendered under EIA 46.01 . [EIA 46.01](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-46.01.html) [EIA 45](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-45.html) [EIA 46](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-46.html) [EIA 46.01](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-46.01.html) |

| The issue under appeal is a definite disqualification | In addition to the documents required in all cases, the officer must include: - a copy of the ROD demonstrating that the Commission acted in a judicious manner in exercising its discretion in determining the number of weeks of disqualification. |

| The issue under appeal relates to the payment of standard or extended parental benefits | In addition to the documents required in all cases, the officer must include: - a copy of the MSCA certification ( BE Memo BE-2021-12); [BE Memo BE-2021-12);](/en/policy/bememo/be2021-11-a.shtml) - a screenshot of the Rate/Duration tab in FTS with the attestation. [BE Memo BE-2021-12);](/en/policy/bememo/be2021-11-a.shtml) |

| The issue under appeal relates to the sharing of parental benefits | In addition to the documents required in all cases, the officer must include: - a copy of the MSCA certification; - a screenshot of the Payments tab or the Pay History (MHQ1) screen in FTS with the type and number of weeks of parental benefits paid to each parent (the officer redacts all personal information of the other parent, except for the name and last 3 digits of the SIN). |

| The issue under appeal is availability for a student in full-time non-referred training | In addition to the documents required in all cases, the officer must include: - all ROEs (including the back page) demonstrating the client’s employment history in the qualifying period (QP) or before the QP. - For paper ROEs, the officer obtains a copy of the original from Imaging. If the back page is unavailable, the officer creates a transcript. |

| The issue under appeal is an antedate | In addition to the documents required in all cases, the officer must include: - the pages of the EI application containing information on the last employment (last day of work); - a copy of the last ROE confirming the client’s last day of work (showing that the client was late in filling their application for benefits); - all documentation relating to the client’s request for antedate. |

| The issue under appeal relates to claim procedures – Report card submitted late | In addition to the documents required in all cases, the officer must include: - a screenshot of the Payments tab (in situations where payments have already been issued and the client failed to continue submitting their reports in a timely matter) in FTS; - a screenshot of the E-Report History (MD01) in FTS; - all documentation related to the claimant’s request that their report be considered as if it was sent earlier (within the time limit). |
``` 

### Note

Source topic: `en_EN/common_notes/note_c_0836.dita`

Note:

Depending on the benefit type (BT) the client chooses, the officer includes the appropriate summary page as follows:

```text
| BT | Summary page |

| Maternity benefits | Validation of maternity benefits information |

| Parental benefits | Validation of parental benefits information |

| Maternity and parental benefits | Validation of maternity or parental benefits information |
``` 

### Note

Source topic: `en_EN/common_notes/note_c_0837.dita`

Note:

If the application does not include a Third Party Declaration and Attestation, the following sections must be included:

- Rights and Responsibilities

- Attestation 

### Note

Source topic: `en_EN/common_notes/note_c_0838.dita`

Note:

Generally, the most recent EI application (initial or renewal) is sufficient unless a more complete history of the claim is needed. In such cases, all relevant applications on a claim (initial and renewal) must be included. 

### Note

Source topic: `en_EN/common_notes/note_c_0839.dita`

Note:

The officer must always include the required transcripts and certifications, if necessary. 

### Note

Source topic: `en_EN/common_notes/note_c_0840.dita`

Note:

The officer must also redact any information that is not relevant to the issue being appealed and that should not be shared with the employer. If warranted, the officer can create separate reconsideration files. 

### Note

Source topic: `en_EN/common_notes/note_c_0841.dita`

Note:

The documents relating to the subsequent investigation are the best evidence. The report on hiring printout may be necessary as it is often the only evidence from the employer. 

### Note

Source topic: `en_EN/common_notes/note_c_0842.dita`

Note:

The officer ensures that the Reg56 auto-text is added to the representations whenever the issue under appeal relates to an OP and write-off. 

### Note

Source topic: `en_EN/common_notes/note_c_0843.dita`

Note:

In the following situations, there is an exception for SROCs and RODs related to a write-off:

- Reconsideration under EIA 112: The reconsideration file sent to the client following a negative decision under EIA 112 does not include EIR 56 assessments unless the client has formally requested a write-off.
         [EIR 56](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-56.html)

- Appeal to the SST: The reconsideration file for SST appeals under EIA 113 includes the EIR 56 assessment, regardless of whether or not the client requested a write-off.
         [EIR 56](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-56.html)

     [EIR 56](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-56.html) 
     [EIR 56](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-56.html) 

### Note

Source topic: `en_EN/common_notes/note_c_0844.dita`

Note:

There is an exception. For more information, the officer goes to The issue under appeal relates to a reason for separation (RFS) .
       [The issue under appeal relates to a reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#RFS)

     [The issue under appeal relates to a reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#RFS) 

### Note

Source topic: `en_EN/common_notes/note_c_0845.dita`

Note:

It is rare that the issue under appeal is an OP calculation. The decision that resulted in the OP is more likely the issue under appeal. The officer must always provide an explanation of the OP calculation in the representations and support the explanation with the Notice of Debt (for simple OPs) or the Notice of Debt and the OP breakdown in all other cases. 

### Note

Source topic: `en_EN/common_notes/note_c_0846.dita`

Note:

If an OP was created due to a retroactive RFS decision and the employer is an interested party, the officer must not include a copy of the Notice of Debt or any reference to an OP as this information must not be shared with the employer. 

### Note

Source topic: `en_EN/common_notes/note_c_0847.dita`

Note:

If the client is appealing both the RFS and the OP calculation and the employer is an interested party, the officer must create a separate reconsideration file for each issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0848.dita`

Note:

When an employer or other person is contesting the imposition of a penalty, according to EIA 39 , the reconsideration file includes only documents related to the contested decision. Generally, this does not include applications for benefits from clients.
       [EIA 39](http://www.servicecanada.gc.ca/eng/ei/legislation/ei_act_part1_11.shtml#a39)

     [EIA 39](http://www.servicecanada.gc.ca/eng/ei/legislation/ei_act_part1_11.shtml#a39) 
