# Calculation: Information on calculation and entitlement to benefits — Knowledge

Source map: `en_EN/procedure/generic/knowledge/knowledge.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/knowledge/generic.dita`

**Table of contents**

- Establishing a benefit period (BP)
         [Establishing a benefit period (BP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Establishing_a_benefit_period)

- Normal weekly earnings (NWE) and earnings last week worked (ELWW)
         [Normal weekly earnings (NWE) and earnings last week worked (ELWW)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#NWE)

- Actuals
         [Actuals](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#actuals)

- Interruption of earnings (I of E)

- Administrative interruption of earnings (I of E)
             [Administrative interruption of earnings (I of E)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Administrative_I_of_E)

- Earnings that do not prevent an interruption of earnings (I of E)
             [Earnings that do not prevent an interruption of earnings (I of E)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Earnings_that_do_not_prevent_an_I_of_E)

- Deferred salary leave
             [Deferred salary leave](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Deferred_salary_leave)

- Multiple jobs
             [Multiple jobs](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Multiple_jobs)

- Reduction of hours worked
             [Reduction of hours worked](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Reduction_of_hours)

- Off-work periods
             [Off-work periods](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Off_work_periods)

- Contracts
             [Contracts](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Contracts)

- Business sold
             [Business sold](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Business_sold)

- Bankruptcy
             [Bankruptcy](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Bankruptcy)

- Real estate salesperson
             [Real estate salesperson](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Real_estate_salesperson)

         [Interruption of earnings (I of E)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings)

- BPC

- Administrative Policy
             [Administrative Policy](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Administrative_Rule)

- Postdate Policy
             [Postdate Policy](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#national_policy_postdates)

         [BPC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_period_commencement)

- Qualifying period (QP)

- Extending the qualifying period (QP)
             [Extending the qualifying period (QP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#QP_extension)

         [Qualifying period (QP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

- Economic Region Database
         [Economic Region Database](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#erd)

- Regional rate of unemployment (RRU)

- Divisor
             [Divisor](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#divisor)

- Pilot Project No. 24: Measures to respond to major changes in economic conditions
             [Pilot Project No. 24: Measures to respond to major changes in economic conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#project_24)

         [Regional rate of unemployment (RRU)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#RRU)

- Entrance requirement

- Variable entrance requirement (VER)
             [Variable entrance requirement (VER)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Variable_entrance_requirement)

- Common entrance requirement (CER) (w/c 2310 to w/c 2361)
             [Common entrance requirement (CER) (w/c 2310 to w/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_Common_entrance_requirement)

         [Entrance requirement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Variable_entrance_requirement)

- Major or minor attached client

- Major or minor attached clients — Common entrance requirement (CER) (from w/c 2310 to w/c 2361)
             [Major or minor attached clients — Common entrance requirement (CER) (from w/c 2310 to w/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_Major_or_minor)

         [Major or minor attached client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Major_or_minor_attached_client)

- Qualifying for benefits

- Fishers
             [Fishers](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Fishers)

- Common entrance requirement
             [Common entrance requirement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#qualify_benefit_cer)

- One-time credit of hours
             [One-time credit of hours](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#1-time_credit)

- Qualifying conditions
             [Qualifying conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_conditions)

- BPNE
             [BPNE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_period_not_established)

- Flowchart — Qualifying conditions to establish a BP for regular benefits
             [Flowchart — Qualifying conditions to establish a BP for regular benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_conditions_to_establish_a_BP)

- BPNE claims — Common entrance requirement (CER) (from w/c 2310 to w/c 2361)
             [BPNE claims — Common entrance requirement (CER) (from w/c 2310 to w/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#BPNE_Claims_Common_entrance_req)

         [Qualifying for benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Types_of_qualifiers)

- Increased entrance requirement

- Increased entrance requirement — Common entrance requirement (CER) (from w/c 2310 to w/c 2361)
             [Increased entrance requirement — Common entrance requirement (CER) (from w/c 2310 to w/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_Increased_entrance_requirement)

- Increased entrance requirement
             [Increased entrance requirement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Increased_entrance_requirement_for_a_reg)

- Relief from the increased entrance requirement
             [Relief from the increased entrance requirement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Relief_from_increased_entrance_requireme)

         [Increased entrance requirement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Increased_entrance_requirements)

- Requalifier
         [Requalifier](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Requalifier)

- Calculation of the benefit rate

- Variable best weeks (VBW)
             [Variable best weeks (VBW)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#vbw)

- Family supplement (FS)
             [Family supplement (FS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#FS)

         [Calculation of the benefit rate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#rate)

- Waiting period (WP)

- Waiving the WP
             [Waiving the WP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#waiving)

- Deferring the WP
             [Deferring the WP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#deferring)

         [Waiting period (WP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Waiting_period)

- Client only entitled to special benefits

- Disentitlement 46 - Benefit period not established (BPNE) N5: Regular qualifier
             [Disentitlement 46 - Benefit period not established (BPNE) N5: Regular qualifier](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Disentitlement_46_BPNE_N5_Regular_qualif)

- Disentitlement 46 - Benefit period not established (BPNE) N5: Common entrance requirement (CER) (from w/c 2310 to w/c 2361)
             [Disentitlement 46 - Benefit period not established (BPNE) N5: Common entrance requirement (CER) (from w/c 2310 to w/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_Disentitlement_46)

         [Client only entitled to special benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Client_Only_Entitled_to_Special_Benefi)

- Regular benefits

- Regular qualifying conditions
             [Regular qualifying conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Regular_entitlement_conditions)

- Regular entitlement conditions
             [Regular entitlement conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_Regular_entitlement_conditions)

- Regular weeks of entitlement
             [Regular weeks of entitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Regular_weeks_of_entitlement)

         [Regular benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Regular_Benefits)

- Special benefits
         [Special benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Special_Benefits)

- Maternity benefits

- Maternity qualifying conditions
             [Maternity qualifying conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Maternity_entitlement_conditions)

- Maternity entitlement conditions
             [Maternity entitlement conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_Maternity_entitlement_conditions)

- Proof of pregnancy
             [Proof of pregnancy](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Proof_of_pregnancy)

- Termination of pregnancy
             [Termination of pregnancy](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Termination_of_pregnancy)

- Maternity weeks of entitlement
             [Maternity weeks of entitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Maternity_weeks_of_entitlement)

- Maternity window
             [Maternity window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Maternity_range)

- Extension of the maternity window
             [Extension of the maternity window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Extending_the_maternity_range)

- Applying for maternity benefits
             [Applying for maternity benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Applying_for_maternity_benefits)

- Maternity and sickness benefits
             [Maternity and sickness benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Maternity_and_sickness_benefits)

         [Maternity benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Maternity_Benefits)

- Parental benefits

- Parental qualifying conditions
             [Parental qualifying conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Parental_entitlement_conditions)

- Parental entitlement conditions
             [Parental entitlement conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_Parental_Entitlement_Conditions)

- Adoptive parents
             [Adoptive parents](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Adoptive_parents_New_policy_in_force_on)

- Legally recognized parents
             [Legally recognized parents](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Legally_recognized_parents_and_parental)

- Proof of birth, or adoption or placement
             [Proof of birth, or adoption or placement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Proof_of_birth_or_adoption_placement)

- Placement when the child in client’s care cannot be legally adopted
             [Placement when the child in client’s care cannot be legally adopted](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Placement_when_the_child_in_the_client)

- Type of parental benefits
             [Type of parental benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#ParentalBenefitType)

- Parental benefit rate
             [Parental benefit rate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#ParentalBenefitRate)

- Maximum entitlement
             [Maximum entitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Maximum)

- Sharing parental benefits
             [Sharing parental benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Sharing)

- Parental window (PW)
             [Parental window (PW)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Parental_window)

- Extension of the PW
             [Extension of the PW](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Conditions_to_allow_the_extension_of_the)

- Terminating parental benefits during the PW — Entitlement conditions are no longer met
             [Terminating parental benefits during the PW — Entitlement conditions are no longer met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Terminating_parental_benefits)

- Parental and sickness benefits
             [Parental and sickness benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Parental_and_sickness_benefits)

         [Parental benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Parental_Benefits)

- Sickness benefits

- Sickness qualifying conditions
             [Sickness qualifying conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Sickness_entitlement_conditions)

- Sickness entitlement conditions
             [Sickness entitlement conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_Sickness_Entitlement_Conditions)

- Proof of the client’s medical condition
             [Proof of the client’s medical condition](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Determining_when_medical_proof_is_requir)

- Otherwise available
             [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Otherwise_available)

- Sickness declared on a regular benefits claim
             [Sickness declared on a regular benefits claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Sickness_declared_on_a_regular_benefits)

- Maximum sickness benefits
             [Maximum sickness benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Maximum_sickness_benefits)

         [Sickness benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Sickness_Benefits)

- Compassionate care benefits (CCB)

- CCB qualifying conditions
             [CCB qualifying conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#CCB_entitlement_conditions)

- CCB entitlement conditions
             [CCB entitlement conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_CCB_Qualifying_Conditions)

- Definition of family member
             [Definition of family member](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Definition_of_family_member)

- Definition of care or support
             [Definition of care or support](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Definition_of_care_or_support)

- Proof of patient’s medical condition
             [Proof of patient’s medical condition](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Proof_of_patients_medical_condition)

- Maximum CCB
             [Maximum CCB](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Maximum_CCB)

- Compassionate care window (CCW)
             [Compassionate care window (CCW)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Compassionate_care_window)

         [Compassionate care benefits (CCB)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Compassionate_Care_Benefits)

- Family caregiver benefits

- Family caregiver qualifying conditions
             [Family caregiver qualifying conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_Family_caregiver_qualifying)

- Family caregiver entitlement conditions
             [Family caregiver entitlement conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#_Family_caregiver_entitlement)

- Disentitlements
             [Disentitlements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Disentitlement)

- Maximum family caregiver benefits
             [Maximum family caregiver benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#MaxBenPayable)

- Family caregiver window (FCW)
             [Family caregiver window (FCW)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#FCW)

- Definition of family member
             [Definition of family member](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#fn)

- Definition of care or support
             [Definition of care or support](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#care)

- Proof of patient’s medical condition
             [Proof of patient’s medical condition](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#proof)

- Sharing of benefits
             [Sharing of benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#SharingBen)

- Operational Centre Memo (MM06)
             [Operational Centre Memo (MM06)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#MM06)

- NO-CR-CODE
             [NO-CR-CODE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#NoCrCode)

         [Family caregiver benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#FCB)

- Entitlement weeks paid or payable
         [Entitlement weeks paid or payable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Entitlement_Weeks_Paid_or_Payable)

- Benefit period (BP)

- Extending the BP
             [Extending the BP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#ExtendingBP)

         [Benefit period (BP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_Period)

**Establishing a benefit period (BP)**

To establish a benefit period , a client must have the following in the QP :
       [benefit period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_Period) 
       [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

- an interruption of earnings (I of E)
         [interruption of earnings](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings)

- the required number of insurable hours

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0852.dita) 

To determine whether a client qualifies for benefits, the insurable hours in the QP are compared to the variable entrance requirement (VER).
       [variable entrance requirement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Variable_entrance_requirement)

In order to establish a BP, it is not necessary for the I of E to have occurred during the most recent employment.

**Normal weekly earnings (NWE) andearnings last week worked (ELWW)**

NWE and ELWW are used during the calculation of a claim to determine when the I of E occurred and to determine the BPC and the allocation of monies on separation.
       [I of E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings) 
       [BPC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_period_commencement)

Generally, NWE consists of the most recent gross weekly earnings paid. NWE can also include monies paid on a regular basis such as overtime, commissions, leave pay (e.g. vacation or holiday pay), allowances (e.g. northern or car) and shift premiums.

ELWW are the earnings gained by the client during the last calendar week at that employment.

UIC automatically calculates an average NWE and an average ELWW amount for each ROE. The averaged amounts are indicated in the Employment History File of each ROE and are used during calculation unless the client provides the amounts after filing the application for benefits. If the client provides NWE and ELWW amounts after filing the application, they are accepted at face value unless they do not appear reasonable or if there is clear evidence to the contrary. The amounts provided by the client are compared to the average weekly insurable earnings calculated from the ROE (excluding monies paid on separation) to determine if they appear reasonable (e.g. a difference between the amount provided by the client and the averaged NWE calculated from the ROE of not more than 10% or $75 is considered reasonable). On occasion, amounts provided which appear incorrect can be considered acceptable based on the client’s situation or the local labour market circumstances (e.g. the client recently had a promotion which increased the normal earnings). When the amounts provided appear reasonable, the officer overrides the averaged amounts by entering the amounts provided in RCM.

For more information, refer to Digest 5.6.3 — Normal weekly earnings from that employment .
       [Digest 5.6.3 — Normal weekly earnings from that employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/allocations-of-earnings.html#5_6_3)

**Actuals**

Actuals are proof, other than information on an ROE, of actual earnings or hours worked in insurable employment, regardless of variable best weeks (VBW) details. Generally, actuals are submitted by the client in the form of pay stubs, but proof of actuals can be anything clients use as a personal record to keep track of their work history. Employers can also submit actuals in the form of payroll histories. Actuals are usually provided by pay period.
       [variable best weeks (VBW)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#vbw)

The officer requests and uses actuals only in exceptional circumstances. When clients or employers provide actuals that are not required, the officer returns them and does not use them. The officer must not ask for actuals unless they are required. When actuals are requested, the officer documents the reason for the request on the file.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0853.dita) 

Actuals are requested when:

- there is an extension of the QP beyond the period covered by the ROE;

- the client is BPNE and actuals allow the client to qualify (i.e. the first day worked [FDW] on an ROE is before the cut-off date and the client is BPNE with only the hours indicated on the ROE);

- the client is subject to an indefinite disqualification and may be a requalifier (i.e. the date of the disqualifying event is between the FDW and the last day paid [LDP] of another ROE).
         [requalifier](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Requalifier)

When actuals are required and received, the officer inputs them in the employment history file and uses them during calculation of the claim. When actuals are used during calculation of the claim, UIC calculates the insurable hours and earnings in the QP using proportional averaging of the remaining hours and earnings on the ROE.

**Interruption of earnings (I of E)**

An I of E occurs:

- when the client is laid off or separated from insurable employment and has a period of 7 or more consecutive days without work and earnings from that employment;
         [earnings](http://www.servicecanada.gc.ca/eng/ei/digest/chp5.shtml)

- on the Sunday of the week in which income falls below 60% of the client’s average normal weekly earnings (NWE) and the separation is due to sickness, maternity, parental, compassionate care or family caregiver leave.
         [normal weekly earnings](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#NWE)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0854.dita) 

**Administrative interruption of earnings (I of E)**

- The 7-day requirement for a regular I of E is deemed to be fulfilled when an ROE is issued because the employer is reasonably sure that there will be 7 consecutive days without work or earnings.
         [I of E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings)

- If the ROE was properly issued, even if the layoff is shorter than 7 consecutive days, the I of E is still deemed to have occurred.

**Earnings that do not prevent an interruption of earnings (I of E)**

All monies that are considered earnings for benefit purposes prevent an I of E, except the following:

- separation monies allocated according to EIR 36(9)
         [EIR 36(9)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html)

- preventive withdrawal payments

- workers’ compensation benefits (WCB)

- group wage loss insurance (WLI)

- pensions

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0855.dita) 

For more information on an I of E, refer to Digest 2 — Interruption of earnings .
       [Digest 2 — Interruption of earnings](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-2/table-of-contents.html)

**Deferred salary leave**

In the case of a deferred salary or self-funded leave, an I of E does not occur until the end of the period of leave unless either the employee or the employer breaks the contract earlier. As a result, the employee is considered not unemployed while the contract continues.

**Multiple jobs**

For an I of E to occur, there must be 7 consecutive days without work or earnings from one insurable employment. This means that even if the client continues working in another insurable employment, after 7 consecutive days with no work or earnings from one employer, an I of E has occurred.

**Reduction of hours worked**

A reduction of hours does not cause an I of E. For example, if the client’s hours are reduced from full time to part-time, there is no I of E unless there was a period of 7 consecutive days without work or earnings with the employer.

**Off-work periods**

When an employee works a greater number of hours or shifts than normal and then has one or more weeks off, an I of E does not occur in the off-work period. For example, if the client’s normal shift is 14 days of work followed by 10 days off, the I of E does not occur until the 11th day off.

**Contracts**

If paid by contract for a period of time, regardless of the work performed in that period, there is no I of E until the end of the contracted period. For example, a client signed a 3-month contract with the employer but completes the work in 2 months, there is no I of E until the end of the third month.

**Business sold**

When an employee ceases to be employed because the business is being sold, an I of E occurs even if the employee’s services are retained by the new owner without a period of 7 consecutive days without work or earnings.

**Bankruptcy**

In cases where an employer declares bankruptcy, an I of E occurs when the receiver takes over the operation of the business. If an employee continues to work for an employer who declares bankruptcy, the I of E does not occur until the employee stops work, even if no wages are paid.

**Real estate salesperson**

An I of E for regular benefits occurs only when the real estate license of a real estate salesperson is surrendered, suspended or revoked. In Ontario, the license is issued by a registrar and is only valid for the employer named on the license. When the employer/employee relationship is terminated, the license becomes invalid.

An I of E for special benefits occurs when a real estate salesperson is out of work due to sickness, maternity, parental or compassionate care leave. The real estate salesperson’s license can still be maintained.

**BPC**

The BPC is the effective or start date of a claim.

A benefit period (BP) generally starts the later of the following dates (EIA 10 ):
       [benefit period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_Period) 
       [(EIA 10](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-2.html#h-215911)

- the Sunday of the week in which the I of E occurs
         [I of E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings)

- the Sunday of the week in which the client applied

However, if a client has insurable employment during that week and the hours are required to establish the BP, the BPC is postdated to the following Sunday. On rare occasions, the officer can postdate the BPC by more than one week but not beyond the current variable entrance requirement (VER) range.
       [variable entrance requirement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Variable_entrance_requirement)

When it is to the client’s advantage, the BPC can be backdated by the number of weeks equivalent to the waiting period (WP) if the client received group WLI or WCB in those weeks. The BPC cannot be backdated beyond the I of E.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0856.dita) 

**Administrative Policy**

When a client applies for benefits, the BPC is determined according to EIA 10.
       [BPC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_period_commencement) 
       [EIA](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-14.html)

Under the Administrative Policy, when a client submits an application in a timely manner, the officer establishes the BP in one of the following weeks, whichever is to the client’s advantage:

- the week in which the I of E occurs;

- the week in which the LDP falls;

- the last week for which WLI, WCB, preventive withdrawal payments or QPIP benefits are paid.

However, if a later BPC would be more advantageous to the client, the officer refers to the Postdate Policy to determine if the BPC should be postdated. The Administrative Policy and the Postdate Policy are 2 distinct policies that the officer applies separately in a step-by-step process.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0857.dita) 

According to the Administrative Policy, the application was submitted in a timely manner because the client applied within 4 calendar weeks of the I of E. The officer can establish the BPC in w/c 2275.

However, in this scenario, it is advantageous to the client to postdate the claim because of earnings in the last week worked. Under the Postdates Policy, the officer postdates the BPC to w/c 2276.

For an application to be considered submitted in a timely manner, the Administrative Policy allows the client up to 4 calendar weeks to apply after the week in which one of the following occurs:

- the week in which the I of E occurs;

- the week in which the LDP falls;

- for fishers, the trip end date (fresh catch) or date of purchase (cured catch);

- the last week for which WLI, WCB, preventive withdrawal payments or QPIP benefits are paid.

If a client does not apply for benefits in a timely manner, the BPC is the Sunday of the week in which the client applies.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0858.dita) 

The Administrative Policy also applies to subsequent claims. A client may re-apply for benefits once the current claim has been exhausted. This new claim is referred to as a subsequent claim. A subsequent claim may be established starting the week following the week in which the prior claim terminated, if the EI application is made within one of the following timeframes:

- 5 weeks from the week in which the last claimant’s reports were issued;

- 4 weeks from the week in which the final claimant’s report is processed in FTS.

If the client does not file the subsequent application within the above timeframes, the subsequent claim is established in accordance with the general guidelines on determining the BPC.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0859.dita) 

If a client does not apply for benefits in a timely manner, the BPC is the Sunday of the week in which the client applies.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0860.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0861.dita) 

**Postdate Policy**

A claim is considered to have been postdated when the BP is established at a date later than EIA 10(1) or the Administrative Policy would allow.

A BPC can be postdated up to 4 weeks, but cannot be postdated beyond the current VER range. A claim cannot be postdated solely for a client to benefit from new legislation, unless otherwise authorized and communicated by EI Operational Policy.

An initial or renewal claim can only be postdated in the following situations that may be advantageous to the client:

- The client needs the hours of insurable employment from the last week worked to qualify for benefits.

- The I of E week or the application week is a full work week (FWW).

- Because of earnings in the week of the I of E, the client would have received only a partial first payment and has requested that the claim be postdated by one week.

- Separation monies or earnings, or a combination of both in the I of E week or the application week are equal to or greater than the benefit rate.

- The client submitted a claim for maternity or parental benefits before the benefit window.

- The client requests special benefits and can receive the maximum entitlement, but earnings during the first week prevent payment of the full benefit rate.

- The client is a teacher and applies for maternity and parental benefits during the non-teaching period. The client may be entitled to a contractual payment from the employer in addition to a supplemental unemployment benefits (SUB) top-up for maternity and parental benefits. These monies are earnings and prevent payment of EI benefits for those weeks, as they do not meet the criteria for SUB. A postdate could be to the client’s advantage, but the officer must pay attention to both the maternity and parental windows to ensure maximum entitlement remains available.

If a client has worked since the date of the initial application and needs those hours to qualify for benefits, the officer can use the additional hours to establish the BP and the client does not have to submit a second application. The BPC is based on the most recent I of E, and the client must provide the ROE and any other relevant employment information. If an initial decision has already been made, the client must reapply.

A claim for sickness benefits is postdated only when the medical certificate indicates a specific recovery date that will allow the client to receive the full entitlement to those benefits at the full weekly rate.

When the recovery week entered is 99-99-9999 (based on a medical certificate that indicates terminal or palliative), SSO automatically postdates the claim by one week if there are earnings in week 1. The BPC of a claim with an indefinite recovery week (based on a medical certificate that indicates terminal or palliative) must not be postdated due to earnings in week 1, unless the client has specifically requested to postdate the claim.

A claim for special benefits (other than sickness benefits) is postdated only when there is clear evidence (e.g. the RTW date) indicating that doing so will allow the client to be paid or payable the maximum rate of benefits for the number of weeks requested or allowable. When information on the file (e.g. the RTW date, the end of a special benefits window or the date of the patient’s death) indicates postdating the claim would not be advantageous to the client, the officer does not postdate the claim.

**Qualifying period (QP)**

The initial QP is defined as the shorter of:

- the 52 weeks immediately preceding the BPC ;
         [BPC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_period_commencement)

- the period beginning the week of a previous BPC and ending the week before the BPC of a new claim.

In some cases, if a client was prevented from working during the QP, the QP may be extended by a maximum of 52 weeks (for a maximum QP length of 104 weeks). The QP cannot be extended beyond the BPC week of a previous claim.

The first week of the QP is referred to as the cut-off date (COD).

The insurable hours that fall within the QP are considered when determining if a client has enough hours to establish a benefit period (BP) and the number of weeks of entitlement. The highest weeks of earnings that fall in the QP are used to determine the benefit rate.
       [benefit period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_Period)

**Extending the qualifying period (QP)**

Conditions for a QP extension

The QP may be extended by one week for each week in the QP where the client proves both of the following conditions are met:
       [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

- The client did not receive EI or QPIP benefits.
         [QPIP](http://www.rqap.gouv.qc.ca/Index_en.asp)

- Throughout the week, the client was not employed in insurable employment due to at least one of the following reasons, even if the reason is not applicable for the entire calendar week:

- illness, injury, quarantine or pregnancy

- receiving assistance under employment benefits (attending referred training or other referred employment activity

- receiving preventive withdrawal payments under a provincial law

- confined in a jail, penitentiary or other similar institution and the client was not found guilty of any of the charges leading to the incarceration.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0862.dita) 

Periods not considered for a QP extension

Weeks in which the following situations occur are considered as weeks of benefits paid or weeks with insurable employment and are not considered for a QP extension:

- At least $1 of EI benefits was paid to the client.

- The client served a definite disqualification.

- Benefits were used to reimburse an overpayment (OP) or a penalty under EIA 38.

- Benefits were withheld for an assignment of benefits (AOB).

- Benefits were withheld pursuant to a family order agreement (FOA).

- The client received provincial benefits for a birth or adoption, such as QPIP benefits.

- The client received insurable employer-paid leave.

For the purposes of extending the QP, insurable employer-paid leave such as WLI, is considered to be insurable employment. Therefore, any weeks during which the client is receiving insurable paid leave, are not used to extend the QP, even if the client was unable to work for medical reasons during that period.

However, weeks during which the client is receiving employer-paid leave that is not insurable are considered for a QP extension.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0863.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0864.dita) 

Unless there is doubt or the extension is for incarceration, the client’s statement on the application is accepted as proof to extend the QP.

An extension of the QP alters the COD.

When a client is incarcerated on or after June 30, 2013, the following proof is required to extend the QP:

- a letter from the institution where the client was incarcerated, to prove the dates of incarceration;

- a letter from the lawyer or the provincial, territorial or federal court, which proves the client was not found guilty;
         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0865.dita)

- a letter or any other type of documentation confirming that there are no other outstanding charges for which the time served is being credited
         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0866.dita)

**Economic Region Database**

The Economic Region database links a client’s postal code to an economic region. The database is regularly updated to reflect changes to postal codes and economic regions.

Canada is divided into a number of economic regions, as listed in the EIR. The economic region used to calculate a claim is the region where the client ordinarily lives during the week of the BPC. When a claim is recalculated, the economic region used is the same as on the initial claim.

When a client’s postal code overlaps 2 economic regions, the client is considered part of the economic region with the highest RRU, which is always in the client’s favour.

The calculation result may generate an error when the system cannot process a change to the Economic Region Database or when the database is unavailable.

**Regional rate of unemployment (RRU)**

For most clients, the RRU is used to determine if the client qualifies for benefits. The RRU is also used to determine the regional divisor . Statistics Canada determines the monthly rate of unemployment for each region, incorporating seasonal adjustment and an estimate of unemployment rates for status Indians living on reserves. The RRU applicable to a client is the average of the rates for the 3 months preceding the BPC week. The current and historical regional rates can be found on the EI Economic Regions page.
       [divisor](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#divisor) 
       [BPC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_period_commencement) 
       [EI Economic Regions](http://srv129.services.gc.ca/eiregions/eng/geocont.aspx)

Due to Covid-19 and the historically high number of Canadians in financial need, a temporary measure is being implemented to reduce the number of hours required to qualify for benefits. On claims with a BPC between w/c 2251 and w/c 2309, the RRU for all 62 economic regions was temporarily set to 13.1%, unless the reported RRU for that region was higher.

The RRU affects the VER, the entitlement weeks and the divisor.

**Pilot Project No. 24: Measures to respond to major changes in economic conditions**

From April 6, 2025, to October 11, 2025, to improve access to benefits, a temporary measure will adjust the unemployment rate for regions with rates under 13.1%. For all initial claims with a BPC between April 6, 2025 (w/c 2494) and October 5, 2025 (w/c 2520), the RRU will be set as follows:

- For regions where the RRU is 6.1% or less, the minimum RRU ( EIR 17 ) is set to 7.1%.
         [EIR 17](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-17.html#h-33)

- For regions where the RRU is 6.2% to 12%, 1% will be added to the set RRU.

- For regions where the RRU is 12.1% to 13%, the RRU is set to 13.1%.

- For regions where the RRU is 13.1% or greater, there is no change to the RRU.

By adjusting the RRU in areas where the RRU is less than 6% and no more than 13%, clients may be entitled to more weeks of regular benefits. The RRU also determines the divisor used when calculating the benefit rate. By adjusting the RRU a client may benefit from a higher benefit rate, since the divisor decreases as the RRU increases.

**Divisor**

The RRU determines the divisor to use when calculating the benefit rate.
       [RRU](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#RRU) 
       [divisor](/en/procedure/generic/additionalresources/divisor_table_regular.shtml)

**Entrance Requirements**

The number of hours of insurable employment required to qualify depends on which entrance requirement was in place at the time of the BPC.

**Variable entrance requirements (VER)**

The VER is the number of insurable hours in the QP that a regular qualifier who is not subject to increased entrance requirements must have in order to establish a BP. The exact number is called the VER and is found in the table of required hours of insurable employment .
       [regular qualifier](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Regular_Benefits) 
       [table of required hours of insurable employment](/en/procedure/generic/additionalresources/ver_reg_ben.shtml)

Depending on the RRU in effect the week of the BPC, this amount is between 420 and 700 hours of insurable employment in the QP .
       [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

**Common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national common entrance requirement (CER) of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, increased entrance requirements may apply. The common entrance requirement applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the entrance requirement is not based on the regional rate of unemployment (RRU). However, the RRU continues to be used to determine the divisor and the entitlement weeks based on the hours of insurable employment in the qualifying period (QP). During this period, a claim with less than 420 hours is finalized as BPNE N1. If there is a violation on file and the client does not meet the increased entrance requirements, the claim is finalized as BPNE N5.
       [increased entrance requirements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Increased_entrance_requirements)

**Majororminorattached client**

All insurable hours included in the QP , including hours from any excluded employment, are used to determine if the client is attached to the labour force in a major or minor way.
       [QP](/en/procedure/generic/knowledge.shtml#Qualifying_period)

A major attached client is a client who has 600 or more insurable hours in the QP.

When a client has 600 or more insurable hours in the QP, but some of those insurable hours were excluded from the calculation, the excluded hours are not included in the Insured hours in qualifying period field on the Rate/Duration tab in FTS. In this situation, the Major Attached box is checked on the Rate/Duration tab to identify the client as major attached.

A minor attached client is one who has less than 600 hours of insurable employment in the QP but has accumulated enough hours to establish a claim for regular benefits.

The system codes claims with a BPC from September 27, 2020, to September 19, 2021, that received a credit of 300 insurable hours as major attached. This means that clients transitioning from the EI ERB who have fewer than 600 hours may also qualify for special benefits.

**Major or minor attached clients— Common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure.

**Qualifying for benefits**

In order to determine if a client qualifies for benefits, it is necessary to determine the number of insurable hours in the QP .
       [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

In general, clients with 700 or more insurable hours in the QP can qualify for all EI (BTs): regular , sickness , maternity , parental , compassionate care and family caregiver .
       [regular](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Regular_Benefits) 
       [sickness](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Sickness_Benefits) 
       [maternity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Maternity_Benefits) 
       [parental](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Parental_Benefits) 
       [compassionate care](/en/procedure/generic/knowledge.shtml#Compassionate_Care_Benefits) 
       [family caregiver](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#FCB)

Clients with fewer than 420 insurable hours in the QP do not qualify for benefits.

**Fishers**

The qualifying conditions are different for fishers. For more information, refer to Digest 15 .
       [Digest 15](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-15/table-of-contents.html)

**Common entrance requirement**

As part of Budget 2021, the Government of Canada announced that a national common entrance requirement (CER) of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, increased entrance requirements may apply. The common entrance requirement applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the entrance requirement is not based on the regional rate of unemployment (RRU). However, the RRU continues to be used to determine the divisor and the entitlement weeks based on the hours of insurable employment in the QP.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

**One-time credit of hours**

To support clients when the EI ERB ends, clients whose BPC is between September 27, 2020, and September 25, 2021, will receive a one-time credit of insurable hours.

Clients requesting special benefits will receive a credit of 480 hours. Clients requesting regular benefits will receive a credit of 300 hours and are coded as major attached by the system, even if they have fewer than 600 hours.

UIC generates one of the following messages on claims receiving the hours credit:

- Warning message 1157 - credit 300 insurable hours

- Warning message 1158 - credit 480 insurable hours

In SSO, the warning appears on the Calculation Result screen in the Message section.

**Qualifying conditions**

To establish a BP, a client who is not subject to increased entrance requirements must have between 420 and 700 hours of insurable employment in the QP. The exact number of hours required to qualify is dependent on the variable entrance requirement (VER) in the client’s economic region in effect for the BPC week. When the client resides so close to the boundary of an economic region that it is unclear which of the regional rate of unemployment (RRUs) applies, the highest RRU is used.
       [BPC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_period_commencement)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0867.dita) 

**BPNE**

When a client does not meet the entrance requirements, a benefit period cannot be established and the claim is BPNE.
       [benefit period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_Period)

There are 3 reasons for BPNE claims:

- There are insufficient hours of insurable employment (N1, N5, N7).

- No I of E has occurred (N8).
         [I of E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings)

- The last ROE is missing (N2).

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0868.dita) 

**Flowchart — Qualifying conditions to establish a BP for regular benefits**

**BPNE claims — Common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national common entrance requirement (CER) of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, increased entrance requirements may apply. The common entrance requirement applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, a claim with less than 420 hours is finalized as BPNE N1. If there is a violation on file and the client does not meet the increased entrance requirements, the claim is finalized as BPNE N5.

**Increased entrance requirement**

Violations apply to cases involving fraud. If it is determined that the client, or a person acting on behalf of the client, knowingly made a false or misleading statement that resulted in an OP, a violation may be imposed on the affected claim.

A client with one or more violations in the 260 weeks (5 years) preceding the initial application for benefits is subject to increased entrance requirements to qualify for benefits.

The total value, actual or potential, of the OP determines the classification of the violation as follows:

```text
| Overpayment (OP) amount | Classification of the violation |

| Less than $1 000 | Minor |

| Between $1 000 and $4 999 | Serious |

| $5 000 or more | Very serious |

| Second or additional violation | Subsequent |
```

Entrance requirements are increased by a set percentage, depending on the classification of the violation, as follows:

- minor: 25%

- serious: 50%

- very serious: 75%

- subsequent: 100%

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0869.dita) 

**Increased entrance requirement — Common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). Based on the common entrance requirement, a client needs 420 hours of insurable employment in the qualifying period (QP) to qualify for regular and special benefits, unless there is a violation on file.

When a violation is on file, the increased entrance requirements for regular and special benefits are as follows, regardless of the regional rate of unemployment (RRU):

1 - Minor violation = 525 hours

2 - Serious violation = 630 hours

3 - Very serious violation = 735 hours

4 - Subsequent violation = 840 hours

**Increased entrance requirements**

There are 4 factors to consider when determining the increased entrance requirements for a claim:

- the classification of the violation

- the 260 weeks before the BPC
         [BPC](/en/procedure/generic/knowledge.shtml#Benefit_period_commencement)

- the variable entrance requirement (VER)
         [variable entrance requirement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Variable_entrance_requirement)

- prior offences

**Relief from the increased entrance requirements**

To meet relief from the increased entrance requirements, one of the following conditions must be met:

- The notice of violation was issued more than 260 weeks before the date of the initial application.

- 2 initial claims have been established since the date the notice of violation was issued.

EI ERB claims are not considered established EI claims that allow the client to gain relief from increased entrance requirements.

Once a violation is classified as “subsequent,” it remains a subsequent violation for 260 weeks (5 years) from the date it is established, or until 2 subsequent claims are established, whichever occurs first.

Once a violation has been classified as “subsequent,” its classification does not change unless the violation leading to its classification is rescinded or cancelled after reconsideration of the decision. If the previous violation is cancelled upon reconsideration, the subsequent violation is reclassified and becomes a first violation.

**Requalifier**

When a client voluntarily leaves without just cause or is dismissed due to misconduct, the insurable hours from the employment are excluded and the client must work enough insurable hours after the disqualifying event to qualify.

If the client has not worked enough insurable hours to qualify after the disqualifying event, the claim is established using all the insurable hours in the QP and a disqualification ( 10 - Dismissal - misconduct proven [D10] or 11 - Voluntary leaving - just cause not shown [D11]) is imposed.

A client who has accumulated enough insurable hours since the most recent disqualifying event to establish a benefit period (BP) is considered a requalifier and no disqualification is imposed.
       [benefit period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_Period)

Once it is determined that the client is a requalifier, the system excludes the ROEs with the voluntary leave without just cause or the dismissal due to misconduct when calculating the insurable hours in the QP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0870.dita) 

**Calculation of the benefit rate**

The benefit rate for regular and special claims is determined using all insurable earnings from all ROEs in the QP . This includes insurable fishing earnings but excludes earnings from employment that the client voluntarily left without just cause or from which the client was dismissed due to misconduct.
       [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

When the client has not accumulated sufficient insurable hours since a disqualifying event to requalify, all ROEs in the QP are used to determine the benefit rate. To determine the benefit rate, the officer also uses ROEs from employment that the client voluntarily left without just cause or from which the client was dismissed due to misconduct.

The officer uses the variable best weeks (VBW) method to determine the average weekly insurable earnings. If the average weekly insurable earnings exceed the maximum weekly insurable earnings , the rate is obtained by multiplying the maximum weekly insurable earnings by 55% for the base rate or by 33% for the reduced rate. If the average weekly insurable earnings do not exceed the maximum weekly insurable earnings, the rate is obtained by multiplying the average weekly insurable earnings by 55% for the base rate or by 33% for the reduced rate.
       [variable best weeks (VBW)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#vbw) 
       [maximum weekly insurable earnings](/en/procedure/generic/additionalresources/max_ben_rate_mwie.shtml#_Table_of_MIE)

The family supplement (FS) can increase the benefit rate. However, the benefit rate cannot exceed the maximum benefit rate .
       [family supplement](/en/procedure/activity/family_supplement.shtml) 
       [maximum benefit rate](/en/procedure/generic/additionalresources/max_ben_rate_mwie.shtml)

A minimum benefit rate applies to all claims in the following periods:

- For claims with a BPC between w/c 2258 and w/c 2309, the minimum benefit rate is $300 for extended parental benefits and $500 for all other BTs. If the client is entitled to the FS, this amount is added to the minimum benefit rate.

- For claims with a BPC between w/c 2310 and w/c 2317, the minimum benefit rate is $180 for extended parental benefits and $300 for all other BTs. If the client is entitled to the FS, this amount is added to the minimum benefit rate.

**Variable best weeks (VBW)**

Based on the earnings included in the calculation of the benefit rate, the VBW method uses the earnings from the weeks with the highest earnings in the QP to calculate the average weekly insurable earnings. For clients who experience sporadic work patterns, this can result in a higher benefit rate that is more responsive to regional economic conditions. The number of weeks used ranges from 14 to 22 and is based on the regional divisor . If there are fewer weeks with earnings than the divisor, all of the weeks are included. The total of the earnings in the weeks that are included is divided by the divisor to obtain the average weekly insurable earnings.
       [divisor](/en/procedure/generic/additionalresources/divisor_table_regular.shtml)

When a client has fishing earnings in the QP, the officer considers only weeks of regular earnings to determine the VBW. Once the weeks of regular earnings have been identified, any fishing earnings that fall in the QP are added to the total of the VBW.

When the client does not provide any VBW or fewer weeks than the divisor, the average weekly insurable earnings are calculated using proportional averaging of the ROEs, or proportional averaging and the VBW information provided by the client. UIC reads the employment history file to determine the VBW of earnings in the QP. UIC may determine different VBW than those provided by the client if there are higher weeks of insurable earnings present. The total of the VBW as determined by UIC is the total insured earnings used to establish the benefit rate.

**Impact of insurable earnings on VBW**

```text
| Type of insurable earnings | Impact of earnings on VBW |

| Vacation pay or shift premiums | The VBW calculation includes the accumulated earnings from all insurable employment in a calendar week including the percentage of vacation pay paid in each pay period and corresponding to that calendar week. This also includes shift premiums. When vacation time is taken, however paid, it is allocated to the pay period for which it is paid. If the weeks fall in the QP, they can be used to determine the VBW. |

| Monies allocated to the pay period in which they are paid | Monies that are allocated to the pay period in which they are paid (such as bonuses, controlled tips or vacation pay where no time is taken) can be used to determine the VBW if the weeks fall within the QP. |

| Insured separation monies | When determining the amount of earnings in a calendar week for the purposes of determining the VBW, the officer does not consider insurable separation monies. The amount of insurable separation monies top-up to be included in the total insurable earnings in the calculation period is the lesser of: - the actual amount of insurable separation monies paid; - 18% of the total earnings of the VBW being used in the calculation of the benefit rate from the employment giving rise to the insurable separation monies. |

| Commissions | When the client is paid solely commissions, or salary and irregularly paid commissions, the insurable earnings are allocated proportionately over the period of employment or the last 52 weeks, whichever is shorter. Clients paid in this manner are an exception to the proportional allocation by pay period rule and while the VBW calculation applies, they will not be able to benefit fully as the earnings for this employment will be the same each week. |
```

**Family supplement (FS)**

The FS provides clients from eligible low-income families with an additional amount that can increase their benefit rate.

The FS can increase a client’s benefit rate payable to as much as 80% of the insurable earnings. As the client’s net family income level rises, the amount of FS payable decreases. When the maximum net family income of $25 921 is reached, no supplement is payable. Including the FS, the client’s benefit rate cannot exceed the maximum benefit rate .
       [maximum benefit rate](/en/procedure/generic/additionalresources/max_ben_rate_mwie.shtml)

A client is entitled to the FS if all of the following conditions are met:

- The client or the client’s spouse is receiving the Canada child benefit for the month before the client files an application for benefits.
         [Canada child benefit](http://www.cra-arc.gc.ca/bnfts/ccb/menu-eng.html)

- The net family income in the base tax year does not exceed $25 921.

- The spouse is not already receiving the FS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0109.dita) 

Entitlement to the FS is based on the receipt of the Canada child benefit and not on the entitlement to the Canada child benefit. Therefore, if for any reason the Canada Revenue Agency (CRA) stops paying the Canada child benefit, the client’s benefit rate reverts to the basic rate without the FS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0111.dita) 

Even though both spouses are entitled to receive the FS, it is paid to only one spouse at a time. If both spouses apply for EI benefits on the same day, the FS automatically goes onto the first claim established. Spouses can choose who of the 2 will receive the FS by requesting a transfer. The client receiving the FS must make this request.

**Waiting period (WP)**

The WP is a 1-week period for which no benefits are paid to the client. This is like the deductible in other insurance policies where the insured person is expected to share a part of the damages or loss. The WP is served in the first calendar week in which, had it not been for the WP, benefits would have been payable to the client.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0871.dita) 

When determining if benefits would have been payable to the client, factors such as not-available days, disentitlements, hours worked and earnings (both allocated and declared) must be considered.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0872.dita) 

Any allocated monies that are considered earnings during the WP are deducted from the first weeks that benefits are payable. The same principle applies to days of disentitlement, which are converted to earnings for this purpose. For more information, refer to Earnings and disentitlements during the waiting period .
       [Earnings and disentitlements during the waiting period](/en/procedure/generic/additionalresources/earnings_disentitlements_wp.shtml)

In some situations, the WP may also be waived or deferred.

**Waiving the waiting period (WP)**

A WP may be waived if it is to the client’s advantage. The WP can be waived when the following conditions are met:

- A BP has been established based on an I of E due to illness, injury, quarantine, pregnancy, the need to care for a newly born or adopted child, or the need to provide care or support to a critically ill family member.
         [I of E](/en/procedure/generic/knowledge.shtml#Interruption_of_earnings)

- After the last day worked, the client received QPIP benefits or paid sick leave (PSL) from the same employer where the I of E occurred.

**Pilot project no. 24: Waiving the waiting period (WP) for BPCs between March 30 and October 10, 2026 (w/c 2493 to w/c 2572)**

A temporary measure to waive the one-week WP has been implemented to support clients impacted by major changes in economic conditions due to the imposition of tariffs by the United States. The WP is waived for all initial claims with a BPC between March 30, 2025 (w/c 2493) and October 10, 2026 (w/c 2572), regardless of the requested BT. If it is advantageous to the client, the client can decide to serve the WP (e.g. the client must serve the WP to receive SUB).

The WP waiver is automatically applied to all claims except claims for special benefits in which there is a SUB code. The officer must verify and enter the appropriate SUB code if the client is receiving SUB. When recalculating a claim and the only change is adding or removing a SUB plan from the ROE, the calculation result will indicate NCA - No changes to the claim . In this situation, the officer manually enters or removes the WP waiver.

A client who applies, qualifies for and is payable benefits before March 30, 2025 (w/c 2493) cannot request to postdate the start date of their claim solely to benefit from this temporary measure.

A client may request to have their claim start in the week they applied for benefits when both of the following conditions are met:

- The client applied for benefits on or after March 30, 2025 (w/c 2493).

- The Administrative Policy was applied and resulted in a BPC before March 30, 2025 (w/c 2493).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0873.dita) 

**Deferring the waiting period (WP)**

A WP can be deferred when more than one client is claiming the following special benefits for the same child or critically ill family member:

- Parental benefits

- CCB

- Family caregiver benefits

One WP must be served between clients, which usually occurs on the first claim established (by a parent, adoptive parent or family member). The WP would then be deferred for the second client sharing the benefits. However, once entitlement to these benefits ends, if the client requests a different benefit type, the WP must then be served.

Before deferring the WP, the officer confirms that the conditions to defer are met. The officer must review the other parent or family member’s file to validate that the client meets the conditions for a WP deferral. This validation is authorized under privacy regulations because the file is reviewed for the purpose of administering the EI program.

For parental benefits, if information on the other parent was not provided on the EI application, the officer conducts fact-finding to obtain it. If information on the other parent cannot be obtained, the reason must be documented on an SROC.

For subsequent claims, the WP can only be deferred when the following conditions are met:

- The client is applying for parental benefits.

- The client has already served a WP for the same birth, adoption or placement.

This situation happens when the same client establishes a claim subsequent to the one on which the WP was served for the above-mentioned reasons in order to collect the balance of benefits payable for that BT.

The officer reviews the client’s claim and the other parent or family member’s file to determine if the client meets the conditions for a WP deferral. Additionally, the officer determines whether deferring the WP is advantageous to the client (e.g. the client has a SUB plan or is entitled to have the WP waived).

If the client requests a different BT after the entitlement to these special benefits ends, the WP must then be served.

Similarly, the WP or its unserved portion may be deferred on a WS claim, but if other benefits are claimed once the WS agreement has ended, the WP or its unserved portion must then be served.

If the WP is waived for the first client claiming parental benefits, CCB or family caregiver benefits, the second client cannot defer the WP because it was not previously served for the same child or ill family member. The second client may however meet the conditions to waive the WP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0653.dita) 

**Client only entitled to special benefits**

If a major attached client with no violation applies for regular benefits and the claim is BPNE, the client cannot convert the claim to special benefits (e.g. sickness). The client must instead apply for a new claim. This means that the earliest date for the new BPC is the date when the client would have been entitled to special benefits. The QP now ends the week prior to this new BPC instead of on the original QP end date of the BPNE claim. Based on this new QP, it must be determined whether the client is still major attached (has at least 600 insurable hours in the QP) and therefore entitled to special benefits. If the client remains BPNE but qualifies for special benefits, an administrative disentitlement is imposed to prevent the payment of regular benefits.
       [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client) 
       [special benefits](/en/procedure/generic/knowledge.shtml#Special_Benefits) 
       [QP](/en/procedure/generic/knowledge.shtml#Qualifying_period)

Disentitlement 46 - Benefit period not established (BPNE) N5

The officer imposes an administrative 46 - Variable entrance requirement not met - special benefits payable disentitlement (D46) to prevent payment of regular EI benefits to an N5 client who applies for special benefits with at least 600 insurable hours in the QP.

Although an N5 client may subsequently work sufficient additional hours of insurable employment to meet the provisions of EIR 93(5)(a) , regular benefits are not payable because there is no entitlement.
       [EIR 93(5)(a)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-93.html)

**Disentitlement 46 - Benefit period not established (BPNE) N5: Common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

A temporary Budget 2021 measure applies to claims for regular and special benefits, with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits, and no D46 is input.

**Regular benefits**

EI regular benefits provide temporary financial assistance to workers who are involuntarily unemployed.

**Regular qualifying conditions**

To qualify for regular benefits, a client must:

- have applied for benefits;

- have had an I of E in the QP ;
         [I of E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings) 
         [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

- have the required number of insured hours in the QP to establish a benefit period (BP). If the client has a violation on file, increased entrance requirements may apply.
         [required number of insured hours](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Major_or_minor_attached_client) 
         [benefit period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_Period) 
         [increased entrance requirements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Increased_entrance_requirements)

**Regular entitlement conditions**

To be entitled to regular benefits, a client must:

- be ready, willing and capable of working;

- be in Canada (exceptions are listed in EIR 55 ).
         [EIR 55](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

**Regular weeks of entitlement**

The number of weeks of regular benefits payable (entitlement) is determined by the following:

- the number of insured hours in the QP

- the regional rate of unemployment (RRU) for the area where the client resides at the time of the BPC .
         [regional rate of unemployment](/en/procedure/generic/knowledge.shtml#RRU) 
         [BPC](/en/procedure/generic/knowledge.shtml#Benefit_period_commencement)

For more information about the maximum benefit entitlement in a BP, the officer can refer to Maximum entitlement to benefits .
       [Maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

Weeks of entitlement must be collected within the benefit period (BP).
       [benefit period](/en/procedure/generic/knowledge.shtml#Benefit_Period)

Once the number of entitlement weeks has been determined, a week of regular benefits is payable for each week that the client:

- is unemployed;

- is ready, willing and capable of work;

- has no earnings or allocations preventing payment;

- has no disentitlement or disqualification preventing payment.

To prove that benefits are payable, clients must complete claimant’s reports. A client receiving regular benefits who is enrolled in an approved apprenticeship course may request an exemption from completing claimant’s reports.

**Special benefits**

- maternity benefits
         [maternity benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Maternity_Benefits)

- parental benefits
         [parental benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Parental_Benefits)

- sickness benefits
         [sickness benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Sickness_Benefits)

- compassionate care benefits (CCB)
         [compassionate care benefits (CCB)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Compassionate_Care_Benefits)

- family caregiver benefits
         [family caregiver benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#FCB)

**Maternity benefits**

For residents of Quebec, refer to (QPIP) .
       [(QPIP)](https://www.rqap.gouv.qc.ca/en)

Maternity benefits are paid for a period of physical inability to work due to pregnancy and childbirth.

**Maternity qualifying conditions**

To qualify for maternity benefits, a client must:

- have applied for benefits;

- have had an I of E in the QP ;
         [I of E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings) 
         [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

- be major attached (has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment. If the client has a violation on file, increased entrance requirements may apply;
         [increased entrance requirements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Increased_entrance_requirements)

**Maternity entitlement conditions**

To be entitled to maternity benefits, a client must:

- provide proof of her pregnancy;

- request the benefits during the maternity window.

**Proof of pregnancy**

To prove her pregnancy, the client must do the following:

- provide a signed statement attesting to her pregnancy and the expected date of birth (DOB) (the attestation at the end of her online application is acceptable)

- report the actual DOB as soon as possible after the birth of the child

**Termination of pregnancy**

When a pregnancy is terminated within the first 19 weeks, the claim is treated as a sickness claim. If a pregnancy is terminated after the 19th week, the claim is treated as a maternity claim.

**Maternity weeks of entitlement**

Maternity benefits may be paid for a maximum of 15 weeks in a benefit period (BP). The 15 weeks payable for a single pregnancy may be paid over 2 BPs.
       [benefit period](/en/procedure/generic/knowledge.shtml#Benefit_Period)

To prove that benefits are payable, clients must complete claimant’s reports. A client receiving maternity benefits may request an exemption from completing claimant’s reports.

**Maternity window**

The maternity window is the period during which maternity benefits can be paid. The maternity window starts the earlier of the following dates:

- 12 weeks before the expected DOB (expected DOB – 12 weeks);

- the actual DOB.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0128.dita) 

The maternity window ends the later of the following dates:

- 17 weeks after the expected DOB (expected DOB + 17 weeks);

- 17 weeks after the actual DOB (actual DOB + 17 weeks).

**Extension of the maternity window**

To allow the client more time to collect maternity benefits to which she is entitled, the maternity window may be extended by one week for each week that a newborn is hospitalized within that period. The maximum extension of the maternity window is 52 weeks after the actual DOB (actual DOB + 52 weeks). The number of weeks of maternity entitlement remains the same.

**Applying for maternity benefits**

A claim for maternity benefits cannot generally be established outside of the maternity window. However, a client can establish a BP for maternity benefits before the maternity window if the following conditions are met:

- The client qualifies for regular benefits.

- The client is applying for maternity benefits from the onset of the claim.

- The client will serve a WP immediately before the maternity window.

When the conditions are met, the client can serve her WP in the period immediately before the maternity window.

**Maternity and sickness benefits**

If a client is unable to work for medical reasons associated with the pregnancy, she may choose to apply for sickness benefits before maternity benefits. If no regular benefits are collected during the claim, the client may be entitled to an extension of the BP to collect her full maternity and parental entitlement.
       [extension of the BP](/en/procedure/generic/knowledge.shtml#Extending_the_benefit_period)

To collect sickness benefits, the client must be able to demonstrate that she is otherwise available for work for the period for which she wishes to collect sickness benefits. This may be difficult to prove if the client had already scheduled with her employer to start her maternity leave before or during the period for which she is requesting sickness benefits, and verification with the employer may be required.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0874.dita) 

**Parental benefits**

For residents of Quebec, refer to the QPIP .
       [QPIP](https://www.rqap.gouv.qc.ca/en)

Parental benefits provide compensation to parents caring for a newborn child or adopted child. Benefits may be paid to either of the biological or adoptive parents or they may be shared between the parents. Clients may also be eligible to receive parental benefits in the following circumstances:

- They are foster parents, or they have temporary or permanent custody of a child and have made a commitment to adopt. Refer to Adoptive parents - New policy in force on January 1, 2012 , for more information.
         [Adoptive parents - New policy in force on January 1, 2012](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Adoptive_parents_New_policy_in_force_on)

- They are in a same-sex relationship and are recognized as the legal other parent of the child (recognized by the province on the child’s birth registration) or they have initiated the adoption process.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0875.dita) 

**Parental qualifying conditions**

To qualify for parental benefits, a client must:

- have applied for benefits;

- have had an I of E in the QP ;
         [I of E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings) 
         [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

- be major attached (has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment. If the client has a violation on file, increased entrance requirements may apply ;
         [increased entrance requirements may apply](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Increased_entrance_requirements)

**Parental entitlement conditions**

To be entitled to parental benefits, a client must:

- provide proof of the birth, adoption or placement;

- request the benefits during the parental window (PW);

- care for the child.

**Adoptive parents**

In addition to the eligibility criteria listed above, the following criteria must be met from the date of placement:

- The child is physically placed with the client.

- The client has made a demonstrable commitment to adopt that child under the laws governing adoption in the province or territory in which the client resides.

When the adoption is not finalized:

- The entitlement to parental benefits ends on the first Sunday after the child is removed from the adoptive home.

- The clients are not required to pay back benefits they received while the child was in their care.

If the child is returned to the custody of the birth parent, the birth parent may then be entitled to parental benefits if he or she meets the conditions for eligibility.

**Legally recognized parents**

A client who is not the child’s biological or adoptive parent may still be recognized as the child’s legal parent (e.g. the non-biological parent in a same-sex relationship). If the client is recognized as the child’s legal parent on the provincial or territorial birth certificate, he or she is eligible to receive parental benefits if the qualifying conditions to establish a claim have been met.

The client is not entitled to parental benefits if the client is not recognized by the province or territory as legal parent on the birth certificate unless an adoption process has begun.

**Proof of birth, adoption or placement**

Parents must supply proof of birth, adoption or placement depending on their relationship to the child or children. For more information, the officer can refer to Parents: Definition — Table .
       [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0876.dita) 

The officer imposes an indefinite 34 - Parental benefits entitlement conditions not met disentitlement (D34) if any of the following conditions apply:

- There is no proof of placement for the purposes of adoption. Note: If the client attests that he or she considers the placement to be permanent and it is the client’s intention to adopt the child, this is considered sufficient proof.

- The birth or placement date is not provided.

- The client is not providing care for the child.

**Placement when the child in the client’s care cannot be legally adopted**

In some situations, a child cannot be legally adopted at the time he or she is placed in the care of the client. Parental benefits may be payable to a client who attests that it is his or her intent to adopt a child who has been placed with him or her by a recognized authority because circumstances exist that render the legally recognized parent(s) incapable of caring for the child. A verbal attestation that the client believes the placement is a permanent one and that he or she intends to adopt the child is an acceptable form of proof.

When the child cannot be legally adopted on the placement date, the officer, at any time, can request that the client provide confirmation that the child for whom he or she is claiming parental benefits has been placed with him or her by a recognized authority.

**Type of parental benefits**

Parental benefits are payable as either standard parental benefits at the basic rate or as extended parental benefits at a reduced rate. Clients choose the parental benefit type they want to receive when applying for parental benefits. However, if the first parent to apply has already chosen a type of parental benefits, the second parent must also choose the same type. Even if the second parent’s claim is antedated to a date before the first parent’s claim, the type of parental benefits chosen by the first parent is still the type of benefits both parents will receive.

The type of parental benefit selected can only be modified if no parental benefits have been paid to the client or to the other parent. Once parental benefits have been paid on a claim (even as little as $1), the client’s choice to receive standard or extended parental benefits cannot be changed .

**Parental benefit rate**

Standard parental benefits are payable at a benefit rate of 55% of the client’s weekly insurable earnings for a major attached client. Extended parental benefits are payable at a benefit rate of 33% of the client’s weekly insurable earnings for a major attached client.

The FS is calculated in the same manner for extended parental benefits as it is for other BTs. This amount is added to the reduced rate for extended parental benefits and can increase the benefit rate to the maximum of 55% of the maximum weekly insurable earnings. Clients receiving extended parental benefits can therefore receive more FS than clients receiving standard parental benefits because they are less likely to be capped by the weekly maximum. Additionally, clients receiving extended parental benefits who qualify for FS will receive the amount over a longer duration resulting in a larger total amount of FS over the period of the claim.

A minimum benefit rate applies to all claims in the following periods:

- For claims with a BPC between w/c 2258 and w/c 2309, the minimum benefit rate is $500 for standard parental benefits or $300 for extended parental benefits. If the client is entitled to FS, this amount is added to the minimum benefit rate.

- For claims with a BPC between w/c 2310 and w/c 2317, the minimum benefit rate is $300 for standard parental benefits or $180 for extended parental benefits. If the client is entitled to FS, this amount is added to the minimum benefit rate.

**Maximum entitlement**

A client is entitled to a maximum of 35 weeks of standard parental benefits or 61 weeks of extended parental benefits per birth or placement for adoption. The maximum parental entitlement is also the maximum number of parental entitlement weeks that can be paid in a BP. Parental benefits can be paid over 2 BPs, but cannot be paid outside of the parental window (PW). The number of weeks of parental benefits a client is entitled to receive is not affected by the number of children born at the same time (twins, triplets, etc.) or by the number of children adopted at the same time.

The officer imposes a 35 - Parental - minor attached or outside range or maximum parental/special benefits paid disentitlement (D35) when one of the following occurs:

- The client is minor attached.

- The claim was not made during the PW.

- The parental benefits are exhausted.

- The maximum combined weeks of special benefits (no regular benefits) have been paid (the officer can refer to BP extension for special benefits for the total number of combined weeks of entitlement combinations).
         [special benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Special_Benefits) 
         [BP extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

- The maximum combination of regular and special benefits has been paid. The officer can refer to Maximum entitlement to benefits .
         [Maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

To prove that benefits are payable, clients must complete claimant’s reports. A client receiving parental benefits can request an exemption from completing claimant’s reports.

The WP can be deferred for a client receiving parental benefits.
       [WP](/en/procedure/generic/knowledge.shtml#Waiting_period)

**Sharing parental benefits**

Parents can share parental benefits. For more information and definitions, the officer can refer to Parents: Definition — Table .
       [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

The type of parental benefits requested by the first parent to apply determines the type of parental benefits all parents are entitled to receive for that same birth, adoption or placement, regardless of which parent is paid first. When fact-finding with parents who applied for benefits after the first parent, the officer informs the other parents of this. Once at least one week of parental benefits has been paid to any parent, all parents requesting parental benefits for the same birth, adoption or placement are only entitled to the type of parental benefits selected by the first parent who applied for benefits.

The maximum shareable entitlement is 40 weeks of standard parental benefits or 69 weeks of extended parental benefits for children born or placed for adoption on or after March 17, 2019. For children born or placed for adoption before this date, the maximum shareable entitlement is 35 weeks of standard parental benefits or 61 weeks of extended parental benefits. The maximum entitlement for one client remains at 35 weeks of standard or 61 weeks of extended benefits. Clients can change the number of weeks that each parent receives at any time before all benefits are paid. When clients cannot agree on the number of weeks they will each receive, the officer reassigns the issue to a Level 2 officer who adjudicates the division of the remaining weeks.

**Validating shared parental benefits**

A Parental Client Record is created for every client requesting parental benefits. The Parental Client Record consists of the client’s SIN, the arrival or placement week (APW) and the other parent’s SIN, if it has been provided. Once a claim is finalized, the system links Parental Client Records for all clients who are sharing parental benefits for the same child. The Parental sharing validation process creates a Claim Review (CR) Parental Benefits Validation WI when one of the following conditions is met:

- The parental benefit type on all linked Parental Client Records is not the same.

- The total number of parental weeks requested on all linked Parental Client Records exceeds the maximum number of shareable parental benefit weeks.

**Parental window**

The PW is the period during which parental benefits can be paid. The PW starts and ends as follows:

- Start week:

- The arrival or placement week (APW) is determined by the parent’s relationship to the child. For more information, the officer can refer to Parents: Definition — Table .
             [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

- End week:

- For standard parental benefits, the end week is 52 weeks after the APW (APW + 52).

- For extended parental benefits, the end week is 78 weeks after the APW (APW + 78).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0877.dita) 

**Extending the benefit period and parental window**

Hospitalization of the child for whom parental benefits are being claimed is grounds to extend the BP and PW. The BP and PW are extended by the number of weeks of hospitalization of the child, up to a maximum extension of 52 weeks. The BP and PW can also be extended for personnel of the Canadian military who are unable to collect their parental benefits because of an imperative military requirement. For more information, the officer can refer to Extension of the benefit period .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

The PW is also extended when a client entitled to parental benefits is entitled to a BP extension for special benefits. When this occurs, the BP and PW are both extended. For more information, the officer can refer to Benefit period: Extension for special benefits — Table.
       [Benefit period: Extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

**Terminating parental benefits during the PW — Entitlement conditions are no longer met**

A client must meet the entitlement conditions for each week of parental benefits requested. If the officer is informed that the client is no longer caring for the child during the PW, the officer imposes a definite or indefinite D34 starting the Monday after the week in which the client is no longer entitled to benefits. For more information, the officer refers to Determining entitlement to parental benefits when the client is no longer caring for the child (Task) .
       [Determining entitlement to parental benefits when the client is no longer caring for the child (Task)](/en/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml)

**Parental and sickness benefits**

Regardless of the BPC date, for any weeks of sickness benefits claimed that fall on or after March 24, 2013, the requirement to be otherwise available does not apply when a client (including fishers) requests a conversion to sickness benefits while on EI or QPIP benefits.
       [BPC](/en/procedure/generic/knowledge.shtml#Benefit_period_commencement) 
       [otherwise available](/en/procedure/generic/knowledge.shtml#Otherwise_available)

The client must provide an acceptable medical certificate that includes the incapacity start date and the probable duration of the incapacity.
       [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

To qualify for sickness benefits, clients on parental leave from their employment who are not claiming EI or QPIP benefits must still prove that they are otherwise available or would be otherwise working.

**Sickness benefits**

Sickness benefits provide compensation to a person who becomes incapable of work due to illness, injury or quarantine and who is otherwise available for work. The client can receive up to 26 weeks of sickness benefits per BP for a BPC in w/c 2374 or later and up to 15 weeks of sickness benefits per BP for a BPC in w/c 2373 or earlier.

**Sickness qualifying conditions**

To qualify for sickness benefits, a client must:

- have applied for benefits;

- have had an I of E in the QP ;
         [I of E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings) 
         [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

- be major attached (has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment). If the client has a violation on file, increased entrance requirements may apply ;
         [increased entrance requirements may apply](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Increased_entrance_requirements)

- be a minor attached client (has fewer than 600 hours of insurable employment) who has at least the variable entrance requirements (VER) in the QP, provided that the most recent RFS is not illness, injury or quarantine. If the client has a violation on file, increased entrance requirements may apply .
         [minor attached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Major_or_minor_attached_client) 
         [variable entrance requirements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Variable_entrance_requirement) 
         [increased entrance requirements may apply](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Increased_entrance_requirements)

**Sickness entitlement conditions**

To be entitled to sickness benefits, a client must:

- provide proof that he or she is unable to work due to illness;

- provide proof that he or she would otherwise be available for work.

**Proof of client’s medical condition**

**Initial claims**

An acceptable medical certificate completed by a doctor or by another approved medical practitioner confirming the client’s sickness must be obtained for each week the client requests sickness benefits.
       [acceptable](/en/procedure/task/determining_med_cert_valid.shtml)

A client applying for sickness benefits using a paper application is advised to submit the medical certificate with the application. A client applying for sickness benefits using the online application who indicates the RFS from the last employer is illness is advised to keep the medical certificate for 6 years and that it may be requested at a later date. A client applying online for sickness benefits who indicates an RFS other than illness is advised to submit the medical certificate.

It is not always necessary for the client to submit the medical certificate. The officer must request a medical certificate only when the client is required to submit it. However, if a medical certificate is submitted, the officer must review it to ensure it is acceptable and use it to determine the recovery week.

The client is not required to submit a medical certificate if all of the following conditions are met:

- The client is major attached (i.e. the client has worked at least 600 hours of insurable employment).

- The RFS on the last ROE is sickness or injury and the client is applying for either sickness benefits or sickness benefits combined with maternity benefits or the client is requesting sickness benefits on an initial subsequent claim immediately following a renewal claim for sickness and the RFS was sickness on the last ROE.

- None of the following disqualifications or disentitlements apply to the claim, regardless of whether they were imposed due to the adjudication or the deferral of a contentious RFS:

- 10 - Dismissal - misconduct proven (D10)

- 11 - Voluntary leaving - just cause not proven (D11)

- 42 - Suspension from employment (D42)

- 43 - Leave of absence (D43)

- 44 - Anticipated loss of employment (D44)

The client must submit an acceptable medical certificate in any of the following situations:

- The client is minor attached and the RFS for the most recent period of employment is not sickness.

- The RFS on the last ROE is not sickness.

- One of the following disqualifications or disentitlements applies to the claim, regardless of whether it was imposed due to the adjudication or the deferral of a contentious RFS:

- D10

- D11

- D42

- D43

- D44

- There is a medical certificate on file that is not acceptable . This applies even when the RFS on the last ROE is sickness or injury and the client is applying for either sickness benefits or sickness benefits combined with maternity benefits.
         [acceptable](/en/procedure/task/determining_med_cert_valid.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0878.dita) 

**Renewal claims**

A client who completes a renewal application for sickness benefits must obtain an acceptable medical certificate . The medical certificate must attest to the client’s incapacity. When the RFS is illness, the client is advised to keep the medical certificate and submit it if requested, for processing purposes.
       [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

The client must submit the medical certificate in any of the following situations:

- The RFS for the most recent period of employment is not illness or injury.

- The client is minor attached and the RFS for the most recent period of employment is not sickness.

- One of the following disqualifications or disentitlements applies to the claim, regardless of whether it was imposed due to the adjudication or the deferral of a contentious RFS:

- D10

- D11

- D42

- D43

- D44

- Entitlement to regular benefits is exhausted and the client has requested sickness benefits.

- A 16 - No medical certificate submitted (D16) is imposed on the claim because a medical certificate was requested but has not been submitted.

**Conversions on continuing claims**

**Conversions when casual sickness benefits have been paid**

A client who is receiving regular benefits, including fishing benefits, can declare up to 4 consecutive weeks of casual sickness benefits. If the client declares a fifth week of casual sickness, the claimant’s report is rejected with the error code C465. If the client requests additional sickness benefits after declaring 4 consecutive weeks, whether benefits have been paid or not, a conversion to a claim for sickness benefits is required.

A maximum of 8 weeks of casual sickness benefits in total can be paid in a BP. If the client declares a ninth week of casual sickness, the claimant’s report is rejected with the error code C484. A client who has already received 8 weeks of casual sickness benefits and who is still incapable of working must submit a medical certificate and convert to a claim for sickness benefits.

The officer determines the number of weeks of casual sickness benefits paid in a BP by referring to the Casual sickness weeks field on the Summary or Special Benefits tab in FTS. When determining the recovery week, the officer must use only the casual sickness weeks counter to obtain the number of weeks of casual sickness benefits paid.

**Medical certificate must be submitted**

A medical certificate must be submitted for a client requesting a conversion to sickness benefits or an extension of a period of sickness if any of the following conditions is met:

- The sickness period is being extended when the initial period of sickness was granted without submitting a medical certificate.

- The maximum of 8 weeks of casual sickness benefits has been paid.

- One of the following disqualifications or disentitlements applies to the claim, regardless of whether it was imposed due to the adjudication or the deferral of a contentious RFS:

- D10

- D11

- D42

- D43

- D44

- The client is requesting sickness benefits during or after receiving maternity, parental, CCB, QPIP or family caregiver benefits.

- Entitlement to regular benefits is exhausted and the client has requested sickness benefits.

- The client is minor attached (i.e. the client has fewer than 600 insurable hours) and the RFS for the most recent period of employment is not sickness.

- A D16 is imposed on the claim because a medical certificate was requested but has not been submitted.

**Otherwise available**

A client who applies for sickness benefits must prove that had it not been for the incapacity, the client would have been available for work.

Regardless of the BPC date, for any weeks of sickness benefits that fall on or after March 24, 2013, the otherwise available requirement does not apply when a client (including fishers) is requesting a conversion for sickness benefits while on EI or QPIP parental benefits. However, a client who is on parental leave from his or her employment, but who is not claiming EI or QPIP parental benefits must still prove that he or she is otherwise available or would be otherwise working to qualify for sickness benefits.
       [BPC](/en/procedure/generic/knowledge.shtml#Benefit_period_commencement)

When a client does not prove that he or she would be otherwise available for work for the entire period of incapacity or for part of that period, the officer imposes a 33 - Incapacity proven but not otherwise available disentitlement (D33). The officer imposes the disentitlement from the date on which the client does not meet the condition until the end of the period of incapacity, or until the date on which the client is otherwise available for work.

**Sickness declared on a claim for regular benefits**

A client who meets the entitlement conditions to receive sickness benefits and who has not received the maximum sickness benefits may declare up to 4 consecutive weeks of sickness on a continuing claim for regular benefits without any interruption in the payment of benefits.

When a client declares sickness for 2 consecutive weeks on the same claimant’s report, the system processes the claimant’s report as a claim for sickness benefits and advises the client to submit a medical certificate if their incapacity lasts more than 4 weeks.

If no decision concerning the illness has been rendered when the third claimant’s report is processed, and 5 sick days are declared in the first week, which is the fifth consecutive week of illness, the claimant’s report is rejected with the error code C465.

A maximum of 8 weeks of casual sickness benefits in total can be paid in a BP. If the client declares a 9th week of casual sickness benefits, the claimant’s report is rejected with the error code C484.

If the client requests additional weeks of sickness benefits after having declared 4 consecutive weeks or the maximum of 8 weeks in a BP, the claim type (CT) must be converted to sickness benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0879.dita) 

When the client declares a partial week of sickness after regular benefits have been exhausted and has not proven incapacity to work due to illness, the officer imposes an 18 - Special benefits - client not entitled to regular benefits disentitlement (D18).

**Maximum sickness benefits**

The client can receive up to 26 weeks of sickness benefits per BP for a BPC in w/c 2374 or later, and up to 15 weeks of sickness benefits per BP for a BPC in w/c 2373 or earlier.

If a client does not meet all the entitlement conditions to receive regular benefits (e.g. the client is still sick) once the maximum weeks of sickness benefits have been paid, the officer imposes a 22 - Illness (maximum sickness/special benefits paid) disentitlement (D22).

Once a client has exhausted entitlement to sickness benefits, the benefits are reduced by one fifth for each day of sickness that is subsequently declared.

To prove that benefits are payable, clients must complete claimant’s reports.

**Compassionate care benefits (CCB)**

CCB provide income support to eligible clients who are absent from work to provide care or support to a family member (patient) with a serious medical condition that poses a significant risk of death within 26 weeks. CCB were introduced January 4, 2004.

CCB claims are processed in selected CCB offices but the client can visit the nearest Service Canada Centre for in-person services.
       [Service Canada Centre](http://offices-bureaux.prv/opd/index.cfm?APP=SEARCH&ACT=SEARCH_RC&LANG=E)

**CCB qualifying conditions**

To qualify for CCB, a client must:

- have applied for benefits;

- have an I of E in the QP ;
         [I of E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings) 
         [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

- be major attached (have accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment). If the client has a violation on file, increased entrance requirements may apply .
         [increased entrance requirements may apply](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Increased_entrance_requirements)

**CCB entitlement conditions**

To be entitled to CCB, a client must:

- submit proof confirming that a family member has a serious medical condition that poses a significant risk of death within 26 weeks and needs care or support from one or more family members;

- provide care or support to an individual identified as a family member;

- request CCB during the 52-week entitlement window established for a patient, if the 26 payable weeks of CCB have not already been paid during that window.

The officer imposes a 51 - Does not meet compassionate care entitlement conditions disentitlement (D51) if the client does not meet the entitlement conditions. Exception: If the client does not submit proof, the officer imposes a 53 - Compassionate care benefits - No medical proof disentitlement (D53).

**Definition of family member**

For the purpose of entitlement to CCB, the term family member as applied to the patient includes any person the client considers to be like a family member. The patient must also consider the client to be like a family member . As proof of this, the client must submit the Compassionate Care Benefits Attestation (INS5223B) signed by the gravely ill family member or a representative.
       [family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml) 
       [Compassionate Care Benefits Attestation (INS5223B)](http://forms-formulaires.prv/eform99/index.cfm?App=Launch&FormID=4180&GroupID=203&LANG=E)

**Definition of care or support**

Care or support of a patient includes:

- directly providing or participating in the care of the patient;

- providing psychological and emotional support to the patient;

- arranging for care of the patient by a third party care provider.

For more information, refer to Digest 23.2.4 — Care or support of gravely ill family member .
       [Digest 23.2.4 — Care or support of gravely ill family member](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-23/compassionate-care-benefits.html#a23_2_4)

**Proof of patient’s medical condition**

Before CCB can be paid, the client must present an acceptable medical certificate signed by a medical doctor or medical practitioner who cared for or treated the patient. The medical certificate must attest to the patient’s health status, the patient’s risk of death within 26 weeks and the need for care or support from one or more family members. For such a certificate to be issued, the patient must agree to release medical information.
       [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

To provide this information, the client provides Service Canada with the following form: Authorization to Release Medical Information for Employment Insurance Compassionate Care and Family Caregiver Benefits (INS5257) completed by the patient or the patient’s representative.
       [Authorization to Release Medical Information for Employment Insurance Compassionate Care and Family Caregiver Benefits (INS5257)](http://forms-formulaires.prv/lc/content/EForms/en/Detail.html?Form=INS5257)

Medical certificates are submitted to National Headquarters for review only in the following situations:

- The certificate is in a language other than French or English.

- The officer is uncertain whether the following 2 conditions have been met:

- The patient has a serious medical condition with a significant risk of death within the next 26 weeks.

- The patient requires the care or support of one or more family members.

- There is doubt about the validity of a certificate issued by a doctor or medical practitioner.

Only one medical certificate is required for the patient in a single compassionate care window (CCW), regardless of how many family members will be collecting benefits in connection with that patient.

The officer imposes a D53 in the following circumstances:

- No certificate is submitted.

- The certificate submitted is not valid.

- The doctor or medical practitioner is not recognized and the certificate is not approved.

**Maximum CCB**

Within a benefit period (BP), a client who is entitled to CCB can receive a maximum of 26 weeks of benefits involving one or more CCWs for one or more patients. The client can receive a maximum of 26 weeks of CCB in a CCW regardless of the number of clients requesting CCB for the same patient.
       [benefit period](/en/procedure/generic/knowledge.shtml#Benefit_Period)

Up to 26 clients may share, concurrently or not, a maximum of 26 weeks of CCB for one patient during the same CCW.

When 2 or more clients present a CCB claim for the same patient and they agree on how they want to share the payable weeks, these weeks are shared according to the agreement between them.

When the clients cannot reach an agreement, sharing is handled as follows:

- When the number of unpaid weeks is equal to the number of clients, one week is assigned to each of them.

- When the number of unpaid weeks is greater than the number of clients, one week is assigned to each of the clients in turn until the payable weeks run out, beginning with the client who first submitted a claim and following the chronological order in which the other clients submitted their claims.

- When there are fewer unpaid weeks than clients, one week is assigned, beginning with the client who first submitted a claim, then to the second, and so on, until the number of payable weeks run out.

The officer imposes a 52 - Compassionate care benefits exhausted disentitlement (D52) in the following circumstances:

- 26 CCB weeks were already paid during the BP.

- 26 CCB weeks were already paid in the CCW.

- The client is excluded from sharing CCB weeks.

- The patient is deceased (effective from the week following the death).

To prove that benefits are payable, clients must complete claimant’s reports. A client receiving CCB can request an exemption from completing claimant’s reports.

The WP can be deferred for a client receiving CCB.
       [WP](/en/procedure/generic/knowledge.shtml#Waiting_period)

**Compassionate care window (CCW)**

The CCW is the period of 52 weeks during which 26 weeks of CCB are payable. The start and end dates of the CCW are based on the medical certificate concerning the gravely ill family member.

The CCW begins on the earliest of the following dates:

- the Sunday of the week in which the CCB medical certificate is signed

- the Sunday of the week in which the terminal diagnosis is made, if quoted in the CCB medical

- the Sunday of the week in which the doctor indicates the terminal condition applied prior to doctor examination, if quoted in the CCB medical

Entitlement within the CCW ends on the appropriate date as follows:

- the Saturday of the week for which the 26th week of CCB is paid to the client during the BP for one or several patients;

- the Saturday of the week for which the 26th week of CCB is paid, whether one or several clients shared CCB during the same CCW;

- the Saturday of the week in which the client ceases to give care or support to the patient;

- the Saturday of the week in which the 52nd week of the CCW occurs;

- the Saturday of the week in which the patient dies.

The CCW cannot be extended. An additional medical certificate may allow a new 52-week window during which CCB can be paid. However, a subsequent CCW does not change the number of entitlement weeks payable.

**Family caregiver benefits**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0487.dita) 

Family caregiver benefits provide temporary income support to an eligible client who takes a leave from work to provide care or support to a critically ill or injured patient.

There are 2 types of family caregiver benefits: family caregiver for adults and family caregiver for children.

The qualifying conditions and the calculation of the benefit rate are the same for both types of family caregiver benefits. The difference between the 2 is the maximum number of weeks payable and the age of the patient.

For more information on this BT, the officer can refer to Family caregiver benefits (Knowledge page) .
       [Family caregiver benefits (Knowledge page)](/en/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml)

**Family caregiver qualifying conditions**

To qualify for family caregiver benefits, a client must:

- have an I of E in the QP ;
         [I of E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Interruption_of_earnings) 
         [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Qualifying_period)

- be major attached (has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment). If the client has a violation on file, increased entrance requirements may apply .
         [increased entrance requirements may apply](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Increased_entrance_requirements)

**Family caregiver entitlement conditions**

The following entitlement conditions must also be met:

- the client must be an eligible family member or close relative;

- the client must submit the Medical certificate for Employment Insurance for Family Caregiver benefits completed by a licensed medical doctor or nurse practitioner;
         [Medical certificate for Employment Insurance for Family Caregiver](http://forms-formulaires.prv/lc/content/EForms/en/Detail.html?Form=INS5242B)

- the patient or the patient’s representative must complete and sign the Authorization to release medical information for Employment Insurance Compassionate Care and Family Caregiver Benefits form;
         [Authorization to release medical information for Employment Insurance Compassionate Care and Family Caregiver Benefits](http://forms-formulaires.prv/lc/content/EForms/en/Detail.html?Form=INS5257)

- the patient must be critically ill or injured and must require care or support of a family member at the time the 52-week window opens;

- the client must request family caregiver benefits during the 52-week entitlement window.

**Disentitlements**

The officer imposes the following disentitlements related to family caregiver benefits when the client does not meet the entitlement conditions:

- 61 - Family caregiver benefits for children or adults - Does not meet entitlement conditions (D61)

- 62 - Family caregiver benefits for children or adults- Benefits Exhausted (D62)

- 63 - Family caregiver benefits for children or adults- No medical proof (D63)

**Maximum family caregiver benefits**

Clients can claim a total of 35 weeks of family caregiver benefits for children and a total of 15 weeks of family caregiver benefits for adults during any given benefit period (BP). Family caregiver benefits can be shared between eligible clients.

Family caregiver benefits do not have to be paid consecutively. They can be paid intermittently during the BP or the 52-week family caregiver window (FCW) in a manner that is most convenient to the client, provided the required medical certificate proves the patient’s critical illness or injury during the weeks claimed.

**Family caregiver window (FCW)**

The FCW is a 52-week period during which family caregiver benefits for adults or children can be paid.

For more information, the officer can refer to Establishing the family caregiver window .
       [Establishing the family caregiver window](/en/procedure/task/establishing_fbw_etablir_fpppa.shtml)

**Definition of family member**

For the purpose of entitlement to family caregiver benefits, the term family member as applied to the patient includes any person the client considers to be like a family member.

The officer can refer to Family member — Definition for a list of all eligible family members or close relative.
       [Family member — Definition](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

**Definition of care or support**

Care or support of a patient includes:

- directly providing or participating in the care of the patient;

- providing psychological and emotional support to the patient.

The officer can refer to Digest 23.2.4 — Care or support of gravely ill family member .
       [Digest 23.2.4 — Care or support of gravely ill family member](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-23/compassionate-care-benefits.html#a23_2_4)

**Proof of patient’s medical condition**

In order to prove that a patient is critically ill or injured and requires the care or support of a family member, a client must obtain an acceptable medical certificate that attests the following information:
       [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

- the patient’s baseline state of health has changed significantly;

- the patient’s life is at risk as a result of an illness or injury;

- the patient requires the care or support of a family member or close relative.

For more information about acceptable medical certificates, the officer can refer to Determining if a medical certificate is acceptable — Family caregiver benefits .
       [Determining if a medical certificate is acceptable — Family caregiver benefits](/en/procedure/task/determining_pcic_med_cert.shtml)

**Sharing of benefits**

Family caregiver benefits can be shared between eligible family members within individual limits for each BT. Family caregiver benefits can be shared either at the same time or separately during the 52-week window. The officer can refer to Family member for information on acceptable family members.
       [Family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

The clients sharing the benefits must agree on the number of weeks each family member claims. Only weeks that have not yet been paid can be shared. When clients disagree on how to share the benefits, a Level 2 officer adjudicates the division of the remaining weeks.

For more information, the officer can refer to Adjudicating the sharing of family caregiver benefits — Disagreement on how to share weeks .
       [Adjudicating the sharing of family caregiver benefits — Disagreement on how to share weeks](/en/procedure/task/adjudicating_na_pcic_bw.shtml)

**Operational Centre Memo (MM06)**

When the claim is not in MPS, the officer processes initial claims in SSO, whereas renewal claims are processed in FTS. The officer then sends an MM06 to IPOC. If the claim is already in MPS, only the MM06 is required.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0880.dita) 

**No-CR CODE**

The NO-CR-CODE option is also available for family caregiver benefits. The system does not automatically cancel the exemption from reporting when the eligibility criteria are no longer met (e.g. BT changes from family caregiver to sickness or a client reports part-time employment). The officer must send an Operational Centre Memo (MM06) to IPOC requesting that the NO-CR-CODE be rescinded.

**Entitlement weeks paid or payable**

A week of benefits is considered to have been paid when at least $1 of benefits has been paid.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0881.dita) 

A week of benefits is considered paid or payable when one of the following occurs:

- The client serves 1 week of a definite disqualification.

- The benefits were used to repay an OP or a penalty.

- Benefits were withheld for assignment of benefits.

- Benefits were withheld pursuant to a family order agreement.

- Benefits were withheld for Canada Revenue Agency.

**Benefit period (BP)**

The BP is the period of time in which a client can claim the weeks of benefits to which he or she is entitled. The duration of a BP is normally 52 weeks including the week of the BPC .
       [BPC](/en/procedure/generic/knowledge.shtml#Benefit_period_commencement)

A BP ends when one of the following occurs:

- All weeks of entitlement to regular benefits payable have been paid.

- The 52-week duration has been reached and there was no condition to extend the BP.

- The client requests and qualifies for termination of the BP.

- The maximum entitlement to benefits has been paid.
         [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

If the client did not receive all the weeks of benefits of entitlement during the BP, the remaining weeks are not brought forward to a subsequent claim.

**Extending the BP**

The EI Act allows the extension of the BP under certain conditions.
       [BP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/knowledge#Benefit_Period)

The extension of the BP allows a client a longer period of time (duration) to collect the weeks of benefits to which he or she is entitled to be paid. The number of weeks of benefits to which the client is entitled remains the same, regardless of the extension.

For more information on the extension of the BP, refer to Extension of the benefit period .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0852.dita`

Note:

An I of E used to establish a BP cannot be used to establish a subsequent claim, unless the previously established BP is cancelled (refer to Cancelling a benefit period ).
       [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml)

     [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0853.dita`

Note:

When an employer attaches pay extracts to the ROE as a common practice, the officer contacts and informs the employer that the information is not required. The officer encourages the employer to complete block 15C instead. When this occurs, the officer verifies if there was a specific request for the actuals to be used for the calculation. If not, the officer returns the actuals using the appropriate notice. 

### Note

Source topic: `en_EN/common_notes/note_c_0854.dita`

Note:

If the ROE was issued with the expectation that the client would not be called back to work within 7 days, an I of E has occurred. However, if the client returned to the same employment within 7 days and the claim has not been finalized, the I of E is deemed not to have taken place. The BP is not established unless an I of E has occurred at another time in the QP. 

### Note

Source topic: `en_EN/common_notes/note_c_0855.dita`

Note:

Statutory holiday pay does not prevent a regular I of E (7 days without work or earnings), but may prevent a special I of E, which occurs when income falls below 60% of NWE and the separation is due to sickness, maternity, parental, compassionate care or family caregiver leave. 

### Note

Source topic: `en_EN/common_notes/note_c_0856.dita`

Note:

Budget 2021 established a common entrance requirement for all BPCs between w/c 2310 and w/c 2361. However, an officer cannot postdate the BPC cannot beyond the current range of the regional rate of unemployment (RRU). The RRU continues to be used for the entitlement weeks and the divisor. 

### Example

Source topic: `en_EN/common_notes/note_c_0857.dita`

Example:

- The I of E and LDP occurred in w/c 2275.

- The client earned $1 000 in wages in the last week worked.

- The client applied in w/c 2279. 

### Note

Source topic: `en_EN/common_notes/note_c_0858.dita`

Note:

When an antedate request is allowed, the application is considered to have been filed on the earlier date. 

### Note

Source topic: `en_EN/common_notes/note_c_0859.dita`

Note:

If the client is part of a Work-Sharing (WS) program, has provided a WS reference code and has applied before the WS reference code expires, the client has submitted the application in a timely manner.
       [WS reference code](/en/procedure/generic/additionalresources/knowledge_reltws.shtml#Reference_Code)

     [WS reference code](/en/procedure/generic/additionalresources/knowledge_reltws.shtml#Reference_Code) 

### Example 1

Source topic: `en_EN/common_notes/note_c_0860.dita`

Example 1:

The I of E occurs in w/c 1928 and the client applies for benefits in w/c 1932. The BPC is in w/c 1928 since the client applied within 4 calendar weeks of the week of the I of E. If a later BPC is more advantageous to the client, the officer can postdate the BPC to a week later than w/c 1928 if the conditions under the Postdate Policy are met.
       [Postdate Policy](/en/policy/nationalpolicy/national_policy_on_postdates.shtml)

     [Postdate Policy](/en/policy/nationalpolicy/national_policy_on_postdates.shtml) 

### Example 2

Source topic: `en_EN/common_notes/note_c_0861.dita`

Example 2:

The I of E occurs in w/c 1928 and the client applies for benefits in w/c 1933. The BPC is in w/c 1933 since the client applied more than 4 calendar weeks after the week of the I of E. The client must request an antedate to have the claim start on an earlier date. 

### Example

Source topic: `en_EN/common_notes/note_c_0862.dita`

Example:

On the initial EI application, the client reported unable to work during the QP due to medical reasons from March 3, 2026, to March 9, 2026 (w/c 2541-2 to w/c 2542-1). The file indicates the following information:

- The client did not receive EI or QPIP benefits during the QP.

- The ROE indicates earnings during the biweekly pay period March 1, 2026, to March 14, 2026.

- Fact-finding with the employer confirmed that the client:

- works as a restaurant manager Tuesdays to Saturdays;

- was unable to work due to illness from Tuesday, March 3, 2026, to Monday, March 9, 2026;

- had no insurable earnings for the calendar week March 1, 2026, to March 7, 2026 (w/c 2541);

- had insurable earnings for the calendar week March 8, 2026, to March 14, 2026, as the client returned to work March 10, 2026.

In this situation, a QP extension can be allowed due to the partial week of illness for w/c 2541, as all conditions have been met. 

### Note

Source topic: `en_EN/common_notes/note_c_0863.dita`

Note:

A QP extension is not required if the client is already entitled to the maximum benefit rate and number of weeks of benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_0864.dita`

Note:

When a claim with a BPC between September 27, 2020 (w/c 2258) and September 19, 2021 (w/c 2309) is converted from an EI Emergency Response Benefit (EI ERB) or Canada Emergency Response Benefit (CERB) claim, an automatic 28-week QP extension is granted for all benefit types (BTs) except fishing and self-employment (SE). 

### Note

Source topic: `en_EN/common_notes/note_c_0865.dita`

Note:

In this context, the term “not found guilty” means any of the following: the client has been found not guilty or has been acquitted, the charges have been dropped, or there has been a stay of proceedings for more than one year (the timeframe allowed to restart the legal proceedings). 

### Note

Source topic: `en_EN/common_notes/note_c_0866.dita`

Note:

A charging document is not considered sufficient proof because a separate document is created for each charge and does not indicate if other charges are pending. 

### Note

Source topic: `en_EN/common_notes/note_c_0867.dita`

Note:

When a client has less than the number of hours required to meet the VER, the claim is not established. However, if the client has more than 420 insurable hours in the QP, and the RRU increases enough that the client may qualify for benefits, the client must submit a new application. 

### Callout

Source topic: `en_EN/common_notes/note_c_0868.dita`

**BPNE Types**

- N1: The client has less than 420 insurable hours (minimum number required to qualify) in the QP .
         [QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#Qualifying_period)

- N2: The client’s last ROE is missing.

- N5: The client does not meet the VER or, if there is a violation on file, the increased entrance requirement .
         [VER](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#Variable_entrance_requirement) 
         [increased entrance requirement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#_Increased_entrance_requirement)

- N7: The client is submitting a summer or winter fishing claim for which the total amount of insurable earnings from employment as a fisher is less than $2 500.

- N8: The client did not have an I of E during the QP. 

### Note

Source topic: `en_EN/common_notes/note_c_0869.dita`

Note:

- For more information, refer to the increased entrance requirements table in EIA 7.1 and Digest 18.10.3
         [EIA 7.1](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-7.1.html) 
         [Digest 18.10.3](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/violation.html#a18_10_3)

- Regardless of the type of benefits claimed, any client who has been issued a notice of violation is subject to increased entrance requirements. There is no exception for special benefits .
         [special benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#Special_Benefits)

     [EIA 7.1](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-7.1.html) 
     [Digest 18.10.3](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/violation.html#a18_10_3) 
     [special benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#Special_Benefits) 

### Note

Source topic: `en_EN/common_notes/note_c_0870.dita`

Note:

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is only required on the most recent ROE in the QP, if the reason for separation (RFS) is contentious. In addition, the common entrance requirement of 420 hours of insurable employment is not used to determine if the client requalifies after a disqualifying event. Instead, the client needs to have worked at least one hour in insurable employment since the disqualifying event and to have filed an EI application.

If the RFS since the disqualifying event is either non-contentious or is adjudicated and allowed, a new claim may be established using the hours from all the ROEs. The indefinite disqualification imposed due to the original period of employment no longer applies because the new ROE from the latest period of employment establishes a new BPC without a disqualification. 

### Note

Source topic: `en_EN/common_notes/note_c_0109.dita`

Note:

The base tax year is the taxation year that ends before the Canada child benefit payment year. For example, payments for July 2015 to June 2016 are based on the net family income for base tax year (taxation year) 2014. 

### Note

Source topic: `en_EN/common_notes/note_c_0111.dita`

Note:

Although the Canada child benefit may be payable to clients whose net family income is greater than $25 921, the maximum net family income to be entitled to the FS is $25 921. 

### Note

Source topic: `en_EN/common_notes/note_c_0871.dita`

Note:

If the BPC is w/c 2062 or earlier, the WP is a 2-week period. The client serves the first week of the WP in the first calendar week in which, had it not been for the WP, benefits would have been payable. Once the client has served the first week of the WP, the following week is deemed to be the second week of the WP. Once the claimant’s report is completed for the second week of the WP, the WP is considered served. 

### Note

Source topic: `en_EN/common_notes/note_c_0872.dita`

Note:

A disqualification has no effect on the WP and can be served only after the WP has been served. 

### Note

Source topic: `en_EN/common_notes/note_c_0873.dita`

Note:

The WP is waived on all claims with a BPC between:

- September 27, 2020 (w/c 2258) and October 25, 2020 (w/c 2262);

- January 31, 2021 (w/c 2276) and September 19, 2021 (w/c 2309).

The WP of claims for sickness benefits is waived for an extended period that covers BPCs from September 25, 2020 (w/c 2258) to September 25, 2021 (w/c 2309). However, the WP will not be waived for clients who are receiving SUB and who apply for special benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_0653.dita`

Note:

If the WP is deferred on a claim with a BPC of w/c 2062 or earlier, the WP is 2 weeks even if it is not served until after w/c 2062. 

### Note

Source topic: `en_EN/common_notes/note_c_0128.dita`

Note:

Before December 3, 2017, the start date of the maternity window was 8 weeks before the expected DOB or the actual DOB. 

### Note

Source topic: `en_EN/common_notes/note_c_0874.dita`

Note:

Some employers may have policies that allow employees to begin their maternity leave a fixed number of weeks before the expected DOB (e.g. in British Columbia, provincial employees can start maternity leave 6 weeks before their expected due date). In such situations, the employee must not be advised to apply for sickness benefits before the maternity benefits, unless it is warranted by her particular circumstances. Incorrectly advising a client to apply for sickness benefits could lead to the following problems:

- When a client is paid sickness benefits before maternity benefits, the EI program may become the “first payer.” Employers registered with the Employment Insurance Premium Reduction Program must be the “first payer” to meet the Program’s requirements. An employee claiming sickness benefits before maternity benefits may therefore jeopardize her employer’s entitlement to the premium reduction.

- There may be an impact on the payment of maternity or parental SUB:

- If a client collects sickness benefits before maternity benefits, she may lose her entitlement to SUB payments for the WP .
             [WP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#Waiting_period)

- The SUB may be payable for a fixed period of time after ceasing work because that period is deemed the maternity or parental leave period. After the fixed period has elapsed, the client may be able to obtain approval from her employer for an extended leave. However, an extended leave would fall outside the period for which the SUB is payable. The client may therefore be denied her full SUB entitlement, or the employer may be compelled to pay the SUB into the period of extended leave.

For these reasons, it is important that a client apply for the appropriate type of benefit based on her circumstances.

     [WP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#Waiting_period) 

### Note

Source topic: `en_EN/common_notes/note_c_0875.dita`

Note:

These situations require additional fact-finding by the officer before adjudicating the claim. 

### Note

Source topic: `en_EN/common_notes/note_c_0876.dita`

Note:

When the adoption raises doubts, proof of placement may be requested. 

### Note

Source topic: `en_EN/common_notes/note_c_0877.dita`

Note:

Under certain conditions, the PW can be extended to allow the client more time to collect weeks of entitlement. 

### Note

Source topic: `en_EN/common_notes/note_c_0878.dita`

Note:

Even if the RFS on the last ROE is sickness, if any of the disqualifications or disentitlements above apply to the claim, or the medical certificate is not acceptable, the client must submit an acceptable medical certificate. 

### Note

Source topic: `en_EN/common_notes/note_c_0879.dita`

Note:

A client should not apply for an initial or renewal claim for regular benefits with the intention of declaring casual sickness from the BPC or renewal date. If the client is not immediately available for work, the officer advises the client to apply for a sickness claim. Casual sickness should only be considered for a continuing regular benefits claim. 

### Note

Source topic: `en_EN/common_notes/note_c_0487.dita`

Note:

Effective December 3, 2017, family caregiver benefits for children replaced PCIC benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_0880.dita`

Note:

When completing the MM06 , the officer must provide to IPOC all the information required to process the payments through CPS. The officer selects 93 - Manual Pay System in the Work item field and 30 - New information on a manual pay claim in the Work type field. 

### Note

Source topic: `en_EN/common_notes/note_c_0881.dita`

Note:

Weeks of QPIP benefits paid equal weeks of EI benefits paid. For more details, refer to QPIP .
       [QPIP](http://www.rqap.gouv.qc.ca/Index_en.asp)

     [QPIP](http://www.rqap.gouv.qc.ca/Index_en.asp) 
