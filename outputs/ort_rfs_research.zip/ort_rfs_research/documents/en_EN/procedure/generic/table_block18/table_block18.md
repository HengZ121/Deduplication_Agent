# ROE: Actions required for comments found in block 18 of a regular ROE — Instructions

Source map: `en_EN/procedure/generic/table_block18/table_block18.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/table_block18/generic.dita`

Select the type of comment indicated in block 18 in order to determine if the comments can be removed.

- Coronavirus, COVID-19 and quarantine-related comments:

- when there is an outstanding ROE Issue (ROE) RFS Action WI for the same ROE
             [when there is an outstanding ROE Issue (ROE) RFS Action WI for the same ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/table_block18#covid19_1)

- when there is no outstanding ROE RFS Action WI for the same ROE
             [when there isnooutstanding ROE RFS Action WI for the same ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/table_block18#covid19_2)

- Reason for separation (RFS) related comments:

- when there is an outstanding ROE Issue RFS Action WI for the same ROE
             [when there is an outstanding ROE Issue RFS Action WI for the same ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/table_block18#RFSwithWI)

- when there is no outstanding ROE RFS Action WI for the same ROE
             [when there isnooutstanding ROE RFS Action WI for the same ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/table_block18#RFSnoWI)

- Vacation pay related comments
         [Vacation pay related comments](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/table_block18#vp)

- Monies other than vacation pay related comments (e.g. severance, pay in lieu, sick days, bonus, etc.)
         [Monies other than vacation pay related comments](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/table_block18#other)

- Miscellaneous comments
         [Miscellaneous comments](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/table_block18#misc)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0952.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0953.dita) 
     [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0954.dita) 

```text
| Both conditions must be met: | In RCM, complete the following fields: |

| Block 18 comments reflect that the RFS is related to one of the following reasons: | Block 16 RFS option is: | Actions required: | Block 16 RFS option: |

| Commission de la construction du Québec (CCQ) vacation leave | A or K | Move comments from block 18 to the Additional Information field. | RFS: Select K - Other . |

| end of contract/season/term | A or K | Move comments from block 18 to the Additional Information field. | Any required changes will be made in the ROE RFS Action WI in NWS. |

| job ended | A or K | Move comments from block 18 to the Additional Information field. |

| plant closure | A or K | Move comments from block 18 to the Additional Information field. |

| position eliminated | A or K | Move comments from block 18 to the Additional Information field. |

| restructuring | A or K | Move comments from block 18 to the Additional Information field. |

| seasonal work | A or K | Move comments from block 18 to the Additional Information field. |

| work shortage | A or K | Move comments from block 18 to the Additional Information field. |

| shutdown | A or K | Move comments from block 18 to the Additional Information field. |

| summer break / Summer job - contract ended | A or K | Move comments from block 18 to the Additional Information field. |

| lay off | A or K | Move comments from block 18 to the Additional Information field. |

| temporary shutdown/lay off | A or K | Move comments from block 18 to the Additional Information field. |

| 7 consecutive days without working | A or K | Move comments from block 18 to the Additional Information field. |

| casual | A or K | Move comments from block 18 to the Additional Information field. |

| name of show / film production | A or K | Move comments from block 18 to the Additional Information field. |

| change of payroll frequency | A or K | Move comments from block 18 to the Additional Information field. If the employer selected a RFS sub-option in block 16 , also indicate that in the Additional Information field. |

| change of company name or ownership of the business | A or K | Move comments from block 18 to the Additional Information field. If the employer selected a RFS sub-option in block 16 , also indicate that in the Additional Information field. |

| requested by Service Canada | A or K | Move comments from block 18 to the Additional Information field. If the employer selected a RFS sub-option in block 16 , also indicate that in the Additional Information field. |

| change of payroll service provider | A or K | Move comments from block 18 to the Additional Information field. If the employer selected a RFS sub-option in block 16 , also indicate that in the Additional Information field. |

| bankruptcy | A or K | Move comments from block 18 to the Additional Information field. |

| Other — employee requested | K | Move comments from block 18 to the Additional Information field. |

| apprenticeship training such as apprentice, apprentice class or apprentice level | C, J or K | Move comments from block 18 to the Additional Information field. |

| return to school with details indicating for apprenticeship training or reference code | C, J or K | Move comments from block 18 to the Additional Information field. |

| return to school with no apprenticeship training details provided | C or K | Move comments from block 18 to the Additional Information field. |

| unpaid medical leave | D, K or N | Move comments from block 18 to the Additional Information field. |

| illness or surgery related comment | D, K or N | Move comments from block 18 to the Additional Information field. |

| preventative withdrawal | D, F, K, N or E | Move comments from block 18 to the Additional Information field. |

| quit without notice | E, K or M | Move comments from block 18 to the Additional Information field. |

| retirement | E, K or M | Move comments from block 18 to the Additional Information field. |

| resigned | E, K or M | Move comments from block 18 to the Additional Information field. |

| personal reasons | E, K or M | Move comments from block 18 to the Additional Information field. |

| job abandonment | E, K or M | Move comments from block 18 to the Additional Information field. |

| Justified — dismissal with justification | E, K or M | Move comments from block 18 to the Additional Information field. |

| to go to another job | E, K or M | Move comments from block 18 to the Additional Information field. |

| to follow spouse | E, K or M | Move comments from block 18 to the Additional Information field. |

| employer relocation | E, K or M | Move comments from block 18 to the Additional Information field. |

| care for a dependant | E, K or M | Move comments from block 18 to the Additional Information field. |

| to become self-employed | E, K or M | Move comments from block 18 to the Additional Information field. |

| voluntary retirement | E, K or M | Move comments from block 18 to the Additional Information field. |

| health reasons | E, K or M | Move comments from block 18 to the Additional Information field. |

| return to school | E, K or M | Move comments from block 18 to the Additional Information field. |

| attendance | E, K or M | Move comments from block 18 to the Additional Information field. |

| poor performance | E, K or M | Move comments from block 18 to the Additional Information field. |

| not suitable, etc. | E | Move comments from block 18 to the Additional Information field. |

| not suitable, etc. | K or M | Move comments from block 18 to the Additional Information field. | RFS: Select M - Dismissal |

| did not pass the probationary period | K or M | Move comments from block 18 to the Additional Information field. | RFS: Select M - Dismissal Terminated within Probationary Period . |

| terminated within probationary period | K or M | Move comments from block 18 to the Additional Information field. | RFS: Select M - Dismissal Terminated within Probationary Period . |
```

```text
| If both of the following conditions are present on the ROE | Then, in RCM ensure the ROE reflects the following: |

| Block 18 comments reflect: | Block 16 RFS option reflects: | Actions required: | Block 16 RFS option: |

| Commission de la construction du Québec (CCQ) vacation leave | A or K | Move comments from block 18 to the Additional Information field. | RFS: Select K - Other . |

| end of contract/season/term | A or K | Move comments from block 18 to the Additional Information field. | RFS: Select A - Shortage of work / End of contract or season . |

| job ended | A or K | Move comments from block 18 to the Additional Information field. |

| plant closure | A or K | Move comments from block 18 to the Additional Information field. |

| position eliminated | A or K | Move comments from block 18 to the Additional Information field. |

| restructuring | A or K | Move comments from block 18 to the Additional Information field. |

| seasonal work | A or K | Move comments from block 18 to the Additional Information field. |

| work shortage | A or K | Move comments from block 18 to the Additional Information field. |

| shutdown | A or K | Move comments from block 18 to the Additional Information field. |

| summer break / Summer job - contract ended | A or K | Move comments from block 18 to the Additional Information field. |

| lay off | A or K | Move comments from block 18 to the Additional Information field. |

| temporary shutdown/lay off | A or K | Move comments from block 18 to the Additional Information field. |

| 7 consecutive days without working | A or K | Move comments from block 18 to the Additional Information field. |

| casual | A or K | Move comments from block 18 to the Additional Information field. |

| name of show / film production | A or K | Move comments from block 18 to the Additional Information field. |

| change of payroll frequency | A or K | Move comments from block 18 and if the employer selected a RFS sub-option in block 16 , move that information as well. |

| change of ownership | A or K | Move comments from block 18 and if the employer selected a RFS sub-option in block 16 , move that information as well. |

| requested by Employment Insurance | A or K | Move comments from block 18 and if the employer selected a RFS sub-option in block 16 , move that information as well. |

| change of service provider | A or K | Move comments from block 18 and if the employer selected a RFS sub-option in block 16 , move that information as well. |

| bankruptcy | A or K | Move comments from block 18 to the Additional Information field. | RFS: Select A - Shortage of work / Employer Bankruptcy or Receivership . |

| employee requested | K | Move comments from block 18 to the Additional Information field. | RFS: Select K - Other / At the Employee's Request . |

| apprenticeship training info | C or J | Move comments from block 18 to the Additional Information field. | RFS: Select J - Apprentice training . |

| return to school with details indicating for apprenticeship training (e.g.: apprentice level or reference code ) | C or J | Move comments from block 18 to the Additional Information field. | RFS: Select J - Apprentice training . |

| return to school with NO apprenticeship training details provided | C or K | Delete comments from block 18 . | RFS: Select E - Quit / Return to school . |

| Queens Regulations/ Orders | K | Move comments from block 18 to the Additional Information field. | RFS: Select K - Other / Canadian Forces - Queen’s Regulations/Orders . |

| medical leave of absence | D, K or N | Move comments from block 18 to the Additional Information field. | RFS: Select D - Illness or injury . |

| unpaid medical leave | D, K or N | Move comments from block 18 to the Additional Information field. | RFS: Select D - Illness or injury . |

| illness or surgery related comment | D, K or N | Move comments from block 18 to the Additional Information field. | RFS: Select D - Illness or injury . |

| preventative withdrawal | D, F, K, N or E | Move comments from block 18 to the Additional Information field. | RFS: Leave as is. |

| quit without notice | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: Select E - Quit . |

| retirement | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: Leave as is. |

| resigned | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E - Quit . |

| personal reasons | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E - Quit . |

| job abandonment | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E - Quit . |

| with cause | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select M - Dismissal . |

| to go to another job | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E - Quit / Take another job . |

| to follow spouse | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E - Quit / Follow Spouse . |

| employer relocation | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E - Quit / Employer Relocation . |

| care for a dependant | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E - Quit / Care for a dependant . |

| to become self-employed | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E - Quit / To become Self-Employed . |

| voluntary retirement | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E RFS: select E - Quit / Voluntary Retirement . |

| health reasons | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E - Quit / Health Reasons . |

| return to school | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select E - Quit / Return to school . |

| attendance | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select M - Dismissal . |

| poor performance | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select M - Dismissal . |

| not suitable, etc. | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: select M - Dismissal . |

| did not pass the probationary period | K or M | Move comments from block 18 to the Additional Information field. | RFS: select M - Dismissal / Terminated within Probationary Period . |

| terminated within probationary period | K or M | Move comments from block 18 to the Additional Information field. | RFS: select M - Dismissal / Terminated within Probationary Period . |
```

```text
| If both of the following conditions are present | Then, in RCM ensure the ROE reflects the following: |

| Block 18 comments reflect: | Block 17A or 17C reflect: | Actions required: | Block 17A or 17C options: |

| vacation pay included/issued/remitted/paid in each pay | 17A includes an amount | Delete comments from block 18 . | 17A: Select Included with each pay (amount will be removed). |

| vacation pay included/issued/remitted/paid in each pay | 17C includes a vacation pay selection or an Other amount (similar to a vacation pay amount) and 17A does not | Delete comments from block 18 . | 17A: Select Included with each pay 17C: remove the amount shown. |

| vacation pay included/issued/remitted/paid in each pay | | Delete comments from block 18 . | |

| vacation pay or 17A included in 15B/15C PP1 | 17A includes an amount | Delete comments from block 18 . | 17A: Select Paid because no longer working . |

| vacation pay included in 15B/15C PP1 | 17C includes a vacation pay selection or an Other amount (similar to a vacation pay amount) and 17A does not | Delete comments from block 18 . | 17A: Select Paid because no longer working . 17A amount: Input amount shown in block 17C. 17C: Remove the amount shown. |

| vacation Pay = 4%, 6%, 8% etc. | 17A includes an amount | Delete comments from block 18 . | 17A: Select Paid because no longer working . |

| vacation Pay = 4%, 6%, 8% etc. | 17C includes a vacation pay selection or an Other amount ( similar to a vacation pay amount) and 17A does not | Delete comments from block 18 . | 17A: Select Paid because no longer working or as based on the comments provided . 17A amount: Input amount shown in block 17C . 17C: Remove the amount shown. |

| paid vacation leave period with precise dates | 17A includes an amount | Move comments from block 18 to the Additional Information field. | 17A: Select Paid for a vacation leave period . 17A date from: Input start of leave period. 17A date to: Input end of leave period. |

| paid vacation leave period with precise dates | 17C includes a vacation pay selection or an Other amount (similar to a vacation pay amount) and 17A does not | Move comments from block 18 to the Additional Information field. | 17A: Select Paid for a vacation leave period 17A date from: Input start of leave period. 17A date to: Input end of leave period. 17C: Remove the amount shown. |

| shutdown general vacation with precise dates | 17A includes an amount | Move comments from block 18 to the Additional Information field. | 17A: Select Paid for a vacation leave period . 17A date from: Input start of leave period. 17A date to: Input end of leave period. 17C: Remove the amount shown. |

| shutdown general vacation with precise dates | 17C includes a vacation pay selection or an Other amount (similar to a vacation pay amount) and 17A does not | Move comments from block 18 to the Additional Information field. | 17A: Select Paid for a vacation leave period . 17A date from: Input start of leave period. 17A date to: Input end of leave period. |

| anniversary vacation pay including anniversary date | 17A includes an amount | Move comments from block 18 to the Additional Information field. | 17A: Select Anniversary (Paid on a specific date each year) . 17A date from: Input anniversary date. |

| anniversary vacation pay including anniversary date | 17C includes a vacation pay selection or an Other amount (similar to a vacation pay amount) and 17A does not | Move comments from block 18 to the Additional Information field. | 17A: Select Anniversary (Paid on a specific date each year) . 17A date from: Input anniversary date. 17C: Remove the amount shown. |
```

```text
| If both of the following conditions are present | Then, in RCM ensure the ROE reflects the following: |

| Block 18 comments reflect: | Block 17 reflects: | Actions required: | Block 17 or block 19 options: |

| Statutory holiday paid for a specific holiday (e.g.: Christmas Day ) | 17B includes Stat Pay amount | Delete comments from block 18 . | 17B date from: Input statutory holiday date. |

| production Bonus | 17C includes Bonus amount | Delete comments from block 18 . | 17C: Select B - Bonus / Production/Incentive . |

| incentive Bonus | 17C includes Bonus amount | Delete comments from block 18 . | 17C: Select B - Bonus / Production/Incentive . |

| staying bonus | 17C includes Bonus amount | Delete comments from block 18 . | 17C: Select B - Bonus / Staying/Contract Complete/End of Season . |

| contract complete bonus | 17C includes Bonus amount | Delete comments from block 18 . | 17C: Select B - Bonus / Staying/Contract Complete/End of Season . |

| end of Season bonus | 17C includes Bonus amount | Delete comments from block 18 . | 17C: Select B - Bonus / Staying/Contract Complete/End of Season . |

| shutdown Bonus | 17C includes Bonus amount | Delete comments from block 18 . | 17C: Select B - Bonus / Closure . |

| closure Bonus | 17C includes Bonus amount | Delete comments from block 18 . | 17C: Select B - Bonus / Closure . |

| separation or Retirement | 17C includes Bonus amount | Delete comments from block 18 . | 17C: Select B - Bonus / Separation or Retirement . |

| holiday bonus with date provided (e.g.: Christmas Bonus ) | 17C includes Bonus amount | Delete comments from block 18 . | 17C: Select B - Bonus / Holiday . 17C Bonus From date: Input holiday date. |

| event bonus with date provided (e.g.: Signing of a contract ) | 17C includes Bonus amount | Delete comments from block 18 . | 17C: Select B - Bonus / Event . 17C Bonus date from: Input event date. |

| employee is entitled to SUB plan | | Delete comments from block 18 . | 17C: Select the appropriate option: U - Supplemental / SUB Maternity/Parental/Compassionate Care/Family caregiver benefits U - Supplemental / SUB Layoff U - Supplemental / SUB Illness U - Supplemental / Sub Training 17C Supplemental Payer Name: Leave this field blank. 17C Supplemental Meets Regulation 38: Do not check the box. |

| government Approved SUB plan | | Delete comments from block 18 . | 17C: Select the appropriate option: U - Supplemental/SUB Maternity/Parental/Compassionate Care/Family caregiver benefits U - Supplemental / SUB Layoff U - Supplemental / SUB Illness U - Supplemental / Sub Training 17C Supplemental Payer Name: Leave this field blank. 17C Supplemental Meets Regulation 38: Do not check the box. |

| pension details, including amounts $, dates etc . | None | Leave comments in block 18. | Leave this block blank. |

| monies on Separation detailed in block 18 . If any insurable separation monies are detailed, the ROE must clearly indicate that they are included in 15B/15C PP1 (e.g.: Severance of $5000.00 and PIL of $3000.00 paid on separation. PIL included in 15B ) . | | Move comments from block 18 to the Additional Information field. | 17C: Select the appropriate monies on separation from the drop-down menu, input amount and any other details required. |

| paid Sick Leave details including amount and date(s) | | Delete comments from block 18 . | 19: Select Paid Sick Leave . 19 Start Date: Input start date. 19 End Date: Input end date. 19 Amount($): Input amount. 19 Per Day/Per Week options: Select correct option . 19 Duration: Input duration. |

| paid Maternity/Parental/Compassionate Care/Family Caregiver Leave details including amount and date(s) | | Delete comments from block 18 . | 19: Select Paid Maternity/Parental/Compassionate Care/Family Caregiver . 19 Start Date: Input start date . 19 End date: Input end date . 19 Amount ($): Input amount . 19 Per Day/Per Week: Select the appropriate radio button. 19 Duration: Input duration. |

| wage Loss Indemnity including amount and date(s) with the information provided clearly indicating the amount is EI Insurable . | | Delete comments from block 18 . | 19: Select Wage Loss Indemnity (EI Insurable) . 19 Start Date: Input start date . 19 End date: Input end date . 19 Amount ($): Input amount . 19 Per Day/Per Week: Select the appropriate radio button. 19 Duration: Input duration. |

| wage Loss Indemnity including amount and date(s) with the information provided clearly indicating the amount is not EI Insurable . | | Delete comments from block 18 . | 19: Select Wage Loss Indemnity (Not EI Insurable) . 19 Start date: Input start date. 19 End date: Input end date. 19 Amount: Input amount. 19 Per Day/Per Week: Select the appropriate radio button. 19 Duration: Input duration. |

| wage Loss Indemnity amount $ and dates provided in Block 18 , but NOT in Block 19 , IF the information provided does not clearly show that the amount is or is not EI insurable . | | Leave information in block 18 . | |

| “no indication of special payment type is provided in block 19” appears in block 18 . | | Leave information in block 18 . | |
```

```text
| If the comments in block 18 reflect: | Then, in RCM ensure the ROE reflects the following: |

| Actions required: | Other block options: |

| amended ROE (including original ROE serial #) | Delete comments from block 18 . | For ROEs that start with the letter E: 2 - Serial # of ROE Amended or Replaced: Input amended serial number. For ROEs that start with the letter S, W or M: Move comment from block 18 to the Additional Information field. |

| return to work date provided | Delete comments from block 18 . | 14 - Expected Date of Recall: input expected date of recall. |

| recall date provided | Delete comments from block 18 . | 14 - Expected Date of Recall: input expected date of recall. |

| comments that have no impact on calculation or entitlement such as: - Rate info (e.g.: Rate is $X.XX / hour ) - Personal Comments (e.g.: Good luck Larry ) - Other Comments (e.g.: Will return when work is available ) | Delete comments from block 18 . | |
```

```text
| Both conditions must be met: | In RCM, complete the following fields: |

| Block 18 comments reflect that the RFS is related to one of the following reasons: | Block 16 RFS option is: | Actions required: | Block 16 RFS option: |

| Coronavirus, COVID-19 or quarantine | A, D, K or N | Move comments from block 18 to the Additional Information field. | Any required changes will be made in the ROE RFS Action WI in NWS. |
```

```text
| If both of the following conditions are present on the ROE: | Then, in RCM ensure the ROE reflects the following: |

| Block 18 comments reflect: | Block 16 RFS option reflects: | Actions required: | Block 16 RFS option: |

| shortage of work or employer-initiated business closure related to the Coronavirus or COVID-19 | A | Move comments from block 18 to the Additional Information field. | RFS: Select A - Shortage of work / End of contract or season . |

| illness or quarantine related to the Coronavirus or COVID-19 | D, K or N | Move comments from block 18 to the Additional Information field. | RFS: Select D - Illness or injury . |

| client refuses to attend work due to the Coronavirus or COVID-19 | E, K or M | Move comments from block 18 to the Additional Information field. | RFS: Select E - Quit / Health Reasons . |

| COVID-19, Coronavirus or the employee requested the ROE due to COVID-19 | K | Move comments from block 18 to the Additional Information field. | RFS: Select A - Shortage of work / End of contract or season . |
``` 

### Note

Source topic: `en_EN/common_notes/note_c_0952.dita`

Note:

For comments in block 18 of an Air Canada ROE SAT, the officer refers to Major Employer Events (MEE) — Information Bulletin .
       [Major Employer Events (MEE) — Information Bulletin](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68)

     [Major Employer Events (MEE) — Information Bulletin](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68) 

### Note

Source topic: `en_EN/common_notes/note_c_0953.dita`

Note:

In order to remove the comments, the comments must match the conditions indicated in the table. 

### Warning

Source topic: `en_EN/common_notes/note_c_0954.dita`

Warning:

For RFS related comments, it is important to determine if there is an outstanding ROE RFS Action WI for the same ROE and select the applicable table.

If there is an outstanding ROE RFS Action WI for the same ROE, do not modify block 16 in RCM unless directed by this procedure. If required, the RFS details are modified in NWS in the ROE RFS Action WI. 
