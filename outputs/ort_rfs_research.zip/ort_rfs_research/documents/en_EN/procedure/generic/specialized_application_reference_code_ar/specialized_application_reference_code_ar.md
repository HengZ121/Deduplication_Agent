# Specialized application: Reference code — Instructions

Source map: `en_EN/procedure/generic/specialized_application_reference_code_ar/specialized_application_reference_code_ar.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/specialized_application_reference_code_ar/generic.dita`

Table of contents

- What you need to know

- Reference code structure
             [Reference code structure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Reference_cCode_sStructure)

- Validity period and tentative BPC
             [Validity period and tentative BPC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Validity_period_and)

- Automotive industry

- Client’s attestation on a specialized application for an automotive industry claim
                 [Client’s attestation on a specialized application for an automotive industry claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Client’s_attestation_on_automotive)

- Creating a 4 - Automotive reference code
                 [Creating a 4 - Automotive reference code](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Creating_a_4)

             [Automotive industry](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#AutomotiveIndustry)

- Apprenticeship

- Client’s attestation on a specialized application for an apprenticeship claim
                 [Client’s attestation on a specialized application for an apprenticeship claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Client’s_attestation_on_apprenticeship)

- Creating a 2 - Apprentice reference code
                 [Creating a 2 - Apprentice reference code](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Creating_a_2)

             [Apprenticeship](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#Apprenticeship)

- Short-term mass layoff

- Client’s attestation on a specialized application for a short term mass layoff claim
                 [Client’s attestation on a specialized application for a short term mass layoff claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Client’s_attestation_on_short_term)

- Creating a 1 - Short-term mass layoff reference code
                 [Creating a 1 - Short-term mass layoff reference code](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Creating_a_1)

             [Short-term mass layoff](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#ShortTermMassLayoff)

- Work-Sharing (WS)

- Client’s attestation on a specialized application for a Work-Sharing (WS) claim
                 [Client’s attestation on a specialized application for a Work-Sharing (WS) claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Client’s_attestation_on_ws)

- Creating a 3 - Work sharing reference code
                 [Creating a 3 - Work sharing reference code](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Creating_a_3)

- Unique identifier
                 [Unique identifier](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Unique_identifier)

- Validity period of the reference code

- Activation date
                     [Activation date](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Activation_date)

- Expiration date
                     [Expiration date](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Expiration_date)

                 [Validity period of the reference code](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Validity_period_of)

- Employee additions
                 [Employee additions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Employee_additions)

             [Work-Sharing (WS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#WorkSharing)

         [What you need to know](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_What_you_need)

- Step by step
         [Step by step](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#_Step_by_step)

**What you need to know**

Reference codes give the client access to one of 4 specialized applications. The specialized application differs from the regular application as it is customized to gather information from the client in the following situations:

- a shortage of work in the automotive industry ;
         [automotive industry](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#AutomotiveIndustry)

- a referral to an apprenticeship ;
         [apprenticeship](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#Apprenticeship)

- a short-term mass layoff ;
         [short-term mass layoff](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#ShortTermMassLayoff)

- participation in a Work-Sharing (WS) agreement.
         [Work-Sharing (WS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/specialized_application_reference_code_ar#WorkSharing)

Using reference codes on the application creates some limitations for clients:

- Clients can request only regular benefits on the application. Clients requesting special benefits cannot complete the specialized application.

- Client information is not shared with designated authorities for referrals to employment measures under EIA 25.

When a reference code is issued for situations other than the ones they were designed for, the limitations can negatively affect clients. Therefore, regional issuers create reference codes only for situations defined in this document.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0933.dita) 

A reference code is valid for a specific period. To access the specialized applications, the reference code must be used between the activation date and the expiration date. A client who tries to access a specialized application outside of this period receives a warning message and can only submit an application for regular benefits if the reference code is invalid.

**Reference code structure**

Reference codes are created on the Admin tab in NWS. Each reference code is composed of 16 digits. The reference code consists of the 4 digits of the Service Canada Centre (SCC) where it was issued, followed by 2 digits identifying the type of reference code and 10 digits specific to the type of specialized application.

The system populates digits 1 to 4 of the reference code based on the SCC field selection and digits 5 and 6 based on the Specialized application field selection. The issuer inputs digits 7 to 10 in the Unique identifier field and digits 11 to 16 in the End digits field.

The following table summarizes this information.

```text
| Specialized application | SCC field Digits 1 to 4 | Specialized application field Digits 5 and 6 | Unique Identifier field Digits 7 to 10 | End digits field Digits 11 to 16 |

| Short-term mass layoff | SCC | 01 | Year of issue | Year and month of expiry |

| Automotive industry | 04 |

| Apprenticeship | 02 | Regional use |

| Work-Sharing | 03 | Regional use | w/c of agreement start date and duration of agreement in weeks |
```

**Validity period and tentative BPC**

Clients can use a reference code during the period between the dates indicated in the Activation date and Expiration date fields. Reference codes for specialized applications other than WS have broad validity periods that relate to the length of an event or program. WS reference codes have validity periods of up to 8 weeks. Reference codes expire at midnight (Eastern Standard Time) on the date indicated in the Expiration date field.

Specialized applications for WS are established with a tentative BPC equal to digits 11 to 14 of the reference code. Tentative BPCs for other specialized applications follow the conditions for regular benefits claims.

**Automotive industry**

Employees in the automotive industry are usually laid off for short periods and are allowed to complete a specialized application through AW using a reference code. This format requires minimal information from the client. There are no questions about other employers or other monies.

A reference code for a layoff in the automotive industry is normally created with a 4 - Automotive code. However, if the client must provide information about other monies paid, a 1 - Short-term mass layoff code can be used.

The reference code must be used when there is an expected return to work (RTW) date. If the duration of the layoff is uncertain or undetermined, a 4 - Automotive or a 1 - Short-term mass layoff is not created . The expected RTW date may change or the temporary layoff may become permanent, however, it is important that there is an expected RTW date when creating the reference code.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0934.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0935.dita) 

**Client’s attestation on a specialized application for an automotive industry claim**

When completing the specialized application, the client is presented with an attestation indicating that the client:

- is applying for regular benefits;

- is not working for the last employer due to a temporary layoff;

- is ready, willing and capable of working during the layoff period;

- would accept employment in the same type of work and wages as in the usual occupation or other suitable employment for which the client has the necessary skills.

**Creating a 4 - Automotive reference code**

The 4 - Automotive reference code conforms to the following criteria:

```text
| Digit position | Description | NWS input |

| 1 to 4 | SCC | SCC field selection |

| 5 and 6 | 04 (specialized application code for an automotive claim) | Specialized application field selection |

| 7 to 10 | Year (if the reference code is valid for 2 years, the regional issuer uses the year the reference code was created) | Unique identifier field |

| 11 to 16 | Year and month the reference code expires | End digits field |
```

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0936.dita) 

**Apprenticeship**

Clients referred to an apprenticeship by a designated authority receive a reference code to complete a specialized application through AW.

On the application, clients must provide the following information:

- Course name

- Course level

- Course identification number

- Course start date

- Course end date

- Name of the learning establishment

- The client can also choose to be exempt from completing claimant’s reports.

Two questions are modified on the apprenticeship application:

- Will you be returning to work the week following the end of your course with this employer?

- Are you self-employed or working for an employer other than the employer that is sending you on the Apprenticeship program?

**Client’s attestation on a specialized application for an apprenticeship claim**

When completing the specialized application, the client is presented with an attestation indicating that the client:

- is applying for regular benefits;

- is temporarily not working full-time, or only working part-time for the last employer, as the client is required to take an apprenticeship course or program.

**Creating a 2 - Apprentice reference code**

The 2 - Apprentice reference code conforms to the following criteria:

```text
| Digit position | Description | NWS input |

| 1 to 4 | SCC | SCC field selection |

| 5 and 6 | 02 (specialized application code for an apprentice claim) | Specialized application field selection |

| 7 to 10 | Year (if the reference code is valid for 2 years, the regional issuer uses the year the reference code was created) | Unique identifier field |

| 11 to 16 | Free text for identification (e.g. year) | End digits field |
```

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0937.dita) 

**Short-term mass layoff**

The 1 - Short-term mass layoff reference code was designed for short-term mass layoffs in any industry that is not related to the automotive industry.

For short-term mass layoffs, the expected RTW date and the period of time the employees will be off work are known. If the duration of the layoff is uncertain or undetermined, a 1 - Short-term mass layoff reference code is not created . The expected RTW date may change or the temporary layoff may become permanent, however, it is important that there is an expected RTW date when creating the reference code.

Of all the specialized applications, the one for short-term mass layoffs is the most similar to a normal application.

After consulting with the regions and the workload managers, it was decided that a 1 - Short-term mass layoff reference code should no longer be issued in situations other than exceptional layoff situations in the automotive industry. This decision was made because the application is not much different from the regular application and most claims can be automated.

**Client’s attestation on a specialized application for a short term mass layoff claim**

When completing the specialized application, the client is presented with an attestation indicating that the client:

- is applying for regular benefits;

- is not working for the last employer due to a temporary layoff and is not working for another employer;

- is ready, willing and capable of working during the layoff period;

- would accept employment in the same type of work and wages as in the usual occupation or other suitable employment for which the client has the necessary skills.

**Creating a 1 - Short-term mass layoff reference code**

The 1 - Short-term mass layoff reference code conforms to the following criteria:

```text
| Digit position | Description | NWS input |

| 1 to 4 | SCC | SCC field selection |

| 5 and 6 | 01 (specialized application code for a short-term mass layoff claim) | Specialized application field selection |

| 7 to 10 | Year (if the reference code is valid for 2 years, the regional issuer uses the year the reference code was created) | Unique identifier field |

| 11 to 16 | Year and month the reference code expires | End digits field |
```

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0938.dita) 

**Work-Sharing (WS)**

The regional EI WS coordinator is responsible for issuing WS reference codes. A reference code is required when an agreement is implemented and when additional clients are added to an already implemented WS agreement. Employees participating in a WS agreement receive a 3 - Work-Sharing reference code through the Applying for Employment Insurance Work-Sharing Benefits — Template and must complete a specialized application through AW using this reference code during the validity period.
       [responsible](http://edsc.prv/en/service-canada/ei/reference-material/ipos/work-sharing/ws-roles-responsabilities.shtml) 
       [Applying for Employment Insurance Work-Sharing Benefits — Template](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_en.docx)

The date the client is added to an agreement (at the implementation date or later) is determined by the program officer. The w/c of this date is entered by the issuer in the End digits field and relates to digits 11 to 14 of the reference code. ACP uses this date to populate the Start date field of the Project Data — Work-Sharing (M171) and to determine the tentative BPC or renewal week.

The issuer also enters the duration of the agreement in weeks in the End digits field. These last 2 digits relate to digits 15 and 16 of the reference code. ACP determines the end date on the M171 by adding the start date and duration and subtracting 1.

**Client’s attestation on a specialized application for a Work-Sharing (WS) claim:**

When completing the specialized application, the client is presented with an attestation indicating that the client:

- is applying for regular benefits;

- is continuing to work for his last employer under a reduced work week.

**Creating a 3 - Work sharing reference code**

The 3 - Work sharing reference code conforms to the following criteria:

```text
| Digit position | Description | NWS input |

| 1 to 4 | SCC | SCC field selection |

| 5 and 6 | 03 (specialized application code for a WS claim) | Specialized application field selection |

| 7 to 10 | Unique identifier (4 digits that cannot start with 0 based on regions’ format) [Unique identifier](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#UniqueIdentifier) | Unique identifier field |

| 11 to 14 | W/c of the start date (the week the agreement is implemented, or the week in which additional employees are added to an already implemented agreement) | First 4 digits of End digits field |

| 15 and 16 | Duration of WS agreement | Last 2 digits of End digits field |
```

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0939.dita) 

The system sends an initial M171 based on the reference code and AW. The fields in the transaction are prefilled as follows:

- Start date: digits 11 to 14

- End date: project start date + digits 15 and 16 – 1

- Project SCC: digits 1 to 4

- Project Number: interim value corresponding to digits 1 to 10

- Weekly hours: hours reported by the client in AW

**Unique identifier**

The unique 4-digit identifier is assigned to a specific WS agreement and differentiates the reference code from other WS reference codes with similar digits (i.e. same region, start date and duration). Use of the unique identifier varies by region.

A specific range of numbers may be assigned to each reference code issuer according to each region (e.g. issuer 1 could be assigned 1111 to 1999). This allows the issuer to go through the range of numbers sequentially while also ensuring that other issuers do not create a duplicate unique identifier. Alternatively, regions may use the unique identifier to indicate which officer will receive all WIs associated with a particular WS agreement (e.g. officer 1 could be designated by 1000 ). A combination of the 2 uses is also possible (e.g. the issuer can be identified by the first 2 digits of the reference code and the officer by the last 2 digits).

In NWS, Specialized Application (SA) WIs can be assigned to an officer’s workload by selecting specific reference codes in the Reference codes field in the Claim trip downs — Specialized application section of the Work Details tab of the officer’s profile. All reference codes in NWS are listed in that field. It may be useful to identify the officer who will receive the WIs using the unique identifier to help find the appropriate reference code.

**Validity period of the reference code**

For a WS reference code, the issuer enters a validity period of 8 weeks from the date the agreement is implemented, or in the case of an employee addition to an already implemented agreement, from the date the client is being added to that agreement. Therefore, the validity period is the 8-week period following the agreement start date for the client. The issuer enters the validity period by inputting dates in the Activation date and Expiration date fields.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0940.dita) 

If a client applies after this period, AW does not permit the use of the expired reference code. The client can then only apply for regular benefits, and must select WS as the reason for separation (RFS). In this situation, normal calculation logic is used to determine the BPC or renewal week and the officer must manually input the M171. If the client wants the claim to start at an earlier date, the client must request an antedate.

**Activation date**

The system prevents the issuer from choosing the current date or earlier:

- The date indicated in the Activation date field is tomorrow’s date.

**Expiration date**

The reference code is valid for up to 8 weeks from the start date. The issuer determines the expiration date by adding 8 weeks to the start date (digits 11 to 14 of the reference code):

- The date indicated in the Expiration date field is the Sunday of the w/c corresponding to the start date + 8 weeks.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0941.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0942.dita) 

**Employee additions**

An employer can add employees to an already implemented WS agreement. A new reference code is required for each group of employees added to the WS agreement in a particular week. Existing reference codes cannot be given to clients with different agreement start dates, even if they are still valid.

Digits 11 to 14 of the reference code reflect the w/c in which the additional employees are added to the agreement because the reference code determines the tentative BPC or renewal week and the information input in the Start date field on the M171.

The duration of the agreement indicated by digits 15 and 16 is adjusted to reflect the time remaining in the agreement.

The 8-week validity period for employee additions is determined in the same way as for new agreements.

**Step by step**

- In NWS, select the Admin tab, then select Reference Code .

- SCC: Select the appropriate SCC.

- Select Create and enter the following:

- English name: Enter a name for the reference code (that will be displayed in the reference code search results list) as follows:

- For WS reference codes, enter the name of the WS employer.

- For the automotive industry or a short-term mass layoff, enter a description of the event.

- For apprenticeship, enter the name of the apprenticeship program.

- French name: Enter the respective French name where necessary or make the same entry as in the English name field when a translation does not apply.

- Specialized application type: Select the appropriate specialized application type.

- Unique identifier: Enter the 4-digit number based on the use of the region.

- End digits: Enter the 6-digit number based on the type of reference code being issued:

- For WS, enter the 4 digits of the w/c of the start date. Digits 5 and 6 are the duration of the WS agreement, or the number of weeks the employee will be participating in the WS agreement. It must be 2 digits (e.g. 9 weeks is entered as 09).

- For the automotive industry or a short-term mass layoff, enter the year followed by the 2-digit month in which the reference code will expire.

- For apprenticeship, enter unique digits for identification.

             [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0943.dita)

- Activation date: Select the appropriate option:

- For a WS agreement, select tomorrow’s date.

- For any other specialized application, select the start or effective date of the event.

- Expiration date: Select the appropriate option:

- For a WS agreement, select the Sunday of the w/c of the start date + 8 weeks.

- For any other specialized application, select the end date of the event.

             [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0944.dita)

- English description: Select the appropriate option:

- For a WS agreement, copy and paste the agreement information from the Employer Template. Do not copy and paste the SIN list.

- For any other specialized application, enter any relevant details or instructions.

- French description: Leave this field blank.
             [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0945.dita)

- Select Save to obtain the newly created reference code. 

### Note

Source topic: `en_EN/common_notes/note_c_0933.dita`

Note:

The level and designation of the regional issuer varies across regions. 

### Example

Source topic: `en_EN/common_notes/note_c_0934.dita`

Example:

A company is forced to layoff some employees due to a labour dispute in the United States, which impacts delivery of materials. As it is uncertain when the labour dispute will end and when employees will return to work, the limitations in using the reference code negatively affect the client and so they must use the normal application process. 

### Note

Source topic: `en_EN/common_notes/note_c_0935.dita`

Note:

As the vast majority of automotive industries are located in Ontario, the Ontario region processes all automotive claims for Canada. 

### Example

Source topic: `en_EN/common_notes/note_c_0936.dita`

Example:

3515042022202201 

### Example

Source topic: `en_EN/common_notes/note_c_0937.dita`

Example:

1955022022202201 

### Info

Source topic: `en_EN/common_notes/note_c_0938.dita`

Example:

2371012022202212 

### Example

Source topic: `en_EN/common_notes/note_c_0939.dita`

Example:

4812032018215826 

### Note

Source topic: `en_EN/common_notes/note_c_0940.dita`

Note:

When the request to issue a reference code is provided to the Regional EI WS Coordinator after the start date of the agreement, the validity period will be less than 8 weeks. Reference codes cannot be issued if a request is received more than 8 weeks after the agreement start date. 

### Note

Source topic: `en_EN/common_notes/note_c_0941.dita`

Note:

Reference codes expire at midnight (Eastern Standard Time). When a reference code is issued for a client who lives west of this time zone, the reference code issuer adds 1 day to the validity period, but does not reference this extra day in the Applying for Employment Insurance Work-Sharing Benefits — Template .
       [Applying for Employment Insurance Work-Sharing Benefits — Template](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_en.docx)

     [Applying for Employment Insurance Work-Sharing Benefits — Template](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_en.docx) 

### Note

Source topic: `en_EN/common_notes/note_c_0942.dita`

Note:

The distribution of the reference code to clients is a responsibility of the parties to the WS agreement (i.e. Service Canada, the employer and employee representatives). New reference codes are not issued to clients who did not receive a reference code at the same time as other participants. As long as the reference code is still valid and their participation in the WS agreement started in the same week, the client uses the same reference code. 

### Note

Source topic: `en_EN/common_notes/note_c_0943.dita`

Note:

For WS reference codes, it is important to complete this field correctly, as ACP uses this information to establish the BPC and input project data on the claim. 

### Note

Source topic: `en_EN/common_notes/note_c_0944.dita`

Note:

Reference codes expire at midnight (Eastern standard time). When a reference code is issued for clients who live west of this time zone, add 1 day to the validity period, but do not reference this extra day in the Applying for Employment Insurance Work-Sharing Benefits — Template .
       [Applying for Employment Insurance Work-Sharing Benefits — Template](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_en.docx)

     [Applying for Employment Insurance Work-Sharing Benefits — Template](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_en.docx) 

### Note

Source topic: `en_EN/common_notes/note_c_0945.dita`

Note:

In the Quebec region, the description fields are left blank. The information is available in the Work-Sharing Reference tool. 
