# Sickness: Incapacity start date — Table

Source map: `en_EN/procedure/generic/additionalresources/incapacity_start_date_sb/incapacity_start_date_sb.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/incapacity_start_date_sb/additional_resources.dita`

Clients must obtain, at their own expense, an acceptable medical certificate that covers every week they request sickness benefits. The medical certificate must show that a client is unable to work because of illness, injury or quarantine. In some cases, the client must submit the medical certificate with the claim. For more information, the officer refers to Determining if a medical certificate must be submitted: Sickness benefits — Initial claims or Determining if a medical certificate must be submitted — Renewal and continuing claims .
       [Determining if a medical certificate must be submitted: Sickness benefits — Initial claims](/en/procedure/task/calc_determining/det_mc_ra.shtml) 
       [Determining if a medical certificate must be submitted — Renewal and continuing claims](/en/procedure/task/determining_med_cert_req.shtml)

If the reason for separation (RFS) is D - Illness or injury on an initial or renewal claim and no medical certificate needs to be submitted, the incapacity start date is the week of the BPC or the renewal week. This applies even if the client submits a medical certificate when it does not need to be submitted. For a conversion from regular to sickness benefits when no medical certificate needs to be submitted, the incapacity start date is the conversion week.

In all other situations, if an incapacity start date is required, the officer determines the date using the information on the medical certificate. If there is a specific incapacity start date on the medical certificate, the incapacity start date is the Sunday of the week in which the doctor or other medical professional indicates that the client was unable to work for medical reasons.

If no specific incapacity start date is provided, the incapacity start date is the Sunday of whichever week is the earliest:

- the week the doctor or other medical professional signed the medical certificate;

- the week of the medical consultation.

The officer determines the incapacity start date and uses the incapacity start week to then determine the recovery week.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0470.dita) 

If the client submits a medical certificate for an extension of sickness benefits and the medical certificate does not indicate that the initial period of sickness is continuing, another medical certificate indicating an incapacity start date is required to continue the payment of benefits immediately after the recovery week on the claim.

If the incapacity start date, signature date or the date of the medical consultation is not indicated, the medical certificate is not acceptable. For more information, the officer refers to Determining if a medical certificate is acceptable .
       [Determining if a medical certificate is acceptable](/en/procedure/task/determining_med_cert_valid.shtml)

```text
| Conditions | Incapacity start date required |

| One of the following disqualifications or disentitlements applies, whether imposed because of a contentious RFS being adjudicated or deferred: - 10 - Dismissal - misconduct proven - 11 - Voluntary leaving - just cause not proven - 42 - Suspension from employment - 43 - Leave of absence - 44 - Anticipated loss of employment | Yes |

| The RFS is other than D and a 46 - Variable entrance requirement not met - special benefits payable disentitlement (D46) applies. A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, a D46 is not input on these claims. | Yes |

| Conversion to sickness benefits during or after receiving maternity benefits, parental benefits or CCB | Yes |

| Conversion from regular benefits to sickness benefits when regular benefits are exhausted | Yes |

| The RFS is D and no medical certificate must be submitted on an initial or renewal claim. | No (The incapacity start date is the BPC or the renewal week.) |

| A medical certificate has been submitted for a subsequent period of incapacity and the medical certificate does not indicate that the initial sickness is continuing. | Yes Note: In this case, to receive sickness benefits for the period immediately following the initial recovery week, the client must provide another medical certificate that covers the gap and includes an incapacity start date. |

| All other situations | No |
``` 

### Example

Source topic: `en_EN/common_notes/note_c_0470.dita`

Example:

The medical certificate was signed by the doctor on Wednesday, March 12, 2025 (w/c 2490-3) and no specific incapacity start date was provided. Therefore the incapacity start date is Sunday, March 9, 2025. When calculating the recovery week, the officer uses w/c 2490 as the incapacity start week. 
