# Purge and recreate: Information on purging claims, EDS reports and APRS trailers — Input guide

Source map: `en_EN/procedure/generic/additionalresources/purge_recreate_knowledge/purge_recreate_knowledge.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/purge_recreate_knowledge/additional_resources.dita`

- Purging a claim
         [Purging a claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#EDSReports)

- P/R reports in EDS
         [P/R reports in EDS](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#PRreportsin) 
         [#eierb_trailers](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#eierb_trailers)

- Special benefit trailers

- Special benefit trailers requiring modifications
             [Special benefit trailers requiring modifications](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#Specialbenefittrailers)

- QPIP trailers
             [QPIP trailers](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#QPIPtrailers)

- CCB trailer set-up and modification
             [CCB trailer set-up and modification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#CCBtrailersetup)

- Family caregiver benefits trailer set-up and modification
             [Family caregiver benefits trailer set-up and modification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#Family_caregiver_benefits)

- Self-employed special benefit trailers
             [Self-employed special benefit trailers](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#Selfemployedspecialbenefits)

         [Special benefit trailers](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#Specialbenefittrailers1)

- Employment initiative trailers

- Non-referred training
             [Non-referred training](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#non_referredtraining)

- Referred training
             [Referred training](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#referredtraining)

- Apprenticeship
             [Apprenticeship](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#apprenticeship)

- Self-employment benefits program
             [Self-employment benefits program](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#selfemploymentbenefitsprogram)

- Job creation program
             [Job creation program](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#jobcreationprogram)

- Work-Sharing (WS)
             [Work-Sharing (WS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#work-sharing-ws)

         [Employment initiative trailers](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#employmentinitiativetrailers)

- Seasonal workers
         [Seasonal workers](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#seasonal-workers)

- Claim successfully recreated
         [Claim successfully recreated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#Claimsuccessfullyrecreated)

- Claim recreated with errors or omission

- Online transactions
             [Online transactions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#Onlinetransactions)

- Re-purge required
             [Re-purge required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#Repurgerequired)

         [Claim recreated with errors or omission](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/purge_recreate_knowledge#Claimrecreatedwitherror)

**Purging a claim**

There are 2 transactions in FTS that purge an active or dormant non-blocked claim from CPS:

- Purge and Recreate adjustment (Used by IPOC) (M101-8): For purging one SIN at a time.

- Multiple Files Control Data type 8 - Purge and Recreate - adjustment (T111-8): For purging multiple SINs at the same time.

There are situations in which, instead of purging the claim, the IPOC officer must use the Computer Pay System claim cancellation (M101-5) or the T111 type 5 - Computer pay system - claim cancellation (T111-5) transaction to make the claim status 8 - Converted to Manual Pay . These include, but are not limited to the following:

- Action on a skeleton claim.

- Postdate (when weeks have been paid between the old and new BPC).

- Previous postdate completed on CPS.

**P/R reports in EDS**

The following is a list of reports used during P/R:

```text
| Report name | Description |

| SD5442 [SD5442](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#SD5442) | P/R worksheet |

| SD5641 [SD5641](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#SD5641) | DIST-0080 and 0090 claims pay status reports (CPSRs) |

| SB1641 [SB1641](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#SB1641) | Claimants on MPS (MPS tax file amounts) |

| SR1041 [SR1041](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#SR1041) | Error list (APRS rejects) |

| SD5641SR10 [SD5641SR10](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#SD5641SR10) | Mini verification CPSRs (DIST-0008, 0078, 0508 and 0578) |
```

**SD5442 (P/R worksheet)**

The P/R worksheet is a replication of all the claim data of a purged claim as it appears in APRS. The IPOC officer uses this worksheet to map out the changes needed on the claim and to track modifications that must be entered in APRS. An electronic version of this worksheet is also available.

**SD5641 (DIST-0090 and DIST-0080)**

The DIST-0090, like the P/R worksheet, displays all claim information at the time the claim is purged, but in the traditional CPSR format.

The DIST-0080 is generated when a recreated claim is successfully returned to CPS. The DIST-0080 shows the new information as entered on the claim in APRS. It is identical to the information shown on the claim in FTS.

**SB1641 (Claimants on MPS)**

When a claim is purged from CPS, all year-to-date amounts move from CPS to MPS and appear on the MPS Tax file. When the IPOC Purge & Recreate WI requires claim changes in APRS that affect the year-to-date amounts, the IPOC officer must manually adjust the tax file before recreating the claim back in CPS. If a claim is processed in APRS but the MPS tax file is not accurate, it results in a tax error.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0547.dita) 

**SR1041 (Error list)**

If an IPOC officer attempts to return a claim to CPS but the edit requirements are not met, an Error list is generated instead of the Mini, and additional modifications are required in APRS. The Error list provides the appropriate error codes, which are described in WECS. When searching for the error code description in WECS, the IPOC officer types “S” before the 3-digit code. For more information on WECS, the IPOC officer refers to Web Error Code System (WECS) .
       [Web Error Code System (WECS)](http://wecs-siew.prv/home_e.aspx)

**SD5641SR10 (Mini)**

The Mini provides a preview of the results of the anticipated manual update if inputs such as a Renewal/Revised (M106) transaction are completed in CPS.

The following chart describes each Mini distribution number.

```text
| Mini 0008 | The proposed result will not create a new overpayment (OP) or issue an underpayment (UP) if the M106 is input, but may result in an OP reversal or other claim changes. |

| Mini 0078 | The proposed result is the creation of an OP on the claim if the M106 is input. |

| Mini 0508 | The proposed result is the creation of an UP on the claim if the M106 is input. |

| Mini 0578 | The proposed result is the creation of both an OP and an UP if the M106 is input. |
```

The Mini number alone is insufficient in determining the accuracy of the recreated claim. The Mini must be thoroughly reviewed and, at times, compared with the DIST-0080.

When the claim changes are valid and entered correctly in APRS, the results of the Mini should match the expectations of the IPOC officer. The IPOC officer analyses any unexpected claim changes on the Mini and create a plan for potential corrective action to resolve the issue. For example, the IPOC officer reviews the tax year associated with the establishment or the adjustment of an OP on the Mini. The establishment of an OP with an invalid tax year is not rejected on the SR1041 (Error list). Therefore, the IPOC officer identifies this unexpected result and corrects the file before recalculating the claim to avoid the establishment of an incorrect OP in PSCD.

**Special benefit trailers**

Officers refer to the following special benefit charts, if necessary:

**Special benefit trailers requiring modifications**

```text
| EI Special BT | APRS trailers and card columns | Changes required | Additional actions |

| Maternity | TC80-2: EDC (card column 23) ADC (card column 27) MAT ST (card column 31) MAT END (card column 35) MAT EXT (card column 39) MAT WKS (card column 40) | - To change the maternity start or end, enter the w/c and, if required, complete the MAT EXT field. - If maternity benefits are still being paid, the MAT END field remains EDC or ADC + 17 weeks (whichever option creates the greater range). - If fewer than 15 weeks of maternity benefits are payable and entitlement is reached before EDC or ADC + 17, enter the w/c of the last maternity week payable in the MAT END and enter MAT EXT code 2 - End week deferred . - If maternity entitlement is reached, the end is the w/c of the last week of maternity benefits paid. | For additional information on the APRS trailers, refer to Purge and Recreate Trailer List . [Purge and Recreate Trailer List](http://wecs-siew.prv/wecs-siew/reflookup_e.aspx) |

| Parental | TC80-1: SEX (card column 70) TC80-2: ACT (card column 42) PAR ST (card column 46) PAR END (card column 50) PAR WKS (card column 54) PAR ENT (card column 56) PAR IND (card column 58) TC81-2: EXT PAR (card column 92) | Complete or amend the parental start week as follows: - For a new parental claim, enter the w/c of the BPC. - For a BPC renewed for parental benefits, enter the w/c of the renewal. - If maternity benefits have been paid in full and parental benefits should immediately follow, enter the w/c following the last week of maternity paid. - If maternity benefits are still being paid and parental benefits should immediately follow, type “9999.” Complete or amend the parental end week as follows: - For ongoing parental entitlement, enter the arrival or placement week + 52 weeks (if extended parental code is blank [TC81-2 cc 92]) or 78 weeks (if extended parental code is 1) + type H extension + BP extension for special benefits. The BP extension for special benefits only applies once the initial BP end has been reached. - If parental entitlement is reached, the end is the w/c of the last week of parental benefits paid. - If parental entitlement has not been reached but the claim is renewed for another BT, enter the w/c before the renewal and select code 3 - Parental terminated in the PAR IND field. - If the parental start week is 9999, type “9999” for the parental end week. If no parental benefits have been paid but the PAR ENT field is completed, type “00” in the PAR WKS field. If a BP extension for special benefits applies and the initial BP end has been reached, select code 5 - Parental duration/maximum special and extend the parental end week by the appropriate number of weeks. If extended parental benefits apply select 1 in the Extended Parental Benefits field. If a reversion from extended parental benefits to standard parental benefits applies, leave the Extended Parental benefits field blank. | When the claim is paying or has paid parental benefits, the gender code must be one of the following: - 5 - Parental, adoptive father - 6 - Parental, adoptive mother - 7 - Parental, natural father - 8 - Parental, natural mother Once the gender code is changed for parental benefits, the code remains for the duration of the claim regardless of the BT being paid. If code 5 is entered in the PAR IND (card column 58) field on the TC80-2 trailer, enter the appropriate information in the corresponding MS (card column 88) field and the new BP END (card column 14) on the TC81-2 trailer. Refer to Benefit period extension for special benefits . [Benefit period extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml) For additional information on the APRS trailers, refer to Purge and Recreate Trailer List . [Purge and Recreate Trailer List](http://wecs-siew.prv/wecs-siew/reflookup_e.aspx) [Benefit period extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml) [Purge and Recreate Trailer List](http://wecs-siew.prv/wecs-siew/reflookup_e.aspx) |

| Sickness | TC80-2: SCK WKS (card column 59) REC WK (card column 61) CAS SCK (card column 89) | When a claim is paying sickness benefits but is scheduled to automatically switch to maternity benefits at the maternity start week, type “9999” in the REC WK field. When weeks of casual sickness benefits have been paid, enter the number of weeks paid. The counter in the CAS SCK field must be blank or display a number from 1 to 8 to reflect the equivalent number of weeks of casual sickness benefits paid that were originally processed on w/c 2385-5 or later. | For additional information on the APRS trailers, refer to Purge and Recreate Trailer List . [Purge and Recreate Trailer List](http://wecs-siew.prv/wecs-siew/reflookup_e.aspx) |

| CCB | TC81-1: CC WKS (card column 111-112) TC86-4: WEEK PROC (card column 15) DY (card column 45) MED CERT (card column 46) STRT (card column 56) END (card column 60) ENT (card column 64) MOD (card column 66) | When CCB has been paid or is payable, a TC86-4 trailer is required to establish the full 52-week CCW and entitlement. Additional TC86-4 trailers are created with each change to entitlement or as the client switches between CCB and another BT. A TC86-4 trailer is not required when a 53 - No medical proof disentitlement prevents the client from being paid CCB on a BP. When creating TC86-4 trailers, enter the same week and day processed on the corresponding TC85-1, 2, 3 trailers. | Go to CCB trailer set-up and modification chart for more information if required. When CCB are starting or stopping in order to pay another BT, a renewal week is required on the TC80-1 trailer. Only one BT can be completed on the TC86-4 trailer. If the client requests a combination of CCB and family caregiver benefits, send the claim to MPS. For additional information on the APRS trailers, refer to Purge and Recreate Trailer List . [CCB trailer set-up and modification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#CCBtrailersetup) [Purge and Recreate Trailer List](http://wecs-siew.prv/wecs-siew/reflookup_e.aspx) |

| Family caregiver benefits | Family caregiver benefits for children: TC81-1: FCC WKS (card column 113-114) TC86-4: WEEK PROC (card column 15) DY (card column 67) MED CERT (card column 68) STRT (card column 78) END (card column 82) ENT (card column 86) MOD (card column 88) Family caregiver benefits for adults: TC81-1: FCA WKS (card column 115-116) TC86-4: WEEK PROC (card column 15) DY (card column 89) MED CERT (card column 90) STRT (card column 100) END (card column 104) ENT (card column 108) MOD (card column 110) | A TC86-4 trailer is required to establish the entitlement and full 52-week family caregiver window (FCW). Create additional TC86-4 trailers for each change to entitlement or when the client switches BTs. A TC86-4 trailer is not required when a 63 - Family caregiver for children or adults - No medical proof disentitlement (D63) prevents the client from being paid family caregiver benefits. When creating TC86-4 trailers, enter the same week and day processed on the corresponding TC85-1, 2, and 3 trailers. | Go to Family caregiver benefits trailer set-up and modification for more information, if required. When starting or stopping family caregiver benefits in order to pay another BT, a renewal week is required on the TC80-1 trailer. If the client requests a combination of family caregiver benefits with a BT other than regular or sickness, send the claim to MPS. For more information on the APRS trailers, refer to: Purge and Recreate Trailer List . [Family caregiver benefits trailer set-up and modification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#Family_caregiver_benefits) [Purge and Recreate Trailer List](http://wecs-siew.prv/wecs-siew/reflookup_e.aspx) |
```

**QPIP trailers**

```text
| QPIP | APRS trailers and card columns | Changes required | Additional information |

| Maternity/Parental | TC80-1: TOT WKS (card column 41) TC80-2: WP WK1 (card column 12) WP CD (card column 16) TC81-1: RFS (card column 105) PROV MAT (card column 107-108) PROV PAR (card column 109-110) TC82-2: DISENT. 1 CD (card column 12) DISENT. 1 FWK (card column 14) DISENT. 1 DY (card column 18) DISENT. 1 TWK (card column 19) DISENT. 1 DY (card column 23) | Validate the total number of weeks paid. Do not include the QPIP weeks . If the HM06 indicates that the WP is waived, enter 9 - WP waived (for Quebec Parental Insurance Plan [QPIP]) in the WP CD field. If the claim begins with QPIP benefits, select F - Pregnancy or P - Parental in the RFS field. Validate and confirm the number of weeks equivalent to EI maternity or parental benefits paid and complete or modify the PROV MAT and PROV PAR fields accordingly. The counter in the PROV MAT field must display a number from 1 to 15 to reflect the equivalent number of weeks paid in QPIP benefits. The counter in the PROV PAR field must display a number from 1 to 35 to reflect the equivalent number of weeks paid in QPIP benefits. Enter the appropriate disentitlement for weeks paid or payable by QPIP: - 56 - Quebec Parental Insurance Plan benefits paid (definite disentitlement) - 57 - EI maternity or parental benefits denied, Quebec Parental Insurance Plan benefits payable by the province (indefinite disentitlement) | The total number of QPIP maternity, paternity, parental or adoption weeks paid under the basic or special plan is displayed in FTS, on the Parental Insurance (Quebec) screen. Basic plan: A week of QPIP benefits corresponds to a week of EI maternity or parental benefits. Special plan: The information on the equivalence to EI benefits is provided on the EI Equivalent - Maternity/Other weeks paid fields. For additional information, refer to QPIP — Knowledge . [QPIP — Knowledge](/en/procedure/generic/additionalresources/qpip_knowledge.shtml#Equivalence) |
```

**CCB trailer set-up and modification**

When creating TC86-4 trailers for a CCB claim, complete the following fields if required:
       [TC86-4](http://wecs-siew.prv/wecs-siew/searchdetails_e.aspx?evalid=86-4)

```text
| Action required | CCB STRT | CCB END | ENT | MOD |

| Set-up of 52-week CCW and entitlement. Note: A set-up trailer is always required when CCB are paid or payable. | Start of CCW as established by the certificate. | CCB start + 51 weeks to establish a 52-week CCW. | 1 to 26, as requested by the client. | Blank |

| Renew CCB - Deferred CCB start and another BT is paid within the initial CCW. | Enter the renewal week for CCB. | Enter the same w/c as the previous TC86-4 trailer. | Blank | R |

| Stop CCB to pay another BT . CCB entitlement has not been reached. | Enter the same w/c as the CCB start on the previous TC86-4 trailer. | Enter the w/c of the last week processed as CCB. | Blank | S |

| Modify the CCB period to resume CCB after another BT has been processed. | Enter the w/c for which CCB have restarted. | Enter the end week of the initial 52-week CCW. | Enter the new CCB entitlement (1 to 26). | M |

| Close the CCW due to deceased patient. | Enter the same w/c as the CCB start of the previous TC86-4 trailer. | Enter the w/c on which the family member passed away. | Enter the number of eligible CCB weeks reported in the previous TC86-4 supplemental data. | D |

| Close the CCW due to CCB finished (entitlement reached). | Enter the same w/c as the CCB start of the previous TC86-4 trailer. | Enter the w/c of the last CCB week paid. | Blank | F |
```

**Family caregiver benefits trailer set-up and modification**

When creating TC86-4 trailers for a family caregiver benefits claim, complete the following fields when necessary:
       [TC86-4](http://wecs-siew.prv/wecs-siew/searchdetails_e.aspx?evalid=86-4)

```text
| Action required | FCB STRT | FCB END | ENT | MOD |

| Set-up of 52-week FCW and entitlement. [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0548.dita) | Start of the FCW as established by the certificate. | Family caregiver benefits start week + 51 weeks to establish a 52-week FCW. | 1 to 35 for family caregiver benefits for children or 1 to 15 for family caregiver benefits for adults, as requested by the client. | Blank |

| Renew family caregiver benefits. Deferred family caregiver benefits start and another BT is paid in the initial FCW. | Enter the renewal week for family caregiver benefits. | Enter the same w/c as the previous TC86-4 trailer. | Blank | R |

| Stop family caregiver benefits to pay another BT. Family caregiver benefits entitlement has not been reached. | Enter the same w/c as the family caregiver benefits start on the previous TC86-4 trailer. | Enter the w/c of the last week processed as family caregiver benefits. | Blank | S |

| Modify the FCW to resume family caregiver benefits after another BT has been processed. | Enter the w/c in which family caregiver benefits restarted. | Enter the end week of the initial 52-week FCW. | Enter the new family caregiver benefits entitlement (1 to 35 weeks or 1 to 15 weeks). | M |

| Close the FCW due to deceased patient. | Enter the same w/c as the family caregiver benefits start of the previous TC86-4 trailer. | Enter the w/c on which the family member passed away. | Enter the number of eligible weeks of family caregiver benefits reported in the previous TC86-4 supplemental data. | D |

| Close the FCW due to family caregiver benefits being finished (entitlement reached). | Enter the same w/c as the family caregiver benefits start of the previous TC86-4 trailer. | Enter the w/c of the last week of family caregiver benefits paid. | Blank | F |
```

**Self-employed special benefits trailers**

```text
| Trailer number | Field | Required changes |

| TC80-1 | HRCC (card column 12) | The Service Canada Centre (SCC) must be one of the following: - Atlantic — 1953 - Quebec — 2930 - Ontario — 3978 - Western Canada and Territories — 4758 |

| INS HR (card column 26) | Leave this field blank. |

| CL TP (card column 68) | Select the appropriate claim type (CT): - 73 - SE - Sickness - 74 - SE - Maternity - 75 - SE - Standard parental - 77 - SE - Compassionate Care - 78 - SE - Family caregiver for children (MPS only) - 79 - SE - Extended parental - 90 - SE - Family caregiver for adults (MPS only) |

| SEX (card column 70) | Select the appropriate sex code: - 1 - Male - 3 - Female - 5 - Parental, adoptive father - 6 - Parental, adoptive mother - 7 - Parental, natural father - 8 - Parental, natural mother |

| DIV WKS (card column 83) | The divisor is always 52. |

| TC81-1 | EMP NO ALPNUMERIC (card column 64-78) | Leave this field blank. |

| TC81-2 | BP ENT (card column 12) | A self-employed worker is not entitled to regular benefits. Leave this field blank. |

| EXCL CODE (card column 41) | Leave this field blank. |

| SCI CD (card column 43) | Select the appropriate code: - 70 - SE skeleton claim (system generated by CPS) - 71 - SE claim established with estimated earnings - 72 - SE claim with earnings from CRA - 78 - SE earnings requested not initiated |

| TC82-2 | ACT CD (card column 118) | This field can be left blank. If completed, the officer must type “G.” |

| TC85-1 | BF TP (card column 91) | Select the appropriate benefit type (BT): - 73 - SE - Sickness - 74 - SE - Maternity - 75 - SE - Parental standard adoption - 76 - SE - Parental standard childcare - 77 - SE - Compassionate Care - 79 - SE - Parental extended adoption - 89 - SE - Parental extended childcare |

| | C R (card column 97) | A special benefits self-employed client cannot be exempt from completing claimant’s report. If there is a 1 in this field, remove it. |

| TC85-2 | SRC (card column 106) | If there is an N in this field, remove it. |

| TC85-3 | BF TP (card column 91) | Select the same self-employed special BT as chosen for the TC85-1 trailer. |
```

**Employment initiative trailers**

Officers refer to the following employment initiative charts, if necessary:

**Non-referred training**

```text
| Trailer number | Field | Required changes |

| TC85-1 | STUAE AMT (card column 35) | Leave the field blank or type “0000.” |

| STUAE CD (card column 39) | If the STUAE AMT field displays “0000”, select 03 - Training . |

| BF TP (card column 91) | For non-referred training, select 01 - Regular . |

| TC86-1 | WEEK PROC (card column 15) PROJ START (card column 19) PROJ END (card column 23) | Complete the fields. |

| TRNG ID (card column 43) | Select 90 - Non-referred claimant . |
```

**Referred training**

```text
| Trailer number | Field | Required changes |

| TC85-1 | STUAE AMT (card column 35) | Type “0000.” |

| STUAE CD (card column 39) | Select 03 - Training . |

| BF TP (card column 91) | Select 06 - Training . |

| TC86-1 | WEEK PROC (card column 15) PROJ START (card column 19) PROJ END (card column 23) | Complete the fields. If the field TRNG ID displays 39 - Lifelong Learning , the PROJ START field must be greater than w/c 2146. If the training end week is reached, regular benefits continue to be paid as long as the client has not been paid full entitlement. A renewal week is not required. |

| PROJECT NO. (card column 27) | The project number must be composed of 10 digits. If the field TRNG ID displays 09 - Feepayer, 39 - Lifelong Learning or 53 - Skills development, full transfer labour market agreement , leave the field blank. |

| PHRCC (card column 33 ) | The field must match the R/C field. |

| RATE (card column 37) | Leave the field blank or type “000.” If the field TRNG ID displays 35 - Skills development - Group , type “000.” |

| TRNG ID (card column 43) | Select the appropriate code: - 09 - Feepayer - 35 - Skills Development - Group - 39 - Lifelong Learning - 53 - Skills development, full transfer labour market agreement - 95 - Pan Canadian, Skills Development - 97 - Skills Development for Aboriginals - 98 - Aboriginal Human Resource Development Agreement |

| R/C (card column 45) | The field must match the PHRCC field. |

| INST CD (card column 49) | For a TRNG ID other than 39 - Lifelong Learning , type “000000,” unless the claim is in the Quebec region, in which case type “123456.” For TRNG ID 39 - Lifelong Learning , type “201808.” |
```

**Apprenticeship**

```text
| Trailer number | Field | Required changes |

| TC80-2 | WP WK1 (card column 12) WP CD (card column 16) | When the WP is waived for apprentices, select 06 - WP waived (used for apprentices) in the field WP CD and type “0000” in the field WP WK 1 . |

| TC81-2 | APP (card column 36) | Select the appropriate code: - 1 - No advance pay: reports to be stopped after the training ends - 2 - No advance pay: reports to be continued after the training ends - 3 - Advance pay: reports are stopped once the training end week has been reached - 4 - Advance pay: continue or start reports after the training ends If the field displays 1 or 3, the claim stops at the course end week. When changing the course end week, update the field accordingly to display the correct apprentice code. |

| TC85-1 | STUAE AMT (card column 35 and 49) | Type “0000.” |

| STUAE CD (card column 39) | Select the appropriate code: - 11 - Apprentice, Training (no advance payment) - 13 - Apprentice, Training (advance payment) - 15 - Apprentice - advance payment allowed but report not paid in advance |

| BF TP (card column 91) | Select 06 - Training . |

| TC86-1 | WEEK PROC (card column 15) PROJ START (card column 19) PROJ END (card column 23) | Complete the fields. |

| PROJECT NO. (card column 27) | The project number must be composed of 10 digits. |

| PHRCC (card column 33) | The field must match the R/C field. |

| RATE (card column 37) | Type “000.” |

| TRNG ID (card column 43) | Select the appropriate code: - 20 - Apprentice, Skills Development, co-managed or no labour market agreement - 21 - Apprentice, Skills Development, full transfer labour market agreement |

| R/C (card column 45) | The field must match the PHRCC field. |

| INST CD (card column 49) | Complete the field. |
```

**Self-employment benefits program**

```text
| Trailer number | Field | Required changes |

| TC80-1 | CL TP (card column 68) | Select 02 - Regular . |

| TC81-2 | TD FLG (card column 60) | Select 6 because the client is internally excluded from completing electronic claimant’s reports. |

| TC85-1 | STUAE AMT (card column 35) | Type “0000.” |

| STUAE CD (card column 39) | Select 12 - Self-employed . |

| BF TP (card column 91) | Select 09 - Self-employed . |

| TC85-2 | SRC (card column 106) | When weeks are inserted or changed to BT 09 - Self-employed , adjust the SRC field by deleting code I, R or G (Internet reporting). |

| TC86-2 | WEEK PROC (card column 15) SE START (card column 19) SE END (card column 23) | Complete the fields. |

| PROJECT NO. (card column 27) | The project number must be composed of 10 digits. |

| PHRCC (card column 33) | The field must match the R/C field. |

| BASIC ALLOW ST (card column 37) BASIC ALLOW END (card column 41) BASIC ALLOW AMT (card column 45) | Leave the fields blank. If completed, clear the fields. Once the claim is back in CPS, in FTS, select the Project Data — Self Employment (M171) transaction and re-input the basic allowance information. |

| R/C (card column 85) | The field must match the PHRCC field. |
```

**Job creation program**

```text
| Trailer number | Field | Required changes |

| TC80-1 | PROJ CTR (card column 74) | If the project rate field for a job creation program is completed, the PROJ CTR field must be in the range of 000 to 058. |

| PROJ ST (card column 77) | Select the appropriate code: - 5 - Active project for job creation - 6 - Terminated project for job creation |

| TC85-1 | BF TP (card column 91) | Select 08 - Job creation . |

| TC86-1 | WEEK PROC (card column 15) PROJ START (card column 19) PROJ END (card column 23) | Complete the fields. |

| PROJECT NO. (card column 27) | The project number must be composed of 10 digits. |

| PHRCC (card column 33) | The field must match the R/C field. |

| RATE (card column 37) | Type “000.” |

| R/C (card column 45) | The field must match the PHRCC field. |
```

**Work-Sharing (WS)**

```text
| Trailer number | Field | Required changes |

| TC80-1 | MA (card column 39) | If the WS agreement is active, select 76 - Automated work-sharing . |

| TOT WKS (card column 41) | Do not include weeks processed as BT 7 in this field. |

| CL TP (card column 68) | If the WS status is 1 - Active project for worksharing , the CT must be 02, 06 or 07. |

| PROJ CTR (card column 74) | Enter the number of weeks processed (including not paid) as BT 7 for the most recent WS period. If no TC85 was processed as BT 7, type “000.” |

| PROJ ST (card column 77) | If the WS agreement is active or if there is no renewal following the completed WS agreement, select 1 - Active project for worksharing . If the WS agreement is completed and is followed by a renewal, select 2 - Terminated project for worksharing . |

| TC80-2 | NO CR (card column 73) PAY WK/DY (card column 75) | If the client is exempt from reporting, complete these fields. |

| TC81-1 | NEXT WK1 (card column 20-23) LAST SENT (card column 24-27) | When TC85s for cycling reports are deleted, enter the w/c for the next week to be processed in both fields. |

| TC81-2 | BP END (card column 14) | Calculate the last renewable week (LRW): BPC + 51 + number of weeks of BP extension + number of weeks processed as BT 7. Compare the calculated LRW to the end week of the WS agreement. If the calculated LRW is greater than the end week of the agreement, enter the calculated LRW. If the agreement end week is greater than the calculated LRW, enter the agreement end week. If either of the LRW or the agreement end week is greater than BPC + 103, enter BPC + 103. |

| EXCL CODE (card column 41) | If the WS agreement is active or if there is no renewal following the completed WS agreement, select 23 - Part-time employment - WS , otherwise leave this field blank. |

| TD FLG (card column 60) | Select 6 because the client is internally excluded from completing electronic claimant’s reports. |

| TC85-1 | MA (card column 24) | Select 76 - Automated work-sharing . If amending a claimant’s report, select 19 - Amended report . |

| STUAE AMT (card column 35) | Enter the hours missed for WS × 10. For example, if the client missed 6.5 hours due to WS, type “0065.” If the client worked at least half an hour for the WS employer and missed no hours due to WS, type “0000” and an FWW (card column 54). If this is not a WS week (i.e. a week during which the client did not work for the WS employer), type “0990.” |

| STUAE CD (card column 39) | Select 01 - Worksharing . |

| FWW (card column 54) | If “0000” was entered in the STUAE AMT field (card column 35), select 1 - Full work week - week 1 . Otherwise leave this field blank. |

| BF TP (card column 91) | If a number other than 0990 has been entered in the STUAE AMT field (card column 35), select 07 - Worksharing . If 0990 has been entered in the STUAE AMT field (card column 35) and if 5 sickness days were entered, select 10 - Sickness . If less than 5 sickness days were entered, select 01 - Regular . |

| WP CD (card column 94) | If the BT is 7 , select 15 - No weeks counted as weeks of benefits paid . Otherwise select the code according to the WP status following normal procedures. |

| TC85-2 | SRC (card column 106) | If the client is exempt from reporting, select N - Internal report generated for no claimant’s report claim . Otherwise leave this field blank. |

| ERN DED WK1 (card column 107) | Leave this field blank. |

| TC86-1 | WEEK PROC (card column 15) | The WS agreement WEEK PROC must be equal to or earlier than the first week that WS was processed. |

| SE START (card column 19) SE END (card column 23) | Enter the start and end w/c of the WS agreement. |

| PROJECT NO. (card column 27) | The project number must be composed of 10 digits. |

| PHRCC (card column 33) | Select the referral SCC. |

| W-S HRS (card column 40) | Enter the normal weekly hours (NWH) × 10. For example, if the NWH are 37.5, type “375” and if they are 40, type “400.” |
```

**Seasonal workers**

As part of the Budget 2018 commitment to assist workers in seasonal industries, Pilot Project 21 was created to provide up to 5 additional weeks (for a maximum of 45 weeks) of regular benefits to clients who meet the seasonal worker definition. This measure has since been extended each year, with Budget 2024 currently extending these provisions until October 24, 2026. The measure for seasonal workers now includes BPCs between w/c 2471 and w/c 2574.

In 2023, a one-year pilot project provided up to an additional 4 weeks of regular benefits to seasonal workers, on top of the 5 weeks provided under the existing temporary legislative measure. This means that the possible total of additional entitlement weeks was 9. This measure applies to claims with a BPC between w/cs 2412 and 2463.

For more information, the IPOC officer refers to Seasonal workers: Information on additional weeks of entitlement — Knowledge .
       [Seasonal workers: Information on additional weeks of entitlement — Knowledge](/en/procedure/generic/additionalresources/sw_info_addi_weeks_entitlement_pp21_knowledge.shtml)

If necessary, the officer refers to the following table:

```text
| Trailer number | Field | Required changes |

| TC81-2 | SEA FL (card column 90) | If the event triggering the P/R request potentially affects a seasonal worker’s entitlement weeks, type “99” in this field. This triggers a seasonal validation that confirms the seasonal worker’s entitlement and, if necessary, displays the seasonal worker entitlement in FTS. Changes to the current BPC, a previous BPC, hours of insurable employment or economic region potentially affect seasonal worker entitlement and status. |
```

**Claim successfully recreated**

There are situations that could require the IPOC officer to input online transactions after the claim was successfully recreated, such as the following examples:

- Claim recalculation is initiated using an M106 transaction with 99 - Manual update in the Recalculation field.

- Claimant’s reports are processed with an Issue Payments (M151/M152) transaction.

- The exemption from reporting is established with an M106.

- Cycling claimant’s reports were deleted in APRS and must be input with an M151/M152.

- Online transactions were rejected with error code C280 when the claim status (CS) was 99 - Purge/Recreate and must be input.

- Disentitlements were deleted in APRS because 7 or more disentitlements are in effect and must be input with a Disqualifications/Disentitlements (M161) transaction.

**Claim recreated with errors or omissions**

When the Minis reveal errors or omissions on the claim, the IPOC officer determines how to resolve the situation. Some incorrectly recreated claims may need to be purged again, while others may only need the input of a transaction in FTS. The nature of the error or omission determines the corrective action required.

**Online transactions**

Many FTS transactions are used to fix specific claim errors. The IPOC P/R officers most commonly use the M106 or process amended claimant’s reports.

Since the M106 forces CPS to read and review all the claim information, it is the most versatile and frequently used transaction by IPOC officers to adjust claims and fix errors. Examples of claim information that an M106 can correct include, but is not limited to, the following:

- total weeks paid;

- disentitlements excluded;

- WP information;

- special benefit weeks paid;

- wrong BT as long as the claimant’s report is properly coded;

- seasonal worker status or entitlement weeks.

A 19 - Amended report manual action (MA19) can be completed to add missing information or to correct incorrect data on a specific claimant’s report.

**Re-purge required**

Examples of situations that require the claim to be re-purged include:

- the amounts paid or recouped are incorrect;

- a valid trailer was deleted in error which contained an amount paid or recouped;

- a valid establishment of an EI OP trailer was deleted;

- trailers recreated but are missing family order agreement amounts;

- the following TC85-1,2 fields recreated incorrectly, causing a tax error or an OP with an invalid tax year:

- BEN AMT (card column 55);

- TAX (card column 59);

- GR-BEN-PD WK1 (card column 61);

- GR-BEN-PD WK2 (card column 65). 

### Note

Source topic: `en_EN/common_notes/note_c_0547.dita`

Note:

When the claim changes affect previous tax year amounts, the IPOC officer creates an IPOC Review (IPOC REV) WI for the regional tax coordinator (RTC) to amend the T4E. 

### Note

Source topic: `en_EN/common_notes/note_c_0548.dita`

Note:

A set-up trailer is always required when family caregiver benefits are paid or payable. 
