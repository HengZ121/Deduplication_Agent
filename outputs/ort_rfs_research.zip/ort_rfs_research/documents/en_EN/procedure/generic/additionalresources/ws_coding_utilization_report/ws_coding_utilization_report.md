# Work-Sharing: Utilization report coding — Input guide

Source map: `en_EN/procedure/generic/additionalresources/ws_coding_utilization_report/ws_coding_utilization_report.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/ws_coding_utilization_report/additional_resources.dita`

The Automated Worksharing screen in FTS has a number of built-in edits to prevent unnecessary rejects or incorrect inputs. If the system identifies data that does not meet the edits, the system highlights the problematic field in red. However, the comments added by the employer do not trigger an edit within the system.

The IPOC officer must therefore review the screen manually. Before uploading the WS UR in AWSS, the IPOC officer must verify the UR for comments. Once the upload is complete, the IPOC officer must check the Automated Worksharing screen for rejected declarations. The following procedures take into account the most common conditions and the action required in each situation.

Select a chart to help when coding a WS UR:

- Special condition codes
         [Special condition codes](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/ws_coding_utilization_report#Special)

- Utilization report (UR) conditions
         [Utilization report (UR) conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/ws_coding_utilization_report#URconditions)

A triage process was developed to convert URs received through the Data Gateway and upload them to FTS. Since the triage process cannot action UR declarations with comments, a workaround was created to notify an IPOC officer to review all UR declarations with comments.

The triage process converts the UR and inputs special condition code 11 - Non-available and sick days are greater than 5 in all declarations that contain a comment. IPOC officers need to familiarize themselves with this workaround because there are 2 scenarios where declarations can be coded with special condition code 11 . The 2 scenarios are:

- An IPOC officer input special condition code 11 to reject a UR declaration if not available days and sick days were greater than 5. NWS generates an IPOC System Notification (IPOC SN) Work-Sharing - Special condition WI.

- The triage process input special condition code 11 to reject a UR declaration with comments. The SIN is added to an .XML file in the Rejected_Declarations subfolder.

The IPOC officer reviews all other information on the UR to determine the correct action to take to address the special condition code.

The officer refers to Actioning a special condition code — IPOC for procedures related to actioning declarations with a special condition code.
       [Actioning a special condition code — IPOC](/en/procedure/task/actioning_wd0242_ws_sc_report.shtml)

**Special condition codes**

Special condition codes were created to help AWSS with coding requirements for a UR and to accelerate the upload of the UR. The special condition code does one of 2 things:

- helps the system determine the action to be taken;

- forces the reject of the UR declaration. NWS generates an IPOC SN Work-Sharing - Special condition WI the following day for the IPOC officer to review the reject and manually input a Manual Action - Claimant’s Reports (T045) transaction to process the declaration.

The IPOC officer may need to manually input the following codes in the Reason for not working field depending on the employer’s declarations:

```text
| Special condition code | Use |

| 1 Paid sick leave (PSL) | If a week is a non-WS week (no hours worked), this code is used to indicate that PSL was declared. If the client’s waiting period (WP) has been served or waived, the system codes the week as non-WS week and shows the PSL as earnings. If the client’s waiting period (WP) has been served or waived and both the claimant’s report and the UR indicate 5 sick days, the system codes the week as sickness and shows the PSL as earnings. Otherwise, if the WP has not been served or waived or either the claimant’s report or the UR doesn’t indicate 5 sick days, the transaction is rejected and an IPOC SN Work-Sharing - Special condition WI is generated to ensure the claim is reviewed and processed correctly. If the amount is unknown, enter $9 999 as the amount paid, and: - create an SROC to indicate that the amount of paid sick leave (PSL) was unknown so the amount of $9 999 was used until further fact-finding can be completed and the claim updated; - create an Action Item (AI) WI and assign it to Processing to advise that: - fact-finding needs to be completed to determine the amount of PSL received, - an incorrect amount of $9 999 was input to process the declaration and prevent unnecessary rejects, - if the week was not a week of WP and the earnings were incorrectly coded as $9 999, the week may need to be updated. |

| 6 Voluntary termination (quit) | This code is used to indicate that the client voluntarily left the WS employment. The transaction is rejected and an IPOC SN Work-Sharing - Special condition WI is generated to ensure that the claim is reviewed and processed correctly. If hours worked are coded, the special condition code is rejected. For coding details, go to Utilization report (UR) conditions . When the UR has been coded, refer to Processing a separation from Work-Sharing employment — IPOC . [Utilization report (UR) conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#URconditions) [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) |

| 7 Terminated (fired) | This code is used to indicate that the client was dismissed from the WS employment. The transaction is rejected and an IPOC SN Work-Sharing - Special condition WI is generated to ensure that the claim is reviewed and processed correctly. If hours worked are coded, the special condition code is rejected. For coding details, go to Utilization report (UR) conditions . When the UR has been coded, refer to Processing a separation from Work-Sharing employment — IPOC . [Utilization report (UR) conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#URconditions) [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) |

| 8 Laid off | This code is used to indicate a separation from the WS employment due to shortage of work, apprenticeship training or maternity, parental, compassionate care or family caregiver leave. The transaction is rejected and an IPOC SN Work-Sharing - Special condition WI is generated to ensure that the claim is reviewed and processed correctly. If hours worked are coded, the special condition code is rejected. For coding details, go to Utilization report (UR) conditions . When the UR has been coded, refer to Processing a separation from Work-Sharing employment — IPOC . [Utilization report (UR) conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#URconditions) [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) |

| 9 Planned shutdown | If the week is a non-WS week (no hours worked), this code is used to: - indicate a planned shutdown; - indicate a week in which the client did not work for the WS employer for reasons other than sickness or non-availability; - ensure that the week is coded as a non-WS week. For this reason, it is essential that all conditions and earnings, including WS earnings, are coded. For coding details, go to Utilization report (UR) conditions . [Utilization report (UR) conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#URconditions) For more information, refer to Actioning a planned shutdown during a Work-Sharing agreement — IPOC . [Actioning a planned shutdown during a Work-Sharing agreement — IPOC](/en/procedure/task/actioning_sswsa.shtml) [Utilization report (UR) conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#URconditions) [Actioning a planned shutdown during a Work-Sharing agreement — IPOC](/en/procedure/task/actioning_sswsa.shtml) |

| 10 Non-available and sick days are greater than 1 and less than 5 | If the week is a non-WS week (no hours worked), this code is used to indicate that the combined amount of not available days and sick days is greater than one day, but less than 5 days. The transaction is rejected and an IPOC SN Work-Sharing - Special condition WI is generated to ensure that the claim is reviewed and processed correctly. |

| 11 Non-available and sick days are greater than 5 | If the week is a non-WS week (no hours worked), this code is used to indicate that the combined amount of not available days and sick days is greater than 5 days. The transaction is rejected and an IPOC SN Work-Sharing - Special condition WI is generated to ensure that the claim is reviewed and processed correctly. The triage process also uses this code to indicate that a declaration contains a comment. The SIN is added to an .XML file in the Rejected_Declarations subfolder. |

| 19 Replace existing record | This code is used to replace an existing AWSS report. It cannot be used to replace a transaction that was processed in BPS. For example, a WS UR for w/c 2010 has already been received and input in FTS and AWSS. The employer notifies us that the declaration for SIN 123 456 789 is incorrect. Providing that w/c 2010 has not already been matched and processed in BPS, the new information can be input in FTS with a special condition code 19 . AWSS removes the previous declaration and replaces it with the new one. If w/c 2010 has already been matched with the claimant’s report and processed in BPS, the employer record is no longer in the AWSS and the special condition code 19 will not work. The modification must be done using a Detailed Claimant’s Report (M152) transaction and a 19 - Amended report manual action (MA19). [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0621.dita) |

| 44 Delete existing record | This code is used to delete an existing AWSS report. It cannot be used to delete a transaction that was processed in the BPS. For example, a WS UR for w/c 2010 has already been received and input in FTS and AWSS. The employer notifies us that the declaration for SIN 123 456 789 is incorrect. The new declaration indicates no hours worked and that the employee was dismissed from the WS employment. Because only one special condition code can be used at a time and the new declaration also requires special condition code 7 , IPOC cannot use special condition code 19 . Providing that w/c 2010 has not yet been matched and processed in BPS, one transaction with special condition code 44 is used to remove the previous declaration, and a second transaction with the new declaration and the special condition code 7 is input. |
```

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0622.dita) 

**Utilization report (UR) conditions**

The following outlines some common conditions and the action required when coding a UR in FTS and AWSS:

```text
| Conditions | Action/Coding |

| NWH < .5 or > 60 | Normal weekly hours (NWH) must be in the range of .5 to 60 and rounded up to the next whole or half decimal (e.g. 8.75 is rounded up to 9). If NWH are greater than 60, verify NWH with the employer. Refer to Fact-finding with a Work-Sharing employer — IPOC for guidance. If the employer insists NWH are greater than 60, refer the issue to the Program Officer and your business expertise advisor. [Fact-finding with a Work-Sharing employer — IPOC](/en/procedure/task/fact_finding_wse.shtml) |

| Hours worked + hours missed > NWH | Edits prevent hours worked and hours missed from totalling more than NWH. If hours missed have been rounded up to meet the necessary edits, hours worked may need to be rounded down. If the difference is not due to the rounding of the numbers, contact the employer and verify the information. Refer to Fact-finding with a Work-Sharing employer — IPOC for guidance. Ensure the employer is not including vacation time or not available time in either of the columns. If hours missed are 0, hours worked can be greater than NWH when the client worked overtime. [Fact-finding with a Work-Sharing employer — IPOC](/en/procedure/task/fact_finding_wse.shtml) |

| Hours worked 0 hours missed due to WS | No special coding is required. When the UR is matched with the claimant’s report, AWSS codes the week as a full work week (FWW). |

| 0 hours worked 0 hours missed due to WS | If not available days, sick days or a reason for separation (RFS) are applicable, refer to the information below. If there is no other information on the UR, fact-find with the employer to determine why the client did not work and did not miss any time due to WS. Refer to Fact-finding with a Work-Sharing employer — IPOC for guidance. [Fact-finding with a Work-Sharing employer — IPOC](/en/procedure/task/fact_finding_wse.shtml) |

| Hours worked Hours missed due to WS | Generally, no special coding required. If hours missed are greater than NWH, verify the correct hours missed with the employer. Refer to Fact-finding with a Work-Sharing employer — IPOC for guidance. If the hours missed are appropriately greater than NWH (due to the averaging of the NWH), refer the issue to your business expertise advisor as a workaround may be required. [Fact-finding with a Work-Sharing employer — IPOC](/en/procedure/task/fact_finding_wse.shtml) |

| 0 hours worked Hours missed due to WS | If no hours were worked, the week is not considered a WS week. Remove the hours missed from FTS and AWSS and keep not available, sick and earnings coding in place. |

| 0 hours worked FWW missed due to WS or a planned shutdown | If no hours were worked, the week is not considered a WS week. However, the client may be payable another type of benefits. In the Reason for not working field, enter special condition code 9 and code earnings. For a planned shutdown, verify that the shutdown was pre-approved by a program officer. If no, process the UR according to the declaration and advise the program officer. |

| Hours worked 1-4 NA days, 1-4 sick days or a combination of 1-4 not available and sick days | Delete any not available days or sick days as this information is not relevant to a WS week. |

| 0 hours worked 1-5 not available days, 1-5 sick days or a combination of not available and sick days | Ensure not available days and sick days are coded. Keep earnings coded, if any. If PSL, wage loss insurance (WLI) or workers’ compensation benefits (WCB) is indicated and the amount is known, keep the earnings coded and enter special condition code 1 . If the PSL, WLI or WCB amount is unknown, enter $9 999 as earnings. If the total of not available days and sick days is greater than 1 and less than 5, enter special condition code 10 . If the total of not available days and sick days is more than 5, enter special condition code 11 . [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0623.dita) |

| Hours worked Vacation pay indicated | Delete any earnings as a result of WS employment as this information is not relevant to a WS week. If the vacation pay amount declared is an amount greater than the normal weekly earnings (NWE), refer to Processing a lump-sum payment under Processing a converted Work-Sharing utilization report . [Processing a converted Work-Sharing utilization report](/en/procedure/task/processing_awsur.shtml#processing_lump_sum_payment) |

| Hours worked Statutory holiday pay | Delete any statutory holiday pay as this information is not relevant to a WS week. |

| 0 hours worked Statutory holiday pay | Remove hours missed, if necessary. Statutory holiday pay must be included in the coded earnings. |

| Hours worked Laid off | Do not use special condition code 8 . Code hours missed, if necessary. Refer to Processing a separation from Work-Sharing employment — IPOC for guidance. [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) |

| Hours worked Quit or Fired | When hours worked is greater than 0, FTS and AWSS do not accept a special condition code. Remove hours worked and hours missed and enter special condition code 6 or 7 ( 6 for voluntary leaving and 7 for dismissal). Refer to Processing a separation from Work-Sharing employment — IPOC for guidance. [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) Late notification of a voluntary leaving or dismissal : A notification is considered late when the declaration for the week of separation has already been received and input. - If the declaration for the week in which the separation occurred has not been received and input, ensure that the appropriate special condition code is added when the input is done. - If the week in which the separation occurred was input but not yet matched in AWSS, input an amended UR declaration by removing the hours worked and hours missed and inputting the appropriate special condition code. - If the week in which the separation occurred was input and matched in AWSS, input the special condition code on the week in which the separation was declared, even if it does not match the week in which the separation actually occurred. Refer to Processing a separation from Work-Sharing employment — IPOC for guidance. [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) |

| 0 hours worked Quit, fired or laid off | Remove any hours missed, if necessary. Keep earnings coded, if any. If the employee voluntarily left the job, enter special condition code 6 . If the employee was dismissed, enter special condition code 7 . If the employee was laid off due to shortage of work, apprenticeship training or maternity, parental, compassionate care or family caregiver leave, enter special condition code 8 . Refer to Processing a separation from Work-Sharing employment — IPOC for guidance. [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) Late notification of a voluntary leaving or dismissal: A notification is considered late when the declaration for the week of separation has already been received and input. - If the declaration for the week in which the separation occurred has not been received and input, ensure that the special condition code is added when the input is done. - If the week in which the separation occurred was input but not yet matched in AWSS, input an amended UR declaration by removing the hours worked and hours missed and inputting the appropriate special condition code. - If the week in which the separation occurred was input and matched in AWSS, input the special condition code on the week in which the separation was declared, even if it does not match the week in which the separation actually occurred. Refer to Processing a separation from Work-Sharing employment — IPOC for guidance. [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) |

| An amended declaration Original declaration not yet matched and processed through the BPS | Enter a special condition code 19 with the new declaration. This removes the original declaration from AWSS. This code cannot be used when a special condition code will be required on the new declaration (see direction for an amended declaration requiring a special condition code). |

| An amended declaration requiring a Special Condition Code. Original declaration not yet matched and processed through the BPS. | Only one special condition code can be used on a transaction. If the new declaration requires a special condition code, use 2 transactions: - On the first transaction, use special condition code 44 . This deletes the original declaration from AWSS. - The second transaction is the new declaration and is accepted as if it is an original. |
``` 

### Info

Source topic: `en_EN/common_notes/note_c_0621.dita`

Note: Special condition code 19 cannot be used when a special condition code will be required on the new declaration (see special condition code 44 ). 

### Note

Source topic: `en_EN/common_notes/note_c_0622.dita`

Note:

When special condition codes 6 , 7 , 8 , 10 and 11 are input, AWSS does not generate an internal Manual action - Claimant’s report (T045) transaction, as fact-finding or special coding is required. When special condition code 1 is used and the WP has not been served or waived on the claim file, AWSS does not generate an internal Manual action - Claimant’s report (T045) transaction, as fact-finding or special coding is required. When a Manual action - Claimant’s report (T045) transaction is not generated due to a special condition code, an IPOC SN Work-Sharing - Special condition WI is created for an IPOC officer to review and take appropriate action. There is no error code assigned and the claimant’s report does not show on the Pending/Reject tab in FTS. The URs in FTS show as matched, but the claimant’s report is still cycling. 

### Note

Source topic: `en_EN/common_notes/note_c_0623.dita`

Note:

Only one special condition code can be used at a time. Special condition code 10 and 11 must always be used over special condition code 1 . 
