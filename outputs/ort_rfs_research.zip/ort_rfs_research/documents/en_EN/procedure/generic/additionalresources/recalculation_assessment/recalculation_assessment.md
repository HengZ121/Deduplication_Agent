# Recalculation: Assessment — Instructions

Source map: `en_EN/procedure/generic/additionalresources/recalculation_assessment/recalculation_assessment.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/recalculation_assessment/additional_resources.dita`

Summary: This additional resource was designed to guide officers through the recalculation process by helping to determine the reason for the recalculation, the expected results, if the recalculation is required, and the necessary transactions to process the recalculation.

Table of Contents

- What you need to know

- What is a recalculation?
             [What is a recalculation?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#Whatisrecalc)

- Assessing the recalculation
             [Assessing the recalculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#assess_recalc)

- Preliminary calculation
             [Preliminary calculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#preliminary_calc)

- No change to the previous calculation result
             [No change to the previous calculation result](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#no_change_pcr)

- Change to initial calculation result
             [Change to initial calculation result](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#change_init_calc)

- Contentious issues in the qualifying period (QP)
             [Contentious issues in the qualifying period (QP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#contentious_qp)

- Contentious issues in the benefit period (BP)

- Contentious issues outside of the BP of an active, dormant or blocked claim
                 [Contentious issues outside of the BP of an active, dormant or blocked claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#contentious_ouside_bp)

- Contentious reason for separation (RFS) overlaps BPC and the previous calculation had an excluded ROE
                 [Contentious reason for separation (RFS) overlaps BPC and the previous calculation had an excluded ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#contentious_rfs)

- Claim previously finalized as BPNE N1, N2, N5 or with a 15 - Claim Procedure disentitlement (D15) on an established claim for a missing ROE
                 [Claim previously finalized as BPNE N1, N2, N5 or with a 15 - Claim Procedure disentitlement (D15) on an established claim for a missing ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#claim_n1_n2_n5)

- Recalculation input guide - SSA version
                 [Recalculation input guide - SSA version](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#recalc_ssa)

             [Contentious issues in the benefit period (BP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#contentious_bp)

         [What you need to know](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#wyntk)

- Step by step

- BPNE N1 or N5 claim
             [BPNE N1 or N5 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#bpne_n1_n5)

- Initial claim established
             [Initial claim established](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#ic_estab)

- Recalculation — No change to the claim
             [Recalculation — No change to the claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#recalc_no_change)

         [Step by step](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#sbs)

**What you need to know**

The purpose of this additional resource is to help officers determine if a recalculation is necessary and, if yes, how to review a claim to determine what actions are necessary based on the available information.

The additional resource is meant to be used along with the appropriate procedures. For more information, the officer refers to the appropriate procedure.

**What is a recalculation?**

A recalculation is required when new information is received on a claim that can impact the previous calculation result. The officer assesses the new information and, if necessary, recalculates the claim using normal calculation procedures to determine if the calculation result changes. The officer then compares the new and previous calculation results to determine the next steps for the claim.

**Assessing the recalculation**

Some reasons for the creation of a Claim Review (CR) Recalculation WI are:

- a new ROE

- an amended ROE

- new information provided by a client that affects the calculation (e.g., qualifying period [QP] extensions)

- variable best weeks (VBW) information

- an antedate

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0569.dita) 

The officer processing the recalculation considers the following questions when reviewing the file:

- Does the client still want to receive benefits?

- Why was the CR Recalculation WI created?

- What was the previous calculation result?

- Is there new information that affects the previous calculation result?

- What are the possible or expected results?

- Are there new contentious issues for which an adjudication is necessary?

- Are there any changes to the information from the previous calculation?

- Which inputs are necessary for the required changes?

- Is communication to the client necessary?

**Preliminary calculation**

To determine the reason for creating the recalculation and the possible expected outcome, the officer can perform a preliminary calculation in SSO to determine if any information changes.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0570.dita) 

The officer compares the previous calculation result to the new calculation result to determine what information has changed. The potential changes include the following:

- a change to the BPC week;

- a change to the benefit type (BT), benefit rate or entitlement weeks;

- a new or amended disqualification;

- a new or amended disentitlement;

- a new or amended allocation or benefit period (BP) extension.

The officer uses a table like the one below to gain a better understanding of anything that has changed after the recalculation.

```text
| Claim information | Previous calculation result | Recalculation result |

| BPC week | - | - |

| BT | - | - |

| Benefit rate | - | - |

| Entitlement weeks | - | - |

| Disqualification | - | - |

| Disentitlement | - | - |

| Allocation | - | - |

| BP extension | - | - |

| Insurable hours | - | - |

| Insurable earnings | - | - |
```

**No change to the previous calculation result**

After reviewing the file and making a preliminary calculation in SSO, if the outcome is no change to the claim, the officer inputs the M103 - Initial Decision (M103) or M106 - Subsequent Decision (M106) transaction for the recalculation with NCA in the BPC Claim action field and completes the CR Recalculation WI.

**Change to initial calculation result**

If the outcome is a change to the claim, the officer verifies if there are any unadjudicated contentious issues in the QP or the BP, and actions them, if necessary.

If there is no change to the BPC, entitlement weeks or benefit rate, but there are other changes not specifically related to the claim calculation (e.g. an amended allocation or an amended reason for separation [RFS]), the officer inputs the transactions in FTS. SSO may not always generate the correct transactions on a recalculation. Therefore, if the transactions do not relate to the claim calculation, it is important for the officer to use other resources such as the Recalculation SSA Input Guide , the procedures and FTS to ensure that the transactions are reviewed and completed accurately.
       [Recalculation SSA Input Guide](https://esdc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml)

**Contentious issues in the qualifying period (QP)**

If there are any unadjudicated contentious issues in the QP, the officer may not have to action them. If the adjudication does not affect the calculation result (i.e., the client is still not entitled), no adjudication is required. The officer does not create a CR WI for the unadjudicated contentious issues and completes the CR Recalculation WI.

If the contentious issue affects the calculation result (i.e., affects entitlement), adjudication is required. The officer creates a CR WI for each contentious issue in the QP and determines if the adjudication can be deferred by referring to Deferring adjudication: Client not requesting benefits . The officer then determines if the adjudication can be completed at Level 1. If the adjudication cannot be deferred or completed at Level 1, the officer assigns the CR WI to the appropriate Level 2 workload hierarchy in NWS and moves the CR Recalculation WI to Pending while awaiting the decisions.
       [Deferring adjudication: Client not requesting benefits](/en/procedure/task/deferring_adj_current_claim.shtml)

**Contentious issues in the benefit period (BP)**

If there are any unadjudicated contentious issues in the BP of a recalculation, and the client is not entitled to any benefits on the claim after the recalculation (e.g., due to a previous disqualification from the BPC, a previous disentitlement on file, the claim being BPNE, etc.), no adjudication is required. The officer does not create a CR WI for the unadjudicated contentious issue in the BP and completes the CR Recalculation WI without rendering a decision.

If the client could be entitled to benefits after the recalculation, the officer creates a CR WI for each contentious issue and determines if the adjudication can be completed at Level 1. If the adjudication cannot be completed at Level 1, the officer determines if the contentious issue impacts the recalculation:

- If no, the officer assigns the CR WI to the appropriate Level 2 workload hierarchy in NWS, imposes a stop payment and completes the CR Recalculation WI.

- If yes, the officer moves the CR Recalculation WI to Pending until a Level 2 officer has rendered a decision.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0571.dita) 

For BPNE claims that become established after recalculation and have a contentious RFS in the BP, the officer refers to Recalculating and establishing BPNE claims: Outstanding issue in the benefit period — Instructions to determine if adjudication is required.
       [Recalculating and establishing BPNE claims: Outstanding issue in the benefit period — Instructions](/en/procedure/generic/additionalresources/recalc-esta-bpne-claim.shtml)

**Contentious issues outside of the BP of an active, dormant or blocked claim**

If any pending or unadjudicated contentious issues occurred outside of the BP of an active, dormant or blocked claim the officer is recalculating, these contentious issues do not impact the result of the recalculation. In these situations, the officer:

- does not create a WI for the issue;

- does not wait for adjudication of the issue;

- proceeds with the claim recalculation.

**Contentious reason for separation (RFS) overlaps BPC and the previous calculation had an excluded ROE**

If there is an ROE with a contentious RFS with the first day worked in the QP and the last day worked (LDW) in the BP, Unemployment Insurance Calculation (UIC) considers the portion of the ROE that falls in the QP when calculating the insurable hours and earnings. If the adjudication of the contentious ROE in the BP is deferred or not allowed, UIC imposes a disqualification from the BPC. In this situation, the officer determines if there was a previously excluded ROE in the QP. If yes, UIC considers all the hours and earnings in the QP, including the excluded ROE, which creates an incorrect calculation. To avoid this, the officer changes the Special condition field in RCM on the ROE with a contentious RFS in the BP. Depending on the RFS, the officer selects Voluntary leaving - Just cause or Misconduct - Not proven to prevent UIC from including the hours and earnings from the excluded ROE.

When the recalculation is completed, the officer imposes a manual disqualification for the contentious RFS in the BP and changes the Special condition field on the ROE to the appropriate option , based on the decision.

**Claim previously finalized as BPNE N1, N2, N5 or with a 15 - Claim Procedure disentitlement (D15) on an established claim for a missing ROE**

When the last ROE is submitted within 90 calendar days of the date the claim was finalized as BPNE code 2 - Last record of employment missing (N2), no adjudication of the delay in submitting the ROE is necessary. To calculate if the ROE is submitted within 90 days, the Level 1 officer determines if the claim was finalized by ACP or an officer:

- If ACP finalized the claim, the officer uses the date in FTS of the Initial decision (H103) transaction + calendar 90 days.

- If an officer manually finalized the claim, the officer uses the date in FTS of the M103 transaction + 90 calendar days.

If the ROE is submitted more than 90 days of the date the claim was finalized as BPNE N2, the officer refers to National Policy on Levels of Decision – Annex 1 to determine if the reason for delay can be adjudicated at Level 1. If the decision is not within Level 1 authority, the officer creates a CR WI for Level 2, assigns it to the appropriate Level 2 workload hierarchy in NWS and moves the CR Recalculation WI to Pending until the decision is rendered.
       [National Policy on Levels of Decision – Annex 1](/en/policy/nationalpolicy/levels_decision-annex1.shtml#s12)

When the claim was previously finalized as BPNE N1 or N5, the officer does not consider if the missing ROE was submitted within 90 days. Claims previously finalized BPNE N1 or N5 have not been established due to insufficient hours. Service Canada may be asked to reconsider this decision when an additional ROE is submitted. That reconsideration would be made under EIA 52 and its applicable timeframes.

**Recalculation input guide - SSA version**

The Recalculation: SSA — Input guide is an important reference guide when processing recalculations. The guide provides the officer with the required inputs based on the type of recalculation being completed to help prevent system rejects. There are also workarounds provided for the various error codes that may appear after attempting a recalculation. The officer should refer to the guide every time a recalculation is required.
       [Recalculation: SSA — Input guide](https://intranet.esdc-edsc.canada.ca/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml)

**Step by step**

- In NWS, review the CR Recalculation WI to determine the reason for creating the recalculation.

- Compare the new information received to the information used in the previous calculation to determine what changes can be expected during the recalculation.

- In FTS, review the claim to determine the result of the previous calculation:

- If the claim was established with a D15 for a missing ROE or was previously finalized as BPNE N2, go to step 4.

- If the claim is BPNE N1 or N5, and a new ROE was received, go to step 7.

- If the claim is established, go to The initial claim is established .
             [The initial claim is established](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#ic_estab)

- In RCM, determine if the ROE that resulted in the decision on the LREM issue or the D15 is on file:

- If yes, go to step 5.

- If no, go to Recalculation — No change to the claim .
             [Recalculation — No change to the claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#recalc_no_change)

- Determine if the ROE was received within 90 days of the original M103 - Initial Decision (M103) transaction:

- If no, go to step 6.

- If yes, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- Refer to the appropriate procedure based on the result of the previous calculation:

- If the claim was previous finalized with a D15 for a missing ROE, go to step 2 of Reviewing a claim that was previously finalized with a D15 disentitlement for a missing ROE .
             [Reviewing a claim that was previously finalized with a D15 disentitlement for a missing ROE](/en/procedure/task/claim_procedure_term_after_roe.shtml)

- If the claim was finalized BPNE N2, go to step 3 of Reviewing a claim that was previously finalized with the last ROE missing .
             [Reviewing a claim that was previously finalized with the last ROE missing](/en/procedure/task/reviewing_claim_twpfwtlroem.shtml)

- Determine the next steps based on the previous calculation result:

- If the claim is BPNE N1 or N5, go to The claim is BPNE N1 or N5 .
             [The claim is BPNE N1 or N5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#bpne_n1_n5)

- If claim is established, go to Initial claim established .
             [Initial claim established](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#ic_estab)

**BPNE N1 or N5 claim**

- After reviewing the new information on file, make a preliminary calculation in SSO and determine if the calculation result changes (e.g. the claim is changed from BPNE N1 to BPNE N5, the client now qualifies for benefits, the hours changed, etc.):

- If yes, go to step 2.

- If no, go to Recalculation — No change to the claim .
             [Recalculation — No change to the claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#recalc_no_change)

- Determine if the client now qualifies:

- If yes, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If no, proceed only with the recalculation of the claim. Do not create WIs for any contentious issues that were determined. Refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

**Initial claim established**

- After reviewing the new information, make a preliminary calculation in SSO and determine if the calculation result changes:

- If yes, go to step 2.

- If no, go to Recalculation — No change to the claim .
             [Recalculation — No change to the claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#recalc_no_change)

- Determine the next steps by reviewing each change in the calculation result:

- If there is a change to the benefit rate or entitlement weeks and there are no contentious or outstanding issues in the QP, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If there is a change to the benefit rate or entitlement weeks and there is a contentious RFS in the QP, go to step 3.

- If there is a change in the benefit rate due to VBW information, go to step 5.

- If there is a new or amended allocation or BP extension, go to step 6.

- If there is a change to the BPC, go to step 8.

- If there is an ROE with a contentious RFS that occurs after the BPC and the recalculation result is to impose a disqualification in the BP, go to step 10.

- If there is a change to a previous disentitlement, or a disentitlement that requires review, go to step 14.

- If there are multiple changes to the calculation result, once the steps for one change are completed, return to the next change listed in this step until all outstanding issues have been addressed. After reviewing all the outstanding issues, determine if a recalculation is still required:

- If yes, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
                 [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If no, go to Recalculation — No change to the claim .
                 [Recalculation — No change to the claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/recalculation_assessment#recalc_no_change)

- Review the information on file to determine if the contentious RFS in the QP has already been adjudicated:

- If yes, in RCM, change the special condition on the ROE and, if there are no other outstanding issues, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If no, determine if there is already a CR WI for the contentious RFS:

- If yes, reassign the CR WI to yourself.

- If no, create a CR WI for the adjudication and assign the CR WI to yourself.

- Determine if the adjudication is within your authority by referring to the appropriate deferral and adjudication tasks:

- If yes, complete the adjudication, and if there are no other outstanding issues, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If no, in NWS, reassign the WI to the appropriate Level 2 workload hierarchy and move the CR Recalculation WI to Pending. When the adjudication is complete, if there are no other outstanding issues, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- Determine if the benefit rate will be higher:

- If yes, and there are no other outstanding issues, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If no, refer to Reviewing the calculation result — Recalculation of an established claim to process the recalculation.
             [Reviewing the calculation result — Recalculation of an established claim](/en/procedure/task/review_calc_result_recalc_estab_claim.shtml)

- Determine if the change to the allocation or BP extension is correct. Verification may be necessary. Refer to the appropriate tasks under the Earnings activity, if necessary:

- If yes, go to step 7.

- If no, correct the information and return to step 1.

         [Earnings](/en/procedure/activity/earnings.shtml)

- Determine if the change to the allocation or BP extension affects the BPC, hours, or earnings in the recalculation:

- If yes, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation. Refer to the appropriate task for modifying the allocation or BP extension, if necessary.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If no, do not process the recalculation. The inputs will be done manually in FTS. Refer to the appropriate task under Earnings to process the transactions.
             [Earnings](/en/procedure/activity/earnings.shtml)

- Determine the reason the BPC has changed with the recalculation result by reviewing the ROEs, the separation monies, the interruption of earnings (I of E), the earnings last week worked (ELWW), and any decisions on file:

- If the new BPC is incorrect, go to step 9.

- If the new BPC is being antedated, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation. When the calculation result is transmitted, ensure that the claimant’s reports for the period covered by the antedate are input on the same day.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If the new BPC is being correctly postdated, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation. Refer to Reviewing the calculation result — BPC to determine if communication to the client is required.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml) 
             [Reviewing the calculation result — BPC](/en/procedure/task/calc_reviewing/review_calc_bpc.shtml#determining_if_a_postdate_is_required35)

- Determine if a change to the BPC is required:

- If no, the BPC from the initial claim calculation must be manually entered in SSO. Return to step 1.

- If yes, the correct BPC must be manually entered in SSO. Refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- Determine if the contentious RFS occurred before the last renewable week (LRW) of the claim being recalculated:

- If no, ignore the contentious RFS and return to step 1.

- If yes, go to step 11.

- Refer to Deferring adjudication: Current established claim to determine if it is possible to defer the adjudication:

- If yes, defer the adjudication and refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If no, determine if there is already a CR WI for the contentious RFS:

- If yes, reassign the CR WI to yourself.

- If no, create a CR WI for the adjudication and assign it to yourself.

         [Deferring adjudication: Current established claim](/en/procedure/task/deferring_adj_current_claim.shtml)

- Determine if the adjudication is within your authority:

- If no, impose a 75 - Verification of reason for termination of Employment manual action (MA75), reassign the CR WI to the appropriate Level 2 workload hierarchy and go to step 13.

- If yes, complete the adjudication and refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- Determine if the Level 2 adjudication could impact the recalculation:

- If yes, move the CR Recalculation WI to Pending. When the adjudication is complete, if there are no other outstanding issues, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If no and there are no other outstanding issues, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0572.dita)

- Determine the type of disentitlement that applies:

- If it is a 2 - Minor attached, reason for separation illness disentitlement (D2) or a 46 - Variable entrance requirement not met - special benefits payable disentitlement (D46) and the client now gains relief from it and there are no other outstanding issues, refer to the appropriate activity in Calculation of a claim — Index (canada.ca) to process the recalculation.
             [Calculation of a claim — Index (canada.ca)](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- For all other disentitlements, go to step 15.

- Determine if the new information on file relates to the disentitlement and whether the disentitlement could potentially be modified or rescinded:

- If yes, create a CR WI and go to step 16.

- If no, note that a change to the disentitlement is not required and return to step 1.

- Determine if modifying or rescinding the disentitlement is within your authority by referring to the Levels of Decision and other appropriate tasks:

- If yes, note that when inputting the recalculation transactions, changes to the disentitlement are required. If there are no other outstanding issues, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If no, reassign the WI to the appropriate Level 2 workload hierarchy, and move the CR Recalculation WI to Pending. When the decision is complete, if there are no other outstanding issues, refer to the appropriate activity in Calculation of a claim — Index to process the recalculation.
             [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

         [Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

**Recalculation — No change to the claim**

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “No changes to the claim.”

- Details: Type “There are no changes to the previous calculation result. No changes are required to the claim.”

- Select Save .

- In FTS, select the Renewal/Revised (M106) transaction and complete the recalculation registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the CR Recalculation WI. 

### Note

Source topic: `en_EN/common_notes/note_c_0569.dita`

Note:

For recalculations to be within Level 1 authority, the BPC must be within the 36-month reconsideration timeframe. However, a recalculation caused by an allowed antedate is not subject to the timeframes under EIA 52 .
       [EIA 52](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/page-8.html#h-216637)

A recalculation resulting in an antedate decision is considered a procedural issue rather than an entitlement decision. This is because the decision is related to the filing of the claim, and it therefore can be recalculated under EIA 111 .
       [EIA 111](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/page-15.html)

For more information on Level 1 reconsideration timeframes, officers refer to Reconsideration, amendment of a decision and error correction .
       [Reconsideration, amendment of a decision and error correction](/en/procedure/activity/informal_reconsideration.shtml)

     [EIA 52](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/page-8.html#h-216637) 
     [EIA 111](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/page-15.html) 
     [Reconsideration, amendment of a decision and error correction](/en/procedure/activity/informal_reconsideration.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0570.dita`

Note:

It is important that the officer reviews, corrects and verifies all ROEs before performing the preliminary calculation in SSO. 

### Note

Source topic: `en_EN/common_notes/note_c_0571.dita`

Note:

Before creating a CR WI for Level 2, the officer determines if there is an ongoing Integrity investigation for the contentious issue. An officer can determine this with any of the following indicators:

- A manual action 71 - Integrity Services case (MA71) is imposed.

- A 71 - Integrity Services case disentitlement (D71) is imposed.

- The Registration flag field on an outstanding registration number has a 1 - Integrity Services .

- An N-04-00-00 letter has been sent to request that a medical certificate be submitted.

- A letter beginning with C-00, C-72, C-73 or C-88 has been sent by Integrity.

- For potentially fraudulent claims, an SROC created by Integrity might be on file indicating that the claim is under review.

If the contentious issue is under investigation, a Level 2 officer is not required to create a CR WI as Integrity will create a CR-Integrity WI when the investigation is completed. 

### Note

Source topic: `en_EN/common_notes/note_c_0572.dita`

Note:

If there is an ROE with a contentious RFS with the first day worked in the QP and the LDW in the BP, and the adjudication is deferred or not allowed and a disqualification must be imposed from the BPC, determine if there was an excluded ROE in the QP of the initial calculation. If yes, to obtain the correct calculation result in SSO, update the Special condition field in RCM on the ROE with the contentious RFS in the BP to Voluntary leaving - Just cause or Misconduct - Not proven , depending on the RFS. This prevents SSO from including the hours and earnings from the excluded ROE. After inputting the calculation, impose a manual disqualification for the contentious ROE in the BP and change the Special condition field in RCM to the appropriate option, based on the decision. 
