# Employer: Major employer event data entry (authorized user) — Instructions

Source map: `en_EN/procedure/generic/additionalresources/employer_major_event_data_entry/employer_major_event_data_entry.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/employer_major_event_data_entry/additional_resources.dita`

Summary: These instructions are for authorized users to create, modify or deactivate an event in Major Employer Events .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

**Table of contents**

- Background
         [Background](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Background)

- Additional information
         [Additional information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Addi)

- Searching for an approved event in the Major Employer Events (MEE)
         [Searching for an approved event in the Major Employer Events (MEE)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Searching_in_approved)

- Verifying if an event exists
         [Verifying if an event exists](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Verifying)

- Submitting an editing and translation request
         [Submitting an editing and translation request](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Submit_editing_translation)

- Creating a new event
         [Creating a new event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_CreatingEvent)

- Completing the Employer Summary tab
         [Completing the Employer Summary tab](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Completing_the_Employer)

- Completing the Event Summary tab
         [Completing the Event Summary tab](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Completing_the_Event)

- Completing the additional tabs vs event types
         [Completing the additional tabs vs event types](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Completing_the_additional)

- Modifying an event or the event status
         [Modifying an event or the event status](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Modifying_an_event)

- Adding an attachment to an event
         [Adding an attachment to an event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_an_attachment)

- Adding, modifying or deleting a hyperlink to an event
         [Adding, modifying or deleting a hyperlink to an event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_a_hyperlink)

- Adding a statutory holiday pay information to an event
         [Adding a statutory holiday pay information to an event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_a_statutory)

- Deactivating an event and reactivating a deactivated event
         [Deactivating an event and reactivating a deactivated event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Deactivating_an_event)

**Background**

The Major Employer Events has 2 purposes:
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Allow an authorized user to create, modify and deactivate event.

- Allow processing officers to consult information about approved Major Employer Events .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0441.dita) 

When Major Employer Events opens, the officer selects the preferred language and the Major Employer Events — Information Bulletin page displays only approved events.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Events can be filtered by Region , Event Type or Year using the corresponding drop-down menus. Filtered results show a specific type of event, depending on what the officer selects. For example, if the authorized user selects Ontario from the Region drop-down menu, the results will display events only in the Ontario region. The information in the columns can be sorted in a specific order by selecting the corresponding column title.

An event can be found by entering the employer’s name in the Search field.

Authorized users can access the MEE database to consult all events. The authorized user selects Menu , then selects Major Employer Events and selects All Events from the Views drop-down menu.

When consulting all events, the authorized user filters the events by Views , Event Type or Year using the corresponding drop-down menus. The authorized user can opt to display all events or a specific type of events by using the Views drop-down menu. For example, if Resolved Events is selected from the Views drop-down menu, the filtered result displays only resolved events.

The following events must always be input into the MEE database:

- Labour Disputes

- School Board

- Voluntary Workforce Reduction Program

- Work Sharing

- Bankruptcy

The following events can be input into the MEE database at the discretion of the regional business expertise staff:

- Mass Layoff and Records of Employment

- Earnings

- Insurable Hours

- Reason for Separation

- Major Fraud

- Emergency Situation

- Collective Grievance Settlement

Authorized users who are part of the School board fact-finding team can refer to School board: Major employer event data entry (authorized user) — Instructions .
       [School board: Major employer event data entry (authorized user) — Instructions](/en/procedure/generic/sb-meede_ds-sdleme.shtml)

**Additional information**

Contact the following GD mailbox for any questions and include “MEE issue” as the subject line of the email: esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca
       [esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca](mailto:esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca)

**Searching for an approved event in the Major Employer Events (MEE)**

When Major Employer Events opens and the preferred language is selected, it displays the Major Employer Events — Information Bulletin page and only approved events are displayed. However, authorized users can search all events including those that are approved, pending, rejected, deactivated or cancelled in the Major Employer Events database.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Search for an approved event in the MEE — Information Bulletin as follows:

- Open Major Employer Events and select English . The Major Employer Event — Information Bulletin page opens and only displays approved events.
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Enter the employer or event name in the Search field.

- If the event is found, select it to access its content and display its details.

**Verifying if an event exists**

Before creating a new event, the authorized user verifies if the event already exists for the same reason and period in the MEE database.

Verify if an event exists as follows:

- Open Major Employer Events and select English .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Menu , then select Major Employer Events .

- If an event exists, select the event to access its content and review its details. To modify the event, go to Modifying an event or the event status .
         [Modifying an event or the event status](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Modifying_an_event)

- If no event exists, go to Creating an event .
         [Creating an event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_CreatingEvent)

**Submitting an editing and translation request**

All of the content published in the MEE — Information Bulletin must be available in both official languages. The authorized users submit an editing and translation request to the Linguistic Services team: EDSC.ServicesLinguistiques_TPAE-EIBP_LinguisticServices.ESDC@hrsdc-rhdcc.gc.ca .
       [EDSC.ServicesLinguistiques_TPAE-EIBP_LinguisticServices.ESDC@hrsdc-rhdcc.gc.ca](mailto:EDSC.ServicesLinguistiques_TPAE-EIBP_LinguisticServices.ESDC@hrsdc-rhdcc.gc.ca)

While waiting for the edited and translated text, it is important that the event is published as soon as possible in the MEE — Information Bulletin.

If information has not yet been translated and is only available in one official language, the authorized user advises officers that there is information available in the other language by selecting the Other Information tab and adding a note to the appropriate field.

Advise officers that information is only available in the other language as follows:

- Select the Other information tab.

- If information is only available in English, in the Additional Information - French field, type “Cet évènement est en cours de traduction. Aucun renseignement n’est actuellement disponible en français, consulter les renseignements en anglais.”

- If information is only available in French, in the Additional Information - English field, type “This event is currently being translated. No information is available in English at this time, refer to the information in French.”

**Creating an event**

When creating a new event, the authorized user completes all required fields indicated with an asterisk (*) on the Employer Summary and Event Summary tabs. The authorized user completes as many fields on each of the tabs as possible. The more information is provided, the more efficient the event is.

Create a new event as follows:

- Open Major Employer Events and select English .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- From the Menu , select New event .

- Select the appropriate event type.

- Complete the appropriate fields on every tab.

- Select the Save tab and select Save .

When the authorized user creates a new event, specific tabs change, depending on the type of event. However, every event has the tabs Employer Summary and Event Summary .

**Completing the Employer Summary tab**

Employer (required)*

Enter the name of the employer or event.

Address 1 (required)*

Enter the employer’s address.

Address 2

Enter the information (if provided) or leave this field blank.

City

Employer Email

Primary Contact Name

Province

Postal Code

Enter the information provided by the employer.

Telephone Number

Telephone Extension

CRA Business Number

Enter the information (if provided) or leave the field blank.

Division / Branch

Enter the information (if provided) or leave this field blank.

**Completing the Event Summary tab**

Region (required)*

Select the appropriate region.

Start Date (required)*

Enter the start date of the event.

End Date

Enter the end date of the event (if provided) or leave this field blank.

Regional contact

Enter the regional contact’s name (if provided) or leave this field blank.

Handled by (required)*

Select the appropriate region.

Additional Processing Information

- Select Yes if any documents, a hyperlink, statutory holiday pay information are attached or if SINs are listed on the SIN Information tab.

- Select No if there are no attachments and no SINs are listed.

Event Type Details

Only displayed for the event type Other. Enter the event description.

Total Number of Employees

Number of Employees Affected

Enter the number of employees (if available) or leave the field blank.

Location Affected

Enter the information (if provided) or leave this field blank.

Reference Code

Only available for certain event types. Enter the information (if available).

**Completing the additional tabs vs event types**

There are 13 different event types. In addition to the fields included on the Employer Summary and Event Summary tabs, every event type has the following standard tabs:

- Procedures

- Processing Considerations

- SIN Information (If SIN information is provided, select Yes in the Additional Processing Information field on the Event Summary tab.)

- Decision

- Other Information

- Additional Info (If a template, hyperlink or information on statutory holiday pay or other documentation is provided, select Yes in the Additional Processing Information field on the Event Summary tab.)

- Save

Certain event types have the following tabs:

```text
| Event Type | Tab |

| Bankruptcy | Union/Trustee |

| Collective Grievance Settlement | Union/Trustee |

| Earnings | Earnings ROE |

| Emergency Situation | External Support Information |

| Insurable Hours | Union/Trustee |

| Labour Disputes | Labour Dispute Union/Trustee |

| Major Fraud | Union/Trustee |

| Mass Layoff and Records of Employment | ROE |

| Reason for Separation | Union/Trustee |

| School Board | ROE |

| Other | Union/Trustee |

| Voluntary Workforce Reduction Program | Voluntary Workforce Reduction Program |

| Work Sharing | ROE |
```

The authorized user completes a tab by selecting the tab and entering information in the appropriate fields.

Complete an additional tab as follows:

- Select the appropriate tab.

- Enter all information in the appropriate fields and sections.

- Select the Save tab and select Save .

To attach a document to an event, go to Adding an attachment to an event .
       [Adding an attachment to an event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_an_attachment)

To add a hyperlink to an event, go to Adding, modifying or deleting a hyperlink to an event .
       [Adding, modifying or deleting a hyperlink to an event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_a_hyperlink)

To add statutory holiday pay information to an event, go to Adding statutory holiday pay information to an event .
       [Adding statutory holiday pay information to an event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Adding_a_statutory)

To modify information on an existing event or modify the status of an event, go to Modifying an event or the event status .
       [Modifying an event or the event status](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_ModifyingEvent)

To deactivate an event or reactivate a deactivated event, go to Deactivating an event and reactivating a deactivated event .
       [Deactivating an event and reactivating a deactivated event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/employer_major_event_data_entry#_Deactivating_an_event)

**Modifying an event or the event status**

Once an event is created, the authorized user modifies the event status to Approved . All approved events display on the MEE — Information Bulletin page. Modify an event as follows:

- Open Major Employer Events and select English .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Menu , then select Major Employer Events .

- Enter the event name in the Search field.

- Select the event to access its content.

- Approver: Select Edit .

- Enter the necessary information on the appropriate tabs.

- Approver: Select Save .

Change the status of an event as follows:

- Open Major Employer Events and select English .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Menu , then select Major Employer Events .

- Enter the event name in the Search field.

- Select the event to access its content.

- Approver: Select Edit .

- Status: Select the appropriate option.

- Approver: Select Save .

**Adding an attachment to an event**

Attachments can only be added to an existing event in the form of an attached document (Word, PDF, etc.). If the document is larger than 10MB, the authorized user adds a hyperlink instead of an attachment.

Add an attachment as follows:

- Save each attachment document on your computer.

- Open Major Employer Events and select English .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Menu , then select Major Employer Events .

- Enter the event name in the Search field.

- Select the event to access its content.

- Approver: Select Edit .

- Select the Additional Info. tab.

- On the Notes section, select + .

- When the New Note window opens:

- Note Text: Enter the document name, using the language of the document.

- If the document is not available in French, type “ Les renseignements ne sont pas disponibles en français, consulter les renseignements en anglais.”

- If the document is not available in English, type “No information is available in English, refer to the information in French.”

- Attach Files: Select Attach Files .

- When your computer’s File Explorer opens, select the document from the location it was saved, then select Open .

- When the document displays in the Attach files field, select Save .

- If the document is available in French, repeat the previous steps.

- If there are other documents to attach, repeat the previous steps until all necessary documents are attached.

- Select the Event Summary tab.

- Additional Processing Information: Select Yes .

- Approver: Select Save .

- Delete all attachment documents from your computer.

**Adding, modifying or deleting a hyperlink to an event**

The authorized user adds, modifies or deletes a hyperlink, if necessary. If the employer provides a hyperlink to a document or when an attachment is larger than 10MB, the authorized user copies and pastes the link into the Hyperlinks section of the Additional Info . tab. Hyperlinks can only be added to an existing event.

Add a hyperlink as follows:

- Copy the hyperlink from its location.

- Open Major Employer Events and select English .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Menu , then select Major Employer Events .

- Enter the event name in the Search field.

- Select the event to access its content.

- Approver: Select Edit .

- Select the Additional Info. tab.

- On the Hyperlink section, select + .

- When the New Hyperlink window opens, paste the English hyperlink in the URL - English field.

- Hyperlink Description - English: Enter the name of the document accessed by the hyperlink.

- If the hyperlink is not available in English, type “The information is not available in English, refer to the French document.” in the Hyperlink Description - English field.

- If the hyperlink is available in French, repeat the previous steps to copy and paste the French hyperlink in the URL - French field in the New Hyperlink window. Enter the French name of the document accessed by the hyperlink in the Hyperlink Description - French field.

- If the hyperlink is not available in French, type “Les renseignements ne sont pas disponibles en français, consulter les renseignements en anglais.” in the Hyperlink Description - French field.

- Select Save .

- If there are other hyperlinks to add, repeat the previous steps until all necessary hyperlinks are added.

- Select the Event Summary tab.

- Additional Processing Information: Select Yes .

- Approver: Select Save .

If necessary, to modify a hyperlink, select the Edit Note icon of the appropriate hyperlink.

If necessary, to delete a hyperlink, select the Delete Note icon of the appropriate hyperlink.

**Adding statutory holiday pay information to an event**

The information about statutory holiday pay can only be added to an existing event. When the authorized user enters an amount of statutory holiday pay, it is rounded to the nearest dollar.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0442.dita) 

Add statutory holiday pay information as follows:

- Open Major Employer Events and select English .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Menu , then select Major Employer Events .

- Enter the event name in the Search field.

- Select the event to access its content.

- Approver: Select Edit .

- Select the Additional Info. tab.

- On the Statutory Holiday section, select + .

- When the New Statutory Holiday window opens, enter the date and amount of the statutory holiday pay in the appropriate fields.

- Select Save .

- Repeat these steps for each additional statutory holiday pay amount.

- Select the Event Summary tab.

- Additional Processing Information: Select Yes .

- Select the Save tab and select Save .

**Deactivating an event and reactivating a deactivated event**

An event can be deactivated but can still be consulted by authorized users in the MEE database. A deactivated event does not appear in the Major Employer Events — Information Bulletin page. An authorised user can reactivate a deactivated event.

Deactivate an event as follows:

- Open Major Employer Events and select English .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Menu , then select Major Employer Events .

- Select Deactivate .

- Check the box of the appropriate event.

- More than one event may be selected.

- Select Deactivate .

- When the Deactivate window opens, select the appropriate Status Reason and select Confirm .

Reactivate a deactivated event as follows:

- Open Major Employer Events and select English .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Menu , then select Major Employer Events .

- Views: Select Resolved Events .

- Select Activate .

- Check the box of the appropriate event.

- More than one event may be selected.

- Select Activate . When the Activate window opens, select the appropriate Status Reason and select Confirm . 

### Note

Source topic: `en_EN/common_notes/note_c_0441.dita`

Note:

An authorized user is normally designated by regional business expertise staff. For more information as to who is an authorized user, the officer emails the contact in the appropriate region at the address indicated in the Additional information section. 

### Note

Source topic: `en_EN/common_notes/note_c_0442.dita`

Note:

When entering the amount, a comma must be used. 
