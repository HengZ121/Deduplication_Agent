# Notice of decision: Requirements — Knowledge

Source map: `en_EN/procedure/generic/additionalresources/notice_decision_ja/notice_decision_ja.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/notice_decision_ja/additional_resources.dita`

Summary: When an officer renders a decision, a verbal or written notice of decision may be required.

Table of contents

Level 1
       [Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/notice_decision_ja#L1)

- Situations that require neither a written notice of decision nor verbal communication
         [Situations that require neither a written notice of decision nor verbal communication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/notice_decision_ja#S1)

- Situations that do not require a written notice of decision when the decision has already been communicated verbally
         [Situations that do not require a written notice of decision when the decision has already been communicated verbally](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/notice_decision_ja#S2)

- Situations that always require a written notice of decision
         [Situations that always require a written notice of decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/notice_decision_ja#alwaysnotice)

Level 2
       [Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/notice_decision_ja#L2)

- Situations that require neither a written notice of decision nor verbal communication
         [Situations that require neither a written notice of decision nor verbal communication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/notice_decision_ja#L3)

- Situations that always require a written notice of decision
         [Situations that always require a written notice of decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/notice_decision_ja#L4)

**Level 1**

**Situations that require neither a written notice of decision nor verbal communication**

There are situations in which a decision does not require a written notice of decision or verbal communication of the decision.

**Claim calculation**

- The claim has been finalized as BPNE 2.

- Following a recalculation, the BPNE claim becomes an established claim.

- The BPC is postdated to allow maternity or parental benefits to be fully paid.

- The BPC is postdated because the client worked a full work week in the week of filing.

- The BPC has been postdated because earnings during the week of the interruption of earnings prevent the client from serving the waiting period (WP) (if necessary, the officer can refer to Waiting period: Conditions that prevent serving of a waiting period — Table ).
         [Waiting period: Conditions that prevent serving of a waiting period — Table](/en/procedure/generic/additionalresources/bp_extension_bpc_table.shtml)

- The WP of a claim for regular or special benefits has been waived.

- The WP is deferred on a claim for parental, compassionate care or family caregiver benefits.

- A request to antedate or extend the qualifying period or benefit period (BP) has been granted.

- The information on the 14 best weeks provided by the client is not used or is partially used.

**Special benefits**

- The client is eligible to receive the maximum maternity benefits;

- The client is eligible to receive full or partial parental or compassionate care benefits;

- The client is eligible to receive the maximum maternity and parental benefits and there is no contentious reason for separation (RFS);

- The client is eligible to receive maternity or parental benefits under the Supplemental Unemployment Benefit Program;

- The RFS is D - Illness or injury , there is no medical certificate on file and the recovery week has been calculated as BPC + 8 weeks, renewal week + 8 weeks or conversion week + 8 weeks (or BPC + 15 weeks for a BPC before w/c 2442);

- A 46 - Variable entrance requirement not met - special benefits payable disentitlement (D46) is imposed to prevent the payment of future regular benefits, the RFS is not contentious and the client requests sickness, maternity, parental, compassionate care or family caregiver benefits. A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, a 46 - Variable entrance requirement not met - special benefits payable disentitlement (D46) will not be input on these claims.

**Earnings**

- The earnings for the last week worked were allocated to the first week of the BP or renewal;

- An exempted pension has been allocated;

- A week of benefits has not been paid because a full week of work was reported, but the client is still unemployed.

**Other situations**

- A disentitlement or disqualification has been rescinded and the claimant’s reports have been processed, making it possible to pay benefits;

- A decision by the Employment Insurance Board of Appeal (EI BOA) or Social Security Tribunal (SST) has been implemented;

- The claimant’s reports have been amended, making it possible to pay benefits for this period;

- A renewal claim has been established and there is no other rendered decision that requires communicating the decision.

- Adjudication of a contentious RFS has been deferred.

**Situations that do not require a written notice of decision when the decision has already been communicated verbally**

Whether the decision is related to an initial, renewal or revised claim, verbal communication of a decision is sufficient and it is not necessary to send a written notice of decision to the client when all of the following conditions have been met:

- It is a Level 1 decision (unless it requires a written notice);

- The decision could create an overpayment (OP), but only if the client contacts the Commission to rectify the erroneous information in the prescribed timeframes;

- The decision and the established OP, if any, have been verbally explained to the client;

- The client has been told that no letter will be sent;

- The client understands and agrees with the decision;

- The right to request a reconsideration under EIA 112 has been verbally explained to the client.

These conditions apply to decisions that are verbally communicated in person or by telephone.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0500.dita) 

**Situations that always require a written notice**

Regardless of whether or not the decision is related to an initial, renewal or revised claim, the officer must always send a notice of decision through ACS in the following situations, even if the client has been verbally informed of the decision. The officer can refer to Verbally communicating a negative decision for next steps.
       [Verbally communicating a negative decision](/en/procedure/task/verbal_communication.shtml)

**Claim calculation**

- A claim has been finalized as BPNE, including situations in which the client could be eligible to receive special benefits, except for BPNE 2 and D46 claims;

- A recalculation has changed the BPC, hours or insurable earnings, which created an OP;

- As a result of a recalculation, an established claim became BPNE (including D14 cancelled claims);

- A 56 - Quebec Parental Insurance Plan benefits disentitlement is imposed.

- A claim has been established and a decision about an allocation must be communicated to the client.

- A claim for maternity or parental benefits has been postdated because the client applied before the benefit window.

**Special benefits**

- The client is eligible to receive fewer than 15 weeks of maternity benefits;

- The client is not eligible to receive special benefits;

- The client is eligible to receive family caregiver benefits;

- The client is not eligible to receive family caregiver benefits;

- The initial, renewal or continuing claim has been approved for a period of sickness benefits based on a medical certificate.

**Decision regarding entitlement to benefits**

- The client could not be contacted to communicate the Level 1 decision;

- The client does not understand or does not agree with the verbally explained decision;

- A negative Level 2 decision has been rendered;

- A 15 - Claim Procedure disentitlement has been imposed.

**Letter to send to the employer**

- The officer must communicate the right to request a reconsideration under EIA 112 to the employer in the following circumstances:

- a dismissal, if misconduct was not proven for a reason other than unsuitability;

- voluntary leaving, if the client demonstrated just cause and the reasons for quitting are work-related;

- a refusal of employment or failure to take advantage of a job opportunity, if the client demonstrated good cause and the reasons for refusal are work-related;

- a disentitlement was not imposed, or ended during a work conflict.

- The client is eligible for Supplemental Unemployment Benefits and the client has worked for more than one employer;

**Other situations**

- The decision has been communicated to an authorized third party (client representative or interpreter);

- The client requested a written notice of decision;

- The client initially agreed with the decision when verbally informed, but subsequently expresses disagreement. In this situation, the officer must use an SROC to record the client’s statement indicating that the client no longer agrees with the decision. The officer must send the ACS letter as soon as the Commission is informed of this fact.

- Initially, no ACS letter was sent and the client now wants a reconsideration of the decision that was verbally communicated, but has not sent a request yet. If the client has already sent a request for reconsideration, no ACS letter is sent.

**Level 2**

**Situations that require neither a written notice of decision nor verbal communication**

There are situations in which a decision does not require a written notice of decision or verbal communication of the decision.

**Claim calculation**

- The RFS is D , there is no medical certificate on file and the recovery week has been calculated as BPC + 8 weeks, renewal week + 8 weeks or conversion week + 8 weeks (or BPC + 15 weeks for a BPC before w/c 2442);

- A request to antedate or extend the qualifying period (QP) or benefit period (BP) has been granted.

**Earnings**

- The earnings for the last week worked were allocated to the first week of the BP or renewal;

- An exempted pension has been allocated;

- A week of benefits has not been paid because a full week of work was reported, but the client is still unemployed.

**Other situations**

- A disentitlement or disqualification has been rescinded and the claimant’s reports have been processed, making it possible to pay benefits;

- A decision by the EI BOA or SST has been implemented;

- The claimant’s reports have been amended, making it possible to pay benefits for this period.

- Adjudication of a contentious RFS has been deferred.

**Situations that always require a written notice**

Regardless of whether or not the decision is related to an initial, renewal or revised claim, the officer must always send a notice of decision through ACS in the following situations, even if the client has been verbally informed of the decision. The officer can refer to Verbally communicating a negative decision for next steps:
       [Verbally communicating a negative decision](/en/procedure/task/verbal_communication.shtml)

- A negative Level 2 decision has been rendered;

- A 15 - Claim Procedure disentitlement (D15) has been imposed;

- An OP has been created and a penalty, a violation or a warning letter has been imposed;

- The decision has been communicated to an authorized third party (client representative or interpreter);

- The client requested a written notice of decision.

- A claim has been established and a decision about an allocation must be communicated to the client.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0500.dita) 

**Letter to send to the employer**

- The officer must communicate the right to request a reconsideration under EIA 112 to the employer in the following circumstances:

- a dismissal, if misconduct was not proven for a reason other than unsuitability;

- voluntary leaving, if the client demonstrated just cause and the reasons for quitting are work-related;

- a refusal of employment or failure to take advantage of a job opportunity, if the client demonstrated good cause and the reasons for refusal are work-related;

- a disentitlement was not imposed or ended during a work conflict.

Creating an ACS Notice

When a written notice of decision is required, the procedure indicates which letter template must be used and which decision attributes must be added. It also indicates if the letter should be saved or sent.

Some notices of decision are now generated automatically by the system. If the system generates the letter automatically, the officer is not required to complete a second letter. If the system cannot generate an automated letter, a Correspondence (COR) WI is created and the officer must complete the letter. For more information on COR WIs, refer to Correspondence WI . For more information on automated letters, consult Automated Correspondence Solution .
       [Correspondence WI](/en/procedure/activity/correspondence.shtml) 
       [Automated Correspondence Solution](https://esdc.prv/en/service-canada/ei/technologies/ei-correspondence/letters/index.shtml)

A notice is sent automatically for the following decisions:

- A claim is established as BPNE N1 or N6 (B-00-00-00 letter);

- A claim for maternity or parental benefits has been established and the number of weeks of maternity benefits is less than 15 (N-01-00-00 letter);

- A renewal claim has been established and an allocation decision must be communicated to the client (R-01-00-00 letter);

- A positive decision has been rendered on a contentious RFS and the employer must be informed of the right to request a reconsideration under EIA 112 (Z-01-00-00 letter). 

### Note

Source topic: `en_EN/common_notes/note_c_0500.dita`

Note:

Leaving a message on an answering machine, a voice mailbox or with a third party is not acceptable and does not constitute the verbal communication of a decision. If a client cannot be reached, the officer must send a notice of decision. 
