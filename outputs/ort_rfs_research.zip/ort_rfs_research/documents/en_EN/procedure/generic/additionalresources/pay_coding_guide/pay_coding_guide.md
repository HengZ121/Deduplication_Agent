# Claimant’s report: Pay coding (external or internal exclusion) — Input guide

Source map: `en_EN/procedure/generic/additionalresources/pay_coding_guide/pay_coding_guide.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/pay_coding_guide/additional_resources.dita`

When clients are excluded from electronic reporting, they must complete a paper claimant’s report to provide information for each week they are claiming benefits. To complete a claimant’s report for clients on Work-Sharing (WS), the IPOC officer goes to Work-Sharing — Pay coding guide .
       [Work-Sharing — Pay coding guide](/en/procedure/generic/additionalresources/pay_coding_guide_ws.shtml)

When the claim is in MPS, the IPOC officer uses the MPS e-ledger and the Claimant’s Reports (T072) transaction to process the client’s declaration. When the claim is in CPS, the officer uses the Issue Payments (M151/M152) transaction.
       [Claimant’s Reports (T072)](/en/procedure/generic/additionalresources/manual_pay_sys_claimant.shtml)

The paper claimant’s report contains 6 questions. Depending on the client’s answers, the IPOC officer or clerk may need to take additional actions. Whenever a client provides information that must be adjudicated or is outside what the officer or clerk can process, the officer or clerk sends an Action Item (AI) WI to Level 1.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0510.dita) 

The 6 questions are the following:

- Were you outside of Canada between Monday and Friday?
         [Were you outside of Canada between Monday and Friday?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pay_coding_guide#_Were_you_outside)

- Did you work, including work for which you will be paid later, unpaid work or self-employment?
         [Did you work, including work for which you will be paid later, unpaid work or self-employment?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pay_coding_guide#Did_you_work)

- Did you start a full-time job?
         [Did you start a full-time job?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pay_coding_guide#Did_you_start_1)

- Did you attend a school or training course(s)?
         [Did you attend a school or training course(s)?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pay_coding_guide#Did_you_attend)

- Were you ready, willing and capable of working each day?
         [Were you ready, willing and capable of working each day?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pay_coding_guide#Were_you_ready_1)

- Did you or will you receive money other than that already reported in 2d or 4b above?
         [Did you or will you receive money other than that already reported in 2d or 4b above?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pay_coding_guide#Did_you_or)

**Were you outside of Canada between Monday and Friday?**

Question 1 has 3 parts:

- Were you outside of Canada between Monday and Friday? (Answer “Yes” if you were outside Canada between Monday and Friday. Answer “No” if you were outside Canada during the weekend only.) If “Yes” complete 1b.

- Was your absence from Canada for a period of more than 24 hours, not including any hours that fell on the weekend?

- For all absences from Canada, provide the following:

- Departure date, time, AM/PM

- Return date, time, AM/PM

- Reason for absence

**Question 1a**

If the client selects Yes to question 1a, verify that parts 1b and 1c are completed.

```text
| Answer | MPS claimant’s reports | CPS claimant’s reports |

| MPS e-ledger | Issue Payments (M151/M152) |

| No | Go to question 2. | Go to question 2. |

| Yes | If there is a disentitlement for the same period on the TC85 tab: - DD/NA: Enter the number of non-available days for each week. On the FTS - ETI tab, select the appropriate options in the Payment code , Week 1 messages or Week 2 messages and Pay history (wk1) or Pay history (wk2) fields. If there is no disentitlement on file, do not process the claimant’s report. Refer to Creating an Action Item (AI) WI in the initial task. | If there is a disentitlement for the same period: Non-available day(s): Leave the field blank and process the claimant’s report. If there is no disentitlement on file, do not process the claimant’s report. Refer to Creating an Action Item (AI) WI in the initial task. |
```

**Did you work, including work for which you will be paid later, unpaid work or self-employment?**

Question 2 has 5 parts:

- Did you work, including work for which you will be paid later, unpaid work or self-employment? If “Yes”, complete 2b, 2c, 2d, and 2e.

- Total hours and dates worked

- Name and address of employer

- Total earnings before deductions

- if you stopped working, give the reason(s)

**Types of earnings declared**

The most common types of earnings reported by a client include:

- insurable employment

- fishing
         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0511.dita)

- self-employment (SE) (e.g. babysitting, real estate officer, taxi driver)
         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0512.dita)

However, a client can report earnings from many different sources. If a decision is required to determine if the earnings are insurable, send an AI WI to Level 1.

**Question 2a**

If the client selects Yes to question 2a, verify that parts 2b, 2c, 2d and 2e are completed.

Determine the number of hours worked. If it is 35 or more (or 28 or more for a week including a statutory holiday ) per week, code it as a FWW .
       [statutory holiday](/en/procedure/generic/additionalresources/stat_civic_holidays.shtml) 
       [FWW](http://wecs-siew.prv/wecs-siew/searchdetails_e.aspx?evalid=R013)

```text
| Answer | MPS claimant’s reports | CPS claimant’s reports |

| MPS e-ledger | Issue Payments (M151/M152) |

| No | Verify question 2e. | Verify question 2e. |

| Yes | On the TC85 tab: - Earnings: Enter the earnings. - FWW: Enter the FWW code, if necessary. On the FTS - ETI tab, select the appropriate options in the Payment code , Week 1 messages or Week 2 messages and Pay history (wk1) or Pay history (wk2) fields. | - Earnings: Enter the earnings. - Full work week: Select the FWW code, if necessary. |

| | Note: If the client also selects Yes to question 3, Did you start a full-time job? and indicates having: - found work on Sunday or Monday of week 1: - Select 1 - Found work on Sunday or Monday of week 1 in the Found work field. Do not code the FWW. Do not add earnings. - found work on Sunday or Monday of week 2: - Add earnings for week 1, if necessary, and code only the found work for week 2. Do not code the FWW or add earnings for week 2. - found work after Monday of week 1: - Add earnings for week 1, if necessary, and select 4 - Found work after Monday in the first week in the Found work field. If week 1 is a FWW, select 1 - Full work week - week 1 in the FWW field and select 2 - Found work on Sunday or Monday of week 2 in the Found work field. - found work after Monday of week 2: - Add earnings for week 1 and week 2, if necessary. Select 5 - Found work after Monday in the second week in the Found work field. Do not code the FWW for week 2. |
```

**Question 2e**

If the client indicates having stopped working and provides contentious information, send an AI WI to Level 1 for adjudication. Refer to Creating an Action Item (AI) WI in the initial task.

Examples of contentious information include:

- contentious reason for separation;

- availability issues;

- clarification of monies;

- clarification of training;

- clarification of work status (e.g. SE);

- labour dispute;

- name or address change reported;

- SIN change reported;

- correspondence attached (e.g. medical note);

- sickness benefits to regular benefits;

- maternity or parental period not set up; or

- any other conflicting information.

**Did you start a full-time job?**

If the client selects Yes to starting a full-time job during the period of this claimant’s report, consider the start date indicated and process the claimant’s reports with the appropriate found work code.
       [found work](http://wecs-siew.prv/wecs-siew/searchdetails_e.aspx?evalid=R012)

```text
| Answer | MPS claimant’s reports | CPS claimant’s reports |

| MPS e-ledger | Issue Payments (M151/M152) |

| No | Go to question 4. | Go to question 4. |

| Yes | On the TC85 tab: - Found Work: Enter the appropriate option. - Earnings: Enter the earnings, if necessary. On the FTS - ETI tab: - Payment code: Select the appropriate option. - Pay history (wk1) or Pay history (wk2): Select 38 - Found work week 1 or 2 . - Issue reports: Select N . | Earnings: Enter the earnings, if necessary. Found work: Select the appropriate code. |

| | Note: If the found work code is: - 1 - Found work on Sunday or Monday of week 1: - Do not add earnings. - 2 - Found work on Sunday or Monday of week 2: - Add earnings for week 1 but do not add earnings for week 2. - 3 - Found work on Monday of the week following week 2: - Add earnings for week 1 or 2, if necessary. - 4 - Found work after Monday in the first week: - Add earnings for week 1. However, if week 1 is a FWW, enter the earnings and select 1 - Full work week - week 1 in the FWW field. Also, instead of 4 - Found work after Monday in the first week , select 2 - Found work on Sunday or Monday of week 2 in the Found work field . - 5 - Found work after Monday in the second week: - Add earnings for week 1, if necessary. Add earnings for week 2. If week 2 is a FWW, do not code FWW. If the client indicates starting a full-time job, refer to [Terminating an active MPS claim](/en/procedure/task/terminating_active_mps.shtml) . [Terminating an active MPS claim](/en/procedure/task/terminating_active_mps.shtml) |
```

**Did you attend a school or training course(s)?**

Question 4 has 3 parts:

- Did you attend a school or training course(s)?

- If “Yes”, indicate the number of hours attended and any training allowance received in 4b, and indicate from whom this money was received in 4c.

- Training allowance and total hours

- Received from

If the client selects Yes to question 4a, verify the number of hours attended or any training allowance received in parts 4b and 4c. Also verify the Project tab in FTS for training information.

For an MPS claim, the Project link on the Manual Pay tab should also be highlighted, which indicates the Agreement - Project Update (T077) transaction was input. However, if the client is paid special benefits when referred to Section 25, do not input a T077 transaction.

Clients who are referred to Section 25 training continue to be paid special benefits as long as they meet the conditions for special benefits. When processing these payments using the Claimant’s Reports (T072) transaction, enter the correct special benefits pay history summary (PHS) code in the Pay history (wk1) or Pay history (wk2) fields.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0513.dita) 

```text
| Answer | MPS e-ledger | Issue Payments (M151/M152) |

| MPS claimant’s reports | CPS claimant’s reports |

| No | | Go to question 5. | Go to question 5. |

| Yes | The training code is 90 on the Project tab (i.e. not referred under section 25). | On the TC85 tab: - STUAE: Type “03.” - STUAE AMT: Type “0000” or enter the training allowance, if necessary. On the FTS - ETI tab: - Project activity: Select T - Trainee paid at training allowance rate . - Pay history (wk1) or Pay history (wk2): Select the appropriate option. [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0514.dita) | STUAE coding: Select T - Training and type “0000” or enter the training allowance, if necessary. |

| The training code is not 90 on the Project tab (e.g. 09, 21, 39, 53) (i.e. referred under section 25). | For special benefits only On the FTS - ETI tab: - Pay history (wk1) or Pay history (wk2): Select the appropriate special benefit option. For all other benefit types (BTs) On the TC85 tab: - STUAE: Type “03.” - STUAE AMT: Type “0000.” On the FTS - ETI tab: - Project activity: Select T - Trainee paid at training allowance rate . - Pay history (wk1) or Pay history (wk2): Select 06 - Part I (training) . | STUAE coding: Select T - Training and type “0000.” |

| [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0515.dita) |

| There is no training code on the Project tab. | - If the client declares less than 10 hours of training per week, do not code training and process the claimant’s report. - If the client declares 10 hours or more of training per week, refer to Creating an Action Item (AI) WI in the initial task. |
```

**Were you ready, willing and capable of working each day?**

Question 5 has 4 parts:

- Were you ready, willing and capable of working each day?

- If “No”, complete 5b and 5c, give the date(s) and reason(s). Complete 5d if applicable.

- Date(s)

- Reason(s)

- Group sickness/maternity insurance.

If the client selects No to question 5a, review the dates and reason indicated in parts 5b and 5c and verify part 5d.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0516.dita) 

```text
| Answer | MPS claimant’s reports | CPS claimant’s reports |

| MPS e-ledger | Issue Payments (M151/M152) |

| Yes | | Go to question 6. | Go to question 6. |

| No | The client declares sick days. | If the CT is 2, 6 or 7 and a client declares 5 days of sickness, and the week is processed on or after w/c 2385-5 and results in a payment as a casual sickness week, on the MN05 tab, do the following: - Cas. Sick Pd: Enter the appropriate number to increase the counter by 1 week, up to a maximum of 8 weeks. On the TC85 : - SICK: Enter the number of sick days for each week. On the FTS - ETI tab, select the appropriate options in the Payment code , Week 1 messages or Week 2 messages and Pay history (wk1) or Pay history (wk2) fields. | Sick day(s): Select the number of sick days for each week. |

| [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0517.dita) |

| The client declares maternity, parental, CCB or family caregiver benefits. | On the TC85 tab: - DD/NA: Leave the field blank. On the FTS - ETI tab, select the appropriate options in the Payment code , Week 1 messages or Week 2 messages and Pay history (wk1) or Pay history (wk2) fields. | Non-available day(s): Select 5 for each week. Note: Family caregiver benefits can only be paid on an MPS claim. |

| [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0518.dita) |

| The client declares non-available days. | On the TC85 tab: - DD/NA: Enter the number of non-available days for each week. On the FTS - ETI tab, select the appropriate options in the Payment code , Week 1 messages or Week 2 messages and Pay history (wk1) or Pay history (wk2) fields. | Non-available day(s): Select the number of non-available days for each week. |

| The client reports being on vacation within Canada between Monday and Friday during the period of this claimant’s report. | On the TC85 tab: - DD/NA: Enter the number of non-available days for each week. On the FTS - ETI tab, select the appropriate options in the Payment code , Week 1 messages or Week 2 messages and Pay history (wk1) or Pay history (wk2) fields. | - Non-available day(s): Do the following: - If there is a disentitlement for the same period, leave the field blank and process the claimant’s report. - If there is no disentitlement on file, enter the non-available days. |

| [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0519.dita) |

| The client reports being unavailable for another reason (e.g. out of Canada, incarcerated, jury duty, labour dispute.) | If there is a disentitlement for the same period on the TC85 tab: - DD/NA: Enter the number of non-available days for each week. On the FTS - ETI tab, select the appropriate options in the Payment code , Week 1 messages or Week 2 messages and Pay history (wk1) or Pay history (wk2) fields. If there is no disentitlement on file, do not process the claimant’s report. Refer to Creating an Action Item (AI) WI in the initial task. | If there is a disentitlement for the same period: Non-available day(s): Leave the field blank and process the claimant’s report. If there is no disentitlement on file, do not process the claimant’s report. Refer to Creating an Action Item (AI) WI in the initial task. |
```

**Did you or will you receive money other than that already reported in 2d or 4b above?**

Question 6 has 4 parts:

- Did you or will you receive money other than that already reported in 2d or 4b above?

- If “Yes”, complete 6b and 6c, indicating from whom and the reason this money was received, and 6d, indicating the amount.

- Received from

- Reason received

- Other monies before deductions

If the client answers No , return to the initial task.

If the client answers Yes , do one of the following:

- For monies or allocations other than wage loss insurance (WLI) or paid sick leave (PSL) (e.g. allocation code P - Pension-not exempt ), go to Monies or allocations other than wage loss insurance (WLI) or paid sick leave (PSL) .
         [Monies or allocations other than wage loss insurance (WLI) or paid sick leave (PSL)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pay_coding_guide#Monies_or_allocations)

- For WLI or PSL, go to Monies declared for wage loss insurance (WLI) or paid sick leave (PSL) .
         [Monies declared for wage loss insurance (WLI) or paid sick leave (PSL)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pay_coding_guide#Monies_declared_for)

**Monies or allocations other than wage loss insurance (WLI) or paid sick leave (PSL)**

```text
| | MPS claimant’s reports | CPS claimant’s reports |

| MPS e-ledger | Issue Payments (M151/M152) |

| Declared monies are equal to the allocated amount on file. | On the TC85 tab: - Alloc: Enter the amount indicated on the M175 tab. | Do not code the allocation. |

| Declared monies are greater or less than the allocated amount on file or there is no allocation on file. | Do not process the claimant’s report. Refer to Creating an Action Item (AI) WI in the initial task. | Do not process the claimant’s report. Refer to Creating an AI WI in the initial task. |
```

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0520.dita) 

**Monies declared for wage loss insurance (WLI) or paid sick leave (PSL)**

**CPS claimant’s reports**

Declared monies are equal to the allocated amount on file.

Do not code the allocation.

Declared monies are greater or less than the allocated amount on file or there is no allocation on file.

Do not process the claimant’s report. Refer to Creating an Action Item (AI) WI in the initial task.

**MPS claimant’s reports**

The premium reduction code is 1 - No Premium Reduction , and the client declares WLI or PSL.

Deduct 50% of the earnings up to the 90% threshold, then dollar for dollar.

On the M175 tab:

- Type: Select the appropriate option:

- If the client declares WLI, type “F.”

- If the client declares PSL, type “L.”

On the TC85 tab:

- Alloc: Enter the WLI or PSL amount, or the total amount if both.

The premium reduction code is 2 - Premium Reduction for a Wage Loss Insurance plan , and the client declares WLI.

Deduct WLI dollar for dollar for BTs 10, 11, 73 and 74 only.

On the M175 tab:

- Type: Type “F.”

On the TC85 tab:

- STUAE: Type “02.”

- STUAE AMT: Enter the WLI amount.

- Alloc: Leave the field blank.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0521.dita) 

The premium reduction code is 2 - Premium Reduction for a Wage Loss Insurance plan , and the client declares PSL.

Deduct 50% of the earnings up to the 90% threshold, then dollar for dollar.

On the M175 tab:

- Type: Type “L.”

On the TC85 tab:

- Alloc: Enter the amount of the PSL.

The premium reduction code is 3 - Premium Reduction for a Paid Sick Leave plan , and the client declares WLI.

Deduct 50% of the earnings up to the 90% threshold, then dollar for dollar.

On the M175 tab:

- Type: Type “F.”

On the TC85 tab:

- Alloc: Enter the amount of the WLI.

The premium reduction code is 3 - Premium Reduction for a Paid Sick Leave plan , and the client declares PSL.

Deduct PSL dollar for dollar for BTs 10, 11, 73 and 74 only.

On the M175 tab:

- Type: Type “L.”

On the TC85 tab:

- STUAE: Type “04.”

- STUAE AMT: Enter the PSL amount.

- Alloc: Leave the field blank.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0521.dita) 

The premium reduction code is 4 - Premium Reduction for a Wage Loss Insurance plan and a Paid Sick Leave plan , and the client declares WLI or PSL or both.

Deduct WLI or PSL dollar for dollar for BTs 10, 11, 73 and 74 only.

On the M175 tab:

- Type: Select the appropriate option:

- If the client declares WLI, type “F.”

- If the client declares PSL, type “L.”

On the TC85 tab:

- STUAE: Type “02.”

- STUAE AMT: Enter the WLI or PSL amount, or the total amount if both.

- Alloc: Leave blank.

There is no premium reduction code, the BT is 10, 11, 73 or 74, and the client declares WLI or PSL for w/c 2147 or later.

Send an AI WI to obtain the premium reduction code before processing the claimant’s report.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0522.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0510.dita`

Note:

In the Western Canada and Territories region, if there is information that must be adjudicated or is outside what the IPOC officer or clerk can process, the officer or clerk sends an AI WI to the regional payment unit to review. If the portion of the claimant’s report to review is outside even what the regional payment unit officer is able to do, the regional payment unit officer then sends an AI WI to Level 1 for review and action. 

### Note

Source topic: `en_EN/common_notes/note_c_0511.dita`

Note:

If a fisher reports hours worked but no earnings, do not code them as a full work week (FWW). 

### Note

Source topic: `en_EN/common_notes/note_c_0512.dita`

Note:

When SE has been adjudicated and allowed, 2 - Self-employed not on SE Project is displayed on the Special Coding screen in FTS. If 2 - Self-employed not on SE Project is not displayed in FTS, or the client reports changes to the SE activity, refer to Creating an Action Item (AI) WI in the initial task. 

### Note

Source topic: `en_EN/common_notes/note_c_0513.dita`

Note:

For short training breaks (e.g. Christmas), continue to code as training. A processing officer provides other approved breaks on an Operational Centre Memo (MM06) . 

### Note

Source topic: `en_EN/common_notes/note_c_0514.dita`

Note:

Do not select 06 - Part I (training) . 

### Note

Source topic: `en_EN/common_notes/note_c_0515.dita`

Note:

If a client reports an allowance, refer to Creating an Action Item (AI) WI in the initial task. 

### Note

Source topic: `en_EN/common_notes/note_c_0516.dita`

Note:

For a deceased client, EIR 27 authorizes the payment of EI benefits to a person who acts on behalf of a deceased client. Verify if there is a representative on file. If there is not, do not process the claimant’s report and send an AI WI to Level 1. 

### Note

Source topic: `en_EN/common_notes/note_c_0517.dita`

Note:

Sickness benefits are payable to a client who meets the eligibility requirements for a maximum of 15 or 26 weeks. If the BPC is on w/c 2374 or after, the total of maximum payable sickness weeks per benefit period (BP) is 26. If the BPC is before w/c 2374, the total maximum payable sickness weeks per BP is 15. Only 5 full consecutive days from Monday to Friday is considered a sick week. When one to 4 sick days are declared on a CT 2, 6, or 7 and the sick counter is already at the maximum of 15 or 26 weeks paid, reduce the benefits by one fifth for each sick day reported.

When a client declares sick days on an original claimant’s report and there is no recovery week on the claim, only 4 consecutive weeks can be declared as casual sickness benefits. When a client declares sick days on an original claimant's report and there is no recovery week on the claim and the claimant’s report is processed on or after w/c 2385-5, only a total of 8 weeks of casual sickness benefits can be paid on a CT 2, 6 or 7. For an MPS claim, if the client continues to report sickness and the maximum of 15 or 26 weeks of sickness, depending on the BPC, have not been paid, the Service Canada Centre (SCC) must be notified. IPOC cannot process the fifth consecutive week or the ninth cumulative week paid unless the SCC indicates a change to CT 3 or 9 with a recovery week. Refer to Creating an Action Item (AI) WI in the initial task. However, for a CPS claim, the officer inputs the M152, which generates a C465 error code for the fifth consecutive week or a C484 error code for the ninth cumulative week and notifies the SCC. 

### Note

Source topic: `en_EN/common_notes/note_c_0518.dita`

Note:

Clients who receive maternity, parental, CCB and family caregiver benefits are not required to be ready, willing and capable of working each day. If a client declares maternity, parental, CCB or family caregiver benefits and the CT on file is not one of these, refer to Creating an AI WI in the initial task. 

### Note

Source topic: `en_EN/common_notes/note_c_0519.dita`

Note:

If a client declares vacation for 6 weeks or more, refer to Creating an Action item (AI) WI in the initial task. 

### Note

Source topic: `en_EN/common_notes/note_c_0520.dita`

Note:

Allocation code P - Pension-not exempt is used to allocate a pension income that is deducted from benefits. Allocation code Q - Pension-exempt is used to allocate a pension that is not deducted from benefits.

For MPS claimant’s reports, pensions with the Q code are not recorded on the TC85 or FTS tab, but pensions with a P code are recorded on the appropriate tab(s).

For CPS claimant’s reports, do not include monies from any allocations in the Allocations field on the Issue Payments (M151/M152) transaction. 

### Note

Source topic: `en_EN/common_notes/note_c_0521.dita`

Note:

All other earnings are deducted at 50% up to the 90% threshold, then dollar for dollar. 

### Note

Source topic: `en_EN/common_notes/note_c_0522.dita`

Note:

If the amount reported is greater than the no benefits payable amount, process the claimant’s report as the client is not entitled to any benefits that week. 
