# Family caregiver: Information on benefits — Knowledge

Source map: `en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge/family_caregiver_benefits_knowledge.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge/additional_resources.dita`

Summary: Family caregiver benefits provide temporary income replacement to eligible family members who take leave from work to provide care or support to a critically ill or injured patient.

**Table of contents**

- Family caregiver benefits for children
         [Family caregiver benefits for children](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#FCBC)

- Family caregiver benefits for adults
         [Family caregiver benefits for adults](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#FCBA)

- Family caregiver benefits for children and family caregiver benefits for adults in the same benefit period (BP)
         [Family caregiver benefits for children and family caregiver benefits for adults in the same benefit period (BP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#sameBP)

- Critically ill or injured child turns 18
         [Critically ill or injured child turns 18](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Child18)

- Processing family caregiver benefits

- Claim type (CT)
             [Claim type (CT)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Claim_type(CT))

- Disentitlements
             [Disentitlements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Disentitlements)

- Antedate
             [Antedate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Antedate)

         [Processing family caregiver benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Processing_PCIC_family)

- Qualifying conditions

- Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to 2361)
             [Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#_Qualifying_for_benefits)

         [Qualifying conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Qualifying_conditions)

- Entitlement Conditions

- Family caregiver window (FCW)
             [Family caregiver window (FCW)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#PCIC_Family_caregiver)

- Maximum benefits payable
             [Maximum benefits payable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Maximum_benefits_payable)

- BP extension
             [BP extension](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Benefit_period_(BP))

         [Entitlement Conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#entitle)

- Waiting period (WP)

- Deferring the waiting period (WP)
             [Deferring the waiting period (WP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Deferral_of_the)

- Waiving the waiting period (WP)
             [Waiving the waiting period (WP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Waiving_of_the)

         [Waiting period (WP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Waiting_period_(WP))

- Medical documentation

- Proof of critically ill or injured patient
             [Proof of critically ill or injured patient](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Proof_of_critically)

- Subsequent medical certificate
             [Subsequent medical certificate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Subsequent_medical_certificate)

- Providing care or support
             [Providing care or support](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Providing_care_or)

- Policy for newborns
             [Policy for newborns](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Interim_policy_for)

         [Medical documentation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Medical_documentation)

- Claimant’s report

- Exemption from reporting
             [Exemption from reporting](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#NOCR)

         [Claimant’s report](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#CR)

- Entitlement issues

- Deferred reason for separation (RFS)
             [Deferred reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Deferred_RFS)

- National Policy on Levels of Decision
             [National Policy on Levels of Decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Levels_of_decision)

- Allocation of monies
             [Allocation of monies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Allocation_of_monies)

- Not otherwise available
             [Not otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Not_otherwise_available)

- Sharing benefits
             [Sharing benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Sharing_of_benefits)

- More than one patient
             [More than one patient](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#More_than_one)

- Training
             [Training](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#train)

- Out of Canada or out of area
             [Out of Canada or out of area](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Out_of_Canada)

- Teachers
             [Teachers](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Teachers)

         [Entitlement issues](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Entitlement_issues)

- Combining benefits
         [Combining benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Combination_of_Benefits)

- Conversions from another benefit type (BT) to family caregiver benefits
         [Conversions from another benefit type (BT) to family caregiver benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Conversions_from_another)

- Conversions from family caregiver benefits to other benefit type (BTs)
         [Conversions from family caregiver benefits to other benefit type (BTs)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/family_caregiver_benefits_knowledge#Conversions_from_PCIC)

**Family caregiver benefits for children**

Family caregiver benefits for children provide temporary income to eligible clients who take leave from work to care for a critically ill or injured patient who is under the age of 18 at the time the family caregiver window (FCW) is established. Clients can claim a total of 35 weeks during any given BP.

The officer refers to Family member for a list of all eligible family members and close relatives and their relation to the critically ill or injured patient.
       [Family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0449.dita) 

**Family caregiver benefits for adults**

Family caregiver benefits for adults provide temporary income to eligible clients who take leave from work to care for a critically ill or injured patient who is over the age of 18 at the time the FCW is established. Clients can claim a total of 15 weeks during any given BP.

The officer refers to Family member for a list of all eligible family members and close relatives and their relation to the critically ill or injured patient.
       [Family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

**Family caregiver benefits for children and family caregiver benefits for adults in the same benefit period**

Family caregiver benefits for children and family caregiver benefits for adults are treated as separate benefit types (BTs) and can both be paid within a benefit period (BP) to their individual maximum entitlement if a client meets the criteria for both types. The restriction is that both types cannot be claimed for the same critically ill or injured patient in the same BP (see critically ill or injured child turns 18).
       [maximum entitlement](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

**Critically ill or injured child turns 18**

If a critically ill or injured child turns 18 during the FCW, the client can continue to receive family caregiver benefits for children.

**Processing family caregiver benefits**

The Centre of Specialization in Sudbury processes all family caregiver benefits claims and the IPOC officers in all 4 regions process the IPOC processing portion.

Claims for family caregiver benefits are not automated. They are completed through SSO and transmitted as usual. The claim is established in CPS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0450.dita) 

**Claim type (CT)**

There are 4 CTs for family caregiver benefits:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- 78 - Self-employed - Family caregiver for children

- 90 - Self-employed - Family caregiver for adults

**Disentitlements**

If the client is not providing care or support for the patient, the officer imposes a 61 - Family caregiver for children or adults - Does not meet entitlement conditions (D61) disentitlement.

When all weeks have been paid, the officer imposes a 62 - Family caregiver for children or adults - Benefits exhausted (D62) disentitlement.

When the medical certificate requirements are not met, the officer imposes a 63 - Family caregiver for children or adults - No medical proof (D63) disentitlement.

**Antedate**

The normal adjudication principles for antedates apply for family caregiver benefits claims. The officer refers to Antedate for additional information.
       [Antedate](/en/procedure/activity/antedate.shtml)

An antedate for family caregiver benefits is denied in the following situations:

- at the time the claim is made, 35 weeks of family caregiver benefits for children have been paid;

- at the time the claim is made, 15 weeks of family caregiver benefits for adults have been paid;

- the period of entitlement has already been established for another client and the request to antedate would move the start week of the 52-week window to an earlier date.

**Qualifying conditions**

The qualifying conditions are the same as for other special benefits. A client qualifies for family caregiver benefits if the following conditions are met:

- The client has had an interruption of earnings (I of E).

- The client is major attached (has accumulated at least 600 hours of insurable employment) or the BPC is between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361) and the client has at least 420 hours of insurable employment. If the client has a violation on file, increased entrance requirements may apply.
         [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

**Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a CER of 420 hours of insurable employment is required to establish a claim for regular or special benefits. If the client has a violation on file, increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

**Entitlement conditions**

A client is entitled to family caregiver benefits if the following conditions are met:

- The client is a family member as outlined in Family member .
         [Family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

- The patient is critically ill or injured and is under the age of 18 at the time the 52-week window opens (family caregiver benefits for children).

- The patient is critically ill or injured and is 18 or older at the time the 52-week window opens (family caregiver benefits for adults).

- The client submits medical documentation proving that the patient is critically ill or injured and requires the care or support of the client.

**Family caregiver window (FCW)**

The 52-week window in which benefits are payable begins in the week in which either of the following falls:

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0451.dita) 

**Start date of the family caregiver window (FCW) for a newborn**

If the medical certificate does not provide a start date when conditions were met or the date provided matches the date of the signature, the start date of the FCW is determined as follows:

- If the date the doctor or nurse practitioner signed the medical certificate is 4 weeks or less after the week the child was born (week of birth + 4), the start date of the FCW is the child’s week of birth.

- If the date the doctor or nurse practitioner signed the medical certificate is 5 weeks or more after the week the child was born (week of birth + 5), the start date of the FCW is the date of signature.

The start date of the FCW should always be based on what is best for the client. Fact-finding with the client may be necessary to determine what is most advantageous. For more information, the officer refers to Family Caregiver Benefits – Newborns – BE 2025-01 (BE Memo) .
       [Family Caregiver Benefits – Newborns – BE 2025-01 (BE Memo)](/en/policy/bememo/be2025-01.shtml)

The FCW ends on the earlier of the following situations:

- the 52-week window has expired;

- the 35 weeks of family caregiver benefits for children or 15 weeks of family caregiver benefits for adults have been paid (either shared or paid to one individual);

- the gravely ill or injured patient dies.

**Maximum benefits payable**

Clients can claim a total of 35 weeks of family caregiver benefits for children and a total of 15 weeks of family caregiver benefits for adults during any given BP. Family caregiver benefits can be shared between clients. Family caregiver benefits do not have to be paid consecutively. They can be paid intermittently during the BP or the 52-week FCW in a manner that is most convenient to the client, provided the required medical certificate proves the patient’s critical illness or injury during the weeks claimed.

**Benefit period (BP) extension**

The BP can be extended for a maximum of 104 weeks to pay additional weeks of family caregiver benefits if all of the conditions are met before the BP ends. For more information, the officer refers to Extension of the benefit period . For more information on BP extension, the officer refers to Benefit period extension for special benefits .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml) 
       [Benefit period extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

**Waiting period (WP)**

The client must serve a WP to receive family caregiver benefits. In some situations, the WP can be deferred or waived.

**Deferring the waiting period (WP)**

The normal one-week WP applies to family caregiver benefits. In certain instances, only one WP is served for the same critically ill family member.

The WP can be deferred when:

- another family member has received the same type of family caregiver benefits for the same patient and has already served the WP;

- multiple family members are requesting benefits at the same time for the same patient, and another family member serves the WP;

The WP is deferred until another BT is requested.

**Waiving the waiting period (WP)**

Current provisions for waiving the WP are applied to family caregiver benefits claims when the following conditions are met:

- After the last day worked (LDW), the client received paid sick leave (PSL) from the employer.

- The client experienced an I of E from employment under EIR 14(2) for special benefits.
         [EIR 14(2)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-4.html)

**Medical documentation**

**Proof of critically ill or injured patient**

In order to prove that a patient is critically ill or injured and requires care or support of a family member, a client must obtain a medical certificate that attests that the patient’s baseline state of health has changed significantly, that the patient’s life is at risk as a result of an illness or injury and that the patient requires care or support of a family member. The medical certificate must be signed by a doctor or a nurse practitioner.

**Period of care and support**

If the doctor or nurse practitioner indicates that the period of care and support is unknown or indefinite, that does not indicate the period during which the patient requires care or support.

The doctor or nurse practitioner must provide an actual period of time during which the patient requires care or support. If the period of time is a specific number of weeks instead of the actual to and from dates, the period of care and support begins on the date the medical certificate was issued.

The patient or representative must complete and sign a Authorization to release medical information for Employment Insurance Compassionate Care and Family Caregiver Benefits (INS5257) form so the doctor or nurse practitioner can release medical information.
       [Authorization to release medical information for Employment Insurance Compassionate Care and Family Caregiver Benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242A.pdf)

A client applying for family caregiver benefits must submit the Medical Certificate for Employment Insurance Family Caregiver Benefits form.
       [Medical Certificate for Employment Insurance Family Caregiver Benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242B.pdf)

The critically ill or injured patient does not always live in Canada and the client can be required to leave Canada to provide care or support for the patient where the patient lives. In these situations, it is still necessary for the client to submit a Medical Certificate for Employment Insurance Family Caregiver Benefits form completed by a doctor or nurse practitioner.
       [Medical Certificate for Employment Insurance Family Caregiver Benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242B.pdf)

To determine if a medical certificate is acceptable, the officer refers to Determining if a medical certificate is acceptable — Family caregiver benefits .
       [Determining if a medical certificate is acceptable — Family caregiver benefits](/en/procedure/task/determining_pcic_med_cert.shtml)

**Subsequent medical certificate**

The period during which the patient requires care and support includes both the initial period during which the patient is critically ill or injured and also the recovery period after the patient’s condition has improved but has not yet returned to the patient’s normal state of health.

The specialist can issue a second medical certificate so the client can also be paid benefits during the patient’s recovery period.

A client who requests benefits during the recovery period must submit a subsequent Authorization to Release Medical Information for Employment Insurance Compassionate Care and Family Benefits (INS5257) form and a Medical Certificate for Employment Insurance Family Caregiver Benefits form.
       [Authorization to Release Medical Information for Employment Insurance Compassionate Care and Family Benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242A.pdf) 
       [Medical Certificate for Employment Insurance Family Caregiver Benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242B.pdf)

**Providing care or support**

Patients may require the care and support of a family member because of their state of health as well as for psychological or emotional support.

Care and support include situations where the client simply spends time each day with the critically ill or injured patient in a home, a hospice or a medical facility. The client may stop providing care to the patient for a few days while claiming family caregiver benefits.

To determine if a client is providing care or support for a critically ill child, the officer can refer to Determining if a client applying for family caregiver benefits is providing care or support to a critically ill or injured patient .
       [Determining if a client applying for family caregiver benefits is providing care or support to a critically ill or injured patient](/en/procedure/task/determining_pcic_benefit_child.shtml)

**Policy for newborns**

The Policy for newborns provides guidance when family caregiver benefits for children are requested for a newborn.
       [Policy for newborns](/en/policy/bememo/be2025-01.shtml)

**Baseline state of health**

The medical certificate is accepted even if it does not confirm there is a significant change in the baseline state of health.

A child whose life is at risk from birth as a result of a serious illness or injury does not have a baseline state of health. Therefore, the Medical Certificate for Employment Insurance Family Caregiver Benefits can be accepted when the answer to question 2 in Section B may be Yes , No or left blank.

**Start date of the family caregiver window (FCW)**

If the medical certificate does not provide a start date when conditions were met (life at risk as a result of illness or injury, change in baseline of health and care or support is required) or the date provided matches the date of the signature, the start date of the FCW is determined as follows:

- If the date the doctor or nurse practitioner signed the medical certificate is 4 weeks or less after the week the child was born (week of birth + 4), the start date of the FCW is the child’s week of birth.

- If the date the doctor or nurse practitioner signed the medical certificate is 5 weeks or more after the week the child was born (week of birth + 5), the start date of the FCW is the date of signature.

The start date of the FCW should always be based on what is best for the client. Fact-finding with the client may be necessary to determine what is most advantageous. For more information, the officer refers to Family Caregiver Benefits – Newborns – BE 2025-01 (BE Memo) .
       [Family Caregiver Benefits – Newborns – BE 2025-01 (BE Memo)](/en/policy/bememo/be2025-01.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0452.dita) 

**Claimant’s reports**

When the claim is in MPS, clients must complete paper claimant’s reports unless they request to be exempted from completing claimant reports.

**Exemption from reporting**

Clients can be exempt from reporting while receiving family caregiver benefits. When the claim is in MPS, the officer sends an Operational Centre Memo (MM06) transaction to IPOC requesting that the NO-CR-CODE be input. For more information, the officer refers to Inputting an exemption from reporting . When the client no longer meets the eligibility criteria (e.g. BT changes from family caregiver benefits to sickness or a client reports part-time employment), the officer sends an MM06 to IPOC requesting that the NO-CR-CODE be rescinded. For more information, the officer refers to Cancelling an exemption from reporting .
       [Inputting an exemption from reporting](/en/procedure/task/inputting_exemption_rep.shtml) 
       [Cancelling an exemption from reporting](/en/procedure/task/cancelling_exemption_rep.shtml)

**Entitlement issues**

**Deferred reason for separation (RFS)**

On an initial claim for family caregiver benefits, the officer can defer fact-finding and adjudication related to a contentious RFS if certain conditions are met.

On a renewal claim for family caregiver benefits, the officer can defer fact-finding for and adjudication of a contentious RFS if an indefinite disqualification was imposed as a result of adjudication. Special benefits are paid regardless of whether the client has enough hours to establish a new claim.

For more information, the officer refers to Deferral of adjudication .
       [Deferral of adjudication](/en/procedure/activity/deferral_adj.shtml)

**National Policy on Levels of Decision**

To determine if a decision is within Level 1 decision of authority, the officer refers to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

If the decision is not within Level 1 authority, the issue must be referred to Level 2 for adjudication as follows:

- Initiate the fact-finding.

- Input the conversion.

- Impose a manual action to stop payment (MA01).

**Allocation of monies**

When a client declares receiving money, the officer must determine if the money received is to be considered earnings for EI purposes. If the officer determines that the money is considered earnings, the officer refers to Earnings to determine how the money is to be allocated.
       [Earnings](/en/procedure/activity/earnings.shtml)

**Working While on Claim (WWC)**

Earnings declared on family caregiver claims will be deducted in the same way as parental, compassionate care and regular benefits using the WWC provisions.

For more information, the officer refers to Pilot Project 17: Increase allowable earnings — Earnings deduction calculation and Pilot Project: Working while on claim — Earnings deduction calculation .
       [Pilot Project 17: Increase allowable earnings — Earnings deduction calculation](/en/procedure/generic/additionalresources/pp_iae_edc.shtml) 
       [Pilot Project: Working while on claim — Earnings deduction calculation](/en/procedure/generic/additionalresources/pp_wwoc_edc.shtml)

**Not otherwise available**

Clients do not need to prove that they would be otherwise available or otherwise working to access family caregiver benefits.

**Sharing benefits**

The legislation provides that one or more eligible clients can share family caregiver benefits for a critically ill or injured patient. The officer can divide the weeks as agreed to by those clients. When these benefits are shared, the officer determines whether other family members are claiming or have claimed family caregiver benefits to care for the same critically ill or injured patient, and the number of weeks being claimed by the other family members. When eligible clients cannot agree on how to share benefits, the officer divides the remaining weeks based on the prescribed rules. For more information, the officer refers to Adjudicating the sharing of family caregiver benefits — Disagreement on how to share weeks .
       [Adjudicating the sharing of family caregiver benefits — Disagreement on how to share weeks](/en/procedure/task/adjudicating_na_pcic_bw.shtml)

**More than one patient**

There may be situations in which there is more than one critically ill or injured patient. Separate 52-week periods can be established for each critically ill or injured patient. The maximum number of benefits payable is as follows:

- a maximum of 35 weeks per child or 15 weeks per adult during the related 52-week FCW; and

- a maximum of 35 weeks (family caregiver benefits for children) or 15 weeks (family caregiver benefits for adults) of benefits can be paid during any given BP.

This means that family members could each establish a BP for one patient and be payable the maximum family caregiver weeks or the family members can share the weeks for each patient to the maximum per patient and BP.

**Training**

A Level 1 officer can allow family caregiver benefits when the client is attending a non-referred course of instruction under EIA 25 if:

- the training is less than 25 hours per week;

- the training is not at a location that requires the client to reside away from the patient while attending the course.

For more information, the officer refers to Training .
       [Training](/en/procedure/activity/training.shtml)

**Out of Canada or out of area**

The critically ill or injured patient does not always reside in Canada, and the client may be required to leave Canada to provide care or support wherever the patient resides. In these situations, it is still necessary for the client to submit a medical certificate completed by a doctor or nurse practitioner with the same type of proof that is required for a critically ill or injured patient residing in Canada.

When the client provides the required information and meets all other entitlement conditions, family caregiver benefits can be paid while the client is out of Canada or out of area.

Clients can be absent from actually providing care to the family member for a short period of time (up to 2 days) while claiming family caregiver benefits. An officer must adjudicate anything over 2 days away from the critically ill or injured patient.

**Teachers**

As is the case for maternity, parental and CCB, family caregiver benefits are payable to teachers during both the teaching and non-teaching periods, provided the client meets all other entitlement conditions for the payment of these benefits.

For more information, the officer refers to Teachers .
       [Teachers](/en/procedure/activity/teachers.shtml)

**Combining benefits**

Special benefits can be paid in any combination during the initial BP, provided the client proves entitlement for each BT and does not exceed the maximum entitlement to benefits .
       [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

**Compassionate Care Benefits (CCB) and family caregiver benefits**

If the critically ill patient's condition deteriorates and results in an end-of-life situation, the client receiving family caregiver benefits can apply for and receive up to 26 weeks of CCB once the FCW has ended (all weeks of FCB have been paid or the 52-week period has elapsed).

If CCB was paid first and there is a significant new change in the patient's normal state of health, the client may receive family caregiver benefits. The compassionate care window does not have to end for family caregiver benefits to become payable.

However, a family member who continues to receive CCB to care for the patient will no longer be eligible if another family member begins to receive family caregiver benefits. In such situations, the other family member must convert his or her claim and share the family caregiver benefits, or wait until the FCW ends (all weeks of benefits have been paid, or the 52-week period has elapsed). If the client applies for CCB before all weeks of family caregiver benefits have been paid or before the end of the FCW, the officer imposes an disentitlement 51 - Does not meet eligibility requirements for Compassionate Care Benefits and sends the appropriate ACS letter.

**Conversions from another benefit type (BT) to family caregiver benefits**

When the client files a CT conversion to family caregiver benefits, the officer completes the following inputs in FTS:

- With or without an effective week, the officer changes the CT to 20, 21, 78 or 90.

- If a disentitlement is required, the officer inputs the appropriate disentitlement.

- The last week of the previous BT requested must be paid before the officer inputs the conversion transactions.

- If the CT changes from regular to family caregiver benefits, a renewal week must be input on the Caregiver/Compassionate care entitlement (M112) screen.

- If the client has provided an invalid medical certificate or does not meet the entitlement conditions, no MM06 is required. When the client is entitled to benefits, the officer creates an MM06 to have IPOC convert the claim to MPS to continue payments.

**Conversions from family caregiver benefits to other benefit types (BTs)**

Conversions are completed within the normal processing workload and are not to be assigned or reassigned to the Centre of Specialization.

If a client requests a conversion from family caregiver benefits to sickness, parental or regular benefits, the officer completes the appropriate checklist with the client.

A client who is requesting a conversion to CCB must complete an application online. CCB can be paid either before the FCW starts or after it ends but CCB cannot be paid during an existing FCW for the same patient. The FCW ends when all weeks of family caregiver benefits have been paid or the 52-week window ends.

If a client is requesting a conversion to maternity benefits, the officer verifies if the client has completed an application for maternity previously for this BPC. If so, the officer refers to the checklist to complete the conversion. If not, the officer advises the client to apply online.

The officer notes and advises the client that if a conversion to maternity, parental or CCB is completed, the payments and claimant reports are processed MPS for the remainder of the claim. In this case, clients must complete paper claimant’s reports unless they request to be exempted from completing claimant reports. After reviewing the conversion request and entitlement conditions, the officer creates an MM06 to request the conversion.

When creating the MM06, the officer includes all information required for the completion of the conversion. This includes:

- the BT being requested;

- the period for which the benefits are to be paid;

- the number of weeks being requested (if necessary);

- any required allocations, BP extensions, disentitlements, etc.

- the exemption from completing claimant reports.

**Related procedures**

- Determining if a medical certificate is acceptable — Family caregiver benefits
         [Determining if a medical certificate is acceptable — Family caregiver benefits](/en/procedure/task/determining_pcic_med_cert.shtml)

- Determining if a client applying for family caregiver benefits is providing care or support to a critically ill or injured family member
         [Determining if a client applying for family caregiver benefits is providing care or support to a critically ill or injured family member](/en/procedure/task/determining_pcic_benefit_child.shtml)

- Adjudicating the sharing of family caregiver benefits — Disagreement on how to share weeks
         [Adjudicating the sharing of family caregiver benefits — Disagreement on how to share weeks](/en/procedure/task/adjudicating_na_pcic_bw.shtml)

- Determining if the client is entitled to the family caregiver benefits weeks requested
         [Determining if the client is entitled to the family caregiver benefits weeks requested](/en/procedure/task/determine_client_fcb_pppa.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0449.dita`

Note:

Before December 3, 2017 these benefits were referred to as PCIC benefits and were only payable to parents of the critically ill child, whereas now they are payable to a family member of the child.
       [family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

     [family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0450.dita`

Note :

Claims for family caregiver benefits for children and family caregiver benefits for adults initially processed in MPS before the implementation of Phase 2 of Budget 2017 are not being converted to CPS. 

### Note

Source topic: `en_EN/common_notes/note_c_0451.dita`

Note:

When the date of the examination and the date the doctor or nurse practitioner certifies the conditions applied at an earlier period of time are different, the start date of the FCW is the date that allows the client to collect the weeks requested. 

### Note

Source topic: `en_EN/common_notes/note_c_0452.dita`

Note:

All the other requirements must be met: the medical certificate is signed, the doctor or nurse practitioner is validated and the authorization is signed by the correct person. 
