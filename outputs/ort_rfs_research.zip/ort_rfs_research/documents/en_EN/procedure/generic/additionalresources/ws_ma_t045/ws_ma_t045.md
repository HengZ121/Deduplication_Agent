# T045: Work-Sharing conditions and required actions — Transaction

Source map: `en_EN/procedure/generic/additionalresources/ws_ma_t045/ws_ma_t045.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/ws_ma_t045/additional_resources.dita`

Occasionally, AWSS matches a claimant’s report and a utilization report (UR), but they are not processed due to an error or special condition code. When they are matched, AWSS cannot match a claimant’s report and a UR a second time. A Manual Action - Claimant’s Report (T045) is required to process the report.

A T045 is used when there is a cycling report that needs to be cleared. It cannot be used to force a report to process if there is no cycling report. When the UR shows as matched in FTS, but there was a reject that prevented the report from processing, the report shows as cycling. The matched status in FTS and the reject indicate that the T045 has to be used to process the report.

If a manual combination of the UR and the claimant’s report is required, the UR must be reviewed to retrieve Work-Sharing (WS) information and, if necessary, the WS information must be combined with the declaration on the claimant’s report. The employer’s URs are located in each region’s national WS folder under the Active_Agreements subfolder:

- Atlantic Region (hrdc-drhc.netnc_common-commun$ins-assursrv-saps-spIPOCAtlantic_Region)

- Région_du_Québec (hrdc-drhc.netnc_common-commun$ins-assursrv-saps-spIPOCRégion_du_Québec )

- Ontario Region (hrdc-drhc.netnc_common-commun$ins-assursrv-saps-spIPOCOntario_Region)

- WT_Region (hrdc-drhc.netnc_common-commun$ins-assursrv-saps-spIPOCWT_Region)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0624.dita) 

The following chart outlines some WS conditions and the action required when inputting the T045 transaction.

```text
| Conditions | Action |

| 0 hours worked 5 non-available days | - In the Non-available day(s) field, select 5 . - Keep the STUAE coding field blank. In the STUAE coding field, FTS automatically shows U0990 . - In the Earnings field, enter earnings from WS employment and non-WS employment (if necessary). |

| 0.5 hours or greater worked 1 to 4 non-available days Hours missed due to WS | - Ignore non-available days. - In the STUAE coding field, enter only the hours missed due to WS. - In the Earnings field, enter earnings from non-WS employment (if necessary). |

| 0.5 hours or greater worked 1 to 4 non-available days 0 hours missed | - Ignore non-available days. - In the STUAE coding field, enter U0000 . - If the actual WS earnings are unavailable and if the earnings come only from WS employment, select a full work week (FWW) in the Full work week field and enter “0000” in the Earnings field. |

| 0 hours worked 1 to 4 non-available days declared | Client exempt from reporting: - In the Non-available day(s) field, select 5 . - Leave the STUAE coding field blank. FTS automatically shows U0990 . - In the Earnings field, enter earnings from WS employment (if necessary). Client completed a claimant's report: - In the Non-available day(s) field, select the greater of the non-available days from the UR or the claimant’s report. - In the STUAE coding field, enter U0990 . - In the Earnings field, enter earnings from WS employment and non-WS employment (if necessary). |

| 0 hours worked Non-available and sick days = 5 | - In the Non-available day(s) field, select the amount of non-available days. - In the Sick day(s) field, select the amount of sick days. - In the STUAE coding field, enter U0990 . - In the Earnings field, enter earnings from WS employment and non-WS employment (if necessary). |

| 0.5 hours or greater worked Non-available and sick days = 1 to 4 Hours missed due to WS | - Ignore non-available and sick days. - In the STUAE coding field, enter the hours missed due to WS. - In the Earnings field, enter earnings from non-WS employment (if necessary). |

| 0.5 hours or greater worked Non-available and sick days = 1 to 4 0 hours missed | - Ignore non-available and sick days. - In the STUAE coding field, enter U0000 . - If the actual earnings are unavailable and if the earnings come only from WS employment, select an FWW in the Full work week field and enter “0000” in the Earnings field. |

| 0 hours worked Non-available and sick days = 1 to 4 | - Call the client to obtain a verbal declaration of non-available days and sick days for the week of the report. - Select the amount of non-available days and sick days as reported by the client in the appropriate fields. - In the STUAE coding field, enter U0990 . - In the Earnings field, enter earnings, if necessary (include paid sick leave [PSL], workers’ compensation benefits [WCB] or wage loss insurance [WLI], if necessary). |

| 0 hours worked 5 sick days | - In the Sick day(s) field, select 5 . - Keep the STUAE coding field blank. FTS automatically shows U0990 . - In the Earnings field, enter earnings from non-WS employment (if necessary). |

| 0 hours worked 5 sick days PSL, WCB or WLI | If the waiting period (WP) has been served or waived: - In the Sick day(s) field, select the sick days. - Keep the STUAE coding field blank. FTS automatically shows U0990 . - In the Earnings field, enter PSL, WCB or WLI and include earnings from non-WS employment, if necessary. - If the PSL, WCB or WLI amount is unknown, enter “9999” in the Earnings field. If the WP has not been served or waived: - In the Sick day(s) field, select 5 . - Keep the STUAE coding field blank, FTS automatically shows U0990 . - Do not enter any PSL, WCB or WLI. - In the Earnings field, enter earnings from non-WS employment, if necessary. |

| 0.5 hours or greater worked 1 to 4 sick days Hours missed due to WS | - Ignore sick days. - In the STUAE coding field, enter the hours missed due to WS. - Ignore earnings, PSL, WCB or WLI resulting from the WS employment. - In the Earnings field, enter earnings from non-WS employment (if necessary). |

| 0.5 hours or greater worked 1 to 4 sick days 0 hours missed | - Ignore sick days. - In the STUAE coding field, enter U0000 . - If the actual earnings are unavailable and the earnings come only from WS employment, select an FWW in the Full work week field and enter “0000” in the Earnings field. |

| 0 hours worked 1 to 4 sick days | Client exempt from reporting: - In the Sick day(s) field, select 5 . - Keep the STUAE coding field blank. FTS automatically shows U0990 . - In the Earnings field, enter earnings from non-WS employment, if necessary. Client completing claimant’s report: - In the Sick day(s) field, select the greater of the sick days from the UR or the claimant’s report. - In the STUAE coding field, enter U0990 . - In the Earnings field, enter earnings, if necessary (include PSL, WCB or WLI, if necessary). |

| 0 hours worked 1 to 4 sick days PSL, WCB or WLI | Client exempt from reporting: If the WP has been served or waived: - In the Sick day(s) field, select 5 . - Keep the STUAE coding field blank. FTS automatically shows U0990 . - In the Earnings field, enter PSL, WCB or WLI. - If the PSL, WCB or WLI amount is unknown, enter “9999” in the Earnings field. If the WP has not been served or waived: - In the Sick day(s) field, select 5 . - Keep the STUAE coding field blank, FTS automatically shows U0990 . - Do not enter PSL, WCB or WLI in the Earnings field. Client completing claimant’s report: If the WP has been served or waived: - In the Sick day(s) field, select the greater of the sick days from the UR or the claimant’s report. - In the STUAE coding field, enter U0990 . - In the Earnings field, enter PSL, WCB or WLI and include earnings from non-WS employment (if necessary). - If the PSL, WCB or WLI amount is unknown, enter “9999” in the Earnings field. If the WP has not been served or waived: - In the Sick day(s) field, select the greater of the sick days from the UR or the claimant’s report. - In the STUAE coding field, enter U0990 . - Do not enter PSL, WCB or WLI in the Earnings field. - In the Earnings field, enter earnings from non-WS employment, if necessary. |

| 0.5 hours or greater worked FWW (non-WS employment) | - In the STUAE coding field, enter the hours missed due to WS. If no hours are missed, enter U0000 , and an FWW in the Full work week field. - In the Earnings field, enter earnings from non-WS employment. If earnings are not on the claimant’s report, contact the client. - Ignore an FWW for non-WS employment. |

| 0 hours worked FWW (non-WS employment) | - In the STUAE coding field, enter U0990 . - In the Full work week field , select an FWW. - In the Earnings field, enter earnings (if earnings are not on the claimant’s report, do not code earnings as 0000 and contact the client). |

| 0.5 hours or greater worked FWW (WS employment) | - In the STUAE coding field, enter U0000 . - If the actual earnings are unavailable and the earning come only from WS employment, select an FWW in the Full work week field , and enter “0000” in the Earnings field. |

| Separation from employment due to apprenticeship training, and maternity, parental, compassionate care or family caregiver leave | - Process the week as a layoff. - Send an Action Item (AI) WI to the Level 1 officer advising that the WS agreement is terminated, the client needs to be contacted for a claim conversion and the benefit type (BT), may need to be changed, if necessary. Refer to Processing a separation from Work-Sharing employment — IPOC for guidance [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) If the client receives maternity or parental QPIP benefits, do not send an AI WI. The client is considered not available. [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) |

| 0.5 hours or greater worked Found work (new employment) | - In the STUAE coding field, enter the hours missed due to WS. If no hours are missed, enter U0000 , and enter an FWW in the Full work week field. - In the Earnings field, enter earnings from non-WS employment. If earnings are not on the claimant’s report, contact the client. - No action is required if the client found work in a non-WS employment |

| 0 hours worked Found work (new employment) | If the client reported having found work for Sunday or Monday, the found work code is 1 - Found work on Sunday or Monday of week 1 . If the client reported having found work for Tuesday to Saturday, the found work code is 4 - Found work after Monday in the first week . - In the Found work field, select 1 or 4 . - Leave the STUAE coding field blank. - In the Earnings field, enter the earnings from the new employment. - Leave week 2 blank. |

| Found work with a contentious reason for separation (RFS) | - Include the found work information in an SROC. |

| 0.5 hours or greater worked Quit, fired or layoff Hours missed due to WS | If the employer indicated a layoff on the UR: - In the STUAE coding field, enter hours missed due to WS. - In the Earnings field, enter the earnings from non-WS employment, if necessary. If the RFS is contentious, do not input a T045 transaction for the week in which the separation occurred, as the week cannot be processed until the separation has been adjudicated. Refer to Processing a separation from Work-Sharing employment — IPOC for guidance. [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) |

| 0.5 hours or greater worked Quit, fired or layoff 0 hours missed due to WS | If the employer indicated a layoff on the UR: - In the STUAE coding field, enter U0000 . - If the actual earnings are unavailable and the earnings come only from WS employment, select a FWW in the Full work week field, and enter “0000” in the Earnings field. If the RFS is contentious, do not input a T045 transaction for the week in which the separation occurred, as the week cannot be processed until the separation has been adjudicated. Refer to Processing a separation from Work-Sharing employment — IPOC for guidance. [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) |

| 0 hours worked Quit, fired or layoff | If the employer indicated a layoff on the UR: - In the STUAE coding field, enter U0990 . - In the Earnings field, enter earnings from WS employment and non-WS employment, if necessary. If the RFS is contentious, do not input a T045 for the week in which the separation occurred, as the week cannot be processed until the separation has been adjudicated. Refer to [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) for guidance. [Processing a separation from Work-Sharing employment — IPOC](/en/procedure/task/actioning_pse_wsc.shtml) |

| Training during WS | - Ignore training information. - In the STUAE coding field, enter WS information. - In the Earnings field, enter earnings from non-WS employment, if necessary. |

| Training during WS Full week – employer directed | - In the STUAE coding field, enter U0000 . - If the actual earnings are unavailable and the earnings come only from WS employment, select an FWW in the Full work week field, and enter “0000” in the Earnings field. |

| 0.5 hours or greater worked Vacation pay Hours missed due to WS | - Ignore vacation pay. - In the STUAE coding field, enter the hours missed due to WS. - In the Earnings field, enter earnings from non-WS employment, if necessary. If the declared vacation pay amount is greater than the normal weekly earnings (NWE), refer to the Actioning a Lump Sum Payment section of the Processing a Work-Sharing utilization report task. [Processing a Work-Sharing utilization report](/en/procedure/task/processing_awsur.shtml#ipocc_item_5) [Processing a Work-Sharing utilization report](/en/procedure/task/processing_awsur.shtml#ipocc_item_5) |

| 0.5 hours or greater worked Vacation pay 0 hours missed | - Ignore vacation pay. - In the STUAE coding field, enter U0000 . - In the Full work week field, select the FWW. - In the Earnings field, enter earnings from non-WS employment, if necessary. If the declared vacation pay amount is greater than the NWE, refer to the Processing a lump-sum payment section of the Processing a Work-Sharing utilization report task. [Processing a Work-Sharing utilization report](/en/procedure/task/processing_awsur.shtml#ipocc_item_5) [Processing a Work-Sharing utilization report](/en/procedure/task/processing_awsur.shtml#ipocc_item_5) |

| 0 hours worked Vacation pay Non-available days | - In the STUAE coding field, enter U0990 . - In the Non-available day(s) field, select the non-available days declared. - In the Earnings field, enter the vacation pay, including other earnings from WS and non-WS employment (if necessary). If the declared vacation pay amount is greater than the NWE, refer to the Processing a lump-sum payment section of the Processing a Work-Sharing utilization report task. [Processing a Work-Sharing utilization report](/en/procedure/task/processing_awsur.shtml#ipocc_item_5) [Processing a Work-Sharing utilization report](/en/procedure/task/processing_awsur.shtml#ipocc_item_5) |

| 0.5 hours or greater worked Statutory holiday pay Hours missed due to WS | - Ignore statutory holiday pays. - In the STUAE coding field, enter the hours missed due to WS. - In the Earnings field, enter earnings from non-WS employment, if necessary. |

| 0.5 hours or greater worked Statutory holiday pay 0 hours missed | - In the STUAE coding field, enter U0000 . - If the actual earnings are unavailable and the earnings come only from WS employment, select an FWW in the Full work week field, and enter “0000” in the Earnings field. |

| 0 hours worked Statutory holiday pay | - In the STUAE coding field, enter U0990 . - In the Earnings field, enter the statutory holiday pay, including other earnings from WS or non-WS employment. |
``` 

### Note

Source topic: `en_EN/common_notes/note_c_0624.dita`

Note:

Sometimes, FTS requires minor adjustments to the declaration in order to use the appropriate special condition code or meet FTS edits. It is for this reason that the employer record in FTS is not to be used to obtain the employer declaration since it may not be a true representation of the employer’s declaration. The original declaration will be available in the URs retained in the employer’s WS folder. 
