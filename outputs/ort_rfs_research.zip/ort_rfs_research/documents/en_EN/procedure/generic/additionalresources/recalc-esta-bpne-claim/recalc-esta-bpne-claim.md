# Recalculating and establishing BPNE claims: Outstanding issue in the benefit period — Instructions

Source map: `en_EN/procedure/generic/additionalresources/recalc-esta-bpne-claim/recalc-esta-bpne-claim.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/recalc-esta-bpne-claim/additional_resources.dita`

Summary: When establishing a BPNE claim through recalculation, the officer determines if there is an outstanding reason for separation (RFS) issue in the benefit period (BP) and if an adjudication is required.

**What You Need to Know**

When the only contentious issue on a BPNE claim that can be established through a recalculation is an RFS in the BP, the officer can complete the calculation and does not need to move the Claim Review (CR) BPNE Recalculation WI to Pending awaiting the decision. If specific conditions are met, an adjudication of the contentious RFS is not required. If the conditions are not met, a 75 - Verification of reason for termination of Employment manual action (MA75) and Claim Review (CR) Revised WI are required.

Officers must also refer to recalculation procedures, if necessary.

**Adjudication not required on a contentious reason for separation (RFS) in the benefit period (BP)**

If the officer determines that there is an outstanding contentious RFS issue in the BP when establishing an BPNE 1 - Insufficient insured hours (N1), 2 - Last record of employment missing (N2) or 5 - Insufficient insured hours / fishing earnings (N5) claim through recalculation, no adjudication, no CR WI and no record of decision (ROD) are required if:

- the date of the event related to the contentious RFS is in the BP;

- one of the following conditions is met:

- The client is not requesting benefits from the week of the contentious RFS.

- The client is not entitled to regular benefits from the BPC because of a contentious RFS adjudication previously denied.

**Last day worked (LDW) or the date of the event related to the contentious reason for separation (RFS) is in the benefit period (BP)**

The first day worked related to the employment with the contentious RFS can be in the qualifying period (QP) or in the BP. Whether the first day worked is during the QP or the BP has no impact on the adjudication of the contentious RFS in the BP.

When the first day worked is in the QP and the LDW is in the BP, Unemployment Insurance Calculation (UIC) considers the hours worked and the earnings in the ROE that are in the QP.

If the conditions are met for not adjudicating the contentious RFS in the BP, the officer may need to modify the block Special Condition of the ROE in RCM of the contentious RFS in the BP to Misconduct - Not proven or Voluntary leaving - Just cause , based on the situation. This action is necessary when there is an ROE in the QP that has been excluded from the calculation, to ensure that the recalculation result displayed in SSO is correct. Once the recalculation transactions have been input, the officer modifies the block Special Condition of the ROE related to contentious RFS in the BP back to blank .

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0567.dita) 

**Client is not requesting benefits from the week of the contentious reason for separation (RFS)**

Information on file showing that the client is not requesting benefits include the following:

- In FTS, there are no cycling claimant’s reports on the Payments tab or rejected claimant’s reports on the E-report tab for the week of the LDW and after.

- There is no renewal or new application on file, and the client has not contacted Service Canada to enquire about the claim.

**Client is not entitled to regular benefits from the BPC because of a previously adjudicated contentious reason for separation (RFS)**

If the client is not entitled to regular benefits because of a 10 - Dismissal - misconduct proven disqualification (D10) or an 11 - Voluntarily leaving - just cause not proven disqualification (D11) imposed from the BPC on a regular claim due to adjudication, the officer does not create a CR WI for a contentious RFS in the BP.

**Contentious reason for separation (RFS) in the benefit period (BP) when the conditions are met and a Claim Review (CR) Revised WI is not required**

When the conditions above are met, the officer does not create a CR Revised WI and does not adjudicate the contentious RFS in the BP.

If a CR Revised WI has previously been created to request an adjudication on the contentious RFS in the BP, the officer sends an email to the Team Leader to request to delete the CR WI.

**Processing the Claim Review (CR) BPNE Recalculation WI if the conditions are not met and a Claim Review (CR) is required**

If there is a contentious RFS in the BP that requires Level 2 adjudication for a BPNE N2 claim and there are cycling claimant’s reports from the week of the contentious RFS, the officer imposes an indefinite 15 - Claim procedure disentitlement (D15) beginning the Monday of the week of the contentious event, so the client does not receive payment starting that week. After the adjudication is completed, the Level 2 officer rescinds the D15.

If the conditions are not met in all other cases, the officer processes the recalculation over 2 days. On day 1, the officer recalculates to establish the claim and to process cycling or rejected claimant’s reports up to but not including the week of the contentious RFS. On day 2, the officer imposes a MA75 to stop payments until the adjudication is completed. The officer does not move the CR BPNE Recalculation WI to Pending until the adjudication is completed.

**Cycling claimant’s reports, rejected claimant’s reports and claimant’s reports checklist**

The client may have completed claimant’s reports related to the BPNE claim.

If the claim was previously finalized BPNE N2 and the client completed claimant’s reports, they are displayed in FTS on the Payments tab. Claimant’s reports are not displayed as rejected in FTS on the E-Report tab or the E-Report History (MD01) screen. The client can continue completing claimant’s reports after the claim has been finalized BPNE N2. When recalculating a BPNE N2 claim, if the BPC week starts before the one displayed in FTS, the cycling claimant’s reports are rejected the next business day.

If the claim was previously finalized BPNE N1 or N5 and the client has completed claimant’s reports, they are displayed as rejected in FTS on the E-Report tab or the MD01.

If the client has not completed claimant’s reports or when they could not be updated because of the initial BPNE calculation, an officer may have completed a claimant’s report checklist. In FTS, the officer processing the CR BPNE Recalculation WI inputs the claimant’s reports from the claimant’s report checklist.

If claimant’s reports have been rejected following the initial BPNE N1 or N5 calculation, in FTS, the officer processing the CR BPNE Recalculation WI inputs the rejected claimant’s reports.

**Deferring adjudication — Client entitled to special benefits and disqualification or administrative 46 - Variable entrance requirement not met - special benefits payable disentitlement (D46) on file**

If a D10 or D11, or an administrative D46 is imposed from the BPC and the client is requesting special benefits, the adjudication of a contentious RFS in the BP can be deferred. The officer refers to Deferring adjudication: Current established claim .
       [Deferring adjudication: Current established claim](/en/procedure/task/deferring_adj_current_claim.shtml)

**Step by Step**

- Determine if one of the following conditions are met:

- The client is not requesting benefits from the week of the contentious RFS.

- The client is not entitled to regular benefits from the BPC because of a previously denied contentious RFS adjudication.

- If yes, go to step 2.

- If no, adjudication is required. Go to step 13.

- Do one of the following based on the claim:

- If the claim is established for regular or special benefits and no D10, D11 or administrative D46 is imposed from the BPC, go to step 3.

- If the claim is established for regular benefits and a D10 or D11 is imposed from the BPC, refer to the appropriate recalculation procedures to input the recalculation transactions in SSO. Go to step 7.

- If the claim is established for special benefits and a D10, D11 or D46 is imposed from the BPC and the client is otherwise available (for sickness benefits only), refer to Deferring adjudication: Current established claim for the contentious RFS in the BP. Then, refer to the appropriate recalculation procedures to input the recalculation transactions in SSO and go to step 7.
             [Deferring adjudication: Current established claim](/en/procedure/task/deferring_adj_current_claim.shtml)

- In SSO, perform the recalculation to determine if the M161 - Disqualifications/Disentitlements (M161) screen with a D10 or D11 is generated based on the contentious RFS in the BP:

- In NWS, determine if there is an ROE in the QP that has been previously denied and that should be excluded in the claim calculation.

- In RCM, modify the block Special Condition of the ROE with a contentious RFS in the BP to Misconduct - Not proven or Voluntary leaving - Just cause , based on the situation. Refer to the procedures to input the recalculation transactions in SSO. Then, go to step 6.

- Once the recalculation transactions have been input, modify the block Special Condition of the ROE with a contentious RFS in the BP to Blank . Go to step 7.

- In FTS, on the Pending/Reject tab, determine if claimant’s reports have been rejected:

- If no, go to step 8.

- If yes, go to step 9.

- In NWS, determine if a claimant’s report checklist has been completed:

- If yes, go to step 9.

- If no, go to step 10.

- Refer to Claimant’s report to input in FTS the rejected claimant’s reports or claimant’s reports from the claimant’s report checklist. Go to step 10.
         [Claimant’s report](/en/procedure/activity/claimant_report.shtml)

- In NWS, determine if a CR Revised WI has previously been created to request adjudication on the same contentious RFS in the BP:

- If yes, go to step 11.

- If no, go to step 24.

- In FTS, determine is there is a revised registration number related to the CR Revised WI:

- If no, go to step 12.

- If yes, in FTS, select the Registration number (M025, M030, M035) transaction and cancel the revised registration number as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 12.

- In Outlook, send an email to your team leader to request the deletion of the CR Revised WI as follows:

- Subject: Type “WI deletion.”

- In the message body, type:
             [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0568.dita)

- Go to step 24.

- In NWS, determine if there is already a CR Revised WI for the adjudication required:

- If yes and the CR Revised WI is Level 1, reassign the CR WI to yourself. Go to step 15.

- If yes and the CR Revised WI is Level 2, go to step 16.

- If no, in FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Create Work item: Do not check the box.

- Select Update .

- Go to step 14.

- In NWS, for each issue requiring adjudication in the BP without a WI, create a CR Revised WI as follows:

- Type: Select Revised .

- Registration number: Enter the revised registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- SCC: Select the Service Canada Centre (SCC) as shown in FTS.

- BPC: Enter the BPC of the claim to be recalculated.

- Date of registration: Enter the date the revised registration number was created.

- Details: Enter the details of the contentious issue that requires adjudication.

- Select Save .

- Reassign the CR WI to yourself.

- Go to step 15.

- Determine if the adjudication is within your authority by referring to the appropriate adjudication task:

- If no, reassign each CR Revised WI as follows:

- Destination: Select Next available user .

- Complexity: Select the appropriate option.

- Reason: Select Unable to complete .

- Details: Type “Not within officer’s authority.”

- Select OK .

- Go to step 16.

- If yes, follow the appropriate task to adjudicate the outstanding issue, refer to the appropriate recalculation procedures to input the recalculation transactions in SSO and go to step 24.

- In SSO, calculate the claim to determine if the M161 - Disqualifications/Disentitlements (M161) transaction with a D10 or D11 is generated based on the contentious RFS in the BP:

- If yes, go to step 17.

- If no, go to step 19.

- In NWS, determine if there is an ROE in the QP that has been previously denied and that should be excluded in the claim calculation.

- If yes, go to step 18.

- If no, when inputting the recalculation transactions, select Delete to delete the M161 - Disqualifications/Disentitlements (M161) transaction created by SSO. Go to step 19.

- In RCM, modify the block Special Condition of the ROE with a contentious RFS in the BP to Misconduct - Not proven or Voluntary leaving - Just cause , based on the situation. Go to step 19.

- Determine which situation applies:

- When establishing a BPNE N2 claim when the client has completed claimant’s reports for the week of the contentious RFS, do the following:

- In SSO, complete the recalculation. Refer to the appropriate recalculation procedures, if necessary. If SSO creates the M161 - Disqualifications/Disentitlements (M161) transaction, select Delete to delete the transaction.

- In FTS on the same day, impose an indefinite administrative D15 from the Monday of the contentious event to prevent payment until adjudication.

- Create a client note for the Level 2 officer explaining that the D15 is imposed to prevent payment until the adjudication is completed, and that once the decision is made, the Level 2 officer must rescind the D15.

- Go to step 24.

- When establishing a BPNE N1 or N5 claim or a BPNE N2 claim when the client has not completed reports for the week of the contentious RFS, do the following:

- In SSO, on the first day, complete the recalculation of the claim. Refer to the appropriate recalculation procedures, if necessary. If SSO creates the M161 - Disqualifications/Disentitlements (M161) transaction, select Delete to delete the transaction.

- Go to step 20.

- Do the following:

- In FTS, input the rejected claimant’s reports or those from the claimant’s report checklist up to the week before the contentious RFS. For more information, refer to Inputting a claimant’s report . Go to step 21.
             [Inputting a claimant’s report](/en/procedure/task/inputting_cr.shtml)

- In NWS, move the CR BPNE Recalculation WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “2-day input.”

- Bring forward date: Enter today’s date + one business day.

- Go to step 22.

- In FTS, on the second day, select the Renewal/Revised (M106) transaction and impose an MA75 to stop payment as follows:

- Registration number: Leave this field blank. If a number is displayed, delete it.

- Manual action: Select 75 - Verification of reason for termination of employment .

- Select Update .

- Go to step 23.

- In RCM, if the block Special Condition of the ROE with a contentious RFS in the BP was previously modified to Misconduct - Not proven or Voluntary leaving - Just cause , change it to Blank .

- Complete the CR BPNE Recalculation WI. 

### Note

Source topic: `en_EN/common_notes/note_c_0567.dita`

Note:

Sometimes, employers issue amended ROEs with the same LDW, but the RFS has changed to a contentious RFS when an employee has a permanent separation while on temporary stoppage of work. In these cases, it is important to determine in which week the contentious event occurred before proceeding with the following instructions. The week of the contentious event determines the proper allocation of any separation monies, paid on a specific date. In all cases, the officer must conduct fact-finding. 

### Callout

Source topic: `en_EN/common_notes/note_c_0568.dita`

“SIN [client’s SIN] WI to be deleted: CR Revised WI created on [date the WI was created]. Reason for deletion: No adjudication required.” 
