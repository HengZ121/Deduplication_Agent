# PCIC: Information on benefits — Knowledge

Source map: `en_EN/procedure/generic/additionalresources/pcic/pcic.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/pcic/additional_resources.dita`

Summary: PCIC benefits provide up to 35 weeks of temporary income replacement to eligible parents who take leave from work to provide care or support to a critically ill or injured child.

**Table of contents**

- Processing PCIC benefits

- Claim type
             [Claim type](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#claimtype)

- Antedate
             [Antedate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#antedate)

         [Processing PCIC benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#processing)

- Qualifying conditions

- PCIC window
             [PCIC window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#BPwindow)

- Maximum benefits payable
             [Maximum benefits payable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#max)

- BP extension
             [BP extension](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#bpext)

- No-CR Code
             [No-CR Code](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#NOCR)

         [Qualifying conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#Qualifyingconditions)

- Waiting period

- Deferral of the waiting period
             [Deferral of the waiting period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#deferralwp)

- Waiving of the waiting period
             [Waiving of the waiting period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#waivingwp)

         [Waiting period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#wp)

- Medical documentation

- Proof of critically ill or injured child
             [Proof of critically ill or injured child](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#proof)

- Subsequent medical
             [Subsequent medical](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#subsequent)

- Providing care or support
             [Providing care or support](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#providingcare)

- Interim policy for newborns
             [Interim policy for newborns](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#interim)

- Disentitlements
             [Disentitlements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#disent)

         [Medical documentation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#meddoc)

- Entitlement issues

- Deferred reason for separation (RFS )
             [Deferred reason for separation (RFS](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#deferred)

- Levels of Decision policy
             [Levels of Decision policy](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#LOD)

- Allocation of monies
             [Allocation of monies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#monies)

- Not otherwise available
             [Not otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#NOA)

- Sharing of benefits
             [Sharing of benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#sharing)

- More than one child

- Same event
                 [Same event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#same)

- Unrelated event
                 [Unrelated event](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#unrelated)

             [More than one child](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#morethanone)

         [Entitlement issues](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#Ent)

- Extending PCIC benefits

- MM06
             [MM06](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#MM06)

         [Extending PCIC benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#Renewal)

- Conversions from another type of benefits to PCIC

- Claimant’s report
             [Claimant’s report](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#ConvCR)

- MM06
             [MM06](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#ConveMM06)

         [Conversions from another type of benefits to PCIC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#another)

- Conversions from PCIC benefits to other types of benefits
         [Conversions from PCIC benefits to other types of benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/pcic#fromPCIC)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0537.dita) 

**Processing PCIC benefits**

All PCIC claims are processed at the Centre of Specialization in Sudbury and the IPOC processing portion is completed by the IPOCs in all 4 regions.

The claims for PCIC benefits are not automated; they are completed through SSO and transmitted as usual. The claim is set up through CPS but no payments are issued, the claim is converted to MPS and all claimant’s reports are processed by the IPOC.

**Claim type**

There are 2 claim types in relation to PCIC benefits:

- CT20 - Regular PCIC benefits

- CT78 - Self-employed PCIC benefits

**Antedate**

The normal adjudication principles for antedates apply for PCIC claims. The agent can refer to Antedate for additional information.
       [Antedate](/en/procedure/activity/antedate.shtml)

An antedate for PCIC benefits will be denied if:

- at the time the claim is made, 35 weeks of PCIC have been paid; or

- the period of entitlement has already been established for another client and the request to antedate would move the start week of the 52-week window to an earlier date.

**Qualifying conditions**

The qualifying conditions are the same as for other special benefits and up to 35 weeks of PCIC benefits can be paid per benefit period if the following entitlement conditions are met:

- The client has had an interruption of earnings;

- The client has at least 600 hours of insurable employment in the qualifying period ( major attached ). If the client has a violation, to know how many hours are required, refer to Increased entrance requirements ;
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client) 
         [Increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

- The client must be the legal parents (including adoptive parents) or legal guardian (in Quebec a legal guardian is referred to as a parental authority or tutor) or have a child placed in their house for the purposes of adoption;

- The child must be critically ill or injured and they must be under the age of 18 at the time the 52-week window opens;

- The client must submit medical documentation proving the child is critically ill or injured and requires the care or support of his/her parents.

**PCIC window**

The 52-week window in which benefits are payable begins when one of the following is met:

- If the claim is filed before the certificate is issued, from the date the medical specialist doctor certifies that the child is critically ill or injured; or

- On the day the first medical certificate is issued.

If more than one child is critically ill or injured as a result of the same event, only one 52-week period may be established and a maximum of 35 weeks of benefits is payable during that 52-week period.

If more than one child is critically ill or injured as a result of unrelated events, separate 52-week periods may be established for each of the critically ill or injured children. However, the maximum number of weeks of PCIC benefits payable is as follows:

- 35 weeks per child during the related 52-week period; and

- a maximum of 35 weeks of PCIC benefits can be paid during any given BP.

**Maximum benefits payable**

A total of 35 weeks of PCIC can be claimed during any given benefit period (BP). PCIC benefits can be shared between clients to a combined maximum of 35 weeks. The 35 weeks of PCIC benefits do not have to be paid consecutively and can be paid intermittently during the BP or the 52-week window, in a manner that is most convenient to the client, provided the required medical proof supports the child’s critical illness during the weeks claimed.

PCIC benefits can no longer be paid when:

- the BP has expired;

- the 52-week window has expired;

- the maximum number of combined benefit weeks on that claim has been paid;
         [maximum number of combined benefit weeks](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

- the 35 weeks of PCIC benefits have been paid (either shared or paid to one individual); or

- the gravely ill child dies.

**Benefit period extension**

The benefit period (BP) can be extended for a maximum of 104 weeks to pay additional weeks of PCIC benefits when all of the conditions are met before the BP ends. Refer to Extension of the benefit period for more information. For more information on BP extension, refer to Benefit period extension for special benefits - Job aid .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml) 
       [Benefit period extension for special benefits - Job aid](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

**No-CR Code**

The NO-CR option is also available for the PCIC benefits. The system will not automatically cancel the exemption from reporting when the eligibility criteria are no longer met (e.g. benefit type changes from PCIC to sickness or a client reports part-time employment). An Operational Centre Memo (MM06) must be sent to IPOC requesting the no card code option be rescinded.

**Waiting period**

A waiting period (WP) must be served for the clients to receive PCIC benefits. In some situations, the WP may be deferred or waived.

**Deferral of the waiting period**

The normal 2-week waiting period (WP) applies to these benefits. If the first parent serves the 2-week WP, the WP for the other parent may be deferred if benefits are requested with respect to the same child.

**Waiving of the waiting period**

Current waiving of the waiting period provisions are applied to PCIC claims, when the following conditions are met:

- after the last day worked, the client received paid sick leave from his employer; and

- the interruption of earnings giving rise to the claim is due to the need to provide care or support to a critically ill or injured child.

**Medical documentation**

**Proof of critically ill or injured child**

In order to prove that a child is critically ill and requires the care or support of a parent, a client must obtain a medical certificate that attests the child’s baseline state of health has changed significantly, the child’s life is at risk as a result of an illness or injury and that the child requires the care or support of a parent. The medical certificate must be signed by a doctor.

**Period of care and support**

If the doctor indicates that the period of care and support is “unknown” or “indefinite”, that does not indicate the period during which the child requires care or support. The agent must contact the client to obtain another medical that shows the specific dates the child requires care or support.

The doctor must provide an actual period of time the child requires care or support. If the period of time is a specific number of weeks instead of actual to and from dates, the period of care and support would begin on the date the medical certificate was issued.

The patient must complete and sign an Authorization to Release a Medical Certificate (INS5242A) form so the specialist medical doctor can release medical information.
       [Authorization to Release a Medical Certificate (INS5242A)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242A.pdf)

A client applying for PCIC benefits must submit the Medical certificate for Employment Insurance benefits for Parents of Critically Ill Children (INS 5242B) form.
       [Medical certificate for Employment Insurance benefits for Parents of Critically Ill Children (INS 5242B)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242B.pdf)

The critically ill or injured child does not always live in Canada and the client is required to leave Canada to provide care or support to the child where the child lives. In these situations, it is still necessary for the client to submit a Medical certificate for Employment Insurance benefits for Parents of Critically Ill Children (INS 5242B) , completed by a specialist medical doctor licensed to practice medicine in Canada as a specialist.
       [Medical certificate for Employment Insurance benefits for Parents of Critically Ill Children (INS 5242B)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242B.pdf)

To determine if a medical certificate is acceptable, refer to Determining if a client applying for PCIC benefits has provided an acceptable medical certificate — Renewal or continuing claim .
       [Determining if a client applying for PCIC benefits has provided an acceptable medical certificate — Renewal or continuing claim](/en/procedure/task/determining_pcic_med_cert.shtml)

**Subsequent medical**

The period during which the child requires care and support includes both the initial period during which the child is critically ill or injured and also the recovery period after the child’s condition has improved but has not yet returned to the child’s normal state of health.

This allows the specialist to issue a second medical certificate so the client can also be paid benefits during the child’s recovery period (up to a maximum of 35 weeks of PCIC benefits).

If a client request benefits during the recovery period, they must submit a subsequent Authorization to Release a Medical Certificate (INS5242A) form and a Medical certificate for Employment Insurance benefits for Parents of Critically Ill Children (INS 5242B) form.
       [Authorization to Release a Medical Certificate (INS5242A)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242A.pdf) 
       [Medical certificate for Employment Insurance benefits for Parents of Critically Ill Children (INS 5242B)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242B.pdf)

**Providing care or support**

A child may require the care and support of a legal parent because of their state of health as well as for psychological or emotional support.

Care and support includes situations where the client simply spends time each day with the critically ill child in a home, a hospice or a medical facility. This also includes situations where the client may stop providing care to the patient for up to 2 days while claiming PCIC benefits.

To determine if a client is providing care or support to a critically ill child, refer to Determining if a client applying for PCIC benefits is providing care or support for a critically ill child — Renewal or continuing claim .
       [Determining if a client applying for PCIC benefits is providing care or support for a critically ill child — Renewal or continuing claim](/en/procedure/task/determining_pcic_benefit_child.shtml)

**Interim policy for newborns**

The interim policy allows PCIC benefits to be paid for a newborn child if certain conditions are met. A newborn does not have a baseline state of health so the answer to the ‘baseline state of health’ question (Question 2 on the INS 5242B - PCIC medical certificate) may not be provided, or the answer may be No .

When an agent applies the interim policy for newborns, all of the following conditions must be met:

- The doctor answered yes to questions 1 and 3;

- The doctor answered yes or no , or did not answer question 2;

- The information on the medical certificate clearly shows that the child was born with a life-threatening illness;

- The medical certificate includes a timeframe during which care or support is required.

**Disentitlements**

When the providing care or support requirements are not met, the agent imposes a 61 - Parents of critically ill children - Does not meet entitlement conditions (D61) disentitlement.

When the medical certificate requirements are not met, the agent imposes a 63 - Parents of critically ill children - No medical proof (D63) disentitlement.

**Entitlement issues**

**Deferred RFS**

On an initial claim for PCIC benefits, fact-finding and adjudication related to a contentious reason for separation (RFS) can be deferred if certain conditions are met.

On a renewal claim for PCIC benefits, fact-finding for and adjudication of a contentious RFS can be deferred if an indefinite disqualification was imposed as a result of adjudication. Special benefits are paid regardless of whether the client has enough hours to establish a new claim.

Refer to Deferral of adjudication for further information.
       [Deferral of adjudication](/en/procedure/activity/deferral_adj.shtml)

**Levels of decision policy**

To determine if a decision is within Level 1 decision of authority, refer to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

If the decision is not within Level 1 authority, the issue must be referred to Level 2 for adjudication as follows:

- Initiate the fact-finding.

- Input the conversion.

- Impose a manual action to stop payment (MA01).

**Allocation of monies**

When a client declares receiving money, the agent must determine if the money received is to be considered earnings for EI purposes. If the agent determines that the money is considered earnings, they must then refer to Earnings to determine how the money is to be allocated.
       [Earnings](/en/procedure/activity/earnings.shtml)

**Not otherwise available**

Clients do not need to prove that they would be “otherwise available” or “otherwise working” to access PCIC benefits.

**Sharing of benefits**

The legislation provides that the 35 weeks of PCIC benefits in relation to a critically ill child can be shared by one or more eligible clients, and that the weeks are to be divided as agreed to by those clients. When these benefits are shared, it must be determined whether the other parent is claiming or has claimed PCIC benefits to care for the same critically ill child, and the number of weeks being claimed by the other parent. When eligible clients cannot come to an agreement on how to share benefits, the remaining weeks will be divided based on the prescribed rules. Refer to Adjudicating the sharing of PCIC benefits — Renewal and continuing claims .
       [Adjudicating the sharing of PCIC benefits — Renewal and continuing claims](/en/procedure/task/adjudicating_na_pcic_bw.shtml)

**More than one child**

There may be situations where there is more than one critically ill or injured child. It is important to determine if benefits are asked for the same event or for an unrelated event.

**Same event**

If more than one child is critically ill or injured as the result of the same event, only one 52-week period is established and only a maximum of 35 weeks of benefits are payable during that 52-week period.

**Unrelated event**

When more than one child is critically ill or injured due to an unrelated event, separate 52-week periods may be established for each of the critically ill children. The maximum number of benefits payable is as follows:

- 35 weeks per child during the related 52-week period; and

- a maximum of 35 weeks of benefits can be paid during any given benefit period (BP).

Unrelated events means that 2 parents could each establish a BP in respect of one child each and be payable a maximum of 35 weeks each or the 2 parents may share the weeks in respect to each child to the maximum of 35 weeks per child and BP.

**Extending PCIC benefits**

When the client files a renewal claim for PCIC benefits the agent must complete the following inputs in FTS:

- Input the effective week.

- Action Code: input “S” if the client is requesting a NO-CR.

- If a disentitlement is required, input the appropriate disentitlement.

**MM06**

If the client has provided an invalid medical certificate or the entitlement conditions are not met, no Operational Centre Memo (MM06) is required. When the client is entitled to benefits, the agent must complete an MM06.

**Conversions from another type of benefits to PCIC**

When the client files a claim type (CT) conversion to PCIC benefits, the agent must complete the following inputs in FTS:

- With or without an effective week, change the CT to 20 or 78.

- If a disentitlement is required, input the appropriate disentitlement from the week in which PCIC benefits are being requested.

**Claimant’s reports**

The last week of the previous benefits type requested must be paid before the conversion transactions are input.

**MM06**

If the client has provided an invalid medical certificate or the entitlement conditions are not met, no Operational Centre Memo (MM06) is required. When the client is entitled to benefits, the agent must complete an MM06 to have IPOC cancel the claim to MPS and paid.

**Conversions from PCIC benefits to other types of benefits**

If a client requests a conversion from PCIC benefits to sickness, parental or regular benefits, the appropriate checklist from the Checklists, Forms and Templates additional resource, must be completed with the client.
       [Checklists, Forms and Templates](/en/procedure/generic/ar_index_cft_afg.shtml)

If the client is requesting a conversion to CCB, they must complete an application online. CCB can be paid either before the PCIC window starts or after the PCIC window ends, but cannot be paid during an existing PCIC window, in respect of the same child. The PCIC window does not end until 35 weeks of PCIC benefits have been paid or the 52-week PCIC window has ended. If the client is requesting CCB before 35 weeks of PCIC benefits has been paid or before the PCIC window has ended, a 51 - Claimant does not provide care or support disentitlement is imposed and the appropriate ACS letter is sent.

If a client is requesting a conversion to maternity, the agent must verify if the client has completed an application for maternity previously for this benefit period commencement. If yes, refer to the checklist from the Checklists, Forms and Templates additional resource, to complete the conversion. If not, the client must be directed to apply online.
       [Checklists, Forms and Templates](/en/procedure/generic/ar_index_cft_afg.shtml)

Conversions are completed within the normal processing workload and are not to be assigned or reassigned to the Centre of Specialization.

It must be noted and clients must be advised that if a conversion to another type of benefits is completed, the claim remains in MPS for the remainder of the claim and paper claimant’s reports must be completed, unless directed by procedure of the type of benefits being requested.

After reviewing the conversion request and entitlement conditions, in order to request the conversion, the agent must complete an Operational Centre Memo (MM06).

When completing the MM06, the user must ensure that all information required for the completion of the conversion is included. This includes the type of benefits being requested, the period for which the benefits are to be paid, the number of weeks being requested (if applicable), the recovery week for sickness benefits, the last renewable week, any required allocations, benefit period extensions, disentitlements etc.

**Related procedures**

- Determining if a client applying for PCIC benefits has provided an acceptable medical certificate — Renewal or continuing claim
         [Determining if a client applying for PCIC benefits has provided an acceptable medical certificate — Renewal or continuing claim](/en/procedure/task/determining_pcic_med_cert.shtml)

- Determining if a client applying for PCIC benefits is providing care or support for a critically ill child — Renewal or continuing claim
         [Determining if a client applying for PCIC benefits is providing care or support for a critically ill child — Renewal or continuing claim](/en/procedure/task/determining_pcic_benefit_child.shtml)

- Adjudicating the sharing of PCIC benefits — Renewal and continuing claim
         [Adjudicating the sharing of PCIC benefits — Renewal and continuing claim](/en/procedure/task/adjudicating_na_pcic_bw.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0537.dita`

Note:

PCIC benefits are replaced by family caregiver benefits for children as of December 3, 2017. Only new, renewing or continuing claims with a family caregiver benefit window start date on or after the date of the coming into force are eligible for the new benefit and expanded entitlement for these benefits. This page must be referred to for all PCIC benefits claim established prior to December 2, 2017. For more information on family caregiver benefits for children, refer to Family caregiver benefits — Knowledge .
       [Family caregiver benefits — Knowledge](/en/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml)

     [Family caregiver benefits — Knowledge](/en/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml) 
