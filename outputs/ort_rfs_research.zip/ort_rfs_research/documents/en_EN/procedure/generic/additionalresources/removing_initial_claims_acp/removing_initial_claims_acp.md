# Calculation: Removal from the ACP wait process — Instructions

Source map: `en_EN/procedure/generic/additionalresources/removing_initial_claims_acp/removing_initial_claims_acp.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/removing_initial_claims_acp/additional_resources.dita`

In some situations, an employee at National Headquarters can interrupt the ACP wait process to avoid incorrect payments or delays for clients.

The following table outlines the only conditions (1a, 1b, 2, 3, 4, 5, 6, or 7) that allow an officer to create a Reminder (REM) WI to remove the claim from the ACP wait process.

- The officer must ensure all required documentation is on file before creating a REM WI (e.g. all ROEs, insurability rulings). If the required documentation is not on file, the REM WI is deleted without contacting the officer.

- New facts obtained must be documented on an SROC, an Action Item (AI) WI or a Call Back (CB) WI, according to existing procedures.

Before submitting the request, the officer reviews the claim to ensure that all other outstanding actions required for processing have been completed.

Requests should only be sent if any of the following conditions are met. If a request does not meet an approved condition, the REM WI is deleted.

```text
| # | Situation | Condition | Related EI ORT tasks |

| 1 | Duplicate periods of employment listed in AW (1a) or Single ROE issued to cover multiple periods of employment (1b) | The same period of employment is listed multiple times on the application - 1a. The client declared the same employer multiple times on the application with the same dates. or - 1b. The client declared multiple periods of employment with the same employer, but that employer submitted one ROE covering all the periods of employment. | Calculation of a claim [Calculation of a claim](/en/procedure/generic/additionalresources/index_calc_claim.shtml) |

| 2 | Employment is not insurable and the ROE will not be issued. | Non-insurable employment — ROE will not be submitted - The client indicated that an ROE will be submitted in the near future, but the employment is later deemed non-insurable. [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0579.dita) | Insurability Dismissal Voluntary leaving [Insurability](/en/procedure/activity/asmt_insurability.shtml) [Dismissal](/en/procedure/activity/dismissal.shtml) [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml) |

| 3 | Last day worked (LDW) for the last employer in AW is more than 33 days later than the last day paid (LDP) on the ROE | A discrepancy greater than 33 days exists between the LDW on the EI application and the LDP on the ROE - This applies only when the LDW on the EI application is more than 33 days later than the LDP on the ROE. Example: LDW on the EI application: February 15, 2016 LDP on the ROE: January 3, 2016 (correct date) [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0580.dita) | Calculation of a claim [Calculation of a claim](/en/procedure/generic/additionalresources/index_calc_claim.shtml) |

| 4 | ROE is outside the qualifying period (QP) | The employment dates for “Other Employers” are not in the QP - The dates the client provided in AW in the section Other Employers are in the QP, but the actual dates on the ROE are not in the QP. Example: BPC: w/c 2034 (June 12, 2016) QP: June 14, 2015 to June 11, 2016 LDW in the section Other Employers in AW: June 16, 2015 LDP on the ROE: June 3, 2015 [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0581.dita) | Calculation of a claim [Calculation of a claim](/en/procedure/generic/additionalresources/index_calc_claim.shtml) |

| 5 | No interruption of earnings (I of E) | The ROE was issued with the reason for separation (RFS) K - Other . The officer contacted the employer and determined there was no I of E from that employer. Once the REM WI is submitted: - Move the Adjudication Issue (ADJ) WI to Pending for 2 business days or until the Claim Assessment (CA) WI is created. - Delete the ADJ WI (authorized officers only) once the CA WI is created. [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0582.dita) | Actioning an Adjudication Issue RFS Review WI: K - Other [Actioning an Adjudication Issue RFS Review WI: K - Other](/en/procedure/task/adj_rfs_review_k_other.shtml) |

| 6 | Antedate allowed | An antedate has been approved on the claim that is in automation. | Antedate Calculation of a claim [Antedate Calculation of a claim](/en/procedure/generic/additionalresources/index_calc_claim.shtml) |

| 7 | Benefit type (BT) correction | The client applied for the wrong BT and the claim is in automation. [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0583.dita) | Correcting the benefit type during automation [Correcting the benefit type during automation](/en/procedure/task/correcting_benefit_type_during_automation.shtml) |
```

```text
| Create a REM WI as follows: |

| - Complexity: Select Level 1 . - Reason: Select Other . - Comments: Type “ACP.” - Due Date: Enter today’s date. - Language: Select the appropriate option. - Details: Type “[1a, 1b, 2, 3, 4, 5, 6, or 7] and [unassigned (UNA) or the name of the officer to whom the Claim Assessment (CA) or Specialized Application (SA) WI must be assigned]. - Destination — Level: Select Canada . - End User: Select Specific user and type “SV-Admin, ACP-TAD.” - Select Save . |
```

For all other situations, the officer consults a Business Expertise Advisor to determine if the team responsible at National Headquarters needs to be contacted. 

### Note

Source topic: `en_EN/common_notes/note_c_0579.dita`

Note:

An officer must still review the new facts regarding the insurability of the employment, conduct the insurability screening and document a decision regarding the insurability. 

### Note

Source topic: `en_EN/common_notes/note_c_0580.dita`

Note:

ACP is waiting for an ROE with an LDP that is January 13, 2016 or later, based on the LDW declared in AW in the section Last Employer Information . If the officer confirms that the LDW is in fact the same as on the ROE, no additional ROE is sent. 

### Note

Source topic: `en_EN/common_notes/note_c_0581.dita`

Note:

The QP can be less than 52 weeks if the client has a previous claim. 

### Note

Source topic: `en_EN/common_notes/note_c_0582.dita`

Note:

If fact-finding reveals that there has been no I of E, documentation must be on file. 

### Note

Source topic: `en_EN/common_notes/note_c_0583.dita`

Note:

There cannot be an outstanding ADJ WI. 
