# ROE issued by the Government of Canada — Instructions

Source map: `en_EN/procedure/generic/additionalresources/roe-issued-gc-ins/roe-issued-gc-ins.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/roe-issued-gc-ins/additional_resources.dita`

Summary: There is a direct telephone line to address ongoing difficulties with conducting fact-finding for ROEs issued from Government of Canada departments and agencies served by Public Service Pay Centre .
       [departments and agencies served by Public Service Pay Centre](https://www.canada.ca/en/public-services-procurement/services/pay-pension/pay-administration/pay-centre-resources/departments-agencies-served-by-pay-centre.html)

**Contacting the Public Service Pay Centre**

Officers contact the Public Service Pay Centre’s Client Contact Centre at 1-855-686-4729 between 7am and 7pm EST, select their preferred language and press 6 on the keypad.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0584.dita) 

Officers may be put on hold before the call is connected. Before initiating fact-finding, the officer must identify as an EI officer from Service Canada and confirm that the other person on the line is a Client Service Representative.

When required, the Client Service Representative will call the EI officer back within 24 hours of obtaining any additional information or to confirm the issue is resolved. The EI officer is informed if the issue cannot be addressed and has been escalated.

If necessary, the officer sends a letter to the Public Service Pay Centre using the following address:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0585.dita) 

Because the mailing address is a post office box, the officer sends the letter by regular mail.

**Initial calculation — Missing ROEs (Level 1)**

An officer processing Claim Assessment (CA) WIs for clients employed by departments and agencies served by Public Service Pay Centre avoids finalizing claims as BPNE 2 or inputting 15 - Claim Procedure disentitlements (D15s) if the missing ROE is not the last ROE. In these cases, it is considered that the client unsuccessfully tried to obtain the ROE from the employer. The officer must fact-find with the client to complete the ROE: INS3166 Request for missing ROE — Form .
       [departments and agencies served by Public Service Pay Centre](https://www.canada.ca/en/public-services-procurement/services/pay-pension/pay-administration/pay-centre-resources/departments-agencies-served-by-pay-centre.html) 
       [ROE: INS3166 Request for missing ROE — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS3166.pdf)

Once the ROE: INS3166 Request for missing ROE — Form has been completed with the client, the officer confirms and verifies the pay period details required to create the interim ROE with the Client Service Representative. The officer also requests that the missing ROE be issued and that the Client Service Representative forward the request to the Public Service Pay Centre. Officers should not wait to create the interim ROE, since there is no guaranteed timeframe for employers to issue the ROE.
       [ROE: INS3166 Request for missing ROE — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS3166.pdf)

The officer refers to Determining if an interim ROE is required .
       [Determining if an interim ROE is required](/en/procedure/task/determining_interim_roe.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0586.dita) 

**Initial calculation — ROE verification**

The officer contacts the Public Service Pay Centre Client Contact Centre using the direct telephone line to request or verify ROE information.

**Initial calculation — Reason for separation**

A Client Service Representative can confirm the reason for separation (RFS) code on the ROE and provide some background information, if available, on the circumstances of the separation. If additional RFS information is required, the Client Service Representative can provide the local manager’s contact information.

**Recalculation**

For a recalculation using a Government of Canada ROE that requires correction, refer to Processing a Claim Review Recalculation WI — Government of Canada ROE (Task) .
       [Processing a Claim Review Recalculation WI — Government of Canada ROE (Task)](/en/procedure/task/cr_recalc_wi_goc_roe.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0584.dita`

Note:

Although 6 is not listed in the options menu; by pressing it, the officer is directed to a Client Service Representative, who is dedicated to assisting Service Canada with ROE corrections. 

### Callout

Source topic: `en_EN/common_notes/note_c_0585.dita`

Public Services and Procurement Canada Public Service Pay Centre Mail Facility PO Box 6500 Matane QC G4W 0H6 

### Note

Source topic: `en_EN/common_notes/note_c_0586.dita`

Note:

When inputting the interim ROE, the officer uses employer number 121491807RP0001. 
