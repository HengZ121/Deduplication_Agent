# Reconsideration under EIA 52 and amendment of a decision under EIA 111 — Instructions

Source map: `en_EN/procedure/generic/additionalresources/rec_eia_lae_52/rec_eia_lae_52.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/rec_eia_lae_52/additional_resources.dita`

Summary: A Level 2 officer can reconsider claims and decisions under EIA 52 and amend or rescind decisions under EIA 111.

**Table of contents**

- Ways an officer may receive a reconsideration or an amendment
         [Ways an officer may receive a reconsideration or an amendment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/rec_eia_lae_52#_Ways_an_officer)

- Reconsidering a claim — EIA 52

- Retroactive or current correction
             [Retroactive or current correction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/rec_eia_lae_52#_Retroactive_versus_current)

         [Reconsidering a claim — EIA 52](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/rec_eia_lae_52#_Reconsidering_a_claim)

- Amending or rescinding a decision — EIA 111

- New facts
             [New facts](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/rec_eia_lae_52#_New_facts)

         [Amending or rescinding a decision — EIA 111](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/rec_eia_lae_52#_Amending_or_rescinding)

- Documenting the decision
         [Documenting the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/rec_eia_lae_52#_Documenting_the_decision)

- Communicating the decision
         [Communicating the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/rec_eia_lae_52#_Letters)

- Inputting the decision
         [Inputting the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/rec_eia_lae_52#_Inputting_the_decision)

- Process for reconsidering under EIA 52
         [Process for reconsidering under EIA 52](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/rec_eia_lae_52#_Process_for_reconsidering)

- Process for amendment under EIA 111
         [Process for amendment under EIA 111](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/rec_eia_lae_52#_Process_for_amendment)

The legislation authorizes the Commission to reconsider claims and decisions and to amend or rescind disputed decisions. A client, an employer, or any other person subject to a decision may request a reconsideration of that decision.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0555.dita) 

**Receiving a reconsideration or an amendment**

A client, employer or any other person subject to a decision can submit new or additional information by:

- contacting the Service Canada call centre;

- visiting a Service Canada Centre (SCC);

- sending this information by mail;

- uploading documents in MSCA or ROE Web.

A reconsideration under EIA 52 can also be initiated internally. For example:

- a Business Expertise Advisor receives a request for guidance and discovers gaps in fact-finding, an error in the transactions, or some other issue that potentially impacts the claim;

- errors in processing the claim are discovered during quality monitoring.

Depending on whether it is an initial, renewal, continuing or terminated claim, and how the new information is received, the actions the officer takes to document the information on the client’s file vary:

- If it is an initial or renewal claim and the Claim action status is In Progress , the officer documents the new information on an SROC and reactivates the related Adjudication Issue (ADJ) WI that was completed.

- If it is a continuing or terminated claim, the officer documents the new information in an SROC and creates a Claim Review (CR) WI.

- NWS can also generate a CR WI automatically when new claim information is submitted.

New information can also be documented in an Action Item (AI) or Call Back (CB) WI.

Sometimes, the client or the employer may contact the officer directly to provide new information. If the decision has already been rendered and the WI completed, the officer refers to Actioning new information provided by the client or the employer after the WI has been completed .
       [Actioning new information provided by the client or the employer after the WI has been completed](/en/procedure/task/actioning_new_info.shtml)

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0556.dita) 

**Reconsidering a claim — EIA 52**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0557.dita) 

Reconsideration under EIA 52 addresses issues of entitlement or qualification (including earnings) and must result in an overpayment (OP) or an underpayment (UP). The reconsideration can be to correct errors, to review a claim or decision or to adjudicate following an investigation by Integrity. It can be requested by a client, an employer, or any other person subject to a decision. The Commission can also decide to reconsider a claim or a decision. The reconsideration must be completed within 36 months after the benefits were paid or would have been payable. In some situation and when there is a false or misleading statement, the timeframe may be extended to 72 months.
       [EIA 52](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

As part of a reconsideration, the Commission must take 4 distinct actions within the 36-month timeframe. If any of the 4 actions cannot be completed within this timeframe, the officer cannot reconsider the claim. These 4 actions are the following:
       [4 distinct actions](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/reconsideration.html#a17_3_0)

- deciding whether or not to reconsider the claim or the decision;

- rendering the new decision;

- calculating the OP or the UP;

- notifying the client of the decision.

When the 4 actions can be completed within the 36-month timeframe, the officer renders and adds the new decision to a record of decision (ROD), inputs the transaction and notifies the client. The officer also notifies the employer when the employer is an interested party.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0558.dita) 

**Retroactive or current correction**

A Commission error occurs when the Commission has all the relevant information to make a decision, but the final decision is not supported by the information on file. The error can occur in the adjudication process or when the transaction to prevent payment was not input.

When a Commission error results in benefits incorrectly paid to a client and the client could not have known that there was no entitlement to these benefits, the officer makes the correction from the next week to be processed. Otherwise, the officer corrects the error retroactively and an OP is created. If the Commission erred in denying benefits, these benefits will be paid.

However, when the Commission error resulted in a decision that is contrary to the structure of the EIA, the officer corrects the error retroactively, even if it results in an OP.

Retroactive reconsideration under EIA 52 can happen only if benefits have been:

- underpaid;

- paid contrary to the structure of the EIA ;
         [contrary to the structure of the EIA](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/reconsideration.html#a17_3_3_2)

- paid because of a false or misleading statement;

- paid and the client ought to have known that there was no entitlement to the benefits paid.

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0559.dita) 

**Amending or rescinding a decision — EIA 111**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0560.dita) 

Amendment under EIA 111 addresses decisions under dispute that require correction because new facts are presented, a material fact was not considered, or was incorrectly considered when the original decision was made. Amendment can be requested by a client, an employer, or any other person who is subject to the decision.
       [EIA 111](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-111.html)

The amending or rescinding of a decision under dispute cannot be performed unless the officer determines that any of the following criteria of EIA 111 are met:

- There are new facts on the file.

- The decision was made without knowledge of a material fact.

- The decision was based on a mistake of a material fact.

When one of the criteria is met and the decision under dispute can be amended or rescinded, the officer renders and adds the new decision to a ROD, inputs the transaction and notifies the client. The officer also notifies the employer when the employer is an interested party.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0561.dita) 

**New facts**

New facts are facts that either happened after a decision was rendered or happened before a decision, but could not have been discovered by the client acting diligently . The new fact must also have a fundamental impact on the decision.
       [acting diligently](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/amendment.html#a17_4_2_2)

Without knowledge of a material fact

Without knowledge of a material fact refers to situations in which any one of the following occurs:

- A material fact was on file at the time the decision was made, but it was overlooked.

- The existence of a material fact was made known by one of the parties, but the officer did not request it or take it into consideration when making the decision.

- The material fact was available before the decision was made, but the officer was unaware of it or did not explore that option thoroughly due to insufficient fact-finding.

Mistake as to a material fact

A mistake as to a material fact happens when a fact was on file or was noted by the officer but was misunderstood and the misinterpretation of that fact resulted in an incorrect decision.

**Documenting the decision**

In NWS, the officer creates a ROD to document whether or not the criteria are met to reconsider or amend a decision under EIA 52 or 111.

The reconsideration and amendment RODs should include the following:

- the issue that resulted in the reconsideration;

- the relevant facts;

- the decision and rationale on whether or not EIA 52 or 111 applies;

- the impact of this decision;

- the EIA, EIR, jurisprudence and Digest references.

If the criteria to reconsider or amend a decision are met, a separate ROD is also required for the new decision on the issue that caused the reconsideration or amendment. When there is a Resolve Issue tab on the ADJ WI, the officer invalidates the initial ROD.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0562.dita) 

**Communicating the decision**

The reason for the reconsideration and its result determine if a letter must be sent to the client, the employer or any other person subject to the decision.

**A client, an employer or any other person who requested a reconsideration**

If the criteria are not met to reconsider under EIA 52 or 111, the officer sends the A-01-00-00 letter to advise the client that a reconsideration is not possible or the Z-00-00-00 letter to advise the employer or any other person. In these situations, the officer does not include the right to request a reconsideration in the letter.

If the criteria are met to reconsider under EIA 52 or 111, but the decision on the issue is maintained , the officer sends the A-01-00-00 letter to advise the client of this. If the criteria are met and the decision is not maintained, the officer sends the appropriate decision letter to advise the client of this new decision only when it is not in the client’s advantage (D-01-00-00, D-20-16-03, N-00-00-00, etc.). Sending a letter to the client is not required when the reconsideration or amendment results in a UP because the payment is considered a notification.

If a new decision is made in the client’s advantage and the employer is considered an interested party, the officer notifies the employer that the initial decision has been changed using the Z-01-00-00 letter. The officer also indicates the employer’s right to request a reconsideration under EIA 112.

If a new decision is made and is not to the advantage of any other person subject to it, the officer notifies this person of this new decision using the Z-00-00-00 letter.

**Internal review**

If the criteria are not met to reconsider under EIA 52, or if the criteria are met, but the decision is maintained , no letter is sent.

If the criteria are met to reconsider under EIA 52 and the decision is not maintained, the officer sends the appropriate decision letter when the new decision is not in the client’s advantage (D-01-00-00, D-20-16-03, N-00-00-00, etc.). When the employer is an interested party, the officer also notifies them.

**Inputting the decision**

If the reconsideration is on an active or terminated claim, the officer inputs the transactions in FTS. If the claim is blocked, the officer inputs the transactions in BCS. Otherwise, the officer sends an Operational Centre Memo (MM06) transaction to IPOC.

If the criteria are not met to reconsider or amend a decision or if the decision is maintained, the officer completes the registration number related to the request.

**Process for reconsidering under EIA 52**

- Create the ROD for the decision to proceed with the reconsideration or not under EIA 52. Then, do one of the following:

- If the criteria are met to proceed with the reconsideration, in the Comments field, type “Reconsideration EIA 52 — [Issue] — [Employer name] — [Date] — Criteria met.” Then, go to step 2.

- If the criteria are not met to proceed with the reconsideration or if the decision is maintained, do the following:

- In the Comments field, type “Reconsideration EIA 52 — [Issue] — [Employer name] — [Date] — [Criteria not met or decision maintained].”

- Determine if the client, the employer or any other person who is subject to a decision requested the reconsideration or if it is an internal review:

- If the client, the employer or any other person who is subject to a decision made the request, go to step 6.

- If it is an internal review, go to step 7.

- Refer to the appropriate task only to adjudicate the issue being reconsidered and create a new ROD for the issue:

- In the Comments field, type “Reconsideration EIA 52 — [Issue] — [Employer name] — [Date] — Decision [rescinded, modified or terminated].”

- If there is a Resolve Issue tab on the initial ROD, invalidate that ROD.

- Determine the impact of the decision as follows:

- If the decision results in an OP, refer to Write-off to determine if the OP can be written off. Go to step 4.
             [Write-off](https://ort-orl.esdc-edsc.canada.ca/en/procedure/activity/write_off.shtml)

- If the decision results in a UP, go to step 5.

- Verbally communicate the negative decision to the client.
         [Verbally communicate](/en/procedure/task/verbal_communication.shtml)

- Input the necessary transactions in the appropriate systems to implement the new decision, including rescinding any manual action (MA) related to the issue being reconsidered.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0563.dita) 

- In ACS, create and send the appropriate letters.

- If an OP is created, add the appropriate OP message, and indicate the right to request for reconsideration.

- If the criteria are not met to proceed with the reconsideration or the initial decision is maintained, complete the registration number.

- Complete the WI.

**Process for amendment under EIA 111**

- Create the ROD for the decision to proceed with the amendment or not under EIA 111. Then, do one of the following:

- If the criteria are met to proceed with the amendment, in the Comments field, type “Amendment EIA 111 ― [Issue] — [Employer name] — [Date] — Criteria met.” Then, go to step 2.

- If the criteria are not met to proceed with the amendment, in the Comments field, type “Amendment EIA 111 — [Issue] — [Employer name] — [Date] — [Criteria not met or decision maintained].” Then, go to step 6.

- Refer to the appropriate task only to adjudicate the issue being amended or rescinded and create a new ROD for the issue.

- In the Comments field, type “Amendment EIA 111 — [Issue] — [Employer name] — [Date] — Decision [rescinded, maintained, modified or terminated].”

- If there is a Resolve Issue tab on the initial ROD, invalidate that ROD.

- Determine the impact of the decision as follows:

- If the decision results in an OP, refer to Write-off to determine if the OP can be written off. Go to step 4.
             [Write-off](https://ort-orl.esdc-edsc.canada.ca/en/procedure/activity/write_off.shtml)

- If the decision results in a UP, go to step 5.

- If the decision is maintained, go to step 6.

- Verbally communicate the negative decision to the client.
         [Verbally communicate](/en/procedure/task/verbal_communication.shtml)

- Input the necessary transactions in the appropriate systems to implement the new decision, including rescinding any MA related to the issue being reconsidered.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0563.dita) 

- In ACS, create and send the appropriate letters.

- If an OP is created, add the appropriate OP message, and indicate the right to request a reconsideration.

- If the criteria are not met to proceed with the amendment or the initial decision is maintained, complete the registration number.

- Complete the WI.

**Policy Reference**

- BE 2007-04 — Simplified Claims Processing: Reconsideration
         [BE 2007-04 — Simplified Claims Processing: Reconsideration](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2007-04.shtml)

- Digest 17 — Reconsideration, amendment and return of benefit
         [Digest 17 — Reconsideration, amendment and return of benefit](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/table-of-contents.html)

- EIA 52
         [EIA 52](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- EIA 111
         [EIA 111](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-111.html) 

### Info

Source topic: `en_EN/common_notes/note_c_0555.dita`

Note: Although EIA 52 allows the Commission to reconsider a claim within 36 months or within 72 months when there is a false statement, this page refers only to the 36-month timeframe. The Level 2 post-audit officer assesses and adjudicates whether a false statement was knowingly made. The decision may result in a penalty or violation. 

### Info

Source topic: `en_EN/common_notes/note_c_0556.dita`

Note: It is the responsibility of a Level 2 post-audit officer to complete CR Integrity WIs. The post-audit officer refers to Integrity case to process the file.
       [Integrity case](/en/procedure/activity/integrity_case.shtml)

If there is a Request for reconsideration (RFR) WI or if reconsideration under EIA 112 has already been performed for the same issue and for the same period, the officer reassigns the WI to the appropriate Appeal Processing Centre (APC).

     [Integrity case](/en/procedure/activity/integrity_case.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0557.dita`

Note:

This information does not apply to error corrections related to earnings made within the 36-month timeframe or to any other type of error corrections made within the 6-week timeframe. 

### Note

Source topic: `en_EN/common_notes/note_c_0558.dita`

Note:

When the reconsideration results in an OP, the officer refers to Adjudicating a write-off to determine if the OP can be written off.
       [Adjudicating a write-off](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/adjudicating_write_off.shtml)

     [Adjudicating a write-off](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/adjudicating_write_off.shtml) 

### Callout

Source topic: `en_EN/common_notes/note_c_0559.dita`

Example — Retroactive correction

The client was dismissed because of the misuse of the company resources. The Level 2 officer determines that misconduct was proven and verbally notifies the client that a disqualification is imposed on the claim.

The officer sends a letter to the client confirming the decision but does not input the indefinite 10 - Dismissal - misconduct proven disqualification (D10) in FTS. The client receives 10 weeks of benefits before the error is found.

Even though the Commission made an error in failing to input the disqualification, the client knew there was no entitlement to benefits. In this situation, the disqualification is imposed retroactively and an OP is created.

Example — Current correction

The client voluntarily left the employment and provided the reason for separation (RFS) on the EI application. However, the officer missed the contentious RFS and established the claim.

The client received 5 weeks of regular benefits before the error is found. The officer adjudicates the voluntary leaving and determines that the client did not demonstrate just cause.

Since the client could not have known there was no entitlement to benefits, the error is corrected from the next week to be processed, and no OP is created. 

### Note

Source topic: `en_EN/common_notes/note_c_0560.dita`

Note:

When reconsideration under EIA 52 is not possible, the officer determines if an amendment under EIA 111 is possible. 

### Note

Source topic: `en_EN/common_notes/note_c_0561.dita`

Note:

When the amendment results in an OP, the officer refers to Adjudicating a write-off to determine if the OP can be written off.
       [Adjudicating a write-off](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/adjudicating_write_off.shtml)

     [Adjudicating a write-off](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/adjudicating_write_off.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0562.dita`

Note:

When the new decision results in an OP, a ROD is also required for the write-off adjudication. For more information, the officer refers to Adjudicating a write-off .
       [Adjudicating a write-off](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/adjudicating_write_off.shtml)

     [Adjudicating a write-off](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/adjudicating_write_off.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0563.dita`

Note:

When a decision about a reason for separation is changed, the Special Condition field on the ROE in RCM must be changed to reflect the correct decision and the original ROD must be invalidated in NWS as the ROE and the automatically resolved or automatically adjudicated ROD may be used in the recalculation of a claim, or in the establishment of a new BPC in the future. Failure to make the change could result in the incorrect payment of benefits in the case of automation.

When a decision that resulted in an OP is completely rescinded on an archived claim or a blocked claim that is not updateable using BCS, send the inputs to IPOC on an Operational Centre Memo (MM06) transaction. 
