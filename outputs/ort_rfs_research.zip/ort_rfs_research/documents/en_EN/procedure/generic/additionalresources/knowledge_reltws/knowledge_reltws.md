# Work-Sharing: Information on Work-Sharing claims processing — Knowledge

Source map: `en_EN/procedure/generic/additionalresources/knowledge_reltws/knowledge_reltws.ditamap`

## Additional Resources

Source topic: `en_EN/procedure/generic/additionalresources/knowledge_reltws/additional_resources.dita`

Summary: This page provides information on how to process Work-Sharing (WS) claims and how to optimally navigate the EI ORT when processing an issue on a WS claim.

Table of contents

- Work-Sharing (WS) claims processing information in the EI ORT
         [Work-Sharing (WS) claims processing information in the EI ORT](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Work-sharing_claims_processing)

- Work-Sharing (WS) program
         [Work-Sharing (WS) program](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Work-sharing_Program)

- Client communication
         [Client communication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#clientcommunication)

- Differences between Work-Sharing (WS) claims and regular claims

- Interruption of earnings (I of E)

- ROE
                 [ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Record_of_Employment)

             [Interruption of earnings (I of E)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Interruption_of_Earnings)

- Reference code
             [Reference code](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Reference_Code)

- Waiting period (WP)
             [Waiting period (WP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Waiting_Period)

- Work-Sharing (WS) week
             [Work-Sharing (WS) week](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Work_sharing_week)

- Earnings from Work-Sharing (WS) employment
             [Earnings from Work-Sharing (WS) employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Earnings_from_Work-Sharing)

- Normal weekly hours (NWH)

- Irregular work week
                 [Irregular work week](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#iww)

- Unconventional schedule that includes regular lay days
                 [Unconventional schedule that includes regular lay days](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#unconsched)

             [Normal weekly hours (NWH)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#nwh)

- Availability
             [Availability](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Availability)

- Out of Canada

- Partial week of disentitlement on a Work-Sharing (WS) claim
                 [Partial week of disentitlement on a Work-Sharing (WS) claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Out_of_Canada_1)

- Determining the correct hours missed due to Work-Sharing (WS) for out of Canada part-week disentitlements
                 [Determining the correct hours missed due to Work-Sharing (WS) for out of Canada part-week disentitlements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Determining_the_correct_1)

             [Out of Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Out_of_Canada)

- Sickness
             [Sickness](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Sickness)

- Casual sickness
             [Casual sickness](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#casual_sickness)

- Duration of and extension to the benefit period (BP)
             [Duration of and extension to the benefit period (BP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Duration_and_Extension)

- Adjudication of reasons for separation (RFS)
             [Adjudication of reasons for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Adjudication_of_reasons)

- Disqualification and disentitlement
             [Disqualification and disentitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Disqualification_and_Disentitlement)

- Payments processing

- Utilization report (UR)
                 [Utilization report (UR)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Utilization_report)

- Claimant's report
                 [Claimant's report](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Claimant_report)

- Exemption from completing claimant's reports
                 [Exemption from completing claimant's reports](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Exemption_from_Completing)

- AWSS
                 [AWSS](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Automated_Work-Sharing_System)

- Normal weekly hours (NWH)
                 [Normal weekly hours (NWH)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#nwh2)

- Benefits paid
                 [Benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Benefits_Paid)

             [Payments processing](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Payments_Processing)

- Administrative review
             [Administrative review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Administrative_Review)

         [Differences between Work-Sharing (WS) claims and regular claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Differences_between_Work-Sharing)

- Claims processing

- Application for EI benefits

- Applying for Employment Insurance Work-Sharing Benefits — Template
                 [Applying for Employment Insurance Work-Sharing Benefits — Template](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Important_notice_for)

             [Application for EI benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Application_for_Employment)

- Automation
             [Automation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Automation)

- End of Work-Sharing (WS) agreement
             [End of Work-Sharing (WS) agreement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Agreement_Duration)

- Subsequent Work-Sharing (WS) agreements
             [Subsequent Work-Sharing (WS) agreements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#_subsequent_ws_aggreement)

- Planned shut down during Work-Sharing (WS) agreement
             [Planned shut down during Work-Sharing (WS) agreement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Work_shortage_during)

         [Claims processing](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Claims_Processing)

- Work-Sharing (WS) beyond 104 weeks
         [Work-Sharing (WS) beyond 104 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#_ws_aggreements_beyond_104_weeks)

- Review of a claim established after a claim that reached week 104
         [Review of a claim established after a claim that reached week 104](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#_review_claims_established_after_week_104)

- Renewal for a Work-Sharing (WS) claim
         [Renewal for a Work-Sharing (WS) claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#renew_ws)

- Regional Work-Sharing (WS) coordinator responsibilities

- Reference code
             [Reference code](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#ReferenceCode)

- Project data (M171) transaction inputs
             [Project data (M171) transaction inputs](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#ProjectDataInputs)

- Work-Sharing (WS) agreement extensions
             [Work-Sharing (WS) agreement extensions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Extensions)

- Review of SU 39241 report
             [Review of SU 39241 report](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#SU39241Report)

- Regional Work-Sharing (WS) coordinators
             [Regional Work-Sharing (WS) coordinators](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#RegionalWorkSharingCoordinators)

         [Regional Work-Sharing (WS) coordinator responsibilities](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#RegionalCoordinatorResponsibilities)

- Roles and responsibilities
         [Roles and responsibilities](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#RR)

**Work-Sharing (WS) claims processing information in the EI ORT**

The processing or adjudication of a WS claim does not differ significantly from the processing or adjudication of a regular benefit claim. WS claims are to be considered as regular claims unless otherwise specified in this document. When no particularities apply to the processing or adjudication of a WS claim, refer to the relevant regular benefits task.

     [Example: Out of Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0474.dita) 
     [Example: Adjudicating reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0475.dita) 

**Work-Sharing (WS) program**

The WS program provides income support to employees who are eligible for regular benefits and who work a reduced work week. This enables the employer to retain all core employees rather than laying off one or more. Information on the WS program is available on the WS program page at Canada.ca . Employers who have questions about the program should be directed to this website. Further information can also be obtained by calling the phone number on the website: 1-800-367-5693.
       [Canada.ca](https://www.canada.ca/en/employment-social-development/services/work-sharing.html)

**Client communication**

WS claims are established in the province where the employer is located. Clients who live in a different province than the employer must use their employer’s postal code when logging in their My Service Canada Account (MSCA).

**Differences between Work-Sharing (WS) claims and regular claims**

A WS claim is established as a regular claim but differs from a regular claim in the following ways.

**Interruption of earnings (I of E)**

An I of E for WS occurs at the beginning of the week in which there is a reduction of at least 10% in the client’s normal weekly earnings (NWE). This normally happens in the first week of the WS agreement.

A WS I of E is not considered a special I of E.

**ROE**

The program officer determines the start date of the WS agreement. All WS agreements start on Sundays, and the program officer instructs the employer to issue ROEs with a last day worked (LDW) in the week preceding the WS agreement start date. The employer completes an ROE for all employees in the WS unit.

The ROE is completed in the following manner:

- Block 11 Last Day Paid (LDP): reflects the LDW prior to the start date of the WS agreement

- Block 14 Expected Date of Recall: leave blank

- Block 16 Reason for Issuing this ROE: H - Work-Sharing

- Block 17 Payments in the final pay period or payable at a later date: leave blank

**Reference code**

The reference code is a 16-digit code used to identify WS claims. The reference code is valid for 8 weeks from the WS agreement start date for new agreements or from the date clients are added to an agreement that is already implemented. When a client submits an EI application with a valid reference code, the client is presented with a specialized application instead of the standard application.

WS agreement information must be entered when a client requests WS benefits. The information is obtained from the reference code. The WS agreement information can be automatically populated in FTS from the client’s EI application or manually input by an officer.

```text
| Reference code digits | Information contained in the reference code |

| 1 to 10 | Project Number | Project number digits |

| 1 to 4 | Service Canada Processing Centre |

| 5 and 6 | Specialized application code for WS (03) |

| 7 to 10 | Unique identifier |

| 11 to 14 | Agreement start date |

| 15 and 16 | Agreement duration (weeks) |
```

After the first UR is received, the Project Number is automatically updated with the WS agreement number. If the officer has the agreement number, it can be used in place of the first 10 digits of the reference code.

**Waiting period (WP)**

The WP is deferred so that WS benefits can be paid. However, the client must serve it to receive other types of benefits. This can occur during the WS agreement (e.g. the client is sick in a WS week). Earnings received during the WP are deducted dollar for dollar from the first 3 payable weeks of non-WS benefits. WP earnings are not recouped from weeks of WS.

When the client indicates an LDW in the first week of WS with reported earnings exceeding 125% of the benefit rate, ACP postdates the renewal to the following week. As earnings from WS employment are not deducted in a WS week, the claim must not be postdated. Only earnings received from outside the WS employment are considered earnings and deducted from a WS week. The officer corrects the postdate in these cases.

**Work-Sharing (WS) week**

A week is processed as a WS week when the client works at least half an hour under the WS agreement during the week.

Clients are payable WS benefits in a WS week when they miss at least half an hour of work under the same WS agreement. When the claimant’s report is processed, the system considers a week in which no hours are worked to be a non-WS week and determines the entitlement to regular or special benefits. The WP can be served, WP earnings can be recouped, and other EI benefits can be payable according to normal entitlement principles.

**Earnings from Work-Sharing (WS) employment**

Earnings that arise from WS employment are not deducted in a WS week. This prevents income earned from the WS employment from reducing benefits. This includes wages, paid sick leave (PSL), paid vacation time, wage loss insurance and workers’ compensation benefits. Only earnings received from outside the WS employment are deducted from a WS week.

If the employer pays the client a lump sum or an amount exceeding the client’s NWE, the officer determines if the amount is considered earnings. If so, the officer determines to which weeks the amount must be allocated. Since the amount cannot be allocated to a week that is processed as a WS week, refer to Allocating earnings from a Work-Sharing employer for the steps to follow.
       [Allocating earnings from a Work-Sharing employer](/en/procedure/task/allocate_earnings_ws_employer.shtml)

Most provincial labour laws and collective agreements have conditions in place that ensure an employee must be paid a minimum number of hours when called in to work. The legislation does not allow Service Canada to convert hours of pay into hours of work and the WS regulations do not provide for deductions of monies paid by the WS employer in a week of WS. WS benefits are paid based on the number of hours physically worked and the number of hours missed due to WS, without reference to earnings paid.

**Normal weekly hours (NWH)**

A program officer determines WS clients’ NWH at the beginning of a WS agreement. NWH are used to determine the percentage of work employees have missed and the amount that may be payable to them.

NWH normally do not change during a WS agreement. However, NWH are corrected if the program officer determines that an error has been made when establishing NWH. The program officer may also approve a change to NWH during a WS agreement when an approved change in a client’s weekly scheduled hours occurs. For more information, the officer refers to Modifying normal weekly hours on a Work-Sharing claim .
       [Modifying normal weekly hours on a Work-Sharing claim](/en/procedure/task/modifying_nwh_ws_claim.shtml)

**Irregular work week**

When a client works different hours from week to week, the program officer uses an average of the hours worked over the last 2 years to determine the NWH to be used on the claim file. Although the averaged NWH are used to determine the payment owed to the client, the employer reports the actual NWH that the client would have worked if the WS agreement was not in place. Although the weekly payments may appear to be miscalculated, they average out over the period of the rotating schedule.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0476.dita) 

**Unconventional schedule that includes regular lay days**

In rare cases, employers have no regular days off. There can also be a week or weeks in which there is no work at all. These cases are very complex and the program officer works with IPOS at National Headquarters to determine the most appropriate way for the employer to complete the UR and ensure their employees are fairly compensated for the loss of hours due to the WS agreement. This generally results in the employer using an averaging or pro-rating formula on the UR and uploading the URs less regularly than once a week.

**Availability**

Clients on a WS claim are considered to be available during any week in which they work for their WS employer. They are not required to be available for work with other employers during these weeks. However, clients must be available for additional work with the WS employer up to their normal hours of work. If a client could have worked, but was not available or declined to work, these hours are not counted as hours missed due to WS. Therefore, WS benefits are not paid for those hours. For more information on WS and availability, the officer refers to Digest 25.5.2 .
       [Digest 25.5.2](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-25/week-work-sharing.html#h2.03)

Normal availability principles apply during weeks processed as non-WS weeks (e.g. weeks of shutdown or full weeks of non-availability).

WS clients are required to report any absences from their area of residence when those absences are not a requirement of the WS employment.

**Out of Canada**

The same principles that apply to clients on regular claims outside of Canada apply to WS clients. A client who is required to perform duties outside Canada for their employer is automatically disentitled from any benefits, including WS. Specific exceptions and related timeframes under Regulation 55 also apply to WS claims.

The application of part-week disentitlements differs because of the way the system calculates benefits during WS weeks. A 13 - Outside Canada disentitlement (D13) is imposed for whole weeks when the client informs Service Canada of an absence from Canada prior to departure. The officer removes the D13 once the correct measures have been taken for any part-week disentitlements. When imposing part-week disentitlements for out of Canada, go to Partial week of disentitlement on a Work-Sharing claim .
       [Partial week of disentitlement on a Work-Sharing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Out_of_Canada_1)

**Partial week of disentitlement on a Work-Sharing (WS) claim**

WS clients are subject to the same out of Canada provisions (refer to Out of Canada ) as other clients. Because the system ignores part-week disentitlements when determining the benefits payable in a WS week, the hours reported as missed due to WS must be examined and adjusted, if necessary, to apply the equivalent effect in a WS week.
       [Out of Canada](/en/procedure/activity/out_canada.shtml)

Where a part-week Out of Canada disentitlement is can be applied to a WS client, the Level 1 officer is responsible for determining partial weeks and making the necessary adjustment to claimant’s reports, even when adjudication of the issue has been referred to Level 2.

**Determining the correct hours missed due to Work-Sharing (WS) for out of Canada part-week disentitlements**

The officer examines and adjusts, if necessary, the hours missed due to WS to reflect the correct entitlement to benefits.

To determine the correct hours missed, a daily breakdown of the hours reported as missed due to WS is required. If this information is not already documented, the officer fact-finds with the employer to obtain the daily breakdown of hours missed due to WS.

If clients are not entitled to benefits for the day, any reported hours missed due to WS for that day must be removed from the weekly total. If no hours were reported as missed due to WS for the day (either because it was not a WS day or because the absence was already considered when reported), no adjustment is necessary.

Adjustments may also be necessary for periods during which the client is allowed to be outside of Canada. For allowable periods during which the client would have missed hours due to WS but these hours were not reported (i.e. because the employer did not know the reason for the client’s absence from Canada), the hours must be added to the weekly total.

The officer’s fact-finding and adjustment to the hours missed due to WS on the claimant’s report must be documented on an SROC.

The officer makes adjustments to the hours missed due to WS if necessary by reviewing the amount indicated as Declared or Coded for Worksharing in the Payment Details window in FTS and by submitting a modified claimant’s report with the adjusted amount (refer to Modifying a claimant’s report ).
       [Modifying a claimant’s report](/en/procedure/task/modifying_cr.shtml)

**Sickness**

A week in which a client misses a full week due to unpaid sickness is counted as a week of sick benefits. The client must be eligible for sickness benefits and first serve a WP, if not yet served or waived, to receive benefits.

When clients declare fewer than 5 sick days in a week in which they worked half an hour or more, it is considered a WS week, and the sick days are ignored. The client receives payment only for the hours missed due to WS. When a client is exempt from reporting and the employer declares fewer than 5 sick days in a week in which the client did not work for the WS employer, there is a presumption that the client is sick for the full week.

**Casual sickness**

There are 2 different counters for weeks of casual sickness for any individual claim:

- Consecutive casual sickness declared: If this counter is at 4 consecutive casual sickness weeks, whether these weeks are paid or not, and a fifth week of casual sickness is input, the claimant’s report is rejected with a C465 error.

- Total casual sickness weeks paid: When 8 weeks of casual sickness have been paid on a claim, consecutive or not, and a ninth week of casual sickness is input, the claimant's report is rejected with a C484 error.

**Duration of an extension to the benefit period (BP)**

WS benefits do not reduce the duration of or entitlement to regular EI benefits. Each week processed as a WS week results in a week of extension to the BP. The BP is automatically extended by the system up to 104 weeks.

When the system processes a week as a regular week during a WS agreement, the BP is not extended automatically. However, the week is considered to be a WS week for the purpose of BP extensions due to policy and can also extend the BP. These weeks are reviewed for manual extension in Extending the benefit period — Work-Sharing claims beyond 104 weeks when the claim reaches 104 weeks and a subsequent claim is established.
       [Extending the benefit period — Work-Sharing claims beyond 104 weeks](/en/procedure/task/extending_bp_ws_cb104w.shtml)

**Adjudication of reasons for separation (RFS)**

Voluntary leaving and dismissal are not specifically addressed in the WS portion of the EIA and EIR. Therefore, they are adjudicated according to regular claims.

Participation in a WS agreement is voluntary, but all employees of a WS unit must agree to reduce their normal work hours and to share the available work. This means that it is not misconduct if a client refuses to participate in a WS agreement and is dismissed as a consequence. It is also not just cause when a client quits instead of participating in a WS agreement, and this is the sole or primary reason the client leaves. The client must show that all reasonable options were explored prior to leaving.

**Disqualification and disentitlement**

Disqualifications imposed for voluntary leaving or misconduct are not suspended to pay WS benefits.

Other outstanding disqualifications or disentitlements are automatically deferred, except for: D5, D12, D13, D14, D15, D21, D38, D39, D42, D43 and D48. Outstanding disentitlements and disqualifications deferred to allow payment of WS benefits are reinstated following the end of the WS agreement.

A week in which the client is disentitled for a full week is considered a non-WS week (regular or special benefits).

A week in which the client is disentitled for a partial week but during which the client worked at least a half hour for the WS employer, is considered a WS week. The system ignores partial disentitlements when the week is a week of WS. This is because the client is paid based on hours missed due to WS. Go to Out of Canada for the procedures to follow if imposing a partial disentitlement because the client is out of Canada for part of a week.
       [Out of Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/additionalresources/knowledge_reltws#Out_of_Canada)

**Payments processing**

**Utilization report (UR)**

Every week, employers complete a UR used to determine the benefits payable to their WS employees.

The UR contains the agreement number, employer name, week starting date and the following information for each employee:

- SIN

- Name

- NWH

- Hours worked

- Days N/A or days missed due to sickness

- PSL amounts

- Hours missed due to WS

- Other paid amounts

- Comments

IPOC uploads the information from the UR, and it is matched to the claimant’s report for the same week.

**Claimant’s report**

Claimant’s reports are either generated by the system when the client is on NO-CR-CODE or when the client completes a paper claimant’s report and sends it in the mail. Clients on WS cannot submit their reports electronically.

Claimant’s reports generated for clients on NO-CR-CODE contain no pay coding and are processed based on the information on the UR. When an amendment to a WS claimant’s report is necessary, WS pay coding must be present.

When a client must complete a paper claimant’s report, the client completes the report in a specific way.

```text
| Block | Description |

| 1a | Answer No, unless the client was out of Canada between Monday and Friday. If so, the client must answer Yes and indicate if the absence from Canada was for less than 24 hours, excluding weekends, as well as provide the reason, date and time of departure and arrival for the absence from Canada in blocks 1b and 1c . |

| 2a | Answer No , unless the client worked for another employer than the WS employer. If so, the client must answer Yes and provide the dates and total hours worked as well as gross earnings received from the non-WS employer in blocks 2b and 2d . |

| 2c | - If No , indicate the name of the WS employer. - If Yes , indicate the name and address of the employer (must be different than the WS employer). |

| 2e | If the client stopped working for any employer during that week, the reason must be provided regardless of if the client worked for that employer during that week. |

| 3a | Answer No , unless the client started a full-time job with an employer other than a WS employer. If so, the client must answer Yes and provide the date they started the full-time job. |

| 4a | Answer No , unless the client is physically attending a course of instruction. If so, the client must answer Yes and declare the total hours attended, any amount of training allowances they received and who they received that allowance from, if necessary, in blocks 4b and 4c . |

| 5a | Answer Yes , unless the client is on vacation, sick or unavailable for any days covered by the claimant’s report. If so, the client must answer No and provide dates and the reason of non-availability in blocks 5b and 5c . The client also indicates any sickness or maternity insurance amounts received, if necessary, in block 5d . |

| 6a | Answer No , unless the client received monies other than already declared in blocks 2d , 4b and 5d and other than monies received from the WS employer. If so, the client must answer Yes and indicate who they received the monies from, the reason they received this payment for and the amount of these monies in blocks 6b , 6c and 6d . |
```

**Exemption from completing claimant’s reports**

When the client completes an application for benefits with a WS reference code, they are presented with a specialized application and the exemption from reporting question. Certain situations, such as self-employment (including farming) or working for another employer (other than the WS employer), prevent some clients from being exempted from completing claimant’s reports. Clients who do not apply with a reference code or who wish to be exempted after choosing to complete claimant’s reports can be exempted later. Refer to Exemption from reporting for inputting and cancelling exemptions from reporting.
       [Exemption from reporting](/en/procedure/activity/exemption_reporting.shtml)

**AWSS**

AWSS allows for the UR to be automatically combined with a claimant’s report when a 76 - Automated work-sharing manual action (MA76) is present on the claim. An MA76 prevents claimant’s reports from being processed before the corresponding UR is received and allows AWSS to automate much of the payment process. It is present on all WS claims, except those requiring manual intervention by IPOC.

When an MA76 is present on a WS claim, the claimant’s report (including NO-CR-CODE generated claimant’s reports) cycles and the client’s declaration is transferred to AWSS. In AWSS, the declaration from the claimant’s report is called the client record. AWSS attempts to match the client record with the UR (called the employer record) for the equivalent period. Once a match is found, AWSS combines the 2 declarations, creates an automated Manual Action - Claimant’s reports (T045) transaction and transfers it to the system for processing.

The 14 - Work-sharing manual action (MA14) allows IPOC to process complex WS claims outside AWSS. At this time, the manual action is exclusively used when a client is participating in more than one WS agreement and IPOC needs to control the payment process. This is necessary because the client can only be paid for the hours missed on one WS agreement at a time and the system issues a payment based on the first UR received. The payment may or may not be issued for the WS agreement the client has chosen to be paid on.

**Normal weekly hours (NWH)**

NWH for a WS client are determined by the program officer at the beginning of a WS agreement. NWH are used to determine the percentage of work an employee has missed and how much may be payable.

NWH do not change during a WS agreement. However, the NWH are corrected if the program officer determines that an error has been made when establishing the NWH. Refer to Modifying normal weekly hours on a Work-Sharing claim for more details.
       [Modifying normal weekly hours on a Work-Sharing claim](/en/procedure/task/modifying_nwh_ws_claim.shtml)

**Benefits paid**

The WS benefits that a client receives in a week are determined by the client’s benefit rate, the client’s NWH and the number of hours reported as missed due to WS in a week. The client receives a proportion of the benefit rate that is equal to the hours missed due to WS compared to their NWH:

Benefits paid = benefit rate x hours missed due to WS ÷ NWH

Monies from the WS employer are not considered earnings and are not coded if they are present on the UR. All other monies are deducted as usual.

If necessary, family order agreement (FOA) and assignment of benefits (AOB) recoveries are deducted from any payable WS benefits.

**Administrative review**

Service Canada’s decision to approve or disapprove the establishment of a WS agreement is not subject to administrative review. This also includes amending a WS agreement. Any other decision with respect to a client’s entitlement is subject to administrative review.

**Claims processing**

**Application for EI benefits**

When WS clients apply online and enter a valid reference code, they are presented with a specialized application.

When WS clients apply online and do not enter a valid reference code, they are presented with a regular application.

**Applying for Employment Insurance Work-Sharing Benefits — Template**

The Applying for Employment Insurance Work-Sharing Benefits — Template is provided to the employee after the WS agreement has been approved. It contains the reference code to use on the application and the period in which the client must apply.
       [Applying for Employment Insurance Work-Sharing Benefits — Template](/resources/ort/documents/Applying_for_EI_Work_Sharing_Benefits_2021_en.docx)

**Automation**

The system can fully automate initial and renewal WS claims if the following conditions are met:

- A specialized application is filed through AW using a valid reference code.

- For initial claims, the last ROE with the RFS and all ROEs for previous employers in the last 52 weeks are on file.

- The application has no other conditions preventing the automation of the claim.

ACP uses the reference code to determine certain inputs:

- digits 1–10 = project number;

- digits 11–14 = the tentative BPC or BPC and the start week of the WS agreement;

- digits 15–16 = the number of WS weeks.

The client’s NWH are obtained from the information provided on the application.

If the claim cannot be automated, the system creates a specialized application WI in NWS.

For continuing claims and renewals that cannot be automated, the officer inputs a Renewal/Revised (M106) transaction with the date equal to the first WS week with code 2, 6 or 7. The officer adds either W - Worksharing - No Claimant’s reports or H - Worksharing with Claimant’s report . If the Claim action code is missing during the renewal, the officer makes sure the claimant’s reports for the period before the WS start week have been processed. Then, the officer inputs an MA76 on day 1 and inputs the code on day 2.

If the last week of the WS agreement has been processed and the MA76 no longer applies, the officer rescinds the manual action.

The officer can also use the 76R - Automated work-sharing Rescind/Removal of Cycling Reports manual action (MA76R) when the last week of the WS agreement has not been processed, if there are cycling claimant’s reports and if an MA76 no longer applies.

When the WS end week is beyond BPC + 103, the Project Data — Worksharing (M171) transaction input by ACP is rejected and no WI is created. The officer responsible for monitoring WS agreements reviews client claims for incomplete information and re-inputs the Project Data (M171) transaction with an agreement end week equal to BPC + 103.

**End of Work-Sharing (WS) agreement**

WS benefits end when the agreement end date is reached or when the WS agreement is terminated before the scheduled end date.

Work-Sharing benefits may end earlier for individual clients when the client:

- returns to full-time employment

- leaves the WS employment

- exhausts the benefits

- stops reporting

**Subsequent Work-Sharing (WS) agreements**

If a special measure allows an employer to enter into a subsequent WS agreement immediately after the existing agreement, that agreement is treated as any new agreement. Clients must apply with a reference code to participate in the subsequent agreement. WS program officers instruct employers to issue ROEs with an end date equal to the day of work before the new agreement.

Clients participating in a subsequent agreement are required to reapply if their claim reaches the end of the BP (BPC + 103)

**Planned shutdown during Work-Sharing (WS) agreement**

Employers can have periods where they shutdown operations. These periods of shutdown are either approved by the program officer, or the WS agreement is terminated.

If the WS agreement is terminated, all participants are removed from the WS agreement and must convert their claims to receive regular benefits. If the program officer does not terminate the agreement and the period of shutdown is for 4 weeks or less, clients can continue to be exempt from reporting. If the period of shutdown is for more than 4 weeks, clients can no longer be exempt from reporting and are required to complete paper claimant’s reports. Clients are subject to the same rights and responsibilities as regular clients during planned shutdowns.

Regardless of the period of shutdown, if the WS agreement remains in place, the employer is required to complete a UR for each and every week.

**Work-Sharing (WS) agreements beyond 104 weeks**

Each week that is processed as a WS week extends the BP by one week. The system extends the BP one week at a time when a week of WS is processed, until the 104th week of the BP, after which the system cannot automate further extensions.

When a client’s WS agreement end date is beyond the BPC + 103 week, the officer enters BPC + 103 as the end date. The officer advises the client by letter to reapply for regular benefits after the BPC + 103 week is processed. The officer documents this and the details of the WS agreement in a record of decision (ROD).

In the letter, clients are informed that the reference code they received at the start of the agreement has now expired and they are advised to apply without a reference code. Clients are also advised to indicate WS as the RFS on the application.

Clients must provide an ROE for any work in their qualifying period (QP), including WS. The last day on the WS ROE must be the last Saturday of the claim (i.e. the 104th week of the claim).

Because the client is now applying for regular benefits, the officer inputs the necessary transactions to establish the claim as a WS claim. This includes inputting a 76 - Automated Work-sharing manual action (MA76), which allows the claimant’s reports to be processed automatically based on the employer’s submission of the UR.

Additionally, the officer enters the WS agreement data found in the ROD. The Project start date is entered as the BPC of the claim.

When applying for regular benefits, the client is not given the option to request an exemption from reporting. In this case, the officer fact-finds with the client and offers that option. If necessary, the officer inputs the NO-CR-CODE.

**Review of a claim established after a claim that reached week 104**

When a WS claim reaches BPC + 103 and a new claim is established within 8 weeks, the claim appears on the SU39241 report in EDS .
       [EDS](http://eds-sde.prv/)

The regional WS coordinator is responsible for ensuring the report is reviewed. If the client’s new benefit rate is lower than on the preceding claim, the officer contacts the client and discusses the advantages and disadvantages of continuing with the new initial claim versus renewing the previous claim.

**Renewal for a Work-Sharing (WS) claim**

When a WS client submits an EI application, the renewal week is the WS agreement start date (digits 11–14 of the reference code). The officer antedates the renewal to the start week, if necessary.

When ACP has incorrectly postdated the renewal week due to earnings from the WS employer, the officer corrects the postdate. Earnings from WS employment are not deducted in a WS week. When ACP created an allocation type W - Earnings week 1 due to earnings from the WS employer in the renewal week, the officer rescinds the allocation. Earnings from WS employment are not deducted in a WS week.

If a deferred adjudication results in a disqualification on a renewal claim, a new BPC is required to pay WS benefits.

**Regional Work-Sharing (WS) coordinator responsibilities**

**Reference code**

Once a WS agreement is in place, the regional WS coordinator is responsible for obtaining and providing a reference code and expiry date to the citizen services specialist. A new reference code is also required when one or more employees are added to an original or extended agreement. When adding an employee, the coordinator issues a new reference code and advises the requester. Digits 11 to 14 of the 16-digit reference code represent the w/c of the agreement start date. When adding employees to the agreement, these digits represent the w/c the employee was added. ACP uses this w/c to set the proper tentative BPC, the BPC or the renewal week.

**Project data (M171) transaction inputs**

To process WS benefits for each employee, employers complete a WS Enrolment Information sheet, which lists all participating employees and their SIN. Upon receiving the enrolment sheet, the coordinator ensures that the top portion is completed and sends a copy to processing.

**Work-Sharing (WS) agreement extensions**

When the program officer approves a WS agreement extension, the regional WS coordinator is notified. The coordinator sends the required information (e.g. the template containing the employer name, the new agreement end date and the appropriate enrolment sheet) to processing for the M171 inputs.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0477.dita) 

**Review of SU 39241 report**

Claims that were processed up to the 104th week and are followed by a new claim (including BPNE claims) are identified on the SU 39241 weekly report that is available in EDS .
       [EDS](http://eds-sde.prv/)

The regional WS coordinator accesses the SU 39241 report every Tuesday. The coordinator pre-screens the report and crosses off the claims on which the benefit rate is higher on the active claim, since no action is required. The coordinator also ensures that the report is actioned weekly for claims on which the benefit rate is lower on the active claim.

To contact the WS coordinators, send an email to: esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca
       [esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca](mailto:esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca)

**Roles and responsibilities**

Refer to the Roles and responsibilities chart regarding the role of program officers, citizen services specialists, IPOC and the regional EI WS coordinator.
       [Roles and responsibilities chart](https://esdc.prv/en/service-canada/ei/reference-material/ipos/work-sharing/ws-roles-responsabilities.shtml) 

### Example: Out of Canada

Source topic: `en_EN/common_notes/note_c_0474.dita`

Example: Out of Canada

Refer to the relevant tasks when adjudicating an out of Canada issue for a WS client, and refer to this knowledge page before imposing any resulting disentitlement. 

### Example: Adjudicating reason for separation (RFS)

Source topic: `en_EN/common_notes/note_c_0475.dita`

Example: Adjudicating reason for separation (RFS)

Refer to the relevant tasks when adjudicating an RFS for a WS client, and refer to this knowledge page for additional considerations if a client is leaving a WS agreement. 

### Example

Source topic: `en_EN/common_notes/note_c_0476.dita`

Example

Two-week rotating schedule: Week 1: NWH = 45 Week 2: NWH = 35

45 + 35 = 80, 80/2 = an average NWH of 40. NWH of 40 is coded to the claim file.

Reported on the UR: Week 1: NWH = 45, hours worked = 27, hours missed due to WS = 18 Week 2: NWH = 35, hours worked = 21, hours missed due to WS = 14

If BPS is able to adjust the NWH on the claim file every week and the client’s benefit rate is $400/week, the client’s payment is: Week 1: (18/45) x $400 = $160 Week 2: (14/35) x $400 = $160 For a 2-week total of $320

With the averaged NWH on the claim file, the client’s payment is: Week 1: (18/40) x $400 = $180 Week 2: (14/40) x $400 = $140 For a 2-week total of $320 

### Note

Source topic: `en_EN/common_notes/note_c_0477.dita`

Note:

In Quebec, processing officers can access WS information directly from the Work-Sharing Reference Tool, an Outlook based communication tool. The regional WS coordinator does not need to forward WS information to processing. 
