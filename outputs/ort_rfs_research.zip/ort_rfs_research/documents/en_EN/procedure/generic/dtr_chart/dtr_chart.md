# Imaging: Document types — Table

Source map: `en_EN/procedure/generic/dtr_chart/dtr_chart.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/dtr_chart/generic.dita`

```text
| Document type | Description | Document Sub-Type to Image |

| CAL | Calculation | Best 14 / Small / Variable best weeks (INS 5241) | Proof of employment (INS 3166) |

| Insurability ruling | Application for an extension of benefit period |

| Employer earning | Application for an extension of the qualifying period |

| Other earnings | Incarceration proof |

| CLT | Client info | EI paper application | Entitlement questionnaire |

| Availability | Immigration documents |

| Employment | Name change |

| Fishing | No card request - Apprentices |

| Reason for separation (RFS) | Request for T4E |

| Teachers | Request to “Mail a copy of ... ” |

| Training | Voluntary termination request |

| Antedate | Bankruptcy |

| Authority to release claim info | TD1: Personal Tax Credit declaration/Change in Tax Status |

| Sickness / Client incapacity | Designation of a representative (INS3280) or Office of the Public Guardian and Trustee court order documents |

| Claim type change (to regular) | Status of returned warrants |

| Proof of identity | |

| EER | Employer information | Information about ROE | RFS information |

| 3 PI | Third-party info | Grievance ruling | Disability money |

| Agreement to repay | Motor vehicle accident payments |

| Canada Pension Plan details | Wage loss paid by a third party |

| Workers Compensation consent to release info | Request for info from a third party |

| Consent to release info to a third party | CRA appeal and deferral |

| Assignment of benefits (INS 3113) | CRA set-off |

| Personal bankruptcy | |

| SPC | Special benefits | CCB/Maternity/Parental/Family caregiver benefits | Medical certificates |

| INT | Integrity | Automated Earnings Reporting System | Formal investigation reports |

| Claimant information session / Selective | Insured earnings match |

| Computer post-audit (INS 5097) and (INS 5098) | Report on hiring |

| Customs | Self-employment / Business Registration Investigations / Self-employed earnings match |

| Employer | Job search form C-73-00-00 |

| Request to provide medical certificate | Sickness Medical Compliance N-04-00-01 |

| APPEALS | Appeals | SST Appeal | Request for reconsideration |

| OTH | Other | Collections | Undeliverable mail (with the envelope if attached to the undeliverable mail) |
``` 
