# Imaging: Actions required for imaged documents when there is no registration number — Instructions

Source map: `en_EN/procedure/generic/tbl_actions_noregistrationnumber/tbl_actions_noregistrationnumber.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/tbl_actions_noregistrationnumber/generic.dita`

```text
| DOCUMENTS | Recalc Footnote * [Footnote*](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#fn*) | Revised Footnote * [Footnote*](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_tables#fn*) | NWS | IMAGING Classification |

| A ccess to information request | | | SROC | Services |

| Antedate | | | AI WI | Action Taken |

| Appointment of representative / Office of the Public Guardian and Trustee court order documents | | | SROC (include the representative name) | Services |

| Assignment of benefit (AOB) enquiry | | | SROC | Services |

| Authorization to release info | | | SROC | Services |

| B ankruptcy | | X | SROC | Action Taken |

| Bankruptcy from overpayment (O/P) recovery | | X | SROC | Action Taken |

| Canada Revenue Agency (CRA) - Insurability ruling | X | | SROC | Action Taken |

| Canada Revenue Agency (CRA) - Notice of Assessment | | | AI WI | Action Taken |

| Canada Revenue Agency (CRA) - Letter-EI premiums | | | AI WI | Action Taken |

| Change of address (not input) | | | SROC | Services |

| D eceased claimant / Death certificate | | X | SROC | Action Taken |

| Disability | | X | SROC | Action Taken |

| E arnings | | X | SROC | Action Taken |

| Extension of the benefit period (BP) | | X | SROC | Action Taken |

| Extension of the qualifying period (QP) | X | | SROC | Action Taken |

| F ailure to report/attend | | X | SROC | Action Taken |

| Form to be completed by an agent | | | SROC | Services |

| G rievance ruling | X | | SROC | Action Taken |

| I mplied Status (proof) | | X | SROC | Action Taken |

| Incarceration (proof) | | X | SROC | Action Taken |

| Information requests (client or other) | | | SROC | Services |

| INS5097-5098 (decision rendered) | | X | SROC | Action Taken |

| J ob searches | | X | SROC | Action Taken |

| L abour disputes | | X | SROC | Action Taken |

| M edical certificate | | X | SROC | Action Taken |

| N ame change (not input) | | | SROC | Services |

| O ut of Canada | | X | SROC | Action Taken |

| P ay stubs requested by an agent | X | | SROC | Action Taken |

| Proof of identity (copies) | | | SROC | Services |

| Q uestionnaires (all) - Level 1 or 2 | | X | SROC | Action Taken |

| R eason for separation (RFS) | | X | SROC | Action Taken |

| Reconsideration of decision | | X | SROC | Action Taken |

| Request for Record of Employment (INS 3166) | X | | SROC | Action Taken |

| T ax deduction (request) | | | SROC | Services |

| Temporary Resident Visa | | X | SROC | Action Taken |

| Training | | X | SROC | Action Taken |

| U ndeliverable mail | | | AI WI | Action Taken |

| V ariable best weeks | X | | SROC | Action Taken |

| W arrant - Missing - Replacement (INS5207) | | | SROC | Services |

| Warrant - Returned | | | SROC | Services |

| Warrant - Stolen (INS2221) | | | SROC | Services |

| Warrant - Void/Cancelled | | | SROC | Services |

| Work Permit (IMM1442 or IMM1102) | | X | SROC | Action Taken |

| Workers Compensation (WC) | | X | SROC | Action Taken |
```

**Footnotes**

    Footnote * 
      Registration number required

Return to first footnote * referrer
           [Return to first footnote*referrer](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/tbl_actions_noregistrationnumber#fn*-1-rf) 
