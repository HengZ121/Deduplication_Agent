# Reviewing the calculation result — Messages

Source map: `en_EN/procedure/generic/rcr_screen_messages/rcr_screen_messages.ditamap`

## Generic

Source topic: `en_EN/procedure/generic/rcr_screen_messages/generic.dita`

Summary: During calculation, SSO may allow calculation, but display messages warning that an error may have occurred. The officer must review these messages and take action, if necessary.

**What you need to know**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0887.dita) 

When using SSO to calculate the claim, if SSO displays the following messages on the Calculation Result screen, you must review what to do:

- Actual date of birth or expected date of birth is coded - Is the external maternity window start week required?
         [Actual date of birth or expected date of birth is coded - Is the external maternity window start week required?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#adcedc)

- Actuals not automated
         [Actuals not automated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#actual)

- Allocation rescinded - Please review
         [Allocation rescinded - Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#allocationrescinded)

- Best Weeks - Actuals required
         [Best Weeks - Actuals required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#bestweeks)

- BPC could possibly be postdated - Please review
         [BPC could possibly be postdated - Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#bpcpostdated)

- BPC is after the Caregiver window end date - Please review
         [BPC is after the Caregiver window end date - Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#bpccriticallyill)

- BPC is greater than the current variable entrance requirement range - Verify the calculation result
         [BPC is greater than the current variable entrance requirement range - Verify the calculation result](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#bpcgreater)

- BPC is prior to caregiver start date window. Please review
         [BPC is prior to caregiver start date window. Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#parentsgreaterbpc)

- BPC not within the compassionate care window
         [BPC not within the compassionate care window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#bpcccw)

- BPC not within the parental window
         [BPC not within the parental window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#bpcpw)

- Caregiver benefits - Medical proof required…Please review
         [Caregiver benefits - Medical proof required…Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#criticallyill)

- Caregiver benefits - Minor attached
         [Caregiver benefits - Minor attached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#parentsminorattached)

- Claim is postdated - Verify the interruption of earnings
         [Claim is postdated - Verify the interruption of earnings](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#claimpostdated)

- Claimant did not qualify at Subsequent/Manual BPC. Claim was postdated
         [Claimant did not qualify at Subsequent/Manual BPC. Claim was postdated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#Claimant_did_not)

- Compassionate care benefit not approved
         [Compassionate care benefit not approved](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#ccbwnot)

- Compassionate care - Minor attached
         [Compassionate care - Minor attached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#ccminor)

- Compassionate care proof required …Please review
         [Compassionate care proof required …Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#ccp)

- CRA status value is equal to Deceased – Please review
         [CRA status value is equal to Deceased – Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#crastatus)

- Credit 300 insurable hours
         [Credit 300 insurable hours](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#Credit_300)

- Credit 480 insurable hours
         [Credit 480 insurable hours](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#Credit_480)

- D57 may be required
         [D57 may be required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#a1120)

- Daily average total > ROE total - Manually adjust the EHF
         [Daily average total > ROE total - Manually adjust the EHF](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#daily)

- Deferred maternity and waiting period waived – Please review
         [Deferred maternity and waiting period waived – Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#maternitywp)

- Disentitlement/disqualification is imposed - May qualify for special benefits
         [Disentitlement/disqualification is imposed - May qualify for special benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#disentmayqualifyspecial)

- Does not qualify on earlier date
         [Does not qualify on earlier date](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#earlierdate)

- Due to extension of qualifying period, additional insurable hours could be required
         [Due to extension of qualifying period, additional insurable hours could be required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#extension)

- Earnings in week 1 has changed, report processed. Review and determine if amendment is required
         [Earnings in week 1 has changed, report processed. Review and determine if amendment is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#ewk1_changed)

- Economic region is incorrect – Please review
         [Economic region is incorrect – Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#economicregion)

- EDC coded - Is EXT - MSW required
         [EDC coded - Is EXT - MSW required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#edccoded)

- Excluded record(s) of employment
         [Excluded record(s) of employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#excludedrecord)

- Hours added for auto QP ext
         [Hours added for auto QP ext](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#_Hours_added_for)

- Insufficient ROE earnings in the self-employed QP – Actuals are required
         [Insufficient ROE earnings in the self-employed QP – Actuals are required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#insufficentroe)

- Insurable earnings increased for minimum benefit rate
         [Insurable earnings increased for minimum benefit rate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#Insurable_earnings)

- Invalid Special Payments - Wage Loss Indemnity (EI Insurable)
         [Invalid Special Payments - Wage Loss Indemnity (EI Insurable)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#invalidsp)

- Later BPC may be more advantageous - input would be needed in the subsequent or manual BPC field of the coding requirements screen
         [Later BPC may be more advantageous - input would be needed in the subsequent or manual BPC field of the coding requirements screen](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#LaterBPC1054)

- Last ROE special condition is required
         [Last ROE special condition is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#LastROESPRequired)

- Manual actual(s) present - Actuals required
         [Manual actual(s) present - Actuals required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#manualactual)

- Maternity claim - BPC not within the maternity window
         [Maternity claim - BPC not within the maternity window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#bpcnotwithin)

- Maternity payable < 15 weeks
         [Maternity payable < 15 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#a1123)

- Maternity proof required…Please review
         [Maternity proof required…Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#a1100)

- Medical certificate required…Please review
         [Medical certificate required…Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#medicalcert)

- MN05 active claim - Actuals may be required
         [MN05 active claim - Actuals may be required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#mn05)

- Monies on separation - fact finding required
         [Monies on separation - fact finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#moniesonsep)

- No interruption in earnings
         [No interruption in earnings](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#noIofE)

- No PHS found in the QP
         [No PHS found in the QP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#nophs)

- Overlapping best weeks - Actuals required
         [Overlapping best weeks - Actuals required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#overlapping)

- Parental benefits - minor attached claimant
         [Parental benefits - minor attached claimant](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#ParMinor1102)

- Parental start week is greater than BPC - Please review
         [Parental start week is greater than BPC - Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#a1090)

- PHS in QP but no automated actual created
         [PHS in QP but no automated actual created](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#phsqp)

- Possible remaining weeks payable
         [Possible remaining weeks payable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#remainingpayable)

- Postdate with earning in week 1 - transmit a M175 type A if required
         [Postdate with earning in week 1 - transmit a M175 type A if required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#postdate_ewk1_m175)

- Proof of birth or of adoption / placement required…Please review
         [Proof of birth or of adoption / placement required…Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#parentaladoption)

- PSL start date after LDP - Please review
         [PSL start date after LDP - Please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#psl)

- Qualifying hours < 600 - May qualify for special benefits
         [Qualifying hours < 600 - May qualify for special benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#QPHrsless600)

- Recovery week is coded with a maternity or parental claim, please review
         [Recovery week is coded with a maternity or parental claim, please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#a1028)

- Recovery week is coded with a regular claim, please review
         [Recovery week is coded with a regular claim, please review](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#invalidRecvCT2)

- Recovery week required
         [Recovery week required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#recoveryweek)

- Re-qualifies as fishing claim type
         [Re-qualifies as fishing claim type](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#requalifies)

- ROE - Record of employment is in error - [serial number]
         [ROE - Record of employment is in error - [serial number]](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#roeErr)

- Self-employment agreement status is Termination. Please confirm eligibility
         [Self-employment agreement status is Termination. Please confirm eligibility](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#seagreement)

- Sickness claim - BPC within the maternity window
         [Sickness claim - BPC within the maternity window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#sicknessclaim)

- Subsequent BPC - Earnings or ROE after LDW
         [Subsequent BPC - Earnings or ROE after LDW](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#subsquentbpc)

- Voluntary leaving/misconduct in the qualifying period, record of employments are overlapping - Actuals may be required
         [Voluntary leaving/misconduct in the qualifying period, record of employments are overlapping - Actuals may be required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#voluntaryleaving)

- VBW < Divisor - insurable earnings credit
         [VBW < Divisor - insurable earnings credit](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#vbw_divisor_insurable_earnings_credit)

**Level 1**

**Actual date of birth or expected date of birth is coded - Is the external maternity window start week required? (1041)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The CT is regular or sickness.

- The Special Benefits section of the Calculation Result screen displays a maternity start and end week. These dates are the maternity window.

- The External maternity start week field is not completed on the Annex - Special Benefits screen in SSO.

- The BPC falls in the period between the maternity start week minus 3 and the maternity end week + 1.

The claim is automatically converted to maternity benefits when all of the following conditions apply:

- a maternity window is present;

- maternity benefits can be paid;

- claimant’s reports are processed for a week in the maternity window.

If the client is entitled to a benefit type (BT) other than maternity during the calculated maternity window or the payment of maternity benefits must be prevented during that window, in SSO, the officer must enter a date in the External maternity start week field to override the calculated maternity window.

If the client is not entitled to a BT other than maternity during the calculated maternity window or the payment of maternity benefits does not need to be prevented during that window, a date is not required in the External maternity start week field in SSO. The officer accepts this message and continues with the calculation of the claim.

**What you need to do**

- Determine if the issue of an external maternity start date has been reviewed:

- If no, refer to Determining if external maternity dates are required on an initial claim .
             [Determining if external maternity dates are required on an initial claim](/en/procedure/task/determining_emdr.shtml)

- If yes, go to step 2.

- Determine if a date is required in the External maternity start week field:

- If no, accept this message and go to step 3.

- If yes, refer to Modifying the maternity information on the Annex - Special Benefits screen in SSO .
             [Modifying the maternity information on the Annex - Special Benefits screen in SSO](/en/procedure/task/modifying_mat_sb_ssa.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Actuals not automated (1124)**

**What you need to know**

SSO displays this message when all of the following conditions are met.

- There is a previous claim which falls in the qualifying period (QP).

- The client declared $0.00 earnings for a week in the QP.

- The ROE pay period detail prevents $0.00 from being entered.

- The calculation determines that there are enough hours to establish the claim.

- The benefit rate determined is less than the maximum benefit rate excluding the family supplement.

The system looks at the pay history of prior claims. If the client has received EI benefits for a week and has declared $0.00 in earnings, the system tries to enter this $0.00 amount for the week into the Employment History File .

The message will include the serial number of the affected ROE.

**What you need to do**

- Accept this message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Allocation rescinded - Please review (1140)**

**What you need to know**

SSO displays this message when both of the following conditions are met:

- An established claim is recalculated.

- An allocation (type C, G, P, Q, S, V) is being rescinded.

If the calculation is accepted and this message is shown, SSO creates an M107 - Additional Claim Data (M107) transaction and fills the Original type field with X - Rescind to remove the allocation.

The allocation must be reviewed to ensure that it should in fact be rescinded.

If the allocation must be rescinded, the officer accepts this message and continues with the calculation of the claim.

If the allocation must remain on the claim, the officer, when reviewing and inputting the calculation, must remember to delete the M107 or modify it to ensure the allocation remains on the claim. The officer then accepts this message and continues with the calculation of the claim.

**What you need to do**

- Determine if the allocation needs to be rescinded or if it should remain on the claim:

- If the allocation should remain on the claim, go to step 2.

- If the allocation should be rescinded, go to step 3.

- When reviewing and inputting the calculation, remember to delete or modify the M107 - Additional Claim Data (M107) transaction to ensure the allocation remains on the claim.

- Accept the message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Best Weeks - Actuals required (1141)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The calculation determines that there are enough hours to establish the claim including special benefit claims with a disentitlement to regular benefits.

- The benefit rate determined excluding any family supplement is less than the maximum benefit rate.

- The Best weeks field on the SSO Application Form screen indicates Yes .

- The variable best weeks (VBW) information is not in the Employment History File .

- One of the following conditions applies:

- The ROE pay period type is not calendar weekly (Sunday start) and the period of employment is greater than the divisor.

- The ROE pay period type is calendar weekly, block 15C is not completed and the period of employment is greater than the divisor.

- The ROE pay period type is calendar weekly, block 15C is completed but does not cover the full period of employment (up to the maximum 53 weeks).

The benefit rate is calculated based on the highest weeks of earnings during the QP . The number of weeks used is based on the regional divisor in effect for the economic region of the client’s normal place of residence as of the date that the benefit period (BP) starts. The range for the number of weeks used is from 14 to 22.
       [QP](/en/procedure/generic/knowledge.shtml#Qualifying_period) 
       [regional divisor](/en/procedure/generic/knowledge.shtml#divisor)

You must ensure that the VBW information in the Employment History File of the associated ROE is the most current information received from the client. This message continues to display even after the information has been entered into the Employment History File.

The ROE is the most valid source of information for VBW. The other sources of information are the pay history of a prior claim and the details provided by the client. The order of importance of the 3 sources of information is as follows:

- ROE

- pay history of a prior claim

- VBW information provided by the client

VBW information provided by the client is submitted on the Variable Best Weeks electronic questionnaire. The client may submit a questionnaire by telephone or by paper. The telephone and paper information is copied into a questionnaire in NWS. VBW information provided by the client is accepted if the following conditions are met:

- The information appears reasonable.

- The information is not contradicted by an ROE or shown as a NIL week on the Pay History Summary (PHS).

- The VBW fall during the period of employment covered by an ROE.

If clients provide conclusive proof via pay stubs that a week that they declare is a variable best week and the ROE shows contradicting information in that week (e.g. the ROE shows $0.00 earnings in that week), you must fact-find with the employer to correct the ROE.

If clients provide conclusive proof via pay stubs that a week that they declare is a variable best week and $0.00 earnings were declared on a prior claim, enter the week as a variable best week if the ROE is on file. If the ROE is not on file, complete a referral to Integrity for possible undeclared earnings. (If an ROE is on file, undeclared earnings will be caught in a post-audit.)
       [referral to Integrity](/en/procedure/activity/referal_integrity.shtml)

**What you need to do**

- In NWS, select Systems - View Questionnaire .

- If there is no Best weeks questionnaire, go to step 2.

- If there is a Best weeks questionnaire, select the most recently completed questionnaire attached to the current Web Application and go to step 4.

- Determine if the VBW information is detailed on an SROC or Action Item (AI) WI (referred to as the “questionnaire” in the following steps):

- If no, go to step 3.

- If yes, go to step 4.

- Select the VBW Details section of the Web application (referred to as the questionnaire in the following steps) and determine if the client provided VBW information:

- If yes, go to step 4.

- If no, go to step 16.

- Review the questionnaire to determine each of the following:

- the number of employers listed for each variable best week amount entered

- the calendar weeks listed.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0888.dita)

- In RCM, determine if there is an ROE from the employer for each calendar week listed:

- If yes, go to step 6.

- If no, go to step 13.

- Determine if the EHF box is displayed beside the ROE:

- If yes, select the box to open the Employment History File and go to step 7.

- If no, refer to Correcting an ROE before proceeding.
             [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- In the Employment History File, for the week being entered, determine if $0.00 is displayed:

- If no, go to step 8.

- If yes, go to step 11.

- Determine if the amount provided on the questionnaire is equal to the amount in the corresponding w/c:

- If no, go to step 9.

- If yes, go to step 11.

- In the Week Code - Earnings field of the corresponding calendar week, enter the amount provided on the questionnaire:

- If there is no exclamation mark, go to step 11.

- If there is an exclamation mark, do the following:

- Reason for actuals: Select Best Weeks .

- Select Validate .

- If the exclamation mark is still displayed, go to step 10.

- If the exclamation mark is no longer displayed, go to step 11.

- Correct the Employment History File error using the table below:

```text
| Error Message | Action required |

| The ROE Pay Period is NIL in 15C. Actuals may not be entered. | Remove the VBW entry. |

| The Earnings for Pay Period (number) cannot be 0.00 because no details have been provided in 15C on the ROE. | - Verify that $0.00 has not been entered in error. - Clear all amounts entered and enter the correct amounts. |

| The total actual calculated earning for ROE (xx) does not match the Total Earnings reported on the ROE 15B (xx). | Determine if removing the lowest VBW entry resolves the error: - If the error is resolved, clear all amounts entered for the pay period and enter all VBW except the lowest entry. - If the error is not resolved, clear all amounts entered and enter the VBW for all pay periods except the one creating the error. |

| The total hours entered (xx) is greater than the total hours reported (xx) on the ROE. | - Verify that amounts have not been entered in the Hours field in error. - Clear all amounts entered and enter the correct amounts. |

| Hours cannot exceed 24 hours per day. The value must be between 0.00 and (xx). | - Verify that amounts have not been entered in the Hours field in error. - Clear all amounts entered and enter the correct amounts. |

| The Earnings must be in the range 0.00 to 99999999.99. | - Enter the amount in the correct format. |

| The Earnings for the First Pay Period cannot be 0 as it contains the First Day Worked. The Hours for the First Pay Period cannot be 0 as it contains the First Day Worked. | - Verify that $0.00 has not been entered in error. - Clear all amounts entered and enter the correct amounts. |

| The total Earnings for Pay Period (xx) (xx) does not equal the earnings reported in 15C on the ROE (xx). They must be equal. | Determine if removing the lowest VBW entry resolves the error: - If the error is resolved, clear all amounts entered for the pay period and enter all the VBW except the lowest entry. - If the error is not resolved, clear all amounts entered and enter the VBW for all pay periods except the one creating the error. |

| The Earnings for the Final Pay Period cannot be 0 as it contains the Last Day Paid. The Hours for the Final Pay Period cannot be 0 as it contains the Last Day Paid. | - Verify that $0.00 has not been entered in error. - Clear all amounts entered and enter the correct amounts. |
```

- If the entry remains flagged with an exclamation mark, repeat step 10.

- If the entry is no longer flagged with an exclamation mark, go to step 11.

- Determine if there are other weeks to be entered for this ROE:

- If yes, return to step 7 to enter the next variable best week.

- If no, go to step 12.

- Determine if entries were made in the Employment History File of the ROE :

- If no, exit the Employment History File and go to step 15.

- If yes, do the following:

- If the Reason for Actuals field is blank, select Best Weeks .

- If Validate is greyed out, select Save .

- If Validate is not greyed out, select Validate and Save .

- Determine if there are VBW from another employer to be entered:

- If yes, return to step 5 for the next employer.

- If no, go to step 14.

- Determine if any entries were made to the Employment History File of any ROE:

- If yes, go to step 15.

- If no, go to step 16.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**BPC could possibly be postdated - Please review (1137)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The CT is special benefits for the self-employed.

- The Sunday of the BPC week falls within the month of December.

- The SE earnings in the QP are less than the minimum required earnings threshold (BPNE 3).
         [QP](/en/procedure/generic/knowledge.shtml#Qualifying_period) 
         [minimum required earnings threshold](https://www.canada.ca/en/services/benefits/ei/ei-self-employed-workers/eligibility.shtml)

The QP is the calendar year before the year of the BPC week. A client applying in the month of December may not have the required earnings in the QP to qualify for SE benefits; however, by postdating the BPC week up to 4 weeks, the client might have the earnings required to qualify.

**What you need to do**

- Determine if fact-finding has already occurred to obtain self-employment earnings information for the year in which the application was filed:

- If no, fact-find with the client to obtain the self-employment earnings amount for the calendar year in which the year of application falls and go to step 2.
             [fact-find](/en/procedure/task/fact_find.shtml)

- If yes, go to step 4.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 3.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 4.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Calculation .

- Comments: Type “Verification of self-employment earnings in the qualifying period.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
             [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client has the minimum required earnings in the calendar year in which December of the year of the application falls:

- If yes, go to step 5.

- If no, go to step 9.

- In SSO, on the Coding Requirements screen, complete the following field:

- Subsequent or manual BPC: Select the Sunday of the first full week of January of the year following the year of application.

- In SSO, on the Application Form screen, complete the following field:

- In the Self-employed details section, complete the following fields:

- Benefit type: Select the BT if not already displayed.

- Estimated Earnings: Enter the amount of estimated earnings the client has provided.

- CRA status: Select Not assessed .

- Select the Next .

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Create and send the N-70-00-00 letter in ACS with the following components and attributes selected:

- SE benefits - BPNE 3/4/8, D73/D74, estimated earnings used, recalc. with actual earnings, excluded ROE (VL and dismissal) (3871): Select Claim is BPNE 3 or Claim is BPNE 3 (with violation) as appropriate.

- Amount of self-employment earnings needed (3894): Enter the amount required.

- Start of qualifying period (4289): Enter the first day of the calendar year before the BPC. (e.g. 01-01-2013 if the BPC date is August 3, 2014.)

- End date of the qualifying period (4291): Enter the last day of the calendar year before the BPC (e.g. 31-12-2013 if the BPC date is August 3, 2014.)

- Amount in self-employment earnings hld (3896): Enter the amount of earnings as displayed on the Calculation Result screen.

- Accept the message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**BPC is after the Caregiver window end date – Please review (1143)**

What you need to know

SSO displays this message when all of the following conditions are met:

- The CT is family caregiver.

- The calculation determines that there are enough hours to establish the claim.

- The Calculation Result screen displays a family caregiver window (FCW) start and end week. These dates are the FCW.

- The BPC is after than the FCW end week.

When a claim is established for family caregiver benefits after the FCW, family caregiver benefits are not payable.

If the calculation is accepted with this message, SSO creates an M161 - Disqualifications/Disentitlements (M161) transaction with an indefinite 61 - Family caregiver for children or adults - Does not meet entitlement conditions disentitlement (D61) from the BPC.

If the client did not apply in a timely manner, the officer determines if an antedate is applicable.

A record of decision (ROD) must be on file when a client is disentitled from special benefits unless the client is disentitled for being minor attached. If a ROD is required but not on file, the officer must return to the previous task that generated the condition to determine if the disentitlement is correct.

**What you need to do**

- Determine if the client applied for benefits in a timely manner:

- If no, go to step 2.

- If yes, accept this message and go to step 6.

- Determine if the client requested an antedate or if there is an implied antedate:

- If yes, go to step 3.

- If no, accept this message and go to step 6.

- Determine if the antedate has been adjudicated:

- If yes, go to step 4.

- If no, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Determine if the antedate has been allowed:

- If yes, go to step 5.

- If no, accept this message and go to step 6.

- Determine if the BPC on the Calculation Result screen displays the earlier date:

- If yes, accept this message and go to step 6.

- If no, refer to Entering an antedate in SSO .
             [Entering an antedate in SSO](/en/procedure/task/calc_calculating/input_antedate.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**BPC is greater than the current variable entrance requirement range - Verify the calculation result (1068)**

**What you need to know**

SSO displays this message when the variable entrance requirement (VER) information for the BPC is not yet available. Without the VER information, which is based on the regional rate of unemployment of the economic region, the claim cannot be calculated. The officer must move the calculation WI to Pending until the VER information becomes available.

**What you need to do**

- In NWS, move the calculation WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Unable to calculate until the VER information for this BPC is available.”

- Bring forward date: Enter the first business day of the following week.

- When the WI moves to the current workload, go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

**BPC is prior to caregiver start date window. Please review (1146)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The calculation determines that a claim can be established.

- The CT is family caregiver.

- The Calculation Result screen displays a FCW start and end week.

- The BPC is earlier than the FCW.

If the calculation is accepted with this message, SSO creates an M161 transaction with a definite 61 - Family caregiver for children or adults - does not meet entitlement conditions disentitlement (D61) from the BPC to day 5 of the week before the start of the FCW.

Postdating the claim may entitle the client to family caregiver benefits. When reviewing the BPC, the officer must remember that a postdate may be required. The officer then accepts this message and continues with the calculation of the claim.

**What you need to do**

- When reviewing the BPC, remember that a postdate to the first week the client qualifies to establish a claim for family caregiver benefits should be considered. Accept this message.

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**BPC not within the compassionate care window (1109)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The calculation determines that there are enough hours to establish the claim.

- The CT is compassionate care.

- The Special Benefits section of the SSO Calculation Result screen displays a compassionate care window (CCW) start and end week.

- The BPC is outside the CCW.

If the calculation is accepted with this message, SSO creates an M161 transaction with an indefinite 51 - Does not meet compassionate care entitlement conditions disentitlement (D51) from the BPC and inputs a status code 4 on the M112 - Compassionate Care entitlement (M112) transaction.

This message, when applicable, is displayed even if compassionate care proof is indicated as outstanding on the Registration screen. When compassionate care proof is outstanding, the officer must not input the date in the Start week of compassionate care window field of the Annex - Special Benefits screen as this would incorrectly impose a D51.

If the BPC is before the CCW, postdating the claim may entitle the client to CCB. When reviewing the BPC, the officer must remember that a postdate may be required. The officer then accepts this message and continues with the calculation of the claim.

If the client did not apply in a timely manner, the officer determines if an antedate is applicable.

**What you need to do**

- Determine if a record of decision (ROD) indicates compassionate care proof is outstanding:

- If yes, go to step 2.

- If no, go to step 4.

- In SSO, on the Annex - Special Benefits screen, remove the date indicated in the Start week of compassionate care window field.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Determine if the BPC is after the CCW:

- If yes, go to step 5.

- If no, go to step 10.

- Determine if the client applied for benefits in a timely manner:

- If no, go to step 6.

- If yes, accept the message and go to step 11.

- Determine if the client requested an antedate or if there is an implied antedate:

- If yes, go to step 7.

- If no, accept the message and go to step 11.

- Determine if the antedate has been adjudicated:

- If yes, go to step 8.

- If no, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Determine if the antedate has been allowed:

- If yes, go to step 9.

- If no, accept the message and go to step 11.

- Determine if the BPC on the Calculation Result screen displays the earlier date:

- If yes, accept the message and go to step 11.

- If no, refer to Entering an antedate in SSO .
             [Entering an antedate in SSO](/en/procedure/task/calc_calculating/input_antedate.shtml)

- When reviewing the BPC, remember to consider a postdate to the first week the client qualifies to establish a claim for CCB. Accept this message.

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**BPC not within the parental window (1099)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The calculation determines that there are enough hours to establish the claim including special benefit claims with a disentitlement to regular benefits.

- The CT is parental.

- The BPC is outside the parental window (PW).

If the calculation is accepted with this message, SSO creates an M161 transaction with an indefinite 35 - Parental benefits - qualifying conditions not met disentitlement (D35) from the BPC.

If the BPC is before the PW, postdating the claim may entitle the client to parental benefits. When reviewing the BPC, the officer must remember that a postdate may be required. Refer to the Postdate Policy for further information. Once the BPC is determined, the officer then accepts this message and continues with the calculation of the claim.
       [Postdate Policy](/en/policy/nationalpolicy/national_policy_on_postdates.shtml)

If the client did not apply in a timely manner, the officer determines if an antedate is applicable.

**What you need to do**

- Determine if the BPC is before the PW:

- If no, go to step 2.

- If yes, go to step 9.

- Determine if the issue of extending the PW has been reviewed:

- If yes, go to step 3.

- If no, go to Determining if an extension of the parental window is required during calculation of a claim .
             [Determining if an extension of the parental window is required during calculation of a claim](/en/procedure/task/determining_epw_cc.shtml)

- Determine if the extension of the PW has been input:

- If yes, go to step 4.

- If no, refer to Extending the benefit period and parental window due to hospitalization of the child in SSO .
             [Extending the benefit period and parental window due to hospitalization of the child in SSO](/en/procedure/task/extending_bp_par_ssa.shtml)

- Determine if the client applied for benefits in a timely manner:

- If no, go to step 5.

- If yes, accept this message and go to step 10.

- Determine if the client requested an antedate or if there is an implied antedate:

- If yes, go to step 6.

- If no, accept this message and go to step 10.

- Determine if the antedate has been adjudicated:

- If yes, go to step 7.

- If no, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Determine if the antedate has been allowed:

- If yes, go to step 8.

- If no, accept this message and go to step 10.

- Determine if the BPC on the Calculation Result screen displays the earlier date:

- If yes, go to step 10.

- If no, refer to Entering an antedate in SSO .
             [Entering an antedate in SSO](/en/procedure/task/calc_calculating/input_antedate.shtml)

- When reviewing the BPC, remember that a postdate to the first week the client qualifies to establish a claim for parental benefits should be considered. Refer to the Postdate Policy for further information. Accept this message.
         [Postdate Policy](/en/policy/nationalpolicy/national_policy_on_postdates.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Caregiver benefits - Medical proof required…Please review (1142)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The calculation determines that the claim can be established.

- The CT is family caregiver.

- The Medical proof field in the Family caregiver section of the Annex - Special Benefits screen indicates No .

When medical proof is not provided, the Medical proof field in the Family caregiver section of the Annex - Special Benefits screen indicates No . In addition to the message Caregiver benefits requested - medical proof required , the SSO Calculation Result screen also indicates that an indefinite 63 - Family caregiver for children or adults - no medical proof disentitlement (D63) is imposed from the BPC.

A ROD must be on file when a client is disentitled from special benefits unless the client is disentitled for being minor attached. If a ROD is required but not on file, the officer must return to the previous task that generated the condition to determine if the disentitlement is correct.

**What you need to do**

- Determine if a ROD indicates the medical proof is outstanding:

- If no, a disentitlement may be imposed in error. Go to step 2.

- If yes, accept the message and go to Next procedure .
             [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

- In SSO, in the Outstanding information section of the Registration screen, do the following:

- Medical certificate - Due date: Delete the due date of the calculation WI.

- Select Save .

- Refer to Determining if a medical certificate is acceptable — Family caregiver benefits .
         [Determining if a medical certificate is acceptable — Family caregiver benefits](/en/procedure/task/determining_pcic_med_cert.shtml)

**Caregiver benefits - Minor attached (1144)**

**What you need to know**

SSO displays this message when both of the following conditions are met:

- The client is minor attached .
         [minor attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

- The CT is family caregiver.

In order to qualify for family caregiver benefits, a client must have at least 600 hours in the QP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0889.dita) 

**What you need to do**

- Accept the message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Claim is postdated - Verify the interruption of earnings (1138)**

**What you need to know**

SSO displays the message when all of the following conditions are met:

- The CT is self-employed special benefits.

- The calculation determines that there are enough earnings to establish the claim.

- The claim has been postdated to a week after the week of filing.

The BPC for self-employment (SE), Part VII claims begins in the week the client files. The client states on the online application that there has been an interruption of earnings (I of E) in the week of filing.
       [Part VII claims](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/FullText.html#h-44)

A claim for benefits may be postdated.

Example 1

- The client files in the last week of December.

- The client does not have sufficient earnings in the preceding calendar year to establish a claim.

- The client has sufficient earnings in the current year to qualify in the following calendar year.

- Therefore, you can postdate the claim to the first full week in January.

Example 2

- It is determined during fact-finding that the client had a full work week in the week of filing. (The client may have worked to Friday, September 13, 2013 and filed for benefits on Saturday, September 14, 2013.)

- The I of E occurs in the week following the week of filing.

- Therefore, the claim is postdated to the week of September 15, 2013.

The client must have an I of E in the week of the BPC to establish a claim for benefits. Because the client’s statement regarding the I of E on the application applies only to the week of filing, you must obtain the client’s statement and confirmation of the I of E in the week of the BPC.

**What you need to do**

- Determine if you have information confirming the client had an I of E in the BPC week:

- If no, fact-find with the client and go to step 2.
             [fact-find](/en/procedure/task/fact_find.shtml)

- If yes, go to step 4.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 3.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 5.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Issue: Select Calculation .

- Comments: Type “verification of interruption in earnings.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
             [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client had an I of E on the postdated BPC week.

- If no, go to step 5.

- If yes, accept this message and go to step 7.

- In SSO, on the Coding Requirements screen, complete the following field:

- Subsequent or manual BPC: Type the Sunday of the week on which the application was submitted.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Claimant did not qualify at Subsequent/Manual BPC. Claim was postdated (1155)**

**What you need to know**

SSO displays the message when all of the following conditions are met:

- The BPC is coded in the Subsequent or manual BPC field.

- The client does not qualify at the BPC coded in the Subsequent or manual BPC field.

- The client qualifies if the BPC is postdated.

- UIC returns a calculation result with the postdated BPC.

If a subsequent or manual BPC results in a BPNE claim, the BPC is established in the week following the interruption of earnings (I of E) in the following situations:

- the client requires the insured hours to qualify for benefits;

- the client requires the insured hours to be entitled to special benefits;

- the week of the I of E is a full work week;

- the earnings in the week of the I of E are equal to or greater than the benefit rate; or

- the client is entitled to maximum special benefits.

**What you need to do**

- Accept the message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Compassionate care benefit not approved (1110)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The calculation determines that there are enough hours to establish the claim (including special benefit claims) with a disentitlement to regular benefits.

- The CT is compassionate care.

- The starting week of the CCW is not indicated on the special benefits annex in SSO.

When a claim is calculated for CCB and an acceptable medical certificate has been received as CCB proof, a start week must be indicated in the Start week of compassionate care window field of the Annex - Special Benefits screen.

This message, when applicable, is displayed even if compassionate care proof is indicated as outstanding on the Registration screen. When proof is outstanding, the officer must not input the date in the Start week of compassionate care window field of the Annex - Special Benefits screen as this would incorrectly impose a D51.

A ROD must be on file when a client is disentitled from special benefits unless the client is disentitled for being minor attached. If a ROD is required but not on file, the officer must return to the previous task that generated the condition to determine if the disentitlement is correct.

**What you need to do**

- Determine if a ROD indicates compassionate care proof is outstanding:

- If yes, accept the message and go to step 2.

- If no, return to Determining if a medical certificate is acceptable: CCB — Initial Claims .
             [Determining if a medical certificate is acceptable: CCB — Initial Claims](/en/procedure/task/calc_determining/medical_cert_ccb.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Compassionate care – Minor attached (1107)**

**What you need to know**

SSO displays the message when all of the following conditions are met:

- The CT is compassionate care.

- The client is minor attached .
         [minor attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

In order to qualify for CCB, a client must have at least 600 hours in the QP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0890.dita) 

**What you need to do**

- Accept the message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Compassionate care proof required …Please review (1106)**

What you need to know

SSO displays this message when the compassionate care proof has been noted as outstanding on the Outstanding information section of the Registration screen.

When the client applying for CCB does not provide compassionate care proof, the officer is directed to note it as outstanding information. In addition to the message Compassionate care benefits requested - medical proof required , the SSO Calculation Result screen also shows in the Disqualification / Disentitlement field that an indefinite 53 - Compassionate care benefits - no medical proof disentitlement (D53) is imposed from BPC.

A ROD must be on file when a client is disentitled from special benefits unless the client is disentitled for being minor attached. If a ROD is required but not on file, the officer must return to the previous task that generated the condition to determine if the disentitlement is correct.

**What you need to do**

- Determine if a ROD indicates compassionate care proof is outstanding:

- If no, a disentitlement can be imposed in error. Go to step 2.

- If yes, accept the message and go to Next procedure .
             [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

- In SSO, in the Outstanding information section of the Registration screen, do the following:

- Compassionate care - Due date: Delete the due date of the calculation WI.

- Select Save .

- Refer to Determining if a medical certificate is acceptable: CCB — Initial Claims .
         [Determining if a medical certificate is acceptable: CCB — Initial Claims](/en/procedure/task/calc_determining/medical_cert_ccb.shtml)

**CRA status value is equal to Deceased - Please review (1136)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The CT is self-employed special benefits.

- The calculation determines that the claim can be established.

- The CRA status value is 8 (deceased).

Prior to finalizing the claim, the officer reviews the claim to apply the appropriate procedures for a deceased client.

**What you need to do**

- Refer to Deceased client .
         [Deceased client](/en/procedure/activity/deseased_client.shtml)

**Credit 300 Insurable Hours (1157)**

**What you need to know**

SSO displays this message on initial claims for regular benefits with a BPC between w/cs 2258 and 2309.

Effective September 27, 2020, a temporary measure was implemented to compensate clients for hours of employment that they could have worked if not for COVID-19-related shutdowns.

A one-time credit of 300 hours is automatically applied to all claims that meet the criteria, regardless of whether:

- the client qualifies for benefits;

- the claim is BPNE;

- the client has more than 1820 hours.

UIC generates warning message 1157 - credit 300 insurable hours on all claims that receive the credit of insurable hours. It appears on the Calculation Results screen.

**What you need to do**

- Accept this message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Credit 480 Insurable Hours (1158)**

**What you need to know**

SSO displays this message on initial claims for special benefits with a BPC between w/cs 2258 and 2309.

Effective September 27, 2020, a temporary measure was implemented to compensate clients for hours of employment that they could have worked if not for COVID-19-related shutdowns.

A one-time credit of 480 hours is automatically applied to all claims that meet the criteria, regardless of whether:

- the client qualifies for benefits;

- the claim is BPNE;

- the client has more than 1820 hours.

UIC generates warning message 1158 - credit 480 insurable hours on all claims that receive the credit of insurable hours. It appears on the Calculation Results screen.

**What you need to do**

Accept this message and go to Next procedure .
       [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**D57 may be required (1120)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The tax province is Quebec.

- The calculation result indicates that the claim can be established.

- The Expected date of birth or Actual date of birth field is completed on the Annex - Special Benefits screen in SSO.

When SSO determines that a claim can be established for a client who resides in Quebec, the officer must determine if the client is entitled to QPIP.

When determining if a claim is ready to calculate, the officer must determine if the client is entitled to QPIP . If the issue has already been reviewed, the officer accepts this message and continues with the calculation of the claim.
       [determine if the client is entitled to QPIP](/en/procedure/task/determining_ccc_wpwpslqpipp.shtml)

**What you need to do**

- Determine if the client’s entitlement to QPIP has already been reviewed:

- If it has not been reviewed, refer to Determining if benefits are paid or payable by QPIP .
             [Determining if benefits are paid or payable by QPIP](/en/procedure/task/reviewing_bpp_qpip.shtml)

- If it has been reviewed, accept the message and go to Next procedure .
             [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Daily average total >ROE total - Manually adjust the EHF (1121)**

**What you need to know**

SSO displays this message when the total hours in the Employment History File are more than the hours in block 15A: Hours of the ROE.

The Employment History File displays the average hours as determined from block 15A: Hours of the ROE and the number of days of work that are represented by the ROE.

UIC determines the average hours as follows:

- Any $0.00 pay periods in block 15C: Pay period details are not considered when determining the days of work.

- Based on the hours in block 15A: Hours and the number of days of work, the average number of daily hours is calculated, rounded to 2 decimals and displayed in the Employment History File . Because of the rounding, the total hours when adding up the daily average may be greater than the total in 15A.

This message is displayed for ROEs that may impact calculation.

**What you need to do**

- Total the hours for each week in the Employment History File .

- Subtract the amount in block 15A: Hours from the total Employment History File hours.

- Subtract the result determined in step 2 from the earliest week shown in the Employment History File .

- Enter the amount determined in step 3 into the earliest week or weeks shown in the Employment History File .

- Reason for actuals: Select Actuals provided by claimant . (This selection is an administrative workaround.)

- Select Validate and Save .

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

**Deferred maternity and waiting period waived – Please review (1040)**

**What you need to know**

SSO displays this message when both of the following conditions are met:

- The Special Benefits section of the Calculation Result screen displays a maternity start and end week. These dates are the maternity window.

- The External maternity start week field is completed on the SSO Annex - Special Benefits .

- The WP is waived.

The claim is automatically converted to maternity benefits when all of the following conditions apply:

- a maternity window is present;

- maternity benefits can be paid;

- claimant’s reports are processed for a week in the maternity window.

If the client is entitled to a BT other than maternity during the calculated maternity window or the payment of maternity benefits must be prevented during that window, in SSO, the officer must enter a date in the External maternity start week field to override the calculated maternity window.

If the client is not entitled to a BT other than maternity during the calculated maternity window or the payment of maternity benefits does not need to be prevented during that window, a date is not required in the External maternity start week field in SSO. The officer accepts this message and continues with the calculation of the claim.

Although a client may meet the entitlement conditions to waive the waiting period (WP) , she may choose to serve it. This can occur when the employer pays a SUB top-up during the WP, or the other parent will be collecting parental benefits and wants to defer serving the WP.
       [waiting period (WP)](/en/procedure/generic/knowledge.shtml)

**What you need to do**

- Determine if on the Annex - Special Benefits , the date in the External maternity start week field is correct:

- If yes, go to step 2.

- If no, refer to Modifying the maternity information on the annex for special benefits in SSO .
             [Modifying the maternity information on the annex for special benefits in SSO](/en/procedure/task/modifying_mat_sb_ssa.shtml)

- Determine if the WP should be waived:

- If no, go to step 3.

- If yes, accept this message and go to step 5.

- In SSO, on the Determination of Earnings screen, complete the following field:

- Waiting period waiver: Select 1 - No .

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Disentitlement/disqualification is imposed - May qualify for special benefits (1053 & 2080)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The CT is regular benefits.

- The calculation result is not BPNE.

- The client does not qualify for regular benefits.

- The client may qualify for special benefits.

When this message appears, the Disqualifications / Disentitlements section of the Calculation Result screen also shows one of the following disqualifications or disentitlements related to a reason for separation (RFS):

- 10 - Dismissal - misconduct proven (D10)

- 11 - Voluntary leaving - just cause not proven (D11)

- 42 - Suspension from employment (D42)

- 43 - Leave of absence (D43)

- 44 - Anticipated loss of employment (D44)

When this occurs, the officer calculating the claim will review each disentitled or disqualified ROE when following the Reviewing the calculation result — Disqualified or disentitled ROE task.
       [Reviewing the calculation result — Disqualified or disentitled ROE](/en/procedure/task/calc_reviewing/review_calc_disqual_exclus.shtml)

**What you need to do**

- On the calculation worksheet, note that when reviewing the calculation result, each disentitled or disqualified ROE must be reviewed.

- Accept this message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Does not qualify on earlier date (1133)**

**What you need to know**

SSO displays this message when the client does not qualify on the earlier date and the following conditions are met:

- The claim is not BPNE 2 (last record of employment missing).

- The Antedate to field on the SSO Application Form screen is completed.

- The client does not qualify at the requested antedate.

In order to allow an antedate, the client must qualify at the requested antedate.

When the client does not qualify at the antedate, the officer determines if the client qualifies on a date falling between the week requested for the antedate and the week of filing. Once the officer determines if the client qualifies at a later date, the officer creates an SROC for the officer adjudicating the antedate and ensures the antedate issue is adjudicated.

**What you need to do**

- Determine if the client qualifies for benefits in a week falling between the date in the Antedate to field and the week of filing:

- If yes, determine the earliest week in which the client qualifies and go to step 2.

- If no, go to step 5.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0891.dita)

- Determine if the earliest week in which the client qualifies is equal to the week of filing:

- If the earliest week in which the client qualifies is not equal to the week of filing, go to step 3.

- If the earliest week in which the client qualifies is equal to the week of filing, go to step 5.

- In NWS, create an SROC as follows:

- Main Issue: Select Antedate .

- Comments: Type “Effective date of antedate.”

- Details: Type “The client does not qualify in the requested week of the antedate but does qualify in the week of [Sunday of the first week following the antedate in which the client qualifies].”

- In SSO, on the Application Form , complete the following field:

- Antedate to: Enter the Sunday of the earliest week in which the client qualifies. Go to step 9 of Calculating a claim in SSO .
             [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- In NWS, create an SROC as follows:

- Main Issue: Select Antedate .

- Comments: Type “Effective date of antedate.”

- Details: Type “The client does not qualify in any week from [requested week of the antedate] to [the week of filing].”

- Remove the date from the Antedate to field on the SSO Application Form screen.

- Determine if there is WI outstanding for the antedate request:

- If there is no outstanding WI for the request, a WI must be created for the issue. Go to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- If there is an outstanding WI for the request, go to Reviewing outstanding WIs related to the calculation of the claim .
             [Reviewing outstanding WIs related to the calculation of the claim](/en/procedure/task/calc_determining/outstandingrelated_wi.shtml)

**Due to extension of qualifying period, additional insurable hours could be required (1093)**

**What you need to know**

- The calculation result includes an extension to the QP.

- An ROE used in the calculation of the claim contains the following:

- A last day for which paid that is after the original QP cut-off date (COD).

- A first day worked that is earlier than the original QP COD.

- Earnings in 15B that were calculated with a period that began after the extended QP COD.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0892.dita) 

**What you need to do**

- On the Calculation Result screen, determine if the benefit rate and the number of weeks of entitlement are at their maximum:

- If no, go to step 2.

- If yes, accept the message and go to step 9.

- Fact-find with the employer to obtain the following information:

- the additional hours

- the earnings

- the first day worked in the earliest pay period and the LDW in the most recent pay period required in the extended QP.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0893.dita)

- Determine if the employer was contacted during fact-finding:

- If the employer was contacted, go to step 5.

- If the employer was not contacted or did not reply to the Z-02-00-00 letter, go to 4.

- Make one attempt to contact the client by telephone to obtain pay period information for the extended QP:

- If you reached the client, go to step 5.

- If you did not reach the client, in ACS, create and print the Q-01-00-00 letter with the following attributes:

- Info required-RE: Antedate/Medical or treatment outside/Mat-Par Direct Deposit/Family Caregiver/Text (2886): Select Specify information required .

- Text - Specify information required (1544): Type
                 [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0894.dita)

- Go to step 9.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Calculation .

- Comments: Type “Additional insurable employment information.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
             [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- In RCM, on the original ROE, do the following:

- Block 10: Enter the day after the LDW in the extended portion of the QP.

- In RCM, enter an interim ROE with the following information:

- Block 4: Enter the employer’s name.

- Block 5: Enter the CRA business number.

- Block 6: Enter the pay period type.

- Block 10: Enter the first day worked in the earliest pay period in the extended QP.

- Block 11: Enter the LDW in the extended portion of the QP.

- Block 12: Enter the end date of the last pay period with earnings in the extended portion of the QP.

- Block 15A: Enter the total insurable hours for the extended portion of the QP.

- Block 15B: Enter the total insurable earnings for the extended portion of the QP.

- Block 16: Select A – Shortage of work .

- Additional Information: Type “Interim ROE created for extended portion of the QP.”

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Earnings in week 1 has changed, report processed. Review and determine if amendment is required (1064)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The claim is being recalculated.

- There was an allocation of earnings coded in the Earnings week 1 field of the previous calculation result.

- The recalculation results in a different amount of earnings for that week.

When earnings are displayed in the Qualifying Conditions - Earnings week 1 field of the Calculation Result screen and the result is accepted, the amount appears in the Earnings week 1 field of the transaction generated by SSO. Once the claim is established, the allocation appears in FTS as an allocation type W - Earnings week 1 for the week of the BPC.

- If the client declares a lower amount of earnings for that week on the claimant’s report, the system uses the amount coded as allocation type W - Earnings week 1 as earnings for that week.

- If the client declares a higher amount of earnings for that week on the claimant’s report, the system uses the higher amount that was declared on the claimant’s report as earnings for that week. The system also updates the allocation type W - Earnings week 1 for that week, to reflect the amount declared on the claimant’s report.

When recalculating a claim that has an allocation type W - Earnings week 1 and the client has submitted a claimant’s report for that week, the officer reviews earnings allocation and the claimant’s report for that week to determine whether the allocation must be modified.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0895.dita) 

**What you need to do**

- Determine if earnings were declared on the claimant’s report for that week:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the earnings declared on the claimant’s report for that week were higher than the amount of earnings indicated in the Earnings week 1 field of the recalculation result:

- If yes, go to step 3.

- If no, go to step 4.

- On the calculation worksheet, note that if SSO generates an earnings allocation to modify the earnings in that week, the allocation must not be input with the recalculation of the claim. The amount declared by the client on the claimant’s reports is the correct amount to be allocated.

- Accept this message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Economic region is incorrect - Please review (1151)**

**What you need to know**

SSO displays this message when one of the following conditions is met:

- The BPC is greater than 1946 and the Economic region – new field is one of the following:

- 03 - Prince Edward Island

- 56 - Yukon

- 57 - Northwest Territories

- 58 - Nunavut

- The BPC is less than 1947 and the Economic region – old field is one of the following:

- 59 - Whitehorse

- 60 - Yukon excluding Whitehorse

- 61 - Yellowknife

- 62 - Northwest Territories excluding Yellowknife

- 63 - Iqaluit

- 64 - Nunavut excluding Iqaluit

- 65 - Charlottetown

- 66 - Prince Edward Island excluding Charlottetown

**What you need to do**

- Review the Economic region – new field and determine if one of the following is displayed:

- 03 - Prince Edward Island

- 56 - Yukon

- 57 - Northwest Territories

- 58 - Nunavut

- If yes, go to step 2.

- If no, go to step 4.

- In the Look up EI Economic Region by Postal Code database, type the residential postal code to determine the economic region.

- If no economic region is found, search the EI Economic Region Search by Municipality or Place Name to determine the economic region. Remember the economic region code found.
             [EI Economic Region Search by Municipality or Place Name](http://srv129.services.gc.ca/eiregions/eng/munic_search.aspx)

- If only one economic region is found, select the economic region name displayed and remember the economic region code.

- If more than one economic region is found, select each economic region name displayed:

- If one economic region has a higher regional rate of unemployment (RRU) than another, remember the economic region code.

- If all economic regions have the same RRU, remember the code of the first economic region displayed.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0896.dita) 
         [Look up EI Economic Region by Postal Code](http://srv129.services.gc.ca/eiregions/eng/postalcode_search.aspx)

- In SSO, on the Name and Address screen, in the Economic region - new field, select the economic region code previously noted.

- Review the Economic region – old field and determine if one of the following is displayed:

- 59 - Whitehorse

- 60 - Yukon excluding Whitehorse

- 61 - Yellowknife

- 62 - Northwest Territories excluding Yellowknife

- 63 - Iqaluit

- 64 - Nunavut excluding Iqaluit

- 65 - Charlottetown

- 66 - Prince Edward Island excluding Charlottetown

- If yes, go to step 5.

- If no, go to step 9.

- In the Look up EI Economic Region by Postal Code database, type the residential postal code to determine the current economic region name. If no economic region is found, search the EI Economic Region Search by Municipality or Place Name to determine the current economic region name.
         [Look up EI Economic Region by Postal Code](http://srv129.services.gc.ca/eiregions/eng/postalcode_search.aspx) 
         [EI Economic Region Search by Municipality or Place Name](http://srv129.services.gc.ca/eiregions/eng/munic_search.aspx)

- Determine the previous economic region name of each current economic region name found in the database:

```text
| Current economic region name | Previous economic region name |

| Whitehorse (59) | Yukon (56) |

| Yukon excluding Whitehorse (60) | Yukon (56) |

| Yellowknife (61) | Northwest Territories (57) |

| Northwest Territories excluding Yellowknife (62) | Northwest Territories (57) |

| Iqaluit (63) | Nunavut (58) |

| Nunavut excluding Iqaluit (64) | Nunavut (58) |

| Charlottetown (65) | Prince Edward Island (03) |

| Prince Edward Island excluding Charlottetown (66) | Prince Edward Island (03) |
```

- If the economic region search by postal code displayed more than one possible economic region, remember the possible previous economic regions. Go to step 7.

- If the economic region search by postal code only displayed one economic region name, remember the previous economic region name. Go to step 8.

- In the Unemployment Rates for the EI Economic Regions database, type the possible previous economic regions to determine the RRU for the week of the BPC.

- If one economic region has a higher RRU than another, remember the economic region code.

- If all economic regions have the same RRU, remember the code of the first economic region displayed.

         [Unemployment Rates for the EI Economic Regions](http://srv129.services.gc.ca/eiregions/eng/rates_hist.aspx)

- In SSO, on the Name and Address screen, in the Economic region - old field, select the economic region code previously noted.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

**EDC coded – Is EXT - MSW required (1134)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The CT is sickness.

- The calculation determines there are enough hours to qualify for special benefits.

- The Special Benefits section of the Calculation Result screen displays a maternity start and end week. These dates are the maternity window.

- The External maternity start week date is blank on the SSO Annex - Special Benefits .

- The maternity start week is earlier than the date at which the client could receive maximum benefit entitlement to sickness benefits.
         [maximum benefit entitlement](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

The claim is automatically converted to maternity benefits when all of the following conditions apply:

- a maternity window is present;

- maternity benefits can be paid;

- claimant’s reports are processed for a week in the maternity window.

If the client is entitled to a BT other than maternity during the calculated maternity window or the payment of maternity benefits must be prevented during that window, in SSO, the officer must enter a date in the External maternity start week field to override the calculated maternity window.

If the client is not entitled to a BT other than maternity during the calculated maternity window or the payment of maternity benefits does not need to be prevented during that window, a date is not required in the External maternity start week field in SSO. The officer accepts this message and continues with the calculation of the claim.

**What you need to do**

- Determine if the issue of an external maternity start date has been reviewed:

- If yes, go to step 2.

- If no, refer to Determining if external maternity dates are required .
             [Determining if external maternity dates are required](/en/procedure/task/determining_emdr.shtml)

- Determine if a date is required in the External maternity start week field:

- If no, accept the message and go to step 3.

- If yes, refer to Modifying the maternity information on the annex for special benefits in SSO .
             [Modifying the maternity information on the annex for special benefits in SSO](/en/procedure/task/modifying_mat_sb_ssa.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Excluded record(s) of employment (1049)**

**What you need to know**

SSO displays this message only when both of the following conditions are met:

- The client qualifies since the disqualifying event.

- The benefit rate and entitlement weeks are less than the maximum.

A disqualifying event occurs if a client is dismissed for misconduct or for voluntarily leaving employment without just cause. If the client works enough hours after a disqualifying event to qualify for benefits, a claim can be established with no disqualification.

When calculating a claim where the client has worked enough hours since the disqualifying event, hours and earnings from the ROE with the disqualifying event are not included in the calculation of either the benefit rate or the entitlement if both of the following conditions apply:

- Block 16: Reason for Separation (RFS) of the ROE has a contentious RFS (E, G, K, or M).

- The Special condition field is blank or is coded as Misconduct Proven or Voluntarily Leaving - No Just Cause .

This ROE is excluded from the claim calculation.

There may be more than one excluded ROE. You must review each ROE with a contentious RFS to ensure all issues have been adjudicated and the Special condition fields are appropriately coded.

**What you need to do**

- In RCM, determine which ROE is excluded from the calculation.

- In NWS, determine if there is a ROD for the adjudication or deferral of the RFS on the excluded ROE:

- If there is a ROD, go to step 3.

- If there is no ROD, refer to Reviewing an outstanding issue with no Adjudication Issue WI.
             [Reviewing an outstanding issue with no Adjudication Issue WI.](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0897.dita)

- In RCM, determine if the entries in the Reason for separation , Special condition and End date (if applicable) fields on the ROE correspond to the decision on the ROD:

- If yes, go to step 4.

- If no, correct the ROE, select Submit and go to step 4.

- Determine if there is another excluded ROE that requires review:

- If yes, return to step 2.

- If no, go to step 5.

- Determine if any changes were made in RCM:

- If yes, go to step 6.

- If no, go to step 7.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Hours added for auto QP ext (1161)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- UIC granted the automatic 28-week QP extension.

- A period of employment on an ROE is greater than one year and overlaps the extended QP.

- UIC used the ROE daily hours average to calculate the missing hours information.

An automatic 28-week QP extension is granted to a client when the following conditions are met:

- The BPC of the claim is between September 27, 2020 (w/c 2258) and September 19, 20221 (w/c 2309).

- The claim was converted from the EI Emergency Response Benefit (EI ERB) or the Canada Emergency Response Benefit (CERB).

- The claim is not for fishing or self-employment (SE) benefits.

When a claim receives this 28-week automatic QP extension and a period of employment on an ROE that is greater than one year overlaps the extended QP, UIC uses the daily average hours on the ROE to add the missing ROE data. This warning message is given only for information purposes and was developed to explain the total insurable hours in the calculation result.

Claims that do not receive this automatic QP extension continue to receive calculation message 1093 - Due to the extension of the QP, Additional insurable hours could be required (if necessary) to advise the officer to obtain additional pay period information.

**What you need to do**

Accept this message and go to Next procedure .
       [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Insufficient ROE earnings in the self-employed QP - Actuals are required (1135)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The calculation determines that the claim can be established.

- The benefit rate excluding the family supplement is less than the maximum.

- The ROE falls within the SE QP.

- The earnings on the ROE and in the Employment History File do not represent all the earnings in the SE QP.

If a client applies and qualifies for benefits for the self-employed (Part VII) , and there are also ROEs with insurable earnings in the QP, the ROE insurable earnings can increase the benefit rate. All the insurable earnings that fall into the self-employed (SE) QP are used to determine the benefit rate.
       [(Part VII)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/FullText.html#h-44)

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0898.dita) 

Earnings are missing for the period from February 12, 2012 to May 5, 2012.

**What you need to do**

- Determine if an attempt has been made to get the additional earnings from the client for the ROE that falls into the SE QP:

- If an attempt has not been made, go to step 2.

- If an attempt has been made, go to step 5.

- Fact-find with the client to obtain the earnings information for the weeks that are not contained on the ROE.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not reply to the N-10-00-00 letter, accept the message and go to step 8.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Calculation .

- Comments: Type “Earnings.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
             [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the additional earnings information has been obtained:

- If the information has been obtained, go to step 6.

- If the information has not been obtained, accept the message and go to step 8.

- Enter the additional earnings into the Employment History File of the ROE.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Insurable earnings increased for minimum benefit rate (1160)**

**What you need to know**

SSO displays this message when a claim is benefiting from the minimum benefit rate measure.

If a benefit rate is below the minimum benefit rate, UIC applies the minimum benefit rate. An officer cannot modify the minimum benefit rate.

A minimum benefit rate applies to all claims in the following periods:

- For claims with a BPC between w/c 2258 and w/c 2309, the minimum benefit rate is $300 for extended parental benefits and $500 for all other BTs.

- For claims with a BPC between w/c 2310 and w/c 2317, the minimum benefit rate is $180 for extended parental benefits and $300 for all other BTs.

A family supplement (FS) is added to the minimum benefit rate amount, if necessary.

UIC generates the new warning message 1160 - Insurable earnings increased for minimum benefit rate on all claims affected by the modified minimum benefit rate. The warning appears on the Calculation Results screen.

**What you need to do**

- Accept this message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Invalid Special Payments - Wage Loss Indemnity (EI Insurable) (2673)**

**What you need to know**

SSO displays this message when the ROE block 19: Special Payments of any ROE in the QP contains an entry in the Wage Loss Indemnity (EI Insurable) section. Although the ROE is not highlighted in red, an entry in this section prevents calculation.

In order to calculate the claim, the officer must remove any monies indicated in the Wage Loss Indemnity (EI Insurable) section. If, while reviewing the BPC in later steps, the officer determines that a wage loss insurance (WLI) payment applies from the BPC, the officer adds a note to the calculation worksheet. The note indicates that when reviewing and inputting the calculation, an Allocation (M175) transaction reason F - Wage Loss Insurance (M175-F) must be input.

Once the M103 - Initial Decision (M103) transaction is generated by SSO, if an amount is displayed in the Earnings week 1 field that is equal to the WLI payment the officer deletes it.

**What you need to do**

- Determine if you have reviewed the WLI information for the purposes of establishing the BPC:

- If you have reviewed the information, go to step 2.

- If you have not reviewed the information, refer to Reviewing for benefits paid or payable from another source .
             [Reviewing for benefits paid or payable from another source](/en/procedure/task/calc_determining/rev_psl_wli.shtml)

- In RCM, update the ROE by inputting the following information in the Additional Information section:

- Additional Information: Type the information found in the Wage Loss Indemnity (EI Insurable) section.

- Wage Loss Indemnity (EI Insurable): Delete the entries.

- Select Validate and Submit . (If there are validation errors, refer to Correcting an ROE before proceeding.)
             [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- On the calculation worksheet, note that when reviewing the BPC, the Administrative Policy may be required to obtain the correct BPC.

- Determine if, when reviewing the BPC, WLI payments apply from the BPC:

- If yes, on the calculation worksheet, note that when reviewing and inputting the calculation, an Allocation (M175) transaction reason F - Wage Loss Insurance (M175-F) must be input. Go to step 5.

- If no, go to step 6.

- Review the M103 - Initial Decision (M103) transaction generated by SSO to determine if an amount is displayed in the Earnings week 1 field that is equal to the WLI payment:

- If yes, delete that amount. Go to step 6.

- If no, go to step 6.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

**Later BPC may be more advantageous - input would be needed in the subsequent or manual BPC field of the coding requirements screen (1054)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The CT is special benefits.

- The client could benefit from a postdate due to one of the following:

- The client’s insured hours in the week of the I of E are required to qualify.

- The client has earnings in the week of the BPC and requests that the BP start at a later date to collect the maximum payable benefits.

- The client had a full working week in the week of the I of E. This can occur even when the client was not paid for that week (e.g. lay days, bankruptcy).

- The client is entitled to the maximum allowable number of weeks of the special BTs requested, but earnings in the week of the BPC will prevent the client from receiving the full entitlement to those benefits at the full weekly rate. If a RTW date is indicated on the ROE, it must be taken into consideration when determining if a claim for special benefits can be postdated.

Postdating the claim may be more advantageous to the client. When reviewing the BPC, the officer must remember that a postdate may be required. The officer then accepts this message and continues with the calculation of the claim.

**What you need to do**

- When reviewing the BPC, remember that a postdate should be considered if the conditions are met.

- Accept the message.

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Last ROE special condition is required (1163)**

**What you need to know**

SSO displays this message when the following conditions are met:

- The BPC is between w/c 2310 and w/c 2361.

- The claim is not BPNE.

- The last ROE RFS is potentially contentious (E, G, K, N or M).

In addition, one of the following conditions is met:

- The Special condition field of the ROE is blank.

- The Special condition field on the ROE indicates Adjudication deferred , and the requested BT is regular.

**What you need to do**

- In NWS, determine if there is a ROD for the adjudication or deferral of the RFS on the last ROE:

- If there is a ROD for the adjudication of the RFS, go to step 2.

- If there is a ROD for the deferral of adjudication of the RFS, go to step 3.

- If there is no ROD, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- In RCM, update the Special condition field on the ROE according to the decision in the ROD. Select Submit and go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- In NWS, select the appropriate RFS issue (i.e. ROD indicating Adjudication deferred ). In the Decision Options menu, select Amend Decision and select OK . Go to step 15 of Determining if a claim is ready to be calculated — Regular benefits.
         [Determining if a claim is ready to be calculated — Regular benefits.](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

**Manual actual(s) present – Actuals required (1149)**

**What you need to know**

SSO displays this message when a variable best week in NWS coincides with a week that contains a manual actual and all of the following conditions are met:

- The calculation determines that there are enough hours to establish the claim including special benefit claims with a disentitlement to regular benefits.

- The benefit rate determined excluding any family supplement is less than the maximum benefit rate.

- There is a Variable Best Weeks (VBW) questionnaire in NWS.

- A manual entry has been made in the Employment History File of an ROE for the same week as a variable best week on the VBW questionnaire.

If you have just entered the VBW information into the Employment History File in response to the “Best Weeks - Actuals Required” message, you can accept this message without further review and go to Next procedure . Otherwise, you must review the Employment History File .
       [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

You must ensure that the VBW information in the Employment History File of the associated ROE is the most current information received from the client. Once you have reviewed the information and made any necessary corrections, you can accept this message and go to Next procedure .
       [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**What you need to do**

- In NWS, select Systems - View Questionnaire .

- If there is no Best weeks questionnaire, go to step 2.

- If there is a Best weeks questionnaire, select the most recent completed questionnaire attached to the current Web Application and go to step 4.

- Determine if the VBW information is detailed on an SROC or Action Item (AI) WI (referred to as the “questionnaire” in the following steps):

- If no, go to step 3.

- If yes, go to step 4.

- Select the VBW Details section of the Web application (referred to as the “questionnaire” in the following steps) and determine if the client provided VBW information:

- If yes, go to step 4.

- If no, go to step 14.

- Review the questionnaire to determine each of the following:

- the number of employers listed for each variable best week amount entered.

- the calendar weeks listed.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0888.dita)

- In RCM, determine if there is an ROE for the employer for each calendar week listed.

- If yes, go to step 6.

- If no, go to step 13.

- Determine if the EHF box is displayed beside the ROE:

- If yes, select the box to open the Employment History File and go to step 7.

- If no, refer to Correcting an ROE before proceeding.
             [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- In the Employment History File, for the week being entered, determine if $0.00 is displayed:

- If no, go to step 8.

- If yes, go to step 10.

- Determine if the amount provided on the questionnaire is equal to the amount of the corresponding w/c:

- If no, go to step 9.

- If yes, go to step 11.

- In the Week Code - Earnings field of the corresponding calendar week, enter the amount provided on the questionnaire:

- If there is no exclamation mark, go to step 11.

- If there is an exclamation mark, do the following:

- Reason for actuals: Select Best Weeks .

- Select Validate .

- If the exclamation mark is still displayed, go to step 10.

- If the exclamation mark is no longer displayed, go to step 11.

- Correct the Employment History File error using the table below:

```text
| Error Message | Action required |

| The ROE Pay Period is NIL in 15C. Actuals may not be entered. | - Remove the VBW entry. |

| The Earnings for Pay Period (x) cannot be 0.00 because no details have been provided in 15C on the ROE. | - Verify that $0.00 has not been entered in error. - Clear all amounts entered and enter the correct amounts. |

| The total actual calculated earning for ROE (xx) does not match the Total Earnings reported on the ROE 15B (xx). | Determine if removing the lowest VBW entry resolves the error: - If the error is resolved, clear all amounts entered for the pay period and enter all VBW except the lowest entry. - If the error is not resolved, clear all amounts entered and enter the VBW for all pay periods except the one creating the error. |

| The total hours entered (xx) is greater than the total hours reported (xx) on the ROE. | - Verify that amounts have not been entered in the Hours field in error. - Clear all amounts entered and enter the correct amounts. |

| Hours cannot exceed 24 hours per day. The value must be between 0.00 and (xx). | - Verify that amounts have not been entered in the Hours field in error. - Clear all amounts entered and enter the correct amounts. |

| The Earnings must be in the range 0.00 to 99999999.99. | - Enter the amount in the correct format. |

| The Earnings for the First Pay Period cannot be 0 as it contains the First Day Worked. The Hours for the First Pay Period cannot be 0 as it contains the First Day Worked. | - Verify that $0.00 has not been entered in error. - Clear all amounts entered and enter the correct amounts. |

| The total Earnings for Pay Period (xx) (xx) does not equal the earnings reported in 15C on the ROE (xx). They must be equal. | Determine if removing the lowest VBW entry resolves the error: - If the error is resolved, clear all amounts entered for the pay period and enter all the VBW except the lowest entry. - If the error is not resolved, clear all amounts entered and enter the VBW for all pay periods except the one creating the error. |

| The Earnings for the Final Pay Period cannot be 0 as it contains the Last Day Paid. The Hours for the Final Pay Period cannot be 0 as it contains the Last Day Paid. | - Verify that $0.00 has not been entered in error. - Clear all amounts entered and enter the correct amounts. |
```

- If the entry remains flagged with an exclamation mark, repeat step 10.

- If the entry is no longer flagged with an exclamation mark, go to step 11.

- Determine if there are other weeks to be entered for this ROE:

- If yes, return to step 7 to enter the next variable best week.

- If no, go to step 12.

- Determine if entries were made in the Employment History File of the ROE:

- If no, exit the Employment History File and go to step 15.

- If yes, do the following:

- If the Reason for actuals field is blank, select Best Weeks .

- If Validate is greyed out, select Save .

- If Validate is not greyed out, select Validate and Save .

- Determine if there are VBW from other employers to be entered:

- If yes, return to step 5 for the next employer.

- If no, go to step 14.

- Determine if any entries were made to the Employment History File of any ROE:

- If yes, go to step 15.

- If no, go to step 16.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Maternity claim - BPC not within the maternity window (1008)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The Claim type field on the Coding Requirements screen indicates Maternity .

- The Special Benefits section of the Calculation Result screen displays a maternity start and end week. This is the maternity window.

- The BPC is outside of the maternity window.

If the BPC is after the maternity window, this message appears in conjunction with the Maternity payable < 15 weeks message.

Maternity benefits are payable only during the maternity window.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0899.dita) 

A client that qualifies for regular benefits and who must serve a waiting period (WP) can establish a claim for maternity benefits before the maternity window, if the start date of the claim allows the client to serve the WP immediately before the maternity window.
       [waiting period (WP)](/en/procedure/generic/knowledge.shtml#Waiting_period)

A client who does not qualify for regular benefits or must not serve a WP can establish a claim for maternity benefits as soon as the start of the maternity window.

The latest a client can establish a BP for maternity benefits is the last week of the maternity window.

If the client wants to establish a claim for maternity benefits, a postdate or extension of the maternity period may be applicable. However, the officer must take into account all issues that prevent the payment of benefits including allocations and a return to work (RTW) date. Postdating the claim may allow the client’s BPC to fall within the maternity window. If the client is applying for maternity benefits before they are entitled, the officer, when reviewing the BPC, must remember that a postdate may be required. Refer to the Postdate Policy for further information. Once the BPC is determined, the officer then accepts this message and continues with the calculation of the claim. If the client is applying for maternity benefits after they are entitled and an extension of the maternity window is applicable, the officer inputs an extension manually after the calculation result is accepted.
       [Postdate Policy](/en/policy/nationalpolicy/national_policy_on_postdates.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0900.dita) 

**What you need to do**

- Determine if the Calculation Result screen displays the Claim type requested:

- If no, refer to Changing the benefit type in SSO during calculation .
             [Changing the benefit type in SSO during calculation](/en/procedure/task/calc_calculating/changing_tentative_ct.shtml)

- If yes, go to step 2.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0901.dita)

- Determine if the BPC is before the maternity start week:

- If yes, go to step 3.

- If no, go to step 4.

- When reviewing the BPC, remember that a postdate to the first week the client qualifies to establish a claim for maternity benefits should be considered. Refer to the Postdate Policy for further information. Accept this message and go to step 11.
         [Postdate Policy](/en/policy/nationalpolicy/national_policy_on_postdates.shtml)

- Determine if the issue of an extension of the maternity window has been reviewed:

- If yes, go to step 5.

- If no, go to Determining if an extension of the maternity window is required .
             [Determining if an extension of the maternity window is required](/en/procedure/task/determining_extension_mrr.shtml)

- Determine if an extension of the maternity window is required:

- If no, go to step 6.

- If yes, accept this message and go to step 11.

- Determine if the client applied for benefits in a timely manner:

- If no, go to step 7.

- If yes, accept this message and go to step 11.

- Determine if the client requested an antedate or if there is an implied antedate:

- If yes, go to step 8.

- If no, accept this message and go to step 11.

- Determine if the antedate has been adjudicated:

- If the antedate has been adjudicated, go to step 9.

- If the antedate has not been adjudicated, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Determine if the antedate has been allowed:

- If yes, go to step 10.

- If no, accept this message and go to step 11.

- Determine if the BPC on the Calculation Result screen displays the earlier date:

- If the BPC is not at the earlier date, refer to Entering an antedate in SSO .
             [Entering an antedate in SSO](/en/procedure/task/calc_calculating/input_antedate.shtml)

- If the BPC is at the earlier date, go to step 11.

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Maternity payable < 15 weeks (1123)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The claim is established.

- The CT is maternity.

- The Special Benefits section of the Calculation Result screen displays a maternity start and end week. This is the maternity window.

- The client could receive less than 15 weeks of maternity benefits based on the maternity end week, the WP and the RTW week.

This message may also appear in conjunction with the 1008 - Maternity claim - BPC not within the maternity window message. If so, deal with that first.

Maternity benefits cannot be paid outside of the maternity range.

If a date is input in the External maternity end week field (e.g. a client establishes a subsequent claim to collect the remainder of maternity benefits), that date is the maternity end week displayed on the Calculation Result screen.

When an extension of the maternity window is required, the extension is input manually on the M107 after the calculation result is accepted. When this occurs, the maternity end week displayed on the Calculation Result screen is the maternity window before it is extended.

If the client did not apply in a timely manner, the officer determines if an antedate is applicable.

**What you need to do**

- Determine if the client is payable less than the maximum entitlement to maternity benefits only because of a RTW date indicated on the ROE:

- If no, go to step 2.

- If yes, accept the message and go to step 14.

- Determine if a date is required in the External maternity end week field to prevent the payment of more than 15 weeks of maternity benefits for this birth (i.e. this is a subsequent claim being established to collect the remainder of maternity benefits for this birth):

- If yes, go to step 3.

- If no, go to step 4.

- Determine if the maternity window end date is the last week the client should be paid maternity benefits for this birth (i.e. the client can collect the remaining maternity entitlement for this birth during the maternity window indicated):

- If yes, accept the message and go to step 14.

- If no, refer to Modifying the maternity information on the annex for special benefits in SSO .
             [Modifying the maternity information on the annex for special benefits in SSO](/en/procedure/task/modifying_mat_sb_ssa.shtml)

- Determine if the client provided both the expected and actual dates of birth:

- If no, go to step 5.

- If yes, go to step 9.

- Make one attempt to contact the client for fact-finding.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 8.

- If the client was not contacted, go to step 14.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Calculation .

- Comments: Type “Maternity information.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
             [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Refer to Modifying the maternity information on the annex for special benefits in SSO .
         [Modifying the maternity information on the annex for special benefits in SSO](/en/procedure/task/modifying_mat_sb_ssa.shtml)

- Determine if the client applied for benefits in a timely manner:

- If no, go to step 10.

- If yes, go to step 14.

- Determine if the client requested an antedate or if there is an implied antedate:

- If yes, go to step 11.

- If no, go to step 14.

- Determine if the antedate has been adjudicated:

- If yes, go to step 12.

- If no, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Determine if the antedate has been allowed:

- If yes, go to step 13.

- If no, go to step 14.

- Determine if the BPC on the Calculation Result screen displays the earlier date:

- If yes, go to step 14.

- If no, refer to Entering an antedate in SSO .
             [Entering an antedate in SSO](/en/procedure/task/calc_calculating/input_antedate.shtml)

- Accept the message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Maternity proof required …Please review (1100)**

**What you need to know**

SSO displays this message when the maternity proof has been noted as outstanding on the Outstanding information section of the Registration screen.

If proof of pregnancy is required , the officer is directed to note it as outstanding information. In addition to the message 1100 - Maternity proof required …Please review , the SSO Calculation Result screen also shows in the Disqualifications / Disentitlements section that an indefinite 15 - Claim procedure disentitlement (D15) is imposed from BPC.
       [proof of pregnancy is required](/en/procedure/generic/knowledge.shtml#Proof_of_pregnancy)

A ROD must be on file when a client is disentitled from special benefits unless the client is disentitled for being minor attached. If a ROD is required but not on file, the officer must return to the previous task that generated the condition to determine if the disentitlement is correct.

**What you need to do**

- Determine if a ROD indicates the maternity proof is outstanding:

- If no, a disentitlement may be imposed in error. Go to step 2.

- If yes, accept the message and go to Next procedure .
             [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

- In SSO, in the Outstanding information section of the Registration screen, do the following:

- Maternity - Due date: Delete the due date of the calculation WI.

- Select Save .

- Refer to Determining if the client has provided proof of her pregnancy .
         [Determining if the client has provided proof of her pregnancy](/en/procedure/task/determining_pembr.shtml)

**Medical certificate required …Please review (1003)**

**What you need to know**

SSO displays this message when the medical certificate has been noted as outstanding in the Outstanding information section of the Registration screen.

When a medical certificate must be submitted, the officer notes it as outstanding information on the Registration screen. In addition to the message 1003-Medical certificate required …Please review , the Calculation Result screen also shows that an indefinite 16 - No medical certificate submitted disentitlement (D16) is imposed from BPC.

A ROD must be on file when a client is disentitled from special benefits unless the client is disentitled for being minor attached. If a ROD is required but not on file, the officer must return to the previous task that generated the condition to determine if the disentitlement is correct.

**What you need to do**

- Determine if a ROD indicates that the medical proof is outstanding:

- If no, a disentitlement may be imposed in error. Go to step 2.

- If yes, accept the message and go to the next procedure .
             [next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

- In SSO, in the Outstanding information section of the Registration screen, do the following:

- Medical certificate - Due date: Delete the due date of the calculation WI.

- Select Save .

- Refer to Determining if a medical certificate must be submitted: Sickness benefits — Initial claims .
         [Determining if a medical certificate must be submitted: Sickness benefits — Initial claims](/en/procedure/task/calc_determining/det_mc_ra.shtml)

**MN05 active claim - Actuals may be required (1129)**

**What you need to know**

SSO displays this message when a previously established claim is still active as shown on the FTS Summary tab.

The system cannot populate the Employment History File of the ROE with actual information unless the previous claim has moved to the Dormant tab in FTS. Even when amounts have been entered into the Employment History File , this message appears if the previous claim is still on the Summary tab.

The reason the previous claim has not moved to the Dormant tab may be one of the following:

- previous claim is a skeleton claim (MA03)

- previous claim is BPNE2 (MA22)

- manual action to stop payments (MA01, 02) is imposed

- cycling reports

- active claim has pending reports for the last week(s) of claim (possible renewal subsequent initial scenario)

This is not an exhaustive list. The previous claim must be reviewed determine the reason that the previous claim has not moved to the Dormant tab.

**What you need to do**

- In FTS, review the previous claim to determine the reason it has not moved to the Dormant tab and take the appropriate action to resolve the issue.

- Once the issue on the previous claim is resolved or if no issue is present, in FTS, select the Initial Intake (M149) transaction to move the claim to the Dormant tab as follows:

- Terminate previous claim: Check the box.

- Select Update .

- In NWS, move the calculation WI to Pending as follows:

- Pending Reason: Select Other .

- Comments: Type “Waiting for claim to go dormant.”

- Bring forward date: Enter today’s date + 1 business day.

- When the WI moves to the current workload, go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

**Monies on separation – fact finding required (1150)**

**What you need to know**

SSO displays this message when block 17C - Other monies of the ROE displays S - Settlement pay or O - Other .

The officer must review these monies to determine if they are correctly indicated in RCM. If the monies are correctly indicated in RCM, they will be allocated on separation and included as insurable separation monies.

**What you need to do**

- Determine if you have reviewed the monies displayed in block 17C - Other monies :

- If you have not reviewed the monies displayed in block 17C - Other monies , return to Verifying ROEs before calculation .
             [Verifying ROEs before calculation](/en/procedure/task/calc_determining/review_roe.shtml)

- If you have reviewed the monies displayed in block 17C - Other monies and determined that the monies must be allocated on separation and included as insurable separation monies, accept the message without further action and go to Next procedure .
             [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0717.dita) 

**No interruption in earnings (1066)**

**What you need to know**

SSO displays this message when the Coding requirements screen indicates no interruption of earnings (I of E).

In the majority of cases, clients have an I of E when they are applying for EI benefits. An I of E can occur at any time during the QP .
       [QP](/en/procedure/generic/knowledge.shtml)

When no I of E is determined, the officer creates a ROD in NWS and indicates that there has not been an I of E in SSO.

When there is not a ROD on file, the Coding requirements screen may incorrectly indicate that there has not been an I of E. When this occurs, the officer corrects the information on the Coding requirements screen and refers to Determining an interruption of earnings before continuing with the calculation of the claim.
       [Determining an interruption of earnings](/en/procedure/task/calc_determining/interruption_earnings.shtml)

When there is a ROD on file, the officer accepts this message.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0902.dita) 

**What you need to do**

- In NWS, determine if there is a ROD indicating that there is no I of E.

- If there is not a ROD indicating that there is no I of E, go to step 2.

- If there is a ROD indicating that there is no I of E, go to step 3.

- In SSO, on the Coding requirements screen, complete the following field:

- Interruption of earnings: Select Yes .

- Refer to Determining if there is an interruption of earnings .
             [Determining if there is an interruption of earnings](/en/procedure/task/calc_determining/interruption_earnings.shtml)

- In NWS, determine if this is an initial calculation or a recalculation:

- If this is an initial calculation, go to step 4.

- If this is a recalculation of an already established BP, go to Voiding a benefit period .
             [Voiding a benefit period](/en/procedure/task/benefit_period_void.shtml)

- Remember that the M101 - File Control Data (M101) transaction type 7 (M101-7) required to cancel the claim must be transmitted after the M103 - Initial Decision (M103) .

- Accept this message and go to step 10 of Reviewing the calculation result .
         [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml)

**No PHS found in the QP (1126)**

**What you need to know**

SSO displays this message when the following criteria are met:

- There are no dormant claims that fall into the QP.

- The calculation determines that the claim can be established.

- The benefit rate excluding the family supplement is less than the maximum rate.

- Manual actuals have not been entered in the Employment History File on any ROE falling in the QP.

UIC reviews the pay history from dormant claims to determine any weeks in which the client has declared $0.00 earnings and attempts to import these weeks into the Employment History File of the ROE for weeks that fall in the QP.

Gaps in employment are determined from the blank (or $0.00) pay periods on the ROE and the weeks when the client declared $0.00 earnings on the previous claim. When there are no dormant claims falling in the QP, the system must rely solely on the detailed earnings section of the ROE to determine these weeks.

**What you need to do**

- Accept this message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Overlapping best weeks - Actuals required (1148)**

**What you need to know**

SSO displays this message when overlapping ROEs exist, when there are variable best weeks (VBW) in the coinciding period, and when all of the following conditions are met:

- The calculation determines that there are enough hours to establish the claim including special benefit claims with a disentitlement to regular benefits.

- The benefit rate determined excluding any family supplement is less than the maximum benefit rate.

- There is a Variable Best Weeks questionnaire in NWS on which the client has indicated one of the following options:

- more than one employer in a calendar week;

- one employer in a calendar week for which RCM contains more than one ROE.

Since the system cannot determine on which ROE to enter the VBW information, the officer must make that determination. This message continues to display even after the information has been entered into the Employment History File .

The officer must ensure that the VBW information in the Employment History File of the associated ROE is the most current information received from the client. After reviewing the information and made any necessary corrections, the officer can accept this message and go to Next procedure .
       [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**What you need to do**

- In NWS, select Systems - View Questionnaire .

- If there is no Best weeks questionnaire, go to step 2.

- If there is a Best weeks questionnaire, select the most recent completed questionnaire attached to the current Web Application and go to step 4.

- Determine if the VBW information is detailed on an SROC or Action Item (AI) WI (referred to as the “questionnaire” in the following steps):

- If no, go to step 3.

- If yes, go to step 4.

- Select the VBW Details section of the Web application (referred to as the “questionnaire” in the following steps) and determine if the VBW information is present:

- If yes, go to step 4.

- If no, go to step 16.

- Review the questionnaire to determine each of the following:

- the number of employers listed for each VBW amount entered;

- the calendar weeks listed.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0888.dita)

- In RCM, determine if there is an ROE from the employer for each calendar week listed:

- If yes, go to step 6.

- If no, go to step 13.

- Determine if the EHF box is displayed beside the ROE:

- If yes, select the box to open the Employment History File and go to step 7.

- If no, refer to Correcting an ROE before proceeding.
             [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- In the Employment History File , for the week being entered, determine if $0.00 is displayed:

- If no, go to step 8.

- If yes, go to step 11.

- Determine if the amount provided on the questionnaire is equal to the amount of the corresponding w/c:

- If no, go to step 9.

- If the amounts are the same, go to step 11.

- In the Week Code - Earnings field of the corresponding calendar week, enter the amount provided on the questionnaire:

- If there is no exclamation mark, go to step 11.

- If there is an exclamation mark, do the following:

- Reason for actuals: Select Best Weeks .

- Select Validate .

- If the exclamation mark is still displayed, go to step 10.

- If the exclamation mark is no longer displayed, go to step 11.

- Correct the Employment History File error using the table below:

```text
| Error Message | Action required |

| The ROE Pay Period is NIL in 15C. Actuals may not be entered. | - Remove the VBW entry. |

| The Earnings for Pay Period (x) cannot be 0.00 because no details have been provided in 15C on the ROE. | - Verify that $0.00 has not been entered in error. - Clear all amounts entered and enter the correct amounts. |

| The total actual calculated earning for ROE (xx) does not match the Total Earnings reported on the ROE 15B (xx). | Determine if removing the lowest VBW entry resolves the error: - If the error is resolved, clear all amounts entered for the pay period and enter all VBW except the lowest entry. - If the error is not resolved, clear all amounts entered and enter the VBW for all pay periods except the one creating the error. |

| The total hours entered (xx) is greater than the total hours reported (xx) on the ROE. | - Verify that amounts have not been entered in the Hours field in error. - Clear all amounts entered and enter the correct amounts. |

| Hours cannot exceed 24 hours per day. The value must be between 0.00 and (xx). | - Verify that amounts have not been entered in the Hours field in error. - Clear all amounts entered and enter the correct amounts. |

| The Earnings must be in the range 0.00 to 99999999.99. | - Enter the amount in the correct format. |

| The Earnings for the First Pay Period cannot be 0 as it contains the First Day Worked. The Hours for the First Pay Period cannot be 0 as it contains the First Day Worked. | - Verify that $0.00 has not been entered in error. - Clear all amounts entered and enter the correct amounts. |

| The total Earnings for Pay Period (xx) (xx) does not equal the earnings reported in 15C on the ROE (xx). They must be equal. | Determine if removing the lowest VBW entry resolves the error: - If the error is resolved, clear all amounts entered for the pay period and enter all the VBW except the lowest entry. - If the error is not resolved, clear all amounts entered and enter the VBW for all pay periods except the one creating the error. |

| The Earnings for the Final Pay Period cannot be 0 as it contains the Last Day Paid. The Hours for the Final Pay Period cannot be 0 as it contains the Last Day Paid. | - Verify that $0.00 has not been entered in error. - Clear all amounts entered and enter the correct amounts. |
```

- If the entry remains flagged with an exclamation mark, repeat step 10.

- If the entry is no longer flagged with an exclamation mark, go to step 11.

- Determine if there are other weeks to be entered for this ROE:

- If yes, return to step 7 to enter the next variable best week.

- If no, go to step 12.

- Determine if entries have been made in the Employment History File of the ROE :

- If no, exit the Employment History File and go to step 13.

- If yes, do the following:

- If the Reason for Actuals field is blank, select Best Weeks .

- If Validate is greyed out, select Save .

- If Validated is not greyed out, select Validate and Save .

- Determine if there are VBW from other employers to be entered:

- If yes, return to step 5 for the next employer.

- If no, go to step 14.

- Determine if any entries were made to the Employment History File of any ROE:

- If yes, go to step 15.

- If no, go to step 16.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Parental benefits - minor attached claimant (1102)**

**What you need to know**

SSO displays this message when both of the following conditions are met:

- The client is minor attached .
         [minor attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

- The CT is parental benefits.

In order to qualify for parental benefits, a client must have at least 600 hours in the QP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0889.dita) 

**What you need to do**

- Accept the message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Parental start week is greater than BPC - Please review (1090)**

**What you need to know**

SSO displays this message when all of the following conditions apply:

- The claim is established.

- The CT is parental.

- The parental start date is greater (>) than the BPC.

This message appears with the 1099 - Parental start week is greater than BPC. Please review message. Review that message first.

Parental benefits are only payable during the parental window.

**What you need to do**

- Accept this message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**PHS in QP but no automated actual created (1127)**

**What you need to know**

The message is displayed when all of the following conditions are met:

- The calculation determines that the claim can be established.

- The benefit rate excluding the family supplement is less than the maximum.

- Manual actuals have not been entered into the EHF on any ROE falling in the QP.

- There is a dormant claim and pay history in the QP but the client either did not complete reports for the weeks or declared earnings that prevented payment.

Gaps in employment are determined from the blank (or $0.00) pay periods on the ROE and the weeks when the client declared $0.00 earnings on the previous claim.

**What you need to do**

- Accept this message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Possible remaining weeks payable (1131)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The CT is fishing benefits.

- A previous claim is still active.

- The BPC of the new fishing claim is later than last week processed plus one week of the previous claim.

Even if the rate on the new fishing claim is higher than a previous claim for regular benefits, the regular claim cannot be terminated in favour of the fishing claim if the following conditions exist:

- There is no indefinite disqualification on the regular claim.

- The regular claim is renewable.

However, if there is an indefinite disqualification on the claim for regular benefits, it can be terminated in favour of the new fishing claim.

**What you need to do**

- Determine if the active claim is for regular benefits:

- If the claim is for regular benefits, go to step 2.

- If the claim is for fishing benefits, go to step 5.

- Determine if there is an indefinite disqualification on the active claim:

- If there is no indefinite disqualification, go to step 3.

- If there is an indefinite disqualification, go to step 6.

- Determine if there are weeks payable on the claim:

- If there are weeks payable, go to step 4.

- If there are no weeks payable, go to step 6.

- Refer to Renewal to renew the active claim.
         [Renewal](/en/procedure/activity/conversions.shtml)

- Determine if it is to the client’s advantage to terminate the old claim in favour of a new claim: (Refer to Terminating a Benefit Period .)

- If it is not to the client’s advantage, accept the message and go to step 6.

- If it is to the client’s advantage, refer to Terminating a Benefit Period .
             [Terminating a Benefit Period](/en/procedure/task/benefit_period_term.shtml)

         [Terminating a Benefit Period](/en/procedure/task/benefit_period_term.shtml)

- Accept the message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Postdate with earning in week 1 - transmit a M175 type A if required (1062)**

**What you need to know**

SSO displays this message when all of the following conditions apply:

- The claim is established.

- The recalculation of the initial claim is postdated.

- There are earnings in the first week.

In this case, if the earnings in the first week of the claim are lower than the earnings in the first week of the recalculation result, amend the earnings using a Subsequent decision - Allocations (M175) transaction type A (M175-A). However, if the earnings in the first week of the claim are higher than the earnings in the first week of the recalculation result, no action is required.

**What you need to do**

- In FTS, determine if the earnings in the first week of the claim are lower than the earnings in the first week of the recalculation result:

- If yes, go to step 2.

- If no, go to step 3.

- On the calculation worksheet, note that, during claim recalculation, the earnings in the first week must be amended to the earnings amount indicated in the recalculation result using a Subsequent decision - Allocations (M175) transaction type A (M175-A).

- Accept this message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Proof of Birth or adoption / placement required …Please review (1101)**

**What you need to know**

SSO displays this message when the parental/adoption proof has been noted as outstanding on the Outstanding information section of the Registration screen.

When the client applying for parental benefits does not provide proof of birth, adoption or placement, the officer is directed to note it as outstanding information. In addition to the message 1101 - Proof of Birth or adoption/placement required … Please review , the SSO Calculation Result screen also shows in the Disqualifications / Disentitlement section that an indefinite 34 - Parental benefits entitlement conditions not met disentitlement (D34) is imposed from BPC.

A ROD must be on file when a client is disentitled from special benefits unless the client is disentitled for being minor attached. If a ROD is required but not on file, the officer must return to the previous task that generated the condition to determine if the disentitlement is correct.

**What you need to do**

- Determine if a ROD indicates the parental/adoption proof is outstanding:

- If no, a disentitlement may be imposed in error. Go to step 2.

- If yes, accept the message and go to Next procedure .
             [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

- In SSO, in the Outstanding information section of the Registration screen, do the following:

- Parental / adoption - Due date: Delete the due date of the calculation WI.

- Select Save .

- Refer to Determining if proof of entitlement to parental benefits is required .
         [Determining if proof of entitlement to parental benefits is required](/en/procedure/task/determining_pepbr.shtml)

**PSL start date after LDP - Please review (1130)**

**What you need to know**

SSO displays this message when both of the following conditions apply:

- Block 19 on the ROE contains paid sick leave or maternity/parental leave.

- The start date of the special payment is later than the last day for which paid in block 11 .

This message is displayed only if the ROE used in the calculation has an issue date of May 25, 2011 or earlier as the entry edits changed as of May 26, 2011.

**What you need to do**

- Refer to Correcting an ROE .
         [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

**Qualifying hours < 600 - May qualify for special benefits (1078)**

**What you need to know**

SSO displays this message when all of the following conditions apply:

- The CT is regular or fishing.

- The client is minor attached .
         [minor attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

- ROEs have been excluded from calculation of the claim.

- The total combined hours using all ROEs are greater than or equal to 600.

If on Coding Requirements screen, the Claim type field indicates Regular, Summer fishing or Winter fishing and there is less than 600 insurable hours in the QP, but using all of the ROEs could result in the client being entitled to special benefits, the officer reviews the ROEs used in calculation of the claim. If an ROE has been excluded in error because the RFS has not been adjudicated, the officer reviews the RFS and obtains a new calculation result.

**What you need to do**

- In RCM, determine which ROE is excluded from the calculation.

- In NWS, determine if there is a ROD for the adjudication or deferral of the RFS on the excluded ROE:

- If there is a ROD, go to step 3.

- If there is no ROD, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0897.dita)

- In RCM, determine if the entries in the Reason for separation , Special condition and End date (if applicable) fields on the ROE correspond to the decision in the ROD:

- If yes, go to step 4.

- If no, correct the ROE, select Submit and go to step 4.

- Determine if there is another excluded ROE that requires review:

- If yes, return to step 2.

- If no, go to step 5.

- Determine if any changes were made in RCM:

- If yes, go to step 6.

- If no, go to step 7.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Recovery week is coded with a maternity or parental claim, please review (1028)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The CT is maternity or parental.

- The Estimated or actual date of recovery field is completed on the Annex - Special Benefits screen in SSO.

If the wrong BT has been input in SSO, change the BT indicated in the Claim type field.

If the BT input in SSO is correct but an incorrect recovery date is input, remove the recovery date and obtain a new calculation result.

**What you need to do**

- In SSO, determine if the wrong BT was input in the Claim type field of the Coding Requirements screen:

- If yes, refer to Changing the benefit type in SSO .
             [Changing the benefit type in SSO](/en/procedure/task/calc_calculating/changing_tentative_ct.shtml)

- If no, go to step 2.

- In SSO, on the Annex - Special Benefits screen, complete the following field:

- Estimated or actual date of recovery: Remove the recovery date.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

**Recovery week is coded with a regular claim, please review (1027)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The CT is regular.

- The Estimated or actual date of recovery field is completed on the Annex - Special Benefits screen in SSO.

If the wrong BT has been input in the Claim type field of the Coding Requirements screen, change the BT indicated.

If the BT input in the Claim type field is correct but an incorrect recovery date is input on the Annex - Special Benefits screen, remove the recovery date and obtain a new calculation result.

**What you need to do**

- In SSO, determine if the wrong BT was input in the Claim type field of the Coding Requirements screen:

- If no, go to step 2.

- If yes, refer to Changing the benefit type in SSO .
             [Changing the benefit type in SSO](/en/procedure/task/calc_calculating/changing_tentative_ct.shtml)

- In SSO, on the Annex - Special Benefits screen, complete the following field:

- Estimated or actual date of recovery: Remove the recovery date.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

**Recovery week required (1002)**

**What you need to know**

SSO displays this message when all of the following conditions apply:

- The claim is established or BPNE 3 or 5.

- The CT is sickness.

- The recovery week is blank.

The UIC program determines a recovery week of BPC + 8 weeks if the following conditions are met:

- The RFS on the last ROE is illness.

- There is no indefinite disqualification being imposed for dismissal (D10) or voluntary leaving (D11).

- There is no disentitlement being imposed for suspension from employment (D42), period of leave (D43) or anticipated loss of employment (D44).

If one of the above conditions is not met, the UIC program cannot set the recovery week. When the recovery date is blank on the Annex - Special Benefits screen, and the recovery week cannot be set, SSO displays the message 1002 - Recovery week required .

If the client does not or cannot provide an acceptable medical certificate by the calculation due date, the officer:
       [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

- enters the outstanding medical certificate on the Registration screen;

- calculates the claim.

If the recovery week has been left blank intentionally and the missing medical certificate has been noted on the Registration screen, the additional message 1003-Medical certificate required …Please review appears. Both messages can be accepted, noting that Yes must be selected Is Indefinite? field of the M103 or M106 SSO transaction presented.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0903.dita) 

**What you need to do**

- Determine if there is a medical certificate on file:

- If no, go to step 2.

- If yes, go to step 3.

- Determine if the message 1003 - Medical certificate required …Please review is displayed:

- If yes, select Yes in the Is Indefinite? field in the Recovery week section of the M103 - Initial Decision (M103) or M106 - Subsequent Decision (M106) transaction. Accept this message and go to Next procedure .
             [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

- If no, refer to Indicating in SSO that information required to calculate a claim is outstanding .
             [Indicating in SSO that information required to calculate a claim is outstanding](/en/procedure/task/calc_calculating/ind_ssa_mcmiss_sb.shtml)

- Determine if you have reviewed the medical certificate:

- If yes, refer to Modifying the sickness benefits information on the Annex — Special benefits screen in SSO .
             [Modifying the sickness benefits information on the Annex — Special benefits screen in SSO](/en/procedure/task/calc_calculating/ent_recdate_ssa_sb.shtml)

- If no, refer to Determining if a medical certificate must be submitted: Sickness benefits — Initial claims .
             [Determining if a medical certificate must be submitted: Sickness benefits — Initial claims](/en/procedure/task/calc_determining/det_mc_ra.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Re-qualifies as fishing claim type (1147)**

**What you need to know**

SSO displays this message when all of the following conditions apply:

- There is a combination of regular and fishing ROEs.

- The regular ROE is excluded from calculation.

- The client requalifies for fishing benefits.

When SSO incorrectly determines that the BT is regular benefits and that the client has no earnings, the officer must determine if the ROE was excluded in error. If the ROE is correctly excluded during calculation of a claim for fishing benefits, the officer must change the status of the excluded ROE in RCM to Void - Not insurable before calculating the claim. Once the claim is calculated, the officer must return to RCM and remove the Void - Not insurable status from the regular ROE. The process ensures that the status of the regular ROE is correct if required for calculation on future claims.

**What you need to do**

- Determine if the message is displayed during calculation of a claim for fishing benefits:

- If yes, go to step 2.

- If no, go to step 13.

- In NWS, determine if there is a ROD for the adjudication of the RFS or the deferral of the RFS of the excluded ROE:

- If there is no ROD, go to step 3.

- If there is a ROD, go to step 8.

- Determine if this is an initial calculation or a recalculation:

- If this is an initial calculation, go to step 4.

- If this is a recalculation, go to step 5.

- In NWS, create an Adjudication Issue (ADJ) WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option based on the client’s preferred language.

- End User: Select Next available user .

- Issue: Check the appropriate box based on the issue.

- Go to step 7.

- In NWS, create a Claim Review (CR) WI as follows:

- Type: Select Revised .

- Issue: Select the appropriate issue.

- Registration number: Enter the recalculation registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- Date of registration: Enter the date of the recalculation registration.

- Reassign each CR Revised WI as follows:

- Destination: Select Myself .

- Reason: Select Related work item .

- Details: Enter the details of the contentious issue that requires adjudication.

- On the calculation worksheet, note that it is necessary to determine if the claim is ready to be calculated after the ROE is adjudicated. Return to Calculating or recalculating a claim for fishing benefits .
         [Calculating or recalculating a claim for fishing benefits](/en/procedure/activity/calc_fish.shtml)

- In RCM, determine if the Reason for separation , Special condition and End date (if applicable) fields on the ROE correspond to the decision on the ROD:

- If yes, go to step 9.

- If no, correct the ROE, select Submit and go to step 9.

- Determine if changes have been made in RCM, SSO or the Employment History File :

- If no, go to step 10.

- If yes, go to step 9 of Calculating a claim in SSO .
             [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- In RCM, in the excluded ROE, change the status of the ROE as follows:

- Status: Select Void - Not Insurable .

- Select Submit .

- On the calculation worksheet, note that after the claim calculation is complete, in RCM, the status of the excluded ROE must be changed so that it is no longer voided.

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- In NWS, determine if there is a ROD for the adjudication or deferral of the RFS on the excluded ROE:

- If there is a ROD, go to step 14.

- If there is no ROD, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- In RCM, determine if the Reason for separation , Special condition and End date (if applicable) fields on the ROE correspond to the decision in the ROD:

- If no, correct the ROE, select Submit and go to step 9 of Calculating a claim in SSO .
             [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- If yes, go to Calculating or recalculating a claim for fishing benefits .
             [Calculating or recalculating a claim for fishing benefits](/en/procedure/activity/calc_fish.shtml)

**ROE error - [serial number] (2286)**

**What you need to know**

SSO displays this message when the following conditions are met:

- The SSO Annex - Special Benefits screen contains QP extension information.

- The tentative cut-off date is not before the tentative BPC – 57.

- There is an ROE in error in the possible QP extension (between tentative cut-off date – 5 and tentative cut-off date – 57).

**What you need to do**

- Action the ROE as per procedures. If necessary, refer to Correcting and ROE .
         [Correcting and ROE](/en/procedure/activity/correct_roe.shtml)

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

**Self-employment agreement status is Termination. Please confirm eligibility (1139)**

**What you need to know**

SSO displays this message when both of the following conditions are met:

- The client is applying for special benefits for the self-employed.

- The self-employment (SE) agreement status is 3 (termination).

A client may choose to terminate the agreement they have entered into to be covered under Part VII Benefits for Self-Employed Persons. The agreement can only be terminated if the client has not collected any benefits under this section of the Act. Even if the client has decided to terminate the agreement and has not collected any benefits, the client is still obligated to pay EI premiums for the calendar year in which the agreement is terminated. Because of this obligation to pay premiums, the client is still considered covered and may be entitled to benefits during that calendar year.
       [Part VII](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/FullText.html#h-44)

If the client chooses to claim these benefits, the request to terminate the agreement must be cancelled.

If a client applies for benefits, you must discuss and confirm the client’s choice to collect benefits and ensure that the client understands that once benefits have been collected, EI premiums must continue to be paid for as long as the client is self-employed.

**What you need to do**

- Determine if there is information on file confirming that the client wants to collect EI benefits:

- If no, go to step 2.

- If yes, go to step 5.

- Fact-find with the client to explain that the SE agreement cannot be terminated once benefits have been collected, and to confirm that the client still wants to collect benefits.
         [Fact-find](/en/procedure/task/fact_find.shtml)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 9.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Calculation .

- Comments: Type “SE agreement.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
             [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client wants to collect EI benefits for the self-employed:

- If the client wants to collect benefits, go to step 6.

- If the client does not want to collect benefits, go to step 11.

- In SSO, on the Application Form screen, complete the following field:

- Self-employed: Select Yes .

- In the Self-employed details section, cancel the request to end the SE agreement as follows:

- SE agreement status: Select Termination request voided .

- Select Save .

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Remember to create and send the F-00-001 letter in ACS with the following attributes:

- Text - Free Text (1612): Type “After you asked to terminate your agreement to participate in the Employment Insurance (EI) Program for access to special benefits as a self-employed person , you applied for EI special benefits as a self-employed person . We must advise you again that if you receive these benefits, you may no longer terminate your agreement and you must continue to pay EI premiums on all future income earned from self-employment.

- Unfortunately, we were unable to contact you and notify you of these conditions by telephone. As a result, we have not processed your application for benefits.

- If you do wish to receive EI special benefits as a self-employed person , please contact us at 1-800-206-7218 or in writing to request the reinstatement of your agreement.”

- In NWS, create an SROC as follows:

- Issue: Select Other .

- Comments: Type “Terminated SE agreement — unable to contact client.”

- Details: Type “Officer was unable to contact client on [date of attempt]. Termination of the SE agreement is maintained. Letter was sent advising client to contact Service Canada if [he/she] wants to collect benefits.”

- Go to step 12.

- In NWS, create an SROC as follows:

- Issue: Select Other .

- Comments: Type “Terminated SE agreement — client does not want to collect benefits.”

- Details: Type “Client does not want to collect benefits. Termination of the SE agreement is maintained. Obligations under the SE agreement were explained to and understood by client [and any other facts obtained].”

- In FTS, select the File Control (M101) transaction to cancel the claim as follows:

- Select Terminate benefit period .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction to cancel the registration number as follows:

- Action: Select Cancel .

- Select Update .

- In NWS, complete the calculation WI.

**Sickness claim - BPC within the maternity window (1004)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- The CT is sickness.

- The calculation determines there are enough hours to qualify for special benefits.

- The Special Benefits section of the Calculation Result screen displays a maternity start and end week. These dates are the maternity window.

- The External maternity start field on the SSO Annex - Special Benefits screen is blank.

- The BPC date falls in the maternity window.

The claim is automatically converted to maternity benefits when all of the following conditions apply:

- a maternity window is present;

- maternity benefits can be paid;

- claimant’s reports are processed for a week in the maternity window.

If the client is entitled to a BT other than maternity during the calculated maternity window or the payment of maternity benefits must be prevented during that window, in SSO, the officer must enter a date in the External maternity start week field to override the calculated maternity window.

If the client is not entitled to a BT other than maternity during the calculated maternity window or the payment of maternity benefits does not need to be prevented during that window, a date is not required in the External maternity start week field in SSO. The officer accepts this message and continues with the calculation of the claim.

**What you need to do**

- Determine if the issue of an external maternity start date has been reviewed:

- If yes, go to step 2.

- If no, refer to Determining if external maternity dates are required on an initial claim .
             [Determining if external maternity dates are required on an initial claim](/en/procedure/task/determining_emdr.shtml)

- Determine if a date is required in the External maternity start week field:

- If no, accept this message and go to step 3.

- If yes, refer to Modifying the maternity information on the annex for special benefits in SSO .
             [Modifying the maternity information on the annex for special benefits in SSO](/en/procedure/task/modifying_mat_sb_ssa.shtml)

- Go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

**Subsequent BPC - Earnings or ROE after LDW (1128)**

**What you need to know**

SSO displays this message when the following condition is met:

- The claim is a renewal/subsequent claim (including BPNE claims and established claims at maximum benefit rate) and one of the following:

- The pay history shows earnings for a period after the LDW as displayed on the SSO Application Form screen.

- There is an ROE with a first day worked that falls after the LDW on the SSO Application Form screen.

When a client applies for benefits, ACP determines if there is a renewable claim on file. If the claim can be renewed and there are 4 weeks or less payable (either due to entitlement or due to the last renewable week), the application can be used to establish a new claim after the renewed claim has been paid out. This is called a subsequent claim.

When the subsequent claim is calculated, the UIC program reviews the pay history and RCM to determine if either condition above applies. If either or both of the conditions apply, the subsequent claim does not automate.

If the client receives earnings after the LDW, the officer must fact-find, if necessary, and do one of the following:

- If the employment is insurable and the details of the employment are available, the officer creates an interim ROE.

- If the employment is not insurable, the officer determines if the issue of self-employment requires adjudication.

- If the officer is unable to determine the nature of the earnings, the officer cancels the claim.

If an ROE is input after the officer determines the claim is ready to calculate, the officer must return to Determining if the claim is ready to be calculated and review the claim.

If an ROE, with a first day worked that falls after the LDW is on file and it has already been reviewed, the officer continues with the calculation of the claim.

**What you need to do**

- In FTS, determine if the earnings were declared on a claimant’s reports for a period after the LDW as displayed on the SSO Application Form screen:

- If yes, go to step 2.

- If no, go to step 10.

- In RCM, determine if there is an ROE for the period with the declared earnings on file:

- If no, go to step 3.

- If yes, go to step 11.

- Determine if additional fact-finding is required to clarify the nature of the declared earnings:

- If yes, go to step 4.

- If no, go to step 6.

- Fact-find with the client to determine if the earnings are related to insurable employment or self-employment (for more information, refer to Earnings ).
         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0904.dita) 
         [Fact-find](/en/procedure/task/fact_find.shtml) 
         [Earnings](/en/procedure/activity/earnings.shtml)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 6.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 12.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Calculation .

- Comments: Type “ROE.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
             [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the earnings are related to insurable employment (for more information, refer to Earnings ):

- If no, go to step 8.

- If yes, go to Determining if an interim ROE is required .
             [Determining if an interim ROE is required](/en/procedure/task/determining_interim_roe.shtml)

         [Earnings](/en/procedure/activity/earnings.shtml)

- Determine if any of the earnings declared were from a period of self-employment:

- If yes, go to step 9.

- If no, go to step 10.

- Determine if the self-employment has been adjudicated:

- If yes, go to step 10.

- If no, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- In RCM, determine if an ROE with a first day worked that falls after the LDW on the SSO Application Form screen is on file:

- If no, go to Next procedure .
             [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

- If yes, go to step 11.

- Determine if the ROE with a first day worked that falls after the LDW on the SSO Application Form screen has already been reviewed:

- If yes, go to Next procedure .
             [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

- If no, refer to Verifying ROEs before calculation .
             [Verifying ROEs before calculation](/en/procedure/task/calc_determining/review_roe.shtml)

- In FTS, select the File Control (M101) - Claim Action transaction and cancel the claim as follows:

- Select Terminate benefit period (M101-7) .

- Select Update .

- Select the Registration number (M025, M030, M035) transaction and cancel the registration number as follows:

- Action: Select Cancel .

- Select Update .

- In NWS, create a ROD as follows:

- Comments: Type “Subsequent claim cancelled.”

- Details: Type the appropriate details based on whether the client was reached:

- If the client was not reached, type “Unable to contact client. Earnings reported between renewal of old claim and start of subsequent.”

- If the client was reached, type “Client was contacted, but unable to provide information. Client was advised to obtain ROE and to file a new application for benefits. Earnings reported between renewal of old claim and start of subsequent.”

- Complete the calculation WI.

**Voluntary leaving/misconduct in the qualifying period - record of employments are overlapping - Actuals may be required (1096)**

**What you need to know**

SSO displays this message when all of the following conditions are met:

- A contentious ROE other than the last ROE displays one of the following in the Special Condition field:

- Blank

- Misconduct Proven

- Voluntary Leaving - No Just Cause

- This ROE overlaps a subsequent ROE that is not contentious.

- UIC cannot determine the actual number of hours worked after the LDW on the contentious ROE.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0905.dita) 

**What you need to do**

- In NWS, review the RODs to determine if the contentious RFS has been adjudicated:

- If yes, go to step 2.

- If no, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
             [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- In RCM, determine if the Reason for separation and Special condition fields on the ROE correspond to the decision on the ROD:

- If yes, go to step 3.

- If no, correct the ROE and select Submit . Go to step 9 of Calculating a claim in SSO .
             [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Determine if the subsequent non-contentious ROE is a SAT ROE (serial number begins with an “S”).

- If it is a SAT ROE, go to step 4.

- If it is not a SAT ROE, go to step 6.

- Determine if the hours from block 15C of the SAT ROE are displayed in the correct pay periods of the Employment History File :

- If no, go to step 5.

- If yes, go to Next procedure .
             [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next)

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0906.dita)

- Copy the hours information for each pay period from block 15C of the ROE into the Employment History File . Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Fact-find with the employer to obtain the actual hours required.
         [Fact-find](/en/procedure/task/fact_find.shtml)

- Determine if the employer was contacted during fact-finding:

- If the employer was not contacted, go to step 8.

- If the employer was contacted, go to step 10.

- Fact-find with the client to obtain the actual hours required.
         [Fact-find](/en/procedure/task/fact_find.shtml)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 10.

- If the client was not contacted, go to step 12.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Calculation .

- Comments: Type “actual hours obtained for the calculation” and indicate who provided the information.

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
             [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Enter the hours obtained into the correct pay periods of the Employment History File .

- Go to step 9 of Calculating a claim in SSO .
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

**Next procedure**

- Determine if the BT requested for the calculation is fishing:

- If yes, refer to Calculating or recalculating a claim for fishing benefits .
             [Calculating or recalculating a claim for fishing benefits](/en/procedure/activity/calc_fish.shtml)

- If no, refer to step 2 of Reviewing the calculation result .
             [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml)

**VBW < Divisor - Insurable earnings credit (1159)**

**What you need to know**

SSO displays this message when the BPC is between September 26, 2021 (w/c 2310) and November 14, 2021 (w/c 2317) and the client has fewer weeks of insurable employment than the divisor.

UIC applies the following formula to ensure that the benefit rate is not negatively affected by having fewer insurable weeks of employment than the divisor.

(Divisor – number of VBWs) × Average weekly insurable earnings

This measure does not apply to fishing and SE claims.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0907.dita) 

**What you need to do**

- Accept this message and go to Next procedure .
         [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/procedure/generic/rcr_screen_messages#next) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_0887.dita`

Note:

When fact-finding about an initial calculation or recalculation using a Government of Canada ROE, refer to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0888.dita`

Note:

For each employer listed, enter the VBW into the Employment History File of the corresponding ROE. If there is more than one ROE from an employer who has been listed only once on the application, ensure the VBW are entered into the appropriate ROE from that employer. 

### Note

Source topic: `en_EN/common_notes/note_c_0889.dita`

Note:

If a client has a violation on file, the number of hours required is greater than 600 hours and the same as the number required for regular benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_0890.dita`

Note:

If a client has a violation on file, the number of hours required is greater than 600 hours and is the same as the number of hours required for regular benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_0891.dita`

Note:

In order to determine if the client qualifies in a week falling between the week requested for the antedate and the week of filing, modify the date indicated in the Antedate to field of the Application Form screen and request a new calculation result. 

### Example

Source topic: `en_EN/common_notes/note_c_0892.dita`

Example:

A claim is calculated with a BPC of September 27, 2015 (w/c 1997) using an ROE that contains the following:

- First day worked: April 13, 2014.

- Last day worked (LDW): September 28, 2015.

- Pay period end date: October 3, 2015.

- Pay period type: Bi-weekly.

The original QP COD was September 28, 2014 (w/c 1945) but due to a QP extension of 15 weeks, the calculation result indicates that the COD is June 15, 2014 (w/c 1930).

The block 15A of the ROE only contains hours from September 21, 2014 to September 28, 2015. Obtaining the hours between June 15, 2014 and September 20, 2014 could result in additional entitlement weeks.

The block 15B of the ROE only contains earnings from March 22, 2015 to September 28, 2015. Obtaining the earnings between June 15, 2014 and March 21, 2015 may result in a higher benefit rate due to variable best weeks. 

### Note

Source topic: `en_EN/common_notes/note_c_0893.dita`

Note:

To make it easier for the employer when you request the additional hours, ask for the information by pay period. If you need 5 weeks of extra hours, ask for the number of pay periods covering those 5 weeks. 

### Callout

Source topic: `en_EN/common_notes/note_c_0894.dita`

“We are writing about your claim for Employment Insurance (EI) benefits.

We extended your qualifying period by [X] weeks, which allows us to consider your insurable employment from [QP start date] to [QP end date]. The qualifying period is the shorter of the 52-week period immediately before the start date of your claim, or the period since the start of your previous claim. However, the qualifying period may be extended if you were not receiving EI benefits and were unable to work for one of the reasons specified in the Employment Insurance Act (for example, illness, injury, pregnancy, authorized course or employment-related activity).

Please provide us your earnings and hours worked for the pay periods between [start date of additional period required] to [end date of additional period required]. You can submit this information about your employment using My Service Canada Account or contact us as indicated below. Providing this information may result in additional weeks of EI benefits or a higher benefit rate.” 

### Note

Source topic: `en_EN/common_notes/note_c_0895.dita`

Note:

When modifying an allocation type W - Earnings week 1 , the officer uses an allocation type A - Amended earnings since an allocation type W - Earnings week 1 cannot be modified. 

### Note

Source topic: `en_EN/common_notes/note_c_0896.dita`

Note:

The unemployment rates available in the database are for the current period. If rates are required for a BPC occurring before the period indicated in the search results (e.g. the BPC is being backdated or antedated to a period before the current unemployment rates displayed), refer to Unemployment Rates for the EI Economic Regions to view a history of the unemployment rates for each economic region and to determine the correct economic region code.
       [Unemployment Rates for the EI Economic Regions](http://srv129.services.gc.ca/eiregions/eng/rates_hist.aspx)

     [Unemployment Rates for the EI Economic Regions](http://srv129.services.gc.ca/eiregions/eng/rates_hist.aspx) 

### Note

Source topic: `en_EN/common_notes/note_c_0897.dita`

Note:

Although it was determined that there were no outstanding adjudication issues while determining if a claim is ready for calculation, a new ROE requiring adjudication may have been submitted since then. 

### Example

Source topic: `en_EN/common_notes/note_c_0898.dita`

Example:

BPC: May 5, 2013 SE QP: January 1, 2012 to December 31, 2012

ROE for part-time insurable employment:

- First day worked: February 12, 2012.

- LDW: November 16, 2012.

- Pay period end date: November 17, 2012

- Pay period type: Bi-weekly.

- 15B contains earnings from May 6, 2012 to November 16, 2012.

- 15C is not completed. 

### Note

Source topic: `en_EN/common_notes/note_c_0899.dita`

Note:

Generally, an extension of the maternity window occurs on an established claim. If the client is entitled to an extension of the maternity window, it is possible that the maternity end week does not reflect the correct end date of the maternity window as the extension is input manually on the M107 after the calculation result is accepted. 

### Note

Source topic: `en_EN/common_notes/note_c_0900.dita`

Note:

If the client is establishing this claim as a subsequent claim to pay the balance of maternity benefits for this birth or if the client is interrupting her maternity benefits early (e.g. a RTW), do not extend the maternity window beyond the date the client is entitled to weeks of maternity benefits for this birth.

If the client did not apply in a timely manner, the officer determines if an antedate is applicable. 

### Note

Source topic: `en_EN/common_notes/note_c_0901.dita`

Note:

The CT requested is displayed in the Claim type field on the Calculation Result screen and must not be mistaken for the Imposed claim type field. 

### Note

Source topic: `en_EN/common_notes/note_c_0717.dita`

Note:

A temporary measure under Pilot Project No. 24 applies to separation monies paid due to a separation from employment on claims with a BPC or allocation start date between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). When separation monies are paid for that period, they are not allocated.

If the monies are paid because of the separation, the officer leaves the date fields of the ROE blank and UIC does not allocate the monies. If the monies are paid for any other reason, the officer enters the appropriate dates in the ROE, and UIC allocates the amounts as usual. 

### Note

Source topic: `en_EN/common_notes/note_c_0902.dita`

Note:

To cancel the claim, the M103 must be input before the M101 - File Control Data (M101) transaction type 7 (M101-7). 

### Note

Source topic: `en_EN/common_notes/note_c_0903.dita`

Note:

When an indefinite recovery week is entered on the Annex - Special Benefits screen, SSO postdates the claim if appropriate because it determines that the maximum of 26 weeks of sickness benefits can be paid. This is the case even when a D16 is being imposed. Entering the missing medical certificate information on the Registration screen and leaving the recovery week blank ensures that the correct BPC is determined, and that the D16 is created. 

### Note

Source topic: `en_EN/common_notes/note_c_0904.dita`

Note:

If the earnings relate to insurable employment, keep the client on the telephone while you complete the steps in Estimating interim ROE information to search for the employer (to confirm there is no doubt of the legitimacy of the employer).
       [Estimating interim ROE information](/en/procedure/task/estimating_interim_roe.shtml)

     [Estimating interim ROE information](/en/procedure/task/estimating_interim_roe.shtml) 

### Example

Source topic: `en_EN/common_notes/note_c_0905.dita`

Example:

2 ROEs on file:

- ROE 1: March 1, 2013 to August 31, 2013, RFS = A

- ROE 2: January 1, 2013 to May 31, 2013 RFS = M and Special Condition field displays Misconduct Proven

In this case, UIC cannot determine how many hours have been accumulated on ROE 1 after the LDW on ROE 2 (from June 1, 2013 to August 31, 2013). 

### Note

Source topic: `en_EN/common_notes/note_c_0906.dita`

Note:

The number of hours for each pay period displayed in the Employment History File is automatically determined by dividing the total number of hours in block 15A of the ROE by the number of days worked in the employment period. The average amount of hours per pay period displayed in the Employment History File is typically different than the actual hours per pay period in block 15C of a SAT ROE. As the actual hours are readily available on the SAT ROE, if the amounts differ, the officer must review block 15C and copy the actual hours per pay period information into the Employment History File . 

### Example

Source topic: `en_EN/common_notes/note_c_0907.dita`

Example:

Client worked for 10 weeks, earning $1 000 per week (total $10 000).

10 VBWs of $1 000

Average weekly insurable earnings = $1 000

Divisor = 14

(14 – 10) × $1 000 = $4 000

Total insurable earnings = $10 000 + $4 000 = $14 000 
