# Calculating or recalculating a claim for regular benefits

Source map: `en_EN/activity/calculation/calculation.ditamap`

## Summary

Source topic: `en_EN/activity/calculation/summary.dita`

Summary: When ACP is unable to automate the calculation of a claim for regular benefits, it must be calculated by an officer. 

## What you need to know

Source topic: `en_EN/activity/calculation/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/activity/calculation/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Manually calculating a claim

Source topic: `en_EN/activity/calculation/manually_calculating_a_claim.dita`

The manual calculation of a claim is complex and must only be done by a trained officer.

An officer must calculate or recalculate a claim when:

- a client applies for benefits using a paper application;

- ACP is unable to automate an electronic application;

- a claim requires a recalculation and ACP is unable to automate the recalculation. 

### Post-EI Emergency Response Benefit (EI ERB) claims

Source topic: `en_EN/activity/calculation/post-ei_emergency_response_benefit_ei_erb_claims.dita`

A client who received all 28 weeks of the EI ERB and meets the required criteria is automatically enrolled for EI benefits. In NWS, a paper application appears on the Client information tree of automatically enrolled claims. To calculate the claim, the officer uses the most recent application on file, which can date as far back as March 4, 2020.

Automatically enrolled claims are always registered as regular benefits because in most cases, it has been 28 weeks or more since the most recent application for the EI ERB. The claim should remain a claim for regular benefits unless the most recent information on file indicates otherwise or the officer is fact-finding and the client requests another benefit type (BT). Automatically enrolled claims that are finalized through the specialized ACP process are always established as claims for regular benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0043.dita) 

All new applications received for regular benefits with BPC w/c 2258 or later, including all automatically enrolled claims, are processed using interim measures to speed up the calculation process.

When the specialized ACP process creates a CA WI, no other WIs will be created. The officer must review the most recent application to determine if further action is required before finalizing the calculation. 

### Calculation versus recalculation

Source topic: `en_EN/activity/calculation/calculation_versus_recalculation.dita`

When a Claim Assessment (CA) or Specialized Application (SA) WI is received, the officer must complete the initial calculation of a claim.

When a Claim Review (CR) WI with a recalculation issue is received, the officer must complete a new calculation of a previously finalized claim. A recalculation is sometimes referred to as a “recomp.” Once an initial calculation is successfully transmitted, a claim must be recalculated when new information is received that will have an effect on the previous calculation result (e.g. an amended ROE is issued).

When a recalculation is required for an Integrity case, an urgent Action Item (AI) WI is created for the recalculation. The officer assigned to this WI must complete the recalculation.

The recalculation of a claim can affect the following:

- the client’s ability to establish a benefit period (BP);
         [benefit period](/en/procedure/generic/knowledge.shtml#Establishing_a_benefit_period)

- the client’s entitlement to benefits;

- the client’s benefit rate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0054.dita) 

### Recalculating a claim affected by a SIN or region change

Source topic: `en_EN/activity/calculation/recalculating_a_claim_affected_by_a_sin_5e2e09cf.dita`

If the client has moved to a different region, changed SINs, or both, since the initial claim was calculated, registering the recalculation in SSO may not be possible. The recalculation must be registered under the original information technology centre (ITC) and SIN when necessary, but must be transmitted manually in FTS under the current ITC and new SIN, if applicable.

For more information, the officer refers to the Appendices B, C and D of the Recalculation input guide - SSA version .
       [Recalculation input guide - SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml) 

### Structure of calculation procedures

Source topic: `en_EN/activity/calculation/structure_of_calculation_procedures.dita`

The calculation procedure is divided into sub-activities to provide a logical sequence to follow when calculating a claim. Although individual officers may have a preferred sequence that is also correct, the procedure is structured to ensure the officer completes all the actions required to process the claim:

- Determining if the claim is ready to be calculated.

- Calculating a claim in SSO.

- Reviewing the calculation result.

- Reviewing and inputting the calculation.

- Communicating decisions after calculation.

Within each sub-activity, there are links to additional procedures that may be required to complete the calculation process. 

### Managing the WI

Source topic: `en_EN/activity/calculation/managing_the_wi.dita`

Regardless of how an officer organizes the work, the officer assigned to complete the calculation of a claim must ensure that any issues are addressed and all the facts required to calculate the claim are on file before completing the calculation. Unless otherwise noted in the procedures, the calculation must not be completed until all related WIs necessary to finalize the calculation are completed. If the calculation cannot be completed because of an outstanding related WI, the WI for the calculation is moved to Pending until the related WI is completed.

Multiple officers may be assigned WIs for the same claim being assessed (e.g. one officer is assigned an ROE RFS Action WI and one is assigned the CA WI). The officers complete only the WI to which they are assigned unless instructed otherwise by a procedure.

When assessing the claim, the officer assigned the calculation must also review any client Note for actions required (e.g. inputting transactions, sending letters).

When the calculation is complete, the officer must communicate the decision to the client as necessary. 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/activity/calculation/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an AI, Call Back (CB), Assessment Issue (ASMT) or Reminder (REM) WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### Establishing a claim for regular benefits

Source topic: `en_EN/activity/calculation/establishing_a_claim_for_regular_benefits.dita`

To establish a claim for regular benefits, a client must meet the following conditions:

- The client has applied for benefits.

- The client has had an interruption of earnings (I of E) in the qualifying period (QP) .
         [interruption of earnings (I of E)](/en/procedure/generic/knowledge.shtml#Interruption_of_earnings) 
         [qualifying period (QP)](/en/procedure/generic/knowledge.shtml#Qualifying_period)

- The client has the required number of insured hours in the QP.
         [required number of insured hours](http://srv129.services.gc.ca/eiregions/eng/rates_cur.aspx)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0021.dita) 

### Paying benefits

Source topic: `en_EN/activity/calculation/paying_benefits.dita`

The number of weeks of regular entitlement is determined by:

- the number of insured hours in the QP

- the regional rate of unemployment (RRU) for the area where the client resides at the time of the BPC
         [regional rate of unemployment (RRU)](/en/procedure/generic/knowledge.shtml#RRU)

The number of weeks of regular entitlement varies from 14 weeks to a maximum of 45 weeks according to Schedule 1 of the EIA .
       [Schedule 1 of the EIA](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/FullText.html#h-72)

Weeks of benefits payable must be collected within the BP. If weeks of special benefits are paid during a benefit period, a client may not be able to collect the full weeks of regular entitlement.

Once the claim is established and it is determined that regular benefits are payable, regular benefits are payable for each week the client submits a claimant’s report and:

- is unemployed

- is ready, willing and capable of work

- does not have earnings or allocations preventing payment

- does not have a disentitlement or disqualification preventing payment 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_0043.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP reverts to regular registration and calculation processes. However, the officer continues to complete outstanding WIs that were created by the specialized process before August 16, 2021 using specialized procedures. 

### Note

Source topic: `en_EN/common_notes/note_c_0054.dita`

Note:

When the recalculation of a claim is required, the officer follows the normal calculation assessment procedures and refers to Recalculation: Assessment — Instructions and the Recalculation input guide - SSA version if necessary. A claim requiring a recalculation must be assessed in the same manner as a claim requiring an initial calculation.
       [Recalculation: Assessment — Instructions](/en/procedure/generic/additionalresources/recalculation_assessment.shtml) 
       [Recalculation input guide - SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml)

     [Recalculation: Assessment — Instructions](/en/procedure/generic/additionalresources/recalculation_assessment.shtml) 
     [Recalculation input guide - SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0021.dita`

Note:

If the client has a violation, there may be increased entrance requirements .
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

## Regional considerations

Source topic: `en_EN/activity/calculation/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/calculation/what_you_need_to_look_for.dita`

## What do you want to do?

Source topic: `en_EN/activity/calculation/what_do_you_want_to_do.dita`

- Determining if a claim is ready to be calculated — Regular benefits
         [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- Calculating a claim in SSO
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Reviewing the calculation result
         [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml)

- Reviewing and inputting the calculation
         [Reviewing and inputting the calculation](/en/procedure/subactivity/input_calculation_results.shtml)

- Communicating decisions after calculation
         [Communicating decisions after calculation](/en/procedure/subactivity/communicating_calc_decisions.shtml) 

## Policy reference

Source topic: `en_EN/activity/calculation/policy_reference.dita`

 
