# Labour dispute

Source map: `en_EN/activity/labour_dispute/labour_dispute.ditamap`

## Summary

Source topic: `en_EN/activity/labour_dispute/summary.dita`

Summary: When clients stop working due to a labour dispute, their entitlement to benefits may be affected. The officer must review the regional decision and, if required, must adjudicate entitlement to benefits. 

## What you need to know

Source topic: `en_EN/activity/labour_dispute/what_you_need_to_know.dita`

### Entitlement to benefits during a labour dispute

Source topic: `en_EN/activity/labour_dispute/entitlement_to_benefits_during_a_labour_dispute.dita`

A labour dispute is any dispute between employers and employees, or between the employees themselves. A labour dispute can be related to employment or non-employment, or to the terms and conditions of employment.

Regardless of whether the labour dispute was initiated by a strike or a lockout, the impact on the claim remains the same. When clients lose their employment or are unable to return to work due to a work stoppage resulting from a labour dispute at their place of employment, they are not entitled to EI benefits under the EIA.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0123.dita) 

### Adjudicating a labour dispute

Source topic: `en_EN/activity/labour_dispute/adjudicating_a_labour_dispute.dita`

All decisions made regarding a labour dispute are completed by the appropriate regional labour dispute coordinator.

The regional coordinator ensures that the initial fact-finding and decisions regarding labour disputes (e.g. start and end dates, dates of disentitlement and any exemptions from disentitlement) are made and posted in the Major Employer Events .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

If a labour dispute has not yet been identified and entered in the Major Employer Events , the officer completes and emails the Labour dispute initial information form to the regional labour dispute coordinator serving the area where the employer’s head office is based.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
       [regional labour dispute coordinator](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0124.dita) 

If the labour dispute has been posted in Major Employer Events and officers require assistance determining entitlement, they contact their regional Business Expertise.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Since a labour dispute is a temporary situation, the officer imposes a 5 - Labour dispute disentitlement (D5) rather than a disqualification.

The D5 is imposed to indicate the period of the labour dispute. The client is disentitled for any days of work stoppage due to a labour dispute during the benefit period (BP) until one of the following occurs:

- The labour dispute ends.

- The client becomes regularly engaged elsewhere in insurable employment.

Clients are not disentitled from benefits if they prove that all of the following conditions are met:

- They are not participating in the labour dispute.

- They are not financing the labour dispute.

- They have no direct interest in the labour dispute. 

### Calculating the disentitlement for a part-time employee

Source topic: `en_EN/activity/labour_dispute/calculating_the_disentitlement_for_a_pa_6c72116b.dita`

When a client loses or is unable to resume part-time employment due to a labour dispute, the officer must calculate the number of days of disentitlement to impose per week.

The officer must create an Operational Centre Memo (MM06) to advise IPOC to impose the part-time disentitlement. 

### Levels of decision

Source topic: `en_EN/activity/labour_dispute/levels_of_decision.dita`

The Level 1 officer can implement the decision made by the regional coordinator on whether to impose a disentitlement or to allow benefits for clients who lost their employment because of a work stoppage at their place of employment when all the following conditions are met:

- The decision is readily apparent;

- No additional fact-finding is required;

- According to the fact-finding related to this decision, it is clearly established who this decision applies to.

If a Level 1 officer cannot implement the decision made by the regional coordinator, the officer refers the RFS to Level 2 for adjudication.

If the client is applying for special benefits or is participating in Section 25 training, the officer reassigns the WI to Level 2 for adjudication. 

### Terminating a labour dispute disentitlement

Source topic: `en_EN/activity/labour_dispute/terminating_a_labour_dispute_disentitlement.dita`

A D5 is terminated on the day before the date on which the labour dispute ends or on the day before the date on which the client became regularly employed elsewhere in insurable employment. Review of the Major Employer Events is required.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

When a client begins working elsewhere during a labour dispute, a Level 2 officer must render a decision on whether the D5 can be terminated. Both of the following conditions must be met for the D5 to be terminated:

- The employment is insurable;

- The client becomes regularly engaged in insurable employment at a place other than where the labour dispute exists.

For more information, refer to Digest 8 — Labour disputes .
       [Digest 8 — Labour disputes](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.html) 

### Note

Source topic: `en_EN/common_notes/note_c_0123.dita`

Note:

When the reason for separation (RFS) on the ROE is Strike or Lockout , the initial claim is not automated and a Claim Assessment (CA) WI is created. 

### Note

Source topic: `en_EN/common_notes/note_c_0124.dita`

Note:

If the employer’s head office is located in the Western Canada and Territories region and a labour dispute has not been entered in Major Employer Events , officers working in the Western Canada and Territories region send the Labour dispute initial information form to the Technical Expertise Request Application (TERA), not to the regional coordinator.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx)

Officers in all other regions email the Labour dispute initial information form only to the regional labour dispute coordinator for the region where the employer’s head office is located, via the regional Business Expertise Consultant’s GD mailbox.
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
       [regional labour dispute coordinator](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml)

     [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
     [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
     [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
     [regional labour dispute coordinator](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml) 

## Regional considerations

Source topic: `en_EN/activity/labour_dispute/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/labour_dispute/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/activity/labour_dispute/in_nws.dita`

- Are there any SROCs, RODs or WIs containing documents relating to the labour dispute?

- Are there any documents relating to the labour dispute? 

### In FTS:

Source topic: `en_EN/activity/labour_dispute/in_fts.dita`

- Is there a D5 disentitlement already on file?

- Is there a 74 - Labour dispute manual action (MA74) imposed on the file? 

### In Imaging:

Source topic: `en_EN/activity/labour_dispute/in_imaging.dita`

- Are there any imaged documents relating to the labour dispute? 

### Major Employer Events:

Source topic: `en_EN/activity/labour_dispute/major_employer_events.dita`

- Is there any information relating to the labour dispute? 

## What do you want to do?

Source topic: `en_EN/activity/labour_dispute/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/labour_dispute/policy_reference.dita`

 
