# Medical certificate — Sickness benefits

Source map: `en_EN/activity/med_cert_sb/med_cert_sb.ditamap`

## Summary

Source topic: `en_EN/activity/med_cert_sb/summary.dita`

Summary: Clients requesting sickness benefits must be able to provide a medical certificate which proves their inability to work due to illness. 

## What you need to know

Source topic: `en_EN/activity/med_cert_sb/what_you_need_to_know.dita`

### Determining if a medical certificate is acceptable

Source topic: `en_EN/activity/med_cert_sb/determining_if_a_medical_certificate_is_8af4656a.dita`

Clients must obtain, at their own expense, an acceptable medical certificate for every week they request sickness benefits ( EIR 40[1] ). The medical certificate must show that a client is unable to work because of illness, injury or quarantine. The medical certificate must attest to the incapacity. In certain situations, the start date and probable duration of the incapacity must be provided. The medical certificate must be signed by a doctor or other medical practitioner.
       [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml) 
       [EIR 40[1]](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-40.html) 
       [start date](/en/procedure/generic/additionalresources/incapacity_start_date_sb.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0130.dita) 

**Requesting translation of a medical certificate**

An acceptable medical certificate must be completed in English or French. If the medical certificate is completed in any other language, the agent must send it for translation. Refer to Sending a medical certificate for translation .
       [Sending a medical certificate for translation](/en/procedure/task/med_cert_translation.shtml) 

### Determining if a medical certificate is required

Source topic: `en_EN/activity/med_cert_sb/determining_if_a_medical_certificate_is_required.dita`

The client is not always required to submit the medical certificate to receive sickness benefits. When applying for sickness benefits, the client must agree to obtain a medical certificate from a doctor, or other acceptable medical proof, that confirms illness or incapacity during the period for which sickness benefits are requested.

Clients applying for sickness benefits using AW can upload the medical certificate immediately. If clients do not submit the medical certificate and the last RFS is illness, clients are advised that it must be submitted if the duration of the illness or injury is greater than 9 weeks. Otherwise, clients are advised to keep the medical certificate for 6 years since it can be requested at a later date. Clients applying for sickness benefits using AW who indicate an RFS other than illness are advised to submit the medical certificate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0045.dita) 

When a client requests weeks of sickness benefits beyond the current recovery date on the claim, or for a period for which a 16 - No medical certificate submitted (D16) disentitlement has been imposed, the client must provide a new acceptable medical certificate as proof of incapacity.

**Imposing a disentitlement**

If a client must submit an acceptable medical certificate but does not, the agent imposes a D16. 

### Note

Source topic: `en_EN/common_notes/note_c_0130.dita`

Note:

The client must pay any costs associated with obtaining a medical certificate. If a client or doctor sends a bill to a Service Canada Centre for a completed medical certificate, the agent returns it to the client. 

### Note

Source topic: `en_EN/common_notes/note_c_0045.dita`

Note:

When a medical certificate is uploaded, the officer or the client must complete a Medical Certificate electronic questionnaire. The electronic questionnaire is not medical proof. The officer does not use it to determine a recovery week or period of incapacity. 

## Regional considerations

Source topic: `en_EN/activity/med_cert_sb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/med_cert_sb/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/activity/med_cert_sb/in_fts.dita`

- Is there a D16 on file?

- Is the client currently receiving sickness benefits? 

### In NWS:

Source topic: `en_EN/activity/med_cert_sb/in_nws.dita`

- Is there an SROC or Action Item WI with a medical certificate transcribed, or has a medical certificate been uploaded?

- If yes, what is the incapacity start date, duration or end date?

- If yes, is the medical certificate written in English or French? 

### In Imaging:

Source topic: `en_EN/activity/med_cert_sb/in_imaging.dita`

- Is there a medical certificate?

- If yes, what is the incapacity start date, duration or end date?

- If yes, is the medical certificate written in English or French? 

## What do you want to do?

Source topic: `en_EN/activity/med_cert_sb/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/med_cert_sb/policy_reference.dita`

 
