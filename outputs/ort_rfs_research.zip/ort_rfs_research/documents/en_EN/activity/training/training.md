# Training

Source map: `en_EN/activity/training/training.ditamap`

## Summary

Source topic: `en_EN/activity/training/summary.dita`

Summary: Clients may report that they are attending training at any time during the life of a claim and adjudication is required to determine entitlement to benefits during the training period. 

## What you need to know

Source topic: `en_EN/activity/training/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/activity/training/training_reported_between_september_27__5ecd71c7.dita`

A transitional measure under which ACP automatically adjudicated and allowed all training effective September 27, 2020 has ended on September 11, 2021.

The intent of this measure was to prevent any delay in payment to clients who reported training. For regular benefits, clients must still be able to prove that they are capable of and available for work while attending non-referred training.

Service Canada has the authority to impose a retroactive 3 - Not available disentitlement (D3) if the client is unable to prove availability, even if ACP initially allowed the training. Therefore, if the client reports not being available while attending non-referred training, and benefits were previously paid for this period, the officer reviews the client’s availability. When the Level 2 officer determines that the client has not proven availability from the start date of the course, the officer imposes a retroactive D3. The officer refers to BE 2020-05 — Emergency Response Benefit Transition Provisions , Digest 10.3 — Credibility and 10.12 — Courses of instruction/employment measures for more information on availability.
       [BE 2020-05 — Emergency Response Benefit Transition Provisions](/en/policy/bememo/be2020-05.shtml) 
       [10.3 — Credibility](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/credibility.shtml#a10_3_0) 
       [10.12 — Courses of instruction/employment measures](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_0)

For special benefits, the client must still meet the entitlement conditions for the requested benefit type (BT) while attending non-referred training. A client attending non-referred training may provide information on a claimant’s report or during a conversation with an officer that brings into question the entitlement to special benefits. In this case, the officer creates a WI for the training issue and follows normal adjudication procedures, even if ACP initially allowed the training. 

### Types of training

Source topic: `en_EN/activity/training/types_of_training.dita`

There are 3 main ways to classify training for EI purposes:

- Non-referred training is a course or program of instruction taken on the client’s own initiative, without approval or referral by a designated referring authority. Training can be at a college or university or any other training provider.

- Referred training is a course or program of instruction taken by the client, or participation in any other employment activity, when referred by a designated authority (provinces, territories or Service Canada) and approved under EIA 25 . The client must provide the following details:

- name and contact information for the training counsellor or referring authority

- start and end dates of the referred training

- name of the school or training institution

         [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/section-25.html)

- Apprenticeship is a formal training program of skills acquisition in a trade, consisting of alternating periods of on-the-job and classroom training, and leading to certification as a journey person. The client must provide the following details:

- 16-digit reference code which identifies the apprenticeship training course

- start and end dates of the course

- name of the school or training institution

The training must be accurately classified to ensure the client’s entitlement to benefits is correctly determined. When clients state that they have been referred to training, but have not provided the required information, the officer conducts fact-finding to confirm that they actually have been referred to this training and to obtain the missing information. 

### Non-referred training

Source topic: `en_EN/activity/training/non-referred_training.dita`

Participating in a non-referred training course can affect whether a client meets the entitlement conditions for the following BTs:

- regular benefits

- sickness benefits

- parental benefits

- CCB

- family caregiver benefits

Participating in a non-referred training course does not affect a client’s entitlement to maternity benefits. However, appropriate procedures must be followed to ensure that the correct documentation is on file, and that the claim is processed properly. If the claim is for CCB, or for maternity benefits only, an electronic questionnaire is not created in AW when the client reports training. Also, MSCA-EI does not display a link to the electronic training questionnaire. Therefore, notification of training is received only if the client provides documentation or a training questionnaire, or if the client speaks directly to an officer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0158.dita) 

If the claim is for a combination of maternity and parental benefits, the questionnaire is created, and the officer must determine if the training is offered only during the maternity period.

When clients receiving regular benefits report that they are not available and do not wish to receive EI benefits for the period of the non-referred training, a Level 1 officer can impose a D3 if the following conditions exist:

- the training is full-time on consecutive weekdays for up to 2 weeks

- the client agrees that no benefits are payable

When clients declare that they are not available and do not agree that no benefits are payable, a Level 2 officer must review the entitlement.

Clients may report that they have received on-the-job training through an employer:

- If the client earns regular wages for the training and the training is not adjudicated as non-referred training, the client must report the hours and earnings on the claimant’s report, and should not report it as training.

- If the client does not earn regular wages for the training, the training is adjudicated as non-referred training and according to the BT.

Clients who report being out of Canada while attending non-referred training, including periods in which a portion of the training is outside Canada, must meet the entitlement conditions to receive benefits while outside Canada. Refer to Out of Canada to determine a client’s entitlement to benefits while outside Canada.
       [Out of Canada](/en/procedure/activity/out_canada.shtml)

**Targeted initiatives and short-term training courses**

Clients who have lost their job or who have been absent from the workforce for long periods of time may take part in a targeted initiative to help them return to the workforce. Clients may also attend a short-term training course to increase their employability in the labour market.

Even though targeted initiatives are not training courses, officers adjudicate a client’s availability in the same manner as with any client who is attending a non-referred training course.

Short-term training courses refer to courses which are offered within the client’s region. Their purpose is to increase a client’s skills for existing employment, or to increase a client’s employability in the labour market. Special short-term courses are sometimes created in different provinces to help develop certain labour market areas. These courses can be approved based on specific criteria that are communicated when courses are available.

Since the purpose of targeted initiatives and short-term training courses is to help a client reintegrate into the workforce, the officer is more tolerant when adjudicating the client’s availability while attending the course.

The officer refers to the job aid for a complete list of non-referred targeted initiatives and short-term courses.
       [job aid](/en/procedure/generic/additionalresources/shortterm_courses_ti.shtml) 

### Referred training

Source topic: `en_EN/activity/training/referred_training.dita`

The Government of Canada works with the provinces and territories to deliver employment programs known as employment benefits and support measures. Labour market development agreements (LMDAs) with the Canada Employment Insurance Commission define the degree of responsibility assumed by each province or territory for the delivery of these programs.
       [Canada Employment Insurance Commission](https://www.canada.ca/en/employment-social-development/corporate/portfolio/ei-commission.html)

The existing LMDAs vary in each of the provinces and territories. Each agreement outlines the responsibilities of the parties involved and how the monies are administered.

The Indigenous Skills and Employment Training Program delivers training-related employment programs by various indigenous groups for indigenous individuals.

To be considered attending referred training, the client must be referred to the training by a designated authority.

The LMDAAccess Module of EIBIS is used by the referring authority of the province, territory or Indigenous Skills and Employment Training Program to obtain the client’s EI status, to input the referred training information or, in some cases, to indicate the intent to refer the client to training in the future. The officer views the Notice of Intent and proposed training details in the LMDAAccess Module . If the client is receiving special benefits and is approved under EIA 25 , the referring authority cannot input the referral information and must use alternate methods of communication.
       [LMDAAccess Module](https://sipae-eibis.service.gc.ca/) 
       [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/section-25.html)

The Skills Boost Initiative (also called the Life-long Learning Initiative) allows long-tenured workers to continue receiving their EI benefits while attending self-funded full-time training (e.g. courses, programs of instruction and in-person or virtual training) to improve their qualifications and skills. This permanent initiative applies to clients attending training on August 5, 2018 or after.

When clients request permission to attend training, the officer processes the request as if they were asking to be referred to training under EIA 25 .
       [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/section-25.html)

If referred to a training course by Service Canada, or by the province or territory in the case of an LMDA, as defined in EIA 25 , clients are considered to be unemployed, and capable of and available for work while they are participating in the course. In the case of special benefits, clients can continue to receive special benefits while on referred training as long as the eligible clients meet the entitlement conditions of the special benefits being claimed.
       [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/section-25.html)

When clients are authorized by a designated provincial authority to quit their employment to pursue referred training, they are provided with a Request for Authorization to Quit Employment form to submit with their application for EI benefits.

**Long-tenured workers**

A client who reports attending full-time training may be identified as a long-tenured worker. If the conditions are met, a client who is identified as a long-tenured worker and who wishes to attend self-funded full-time training can be referred to that training by Service Canada.

To be considered a long-tenured worker, a client must meet the following 2 conditions:

- have paid at least 30% of the maximum EI premiums for at least 7 of the last 10 years;

- not have received more than 35 weeks of regular benefits in the last 156 weeks (3 years) before the BPC of the current claim.

Service Canada has the authority to approve full-time training for a long-tenured worker. However, before adjudicating training, the officer adjudicates other contentious issues to determine if the client is entitled to benefits. This can help the client better understand the decision-making process, as the client may assume that for a referred training situation, contentious issues are automatically allowed.

When a client is identified as a long-tenured worker, the officer refers to the appropriate task for adjudicating training for a long-tenured worker.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0159.dita) 

**Self-Employment Benefits Program**

Any training that clients participating in the Self-Employment Benefits Program attend is considered an integral part of the program. No adjudication is required. Clients are advised not to declare training on their claimant’s reports while participating in the program. Only the Self-Employment Benefits Program information is indicated on the Project tab in FTS. 

### Apprenticeships

Source topic: `en_EN/activity/training/apprenticeships.dita`

An apprenticeship is a formal training program of skills acquisition in a trade, consisting of alternating periods of on-the-job and classroom training and leading to certification as a journey person.

Each province and territory has its own government office that oversees apprenticeship training and certification for that province or territory. Registered apprentices are normally already employed full-time or part-time with an employer or through a union that agrees to sponsor and train them as an apprentice in a specific skilled trade.

Clients must be referred to apprenticeship training by a designated authority.

Clients can either be a registered apprentice within their provincial apprenticeship branch or be referred to training by a designated provincial authority. When clients are authorized by a designated provincial authority to quit their employment to pursue apprenticeship training, they are provided with a Request for Authorization to Quit Employment form to submit with their application for EI benefits.

When clients are referred to apprenticeship training and are enrolled in a training session, a 16-digit reference code is provided by Service Canada or the province in the case of the LMDA, or by a designated authority (provincial apprenticeship branch). This code must be used to apply for EI benefits. When the reference code is entered, the client is presented with a specialized application that allows ACP to input the apprenticeship information on the Project tab in FTS. To determine if the claim can be automated, ACP also verifies if the ROE has a reason for separation (RFS) of J - Apprentice Training or A - Shortage of work . 

### End of training

Source topic: `en_EN/activity/training/end_of_training.dita`

At the end of non-referred training, the client’s entitlement to benefits must be reviewed. Adjudication may be required or, if imposed for the training period, an indefinite disentitlement may need to be terminated.

Referred training is approved for a set period of time and the referring authority provides the end date. If the client stops attending the course before the end date without approval from the referring authority, the client’s entitlement to benefits must be reviewed.

At the end of apprenticeship training, the client’s entitlement to benefits must be reviewed, as clients are usually still employed and are temporarily leaving their employment to attend the apprenticeship course. It is assumed that clients will return to work for the most recent employer at the end of the training. If the client is not returning to work, a conversion may be required, and the RFS may need to be adjudicated. Refer to Conversion and renewal .
       [conversion](/en/procedure/activity/conversions.shtml) 
       [Conversion and renewal](/en/procedure/activity/conversions.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0158.dita`

Note:

If the claim is for CCB, the officer cannot currently create an Adjudication Issue (ADJ) Training WI. When a client receiving CCB reports training, the officer creates an ADJ Availability WI and indicates in the Details field that the issue is actually training. This workaround applies until a system update is done to allow:

- the client to report training on the EI application;

- the client to complete an electronic training course questionnaire for a claim for CCB;

- the officer to create an ADJ Training WI on a claim for CCB. 

### Note

Source topic: `en_EN/common_notes/note_c_0159.dita`

Note:

To determine if a client is a long-tenured worker, the officer refers to Determining if a client is a long-tenured worker .
       [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml)

     [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml) 

## Regional considerations

Source topic: `en_EN/activity/training/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/training/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/activity/training/in_fts.dita`

- What is the BT?

- Is this an initial, renewal or continuing claim?

- Is there training information on the Project tab? 

### In NWS:

Source topic: `en_EN/activity/training/in_nws.dita`

- Is there an ADJ WI (initial or renewal claim) or a Claim Review (CR) WI (continuing claim) for the training issue?

- Is there a valid reference code on the EI application or on any SROCs or WIs?

- Are there any WIs, SROCs or RODs indicating the type of training (referred, for long-tenured workers, non-referred or apprenticeship)? 

### In RCM:

Source topic: `en_EN/activity/training/in_rcm.dita`

- Is the RFS on the ROE either J - Apprentice Training or A - Shortage of work ? 

### In Imaging:

Source topic: `en_EN/activity/training/in_imaging.dita`

- Are there any documents relating to the training? 

## What do you want to do?

Source topic: `en_EN/activity/training/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/training/policy_reference.dita`

 
