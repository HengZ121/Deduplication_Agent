# Calculating or recalculating a claim for maternity and parental benefits

Source map: `en_EN/activity/calc_mat_par/calc_mat_par.ditamap`

## Summary

Source topic: `en_EN/activity/calc_mat_par/summary.dita`

Summary: When ACP is unable to automate the calculation of a claim for maternity benefits, or a combination of maternity and parental benefits, it must be calculated by an officer. 

## What you need to know

Source topic: `en_EN/activity/calc_mat_par/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/activity/calc_mat_par/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Manually calculating a claim

Source topic: `en_EN/activity/calc_mat_par/manually_calculating_a_claim.dita`

The manual calculation of a claim is complex and must only be done by a trained officer.

An officer must calculate or recalculate a claim when:

- when a client applies for benefits using a paper application;

- when ACP is unable to automate an electronic application;

- when a claim requires a recalculation and ACP is unable to automate the recalculation. 

### Calculation versus recalculation

Source topic: `en_EN/activity/calc_mat_par/calculation_versus_recalculation.dita`

When a Claim Assessment (CA) or Specialized Application (SA) WI is received, the officer must complete the initial calculation of a claim.

When a Claim Review (CR) WI with a recalculation issue is received, the officer must complete a new calculation of a previously finalized claim. A recalculation is sometimes referred to as a “recomp.” Once an initial calculation is successfully transmitted, a claim must be recalculated when new information is received that will have an effect on the previous calculation result (e.g. an amended ROE is issued).

When a recalculation is required for an Integrity case, an urgent Action Item (AI) WI is created for the recalculation. The officer assigned to this WI must complete the recalculation.

The recalculation of a claim can affect the following:

- the client’s ability to establish a benefit period (BP);
         [benefit period](/en/procedure/generic/knowledge.shtml#Establishing_a_benefit_period)

- the client’s entitlement to benefits;

- the client’s benefit rate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0020.dita) 

### Recalculating a claim affected by a SIN or region change

Source topic: `en_EN/activity/calc_mat_par/recalculating_a_claim_affected_by_a_sin_5e2e09cf.dita`

If the client has moved to a different region, changed SINs, or both, since the initial claim was calculated, registering the recalculation in SSO may not be possible. The recalculation must be registered under the original information technology centre (ITC) and SIN when necessary, but must be transmitted manually in FTS under the current ITC and new SIN, if applicable.

For more information, the officer refers to the Appendices B, C and D of the Recalculation input guide – SSA version .
       [Recalculation input guide – SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml) 

### Structure of calculation procedures

Source topic: `en_EN/activity/calc_mat_par/structure_of_calculation_procedures.dita`

The calculation procedure is divided into sub-activities to provide a logical sequence to follow when calculating a claim. Although individual officers may have a preferred sequence that is also correct, the procedure is structured to ensure the officer completes all the actions required to process the claim:

- Determining if a claim is ready to be calculated.

- Calculating a claim in SSO.

- Reviewing the calculation result.

- Reviewing and inputting the calculation.

- Communicating decisions after calculation.

Within each sub-activity, there are links to additional procedures that may be required to complete the calculation process. 

### Managing the WI

Source topic: `en_EN/activity/calc_mat_par/managing_the_wi.dita`

Regardless of how an officer organizes the work, the officer assigned to complete the calculation of a claim must ensure that any issues are addressed and all the facts required to calculate the claim are on file before completing the calculation. Unless otherwise noted in the procedures, the CA WI must not be completed until all related WIs necessary to finalize the calculation are completed. If the calculation cannot be completed because of an outstanding related WI, the WI for the calculation is moved to Pending until the related WI is completed.

Multiple officers may be assigned WIs for the same claim being assessed (e.g. one officer is assigned an ROE reason for separation [RFS] Action WI and one is assigned the CA WI). The officers complete only the WI to which they are assigned unless instructed otherwise by a procedure.

When assessing the claim, the officer assigned the calculation must also review any client Note for actions required (e.g. inputting transactions, sending letters).

When the calculation is complete, the officer must communicate the decision to the client as necessary.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0024.dita) 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/activity/calc_mat_par/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an AI, Call Back (CB), Assessment Issue (ASMT) or Reminder (REM) WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### Qualifying for maternity and parental benefits

Source topic: `en_EN/activity/calc_mat_par/qualifying_for_maternity_and_parental_benefits.dita`

To qualify for maternity benefits, or a combination of maternity and parental benefits, a client must meet the following conditions:

- The client has applied for benefits.

- The client has had an interruption of earnings (I of E) in the qualifying period (QP).
         [interruption of earnings](/en/procedure/generic/knowledge.shtml#Interruption_of_earnings) 
         [qualifying period](/en/procedure/generic/knowledge.shtml#Qualifying_period)

- The client is major attached (has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0025.dita) 

**Qualifying for benefits with the common entrance requirement (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national common entrance requirement of 420 hours of insurable employment is required to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The common entrance requirement applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to maternity and parental benefits

Source topic: `en_EN/activity/calc_mat_par/entitlement_to_maternity_and_parental_benefits.dita`

To be entitled to maternity benefits, or a combination of maternity and parental benefits, a client must meet the following conditions:

- The client is able to provide proof of her pregnancy.

- If the client is applying for parental benefits, the client is able to provide proof of birth, adoption or placement.

- The client requests the benefits during the maternity and parental windows.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0026.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0027.dita) 

A major attached client is entitled to receive special benefits regardless of the RFS.
       [special benefits](/en/procedure/generic/knowledge.shtml#Special_Benefits)

An administrative disentitlement is imposed to prevent the payment of regular benefits for a client who qualifies for special benefits but not for regular benefits.

**Proof of pregnancy**

As proof of the pregnancy, the client must provide a signed statement attesting to her pregnancy and her expected date of birth (DOB). The attestation at the end of an AW application is accepted as a signed statement. A completed and signed Maternity or parental: INS5168 Annex 3 — Form is also accepted as proof of pregnancy. If the officer completes the INS5168 form with the client, a verbal attestation is not acceptable. The officer mails the INS5168 form to the client to sign and return. The client must also advise Service Canada of the actual DOB as soon as possible.
       [Maternity or parental: INS5168 Annex 3 — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5168.pdf)

**Proof of birth, adoption or placement**

Parents must supply proof of birth, adoption or placement depending on their relationship to the child or children. For more information, the officer can refer to Parents: Definition — Table .
       [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0028.dita) 

### Maternity window

Source topic: `en_EN/activity/calc_mat_par/maternity_window.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0029.dita) 

The maternity window is the period during which maternity benefits can be paid. The maternity window starts on the earlier of the following dates:

- 12 weeks before the expected DOB (expected DOB – 12 weeks);

- the actual DOB.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0030.dita) 

The maternity window ends on the later of the following dates:

- 17 weeks after the expected DOB (expected DOB + 17 weeks);

- 17 weeks after the actual DOB (actual DOB + 17 weeks).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0031.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0032.dita) 

### Parental window (PW)

Source topic: `en_EN/activity/calc_mat_par/parental_window_pw.dita`

The parental window (PW) is the period during which parental benefits can be paid. The PW starts and ends as follows:

- Start week:

- The arrival or placement week (APW) is determined by the parent’s relationship to the child. For more information, the officer can refer to Parents: Definition — Table .
             [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

- End week:

- For standard parental benefits, the end week is 52 weeks after the APW (APW + 52).

- For extended parental benefits, the end week is 78 weeks after the APW (APW + 78)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0033.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0034.dita) 

### Payment of benefits

Source topic: `en_EN/activity/calc_mat_par/payment_of_benefits.dita`

Maternity benefits can be paid for a maximum of 15 weeks in a BP. The 15 weeks payable for a single pregnancy can be paid over 2 BPs. Maternity benefits are not payable outside of the maternity window. The payment of maternity benefits occurs automatically based on the maternity window if the entitlement conditions are met.

Once the claim is established and it is determined that maternity benefits are payable, maternity benefits are payable for each week the client submits a claimant’s report and:

- declares 5 non-available days

- has provided the required proof for maternity benefits

- does not have earnings or allocations preventing payment

- does not have a disentitlement preventing payment

Parental benefits can be paid at either the basic rate or at a reduced rate over an extended period of time. The maximum number of parental entitlement weeks for a birth or adoption varies depending on the type of parental benefits the client receives and whether they are shared with any of the other legally recognized parents. 

### Maximum entitlement

Source topic: `en_EN/activity/calc_mat_par/maximum_entitlement.dita`

A client is entitled to a maximum of 35 weeks of standard parental benefits or 61 weeks of extended parental benefits per birth or placement for adoption. The maximum parental entitlement is also the maximum number of parental entitlement weeks that can be paid in a BP. The parental entitlement can be paid over 2 BPs, but cannot be paid outside of the PW. The number of weeks of parental benefits a client is entitled to receive is not affected by the number of children born at the same time (twins, triplets, etc.) or by the number of children adopted at the same time. 

### Sharing parental benefits

Source topic: `en_EN/activity/calc_mat_par/sharing_parental_benefits.dita`

Parents can share parental benefits. For more information and definitions, the officer can refer to Parents: Definition — Table .
       [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

The type of parental benefits requested by the first parent to apply determines the type of parental benefits all parents are entitled to receive for the same birth, adoption or placement, regardless of which parent is paid first. When fact-finding with parents who applied for benefits after the first parent, the officer informs the other parents of this. Once at least one week of parental benefits has been paid to any parent, all parents requesting parental benefits for the same birth, adoption or placement are only entitled to receive the type of parental benefits selected by the first parent who applied for benefits.

The maximum shareable entitlement is 40 weeks of standard parental benefits or 69 weeks of extended parental benefits for children born or placed for adoption on or after March 17, 2019. For children born or placed for adoption before this date, the maximum shareable entitlement is 35 weeks of standard parental benefits or 61 weeks of extended parental benefits. The maximum entitlement for one client remains at 35 weeks of standard or 61 weeks of extended benefits. Clients can change the number of weeks that each parent receives at any time before all benefits are paid. When clients cannot agree on the number of weeks they will each receive, the officer reassigns the issue to a Level 2 officer who adjudicates the division of the remaining weeks.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0035.dita) 

Once the claim is established and it is determined that parental benefits are payable, parental benefits are payable for each week the client submits a claimant’s report and:

- declares 5 non-available days

- has provided the required proof for parental benefits

- does not have earnings or allocations preventing payment

- does not have a disentitlement preventing payment

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0036.dita) 

### Validating shared parental benefits

Source topic: `en_EN/activity/calc_mat_par/validating_shared_parental_benefits.dita`

A Parental Client Record is created for every client requesting parental benefits. The Parental Client Record consists of the client’s SIN, the arrival or placement week (APW) and the other parent’s SIN, if it has been provided. Once a claim is finalized, the system links Parental Client Records for all clients who are sharing parental benefits for the same child. The Parental sharing validation process creates a Claim Review (CR) Parental Benefits Validation WI when one of the following conditions is met:

- The parental BT on all linked Parental Client Records is not the same.

- The total number of parental weeks requested on all linked Parental Client Records exceeds the maximum number of shareable parental benefit weeks. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_0020.dita`

Note:

When the recalculation of a claim is required, the officer follows the normal calculation assessment procedures and refers to Recalculation: Assessment — Instructions and the Recalculation input guide – SSA version if necessary. A claim requiring a recalculation must be assessed in the same manner as a claim requiring an initial calculation.
       [Recalculation: Assessment — Instructions](/en/procedure/generic/additionalresources/recalculation_assessment.shtml) 
       [Recalculation input guide – SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml)

     [Recalculation: Assessment — Instructions](/en/procedure/generic/additionalresources/recalculation_assessment.shtml) 
     [Recalculation input guide – SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0024.dita`

Note:

In New Brunswick, the collective agreement for teachers allows up to 30 days of paid maternity leave. When a client living in New Brunswick is a teacher and requests maternity benefits, ACP will not automate the claim. The paid maternity leave impacts the date of the interruption of earnings (I of E). The waiting period (WP) must be served as only the WP of paid sick leave (PSL) can be waived.

If an officer assigned to a WI related to the calculation of maternity benefits with paid maternity leave on the file and the client is a teacher working and living in New Brunswick, the officer reassigns the WI to the level EI Processing - ATL . 

### Note

Source topic: `en_EN/common_notes/note_c_0025.dita`

Note:

If the client has a violation on file, there may be increased entrance requirements .
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Note

Source topic: `en_EN/common_notes/note_c_0026.dita`

Note:

The birth or adoption of more than one child at the same time is treated as the birth or adoption of a single child. 

### Note

Source topic: `en_EN/common_notes/note_c_0027.dita`

Note:

If the reason for separation (RFS) on the last ROE is P - Parental and maternity benefits were requested, additional fact-finding is required. The officer contacts the employer first to ensure the RFS on the ROE is correct. If so, the officer then contacts the client to ensure the requested benefit type (BT) is correct. If the client has applied for the wrong BT, the officer refers to Determining during calculation if the client applied for the wrong benefit type .
       [Determining during calculation if the client applied for the wrong benefit type](/en/procedure/task/calc_determining/wrong_bt_requested.shtml)

     [Determining during calculation if the client applied for the wrong benefit type](/en/procedure/task/calc_determining/wrong_bt_requested.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0028.dita`

Note:

When the adoption raises doubts, a proof of placement may be requested. 

### Note

Source topic: `en_EN/common_notes/note_c_0029.dita`

Note:

When a pregnancy is terminated within the first 19 weeks, the claim is treated as a sickness claim. If a pregnancy is terminated after the 19th week, the claim is treated as a maternity claim and the DOB is used to determine the maternity window.

To calculate which week is the 19th week, the officer uses the following formula:

- [w/c of the expected DOB] – 39 + 18

Example:

The expected DOB is December 16, 2020 (w/c 2269), but the client’s pregnancy is terminated on August 29, 2020 (w/c 2253).

19th week calculation: w/c 2269 – 39 + 18 = w/c 2248

Since w/c 2253 is after the 19th week, the claim is treated as a maternity claim and the w/c 2253 is coded as the actual DOB. 

### Note

Source topic: `en_EN/common_notes/note_c_0030.dita`

Note:

A client who qualifies for regular benefits and who must serve a waiting period (WP) can establish a claim for maternity benefits 13 weeks before the expected DOB (expected DOB – 13), serve the WP, and then collect maternity benefits beginning the 12th week before the expected DOB. If the WP is waived , maternity benefits cannot be paid earlier than expected DOB – 12 weeks, or the actual DOB.
       [waiting period (WP)](/en/procedure/generic/knowledge.shtml#Waiting_period) 
       [WP is waived](/en/procedure/generic/knowledge.shtml#Waiving)

     [waiting period (WP)](/en/procedure/generic/knowledge.shtml#Waiting_period) 
     [WP is waived](/en/procedure/generic/knowledge.shtml#Waiving) 

### Note

Source topic: `en_EN/common_notes/note_c_0031.dita`

Note:

Under certain conditions, the maternity window can be extended to allow the client more time to collect weeks of entitlement. For more information, refer to Extending the maternity window .
       [Extending the maternity window](/en/procedure/generic/knowledge.shtml#Extending_the_maternity_range)

     [Extending the maternity window](/en/procedure/generic/knowledge.shtml#Extending_the_maternity_range) 

### Note

Source topic: `en_EN/common_notes/note_c_0032.dita`

Note:

If a client is unable to work for medical reasons associated with the pregnancy, she can choose to apply for sickness benefits before maternity benefits. If no regular benefits are collected during the claim, the client can be entitled to an extension of the BP to collect her full maternity and parental entitlement.
       [extension of the BP](/en/procedure/generic/knowledge.shtml#ExtendingBP)

     [extension of the BP](/en/procedure/generic/knowledge.shtml#ExtendingBP) 

### Note

Source topic: `en_EN/common_notes/note_c_0033.dita`

Note:

Under certain conditions, the PW can be extended to allow the client more time to collect weeks of entitlement. For more information, refer to Conditions to allow the extension of the PW .
       [Conditions to allow the extension of the PW](/en/procedure/generic/knowledge.shtml#Conditions_to_allow_the_extension_of_the)

     [Conditions to allow the extension of the PW](/en/procedure/generic/knowledge.shtml#Conditions_to_allow_the_extension_of_the) 

### Note

Source topic: `en_EN/common_notes/note_c_0034.dita`

Note:

A client must meet the entitlement conditions for each week of parental benefits requested. If the officer is informed that the client is no longer caring for the child during the PW, the officer imposes a definite or indefinite 34 - Parental benefits entitlement conditions not met disentitlement (D34) starting the Monday after the week in which the client is no longer entitled to benefits. For more information, the officer refers to Determining entitlement to parental benefits when the client is no longer caring for the child .
       [Determining entitlement to parental benefits when the client is no longer caring for the child](/en/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml)

     [Determining entitlement to parental benefits when the client is no longer caring for the child](/en/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0035.dita`

Note:

When a person who is pregnant or has recently given birth requests both maternity and parental benefits, the parental benefits, if payable, begin the week after maternity benefits end. 

### Note

Source topic: `en_EN/common_notes/note_c_0036.dita`

Note:

A client receiving maternity or parental benefits may request an exemption from completing claimant’s reports. 

## Regional considerations

Source topic: `en_EN/activity/calc_mat_par/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/calc_mat_par/what_you_need_to_look_for.dita`

## What do you want to do?

Source topic: `en_EN/activity/calc_mat_par/what_do_you_want_to_do.dita`

The calculation sub-activities are as follows:

- Determining if a claim is ready to be calculated — Maternity and parental benefits
         [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- Calculating a claim in SSO
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Reviewing the calculation result
         [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml)

- Reviewing and inputting the calculation
         [Reviewing and inputting the calculation](/en/procedure/subactivity/input_calculation_results.shtml)

- Communicating decisions after calculation
         [Communicating decisions after calculation](/en/procedure/subactivity/communicating_calc_decisions.shtml) 

## Policy reference

Source topic: `en_EN/activity/calc_mat_par/policy_reference.dita`

 
