# Calculating or recalculating a claim for sickness benefits

Source map: `en_EN/activity/calc_sick/calc_sick.ditamap`

## Summary

Source topic: `en_EN/activity/calc_sick/summary.dita`

Summary: When ACP is unable to automate the calculation of a claim for sickness benefits, an officer calculates it. 

## What you need to know

Source topic: `en_EN/activity/calc_sick/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/activity/calc_sick/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Manually calculating a claim

Source topic: `en_EN/activity/calc_sick/manually_calculating_a_claim.dita`

The manual calculation of a claim is complex and must only be done by a trained officer.

An officer must calculate or recalculate a claim when:

- a client applies for benefits using a paper application;

- ACP is unable to automate an electronic application;

- a claim requires a recalculation and ACP is unable to automate the recalculation. 

### Post-EI Emergency Response Benefit (EI ERB) claims

Source topic: `en_EN/activity/calc_sick/post-ei_emergency_response_benefit_ei_erb_claims.dita`

All new applications received for sickness benefits with a BPC of w/c 2258 or later are processed using interim measures to speed up the calculation process.

When the specialized ACP process creates a CA WI, no other WIs will be created. The officer must review the most recent application and determine if further action is required before finalizing the calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0043.dita) 

### Calculation versus recalculation

Source topic: `en_EN/activity/calc_sick/calculation_versus_recalculation.dita`

When a Claim Assessment (CA) or Specialized Application (SA) WI is received, the officer must complete the initial calculation of a claim.

When a Claim Review (CR) WI with a recalculation issue is received, the officer must complete a new calculation of a previously finalized claim. A recalculation is sometimes referred to as a “recomp.” Once an initial calculation is successfully transmitted, a claim must be recalculated when new information is received that will have an effect on the previous calculation result (e.g. an amended ROE is issued).

When a recalculation is required for an Integrity case, an urgent Action Item (AI) WI is created for the recalculation. The officer assigned to this WI must complete the recalculation.

The recalculation of a claim can affect the following:

- the client’s ability to establish a benefit period (BP);
         [benefit period](/en/procedure/generic/knowledge.shtml#Establishing_a_benefit_period)

- the client’s entitlement to benefits;

- the client’s benefit rate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0020.dita) 

### Recalculating a claim affected by a SIN or region change

Source topic: `en_EN/activity/calc_sick/recalculating_a_claim_affected_by_a_sin_5e2e09cf.dita`

If the client has moved to a different region, changed SINs, or both, since the initial claim was calculated, registering the recalculation in SSO may not be possible. The recalculation must be registered under the original information technology centre (ITC) and SIN when necessary, but must be transmitted manually in FTS under the current ITC and new SIN, if applicable.

For more information, the officer refers to the Appendices B, C and D of the Recalculation input guide – SSA version .
       [Recalculation input guide – SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml) 

### Structure of calculation procedures

Source topic: `en_EN/activity/calc_sick/structure_of_calculation_procedures.dita`

The calculation procedure is divided into sub-activities to provide a logical sequence to follow when calculating a claim. Although individual officers may have a preferred sequence that is also correct, the procedure is structured to ensure the officer completes all the actions required to process the claim:

- Determining if a claim is ready to be calculated.

- Calculating a claim in SSO.

- Reviewing the calculation result.

- Reviewing and inputting the calculation.

- Communicating decisions after calculation.

Within each sub-activity, there are links to additional procedures that may be required to complete the calculation process. 

### Managing the WI

Source topic: `en_EN/activity/calc_sick/managing_the_wi.dita`

Regardless of how an officer organizes the work, the officer assigned to complete the calculation of a claim must ensure that any issues are addressed and all the facts required to calculate the claim are on file before completing the calculation. Unless otherwise noted in the procedures, the CA WI must not be completed until all issues are addressed and related WIs necessary to finalize the calculation are completed. If the calculation cannot be completed because of an outstanding related WI, the WI for the calculation is moved to Pending until the related WI is completed.

Multiple officers may be assigned WIs for the same claim being assessed (e.g. one officer is assigned an ROE reason for separation [RFS] Action WI and one is assigned the CA WI). The officers complete only the WI to which they are assigned unless instructed otherwise by a procedure.

When assessing the claim, the officer assigned the calculation must also review any client Note for actions required (e.g. inputting transactions, sending letters).

When the calculation is complete, the officer must communicate the decision to the client as necessary. 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/activity/calc_sick/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an AI, Call Back (CB), Assessment Issue (ASMT) or Reminder (REM) WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### Qualifying for sickness benefits

Source topic: `en_EN/activity/calc_sick/qualifying_for_sickness_benefits.dita`

To qualify for sickness benefits, a client must meet the following conditions:

- The client has applied for benefits.

- The client has had an interruption of earnings (I of E) in the qualifying period (QP).
         [interruption of earnings](/en/procedure/generic/knowledge.shtml#Interruption_of_earnings) 
         [qualifying period](/en/procedure/generic/knowledge.shtml#Qualifying_period)

- The client is major attached ( has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

- The client is minor attached (has fewer than 600 hours of insurable employment) and qualifies for regular benefits with an RFS other than illness, injury or quarantine.
         [minor attached](/en/procedure/generic/knowledge.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0021.dita) 

### Qualifying for benefits with the common entrance requirement (from w/c 2310 to w/c 2361)

Source topic: `en_EN/activity/calc_sick/qualifying_for_benefits_with_the_common_bc559d47.dita`

As part of Budget 2021, the Government of Canada announced that a national common entrance requirement (CER) of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in the EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to sickness benefits

Source topic: `en_EN/activity/calc_sick/entitlement_to_sickness_benefits.dita`

To be entitled to sickness benefits, clients must:

- provide a medical certificate which proves the inability to work due to illness;

- prove that they would be otherwise available for work (i.e. they would either be working or looking for work were it not for the illness).
         [otherwise available](/en/procedure/generic/knowledge.shtml#Otherwise_available)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0044.dita) 

A major attached client is entitled to receive special benefits regardless of the RFS.
       [special benefits](/en/procedure/generic/knowledge.shtml#Special_Benefits)

An administrative disentitlement is imposed to prevent the payment of regular benefits for a client who qualifies for special benefits but not for regular benefits. 

### Proof of incapacity

Source topic: `en_EN/activity/calc_sick/proof_of_incapacity.dita`

Clients applying for sickness benefits must be able to provide a medical certificate which proves the inability to work due to illness.

A medical certificate completed by a doctor or other medical practitioner confirming the client’s sickness must be obtained for each week the client requests sickness benefits.

Clients applying for sickness benefits using AW can upload the medical certificate immediately. If clients do not submit the medical certificate and the last RFS is illness, clients are advised that it must be submitted if the duration of the illness or injury is greater than 9 weeks. Otherwise, clients are advised to keep the medical certificate for 6 years since it can be requested at a later date. If the last RFS is not illness, clients are advised they must provide a medical certificate and can upload it later using MSCA.

If a medical certificate is required and not provided, a 16 - No medical certificate submitted (D16) disentitlement must be imposed on the claim.

An officer must not request a medical certificate unless it is required. If a medical certificate is received but not required, the officer reviews it and updates the recovery date according to the information on the medical certificate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0045.dita) 

### Paying benefits

Source topic: `en_EN/activity/calc_sick/paying_benefits.dita`

The client can receive up to 26 weeks of sickness benefits per BP for a BPC in w/c 2374 or later, and up to 15 weeks of sickness benefits per BP for a BPC in w/c 2373 or earlier.

Once the claim is established and it is determined that sickness benefits are payable, sickness benefits are payable for each week the client submits a claimant’s report and:

- declares 5 days of sickness

- is otherwise available for work

- has supplied provided the required proof for sickness benefits

- does not have earnings or allocations preventing payment

- does not have a disentitlement preventing payment 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_0043.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP reverts to regular registration and calculation processes. However, the officer continues to complete outstanding WIs that were created by the specialized process before August 16, 2021 using specialized procedures. 

### Note

Source topic: `en_EN/common_notes/note_c_0020.dita`

Note:

When the recalculation of a claim is required, the officer follows the normal calculation assessment procedures and refers to Recalculation: Assessment — Instructions and the Recalculation input guide – SSA version if necessary. A claim requiring a recalculation must be assessed in the same manner as a claim requiring an initial calculation.
       [Recalculation: Assessment — Instructions](/en/procedure/generic/additionalresources/recalculation_assessment.shtml) 
       [Recalculation input guide – SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml)

     [Recalculation: Assessment — Instructions](/en/procedure/generic/additionalresources/recalculation_assessment.shtml) 
     [Recalculation input guide – SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0021.dita`

Note:

If the client has a violation, there may be increased entrance requirements .
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Note

Source topic: `en_EN/common_notes/note_c_0044.dita`

Note:

When clients do not prove that they would be otherwise available for work for the entire period of incapacity or for part of that period, the officer imposes a 33 - Incapacity proven but not otherwise available disentitlement (D33) from the date on which the condition is not met until the end of the period of incapacity, or until the date on which the client is otherwise available for work. 

### Note

Source topic: `en_EN/common_notes/note_c_0045.dita`

Note:

When a medical certificate is uploaded, the officer or the client must complete a Medical Certificate electronic questionnaire. The electronic questionnaire is not medical proof. The officer does not use it to determine a recovery week or period of incapacity. 

## Regional considerations

Source topic: `en_EN/activity/calc_sick/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/calc_sick/what_you_need_to_look_for.dita`

## What do you want to do?

Source topic: `en_EN/activity/calc_sick/what_do_you_want_to_do.dita`

- Determining if a claim is ready to be calculated — Sickness benefits
         [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- Calculating a claim in SSO
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Reviewing the calculation result
         [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml)

- Reviewing and inputting the calculation
         [Reviewing and inputting the calculation](/en/procedure/subactivity/input_calculation_results.shtml)

- Communicating decisions after calculation
         [Communicating decisions after calculation](/en/procedure/subactivity/communicating_calc_decisions.shtml) 

## Policy reference

Source topic: `en_EN/activity/calc_sick/policy_reference.dita`

 
