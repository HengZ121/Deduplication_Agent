# Availability

Source map: `en_EN/activity/availability/availability.ditamap`

## Summary

Source topic: `en_EN/activity/availability/summary.dita`

Summary: All clients requesting regular benefits must prove their availability for work. Clients requesting sickness benefits must prove that they would be available for work if not for the illness or injury. 

## What you need to know

Source topic: `en_EN/activity/availability/what_you_need_to_know.dita`

### Temporary process is no longer in effect — Relaxed requirements

Source topic: `en_EN/activity/availability/temporary_process_is_no_longer_in_effec_dc8cd340.dita`

The simplification measure for relaxed requirements ends September 25, 2021. Effective September 26, 2021, the officer follows normal procedures to adjudicate all availability issues. 

### Work-Sharing (WS) and availability

Source topic: `en_EN/activity/availability/work-sharing_ws_and_availability.dita`

The COVID-19 special measures for availability during a WS agreement are no longer in effect. Effective immediately, the hours missed due to COVID-19 situations are no longer counted as hours missed due to WS.

WS clients are considered available during any week in which they work for their WS employer. They are not required to be available for work with other employers during these weeks. However, clients must be available for additional work with the WS employer up to their normal hours of work. If an employee could have worked, but was not available or declined to work, these hours are not counted as hours missed due to WS. Therefore, WS benefits are not paid for those hours.

For more information, the officer refers to the Availability section of Work-Sharing: Information on Work-Sharing claims processing — Knowledge .
       [Work-Sharing: Information on Work-Sharing claims processing — Knowledge](/en/procedure/generic/additionalresources/knowledge_reltws.shtml) 

### WIs for availability issues

Source topic: `en_EN/activity/availability/wis_for_availability_issues.dita`

Depending on the situation, different WIs may be created for availability issues, according to the claim type (CT):

- When a potential availability issue is identified on an initial or a renewal claim, an Adjudication Issue (ADJ) Availability WI is created.

- When a potential availability issue is identified on a continuing claim, a Claim Review (CR) Revised WI is created. 

### Presumption of non-availability

Source topic: `en_EN/activity/availability/presumption_of_non-availability.dita`

If the issue is related to a contentious reason for separation (RFS), the officer does not review the client’s availability, unless the information on file suggests a presumption of non-availability.

There is a strong presumption of non-availability in the following cases:

- voluntary leaving for retirement

- voluntary leaving for health reasons

- voluntary leaving to care for a child or immediate family member

- voluntary leaving owing to loss of transportation

- voluntary leaving to go back to school

- leave of absence

- dismissal for unavailability

- vacation pay during a vacation closure period 

### Limited or reduced capacity

Source topic: `en_EN/activity/availability/limited_or_reduced_capacity.dita`

A client whose capacity to work is limited due to a recent disability could still be considered available and may be eligible to receive regular benefits if the following conditions are met:

- The client can work full time;

- The client is willing to accept suitable work;

- There are reasonable opportunities for suitable work in the labour market.

If the client’s involuntary restrictions makes obtaining employment unlikely, the claim must be reviewed to determine whether a conversion to sickness benefits would be possible or whether a disentitlement must be imposed.

If the client already has a permanent restriction and the client’s availability remains unchanged in terms of duties or hours of work, the officer considers the client’s availability to be in order. However, if there is a change in duties or hours of work, the officer assesses the situation according to the definition of suitable employment. 

### Otherwise available issues

Source topic: `en_EN/activity/availability/otherwise_available_issues.dita`

When clients request sickness benefits, the officer verifies whether they are otherwise available. Clients must prove that they would be available for work if not for the illness or injury. A situation that leads officers to question clients’ availability for regular benefits should also lead officers to question clients’ ability to prove that they are otherwise available for sickness benefits.

Exception: When clients request sickness benefits while receiving and remaining entitled to parental, CCB, family caregiver benefits or QPIP, they are considered otherwise available. 

### Levels of decision

Source topic: `en_EN/activity/availability/levels_of_decision.dita`

Under certain conditions indicated in the processing steps, Level 1 and Level 2 officers can adjudicate a client’s availability or otherwise available issues. 

### Situations not covered in this activity

Source topic: `en_EN/activity/availability/situations_not_covered_in_this_activity.dita`

Various procedures cover the availability and otherwise available issues. For any of the following situations, the officer refers to the applicable activity:

- Vacation in Canada
         [Vacation in Canada](/en/procedure/activity/vacation.shtml)

- Jury duty
         [Jury duty](/en/procedure/activity/jury_duty.shtml)

- Out of Canada
         [Out of Canada](/en/procedure/activity/out_canada.shtml)

- Training
         [Training](/en/procedure/activity/training.shtml)

- Incarceration
         [Incarceration](/en/procedure/activity/incarceration.shtml)

- Self-employment
         [Self-employment](/en/procedure/activity/self_employed.shtml)

- 900-series SIN
         [900-series SIN](/en/procedure/activity/expired_900.shtml) 

### Client considered available

Source topic: `en_EN/activity/availability/client_considered_available.dita`

Some clients are considered available even if they actually are not. These include:

- clients who are referred to a training, program of instruction or employment activity;

- clients who are employed under a WS program;

- fishers (in certain situations).

Clients who had a fishing benefit period (BP) established, whether for summer or winter fishing, are considered available for work with regard to their fishing activities. During the periods stated below, a 3 - Not available disentitlement (D3) is not imposed, for the sole reason that the client took part in fishing activities:

- Summer fishing: starting the week in which October 1 falls to the week in which the following June 15 falls.

- Winter fishing: starting the week in which April 1 falls to the week in which the following December 15 falls. 

### Legal tests

Source topic: `en_EN/activity/availability/legal_tests.dita`

**Availability**

To determine whether a client has proven availability and to facilitate adjudication and fact-finding, the Level 2 officer answers the following questions:

- Does the client’s attitude reflect a sincere desire to work or, conversely, the lack of concern of a person not really seeking suitable employment?

- Are there any circumstances which obstruct the client’s desire to work?

- Is the client’s willingness to work subject to restrictions (expectations which greatly reduce chances of obtaining employment)?

- Has the client’s inability to obtain suitable employment been tested through personal efforts to find work?

**Otherwise available**

To determine whether a client can be considered otherwise available and to facilitate adjudication and fact-finding, the officer determines if the client would be available for work if not for the illness or injury. 

### Disentitlements

Source topic: `en_EN/activity/availability/disentitlements.dita`

If clients cannot prove their availability, the officer imposes a D3.

If the officer cannot contact a client with questionable availability, the officer imposes a D3.

If clients cannot prove that they are otherwise available, the officer imposes a 33 - Incapacity proven but not otherwise available disentitlement (D33).

If the officer cannot contact clients who cannot prove that they are otherwise available, the officer imposes a D33.

Clients who do not prove that they are making reasonable and customary efforts to find suitable employment are subject to a 24 - Failure to actively search for work disentitlement (D24). Officers also impose a D24 when clients do not comply with a request to submit their job search efforts.

Any of these disentitlements can be imposed at the same time as another disentitlement or a disqualification from receiving benefits.

The disentitlement starts and ends on a working day (i.e. Monday to Friday, including holidays). Officers cannot impose a disentitlement on a client for a half-day. Extenuating circumstances cannot reduce the length of the disentitlement.

The disentitlement can be reviewed at any time during the claim, to be rescinded, amended or terminated.

To determine the impact of a disentitlement imposed during the waiting period (WP), the officer refers to Waiting period: Impact of earnings and disentitlements — Knowledge .
       [Waiting period: Impact of earnings and disentitlements — Knowledge](/en/procedure/generic/additionalresources/earnings_disentitlements_wp.shtml) 

### Adjudication Issue (ADJ) Child care WI

Source topic: `en_EN/activity/availability/adjudication_issue_adj_child_care_wi.dita`

The system creates an ADJ Child care WI when a client applies for regular or fishing benefits and indicates that she gave birth in the last 17 weeks and does not have child care arrangements. A Level 1 officer verifies that the client indicated the correct benefit type (BT) on the application. If the client confirms that she wants regular or fishing benefits, a Level 2 officer adjudicates the availability issue caused by the lack of child care arrangements. 

## Regional considerations

Source topic: `en_EN/activity/availability/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/availability/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/activity/availability/in_nws.dita`

- Do the specific details or WI history of an ADJ WI or a CR WI contain information about availability?

- Are there any SROCs or other WIs containing additional information about availability?

- Are there documents related to the issue? 

### In Imaging:

Source topic: `en_EN/activity/availability/in_imaging.dita`

- Are there imaged documents that can provide additional information about availability? 

### In FTS:

Source topic: `en_EN/activity/availability/in_fts.dita`

- Is there already an indefinite D3 on file?

- Is there already a D33 on file?

- Is there already a D24 on file? 

### How to choose which procedure to use

Source topic: `en_EN/activity/availability/how_to_choose_which_procedure_to_use.dita`

Depending on the circumstances, more than one availability procedure may apply. To determine the correct actions, refer to the What you need to look for section and then review the chart below:
       [What you need to look for](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/activity/availability#WYNTLF)

```text
| Situation | Applicable availability task |

| The client has preferences or restrictions affecting their availability or job search. | Adjudicating availability — Preference or restriction and reasonable period [Adjudicating availability — Preference or restriction and reasonable period](/en/procedure/task/availability_adj_res.shtml) |

| The client is providing new information after a D24 has been imposed. | Actioning new information after a D24 has been imposed [Actioning new information after a D24 has been imposed](/en/procedure/task/actioning_new_info_d24.shtml) |

| The client statement regarding a specific availability issue: - not available | Adjudicating non-availability declared by the client [Adjudicating non-availability declared by the client](/en/procedure/task/availability_declared_client.shtml) |

| The client statement regarding a specific availability issue: - presently employed part-time | Adjudicating availability — Client is working part-time [Adjudicating availability — Client is working part-time](/en/procedure/task/availability_pt.shtml) |

| The client statement regarding a specific availability issue: - devoting time to personal activities | Adjudicating availability — Volunteer or other personal activities [Adjudicating availability — Volunteer or other personal activities](/en/procedure/task/availability_personal_act.shtml) |

| The client is or was absent from home: - while in Canada only | Adjudicating availability — Absence from home while in Canada and not on vacation [Adjudicating availability — Absence from home while in Canada and not on vacation](/en/procedure/task/availability_absence.shtml) |

| The client was absent from the area: - indefinite D3 on file | Adjudicating availability — Absence after the client has returned home [Adjudicating availability — Absence after the client has returned home](/en/procedure/task/availability_client_return.shtml) |

| The client indicates a gradual return to work after a period of illness. | Adjudicating availability — Gradual return to work [Adjudicating availability — Gradual return to work](/en/procedure/task/availability_adj_rw.shtml) |

| The client applies for regular or fishing benefits and has no child care. | Actioning an Adjudication Issue Child care WI [Actioning an Adjudication Issue Child care WI](/en/procedure/task/actioning_adj_cc_wi.shtml) |

| The client has an otherwise available issue. | Adjudicating otherwise available issues — Initial claim [Adjudicating otherwise available issues — Initial claim](/en/procedure/task/no_available.shtml) |

| Adjudicating otherwise available issues — Renewal claim [Adjudicating otherwise available issues — Renewal claim](/en/procedure/task/no_available_rc.shtml) |

| Adjudication otherwise available issues — Continuing claim [Adjudication otherwise available issues — Continuing claim](/en/procedure/task/no_available_cc.shtml) |
``` 

## What do you want to do?

Source topic: `en_EN/activity/availability/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/availability/policy_reference.dita`

 
