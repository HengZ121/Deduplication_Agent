# Adjudication Issue RFS Review WI

Source map: `en_EN/activity/adj_rfs_review/adj_rfs_review.ditamap`

## Summary

Source topic: `en_EN/activity/adj_rfs_review/summary.dita`

Summary: When a regular ROE is received with a reason for separation (RFS) K - Other or G - Mandatory retirement , or a fishing ROE is received with a RFS B - Other , an Adjudication Issue (ADJ) RFS Review WI is created. The system cannot create a link between the ROE and the matching period of employment reported on the initial EI application. 

## What you need to know

Source topic: `en_EN/activity/adj_rfs_review/what_you_need_to_know.dita`

### Conditions for creating the WI

Source topic: `en_EN/activity/adj_rfs_review/conditions_for_creating_the_wi.dita`

When none of the periods of employment reported on the application have a contentious RFS, or when all the periods of employment with a contentious RFS are already linked to an ROE, an ADJ RFS Review WI is created. 

### Reviewing the reason for separation (RFS)

Source topic: `en_EN/activity/adj_rfs_review/reviewing_the_reason_for_separation_rfs.dita`

When an ADJ RFS Review WI is received, the Level 1 agent reviews the information on file and, if necessary, fact-finds with the interested parties to determine if the RFS is contentious and requires adjudication. The agent takes the appropriate action to ensure that the RFS issue is resolved. 

## Regional considerations

Source topic: `en_EN/activity/adj_rfs_review/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/adj_rfs_review/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/activity/adj_rfs_review/in_nws.dita`

- What type of ADJ RFS Review WI was created? 

## What do you want to do?

Source topic: `en_EN/activity/adj_rfs_review/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/adj_rfs_review/policy_reference.dita`

 
