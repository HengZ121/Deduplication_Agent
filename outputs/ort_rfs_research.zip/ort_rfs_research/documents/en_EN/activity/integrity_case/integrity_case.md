# Integrity case

Source map: `en_EN/activity/integrity_case/integrity_case.ditamap`

## Summary

Source topic: `en_EN/activity/integrity_case/summary.dita`

Summary: Investigators report facts from an investigation and include a recommendation when there have been false or misleading statements or misrepresentations that may affect qualification or entitlement to EI, as well as when a third party has fraudulently used a client’s personal information to obtain benefits. 

## What you need to know

Source topic: `en_EN/activity/integrity_case/what_you_need_to_know.dita`

### Adjudication process

Source topic: `en_EN/activity/integrity_case/adjudication_process.dita`

This activity indicates the steps to follow when it is determined that a false or misleading statement has been made resulting in a qualification or entitlement issue related to EI benefits. The officer must adjudicate the issue following the procedures in this section.

If it is determined that the false or misleading statement or misrepresentation was made knowingly by the client , the officer must follow the procedures below to adjudicate the qualification or EI entitlement issue, then refer to Misrepresentation to determine the type of sanction to impose. The officer must input the complete decision after determining the sanction.
       [Misrepresentation](/en/procedure/activity/misrepresentation.shtml) 

### Investigative threshold

Source topic: `en_EN/activity/integrity_case/investigative_threshold.dita`

The Integrity investigative threshold is $400. Computer post-audit investigations will not be generated when the overpayment (OP) is less than $400. Integrity may also consider that other investigations are in order when the OP is below the threshold. Cases with an OP below the threshold are referred for adjudication only when specific exceptions are met (voluntary disclosure or impact on an active claim). Officers are not required to validate the threshold.

Officers process all Claim Review (CR) Integrity WIs following normal procedures even if, after adjudication, it is determined the OP is below the threshold. 

### Reconsidering a decision

Source topic: `en_EN/activity/integrity_case/reconsidering_a_decision.dita`

EIA 52 states that a claim for benefits may be reconsidered as long as it results in an OP or an underpayment (UP). The time limit for reconsidering a claim is 36 months from the week benefits were paid or payable. This period is extended to 72 months if there is a false or misleading statement.
       [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html) 

### Determining if a false statement was made

Source topic: `en_EN/activity/integrity_case/determining_if_a_false_statement_was_made.dita`

A false statement is a statement that is incorrect or untrue. It can be the result of an intentional or negligent action, or it can be the result of an honest mistake.

For example, a client declares $100 in earnings, but a subsequent investigation shows that the client actually earned $225. At this point, we only know that the information provided by the client is incorrect. Without an explanation from the client, it cannot be determined if the client intentionally or knowingly reported the incorrect amount. Regardless of whether it was intentional or an honest mistake, the client reported the incorrect amount. Therefore, the reconsideration period can be extended to 72 months. 

### False statement knowingly made

Source topic: `en_EN/activity/integrity_case/false_statement_knowingly_made.dita`

Knowingly means the officer can reasonably conclude that clients knew the information provided was untrue when they provided or did not declare that information. There is no element of intent in this consideration. It is not necessary to determine a degree of fault. The officer must only establish that it is more likely the client understood the information provided did not accurately portray the facts. 

### Voluntary disclosure

Source topic: `en_EN/activity/integrity_case/voluntary_disclosure.dita`

This policy encourages clients, employers and third parties to come forward and voluntarily disclose misrepresentations. Under this policy, voluntary disclosure occurs when a person admits to having knowingly made a false statement.

An investigator may recommend that the file be reconsidered in light of the National Policy on Voluntary Disclosure .
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

There are 2 essential criteria for accepting a voluntary disclosure:

- There is no investigation under way in relation to the voluntary disclosure when a client admits to making a false statement.

- The false statement would have resulted in punitive measures such as a penalty, a warning or prosecution had there been no voluntary disclosure.

There is no limit to the number of times that a client can voluntarily disclose information.

When a voluntary disclosure is accepted, the client, employer or a third party benefits from the following:

- no penalty, warning letter or prosecution;

- no increase in benefit period entrance requirements (violation);

- no interest is applied to the OP;

- this misrepresentation is not considered when determining if future misrepresentations are repetitive.

However, the OP caused by the voluntary disclosure is deemed fraudulent. It cannot be written off and it survives bankruptcy. 

### Responsibilities of the investigator

Source topic: `en_EN/activity/integrity_case/responsibilities_of_the_investigator.dita`

The investigator assigned to the investigation must gather all the facts and relevant documents relating to the identified litigious issue, and submit the file and recommendations to Level 2. 

### Responsibilities of the Level 2 officer

Source topic: `en_EN/activity/integrity_case/responsibilities_of_the_level_2_officer.dita`

Level 2 officers are responsible for processing the CR Integrity WIs that are assigned to them. They consult NIIS for each case to find all the relevant information to adjudicate the issue (e.g. the statements of the client, the employer or a third party, and the Report of Investigation).

Level 2 officer also consult Imaging to retrieve all the documents that may be related to the identified issue.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0119.dita) 

Level 2 officer ensure that all essential facts are complete and adjudicate in a fair and equitable manner based on these facts. The Level 2 officer is not bound by the investigator’s recommendation. 

### Adjudicating all undisclosed contentious reasons for separation (RFSs)

Source topic: `en_EN/activity/integrity_case/adjudicating_all_undisclosed_contentiou_8736c36f.dita`

The Level 2 officer adjudicates all contentious RFSs in a qualifying period (QP) and in a benefit period (BP) that are part of the Integrity investigation. The adjudication of an Integrity investigation decision cannot be deferred. 

### Returning a file to Integrity

Source topic: `en_EN/activity/integrity_case/returning_a_file_to_integrity.dita`

After conducting a full review of the investigation, if the Level 2 officer determines that facts are missing, the officer must return the investigation to the investigator for further fact-finding and indicate the information that is missing but necessary to adjudicate the issue. The Level 2 officer must not adjudicate if facts are missing or incomplete.

Facts are not considered missing or incomplete if the investigator has followed up with the client when the client fails to report for an interview or fails to reply to a request for information. The investigator is not required to send a follow-up letter, but must make 2 attempts on 2 different days to contact the client by telephone. If the investigator leaves a message on a voicemail, only one attempt is required and they must give the clients 48 hours to respond.

If the investigator recommends that the Integrity case be considered a voluntary disclosure, but the investigation type in NIIS is incorrect, the officer also returns the file to Integrity.

When adjudicating a case of unreported earnings, the Level 2 officer may notice that the employer did not fully complete the section about other monies on the INS5097. In this case, the officer returns the case to Integrity for further fact-finding only if:

- The investigator, when reviewing the case, must contact the employer to clarify other issues on the INS5097 form but do not clarify the section about other monies.

If the employer did not complete the section about other monies, the Level 2 officer adjudicates the case as is. In this situation, it is assumed that no other monies were paid to the client.

If the employer selected Yes in the section about other monies but did not provide details, the Level 2 officer adjudicates the case as is, if the investigator, while reviewing the case, did not have to contact the employer for any other issues on the INS5097 form. 

### Sending a claim for recalculation

Source topic: `en_EN/activity/integrity_case/sending_a_claim_for_recalculation.dita`

When a RFS is assessed and a new ROE must be included in the rate calculation, a retroactive review of the claim calculation is required, regardless of the impact (creation of an OP or a UP) that this ROE has on the benefit rate and the duration of the claim.
       [a retroactive review](/en/policy/bememo/be2007-04.shtml)

In this situation, the Level 2 officer adjudicates the RFS and completes all the necessary actions related to the CR Integrity WI. Then, the Level 2 officer creates an Action Item (AI) WI for Level 1 for a claim recalculation. 

### Variable best weeks (VBW)

Source topic: `en_EN/activity/integrity_case/variable_best_weeks_vbw.dita`

If additional information contradicts the information used to establish a claim under the benefit rate calculation policy, the officer must reconsider the claim to ensure entitlement has been correctly determined.

However, the officer does not reconsider the claim when information gathered from an Integrity investigation reveals that earnings were not declared, but that the benefit rate calculation policy was correctly applied the first time.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0120.dita) 

### Reviewing the EI Validation of Home Address Program Compliance

Source topic: `en_EN/activity/integrity_case/reviewing_the_ei_validation_of_home_add_313d2f42.dita`

Investigators are reviewing a random sample of EI claims to assess whether the correct home address was used to determine the client’s entitlement to EI regular benefits. 

### Reviewing the Premium Reduction Program (PRP) compliance

Source topic: `en_EN/activity/integrity_case/reviewing_the_premium_reduction_program_5c72f468.dita`

Investigators are reviewing a random sample of EI sickness claims to determine if clients received or were entitled to receive paid sick leave or wage loss indemnity through their employer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0121.dita) 

### Job search compliance review

Source topic: `en_EN/activity/integrity_case/job_search_compliance_review.dita`

Investigators are conducting job search compliance reviews on selected EI clients to determine whether the clients have met their obligations to be ready and willing to work, to actively search for and accept suitable employment and to keep a detailed record of their job search efforts. 

### Sharing parental benefits

Source topic: `en_EN/activity/integrity_case/sharing_parental_benefits.dita`

Investigators are reviewing EI claims in which parental sharing has occurred to determine if clients were entitled to the parental benefits that they received. This applies only to clients who shared parental benefits before September 2019. 

### Duplicate payment

Source topic: `en_EN/activity/integrity_case/duplicate_payment.dita`

Investigators are determining if a client received the original and replacement payments when the client disputes receiving both payments and if a trace request has already been processed. 

### EI Emergency Response Benefit (EI ERB) — Income review

Source topic: `en_EN/activity/integrity_case/ei_emergency_response_benefit_ei_erb__i_fb21a6aa.dita`

Integrity reviewed clients’ eligibility for the EI ERB that was received while clients earned income during the EI ERB period.

These procedures apply only to Level 2 officers who are part of the Level 2 adjudication team actioning EI ERB income cases. 

### Fraudulent EI claims

Source topic: `en_EN/activity/integrity_case/fraudulent_ei_claims.dita`

Investigators are reviewing potentially fraudulent EI claims on which a third party compromised the client’s personal information and used it to attempt to obtain benefits. Investigators create a CR Integrity ERB-EI Transition WI if it is confirmed that an EI claim or payments issued on an EI claim are fraudulent. These cases are actioned only by officers who are part of the specialized team actioning fraud cases. 

### Example

Source topic: `en_EN/common_notes/note_c_0119.dita`

Example:

If there is a post audit for an earnings correction, the Request for Clarification of Employment Information (INS5098) form and the Request for Payroll Information (INS5097) form may be available in Imaging. 

### Example

Source topic: `en_EN/common_notes/note_c_0120.dita`

Example:

The client does not provide best weeks information so the benefit rate is calculated using proportional averaging of the ROEs. Integrity obtains the correct data which potentially increases or decreases the benefit rate. The officer does not recalculate the benefit rate because the policy was correctly applied the first time and the client did not provide any false or misleading information used for the calculation of the claim. 

### Note

Source topic: `en_EN/common_notes/note_c_0121.dita`

Note:

The EI PRP compliance review has been suspended. 

## Regional considerations

Source topic: `en_EN/activity/integrity_case/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/integrity_case/what_you_need_to_look_for.dita`

### In NIIS:

Source topic: `en_EN/activity/integrity_case/in_niis.dita`

- What is the issue identified?

- Is the investigation the result of a program compliance review? 

## What do you want to do?

Source topic: `en_EN/activity/integrity_case/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/integrity_case/policy_reference.dita`

 
