# Post-EI ERB — Procedures for claims automated in the specialized ACP process

Source map: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/post_eierb_assessment_issue_wi_unique_s_774b2eb0.ditamap`

## Summary

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/summary.dita`

Summary: On September 27, 2020, a specialized ACP process was put in place to streamline the processing of initial claims for regular and sickness benefits. Unique Assessment Issue (ASMT) WIs or Action Item (AI) WIs were created when agent review was required on both initial claims and claims that were being converted to regular benefits. This temporary process ends on August 16, 2021. However, the agent continues to complete outstanding WIs that were created by the specialized ACP process before August 16, 2021 using specialized process procedures. 

## What you need to know

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/untitled_section.dita`

- **COVID-19 Alert — Updated September 28, 2020 (select for additional information)**

           [Danger](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0140.dita) 

### Specialized ACP process

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/specialized_acp_process.dita`

This streamlined process applies only to initial applications for regular or sickness benefits that meet specific criteria.

Some of the claims in the specialized ACP process have a paper application in the Client information tree because the client was automatically enrolled after exhausting an EI Emergency Response Benefit (EI ERB) claim. In this case, the agent reviews the most recent application for the EI ERB when completing the WI.

The regular ACP wait process does not apply to the specialized process. There are no ROE Issue (ROE) WIs created in the specialized ACP process. Three ASMT WIs are unique to the specialized process. ACP creates one of these WIs when agent intervention is required. These ASMT WIs will prevent the ACP specialized process from finalizing the calculation until the agent completes the ASMT WI. 

### Assessment Issue (ASMT) BPNE WI

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/assessment_issue_asmt_bpne_wi.dita`

ACP creates an ASMT BPNE WI in the specialized ACP process when the tentative calculation result is BPNE N1, N2 or N5. A Level 1 agent reviews the file to determine if there is a missing ROE and whether an interim ROE or actuals are required. After the agent completes the ASMT BPNE WI, ACP calculates and finalizes the claim. Only ACP can create this WI. 

### Assessment Issue (ASMT) ROE Correction WI

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/assessment_issue_asmt_roe_correction_wi.dita`

ACP creates an ASMT ROE Correction WI in the specialized ACP process when a regular or fishing ROE has an error that prevents calculation. The agent follows the appropriate procedure to correct the error and complete the WI. Only ACP can create this WI. 

### Duplicate ROEs

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/duplicate_roes.dita`

If the ROE error indicates that the serial number has already been entered for another SIN, the agent refers to Post-EI ERB — Correcting an ROE flagged as a duplicate ROE with a different SIN .
       [Post-EI ERB — Correcting an ROE flagged as a duplicate ROE with a different SIN](/en/procedure/task/post_eierb_correcting_roe_flagged_duplicate_roe_different_sin.shtml) 

### ROEs with a serial number status problem

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/roes_with_a_serial_number_status_problem.dita`

If the ROE error indicates there is a problem with the status of the serial number, the agent refers to Post-EI ERB — Correcting an ROE flagged with a serial number problem .
       [Post-EI ERB — Correcting an ROE flagged with a serial number problem](/en/procedure/task/post_eierb_correcting_roe_flagged_with_a_serial_number_problem.shtml) 

### Assessment Issue (ASMT) ROE Comments WI

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/assessment_issue_asmt_roe_comments_wi.dita`

ACP creates an ASMT ROE Comments WI in the specialized ACP process when the comments on a fishing or regular ROE require review. The agent reviews the comments, takes the appropriate action and completes the WI. Only ACP can create this WI. 

### Converting claims automated in the specialized ACP process

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/converting_claims_automated_in_the_spec_c42658c2.dita`

Claims automated in the specialized ACP process are established without adjudicating contentious RFS issues in the client’s qualifying period (QP). The Special condition field of the ROE is blank or deferred, and UIC considers the RFS non-contentious at that time . As a result, the contentious ROE is included in the calculation and no disqualification is imposed.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0141.dita) 

When a client requests a conversion from special benefits (including sickness benefits) to regular benefits, the agent reviews any RFS issues in order to prevent the payment of benefits to which the client is not entitled. An AI WI is created for the Level 2 agent to adjudicate each contentious RFS in the 12-week period before the interruption of earnings (I of E) used to establish the claim (even though it was previously considered non-contentious by UIC during the initial calculation). 

### Danger

Source topic: `en_EN/common_notes/note_c_0140.dita`

This page is affected by COVID-19-special measures. COVID-19 related changes are not highlighted. For more information, the agent refers to the appropriate Headlines and Updates page.

- September 28, 2020 — The activity was created ( more information ).
         [more information](/en/site/dossier/new_updated_post_eierb_specialized_acp_process.shtml)

- April 1, 2021 — This activity was updated with information about adjudicating reason for separation (RFS) issues when clients request a conversion from special to regular benefits.

     [more information](/en/site/dossier/new_updated_post_eierb_specialized_acp_process.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0141.dita`

Note:

The ACP specialized process ends August 16, 2021. As of that date, ACP creates Adjudication Issue (ADJ) WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

## Regional considerations

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/in_nws.dita`

- What is the issue on the Specific Details tab of the ASMT WI? Is there any additional information in the Details field?

- Is Reason for Separation indicated in the Issue field of the AI WI?

- If yes, is there any additional information in the Details field? 

### In RCM:

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/in_rcm.dita`

- Is it a regular or fishing ROE? 

## What do you want to do?

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/post_eierb_assessment_issue_wi_unique_s_774b2eb0/policy_reference.dita`

 
