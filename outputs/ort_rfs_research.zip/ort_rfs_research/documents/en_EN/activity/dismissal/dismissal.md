# Dismissal

Source map: `en_EN/activity/dismissal/dismissal.ditamap`

## Summary

Source topic: `en_EN/activity/dismissal/summary.dita`

Summary: When a client is dismissed from a job, the reason for separation (RFS) must be reviewed to determine if the client is entitled to benefits. 

## What you need to know

Source topic: `en_EN/activity/dismissal/what_you_need_to_know.dita`

### Level 1

Source topic: `en_EN/activity/dismissal/level_1.dita`

**Dismissal — Unsuitable**

A Level 1 officer can render the decision to allow a dismissal on all claim types (CT) when:

- the client indicates being dismissed due to unsuitability or due to a shortage of work; and

- the employer, when contacted, confirms that the client was not suitable for the position and there was no misconduct; or

- a comment on the ROE confirms the dismissal is due to the client being unsuitable, not passing training or being terminated within the probationary period; and

- there are no other contentious issues related to the dismissal that would prevent the Level 1 officer from allowing the RFS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0090.dita) 

A Level 1 officer can render the decision to allow a dismissal on an initial or renewal claim without further fact-finding with the client when:

- the client worked for the employer for 12 weeks or less; and

- the client did not provide any details on the EI application about that employment; and

- the employer, when contacted, confirms that the client was not suitable for the position and there was no misconduct; or

- a comment on the ROE confirms the dismissal is due to the client being unsuitable, not passing training or being terminated within the probationary period; and

- there are no other contentious issues related to the dismissal that would prevent the Level 1 officer from allowing the RFS.

For more information, the Level 1 officer refers to the tasks Adjudicating a dismissal for unsuitability — Initial claim or Adjudicating a dismissal for unsuitability — Renewal claim for more information.
       [Adjudicating a dismissal for unsuitability — Initial claim](/en/procedure/task/dismissal_ic.shtml) 
       [Adjudicating a dismissal for unsuitability — Renewal claim](/en/procedure/task/dismissal_rc.shtml)

If the fact-finding reveals that the dismissal is due to potential misconduct, the dismissal must be adjudicated at Level 2.

When a client indicates on the application that they have already provided the details for the RFS, the dismissal questionnaire is not presented to the client. The same applies when a client does not declare a contentious RFS on the application. In this situation, the Level 1 officer initiates fact-finding with the client to determine which procedure to choose. If the client indicates a reason that does not fall within Level 1 authority, the officer reassigns the WI to Level 2.

**Suspension — Terminating a disentitlement**

When a client is suspended from employment as a result of misconduct, a disentitlement is input. When there is an indefinite disentitlement on file and the client reports being available for work and poses no restrictions for accepting employment, a Level 1 officer can terminate the disentitlement on a renewal claim if one of the following criteria is met:

- the period of suspension expired; or

- the client was laid off; or

- the reason for not returning to work can be allowed at Level 1; or

- the client accumulated enough insurable hours with another employer after the beginning of the period of suspension to qualify for the requested BT.

If fact-finding reveals that the client was dismissed or quit the job for a reason that cannot be allowed at Level 1, a Level 2 officer must adjudicate the issue. 

### Level 2

Source topic: `en_EN/activity/dismissal/level_2.dita`

**Misconduct**

Cases of misconduct are only adjudicated at Level 2.

**Mandatory retirement**

Human rights legislation in Canada prohibits mandatory retirement. Very few occupations are exempt from this legislation. Some employers may be able to demonstrate a genuine reason for mandatory retirement, but these cases are rare.

Employers are instructed to choose G - Mandatory retirement as the RFS on the ROE only in cases of mandatory retirement, and to choose E - Quit as the RFS in cases of voluntary retirement.

A mandatory retirement cannot be considered as voluntary leaving. In cases where clients do not voluntarily leave their employment, the separation is initiated by the employer. A Level 2 officer must adjudicate the RFS as a dismissal.

**Suspension**

When a client is suspended from employment, the RFS is adjudicated at Level 2. If the officer finds that the client was suspended due to misconduct, the officer imposes an indefinite 42 - Suspension from employment disentitlement (D42). If the suspension occurs during the BP, the disentitlement begins the day the suspension occurred. If the client submits a new claim, the disentitlement begins at the BPC. The disentitlement continues for the length of the claim unless the client gains relief from the disentitlement.

A D42 can be terminated when the suspension ends, if the client accumulates enough insurable hours of employment from another employer to qualify for benefits, or if the client is dismissed or quits. If the client was dismissed or quit during the suspension, the officer adjudicates the RFS before terminating the disentitlement.

If the suspension is only in the qualifying period (QP), and the client has gained relief and is not requesting benefits during the suspension, the officer does not need to adjudicate the suspension. This applies to any suspension in the QP other than a suspension from the last employer before the BPC. The officer refers to Adjudicating a dismissal or suspension — Initial claim for instructions to complete the Adjudication Issue (ADJ) WI.
       [Adjudicating a dismissal or suspension — Initial claim](/en/procedure/task/dismissal_ds_ic.shtml)

**Dismissal or voluntary leaving during a period of suspension**

If, during a period of suspension, a client quits for a reason that cannot be allowed at Level 1 or if the client is dismissed by the employer, the officer adjudicates the RFS before terminating the disentitlement. The circumstances must be reviewed to determine if a disqualification applies. It is also possible that the disqualification is retroactive to the beginning of the suspension. Cases of dismissal during a suspension can only be adjudicated at Level 2.

**Dismissal during a labour dispute**

Additional fact-finding must be completed when a client is dismissed either before or during a labour dispute. If the dismissal has occurred during a labour dispute, a disentitlement may apply for the period of the dispute. These cases can only be adjudicated at Level 2.

**Levels of decision**

When ACP cannot adjudicate the dismissal, an ADJ WI is created and assigned to the appropriate level according to the National policy on Level of Decision .
       [National policy on Level of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

If there is an ADJ WI for a contentious RFS that falls after the BPC date on a claim with a status of In Progress (Automation) or In Progress (Manual) , the officer follows the Level 2 procedures. The system updates the Special condition field of the ROE when the ADJ WI is completed. If necessary, the officer manually inputs the disqualification in FTS.
       [Level 2](/en/procedure/task/vllevel2_ic.shtml) 

### Reason for separation (RFS) — Temporary Budget measures

Source topic: `en_EN/activity/dismissal/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**Adjudicating the last employment in the qualifying period (QP) — BPCs between w/c 2310 and w/c 2361**

Budget 2021 has introduced a temporary simplification measure starting September 26, 2021. For claims with a BPC between w/c 2310 and w/c 2361, the officer will only adjudicate the last period of employment in the QP if it is contentious. If the officer allows the last RFS, all other ROEs in the QP, even if they are contentious, are used to calculate the claim. If, however, the officer does not allow the RFS on the last ROE in the QP, the claim is calculated with a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 

This new measure does not apply to self-employment (SE) and fishing claims. If clients applying for SE or fishing benefits have a BPC w/c 2310 and later, insurable employment in the QP and any contentious RFSs, these RFSs must be adjudicated following normal adjudication procedures.

When the client declares other employers with a contentious RFS on the same application, if ACP does not allow the issue under auto-adjudication rules, the issue is automatically resolved and ACP creates a record of decision (ROD) that shows Adjudication not Required . The Special condition field on the ROE is not updated, and the ROE is included in the calculation. An ADJ WI is not created for the RFS.

When there is more than one ROE with the same last day paid (LDP), and one of the ROEs is contentious while the other ROE is not, adjudication is not required and both ROEs will be included in the calculation.

**Adjudication not required: Reason for separation (RFS) beyond 12 weeks — BPCs between w/c 2258 and w/c 2309**

Adjudication principles on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309 only apply to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the interruption of earnings (I of E) used to establish the claim.

**Adjudication not previously required — Specialized ACP process**

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the QP. The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0092.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0090.dita`

Note:

For dismissals, the National Policy on Levels of Decision states that confirmation from the employer is not required if the statement on the ROE (i.e. a comment in block 18 - Comments or the code M - Dismissal or suspension / Terminated within probationary period in block 16 - Reason for issuing this ROE of a web ROE) indicates that the client was dismissed due to unsuitability, not passing training or being terminated within the probationary period.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

     [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0092.dita`

Note:

Any contentious RFS issues in the benefit period (BP) must be adjudicated. 

## Regional considerations

Source topic: `en_EN/activity/dismissal/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/dismissal/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/activity/dismissal/in_nws.dita`

- Are there are any SROCs, Action Item WIs or documentation containing checklists or other details relating to the dismissal or suspension? 

### In FTS:

Source topic: `en_EN/activity/dismissal/in_fts.dita`

- Is there an initial, continuing or renewal claim? 

## What do you want to do?

Source topic: `en_EN/activity/dismissal/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/dismissal/policy_reference.dita`

 
