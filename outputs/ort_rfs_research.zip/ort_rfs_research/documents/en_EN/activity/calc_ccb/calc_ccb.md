# Calculating or recalculating a claim for CCB

Source map: `en_EN/activity/calc_ccb/calc_ccb.ditamap`

## Summary

Source topic: `en_EN/activity/calc_ccb/summary.dita`

Summary: When a client applies for CCB, an officer must calculate the claim. 

## What you need to know

Source topic: `en_EN/activity/calc_ccb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/activity/calc_ccb/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0018.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Manually calculating a claim

Source topic: `en_EN/activity/calc_ccb/manually_calculating_a_claim.dita`

The manual calculation of a claim is complex and must only be done by a trained officer.

An officer must calculate or recalculate a claim when:

- a client applies for benefits using a paper application;

- ACP is unable to automate an electronic application;

- a claim requires a recalculation and ACP is unable to automate the recalculation. 

### Calculation versus recalculation

Source topic: `en_EN/activity/calc_ccb/calculation_versus_recalculation.dita`

When a Claim Assessment (CA) or Specialized Application (SA) WI is received, the officer must complete the initial calculation of a claim.

When a Claim Review (CR) WI with a recalculation issue is received, the officer must complete a new calculation of a previously finalized claim. A recalculation is sometimes referred to as a “recomp.” Once an initial calculation is successfully transmitted, a claim must be recalculated when new information is received that will have an effect on the previous calculation result (e.g. an amended ROE is issued).

When a recalculation is required for an Integrity case, an urgent Action Item (AI) WI is created for the recalculation. The officer assigned to this WI must complete the recalculation.

The recalculation of a claim can affect the following:

- the client’s ability to establish a benefit period (BP);
         [benefit period](/en/procedure/generic/knowledge.shtml#Establishing_a_benefit_period)

- the client’s entitlement to benefits;

- the client’s benefit rate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0020.dita) 

### Recalculating a claim affected by a SIN or region change

Source topic: `en_EN/activity/calc_ccb/recalculating_a_claim_affected_by_a_sin_5e2e09cf.dita`

If the client has moved to a different region, changed SINs, or both, since the initial claim was calculated, registering the recalculation in SSO may not be possible. The recalculation must be registered under the original information technology centre (ITC) and SIN when necessary, but must be transmitted manually in FTS under the current ITC and new SIN, if applicable.

For more information, the officer refers to the Appendices B, C and D of the Recalculation input guide – SSA version .
       [Recalculation input guide – SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml) 

### Structure of calculation procedures

Source topic: `en_EN/activity/calc_ccb/structure_of_calculation_procedures.dita`

The calculation procedure is divided into sub-activities to provide a logical sequence to follow when calculating a claim. Although individual officers may have a preferred sequence that is also correct, the procedure is structured to ensure the officer completes all the actions required to process the claim:

- Determining if the claim is ready to be calculated.

- Calculating a claim in SSO.

- Reviewing the calculation result.

- Reviewing and inputting the calculation.

- Communicating decisions after calculation.

Within each sub-activity, there are links to additional procedures that may be required to complete the calculation process. 

### Managing the WI

Source topic: `en_EN/activity/calc_ccb/managing_the_wi.dita`

Regardless of how an officer organizes the work, the officer assigned to complete the calculation of a claim must ensure that any issues are addressed and all the facts required to calculate the claim are on file before completing the calculation. Unless otherwise noted in the procedures, the officer must not complete the calculation until all related WIs necessary to finalize the calculation are completed. If the calculation cannot be completed because of an outstanding related WI, the WI for calculation is moved to Pending until the related WI is completed.

Multiple officers may be assigned WIs for the same claim being assessed (e.g. one officer is assigned an ROE reason for separation [RFS] Action WI and one is assigned the CA WI). The officers complete only the WI to which they are assigned unless instructed otherwise by a procedure.

When assessing the claim, the officer assigned the calculation must also review any client Note for actions required (e.g. inputting transactions, sending letters).

When the calculation is complete, the officer must communicate the decision to the client as necessary. 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/activity/calc_ccb/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an AI, Call Back (CB), Assessment Issue (ASMT) or Reminder (REM) WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### Sharing information

Source topic: `en_EN/activity/calc_ccb/sharing_information.dita`

Up to 26 clients may share in CCB for any one patient.

When a client submits an AW application for CCB or submits the Compassionate Care Benefits - Annex 5 form with a paper application for CCB, the client is informed that in certain situations, information may be shared with other members of the patient’s family. This may include disclosure of the client’s identity to other members of the family who have claimed CCB. Similarly, the total number of weeks paid and payable may be disclosed to a family member who requests CCB.

If a person who is not a client wants to know whether other family members of the patient have claimed or received CCB, the officer must advise the individual that this information cannot be disclosed. However, when an individual intends to claim CCB, the number of weeks payable can be disclosed. No other information may be provided until the claim has been submitted. The officer must not reveal another client’s SIN to anyone at any time. 

### Qualifying for CCB

Source topic: `en_EN/activity/calc_ccb/qualifying_for_ccb.dita`

To qualify for CCB, a client must meet the following conditions:

- The client has applied for benefits.

- The client has had an interruption of earnings (I of E) in the qualifying period (QP).
         [interruption of earnings](/en/procedure/generic/knowledge.shtml#Interruption_of_earnings) 
         [qualifying period](/en/procedure/generic/knowledge.shtml#Qualifying_period)

- The client is major attached (has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0021.dita) 

**Qualifying for benefits with the common entrance requirement (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national common entrance requirement (CER) of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the definitions for major attach and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to CCB

Source topic: `en_EN/activity/calc_ccb/entitlement_to_ccb.dita`

To be entitled to CCB, a client must meet the following conditions:

- The client can provide a medical certificate which proves that a patient who is a family member (as outlined in Family member ) meets both of the following conditions:

- The patient has a serious medical condition with a risk of death within 26 weeks.

- The patient requires care or support from one or more family members.

         [Family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

- The client is providing care or support to the patient identified on the medical certificate.

- The client requests the benefits during the compassionate care window (CCW) established for the patient.

- The 26 payable weeks of CCB have not already been paid during the CCW for the patient.

A major attached client is entitled to receive special benefits regardless of the RFS.
       [special benefits](/en/procedure/generic/knowledge.shtml#Special_Benefits)

An administrative disentitlement is imposed to prevent the payment of regular benefits for a client who qualifies for special benefits but not for regular benefits. 

### Medical certificate

Source topic: `en_EN/activity/calc_ccb/medical_certificate.dita`

A client applying for CCB must be able to provide a medical certificate that proves the client’s gravely ill family member (patient) requires care and support. The medical certificate must be completed by a doctor or other medical practitioner and must confirm the patient is at risk of death within 26 weeks and requires care or support from one or more family members.

It is not always necessary for a client to submit a medical certificate because only one medical certificate is required per patient, per CCW, regardless of how many family members are collecting benefits for providing care and support to the patient. If a medical certificate is required and not provided, the officer imposes a 53 - Compassionate care benefits - No medical proof disentitlement on the claim. If a medical certificate is required but does not meet the conditions required, the officer imposes a 51 - Does not meet compassionate care entitlement conditions disentitlement on the claim. An officer must not request a medical certificate unless it is required. If a medical certificate is received but not required, the officer must review it and update the file according to the information the medical certificate provides. 

### Compassionate care window (CCW)

Source topic: `en_EN/activity/calc_ccb/compassionate_care_window_ccw.dita`

When an acceptable medical certificate as proof of the patient’s medical condition is received, a CCW is established for a period of 52 weeks or until the week of the patient’s death, whichever occurs first. Once a CCW is established, it cannot be extended. If additional CCB are required, a new CCW may be established after the initial CCW ends. 

### Paying benefits

Source topic: `en_EN/activity/calc_ccb/paying_benefits.dita`

The maximum number of weeks of CCB payable in a BP is 26 for one or more patients. Up to 26 clients may share in CCB for any one patient. A maximum of 26 weeks is payable per gravely ill family member. CCB can be paid only during a CCW.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0022.dita) 

Once the claim is established and it is determined that CCB are payable, CCB are payable for each week the client submits a claimant’s report and:

- declares 5 non-available days

- has provided the required proof for CCB

- does not have earnings or allocations preventing payment

- does not have a disentitlement preventing payment

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0023.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0018.dita`

Note:

CCB claims are processed in selected CCB offices .
       [selected CCB offices](https://esdc.prv/en/service-canada/ei/contacts/compassionate_care.shtml)

     [selected CCB offices](https://esdc.prv/en/service-canada/ei/contacts/compassionate_care.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_0020.dita`

Note:

When the recalculation of a claim is required, the officer follows the normal calculation assessment procedures and refers to Recalculation: Assessment — Instructions and the Recalculation input guide – SSA version if necessary. A claim requiring a recalculation must be assessed in the same manner as a claim requiring an initial calculation.
       [Recalculation: Assessment — Instructions](/en/procedure/generic/additionalresources/recalculation_assessment.shtml) 
       [Recalculation input guide – SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml)

     [Recalculation: Assessment — Instructions](/en/procedure/generic/additionalresources/recalculation_assessment.shtml) 
     [Recalculation input guide – SSA version](https://edsc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0021.dita`

Note:

If the client has a violation, there may be increased entrance requirements .
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Note

Source topic: `en_EN/common_notes/note_c_0022.dita`

Note:

The WP may be deferred for a client receiving CCB.
       [WP](/en/procedure/generic/knowledge.shtml#Waiting_period)

     [WP](/en/procedure/generic/knowledge.shtml#Waiting_period) 

### Note

Source topic: `en_EN/common_notes/note_c_0023.dita`

Note:

A client receiving CCB may request an exemption from completing claimant’s reports. 

## Regional considerations

Source topic: `en_EN/activity/calc_ccb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/calc_ccb/what_you_need_to_look_for.dita`

## What do you want to do?

Source topic: `en_EN/activity/calc_ccb/what_do_you_want_to_do.dita`

- Determining if a claim is ready to be calculated — CCB
         [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- Calculating a claim in SSO
         [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Reviewing the calculation result
         [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml)

- Reviewing and inputting the calculation
         [Reviewing and inputting the calculation](/en/procedure/subactivity/input_calculation_results.shtml)

- Communicating decisions after calculation
         [Communicating decisions after calculation](/en/procedure/subactivity/communicating_calc_decisions.shtml) 

## Policy reference

Source topic: `en_EN/activity/calc_ccb/policy_reference.dita`

 
