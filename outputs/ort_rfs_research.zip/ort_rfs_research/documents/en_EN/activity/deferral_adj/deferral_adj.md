# Deferral of adjudication

Source map: `en_EN/activity/deferral_adj/deferral_adj.ditamap`

## Summary

Source topic: `en_EN/activity/deferral_adj/summary.dita`

Summary: In certain situations, adjudication of a contentious issue can be deferred. 

## What you need to know

Source topic: `en_EN/activity/deferral_adj/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/activity/deferral_adj/untitled_section.dita`

When clients apply for EI, they must meet the entitlement conditions for the benefit type (BT) they are requesting. In certain situations, the officer can defer the adjudication of issues such as a contentious reason for separation (RFS) (including leave of absence) or availability. 

### Initial claims

Source topic: `en_EN/activity/deferral_adj/initial_claims.dita`

There are 14 main situations in which adjudication can be deferred on an initial claim:

- any adjudication issue when the claim is automated BPNE 2;

- any adjudication issue when the claim is a manual BPNE 2 at day 27;

- any adjudication issue when the claim is automated BPNE 1 or 5;

- any adjudication issue when the claim is a manual BPNE 1 or 5;

- any adjudication issue when the client has less than 420 hours in the qualifying period (QP) and is requesting regular or sickness benefits;

- any adjudication issue when the client has less than 600 hours in the QP and is requesting special benefits other than sickness benefits;

- the RFS is B - Strike or lockout (labour dispute) and the claim is BPNE;

- a contentious RFS when the last ROE is the only ROE with a contentious RFS in the QP, the client is otherwise available for work and qualifies for sickness benefits;

- a contentious RFS when the last ROE is the only ROE with a contentious RFS in the QP and the client qualifies for special benefits other than sickness benefits;

- a contentious RFS before a disqualifying event in the QP when the client requesting benefits did not work enough hours since the disqualifying event to gain relief from the indefinite disqualification;

- a contentious RFS before a disqualifying event that results in an indefinite disqualification when the client is otherwise available for work and qualifies for sickness benefits;

- a contentious RFS before a disqualifying event that results in an indefinite disqualification when the client qualifies for special benefits other than sickness benefits.

- a leave of absence when:

- the leave is not the RFS on the last ROE;

- the client started new employment while on a leave of absence from the previous employment;

- the client stopped working for medical reasons (RFS on the last ROE is D - Illness or Injury );

- the client is otherwise available for work and qualifies for sickness benefits.

- a leave of absence when:

- the leave is not the RFS on the last ROE;

- the client started new employment while on a leave of absence from the previous employment;

- the client has stopped working for reasons related to the requested benefit type (BT);

- the RFS on the last ROE is F , P or Z ;

- the client qualifies for special benefits.

**Budget 2021 temporary measures:**

- When the BPC is between w/cs 2310 and 2361, adjudication of a contentious RFS before the last period of employment is not deferred, because adjudication is not required on contentious RFS in the QP before the last period of employment. This measure does not apply on claims for fishing benefits or benefits for the self-employed.

- When the BPC is between w/cs 2310 and 2361 and the claim is for sickness benefits, adjudication of the RFS for the last period of employment can be deferred, regardless of the RFS on other ROEs in the QP, as long as the client is otherwise available for work and qualifies for sickness benefits. This measure does not apply on claims for fishing benefits or benefits for the self-employed.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0081.dita) 

### Claim other than initial

Source topic: `en_EN/activity/deferral_adj/claim_other_than_initial.dita`

On a renewal, conversion or continuing claim, adjudication is deferred in the following situations:

- on any contentious RFS when there is an existing indefinite disqualification for:

- regular benefits, if the client has not accumulated enough hours since the disqualifying event to establish a new initial claim;

- sickness benefits, if the client is otherwise available for work;

- all cases of maternity, parental, CCB and family caregiver benefits.

- on any contentious RFS when:

- the client qualifies for sickness, maternity, parental, CCB or family caregiver benefits;

- there is an existing indefinite 46 - Variable entrance requirement not met - special benefits payable disentitlement (D46);

- the client is otherwise available (sickness benefits only).

- on any contentious RFS when:

- the client qualifies for sickness, maternity, parental, CCB or family caregiver benefits;

- the contentious RFS does not impact benefits previously paid;

- the client is not requesting regular benefits for any period after the contentious RFS.

- the client is otherwise available (sickness benefits only).

- on a leave of absence when:

- the leave is not the RFS on the last ROE;

- the client started new employment while on a leave of absence from the previous employment;

- the client stopped working for medical reasons (RFS on the last ROE is D - Illness or Injury );

- the client is otherwise available for work and qualifies for sickness benefits.

- on a leave of absence when:

- the leave is not the RFS on the last ROE;

- the client started new employment while on a leave of absence from the previous employment;

- the client stopped working for reasons related to the requested BT;

- the RFS on the last ROE is F , P or Z ;

- the client qualifies for special benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0082.dita) 

**Budget 2021 temporary measures**

On claims for regular benefits, when the BPC is between w/cs 2310 and 2361, the officer adjudicates any new contentious RFS in the benefit period (BP). Adjudication cannot be deferred even if there is an indefinite disqualification for a contentious RFS that was not allowed. This measure does not apply to claims for SE or fishing benefits. 

### Client not requesting benefits

Source topic: `en_EN/activity/deferral_adj/client_not_requesting_benefits.dita`

When a new contentious RFS is received on an established claim, whether active or dormant, the officer can defer adjudication if the following 2 conditions are met:

- The contentious RFS does not impact any period for which benefits have already been paid.

- The client is not requesting benefits for any period after the contentious RFS. 

### Exception — Integrity investigation

Source topic: `en_EN/activity/deferral_adj/exception__integrity_investigation.dita`

The Level 2 officer must adjudicate all contentious RFSs that are part of an Integrity investigation. The adjudication of an Integrity investigation decision cannot be deferred. 

### Adjudication Issue (ADJ) WIs

Source topic: `en_EN/activity/deferral_adj/adjudication_issue_adj_wis.dita`

ADJ WIs are created when a contentious issue is identified on initial or renewal claims for benefit. The initial claim cannot be calculated, or the renewal claim cannot be finalized until all ADJ WIs are completed.

For some ADJ WIs, there is a Resolve Issue tab which includes screens where the officer documents the decision. When the ADJ WI is completed, NWS creates a record of decision (ROD) based on the Resolve Issue screens.

When there is no Resolve Issue tab on the ADJ WI, the officer is responsible for creating the ROD. For all ADJ WIs, the officer updates the Special condition field on the ROE, if necessary. 

### Communication

Source topic: `en_EN/activity/deferral_adj/communication.dita`

There is no requirement to send the client a written notification of deferred adjudication for any contentious RFS issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Note

Source topic: `en_EN/common_notes/note_c_0081.dita`

Note:

The officer cannot defer adjudication for a contentious RFS before a disqualifying event in the QP if it results in the ROE being excluded from calculation. In this case, any prior RFS must be adjudicated as hours and earnings could be included in the calculation. 

### Note

Source topic: `en_EN/common_notes/note_c_0082.dita`

Note:

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, a D46 will not be input on these claims. 

## Regional considerations

Source topic: `en_EN/activity/deferral_adj/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/deferral_adj/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/activity/deferral_adj/in_fts.dita`

- What is the BT of the claim?

- Is the claim an initial or renewal? 

### In NWS:

Source topic: `en_EN/activity/deferral_adj/in_nws.dita`

- What BT did the client apply for? 

## What do you want to do?

Source topic: `en_EN/activity/deferral_adj/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/deferral_adj/policy_reference.dita`

 
