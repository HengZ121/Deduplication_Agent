# Access code

Source map: `en_EN/activity/access_code/access_code.ditamap`

## Summary

Source topic: `en_EN/activity/access_code/summary.dita`

Summary: To ensure the confidentiality of information relating to a claim for benefits, the system issues an access code. This access code is on the first benefit statement sent to the client. 

## What you need to know

Source topic: `en_EN/activity/access_code/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/activity/access_code/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0001.dita) 

- **COVID-19 Alert — Updated March 24, 2021 (Select for additional information)**

           [Danger](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0002.dita) 

### Function of the access code

Source topic: `en_EN/activity/access_code/function_of_the_access_code.dita`

The SIN and the access code allow clients to:

- obtain personal information about their claim for benefits through any of the following channels:

- MSCA-EI

- the Telephone Information Service (TIS)

- a Service Canada Centre (SCC)

- call centres

- complete electronic claimant’s reports through TRS or IRS.

     [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0003.dita) 

### Replacing an access code

Source topic: `en_EN/activity/access_code/replacing_an_access_code.dita`

Clients can replace their own access code using TIS. When clients lose or forget their access code, they are unable to access TIS or complete electronic claimant’s reports. However, it is possible for a Service Canada agent to replace the original access code or issue a temporary one. Replacing the access code with either the original code or a temporary code automatically restores the client’s access to these services. 

### Detailed security check

Source topic: `en_EN/activity/access_code/detailed_security_check.dita`

A detailed security check must be conducted with the client before providing information or issuing an access code. The agent does not accept requests to reissue an access code from a third party, unless it is from the designated representative. In the case of a representative, ensure that there is no electronic document indicating that the client has recovered and no longer requires the services of the representative. Representatives are identified in FTS with the indicator “/REP/”. For additional information, refer to Appointment of representative — Limited physical or mental capacity .
       [Appointment of representative — Limited physical or mental capacity](/en/procedure/activity/app_rep.shtml) 

### Issuing an original or temporary access code

Source topic: `en_EN/activity/access_code/issuing_an_original_or_temporary_access_code.dita`

After completing the detailed security check, the agent issues the original access code and sends it by mail. However, when clients have an electronic claimant’s report that is past due or imminent (within the next 5 business days), the agent issues a temporary access code which the client must replace by contacting TIS. 

### Note

Source topic: `en_EN/common_notes/note_c_0001.dita`

Note:

Officers trained in Cúram Universal Access refer to Cúram Procedures .
       [Cúram Procedures](/en/procedure/generic/procedure-relatives-curam-curam-procedures.shtml)

A Cúram claim can be identified in FTS by the presence of a padlock icon (the Cúram Claim Indicator) next to the client’s SIN.

     [Cúram Procedures](/en/procedure/generic/procedure-relatives-curam-curam-procedures.shtml) 

### Danger

Source topic: `en_EN/common_notes/note_c_0002.dita`

This page is affected by COVID-19 special measures. COVID-19 related changes are not highlighted. For more information, the agent refers to the appropriate Headlines and Updates page.

- March 24, 2021 — This procedure has been updated to include fraudulent EI claims ( more information ).
         [more information](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml)

     [more information](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Warning

Source topic: `en_EN/common_notes/note_c_0003.dita`

Warning:

If fraudulent activity is suspected on an EI or EI Emergency Response Benefit (EI ERB) claim, the agent does not issue the access code. For more information, the agent refers to Determining if an issue must be referred to Integrity for more information.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

     [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

## Regional considerations

Source topic: `en_EN/activity/access_code/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/access_code/what_you_need_to_look_for.dita`

### In NWS

Source topic: `en_EN/activity/access_code/in_nws.dita`

- What personal information did the client indicate in the Personal Information section of the application? 

### In FTS

Source topic: `en_EN/activity/access_code/in_fts.dita`

- Is this a new claim that has not been registered?

- Is the client’s personal information available?

- Is there a claimant’s report due in the next 5 business days? 

## What do you want to do?

Source topic: `en_EN/activity/access_code/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/access_code/policy_reference.dita`

 
