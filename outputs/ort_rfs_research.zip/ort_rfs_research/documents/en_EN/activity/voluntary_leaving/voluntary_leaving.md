# Voluntary leaving

Source map: `en_EN/activity/voluntary_leaving/voluntary_leaving.ditamap`

## Summary

Source topic: `en_EN/activity/voluntary_leaving/summary.dita`

Summary: When clients voluntarily leave employment, their entitlement to regular benefits may be affected. Adjudication is required to determine if there is just cause for leaving the employment. 

## What you need to know

Source topic: `en_EN/activity/voluntary_leaving/what_you_need_to_know.dita`

### Voluntarily leaving employment

Source topic: `en_EN/activity/voluntary_leaving/voluntarily_leaving_employment.dita`

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave the employment. If it is determined that the client left the employment without just cause, an indefinite disqualification is imposed on the claim for regular benefits, unless the client has worked enough insurable hours since the voluntary leaving to establish a new claim. In that case, on an initial claim, the ROE with the voluntary leaving without just cause is excluded from the calculation of the claim. On a renewal claim, the renewal is processed without a disqualification.

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is only required on the most recent ROE in the QP, if the RFS is contentious. In addition, the common entrance requirement of 420 hours of insurable employment is not used to determine if the client requalifies after a disqualifying event. Instead, the client needs to have worked at least one hour in insurable employment since the disqualifying event and to have filed an EI application.

If the RFS since the disqualifying event on claims with a BPC between w/c 2310 and w/c 2361 is either non-contentious or is adjudicated and allowed, the officer can establish a new claim without a disqualification using the hours from all the ROEs in the QP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0164.dita) 

The clients are responsible for advising the Commission in a timely manner of any jobs they have left while on a claim. 

### Leaving before an anticipated end of employment

Source topic: `en_EN/activity/voluntary_leaving/leaving_before_an_anticipated_end_of_employment.dita`

A disqualification is not imposed on a claim for regular benefits when the client voluntarily leaves without just cause within 3 weeks of the anticipated end of the employment. In that case, a disentitlement is imposed. A disentitlement is also imposed when the client takes a temporary leave of absence from the employment without just cause. 

### Reasons for leaving employment

Source topic: `en_EN/activity/voluntary_leaving/reasons_for_leaving_employment.dita`

Reasons for voluntarily leaving employment include:

- other employment (includes SE)

- to follow another individual

- medical reasons

- course of instruction

- retirement (includes approved workforce reductions)

**Mandatory retirement**

Human rights legislation in Canada prohibits mandatory retirement. Very few occupations are exempt from this legislation. Some employers may be able to demonstrate a genuine reason for mandatory retirement. However cases are rare.

Employers are instructed to choose G - Mandatory retirement as the RFS on the ROE only in cases of mandatory retirement, and to choose E - Quit as the RFS in cases of voluntary retirement.

A mandatory retirement cannot be considered as voluntary leaving. In cases where clients do not voluntarily leave their employment, the separation is initiated by the employer. A Level 2 officer must adjudicate the RFS as a dismissal .
       [dismissal](/en/procedure/activity/dismissal.shtml) 

### ROE

Source topic: `en_EN/activity/voluntary_leaving/roe.dita`

An ROE is not required to adjudicate voluntary leaving. 

### Processing the claim

Source topic: `en_EN/activity/voluntary_leaving/processing_the_claim.dita`

Voluntary leaving can occur on initial, renewal and continuing claim types. The claim type determines the required actions when the issue is adjudicated.

**Automated adjudication**

When clients apply online for benefits, for either an initial or a renewal claim, the client must indicate on the electronic questionnaire why they voluntarily left their job. The clients’ answers are used in combination with logic based on the National policy on Levels of Decision to determine if the voluntary leaving can be auto-adjudicated by ACP. Currently, ACP can adjudicate the following reasons for voluntary leaving:
       [National policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- starting another job

- leaving a part-time job for a full-time job

- employment relocation of a spouse or a common-law partner

- moving in with a common-law partner or a fiancé

- moving with a parent(s) or a legal guardian

When ACP adjudicates a voluntary leaving, a ROD is automatically created.

If there is an ADJ WI for a contentious RFS that falls after the BPC date on a claim with a status of In Progress (Automation) or In Progress (Manual) , the officer follows the Adjudicating voluntary leaving: Initial Claim — Level 2 . The system updates the Special condition field of the ROE when the ADJ WI is completed. If necessary, the officer manually inputs the disqualification in FTS.
       [Adjudicating voluntary leaving: Initial Claim — Level 2](/en/procedure/task/vllevel2_ic.shtml)

**Levels of decision**

When ACP cannot adjudicate the voluntary leaving, an ADJ WI is created and assigned to the appropriate level according to the National policy on Level of Decision policy.
       [National policy on Level of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

**Reviewing an initial or renewal claim**

When a client indicates on the application that the details for the RFS have already been provided, the voluntary leaving questionnaire is not presented. The same applies when a client does not declare a contentious RFS on the application. In this situation, the Level 1 officer initiates fact-finding with the client to determine which procedure to choose. If the client indicates a reason that does not fall within Level 1 authority, the officer reassigns the WI to Level 2.

**Adjudicating a continuing claim**

For continuing claims, the officer manually creates the ROD and, if necessary, inputs the disqualification in FTS. 

### Reason for separation (RFS) — Temporary Budget measures

Source topic: `en_EN/activity/voluntary_leaving/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**Adjudicating the last employment in the qualifying period (QP) — BPCs between w/c 2310 and w/c 2361**

Budget 2021 has introduced a temporary simplification measure starting September 26, 2021. For claims with a BPC between w/c 2310 and w/c 2361, the officer will only adjudicate the last period of employment in the QP if it is contentious. If the officer allows the last RFS, all other ROEs in the QP, even if they are contentious, are used to calculate the claim. If, however, the officer does not allow the RFS on the last ROE in the QP, the claim is calculated with a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 

This new measure does not apply fishing claims and claims from self-employed people. Instead, if clients have insurable employment in the QP with a contentious RFS and a BPC between w/c 2310 and w/c 2361 when they apply for self-employment (SE) or fishing benefits, the officer must adjudicate the contentious RFS following normal adjudication procedures.

When the client declares other employers with a contentious RFS on the same application, if ACP does not allow the issue under auto-adjudication rules, the issue is automatically resolved and ACP creates a record of decision (ROD) that shows Adjudication not Required . The Special condition field on the ROE is not updated, and the ROE is included in the calculation. An Adjudication Issue (ADJ) WI is not created for the RFS.

When there is more than one ROE with the same last day paid (LDP), and one of the ROEs is contentious while the other ROE is not, adjudication is not required and both ROEs will be included in the calculation.

**Adjudication not required — Reason for separation (RFS) beyond 12 weeks – BPCs between w/c 2258 and w/c 2309**

Adjudication principles on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309 only apply to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the interruption of earnings (I of E) used to establish the claim.

**Adjudication not previously required — Specialized ACP process**

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the QP. The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0092.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0164.dita`

Note:

For claims with BPCs between w/c 2310 and w/c 2361 excluded ROEs only apply to SE benefits and fishing claims. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0092.dita`

Note:

Any contentious RFS issues in the benefit period (BP) must be adjudicated. 

## Regional considerations

Source topic: `en_EN/activity/voluntary_leaving/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/voluntary_leaving/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/activity/voluntary_leaving/in_nws.dita`

- What is the client’s statement in the Voluntary Leave section of this or a prior application?

- Are there any SROCs, Action Item WIs or documentation containing checklists or other details relating to the voluntary leaving on this or a prior application? 

### In Imaging:

Source topic: `en_EN/activity/voluntary_leaving/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving? (Documents may have been received before the most recent application.) 

## What do you want to do?

Source topic: `en_EN/activity/voluntary_leaving/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/voluntary_leaving/policy_reference.dita`

 
