# ROE Issue RFS Action WI

Source map: `en_EN/activity/roe_rfs/roe_rfs.ditamap`

## Summary

Source topic: `en_EN/activity/roe_rfs/summary.dita`

Summary: When an ROE is received with a contentious reason for separation (RFS) on an initial Web application, if the system cannot create a link between the ROE and a matching period of employment reported on the application or determine if the RFS requires adjudication, an ROE RFS Action WI is created. 

## What you need to know

Source topic: `en_EN/activity/roe_rfs/what_you_need_to_know.dita`

### Linking the ROE and the matching period of employment

Source topic: `en_EN/activity/roe_rfs/linking_the_roe_and_the_matching_period_f71580ff.dita`

When an ROE with a contentious RFS is received, the system verifies whether there is a matching period of employment reported on the initial Web application. If a match is found, the system creates a link from the ROE to the matching period of employment and then determines if there is an electronic record of decision (ROD) for the RFS issue or an outstanding Adjudication Issue (ADJ) WI. 

### The system is unable to create a link

Source topic: `en_EN/activity/roe_rfs/the_system_is_unable_to_create_a_link.dita`

The system creates an ROE RFS Action WI when it is unable to create a link between the ROE and a matching period of employment. The system also creates an ROE RFS Action WI when it creates a link between the ROE and a matching period of employment and when the following conditions are met:

- there is no outstanding ADJ WI

- there is no electronic ROD for the issue or there are comments on the ROE

The system creates the ROE RFS Action WI at the Non-complex level only and it cannot be reassigned to Level 1 or Level 2.

**Agent actions required**

The Non-complex agent reviews the ROE and, if applicable, creates a link to the matching period of employment. When there is a Resolve Issue section for the WI, the Non-complex agent determines if the RFS details must be modified. If there is a decision on file, the agent selects the appropriate Special Condition option when applicable. The system updates the ROE based on the options selected by the agent in the ROE RFS Action WI. Once the ROE RFS Action WI is completed, the system determines if an ADJ WI must be reactivated or created. No further action is required by the Non-complex agent. 

## Regional considerations

Source topic: `en_EN/activity/roe_rfs/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/roe_rfs/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/activity/roe_rfs/in_nws.dita`

- What is the RFS indicated in the Details section of the Specific Details tabof the ROE RFS Action WI?

- If the RFS is Other , does the serial number of the ROE start with Z or Y (indicating that it is a fishing ROE)? 

## What do you want to do?

Source topic: `en_EN/activity/roe_rfs/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/roe_rfs/policy_reference.dita`

 
