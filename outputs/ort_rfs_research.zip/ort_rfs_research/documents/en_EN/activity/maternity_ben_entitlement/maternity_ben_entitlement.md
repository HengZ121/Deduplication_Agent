# Maternity benefits — Entitlement

Source map: `en_EN/activity/maternity_ben_entitlement/maternity_ben_entitlement.ditamap`

## Summary

Source topic: `en_EN/activity/maternity_ben_entitlement/summary.dita`

Summary: Clients applying for maternity benefits must prove that they are entitled to maternity benefits for a period of physical inability to work due to pregnancy or childbirth. 

## What you need to know

Source topic: `en_EN/activity/maternity_ben_entitlement/what_you_need_to_know.dita`

### Qualifying for maternity benefits

Source topic: `en_EN/activity/maternity_ben_entitlement/qualifying_for_maternity_benefits.dita`

Maternity benefits are available to a client who is away from work due to pregnancy or childbirth.

To qualify for maternity benefits, a client must meet the following conditions:

- She has applied for benefits;

- She has had an interruption of earnings (I of E) in the qualifying period (QP);
         [interruption of earnings](/en/procedure/generic/knowledge.shtml#Interruption_of_earnings) 
         [qualifying period](/en/procedure/generic/knowledge.shtml#Qualifying_period)

- She is major attached (has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0127.dita) 

**Qualifying for benefits with the common entrance requirement (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national common entrance requirement (CER) of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to maternity benefits

Source topic: `en_EN/activity/maternity_ben_entitlement/entitlement_to_maternity_benefits.dita`

To be entitled to maternity benefits, a client must provide proof of the pregnancy.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0027.dita) 

Maternity benefits can no longer be paid when one of the following occurs:

- The benefit period (BP) has expired.

- The maximum entitlement to benefits payable on that claim has been reached.
         [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

- The maternity window has expired.

- The maximum number of weeks of maternity benefits has been paid. 

### Proof of pregnancy

Source topic: `en_EN/activity/maternity_ben_entitlement/proof_of_pregnancy.dita`

As proof of the pregnancy, the client must provide a signed statement attesting to her pregnancy and the expected date of birth (DOB). The attestation at the end of an EI application is accepted as a signed statement. A completed and signed Maternity or parental: INS5168 Annex 3 — Form is also accepted as proof of pregnancy. If the officer completes the INS5168 form with the client, a verbal attestation is not acceptable. The officer informs the client that she can complete the form in one of the following ways:
       [Maternity or parental: INS5168 Annex 3 — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5168.pdf)

- returning the form in person;

- printing the form online and mailing it to Service Canada;

- having the officer mail the form to the client to sign and return.

The client must also advise Service Canada of the actual DOB as soon as possible. 

### Maternity window

Source topic: `en_EN/activity/maternity_ben_entitlement/maternity_window.dita`

The maternity window is the period during which maternity benefits can be paid. The maternity window starts the earlier of the following dates:

- 12 weeks before the expected DOB (expected DOB – 12 weeks);

- the actual DOB.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0128.dita) 

The maternity window ends the later of the following dates:

- 17 weeks after the expected DOB (expected DOB + 17 weeks);

- 17 weeks after the actual DOB (actual DOB + 17 weeks).

**Extending the maternity window**

To allow the client more time to collect the maternity benefits to which she is entitled, the maternity window can be extended by one week for each week or partial week that a newborn is hospitalized. The maximum extension of the maternity window is 52 weeks after the actual DOB (actual DOB + 52 weeks). The number of weeks of maternity entitlement remains the same. For more information, the officer refers to Extension of the maternity window .
       [Extension of the maternity window](/en/procedure/generic/knowledge.shtml#Extending_the_maternity_range) 

### Applying for maternity benefits

Source topic: `en_EN/activity/maternity_ben_entitlement/applying_for_maternity_benefits.dita`

A claim for maternity benefits cannot generally be established outside of the maternity window. However, a client can establish a BP for maternity benefits the week before the maternity window if all of the following conditions are met:

- The client qualifies for regular benefits.

- The client is applying for maternity benefits from the onset of the claim.

- The client serves a waiting period (WP) immediately before the maternity window.

When all of the conditions are met, the client can serve her WP in the week immediately before the maternity window. 

### Payment of benefits

Source topic: `en_EN/activity/maternity_ben_entitlement/payment_of_benefits.dita`

Maternity benefits can be paid for a maximum of 15 weeks in a BP. The 15 weeks payable for a single pregnancy can be paid over 2 BPs. Maternity benefits are not payable outside of the maternity window. If the entitlement conditions are met, maternity benefits are paid automatically based on the maternity window. Once the claim is established and it is determined that maternity benefits are payable, maternity benefits are payable for each week the client submits a claimant’s report and:

- declares 5 non-available days;

- has provided the required proof for maternity benefits;

- does not have earnings or allocations preventing payment;

- does not have a disentitlement preventing payment. 

### Termination of pregnancy

Source topic: `en_EN/activity/maternity_ben_entitlement/termination_of_pregnancy.dita`

When a pregnancy is terminated within the first 19 weeks, the claim is treated as a sickness claim. If a pregnancy is terminated after the 19th week, the claim is treated as a maternity claim. 

### Sickness benefits during the maternity window

Source topic: `en_EN/activity/maternity_ben_entitlement/sickness_benefits_during_the_maternity_window.dita`

If a client is unable to work for medical reasons and she is pregnant, she can apply for sickness benefits before maternity benefits. If no regular benefits have been received on the claim, the client may be entitled to an extension of the BP to collect her full maternity and parental entitlement.
       [extension of the BP](/en/procedure/generic/knowledge.shtml#Extending_the_benefit_period)

To receive sickness benefits, the client must prove that she is otherwise available for work for the period for which she requests sickness benefits. This may be difficult to prove if the client had already arranged with her employer to start her maternity leave before or during the period for which she is requesting sickness benefits. Therefore, the officer may need to verify the information with the employer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0129.dita) 

### External maternity start week or end week

Source topic: `en_EN/activity/maternity_ben_entitlement/external_maternity_start_week_or_end_week.dita`

When a client is entitled to other benefits during the maternity window, an external maternity start week is required to prevent the payment of maternity benefits. If a client is entitled to fewer than 15 weeks of maternity benefits, as is the case when maternity benefits are paid over 2 BPs, an external maternity end week is required to prevent all 15 weeks from being paid. 

### Actual date of birth (DOB) reported

Source topic: `en_EN/activity/maternity_ben_entitlement/actual_date_of_birth_dob_reported.dita`

Often, when a maternity claim is set up, the only date available to the officer is the expected DOB. Maternity benefits are then set up with that information. If the actual DOB is provided and it differs from the expected DOB used to establish the claim, the officer may need to input more information to ensure the maternity window and parental window (PW) are correct.

When a client reports that the actual DOB falls in a period when sickness benefits were already paid, the officer determines if the client is otherwise available. 

### Note

Source topic: `en_EN/common_notes/note_c_0127.dita`

Note:

If the client has a violation, there may be increased entrance requirements. 

### Note

Source topic: `en_EN/common_notes/note_c_0027.dita`

Note:

If the reason for separation (RFS) on the last ROE is P - Parental and maternity benefits were requested, additional fact-finding is required. The officer contacts the employer first to ensure the RFS on the ROE is correct. If so, the officer then contacts the client to ensure the requested benefit type (BT) is correct. If the client has applied for the wrong BT, the officer refers to Determining during calculation if the client applied for the wrong benefit type .
       [Determining during calculation if the client applied for the wrong benefit type](/en/procedure/task/calc_determining/wrong_bt_requested.shtml)

     [Determining during calculation if the client applied for the wrong benefit type](/en/procedure/task/calc_determining/wrong_bt_requested.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0128.dita`

Note:

Before December 3, 2017, the start date of the maternity window was 8 weeks before the expected DOB or the actual DOB. 

### Note

Source topic: `en_EN/common_notes/note_c_0129.dita`

Note:

Some employers may have policies that allow employees to begin their maternity leave a fixed number of weeks before the expected DOB (e.g. in British Columbia, provincial employees can start maternity leave 6 weeks before their expected due date). In such situations, the officer does not advise the employee to apply for sickness benefits before maternity benefits, unless her particular circumstances require it. If the officer incorrectly advises the client, the following problems may occur:

- When a client receives sickness benefits before maternity benefits, the EI program may become the first payer. Employers registered with the Premium Reduction Program (PRP) must be the first payer to meet the program’s requirements. An employee claiming sickness benefits before maternity benefits can therefore jeopardize her employer’s entitlement to the PRP.

- There may be an impact on the payment of maternity or parental supplementary unemployment benefits (SUB):

- if a client receives sickness benefits before maternity benefits, she may lose her entitlement to SUB payments for the WP;

- the SUB may be payable for a definite period after ceasing work because that period is deemed the maternity or parental leave period. After the definite period has expired, the client may be able to obtain approval from her employer for an extended leave. However, an extended leave would fall outside the period for which the SUB is payable. Therefore, the client may be denied her full SUB entitlement, or the employer may be compelled to pay the SUB into the period of extended leave.

For these reasons, it is important that a client apply for the appropriate benefit type (BT) based on her circumstances. 

## Regional considerations

Source topic: `en_EN/activity/maternity_ben_entitlement/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/maternity_ben_entitlement/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/activity/maternity_ben_entitlement/in_nws.dita`

- Is there already an established maternity claim?

- Is there an Action Item (AI) WI or Claim Review (CR) WI with an actual DOB provided? 

## What do you want to do?

Source topic: `en_EN/activity/maternity_ben_entitlement/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/maternity_ben_entitlement/policy_reference.dita`

 
