# Leave of absence

Source map: `en_EN/activity/leave_absence/leave_absence.ditamap`

## Summary

Source topic: `en_EN/activity/leave_absence/summary.dita`

Summary: When a client takes a voluntary leave of absence, entitlement to regular benefits may be affected. Adjudication is required to determine if there is just cause for the leave of absence from employment. 

## What you need to know

Source topic: `en_EN/activity/leave_absence/what_you_need_to_know.dita`

### Leave of absence

Source topic: `en_EN/activity/leave_absence/leave_of_absence.dita`

A leave of absence is a prearranged unpaid period of absence from work, authorized by the employer, with an anticipated end or return to work (RTW) date. A leave of absence differs from normal periods away from the workplace (e.g. sick leave, vacation, parental leave, alternate work arrangements involving changes to the normal schedule) in that a leave of absence is considered an exceptional circumstance, rather than a benefit or normal working schedule.

Leave of absence can occur on initial, renewal and continuing claims.

The clients are responsible for reporting in a timely manner if they take a leave of absence from employment while on a claim.

The claim type (CT) determines the type of WI created for the leave of absence issue and the required actions to adjudicate the issue. On an initial or renewal claim, an Adjudication Issue (ADJ) WI is created for the leave of absence issue. On a continuing claim, the leave of absence issue is indicated in a Claim Review (CR) Revised WI or an Action Item (AI) WI. 

### Adjudicating a leave of absence

Source topic: `en_EN/activity/leave_absence/adjudicating_a_leave_of_absence.dita`

Clients who are not working because they requested and were granted a leave of absence are considered to be temporarily unemployed. The reasons for requesting the leave of absence are subject to the same considerations as voluntarily leaving the employment because it is the client’s actions which trigger this period of unemployment.

The officer must determine if the client had just cause for the voluntary leave of absence.

There is no automated adjudication of the leave of absence issue.

**Just cause**

Just cause means that when all factors are considered, the client had no reasonable alternative but to take a leave of absence from the employment.

When just cause is shown for the leave of absence, the officer reviews the client’s availability.

**No just cause**

Since the leave of absence is a temporary situation, if the officer determines that the client had no just cause for the leave of absence, a disentitlement is imposed rather than a disqualification. The 43 - Leave from employment without just cause disentitlement (D43) is imposed to indicate an authorized period of leave without just cause. If the conditions for terminating the disentitlement have not been met when the claim ends, the disentitlement is carried over to the next benefit period (BP).

When just cause is not shown for the leave of absence, special benefits are payable even during an unpaid leave. 

### Availability during a leave of absence

Source topic: `en_EN/activity/leave_absence/availability_during_a_leave_of_absence.dita`

If requesting regular benefits, the client must be capable of and available for work to be considered entitled. However, if requesting sickness benefits, the client must be otherwise available to be considered entitled. If the client is not otherwise available, the officer reviews the client’s availability. 

### Levels of decision

Source topic: `en_EN/activity/leave_absence/levels_of_decision.dita`

When specific conditions are met, the Level 1 officer may adjudicate and allow a leave of absence on an initial claim. When the Level 1 officer cannot adjudicate the issue, the facts are documented and the reason for separation (RFS) is referred to Level 2 for adjudication.

An ROE is not required to adjudicate a leave of absence. 

### Terminating a Leave from employment without just cause disentitlement (D43)

Source topic: `en_EN/activity/leave_absence/terminating_a_leave_from_employment_wit_a8e2f11e.dita`

When specific conditions are met, the Level 1 officer can terminate a D43 disentitlement on a renewal claim.

When clients on a leave of absence decide to voluntarily leave their employment, are dismissed or laid off due to a shortage of work, the D43 is terminated on the date before the date the relationship between employer and employee ceased to exist. 

### Adjudicating a reason for separation (RFS) after the leave of absence

Source topic: `en_EN/activity/leave_absence/adjudicating_a_reason_for_separation_rf_c0d9687d.dita`

When clients at the end of a leave of absence voluntarily leave employment or are dismissed, their entitlement to regular benefits may be affected. Adjudication is required to determine entitlement to benefits. 

### Processing the Adjudication Issue (ADJ) WI when the employment is not insurable

Source topic: `en_EN/activity/leave_absence/processing_the_adjudication_issue_adj_w_43ed2c2a.dita`

Adjudication of the leave of absence is not required if the employment is not insurable, either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, the ADJ WI must not be completed. The officer follows the p rocedures and conditions for removal of claims from ACP process . The officer moves the ADJ WI to Pending until the Claim Assessment (CA) or Specialized Application (SA) WI is created. An authorized user must then delete the ADJ WI.
       [rocedures and conditions for removal of claims from ACP process](https://esdc.prv/en/service-canada/ei/technologies/acp/index.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0125.dita) 

Even if the leave is not adjudicated, the officer must pay attention to potential availability issues. 

### Reason for separation (RFS) — Temporary Budget measures

Source topic: `en_EN/activity/leave_absence/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**Adjudicating the last employment in the qualifying period (QP) — BPCs between w/c 2310 and w/c 2361**

Budget 2021 has introduced a temporary simplification measure starting September 26, 2021. For claims with a BPC between w/c 2310 and w/c 2361, the officer will only adjudicate the last period of employment in the QP if it is contentious. If the officer allows the last RFS, all other ROEs in the QP, even if they are contentious, are used to calculate the claim. If, however, the officer does not allow the RFS on the last ROE in the QP, the claim is calculated with a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 

This new measure does not apply to self-employment (SE) and fishing claims. If clients applying for SE or fishing benefits have a BPC w/c 2310 and later, insurable employment in the QP and any contentious RFSs, these RFSs must be adjudicated following normal adjudication procedures.

When the client declares other employers with a contentious RFS on the same application, if ACP does not allow the issue under auto-adjudication rules, the issue is automatically resolved and ACP creates a record of decision (ROD) that shows Adjudication not Required . Block Special condition on the ROE is not updated, and the ROE is included in the calculation. An ADJ WI is not created for the RFS.

When there is more than one ROE with the same last day paid (LDP), and one of the ROEs is contentious while the other ROE is not, adjudication is not required and both ROEs will be included in the calculation.

**Adjudication not required — Reason for separation (RFS) beyond 12 weeks — BPCs between w/c 2258 and w/c 2309**

Adjudication principles on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309 only apply to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the interruption of earnings (I of E) used to establish the claim

**Adjudication not previously required — Specialized ACP process**

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the qualifying period (QP). The RFS issues that were not previously adjudicated can be identified because block Special condition was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0126.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0125.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. In these situations, adjudication of the leave is required. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0126.dita`

Note:

Any contentious RFS issues in the BP must be adjudicated. 

## Regional considerations

Source topic: `en_EN/activity/leave_absence/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/activity/leave_absence/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/activity/leave_absence/in_nws.dita`

- Are there are any SROCs, AI WIs, other WIs or documentation containing checklists or other details relating to the leave of absence? 

### In Imaging:

Source topic: `en_EN/activity/leave_absence/in_imaging.dita`

- Are there any imaged documents relating to the leave of absence? (Documents may have been received before the most recent application.) 

## What do you want to do?

Source topic: `en_EN/activity/leave_absence/what_do_you_want_to_do.dita`

## Policy reference

Source topic: `en_EN/activity/leave_absence/policy_reference.dita`

 
