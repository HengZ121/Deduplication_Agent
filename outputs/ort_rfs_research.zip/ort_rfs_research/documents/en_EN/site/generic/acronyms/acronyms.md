# Acronyms

Source map: `en_EN/site/generic/acronyms/acronyms.ditamap`

## Generic

Source topic: `en_EN/site/generic/acronyms/generic.dita`

- A - Acronym with names starting with the letter A
         [A- Acronym with names starting with the letter A](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#A)

- B - Acronym with names starting with the letter B
         [B- Acronym with names starting with the letter B](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#B)

- C - Acronym with names starting with the letter C
         [C- Acronym with names starting with the letter C](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#C)

- D - Acronym with names starting with the letter D
         [D- Acronym with names starting with the letter D](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#D)

- E - Acronym with names starting with the letter E
         [E- Acronym with names starting with the letter E](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#E)

- F - Acronym with names starting with the letter F
         [F- Acronym with names starting with the letter F](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#F)

- G - Acronym with names starting with the letter G
         [G- Acronym with names starting with the letter G](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#G)

- I - Acronym with names starting with the letter I
         [I- Acronym with names starting with the letter I](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#I)

- L - Acronym with names starting with the letter L
         [L- Acronym with names starting with the letter L](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#L)

- M - Acronym with names starting with the letter M
         [M- Acronym with names starting with the letter M](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#M)

- N - Acronym with names starting with the letter N
         [N- Acronym with names starting with the letter N](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#N)

- O - Acronym with names starting with the letter O
         [O- Acronym with names starting with the letter O](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#O)

- P - Acronym with names starting with the letter P
         [P- Acronym with names starting with the letter P](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#P)

- Q - Acronym with names starting with the letter Q
         [Q- Acronym with names starting with the letter Q](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#Q)

- R - Acronym with names starting with the letter R
         [R- Acronym with names starting with the letter R](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#R)

- S - Acronym with names starting with the letter S
         [S- Acronym with names starting with the letter S](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#S)

- T - Acronym with names starting with the letter T
         [T- Acronym with names starting with the letter T](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#T)

- U - Acronym with names starting with the letter U
         [U- Acronym with names starting with the letter U](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#U)

- V - Acronym with names starting with the letter V
         [V- Acronym with names starting with the letter V](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#V)

- W - Acronym with names starting with the letter W
         [W- Acronym with names starting with the letter W](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/generic/acronyms#W)

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1274.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1275.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1276.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1277.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1278.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1279.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1280.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1281.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1282.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1283.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1284.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1285.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1286.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1287.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1288.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1289.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1290.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1291.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1292.dita) 
     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1293.dita) 
    Footnote * 
      indicates a work item

Footnote * 
      Footnote ** 
      The Web version of SSA / La version Web de SSA

Footnote ** 

### Callout

Source topic: `en_EN/common_notes/note_c_1274.dita`

**A**

    ACP: 
      Automated Claims Processing / Traitement automatisé des demandes (TAD) 
      ACS: 
      Automated Correspondence Solution / Solution de correspondance automatisée (SCA) 
      ADJ Footnote * : 
      Adjudication Issue / Litige - Décision (DEC

Footnote *

) 
      ADMS: 
      Appeals Delivery and Management System / Système de gestion et de prestation des appels (SGPA) 
      AI Footnote * : 
      Action Item / Action à prendre (AP

Footnote *

) 
      AOB: 
      assignment of benefits / cession de prestations (CDP) 
      APC: 
      Appeal Processing Centre / Centre de traitement des appels (CTA) 
      APRS: 
      Automated Purge/Recreate System / Système automatisé de suppression/recréation (SASR) 
      APW: 
      arrival or placement week / semaine d’arrivée ou de placement (SAP) 
      ASMT Footnote * : 
      Assessment Issue / Évaluation pour le calcul (ECAL

Footnote *

) 
      AVRES: 
      Automated Voice Response Enquiry System / Système de réponse vocale automatisée (SRVA) 
      AW: 
      AppliWeb / AppliWeb (AW) 
      AWSS: 
      Automated Work-Sharing System / Système de travail partagé automatisé (STPA) 

### Callout

Source topic: `en_EN/common_notes/note_c_1275.dita`

**B**

    BCS: 
      Blocked Claims System / Système des demandes bloquées (SDB) 
      BN: 
      business number / numéro d’entreprise (NE) 
      BNOP: 
      Benefit and Overpayment System / Fichier de l’état de prestations et des trop-payés (FPTP) 
      BP: 
      benefit period / période de prestations (PP) 
      BPC: 
      benefit period commencement / début de la période de prestations (DPP) 
      BPNE: 
      benefit period not established / période de prestations non établie (PPNE) 
      BPS: 
      Benefit Pay System / Système de paiement des prestations (SPP) 
      BRAC: 
      benefit repayment adjustment calculation / calcul de l’ajustement du remboursement des prestations (CARP) 
      BT: 
      benefit type / genre de prestations (GP) 

### Callout

Source topic: `en_EN/common_notes/note_c_1276.dita`

**C**

    CA Footnote * : 
      Claim Assessment / Évaluation de la demande (EVD

Footnote *

) 
      CAAPS: 
      Computer Assisted Appeals Preparation System / Système de rédaction des appels par ordinateur (SRAO) 
      CB Footnote * : 
      Call Back / Rappel (RA

Footnote *

) 
      CCAJ: 
      Connecting Canadians with available jobs / Jumeler les Canadiens et Canadiennes aux emplois disponibles (JCCED) 
      CCB: 
      compassionate care benefits / prestations de compassion (PDC) 
      CCW: 
      compassionate care window / fenêtre de compassion  (FC) 
      CER: 
      common entrance requirement / norme d’admissibilité commune (NAC) 
      CFOB: 
      Chief Financial Officer Branch / Direction générale du dirigeant principal des finances (DGDPF) 
      CIC: 
      Citizenship and Immigration Canada / Citoyenneté et Immigration Canada (CIC) 
      COD: 
      cut-off date / date limite (DL) 
      COR Footnote * : 
      Correspondence / Correspondance (COR

Footnote *

) 
      CPP: 
      Canada Pension Plan / Régime de pensions du Canada (RPC) 
      CPS: 
      Computer Pay System / Système informatisé de paiement (SIP) 
      CPSR: 
      claims pay status report / relevé de prestations payées (RPP) 
      CR Footnote * : 
      Claim Review / Révision de la demande (RVD

Footnote *

) 
      CRA: 
      Canada Revenue Agency / Agence du revenu du Canada (ARC) 
      CS (1): 
      claim status / état de la demande (ED) 
      CS Footnote * (2): 
      Claim Set-Up / Établissement de la demande (ETD

Footnote *

) 
      CT: 
      claim type / genre de la demande (GD) 
      CUB: 
      Canadian Umpire Benefits / Décision du juge-arbitre (CUB) 

### Callout

Source topic: `en_EN/common_notes/note_c_1277.dita`

**D**

    DARS: 
      Departmental Accounts Receivable System / Système ministériel des comptes débiteurs (SMCD) 
      Digest: 
      Digest of Benefit Entitlement Principles / Guide de la détermination de l’admissibilité (GDA) 
      DOB: 
      date of birth / date de naissance (DDN) 

### Callout

Source topic: `en_EN/common_notes/note_c_1278.dita`

**E**

    EDS: 
      Electronic Documents System / Système de documents électroniques (SDE) 
      EI: 
      Employment Insurance / assurance-emploi (AE) 
      EI BOA: 
      Employment Insurance Board of Appeal / Conseil d’appel en assurance-emploi (CAAE) 
      ET ORT: 
      EI Online Reference Tool / Outil de référence en ligne de l’AE (ORL AE) 
      EIA: 
      Employment Insurance Act / Loi sur l’assurance-emploi (LAE) 
      EIBIS: 
      EI Benefits Information System / Système d’information sur les prestations d’AE (SIPAE) 
      EIBS: 
      EI Business Solutions / Solutions d’affaires de l’AE (SAAE) 
      EIFACS 
      EI Financial Accounting and Control System / Système comptable financier et de contrôle de l’AE (SCFCAE) 
      EI(F)R: 
      Employment insurance (Fishing) Regulations / Règlement sur l’assurance-emploi (pêche) (RAE-P) 
      EIR: 
      Employment Insurance Regulations / Règlement sur l’assurance-emploi (RAE) 
      ELWW: 
      earnings last week worked / rémunération dernière semaine de travail (RDST) 
      ESDC: 
      Employment and Social Development Canada / Emploi et Développement social Canada (EDSC) 

### Callout

Source topic: `en_EN/common_notes/note_c_1279.dita`

**F**

    FCA: 
      Federal Court of Appeal / Cour d’appel fédérale (CAF) 
      FCB: 
      Family caregiver benefits / prestations pour proches aidants (PPA) 
      FCW: 
      family caregiver window / fenêtre pour proches aidants (FPA) 
      FOA: 
      family order agreement / accord d’ordonnance familiale (AOF) 
      FS: 
      family supplement / supplément familial (SF) 
      FTS: 
      Full Text Screens / Écrans en texte intégral (ETI) 
      FWW: 
      full work week / semaine entière de travail (SET) 

### Callout

Source topic: `en_EN/common_notes/note_c_1280.dita`

**G**

    GEN Footnote * : 
      General Inquiry / Demande de renseignements (DR

Footnote *

) 

### Callout

Source topic: `en_EN/common_notes/note_c_1281.dita`

**I**

    I of E: 
      interruption of earnings / arrêt de rémunération (A de R) 
      IPOC: 
      Insurance Payment Operational Centre / Centre opérationnel de paiement de l’assurance (COPA) 
      IPOC MA Footnote * : 
      IPOC Manual Action / COPA Traitement manuel (COPA TM

Footnote *

) 
      IPOC MPS Footnote * : 
      IPOC Manual Pay / COPA Paiement manuel (COPA SMP

Footnote *

) 
      IPOC O/P Footnote * : 
      IPOC Overpayment / COPA Trop-payé (COPA T-P

Footnote *

) 
      IPOC P/R Footnote * : 
      IPOC Purge & Recreate / COPA Suppression et recréation (COPA SR

Footnote *

) 
      IPOC REV Footnote * : 
      IPOC Review / COPA Révision (COPA REV) 
      IPOC SN Footnote * : 
      IPOC System Notification / COPA Notification du système (COPA NS 
      IPOS: 
      Insurance Payment Operational Services / Services opérationnels de paiement de l’assurance (

SOPA

) 
      IRCC: 
      Immigration, Refugees and Citizenship Canada / Immigration, Réfugiés et Citoyenneté Canada (IRCC) 
      IRS: 
      Internet Reporting Service / Service de déclaration par Internet (SDI) 
      ITC: 
      information technology centre / centre de technologie de l’information (CTI) 

### Callout

Source topic: `en_EN/common_notes/note_c_1282.dita`

**L**

    LDP: 
      last day paid / dernier jour payé (DJP) 
      LDW: 
      last day worked / dernier jour de travail (DJT) 
      LMDA: 
      labour market development agreement / entente sur le développement du marché du travail (EDMT) 
      LREM: 
      last record of employment missing / dernier relevé d’emploi manquant (DREM) 
      LRW: 
      last renewable week / dernière semaine renouvelable (DSR) 

### Callout

Source topic: `en_EN/common_notes/note_c_1283.dita`

**M**

    MA: 
      manual action / traitement manuel  (TM) 
      MEE 
      Major Employer Events / Évènements majeurs en entreprise (EME) 
      MPS: 
      Manual Pay System / Système manuel de paiement (SMP) 
      MSCA: 
      My Service Canada Account / Mon dossier Service Canada (MDSC) 
      MSCA-EI: 
      My Service Canada Account - Employment Insurance / Mon dossier Service Canada - Assurance-emploi (MDSC-AE) 

### Callout

Source topic: `en_EN/common_notes/note_c_1284.dita`

**N**

    NAR: 
      National Accounts Receivable / Comptes débiteurs nationaux (CDN) 
      NIIS: 
      National Integrity Investigation System / Système national d’enquêtes d’Intégrité (SNEI) 
      NOC: 
      National Occupational Classification / Classification nationale des professions (CNP) 
      NOD: 
      Notice of Debt / Avis de dette (ADD) 
      NWE: 
      normal weekly earnings / rémunération hebdomadaire normale (RHN) 
      NWH: 
      normal weekly hours / heures hebdomadaires normales (HHN) 
      NWS: 
      National Workload System / Système national de la charge de travail (SNCT) 

### Callout

Source topic: `en_EN/common_notes/note_c_1285.dita`

**O**

    OLIS: 
      Online Insurance System / Système d’accès direct de l’assurance (SADA) 
      OP: 
      overpayment / trop-payé (T-P) 

### Callout

Source topic: `en_EN/common_notes/note_c_1286.dita`

**P**

    P/R: 
      purge and recreate / suppression et recréation (S/R) 
      PA 
      put away / à classer (AC) 
      PCA: 
      possible Commission appeal / appel possible de la Commission (APC) 
      PCIC: 
      parents of critically ill children / parents d’enfants gravement malades (PEGM) 
      PHS: 
      pay history summary / état récapitulatif des paiements (ERP) 
      PRP 
      Premium Reduction Program / Programme de réduction du taux de cotisation (PRTC) 
      PSL: 
      paid sick leave / congé de maladie payé (CMP) 
      PSCD: 
      Public Sector Collection and Disbursement / Recouvrements et décaissements du secteur public (PSCD) 
      PSPC 
      Public Services and Procurement Canada / Services publics et Approvisionnement Canada (SPAC) 
      PW: 
      parental window / fenêtre parentale (FP) 
      PWGSC: 
      Public Works and Government Services Canada / Travaux publics et Services gouvernementaux Canada (TPSGC) 

### Callout

Source topic: `en_EN/common_notes/note_c_1287.dita`

**Q**

    QP: 
      qualifying period / période de référence (PR) 
      QPIP: 
      Quebec Parental Insurance Plan / Régime québécois d’assurance parentale (RQAP) 

### Callout

Source topic: `en_EN/common_notes/note_c_1288.dita`

**R**

    RCM: 
      ROE Capture Module / Module de saisie du RE (MSRE) 
      RCP: 
      rate calculation period / période de base (PB) 
      REM Footnote * : 
      Reminder / À revoir (AR

Footnote *

) 
      RFR Footnote * : 
      Request for reconsideration / Demande de révision (DDR

Footnote *

) 
      RFS: 
      reason for separation / motif de cessation d’emploi (MCE) 
      RMDS: 
      ROE Management and Distribution System / Système de gestion et de distribution des RE (SGDRE) 
      RNS (1): 
      ROE Notification System / Système d’avis de RE (ARE) 
      RNS Footnote * (2): 
      ROE Notification / Avis de relevé d’emploi (ARE

Footnote *

) 
      ROD: 
      record of decision / rapport de décision  (RD) 
      ROE (1): 
      record of employment / relevé d’emploi (RE) 
      ROE Footnote * (2): 
      ROE Issue / Évaluation du relevé d’emploi (RE

Footnote *

) 
      ROE SAT: 
      ROE secure automated transfer / transfert automatisé protégé des RE (RE TAP) 
      RPAN: 
      Returned payment advice notice / Avis de paiement retourné (APR) 
      RRSP: 
      Registered Retirement Savings Plan / Régime enregistré d’épargne-retraite (REER) 
      RRU: 
      regional rate of unemployment / taux régional de chômage (TRC) 
      RTC: 
      Regional Tax Coordinator / coordonnateur fiscal régional (CFR) 
      RTW: 
      return to work / retour au travail (RAT) 

### Callout

Source topic: `en_EN/common_notes/note_c_1289.dita`

**S**

    SA Footnote * : 
      Specialized Application / Demande spécialisée (DS

Footnote *

) 
      SCC: 
      Service Canada centre / Centre Service Canada  (CSC) 
      SE: 
      self-employment / travail indépendant (TI) 
      SIN: 
      social insurance number / numéro d’assurance sociale (NAS) 
      SIR (1) 
      Social Insurance Registry / Registre d’assurance sociale (RAS) 
      SIR Footnote * (2) 
      SIR Validation / Validation du RAS (RAS

Footnote *

) 
      SOBR: 
      statement of benefits repaid / état des prestations remboursées (EDPR) 
      SPS: 
      Standard Payment System / Système normalisé des paiements (SNP) 
      SROC: 
      supplementary record of claim / renseignements supplémentaires concernant la demande de prestations (RSDP) 
      SSA: 
      Support System for Agents / Système de soutien pour agents (SSA) 
      SSO: 
      Support System for Officers / Système de soutien pour agents (SSA)

Footnote ** 
      SST: 
      Social Security Tribunal / Tribunal de la sécurité sociale (TSS) 
      SUB: 
      supplemental unemployment benefits / prestations supplémentaires de chômage (PSC) 

### Callout

Source topic: `en_EN/common_notes/note_c_1290.dita`

**T**

    TIS: 
      Telephone Information Service / Service d’information par téléphone (SIT) 
      TLRW: 
      true last renewable week / véritable dernière semaine renouvelable (VDSR) 
      TRS: 
      Telephone Reporting Service / Service de déclaration par téléphone (SDT) 

### Callout

Source topic: `en_EN/common_notes/note_c_1291.dita`

**U**

    UIC: 
      unemployment insurance calculation / calcul d’assurance-chômage (CAC) 
      UNA: 
      unassigned / non assigné (NA) 
      UP: 
      underpayment / moins-payé (M-P) 
      UR: 
      utilization report / rapport d’utilisation (RU) 

### Callout

Source topic: `en_EN/common_notes/note_c_1292.dita`

**V**

    VBW: 
      variable best weeks / meilleures semaines variables (MSV) 
      VER: 
      variable entrance requirement / norme variable d’admissibilité (NVA) 

### Callout

Source topic: `en_EN/common_notes/note_c_1293.dita`

**W**

    w/c: 
      week code / semaine codée (s/c) 
      WCB: 
      workers’ compensation benefits / indemnités pour accidents du travail (IAT) 
      WECS: 
      Web Error Code System / Système d’indicatifs d’erreur sur le Web (SIEW) 
      WEPP: 
      Wage Earner Protection Program / Programme de protection des salariés (PPS) 
      WI: 
      work item / article de travail  (AT) 
      WIID: 
      Work Item Inventory Distribution System / Système de distribution de l’inventaire des activités (SDIA) 
      WLI: 
      wage loss insurance / indemnités d’assurance-salaire (IAS) 
      WP: 
      waiting period / délai de carence (DC) 
      WS: 
      Work-Sharing / Travail partagé (TP) 
      WWC: 
      Working While on Claim / Travail pendant une période de prestations (TPP) 
