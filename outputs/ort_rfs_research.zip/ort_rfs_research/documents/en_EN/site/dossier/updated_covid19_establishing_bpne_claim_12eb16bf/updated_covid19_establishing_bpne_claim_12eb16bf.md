# Archived: COVID-19 and establishing BPNE claims as EI Emergency Response Benefit claims — Procedures (Level 1)

Source map: `en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf/updated_covid19_establishing_bpne_claim_12eb16bf.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf/summary.dita`

Due to the COVID-19 situation, temporary measures have been implemented that allow agents to establish BPNE claims as EI Emergency Response Benefit claims. Agents can now also recalculate claims that were previously finalized BPNE 1 or BPNE 5 to EI Emergency Response Benefit claims. 

## Generic

Source topic: `en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf/generic.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1052.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf#archived)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1211.dita) 

**Table of Contents**

- What You Need To Know
         [What You Need To Know](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf#What_you_need)

- Regional Considerations

- Quebec Region
             [Quebec Region](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf#rc_que)

         [Regional Considerations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf#rc)

- Temporary process
         [Temporary process](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf#Temporary_process)

**What you need to know**

Due to the COVID-19 situation, a utility was created and run to convert finalized BPNE claims to EI Emergency Response Benefit claims. Because this utility is not permanent, and to ensure consistent service, temporary procedures have been created to allow agents to establish these claims manually.

Effective immediately, agents apply the new temporary measures below to do one of the following:

- Calculate and establish an initial claim that would have been finalized BPNE as an EI Emergency Response Benefit claim;

- Recalculate a BPNE claim to establish an EI Emergency Response Benefit claim based on a client request.

Before recalculating a BPNE claim as a claim for the EI Emergency Response Benefit, the agent ensures the client has not applied for the Canada Emergency Response Benefit (CERB) through the Canada Revenue Agency (CRA). A client who is receiving CERB cannot receive the EI Emergency Response Benefit, and the agent does not establish the claim.

Clients who report an expected date of birth (DOB) on their applications are now entitled to EI Emergency Response Benefit regardless of the number of hours worked. Initial claims containing an expected DOB with a BPNE-N5 calculation result, and recalculations of BPNE-N5 claims with an expected DOB are not included in the following temporary measures. Instead, these claims will be identified via a data extract and processed manually to ensure correct payment of EI Emergency Response Benefit, maternity and/or parental benefits.

**Regional Considerations**

**Quebec region**

When the client could be entitled to QPIP, agents are asked to ensure the client’s EDC is not removed from the M103 transaction. To ensure the data extract is accurate, the EDC must be on the M103 transaction.

**Temporary process**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0988.dita) 

- Determine if the client meet any of the following criteria:

- the tentative BPC on the 149-Initial Intake Data transaction is on or before March 1, 2020

- the client provided a reference code including Work-Sharing

- the client is a commuter, interstate or international

- the client is applying for special benefits other than sickness (maternity, parental, CCB and family caregiver benefits)

- If yes, process the claim as per normal procedures.

- If no, go to step 2.

- Determine if the client is applying for fishing benefits:

- If yes, go to step 3.

- If no, go to step 4.

- Determine if the client is applying for fishing benefits and meets one of the following criteria:

- the client was not paid at least one week of fishing benefits between December 29, 2019 and October 3, 2020

- the client was paid at least one week of fishing benefits between December 29, 2019 and October 3, 2020 but the client has not exhausted their claim for benefits

- If yes, process the claim as per normal procedures.

- If no, the client is entitled to EI Emergency Response Benefit. Go to step 4.

- In FTS, determine if the client is receiving CERB through the CRA:

- If the client is not receiving CERB, go to step 5.

- If the client is receiving CERB and the claim is an initial calculation, the client is not entitled to EI ERB. Withdraw the claim .
             [Withdraw the claim](/en/procedure/task/withdraw_an_app.shtml)

- If the client is receiving CERB and the claim is a recalculation, the client is not entitled to the EI Emergency Response Benefit. Advise the client, NCA the registration, and complete any outstanding WIs. No further action is required.

- Determine if the claim is an initial calculation or a recalculation of a BPNE claim.

- If the claim is a recalculation of a BPNE claim, go to step 6.

- If the claim is an initial calculation, go to Establishing an EI Emergency Response Benefit claim — Initial calculation .
             [Establishing an EI Emergency Response Benefit claim — Initial calculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf#initial)

- In FTS, determine if there is a revised registration number on the client’s file.

- If yes, go to step 7.

- If no, assign a revised registration number and go to step 7.

- Determine the type of BPNE claim:

- If the claim is BPNE N1 or N7, go to Establishing an EI Emergency Response Benefit claim — BPNE N1 or N7 claim.
             [Establishing an EI Emergency Response Benefit claim — BPNE N1 or N7 claim.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf#n1)

- If the claim is BPNE N5 with no violation, go to Establishing an EI Emergency Response Benefit claim — BPNE N5 claim with no violation .
             [Establishing an EI Emergency Response Benefit claim — BPNE N5 claim with no violation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf#n5_without)

- If the claim is BPNE N5 with violation, go to Establishing an EI Emergency Response Benefit claim — BPNE N5 claim with a violation .
             [Establishing an EI Emergency Response Benefit claim — BPNE N5 claim with a violation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf#n5_with)

**Establishing an EI Emergency Response Benefit claim — Initial calculation**

- In NWS, determine if the client has indicated they are pregnant or have given birth:

- If no, go to step 2.

- If yes and the claim is BPNE N1 or N7, go to step 5.

- If yes and the claim is BPNE N5, temporary measures do not apply. Finalize the claim as BPNE N5 following normal procedures.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1212.dita)

- In SSA, calculate the claim as usual and store the transaction in SSA.

- In FTS, enter the client’s SIN and open the stored Initial decision (M103) transaction. Manually modify the necessary data to establish the claim as an EI Emergency Response Benefit as follows:

- Complete the WI.

- In SSA, calculate the claim as usual and store the transaction.

- In FTS, enter the client’s SIN and open the stored Initial decision (M103) transaction. Manually modify the necessary data to establish the claim as an EI Emergency Response Benefit claim as follows:

- BPC: Enter w/c 2230 or later.

- Claim type: Select 2 - Regular .

- Manual action: Leave this field blank.

- Insured — Hours: Type “1400.”

- Divisor: This field is prefilled if the claim was established BPNE N5. However, if the claim was established BPNE N1, determine and input the divisor using the Regional Rates screen, with the BPC and the client’s economic region.

- Insured — Earnings: Enter the sum of 909 × the divisor.

- Cut off date: This field is prefilled from the stored transaction.

- Economic Region: This field is prefilled from the stored transaction.

- Labour Force Attachment: Leave this field blank.

- Reason for separation: This field is prefilled from stored transaction.

- Employer: This field is prefilled from stored transaction.

- Last job: This field is prefilled from stored transaction.

- Gender: This field is prefilled from stored transaction.

- Confinement week: Enter the BPC + 16 weeks.

- Wage Loss insurance: Select 3 - Paid sick leave prior to benefit period commencement - WP must be waived .

- Waiting Period: Select 2 - Waived .

- Tax credit: This field is prefilled from the stored transaction.

- Supplement claim information : Leave the field blank to allow the utility to update the claim during the next overnight run.

- Pending review: Leave this field blank.

- Decision type: This field is prefilled from the stored transaction.

- BPNE: Leave this field blank.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Click Update .

- Input the following transactions the same day as the Initial decision (M103) transaction to ensure the claim processes as an EI Emergency Response Benefit claim:

- Open the Additional Data (M107) transaction and input an external maternity start week as follows:

- External Maternity — Start week: Enter the BPC + 16 weeks.

- Click Update .

- Open the Disqualification/Disentitlement (M161) transaction and input an indefinite 39 - Prevent payment of part II benefits and/or incorrect Part I benefits disentitlement (D39) as follows:

- Disentitlement — Start date: Enter the BPC + 16 weeks.

- Click Update .

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1213.dita)

- Send an email to the NC-INS-ASSUR_BPS-SPP_FTS-ETI_JP-PE_UIC-CAC_SSA-GD as follows:

- Subject: Type “BPNE N1 to EI Emergency Response Benefit with birth.”

- Body: Include the client’s SIN.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1214.dita) 

**Establishing an EI Emergency Response Benefit claim — BPNE N1 or N7 claim**

- In NWS, determine if the client has indicated they are pregnant or have given birth:

- If no, go to step 2.

- If yes, go to step 4.

- In FTS, complete the Renewal/Revised (M106) transaction as follows:

- Claim type : Select 2 - Regular .

- Manual Action : Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Insured — Hours: Type “1400.”

- Divisor: Determine and input the divisor using the Regional Rates screen, with the BPC and client’s economic region.

- Insured — Earnings: Enter the sum of 909 × the divisor.

- Cut off date: Enter the cut-off date (COD) as shown on the claim.

- Labour Force Attachment: Select X - Rescind the Labour Force Attachment .

- Wage loss insurance: Select 3 - Paid sick leave prior to benefit period commencement - WP must be waived .

- Waiting period: Select 2 - Waived .

- Supplementary claim information: Leave the field blank to allow the utility to updates the claim during the following overnight run.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Detection: Select 24 - Recalculation - Amended ROE .

- Infraction: Select C - Non-fraud - Insurability - new information .

- Message: Select 9 - An overpayment resulted due to a change in insurable employment .

- Click Update .

- Complete the WI.

- In FTS, complete the Renewal/Revised (M106) transaction as follows:

- Claim type: Select 2 - Regular .

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Insured — Hours: Type “1400.”

- Divisor: Determine and input the divisor using the Regional Rates screen, with the BPC and client’s economic region.

- Insured — Earnings: Enter the sum of 909 × the divisor.

- Cut off date: Enter the COD as shown on the claim.

- Action: Input a D39 from the BPC + 16 weeks.

- Labour Force Attachment: Select X - Rescind the Labour Force Attachment .

- Wage loss insurance: Select 3 - Paid sick leave prior to benefit period commencement - WP must be waived .

- Waiting period: Select 2 - Waived .

- Click the Special benefits (M106) link and input the following:

- Confinement week : Enter the w/c equal to BPC + 16.

- Click the Additional data (M107) link and input the following:

- External Maternity — Start week : Enter the w/c equal to BPC + 16.

- Supplementary claim information: Leave the field blank to allow the utility to updates the claim during the following overnight run.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Detection: Select 24 - Recalculation - Amended ROE .

- Infraction: Select C - Non-fraud - Insurability - new information .

- Message: Select 9 - An overpayment resulted due to a change in insurable employment .

- Click Update .

- Send an email to the NC-INS-ASSUR_BPS-SPP_FTS-ETI_JP-PE_UIC-CAC_SSA-GD as follows:

- Subject: Type “BPNE N1 to EI Emergency Response Benefit with birth.”

- Body: Include the client’s SIN.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1215.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1214.dita) 

**Establishing an EI Emergency Response Benefit claim — BPNE N5 claim with no violation**

- In NWS, determine if the client has indicated they are pregnant or have given birth:

- If no, go to step 2.

- If yes, temporary measures do not apply. Finalize the claim as BPNE N5 following normal procedures.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1216.dita)

- In FTS, complete the Renewal/Revised (M106) transaction as follows:

- BPC: Enter the BPC as shown on the claim (it cannot be earlier than w/c 2230).

- Claim type: Select 2 - Regular .

- Insured — Hours: Type “1400.”

- Divisor: Enter the divisor as shown on the claim.

- Insured — Earnings: Enter the sum of 909 × the divisor.

- Cut off date: Enter the COD as shown on the claim.

- Labour Force Attachment: Select X - Rescind the Labour Force Attachment .

- Wage loss insurance: Select 3 - Paid sick leave prior to benefit period commencement - WP must be waived .

- Waiting period: Select 2 - Waived .

- Supplementary claim information: Leave the field blank to allow the utility to updates the claim during the following overnight run.

- Detection: Select 24 - Recalculation - amended record of employment .

- Infraction: Select C - Non-fraud - Insurability - new information .

- Message: Select 9 - An overpayment resulted due to a change in insurable employment .

- Click Update .

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1215.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1214.dita) 

**Establishing an EI Emergency Response Benefit claim — BPNE N5 claim with a violation**

- In NWS, determine if the client has indicated they are pregnant or have given birth:

- If no, go to step 2.

- If yes, temporary measures do not apply. Finalize the claim as BPNE N5 following normal procedures.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1217.dita)

- In FTS, complete the Renewal/Revised (M106) transaction as follows:

- BPC: Enter the BPC as shown on the claim (it cannot be earlier than w/c 2230).

- Claim type: Select 2 - Regular .

- Insured — Hours: Type “1400.”

- Divisor: Enter the divisor as shown on the claim.

- Insured — Earnings: Enter the sum of 909 × the divisor.

- Cut off date: Enter the COD as shown on the claim.

- Violation: Leave this field blank.

- Labour Force Attachment: Select 1 - 420 to 909 insured hours or violation on the claim or Regular qualifier (labour force attachment requirements met) .

- Wage loss insurance: Select 3 - Paid sick leave prior to benefit period commencement - WP must be waived .

- Waiting period: Select 2 - Waived .

- Supplementary claim information: Leave the field blank to allow the utility to updates the claim during the following overnight run.

- Detection: Select 24 - Recalculation - amended record of employment .

- Infraction: Select C - Non-fraud - Insurability - new information .

- Message: Select 9 - An overpayment resulted due to a change in insurable employment .

- Click Update .

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1215.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1214.dita) 

### Warning

Source topic: `en_EN/common_notes/note_c_1052.dita`

**This page has been archived on the Web**

UPDATED: 2021-02-03 — The Headlines and Updates page has been archived because the information is outdated.

Agents should not be attempting to establish a new EI ERB claim without referring to their BEA.

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available. 

### Note

Source topic: `en_EN/common_notes/note_c_1211.dita`

Note:

This Headlines and Updates page was created on May 27, 2020 and has been updated as follows:

- June 1, 2020: Regional considerations were added for when a client could be entitled to QPIP.

- June 2, 2020: Updated to identify screening criteria for EI Emergency Response Benefit.

- June 11, 2020: Updated due to FTS update and to provide further clarity to agents processing BPNE to EI Emergency Response Benefit claims.

- August 3, 2020: Updated to modify the screening criteria to determine if the claim is an EI ERB claim.

- August 18, 2020: Updated to expand screening criteria for EI Emergency Response Benefit to include clients who have exhausted their existing claim for regular or fishing benefits

- September 01, 2020: Updated to adjust the steps for the screening of fishers who have exhausted their claim.

- September 23, 2020: Updated to adjust the steps to withdraw claims for clients who are receiving CERB and the claim is an initial calculation.

- February 3, 2021: This page has been archived. 

### Note

Source topic: `en_EN/common_notes/note_c_0988.dita`

Note:

Procedures have not been updated. Refer to COVID-19 — Procedural changes for a table of affected procedures.
       [COVID-19 — Procedural changes](/en/procedure/generic/covidhu.shtml)

     [COVID-19 — Procedural changes](/en/procedure/generic/covidhu.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1212.dita`

Note:

When the client could be entitled to QPIP, agents must not delete the expected DOB on the M103 in this temporary measure. 

### Note

Source topic: `en_EN/common_notes/note_c_1213.dita`

Note:

Complete the registration number with the last transaction. 

### Note

Source topic: `en_EN/common_notes/note_c_1214.dita`

Note:

Commuter clients are not entitled to the EI Emergency Response Benefit. Process these claims as usual. 

### Note

Source topic: `en_EN/common_notes/note_c_1215.dita`

Note:

Any outstanding claimant’s reports that require input must be done on day 2 after the claim has been established as EI Emergency Response Benefit. 

### Note

Source topic: `en_EN/common_notes/note_c_1216.dita`

Note:

When a client could be entitled to QPIP, agents in the Quebec region must not delete the expected DOB from the M103 transaction in this temporary measure. 

### Note

Source topic: `en_EN/common_notes/note_c_1217.dita`

Note:

When clients could be entitled to QPIP, agents in the Quebec region must not delete the expected DOB from the M103 transaction in this temporary measure. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_covid19_establishing_bpne_claim_12eb16bf/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
