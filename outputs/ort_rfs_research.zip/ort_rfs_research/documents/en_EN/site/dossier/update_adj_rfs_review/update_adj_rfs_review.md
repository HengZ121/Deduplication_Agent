# Update to Adjudication Issue RFS Review WI procedures

Source map: `en_EN/site/dossier/update_adj_rfs_review/update_adj_rfs_review.ditamap`

## Summary

Source topic: `en_EN/site/dossier/update_adj_rfs_review/summary.dita`

The ADJ RFS Review WI procedures have been updated in response to national and regional contributions. 

## Generic

Source topic: `en_EN/site/dossier/update_adj_rfs_review/generic.dita`

The updates clarify the following:

- To determine the reason for separation (RFS), agents may need to fact-find with both the employer and the client.

- When the RFS on the ROE is K - Other , agents must create a record of decision (ROD) if they determine there is no interruption of earnings. This documentation is required to support the deletion of the WI.

- When the RFS on the ROE is K – Other , agents must change the RFS in RCM to A – Shortage of work if they determine that the RFS is not contentious and no other RFS option is applicable. 

## Summary of changes

Source topic: `en_EN/site/dossier/update_adj_rfs_review/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
