# ROE Issue RFS Action WI — Modifying the reason for separation

Source map: `en_EN/site/dossier/roe_issue_rfs_action/roe_issue_rfs_action.ditamap`

## Summary

Source topic: `en_EN/site/dossier/roe_issue_rfs_action/summary.dita`

The procedures have been updated to ensure that the reason for separation (RFS) details are modified only if there is no conflicting record of decision (ROD) on file. Clarification was also added to ensure the agent selects the appropriate special condition option when the decision on file indicates Suspension from employment (D-42) . 

## Generic

Source topic: `en_EN/site/dossier/roe_issue_rfs_action/generic.dita`

Before changing the RFS to a non-contentious option ( A - Shortage of work , D - Illness or injury or J - Apprentice training ) based on comments on the ROE, the agent must first determine if there is a ROD on file. If there is no ROD on file for the period of employment, or if the ROD supports the non-contentious RFS, the agent modifies the RFS details. If there is a ROD on file indicating that the RFS is contentious (e.g. dismissal or suspension, leave of absence, voluntary leaving), the agent must not modify the RFS details. This update directs the agent to the correct next step and avoids creating unnecessary Level 1 WIs.

A ROD can indicate Misconduct Proven for both a dismissal and suspension. The agent selects Misconduct Proven as the special condition option only for a dismissal. When the ROD also indicates Suspension from employment (D-42) , the agent must select Suspension as the special condition option. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/roe_issue_rfs_action/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
