# Information: Post-EI ERB and automation of sickness benefits

Source map: `en_EN/site/dossier/information_post_eierb_automation_of_si_2ca0645f/information_post_eierb_automation_of_si_2ca0645f.ditamap`

## Summary

Source topic: `en_EN/site/dossier/information_post_eierb_automation_of_si_2ca0645f/summary.dita`

Effective October 16, 2020, the UIC has been programmed to input a recovery date on sickness claims regardless of the reason for separation (RFS). 

## Generic

Source topic: `en_EN/site/dossier/information_post_eierb_automation_of_si_2ca0645f/generic.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1115.dita) 

To facilitate automation, UIC will input recovery dates and no longer trip down on claims for sickness benefits, regardless of the RFS. This aligns with the fact that the requirement to submit the medical certificate has been suspended, as outlined in BE Memo 2020-5, as well as a client’s ability to declare 15 weeks of casual sickness.

The logic behind the UIC that currently applies to sickness claims with an RFS of D - Illness is extended to all sickness claims. The recovery date for initial sickness claims will be BPC + 15, or BPC + 8 if combined with maternity benefits. This logic applies to claims with a BPC between September 27, 2020 (w/c 2258) and June 6, 2021 (w/c 2294). 

### Note

Source topic: `en_EN/common_notes/note_c_1115.dita`

Note:

This Headlines and Updates page was created on October 16, 2020. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/information_post_eierb_automation_of_si_2ca0645f/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
