# Updated: Deferral of adjudication on renewal and conversion claims, and continuing claims for special benefits — Procedures and additional resource (Level 1 and Level 2)

Source map: `en_EN/site/dossier/upd_def_adj_claims/upd_def_adj_claims.ditamap`

## Summary

Source topic: `en_EN/site/dossier/upd_def_adj_claims/summary.dita`

Effective immediately, officers can defer all adjudications on contentious reasons for separation (RFS) on renewal and conversion claims, and on continuing claims for special benefits when the client:

- meets the qualifying conditions for the benefit type requested;

- is not requesting regular benefits for any period after the contentious RFS. 

## Generic

Source topic: `en_EN/site/dossier/upd_def_adj_claims/generic.dita`

Officers can now defer the adjudication of a contentious RFS on renewal and conversion claims, and on continuing claims for special benefits when all of the following conditions are met:

- The contentious RFS does not impact the qualifying period (QP).

- The client is not requesting regular benefits for any period after the contentious RFS.

- The client is only requesting special benefits after the contentious RFS.

- The client is otherwise available for work (sickness benefits only).

The titles of the deferral procedures for renewals now include all claim types (CTs) other than initial, and the Overarching Principles for Content in EI ORT  includes information regarding deferrals.
       [Overarching Principles for Content](/en/site/generic/guide_content_principles.shtml)

Deferrals for special benefits no longer require a previously imposed disqualification on the claim. Officers must now:

- document the deferral decision;

- update the Special Conditions field in RCM, if necessary;

- impose an indefinite disqualification to prevent the payment of regular benefits.

If adjudication cannot be deferred, officers follow the existing procedures for adjudication. 

## Summary of changes

Source topic: `en_EN/site/dossier/upd_def_adj_claims/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
