# New: Integrity case: Review of EI ERB claims when a client had income during the EI ERB period — Task (Level 2)

Source map: `en_EN/site/dossier/new-ic-rev-eierb-c-i/new-ic-rev-eierb-c-i.ditamap`

## Summary

Source topic: `en_EN/site/dossier/new-ic-rev-eierb-c-i/summary.dita`

New procedures have been added to the Integrity case activity to support Integrity’s review of clients’ eligibility for the EI ERB that was received while clients earned income during the EI ERB period. These procedures apply Level 2 officers who are part of the team actioning EI ERB eligibility cases from Integrity. 

## Generic

Source topic: `en_EN/site/dossier/new-ic-rev-eierb-c-i/generic.dita`

The Level 2 officer receives a Claim Review (CR) Integrity - EI ERB Reason for separation WI to action these cases. The officer reviews each 2-week EI ERB period to determine if the client is eligible for the benefits paid. The officer first determines if the client had 7 consecutive days with no work and no income during the 2-week EI ERB period being reviewed. If yes, the client remains eligible for the benefits paid for those 2 weeks. If no, the officer determines if the client’s income exceeds $1 000 over a 4-week period.

If the client’s income exceeds $1 000 in the 4-week period, the officer imposes a 47 - EI ERB - Earnings limit exceeded for the four week period disentitlement (D47) only for the 2-week EI ERB period under review. To impose the disentitlement, the officer refers to the new task on implementing the decision. 

## Summary of changes

Source topic: `en_EN/site/dossier/new-ic-rev-eierb-c-i/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
