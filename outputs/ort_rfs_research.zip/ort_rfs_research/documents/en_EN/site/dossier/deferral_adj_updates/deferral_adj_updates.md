# Deferral of adjudication—Updates

Source map: `en_EN/site/dossier/deferral_adj_updates/deferral_adj_updates.ditamap`

## Summary

Source topic: `en_EN/site/dossier/deferral_adj_updates/summary.dita`

As part of our ongoing efforts to maintain the content of the EI ORT, all Deferral of adjudication tasks has been updated based on regional feedback. 

## Generic

Source topic: `en_EN/site/dossier/deferral_adj_updates/generic.dita`

Each task under the Deferral of adjudication activity have been updated. Here is a list of the main changes:

- Deferral is now possible for any adjudication issue when the client has less than 420 hours in the qualifying period (QP) and is requesting regular or sickness benefits.

- Deferral is now possible for a contentious RFS before a disqualifying event that results in an indefinite disqualification when the client qualifies for special benefits.

- Deferral is now possible for a contentious RFS if an indefinite disqualification was imposed as a result of adjudication or a deferral on the initial claim.

- The adjudication of an antedate request can never be deferred. Antedate requests must be adjudicated even if the claim results in a BPNE 1 or 5. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/deferral_adj_updates/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
