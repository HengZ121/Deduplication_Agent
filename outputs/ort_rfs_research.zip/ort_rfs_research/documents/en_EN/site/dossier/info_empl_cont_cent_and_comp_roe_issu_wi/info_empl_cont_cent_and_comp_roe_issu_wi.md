# Information: Employer Contact Centre and completion of ROE Issue WIs

Source map: `en_EN/site/dossier/info_empl_cont_cent_and_comp_roe_issu_wi/info_empl_cont_cent_and_comp_roe_issu_wi.ditamap`

## Summary

Source topic: `en_EN/site/dossier/info_empl_cont_cent_and_comp_roe_issu_wi/summary.dita`

Effective May 2, 2022, the Employer Contact Centre officers will be able to update and complete some ROE Issue (ROE) Correction, Comment and RFS Action WIs when helping employers who contact the call centre. 

## Generic

Source topic: `en_EN/site/dossier/info_empl_cont_cent_and_comp_roe_issu_wi/generic.dita`

Employer Contact Centre officers are responsible for answering employers’ questions about completing ROEs. As of May 2, 2022, they will also be authorized to correct some ROE errors preventing validation.

Employer Contact Centre officers will receive guidance, mirroring current EI ORT procedures, instructing them how to action ROE Correction, Comment and RFS Action WIs that would otherwise be in the NWS queue for the next available processing officer. This will reduce employer calls and improve automation.

Current EI ORT procedures will not be changed. If Employer Contact Centre officers receive a call from an employer and there are errors preventing the ROE validation, they will correct, validate and document the changes made to the ROE in RCM. If a WI is already assigned to a processing officer, Employer Contact Centre Team Leaders will be authorized to reassign that WI to an Employer Contact Centre officer for completion. Employer Contact Centre officers will email their Team Leaders (adding as CC the officer assigned to the WI) and request that the WI be reassigned to them.

While the system automatically validates ROEs, in some situations this validation can be performed only when a change (e.g. deleting a comment) is made in RCM. If an error is detected during validation, NWS does not automatically create an ROE Correction WI, but this error prevents ACP from calculating the claim. If possible, Employer Contact Centre officers will make all required corrections to validate the ROE. However, if they cannot correct the error, they will create an ROE Correction WI for processing officers following normal EI ORT procedures. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/info_empl_cont_cent_and_comp_roe_issu_wi/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
