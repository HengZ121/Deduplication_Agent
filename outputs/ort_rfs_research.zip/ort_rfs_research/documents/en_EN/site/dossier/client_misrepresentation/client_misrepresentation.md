# Misrepresentation — Update

Source map: `en_EN/site/dossier/client_misrepresentation/client_misrepresentation.ditamap`

## Summary

Source topic: `en_EN/site/dossier/client_misrepresentation/summary.dita`

As part of our ongoing efforts to maintain the content of the EI ORT, the Misrepresentation procedures have been updated based on regional feedback. 

## Generic

Source topic: `en_EN/site/dossier/client_misrepresentation/generic.dita`

The most significant changes include:

When a case involves multiple benefit periods (BPs), the agent completes the steps for each BP. When a total net overpayment (OP) is based on more than one BP, the agent calculates the penalty cap separately for each BP. The same applies to the legal validation calculation.

A recalculation is required when the misrepresentation involves an undisclosed contentious reason for separation (RFS) in the qualifying period (QP) and impacts the calculation of the claim. When a recalculation is required, the agent creates a Claim Review (CR) Recalculation WI and a client Note for Level 1 to recalculate the claim.

When a client declared earnings from more than one employer for a week that is being amended, the earnings must be combined for both employments for that week. The total is the amount to be allocated.

The agent determines if a stop payment has been imposed during the investigation and removes it, if applicable.

A separate letter is required for each calendar year when there are more than 52 weeks of unreported earnings.

The steps for the Operational Centre Memo (MM06) transaction have been updated. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/client_misrepresentation/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
