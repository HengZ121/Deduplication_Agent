# Updated: Extension of temporary simplification measures — Procedures (Level 1, Level 2 and IPOC)

Source map: `en_EN/site/dossier/updated_extension_temporary_simplificat_9c07626f/updated_extension_temporary_simplificat_9c07626f.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_extension_temporary_simplificat_9c07626f/summary.dita`

To continue supporting Canadians during the third wave of the COVID-19 pandemic, simplification measures are being extended until September 25, 2021. 

## Generic

Source topic: `en_EN/site/dossier/updated_extension_temporary_simplificat_9c07626f/generic.dita`

Temporary simplification measures were implemented at the start of the COVID-19 pandemic to help process applications for benefits. With the transition to EI in September 2020, the temporary measures were reviewed and the EI ORT was updated to indicate that the measures would be extended until March 31 st , 2021.

Since many regions are now experiencing a third wave of the COVID-19 pandemic, the following simplification measures are extended until September 25, 2021:

    900-series SINS: 
      Agents continue to accept verbal confirmation from clients that they are authorized to remain in Canada and that they have proof (e.g. work permit, study permit, proof of implied status). When the client verbally confirms having proof, the agent obtains the details (e.g. date the authorization was issued and expiry date), advises the client to submit the authorization and creates a Reminder (REM) WI to follow up on this issue. 
      Availability: 
      Agents continue to allow availability when clients state that they would have been available or otherwise available for work if not for COVID-19 and there are no other restrictions on their availability Therefore, clients who are ready, willing and capable of accepting suitable employment and demonstrate their desire to return to the labour market by not imposing restrictions on their availability are considered available. Agents adjudicate availability following normal procedures for clients who indicate that they are unable to return to work or seek employment or are not otherwise available for work due to a restriction on their availability and may be disentitled from receiving benefits. 
      Fact-finding: 
      When fact-finding about reason for separation (RFS) issues, agents make one attempt to contact an employer. When fact-finding with an employer about ROE issues or any other issues (earnings, insurability, etc.), agents follow the normal fact-finding procedures unless they confirm that the business is closed. If the business is closed, agents attempt to resolve the outstanding issues with the client or with the information on file. 
      SIR non-match and client’s identity validation: 
      When a client lives within 50 kilometres of a Service Canada Centre (SCC) that is closed due to COVID-19, agents can use flexibility and allow clients to submit proof of identity by mail. 

**Impact on procedures**

The What You Need To Know and Step by Step sections of the following procedures have been updated to indicate that the temporary simplification measures are in effect until September 25, 2021:

- Availability

- Actioning an Adjudication Issue Child care WI

- Adjudicating non-availability declared by the client

- Adjudicating availability — Gradual return to work

- Adjudicating availability — Preference or restriction and reasonable period

- Adjudicating availability — Volunteer or other personal activities

- Adjudicating availability — Client is working part-time

- Adjudicating otherwise available issues — Initial claim

- Adjudicating otherwise available issues — Continuing claim

- Adjudicating otherwise available issues — Renewal claim

- 900-series SIN

- Actioning an expired 900-series SIN — Regular or sickness benefits

- Actioning an expired 900-series SIN — Special benefits other than sickness

- Adjudicating availability: 900-series SIN

- Reviewing a Reminder WI to follow up on a 900-series SIN

- Determining entitlement for a client with a valid 900-series SIN

- Determining if an insurability ruling is required — 900-series SIN

- Fact-Finding

- Completing a SIR Validation WI when there are blank fields in SIR

- Completing a SIR Validation WI when the date of birth does not match the SIR

- Completing a SIR Validation WI when the first name does not match in the SIR

- Completing a SIR Validation WI when the last name does not match the SIR

- Completing a SIR Validation WI when multiple elements do not match the SIR 

## Summary of changes

Source topic: `en_EN/site/dossier/updated_extension_temporary_simplificat_9c07626f/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
