# New EI ORT procedure—Deferring adjudication: Current established claim

Source map: `en_EN/site/dossier/update_deferring_adj/update_deferring_adj.ditamap`

## Summary

Source topic: `en_EN/site/dossier/update_deferring_adj/summary.dita`

A new task called Deferring adjudication: Current established claim has been published in the EI ORT. 

## Generic

Source topic: `en_EN/site/dossier/update_deferring_adj/generic.dita`

As part of our efforts to develop the remaining processing procedures, the Deferring Adjudication: Current established claim task is now available in the EI ORT.

On an established claim for benefits, the agent can defer adjudication of a contentious reason for separation (RFS) if the client is not requesting benefits after the date of the contentious RFS. Adjudication is deferred until the client requests benefits.

The Deferral of adjudication activity has also been updated to provide details for the scenario in which a client has a contentious RFS before a disqualifying event in the qualifying period (QP) and is requesting regular benefits but did not work enough hours since the disqualifying event to gain relief from the indefinite disqualification.

The agent must impose a 10 - Dismissal - misconduct proven or 11 - Voluntary leaving - j ust cause not proven disqualification as a result of the adjudication of a contentious RFS before a disqualifying event in the QP. If calculation results in the ROE of the disqualifying event being excluded from calculation, the agent must adjudicate every remaining contentious RFS because this affects the rate and entitlement weeks.

Content related to these procedures in the Benefit Manual will soon be archived. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/update_deferring_adj/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
