# Fort McMurray Fires - Updated May 13, 2016

Source map: `en_EN/site/dossier/fort_mac_1/fort_mac_1.ditamap`

## Summary

Source topic: `en_EN/site/dossier/fort_mac_1/summary.dita`

Emergency measures have been adopted to assist clients affected by wildfires in Fort McMurray, Alberta. These changes only apply to clients who are affected by the fires in Fort McMurray. 

## Generic

Source topic: `en_EN/site/dossier/fort_mac_1/generic.dita`

[Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1026.dita) 

The Fort McMurray Service Canada centre is currently closed and mail delivery to Fort McMurray has been suspended. Service Canada has set up a dedicated line providing information on EI. Affected clients can call 1-800-206-7218 and choose option “6” to get information.

**Reference Code**

A reference code, 4812012016030516, has been issued for clients that are affected by the fires. Claims filed with the reference code will be processed by a dedicated unit in the Western Canada and Territories region. The reference code can only be used by clients requesting regular benefits. Clients requesting special benefits should not use the reference code.

**Social Insurance Registry (SIR) non-match**

If clients cannot be contacted to validate their identification, their claim will not be delayed. The SIR Validation (SIR) WI will be moved to Pending and, once conditions in Fort McMurray return to normal, the client will be contacted to follow up on their SIR validation.

**Client’s address**

Clients are being told to enter their permanent address in the residential address field of their application, whether their permanent address is in Fort McMurray or elsewhere. If clients have been temporarily displaced because of the fires, they can enter their temporary address in the mailing address field. This temporary mailing address could be a hotel, a shelter, etc.

**Interim ROEs**

Since employers may not be able to issue ROEs, an interim ROE will be created as soon as possible for affected clients.

**Direct deposit**

Clients who provided direct deposit information on a previous claim in a region other than Western Canada and Territories may need to have their direct deposit information updated. The direct deposit information from the other region may not be carried forward to their new claim. If agents are in contact with an affected client, they must always make sure the direct deposit information on file is correct.

**Reason for separation**

If the client is involuntarily no longer working because of the mandatory evacuation, or because the business closed due to the fires in Fort McMurray, the reason for separation is considered non-contentious and can be allowed at Level 1. However, if a client has quit or taken a leave of absence because of the fires, a Level 2 adjudication is necessary. Normal adjudication principles must be followed to determine if the client had a reasonable alternative to quitting or taking a leave of absence.

**Availability**

A client’s availability is not addressed on the application. Therefore, the availability of affected clients can be allowed at Level 1 unless there is additional information on file that indicates the client may not be available. Normal adjudication principles must be followed. However, the Level 2 adjudicator will apply leniency and flexibility and take into account each client’s personal circumstances when adjudicating availability.

**Claimant’s report**

Agents must obtain any missing claimant’s report information whenever they are in contact with an affected client.

**Replacement warrants**

Affected clients will no longer have to wait 8 days before a replacement warrant can be requested. Replacement warrant requests will be processed immediately.

**Western Canada and Territories procedures**

The Western Canada and Territories region has created a web site with processing information and resources for agents who are dealing with claims filed by clients who have been affected by the Fort McMurray fires.
       [web site](http://servicecanada.prv/eng/w-t/pps/ins-ass/ops_committee/wildfire_response.shtml)

**Clients outside the Western Canada and Territories region**

If a client applies using the reference code and provides a residential address outside the Western Canada and Territories region, the claim will  still be calculated in the Western Canada and Territories region. Once the claim is finalized, the claim will be transferred to the region where the client resides. 

### Info

Source topic: `en_EN/common_notes/note_c_1026.dita`

**Note:**

As changes are ongoing, the individual tasks in the EI ORT will not be updated. The information here replaces any related guidance in the EI ORT procedures. Please continue to check this page for further updates. 
