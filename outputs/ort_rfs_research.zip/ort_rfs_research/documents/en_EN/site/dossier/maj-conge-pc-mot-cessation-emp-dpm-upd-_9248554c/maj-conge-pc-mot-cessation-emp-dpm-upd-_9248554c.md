# Updated: Parental leave as the reason for separation on maternity benefit claims — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/maj-conge-pc-mot-cessation-emp-dpm-upd-_9248554c/maj-conge-pc-mot-cessation-emp-dpm-upd-_9248554c.ditamap`

## Summary

Source topic: `en_EN/site/dossier/maj-conge-pc-mot-cessation-emp-dpm-upd-_9248554c/summary.dita`

Effective March 28, 2026, applications for maternity benefits will trip down, creating a Claim Assessment (CA) WI when the reason for separation (RFS) on the last ROE is P - Parental . 

## Generic

Source topic: `en_EN/site/dossier/maj-conge-pc-mot-cessation-emp-dpm-upd-_9248554c/generic.dita`

A system update will create CA WIs on maternity claims when the RFS on the last ROE is P - Parental . This change ensures that the client is applying for the correct benefit type (BT). Changes have also been made to the EI application clarifying the purpose of maternity benefits to reduce errors in clients choosing a BT going forward.

Officers must conduct fact-finding with the employer to ensure that the RFS on the ROE is correct. If so, further fact finding with the client is required to ensure that the BT is correct. The same applies for conversions or renewal claims when an RFS is Parental. 

## Summary of changes

Source topic: `en_EN/site/dossier/maj-conge-pc-mot-cessation-emp-dpm-upd-_9248554c/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
