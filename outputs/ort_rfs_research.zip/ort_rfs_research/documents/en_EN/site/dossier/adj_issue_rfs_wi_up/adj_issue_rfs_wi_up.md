# Adjudication Issue RFS Review WI – Updated procedure

Source map: `en_EN/site/dossier/adj_issue_rfs_wi_up/adj_issue_rfs_wi_up.ditamap`

## Summary

Source topic: `en_EN/site/dossier/adj_issue_rfs_wi_up/summary.dita`

The procedure for Actioning an Adjudication Issue RFS Review WI: K - Other has been updated based on regional feedback. 

## Generic

Source topic: `en_EN/site/dossier/adj_issue_rfs_wi_up/generic.dita`

When fact-finding reveals that the client continues to work part-time, availability is an issue requiring adjudication. In this situation, the agent creates an Adjudication (ADJ) Availability WI before updating the reason for separation (RFS) in RCM and completing the ADJ Issue RFS Review WI in NWS. This step ensures that the claim does not automate before the agent adjudicates the client’s availability.

A regional consideration has been added. In the Quebec region, business expertise advisors (not team leaders) delete WIs. When required by the procedure, the agent uses the National Business Expertise Tool (NEXO) to ask a business expertise advisor to delete the ADJ WI. 

## Summary of changes

Source topic: `en_EN/site/dossier/adj_issue_rfs_wi_up/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
