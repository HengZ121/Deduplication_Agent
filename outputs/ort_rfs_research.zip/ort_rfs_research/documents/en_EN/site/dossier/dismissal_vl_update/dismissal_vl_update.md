# Dismissal and Voluntary leaving procedures update

Source map: `en_EN/site/dossier/dismissal_vl_update/dismissal_vl_update.ditamap`

## Summary

Source topic: `en_EN/site/dossier/dismissal_vl_update/summary.dita`

The procedures for adjudicating dismissal and voluntary leaving have been updated to address issues identified since the November 2015 Employment Insurance Business Solutions release. Additional changes and corrections were made as part of our ongoing efforts to address feedback and improve the content of the EI Online Reference Tool. 

## Generic

Source topic: `en_EN/site/dossier/dismissal_vl_update/generic.dita`

The following content was added to the applicable procedures:

**Non-insurable employment:**

- The agent must adjudicate a reason for separation from employment that is not insurable due to an arm’s length issue.

- The agent does not need to adjudicate a reason for separation from employment that is not insurable either because the client works under a contract for service, or because the client owns more than 40% of the business shares. For initial and renewal claims, the procedures explain how to complete the Adjudication Issue (ADJ) WI.

**Reason for separation (RFS) occurred before the qualifying period:**

- If the facts on file clearly indicate that the RFS occurred before the qualifying period, the Level 2 agent must change the complexity of the ADJ WI on initial or renewal claims so that the appropriate Resolve Issue screens are displayed.

**Mandatory retirement:**

- Human rights legislation in Canada prohibits mandatory retirement. Very few occupations are exempt from this legislation. Some employers may be able to demonstrate a genuine reason for mandatory retirement, but these cases are rare. Mandatory retirement cannot be considered as voluntary leaving because it is the employer, not the client, who initiates the separation from employment. A Level 2 agent must adjudicate the mandatory retirement as a dismissal.

**Client does not want employer to be contacted:**

- If the client does not want the employer to be contacted for fact-finding, the agent must explain when it is legally required. If the client insists that the employer not be contacted, the agent advises the client that the only alternative is to withdraw the claim. The agent must then document the file accordingly.

**Railway misconduct:**

- When adjudicating cases of railway misconduct, the agent must request a copy of the hearing transcript and any other files containing evidence regarding the separation. Railway misconduct is only proven when the agent is able to obtain the transcript, or when the client has provided sufficient information regarding the railway rule or regulation violation to prove misconduct without the transcript.

Additional clarification and corrections were made. Please refer to the description of changes in the table below and to the specific procedures.

Related sections of the Benefit Manual will soon be archived. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/dismissal_vl_update/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
