# Updated: Contentious issues reported on the EI application — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_contentious_issues_reported_on__dab5fa1e/updated_contentious_issues_reported_on__dab5fa1e.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_contentious_issues_reported_on__dab5fa1e/summary.dita`

Effective August 9 2021, certain Adjudication Issue (ADJ) WIs will temporarily not be created. 

## Generic

Source topic: `en_EN/site/dossier/updated_contentious_issues_reported_on__dab5fa1e/generic.dita`

The specialized process ends on August 16, 2021. As a result, the system will again create ADJ WIs for all contentious reasons for separation (RFS) reported on the EI application and continue to auto-adjudicate training when applicable.

In keeping with other transition measures to facilitate access to EI benefits following the end of the emergency response benefits, ADJ WIs will not automatically be created for farming, self-employment and teacher issues declared on initial applications for benefits from August 9 to September 11, 2021. This does not mean that these issues will never be adjudicated. A review process will select claims for adjudication at a later date.

Agents are not expected to identify, create WIs for or adjudicate contentious issues for farming, self-employment (SE) or teacher issues that are declared on initial EI applications received from August 9 to September 11, 2021. However, if the client later reports one of these issues during fact-finding on another issue or on claimant’s reports (during processing of the initial claim or the benefit period [BP]), the agent follows normal adjudication and reconsideration procedures. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_contentious_issues_reported_on__dab5fa1e/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
