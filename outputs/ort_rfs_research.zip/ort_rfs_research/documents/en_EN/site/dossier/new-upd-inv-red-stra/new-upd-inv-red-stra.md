# New and updated: Adjudication not required in the benefit period for BPNE recalculations — Procedures and additional resource (Level 1 and Level 2)

Source map: `en_EN/site/dossier/new-upd-inv-red-stra/new-upd-inv-red-stra.ditamap`

## Summary

Source topic: `en_EN/site/dossier/new-upd-inv-red-stra/summary.dita`

Effective immediately, a Claim Review (CR) Revised WI may no longer be required for a contentious reason for separation (RFS) in the benefit period (BP) of a BPNE claim established through recalculation if specific conditions are met. 

## Generic

Source topic: `en_EN/site/dossier/new-upd-inv-red-stra/generic.dita`

The Inventory Stabilization Strategy team is implementing a strategy for revised claims regarding contentious RFS issues in the BP of BPNE recalculations.

The additional resource Recalculating and establishing BPNE claims: Outstanding issue in the benefit period — Instructions has been created to provide the specific conditions a claim must meet for the officer to process a BPNE recalculation without adjudicating a contentious RFS in the BP.
       [Recalculating and establishing BPNE claims: Outstanding issue in the benefit period — Instructions](/en/procedure/generic/additionalresources/recalc-esta-bpne-claim.shtml)

The officer does not create a CR WI or a record of decision (ROD) if the following conditions are met:

- The date of the event related to the contentious RFS is in the BP.

- One of the following conditions is met:

If a WI related to the contentious RFS is already created, ask the Team Leader to cancel the CR Revised WI.

If these conditions are not met to not adjudicate the contentious RFS in the BP for a BPNE recalculation, the officer processes the recalculation according to the instructions below. If the adjudication cannot be completed at level 1, the officer imposes a 75 - Verification of reason for termination of Employment manual action (MA75) to stop payments until a Level 2 officer reviews the file.

If a BPNE recalculation meets these conditions, the officer processes the recalculation according to the following instructions:

- Create a CR WI for the contentious RFS.

- Complete the CR BPNE Recalculation WI.

The officer does not move the CR BPNE Recalculation WI to Pending while waiting for adjudication. 

## Summary of changes

Source topic: `en_EN/site/dossier/new-upd-inv-red-stra/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
