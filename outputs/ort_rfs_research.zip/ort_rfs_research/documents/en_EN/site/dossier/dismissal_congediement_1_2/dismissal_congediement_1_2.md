# Updated: Dismissal – Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/dismissal_congediement_1_2/dismissal_congediement_1_2.ditamap`

## Summary

Source topic: `en_EN/site/dossier/dismissal_congediement_1_2/summary.dita`

As part of our ongoing efforts to maintain the content of the EI ORT, the activity page and some of the Dismissal procedures have been updated based on regional feedback. 

## Generic

Source topic: `en_EN/site/dossier/dismissal_congediement_1_2/generic.dita`

The activity page has been updated to clarify that when the client has not provided the reason for the dismissal, the agent initiates fact-finding to determine which procedure to choose.

The step to determine if the reason for separation (RFS) is in the qualifying period (QP) for renewal claims has been removed.

The step to determine if the client was reached during the fact-finding is removed in the Adjudicating a dismissal or suspension – Renewal claims task. This is to ensure the agent follows the Verbal communication of a decision task to complete the Verbal Communication of Decision screen on the Resolve Issue tab in NWS.

A step has been added to update the Special Condition field on the ROE in RCM for renewal claims when a previously deferred RFS is now allowed.

Steps in the Review the elements on file section are modified to properly reflect the Levels of Decision policy of the Terminating a D42 disentitlement task. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/dismissal_congediement_1_2/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
