# Updated: Specialized process — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_specialized_process_procedures_l1_l2/updated_specialized_process_procedures_l1_l2.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_specialized_process_procedures_l1_l2/summary.dita`

The specialized process ends on August 16, 2021. 

## Generic

Source topic: `en_EN/site/dossier/updated_specialized_process_procedures_l1_l2/generic.dita`

A specialized process was implemented to streamline the processing of EI regular and sickness benefits so that unemployed clients could transition from the EI Emergency Response Benefits (EI ERB) to EI benefits as quickly as possible. This process will end as of August 16, 2021. Therefore, all applications received as of August 16, 2021, will go through the normal process which includes the creation of WIs and the ROE wait process.

This will have several impacts on processing agents:

- Although no new Assessment Issue (ASMT) WIs related to the specialized process will be created, agents must complete ASMT WIs created for claims received before August 16, 2021;

- The Post-EI ERB — Procedures for claims in the specialized process will remain available to help agents process these WIs
             [Post-EI ERB — Procedures for claims in the specialized process](/en/procedure/activity/post_eierb_assessment_issue_wi_unique_specialized_acp_process.shtml)

- An Adjudication Issue (ADJ) WI will be created for all contentious reason for separation (RFS) issues reported on the application for benefits;

- As per the simplificaiton measures in place , agents are only required to adjudicate the RFS on the last employment in the QP and contentious RFS issues that fall in the 12-week period before the interruption of earnings (I of E) used to establish the claim.
             [simplificaiton measures in place](/en/site/dossier/updated_post_eierb_adjudicating_reason_for_separation_policy_procedure_l1_l2.shtml)

- When a contentious issue is identified for which there is no WI, agents can create the appropriate ADJ WI. However, from August 9, 2021 to September 11, 2021, the system will not raise ADJ issues on initital claims for Farming, Self-Employment and Teaching .
         [Farming, Self-Employment and Teaching](/en/site/dossier/updated_contentious_issues_reported_on_ei_application_l1_l2.shtml)

When processing claims, agents follow current procedures and apply appropriate simplification measures (900-series SINS, availability, fact-finding and Sir non match and missing medical certificates ).
       [simplification measures](/en/site/dossier/updated_extension_temporary_simplification_measures_l1_l2_ipoc.shtml) 
       [missing medical certificates](/en/site/dossier/mc_proc_1_2.shtml) 

## Summary of changes

Source topic: `en_EN/site/dossier/updated_specialized_process_procedures_l1_l2/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
