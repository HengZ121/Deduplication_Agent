# Integrity case – Updates to the activity page

Source map: `en_EN/site/dossier/intergrity_case_uap/intergrity_case_uap.ditamap`

## Summary

Source topic: `en_EN/site/dossier/intergrity_case_uap/summary.dita`

The Integrity case activity page has been update to include information about variable best weeks. 

## Generic

Source topic: `en_EN/site/dossier/intergrity_case_uap/generic.dita`

Agents do not recalculate the claim when Integrity obtains the variable best weeks information that was not provided by the client during the initial calculation of the claim. Agents recalculate the claim only if there is another reason for doing so (example: false ROE, undeclared contentious RFS). 

## Summary Of Changes

Source topic: `en_EN/site/dossier/intergrity_case_uap/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
