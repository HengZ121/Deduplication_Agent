# ROE Issue RFS Action WI — Regular and fishing ROEs

Source map: `en_EN/site/dossier/roe_issue_rfs_action_wi/roe_issue_rfs_action_wi.ditamap`

## Summary

Source topic: `en_EN/site/dossier/roe_issue_rfs_action_wi/summary.dita`

Two new tasks for completing an ROE Issue RFS Action WI have been published in the EI ORT 

## Generic

Source topic: `en_EN/site/dossier/roe_issue_rfs_action_wi/generic.dita`

As part of our efforts to develop the remaining processing procedures, the ROE Issue RFS Action WI activity has been updated to include tasks to complete a WI created for a regular ROE with an RFS of B - Strike or lockout and a fishing ROE with RFS of B - Other . 

## Summary Of Changes

Source topic: `en_EN/site/dossier/roe_issue_rfs_action_wi/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
