# Updated: Undisclosed contentious reason for separation issues — Procedures (Level 1)

Source map: `en_EN/site/dossier/update_ucr_sep_issues/update_ucr_sep_issues.ditamap`

## Summary

Source topic: `en_EN/site/dossier/update_ucr_sep_issues/summary.dita`

As a result of regional feedback, procedures have been updated to provide information to Level 1 officers regarding undisclosed contentious reason for separation (RFS) issues. 

## Generic

Source topic: `en_EN/site/dossier/update_ucr_sep_issues/generic.dita`

Guidance has been added in the What you need to know and Step by step sections of appropriate Level 1 adjudication procedures. This addition is to ensure that the Level 1 officer reviews a file for situations in which a contentious RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists. The Level 1 officer refers to the task Determining if an issue must be referred to Integrity to determine if the contentious RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

The Step by step section has also been updated to clarify the actions the Level 1 officer must take. 

## Summary of changes

Source topic: `en_EN/site/dossier/update_ucr_sep_issues/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
