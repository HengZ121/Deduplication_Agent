# Updated: Fishing ROE Web — Procedures (Non-complex and Level 1)

Source map: `en_EN/site/dossier/updated_fishing_roe_web/updated_fishing_roe_web.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_fishing_roe_web/summary.dita`

Procedures have been updated as a result of the November systems release introducing fishing ROEs to ROE Web. 

## Generic

Source topic: `en_EN/site/dossier/updated_fishing_roe_web/generic.dita`

Employers can now issue fishing ROEs in ROE Web. The serial number for a fishing ROE Web always begins with Y . A fishing ROE Web includes an additional reason for separation (RFS) code ( A - Requested by fisher ). RCM has also been updated to include this new RFS code for entering fishing ROEs when the ROE comment indicates it is requested by the fisher. The dollar amount fields in RCM for fishing ROEs are also expanded from $999 999.99 to $9 999 999.99.

All procedures related to fishing ROEs have been updated to include the new code ( Y ) for a fishing ROE Web. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_fishing_roe_web/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
