# Updated: Deferral of adjudication for a labour dispute — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/mise-rep-dec-con-collectif-upd-def-adj-_9f1da73f/mise-rep-dec-con-collectif-upd-def-adj-_9f1da73f.ditamap`

## Summary

Source topic: `en_EN/site/dossier/mise-rep-dec-con-collectif-upd-def-adj-_9f1da73f/summary.dita`

Based on guidance from the EI Operational Policy Division and feedback from the regions, procedures have been updated to clarify that the reason for separation (RFS) for a strike or lockout (labour dispute) can only be deferred if the claim is or will be BPNE. If the claim is or can be established, deferral of adjudication is impossible. 

## Generic

Source topic: `en_EN/site/dossier/mise-rep-dec-con-collectif-upd-def-adj-_9f1da73f/generic.dita`

In a labour dispute situation, the officer must render a decision on claims for all benefit types (BTs), unless the claim cannot be established. 

## Summary of changes

Source topic: `en_EN/site/dossier/mise-rep-dec-con-collectif-upd-def-adj-_9f1da73f/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
