# Adjudicating a contentious reason for separation on a renewal claim.

Source map: `en_EN/site/dossier/update_adj_crs_rc/update_adj_crs_rc.ditamap`

## Summary

Source topic: `en_EN/site/dossier/update_adj_crs_rc/summary.dita`

Details are provided on how to proceed when adjudication must be done on a contentious reason for separation on a renewal claim and the client has worked enough hours to establish a new claim. 

## Generic

Source topic: `en_EN/site/dossier/update_adj_crs_rc/generic.dita`

Dismissal or voluntary leaving from employment may affect a client’s entitlement to regular benefits on a renewal claim.

Usually, if it is determined the client lost their employment due to misconduct or having no just cause to quit a job, an indefinite disqualification is imposed.  There is one exception: on a renewal claim if no indefinite disqualification has been imposed on the claim and the client has worked enough insurable hours since the last disqualifying event, the client may be exempt from serving the disqualification. In these cases, the claim is renewed and no disqualification is imposed.

Since the IRP 1.2 update, when the Resolve Issue tab of the ADJ WI is completed with a negative decision for a contentious reason for separation, the system automatically impose an indefinite disqualification even if the client has worked enough hours to establish a new claim.

Since no disqualification should be imposed, the agent must manually rescind this disqualification.  Note that the only disqualification that must be rescinded is this event’s. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/update_adj_crs_rc/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
