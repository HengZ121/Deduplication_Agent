# Archived: Information: Update on ROE issued by the Government of Canada

Source map: `en_EN/site/dossier/update_roe_goc/update_roe_goc.ditamap`

## Summary

Source topic: `en_EN/site/dossier/update_roe_goc/summary.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1189.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/update_roe_goc#archived)

Summary: This communication provides information about ROEs issued for the Government of Canada and the process to follow when attempting to conduct fact-finding. The update clarifies the creation of interim ROEs in order to process claims.

     [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1190.dita) 
     [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1191.dita) 

### Warning

Source topic: `en_EN/common_notes/note_c_1189.dita`

**This page has been archived on the Web**

UPDATED: 2024-08-02 — This page has been archived because the information is outdated.

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available. 

### Warning

Source topic: `en_EN/common_notes/note_c_1190.dita`

**Attention:**

This communication applies only to government departments serviced by the Public Service Pay Centre .
       [government departments serviced by the Public Service Pay Centre](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html)

For ROEs issued for government departments not serviced by the Public Service Pay Centre, the agent must return to the originating task or follow normal procedures.

     [government departments serviced by the Public Service Pay Centre](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html) 

### Warning

Source topic: `en_EN/common_notes/note_c_1191.dita`

**Attention:**

As of July 18, 2016, when fact-finding is required to verify ROEs information, the agents must send an email to the Public Service Pay Centre GD mailbox instead of contacting the employer by telephone.

The Public Service Pay Centre GD mailbox should not be used for missing ROEs. 

## Generic

Source topic: `en_EN/site/dossier/update_roe_goc/generic.dita`

**Current situation**

The Government of Canada is onboarding departments to Phoenix, the new pay system.

The implementation of Phoenix occurred in 2 separate rollouts: on February 11, 2016, and on April 7, 2016.

Refer to Phoenix Rollout Schedule for a list of the departments impacted by each rollout.
       [Phoenix Rollout Schedule](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html)

We are currently aware that clients are having difficulties getting their ROEs, or that if an ROE is produced, it contains errors. We are also aware that processing agents are having difficulties reaching the employer to process claims.

**What to expect from an ROE perspective**

As with other employers who change payroll service providers, an ROE is issued by the outgoing service provider. The same should occur for this situation. For a department that has changed to Phoenix, 2 ROEs should be issued: one for the pre-Phoenix employment period (an ROE SAT), and one for the post-Phoenix employment period (a Web ROE). The reason for separation (RFS) of the pre-Phoenix ROE should be K - Other with a comment indicating “Change to payroll provider”.

However, some issues have been raised:

- Only one ROE, the pre or post-Phoenix, has been issued.

- Only one ROE, the pre or post-Phoenix, has been issued, and it covers the entire employment period, causing “NIL” amounts in block 15C.

- Both ROEs are issued, but the employment period dates overlap.

- ROEs are not issued.

- The RFS on the pre-Phoenix ROE SAT is incorrect.

**What you need to do in these cases**

**Missing ROE — Level 1 agents**

As the issue is known, agents processing Claim Assessment WIs must avoid finalizing claims BPNE 2 or inputting D15 disentitlements if the missing ROE is not the last ROE. It is considered that the client unsuccessfully tried to get the ROE from the employer. In this situation, agents must create interim ROEs.

The agents must fact-find with the client to complete the Request for record of employment (INS3166) form.
       [Request for record of employment (INS3166)](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/ROE-INS3166_Request_for_missing_ROE_transcript-Form.doc)

Agents must refer to Determining if an interim ROE is required . As indicated in step 6 of this task, the agents must fact-find with the employer. If the employer cannot be reached, the agent creates the interim ROE, sends the first Z-02-00-00 letter, creates a Reminder (REM) WI and calculates the claim. If the ROE is not received within the applicable timeframes, the agent sends a second Z-02-00-00 letter and creates a second REM WI.
       [Determining if an interim ROE is required](/en/procedure/task/determining_interim_roe.shtml) 
       [fact-find](/en/procedure/task/fact_find.shtml)

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1192.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1193.dita) 

If the employer does not respond to the letter when the agent follows up on the REM WI, the file must be referred to Integrity .
       [referred to Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

**ROEs that must be verified**

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1194.dita) 

**Non-complex level**

Agents processing ROE Issue WI at the Non-complex level must also follow the instructions in this communication.

For an ROE SAT from the Public Service Pay Centre with K - Other in block 16 and no comments in block 18:

- If the last day worked aligns with the Phoenix rollout schedule for that department, the RFS K -Other can be modified to RFS A - Shortage of work/End of contract or season .

**Level 1**

Level 1 agents must refer to the task Correcting an error during calculation or recalculation — Regular ROE .
       [Correcting an error during calculation or recalculation — Regular ROE](/en/procedure/task/correcting_roe_error_calculation_regular.shtml) 

### Callout

Source topic: `en_EN/common_notes/note_c_1192.dita`

The Public Service Pay Centre GD mailbox should not be used for missing ROEs. 

### Info

Source topic: `en_EN/common_notes/note_c_1193.dita`

**Note:**

- When inputting the interim ROE, the agent must use employer number 121491807RP0001.

- When sending a letter to the Public Service Pay Centre, the agent must send it to the following address: Public Services and Procurement Canada Public Service Pay Centre - Mail Facility PO BOX 6500 Matane QC G4W 0H6

- Since the mailing address is a PO BOX, the second Z-02-00-00 letter must be sent by regular mail. 

### Callout

Source topic: `en_EN/common_notes/note_c_1194.dita`

As of July 18, 2016, when it is required to fact-find with the Public Service Pay Centre to verify ROEs information, the agents are allowed to send an email to initiate the contact with the employer. A Pay Centre agent will call back the processing agent in order to conduct the fact-finding. No further email exchanges should occur between Pay Centre agents and processing agents. Only one email must be sent. If within 48 hours the Pay Centre agent has not called the processing agent, the Z-02-00-00 letter is sent as per usual fact-finding procedures.

The agents must use the following template, add their contact information, the ROE serial number and check the appropriate boxes ROE information required
       [ROE information required](/resources/ort/documents/ROE_information_required.msg)

**Note:**

No personal information can be included in the email. The client’s name should not appear in the email; only the information required in the template must be included. 

## Summary of changes

Source topic: `en_EN/site/dossier/update_roe_goc/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
