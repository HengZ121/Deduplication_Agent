# Updated: Adjudicating a reason for separation — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_adjudicating_reason_for_separat_141ad449/updated_adjudicating_reason_for_separat_141ad449.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_adjudicating_reason_for_separat_141ad449/summary.dita`

Tasks related to the reason for separation (RFS) have been updated based on regional contributions received in association with the Budget 2021 RFS measure. 

## Generic

Source topic: `en_EN/site/dossier/updated_adjudicating_reason_for_separat_141ad449/generic.dita`

To respond to contributions received from regions, the following changes have been made in the Voluntary Leaving activity and in the 10 tasks related to the RFS listed below.

**All tasks related to the RFS:**

- The wording in the What you need to know sections has been updated to better explain the Budget 2021 RFS measure and the impacts on adjudication.

- Some headings have been updated for consistency with the other RFS tasks.

- The step numbers in the Step by step sections have been corrected, which were noted following the updates made as a result of Budget 2021.

- The acronym for common entrance requirement (CER) has been updated according to the terminology updates from December 2021.
         [terminology updates](/en/site/dossier/information_terminology_updates_dec_2021.shtml)

**Adjudicating voluntary leaving: Renewal claim — Level 2 and Adjudicating a dismissal or suspension — Renewal claim — Level 2 tasks:**

- The diagrams on the Budget 2021 RFS measure have been adjusted to reflect the appropriate issue for each task.

- The Step by step sections now include instructions on communicating a negative decision to clients with a BPC between w/c 2310 and w/c 2361, both verbally and in writing. Instructions for which attributes to select on the ACS letter have also been added. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_adjudicating_reason_for_separat_141ad449/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
