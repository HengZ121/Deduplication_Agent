# Information: Additional interim measures for clients affected by the 2024 postal services disruption

Source map: `en_EN/site/dossier/info-add-imca-psd-2024/info-add-imca-psd-2024.ditamap`

## Summary

Source topic: `en_EN/site/dossier/info-add-imca-psd-2024/summary.dita`

Interim measures for fact-finding and ROEs are in effect for the duration of the postal services disruption. 

## Generic

Source topic: `en_EN/site/dossier/info-add-imca-psd-2024/generic.dita`

The following measures enhance, but do not replace, the existing procedures and are in addition to the instructions in Information: Interim measures for clients affected by the 2024 postal services disruption .
       [Information: Interim measures for clients affected by the 2024 postal services disruption](/en/site/dossier/info-2024-postal-str-gen.shtml)

**Fact-finding**

When the client, employer or third party does not have a telephone number with a voicemail or an email, the officer moves the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Postal disruption.”

- Bring forward date: Enter today’s date + 3 business days.

The officer repeats moving the WI to Pending until the end of the postal services disruption, if necessary.

At the end of the postal services disruption, if the client is not reached during fact-finding or has not communicated with the officer, the officer creates and sends the N-10-00-00 letter. Then, the officer moves the WI to Pending for another 10 days before proceeding with the usual procedures.

At the end of the postal services disruption, when fact-finding with an employer or third party, the officer creates and sends the Z-00-00-00 letter. Then, the officer moves the WI to Pending for 10 additional days before proceeding with the usual procedures.

There is no change to fact-finding when the officer has left a voicemail message or sent an email.

**ROE verification**

When the officer cannot leave a voicemail message for the employer, or when the employer does not reply to the voicemail, the officer obtains the information from other sources (e.g. the client) and corrects the ROE, or estimates the missing information required to correct the ROE.

The officer creates and sends the Z-02-00-00 letter based on the claim information, and selects all the required attributes, including the following:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1029.dita) 

The officer also creates and sends the N-06-00-00 letter based on the claim information, and selects all the required attributes, including the following:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1030.dita) 

If there is a related ROE Correction WI, the officer completes it. If there is no related ROE Correction WI, the officer follows the appropriate task for calculating a claim. The officer does not refer the file to Integrity for non-compliance.

**Interim ROE**

When an ROE is missing because it has not been received by mail, the officer creates an interim ROE.

The officer disregards the steps for sending a letter to the employer when conducting fact-finding with the employer. 

### Callout

Source topic: `en_EN/common_notes/note_c_1029.dita`

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805):

- Multiple Changes to ROE or

- A Single Change to ROE

- List of the change

- Attached INS 3413 

### Callout

Source topic: `en_EN/common_notes/note_c_1030.dita`

- Various reasons - No ROE - Claim Approved / Claim not established (2699)

- Claim approved -Unverified / Interim ROE(s)

- Unverified ROE / unverified ROEs / Interim ROE / Interim ROEs (2502): Select Unverified ROE or unverified ROE(s) , depending on the case.

- Receive ROE(s)/Receive additional info about ROE(s) (2503): Select Receive additional info about ROE(s) . 

## Summary of changes

Source topic: `en_EN/site/dossier/info-add-imca-psd-2024/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
