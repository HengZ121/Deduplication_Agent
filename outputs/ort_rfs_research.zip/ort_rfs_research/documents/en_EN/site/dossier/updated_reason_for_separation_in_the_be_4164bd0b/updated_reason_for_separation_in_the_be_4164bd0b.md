# Updated: Reason for separation in the benefit period — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_reason_for_separation_in_the_be_4164bd0b/updated_reason_for_separation_in_the_be_4164bd0b.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_reason_for_separation_in_the_be_4164bd0b/summary.dita`

When implementing a negative decision on a contentious reason for separation (RFS) in the benefit period (BP) on an initial claim for which the Claim action status is In Progress , the officer inputs a 15 - Claim Procedure disentitlement (D15) because the system will not impose a disqualification in these cases. 

## Generic

Source topic: `en_EN/site/dossier/updated_reason_for_separation_in_the_be_4164bd0b/generic.dita`

Due to the workload backlog, resulting in claim-processing delays, some clients are finding employment early in their BP after filing an initial claim for EI benefits and are subsequently losing or leaving those jobs while the initial claim’s Claim action status is still In Progress . When the officer adjudicates this contentious RFS and determines that the client did not have just cause for voluntarily leaving their employment or was dismissed due to misconduct, the system does not generate the disqualification transaction as expected when the officer completes the Adjudication Issue (ADJ) WI.

The officer continues to adjudicate all contentious RFSs in the BP and in the qualifying period (QP), as normal. This includes documenting the decision on the Resolve Issue tab of the ADJ WI, verbally communicating the negative decision to the client and creating and saving the D-01-00-00 letter. However, when the contentious RFS is in the BP of an initial claim whose Claim action status is In Progress and the decision is to not allow benefits, the officer follows the new steps in the Adjudicating a dismissal or suspension — Initial claim and Adjudicating voluntary leaving: Initial Claim — Level 2 tasks to impose a D15 since the system does not impose a disqualification.

Imposing a D15 following the decision allows the claim to continue in automation and prevents the payment of benefits once the claim automates and is established. New information has been added to the procedures advising the officer to manually input a D15 disentitlement effective from the Monday of the week of the disqualifying event, as well as to create a Reminder (REM) WI for Level 1 before completing the ADJ WI.

Once the initial claim is established, the Level 1 officer follows the instructions on the REM WI. When a disqualification for an RFS issue in the QP is not imposed and the claim is not BPNE, the Level 1 officer is responsible for imposing the indefinite disqualification, rescinding the D15 and sending the saved D-01-00-00 letter to the client. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_reason_for_separation_in_the_be_4164bd0b/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
