# Updated: Voluntary leaving — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/vl_procedures_li_l2/vl_procedures_li_l2.ditamap`

## Summary

Source topic: `en_EN/site/dossier/vl_procedures_li_l2/summary.dita`

As part of our ongoing efforts to maintain the content of the EI ORT, the activity page and some of the Voluntary leaving procedures have been updated based on regional feedback. 

## Generic

Source topic: `en_EN/site/dossier/vl_procedures_li_l2/generic.dita`

The activity page has been updated to clarify that when the client has not provided the reason for the voluntary leaving, the agent initiates fact-finding to determine which procedure to choose. The activity page has also been updated to include that if there is an Adjudication Issue (ADJ) WI for a contentious RFS that falls after the BPC for claims that are In Progress , the agent continues in that task to adjudicate that WI.

The step to determine if the reason for separation (RFS) is in the qualifying period (QP) for renewal claims has been removed.

A step has been added to update the Special Condition field on the ROE in RCM for renewal and continuing claims.

Clarification has been added that in the What You Need to Know section to properly reflect the Levels of Decision policy of the Adjudicating voluntary leaving (Level 1) course of instruction tasks.

The step to determine if the client was reached during the fact-finding has been removed from the Level 2 Initial and Renewal tasks. The agent refers to the Verbally communicating a negative decision task when the client is not reached to ensure the agent completes the Verbal Communication of Decision screen on the Resolve Issue tab in NWS. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/vl_procedures_li_l2/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
