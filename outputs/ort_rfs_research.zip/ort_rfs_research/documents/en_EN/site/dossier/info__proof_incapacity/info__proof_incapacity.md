# Information: Proof of Incapacity Policy update and determination of the recovery week and incapacity start week on a claim for sickness benefits

Source map: `en_EN/site/dossier/info__proof_incapacity/info__proof_incapacity.ditamap`

## Summary

Source topic: `en_EN/site/dossier/info__proof_incapacity/summary.dita`

After receiving requests for clarification regarding the wording and interpretation of the Proof of Incapacity Policy , the EI Operational Policy Division determined that an update is required to provide clear and concise directions. The Proof of Incapacity Policy will be updated on April 7, 2024, and includes changes to how the recovery week and the incapacity start week are determined on a claim for sickness benefits.
       [Proof of Incapacity Policy](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/proof_of_incapacity_policy.shtml) 
       [Proof of Incapacity Policy](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/proof_of_incapacity_policy.shtml) 

## Generic

Source topic: `en_EN/site/dossier/info__proof_incapacity/generic.dita`

The extension to the number of the sickness benefits weeks has provided greater flexibility to Canadian citizens in need of sickness benefits. To ensure stewardship of the EI account, while seeking an appropriate balance with client service, the Proof of Incapacity Policy was updated to clarify when a client would be required to submit a medical certificate to the Commission.

On a claim for sickness benefits, when the reason for separation (RFS) is D - Illness or injury and the client is not required to submit a medical certificate before sickness benefits are payable, the recovery week will now be calculated as BPC + 8 instead of BPC + 15. This change will apply to all claims with a BPC of April 7, 2024 (w/c 2442) or later. A system update will implement this change.

The Proof of Incapacity Policy will also be updated with instructions on determining the incapacity start date on a claim for sickness benefits.

Procedures affected by this policy update will be changed accordingly on April 8, 2024.

While all clients are required to obtain a medical certificate for sickness benefits, AW will be updated on March 16, 2024 with new messages indicating if a medical certificate must be submitted with the EI application. This will improve clients’ understanding of when a medical certificate must be submitted to the Commission and help with the EI processing workload. The option to upload a medical certificate will only be displayed in specific instances. This will help reduce creating unnecessary WIs related to medical certificates that the client did not need to submit with the EI application. 

## Summary of changes

Source topic: `en_EN/site/dossier/info__proof_incapacity/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
