# Updated: Temporary simplification measures and fact-finding with employers — Procedures (Non-complex, Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_tsmffe/updated_tsmffe.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_tsmffe/summary.dita`

In order to continue to support Canadians during the transition to EI benefits, simplification measures are implemented until March 31, 2021. 

## Generic

Source topic: `en_EN/site/dossier/updated_tsmffe/generic.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1273.dita) 

As part of the transition to EI benefits, simplification measures are implemented for situations where employers need to be contacted during fact-finding.

When fact-finding about reason for separation (RFS) issues, agents make one attempt to contact an employer. When fact-finding with an employer about ROE issues or any other issues (earnings, insurability, etc.), agents follow the normal fact-finding procedures unless they confirm that the business is closed. If the business is closed, agents attempt to resolve the outstanding issues with the client or with the information on file. 

### Note

Source topic: `en_EN/common_notes/note_c_1273.dita`

Note:

This Headlines and Updates page was created on December 23, 2020. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_tsmffe/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
