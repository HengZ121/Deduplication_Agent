# Updated: Deferring adjudication on a renewal claim for regular benefits — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated-deferring-adjudication-renewal-claim/updated-deferring-adjudication-renewal-claim.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated-deferring-adjudication-renewal-claim/summary.dita`

Based on feedback from the regions, the task Deferring adjudication: Renewal claim — Regular benefits has been updated to clarify when the officer can defer the adjudication on a contentious reason for separation (RFS) on a renewal claim when an indefinite disqualification has been imposed after a decision. 

## Generic

Source topic: `en_EN/site/dossier/updated-deferring-adjudication-renewal-claim/generic.dita`

New examples and clearer explanations have been added to the task to help the officer determine if the adjudication of a contentious RFS can be deferred on a renewal claim for regular benefits. The order in which contentious RFSs are reviewed on a renewal claim has been specified. The officer reviews the contentious RFS in the benefit period (BP) one at a time starting from the BPC, after establishing if the client has enough hours to requalify after the disqualifying event. If a contentious RFS is not allowed, the officer determines if the client has enough hours to requalify with another employment. If not, the officer defers the Adjudication Issue (ADJ) WI. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated-deferring-adjudication-renewal-claim/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
