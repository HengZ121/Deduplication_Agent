# Information: Post-EI ERB and Information on upcoming transition to EI and interim measures

Source map: `en_EN/site/dossier/information_erb_pu_post_transitition/information_erb_pu_post_transitition.ditamap`

## Summary

Source topic: `en_EN/site/dossier/information_erb_pu_post_transitition/summary.dita`

The purpose of this update is to provide agents with information related to upcoming changes that will be implemented effective September 27, 2020 related to the transition from Emergency Response Benefits (ERB/CERB) to Employment Insurance. 

## Generic

Source topic: `en_EN/site/dossier/information_erb_pu_post_transitition/generic.dita`

**Transition to EI – Post EI ERB**

Considering the high volume of claims expected after the EI ERB/CERB period ends, systems updates and interim measures have been developed. These changes will be implemented to support clients during this transition period and into the future. While further details and training will be provided prior to these updates, this update is to provide agents with a brief overview of the upcoming changes.

The following temporary measures are being implemented:

**Regional rate of unemployment**

As a first step to help eligible Canadians transition from the EI ERB/CERB back into the EI and into the labour force, a minimum unemployment rate is being used for all EI economic regions in order to lower the hours required to qualify for EI regular benefits. Implemented on August 9, 2020, the RRU for all 62 economic regions is set now to 13.1% unless the reported RRU for that region is higher. This change is in effect from BPC w/c 2251 (August 9, 2020) to BPC w/c 2309 (September 25, 2021).

**Hours credit**

Access to EI benefits is normally based on the number of insurable hours an individual has worked in the year prior to their application, or since their last claim. The pandemic has prevented many Canadians from accumulating the number of insurable hours that is normally required, and the government has taken action to address this. A one-time credit of 300 hours for regular benefits and 480 hours for special benefits will be automatically applied to eligible clients with a BPC from w/c 2258 (September 27, 2020) to BPC w/c 2309 (September 25, 2021).

By setting the minimum RRU to 13. 1%, the Government of Canada can standardize benefits across the country. This will provide clients with a minimum entitlement of 26 weeks of regular benefits and use 14 best weeks to calculate the benefit rate. It also allows the required insurable hours to be set to the minimum of 420 hours, which, when combined with the hours credit, allows individuals to qualify for EI benefits with only 120 hours of insurable work.

**Minimum benefit rate**

To further support clients and in addition to the above measures that will increase access to the program, a minimum benefit rate of $400 per week or $240 per week for extended parental benefits will be automatically applied to eligible clients with a BPC starting w/c 2258 (September 27, 2020) to BPC w/c 2309 (September 25, 2021).

**Waiting period waiver**

The waiting period will be waived on all new initial claims, whether they have received EI ERB/CERB or not, on claims with BPC w/c 2258 (September 27, 2020) up to and including BPC w/c 2262 (October 25, 2020).

**Qualifying Period (QP) Extension**

An automatic QP extension of 28 weeks will be applied to eligible claims from BPC w/c 2258 (September 27, 2020) to BPC w/c 2309 (September 25, 2021) when the client has converted from EI ERB or CERB to EI.

**Monies on separation**

The allocation of monies on separation will no long be required on any claim where the start date of the allocation would begin on or after September 27, 2020 until September 25, 2021, regardless of the BPC.

**Extending casual sickness weeks**

The number of casual sickness weeks is being extended to 15 weeks for all claimant’s reports processed from September 27, 2020 until January 24,2021 regardless of the BPC or whether the clent received EI ERB or CERB.

**Reason for separation**

Simplification measures will be implemented in relation to the adjudication of contentious RFS on new initial claims for regular and sickness benefits for claims with a BPC from w/c 2258 (September 27, 2020) to BPC w/c 2309 (September 25, 2021).

**Specialized ACP Processing**

To support the interim measures a new specialized ACP process will be implemented. This will allow eligible EI ERB clients who have not reported a return to work to automatically be enrolled for EI regular benefits without completeing a new application. This new process will also allow new initial applications for regular or sickness benefits to be processed efficiently while applying the appropriate interim measures.

Procedures related to the interim measures listed above will be updated and further details will be provided once the interim measures are in effect . Watch for these headlines and updates on September 28, 2020.

While this is the most current information, it is subject to change and updates will be communicated as necessary. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/information_erb_pu_post_transitition/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
