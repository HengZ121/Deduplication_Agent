# Updated: ROE comments and artificial intelligence model — Procedures and additional resource (Non-complex and Level 1)

Source map: `en_EN/site/dossier/updated_roe_comments_artificial_intelli_ac8ae751/updated_roe_comments_artificial_intelli_ac8ae751.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_roe_comments_artificial_intelli_ac8ae751/summary.dita`

Procedures have been modified to reflect that an artificial intelligence model has been implemented on June 20, 2020 to assess and action ROE comments. 

## Generic

Source topic: `en_EN/site/dossier/updated_roe_comments_artificial_intelli_ac8ae751/generic.dita`

In this first phase of implementation, the artificial intelligence model evaluates only comments related to the reason for separation (RFS) or to COVID-19 in block 18 of a regular ROE. If the artificial intelligence model can determine the appropriate action, the system moves the comments from block 18 to the Additional Information field. If necessary, the system also modifies the RFS according to current procedures. The artificial intelligence model is applied before the ROE enters the ACP wait process. Consequently, the system only creates a WI in NWS when an agent must review comments that the artificial intelligence model was unable to address.

The artificial intelligence model will also be used to conduct a one-time reassessment of comments on the large volume of ROEs received due to COVID-19 that were not addressed during the simplified processing of EI Emergency Response Benefits. During this one-time reassessment, the artificial intelligence model will assess and action comments in block 18 of a regular ROE if:

- the ROE was created on or after March 8, 2020;

- the ROE has not been corrected;

- there is no ROE Issue (ROE) RFS Action WI associated with the ROE serial number.

If the artificial intelligence model can address the comments on the ROE, a system utility will delete an  associated ROE Comments WI.

Changes made by the artificial intelligence model are indicated in either or both the Audit Trail and Additional Information fields in RCM.

For more information, the agent refers to the system release notes .
       [release notes](http://esdc.prv/en/service-canada/ei/technologies/eibs/updates-highlights/index.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1265.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_1265.dita`

Note:

This Headlines & Updates replaces the information provided in Updated: COVID-19 and ROEs — Procedures and additional resource (Non-complex) .
       [Updated: COVID-19 and ROEs — Procedures and additional resource (Non-complex)](/en/site/dossier/update_covid19_nc_roe.shtml)

     [Updated: COVID-19 and ROEs — Procedures and additional resource (Non-complex)](/en/site/dossier/update_covid19_nc_roe.shtml) 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_roe_comments_artificial_intelli_ac8ae751/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
