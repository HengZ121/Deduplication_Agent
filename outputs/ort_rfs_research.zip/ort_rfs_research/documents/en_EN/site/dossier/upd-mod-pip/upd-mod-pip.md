# Updated: Modification of Proof of Incapacity Policy 4.6 — Policy and procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/upd-mod-pip/upd-mod-pip.ditamap`

## Summary

Source topic: `en_EN/site/dossier/upd-mod-pip/summary.dita`

The requirements for a medical certificate when a client qualifies for special benefits but not for regular benefits have been clarified with respect to the reason for separation (RFS). 

## Generic

Source topic: `en_EN/site/dossier/upd-mod-pip/generic.dita`

A client who applies for sickness benefits with an RFS other than illness or injury must always submit a medical certificate to receive sickness benefits. Proof of Incapacity Policy 4.6 has been updated to indicate that a client who qualifies for special benefits but not regular benefits must submit a medical certificate when the RFS is not illness or injury. Information indicating that a client must always submit a medical certificate when qualifying for special benefits but not regular benefits, regardless of the RFS, has been deleted in the following pages:

- Determining if a medical certificate must be submitted — Renewal and continuing claims

- Calculation: Information on calculation and entitlement to benefits — Knowledge

In addition, podiatrists have been added to the list of medical practitioners who can complete and sign a medical certificate for sickness benefits, or to support voluntary leaving for medical reasons, provided the client’s illness is within the specialist’s field. Digest 11.2.2 will be updated at a future date to reflect this change. 

## Summary of changes

Source topic: `en_EN/site/dossier/upd-mod-pip/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
