# Updated: Deferral of adjudication: Renewal claim — Special benefits (other than sickness) — Task (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_deferral_of_adjudication_renewa_a859f91c/updated_deferral_of_adjudication_renewa_a859f91c.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_deferral_of_adjudication_renewa_a859f91c/summary.dita`

A new situation in which agents can defer the adjudication on a contentious reason for separation (RFS) on a renewal claim for special benefits (other than sickness) has been added. 

## Generic

Source topic: `en_EN/site/dossier/updated_deferral_of_adjudication_renewa_a859f91c/generic.dita`

Previously, agents were only allowed to defer a contentious RFS on a renewal claim for maternity, parental, CCB or family caregiver benefits when an indefinite disqualification was already imposed as a result of adjudication.

Now agents can also defer the adjudication of a contentious RFS on a renewal claim for special benefits (other than sickness) when:

- the ROE with a contentious RFS is for the client’s most recent period of employment and

- the client qualifies for maternity, parental, CCB or family caregiver benefits 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_deferral_of_adjudication_renewa_a859f91c/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
