# Archived: EIA 25 — Adjudication of early course end date — Task (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_eia25_aeced/updated_eia25_aeced.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_eia25_aeced/summary.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1244.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_eia25_aeced#archived)

Due to COVID-19, the requirements for adjudicating early departure from referred training approved under EIA 25 and availability are relaxed. This guidance is in effect from March 09, 2020 to the day the state of emergency is lifted. This includes federal, provincial, territorial and municipal levels.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1245.dita) 

### Warning

Source topic: `en_EN/common_notes/note_c_1244.dita`

**This page has been archived on the Web**

UPDATED: 2020-08-03 — The Headlines and Updates page has been archived because the information is outdated. There should not be any new situations of early termination of referred training.

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available. 

### Note

Source topic: `en_EN/common_notes/note_c_1245.dita`

Note:

This Headlines and Updates was created on April 03, 2020 and has been updated as follows:

- April 22, 2020: The update changes the end date of the training break in FTS from April 10, 2020 to May 09, 2020.

- May 6, 2020: The update changes the end date of the training break in FTS from May 9, 2020 to July 04, 2020.

- August 3, 2020: This H&U is now archived 

## Generic

Source topic: `en_EN/site/dossier/updated_eia25_aeced/generic.dita`

**Table of Contents**

- What You Need To Know
         [What You Need To Know](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_eia25_aeced#What_You_Need)

- Temporary process
         [Temporary process](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_eia25_aeced#Temporary_process)

**What You Need To Know**

Due to COVID-19, some referred training ended early, including the labour market development agreement (LMDA) referred training under EIA 25, Life Long Learning Initiative and apprentices.

To ensure these clients do not have an interruption in pay, National Headquarters and the regions have entered a training break in FTS for the period of March 16 to July 4, 2020. This training break prevents the trip down of claimant reports for claims where the training information on file and the claimant’s report do not match.

If a client or trainer advises that a course has ended early due to COVID-19, the agent accepts this statement at face value. No disqualification for leaving a course early applies as the client did not voluntarily leave, nor was expelled.

Although the Government of Canada has adopted measures to demonstrate flexibility on referred training under EIA 25, Life Long Learning Initiative and apprentices, the agent must still adjudicate voluntary leaving and availability for work issues under the simplified measures below.

**Temporary process**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0974.dita) 

**Adjudicating voluntary leaving: Course of instruction**

Some training programs are cancelled in their entirety due to COVID-19. Adjudication is however still required when a client voluntarily leaves employment to take a course, program of instruction or an employment activity.

A client may be unable to submit the Request for Authorization to Quit Employment (EMP5342) form. This means there is no evidence to support the Counsel to Leave Employment to attend the period of training.

Unless there is evidence to indicate misrepresentation regarding the Counsel to Leave Employment, the agent accepts the client’s statement at face value and allows the reason for separation (RFS).

**Creating a record of decision (ROD)**

Agents create a ROD as follows:

- Comments: Type “Simplification measure. Adjudicating voluntary leaving: Course of instruction.”

- Details: The client states there was a Counsel to Leave Employment, but is unable to submit the Request for Authorization to Quit Employment (EMP5342) form for (enter employer name) due to COVID-19. As per national guidance, the client’s statement is accepted at face value and the RFS is allowed.

**Availability**

When clients advise they cannot work because there is no work in their field due to the COVID-19, agents confirm that there are no other issues affecting availability. If the only consideration is relative to the COVID-19, agents accept that the clients are available for work. Then, agents tell the clients to indicate this information on their claimant’s report.

For more information to assess the need for adjudication, agents refer to Updated: COVID-19 and availability — Procedures (Level 1 and Level 2) .
       [Updated: COVID-19 and availability — Procedures (Level 1 and Level 2)](/en/site/dossier/avail_covid19_l2_l2.shtml)

If there are other issues unrelated to COVID-19, the agent documents the client’s file and a Level 2 agent adjudicates the other issues. For more information, agents refer to Adjudicating the end of referred training .
       [Adjudicating the end of referred training](/en/procedure/task/training_ert.shtml)

**Adjudicating Early Training Ending**

When a trainer or a client indicates that the training ended early, the Commission accepts that the amended end date is due to COVID-19. As per the policy decision, the Commission presumes that:

- the client did not voluntarily leave the training;

- the client was not expelled;

- the client is available within the definition of deemed availability under EIA 25 and EIA 18.

**Creating a record of decision (ROD)**

Agents create a ROD as follows:

- Comments: Type “Simplification measure under EIA 25 for training availability.”

- Details: As per national guidance, no disqualification under EIA 27 applies based on the presumption that the client did not voluntarily leave the training and was not expelled from the training. Availability is allowed, effective the first day following the end of training date. 

### Note

Source topic: `en_EN/common_notes/note_c_0974.dita`

Note:

Procedures have not been updated. Refer to COVID-19 — Measures for a table of affected procedures.
       [COVID-19 — Measures](/en/procedure/generic/covidhu.shtml)

     [COVID-19 — Measures](/en/procedure/generic/covidhu.shtml) 
