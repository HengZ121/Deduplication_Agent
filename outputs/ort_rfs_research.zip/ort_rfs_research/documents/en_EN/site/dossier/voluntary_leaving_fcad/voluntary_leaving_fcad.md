# Voluntary leaving — Federal Court of Appeal decisions

Source map: `en_EN/site/dossier/voluntary_leaving_fcad/voluntary_leaving_fcad.ditamap`

## Summary

Source topic: `en_EN/site/dossier/voluntary_leaving_fcad/summary.dita`

The Federal Court of Appeal (FCA) recently rendered 2 decisions regarding voluntarily leaving employment as a result of modifications affecting a client’s benefits and pensions with the employer. This reminder is also intended to emphasize the importance of fact-finding and the need to clarify the circumstances that led the client to voluntarily leave the employment. 

## Generic

Source topic: `en_EN/site/dossier/voluntary_leaving_fcad/generic.dita`

**Anh Hong (A-281-16)**

In 2012, the company for which the client worked informed its employees of a change to the retirement benefits plan: any employees who retired after January 1, 2015, would no longer keep their extended health benefits after retiring. In order to retain this coverage for her and her husband, the 63-year-old client retired on December 31, 2014, and argued that she had no choice. The client further stated that she would not have retired when she did, had she been able to keep her health benefits upon retiring at a later date.

Given the multiple medications required by the client and her husband, as well as their significant dental needs, the FCA determined that the need to maintain the required coverage provided her with just cause for retiring. The FCA also noted that because the client relied heavily on the benefit coverage, she would likely need to continue to do so during retirement. Therefore, the rollback of the coverage was similar to a significant modification in wages or salary. Under EIA 29(c), such modifications are included in the non-exhaustive list of circumstances that can provide an employee with just cause for leaving the employment.

**William Peppard (A-289-16)**

The client retired from the Canadian Armed Forces as a regular force member in 2010 with 25 years of service. Until September 2013, he served as a full-time reservist while collecting his retirement pension. This was known as “double-dipping.” Following a Canadian Armed Forces policy change made in 2012, the client could no longer “double-dip” after September 14, 2013. He could not work full-time while collecting his retirement pension from the same employer.

After that policy change, the client would have had to begin contributing again (as of September 2013) to his superannuation pension and defer receiving it if he wanted to continue working full-time for the Canadian Armed Forces. Rather than continue to work full-time, the client left his full-time position in favour of a part-time position as a reservist and returned to school full-time. Given these circumstances, the FCA agreed with the Social Security Tribunal (SST) - Appeal Division that the client had just cause for leaving his employment. The FCA decision in this case also cites paragraph 29(c)(vii), which identifies a “significant modification of terms and conditions respecting wages or salary” as an indicator of just cause.

**Impact of these FCA decisions**

These FCA decisions underscore the fact that the list of reasons found in EIA 29(c) is non-exhaustive and that clients with similar reasons could also be considered to have just cause for leaving their employment. That is, if considering all the circumstances, clients did not have any reasonable alternative but to leave the employment when they did.

In the Hong case ( A-281-16 ) specifically, the client separated from her employment by retiring. Although retirement is not one of the circumstances listed under EIA 29(c), the FCA considered that the circumstances of her separation (i.e. significant change in her company’s extended health benefits pre-retirement) provided the employee with just cause for leaving her employment.
       [A-281-16](http://decisions.fca-caf.gc.ca/fca-caf/decisions/en/item/224188/index.do?r=AAAAAQAJMjAxN2ZjYTQ2AQ)

**Fact-finding and decision**

Level 2 agents adjudicate voluntary leaving cases resulting from modifications that affect a client’s benefits and pensions. When doing so, the agents carefully review all circumstances that led the client to leave the employment. Agents must keep in mind that the change to the client’s benefits and pensions must have occurred afterthe client was hired. If the situation which caused the client to leave was a policy already in place when he or she was hired, it is not just cause.

The case of federal employees returning to work on contract illustrates this directive.If these employees work longer than a specific number of days, their pension stops and they must start contributing again. This is not just cause to leave employment, as this condition was in place when they started working.

Once it has been established that the client voluntarily left the employment, the agent decides whether the client is eligible to receive EI benefits by determining if the client had just cause for doing so under EIA 29(c) .
       [EIA 29(c)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

As indicated previously, the list of circumstances in EIA 29( c ) is not exhaustive. The existence of any particular circumstance does not automatically give clients just cause for leaving employment, as clients must also show that they had no reasonable alternative .

The definition of “reasonable alternative” can certainly vary from one case to another. The legislation does not ask clients to do the impossible in establishing just cause for voluntarily leaving. All it requires is what is reasonable under the circumstances. What is required is to determine:

- the situation that led to the voluntary separation;

- whether other measures or reasonable alternatives that could have remedied this situation existed or were exercised; and

- the clients’ reasons for not using what appeared to be reasonable and available solutions.

**Availability and other related issues on the claim**

The agent must consider other factors to pay EI benefits to such clients. Clients must:

- be able, available and looking for any suitable work; and

- meet the qualifying and entitlement conditions.

Voluntary leaving and availability for work are 2 very distinct issues addressed under separate sections of the EIA. The agent must therefore adjudicate them separately, making a decision for each issue. A client who cannot prove availability through an active job search is not normally entitled to regular benefits.

Processing agents should process and input all related issues on a claim, such as allocation of pension or other monies, availability, and reason for separation. All decisions are separate and if one decision later gets rescinded, any other issue affecting pay, such as an allocation, must be on the file.

**Conclusion**

A change in policy is not needed at this time as these 2 FCA decisions (Peppard [ A-289-16 ] and Hong [ A-281-16 ]) are unique and can be distinguished from other situations. EI Operational Policy and Appeals Division at National Headquarters will monitor cases with similar circumstances to determine if there is an issue to be addressed.
       [A-289-16](http://decisions.fca-caf.gc.ca/fca-caf/decisions/en/item/231254/index.do?r=AAAAAQAJMjAxN2ZjYTQ2AQ) 
       [A-281-16](http://decisions.fca-caf.gc.ca/fca-caf/decisions/en/item/224188/index.do?r=AAAAAQAJMjAxN2ZjYTQ2AQ)

Remember that, as all cases have their specifics facts, each must be considered individually. If in the future you have a specific case where questions are raised, please submit them to the EI Operational Policy Service Desk at nc-ins-assur_benefit_entitlement-gd@hrdc-drhc.net .
       [nc-ins-assur_benefit_entitlement-gd@hrdc-drhc.net](mailto:nc-ins-assur_benefit_entitlement-gd@hrdc-drhc.net) 

## Summary Of Changes

Source topic: `en_EN/site/dossier/voluntary_leaving_fcad/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
