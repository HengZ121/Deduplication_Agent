# New and updated: Budget 2021: Increase in the maximum number of weeks of sickness benefits — Policy and procedures (Level 1, Level 2 and IPOC)

Source map: `en_EN/site/dossier/new_upd_buget2021_increase_max_num_wks__9c80c870/new_upd_buget2021_increase_max_num_wks__9c80c870.ditamap`

## Summary

Source topic: `en_EN/site/dossier/new_upd_buget2021_increase_max_num_wks__9c80c870/summary.dita`

As part of Budget 2021, the Government of Canada announced that the maximum number of weeks of entitlement to sickness benefits is increasing from 15 to 26 weeks. 

## Generic

Source topic: `en_EN/site/dossier/new_upd_buget2021_increase_max_num_wks__9c80c870/generic.dita`

Clients who have claims with a BPC of December 18, 2022 (w/c 2374) or later could be entitled to a maximum of 26 weeks of sickness benefits in their benefit period (BP). Clients who have claims with a BPC of December 11, 2022 (w/c 2373) or earlier will continue to be entitled to a maximum of 15 weeks of sickness benefits in a BP. Refer to BE Memo 2022-08 for additional information.
       [BE Memo 2022-08](/en/policy/bememo/be2022_08.shtml)

**Additional resource**

A new resource, Benefit period: Extension for special benefits (BPC in w/c 2374 or later) — Table, has been created for claims with BPCs of w/c 2374 or later to indicate the changes to the total weeks of entitlement when there is a combination of special benefits. The existing table has been retitled Benefit period: Extension for special benefits (BPC in w/c 2373 or earlier) — Table.

**Recovery date**

For a claim for sickness benefits when no medical certificate is required and none has been submitted, the officer still calculates the recovery week as BPC + 15.

The guidance for determining the recovery date on a claim has not changed. However, the task Modifying the sickness benefits information on the Annex - Special Benefits screen in SSA has been updated to remove steps that incorrectly referred to information on medical certificates in the section on determining the recovery date when no medical certificate is on file. Clarifications have been added to some tasks to indicate that if a medical certificate was submitted, the officer must use it to determine the client’s entitlement to sickness benefits and the recovery date, whether the certificate was required or not.

**Communication to Clients**

MSCA will generate a message to clients when a claim for sickness benefits is established. The message advises clients that if they are able to provide a medical certificate, they may be entitled to a maximum of 26 weeks of sickness benefits for claims with a BPC of w/c 2374 or later and a maximum of 15 weeks of sickness benefits for claims with a BPC of w/c 2373 or earlier. Clients are also advised in AW that if they are requesting 9 or more weeks of sickness benefits, they must submit a medical certificate. If a claim for sickness benefits is calculated with a recovery week of BPC + 15 because no medical certificate is required and none has been submitted, the officer does not send an ACS letter to the client. Clients whose claim has a BPC of w/c 2374 or later and is calculated with a recovery week of BPC + 15 are only entitled to 15 weeks of sickness benefits unless they submit an acceptable medical certificate indicating a later recovery date. Officers will continue to send ACS letters when the recovery week has been determined based on a medical certificate.

**Combination of sickness and maternity benefits**

There are no changes to claims with sickness benefits combined with maternity, or with maternity and parental benefits. The recovery week remains BPC + 8 when the RFS is D , there is no medical certificate on file and the client is otherwise available for the period for which they are requesting sickness benefits. If the client has submitted a medical certificate, the officer still determines the period for which the client is entitled to sickness benefits based on the information on the medical certificate. If the client is entitled to sickness benefits in the maternity window, regardless of the number of weeks of sickness benefits the client may be entitled to, the officer still determines the correct date for the start of maternity benefits and, if necessary, inputs the external maternity start week to begin payment of maternity benefits.

**IPOC**

The following IPOC task and additional resources have been updated to align with the budget 2021 increase in the maximum number of weeks of sickness benefits:

- Changing a fishing claim type — Purge and recreate
         [Changing a fishing claim type — Purge and recreate](/en/procedure/task/changing_fct_pr.shtml)

- Claimant’s report: Pay coding (external or internal exclusion) — Input guide
         [Claimant’s report: Pay coding (external or internal exclusion) — Input guide](/en/procedure/generic/additionalresources/pay_coding_guide.shtml)

- T072: MPS claimant’s report — Transaction
         [T072: MPS claimant’s report — Transaction](/en/procedure/generic/additionalresources/manual_pay_sys_claimant.shtml)

**Other changes**

ACS letters have been updated to include a drop-down menu with options of a maximum of either 15 or 26 weeks of sickness benefits.

Based on a new legal opinion, EI Operational Policy has confirmed that the maximum number of weeks of combined special benefits payable in a BP is 102. Tasks and additional resources have been updated where they incorrectly referred to a maximum of 104 weeks payable. 

## Summary of changes

Source topic: `en_EN/site/dossier/new_upd_buget2021_increase_max_num_wks__9c80c870/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
