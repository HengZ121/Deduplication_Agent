# Updated: Misrepresentation penalty calculation exceptions — Procedures (Level 2)

Source map: `en_EN/site/dossier/upd_misrep_penalty_calc_exceptions_proc_l1/upd_misrep_penalty_calc_exceptions_proc_l1.ditamap`

## Summary

Source topic: `en_EN/site/dossier/upd_misrep_penalty_calc_exceptions_proc_l1/summary.dita`

Based on regional feedback, the Adjudicating client or third party misrepresentation — Monetary penalty or warning letter task has been updated to include an existing exception regarding penalty calculations that was missing. 

## Generic

Source topic: `en_EN/site/dossier/upd_misrep_penalty_calc_exceptions_proc_l1/generic.dita`

When a client submits an ROE on which the reason for separation (RFS) was knowingly altered and the misrepresentation is identified before benefits are paid, the claim is established with a benefit rate, but no benefits are paid because of the disqualification. In this case no overpayment (OP) occurs, therefore the penalty is calculated based on the benefit rate rather than the net OP.

Details of the calculation and an example have been added in the What You Need To Know section. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/upd_misrep_penalty_calc_exceptions_proc_l1/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
