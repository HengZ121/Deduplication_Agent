# Updated: COVID-19 and missing medical certificates — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/mc_proc_1_2/mc_proc_1_2.ditamap`

## Summary

Source topic: `en_EN/site/dossier/mc_proc_1_2/summary.dita`

Due to COVID-19, the Government of Canada has removed the requirement for clients to submit a medical certificate when requesting benefits. 

## Generic

Source topic: `en_EN/site/dossier/mc_proc_1_2/generic.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1134.dita) 

**Table of Contents**

- What You Need To Know
         [What You Need To Know](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/mc_proc_1_2#wyntk)

- Temporary process
         [Temporary process](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/mc_proc_1_2#tp)

**What You Need To Know**

Normally, when medical proof is required to obtain benefits, the client must submit a medical certificate. The government has removed this requirement for certain periods in order to ease the process of obtaining benefits. This will also reduce the number of clients who must seek out medical attention when requesting benefits. When simplification measures apply, agents must not request that clients provide a medical certificate.

**Medical certificate for sickness benefits, to justify a reason for separation (RFS) or in cases of early recovery**

For benefit periods (BPs) established or renewed from March 15, 2020 (w/c 2230) to September 19, 2021 (w/c 2309), a client is no longer required to provide a medical certificate to receive sickness benefits. This also applies for claims for regular benefits when a client needs to justify an RFS for medical reasons.

When a client requests regular benefits after having received sickness benefits and declares an early recovery, a medical certificate is not required if the effective date of the conversion is between March 15, 2020 (w/c 2230) and September 19, 2021 (w/c 2309).

For BPs established before March 15, 2020, no new medical certificate is required to pay sickness benefits for weeks between March 15, 2020 to September 25, 2021.

When a medical certificate is not provided, the agent adds a record of decision (ROD) to the file to indicate that a medical certificate is not required due to the simplification measures.

Any claim with a BPC of w/c 2309 (September 19, 2021) or earlier will benefit from the temporary measure, and claims with a BPC of w/c 2310 (September 26, 2021) or later will revert to standard rules.

**Medical certificate for CCB or family caregiver benefits**

For claims with a BPC between w/c 2230 (March 15, 2020) and w/c 2258 (September 27, 2020), a client requesting CCB or family caregiver benefits is not required to provide a medical certificate or an authorization to release a medical certificate to be entitled to benefits. For claims with a BPC of w/c 2259 or later, the client must provide a medical certificate and an authorization to release a medical certificate as per normal procedures to receive these benefits.

For BPs established before March 15, 2020, no new medical certificate or authorization to release a medical certificate is required to pay special benefits on a renewal or conversion claim for the weeks between w/c 2230 (March 15, 2020) and w/c 2258 (September 27, 2020).

Any claim with a BPC of w/c 2258 (September 27, 2020) or earlier will benefit from the temporary amendment and claims with a BPC of w/c 2259 (October 4, 2020) or later will revert to standard rules.

**Reviewing a medical certificate supplied by the client**

When a medical certificate is provided, it must be reviewed to determine the client’s entitlement. The agent adjudicates the issue under the normal procedures.

**Regular and sickness benefits**

**The following procedures have been updated:**

- Converting a claim from regular to sickness benefits
         [Converting a claim from regular to sickness benefits](/en/procedure/task/conv_regsick.shtml)

- Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim
         [Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim](/en/procedure/task/conv_regsick_eia25.shtml)

- Converting a claim from maternity to sickness benefits
         [Converting a claim from maternity to sickness benefits](/en/procedure/task/conv_matsick.shtml)

- Converting a claim from parental to sickness benefits
         [Converting a claim from parental to sickness benefits](/en/procedure/task/conv_parsick.shtml)

- Renewing a claim for sickness benefits
         [Renewing a claim for sickness benefits](/en/procedure/task/renew_sb.shtml)

- Determining if a medical certificate is required or acceptable — Sickness benefits
         [Determining if a medical certificate is required or acceptable — Sickness benefits](/en/procedure/task/calc_determining/det_mc_ra.shtml)

- Adjudicating voluntary leaving (Level 1): Medical reasons — Initial claim
         [Adjudicating voluntary leaving (Level 1): Medical reasons — Initial claim](/en/procedure/task/vllevel1_mr_ic.shtml)

- Adjudicating voluntary leaving (Level 1): Medical reasons — Continuing claim
         [Adjudicating voluntary leaving (Level 1): Medical reasons — Continuing claim](/en/procedure/task/voluntary_leaving_medical_reason_l1.shtml)

- Adjudicating voluntary leaving (Level 1): Medical reasons — Renewal claim
         [Adjudicating voluntary leaving (Level 1): Medical reasons — Renewal claim](/en/procedure/task/vllevel1_mr_rc.shtml)

- Converting a claim from sickness to regular benefits
         [Converting a claim from sickness to regular benefits](/en/procedure/task/conv_sickreg.shtml)

**CCB**

**Temporary process**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1135.dita) 

**Determining entitlement**

For new, renewed or converted BPs between March 15, 2020 (w/c 2230) and September 27, 2020 (w/c 2258), the agent considers that the client is entitled to any benefits that would have been payable if the medical certificate had been issued. This means that the patient meets the following conditions:

- The patient has a significant risk of death in the next 26 weeks.

- The patient requires care or support.

The agent does not conduct fact-finding with the client and consider that these entitlement conditions are met as if the medical certificate had been provided.

**Determining the compassionate care window (CCW)**

When there is no existing CCW, instead of using information that would normally be provided on a medical certificate, the agent uses:

- the BPC to determine the CCW start date for initial claims;

- the renewal week to determine the CCW start date for renewal claims.

- the week the claim was converted to CCB to determine the CBW start date when converting on a continuing claim.

When there is already a CCW for a patient, the agent follows the usual procedures. The agent marks the new certificate as duplicate and adds the claimant to the existing certificate.

**Changes to required SSA inputs**

For CCB, no additional inputs are required on the Annex - Special Benefits screen as the Compassionate care proof field is prefilled with Yes .

**Changes to inputs in the Caregiver/Compassionate care data entry (MCB1) transaction**

When there is no existing CCW, do the following:

- Certificate confirmation: Select Y - Approved .

- Start date: Enter the start date that applies (the BPC start date, renewal week or conversion week).

**Family caregiver benefits**

**Temporary process**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1135.dita) 

**Determining entitlement**

For new, renewed or converted BPs between March 15, 2020 (w/c 2230) and September 27, 2020 (w/c 2258), the agent considers that the client is entitled to any benefits that would have been payable if the medical certificate had been issued. This means that the patient meets the following conditions:

- The patient’s life is at risk.

- There has been a change in the patient’s baseline state of health.

- The patient requires care or support.

The agent does not conduct fact-finding with the client and consider that these entitlement conditions are met as if the medical certificate had been provided.

**Determining the family caregiver window (FCW)**

When there is no existing FCW, instead of using information that would normally be provided on a medical certificate, the agent uses:

- the BPC to determine the FCW start date on initial claims;

- the renewal week to determine the FCW start date on renewal claims.

- the week the claim was converted to FCB to determine the FCW start date when converting on a continuing claim.

When there is already a FCW for a patient, the agent follows the usual procedures. The agent marks the new certificate as duplicate and adds the claimant to the existing certificate.

**Determining the care or support end date for FCB**

To calculate the care or support end date, the agent uses the BPC + 51 weeks for initial claims, the renewal week + 51 weeks for renewal claims or the conversion week + 51 for conversions.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1136.dita) 

When the FCW was established before March 15, 2020, and the client requests additional weeks between March 15, 2020 and October 3, 2020, no medical is required.

If the original care and support end date was March 7, 2020 or earlier, and the client requests additional weeks to be paid prior to March 15, 2020, a medical is required .

**Changes to required SSA inputs**

For FCB, on the Annex - Special Benefits screen, type “Y” for yes in the Medical proof is provided? Field, which is prefilled with N for no, since the claim is to be established as if the client had provided a medical certificate.

**Changes to inputs in the Caregiver/Compassionate care data entry (MCB1) transaction**

When there is no existing FCW, do the following:

- Certificate confirmation: Select Y - Approved .

- Start date: Enter the start date that applies (the BPC start date, renewal week or conversion week).

For family caregiver benefits, do the following:

- End date for care/support: Enter the appropriate option:

- For initial claims, enter the Saturday of the week corresponding to BPC + 51 weeks.

- For renewal claims, enter the Saturday of the week corresponding to the renewal week + 51 weeks.

- For conversions, enter the Saturday of the week corresponding to the week of the conversion +51.

For claims established before March 15, 2020, when a patient requires additional care or support (extension of the end date for care or support) for weeks falling March 15 or later, input in the end date of the FCW in the End date for care/support field.

**Obtaining more information**

For more information, the agent refers to Medical Certificates During the COVID-19 Situation – BE 2020-03 and to Emergency Response Benefit Transition Provisions — BE 2020-05 .
       [Medical Certificates During the COVID-19 Situation – BE 2020-03](/en/policy/bememo/be2020-03.shtml) 
       [Emergency Response Benefit Transition Provisions — BE 2020-05](/en/policy/bememo/be2020-05.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1134.dita`

Note:

This Headlines and Updates page was created on April 3, 2020 and has been updated as follows:

- May 27, 2020: The page now includes information about missing medical certificates for CCB and family caregiver benefits. The April 6, 2020 Headlines and Updates page about missing medical certificates for CCB and family caregiver benefits has been deleted.

- June 4, 2020: The page has been updated to specify that the agent inputs the recovery week on an Initial decision ( M103) transaction and not in the Annex - Special Benefits screen in SSA for sickness benefits.

- October 1, 2020: The page has been updated to extend the measure until September 25, 2021 except for CCB and family caregiver benefits.

- November 13, 2020: The page has been updated to clarify information on missing medical certificates for CCB and family caregiver benefits.

- December 4, 2020: The page has been updated to indicate that the procedures for regular and sickness benefits have been updated to reflect the current measures.

- January 26, 2021: The page has been updated to add information about early recovery. 

### Note

Source topic: `en_EN/common_notes/note_c_1135.dita`

Note:

Procedures have not been updated. The agent refers to COVID-19 — Procedural changes for a table of affected procedures.
       [COVID-19 — Procedural changes](/en/procedure/generic/covidhu.shtml)

     [COVID-19 — Procedural changes](/en/procedure/generic/covidhu.shtml) 

### Example

Source topic: `en_EN/common_notes/note_c_1136.dita`

Example:

- If a claim is established with a BPC w/c 2230 (15 March 2020), the care or support end date will be the Saturday of w/c 2281 (13 March 2021.)

- If a claim is renewed with a renewal week of w/c 2250, the care or support end date will be the Saturday of w/c 2301 (31 July 2021.)

- If a claim is converted in the week w/c 2250, the care or support end date will be the Saturday of w/c 2301 (31 July 2021.) 

## Summary Of Changes

Source topic: `en_EN/site/dossier/mc_proc_1_2/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
