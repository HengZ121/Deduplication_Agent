# Information: COVID-19 and processing information (Questions and answers)

Source map: `en_EN/site/dossier/information_covid19_processing_information/information_covid19_processing_information.ditamap`

## Summary

Source topic: `en_EN/site/dossier/information_covid19_processing_information/summary.dita`

Due to COVID-19, additional information to support claim processing is provided. 

## Generic

Source topic: `en_EN/site/dossier/information_covid19_processing_information/generic.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1082.dita) 

The information contained in this update provides agents with the most current procedures, policies, workload instructions and system information to help process claims.

However, as the situation is constantly evolving, this information is subject to change and will be updated, if necessary.

This page will regularly be updated to include more questions and answers.

**Table of content**

- EI Emergency Response Benefit – General information

- How can agents identify if a claim is an EI Emergency Response Benefit claim?
             [How can agents identify if a claim is an EI Emergency Response Benefit claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_How_can_agents)

- How do clients know if they should apply with Canada Revenue Agency or Service Canada?
             [How do clients know if they should apply with Canada Revenue Agency or Service Canada?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_How_do_clients)

- Can a client with an EI Emergency Response Benefit claim request that their claim be established under normal EI rules and have a benefit rate higher than $500 per week?
             [Can a client with an EI Emergency Response Benefit claim request that their claim be established under normal EI rules and have a benefit rate higher than $500 per week?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_a_client)

- Will the EI Emergency Response Benefit count as regular weeks of EI entitlement?
             [Will the EI Emergency Response Benefit count as regular weeks of EI entitlement?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Will_the_EI)

- What is the one-time payment of $2000 that clients will receive?
             [What is the one-time payment of $2000 that clients will receive?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_What_is_the)

- Is the one-time payment of $2000 being paid on every EI Emergency Response Benefit claims?
             [Is the one-time payment of $2000 being paid on every EI Emergency Response Benefit claims?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Is_the_one-time)

- How many weeks of the EI Emergency Response Benefit can the client request?
             [How many weeks of the EI Emergency Response Benefit can the client request?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#how_many_wks_ei_erb_client_request)

         [EI Emergency Response Benefit – General information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#EI_Emergency_Response_gi)

- EI Emergency Response Benefit – Processing claims

- What should agents do with a draft SROC of claims that have been completed as an EI Emergency Response Benefit claim?
             [What should agents do with a draft SROC of claims that have been completed as an EI Emergency Response Benefit claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_What_should_agents)

- Will previously finalized BPNE claims with a BPC on or after March 15, 2020 be converted to EI Emergency Response Benefit?
             [Will previously finalized BPNE claims with a BPC on or after March 15, 2020 be converted to EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Will_previously_finalized)

- Where does the agent find the tentative BPC on a skeleton claim?
             [Where does the agent find the tentative BPC on a skeleton claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Where_does_the)

- For what reasons will the ACP utility not automate a skeleton claim as an EI Emergency Response Benefit claim?
             [For what reasons will the ACP utility not automate a skeleton claim as an EI Emergency Response Benefit claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_For_what_reasons)

- Can agents rescind a disentitlement or disqualification that is imposed on an EI Emergency Response Benefit claim?
             [Can agents rescind a disentitlement or disqualification that is imposed on an EI Emergency Response Benefit claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_agents_rescind)

- Is there a specific window for a client to collect the EI Emergency Response Benefit?
             [Is there a specific window for a client to collect the EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Is_there_a)

- Should agent check the ERB Details screen to determine if the client is receiving CERB prior to establishing the EI Emergency Response Benefit claim?
             [Should agent check theERB Detailsscreen to determine if the client is receiving CERB prior to establishing the EI Emergency Response Benefit claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Should_agent_check)

- Why is the 65 - Lump Sum Payment ($2000) - Canadian Emergency Response disentitlement (D65) imposed on EI Emergency Response Benefit claims?
             [Why is the65 - Lump Sum Payment ($2000) - Canadian Emergency Responsedisentitlement(D65)imposed on EI Emergency Response Benefit claims?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#why_65_imposed_ei_erbc)

- How will the D65 be communicated to clients?
             [How will the D65 be communicated to clients?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#how_d65_communicated_client)

- Is the D65 imposed on claims where clients received money from the CRA?
             [Is the D65 imposed on claims where clients received money from the CRA?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Is_the_D65)

- Does the CERB (CRA) field gets updated when the client repays the money paid?
             [Does the CERB (CRA) field gets updated when the client repays the money paid?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_does_cerb_cra)

- Are clients who where on maternity or parental leave immediately prior to the start of the pandemic, considered to have loss their employment due to COVID-19 if they cannot return to work?
             [Are clients who where on maternity or parental leave immediately prior to the start of the pandemic, considered to have loss their employment due to COVID-19 if they cannot return to work?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Are_clients_who)

         [EI Emergency Response Benefit – Processing claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#ei_rb_pc)

- After the last payment of the EI Emergency Response Benefit

- Do clients need to submit a new EI application or call Service Canada after receiving 28 weeks of the EI Emergency Response Benefit?
             [Do clients need to submit a new EI application or call Service Canada after receiving 28 weeks of the EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#client_need_submit_ei_erb)

- Do clients need to submit a new EI application or call Service Canada after receiving 28 weeks of CERB?
             [Do clients need to submit a new EI application or call Service Canada after receiving 28 weeks of CERB?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#client_need_submit_ei_cerb)

         [After the last payment of the EI Emergency Response Benefit](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#after_last_payment_ei_erb)

- Canada Emergency Student Benefit

- What is the Canada Emergency Student Benefit?
             [What is the Canada Emergency Student Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_What_is_the_cesb)

- How much can student receive?
             [How much can student receive?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_How_much_can)

- Can an EI Emergency Response Benefit claim be terminated if the client should have applied to the CESB instead?
             [Can an EI Emergency Response Benefit claim be terminated if the client should have applied to the CESB instead?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_an_EI)

         [Canada Emergency Student Benefit](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Canada_Emergency_Student)

- Canada Emergency Wage Subsidy

- What is the Canada Emergency Wage Subsidy?
             [What is the Canada Emergency Wage Subsidy?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_What_is_the_cews)

- Should an employer include the CEWS as earnings when completing a ROE?
             [Should an employer include the CEWS as earnings when completing a ROE?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Should_an_employer_cews)

- How should the employer attribute hours when the employees are paid their normal salary but they are not working?
             [How should the employer attribute hours when the employees are paid their normal salary but they are not working?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_How_should_employee_pay_normal)

- How should the employer attribute hours when the employees are paid an amount lower than their normal salary?
             [How should the employer attribute hours when the employees are paid an amount lower than their normal salary?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_How_should_employee_pay_lower)

         [Canada Emergency Wage Subsidy](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Canada_Emergency_Wage)

- 900-series SIN

- Can clients with a 900-series SIN receive benefits if a valid work permit is not on file?
             [Can clients with a 900-series SIN receive benefits if a valid work permit is not on file?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_clients_with)

- What should agents do if they have an ASMT Insurability WI for a client with a 900-series SIN?
             [What should agents do if they have an ASMT Insurability WI for a client with a 900-series SIN?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_What_should_agents)

- Can clients with a 900-SIN who have a valid work permit or implied status be considered available for work if they are not working due to COVID-19?
             [Can clients with a 900-SIN who have a valid work permit or implied status be considered available for work if they arenotworking due to COVID-19?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_clients_with_1)

         [900-series SIN](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_900-series_SIN)

- Availability

- Are clients expected to actively look for a job during the COVID-19 pandemic?
             [Are clients expected to actively look for a job during the COVID-19 pandemic?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Are_clients_expected)

- Can clients who states experiencing childcare issue due to COVID-19 be considered available?
             [Can clients who states experiencing childcare issue due to COVID-19 be considered available?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_clients_who)

- Is training considered a contentious issue on EI Emergency Response Benefit claims?
             [Is training considered a contentious issue on EI Emergency Response Benefit claims?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Is_training_considered)

- Can an agent terminate a 3-Not available (D03) disentitlement on a claim with a BPC prior to March 15, 2020, if the client’s training stopped due to COVID-19?
             [Can an agent terminate a3-Not available (D03)disentitlement on a claim with a BPC prior to March 15, 2020, if the client’s training stopped due to COVID-19?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_an_agent)

         [Availability](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#availability)

- Claimant’s report

- Do clients with an EI Emergency Response Benefit claim have to complete claimant’s reports?
             [Do clients with an EI Emergency Response Benefit claim have to complete claimant’s reports?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Do_clients_with)

- How does the system process the information declared on the claimant’s report?
             [How does the system process the information declared on the claimant’s report?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_How_does_the)

- How long do clients have to complete their claimant’s report?
             [How long do clients have to complete their claimant’s report?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_How_long_do)

- What actions must be taken when a client reports a mistake made on a claimant’s report for an EI Emergency Response Benefit claim?
             [What actions must be taken when a client reports a mistake made on a claimant’s report for an EI Emergency Response Benefit claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_What_actions_must)

- What clients should be answering on the CR when they have been recalled to work but are unable to return?
             [What clients should be answering on the CR when they have been recalled to work but are unable to return?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_What_clients_should)

         [Claimant’s report](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#claimant_report)

- Earnings

- Does allocation of earnings have an impact on EI Emergency Response Benefit claims?
             [Does allocation of earnings have an impact on EI Emergency Response Benefit claims?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Does_allocation_of)

- Should allocation letters be sent to client receiving the EI Emergency Response Benefit?
             [Should allocation letters be sent to client receiving the EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Should_allocation_letters)

         [Earnings](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#earnings)

- Family supplement

- Is a client with an EI Emergency Response Benefit claim eligible for family supplement?
             [Is a client with an EI Emergency Response Benefit claim eligible for family supplement?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Is_a_client)

- Does the family supplement apply to the initial $2000 payment?
             [Does the family supplement apply to the initial $2000 payment?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Does_the_family)

         [Family supplement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#fs)

- Income taxes and T4

- Can a client request that income taxes be deducted on EI Emergency Response Benefit payments?
             [Can a client request that income taxes be deducted on EI Emergency Response Benefit payments?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_a_client_4)

- Will clients receive a T4 slip if they have received a CERB payment?
             [Will clients receive a T4 slip if they have received a CERB payment?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Will_clients_receive)

- Are income taxes deducted from EI Emergency Response Benefit payments?
             [Are income taxes deducted from EI Emergency Response Benefit payments?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Are_income_taxes)

         [Income taxes and T4](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#it_t4)

- Maternity benefits and EI Emergency Response Benefit

- How will EI Emergency Response Benefit payments affect clients requesting maternity or parental benefits after the EI Emergency Response Benefit period?
             [How will EI Emergency Response Benefit payments affect clients requesting maternity or parental benefits after the EI Emergency Response Benefit period?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_How_will_EI)

- Does EI Emergency Response Benefit payments affect the weeks of entitlement to maternity or parental benefits?
             [Does EI Emergency Response Benefit payments affect the weeks of entitlement to maternity or parental benefits?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Do_EI_Emergency)

- Can a Confinement week or Arrival placement week be input on tan EI Emergency Response Benefit claim?
             [Can a Confinement week or Arrival placement week be input on tan EI Emergency Response Benefit claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_a_Confinement)

- Is there a specialized team handling the processing of maternity claims after the client collect EI Emergency Response Benefit?
             [Is there a specialized team handling the processing of maternity claims after the client collect EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Is_there_a_specialized_team)

- Is the QP extended for clients requesting maternity benefits after collecting the EI Emergency Response Benefit?
             [Is the QP extended for clients requesting maternity benefits after collecting the EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Is_the_QP)

         [Maternity benefits and EI Emergency Response Benefit](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Maternity_benefits_and)

- Out of Canada

- Should a disentitlement be imposed for Out of Canada on EI Emergency Response Benefit claims?
             [Should a disentitlement be imposed for Out of Canada on EI Emergency Response Benefit claims?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Should_a_disentitlement)

         [Out of Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#out_canada)

- Overpayments and dual payments

- Will clients have to repay the overpayment that was created when their claim was recalculated as an EI Emergency Response Benefit claim (e.g. benefit rate was $573 and is now $500)?
             [Will clients have to repay the overpayment that was created when their claim was recalculated as an EI Emergency Response Benefit claim (e.g. benefit rate was $573 and is now $500)?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Will_clients_have)

- Under what circumstances can a client be asked to repay payments received from CRA for CERB?
             [Under what circumstances can a client be asked to repay payments received from CRA for CERB?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Under_what_circumstances)

- Can a client repay or return a CERB payment to CRA directly?
             [Can a client repay or return a CERB payment to CRA directly?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_a_client_repay)

- Can a client choose to repay or return a CERB payment to Service Canada?
             [Can a client choose to repay or return a CERB payment to Service Canada?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_a_client_choose)

- How can a client choose to repay or return an EI Emergency Response Benefit payment to Service Canada?
             [How can a client choose to repay or return an EI Emergency Response Benefit payment to Service Canada?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_How_can_a)

         [Overpayments and dual payments](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#op_dp)

- Postdates and antedates

- Can a claim for regular or sickness benefits be postdated to March 15, 2020 to be established as EI Emergency Response Benefit claim?
             [Can a claim for regular or sickness benefits be postdated to March 15, 2020 to be established as EI Emergency Response Benefit claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_a_claim)

- Can a client request to antedate their EI Emergency Response Benefit claim?
             [Can a client request to antedate their EI Emergency Response Benefit claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_a_client_request)

         [Postdates and antedates](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Postdates)

- Teachers

- Should the Teachers issue be adjudicated on EI Emergency Response Benefit claims?
             [Should the Teachers issue be adjudicated on EI Emergency Response Benefit claims?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Should_the_Teachers)

         [Teachers](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Teachers)

- Terminating an existing claim

- Can a client with a BPC before March 15, 2020, which could be renewed, ask for their claim to be terminated in order to receive the EI Emergency Response Benefit?
             [Can a client with a BPC before March 15, 2020, which could be renewed, ask for their claim to be terminated in order to receive the EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_a_client_bpc)

- Can a client request to terminate their EI Emergency Response Benefit claim in favour of special benefits?
             [Can a client request to terminate their EI Emergency Response Benefit claim in favour of special benefits?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_a_client1)

         [Terminating an existing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Terminating_an_existing)

- Training – Section 25 and Apprenticeships

- Can a client with a Section 25 referral receive payments from the EI Emergency Response Benefit?
             [Can a client with a Section 25 referral receive payments from the EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_a_client)

- How can the referring authority verify if the client is receiving payments from the EI Emergency Response Benefit?
             [How can the referring authority verify if the client is receiving payments from the EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_How_can_the)

- What happens when a client applies with a reference code for apprenticeship?
             [What happens when a client applies with a reference code for apprenticeship?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_What_happens_when)

- Are EI Emergency Response Benefit clients participating in referred (including apprenticeship) eligible for employment benefits under Part II of the EIA?
             [Are EI Emergency Response Benefit clients participating in referred (including apprenticeship) eligible for employment benefits under Part II of the EIA?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Are_clients_participating)

- Does financial assistance monies have an impact on EI Emergency Response Benefit claims?
             [Does financial assistance monies have an impact on EI Emergency Response Benefit claims?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Is_financial_assistance)

- Can project information be input on an EI Emergency Response Benefit claim?
             [Can project information be input on an EI Emergency Response Benefit claim?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_project_information)

- Can clients receiving EI Emergency Response Benefit who are a referred apprentice be exempted from completing their CR?
             [Can clients receiving EI Emergency Response Benefit who are a referred apprentice be exempted from completing their CR?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_clients_receiving)

         [Training – Section 25 and Apprenticeships](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Training_–_Section)

- Waiting period

- Can the WP be waived on a renewal claim if the WP has not been served?
             [Can the WP be waived on a renewal claim if the WP has not been served?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#_Can_the_WP)

         [Waiting period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#wp)

- Withdrawing an application for EI Emergency Response Benefit

- Can a client withdraw their application for EI Emergency Response Benefit?
             [Can a client withdraw their application for EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#Withdrawing_an_application_1)

         [Withdrawing an application for EI Emergency Response Benefit](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#Withdrawing_an_application)

- Work-sharing

- Can a client who is part of a work-sharing agreement collect EI Emergency Response Benefit?
             [Can a client who is part of a work-sharing agreement collect EI Emergency Response Benefit?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#work-sharing_1)

- Can an employer with a valid work-sharing agreement combine the work-sharing agreement with the Canada Emergency Wage Subsidy?
             [Can an employer with a valid work-sharing agreement combine the work-sharing agreement with the Canada Emergency Wage Subsidy?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#work-sharing_2)

- Does the employer need to obtain the exact amount of EI benefits each employee is receiving?
             [Does the employer need to obtain the exact amount of EI benefits each employee is receiving?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#work-sharing_3)

- Can an employer terminate the work-sharing agreement to receive the Canada Emergency Wage Subsidy?
             [Can an employer terminate the work-sharing agreement to receive the Canada Emergency Wage Subsidy?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#work-sharing_4)

         [Work-sharing](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/information_covid19_processing_information#work-sharing)

**EI Emergency Response Benefit – General information**

**How can agents identify if a claim is an EI Emergency Response Benefit claim?**

Once processed, these claims display 5 – Automation Utility – Canada Emergency Response Benefits or 6 – Reassessment Utility – Canada Emergency Response Benefits in the Supplementary Claim Information field in FTS.

**How do clients know if they should apply with Canada Revenue Agency or Service Canada?**

Clients must complete a questionnaire , the answers provided will direct clients to the service option that best fits their situation.
       [questionnaire](https://www.canada.ca/en/services/benefits/ei/cerb-application.html)

**Can a client with an EI Emergency Response Benefit claim request that their claim be established under normal EI rules and have a benefit rate higher than $500 per week?**

No. All regular or sickness claims with a BPC between March 15, 2020 and September 27, 2020 after are considered EI Emergency Response Benefit claims and the benefit rate cannot be changed.

**Will the EI Emergency Response Benefit count as regular weeks of EI entitlement?**

No. If clients still require EI benefits following 28-weeks payment of the EI Emergency Response Benefit, these 28 weeks will not impact the client’s regular entitlement weeks for EI benefits.

**What is the one-time payment of $2000 that clients will receive?**

Until June 22, 2020, clients who were eligible for the EI Emergency Response Benefit received an initial payment of $2 000 immediately upon the establishment of their claim. Following the initial $2000 payment, clients requesting the EI Emergency Response Benefit must continue to complete bi-weekly claimant’s reports to demonstrate their ongoing entitlement to the benefit. They will receive $1000 for each bi-weekly claimant’s report that they complete.

Due to the timing of the release of the initial $2000 payment, and depending on when claims were finalized, some clients may already have received their first payment, or even their first 2 payments for the EI Emergency Response Benefit. These clients will also receive the initial $2000 payment as an advance of weeks to be paid later on their claim. No client will receive more than 28 weeks of benefits.

The details of the $2000 initial payment appear on the ERB Details screen.

**Is the one-time payment of $2000 being paid on every EI Emergency Response Benefit claim?**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1083.dita) 

Before June 22, 2020, each Monday, the one-time payment of $2 000 was paid to clients who established an EI Emergency Response Benefit claim in the previous week. This payment was considered an advance payment of 4 weeks of entitlement to the EI Emergency Response Benefit.

The one-time payment is not paid on claims where the client has declared being pregnant or for clients who have received payments from CRA.

**How many weeks of the EI Emergency Response Benefit can the client request?**

28 weeks. Originally set at 16 weeks of entitlement, the Government of Canada announced on June 16, 2020 that the EI Emergency Response Benefit would be extended to 24 weeks. On August 20, 2020 the Government of Canada announced on that the EI Emergency Response Benefit would be extended to 28 weeks. However, the period in which clients can receive EI Emergency Response Benefit payments remains unchanged. Clients have until October 3, 2020 to collect all 28 weeks of benefits.

**EI Emergency Response Benefit – Processing claims**

**What should agents do with a draft SROC of claims that have been completed as an EI Emergency Response Benefit claim?**

Agents must save their drafted documents in order to preserve any preliminary fact-finding. Agents must add a client Note stating that the fact-finding was not completed due to the utility run.

**Will previously finalized BPNE claims with a BPC on or after March 15, 2020 be converted to EI Emergency Response Benefit?**

On April 29, 2020, a utility was run to establish EI Emergency Response Benefit claims for clients whose application was previously finalized BPNE 1 or BPNE 5 with a BPC on or after March 15, 2020.

If the claim was not picked-up by the utility or before establishing a BPNE claim, the agent should refer to COVID-19 and establishing BPNE claims as EI Emergency Response Benefit claims .
       [COVID-19 and establishing BPNE claims as EI Emergency Response Benefit claims](/en/site/dossier/updated_covid19_establishing_bpne_claim_as_eierbc_l1.shtml)

**Where does the agent find the tentative BPC on a skeleton claim?**

The tentative BPC information can be found on the 149-Initial Intake Data transaction in the Transaction History screen.

**For what reasons will the ACP utility not automate a skeleton claim as an EI Emergency Response Benefit claim?**

The ACP utility will not automate the claim if one of the following conditions apply:

- the tentative BPC on the 149-Initial Intake Data transaction is on or before March 1, 2020

- the client declared a last day work before June 21, 2019 in AppliWeb*

- the client answered yes to the question “Are you pregnant or giving birth within the next 17 weeks?”*

- the client provided a reference code including Work-Sharing*

- the client is a commuter, interstate or overseas*

- the client is a fisher*

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1084.dita) 

**Can agents rescind a disentitlement or a disqualification that is imposed on an EI Emergency Response Benefit claim?**

Yes. If the claim is an ERB claim the agent can rescind the following disentitlements if the disentitlement start date is on or after March 15, 2020:

- 1 – Not unemployed

- 2 – Minor attached, reason for separation illness (Not capable)

- 3 – Not available

- 10 – Dismissal - Misconduct proven

- 11 – Voluntary leaving - just cause not proven

- 12 – Inmate of penal institution

- 13 – Outside Canada

- 15 – Claim Procedure

- 23 – Teacher (Non teaching period)

- 33 – Incapacity proven but not otherwise available

- 35 -  Parental benefits, qualifying conditions not met

- 38 – Vacation in Canada

- 42 – Suspension of employment

- 43 – Leave of absence

Note:

For clients with 900-series SINs, agents must not rescind the D3 or D15 disentitlement until confirmation is obtained that the client has a valid work or study permit. Refer to Updated: COVID-19 and work permits for 900-series SIN — Procedures (Level 1 and Level 2) .
       [Updated: COVID-19 and work permits for 900-series SIN — Procedures (Level 1 and Level 2)](/en/site/dossier/updated_covid19_work_permit_900_sin.shtml)

The agent must create a ROD:

- Comments : [type Disentitlement or Disqualification] rescinded - EI – Emergency Response Benefit

- Details : [type Disentitlement or Disqualification] rescinded as it is deemed to be an EI – Emergency Response Benefit claim.

**Is there a specific window for a client to collect the EI Emergency Response Benefit?**

Yes. The specific window to collect the 28 weeks of the EI Emergency Response Benefit is from March 15, 2020 to October 3, 2020.  However, there is no requirement that clients receive all 28 weeks at once.  For example, if a client collects 10 weeks of the EI Emergency Response Benefit and then returns to work for 5 weeks, they could subsequently receive the remaining 14 weeks after that if still within the specific window.

**Should agent check the ERB Details screen to determine if the client is receiving CERB prior to establishing the EI Emergency Response Benefit claim?**

Yes. A client cannot receive benefits from CERB and from the EI Emergency Response Benefit at the same time. Before establishing the EI Emergency Response Benefit claim, the agent must check the ERB Details screen.  If the client has received CERB, the agent must contact the client to advise them to remain on CERB.

If the client is pregnant and is collecting CERB, the agent must advise the client to wait until she is ready to collect maternity benefits before applying.

The agent refers to COVID-19 and Emergency Response Benefit to determine what actions to take.
       [COVID-19 and Emergency Response Benefit](/en/site/dossier/information_covid19_emergency_response_benefits.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1085.dita) 

**Why is the 65 - Lump Sum Payment ($2000) - Canadian Emergency Response disentitlement (D65) imposed on EI Emergency Response Benefit claims?**

A D65 is imposed to account for the initial $2 000 advance payment.

Starting June 8, 2020, to avoid causing the client financial hardship, the D65 will be imposed for 2 weeks at a time. Weeks 13 and 14 are the first weeks that will be accounted for. Weeks 20 and 21 are the last two weeks that will be accounted for.

When an agent must determine if the second D65 is to be imposed, the following 2 conditions must be met:

- 17 weeks of EI Emergency Response Benefit must be paid

- The first D65 must have been served

When looking at the weeks paid counter, the agent will see 17 when the next set of D65 is imposed. However when explaining the D65 to the client, the agent must understand that the D65 is for week 20 and 21 (17 weeks paid + 2 weeks of D65).

**How will the D65 be communicated to clients?**

Communication to clients will include emails and telephone messages.

**Is the D65 imposed on claims where clients received money from the CRA?**

No. All D65 previously imposed on claims where the clients had received the initial $2000 payment from the CRA have been rescinded.

**Does the CERB (CRA) field gets updated when the client repays the money paid?**

No. At this time, even if the client repays the money paid by CRA, the CERB CRA field will not be updated with the new information. This is why the D65 is no longer impose on these claims.

**Are clients who where on maternity or parental leave immediately prior to the start of the pandemic, considered to have loss their employment due to COVID-19 if they cannot return to work?**

Yes.  Clients are considered to have stopped working for COVID-19 related reasons if they are unable to return to work due to COVID-19 following their maternity or parental leave.  These clients should apply to the CERB, however if the client has applied for the EI Emergency Response Benefit and they meet the eligibility criteria for CERB, the EI Emergency Response Benefit claim will be approved.

**After the last payment of EI Emergency Response Benefit**

**Do clients need to submit a new EI application or call Service Canada after receiving their 28 weeks of the EI Emergency Response Benefit?**

No. Clients should not submit a new EI application. Service Canada will use the application that was previously submitted to determine eligibility for a new EI claim. Service Canada will contact clients if additional information is required to process their EI claims.

**Do clients need to submit a new EI application or call Service Canada after receiving their 28 weeks of CERB?**

Yes. Clients need to apply for EI benefits so that their eligibility can be determined. It is important that clients do not apply for EI until they have reached the end of their 28 weeks of CERB payments. This will prevent duplicate payments and ensure that their EI claims are established from the correct date.

**Canada Emergency Student Benefit**

**What is the Canada Emergency Student Benefit?**

The Canada Emergency Student Benefit provides financial support to post-secondary students, and recent post-secondary and high school graduates who are unable to find work due to COVID-19.

This benefit is for students who do not qualify for the CERB or EI Emergency Response Benefit.

**How much can student receive?**

Eligible students can receive $1 250 for each 4-week period from May to August 2020.

If the student has a disability or dependants, they may get an extra $750.

**Can an EI Emergency Response Benefit claim be terminated if the client should have applied to the CESB instead?**

Yes. When the client indicates that they should not be receiving the EI Emergency Response Benefit but the CESB, the agent must determine if the client is eligible for the EI Emergency Response Benefit.  If yes, the agent explains to the client that they qualify and that they do not need to apply for the CESB.

If the client does not qualify for the EI Emergency Response Benefit, the agent tells the client to contact the CRA at 1-800-959-8281. A process is in place to confirm eligibility for the CESB and to establish the claim.  The agent does not have to take any action to cancel the claim, but can terminate the claim with a transaction M101-7 - Terminate benefit period .

**Canada Emergency Wage Subsidy**

**What is the Canada Emergency Wage Subsidy?**

The Canada Emergency Wage Subsidy (CEWS) is a wage subsidy program available for qualified employers to help pay their employees and avoid having to lay them off.
       [Canada Emergency Wage Subsidy (CEWS)](https://www.canada.ca/en/revenue-agency/services/subsidy/emergency-wage-subsidy.html)

**Should an employer include the CEWS when completing a Record of Employment?**

Yes. If the employee was previously employed in insurable employment, the CEWS should be included on the ROE with all other wages paid by the employer.

Hours associated to the amount of CEWS paid should also be included on the ROE.

If the first day paid or last day paid falls in a period where CEWS were paid, the employer should input that date.

When there is doubt about the insurability of the employment, an insurability ruling should be requested from the CRA.

**How should the employer attribute hours when the employees are paid their normal salary but they are not working?**

When the employer pays the client’s normal salary, the employer must report, on the ROE, all insurable hours and earnings in the same way as if the employee was at work full time.

**How should the employer attribute hours when the employees are paid an amount lower than their normal salary?**

In accordance with EIR 10.1, if the only change is the salary, the normal weekly hours would be reported.

For example, if an employer pays an employee 75% of their normal salary ($600 per week instead of $800), but their normal 40-hour per week work schedule remains unchanged, the employer puts $600 as insurable earnings and 40 as insurable hours.

**900-series SIN**

**Can clients with a 900-series SIN receive benefits if a valid work or study permit is not on file?**

Yes. Agents can temporarily accept verbal confirmation of a valid work permit, study permit or implied status so that benefits are not delayed. The client is advised that they must submit the proof  as soon as possible. This temporary measure to both an EI Emergency Response Benefit claim and an EI benefits claim.

The agent can refer to Updated: COVID-19 and work permits for 900-series SIN — Procedures (Level 1 and Level 2) .
       [Updated: COVID-19 and work permits for 900-series SIN — Procedures (Level 1 and Level 2)](/en/site/dossier/updated_covid19_work_permit_900_sin.shtml)

**What should agents do if they have an ASMT Insurability WI for a client with a 900-series SIN?**

Insurability of employment for clients with 900-series SINs is not an issue for EI Emergency Response Benefit claims as these claims are not established based on insurable employment. However, for EI claims, regular procedures must be applied.

**Can clients with a 900-SIN be considered available for work if they are not working due to COVID-19?**

Yes. Although the purpose for being in Canada is to work, the Government of Canada understands that it can be difficult for clients to look for a job during a pandemic.

No disentitlement must be imposed if the client is having trouble finding a job or if the work permit has restrictions.

**Availability**

**Are clients expected to actively look for a job during the COVID-19 pandemic?**

The Government of Canada understands that it can be difficult for clients to look for a job during a pandemic.

When the client cannot look for work or find a job because of COVID-19, no disentitlement must be imposed for this reason on EI Emergency Response Benefit and on a regular or sickness claim with a BPC prior to March 15, 2020.

**Can clients who states experiencing childcare issue due to COVID-19 be considered available?**

Yes. The Government of Canada understands that it is essential for parents to take care of their children who cannot go to school or daycare because of the COVID-19 pandemic.

No disentitlement must be imposed for this reason on EI Emergency Response Benefit and on a regular or sickness claim with a BPC prior to March 15, 2020.

**Is training considered a contentious issue on EI Emergency Response Benefit claims?**

No. As schools are closed due to the COVID-19 pandemic, training is not considered as a contentious issue.

No disentitlement must be imposed for this reason on EI Emergency Response Benefit and on a regular or sickness claim with a BPC prior to March 15, 2020.

**Can an agent terminate a 3-Not available (D03) disentitlement on a claim with a BPC prior to March 15, 2020, if the client’s training stopped due to COVID-19?**

Yes. A client cannot be denied benefits on the sole fact that they were attending training if the training has stopped for an indeterminate period due to the pandemic. The 3-Not available (D03) disentitlement can be terminated effective the last day of training.

**Claimant's report**

**Do clients with an EI Emergency Response Benefit claim have to complete claimant’s reports?**

Yes. Clients must file their claimant’s report every two weeks as usual.

Since many clients are applying for EI for the first time, they may not be aware they are required to complete CR. Emails are being sent to remind them that completing reports is necessary to continue being paid. These emails are being sent to clients who provided an email address in their application. Calls are also being made by agents who are responsible to complete CR when the client is contacted.

**How does the system process the information declared on the claimant’s report?**

If a client declares earnings, not available days, training or sick days, the system does not consider the information when determining if clients are entitled to EI Emergency Response Benefits payments.

If a client declares to have found work or worked a full week, the system does consider the information when determining if clients are entitled to EI Emergency Response Benefit payments.

**How long do clients have to complete their claimant’s report?**

EI clients are usually given 5 weeks to complete their claimant’s report For EI Emergency Response Benefit claims clients have 12 weeks to complete their claimant’s report.

Original claimant’s reports for the EI ERB period cannot be accepted after December 2, 2020.

**What actions must be taken when a client reports a mistake made on a claimant’s report for an EI Emergency Response Benefit claim?**

When clients report having made a mistake when completing their claimant’s report, the following action should be taken:

- Refer to Modifying a claimant’s report — EI ERB .
         [Modifying a claimant’s report — EI ERB](/en/procedure/task/modifying_claimant_report_eierb.shtml)

**What clients should be answering on the CR when they have been recalled to work but are unable to return?**

When clients complete their CR, they are asked if they were ready, willing and capable of working each day, Monday through Friday, during each week of the report. The client must answer No if they are unable to return to work when recalled by their employer because they are:

- in quarantine or sick due to COVID-19

- taking care of others because they are in quarantine or sick due to COVID-19

- taking care of children or other dependents because their care facility is closed due to COVID-19

They will still remain entitled to the EI Emergency Response Benefit.

**Earnings**

**Does allocation of earnings have an impact on EI Emergency Response Benefit claims?**

No. Allocation of all earnings has no impact on an EI Emergency Response Benefit claim.

If the client contacts Service Canada to enquire about an allocation that is still on their claim, the agent can rescind the allocation and all applicable BP extension if the claim is considered as an EI Emergency Response Benefit claim.

Although earnings are not allocated, clients whose income exceeds $1 000 in the 4 weeks for which the EI ERB is paid are not eligible for benefits in that period.

**Should allocation letters be sent to client receiving the EI Emergency Response Benefit?**

No. Allocation of all earnings has no impact on an EI Emergency Response Benefit claim and a letter should not be send.

**Family supplement**

**Is a client with an EI Emergency Response Benefit claim eligible for family supplement?**

Yes. If they are eligible, clients will receive family supplement in addition to the $500 per week.

**Does the family supplement apply to the initial $2000 payment?**

No. The initial $2000 payment was a flat amount that was paid to ensure that, regardless of whether Canadians applied for assistance through the CRA or Service Canada, their initial payment would be the same. The family supplement rate applies only to EI Emergency Response Benefit payments made when the client does their CR.

**Income taxes and T4**

**Can a client request that income taxes be deducted on EI Emergency Response Benefit payments?**

No. The Government of Canada had decided that no tax will be with-held on EI Emergency Response Benefit payments.

**Will clients receive a T4 slip if they have received a CERB payment?**

Yes. Since a CERB payment is taxable, clients can expect to receive a T4 on the amount of CERB received.

In order to ensure that T4 slips are not issued improperly, clients are encouraged to repay CERB overpayments before December 31, 2020. If the client needs more time to repay based on their personal situation, they must contact the CRA as soon as possible to make payment arrangements.

**Are income taxes deducted from EI Emergency Response Benefit payments?**

No. The EI Emergency Response Benefit payment is taxable but no taxes are deducted from the payment. However, income taxes are deducted when the claim is initially established as an EI claim. When the system converts the claim to an EI Emergency Response Benefit claim, the taxes deducted from the previously paid weeks is not paid back to the client.

**Maternity benefits and EI Emergency Response Benefit**

**How will EI Emergency Response Benefit payments affect clients requesting maternity benefits after the EI Emergency Response Benefit period?**

Clients receiving the EI Emergency Response Benefit can switch to maternity benefits when appropriate to their situation as long as they meet the eligibility criteria for those benefits. There is no requirement to claim the EI Emergency Response Benefit for the entire 28 weeks.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1086.dita) 

**Do EI Emergency Response Benefit payments affect the weeks of entitlement to maternity or parental benefits?**

No. EI Emergency Response Benefit payments do not affect the weeks of entitlement to maternity or parental benefits.

EI maternity and parental benefit claims continue to be processed as usual, whether they were established before or after March 15, 2020. The eligibility criteria including the hours of work needed to qualify remain unchanged.

**Can a Confinement week or Arrival placement week be input on an EI Emergency Response Benefit claim?**

No. The agent will get the error message C173: Invalid Recalculation when inputting a confinement week (CNF WK) or Arrival placement week (APW). The agent takes the following measures:

- If the CNF WK or APW is after the period the client can collect the EI Emergency Response Benefit, the agent must create a REM WI. The Due date is the week before the CNF WK or the APW.

- If the CNF WK or APW is within the period the client can collect the EI Emergency Response Benefit, the agent refers to COVID-19 – Converting EI Emergency Response Benefit claims to maternity benefits .
         [COVID-19 – Converting EI Emergency Response Benefit claims to maternity benefits](/en/procedure/task/covid19_converting_eierbcmb.shtml)

**Is there a specialized team handling the processing of maternity claims after the client collect EI Emergency Response Benefit?**

Yes. A specialized team in the Western region does claims conversion. When a claim must be converted to maternity benefits, the agent does not complete the WI and does not convert the claim.  The agent reassigns the file as follows:

- If there is a draft SROC, the WI is reassigned to the agent directly.

- If there is no draft SROC, the WI is reassigned as follows:

- Destination – Level:

- Natl Processing & Payment Svcs

- Specialized EI Processing – WT

- New Legislation – WT

- NERE – WT

- Complexity: Level 1

- Reason: Other

- Details: Type “Conversion EI ERB to maternity benefits.”

**Is the QP extended for clients requesting maternity benefits after collecting the EI Emergency Response Benefit?**

Yes. To account for the EI ERB or CERB period, the QP is extended:

- by 16 weeks if the BPC for the new initial claim is before July 5, 2020.

- by 24 weeks if the BPC for the new initial claim is between July 5, 2020 and August 23 2020.

- by 28 weeks if the BPC for the new initial claim is on or after August 30, 2020.

**Out of Canada**

**Should a disentitlement be imposed for Out of Canada on EI Emergency Response Benefit claims?**

No. Clients who are resident of Canada may be temporary unable to return to Canada due to COVID-19.

If clients with an EI Emergency Response Benefit claim are in this situation, the information must be recorded on file but no disentitlements should be imposed.

**Overpayments and dual payments**

**Will clients have to repay the overpayment that was created when their claim was recalculated as an EI Emergency Response Benefit claim (e.g. benefit rate was $573 and is now $500)?**

No. The overpayments (OP) created on claims when the benefit rate was initially higher than $500 are written off. The OP is still displayed in FTS but there is no recoverable balance for it.

**Under what circumstances can a client be asked to repay payments received from CRA for CERB?**

Clients may need to return or repay a CERB payment if they:

- return to work earlier than expected, including being paid retroactively

- applied for CERB but later realize they were not eligible

- received both CERB and EI Emergency Response Benefit payments for the same period

**Can a client repay or return a CERB payment to CRA directly?**

Yes. A client can return or repay a CERB payment to the CRA. Instructions on how to proceed can be found here .
       [here](https://www.canada.ca/en/revenue-agency/services/benefits/apply-for-cerb-with-cra.html)

**Can a client choose to repay or return a CERB payment to Service Canada?**

Yes. A client who chooses to repay a CERB payment to Service Canada must do the following:

- If the client still has the cheque, they can return the cheque by mail to:
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1087.dita)

- If the client was paid by direct deposit or has deposited the cheque, they can pay their account using any of the two methods as outlined below:

- At their financial institution

Clients must not send cash through the mail.

**How can a client choose to repay or return an EI Emergency Response Benefit payment to Service Canada?**

If the client still has the original check, they can return it by mail to the address below.

If the client does not have the check, has deposited the check or has received the money via direct deposit, they can pay their account using any of the three following methods:

- Online Banking

- The client must select "Employment and Social Development Canada" if available through their financial institution's website.

- The client must enter their 9 digit Social Insurance Number (SIN). If their financial institution requires 11 characters, the client must add the letters “YY” or the numbers “00” to the end of their SIN.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1088.dita)

- At their financial institution

- The client must write their (SIN) on the check or money order and indicate it is for “Repayment of CERB”

- By mail

- The client must send their payment by check or money order made out to “Receiver General of Canada”, write their SIN and mail it to the following address below:
             [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1089.dita)

**Postdates and antedates**

**Can a claim for regular or sickness benefits be postdated to March 15, 2020 to be established as EI Emergency Response Benefit claim?**

Only a claim for regular or sickness benefits with a tentative BPC of March 8, 2020 can be postdated to March 15, 2020.

Postdates on already established claims for regular and sickness benefits are not permitted for the sole purpose of receiving the EI Emergency Response Benefit. While the existing postdate policy continues to apply, an exception will be made to allow a postdate from BPC of March 8, 2020 to BPC of March 15, 2020. The client must request the postdate.

**Can a client request to antedate their EI Emergency Response Benefit claim?**

Yes. EI Emergency Response Benefit claims can start as early as March 15, 2020 and clients can apply for the EI Emergency Response Benefit until December 2, 2020.

There is no requirement that clients applying for the EI Emergency Response Benefit file in a timely manner therefore antedate requests are not applicable for the EI Emergency Response Benefit.

**Teachers**

**Should the Teachers issue be adjudicated on EI Emergency Response Benefit claims?**

No. Teaching is not considered a contentious issue for an EI Emergency Response Benefit claim.

However, the Teaching issue must be adjudicated for clients who want to receive maternity, parental, family caregiver, CCB, work-sharing or fishing benefits and clients who renew their EI benefits claim after March 15, 2020.

**Terminating an existing claim**

**Can a client with a BPC before March 15, 2020, which could be renewed, ask for their claim to be terminated in order to receive the EI Emergency Response Benefit?**

Yes. As per usual procedures, when assessing a renewal, it might be to the client’s advantage to establish a new benefit period (BP) instead of renewing the existing BP. In all cases, if the client is requesting their claim be terminated to receive the EI Emergency Response Benefit, advantages and disadvantages must be discussed with the client, as the decision to terminate the BP is final, and cannot be reversed.

More specifically, there is a possibility that the client may not have enough hours to establish a new BPC after the 28-week of EI Emergency Response Benefit are paid out. The client must understand that the decision to terminate the claim is NOT reversible and if the client will not be able to change their mind if the client does not have enough hours to qualify for the new claim. If following that discussion, the client decides to terminate their existing EI claim in favour of starting a new claim for EI Emergency Response Benefit, they can, provided they meet the eligibility criteria as outlined in the EI Emergency Response Benefit — BE 2020-04 (BE Memo) .
       [EI Emergency Response Benefit — BE 2020-04 (BE Memo)](/en/policy/bememo/be2020-04.shtml)

**Can a client request to terminate their EI Emergency Response Benefit claim in favour of special benefits?**

No. At this time, an EI Emergency Response Benefit claim cannot be terminated other than for maternity benefits.

The agent documents the file, pends the WI until August 28, 2020. If the information on how to convert the file is not provided on August 28, 2020, the agent pends the WI for another 5 days.

**Training – Section 25 and Apprenticeships**

**Can a client with a Section 25 referral receive payments from the EI Emergency Response Benefit?**

Yes. There is no stipulation in the Interim Orders that prevents clients who attend referred training or are an apprentice to receive payments from the EI Emergency Response Benefit.

**How can the referring authority verify if the client is receiving payments from the EI Emergency Response Benefit?**

The LMDAAccess Module does not distinguish an EI Emergency Response Benefit claim from an EI benefits claim. However, since EI Emergency Response Benefit claims contain the same characteristics, they can be identified as follows:

- Benefit Period Commencement : between March 15, 2020 and September 27, 2020

- Claim Type : Regular

- Number of Weeks Eligible : 29

- EI Benefit Rate : $500 (greater for clients entitled to the family supplement)

**What happens when a client applies with a reference code for apprenticeship?**

All regular or sickness claims filed with an apprenticeship reference code with a BPC between March 15, 2020 and September 27, 2020 are converted to EI Emergency Response Benefit. The project information is coded on the project tab in FTS.

**Are EI Emergency Response Benefit clients participating in referred training (including apprenticeship) eligible for employment benefits under Part II of the EI Act?**

No. The process of obtaining the approvals for these clients to be eligible for support under Part II of the EI Act is currently under way but at this time they are not considered as being eligible. More information on this matter will be shared once it is received.

**Does financial assistance monies have an impact on EI Emergency Response Benefit claims?**

No. Any financial assistance to support basic living expenses, child-care or transportation costs are not considered earnings for clients who are receiving EI Emergency Response Benefit. Earnings from employment received as part of a program funded under the labour market transfer agreements are considered earnings for the purposes of EI Emergency Response Benefit.

**Can project information be input on an EI Emergency Response Benefit claim?**

Yes. When confirmation is received that the client is participating in referred training or is an apprentice, the project information must be input in FTS.

The agent refers to Confirming referred training: Regular or fishing benefits — Continuing claim or to Confirming apprenticeship training — Continuing claim for details on how to input the project information.
       [Confirming referred training: Regular or fishing benefits — Continuing claim](/en/procedure/task/training_cc.shtml) 
       [Confirming apprenticeship training — Continuing claim](/en/procedure/task/training_rcc.shtml)

**Can clients receiving EI Emergency Response Benefit who are a referred apprentice be exempted from completing their CR?**

Yes. Referred apprentice receiving payments from the EI Emergency Response Benefit can request to be exempted from completing CR provided they agreed to the Apprentice Exemption Declaration.

**Waiting Period**

**Can the WP be waived on a renewal claim if the WP has not been served?**

Yes. If the WP has not been served and the client is now renewing the claim for sickness benefits, the WP can be waived if the renewal week is on or after March 15, 2020.

**Withdrawing an application for EI Emergency Response Benefit**

**Can a client withdraw their application for EI Emergency Response Benefit?**

Yes. If a BP has not yet been established, an application can be withdrawn. When an application is withdrawn, the agent cancels the application and the system deletes all outstanding WIs associated with the application.

**Work-sharing**

**Can a client who is part of a work-sharing agreement collect EI Emergency Response Benefit?**

No. A client with a work-sharing claim cannot collect EI Emergency Response Benefit.

**Can an employer with a valid work-sharing agreement combine the work-sharing agreement with the Canada Emergency Wage Subsidy?**

Yes. An employer can combine the Canada Emergency Wage Subsidy (CEWS) with a work-sharing agreement, but having the work-sharing agreement will lower the subsidy that the employer will receive as part of the CEWS.

**To claim the Canada Emergency Wage Subsidy, does the employer need to obtain the exact amount of EI benefits each employee is receiving?**

Yes. However, in order to protect the client’s personal information, Service Canada cannot share with an employer the amount of EI benefits paid to employees. The employer will need to contact each employee directly to receive the information.

**Can an employer terminate the work-sharing agreement to receive the Canada Emergency Wage Subsidy?**

Yes. The employer can terminate the work-sharing agreement at any time. After accessing the CEWS, they can submit a new work-sharing agreement. 

### Warning

Source topic: `en_EN/common_notes/note_c_1082.dita`

Updated: 2020-12-03 — New information is highlighted. 

### Note

Source topic: `en_EN/common_notes/note_c_1083.dita`

Note:

As of Monday June 22, 2020 the $2 000 advance lump sum payment has stopped. New clients applying for the EI Emergency Response Benefit will receive benefits when they complete their claimant’s reports. No D65 will be imposed on these claims. 

### Note

Source topic: `en_EN/common_notes/note_c_1084.dita`

Note:

Clients who are fishers, commuter, interstate or overseas, have a last day prior to June 21, 2019, have provided a reference code other than for Work-Sharing (WS) or are pregnant may still qualify for the EI Emergency Response Benefit. The agent must determine if the client qualifies for the EI Emergency Response Benefit. 

### Note

Source topic: `en_EN/common_notes/note_c_1085.dita`

Note:

If the client cannot be reached, the agent should not establish the EI Emergency Response Benefit claim. 

### Note

Source topic: `en_EN/common_notes/note_c_1086.dita`

Note:

At this time, only client requesting maternity benefits can terminated their EI Emergency Response Benefit claim. The agent refers to COVID-19 – Converting EI Emergency Response Benefit claims to maternity benefits for details on how to convert the claim.
       [COVID-19 – Converting EI Emergency Response Benefit claims to maternity benefits](/en/procedure/task/covid19_converting_eierbcmb.shtml)

     [COVID-19 – Converting EI Emergency Response Benefit claims to maternity benefits](/en/procedure/task/covid19_converting_eierbcmb.shtml) 

### Callout

Source topic: `en_EN/common_notes/note_c_1087.dita`

ESDC Remittances

PO Box 1122

Matane QC G4W 4S7 

### Note

Source topic: `en_EN/common_notes/note_c_1088.dita`

Note:

Given that each financial institution is different, the client should use their SIN with the letters “YY” after, if this is not accepted by the system, the client can input their SIN and the numbers “00”. 

### Callout

Source topic: `en_EN/common_notes/note_c_1089.dita`

Mailing address

ESDC Remittances

PO Box 1122

Matane QC G4W 4S7 

## Summary of changes

Source topic: `en_EN/site/dossier/information_covid19_processing_information/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
