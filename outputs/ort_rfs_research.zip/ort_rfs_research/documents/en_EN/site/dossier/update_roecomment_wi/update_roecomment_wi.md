# ROE Comments WI—Regular ROE procedure update and new job aid

Source map: `en_EN/site/dossier/update_roecomment_wi/update_roecomment_wi.ditamap`

## Summary

Source topic: `en_EN/site/dossier/update_roecomment_wi/summary.dita`

The procedure for completing an ROE Comments WI — Regular ROE has been updated to address the system changes following the emergency release on December 15, 2015. The job aid for actioning comments in block 18 of a regular ROE has been updated, renamed and added to the Job Aids page. 

## Generic

Source topic: `en_EN/site/dossier/update_roecomment_wi/generic.dita`

The job aid used to determine if the comments on the ROE can be actioned or removed from block 18 has been modified. There are now 2 sections for comments related to a reason for separation (RFS), depending on whether there is an outstanding ROE Issue (ROE) RFS Action WI for the same ROE.

The new job aid is called Comments in block 18 of a regular ROE .
       [Comments in block 18 of a regular ROE](/en/procedure/generic/table_block18.shtml)

When there is an ROE Comments WI and an outstanding ROE RFS Action WI for the same ROE (always the last ROE), the agent must not modify block 16 in RCM unless directed otherwise by the job aid. If required, the details related to the RFS are modified in NWS within the ROE RFS Action WI.

The Level 1 procedures have been corrected to ensure that a finalized claim is recalculated if the comments on the ROE affect the calculation or entitlement. Additionally, if the Level 1 agent changes the RFS from a non-contentious to a contentious issue and the claim status is In Progress (Manual) or the claim has been established, the agent must ensure that the new RFS is adjudicated. 

## Summary of changes

Source topic: `en_EN/site/dossier/update_roecomment_wi/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
