# Information: Interim measures for clients affected by the 2025 postal services disruption

Source map: `en_EN/site/dossier/ren-mes-pro-cli-pert-serv-post-info-int_8afb18dc/ren-mes-pro-cli-pert-serv-post-info-int_8afb18dc.ditamap`

## Summary

Source topic: `en_EN/site/dossier/ren-mes-pro-cli-pert-serv-post-info-int_8afb18dc/summary.dita`

Temporary measures are implemented to help clients during the postal services disruption. 

## Generic

Source topic: `en_EN/site/dossier/ren-mes-pro-cli-pert-serv-post-info-int_8afb18dc/generic.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1175.dita) 

**Impacts of the postal services disruption**

The postal services disruption affects the daily mailing of:

- benefit statements;

- benefit payment cheques;

- paper claimant’s reports;

- notices of debt;

- ACS letters;

- access codes;

- questionnaires, forms and any other requests for information.

Similarly, receiving correspondence from clients may be delayed.

Officers must encourage clients to sign up for direct deposit to avoid delayed payments. Payment by direct deposit is not impacted by the postal services disruption.
       [direct deposit](/en/procedure/activity/direct_deposit.shtml)

The following interim measures have been put in place to help clients during the postal services disruption.

**Interim measures**

Access code: During the postal services disruption, the normal timeframe for mailing a temporary access code is waived. The officer refers to Issuing an access code and immediately issues a temporary access code to clients who have not received their access code by mail.
       [Issuing an access code](/en/procedure/task/replacing_ac.shtml)

ACS letters: ACS letters cannot be mailed until the postal services disruption ends. The officer still creates and prints all required ACS letters. Automated letters are held at the print site until the postal services disruption has ended. When a call is required to communicate a decision, the officer informs the client of the delay in mailing the letter.

Urgent requests for information: When a client indicates an urgent need for a letter and the call centre cannot process the request, the officer creates an Action Item (AI) WI and sends it to a processing centre. The officer creates and sends the F-00-00-00 letter and contacts the client to advise them to visit a Service Canada Centre (SCC), if possible, to request a reprint as the letter will not be sent until the postal services disruption has ended.

Overpayments (OPs): The officer does not implement any decision on misrepresentation during the postal services disruption. The officer moves the WI to Pending until the postal services disruption ends.

Fact-finding: When the client, employer or third party does not have a telephone number with a voicemail or an email, the officer moves the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Postal services disruption.”

- Bring forward date: Enter today’s date + 3 business days.

If necessary, the officer repeats moving the WI to Pending until the end of the postal services disruption.

At the end of the postal services disruption, if the client is not reached during fact-finding or has not communicated with the officer, the officer creates and sends the N-10-00-00 letter. Then, the officer moves the WI to Pending for 10 business days before proceeding with the usual procedures.

When the postal services disruption has ended, when fact-finding with an employer or third party, the officer creates and sends the Z-00-00-00 letter. Then, the officer moves the WI to Pending for 10 business days before proceeding with the usual procedures.

There is no change to fact-finding when the officer has left a voicemail message or sent an email.

ROE verification: When the officer cannot leave a voicemail message for the employer, or when the employer does not reply to the voicemail, the officer obtains the information from other sources (e.g. the client) and corrects the ROE, or estimates the missing information required to correct the ROE.

The officer creates and sends the Z-02-00-00 letter based on the claim information, and selects all the required attributes, including the following:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805):

- Multiple Changes to ROE or

- A Single Change to ROE

- List of the change

- Attached INS 3413

The officer also creates and sends the N-06-00-00 letter based on the claim information and selects all the required attributes, including the following:

- Various reasons - No ROE - Claim Approved / Claim not established (2699)

- Claim approved -Unverified / Interim ROE(s)

- Unverified ROE / unverified ROEs / Interim ROE / Interim ROEs (2502): Select Unverified ROE or unverified ROE(s) , depending on the case.

- Receive ROE(s)/Receive additional info about ROE(s) (2503): Select Receive additional info about ROE(s) .

If there is a related ROE Correction WI, the officer completes it. If there is no related ROE Correction WI, the officer follows the appropriate task for calculating a claim. The officer does not refer the file to Integrity for non-compliance.

Interim ROE: When an ROE is missing because it has not been received by mail, the officer creates an interim ROE.

The officer disregards the steps for sending a letter to the employer when conducting fact-finding with the employer.

Sending the reconsideration file following a negative decision under EIA 112: When verbally communicating a fully or partially negative decision resulting from a reconsideration under EIA 112, the officer promotes the use of Connect as the preferred method for sending the reconsideration file during the postal services disruption, as Connect is not impacted by this disruption.

If the client refuses to use Connect , the officer informs the client that due to the postal services disruption, the reconsideration file will be mailed only when postal services resume. The officer ensures that the client understands the timeframe to submit an appeal to the Social Security Tribunal (SST) is 30 days regardless of whether the client receives the reconsideration file or not.

To assemble a reconsideration file and create a Reminder (REM) WI requesting that a Non-complex officer send it, the officer refers to Sending the reconsideration file to the client following a negative decision under EIA 112 — Instructions .
       [Sending the reconsideration file to the client following a negative decision under EIA 112 — Instructions](/en/procedure/generic/additionalresources/env-doss-rev-cli-suit-dec-def-112-send-rec-file-clien-nd-112.shtml)

If the client states not wanting to receive the reconsideration file, the officer:

- documents the information as required;

- does not assemble the reconsideration file;

- does not create a REM WI.

During the postal services disruption, the Non-complex officer completes the REM WI related to sending the reconsideration file electronically. If the client wishes that the reconsideration file be mailed when postal services resume, the officer moves the related REM WI to Pending . When postal services resume, the Non-complex officer determines if the client submitted an appeal to the SST:

- If yes, the Non-complex officer completes the REM WI and no further action is required.

- If no, the Non-complex officer prints the reconsideration file and mails it to the client.

**Payment by cheque**

Cheques created before the postal services disruption were mailed as usual and are delayed in the mail system until postal services resume.

Cheques that would normally be created during the postal services disruption will not be created until the postal services disruption ends.

At the end of each month, Canada Post will deliver cheques to remote communities that are not served by Purolator. Canada Post locations that have post office boxes will be open so that clients can pick up cheques that were sent in this monthly delivery. If clients are identified as eligible for this service, an officer from a specialized team creates an SROC to document the information on the claim.

If clients who live in a remote area and are unable to receive payment by direct deposit contact Service Canada to ask about their cheques during the postal services disruption, the officer informs the clients that their cheques will be delivered by Canada Post on a monthly basis.The first delivery is scheduled for November. The date is not yet determined.

**Payment replacement by direct deposit**

When clients provide banking information, future payments are deposited into the bank account. When the client provides banking information and there is an outstanding cheque that was mailed before the postal services disruption or a cheque that is being held from creation until the postal services disruption ends, the officer refers to Processing a warrant replacement request submitted by a client to replace the cheque with a direct deposit payment. The officer informs the client that any original cheque must be returned to Service Canada when it is received.
       [Processing a warrant replacement request submitted by a client](/en/procedure/task/processing_warrant_replacement_request_client.shtml)

**Dire need situations for clients without direct deposit**

When the client is in a dire needs situation and the cheque cannot be replaced by a direct deposit payment, the officer does the following:

For clients in communities served by Purolator: If necessary, the officer confirms that the client has verified the mail and that no cheque was delivered.

During the postal services disruption, the usual timeframe to receive a cheque as indicated in SPS (warrant issue date + 8 business days) is waived. The officer refers to Processing a warrant replacement request submitted by a client . When completing the Payment: INS5207 Missing warrant replacement — Form , the officer confirms the client’s residential address. The officer informs the client that the cheque will be delivered to the home address within the next 10 business days.
       [Processing a warrant replacement request submitted by a client](/en/procedure/task/processing_warrant_replacement_request_client.shtml) 
       [Payment: INS5207 Missing warrant replacement — Form](http://forms-formulaires.prv/lc/apps/EForms/pdf/en/ESDC-INS5207.pdf)

For clients in communities not served by Purolator: On a monthly basis, Canada Post will deliver cheques to clients who live in a remote area and receive their EI payments by cheque. The deliveries are targeted to reach communities in the third week of the month.

**Payment replacement — IPOC**

The IPOC officer assigned to the payment replacement request replaces the payment immediately, even if the 8-business day timeframe has not elapsed.

**Replacement by direct deposit**

- If the cheque was mailed before the postal services disruption and the client has provided banking information, the IPOC officer replaces the cheque with a direct deposit payment according to normal procedures.

- If the cheque was produced and sent during the postal services disruption, the IPOC officer intercepts and returns the cheque in SPS. Another IPOC officer replaces the cheque with a direct deposit payment.

**Replacement by cheque**

- If the cheque was mailed before the postal services disruption, the IPOC officer completes the Courier Request form to request a new cheque be delivered to the client by courier.
         [Courier Request](https://014gc.sharepoint.com/sites/PR6508883/_layouts/15/listforms.aspx?cid=MDk4NWQxZWUtNTVmOS00Mzk3LWJkNWItZDcwMWVmODI5MTdi&nav=NjBmMzMxMTEtYWYxYS00MmE4LWE3MWQtY2ZjZGE2YzI2MTQ0&xsdata=MDV8MDJ8a3Jpc3RhLmhvaWRnZUBzZXJ2aWNlY2FuYWRhLmdjLmNhfGMzZmJmOGQ5YTU5NDQxOWQ2YTg5MDhkZDk3OTI0N2FifDllZDU1ODQ2OGE4MTQyNDZhY2Q4YjFhMDFhYmZjMGQxfDB8MHw2Mzg4MzMzNzY2OTQ1OTkxMDR8VW5rbm93bnxUV0ZwYkdac2IzZDhleUpGYlhCMGVVMWhjR2tpT25SeWRXVXNJbFlpT2lJd0xqQXVNREF3TUNJc0lsQWlPaUpYYVc0ek1pSXNJa0ZPSWpvaVRXRnBiQ0lzSWxkVUlqb3lmUT09fDB8fHw%3d&sdata=emZ3ZlFUT3VNaDhtdXB0aUQ1bDlDeFlZUzljTEhYeXVUOUNMclBiQU5jND0%3d&clickparams=eyAiWC1BcHBOYW1lIiA6ICJNaWNyb3NvZnQgT3V0bG9vayIsICJYLUFwcFZlcnNpb24iIDogIjE2LjAuMTg2MjMuMjAyNjYiLCAiT1MiIDogIldpbmRvd3MiIH0%3D)

- If the cheque was created and mailed during the postal services disruption, the IPOC officer intercepts and returns the cheque in SPS, then completes the Courier Request form to request a new cheque be delivered to the client by courier.
         [Courier Request](https://014gc.sharepoint.com/sites/PR6508883/_layouts/15/listforms.aspx?cid=MDk4NWQxZWUtNTVmOS00Mzk3LWJkNWItZDcwMWVmODI5MTdi&nav=NjBmMzMxMTEtYWYxYS00MmE4LWE3MWQtY2ZjZGE2YzI2MTQ0&xsdata=MDV8MDJ8a3Jpc3RhLmhvaWRnZUBzZXJ2aWNlY2FuYWRhLmdjLmNhfGMzZmJmOGQ5YTU5NDQxOWQ2YTg5MDhkZDk3OTI0N2FifDllZDU1ODQ2OGE4MTQyNDZhY2Q4YjFhMDFhYmZjMGQxfDB8MHw2Mzg4MzMzNzY2OTQ1OTkxMDR8VW5rbm93bnxUV0ZwYkdac2IzZDhleUpGYlhCMGVVMWhjR2tpT25SeWRXVXNJbFlpT2lJd0xqQXVNREF3TUNJc0lsQWlPaUpYYVc0ek1pSXNJa0ZPSWpvaVRXRnBiQ0lzSWxkVUlqb3lmUT09fDB8fHw%3d&sdata=emZ3ZlFUT3VNaDhtdXB0aUQ1bDlDeFlZUzljTEhYeXVUOUNMclBiQU5jND0%3d&clickparams=eyAiWC1BcHBOYW1lIiA6ICJNaWNyb3NvZnQgT3V0bG9vayIsICJYLUFwcFZlcnNpb24iIDogIjE2LjAuMTg2MjMuMjAyNjYiLCAiT1MiIDogIldpbmRvd3MiIH0%3D) 

### Note

Source topic: `en_EN/common_notes/note_c_1175.dita`

Note:

As these changes are temporary, related procedures in the EI ORT have not been updated. The instructions below replace any related guidance in the EI ORT procedures for the duration of the postal services disruption. To obtain information on the labour dispute, the officer refers to Major Employer Events .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1739306425834)

     [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1739306425834) 

## Summary of changes

Source topic: `en_EN/site/dossier/ren-mes-pro-cli-pert-serv-post-info-int_8afb18dc/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
