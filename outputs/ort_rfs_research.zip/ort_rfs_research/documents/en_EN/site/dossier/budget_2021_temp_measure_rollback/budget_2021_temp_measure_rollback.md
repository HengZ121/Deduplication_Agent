# Information: Budget 2021 — Temporary measures rollback

Source map: `en_EN/site/dossier/budget_2021_temp_measure_rollback/budget_2021_temp_measure_rollback.ditamap`

## Summary

Source topic: `en_EN/site/dossier/budget_2021_temp_measure_rollback/summary.dita`

The temporary legislative measures that were introduced in Budget 2021 will end on September 24, 2022. 

## Generic

Source topic: `en_EN/site/dossier/budget_2021_temp_measure_rollback/generic.dita`

The end of the temporary measures that were introduced in Budget 2021 will mark a return to several processes and procedures in place before the COVID-19 pandemic.

For claims with BPC of w/c 2362 or after:

- The client must meet the following entrance requirements in the qualifying period (QP) for the requested benefit type (BT):

- For regular benefits, a variable entrance requirement (VER) of between 420 and 700 hours of insurable employment based on the regional rate of unemployment (RRU).
             [variable entrance requirement](/en/procedure/generic/additionalresources/ver_reg_ben.shtml)

- For special benefits, a minimum of 600 hours of insurable employment or $3 760 of insurable earnings from fishing.

- For fishing benefits, a VER of between $2 500 and $4 200 of insurable earnings from fishing based on the RRU.

- For special benefits for the self-employed, a minimum of $8 092 in net self-employment (SE) earnings in 2021 (the minimum SE earnings amount changes yearly at the beginning of January).
             [net self-employment (SE) earnings](/en/procedure/task/all_se_earnings.shtml#calculating_net_income68)

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0984.dita)

- The previous rules for adjudicating reason for separation (RFS) issues will apply:

- All contentious RFS issues in the QP will be adjudicated to determine if the insurable hours and earnings should be included or excluded from the claim calculation, or if a disqualification should be imposed.

- All the previous rules for deferring adjudication will again be in effect.

- All contentious RFS issues in the benefit period (BP) will continue to require adjudication.

Additionally, as of September 25, 2022, separation monies will be allocated on claims and deducted from benefits.

Procedures, training resources and systems will be updated accordingly. 

### Note

Source topic: `en_EN/common_notes/note_c_0984.dita`

Note:

When a violation is on file, increased entrance requirements apply. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/budget_2021_temp_measure_rollback/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
