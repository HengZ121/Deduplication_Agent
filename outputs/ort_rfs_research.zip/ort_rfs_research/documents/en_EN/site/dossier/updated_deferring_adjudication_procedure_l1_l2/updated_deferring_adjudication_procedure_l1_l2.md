# Updated: Deferring Adjudication — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_deferring_adjudication_procedure_l1_l2/updated_deferring_adjudication_procedure_l1_l2.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_deferring_adjudication_procedure_l1_l2/summary.dita`

Adjudication can now be deferred on initial claims for special benefits with a BPC between w/c 2258 and w/c 2309 when the last ROE is the only ROE with a contentious reason for separation (RFS) in the 12-week period before the client’s most recent interruption of earnings (I of E). 

## Generic

Source topic: `en_EN/site/dossier/updated_deferring_adjudication_procedure_l1_l2/generic.dita`

Due to the RFS transitional measure, the agent considers any contentious RFS issues that occurred more than 12 weeks before the most recent I of E as non-contentious. Consequently, when reviewing an Adjudication Issue (ADJ) WI on an initial claim for special benefits with a BPC between w/c 2258 and w/c 2309, the agent can defer adjudication when the last ROE is the only contentious ROE in the 12 weeks before the client’s most recent I of E. The agent considers any contentious RFS issues that occurred before the 12-week period as non-contentious and does not take them into account when determining if the adjudication of the last contentious RFS can be deferred. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_deferring_adjudication_procedure_l1_l2/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
