# New: Reason for separation adjudication on renewals — Policy and procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/new_rfsaor_policy_procedures/new_rfsaor_policy_procedures.ditamap`

## Summary

Source topic: `en_EN/site/dossier/new_rfsaor_policy_procedures/summary.dita`

Adjudication of contentious reason for separation (RFS) issues in the qualifying period (QP) of claims processed through the specialized ACP process is not required on renewal claims as long as the client is still requesting regular benefits. 

## Generic

Source topic: `en_EN/site/dossier/new_rfsaor_policy_procedures/generic.dita`

Effective September 27, 2020 the specialized process streamlined the processing of initial claims with a benefit period commencement (BPC) between w/c 2258 and w/c 2309. Claims processed through the specialized process were established without adjudicating contentious issues in the QP. The RFS issues that were not previously adjudicated can be identified because the special condition field was left blank on the Record of employment (ROE).

Clients filing a renewal of their claim with BPC 2258 or greater may declare the same contentious RFS issues from their QP that were previously not adjudicated because the claim went through the specialized ACP process. In these cases, when a client is renewing their claim for regular benefits the RFS from the QP is not adjudicated as long as the client is still requesting regular benefits. If there is an outstanding Adjudication Issue (ADJ) WI for the contentious RFS, the agent does not adjudicate the issue. The agent sends a request to an authorized user to delete the WI.

If there is both a Claim Assessment (CA) Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 agent ensures that the manual action 02 - Contentious renewal in automation (MA02) is removed by:

- processing the renewal following the normal procedure by inputting the renewal week;

- completing the registration number;

- completing the CA Renewal WI, even though the ADJ WI remains outstanding.

After the CA Renewal WI is completed, the agent sends a request to an authorized user to have the outstanding ADJ WI deleted.

Normal adjudication principles continue to apply to any RFS issues declared during the benefit period (BP) when clients renew their claim for benefits.

A COVID-19 alert and the What you need to know sections of the following activity pages and procedures have been updated with the information noted above:

- Dismissal (Activity)

- Leave of absence (Activity)

- Voluntary leaving (Activity)

- Adjudicating a dismissal or suspension — Renewal claim (Task)

- Adjudicating a dismissal for unsuitability— Renewal claim (Task)

- Adjudicating a leave of absence — Level 1 (Task)

- Adjudicating a leave of absence — Level 2 (Task)

- Adjudicating voluntary leaving (Level 1): Course of instruction — Renewal

- Adjudicating voluntary leaving (Level 1): Following another individual — Renewal

- Adjudicating voluntary leaving (Level 1): Medical reasons — Renewal

- Adjudicating voluntary leaving (Level 1): Other employment — Renewal

- Adjudicating voluntary leaving (Level 1): Workforce reduction — Renewal

- Adjudicating voluntary leaving: Renewal claim — Level 2

- Determining if a claim is ready to be renewed or converted (Task)

- Renewing a claim for regular benefits (Task) 

## Summary Of Changes

Source topic: `en_EN/site/dossier/new_rfsaor_policy_procedures/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
