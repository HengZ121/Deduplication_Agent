# Information: End of Budget 2021 temporary measures

Source map: `en_EN/site/dossier/information_end_of_budget_2021_temp_measures/information_end_of_budget_2021_temp_measures.ditamap`

## Summary

Source topic: `en_EN/site/dossier/information_end_of_budget_2021_temp_measures/summary.dita`

The legislative and regulatory amendments that were implemented for claims with a BPC of September 26, 2021 (w/c 2310) to September 18, 2022 (w/c 2361) end on September 24, 2022. 

## Generic

Source topic: `en_EN/site/dossier/information_end_of_budget_2021_temp_measures/generic.dita`

The Government of Canada implemented the Budget Implementation Act 2021 , Bill C-30, which amended the legislation to simplify and broaden access to EI benefits for a period of one year. Bill C-30 also provided for a return to the pre-pandemic legislation at the end of the temporary measures. Accordingly, the temporary measures related to entrance requirements, separation monies, and reasons for separation (RFSs) end on September 24, 2022. The impact of the end of those temporary measures on the related procedures is as follows:

**Entrance requirements**

As part of Budget 2021, a common entrance requirement (CER) of 420 hours was required to establish a claim for regular or special benefits when the BPC was between w/cs 2310 and 2361.

With this temporary measure ending on September 24, 2022, claims will no longer be established based on the CER. The entrance requirements for claims with a BPC of w/c 2362 or later are as follows:

- Regular benefits : The variable entrance requirement (VER) of the economic region of the client’s ordinary place of residence during the week of the BPC is used to determine the number of hours required to establish a claim. The VER is based on the regional rate of unemployment (RRU) and requires the client to have worked between 420 and 700 hours in insurable employment in the qualifying period (QP).

- Special benefits:

- Sickness benefits : The client must meet one of the following conditions:

- The client is major attached (i.e. has accumulated at least 600 hours of insurable employment in the QP).

- The client is minor attached (i.e. has accumulated less than 600 hours of insurable employment in the QP), meets the VER and the RFS is not illness, injury or quarantine.

- Special benefits other than sickness : The client must be major attached (i.e. has accumulated at least 600 hours of insurable employment in the QP).

- Fishing benefits: When the fisher does not qualify for regular or special benefits, a fishing claim can be established. The amount of fishing earnings required to establish a claim varies depending on the RRU in the region where the client resides. The VER is between $2 500 and $4 200 of insurable fishing earnings in the QP.

- Sickness benefits: The fisher must meet one of the following conditions:

- The fisher is major attached (i.e. has accumulated at least $3 760 of insurable fishing earnings in the QP).

- The fisher is minor attached (i.e. has accumulated less than $3 760 of insurable fishing earnings in the QP), meets the VER and the RFS is not illness, injury or quarantine.

- Special benefits other than sickness: The fisher must be major attached (i.e. has accumulated at least $3 760 of insurable fishing earnings in the QP).

- Special benefits for the self-employed: For claims with a BPC between January 2, 2022 (w/c 2324), and September 18, 2022 (w/c 2361), the client must have a minimum of $5 289 in net self-employment (SE) earnings in 2021. However, for claims with a BPC between September 25, 2022 (w/c 2362) and December 25, 2022 (w/c 2375), the minimum qualifying amount is $8 092 in net SE earnings in 2021. Due to CPS limitations, there cannot be 2 different minimum qualifying amounts within one calendar year. Therefore, IPOC intervention may be required to calculate or recalculate the claim. An SROC is created on the files of affected clients, and officers working in the Centre of Specialization and IPOC process the claims in MPS or CPS.

For all benefit types (BTs), if the client has a violation on file, increased entrance requirements may apply. The officer must ensure all qualifying and entitlement conditions are met for the requested BT.

**Increased entrance requirements**

When a violation is on file, there are increased entrance requirements for regular and special benefits. For claims with a BPC between w/cs 2310 and 2361 when the CER is in effect, the corresponding increased entrance requirements are as follows:

- 1 - Minor violation = 525 hours or $3 200 fishing earnings

- 2 - Serious violation = 630 hours or $3 800 fishing earnings

- 3 - Very serious violation = 735 hours or $4 350 fishing earnings

- 4 - Subsequent violation = 840 hours or $5 100 fishing earnings

However, as of September 25, 2022, the increased entrance requirements again depend on both the RRU and the classification of the violation, as indicated in Violation: Impact on calculation for regular and fishing claims (increased entrance requirements) — Table .
       [Violation: Impact on calculation for regular and fishing claims (increased entrance requirements) — Table](/en/procedure/generic/additionalresources/increased_entrance_requirements.shtml)

**Impact of the end of temporary measures on disentitlements**

Clients whose claims have a BPC between w/cs 2310 and 2361 and are established with 420 hours of insurable employment or more qualify for benefits. Therefore, disentitlements for minor attached clients who did not have enough hours to qualify for special benefits were not imposed since they did not apply.

As of September 25, 2022, the following disentitlements will once again be automatically generated during the calculation of the claim based on the hours of insurable employment:

- 2 - Minor attached, reason for separation illness disentitlement (D2)

- 25 - Maternity benefits - Minor attached disentitlement (D25)

- 35 - Parental benefits, qualifying conditions not met disentitlement (D35)

- 51 - Does not meet compassionate care entitlement conditions disentitlement (D51)

- 61 - Family caregiver for children or adults - Does not meet entitlement conditions disentitlement (D61)

An officer may need to manually impose one of the disentitlements listed above when the client has not accumulated the required number of hours in the QP or when another entitlement condition is not met, as outlined in the relevant procedures.

**System updates**

On September 17, 2022 (effective w/c 2361), the system will be updated so that all claims with a BPC of w/c 2362 or later are calculated based on either the VER or the 600-hour requirement for special benefits. If the client has a violation on file, increased entrance requirements may apply.

**Separation monies**

As part of Budget 2021, certain monies paid due to separation from employment were not allocated. Separation monies that were reviewed between w/c 2310 and w/c 2361 were not considered earnings and were not allocated.

As of September 25, 2022, separation monies that were not considered as earnings under the temporary measures are once again considered as earnings for benefit purposes and may extend the BP. For new allocations with a start date of September 25, 2022 or later, separation monies are considered earnings and are allocated on initial, renewal and continuing claims. They are also considered to extend the BP. As described in EIR 36(9), the allocation start week is considered to be the week of the layoff or separation, or the following week if the week of the layoff or separation is a full work week (FWW).

If separation monies are reviewed after September 25, 2022 (w/c 2362), but the allocation start date is between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361), the temporary measures apply. Therefore, these monies are not considered earnings, nor do they extend the BP.

In addition, Budget 2021 contained a measure for monies paid out from wrongful dismissal, grievance settlements and bankruptcies. EIA 46.01 was amended as part of Budget 2021 and the threshold amount that was used to determine if a payment issued under these circumstances would be allocated was removed. As of September 25, 2022, the officer will once again consider the threshold amount when determining if these monies need to be allocated.

**System update**

Systems will be updated to perform the correct allocations and extension of the benefit period, if necessary on Initial, Renewal and Recalculations.  Furthermore, as of September 16, 2022 a Claim Assessment (CA) WI will be created if a client declares an unacceptable monies on separation, or does not know the amount.

**Reason for separation (RFS)**

As part of the Budget 2021 temporary RFS measure, the following changes were implemented for initial claims with a BPC between w/cs 2310 and 2361:

- Only the last RFS required adjudication, if it was contentious.

- All hours of insurable employment in the QP are used to qualify for benefits as long as one of the following situations applies:

- the clients’ last employment ended through no fault of their own;

- the clients demonstrate just cause for voluntarily leaving their last employment;

- the clients did not lose their last employment due to misconduct.

- No other contentious RFS in the QP was adjudicated because the system was modified to automatically resolve the Adjudication Issue (ADJ) WIs by creating a record of decision (ROD) that shows Adjudication not Required .

- Following a disqualification, clients only needed to have worked at least one hour in insurable employment since the disqualifying event and to apply for benefits in order to establish a new initial claim.

The rules for adjudicating RFS issues that were effective before the COVID-19 pandemic will resume for claims with a BPC of w/c 2362 or later. This means that:

- the officer adjudicates all contentious RFS issues in the QP to determine if the insurable hours and earnings from that employment should be included in the claim calculation or excluded from it, or if a disqualification should be imposed;

- the officer continues to adjudicate any contentious RFS issues in the BP;

- the client is disqualified from receiving regular benefits if the client lost a job due to misconduct or voluntarily left without just cause, and the client must have worked enough hours in insurable employment since this disqualifying event in order to requalify for benefits;

- the client must have worked enough hours to requalify and meet all of the required criteria before the officer terminates or cancels a claim.

In order to align with the return to the previous rules, ADJ WIs will be automatically created on claims with a tentative BPC of w/c 2361. The officer must adjudicate those WIs following normal procedures (instead of the temporary measures), since it is possible for the claim to be finalized and established with a BPC of w/c 2362 or later. However, if the claim is finalized with a BPC of w/c 2361, the system will ignore the decision the officer made and it will apply the temporary measure.

On September 19, 2022 the affected EI ORT procedures related to entrance requirements, separation monies and RFSs will be updated. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/information_end_of_budget_2021_temp_measures/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
