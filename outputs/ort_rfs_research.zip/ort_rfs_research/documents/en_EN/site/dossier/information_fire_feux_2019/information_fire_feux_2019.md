# Information: Wildfires in western Canada and Ontario — Spring 2019

Source map: `en_EN/site/dossier/information_fire_feux_2019/information_fire_feux_2019.ditamap`

## Summary

Source topic: `en_EN/site/dossier/information_fire_feux_2019/summary.dita`

Emergency measures have been adopted to help clients affected by wildfires in western Canada and Ontario. The measures described below apply to clients who live in the evacuated areas or who have been affected by the disaster. 

## Generic

Source topic: `en_EN/site/dossier/information_fire_feux_2019/generic.dita`

**Reference codes**

Reference codes have been issued for clients who are affected by the wildfires.

- Affected clients in Alberta must use code 4812014812201900

- Affected clients in British Columbia must use code 5986015986201900

- Affected clients in Saskatchewan and Manitoba must use code 4317014317201900

- Affected clients in the Northwest Territories, Yukon and Nunavut must use code 4813014813201900

- Clients affected in Ontario should use code 3529012019061119

These reference codes can be used only by clients requesting regular benefits. Clients requesting special benefits must not use them.

**Client’s address**

Clients must enter their permanent address in the Residential address field of their AW application. If clients have been temporarily displaced because of the wildfires, they can enter their temporary address in the Mailing address field. This temporary mailing address could be a hotel, a community centre, etc.

**Interim ROEs**

Since employers may not be able to issue ROEs, an interim ROE must be created as soon as possible for affected clients.

**Reason for separation**

If the client is no longer working because of the mandatory evacuation, or because the business closed due to the wildfires, the reason for separation (RFS) is considered non-contentious. However, if a client has quit or taken a leave of absence because of the wildfires but is not directly affected by them, Level 2 adjudication is necessary. Normal adjudication principles must be followed to determine if the client had a valid reason for quitting or taking a leave of absence.

**Availability**

The availability of affected clients can be allowed at Level 1 unless there is additional information on file that indicates the client may not be available. Normal adjudication principles must be followed. However, the Level 2 agent must take into account each client’s personal circumstances when adjudicating availability.

**Earnings**

Some clients may be entitled to government or charitable financial assistance. These earnings are considered relief monies and are not considered earnings for benefit purposes. A Level 1 agent processes these monies.

Any other amount or compensation paid by the employer to assist affected employees must be assessed according to the usual rules.

**Major Employer Events**

Agents must regularly refer to the Major Employer Events (MEE) — Information Bulletin for information on employers and employee groups affected by the disaster. The Ontario region has created an event in the MEE bulletin related to wildfires under “Ontario Fires 2019 - Pikangikum in Northern Ontario.”

**Clients outside the affected provinces**

If a claim is filed using one of the region’s reference codes, but the residential address provided is outside the affected region, the claim is still calculated according to the reference code used. Once the claim is finalized, it will be transferred to the region where the client lives.

The Western Canada and Territories region has created a team to handle wildfire files. Agents from other regions must reassign all related WIs to the following hierarchy: Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - WT / Vacant - WT . 

## Summary of changes

Source topic: `en_EN/site/dossier/information_fire_feux_2019/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
