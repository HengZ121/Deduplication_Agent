# Updated: Budget 2021 and common entrance requirement — Policy and procedures (All levels)

Source map: `en_EN/site/dossier/updated_budget_2021_common_entrance_req_56204a4a/updated_budget_2021_common_entrance_req_56204a4a.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_budget_2021_common_entrance_req_56204a4a/summary.dita`

As part of Budget 2021, a national common entrance requirement for regular or special benefits has been introduced for claims with a BPC between September 26, 2021(w/c 2310) and September 18, 2022 (w/c 2361). 

## Generic

Source topic: `en_EN/site/dossier/updated_budget_2021_common_entrance_req_56204a4a/generic.dita`

The common entrance requirement ensures that no claimant, with the exception of those who have a violation, will require more than 420 hours of insurable employment to qualify for EI regular and special benefits.

For the duration of this measure:

- 420 hours of insurable employment is required to establish a claim for regular or special benefits;

- the definitions of major attached and minor attached, as stated in EIA 6(1), are repealed.

- the entrance requirement for fishing benefits has also been reduced to $2 500 and the entrance requirement for self-employment (SE) benefits to $5 289.

- If the client has a violation on file, increased entrance requirements may apply.
         [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

As a result of the common entrance requirement, the following BPNE codes are used in the situations outlined below:

- BPNE N1 is used for clients who do not qualify for benefits.

- BPNE N5 is used for clients who:

- must meet increased entrance requirements;

- have more than 420 hours of insurable employment;

- do not have enough hours to meet the increased entrance requirements.

- BPNE N7 is used for fishers who:

- have fishing earnings in the qualifying period (QP);

- do not have enough insurable fishing earnings to meet the entrance requirement of $2 500.

- BPNE N5 is used for fishers who do not meet the increased entrance requirement.

- BPNE N3 is used for self-employed persons who:

- have opted in to the EI program;

- do not meet the entrance requirement of $5 289 in SE earnings or the increased entrance requirement.

**Impact on procedures**

The definitions of major and minor attaches, as stated in EIA 6(1), are repealed for the duration of the measure. However, when following procedures, agents will select the major attached option when processing a claim for a client that has 420 or more insurable hours.

Since a client needs 420 hours of insurable employment to qualify for sickness benefits or any other benefit type (BT), if the BPC is between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361), the agent cannot use the claim type (CT) 9 - Sickness - minor attached . In addition, the agent does not impose a 2 - Minor attached, reason for separation illness disentitlement (D2) on these claims.

**Transitional postdate policy**

Since the common entrance requirement only comes into force on September 26, 2021, in the meantime, the agent may encounter cases in which clients do not qualify for the benefits they are requesting based on the hours of insurable employment required. To provide a better service to clients and avoid them having to reapply for benefits, a transitional postdate policy is being implemented. Therefore, claims with a BPC no more than 2 weeks before the effective date of the common entrance requirement can be postdated to w/c 2310, if this BPC would allow clients to qualify for the benefits they are requesting.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1197.dita) 

**Administrative antedate policy**

The administrative antedate policy should only apply if it is to the client’s advantage. Even if a BPC could be established before the effective date of the common entrance requirement, claims filed within 4 weeks of the interruption of earnings (I of E) are not antedated if this would result in the client not qualifying.

Information about the Budget 2021 common entrance requirement measure has been added to all relevant activities, tasks, additional resources and tables.

For additional information: Budget 2021 - Seeing Canadians and Businesses through to Recovery – BE-MEMO-2021-03. 

### Example

Source topic: `en_EN/common_notes/note_c_1197.dita`

Example:

A client files for maternity benefits in w/c 2309 with 500 hours of insurable employment. If her BPC were in w/c 2309, she would not qualify for maternity benefits because she is minor attached. Therefore, the agent can postdate her claim to w/c 2310 so that she can receive maternity benefits by meeting the common entrance requirement of 420 hours of insurable employment. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_budget_2021_common_entrance_req_56204a4a/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
