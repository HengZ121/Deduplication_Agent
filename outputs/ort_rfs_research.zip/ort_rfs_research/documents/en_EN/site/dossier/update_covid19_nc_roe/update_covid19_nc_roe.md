# Archived: COVID-19 and ROEs — Procedures and additional resource (Non-complex)

Source map: `en_EN/site/dossier/update_covid19_nc_roe/update_covid19_nc_roe.ditamap`

## Summary

Source topic: `en_EN/site/dossier/update_covid19_nc_roe/summary.dita`

## Generic

Source topic: `en_EN/site/dossier/update_covid19_nc_roe/generic.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1187.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/update_covid19_nc_roe#archived)

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/update_covid19_nc_roe#archived)

Due to COVID-19, the task Completing an ROE Issue RFS Action WI: K - Other and the instructions ROE: Actions required for comments found in block 18 of a regular ROE have been updated to provide the measures to take when the ROE includes comments related to COVID-19.

If the ROE comments indicate Coronavirus or COVID-19 but are not detailed enough to determine the RFS, the agent must review the client’s requested benefit type in the application in NWS, and update the RFS to match. For example if the client has requested sickness benefits, update the RFS to D-Illness or injury; if the client has requested regular benefits, update the RFS to A-Shortage of work. 

### Warning

Source topic: `en_EN/common_notes/note_c_1187.dita`

**This page has been archived on the Web**

UPDATED: 2020-06-22 — The Headlines and Updates page has been archived because the temporary measures have been replaced by new measures. For more details, refer to Updated: ROE comments and artificial intelligence model — Procedures and additional resource (Non-complex and Level 1) .
       [Updated: ROE comments and artificial intelligence model — Procedures and additional resource (Non-complex and Level 1)](/en/site/dossier/updated_roe_comments_artificial_intelligence_model_procedure_ar.shtml)

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available.

     [Updated: ROE comments and artificial intelligence model — Procedures and additional resource (Non-complex and Level 1)](/en/site/dossier/updated_roe_comments_artificial_intelligence_model_procedure_ar.shtml) 

## Summary Of Changes

Source topic: `en_EN/site/dossier/update_covid19_nc_roe/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
