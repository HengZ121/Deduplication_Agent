# Updated: WIs created for outstanding adjudications when completing conversions on a continuing claim — Procedures (Level 1)

Source map: `en_EN/site/dossier/upd-wi-out-adj-cont/upd-wi-out-adj-cont.ditamap`

## Summary

Source topic: `en_EN/site/dossier/upd-wi-out-adj-cont/summary.dita`

All procedures on conversions have been updated to include information and steps for creating a Claim Review (CR) WI for outstanding contentious issues for conversions on continuing claims. These steps replace the client Note that used to be created and eliminates the need for Level 1 officers to reassign the CR Conversion WIs to Level 2 when a contentious adjudication issue exists. Many procedures have been changed to reflect this update. 

## Generic

Source topic: `en_EN/site/dossier/upd-wi-out-adj-cont/generic.dita`

When a Level 1 officer identifies a contentious issue (e.g. reason for separation [RFS], availability, farming) on a conversion request on a continuing claim, the Level 1 officer creates a CR WI for the contentious issue and attempts to adjudicate according to the National Policy on Levels of Decision. If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2.

The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1). The Level 1 officer does not reassign the CR Conversion WI to Level 2 for any reason.

Changes have been made to all conversion procedures under the following headings:

- Converting EI ERB claims

- Conversion from regular benefits

- Conversion from sickness benefits

- Conversion from special benefits other than sickness benefits 

## Summary of changes

Source topic: `en_EN/site/dossier/upd-wi-out-adj-cont/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
