# Updated: Referring an unreported contentious reason for separation to Integrity — Procedures and additional resource (Non-complex, Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_referring_an_unreported_content_79f8b883/updated_referring_an_unreported_content_79f8b883.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_referring_an_unreported_content_79f8b883/summary.dita`

Since the beginning of the COVID-19 pandemic, referring issues to Integrity has been restricted. Although the restrictions are still in place, tasks were updated with clarifications about undisclosed contentious reasons for separation (RFS) so that officers know when to refer the issue to Integrity. 

## Generic

Source topic: `en_EN/site/dossier/updated_referring_an_unreported_content_79f8b883/generic.dita`

The officer only refers an issue related to an unreported contentious RFS to Integrity when the RFS impacts the payment of benefits on a current claim and benefits paid on a previous claim. If the undisclosed contentious RFS only impacts a previous claim, the officer does not refer it to Integrity and does not adjudicate it. This is because the RFS will prompt the creation of an investigation from one of Integrity’s detection programs.

When referring an RFS that impacts the payment of benefits on a current claim to Integrity, the officer determines if there is an outstanding Action Item (AI) WI assigned to Integrity for that RFS:

- If no, the officer creates an urgent AI WI for Integrity.

- If yes, the officer adds information to the AI WI and checks the Urgent box.

Whether creating a new AI WI or adding information to an existing one, the officer documents in the WI that the RFS impacts the payment of benefits so that the investigation can be prioritized. The officer moves the Adjudication (ADJ) WI to Pending until the investigation is complete.

The officer refers to Determining if an issue must be referred to Integrity for more information on when to refer unreported contentious RFS to Integrity.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

## Summary of changes

Source topic: `en_EN/site/dossier/updated_referring_an_unreported_content_79f8b883/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
