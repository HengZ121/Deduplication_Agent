# ROE Issue RFS Action WI — Linking an ROE to a period of employment

Source map: `en_EN/site/dossier/roe_rfs_updates/roe_rfs_updates.ditamap`

## Summary

Source topic: `en_EN/site/dossier/roe_rfs_updates/summary.dita`

The procedures for completing an ROE Issue (ROE) RFS Action WI have been updated to reflect the system changes following the emergency release on December 15, 2015 and to address other regional feedback. 

## Generic

Source topic: `en_EN/site/dossier/roe_rfs_updates/generic.dita`

When creating a link between an ROE and a period of employment with the same employer’s name, the agent must consider all of the ROEs on file to determine which one, if any, is the best match for last day worked and last day for which paid.

Before changing the reason for separation (RFS) to a non-contentious option ( A - Shortage of work , D - Illness or injury , or J - Apprentice training ) based on the comments in block 18 or the Additional information field of the ROE, the agent must determine if there is record of decision (ROD) on file indicating another RFS. If there is a ROD on file indicating another RFS, the agent does not change the RFS and selects No Decision Matches the ROE .

When the ROE is linked to a period of employment, the RFS on the ROE is E - Quit and the RFS on the ROD is voluntary leaving, the system implements the decision on file. The Resolve Issue section is not displayed in the WI and confirmation of an automated decision is not required in this situation.

When the ROE is linked to a period of employment, the RFS on the ROE is M - Dismissal , the ROD on file indicates “Dismissal — ROE confirmation required”, the RFS sub-option is Dismissal - Terminated within probationary period and there are comments on the ROE, the agent selects No Decision Matches the ROE if the comments on the ROE do not confirm the automated decision.

When the RFS on the ROE is K - Other , the RFS sub-option is Other - At the employee’s request , and there is no ROD on file for that employment, the system creates an Adjudication Issue RFS Review WI when the ROE RFS Action WI is completed. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/roe_rfs_updates/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
