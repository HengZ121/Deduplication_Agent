# Updated: Determining the recovery week and incapacity start week on claims for sickness benefits — Policy and procedures (Level 1, Level 2 and IPOC)

Source map: `en_EN/site/dossier/upd-det-rec-w-inc-sw-sb/upd-det-rec-w-inc-sw-sb.ditamap`

## Summary

Source topic: `en_EN/site/dossier/upd-det-rec-w-inc-sw-sb/summary.dita`

The National Policy on Proof of Incapacity has been updated effective April 7, 2024 (w/c 2442) with changes to the way officers determine the recovery week on a claim for sickness benefits. A new section has also been added to provide guidance on how to determine the incapacity start week.
       [National Policy on Proof of Incapacity](/en/policy/nationalpolicy/proof_of_incapacity_policy.shtml) 

## Generic

Source topic: `en_EN/site/dossier/upd-det-rec-w-inc-sw-sb/generic.dita`

**Policy:**

On a claim for sickness benefits, when the reason for separation (RFS) is D - Illness or injury and the client is not required to submit a medical certificate, the recovery week will now be calculated as BPC + 8 weeks instead of BPC + 15 weeks. This change applies to all claims with a BPC of April 7, 2024 (w/c 2442) or after. A systems update has been made to implement this change.

A new section has been added to the National Policy on Proof of Incapacity — Incapacity start date, which provides guidance on how to determine the incapacity start week on a claim for sickness benefits, if necessary. On an initial or renewal claim, when the RFS is D and no medical certificate needs to be submitted, the incapacity start week is the BPC or renewal week. On a conversion from regular to sickness benefits, when no medical certificate needs to be submitted, the incapacity start date is the conversion week. In all other situations, the incapacity start date is the Sunday of the week in which the doctor or medical professional indicates the client became unable to work for medical reasons. If no specific incapacity start date is provided, the incapacity start date is the Sunday of the week of the medical consultation, or of the week in which the doctor or medical professional signed the medical certificate, whichever is earlier.

This new section also provides guidance on how to determine the incapacity start week when a medical certificate is submitted for a subsequent period of incapacity and there is a gap between the previous recovery week and the incapacity start week on the new medical certificate.

**Coming into force date:**

The coming into force date for the change from BPC + 15 weeks to BPC + 8 weeks is effective on all claims with a BPC of April 7, 2024 (w/c 2442) or later. All other changes to the policy are effective immediately.

**Automated claims:**

Claims for sickness benefits with an RFS of D that are automated with a BPC of April 7, 2024 (w/c 2442) or later will be established with a recovery week of BPC + 8 weeks.

**Procedures:**

Tasks that reference the determination of a recovery week on an initial claim for sickness benefits when the RFS is D and no medical is required have been changed from BPC + 15 weeks to BPC + 8 weeks for claims with BPC of April 7, 2024 (w/c 2442) or later. Additional resources and tasks have also been updated to provide the new guidance on how to determine an incapacity start week for an initial period of sickness benefits. Guidance has also been provided on subsequent periods of incapacity when there is a gap between the previous recovery week and the incapacity start week on the medical certificate for a new period of sickness benefits.

Changes have also been made to the conditions for determining if a medical certificate is acceptable. If there are no dates on a medical certificate, it is not considered acceptable and the client must submit a new one.

The following procedures in the EI ORT have been updated to reflect these changes to the National Policy on Proof of Incapacity :
       [National Policy on Proof of Incapacity](/en/policy/nationalpolicy/proof_of_incapacity_policy.shtml)

- Sickness: Incapacity start date — Table
         [Sickness: Incapacity start date — Table](/en/procedure/generic/additionalresources/incapacity_start_date_sb.shtml)

- Determining the recovery week — Instructions
         [Determining the recovery week — Instructions](/en/procedure/generic/determing_the_recovery_week_instruction.shtml)

- Determining if a medical certificate is acceptable
         [Determining if a medical certificate is acceptable](/en/procedure/task/determining_med_cert_valid.shtml)

- Determining if a medical certificate must be submitted: Sickness benefits — Initial claims
         [Determining if a medical certificate must be submitted: Sickness benefits — Initial claims](/en/procedure/task/calc_determining/det_mc_ra.shtml)

- Determining if a medical certificate must be submitted — Renewal and continuing claims
         [Determining if a medical certificate must be submitted — Renewal and continuing claims](/en/procedure/task/determining_med_cert_req.shtml)

- Reviewing a medical certificate submitted by a client receiving sickness benefits
         [Reviewing a medical certificate submitted by a client receiving sickness benefits](/en/procedure/task/reviewing_mc_crsb.shtml)

- Reviewing a medical certificate submitted by a client with a D16 disentitlement
         [Reviewing a medical certificate submitted by a client with a D16 disentitlement](/en/procedure/task/review_d16_med_cert.shtml)

- Modifying the sickness benefits information on the Annex — Special benefits screen in SSA
         [Modifying the sickness benefits information on the Annex — Special benefits screen in SSA](/en/procedure/task/calc_calculating/ent_recdate_ssa_sb.shtml)

- Reviewing the calculation result — Special benefits
         [Reviewing the calculation result — Special benefits](/en/procedure/task/calc_reviewing/review_rw.shtml)

- Notice of decision: Requirements — Knowledge
         [Notice of decision: Requirements — Knowledge](/en/procedure/generic/additionalresources/notice_decision_ja.shtml)

- Converting a claim from regular to sickness benefits
         [Converting a claim from regular to sickness benefits](/en/procedure/task/conv_regsick.shtml)

- Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim
         [Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim](/en/procedure/task/conv_regsick_eia25.shtml)

- Converting a claim from maternity to sickness benefits
         [Converting a claim from maternity to sickness benefits](/en/procedure/task/conv_matsick.shtml)

- Converting a claim from parental to sickness benefits
         [Converting a claim from parental to sickness benefits](/en/procedure/task/conv_parsick.shtml)

- Converting a claim from CCB to sickness benefits — Continuing claim
         [Converting a claim from CCB to sickness benefits — Continuing claim](/en/procedure/task/conv_ccb_sick_cc.shtml)

- Renewing a claim for sickness benefits
         [Renewing a claim for sickness benefits](/en/procedure/task/renew_sb.shtml) 

## Summary of changes

Source topic: `en_EN/site/dossier/upd-det-rec-w-inc-sw-sb/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
