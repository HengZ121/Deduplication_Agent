# New: Adjudicating reasons for separation on conversions — Policy and procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/new_arsc_pap/new_arsc_pap.ditamap`

## Summary

Source topic: `en_EN/site/dossier/new_arsc_pap/summary.dita`

New Policy guidance requires that the agent adjudicate contentious reason for separation (RFS) issues in the qualifying period (QP) when a client requests a conversion from special to regular benefits on claims with a BPC between w/c 2258 and w/c 2309. 

## Generic

Source topic: `en_EN/site/dossier/new_arsc_pap/generic.dita`

As of September 27, 2020 claims for sickness and regular benefits automated in the specialized ACP process were established without adjudicating contentious RFS issues in the QP. Effective immediately, agents adjudicate all RFS issues in the 12-week period before the interruption of earnings (I of E) used to establish the claim when clients request a conversion from special to regular benefits.

Claims being converted from special to regular benefits with contentious RFS issues in the QP are identified with a 1 - General suspension of benefits (stop payment) manual action (MA01) and an Action Item (AI) WI. To help agents action these WIs, a new procedure has been developed. That procedure provides instructions to apply the new policy guidance and to adjudicate RFS issues that were not adjudicated when the client initially applied for benefits.

The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE, but the ROE was still included in the initial calculation.

The agent does not need to adjudicate contentious RFS issues in the QP for sickness claims automated in the specialized ACP process that are now being recalculated because the client has requested regular benefits from BPC.

**Impact on adjudication**

If adjudication results in a negative decision and a disqualification or disentitlement applies, the effective date is the week of the conversion rather than the date of the event. There may be situations where the client received some weeks of regular benefits before the manual action (MA) was imposed. In those situations, the effective date of the disqualification or the disentitlement is the week that the MA01 was imposed. In cases where the adjudication results in a negative decision and no MA was imposed, the disqualification or disentitlement is effective from the beginning of the week the issue is adjudicated.

**Requalifying and recalculation**

Clients who have accumulated enough insurable hours to establish a benefit period (BP) since the most recent disqualifying event are considered requalifiers and no disqualification is imposed. However, due to the one-time credit of insurable hours, clients need 120 hours of insurable employment since the most recent disqualifying event to requalify. If the client requalifies, the ROE with the disqualifying event is excluded and no disqualification is imposed.
       [benefit period](/en/procedure/generic/knowledge.shtml#Benefit_Period)

When agents determine that the client requalifies after the most recent disqualifying event, they normally determine if a recalculation is required by reviewing changes to either the client’s benefit rate or the weeks of entitlement. Since all claims with a BPC between w/c 2258 and w/c 2309 will include 50 weeks of entitlement, a recalculation is only required if the client’s benefit rate is greater than the minimum of $500. Therefore, once all of the contentious RFS issues have been adjudicated, a recalculation is not required when a disqualification was imposed on the last ROE or the client has the minimum benefit rate of $500. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/new_arsc_pap/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
