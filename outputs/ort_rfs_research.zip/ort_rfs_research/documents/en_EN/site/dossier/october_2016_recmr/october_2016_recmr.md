# October 2016 Record of Employment Capture Module Release

Source map: `en_EN/site/dossier/october_2016_recmr/october_2016_recmr.ditamap`

## Summary

Source topic: `en_EN/site/dossier/october_2016_recmr/summary.dita`

Procedures have been updated as a result of the October 2016 Record of Employment Capture Module (RCM) release. A new task called Entering data from a paper ROE — Laser ROE has been published in the EI Online Reference Tool (EI ORT). 

## Generic

Source topic: `en_EN/site/dossier/october_2016_recmr/generic.dita`

The following changes that impact procedures are being implemented in RCM:

- The dollar amount fields on the ROE are expanded from $999,999.99 to $9,999,999.99 . Amounts up to $9,999,999.99 can now be entered on the ROE. This impacts the following fields: While larger amounts can now be entered on an ROE, the ROE will be saved in error as other EI systems cannot accept these larger amounts. When the ROE is called for calculation, an ROE Correction WI is created in NWS and the agent must correct the ROE, to ensure the claim is calculated correctly.  The agent must determine the average normal weekly earnings (ANWE) and the average earnings in the last week worked (AELWW) according the client’s real earnings and complete the section Allocation of monies in RCM.

- 15B – Total insurable earnings

- 15C PP1-53 – Pay Period Earnings

- 17A –Vacation Pay Amount

- 17B – Statutory Holiday Amount

- 17C – Other Money Amount

- 19 – Special Payment Amounts

- Delete and Unsigned values have been moved from the STATUS drop-down menu in RCM. Only calculation statuses (Insurability in Order , Insurability Ruling Pending and Void – Not Insurable) remain in the dropdown menu of the STATUS field. Delete and Unsigned have separate check boxes below.  This prevents the overwriting of statuses when more than one of these values is applicable. The agent can select the appropriate value from the dropdown menu of the STATUS field and check the boxes below as required.

- Reason for separation (RFS) codes and RFS sub-codes have been combined in a single drop down menu in Block 16. RCM used to contain a drop down menu for the RFS codes and 2 additional drop down menus for Special Condition and RFS sub-codes based on the initial code value selected for RFS.  The RFS codes and sub-codes are now combined into one drop down menu.  Special condition remains as is. The WIs are not impacted by this change.  Although the RFS codes and sub-codes are combined into one drop down menu in RCM, they are separate in the WI. This change does not impact the underlying structure of the data.

- Other Money codes and supplemental unemployment benefits (SUB) codes are combined into a single drop down menu in Block 17C Similar to the above change, the Other Money codes and SUB codes in block 17C (Other Monies) are combined into one drop-down menu.

- L series ROEs are now rejected The laser scan program has been decommissioned for several years but employers were allowed to print and mail the L series ROEs. It was possible for agents to enter them in RCM as regular paper ROEs. The L series ROEs are now rejected as having invalid serial numbers. Agents must now enter them as interim ROEs, scan them and send a copy to the ROE registration services team, who then follows up with employers. A new task (Entering data from a paper ROE — Laser ROE) is now available in the EI ORT.

The following job aids have been updated according to these changes:

- Comments found in block 18 of a regular ROE
         [Comments found in block 18 of a regular ROE](/en/procedure/generic/table_block18.shtml)

- Correction of an RCM validation error — Regular ROE
         [Correction of an RCM validation error — Regular ROE](/en/procedure/generic/correction_reg_1.shtml)

- Correction of an RCM validation error when employer cannot be reached — Regular ROE
         [Correction of an RCM validation error when employer cannot be reached — Regular ROE](/en/procedure/generic/correction_reg_2.shtml)

- Correction of an RCM validation error when employer cannot be reached — Fishing ROE
         [Correction of an RCM validation error when employer cannot be reached — Fishing ROE](/en/procedure/generic/correction_fishing_2.shtml) 

## Summary of changes

Source topic: `en_EN/site/dossier/october_2016_recmr/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
