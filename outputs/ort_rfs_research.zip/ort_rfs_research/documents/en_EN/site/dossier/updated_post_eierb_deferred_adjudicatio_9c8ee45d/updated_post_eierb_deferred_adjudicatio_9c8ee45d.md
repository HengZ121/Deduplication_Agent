# Updated: Post-EI ERB and deferred adjudication of reason for separation — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_post_eierb_deferred_adjudicatio_9c8ee45d/updated_post_eierb_deferred_adjudicatio_9c8ee45d.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_post_eierb_deferred_adjudicatio_9c8ee45d/summary.dita`

As part of the transition to EI, UIC does not impose a disqualification if adjudication of the reason for separation (RFS) is deferred on initial claims when the BPC is between September 27, 2020 (w/c 2258) and September 25, 2021 (w/c 2309). 

## Generic

Source topic: `en_EN/site/dossier/updated_post_eierb_deferred_adjudicatio_9c8ee45d/generic.dita`

For all Initial calculations and recalculations with BPC 2258 to 2309, when the special condition is blank or deferred, UIC considers the RFS as non-contentious and includes the ROE in the calculation.

When converting a claim from special benefits to regular benefits, since no disqualification was imposed by UIC on the initial claim, agents must adjudicate all outstanding RFS issues to prevent payment of benefits to which the client is not entitled.

Information in the What You Need to Know section of the following tasks was updated to reflect this UIC change:

- Converting a claim from sickness to regular benefits

- Converting a claim from maternity to regular benefits

- Converting a claim from parental to regular benefits

- Converting a claim special benefits to regular benefits for a client participating in a Work-Sharing program

- Deferring adjudication: Renewal claim – Sickness benefits

- Deferring adjudication: Renewal claim – Special benefits (Other than sickness) 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_post_eierb_deferred_adjudicatio_9c8ee45d/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
