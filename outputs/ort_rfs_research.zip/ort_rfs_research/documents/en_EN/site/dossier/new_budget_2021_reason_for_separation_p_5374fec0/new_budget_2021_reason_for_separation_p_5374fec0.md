# Updated: Budget 2021 and reason for separation — Policy and procedures (Non-complex, Level 1 and Level 2)

Source map: `en_EN/site/dossier/new_budget_2021_reason_for_separation_p_5374fec0/new_budget_2021_reason_for_separation_p_5374fec0.ditamap`

## Summary

Source topic: `en_EN/site/dossier/new_budget_2021_reason_for_separation_p_5374fec0/summary.dita`

On initial claims with a BPC between w/c 2310 and w/c 2361, only the contentious reason for separation (RFS) for the last period of employment is adjudicated. This measure does not apply to claims for self-employment (SE) or fishing benefits. 

## Generic

Source topic: `en_EN/site/dossier/new_budget_2021_reason_for_separation_p_5374fec0/generic.dita`

Procedures affected by the Budget 2021 RFS measure have been updated. However, this measure only applies to claims with a BPC between w/c 2310 and w/c 2361.

As part of Budget 2021, a temporary measure has been introduced for initial claims and recalculations. It provides that all hours of insurable employment in the qualifying period (QP) can be used to qualify for benefits as long as the clients’ last employment ended through no fault of their own or they prove just cause for leaving. No other contentious RFS in the QP is adjudicated, and all ROEs are included in the claim calculation. However, if the agent determines that the RFS for the last period of employment used to establish the benefit period (BP) is not allowed, all the hours are included in the claim calculation and the agent imposes a disqualification.

**System changes effective September 13, 2021**

The following changes have been made to support the implementation of the RFS temporary measure:

- The system only creates an Adjudication Issue (ADJ) RFS Review WI when the contentious RFS:

- for the last period of employment reported on the EI application is dismissal, suspension, voluntary leaving or leave of absence;

- with any employer in the QP is strike.

- The new decision Adjudication not required - Budget 2021 EI Simplification measures has been added to the Level 1 ADJ Voluntary leaving and Dismissal WIs on initial claims for regular or special benefits.

- When a client reports a contentious RFS in the Other Employers section of the EI application, the system  applies the auto-adjudication rules. If the RFS cannot be allowed under the auto-adjudication rules, the system  automatically resolves the RFS issue with Adjudication not required - Budget 2021 EI Simplification measures .

- When the system automatically resolves an issue with Adjudication not required - Budget 2021 EI Simplification measures , the Special condition field on the ROE is not updated, but this ROE is still included in the claim calculation.

**Impact on adjudication of claims with a BPC between w/c 2310 and w/c 2361**

When establishing an initial claim, adjudication is only required on the contentious RFS for the period of employment with the latest last day paid (LDP) used to establish the claim. Therefore, the system creates an ADJ WI when the last RFS reported on the EI application is contentious. If the agent determines that adjudication is not required because the RFS for which a WI was created is not for the latest period of employment, the agent resolves the issue with Adjudication not required - Budget 2021 EI Simplification measures .

On renewal and continuing claims for regular benefits, adjudication is required on all contentious RFSs in the BP.

As part of the legislative changes of Budget 2021, clients no longer have to work enough hours in insurable employment since the disqualifying event to establish a new initial claim for benefits. EIA 30(1) up to paragraph (b) has been updated to indicate that clients are disqualified from receiving regular benefits if they lost their employment due to misconduct or voluntarily left their employment without just cause, unless they have worked in insurable employment and filed a new initial claim since losing or leaving the employment. This means that the agent does not use the common entrance requirement of 420 hours of insurable employment to determine if the client requalifies after a disqualifying event. Instead, the client needs to have worked at least one hour in insurable employment since the disqualifying event and to have filed an EI application. If the RFS since the disqualifying event is either non-contentious or adjudicated and allowed, the agent can establish a new claim using the hours from all of the ROEs.

When clients submit renewal applications for regular benefits to reactivate their previously established claims on which benefits were paid, any new contentious RFS in the BP must be adjudicated. If the agent determines that they lost their employment due to misconduct or voluntarily left their employment without just cause, the agent imposes an indefinite disqualification. However, if they worked since this disqualifying event and the RFS from that employment is not contentious or is adjudicated and allowed, the agent determines if they worked enough hours in insurable employment since the initial BPC to establish a new claim. To make this determination, the agent uses the hours from the ROE that resulted in the disqualification and the hours from the ROEs since the disqualification. If the agent determines that they have enough hours to establish a new claim, the agent creates a WI to terminate the claim in order to establish a new initial claim.

Under this measure, the agent considers a contentious RFS only if it is for the most recent period of employment. If so, no adjudication is required for any other ROE in the QP. Therefore, the agent does not consider deferral for other ROEs in the QP.

If the adjudication of a contentious RFS resulted in an outstanding indefinite disqualification on a renewal claim for regular benefits, the agent cannot defer adjudication and must adjudicate any new contentious RFS in the BP.

When a client requests sickness benefits on an initial claim with a BPC between w/c 2310 and w/c 2361, adjudication of the RFS for the last period of employment can be deferred regardless of the RFS on other ROEs in the QP, as long as the client is otherwise available and qualifies for sickness benefits. In addition, when a client requests special benefits other than sickness between w/c 2310 and w/c 2361, adjudication of the RFS for the last period of employment can be deferred regardless of the RFS of other ROEs in the QP.

**Impact on procedures**

Information on how to apply the Budget 2021 RFS measure has been added to the following activities and the What You Need To Know and Step by Step sections of the following tasks:

- Dismissal (Activity)
         [Dismissal (Activity)](/en/procedure/activity/dismissal.shtml)

- Adjudicating a dismissal or suspension — Initial claim (Task)
         [Adjudicating a dismissal or suspension — Initial claim (Task)](/en/procedure/task/dismissal_ds_ic.shtml)

- Adjudicating a dismissal for unsuitability — Initial claim (Task)
         [Adjudicating a dismissal for unsuitability — Initial claim (Task)](/en/procedure/task/dismissal_ic.shtml)

- Adjudicating a dismissal or suspension — Renewal claim (Task)
         [Adjudicating a dismissal or suspension — Renewal claim (Task)](/en/procedure/task/dismissal_ds_rc.shtml)

- Voluntary leaving (Activity)
         [Voluntary leaving (Activity)](/en/procedure/activity/voluntary_leaving.shtml)

- Adjudicating voluntary leaving (Level 1): Course of instruction — Initial claim (Task)
         [Adjudicating voluntary leaving (Level 1): Course of instruction — Initial claim (Task)](/en/procedure/task/vl_course_ic.shtml)

- Adjudicating voluntary leaving: Initial Claim — Level 2 (Task)
         [Adjudicating voluntary leaving: Initial Claim — Level 2 (Task)](/en/procedure/task/vllevel2_ic.shtml)

- Adjudicating voluntary leaving (Level 1): Medical reasons — Initial claim (Task)
         [Adjudicating voluntary leaving (Level 1): Medical reasons — Initial claim (Task)](/en/procedure/task/vllevel1_mr_ic.shtml)

- Adjudicating voluntary leaving (Level 1): Following another individual — Initial claim (Task)
         [Adjudicating voluntary leaving (Level 1): Following another individual — Initial claim (Task)](/en/procedure/task/vllevel1_fai_ic.shtml)

- Adjudicating voluntary leaving (Level 1): Other employment — Initial claim (Task)
         [Adjudicating voluntary leaving (Level 1): Other employment — Initial claim (Task)](/en/procedure/task/vllevel1_oe_ic.shtml)

- Adjudicating voluntary leaving (Level 1): Workforce reduction — Initial claim (Task)
         [Adjudicating voluntary leaving (Level 1): Workforce reduction — Initial claim (Task)](/en/procedure/task/vl_wr_ic.shtml)

- Leave of absence (Activity)
         [Leave of absence (Activity)](/en/procedure/activity/leave_absence.shtml)

- Adjudicating a leave of absence — Level 1 (Task)
         [Adjudicating a leave of absence — Level 1 (Task)](/en/procedure/task/voluntary_leaving_loa.shtml)

- Adjudicating a leave of absence — Level 2 (Task)
         [Adjudicating a leave of absence — Level 2 (Task)](/en/procedure/task/adjudicating_loa_l2.shtml)

- Deferral of adjudication (Activity)
         [Deferral of adjudication (Activity)](/en/procedure/activity/deferral_adj.shtml)

- Deferring adjudication: Initial claim — Regular benefits (Task)
         [Deferring adjudication: Initial claim — Regular benefits (Task)](/en/procedure/task/defer_adj_initial_regular_ben.shtml)

- Deferring adjudication: Initial claim — Sickness benefits (Task)
         [Deferring adjudication: Initial claim — Sickness benefits (Task)](/en/procedure/task/defer_adj_initial_sickness_ben.shtml)

- Deferring adjudication: Initial claim — Special benefits (other than sickness) (Task)
         [Deferring adjudication: Initial claim — Special benefits (other than sickness) (Task)](/en/procedure/task/defer_adj_initial_special_ben_other_sickness.shtml)

- Deferring adjudication: Renewal claim — Regular benefits (Task)
         [Deferring adjudication: Renewal claim — Regular benefits (Task)](/en/procedure/task/defer_adj_renewal_regular_ben.shtml)

- Reviewing the calculation result — Disqualified or disentitled ROE (Task)
         [Reviewing the calculation result — Disqualified or disentitled ROE (Task)](/en/procedure/task/calc_reviewing/review_calc_disqual_exclus.shtml)

- Reviewing the calculation result — Messages
         [Reviewing the calculation result — Messages](/en/procedure/generic/rcr_screen_messages.shtml)

- Reviewing information for a missing ROE (Task)
         [Reviewing information for a missing ROE (Task)](/en/procedure/task/calc_determining/missing_roe.shtml)

- Reviewing an outstanding issue with no Adjudication Issue WI (Task)
         [Reviewing an outstanding issue with no Adjudication Issue WI (Task)](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Cancelling a benefit period (Task)
         [Cancelling a benefit period (Task)](/en/procedure/task/benefit_period_cancel.shtml)

- Terminating a benefit period (Task)
         [Terminating a benefit period (Task)](/en/procedure/task/benefit_period_term.shtml)

For additional information consult Budget 2021 - Seeing Canadians and Businesses through to Recovery – BE-MEMO-2021-03 (BE Memo). 

## Summary Of Changes

Source topic: `en_EN/site/dossier/new_budget_2021_reason_for_separation_p_5374fec0/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
