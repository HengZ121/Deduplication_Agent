# Archived: COVID-19 and fact-finding — Task (All levels)

Source map: `en_EN/site/dossier/fact_find_covid19_update/fact_find_covid19_update.ditamap`

## Summary

Source topic: `en_EN/site/dossier/fact_find_covid19_update/summary.dita`

Due to COVID-19, fact-finding with employers has changed. 

## Generic

Source topic: `en_EN/site/dossier/fact_find_covid19_update/generic.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1023.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/fact_find_covid19_update#archived)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1024.dita) 

**Table of Content**

- What You Need To Know
         [What You Need To Know](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/fact_find_covid19_update#What_You_Need)

- Temporary process

- Fact-finding for ROE issues
             [Fact-finding for ROE issues](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/fact_find_covid19_update#FFforROEIssues)

- Fact-finding for other issues
             [Fact-finding for other issues](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/fact_find_covid19_update#FFforOtherIssues)

         [Temporary process](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/fact_find_covid19_update#Temporary_process)

**What You Need To Know**

**Fact-finding for ROE issues**

Effective immediately, the agent follows regular fact-finding procedures when attempting to contact an employer for ROE issues, unless the agent confirms that the business remains closed due to COVID-19.
       [fact-finding](/en/procedure/task/fact_find.shtml)

Confirmation of closure due to COVID-19 includes the following:

- an indication on the employer’s voicemail;

- information on the employer’s website;

- a statement from the client.

After confirming that the business remains closed due to COVID-19, the agent documents the information on an SROC and continues processing the claim using the information on file.

**Integrity referrals**

Although the agent follows normal fact-finding procedures when trying to contact the employer for all ROE issues, the agent does not refer a WI to Integrity if the employer does not respond to the second Z-02-00-00 letter. Instead, the agent completes the WI with no further action. If there is any indication of a false ROE, the agent refers the issue to Integrity.

**Fact-finding for other issues**

When conducting fact-finding for any other issue, the agent makes one attempt to contact an employer. If the employer is not reached on the first attempt, the agent does not leave a message asking the employer to call back. Instead, the agent documents the attempt on an SROC and continues processing the claim using the information on file.

**Temporary process**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0988.dita) 

If the fact-finding is for an ROE, go to Fact-finding for ROE issues . If the fact-finding is for any other issue, go to Fact-finding for other issues .
       [Fact-finding for ROE issues](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/fact_find_covid19_update#FFforROEIssues) 
       [Fact-finding for other issues](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/fact_find_covid19_update#FFforOtherIssues)

**Fact-finding for ROE issues**

In NWS, create an SROC as follows:

- Main Issue: Select the appropriate issue or select Other (if the issue is not in the menu).

- Comments: Type “Simplification measure: attempt to contact employer — [employer’s name].”

- Details: Type “Unable to reach the employer on the first attempt. There is confirmation that [business name] is closed due to COVID-19. The business closure was confirmed by [how the closure was confirmed]. The claim is processed using the information on file.”

Non-complex: If the employer’s business remains closed because of COVID-19, do not send the Z-02-00-00 letter. Instead, document the information on an SROC and return to the initial task.

Level 1: If the employer’s business remains closed because of COVID-19, do not send the Z-02-00-00 letter. Instead, document the information on an SROC and try to resolve any issues with the client. Refer to interim ROE procedures to resolve the issues.

**Fact-finding for other issues**

Level 1: If the employer is not reached after the first attempt, do not send a Z-02-00-00 letter, just document the file with an SROC and try to resolve any issues with the client. Refer to Fact-finding and use the client’s statement to confirm the reason for separation (RFS), availability, earnings and any calculation or insurability issues.
       [Fact-finding](/en/procedure/task/fact_find.shtml)

Level 2: If the employer is not reached after the first attempt, do not send a Z-02-00-00 letter, just document the file with an SROC. Use the client’s statement to confirm the RFS or availability issues, and give the benefit of the doubt to the client, if necessary. Document in a record of decision (ROD) that simplification measures have been used. The Z-01-00-00 is still sent to the employer when allowing a work-related contentious RFS.

IPOC: If the employer is not reached after the first attempt, document the file with an SROC and return to the initial task.

Request for reconsideration: This measure also applies when processing a client’s request for reconsideration. 

### Warning

Source topic: `en_EN/common_notes/note_c_1023.dita`

**This page has been archived on the Web**

UPDATED: 2020-12-23 — The Headlines and Updates page has been archived because the temporary measures have been replaced by new measures. For more details, refer to Temporary simplification measures and fact-finding with employers — (Non-complex, Level 1 and Level 2) .
       [Temporary simplification measures and fact-finding with employers — (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_tsmffe.shtml)

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available.

     [Temporary simplification measures and fact-finding with employers — (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_tsmffe.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1024.dita`

Note:

This Headlines and Updates page was created on March 20, 2020 and has been updated as follows:

- July 22, 2020: Simplification measures for fact-finding with employers for ROE issues no longer apply. The agent refers to Fact-finding for all ROE issues, unless the business remains closed due to COVID-19.
         [Fact-finding](/en/procedure/task/fact_find.shtml)

     [Fact-finding](/en/procedure/task/fact_find.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0988.dita`

Note:

Procedures have not been updated. Refer to COVID-19 — Procedural changes for a table of affected procedures.
       [COVID-19 — Procedural changes](/en/procedure/generic/covidhu.shtml)

     [COVID-19 — Procedural changes](/en/procedure/generic/covidhu.shtml) 

## Summary Of Changes

Source topic: `en_EN/site/dossier/fact_find_covid19_update/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
