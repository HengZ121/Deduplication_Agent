# New and updated: Work-Sharing — Procedures and additional resources (Level 1, Level 2 and IPOC)

Source map: `en_EN/site/dossier/ws_procedures_ar/ws_procedures_ar.ditamap`

## Summary

Source topic: `en_EN/site/dossier/ws_procedures_ar/summary.dita`

The Work-Sharing activity has been updated to include 3 new tasks for processing agents. 

## Generic

Source topic: `en_EN/site/dossier/ws_procedures_ar/generic.dita`

New tasks:

- Modifying normal weekly hours on a Work-Sharing claim

- Allocating earnings from a Work-Sharing employer

- Actioning a permanent reason for separation on a Work-Sharing claim

The additional resource, Work-Sharing: Information on Work-Sharing claims processing — Knowledge, has been updated to include the GD mailboxes for the regional Work-Sharing (WS) coordinators, and the information in several sections has been enhanced. New templates have been created for communicating with IPOC in Allocating earnings from a Work-Sharing employer and Actioning a permanent reason for separation on a Work-Sharing claim. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/ws_procedures_ar/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
