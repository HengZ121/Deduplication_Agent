# Updated: Processing a separation from Work-Sharing employment — Task (IPOC)

Source map: `en_EN/site/dossier/maj-cessation-emploi-acc-tra-part-upd-s_b0e303f4/maj-cessation-emploi-acc-tra-part-upd-s_b0e303f4.ditamap`

## Summary

Source topic: `en_EN/site/dossier/maj-cessation-emploi-acc-tra-part-upd-s_b0e303f4/summary.dita`

The task Processing a separation from Work-Sharing employment has been updated to include instructions when an officer sends either an Operational Centre Memo (MM06) transaction or an IPOC Review (IPOC REV) WI if further IPOC action is required for the week in which a separation occurs and the reason for separation (RFS) has been adjudicated. 

## Generic

Source topic: `en_EN/site/dossier/maj-cessation-emploi-acc-tra-part-upd-s_b0e303f4/generic.dita`

## Summary of changes

Source topic: `en_EN/site/dossier/maj-cessation-emploi-acc-tra-part-upd-s_b0e303f4/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
