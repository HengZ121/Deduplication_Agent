# Referral to Integrity

Source map: `en_EN/site/dossier/update_ref_int/update_ref_int.ditamap`

## Summary

Source topic: `en_EN/site/dossier/update_ref_int/summary.dita`

When referring a file to Integrity, an MA71 is only input when the issue reported affects the client’s future entitlement to benefit. 

## Generic

Source topic: `en_EN/site/dossier/update_ref_int/generic.dita`

The procedure for imposing an MA71 has been modified following consultation with Integrity concerning WIs received about a potential voluntary disclosure.

When dealing with a potential voluntary disclosure, a manual action (MA) is input to prevent payment of future benefits on a continuing or renewal claim. The stop payment remains on file until a decision is made to allow or deny benefits. As the claim is referred to Integrity for further fact-finding, the MA code used is 71 - Integrity Services case . An MA71 is only imposed in cases where there is a reasonable likelihood that failure to impose stop payments will result in an overpayment.

Examples where an MA71 is not imposed:

- client declares a previous absence from Canada (client has returned to Canada and is available for work)

- client declares previous short-term training (client is no longer in school and is available for work)

- client declares a previous incarceration period (client is no longer in jail and is available for work)

- client declares earnings that will not be allocated to future weeks

Examples where an MA71 is always imposed:

- client declares a contentious reason for separation

- client declares a previous and ongoing availability issue (training, out of Canada, vacation, retirement, incarceration, etc.)

- client refuses employment 

## Summary Of Changes

Source topic: `en_EN/site/dossier/update_ref_int/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
