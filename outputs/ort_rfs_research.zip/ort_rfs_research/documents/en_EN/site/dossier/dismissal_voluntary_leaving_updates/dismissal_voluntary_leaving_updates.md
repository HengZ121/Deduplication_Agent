# Dismissal and Voluntary leaving: Updates

Source map: `en_EN/site/dossier/dismissal_voluntary_leaving_updates/dismissal_voluntary_leaving_updates.ditamap`

## Summary

Source topic: `en_EN/site/dossier/dismissal_voluntary_leaving_updates/summary.dita`

The Dismissal and Voluntary leaving tasks have been updated to include steps to take when a disqualification needs to be rescinded following a new decision. 

## Generic

Source topic: `en_EN/site/dossier/dismissal_voluntary_leaving_updates/generic.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Agents must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 10 - Dismissal - misconduct proven (D10) or 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the agent must rescind the D10 or D11 that is on file. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/dismissal_voluntary_leaving_updates/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
