# Updated: Deferred adjudication — No notification required — Procedures and additional resource (All levels)

Source map: `en_EN/site/dossier/maj_rep_dec_auc_avis_req-update_def_adj_ee5b496a/maj_rep_dec_auc_avis_req-update_def_adj_ee5b496a.ditamap`

## Summary

Source topic: `en_EN/site/dossier/maj_rep_dec_auc_avis_req-update_def_adj_ee5b496a/summary.dita`

During the ACS Letter Content Review process, the working group decided to remove all paragraphs from the D-01-00-00 letter in the ACS system that contained instructions to notify clients about deferred adjudication of contentious reason for separation (RFS) issues because there is no legislated requirement to notify clients of deferrals. Because deferring adjudication of an RFS is not a decision, for consistency and to improve client experience, all pages in the EI ORT have been updated and no longer direct officers to send a letter notifying clients of deferred adjudications. 

## Generic

Source topic: `en_EN/site/dossier/maj_rep_dec_auc_avis_req-update_def_adj_ee5b496a/generic.dita`

This update applies to deferred RFS adjudications for all benefit types (BTs). Officers still follow the guidance to document the deferral in a record of decision (ROD) in NWS when the criteria for deferral have been met, but they no longer need to update or create a letter.

Decisions clients must be notified about are listed in the Notice of decision: Requirements — Knowledge page.
       [Notice of decision: Requirements — Knowledge](/en/procedure/generic/additionalresources/notice_decision_ja.shtml)

If an officer has already drafted or sent a letter to print that includes the deferral information, these created letters can still be sent. However, no letters need to be created with information about a deferred adjudication from the time this update is published. 

## Summary of changes

Source topic: `en_EN/site/dossier/maj_rep_dec_auc_avis_req-update_def_adj_ee5b496a/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
