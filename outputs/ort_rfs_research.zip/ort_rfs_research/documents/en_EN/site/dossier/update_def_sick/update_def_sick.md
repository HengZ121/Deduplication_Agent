# Deferring adjudication (sickness benefits) procedures clarification

Source map: `en_EN/site/dossier/update_def_sick/update_def_sick.ditamap`

## Summary

Source topic: `en_EN/site/dossier/update_def_sick/summary.dita`

To defer adjudication of a contentious reason for separation (RFS) on an initial or renewal claim for sickness benefits, the agent must determine if the client is otherwise available for work. 

## Generic

Source topic: `en_EN/site/dossier/update_def_sick/generic.dita`

The procedures to defer adjudication on initial and renewal claims for sickness benefits were amended to clarify the availability requirement. There must be no indication that the client is not otherwise available for work. Adjudication cannot be deferred if the RFS implies that the client is not otherwise available for work. Fact-finding to clarify entitlement to sickness benefits may be required before the adjudication of the RFS can be deferred. 

## Summary of changes

Source topic: `en_EN/site/dossier/update_def_sick/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
