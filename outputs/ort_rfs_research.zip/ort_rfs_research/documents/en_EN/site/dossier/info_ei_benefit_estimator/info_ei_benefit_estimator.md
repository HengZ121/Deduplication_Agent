# Information: New online tool for clients — EI Benefits Estimator 101

Source map: `en_EN/site/dossier/info_ei_benefit_estimator/info_ei_benefit_estimator.ditamap`

## Summary

Source topic: `en_EN/site/dossier/info_ei_benefit_estimator/summary.dita`

On October 24, 2024, a new online tool for clients called the EI Benefits Estimator will be released. Officers may receive enquiries from clients regarding the new online tool. 

## Generic

Source topic: `en_EN/site/dossier/info_ei_benefit_estimator/generic.dita`

The EI Benefits Estimator helps clients to make informed decisions about applying for EI before submitting an application. This tool covers all benefit types (BTs). It also helps determine which BT might be right for clients, whether for their current or future situation, and helps estimate the weekly benefit rate and duration.

The EI Benefits Estimator:

- can be easily accessed on Canada.ca ;
         [Canada.ca](https://estimateurae-eiestimator.service.canada.ca/en)

- takes about 10 minutes to complete;

- uses simplified business rules and does not have access to the client’s file;

- is anonymous and no personal information is asked (including the SIN);

- does not save any information or results.

If it is determined that the client qualifies for benefits, the estimate of the client’s benefit rate and weeks of entitlement are shared with the client.

If it is determined that the client does not qualify for benefits, an explanation is given to the client.

In all cases, the client is advised of the following:

- The results are only estimates.

- Clients must apply to obtain a formal decision.

- The process to apply for benefits, with a link to AW.

- It is important to apply for EI immediately after ceasing work or after the earnings are reduced to avoid losing benefits.

- The EI application takes about one hour to complete.

- It is possible to return to the beginning and start a new estimate.

- The data used by the tool is updated regularly and results might change in the future.

When speaking with the client, the officer considers that the amount paid may differ from the estimated amount. The tool only provides an estimate and does not guarantee qualification and entitlement. Other factors that may affect the amounts are overpayments (OP), penalties on file, family supplement (FS), etc. Additionally, the regional rate of unemployment (RRU) produced by Statistics Canada can vary over time. The RRU (except for the territories) are seasonally adjusted 3-month-moving averages. Thus, the RRU retrieved when clients use the EI Benefits Estimator may differ from the RRU retrieved when clients submit an EI application. It is also possible that the information the client entered in the tool does not match actual figures in EI systems.  Several factors may affect a client’s qualification for benefits, including the reason for separation (RFS), a previous claim (in the last 12 months), availability, and insurability of employment.

The EI Benefits Estimator reviews the information that the client provided and uses the program’s rules to estimate the benefit rate and if the client qualifies for benefits. If the client has worked enough hours to meet those requirements, the tool estimates the number of weeks of benefits that can be received, as well as the benefit rate based on the earnings.

Furthermore, the information that is input into the EI Benefits Estimator is not linked to the client’s file and cannot be used in an EI application, or for an appeal of an EI decision.

The EI Benefits Estimator only estimates one BT per use. If the client wants to examine multiple BTs, the client must use the tool multiple times. However, if the client is estimating for maternity benefits, the results page will provide additional information about potential qualification for sickness and parental benefits, as these BTs often go together.

Training is available for officers in SABA:

- Course Name: Employment Insurance (EI) Benefits Estimator 101
         [Employment Insurance (EI) Benefits Estimator 101](https://esdc.sabacloud.com/Saba/Web_spf/CA1PRD0006/common/ledetail/cours000000000131630/latestversion)

- Course ID: 0000148919 

## Summary of changes

Source topic: `en_EN/site/dossier/info_ei_benefit_estimator/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
