# Archived: COVID-19 and deferral of adjudication on an EI Emergency Response Benefit claim

Source map: `en_EN/site/dossier/covid19_deferral_adjudication_eierbc/covid19_deferral_adjudication_eierbc.ditamap`

## Summary

Source topic: `en_EN/site/dossier/covid19_deferral_adjudication_eierbc/summary.dita`

Due to the COVID-19 situation, several system utilities are run to automatically process claims as EI Emergency Response Benefit claims. Therefore, when all criteria are met, deferral of adjudication is allowed on all contentious issues on claims for the EI Emergency Response Benefit. 

## Generic

Source topic: `en_EN/site/dossier/covid19_deferral_adjudication_eierbc/generic.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0991.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#archived)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0992.dita) 

**Table of contents**

- What you need to know
         [What you need to know](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#wyntk)

- Temporary process

- Fact-finding
             [Fact-finding](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#fact_finding)

- Record of decision (ROD) — Contentious reason for separation (RFS)
             [Record of decision (ROD) — Contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#rod_crs)

- Record of decision (ROD) — Interactive Adjudication (ADJ) WI
             [Record of decision (ROD) — Interactive Adjudication (ADJ) WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#rod_adj)

- Record of decision (ROD) — All other situations
             [Record of decision (ROD) — All other situations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#rod_aos)

- Additional actions required
             [Additional actions required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#Additional)

         [Temporary process](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#temp)

**What you need to know**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0993.dita) 

**Initial claims**

When the agent determines the client qualifies for an EI Emergency Response Benefit claim, adjudication is deferred on all contentious issues.

The system fully automates these claims when possible, deletes all related WIs and processes them as EI Emergency Response Benefit claims.

When the system is not able to automatically process a regular or sickness claim, the agent processes it normally. The agent:

- does not modify the ROEs to match the $500 per week benefit rate;

- does not input the 5 - Automation Utility - Canada Emergency Response Benefits or 6 - Reassessment Utility - Canada Emergency Response Benefits code (the system inputs it).

Since the system deletes all WIs when the claim is processed automatically as an EI Emergency Response Benefit claim, the agent can now defer adjudication if all the following criteria are met:

- the client requests regular or sickness benefits (includes situations when the client declares being pregnant);

- the tentative BPC is on March 8, 2020 or after;

- the last day worked (LDW) for the last period of employment is on or after June 21, 2019.

**Renewal or continuing claims**

When the agent determines that the claim is a renewal or continuing EI Emergency Response Benefit claim, adjudication is deferred on all contentious issues. The agent can identify these claims because they have an ERB Claim indicator in FTS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0994.dita) 

**Temporary process**

Note : Procedures have not been updated. Refer to COVID-19 — Procedural changes for a table of affected procedures. When all the above criteria are met, defer adjudication by following this temporary process.
       [COVID-19 — Procedural changes](/en/procedure/generic/covidhu.shtml)

**Fact-finding**

No fact-finding is required when deferring adjudication on a contentious issue based on this temporary measure.

**Record of decision (ROD) — Contentious reason for separation (RFS)**

When there is a Resolve Issue tab on the ADJ WI, the agent must not indicate that adjudication was deferred since the system will automatically impose a disqualification. In situations when the client qualifies for the EI Emergency Response Benefit, it is important that no disqualification be imposed on the file. Complete the ADJ WI as follows.

**Voluntary leaving or dismissal**

**Level 1**

- If the client voluntarily left the employment, in NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen by selecting the appropriate reason to allow the voluntary leave.

- If the client was dismissed, in NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Dismissal screen as follows:

- Select Based on the information on file, the criteria to allow the decision to be made at Level 1 have been met. The employer confirms the reason for separation was not due to any wrong-doing on the part of the client. (National Policy on Levels of Decision) .

- Click Continue .

- In both cases, create a separate ROD as follows:

- Comments: Type “COVID-19 — [employer name] — [LDW] — adjudication deferred.”

- Details: Type “The client is entitled to the EI Emergency Response Benefit. Adjudication deferred.”

- Go to Additional actions required .
         [Additional actions required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#Additional)

**Level 2**

- If the client voluntarily left the employment, in NWS, on the Resolve Issue tab of the ADJ WI, complete the Voluntary leaving screen as follows:

- Relevant Facts: Type “The client is entitled to the EI Emergency Response Benefit. Adjudication deferred.”

- Decision: Select Voluntary Leaving - Just cause shown .

- Written Notification: Select No .

- Click Continue .

- If the client was dismissed, in NWS, on the Resolve Issue tab of the ADJ WI, complete the Dismissed or Suspended screen as follows:

- Relevant Facts: Type “The client is entitled to the EI Emergency Response Benefit. Adjudication deferred.”

- Decision: Select Misconduct not proven .

- Written Notification: Select No .

- Click Continue .

- Go to Additional actions required .
         [Additional actions required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#Additional)

**Record of decision (ROD) — Interactive Adjudication Issue (ADJ) WI**

**Training**

**Level 1**

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Training screen as follows:

- Select Adjudication of training is not required .

- Click Continue .

- Explain why adjudication is not required : Type “The client is entitled to the EI Emergency Response Benefit.”

- Go to Additional actions required .
         [Additional actions required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#Additional)

**Level 2**

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Training is not an issue .

- Click Continue .

- Complete the Training is not an issue screen as follows:

- Relevant Facts: Type “The client is entitled to the EI Emergency Response Benefit.”

- Click Continue .

- Go to Additional actions required .
         [Additional actions required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#Additional)

**Self-employment (SE) or farming**

**Level 1**

- If the client has engaged in SE activities, in NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Self-employment screen as follows:

- Select The client’s engagement in self-employment activities ceased prior to the BPC .

- Enter the date that the client’s engagement in SE activities ceased (DD/MM/YYYY) : Enter the Friday before the BPC week.

- If the client has engaged in farming activities, in NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Farming screen as follows:

- Select The client’s engagement in farming activities ceased prior to the BPC .

- Enter the date that the client’s engagement in farming activities ceased (DD/MM/YYYY) : Enter the Friday before the BPC week.

- Create a ROD as follows:

- Comments: Type “COVID-19 — [contentious issue] — adjudication deferred.”

- Details: Type “The client is entitled to the EI Emergency Response Benefit. Adjudication deferred.”

- Go to Additional actions required .
         [Additional actions required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#Additional)

**Level 2**

- If the client has engaged in self-employment activities, in NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Self-employment screen as follows:

- Select Not engaged in self-employment .

- Click Continue .

- Complete the Not engaged in self-employment screen as follows:

- Relevant Facts: Type “The client is entitled to the EI Emergency Response Benefit. Adjudication deferred.”

- Click Continue .

- If the client has engaged in farming activities, in NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Farming screen as follows:

- Select Not engaged in farming .

- Click Continue .

- Complete the Not engaged in Farming screen as follows:

- Relevant Facts: Type “The client is entitled to the EI Emergency Response Benefit. Adjudication deferred.”

- Click Continue .

- Go to Additional actions required .
         [Additional actions required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/covid19_deferral_adjudication_eierbc#Additional)

**Record of decision (ROD) — All other situations**

- In all other situations, create a ROD as follows:

- Comments: Type “COVID-19 — [contentious issue] — adjudication deferred.”

- Details: Type “The client is entitled to EI Emergency Response Benefit. Adjudication deferred.”

**Additional actions required**

- Determine if the ADJ WI is for a contentious RFS:

- If yes, go to step 2.

- If no, go to step 4.

- Create a Reminder (REM) WI as follows:

- Send to my pending workload: Check the box.

- Pending reason: Select Other .

- Comments: Type “Waiting for the claim to be finalized.”

- Once the claim has been finalized, modify the Special condition field on the ROE as follows:

- If the adjudication was deferred on a revised claim, in FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Click Update . 

### Warning

Source topic: `en_EN/common_notes/note_c_0991.dita`

**This page has been archived on the Web**

UPDATED: 2021-02-03 —The Headlines and Updates page has been archived because the information is outdated. EI ERB ended on September 27, 2020.

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available. 

### Note

Source topic: `en_EN/common_notes/note_c_0992.dita`

Note:

This Headlines and Updates page was created on May 21, 2020 and has been updated as follows:

- June 15, 2020: The Temporary process section has been updated with details on the different options for Level 1 and Level 2 agents when completing the Resolve Issue tab on an Adjudication Issue (ADJ) WI for contentious issues. The What you need to know section has been updated with new information indicating that this process only applies to EI Emergency Response Benefit initial, renewal or continuing claims.

- February 3, 2021: This page is now archived. 

### Note

Source topic: `en_EN/common_notes/note_c_0993.dita`

Note:

This temporary process does not apply to work permit or 900-series SIN situations. The agent refers to Updated: COVID-19 and work permits for 900-series SIN — Procedures for actions to take in these situations.
       [Updated: COVID-19 and work permits for 900-series SIN — Procedures](/en/site/dossier/updated_covid19_work_permit_900_sin.shtml)

     [Updated: COVID-19 and work permits for 900-series SIN — Procedures](/en/site/dossier/updated_covid19_work_permit_900_sin.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0994.dita`

Note:

The agent continues to follow normal procedures for determining if the adjudication of a contentious issue can be deferred on all other initial, renewal and continuing claims for EI benefits with a BPC before March 15, 2020. 
