# New: Recalculation Assessment Instructions — Additional resource (Level 1)

Source map: `en_EN/site/dossier/new_recalculat_assess/new_recalculat_assess.ditamap`

## Summary

Source topic: `en_EN/site/dossier/new_recalculat_assess/summary.dita`

The additional resource Recalculation: Assessment — Instructions has been created to guide officers through the recalculation process and to help prevent unnecessary work. This additional resource indicates the order in which an officer reviews a recalculation, and the officer uses it along with the appropriate EI ORT procedures. 

## Generic

Source topic: `en_EN/site/dossier/new_recalculat_assess/generic.dita`

The officer completing a recalculation reviews the new information on file and compares it to the information used in the previous calculation to determine the changes to expect.

For a BPNE claim, the officer verifies if missing or additional information is now on file to determine if the recalculation is required.

For an established claim, the officer makes an initial calculation in SSA with the new information, then compares the previous and new calculation results. The differences between the 2 calculation results determine the next required steps for the recalculation.

The additional resource includes instructions for situations in which a contentious issue is identified in a recalculation. The officer must confirm if the contentious issue requires adjudication:

- If the contentious issue is in the qualifying period (QP) and the claim is established, the issue must be adjudicated and the officer creates a Claim Review (CR) WI.

- If the contentious issue is in the QP but the client does not have enough hours to qualify for benefits after the claim is recalculated, the officer does not create a CR WI.

- If the contentious issue is in the benefit period (BP) of the claim being recalculated, the officer processes the recalculation and does not wait for the issue to be adjudicated.

The additional resource also includes instructions for situations in which a ROE with a contentious reason for separation (RFS) overlaps the BPC and there was an excluded ROE in the QP of the initial calculation.

The recalculation process is different from the process of calculating an initial claim. Therefore, the officer uses this resource as a guide to review and process a recalculation, and not as a guide for an initial calculation. The officer refers to the calculation procedures and Recalculation input guide - SSA version , if necessary, while following the steps in this resource.
       [Recalculation input guide - SSA version](https://esdc.prv/en/service-canada/ei/technologies/bps/recalculation_input_guide.shtml) 

## Summary of changes

Source topic: `en_EN/site/dossier/new_recalculat_assess/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
