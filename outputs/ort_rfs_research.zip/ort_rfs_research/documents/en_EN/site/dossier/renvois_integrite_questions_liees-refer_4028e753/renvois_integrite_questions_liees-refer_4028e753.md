# Updated: Referrals to Integrity — Undisclosed contentious reason for separation issues — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/renvois_integrite_questions_liees-refer_4028e753/renvois_integrite_questions_liees-refer_4028e753.ditamap`

## Summary

Source topic: `en_EN/site/dossier/renvois_integrite_questions_liees-refer_4028e753/summary.dita`

Based on feedback from national partners, procedures have been updated to provide information to Level 1 and Level 2 officers on undisclosed contentious reason for separation (RFS) issues and when those issues must be referred to integrity. 

## Generic

Source topic: `en_EN/site/dossier/renvois_integrite_questions_liees-refer_4028e753/generic.dita`

Clarifications have been added in the What you need to know and Step by step sections of appropriate Level 1 and Level 2 procedures. This addition is to ensure that the officer reviews a file for situations in which a contentious RFS was undisclosed on a previous claim, and a potential overpayment (OP) situation exists. The officer refers to the task Determining if an issue must be referred to Integrity to determine if the contentious RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

The following procedures have been updated:

- Reviewing an outstanding issue with no Adjudication Issue WI
         [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Adjudicating voluntary leaving: Renewal claim — Level 2
         [Adjudicating voluntary leaving: Renewal claim — Level 2](/en/procedure/task/vllevel2_rc.shtml)

- Adjudicating voluntary leaving: Continuing claim — Level 2
         [Adjudicating voluntary leaving: Continuing claim — Level 2](/en/procedure/task/voluntary_leaving_l2.shtml)

- Adjudicating voluntary leaving (Level 1): Referred training or employment activity — Renewal
         [Adjudicating voluntary leaving (Level 1): Referred training or employment activity — Renewal](/en/procedure/task/vllevel1_coi_renewal.shtml)

- Adjudicating voluntary leaving (Level 1): Referred training or employment activity — Continuing claim
         [Adjudicating voluntary leaving (Level 1): Referred training or employment activity — Continuing claim](/en/procedure/task/voluntary_leaving_course_l1.shtml)

- Adjudicating voluntary leaving (Level 1): Other employment — Renewal claim
         [Adjudicating voluntary leaving (Level 1): Other employment — Renewal claim](/en/procedure/task/vllevel1_oe_rc.shtml)

- Adjudicating voluntary leaving (Level 1): Other employment — Continuing claim
         [Adjudicating voluntary leaving (Level 1): Other employment — Continuing claim](/en/procedure/task/voluntary_leaving_other_employment_l1.shtml)

- Adjudicating voluntary leaving (Level 1): Medical reasons — Renewal claim
         [Adjudicating voluntary leaving (Level 1): Medical reasons — Renewal claim](/en/procedure/task/vllevel1_mr_rc.shtml)

- Adjudicating voluntary leaving (Level 1): Medical reasons — Continuing claim
         [Adjudicating voluntary leaving (Level 1): Medical reasons — Continuing claim](/en/procedure/task/voluntary_leaving_medical_reason_l1.shtml)

- Adjudicating voluntary leaving (Level 1): Following another individual — Renewal claim
         [Adjudicating voluntary leaving (Level 1): Following another individual — Renewal claim](/en/procedure/task/vllevel1_fai_rc.shtml)

- Adjudicating voluntary leaving (Level 1): Following another individual — Continuing claim
         [Adjudicating voluntary leaving (Level 1): Following another individual — Continuing claim](/en/procedure/task/voluntary_leaving_another_individual_l1.shtml)

- Adjudicating voluntary leaving (Level 1): Workforce reduction — Renewal claim
         [Adjudicating voluntary leaving (Level 1): Workforce reduction — Renewal claim](/en/procedure/task/vl_wr_rc.shtml)

- Adjudicating voluntary leaving (Level 1): Workforce reduction — Continuing claim
         [Adjudicating voluntary leaving (Level 1): Workforce reduction — Continuing claim](/en/procedure/task/voluntary_leaving_work_reduction_l1.shtml)

- Adjudicating a leave of absence — Level 1
         [Adjudicating a leave of absence — Level 1](/en/procedure/task/voluntary_leaving_loa.shtml)

- Adjudicating a leave of absence — Level 2
         [Adjudicating a leave of absence — Level 2](/en/procedure/task/adjudicating_loa_l2.shtml)

- Adjudicating a dismissal for unsuitability — Renewal claim
         [Adjudicating a dismissal for unsuitability — Renewal claim](/en/procedure/task/dismissal_rc.shtml)

- Adjudicating a dismissal for unsuitability — Continuing claim
         [Adjudicating a dismissal for unsuitability — Continuing claim](/en/procedure/task/dismissal_cc.shtml)

- Adjudicating a dismissal or suspension — Renewal claim
         [Adjudicating a dismissal or suspension — Renewal claim](/en/procedure/task/dismissal_ds_rc.shtml)

- Adjudicating a dismissal or suspension — Continuing claim
         [Adjudicating a dismissal or suspension — Continuing claim](/en/procedure/task/dismissal_ds.shtml) 

## Summary of changes

Source topic: `en_EN/site/dossier/renvois_integrite_questions_liees-refer_4028e753/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
