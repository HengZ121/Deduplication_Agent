# Information: Update on Flooding and fires — Western Canada and Territories region (Spring 2018)

Source map: `en_EN/site/dossier/information_flooding_fires_wctr_2018/information_flooding_fires_wctr_2018.ditamap`

## Summary

Source topic: `en_EN/site/dossier/information_flooding_fires_wctr_2018/summary.dita`

Updated June 6, 2018 — Information is now in the Major Employer Events database.

Emergency measures have been adopted to assist clients affected by flooding or fires in the Western Canada and Territories region. These changes apply only to clients who are affected by the flooding or fires in the Western Canada and Territories region. 

## Generic

Source topic: `en_EN/site/dossier/information_flooding_fires_wctr_2018/generic.dita`

[Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1108.dita) 

**Reference codes**

Reference codes have been issued to facilitate the processing of claims for clients that are affected by flooding or fires.

Reference codes for clients who are affected by the flooding.

```text
| Region | Reference code |

| Alberta | 4812-01-4812-002018 |

| British Columbia | 5910-01-5910-002018 |

| Manitoba | 4317-01-4317-002018 |

| Saskatchewan | 4317-01-4317-002018 |

| Western Canada and Territories | 4813-01-4813-002018 |
```

Reference codes for clients who are affected by fires.

```text
| Region | Reference code |

| Alberta | 4812-01-4812-201800 |

| British Columbia | 5986-01-5986-598600 |

| Manitoba | 4317-01-4317-431700 |

| Saskatchewan | 4317-01-4317-431700 |

| Western Canada and Territories | 4813-01-4813-481300 |
```

Applications must be submitted using the appropriate reference code according to the region where the client resides.

Only clients requesting regular benefits can use these reference codes. Clients requesting special benefits cannot use these reference codes.

**Client’s address**

Clients’ mailing address must be updated to their current mailing address. If clients have been temporarily displaced because of the flooding or fires, they can enter their temporary address in the mailing address field. This temporary mailing address could be a hotel, a shelter, etc.

**Mail delivery**

If clients need more information about mail delivery, they can refer to the Canada Post website or call 1-888-550-6333.
       [Canada Post](https://www.canadapost.ca/web/en/blogs/announcements/list.page?cattype=announcements&cat=servicealerts)

**Interim ROEs**

Since employers may not be able to issue ROEs, an interim ROE must be created as soon as possible for affected clients.

**Direct deposit**

Clients may need to have their direct deposit information updated. If agents are in contact with an affected client, they must always make sure the direct deposit information on file is correct.

**Reason for separation (RFS)**

If the client is involuntarily no longer working because of the mandatory evacuation, or because the business closed due to the flooding or fires, the RFS is considered non-contentious and can be allowed at Level 1. However, if a client has quit or taken a leave of absence because of the flooding, a Level 2 agent must adjudicate. Normal adjudication principles must be followed to determine if the client had a reasonable alternative to quitting or taking a leave of absence.

**Availability**

A client’s availability is not addressed on the application. Therefore, the availability of affected clients can be allowed at Level 1 unless there is additional information on file that indicates the client may not be available. Normal adjudication principles must be followed. However, the Level 2 agent must take into account each client’s personal circumstances when adjudicating availability. A client should not be refused benefits if the emergency situation is the sole reason for the non-availability.

**Claimant’s report**

Agents must obtain any missing claimant’s report information whenever they are in contact with an affected client. 

### Info

Source topic: `en_EN/common_notes/note_c_1108.dita`

**Note:**

The agent must check the Major Employer Events database for the most current information as changes are ongoing. 

## Summary of changes

Source topic: `en_EN/site/dossier/information_flooding_fires_wctr_2018/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
