# Updated: Adjudicating an Integrity case — Undeclared reason for separation — Procedures (Level 2)

Source map: `en_EN/site/dossier/upd-adj-an-int-case/upd-adj-an-int-case.ditamap`

## Summary

Source topic: `en_EN/site/dossier/upd-adj-an-int-case/summary.dita`

Based on regional feedback, the sections of the Integrity case procedures related to undeclared reason for separation (RFS) issues have been clarified. 

## Generic

Source topic: `en_EN/site/dossier/upd-adj-an-int-case/generic.dita`

Relevant tasks have been updated to clarify the application of EIA 38(1) when a client fails to report an employment and therefore, is not asked the RFS on the EI application or on their electronic claimant’s report. The client’s failure to report employment is not considered to be a knowingly made false statement related to the RFS. In such cases, misrepresentation may only be found if there is a separate false statement knowingly made for the issue.

Tasks have also been updated to clarify the EIA 52 reconsideration timeframes. A false statement associated with each issue under reconsideration is not required to extend the period to 72 months for all issues. For example, a false statement stemming from a failure to report earnings will extend the reconsideration time period for all issues detected. Therefore, the RFS is adjudicated at the same time as the undeclared earnings, even if one of the issues is outside of the 36 month timeframe. 

## Summary of changes

Source topic: `en_EN/site/dossier/upd-adj-an-int-case/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
