# Archived: Updated: COVID-19 and antedating an EI Emergency Response Benefit claim — Policy and procedures (Level 1, Level 2 and IPOC)

Source map: `en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589/updated_covid19_antedating_ei_emergency_d3418589.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589/summary.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0826.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589#archived)

New interim orders that amend the EIA to help agents administer the EI Emergency Response Benefit (EI ERB) have been created. These changes may prompt antedate requests. In alignment with policy, the procedures for processing antedates for EI ERB claims have been updated. 

### Warning

Source topic: `en_EN/common_notes/note_c_0826.dita`

**This page has been archived on the Web**

UPDATED: 2022-04-12 — The Headlines and Updates page has been archived because the information is outdated.

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available. 

## Generic

Source topic: `en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589/generic.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1198.dita) 

**Table of Contents**

- What You Need To Know
         [What You Need To Know](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589#wyntk)

- Temporary process

- Level 1 — Antedate to a BPC within the EI Emergency Response Benefit (EI ERB) period
             [Level 1 — Antedate to a BPC within the EI Emergency Response Benefit (EI ERB) period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589#Level_1_bpc_within)

- Level 1 — Antedate to a BPC before the EI Emergency Response Benefit (EI ERB) period
             [Level 1 — Antedate to a BPC before the EI Emergency Response Benefit (EI ERB) period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589#Level_1_bpc_before)

- IPOC — The new BPC is between w/c 2230 and 2258
             [IPOC — The new BPC is between w/c 2230 and 2258](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589#IPOC_new_between)

- IPOC — The new BPC is before w/c 2230
             [IPOC — The new BPC is before w/c 2230](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589#IPOC_new_before)

         [Temporary process](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589#steps)

**What You Need To Know**

Clients who delay filing a claim for benefits, but who want their claims to begin at an earlier date, must request an antedate. When determining the BPC of a claim, agents use the administrative rule in all cases. However, there is no requirement that clients must apply for the EI ERB in a timely manner. Therefore, the client is not required to prove good cause for the delay when requesting an antedate between March 15, 2020 and October 3, 2020. However, clients need to qualify for the EI ERB from the date they want their claim to start. The EI ERB is payable up to and including the week ending October 3, 2020. However, no EI ERB claim can be established with a BPC on or after September 27, 2020. Any claim established with a BPC on or after September 27, 2020 is processed as a claim for EI benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1199.dita) 

For clients who want to antedate their claim to a date before March 15, 2020, agents use normal antedate procedures. These clients are required to show good cause for the delay in applying.

Agents who receive antedate requests for the EI ERB review the claim and the potential advantages and disadvantages of the antedate with the client. This includes, but is not limited to, potential OPs that can result when antedating a claim to a BPC earlier than March 15, 2020 including the $2 000 initial payments that were made. BPCs established before the EI ERB period are subject to normal EI benefit rates, waiting periods (WPs) and legislation. The agent also obtains any claimant’s report information for the antedate period. Once adjudication is completed, the agent determines whether the antedate can be processed in FTS or if an Operational Centre Memo (MM06) transaction is required to have an IPOC agent process the antedate in purge and recreate (P/R).

Antedates to a BPC before March 15, 2020 (w/c 2230) (e.g. March 22 [w/c 2231] to March 01 [w/c 2228]) will be rejected in FTS with error code C173 and can only be completed by an IPOC agent in P/R. If there is a D65 on the file, the agent must identify it in the request to IPOC to have it removed. If the initial $2 000 payment was issued, the agent must also request in the MM06 that IPOC assess it for a possible OP.

If the client is requesting to antedate a claim to an earlier date that is still within the EI ERB period (i.e. March 22 [w/c 2231] to March 15 [w/c 2230]) the agent can process the antedate transactions in FTS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1200.dita) 

**Temporary process**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0988.dita) 

**Level 1 — Antedate to a BPC within the EI Emergency Response Benefit (EI ERB) period**

Effective immediately, agents complete antedates for claims that display 5 - COVID-19 Automation Utility or 6 - COVID-19 Reassessment Utility in the Supplementary Claim Information field on a Renewal/Revised (M106) transaction in FTS .

If there is no registration number, the agent assigns a revised number in FTS and completes the M106 as follows:

- BPC: Enter the antedated BPC (cannot be before w/c 2230).

- Insured Earnings: Enter the earnings as shown on the claim.

- Divisor: Enter the divisor as shown on the claim.

- Cut off date: Enter the antedated BPC – 52 weeks or the previous BPC, whichever is later.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Detection: Select 23 - Recalculation - postdating or antedating .

- Infraction: Select C - Non-fraud - Insurability - new information .

- Message: Select 38 - An overpayment resulted due to a change in the start of your claim .

- Select Update .

If the system rejects the transaction with error code C261 , the agent checks the Regional Rates screen in FTS to identify the correct divisor for the antedated BPC. The agent enters this number on the M106 and changes the insured earnings amount to the new divisor × $909.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1201.dita) 

**Level 1 — Antedate to a BPC before the EI Emergency Response Benefit (EI ERB) period**

Effective immediately, agents complete Operational Centre Memo (MM06) transactions for claims that display 5 - COVID-19 Automation Utility or 6 - COVID-19 Reassessment Utility in the Supplementary Claim Information field as follows:

- BPC: Select the BPC of the claim requiring the claimant’s report to be input.

- Work item: Select 92 - Purge and Recreate .

- Work type: Select 20 - Benefit period commencement change .

- Remarks line 1: Type “Error C [XXX] — Antedate BPC from [XXXX] to [XXXX].”

- to [XXXX].”

- Remarks lines 2 and 3 : Type “M106 BPC [XXXX], INS HRS [XXXX], INS EARNINGS [XXXXX], DIV WK [XX], COD [XXXX], ERN WK 1 [XXXX], LFA [XX], WP [served, deferred or waived], SCI [5, 6 or blank], RFS [X], EMPLOYER [XXXXXXXXXRPXXX], rescind D65s. Determine if the initial $2 000 payment requires amending.

- Remarks line 4: Provide the M151 or M152 claimant’s report between the new and old BPCs.

- Remarks line 5: Enter your name and telephone number.

- Detection: Select 23 - Recalculation - postdating or antedating .

- Infraction: Select C - Non-fraud - Insurability - new information .

- Message: Select 38 - An overpayment resulted due to a change in the start date of your claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

Once completed, agents create a Reminder (REM) WI for themselves and move it to Pending until next business day. The NWS WI will be generated during the overnight processing run. Agents are responsible for marking that WI as urgent .

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1202.dita) 

**IPOC — The new BPC is between w/c 2230 and 2258**

- For claims with 5 - COVID-19 Automation Utility in the Supplementary claim information field, do the following:

- In FTS, complete the File Control Data (M101) type 8 (M101-8) or Multiple Files Control Data (T111) type 8 (T111-8) transaction to temporarily remove the claim from CPS and change the status to 99 - Purge/Recreate .

- In APRS, change the BPC as requested on the Operational Centre Memo (MM06) transaction.

- Change the entitlement weeks to 29 on the TC81-2 trailer (card column 12).

- Leave 5 - COVID-19 Automation Utility in the Supplementary claim information field on the TC81-2 trailer (card column 43) .

- Leave 65 - Lump Sum Payment ($2000) - Canadian Emergency Response in the Disentitlement field on the TC82-2 or TC82-3 trailer.

- Insert all weeks before the original BPC:

- Include earnings only when associated with a FWW or a found work.

- Include training declarations only for referred training.

- Do not include sick days and not available days.

- After the P/R upload, review the Mini as soon as it is available to ensure it reflects the desired results.

- Input an amended claimant’s report for the weeks inserted before the original BPC to issue payment.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1203.dita)

- For claims with 6 - COVID-19 Reassessment Utility in the Supplementary claim information field, do the following:

- In FTS, complete the M101-8 or T111-8 transaction to temporarily remove the claim from CPS and change the status to 99 - Purge/Recreate .

- In APRS, change the BPC as requested on the Operational Centre Memo (MM06) transaction.

- In FTS, verify the divisor on the Regional Rates screen for the new BPC to see if it differs from the current divisor on the claim.

- In APRS, change the divisor to match the divisor from the FTS Regional Rates screen for the new BPC, if necessary.
             [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1204.dita)

- If the divisor was modified, change the insured earnings to equal the new divisor x $909. This creates a benefit rate of $500.

- Change the entitlement weeks to 29 on the TC81-2 trailer (card column 12).

- Leave 6 - COVID-19 Reassessment Utility in the Supplementary claim information field on the TC81-2 trailer (card column 43) .

- Leave 65 - Lump Sum Payment ($2000) - Canadian Emergency Response in the Disentitlement field on the TC82-2 or TC82-3 trailer.

- Insert all weeks before the original BPC:

- Include earnings only when associated with a FWW or a found work.

- Include training declarations only for referred training.

- Do not include sick days and not available days.

- After the P/R upload, review the Mini as soon as it is available to ensure it reflects the desired results.

- Input an amended claimant’s report for the weeks inserted before the original BPC to issue payment.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1205.dita)

**IPOC — The new BPC is before w/c 2230**

- For claims with 5 - COVID-19 Automation Utility or 6 - COVID-19 Reassessment Utility in the Supplementary claim information field, do the following:

- In FTS, complete the M101-8 or T111-8 transaction to temporarily remove the claim from CPS and change the status to 99 - Purge/Recreate .

- From the Enquiry menu, open and review the Emergency Response Benefits screen to determine if the initial $2 000 payment was issued.

- If the payment was issued and there is no additional Operational Centre Memo (MM06) transaction with a request to cancel the initial $2 000 payment, establish an OP as follows:

- In PSCD, select the Create Debt transaction and complete the appropriate fields. For more information on establishing a debt in PSCD, refer to Creating a debt in PSCD .
                 [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1206.dita) 
                 [Creating a debt in PSCD](/en/procedure/task/creating_a_debt_in_pscd.shtml)

- In FTS, select the Emergency Response Lump Sum Payment Modification transaction from the IPOC menu. Then, update the Lump sum payment modification field as follows:

- Lump sum payment modification: Select D - Established as overpayment . If necessary, refer to COVID-19: Emergency Response Lump Sum Payment Modification – Knowledge for more information.
                     [COVID-19: Emergency Response Lump Sum Payment Modification – Knowledge](/en/procedure/generic/covid19_emergency_response_lump_sump_payment_modification_knowledge.shtml)

- Select Update .

             [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1207.dita)

- In APRS, change the BPC, insured hours, insured earnings, divisor and cut-off date (COD) as requested on the Operational Centre Memo (MM06) transaction.

- Update the WP as requested on the Operational Centre Memo (MM06) transaction, if necessary.

- Update other claim changes as requested on the Operational Centre Memo (MM06) transaction, if necessary.

- Remove the 5 - COVID-19 Automation Utility or 6 - COVID-19 Reassessment Utility code from the Supplementary claim information field on the TC81-2 trailer (card column 43).

- Remove all D65s.

- Insert all weeks before the original BPC, coding earnings, sick days, not available days and training declarations as provided on the Operational Centre Memo (MM06) transaction.

- After the P/R upload, review the Mini as soon as it is available to ensure it reflects the desired results.

- Input an amended claimant’s report for the weeks inserted before the original BPC to issue payment.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1208.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_1198.dita`

Note:

This Headlines and Updates page was created on April 22, 2020 and has been updated as follows:

- May 12, 2020 — The page was updated to include policy changes to the EI ERB and to explain the antedate situations that agents can now process in FTS.

- May 20, 2020 — Only the IPOC section was updated to clarify that a full work week (FWW) or found work is coded on EI ERB claims.

- June 9, 2020 — The Level 1 instructions for antedating the BPC within the EI ERB period have been updated to correct how the agent determines the cut-off date (COD).

- June 12, 2020 — Because of a recent policy interpretation, the information in the What You Need to Know section has been updated to advise agents that the client does not need to show good cause when requesting an antedate on EI ERB claims. For more information, agents refer to updated EI ERB — BE 2020-04 (BE Memo) .
         [EI ERB — BE 2020-04 (BE Memo)](/en/policy/bememo/be2020-04.shtml)

- July 22, 2020 — The page was updated to include information on how to complete the Operational Centre Memo (MM06) transaction when a claim is antedated to a BPC before EI ERB period and a 65 - Lump Sum Payment ($2000) - Canadian Emergency Response (D65) code is on the file.

- August 24, 2020 — The page was updated to provide information on establishing an overpayment (OP) for the initial $2 000 payment, if necessary.

- September 8, 2020 — The page was updated to provide information on how to complete the MM06 when the claim is antedated to a period prior to the EI ERB claim.

- November 6, 2020 — The page was updated to clarify that a client has until December 2, 2020, to request the EI ERB for any week between March 15, 2020, and October 3, 2020. As of December 3, 2020, clients can only apply for EI or for one of the Canada recovery benefits.

- December 15, 2020 — The IPOC — The new BPC is before w/c 2230 section was updated to include the instructions for establishing an OP in DARS for the initial $2 000 payment with the new OP message code 146 .

- January 5, 2020 — The OP message code 146 is now available in the drop-down menu of the EI Account Establishment (DE013) screen in DARS.

- June 19, 2021 ­— The IPOC agent can modify the Lump sum payment modification field on the Emergency Response Lump Sum Payment Modification transaction ( more information ).
         [more information](/en/site/dossier/new_updated_emergency_response_benefits_screen_procedure_ar.shtml)

     [EI ERB — BE 2020-04 (BE Memo)](/en/policy/bememo/be2020-04.shtml) 
     [more information](/en/site/dossier/new_updated_emergency_response_benefits_screen_procedure_ar.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1199.dita`

Note:

The client has until December 2, 2020 to request an antedate for any week between March 15, 2020 and October 3, 2020. As of December 3, 2020, antedate requests for EI ERB claims are not accepted. The client must apply for EI or for one of the Canada recovery benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_1200.dita`

Note:

There may be situations unrelated to COVID-19 that prevent the antedate from being processed in FTS. Agents must be aware of other error codes and action those appropriately. 

### Note

Source topic: `en_EN/common_notes/note_c_0988.dita`

Note:

Procedures have not been updated. Refer to COVID-19 — Procedural changes for a table of affected procedures.
       [COVID-19 — Procedural changes](/en/procedure/generic/covidhu.shtml)

     [COVID-19 — Procedural changes](/en/procedure/generic/covidhu.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1201.dita`

Note:

- These instructions are only for claims:

- Leave all other fields blank.

- Input all claimant’s reports from the antedated BPC to the original BPC on the day the M106 is transmitted.

- Omit all earnings, sick days, not available days and training declarations (except referred training) on the Electronic Claimant’s Report — Pay Coding (M153) transaction. 

### Note

Source topic: `en_EN/common_notes/note_c_1202.dita`

Note:

- These instructions are only for claims:

- with a BPC of w/c 2230 to 2258 that are being antedated to a new BPC before w/c 2230 or;

- with a BPC that CPS would reject (e.g. error code C777). These claims can be within the EI ERB time frame, but since the antedated BPC is already on the Dormant tab, an IPOC agent processes them in P/R. Agents must be aware of other situations that may require an IPOC agent to process the antedate in P/R. Do not include “rescind D65” or “determine if the initial $2 000 payment requires amending” when the BPC remains between w/c 2230 and w/c 2258.

- that have 5 - COVID-19 Automation Utility or 6 - COVID-19 Reassessment Utility in the Supplementary claim information field.

- If the claim displays 5 - COVID-19 Automation Utility , the agent cannot register a recalculation in SSA because there is no claim to recalculate. The workaround is to register an initial claim, input the data to obtain a calculation result for the desired BPC, and send the file to IPOC on an Operational Centre Memo (MM06) transaction.

- When the new BPC is before the EI ERB period (e.g. w/c 2229), the agent removes the code from the Supplementary claim information field. Processing agents include this information on the Operational Centre Memo (MM06) transaction.

- To avoid payment delays, if possible, the agent processes available weeks from the original BPC onward in CPS on the day the Operational Centre Memo (MM06) transaction is created. This issues payment to the client and leaves only the weeks between the old and new BPCs to be processed in P/R. 

### Note

Source topic: `en_EN/common_notes/note_c_1203.dita`

Note:

For claims with code 5 - COVID-19 Automation Utility in the Supplementary claim information field, the agent leaves the code as is. If deleted in error, the claim will need to be re-purged to add the 5 - COVID-19 Automation Utility code.

During a manual update, CPS re-evaluates the D65 when weeks have been added at the beginning of an EI ERB claim. CPS imposes the first D65 after the 12th week paid, and the second D65 after the 17th week paid. This may result in one of the D65s being moved and an OP being established. 

### Note

Source topic: `en_EN/common_notes/note_c_1204.dita`

Note:

For claims with regional rate of unemployment (RRU) of 13.1% or more, the divisor 14 does not need to be changed. 

### Note

Source topic: `en_EN/common_notes/note_c_1205.dita`

Note:

During a manual update, CPS re-evaluates the D65 when weeks have been added at the beginning of an EI ERB claim. CPS imposes the first D65 after the 12th week paid, and the second D65 after the 17th week paid. This may result in one of the D65s being moved and an OP being established. 

### Note

Source topic: `en_EN/common_notes/note_c_1206.dita`

Note:

When establishing an OP in PSCD for the initial $2 000 payment, select the contract object type ERB2 - CERB Advance Payment and the OP message code 46 - You are no longer entitled to the advanced payment of Canada Emergency Response Benefits you have received. This caused an overpayment . The IPOC agent manually rescinds the D65 from the EI ERB claim and applies the underpayment (UP) to the OP using a Claimant’s Reports (T072) transaction in FTS as a recoupment. 

### Note

Source topic: `en_EN/common_notes/note_c_1207.dita`

Note:

An OP is not required if there is another Operational Centre Memo (MM06) transaction requesting that the initial $2 000 payment be cancelled. 

### Note

Source topic: `en_EN/common_notes/note_c_1208.dita`

Note:

The agent always waives the WP on EI ERB claims. A client who wants to antedate the claim to a new BPC before w/c 2230 may have to serve the WP. The agent includes the WP details for the new BPC on the Operational Centre Memo (MM06) transaction. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_covid19_antedating_ei_emergency_d3418589/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
