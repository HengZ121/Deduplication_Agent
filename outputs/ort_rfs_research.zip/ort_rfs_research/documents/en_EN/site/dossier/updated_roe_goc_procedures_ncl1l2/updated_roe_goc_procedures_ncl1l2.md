# Archived: Updated: ROE issued by the Government of Canada — Procedures (Non-complex, Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_roe_goc_procedures_ncl1l2/updated_roe_goc_procedures_ncl1l2.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_roe_goc_procedures_ncl1l2/summary.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1189.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/site/dossier/updated_roe_goc_procedures_ncl1l2#archived)

A direct telephone line is being introduced to address ongoing difficulties with conducting fact-finding for ROEs issued from Government of Canada departments serviced by the Public Service Pay Centre . The new procedure is being implemented one region at a time.
       [Government of Canada departments serviced by the Public Service Pay Centre](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html) 

### Warning

Source topic: `en_EN/common_notes/note_c_1189.dita`

**This page has been archived on the Web**

UPDATED: 2024-08-02 — This page has been archived because the information is outdated.

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available. 

## Generic

Source topic: `en_EN/site/dossier/updated_roe_goc_procedures_ncl1l2/generic.dita`

[Attention](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1266.dita) 
     [Attention](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1267.dita) 

A new procedure has been developed for agents to conduct fact-finding with the Public Service Pay Centre. Once it is implemented in a region, agents in that region can verify ROE information using the direct telephone line. This procedure replaces the current email fact-finding procedure for Government of Canada ROEs.

**Contacting the Public Service Pay Centre**

Agents contact the Public Service Pay Centre’s Client Contact Centre at 1-855-686-4729 between 7am and 7pm EST, select their preferred language and press 5 on the keypad.

Note: Although 5 is not listed in the options menu, by pressing it, the agent is directed to a pay liaison unit officer, who is dedicated to assisting Service Canada with ROE corrections.

The agent may be put on hold before the call is connected. Before initiating fact-finding, the agent must identify that he or she is an EI agent calling from Service Canada, and confirm that the other person on the line is a pay liaison unit officer. If the officer needs to conduct additional fact-finding to provide the requested information, the officer calls the agent back within 24 hours of obtaining the information. If the pay liaison unit officer is unable to address the issue, the officer calls and informs the agent that the inquiry has been escalated. The Public Service Pay Centre agent who resolves the issue calls the EI agent back.

If necessary, the agent sends a letter to the Public Service Pay Centre using the following address:

Public Services and Procurement Canada Public Service Pay Centre Mail Facility PO Box 6500 Matane QC G4W 0H6

Because the mailing address is a post office box, the agent sends the letter by regular mail.

**Initial calculation — Missing ROEs (Level 1)**

An agent processing Claim Assessment (CA) WIs for clients employed by Government of Canada departments serviced by the Public Service Pay Centre avoids finalizing claims as BPNE 2 or inputting 15 - Claim Procedure disentitlements (D15s) if the missing ROE is not the last ROE. In these cases, it is considered that the client unsuccessfully tried to obtain the ROE from the employer. The agent must fact-find with the client to complete the ROE: INS3166 Request for missing ROE — Form .
       [Government of Canada departments serviced by the Public Service Pay Centre](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html) 
       [ROE: INS3166 Request for missing ROE — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS3166.pdf)

Once the ROE: INS3166 Request for missing ROE — Form has been completed with the client, the agent confirms and verifies the pay period details required to create the interim ROE with the pay liaison unit officer. The agent also requests that the missing ROE be issued and that the officer forward the request to the Public Service Pay Centre. Agents should not wait to create the interim ROE, since there is no guaranteed timeframe for employers to issue the ROE.
       [ROE: INS3166 Request for missing ROE — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS3166.pdf)

The agent refers to Determining if an interim ROE is required .
       [Determining if an interim ROE is required](/en/procedure/task/determining_interim_roe.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1268.dita) 

**Initial calculation — ROE verification (Non-complex and Level 1)**

The agent contacts the Client Contact Centre using the direct telephone line to request or verify ROE information.

**Initial calculation — Reason for separation (Level 1 and 2)**

Pay liaison unit officer can confirm the reason for separation (RFS) code on the ROE and provide some background information, if available, on the circumstances of the separation. If additional RFS information is required, the officer can provide the local manager’s contact information. 

### Attention

Source topic: `en_EN/common_notes/note_c_1266.dita`

Attention:

This update applies only to Government of Canada departments serviced by the Public Service Pay Centre .
       [Government of Canada departments serviced by the Public Service Pay Centre](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html)

For ROEs issued from government departments not serviced by the Public Service Pay Centre, return to the initial task and follow normal procedures.

     [Government of Canada departments serviced by the Public Service Pay Centre](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html) 

### Attention

Source topic: `en_EN/common_notes/note_c_1267.dita`

Attention:

The direct telephone line to conduct fact-finding with the Public Service Pay Centre will be implemented gradually according to the following schedule:

Western Canada and Territories Region: January 14, 2019 Ontario Region: February 11, 2019 Atlantic Region: February 25, 2019 Quebec Region: March 11, 2019

**Before the implementation date**

For an initial calculation using a Government of Canada ROE that is missing or requires correction, agents in regions where the direct telephone line is not yet available continue to refer to Information: Update on ROE issued by the Government of Canada .
       [Information: Update on ROE issued by the Government of Canada](/en/site/dossier/update_roe_goc.shtml)

For a recalculation using a Government of Canada ROE that requires correction, agents in regions where the direct telephone line is not yet available continue to refer to Processing a Claim Review Recalculation WI — Government of Canada ROE (Archived).
       [Processing a Claim Review Recalculation WI — Government of Canada ROE](/archive/2018/11/09/en/procedure/task/cr_recalc_wi_goc_roe_9.shtml)

Note: Effective March 11, 2019, the following procedures apply in all regions.

**On or after the implementation date**

For an initial calculation using a Government of Canada ROE that is missing or requires correction, agents in regions where the direct telephone line is available refer to the procedure below .
       [below](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#ContactingPSPC)

For a recalculation using a Government of Canada ROE that requires correction, agents in regions where the direct telephone line is available refer to Processing a Claim Review Recalculation WI — Government of Canada ROE .
       [Processing a Claim Review Recalculation WI — Government of Canada ROE](/en/procedure/task/cr_recalc_wi_goc_roe.shtml)

     [Information: Update on ROE issued by the Government of Canada](/en/site/dossier/update_roe_goc.shtml) 
     [Processing a Claim Review Recalculation WI — Government of Canada ROE](/archive/2018/11/09/en/procedure/task/cr_recalc_wi_goc_roe_9.shtml) 
     [below](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#ContactingPSPC) 
     [Processing a Claim Review Recalculation WI — Government of Canada ROE](/en/procedure/task/cr_recalc_wi_goc_roe.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1268.dita`

Note:

When inputting the interim ROE, the agent uses employer number 121491807RP0001. 

## Summary of changes

Source topic: `en_EN/site/dossier/updated_roe_goc_procedures_ncl1l2/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
