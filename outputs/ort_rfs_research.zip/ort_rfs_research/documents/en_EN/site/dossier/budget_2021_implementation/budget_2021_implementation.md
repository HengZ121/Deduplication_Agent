# Budget 2021 implementation

Source map: `en_EN/site/dossier/budget_2021_implementation/budget_2021_implementation.ditamap`

## Summary

Source topic: `en_EN/site/dossier/budget_2021_implementation/summary.dita`

Budget 2021 introduces temporary legislative measures that come into force on September 26, 2021 (w/c 2310). Affected procedures will be updated by September 27, 2021. 

## Generic

Source topic: `en_EN/site/dossier/budget_2021_implementation/generic.dita`

The new legislative measures are as follows:

- Common entrance requirement:

- Clients need 420 hours of insurable employment to establish a claim for regular or special benefits with a BPC from September 26, 2021 (w/c 2310) to September 18, 2022 (w/c 2361).

- A comparable common earnings threshold applies to fishing benefits ($2 500) and benefits for the self-employed ($5 289).

- Increased entrance requirements due to violations still apply.

- Reason for separation (RFS):

- For initial claims with a BPC from w/c 2310 to w/c 2361 (excluding fishing benefits and benefits for the self-employed), a contentious RFS is only adjudicated if it is the last ROE in the qualifying period (QP).

- Exception: When the RFS is strike or lockout, adjudication is required.

- All hours of insurable employment in the QP are used to establish the claim (no ROE is excluded).

- All contentious RFS in the benefit period (BP) require adjudication.

- Separation monies:

- Certain monies paid due to separation from employment are not allocated. This measure applies when the start date of the allocation is between w/c 2310 and w/c 2361.

- Minimum benefit rate:

- A minimum benefit rate of $300 per week ($180 for extended parental benefits) applies to claims with a BPC from September 26, 2021 (w/c 2310) to November 14, 2021 (w/c 2317).

Additionally, Budget 2021 extends the following temporary measures:

- Seasonal workers:

- 5 additional weeks of regular benefits for seasonal workers in certain economic regions. This measure ends on October 29, 2022 (w/c 2366).

- Fishers:

- This temporary measure is extended to December 18, 2021 (w/c 2321). This allows self-employed fishers to establish a winter 2021 fishing BP based on their most recent insurable earnings or the ones used to establish a previous winter fishing claim, whichever is higher. Self-employed fishers can only benefit from this measure one time per fishing claim type.

- Work-Sharing (WS):

- The extension of temporary enhancements to the WS program allows longer WS agreements and waives the cooling-off period for a subsequent agreement.

**System and procedure updates**

The systems will be updated to support these new measures on September 11, 2021. The procedures affected by these new measures will be updated on September 13, 2021, but will only apply to claims with a tentative or final BPC from w/c 2310 to w/c 2361. Procedures for the extended measures will be updated on September 27, 2021.

Temporary simplification measures (e.g. fact-finding, medical certificates, work permits) continue to apply until September 25, 2021.
       [Temporary simplification measures](/en/site/dossier/updated_extension_temporary_simplification_measures_l1_l2_ipoc.shtml)

Emergency response benefit transition provisions (e.g. hours credit, minimum benefit rate, RFS 12-week rule) continue to apply to claims with a BPC before w/c 2310.
       [Emergency response benefit transition provisions](/en/site/dossier/new_erbt_be2020-05.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0983.dita) 

Procedures indicate all the temporary measures that are currently in effect. 

### Note

Source topic: `en_EN/common_notes/note_c_0983.dita`

Note:

As of September 11, 2021, the system will no longer automatically adjudicate training. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/budget_2021_implementation/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
