# Updated: ROE Issue RFS Action WI with K - Other — Procedure

Source map: `en_EN/site/dossier/roe_issues_rfs_action_update_procedure/roe_issues_rfs_action_update_procedure.ditamap`

## Summary

Source topic: `en_EN/site/dossier/roe_issues_rfs_action_update_procedure/summary.dita`

The task Completing an ROE Issue RFS Action WI: K — Other has been updated based on regional feedback. 

## Generic

Source topic: `en_EN/site/dossier/roe_issues_rfs_action_update_procedure/generic.dita`

An agent can receive an ROE Issue (ROE) RFS Action WI for an ROE with one of the following reasons for separation (RFS):

- K - Other / Change of payroll frequency

- K - Other / Change of ownership

- K - Other / Requested by Employment Insurance

- K - Other / Change of Service Provider

In this case, if the Resolve Issue section is displayed on the WI, the agent changes the RFS from K - Other to A - Shortage of Work in the ROE Issue RFS Action WI. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/roe_issues_rfs_action_update_procedure/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
