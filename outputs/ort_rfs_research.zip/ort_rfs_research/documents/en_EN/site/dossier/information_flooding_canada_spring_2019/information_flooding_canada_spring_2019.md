# Information: Flooding in Canada (spring 2019)

Source map: `en_EN/site/dossier/information_flooding_canada_spring_2019/information_flooding_canada_spring_2019.ditamap`

## Summary

Source topic: `en_EN/site/dossier/information_flooding_canada_spring_2019/summary.dita`

Emergency measures have been adopted to assist clients affected by flooding in Canada. The measures described below apply to clients living in the flooded areas who have been affected by the disaster. 

## Generic

Source topic: `en_EN/site/dossier/information_flooding_canada_spring_2019/generic.dita`

**Reference codes**

- Clients affected in Quebec must use the 2371011233218211 code.

- Clients affected in the Atlantic must use the 1640012019218211 code.

- Clients affected in Ontario must use the 3515012019274315 code.

- Clients affected in Saskatchewan and Manitoba must use the 4317014317012019 code.

- Clients affected in Alberta must use the 4812014812012019 code.

- Clients affected in British Columbia must use the 5986015986012019 code.

- Clients affected in Northwest Territories , Yukon and Nunavut must use the 4813014813012019

The reference code for Quebec is valid between April 14 and June 29, 2019. The reference code for the Atlantic region is valid between April 27 and June 29, 2019. The reference code for Ontario is valid between April 27 and May 31 st , 2019.

The reference codes can be used only by clients requesting regular benefits. Clients requesting special benefits must not use them.

Claims filed with the Quebec reference code will be processed by dedicated employees. For the Atlantic region, claims filed with a reference code will be processed normally.

**Client's address**

Clients must enter their permanent address in the Residential address field of their AW application. If clients have been temporarily displaced because of the flooding, they can enter their temporary address in the Mailing address field. This temporary mailing address could be a hotel, a community centre, etc.

**Interim ROEs**

Since employers may not be able to issue ROEs, an interim ROE must be created as soon as possible for affected clients.

**Reason for separation**

If the client is no longer working because of the mandatory evacuation, or because the business closed due to the flooding, the reason for separation is considered non-contentious. However, if a client has quit or taken a leave of absence because of the flooding, Level 2 adjudication is necessary. Normal adjudication principles must be followed to determine if the client had a valid reason for quitting or taking a leave of absence.

**Availability**

The availability of affected clients can be allowed at Level 1 unless there is additional information on file that indicates the client may not be available. Normal adjudication principles must be followed. However, the Level 2 adjudicator must take into account each client’s personal circumstances when adjudicating availability.

**Earnings**

Some clients may be entitled to government or charitable financial assistance. These earnings are considered as relief monies and are not considered earnings for the purposes of benefits. A Level 1 agent processes these monies.

Any other amount or compensation paid by the employer to assist affected employees must be assessed according to the usual rules.

**Quebec procedures**

The Quebec region has created a reference document with processing information and resources for agents who are dealing with claims filed by clients who have been affected by the flooding in Quebec.
       [reference document](/resources/ort/documents/DEOAE-BREFF-20190425-MemoSpringFloods2019-VF.docx)

**Clients outside the affected region**

If a claim is filed using one of the region’s reference code but the residential address provided is outside the affected region, the claim will still be calculated according to the reference code used. Once the claim is finalized, it will be transferred to the region where the client resides. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/information_flooding_canada_spring_2019/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
