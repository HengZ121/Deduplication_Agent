# New: Emergency Response Benefit Transition Provisions – BE 2020-05 — Policy and procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/new_erbt_be2020-05/new_erbt_be2020-05.ditamap`

## Summary

Source topic: `en_EN/site/dossier/new_erbt_be2020-05/summary.dita`

The purpose of this memorandum is to describe the interim orders made on August 28, 2020 and September 27, 2020 by the Minister of Employment and Social Development amending the EI Act for the purpose of implementing temporary transition measures from the ERB/CERB to EI benefits. 

## Generic

Source topic: `en_EN/site/dossier/new_erbt_be2020-05/generic.dita`

Effective September 27, 2020, temporary measure are implemented to facilitate the transition from ERB/CERB to EI benefits and avoid delays in paying benefits for Canadians.

The measures include:

- A minimum national standard of 13.1% for the regional rate of unemployment (RRU)

- A credit of insurable hours added to initial claims; 300 for regular benefits and 480 for special benefits

- An extension to the qualifying period (QP) for claimants who received the ERB/CERB

- A minimum weekly benefit rate of $500

- Waiving of the waiting period on all initial claims until October 25, 2020

- Contentious reason for separation (RFS) falling more than 12 weeks before the most recent interruption of earnings in the qualifying period will not be adjudicated for initial claims

- Monies that fall under sections 36(8), 36(9) and 36(19) of the EI Regulations will not be allocated into the benefit period

- Training on all claims is allowed – availability is still required and may be reviewed after benefits have been paid

Self-employed fishers will benefit from the following transitional measures:

- Establishing a fishing benefit period based on the highest of their total insurable earnings from their most recent qualifying period, those used to establish their claim for the same season from the previous year or their claim for the same season for the second previous year.

- A minimum earnings requirements set at $2500, including for special benefits

- A minimum weekly benefit rate of $500 

## Summary Of Changes

Source topic: `en_EN/site/dossier/new_erbt_be2020-05/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
