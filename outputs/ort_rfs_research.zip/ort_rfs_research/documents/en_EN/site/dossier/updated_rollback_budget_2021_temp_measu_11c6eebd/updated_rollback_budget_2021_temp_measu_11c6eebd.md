# Updated: Rollback of the Budget 2021 temporary measure related to reason for separation issues — Procedures (All levels)

Source map: `en_EN/site/dossier/updated_rollback_budget_2021_temp_measu_11c6eebd/updated_rollback_budget_2021_temp_measu_11c6eebd.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_rollback_budget_2021_temp_measu_11c6eebd/summary.dita`

The rules for adjudicating reason for separation (RFS) issues that were effective before the COVID-19 pandemic will resume for claims with a BPC of w/c 2362 or later. 

## Generic

Source topic: `en_EN/site/dossier/updated_rollback_budget_2021_temp_measu_11c6eebd/generic.dita`

On claims with BPC of w/c 2362 or later, the officer adjudicates all contentious RFS issues in the qualifying period (QP) to determine if the insurable hours and earnings from that employment should be included in the claim calculation. EIA 30(1)(a), which was repealed as part of the temporary measures, is reinstated. Therefore, a client is disqualified from receiving regular benefits if the client lost a job due to misconduct or voluntarily left without just cause. The client must have worked enough hours in insurable employment since this disqualifying event to requalify for benefits.

The officer continues to adjudicate any contentious RFS issues in the benefit period (BP).

On a renewal claim, if the client has worked since the disqualifying event, the officer determines if the client worked enough insurable hours since this event to gain relief from the disqualification. When determining if the client worked enough hours to establish a new claim, the officer should keep in mind that the rules for establishing a new claim change depending on the BPC:

- For a BPC between w/cs 2310 and 2361, the temporary measures apply.

- For a BPC of w/c 2362 or later, the rules that were effective before the COVID-19 pandemic apply again.

All the previous rules for deferring adjudication will resume for claims with a BPC of w/c 2362 or later.

**System changes and transitional measures**

In order to align with the return to the previous rules, Adjudication Issue (ADJ) WIs will be created on initial claims with a tentative BPC of w/c 2361 for each contentious RFS issue in the QP.

The officer adjudicates these ADJ WIs following normal procedures, including applying the usual deferral conditions that applied before the temporary RFS measure and communicating the negative decision when a disqualification is imposed or an ROE is excluded. During the transitional period, when verbally communicating the negative decision, the officer advises the client that this RFS decision is made before the claim is calculated. Therefore, once the claim is calculated, if this decision results in an ROE being excluded or regular benefits not being payable, the client will receive a written notice of decision explaining the decision and the client’s right to appeal. However, once the claim is calculated, if the decision does not impact benefits, no notice of decision is sent and the client will receive EI payments instead.

When an RFS issue requiring adjudication is identified on an initial claim with a tentative BPC of w/c 2361 or later and there is no outstanding WI, the officer creates the appropriate WI. The officer either adjudicates the issue or reassigns the WI to Level 2 for adjudication before calculating the claim. If the claim is finalized with BPC of w/c 2361 or before, the system ignores the decision on the other employment in the QP and includes all the insurable hours and earnings when calculating the claim.

If the tentative BPC is w/c 2360 or before, the system does not create ADJ WIs for other contentious RFS issues in the QP. Under the temporary Budget 2021 measures, the system automatically resolves these WIs by creating a record of decision (ROD) that shows Adjudication not Required . However, if the BPC is postdated to w/c 2362 or later, a Claim Assessment (CA) WI is created if the system identifies a contentious ROE with a blank Special condition field. The following message appears under Processing activities in NWS: UIC calculation result includes a DQ/DE for ROE with a blank special condition - please review. In this case, the officer reactivates the ADJ WI and follows normal procedures to ensure the issue is adjudicated, since the temporary measure no longer applies to this BPC.

**Impact on procedures**

The rollback of the temporary measure related to RFS issues impacts 26 EI ORT activities and tasks. Each updated page includes a label and highlighting to show the changes that were made. Most changes involve moving information about the Budget 2021 temporary measure related to RFS issues from the top of the What You Need To Know section to the new heading Reason for separation (RFS) – Temporary Budget measures . Of all the RFS procedures that have been updated, the following procedures have had the most significant updates, including changes to the Step by Step section:

- Adjudicating a dismissal or suspension — Initial claim
         [Adjudicating a dismissal or suspension — Initial claim](/en/procedure/task/dismissal_ds_ic.shtml)

- Adjudicating a dismissal or suspension — Renewal claim
         [Adjudicating a dismissal or suspension — Renewal claim](/en/procedure/task/dismissal_ds_rc.shtml)

- Adjudicating a dismissal for unsuitability — Initial claim
         [Adjudicating a dismissal for unsuitability — Initial claim](/en/procedure/task/dismissal_ic.shtml)

- Adjudicating voluntary leaving (Level 1): Referred training or employment activity — Initial claim
         [Adjudicating voluntary leaving (Level 1): Referred training or employment activity — Initial claim](/en/procedure/task/vl_course_ic.shtml)

- Adjudicating voluntary leaving: Initial Claim — Level 2
         [Adjudicating voluntary leaving: Initial Claim — Level 2](/en/procedure/task/vllevel2_ic.shtml)

- Adjudicating voluntary leaving: Renewal claim — Level 2
         [Adjudicating voluntary leaving: Renewal claim — Level 2](/en/procedure/task/vllevel2_rc.shtml)

- Adjudicating voluntary leaving (Level 1): Medical reasons — Initial claim
         [Adjudicating voluntary leaving (Level 1): Medical reasons — Initial claim](/en/procedure/task/vllevel1_mr_ic.shtml)

- Adjudicating voluntary leaving (Level 1): Following another individual — Initial claim
         [Adjudicating voluntary leaving (Level 1): Following another individual — Initial claim](/en/procedure/task/vllevel1_fai_ic.shtml)

- Adjudicating voluntary leaving (Level 1): Other employment — Initial claim
         [Adjudicating voluntary leaving (Level 1): Other employment — Initial claim](/en/procedure/task/vllevel1_oe_ic.shtml)

- Adjudicating voluntary leaving (Level 1): Workforce reduction — Initial claim
         [Adjudicating voluntary leaving (Level 1): Workforce reduction — Initial claim](/en/procedure/task/vl_wr_ic.shtml)

- Adjudicating a leave of absence — Level 1
         [Adjudicating a leave of absence — Level 1](/en/procedure/task/voluntary_leaving_loa.shtml)

- Adjudicating a leave of absence — Level 2
         [Adjudicating a leave of absence — Level 2](/en/procedure/task/adjudicating_loa_l2.shtml)

- Deferring adjudication: Initial claim — Regular benefits
         [Deferring adjudication: Initial claim — Regular benefits](/en/procedure/task/defer_adj_initial_regular_ben.shtml)

- Deferring adjudication: Initial claim — Sickness benefits
         [Deferring adjudication: Initial claim — Sickness benefits](/en/procedure/task/defer_adj_initial_sickness_ben.shtml)

- Deferring adjudication: Initial claim — Special benefits (other than sickness)
         [Deferring adjudication: Initial claim — Special benefits (other than sickness)](/en/procedure/task/defer_adj_initial_special_ben_other_sickness.shtml)

- Deferring adjudication: Renewal claim — Regular benefits
         [Deferring adjudication: Renewal claim — Regular benefits](/en/procedure/task/defer_adj_renewal_regular_ben.shtml)

- Reviewing an outstanding issue with no Adjudication Issue WI
         [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

- Cancelling a benefit period
         [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml)

- Terminating a benefit period
         [Terminating a benefit period](/en/procedure/task/benefit_period_term.shtml)

For more information, the officer refers to BE 2022-04 — New: Rollback of temporary measures of Budget 2021-Seeing Canadians and Businesses Through to Recovery .
       [BE 2022-04 — New: Rollback of temporary measures of Budget 2021-Seeing Canadians and Businesses Through to Recovery](/en/site/dossier/new_rollback_of_temp_measures_budget_2021_bememo_2022_04.shtml) 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_rollback_budget_2021_temp_measu_11c6eebd/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
