# New and updated: National Policy on Levels of Decision — Policy and procedures (Level 1)

Source map: `en_EN/site/dossier/new_updated_national_policy_on_lod_poli_98e61b5c/new_updated_national_policy_on_lod_poli_98e61b5c.ditamap`

## Summary

Source topic: `en_EN/site/dossier/new_updated_national_policy_on_lod_poli_98e61b5c/summary.dita`

EI Operational Policy has updated the National Policy on Levels of Decision effective March 18, 2022. Three new procedures have been created to reflect a new authority for rescinding a disentitlement when converting a claim from CCB to regular, maternity, and parental benefits. In addition, EI Operational Policy clarified Level 1 authority concerning conversions from special to regular benefits. Numerous procedures have been updated to reflect these and other changes to the policy. 

## Generic

Source topic: `en_EN/site/dossier/new_updated_national_policy_on_lod_poli_98e61b5c/generic.dita`

The following changes to the National Policy on Levels of Decision — Annex 1 impact new and existing procedures:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1157.dita) 

Separate from these updates, EI Operational Policy has also confirmed that when converting from any special benefit type to regular benefits, Level 1 officers can allow the conversion if the client is available for work and if the client was either receiving regular benefits before the special benefits, or if the reason for separation (RFS) can be allowed at Level 1. These tasks previously indicated the need to refer the file to Level 2 if the client was not receiving regular benefits before the special benefits even if the RFS could be allowed at Level 1. The Step by step section in those  tasks has been updated to reflect the actual authority as written in the Policy.

Updates have been made to tasks that fall under the following activities:

- Antedate
         [Antedate](/en/procedure/activity/antedate.shtml)

- Conversion and renewal
         [Conversion and renewal](/en/procedure/activity/conversions.shtml)

- Training
         [Training](/en/procedure/activity/training.shtml)

- Incarceration
         [Incarceration](/en/procedure/activity/incarceration.shtml)

- Not unemployed
         [Not unemployed](/en/procedure/activity/not_unemployed.shtml)

- Out of Canada
         [Out of Canada](/en/procedure/activity/out_canada.shtml)

- Claim procedure
         [Claim procedure](/en/procedure/activity/claim_procedure.shtml)

- Voluntary leaving
         [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml) 

### Callout

Source topic: `en_EN/common_notes/note_c_1157.dita`

Section 2 — Antedate 
      The wording in an existing delegation of authority was updated. Level 1 officers can now allow an antedate for one or a combination of reasons under specific circumstances. 
      Section 3 — Availability 
      A new Level 1 authority has been added. Level 1 officers can now rescind the return to work (RTW) date when converting between benefit types (BTs). 
      Section 4 — Training and employment activities 
      Certain authorities have been changed from being temporary measures to being permanent measures. The wording reflecting temporary measures has been removed. The wording for referred training has been updated to include employment activities to which the client has been referred. 
      Section 6 — Incarceration 
      The wording has been changed to reflect that Level 1 officers can terminate a disentitlement for incarceration if the incarceration ended before the renewal date.

EI Operational Policy has also confirmed that the authority applies to all BTs. 
      Section 9 — Not unemployed 
      Certain authorities have been changed from being temporary measures to being permanent measures.

The wording reflecting temporary measures has been removed.

The wording concerning Level 1 officers allowing benefits has been changed from “the business is no longer operating” to “the business is permanently closed.” 
      Section 10 — Out of Canada 
      The authority for terminating a disentitlement for being out of Canada has been updated. It clarifies that the officers must adjudicate availability for the date of return to Canada. 
      Section 12 — Claim procedure 
      The period of time allowed for Level 1 officers to impose or rescind a 15 - Claim procedure disentitlement (D15) for a missing ROE has been changed from 45 days to 90 days. 
      Section 14 — Voluntary Leaving 
      The wording for allowing a client to voluntarily leave employment to move with another person has been updated. References to no other reasonable alternatives have been removed and replaced with references to no other contentious issues related to the voluntary leaving that would prevent Level 1 officers from allowing it.

Other wording in the sections on voluntarily leaving employment to move with another person have also been slightly modified.

The conditions for Level 1 officers to allow a client’s voluntarily leaving to accept other employment or due to a job offer have been made more specific. 
      Section 17 — Modification of an existing disentitlement — Special benefits 
      A note has been added indicating that a client is not required to show good cause for the delay when submitting a medical certificate for special benefits.

Level 1 officers have the authority to rescind the disentitlement, regardless of the length of delay.

New authorities have also been added to this section. Level 1 officers can now terminate disentitlements on CCB or family caregiver benefits claims when converting to another BT. Existing tasks have been updated, and 3 new tasks have been created to accommodate these changes.

The What You Need to Know and Step by Step sections of these tasks has been updated to inform the officer that retroactive conversion requests from CCB or family caregiver benefits must be reassigned to the CCB and family caregiver benefits hierarchies, but that all other conversions from CCB or family caregiver benefits are completed in the normal processing workload. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/new_updated_national_policy_on_lod_poli_98e61b5c/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
