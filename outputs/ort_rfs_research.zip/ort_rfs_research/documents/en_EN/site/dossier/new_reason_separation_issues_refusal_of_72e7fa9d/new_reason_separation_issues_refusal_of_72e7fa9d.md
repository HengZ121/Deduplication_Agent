# Updated: EI Eligibility and refusal of vaccination — Policy and procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/new_reason_separation_issues_refusal_of_72e7fa9d/new_reason_separation_issues_refusal_of_72e7fa9d.ditamap`

## Summary

Source topic: `en_EN/site/dossier/new_reason_separation_issues_refusal_of_72e7fa9d/summary.dita`

The new BE 2021-10 — EI Eligibility and refusal to comply with a mandatory vaccination policy provides information regarding the eligibility to Employment Insurance (EI) regular benefits when a client refuses to comply with the employer’s mandatory COVID-19 vaccination policy. 

## Generic

Source topic: `en_EN/site/dossier/new_reason_separation_issues_refusal_of_72e7fa9d/generic.dita`

Employers’ mandatory COVID-19 vaccination policies may result in employees’ voluntary leaving, dismissal or suspension for refusing to comply. The BE Memo 2021-10 indicates that each case needs to be assessed based on its own set of circumstances and that Level 2 officers conduct thorough fact-finding to support the existence of exceptional circumstances when determining a client’s entitlement to EI benefits.

When adjudicating cases in which clients quit their employment for refusing to comply with their employer’s mandatory vaccination policy, the officer determines if clients had just cause and considers the legal test of no reasonable alternative as established by jurisprudence. Similarly, when adjudicating dismissal or suspension cases, the officer determines if the loss of employment was the result of the clients’ misconduct.

When reviewing such cases, the officer also determines if the client meets the availability conditions in order to be entitled to EI benefits. If it is determined that a client’s availability is in question for regular benefits or that the client may not be otherwise available for sickness benefits, the officer follows the Overarching Principles for Content in EI ORT to create a WI for review of the availability issue, if necessary.
       [Overarching Principles for Content in EI ORT](/en/site/generic/guide_content_principles.shtml)

On Canada.ca, employers can now find new information to complete ROEs when employees lost their employment for refusing to comply with a vaccination policy. In addition, new information regarding qualifying and entitlement conditions to EI benefits in cases of vaccination refusal has been added.

Since normal adjudication principles continue to apply when clients lose or leave their employment for not complying with the employer’s mandatory COVID-19 vaccination policy, EI ORT procedures have not been updated. Instead, a note with a link to the BE Memo 2021-10 has been added to RFS procedures. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/new_reason_separation_issues_refusal_of_72e7fa9d/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
