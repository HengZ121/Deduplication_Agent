# Updated: Resumption of Referrals to Integrity — Procedures and additional resource (Non-complex, Level 1 and Level 2)

Source map: `en_EN/site/dossier/maj-rep-ren-int-pra-upd-resump-ref-integrity/maj-rep-ren-int-pra-upd-resump-ref-integrity.ditamap`

## Summary

Source topic: `en_EN/site/dossier/maj-rep-ren-int-pra-upd-resump-ref-integrity/summary.dita`

Since March 2020, due to COVID-19, officers referred only urgent files and specific issues to Integrity. Integrity has now resumed most of the investigations. 

## Generic

Source topic: `en_EN/site/dossier/maj-rep-ren-int-pra-upd-resump-ref-integrity/generic.dita`

The restriction on referring issues to Integrity has been lifted for all issues except self-employment (SE). The officer refers the file to Integrity only when the SE issue impacts the payment of future benefits. The officer can now refer all other issues to Integrity following normal procedures.

Additionally, based on collaboration with Integrity and Business Analysis and Information Management, changes have been made to the section Unreported contentious reason for separation (RFS) in the task Determining if an issue must be referred to Integrity . The officer determines if an unreported contentious RFS impacts the current work:

- If yes, the officer determines the benefit type (BT) the client received after the last day worked (LDW) of the contentious RFS to determine the next steps.

- If no, the officer does not refer the RFS to Integrity and does not adjudicate the issue. The RFS prompts the creation of an investigation from one of Integrity’s detection programs. 

## Summary of changes

Source topic: `en_EN/site/dossier/maj-rep-ren-int-pra-upd-resump-ref-integrity/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
