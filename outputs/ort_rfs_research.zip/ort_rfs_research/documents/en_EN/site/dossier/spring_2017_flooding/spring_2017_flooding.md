# Spring 2017 Flooding in Canada

Source map: `en_EN/site/dossier/spring_2017_flooding/spring_2017_flooding.ditamap`

## Summary

Source topic: `en_EN/site/dossier/spring_2017_flooding/summary.dita`

Attention: Updated May 16, 2017 — A reference code has been issued for British Columbia.

Emergency measures have been adopted to assist clients affected by flooding in Canada. These changes apply only to clients who are affected by the flooding in Ontario, Quebec and British Columbia. 

## Generic

Source topic: `en_EN/site/dossier/spring_2017_flooding/generic.dita`

[Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1026.dita) 

**Reference codes**

Reference codes have been issued for clients who are affected by the floods.

- Clients affected in Ontario must use the 3515012017201705 code.

- Clients affected in Quebec must use the 2371011233207910 code.

These reference codes are valid only between May 13 and July 1, 2017.

- Clients affected in British Columbia must use the 5986012017002018 code.

This reference code is valid between May 17, 2017 and May 16, 2018.

The reference codes can be used only by clients requesting regular benefits. Clients requesting special benefits cannot use these reference codes.

Claims filed with these reference codes will be processed by dedicated employees.

**Client’s address**

Clients are being told to enter their permanent address in the residential address field of their application, whether their permanent address is in the affected area or elsewhere. If clients have been temporarily displaced because of the flooding, they can enter their temporary address in the mailing address field. This temporary mailing address could be a hotel, a shelter, etc.

**Interim ROEs**

Since employers may not be able to issue ROEs, an interim ROE must be created as soon as possible for affected clients.

**Direct deposit**

Clients who provided direct deposit information on a previous claim in another region may need to have their direct deposit information updated. The direct deposit information from the other region may not be carried forward to their new claim. If agents are in contact with an affected client, they must always make sure the direct deposit information on file is correct.

**Reason for separation**

If the client is involuntarily no longer working because of the mandatory evacuation, or because the business closed due to the flooding, the reason for separation is considered non-contentious and can be allowed at Level 1. However, if a client has quit or taken a leave of absence because of the flooding, Level 2 adjudication is necessary. Normal adjudication principles must be followed to determine if the client had a reasonable alternative to quitting or taking a leave of absence.

**Availability**

A client’s availability is not addressed on the application. Therefore, the availability of affected clients can be allowed at Level 1 unless there is additional information on file that indicates the client may not be available. Normal adjudication principles must be followed. However, the Level 2 adjudicator must take into account each client’s personal circumstances when adjudicating availability. The When Disaster Strikes page indicates that no client should be refused benefits if the emergency situation is the sole reason for the non-availability.
       [When Disaster Strikes](http://servicecanada.prv/eng/ei/reference-material/manuals-guides/when_disaster_strikes.shtml#section6.3)

**Claimant’s report**

Agents must obtain any missing claimant’s report information whenever they are in contact with an affected client.

**Replacement warrants**

Affected clients will no longer have to wait 8 days before a replacement warrant can be requested. Replacement warrant requests will be processed immediately.

**Quebec procedures**

The Quebec region has created a reference document with processing information and resources for agents who are dealing with claims filed by clients who have been affected by the flooding in Quebec.

**Clients outside the affected provinces**

If a client applies using one of the reference codes and provides a residential address outside the affected provinces, the claim will still be calculated in the region where the application was directed in NWS. Once the claim is finalized, if applicable, the claim will be transferred to the region where the client resides. 

### Info

Source topic: `en_EN/common_notes/note_c_1026.dita`

**Note:**

As changes are ongoing, the individual tasks in the EI ORT will not be updated. The information here replaces any related guidance in the EI ORT procedures. Please continue to check this page for further updates. 

## Summary of changes

Source topic: `en_EN/site/dossier/spring_2017_flooding/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
