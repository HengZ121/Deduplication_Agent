# Updated: Post EI-ERB and adjudicating reasons for separation — Policy and procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_post_eierb_adjudicating_reason__c823606b/updated_post_eierb_adjudicating_reason__c823606b.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_post_eierb_adjudicating_reason__c823606b/summary.dita`

Effective September 27, 2020, when the EI Emergency Response Benefit (EI ERB) ends, claims whose BPC is between w/c 2258 and w/c 2309 that meet specific criteria for regular and sickness benefits are temporarily being processed through a new specialized ACP process and are established without adjudicating contentious reason for separation (RFS) issues in the qualifying period (QP).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1254.dita) 

A transitional measure related to RFS adjudication is also being implemented as of September 27, 2020. This measure applies to initial claims in the normal ACP process whose BPC is between w/c 2258 and w/c 2309. For these claims, the RFS adjudication principles apply only to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the interruption of earnings (I of E) used to establish the claim. 

### Note

Source topic: `en_EN/common_notes/note_c_1254.dita`

Note:

This Headlines and Updates page was created on September 28, 2020 and has been updated as follows:

- April 1, 2021: This update includes clarification of the 12-week period. 

## Generic

Source topic: `en_EN/site/dossier/updated_post_eierb_adjudicating_reason__c823606b/generic.dita`

As of September 27, 2020, a new specialized ACP process streamlines the processing of initial applications for regular and sickness benefits whose BPC is between w/c 2258 and w/c 2309 that meet specific criteria. Claims processed through this specialized ACP process are established without adjudicating contentious RFS issues in the client’s QP. The agent cannot create Adjudication Issue (ADJ) WIs for contentious RFS issues in the QP on claims during the specialized ACP process. These contentious RFS issues may be adjudicated after the claim is established.

Applications that do not meet the specific criteria to go through the specialized ACP process are directed to the normal ACP process. When using the normal ACP process, ACP creates ADJ WIs for each contentious RFS issue. However, for claims whose BPC is between w/c 2258 and w/c 2309, the RFS transitional measure applies, which specifies that the agent adjudicates only the RFS of the last employment in the QP and any other contentious RFS issues in the 12 weeks before the I of E used to establish the claim. This period is determined by subtracting 12 weeks from the week of the I of E used to establish the claim. Any ADJ WIs for RFS issues that are outside the 12-week period are allowed without fact-finding and adjudication.

**Impact on adjudication**

Claims in the normal ACP process have ADJ WIs created for all contentious RFS issues in the QP. However, adjudication procedures only apply to the last employment in the QPand to any other contentious RFS issues in the 12 weeks before the I of E used to establish the claim. If agents receive ADJ WIs for contentious RFS issues outside of the 12-week period on claims whose BPC is between w/c 2258 and 2309, adjudication and fact-finding are not required. The RFS procedures have been updated, advising agents to allow those ADJ WIs.

If the agent is processing the calculation or recalculation of an initial regular or sickness claim whose BPC is between w/c 2258 and w/c 2309, the agent does not identify or adjudicate any contentious RFS issues in the QP.

Contentious RFS issues in the benefit period (BP) are adjudicated using the normal adjudication procedures for renewal and continuing claims.

Contentious RFS issues that were not adjudicated because the application was processed through the specialized ACP process may be adjudicated after the claim is established.

**Impact on procedures**

The What You Need To Know and Step by Step sections of the following procedures have been updated. They now instruct agents not to adjudicate RFS issues in the QP of initial claims for which an ADJ WI exists when the RFS issue is outside the 12-week period outlined above:

- Voluntary Leaving

- Adjudicating voluntary leaving (Level 1): Course of instruction — Initial claim

- Adjudicating voluntary leaving (Level 1): Following another individual — Initial claim

- Adjudicating voluntary leaving (Level 1): Medical reasons — Initial claim

- Adjudicating voluntary leaving (Level 1): Other employment — Initial claim

- Adjudicating voluntary leaving (Level 1): Workforce reduction — Initial claim

- Adjudicating voluntary leaving: Initial Claim — Level 2

- Dismissal

- Adjudicating a dismissal for unsuitability — Initial claim

- Adjudicating a dismissal or suspension — Initial claim

- Leave of absence

- Adjudicating a leave of absence — Level 1

- Adjudicating a leave of absence — Level 2

The What You Need To Know and Step by Step sections of the following procedure have been updated. They now advise agents not to create WIs for any contentious RFS issues in the QP when completing the calculation or recalculation of an initial claim for regular or sickness benefits:

- Reviewing an outstanding issue with no Adjudication Issue WI. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_post_eierb_adjudicating_reason__c823606b/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
