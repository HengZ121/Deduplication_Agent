# Updated: Medical certificate requirements and maximum weeks of sickness benefits payable — Procedures and additional resources (Level 1 and Level 2)

Source map: `en_EN/site/dossier/upd-mcr-mwsbp/upd-mcr-mwsbp.ditamap`

## Summary

Source topic: `en_EN/site/dossier/upd-mcr-mwsbp/summary.dita`

As a result of regional feedback, changes have been made to procedures and additional resources related to medical certificate requirements and the maximum number of weeks of sickness benefits payable. 

## Generic

Source topic: `en_EN/site/dossier/upd-mcr-mwsbp/generic.dita`

The changes made to the procedures and additional resources include the following:

- The additional resource Determining the recovery week — Instructions has been updated to include clarifications and additional scenarios on what the recovery week is based on the information on the medical certificate.

- The information on how to determine the recovery week based the recovery date or incapacity end date has been updated for clarity.

- The requirements for a medical certificate to be acceptable now include the client’s name.

- The additional resource Medical Certificate: Conditions to be accepted — Knowledge has been restructured to separate the medical certificate requirements based on the benefit type (BT) the client is requesting.

- The medical certificate requirements for CCB have been updated to include the information specified on the CCB: INS5216B Medical certificate — Form.

- The word required has been removed from the titles of the tasks for determining if a medical certificate is required or acceptable for CCB, because a medical certificate for CCB must always be submitted.

- A clarification has been made to explain that the client must always submit a medical certificate to receive sickness benefits when there is a disqualification on the claim. This applies even if the disqualification was imposed because of an adjudication or because of the deferral of a contentious reason for separation (RFS).

- All tasks in which the maximum number of weeks of sickness benefits is referenced have been updated to specify the following information:

- the maximum number of weeks payable per benefit period (BP) is up to 26 weeks for claims with a BPC in w/c 2374 or later;

- the maximum number of weeks payable per BP is up to 15 weeks for claims with a BPC in w/c 2373 or earlier. 

## Summary of changes

Source topic: `en_EN/site/dossier/upd-mcr-mwsbp/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
