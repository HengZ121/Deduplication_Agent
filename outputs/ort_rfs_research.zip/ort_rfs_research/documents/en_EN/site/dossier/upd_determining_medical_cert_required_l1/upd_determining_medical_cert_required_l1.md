# Updated: Determining if a medical certificate is required — Task (Level 1)

Source map: `en_EN/site/dossier/upd_determining_medical_cert_required_l1/upd_determining_medical_cert_required_l1.ditamap`

## Summary

Source topic: `en_EN/site/dossier/upd_determining_medical_cert_required_l1/summary.dita`

Based on regional feedback, the task Determining if a medical certificate is required or acceptable — Sickness benefits has been updated.
       [Determining if a medical certificate is required or acceptable — Sickness benefits](/en/procedure/task/calc_determining/det_mc_ra.shtml) 

## Generic

Source topic: `en_EN/site/dossier/upd_determining_medical_cert_required_l1/generic.dita`

The conditions under which sickness benefits can be allowed without a medical certificate being submitted have been clarified to include sickness benefits combined with maternity benefits. The task previously contained a note which led to confusion about the requirement for a medical certificate. A client is not required to submit the medical certificate in the following situations:

- The client is major attached.

- The reason for separation (RFS) is sickness or injury and the client is applying for either sickness benefits or sickness benefits combined with maternity benefits.

- The client is requesting sickness benefits on an initial subsequent claim immediately following a renewal claim for sickness and the RFS was sickness on the last ROE.

- There are no disqualifications or disentitlements on the claim. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/upd_determining_medical_cert_required_l1/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
