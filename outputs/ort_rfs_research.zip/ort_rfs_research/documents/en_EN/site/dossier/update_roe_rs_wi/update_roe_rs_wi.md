# ROE Reason for Separation WI procedures clarification

Source map: `en_EN/site/dossier/update_roe_rs_wi/update_roe_rs_wi.ditamap`

## Summary

Source topic: `en_EN/site/dossier/update_roe_rs_wi/summary.dita`

ROE Reason for separation WI procedures now include links to the associated adjudication procedures for Level 1 and Level 2 agents. 

## Generic

Source topic: `en_EN/site/dossier/update_roe_rs_wi/generic.dita`

As per feedback received, steps have been added for Level 1 and Level 2 in each ROE RFS WI task with links to corresponding adjudication procedures.

The ROE RFS WI tasks were designed to provide Non-complex agents with instructions on how to update the Reason for separation and Special condition fields when an ROE RFS WI is received. If an ROE RFS WI is reassigned to Level 1 or Level 2, the agent must adjudicate the RFS in question by following the appropriate Adjudication procedure.
       [Adjudication](/en/procedure/index/adjudicate.shtml) 

## Summary Of Changes

Source topic: `en_EN/site/dossier/update_roe_rs_wi/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
