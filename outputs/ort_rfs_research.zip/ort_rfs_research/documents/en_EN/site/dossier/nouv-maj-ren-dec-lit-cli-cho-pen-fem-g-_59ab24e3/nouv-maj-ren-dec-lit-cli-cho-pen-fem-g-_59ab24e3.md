# New and updated: Adjudicating the not unemployed issue during a general shutdown with vacation pay – BE Memo 2026-01 — Policy and procedures (Non-complex, Level 1 and Level 2)

Source map: `en_EN/site/dossier/nouv-maj-ren-dec-lit-cli-cho-pen-fem-g-_59ab24e3/nouv-maj-ren-dec-lit-cli-cho-pen-fem-g-_59ab24e3.ditamap`

## Summary

Source topic: `en_EN/site/dossier/nouv-maj-ren-dec-lit-cli-cho-pen-fem-g-_59ab24e3/summary.dita`

As a result of a Federal Court of Appeal (FCA) decision, procedures have been updated with information and guidance on how to adjudicate the not unemployed issue when a client is on paid vacation due to a general shutdown of the business, according to the collective agreement or employment contract. 

## Generic

Source topic: `en_EN/site/dossier/nouv-maj-ren-dec-lit-cli-cho-pen-fem-g-_59ab24e3/generic.dita`

A new BE Memo FCA decision: Marquis (A-121-23) Unemployment status during holiday closure with vacation pay in trust— BE 2026-01 has been created. The BE Memo explains the FCA decision and its impact on adjudicating the not unemployed issue when a client is on vacation due to a general shutdown of the business, according to the collective agreement or employment contract, and the vacation pay is paid into a trust or set aside.
       [FCA decision: Marquis (A-121-23) Unemployment status during holiday closure with vacation pay in trust— BE 2026-01](/en/policy/bememo/be2026-01.shtml)

According to this FCA decision, a client is considered not unemployed when requesting EI benefits for a vacation period provided for in an agreement (collective agreement or other) between the employer and the employee (or the union representing the employees).

If these 3 conditions in EIA 11(3) are met, a 1 - Not unemployed disentitlement (D1) must be imposed:
       [EIA 11(3)](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/section-11.html)

- Vacation period: The client took a vacation under the agreement in place with the employer.

- Employment status: The client continues to be employed by the employer during the vacation period.

- Vacation pay: The client received (or will receive) vacation pay set aside for this period, regardless of when the monies are paid.
         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1170.dita)

The D1 is valid for the entire duration of the vacation period.

The usual procedures concerning the interruption of earnings (I of E) apply. The beginning of the vacation period does not count as an I of E under EIR 14(6) . However, if the client can establish a claim with another I of E within the qualifying period ( QP ),the officer imposes a D1 if the conditions are met.
       [EIR 14(6)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-14.html) 
       [QP](https://laws-lois.justice.gc.ca/eng/regulations/sor-96-332/page-2.html#h-982844)

Procedures impacted by the FCA decision have been updated. One important change is what to do when an ROE is issued with a note concerning the Commission de la construction du Québec vacation leave. Previously, the instructions were to update the reason for separation (RFS) from K - Other to A - Shortage of work / End of contract or season , but under the new guidance, the claim now needs to be reviewed by a Level 2 officer. 

### Note

Source topic: `en_EN/common_notes/note_c_1170.dita`

Note:

Adjudicating employment status is a Level 2 decision. 

## Summary of changes

Source topic: `en_EN/site/dossier/nouv-maj-ren-dec-lit-cli-cho-pen-fem-g-_59ab24e3/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
