# Updates to the Conversion and Renewal tasks

Source map: `en_EN/site/dossier/updates_conversion_renewal_tasks/updates_conversion_renewal_tasks.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updates_conversion_renewal_tasks/summary.dita`

Conversion and renewal procedures have been updated to correct multiple errors. 

## Generic

Source topic: `en_EN/site/dossier/updates_conversion_renewal_tasks/generic.dita`

As part of our continuous efforts to develop and keep EI ORT content updated, we are pleased to present to you the changes that have been made in the conversion and renewal procedures. Here is a list of the main changes:

Sections in the procedures related to the effective week of the conversion and renewal have been clarified. Previously, procedures incorrectly indicated that when a client files a renewal application in the 4 weeks following the last day worked, the effective week of the renewal is the week before the renewal application was filed.

Sections in the procedures related to casual sickness when the client is receiving parental benefits have been clarified. Before, procedures incorrectly indicated that the client could report 4 weeks of casual sickness while receiving parental benefits.

Since the procedures are mainly intended for Level 1 agents, references to the use of the decision-making process forms when creating a record of decision (ROD) by agents in the Quebec region have been removed.

A hyperlink to the Extension of the benefit period activity has been added.
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

New information on the actions to take when the decision on a contentious reason for separation (RFS) has been deferred or when there is a decision on file that results in an indefinite disqualification has been added.

New information on assessing the advantages for the client to renew the claim has also been added.

New information on the actions to take when the client is awaiting a decision from a third party has also been added. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updates_conversion_renewal_tasks/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
