# Updated: Post EI-ERB and adjudicating reasons for separation — Procedures (Level 1 and Level 2)

Source map: `en_EN/site/dossier/updated_post_eierb_adj_reasons_for_separation/updated_post_eierb_adj_reasons_for_separation.ditamap`

## Summary

Source topic: `en_EN/site/dossier/updated_post_eierb_adj_reasons_for_separation/summary.dita`

The end date of the reason for separation (RFS) transitional measure has been added to all of the RFS tasks. In addition, RFS procedures now advise the Level 1 agent to create a manual record of decision (ROD) when adjudication is not required because the contentious issue is more than 12 weeks before the client’s most recent interruption of earnings (I of E) in the qualifying period (QP). 

## Generic

Source topic: `en_EN/site/dossier/updated_post_eierb_adj_reasons_for_separation/generic.dita`

RFS procedures have been updated to indicate that the transitional measure for adjudicating contentious RFS issues on initial claims applies to all claims with a BPC between w/c 2258 and w/c 2309.

In addition, RFS procedures now advise the Level 1 agent to create a manual ROD when the contentious issue is more than12 weeks before the client’s most recent I of E in the QP. Once the manual ROD is created, the agent resolves the Adjudication (ADJ) WI by selecting Yes to the question Is the decision for this issue is already on file? on the Resolve Issue tab in NWS. The agent then allows the RFS and complete the ADJ WI. 

## Summary Of Changes

Source topic: `en_EN/site/dossier/updated_post_eierb_adj_reasons_for_separation/summary_of_changes.dita`

**Summary Of Changes**

```text
| Item | Description | Impact |
``` 
