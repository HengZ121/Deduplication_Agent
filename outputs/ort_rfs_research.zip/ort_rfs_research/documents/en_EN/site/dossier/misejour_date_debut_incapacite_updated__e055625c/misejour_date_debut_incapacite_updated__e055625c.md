# Updated: Incapacity start date and recovery date — Sickness benefits — Procedures and additional resource (Level 1)

Source map: `en_EN/site/dossier/misejour_date_debut_incapacite_updated__e055625c/misejour_date_debut_incapacite_updated__e055625c.ditamap`

## Summary

Source topic: `en_EN/site/dossier/misejour_date_debut_incapacite_updated__e055625c/summary.dita`

Based on feedback from the regions and the EI Operational Policy Division, clarification has been added in the EI ORT to help the officer to determine if an incapacity start date is required and what it should be, and to determine a recovery week on claims for sickness benefits. 

## Generic

Source topic: `en_EN/site/dossier/misejour_date_debut_incapacite_updated__e055625c/generic.dita`

Incapacity start date

When the reason for separation (RFS) is D - Illness or injury on an initial or renewal claim and no medical certificate needs to be submitted, the incapacity start date is the week of the BPC or the renewal week. This applies even if the client submits a medical certificate that does not need to be submitted.

If the client submits a medical certificate for an extension of a period of sickness benefits and the medical certificate does not indicate that the initial period of sickness is continuing, an incapacity start date is required to continue the payment of benefits immediately after the initial recovery week on the claim.

The information on how to determine the incapacity start date has been updated in order to align with the Proof of Incapacity Policy. If there are no disqualifications or disentitlements on a claim and the RFS is other than D, the officer determines the incapacity start date using the information on the medical certificate.

Clarification has been added to explain that the officer uses the week of the start of the incapacity period when calculating the recovery week.

Recovery date

When the medical certificate states that the client is incapable of working until a specific date, that date is the last day of incapacity and the recovery date is the next day.

When the RFS is D on an initial or renewal claim and there are no disqualifications or disentitlements, the officer uses the BPC or the renewal week as the incapacity start date when determining the recovery week, regardless of whether or not a medical certificate has been submitted. 

## Summary of changes

Source topic: `en_EN/site/dossier/misejour_date_debut_incapacite_updated__e055625c/summary_of_changes.dita`

**Summary of changes**

```text
| Item | Description | Impact |
``` 
