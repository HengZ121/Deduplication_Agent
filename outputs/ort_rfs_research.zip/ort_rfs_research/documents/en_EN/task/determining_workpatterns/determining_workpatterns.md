# Identifying and referring potential work patterns and lay day situations — Level 1

Source map: `en_EN/task/determining_workpatterns/determining_workpatterns.ditamap`

## Summary

Source topic: `en_EN/task/determining_workpatterns/summary.dita`

Summary: When working on a claim, agents must identify potential work patterns and lay day situations and refer the file for adjudication. 

## What you need to know

Source topic: `en_EN/task/determining_workpatterns/what_you_need_to_know.dita`

### Identifying potential lay day situations

Source topic: `en_EN/task/determining_workpatterns/identifying_potential_lay_day_situations.dita`

Quite often, employees regularly work more hours than other individuals working full-time elsewhere. In order to receive benefits, clients must prove that they were unemployed for that week. When clients work more hours than normal and are entitled to a period of leave to compensate for the additional work, the situation must be adjudicated to determine if clients are considered not unemployed during any week in the period of compensatory leave. 

### Defining full-time employment

Source topic: `en_EN/task/determining_workpatterns/defining_full-time_employment.dita`

For the purpose of lay days, full-time employment is defined as the normal number of hours of work that is considered full-time employment in the client’s province or territory of work. This means full-time employment in general, not just for that specific category of work. Agents must refer to Normal number of hours worked per week in full-time employment by province or territory to determine what is considered full-time employment in the province or territory of work.
       [Normal number of hours worked per week in full-time employment by province or territory](/en/procedure/generic/additionalresources/normal_hours_week.shtml) 

### Determining work patterns — Increased number of hours worked per week

Source topic: `en_EN/task/determining_workpatterns/determining_work_patterns__increased_nu_b7ca88a6.dita`

Many employers have developed work patterns in which employees work additional hours in a work week and are compensated for the additional hours with a period of leave.

Common examples of these work patterns are:

- 2 and 1: 12 hours per day, 7 days per week for 2 weeks followed by one week off;

- 3 and 1: 10 hours per day, 7 days per week for 3 weeks followed by one week off.

In these situations, employers normally have employees on varying rotational patterns to ensure that work continues during periods of leave for employees.

Determining if a pattern of additional hours followed by a period of leave exists does not depend on the formal contractual relationship between an employer and employee. The pattern does not have to be established on a regular and weekly basis but there should be an element of predictable repetition. The fact that the work pattern is in place is sufficient to proceed with determining if the client is not unemployed. 

### Defining period of leave (lay days)

Source topic: `en_EN/task/determining_workpatterns/defining_period_of_leave_lay_days.dita`

A client is considered to be on a period of leave (lay days) when both of the following conditions are met:

- The client regularly works a greater number of hours in each week than individuals who have a full-time employment in the client’s province or territory of employment.

- The client is entitled to a period of leave under an employment agreement (contract of service) as a way to compensate for the extra time worked.

When both conditions are met and the period of leave (lay days) falls within the period of employment, clients are considered to have worked a full work week (FWW) for the duration of the work cycle, are not unemployed and are not entitled to benefits for any weeks during which they are on leave (lay days).

The term used to describe the period of leave (i.e. lay days, shore days, period of leave) and whether the client is being paid during the period of lay days do not have any impact on how the issue is adjudicated.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3225.dita) 
     [Example of a regular work pattern without increased hours](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1689.dita) 

### Identifying work pattern issues

Source topic: `en_EN/task/determining_workpatterns/identifying_work_pattern_issues.dita`

Clients may not recognize that their work pattern is contrary to the provisions of EIA 11(4). The pattern of excess work does not need to be established on a regular and weekly basis, but there should be an element of predictable repetition in the pattern of work.

Therefore, when working on a claim, the agent must look for clues that indicate what the client’s work pattern is.

**Work pattern information on the EI application**

When the client files an EI application, questions relating to the rate of pay are asked. On an initial claim, the question “What was your hourly rate of pay or annual salary (before deductions)?” is asked. On a renewal claim the questions “How many hours did you normally work?” and “How many days did you normally work?” are asked.

There is also a question in the Last Employer Information section that asks if the client is returning to work with this employer. A good indicator that the client has a set work pattern is when the answer to that question is yes and the return date is set to be within a short time period from the last day of work.

**Pay period information in RCM**

On some ROEs, block 15C details the number of insurable hours in a pay period. On other ROEs, a pay period with earnings may alternate with another that has no earnings or with less than normal earnings.

**Decision in Major Employer Events (MEE) — Information Bulletin**

In some situations, if a decision concerning a work pattern has already been rendered, the decision might be found in the Major Employer Events . Even if the employer’s name is found in the Major Employer Events , it is the responsibility of the adjudicator to conduct the necessary fact-finding to determine if that client is working the specified work pattern.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 

### Info

Source topic: `en_EN/common_notes/note_c_3225.dita`

**Example of a lay day work pattern**

- ABC Trucking has 2 trucks and employs 4 drivers.

- The employees have a verbal arrangement with the employer to work one week out of every 2 on an alternating basis.

- The employees are not compensated by the employer for the week they do not work.

- This work arrangement ensures that the trucks are always moving, thereby maximizing the profit the employer generates.

- The employees work an average of 50 hours during the week they work.

- The reason for separation on the ROE indicates shortage of work, with an expected return to work of the following week.

- The Employment Standards Act for the province of work indicates that 40 hours per week is considered as full-time employment.

- Since the employees are not working every second week and are not paid for those weeks, they request EI benefits for the week they do not work.

In this case, EI benefits are not payable for the weeks the clients do not work because they meet all the following conditions:

- Every week, they regularly work more hours than a person employed in full-time employment.

- They are entitled to a period of leave under an employment agreement to compensate for the extra time worked.

- There is an agreement in place with the employer for this pattern of work. 

### Example of a regular work pattern without increased hours

Source topic: `en_EN/common_notes/note_c_1689.dita`

Example of a regular work pattern without increased hours

- There are 2 co-workers who are employed in companion home care, caring for an elderly client.

- The employees alternate working 35 hours one week, followed by a week off.

- The employees and employer have agreed to this type of work schedule.

- The Employment Standards Act for the province of work indicates that 40 hours per week is considered as full-time employment.

- Since the employees are not working every second week and are not paid for those weeks, they request EI benefits for the week they do not work.

In this case, there is an agreement between the employer and employees regarding the work pattern; however, the employees do not work excessive hours and are not paid for the week they do not work.

EI benefits may be payable for the weeks the clients do not work if they can prove they meet the availability requirements during their week off. 

## Regional considerations

Source topic: `en_EN/task/determining_workpatterns/regional_considerations.dita`

Atlantic and Western Canada and Territories regions — For events before May 14, 2018, if a decision concerning a work pattern has already been rendered, it can be found in the following databases:

- Atlantic region: Documents are stored in the regional common document share under EI Document Library /LayDays

- Western Canada and Territories region: Employer Information Log
         [Employer Information Log](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/empff.shtml) 

## What you need to look for

Source topic: `en_EN/task/determining_workpatterns/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/determining_workpatterns/in_fts.dita`

- Has the client filed a claimant’s report since the last day of work?

- If yes, how many hours is the client working in a week? 

### In NWS:

Source topic: `en_EN/task/determining_workpatterns/in_nws.dita`

- Has the client indicated an expected date of recall for the last employer?

- If the claim is established, what is the claim type? 

### In RCM:

Source topic: `en_EN/task/determining_workpatterns/in_rcm.dita`

- In block 14 , has the employer indicated that the client is returning to work?

- If yes, what is the expected date of recall?

- Does block 15C display the number of hours worked per pay period?

- Does block 15C display variations in earnings in each pay period? 

## Step by step

Source topic: `en_EN/task/determining_workpatterns/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/determining_workpatterns/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/determining_workpatterns/reviewing_the_file_level_1.dita`

- In the Major Employer Events , determine if there is any information relating to lay days for that employer:

- If no, go to step 2.

- If yes, go to step 9.

- Review the application and the ROE to determine if the client is returning to work for that employer:

- If the application, the ROE, or both indicate the client is returning to work for that employer, go to step 3.

- If there is no information about that employer on the application or ROE, go to step 3.

- If the application and the ROE indicate no or unknown and the client is not returning to work for that employer, go to step 13.

- In FTS, on the E-Report tab, determine if the client has submitted claimant’s reports:

- If no, go to step 4.

- If yes, note the number of hours that the client reported for each week. Go to step 7.

- In RCM, determine if block 15C on the ROE of that employer displays the number of hours worked by pay period:

- If no, go to step 5.

- If the ROE for that employer is not on file, go to step 5.

- If yes, note the number of hours regularly worked per pay period and go to step 7.

- Determine if block 15C of the ROE of that employer regularly displays variations in earnings:

- If yes, go to step 6.

- If the ROE for that employer is not on file, go to step 6.

- If no, go to step 7.

- Determine if the variations indicate that the client may be working more hours in some weeks and less or no hours in the following weeks:

- If yes, go to step 7.

- If no, there is no lay day issue. Return to the originating task.

- Determine what is considered as full-time employment in the client’s province or territory of work. Refer to Normal number of hours worked per week in full-time employment by province or territory for the province of work.

- Determine if the client regularly works more hours in a week than what is considered as full-time employment in the client’s province or territory of work:

- If yes, go to step 9.

- If no, there is no lay day issue. Return to the originating task. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/determining_workpatterns/reassigning_the_issue_to_level_2_level_1.dita`

- Determine the claim type:

- If it is an initial or renewal claim, go to step 10.

- If it is a continuing claim, go to step 11.

- In NWS, create an Adjudication Issue WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Destination — SCC: Enter the Service Canada centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue(s): Select Availability .

- Details: Type “Adjudication required — possible lay day situation.”

- Click Save .

- Go to step 13.

- In FTS, select the Renewal/Revised (M106) transaction and input a 1 - General suspension of benefits (stop payments) manual action (MA01) as follows:

- Registration number: Leave blank or if a registration number is shown, remove it.

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Click Update .

- In NWS, create a Claim Review WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Destination — SCC: Enter the SCC as shown in FTS.

- BPC: Enter the BPC on which the issue is to be adjudicated.

- Click Save .

- Return to originating task or complete the WI. 

## Policy reference

Source topic: `en_EN/task/determining_workpatterns/policy_reference.dita`

- BE 2016-08 — Not Unemployed: Lay Days and other Work Patterns
         [BE 2016-08 — Not Unemployed: Lay Days and other Work Patterns](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2016-08.shtml)

- Digest 4 — Week of unemployment
         [Digest 4 — Week of unemployment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-4/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- EIA 11
         [EIA 11](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-11.html)

- EIR 14(3)
         [EIR 14(3)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-14.html)

- EIR 31
         [EIR 31](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-31.html) 
