# Adjudicating voluntary leaving (Level 1): Medical reasons — Continuing claim

Source map: `en_EN/task/voluntary_leaving_medical_reason_l1/voluntary_leaving_medical_reason_l1.ditamap`

## Summary

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/summary.dita`

Summary: When a client voluntarily leaves employment for medical reasons, entitlement to regular benefits on a continuing claim may be affected. Adjudication is required to determine if there is just cause for leaving the employment. 

## What you need to know

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/what_you_need_to_know.dita`

### Adjudicating voluntary leaving for medical reasons

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/adjudicating_voluntary_leaving_for_medi_f364db99.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4947.dita) 

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave the employment. If it is determined that the client left the employment without just cause, a disqualification is imposed on the claim for regular benefits, unless the client has worked enough insurable hours since the voluntary leaving to establish a new claim. In this case, the ROE with the voluntary leaving is excluded from the calculation of the claim.

Medical documentation supporting the voluntary leaving is required to render a decision at Level 1 ( National Policy on Levels of Decision ). If the client does not provide acceptable medical documentation related to the voluntary leaving, a Level 2 officer must adjudicate the reason for separation (RFS). Medical documentation is accepted from a licensed medical doctor (Canadian or American) or, if the illness being treated is within the practitioner’s field, from the following practitioners:
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- psychologist;

- chiropractor;

- optometrist;

- podiatrist;

- dentist;

- registered doctor of traditional Chinese medicine or Registered traditional Chinese medicine practitioner recognized by the province;

- nurse practitioner;

- midwife;

- registered nurse (only in isolated areas when a doctor is not available).

An ROE is not required to adjudicate voluntary leaving. 

### Automated adjudication

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/automated_adjudication.dita`

ACP does not adjudicate voluntary leaving on a continuing claim. 

### Levels of decision

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/levels_of_decision.dita`

When specific conditions are met, the Level 1 officer may adjudicate and allow the voluntary leaving when it is based on a doctor’s recommendation or a temporary medical condition. 

### Doctor’s recommendation

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/doctors_recommendation.dita`

- A licensed medical practitioner recommended that the client leave the employment.

- The client provides medical documentation or another certificate showing the doctor’s recommendation. 

### Temporary medical condition

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/temporary_medical_condition.dita`

- The client provides medical documentation supporting the temporary condition.

- The employer confirms all of the following:

- The client requested a leave of absence.

- The leave of absence was denied.

- There were no other suitable positions available for the client.

When the Level 1 officer cannot adjudicate the issue, the facts are documented and the voluntary leaving is referred to Level 2 for adjudication. 

### Employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/employment_is_not_insurable.dita`

Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is not required if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. 

### Actions required following adjudication

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/actions_required_following_adjudication.dita`

When the voluntary leaving is adjudicated and the ROE is received, the Special condition field of the ROE must be updated to show either Voluntary leaving - Just cause or Voluntary leaving - No just cause . 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Previously deferred decision

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D11 that is on file and update the Special Condition field on the ROE in RCM. 

### Note

Source topic: `en_EN/common_notes/note_c_4947.dita`

Note:

The temporary measure for medical certificates ends September 25, 2021. For all benefit periods (BPs) with a BPC or renewal week of September 26, 2021 (w/c 2310) or later, the officer follows normal procedures.

For BPs with a BPC or renewal week between March 15, 2020 (w/c 2230) and September 19, 2021 (w/c 2309), a client is not required to provide a medical certificate when the client needs to justify an RFS for medical reasons. 

## Regional considerations

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Voluntary Leave section of this or a previous EI application?

- Are there any SROCs, Action item (AI) WIs or documentation containing checklists or other details relating to the voluntary leaving on this or a previous EI application?

- Has medical documentation been uploaded? 

### In FTS:

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/in_fts.dita`

- Is there a 75 - Verification of reason for termination of Employment manual action (MA75) imposed to stop payments?

- Is there a registration number? 

### In Imaging:

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving? (Documents may have been received prior to the most recent application.)

- Is there medical documentation on file? 

### In RCM:

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/in_rcm.dita`

- Has an ROE been received for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving? 

## Step by step

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/reviewing_the_file_level_1.dita`

- Determine if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 2.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_medical_reason_l1#Employment_is_not)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if there is enough information to adjudicate the voluntary leaving based on the National Policy on Levels of Decision:

- If additional details are needed, go to step 5.

- If additional details are not needed, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/fact-finding_level_1.dita`

- Determine if an acceptable medical certificate is on file:

- If yes, fact-find with the client or the employer
               [fact-find](/en/procedure/task/fact_find.shtml)

- If no, fact-find with the client to request the additional details and the medical certificate.
               [fact-find](/en/procedure/task/fact_find.shtml)

- Determine if the client or employer was contacted during fact-finding:

- If the client or employer was contacted, go to step 7.

- If the client or employer was not contacted and did not reply to the N-10-00-00 or Z-00-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_medical_reason_l1#reassign2)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type one of the following:

- If an acceptable medical certificate is on file: “Voluntary leaving — employer’s name — last day worked — [client or employer].”
                   [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

- If an acceptable medical certificate is not on file: “Conversation with the client — medical proof needed.”
                   [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if an acceptable medical certificate is on file:

- If no, go to step 9.

- If yes, go to step 12.

- Determine if the client indicates that a medical certificate will be submitted:

- If yes, go to step 10.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_medical_reason_l1#reassign2)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Medical certificate .

- Comments: Type “Awaiting medical certificate.”

- Bring forward date: Enter the day the client was contacted + 10 working days.

- Select Save .

- When the WI moves to the current workload, determine if the medical certificate has been received:

- If yes, go to step 12.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_medical_reason_l1#reassign2)

- Determine if the conditions are met to adjudicate the issue at Level 1 by referring to the applicable situation below.

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4949.dita) 

- If all related criteria are met, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_medical_reason_l1#_Reason_for_separation)

- If all related criteria are not met, or there is contradictory or contentious information on file regarding the reason for leaving, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_medical_reason_l1#reassign2) 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — just cause.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In RCM, verify if the ROE with the voluntary leaving has been received:

- If yes, go to step 3.

- If no, go to step 4.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select E – Quit / Health Reasons .

- Special condition: Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the voluntary leaving from block 18 to the Additional information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3230.dita)

- In FTS, determine if there is a D11 on file because this RFS adjudication was previously deferred:

- If yes, go to step 5.

- If no, go to step 7.

- Determine if the D11 is solely due to this previously deferred RFS issue and if no other issues must be adjudicated:

- If no other issues must be adjudicated, go to step 6.

- If other issues must be adjudicated, go to the appropriate task for guidance. Then, go to step 6.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F – Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Determine if an MA75 is imposed and if there is a registration number:

- If an MA75 is imposed but there is no registration number, go to step 8.

- If an MA75 is imposed and there is a registration number, go to step 9.

- If an MA75 is not imposed but there is a revised registration number, go to step 10.

- If none of the above applies, go to step 11.

- Select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and remove the MA75 as follows:

- Registration number: Select the applicable registration number.

- Manual action: Select 75 - Verification of reason for termination of Employment .

- Rescind: Check the box.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 11.

- Select the Renewal/Revised (M106) transaction and clear the outstanding registration as follows:

- Claim allowed: Select NCA - no change on the claim .

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI related to the voluntary leaving. 

#### Employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Complete the WI related to the voluntary leaving. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/reassigning_the_issue_to_level_2_level_1.dita`

- In FTS, on the Summary tab, determine if an MA75 has been imposed:

- If yes, go to step 2.

- If no and the client is requesting special benefits, go to step 2.

- If no and the client is requesting regular benefits, select the Renewal/Revised (M106) transaction and impose the MA75 as follows:

- Registration number: Leave the field blank. If a number is displayed, remove it.

- Manual action: Input 75 - Verification of reason for termination of Employment .

- Select Update .

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “The client quit [his/her] job due to medical reasons and [provide a brief reason for the referral, e.g. doctor did not authorize quit] — unable to complete at Level 1.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4949.dita`

Voluntary leaving based on a doctor’s recommendation — Criteria to be met to adjudicate the issue at Level 1

- The client voluntarily leaves employment for medical reasons on the advice of a licensed medical practitioner.

- The client provides medical documentation or another medical certificate confirming that the voluntary leaving is for a medical reason.

Voluntary leaving due to a temporary medical condition — Criteria to be met to adjudicate the issue at Level 1

- The client voluntarily leaves employment due to a temporary medical condition.

- The client provides medical documentation or another medical certificate confirming the temporary medical condition.

- The employer confirms that the client’s request for a leave of absence was denied and that no other suitable positions are available for the client. 

#### Note

Source topic: `en_EN/common_notes/note_c_3230.dita`

Note:

Selecting Validate may cause the ROE to be flagged with an error. If this occurs, no further action is required. If the client submits another claim, the ROE is corrected at that time. 

## Policy reference

Source topic: `en_EN/task/voluntary_leaving_medical_reason_l1/policy_reference.dita`

- Digest 6 — Voluntarily leaving employment
         [Digest 6 — Voluntarily leaving employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/table-of-contents.html)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html) 
