# Adjudicating voluntary leaving: Initial Claim — Level 2

Source map: `en_EN/task/vllevel2_ic/vllevel2_ic.ditamap`

## Summary

Source topic: `en_EN/task/vllevel2_ic/summary.dita`

Summary: When clients voluntarily leave employment, their entitlement to regular benefits on an initial claim may be affected. If the reason for separation (RFS) cannot be allowed at Level 1 according to the National policy on Levels of Decision , the voluntary leaving must be adjudicated at Level 2 to determine if the client had just cause for leaving the employment.
       [National policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

## What you need to know

Source topic: `en_EN/task/vllevel2_ic/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/vllevel2_ic/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4962.dita) 

### Adjudicating voluntary leaving

Source topic: `en_EN/task/vllevel2_ic/adjudicating_voluntary_leaving.dita`

The adjudication process is the same (though the inputs are different) for the following types of voluntary leaving:

- permanently leaving employment

- taking a temporary leave of absence from employment (refer to Adjudicating a voluntary leave of absence — Level 2 )
         [Adjudicating a voluntary leave of absence — Level 2](/en/procedure/task/adjudicating_loa_l2.shtml)

- leaving employment early in anticipation of a layoff or the end of the term of employment

**ROE**

An ROE is not required to adjudicate voluntary leaving.

In NWS, there may be a New ROE message displayed on the ADJ WI for the voluntary leaving issue. The message indicates that a new ROE has been received with an RFS that must be reviewed. The ROE may match the period of employment for that or another outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4936.dita) 

**Determining just cause**

When clients voluntarily leave their employment, you must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave. If it is determined the client left the employment without just cause, an indefinite disqualification is imposed on the claim for regular benefits, unless the client has worked enough insurable hours since the voluntary leaving to establish a new claim. In that case, on an initial claim, the ROE with the voluntary leaving without just cause is excluded from the calculation of the claim.

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is only required on the most recent ROE in the QP, if the RFS is contentious. In addition, the common entrance requirement of 420 hours of insurable employment is not used to determine if the client requalifies after a disqualifying event. Instead, the client needs to have worked at least one hour in insurable employment since the disqualifying event and to have filed an EI application.

If the RFS since the disqualifying event on claims with a BPC between w/c 2310 and w/c 2361 is either non-contentious or is adjudicated and allowed, the officer can establish a new claim without a disqualification using the hours from all the ROEs in the QP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4963.dita) 

When the Level 1 officer cannot allow the voluntary leaving according to the National policy on Levels of Decision , the Level 2 officer must fact-find to determine if the client has just cause and render a decision. It must first be proven that the client left the employment voluntarily. Once it is established that the client initiated the leaving, just cause is determined as follows:
       [National policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- If the client demonstrates that there was no reasonable alternative to leaving the employment, just cause is shown.

- If the client does not demonstrate that there is no reasonable alternative to leaving the employment, just cause is not shown. 

### Fact-finding

Source topic: `en_EN/task/vllevel2_ic/fact-finding.dita`

The adjudicating officer gathers all relevant information and completes all fact-finding before adjudicating the issue. The Level 2 officer must:

- offer the client and the employer the opportunity to provide information concerning the RFS;

- allow both parties to provide an explanation or clarification when there are contradictory statements;

- give the client the opportunity to provide a final rebuttal;

- take this information into account when adjudicating the issue;

- give the client the benefit of the doubt when the facts provided by the client and those provided by the employer are equally credible.

**Fact-finding — Voluntary leaving for personal reasons**

In cases where clients voluntarily leave their employment strictly for personal reasons (e.g. returning to school, changing careers, providing care for an ill child), it is unnecessary to contact the employer again after the initial fact-finding if:

- the facts are credible;

- considering all factors, it is unlikely that the employer has any information about the existence or absence of other reasonable alternatives for the client.

**Client wishes employer not be contacted**

In cases where the voluntary leaving is not strictly for personal reasons and the client does not want the employer to be contacted, officers must explain that they are legally required to fact-find with the employer. If the client insists that the employer not be contacted, officers advise the client that the only alternative is to withdraw the claim for benefits. Officers document the client’s request to withdraw the claim. Refer to Withdrawing an application .
       [Withdrawing an application](/en/procedure/task/withdraw_an_app.shtml)

**Refusing employment**

Voluntarily leaving an employment can also include:

- refusing employment that is offered as an alternative to an anticipated loss of employment (the voluntary leaving occurs when the loss of employment occurs);

- refusing to resume an employment (the voluntary leaving occurs when the employment is meant to resume);

- refusing to continue an employment after the work, undertaking or business of the employer is transferred to another employer.

**Mandatory retirement**

Human rights legislation in Canada prohibits mandatory retirement. Very few occupations are exempt from this legislation. Some employers may be able to demonstrate a genuine reason for mandatory retirement, however these cases are rare.

In cases of mandatory retirement, clients do not voluntarily leave their employment. The separation is initiated by the employer. Consequently, a Level 2 officer must adjudicate the reason for separation as a dismissal and determine whether the client lost the employment due to misconduct.
       [dismissal](/en/procedure/task/dismissal_ds_ic.shtml) 

### Imposing a disqualification or disentitlement

Source topic: `en_EN/task/vllevel2_ic/imposing_a_disqualification_or_disentitlement.dita`

Once it is determined that the client did not have just cause for voluntarily leaving the employment, the officer must determine whether an indefinite disqualification or disentitlement applies.

**Imposing a disentitlement**

If the client voluntarily left the employment within 3 weeks of an anticipated layoff or the end-of-term employment, the 44 - Loss of employment in anticipation of layoff disentitlement (D44) is imposed. The D44 is imposed for a definite period only (maximum 3 weeks).

**Imposing a disqualification**

If the client voluntarily left the employment more than 3 weeks before an anticipated layoff and in all other cases , the 11 - Voluntary leaving - just cause not proven indefinite disqualification (D11) is imposed.

**Suspending a disqualification or disentitlement**

The D11 disqualification and the D44 disentitlement are suspended when special benefits are claimed and otherwise payable. 

### Automated adjudication

Source topic: `en_EN/task/vllevel2_ic/automated_adjudication.dita`

ACP does not automate a Level 2 decision for voluntary leaving.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3239.dita) 

### Notifying the employer

Source topic: `en_EN/task/vllevel2_ic/notifying_the_employer.dita`

The employer must be notified in writing of the decision and provided with the right to request a reconsideration in the case of voluntary leaving when the reasons for leaving are work-related , but just cause for leaving was shown. 

### Claim action status and processing the claim

Source topic: `en_EN/task/vllevel2_ic/claim_action_status_and_processing_the_claim.dita`

During processing, an initial claim will display one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can process the claim. There is a Resolve Issue tab for ADJ Voluntary leaving WIs, which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a ROD based on the Resolve Issue screens. Before the claim is calculated, the system updates the ROE based on the Resolve Issue screens. Before the claim is established, the system also generates the disqualification or disentitlement transaction, if required by the decision. If the voluntary leaving is allowed and the employer must be notified, the system automates the Z-01-00-00 letter, or creates a Correspondence (COR) WI. If the voluntary leaving is not allowed, the system creates a COR WI for the D-01-00-00 or N-00-00-00 letter. 

### Reason for separation (RFS) in the benefit period (BP) and In Progress claim action status

Source topic: `en_EN/task/vllevel2_ic/reason_for_separation_rfs_in_the_benefi_eaeeaa7b.dita`

A client may find employment at the beginning of the BP and subsequently leave or lose that employment before the initial claim is established. An Adjudication Issue (ADJ) WI is created for officers to adjudicate the contentious RFS. When the decision is that the client did not have just cause for voluntarily leaving their employment and that a D11 indefinite disqualification applies in the BP, the system does not automatically impose the disqualification in the BP when the officer completes the screens on the Resolve Issue tab.

When adjudicating an RFS issue in the BP of a claim for which the Claim action status is In Progress , the Level 2 officer documents the decision on the Resolve Issue tab of the ADJ WI, verbally communicates the negative decision to the client and creates a draft of the D-01-00-00 letter as normal. However, the Level 2 officer also manually inputs a D15 and creates a Reminder (REM) WI for Level 1 before completing the ADJ WI.

The Level 2 officer manually imposes a D15 effective from the Monday of the week of the disqualifying event. Imposing the D15 allows the claim to continue in automation and prevents the payment of benefits from the date the client does not have just cause for voluntarily leaving their employment in the BP.

When creating the REM WI for Level 1, the Level 2 officer includes instructions to impose the indefinite D11, rescind the D15 and send the D-01-00-00 letter. The Level 1 officer waits until the claim is established before actioning the REM WI. 

### Previously adjudicated voluntary leaving

Source topic: `en_EN/task/vllevel2_ic/previously_adjudicated_voluntary_leaving.dita`

In some cases, the ADJ WI may be for a voluntary leaving issue that was previously adjudicated. The officer indicates on the Resolve issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the appropriate special condition based on the previous decision. The system updates the ROE when the ADJ WI is completed. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/vllevel2_ic/determining_if_the_file_must_be_referre_f4ff817e.dita`

When the RFS was undisclosed on a previous claim and a potential overpayment situation exists, refer to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/vllevel2_ic/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the voluntary leaving is not required if the employment is not insurable either because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, the ADJ WI must not be completed. The officer follows the procedures and conditions for removal of claims from ACP process . The officer moves the ADJ WI to Pending until the Claim Assessment (CA) or Specialized Application (SA) WI is created. An authorized user must then delete the ADJ WI.
       [procedures and conditions for removal of claims from ACP process](/en/procedure/generic/additionalresources/removing_initial_claims_acp.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4925.dita) 

### Reason for separation (RFS) — Temporary Budget measures

Source topic: `en_EN/task/vllevel2_ic/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**BPC’s between w/c 2310 and w/c 2361— Adjudicating the last employment in the qualifying period (QP)**

Budget 2021 has introduced a temporary simplification measure starting September 26, 2021. For claims with a BPC between w/c 2310 and w/c 2361, the officer will only adjudicate the last period of employment in the QP if it is contentious. If the officer allows the last RFS, all other ROEs in the QP, even if they are contentious, are used to calculate the claim. If, however, the officer does not allow the RFS on the last ROE in the QP, the claim is calculated with a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 

This new measure does not apply to fishing claims and claims from self-employed people. Instead, if clients have insurable employment in the QP with a contentious RFS and a BPC between w/c 2310 and w/c 2361 when they apply for self-employment (SE) or fishing benefits, the officer must adjudicate the contentious RFS following normal adjudication procedures.

When the client declares other employers with a contentious RFS on the same application, if ACP does not allow the issue under auto-adjudication rules, the issue is automatically resolved and ACP creates a record of decision (ROD) that shows Adjudication not Required . The Special condition field on the ROE is not updated, and the ROE is included in the calculation. An Adjudication Issue (ADJ) WI is not created for the RFS.

ACP does not always automatically create an ADJ WI when the application is received. However, if an ROE with a contentious RFS is received during the automation process, ACP may create an ADJ WI or ROE Issue (ROE) RFS Action WI.

When there is more than one ROE with the same last day paid (LDP), and one of the ROEs is contentious while the other ROE is not, adjudication is not required and both ROEs are included in the calculation.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4932.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4927.dita) 

### Adjudication not required: Reason for separation (RFS) beyond 12 weeks — BPCs between w/c 2258 and w/c 2309

Source topic: `en_EN/task/vllevel2_ic/adjudication_not_required_reason_for_se_2ca905dc.dita`

Adjudication principles on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309 only apply to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the I of E used to establish the claim.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3243.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4964.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4962.dita`

Note:

If the adjudication of the voluntary leaving is part of a recalculation or if it is a Claim Review (CR) WI, the officer must refer to Adjudicating voluntary leaving: Continuing claim — Level 2 .
       [Adjudicating voluntary leaving: Continuing claim — Level 2](/en/procedure/task/voluntary_leaving_l2.shtml)

     [Adjudicating voluntary leaving: Continuing claim — Level 2](/en/procedure/task/voluntary_leaving_l2.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4936.dita`

Note:

The client may report voluntary leaving on the application for benefits but the ROE indicates a non-contentious RFS. In this situation, fact-finding is required. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the WI is completed indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_4963.dita`

Note:

For claims with BPCs between w/c 2310 and w/c 2361, excluded ROEs only apply to SE and fishing claims. 

### Note

Source topic: `en_EN/common_notes/note_c_3239.dita`

Note:

If a claim is between w/c 2310 and w/c 2361 and all ROEs are on file, ACP may automatically resolve ADJ RFS WIs for periods of employment other than the last. 

### Note

Source topic: `en_EN/common_notes/note_c_4925.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Example 1

Source topic: `en_EN/common_notes/note_c_4932.dita`

Example 1:

Peter’s LDP was September 28, 2021 (w/c 2310) with 2 employers. Three periods of employment are provided on his EI application. Peter declared Employer 1 as his last employer and the RFS is shortage of work. In the Other Employers section of the application, Peter declared Employer 2 and the RFS is voluntary leaving. He also declared Employer 3 and the RFS is dismissal. The interruption of earnings (I of E) is in w/c 2310, and he applied for benefits on September 29, 2021. His BPC is September 26, 2021 (w/c 2310).

There are 2 contentious ROEs on Peter’s file:

Employer 1: The LDP is September 28, 2021 (w/c 2309). The RFS is A .

Employer 2: The LDP is September 28, 2021 (w/c 2309). The RFS is E .

Employer 3: The LDP is May 19, 2021 (w/c 2291). The RFS is M .

Employer 1 and Employer 2 have the same LDP. The RFS with Employer 1 is non-contentious, so adjudication is not required for Employer 2. ACP automatically resolves the RFS for Employer 2 and creates a ROD that shows Adjudication not required .

The RFS with Employer 3 is contentious and is in the QP. However, because it is not the last employer in the QP, adjudication is not required. ACP creates a ROD that shows Adjudication not required .

All ROEs are included in the calculation of the claim. 

### Example 2

Source topic: `en_EN/common_notes/note_c_4927.dita`

Example 2:

Abdul’s LDP was September 24, 2021 (w/c 2309) with both of his employers. He declared Employer 1 as his last employer and the RFS is voluntary leaving. In the Other Employers section of the application, Abdul declared Employer 2 and the RFS is dismissal. The I of E is in w/c 2309, and he applied for benefits on September 26, 2021. His BPC is September 26, 2021 (w/c 2310).

- Employer 1: The LDP is September 24, 2021 (w/c 2309). The RFS is E .

- Employer 2: The LDP is September 24, 2021 (w/c 2309). The RFS is M .

Employer 1 and 2 have the same LDP and the RFS with both employers are contentious. ACP creates an ADJ WI for Employer 1, automatically resolves the RFS issue for Employer 2 and creates a ROD that shows Adjudication not required . If the leave of absence with Employer 1 is not allowed, the RFS with Employer 2 must be adjudicated. 

### Example

Source topic: `en_EN/common_notes/note_c_3243.dita`

Example:

Mary’s LDP was September 25, 2020 (w/c 2257). Her I of E is in w/c 2257, she submitted her application for benefits on September 26, 2020, and her BPC will be September 27, 2020 (w/c 2258).

There are 3 contentious ROEs on Mary’s file:

ROE 1: LDP September 25, 2020 (w/c 2257).

ROE 2: LDP July 17, 2020 (w/c 2247).

ROE 3: LDP May 31, 2020 (w/c 2241).

To determine which RFS to adjudicate, the officer subtracts 12 weeks from w/c 2257 (week of the I of E). For the example above, the formula is as follows: w/c 2257 (I of E) – 12 = w/c 2245. This determines a 12-week period falling before the Sunday of the I of E that encompasses the weeks from w/c 2245 to w/c 2256. The officer follows normal procedures and adjudicates ROE 1, which is the most recent ROE in the QP, and ROE 2, as it falls between w/c 2245 and w/c 2256, the 12-week period.

The officer allows any contentious RFS that occurs before the 12-week period. ROE 3 is before the 12-week period, so the officer allows the RFS by following the steps of Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
       [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#beyond_12_wks)

     [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#beyond_12_wks) 

### Note

Source topic: `en_EN/common_notes/note_c_4964.dita`

Note:

For information regarding RFS issues resulting from a client not complying with the employer’s COVID-19 vaccination policy, the officer refers to EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo) .
       [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml)

     [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml) 

## Regional considerations

Source topic: `en_EN/task/vllevel2_ic/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/vllevel2_ic/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/vllevel2_ic/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a prior application?

- What is the client’s statement in the Voluntary Leave section of this or a prior application?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the voluntary leaving on this or a prior application?

- What benefit type (BT) is the client applying for?

- Is the appropriate ROE linked to the period of employment for the voluntary leaving issue? 

### In Imaging:

Source topic: `en_EN/task/vllevel2_ic/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving? (Documents may have been received before the date of the most recent application). 

### In RCM:

Source topic: `en_EN/task/vllevel2_ic/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving?

- Are there other ROEs since the voluntary leaving?

- If so, does the client have enough hours after the voluntary leaving to qualify for benefits? 

## Step by step

Source topic: `en_EN/task/vllevel2_ic/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/vllevel2_ic/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/vllevel2_ic/reviewing_the_file_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, determine if the appropriate ROE is linked to the period of employment:

- If yes, go to step 2.

- If no , select the appropriate ROE in the list and select Save to create a link.

- If the ROE is not on file, go to step 2.

- Determine if there is a ROD for the voluntary leaving issue on file:

- If there is a ROD for the voluntary leaving issue, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_ic#DecOnFile)

- If there is no ROD for the voluntary leaving issue, go to step 3.

- Determine if the client is correcting previously provided information or providing previously omitted information, determine if the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 4.

- If yes, determine if the issue should be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if the facts on the file clearly indicate that the RFS occurred before the qualifying period:

- If no, go to step 5.

- If yes, go to Reason for separation (RFS) occurred before the qualifying period (QP) .
               [Reason for separation (RFS) occurred before the qualifying period (QP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_ic#RFSOutsideQP)

- In FTS, determine if the BPC falls in a period where special measures apply:

- If the BPC is between w/c 2258 and w/c 2309, go to step 6.

- If the BPC is between w/c 2310 and w/c 2360, go to step 8.

- If the BPC is not in either of the periods, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita)

- Determine if the voluntary leaving occurred on the most recent ROE:

- If no, go to step 7.

- If yes, go to step 10.

- Determine if the voluntary leaving occurred within the 12-week period before the I of E:

- If yes, go to step 10.

- If no, go to Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
               [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_ic#beyond_12_wks)

- Determine if the claim is for SE or fishing benefits:

- If no, go to step 9.

- If yes, go to step 10.

- Determine if the voluntary leaving occurred on the most recent ROE:

- If yes, go to step 10.

- If no, go to Adjudication not required — Budget 2021 simplification measures .
               [Adjudication not required — Budget 2021 simplification measures](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_ic#adj_not_required_budget_2021)

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if employment is not insurable because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 12.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_ic#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if there is enough information on file to adjudicate the RFS:

- If no, go to step 13.

- If yes, go to step 16. 

#### Fact-finding

Source topic: `en_EN/task/vllevel2_ic/fact-finding_level_2.dita`

- Fact-find with the client and the employer. Refer to the Fact-Finding Guide and Digest 6 — Voluntarily Leaving Employment to determine the questions to ask.

- Determine if the client or employer was reached during fact-finding:

- If the client or employer was reached, go to step 15.

- If the client or employer was not reached or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to step 16.

- In NWS, add to the draft SROC or create a new SROC as follows:

- Issue: Select Reason for separation .

- Comments: Type “Voluntary leaving — [employer’s name] — [LDW] — [client or employer].”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1746.dita) 

#### Adjudicating voluntary leaving

Source topic: `en_EN/task/vllevel2_ic/adjudicating_voluntary_leaving_level_2.dita`

- Determine if the RFS is contentious:

- If the RFS is voluntary leaving, go to step 17.

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS) .
               [Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_ic#NotContentious)

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if just cause is proven, considering all evidence provided by both the client and the employer, and in accordance with the principles outlined in the EIA, EIR and case law (refer to Digest 6 — Voluntary leaving employment as needed):

- If the client has not shown just cause, go to step 18.

- If the client has shown just cause, go to Just cause shown .
               [Just cause shown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_ic#JustCauseShown)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1747.dita)

- Determine if the client left within 3 weeks of an anticipated layoff or end-of-term employment.

- If the client did not leave within 3 weeks of an anticipated layoff or end-of-term employment, go to Just cause not shown .
               [Just cause not shown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_ic#Justcausenotshown)

- If the client left within 3 weeks of an anticipated layoff or end-of-term employment, go to Voluntary leaving before anticipated end of employment — Just cause not shown .
               [Voluntary leaving before anticipated end of employment — Just cause not shown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_ic#D44) 

#### Adjudication not required — Budget 2021 simplification measures

Source topic: `en_EN/task/vllevel2_ic/adjudication_not_required__budget_2021__620824ac_level_2.dita`

- In NWS, on the General Details tab of the ADJ WI, change the complexity as follows:

- Complexity: Select Level 1 .

- Select Save .

- Select Continue .

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Resolve issue: Select Adjudication not required - Budget 2021 EI Simplification Measures .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Just cause not shown

Source topic: `en_EN/task/vllevel2_ic/just_cause_not_shown_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Enter the employer’s name.

- Enter the date of the voluntary leaving.

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Relevant Facts: Enter the relevant facts.

- Indicate if the employer agrees with the client’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if required.

- Rationale: Select No and enter any additional information.

- References: Select EIA 30 and enter any additional references.

- Decision: Select Voluntary Leaving - Just cause not shown .

- Do you wish to enter a disentitlement (D-44, anticipated loss of employment)?: Select No .

- Select Continue .

- Verbally communicate the decision to the client.

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- In ACS, create and save a D-01-00-00 letter for regular benefits, or a N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits and does not have enough hours since the voluntary leaving to qualify, select the following attributes:

- Disqualifications – Definite/indefinite – Previous/current /revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542) .

- D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542): Select Disqualification message (2543) .

- Disqualification message(2543): Select D11 - Voluntary leaving .

- D11 - No benefits payable (Date of event: before, on, or after the BPC date) (2544): Select Date of event on or before BPC or Date of event after BPC and the appropriate sub-options.

- D11 - Min hrs for reg ben/Insuf. hrs accum. Since event reg/Insuf. hrs/reg+ earnings/fishing (2545):

- If the client has not worked since the disqualifying event, select Minimum hours required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious there are insufficient hours since the disqualifying event to qualify, select Insufficient hours accumulated since event for regular or Insufficient hours accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but you do not have the information or knowledge to complete this block, select Min hrs required to qualify for regular benefits .

- If the client is requesting regular benefits and has enough hours since the voluntary leaving to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE Excluded due to voluntary leave not just cause or misconduct .

- Text - Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (1503): Select D11 message .

- If the client is requesting special benefits and does not have enough hours since the voluntary leaving to qualify for regular benefits, select the following attributes:

- Special benefits approved (3046): Select the benefit type and the appropriate options.

- Not Entitled to Regular AFTER Special: D10/D11 or Claim is BPNE – Initial or Renewal claim or D42 - D43 (2540): Select (D11/D10) imposed – Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491): Select D11 imposed – Special benefits allowed .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D11 - Min hrs req for reg ben/Insuf. hrs accum. Since event reg/Insuf. hrs/reg+earnings/fishing (2545):

- If the client has not worked since the disqualifying event, select Minimum hours required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious there are insufficient hours since the disqualifying event to qualify, select Insufficient hours accumulated since event for regular or Insufficient hours accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but you do not have the information or knowledge to complete this block, select Minimum hours required to qualify for regular benefits .

- If the client is requesting special benefits and has enough hours since the event to qualify for regular benefits, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (2463): Select D11 message .

- Special Benefits Approved (3046): Select benefit type and the appropriate options.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In FTS, determine if the voluntary leaving occurred after the tentative BPC:

- If no, go to step 7.

- If yes, go to Just cause not shown — Reason for separation (RFS) in the benefit period (BP) .
               [Just cause not shown — Reason for separation (RFS) in the benefit period (BP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_ic#_Misconduct_Proven_Reason)

- In NWS, create a client Note instructing the responsible officer to add the appropriate attributes before sending the saved D-01-00-00 or N-00-00-00 letter in ACS when completing the COR WI.

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/vllevel2_ic/decision_already_on_file_level_2.dita`

- Determine if the appropriate decision is listed:

- If yes, on the list, select the appropriate ROD and select Save . Go to step 4.

- If no , select Decision not in the list .

- Select the appropriate special condition option based on the decision on file and select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reason for separation (RFS) occurred before the qualifying period (QP)

Source topic: `en_EN/task/vllevel2_ic/reason_for_separation_rfs_occurred_befo_370bd688_level_2.dita`

- In NWS, on the General Details tab of the ADJ WI, change the complexity of the WI as follows:

- Complexity: Select Level 1 .

- Select Save .

- When the Warning window is displayed, select OK .

- On the Resolve Issue tab of the ADJ WI, complete the Level 1 voluntary leaving screen as follows:

- Select The period of employment falls prior to the qualifying period .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Adjudication not required – Reason for separation (RFS) beyond 12 weeks

Source topic: `en_EN/task/vllevel2_ic/adjudication_not_required__reason_for_s_d81cc200_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Enter the employer’s name.

- Enter the date of the voluntary leaving.

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Relevant Facts: Type “Reason for separation is beyond the 12-week period and adjudication is not required.”

- Does the employer agree with the client’s version of the events?: Select Not appropriate .

- Credibility: Select Credibility was not a factor in the decision-making process .

- Rationale: Select Yes .

- Additional information: Type “Post-Employment Insurance Emergency Response Benefit transitional measure.”

- References: Any additional references: Type “EIA 153.194.”

- Decision: Select Voluntary Leaving - Just cause shown .

- Written Notification: Select No .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/vllevel2_ic/employment_is_not_insurable_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [LDW] —adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed people). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the shares in the business. Adjudication of the voluntary leaving is therefore not required.”

- Determine the Claim action status:

- If the status is Initial — In Progress (Automation) , go to step 3.

- If the status is Initial — In Progress (Manual) , go to step 6.

- In NWS, create a Reminder WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “ACP.”

- Due date: Enter today’s date.

- Language: Select the appropriate option.

- Details: Type “2” and “UNA” or the user name of the person to whom the CA or SA WI is to be assigned.

- Destination: Select Level and Canada .

- End User: Select Specific user and type “SV-Admin, ACP-TAD.”

- Select Save .

- Move the ADJ WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting removal of claim from automation process. Employment not insurable. This WI must be deleted once CA or SA WI is created.”

- Bring forward date: Enter today’s date + 2 working days.

- Select OK .

- When the ADJ WI moves to the current workload, confirm that the Claim action status is Initial — In Progress (Manual) and a CA or SA WI was created.

- Contact an authorized user (team leader or business expertise advisor) to delete the ADJ WI. 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/vllevel2_ic/non-contentious_reason_for_separation_rfs_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving screen as follows:

- Select The reason for separation is not voluntary leaving .

- Select Continue .

- Complete the Not voluntary leaving screen as follows:

- Select the appropriate RFS.

- Select Continue

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Just cause not shown — Reason for separation (RFS) in the benefit period (BP)

Source topic: `en_EN/task/vllevel2_ic/just_cause_not_shown__reason_for_separa_76172ac2_level_2.dita`

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose the D15 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select - Add .

- Disentitlement: Select 15 - Claim procedure .

- Start date: Enter the disentitlement start date (i.e. the Monday of the week of the disqualifying event).

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Impose D11 and rescind D15 starting on w/c XXXX-X.”

- Due Date: Enter today’s date + 2 business days.

- Language: Select the appropriate option.

- Benefit type: Select the appropriate option.

- Details: Type all the following:
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4965.dita)

- Destination — Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Revised BPNE .

- End User: Select Next available user .

- Select Save .

- Complete the ADJ WI. 

#### Just cause shown

Source topic: `en_EN/task/vllevel2_ic/just_cause_shown_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Enter the employer’s name.

- Enter the date of the voluntary leaving.

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Relevant Facts: Enter the relevant facts.

- Indicate if the employer agrees with the client’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if required.

- Rationale: Select Yes and enter any additional information.

- References: Enter any additional references.

- Decision: Select Voluntary Leaving - Just cause shown .

- Written Notification: Select the appropriate option and, if required, provide the employer details for the letter.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Voluntary leaving before anticipated end of employment — Just cause not shown

Source topic: `en_EN/task/vllevel2_ic/voluntary_leaving_before_anticipated_en_d591facb_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Enter the employer’s name.

- Enter the date of the voluntary leaving.

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Relevant Facts: Enter the relevant facts.

- Indicate if the employer agrees with the client’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if required.

- Rationale: Select No and enter any additional information.

- References: Select EIA 33 and enter any additional references.

- Decision: Select Voluntary Leaving - Just cause not shown .

- Do you wish to enter a disentitlement (D-44, anticipated loss of employment)?: Select Yes .

- Input disentitlement: Enter the disentitlement end date (must be a weekday).

- Select Continue .

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- In ACS, create and save a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the appropriate options:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 (3021): Select D44 - Leaves employment without just cause within 3 weeks of layoff or end of term .

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the benefit type and the appropriate options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text – Footnote (11745): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [X] to [X] because you quit your job with [Text - Name of Employer(s)] without just cause on [Date of Event] within 3 weeks of [being laid off/the end of term].”

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to send the saved letter in ACS when completing the COR WI.

- Complete the ADJ WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_1746.dita`

Note:

Create a new SROC for each conversation with the employer or the client (e.g. if you contacted the employer twice, create 2 SROCs). 

#### Note

Source topic: `en_EN/common_notes/note_c_1747.dita`

Note:

If you are unable to contact the client or the employer, render a decision based on the information on file. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4965.dita`

“If the claim is finalized as BPNE, complete the REM WI.

If the claim is established (i.e. not BPNE), whether or not a D11 is already imposed:

- in FTS, obtain a revised registration number;

- input the indefinite D11 from w/c [XXXX];

- rescind the D15 from w/c [XXXX];

- update and send the draft ACS letter.” 

## Policy reference

Source topic: `en_EN/task/vllevel2_ic/policy_reference.dita`

- Digest 6 — Voluntary leaving employment
         [Digest 6 — Voluntary leaving employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- BE 2010-12 — Voluntary Leaving to Attend Approved Training
         [BE 2010-12 — Voluntary Leaving to Attend Approved Training](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2010-12.shtml)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- EIA 32
         [EIA 32](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-32.html)

- EIA 33
         [EIA 33](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-33.html) 
