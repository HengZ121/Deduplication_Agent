# Converting a claim from family caregiver benefits

Source map: `en_EN/task/converting_cfcb_convetir_dpppa/converting_cfcb_convetir_dpppa.ditamap`

## Summary

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/summary.dita`

Summary: After receiving family caregiver benefits (FCB), clients may request a conversion to other benefit types (BTs). 

## What you need to know

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/untitled_section.dita`

The purpose of this task is to help processing officers finalize conversion requests from FCB. For a claim to be converted to the requested BT, the client must meet all entitlement and qualifying conditions.

The officer reviews all documentation in the electronic claim to ensure all issues and information have been addressed as appropriate. The system does not generate a new WI or send a notification for outstanding Claim Assessment (CA) or Specialized Application (SA) WIs when documents are uploaded in all situations. 

### Reassigning a WI to the Specialized EI Processing/Family Caregiver level

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/reassigning_a_wi_to_the_specialized_ei__4b9ec2a4.dita`

When a client requests a retroactive conversion from FCB to another BT, the officer reassigns the WI related to the conversion to the Family Caregiver Centre of Specialization. A conversion request is retroactive when the client requests a conversion to another BT for which FCB weeks were already processed, whether they were paid or not. The regular processing officer processes all other conversions from FCB to another BT and does not reassign them to the specialized processing team. 

### Converting to regular, sickness or parental benefits

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/converting_to_regular_sickness_or_paren_918b708a.dita`

If a client requests a conversion from FCB to regular, sickness or parental benefits, the officer completes the appropriate checklist with the client, from the Checklists, Forms and Templates additional resource.
       [Checklists, Forms and Templates](/en/procedure/generic/ar_index_cft_afg.shtml) 

### Levels of Decision

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/levels_of_decision.dita`

A decision to allow regular benefits following sickness benefits can be rendered at Level 1 under the National Policy on Levels of Decision. If there are any issues that cannot be adjudicated by Level 1 under the National Policy on Levels of Decision, the file is referred for Level 2 adjudication.

A Level 1 officer can render the decision to convert a claim from special benefits to regular benefits when:

- the client was receiving regular benefits before receiving special benefits; or

- the reason for not returning to work can be allowed at Level 1; and

- the client is capable of and available for work and poses no restriction towards accepting employment.

A decision to allow sickness benefits after FCB can be rendered at Level 1 when:

- the client was receiving or was entitled to parental benefits, FCB or CCB at the start of the illness, injury or quarantine; and

- the client’s entitlement to parental benefits, FCB or CCB will continue up to or beyond the recovery date; and

- the client submits a medical certificate for the period of incapacity which includes both the date the illness began and the expected recovery date.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2853.dita) 

### Converting to CCB

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/converting_to_ccb.dita`

A client requesting a conversion to CCB must complete an application online. 

### Converting to maternity benefits

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/converting_to_maternity_benefits.dita`

If a client is requesting a conversion to maternity benefits, the officer must verify if the client has previously completed an application for maternity for this BPC. If yes, the conversion can be completed with the appropriate checklist from the Checklists, Forms and Templates additional resource. If no, the client must apply online or provide a completed and signed Maternity or parental: INS5168 Annex 3 — Form .
       [Checklists, Forms and Templates](/en/procedure/generic/ar_index_cft_afg.shtml) 
       [Maternity or parental: INS5168 Annex 3 — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5168.pdf) 

### Determining when an Operational Centre Memo (MM06) transaction is required

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/determining_when_an_operational_centre__c002d667.dita`

When a client requests a claim conversion involving a FCW, the only BTs accepted in CPS are regular or sickness. When a client requests a conversion to maternity benefits, parental benefits or CCB, the officer sends an MM06 to IPOC to convert the claim. When completing the MM06, the officer ensures that all information required for the conversion is included. This includes the BT being requested, the period for which the benefits are to be paid, the number of weeks being requested, any required allocations, benefit period (BP) extensions, disentitlements, etc.

The claim remains in MPS for the remainder of the BP. The client must complete paper claimant’s reports, unless the client requests and is eligible to be exempted from submitting claimant reports. 

### Qualifying and entitlement conditions

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/qualifying_and_entitlement_conditions.dita`

The officer refers to the chart below to determine if the client qualifies for the requested BT. For more information about the entitlement conditions for all BTs, the officer refers to Knowledge related to calculation .
       [Knowledge related to calculation](/en/procedure/generic/knowledge.shtml)

```text
| BT | Determining if the conditions to allow at Level 1 are met |

| Regular [Regular](/en/procedure/generic/knowledge.shtml#Regular_Benefits) | There is no 46 - Variable entrance requirement not met, special benefits payable disentitlement (D46). The client was receiving regular benefits before receiving special benefits; or the reason for not returning to work can be allowed at Level 1; and The client is in Canada (exceptions are listed in EIR 55 ). [EIR 55](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html) |

| Sickness [Sickness](/en/procedure/generic/knowledge.shtml#Sickness_Benefits) | If necessary, the client provides proof of illness, injury or quarantine. To determine if proof of illness, injury or quarantine is required, the officer refers to Determining if a medical certificate must be submitted — Renewal and continuing claims . When FCB are exhausted or the sickness period extends beyond the FCW, the client provides proof of illness, injury or quarantine and proves being otherwise available for work. [Determining if a medical certificate must be submitted — Renewal and continuing claims](/en/procedure/task/determining_med_cert_req.shtml) |

| Maternity [Maternity](/en/procedure/generic/knowledge.shtml#Maternity_Benefits) | The client provides proof of the pregnancy. |

| Parental [Parental](/en/procedure/generic/knowledge.shtml#Parental_Benefits) | The client provides proof of the birth, adoption or placement. |

| CCB [CCB](/en/procedure/generic/knowledge.shtml#Compassionate_Care_Benefits) | The client submits proof confirming that a family member has a serious medical condition that poses a significant risk of death within 26 weeks and needs care or support from one or more family members. The client provides care or support to an individual identified as a family member. The client is requesting CCB during the 52-week compassionate care window (CCW) established for a patient. The client is not requesting CCB during the 52-week FCW for the same patient. |
```

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0021.dita) 

**Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits, regardless of the conversion date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Otherwise available

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/otherwise_available.dita`

Clients do not need to prove that they are otherwise available for work or that they would be otherwise working to receive FCB.

Clients who apply for sickness benefits during the FCW do not have to prove that they are otherwise available for work. However, when FCB are exhausted or the sickness period extends beyond the FCW, clients must prove that they are otherwise available for work during that period. They must submit a medical certificate with the incapacity start date and the expected recovery date. 

### FCB and CCB

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/fcb_and_ccb.dita`

While FCB and CCB may be combined, the client cannot receive CCB for the same patient at the same time as FCB. CCB can be paid either before the FCW starts or after it ends, but cannot be paid during an existing FCW for the same patient. The FCW does not end until the maximum number of weeks of entitlement to FCB has been paid or the 52-week window has ended. 

### Client’s address

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/clients_address.dita`

As a client requesting FCB may temporarily move to another address to provide care or to support a critically ill or injured patient, the client’s address on the application form is compared to the address in FTS to determine if there has been a change. When a client moves to a province or territory served by a different region, a change in region in FTS is required. For more information, the officer refers to Change of address .
       [Change of address](/en/procedure/activity/change_address.shtml) 

### Disentitlements

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/disentitlements.dita`

The officer imposes the following disentitlements related to FCB when the client does not meet the entitlement conditions:

- 61 - Family caregiver benefits for children or adults - Does not meet entitlement conditions disentitlement (D61)

- 62 - Family caregiver benefits for children or adults - Benefits exhausted disentitlement (D62)

- 63 - Family caregiver benefits for children or adults - No medical proof disentitlement (D63)

For more information, the officer refers to Family caregiver: Information on benefits — Knowledge .
       [Family caregiver: Information on benefits — Knowledge](/en/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml) 

### Outstanding disentitlements

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/outstanding_disentitlements.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies on the renewal (conversion). A Level 1 officer can terminate or rescind the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . If the information on file allows for the disentitlement to be terminated, it ends on the Friday of the week before the conversion week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

A Level 1 officer can render the decision to terminate a disentitlement and allow another BT to be paid on a continuing or renewal claim when all of the following conditions are met:

- The client is requesting a conversion from FCB to another BT.

- There is a D61, a D62 or a D63 on file.

- The date from which the client is requesting the conversion is after the later of either:

- the weeks requested for the required care or support;

- the date on the medical certificate.

- The client meets the entitlement conditions for the requested BT.

- If the client requests regular or sickness benefits, there is no disentitlement on file related to any of the following:

- availability

- not otherwise available

- self-employment (SE) issues

- labour dispute

- If the client requests regular benefits, the reason for not returning to work can be allowed at Level 1.

- If the client requests special benefits, the reason for not returning to work can be allowed at Level 1 and is related to the BT requested.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2752.dita) 

If the outstanding disentitlement is a 15 - Claim Procedure disentitlement (D15) imposed by integrity and is related to a missed client information session, the Level 1 officer refers the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine why the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For instructions to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent.

**Previously deferred adjudication on reasons for separation (RFSs)**

After converting a claim to regular benefits, any RFS for which adjudication had previously been deferred must be adjudicated.

When the claim is calculated, if the RFS adjudication is deferred, a disqualification is automatically imposed and appears in FTS on the Disqualification/Disentitlement screen.

The officer always verifies if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 10 - Dismissal - misconduct proven (D10) or 11 - Voluntary leaving - just cause not proven (D11) disqualification was imposed, no regular benefits are payable on this claim.

If there is a ROD on file indicating that adjudication of an RFS was deferred, that RFS must be adjudicated. The Level 1 officer attempts to adjudicate the RFS according to the National Policy on Levels of Decision . If it is not within Level 1 authority, the officer reassigns the RFS to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2728.dita) 

### Adjudicating new contentious issues

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/adjudicating_new_contentious_issues.dita`

When renewing a claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If the client reports the issue on the application, the system creates an ADJ WI. If a contentious issue is detected while reviewing the claim, the Level 1 officer creates an ADJ WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If it is not possible to adjudicate the issue, the Level 1 officer reassigns the ADJ WI to Level 2 for adjudication.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

When an ADJ WI is created on a renewal claim, either manually or by the system, the system automatically imposes a 2 - Contentious renewal in automation manual action (MA02) to prevent payment of benefits until the contentious issue is adjudicated. If the renewal or decision must be input manually, the officer performs the inputs before completing the CA WI. Completing the WI triggers the removal of the MA02 by the system if there is no outstanding ADJ WI, an officer cannot rescind an MA02.

When converting a continuing claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If there is no existing WI for the issue, the Level 1 officer creates a Claim Review (CR) WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the contentious CR WI to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

The Level 1 officer does not reassign the Conversion WI to Level 2 for any reason.

**Temporary foreign workers (900-series SINs)**

All foreign workers are given temporary resident status for a limited period of time when they enter Canada. Generally, foreign workers can show their availability to accept work only if they have a valid work permit that allows them to work in Canada. Therefore, when foreign workers want to renew or convert a claim for regular benefits, the officer reviews the validity of their work permits. For more information, the officer refers to 900-series SIN .
       [900-series SIN](/en/procedure/activity/expired_900.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2854.dita) 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular . The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an Action Item (AI), Call Back (CB), Assessment Issue (ASMT) or Reminder (REM WI), the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### Effective date of conversion

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/effective_date_of_conversion.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer refers to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Subsequent claim

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/subsequent_claim.dita`

The renewal application can be used to establish a subsequent claim when the following conditions are met:

- The claim is renewed and there are 4 or fewer weeks of benefits remaining in the BP.

- The client has worked enough hours to establish a new claim.

ACP can register the subsequent claim if the Claim Assessment (CA) WI for a renewal or subsequent initial claim is finalized within 28 days of the renewal application.

When ACP cannot register the subsequent claim because the renewal is not processed within 28 days of the renewal application (i.e. REN WK not found or no match and polling limit exceeded is displayed on the Processing Activities tab in NWS) or when the claim was converted to MPS, the officer processing the CA Renewal WI creates a REM WI. This ensures that an officer will manually register the subsequent claim. 

### Return to work (RTW)

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/return_to_work_rtw.dita`

If there is an RTW on the claim that falls on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer refers the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### Extending the benefit period (BP)

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/extending_the_benefit_period_bp.dita`

The BP can be extended to a maximum of 104 weeks to pay additional weeks of sickness, maternity, parental, CCB and FCB where the client did not receive the maximum entitlement during the initial BP.

For more information on BP extensions for combined special benefits, the officer refers to Benefit period extension for special benefits or Maximum entitlement to benefits .
       [Benefit period extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml) 
       [Maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2653.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### ACS letters

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/acs_letters.dita`

Communication of the renewal decision is not necessary when the only transaction input is the renewal transaction. When another decision is input at the time of the renewal (disentitlement, disqualification or allocation of earnings) communication of the decision is necessary.

Written communication of the decision is usually done by officers who are responsible for sending the appropriate letter. In certain situations, the R-01-00-00 letter is sent automatically. Officers must ensure that the letter was sent and, if the letter was not sent, they must create and send the letter.

If a renewal and an allocation are input by the same officer and are processed on the same day, the R-01-00-00 letter is, in most cases, created automatically.

However, the letter is not sent automatically if one of the following conditions is met:

- One of the transactions (M106 or M175) is rejected.

- The allocation code on the M175 is A.

- An E or W allocation is input for more than one week.

- A stop payment is imposed (MA01, MA02, MA48, MA71, MA72, MA73, MA74, MA75).

- A disqualification or disentitlement is being input.

- A disqualification or disentitlement is already on file and is not being rescinded or terminated.

In some cases, the letter may be sent automatically but additional decisions must be communicated. To prevent duplication of letters, the officer must prevent the letter from being sent automatically using the Automated Letter Bypass function in FTS. 

### Note

Source topic: `en_EN/common_notes/note_c_2853.dita`

Note:

When FCB are exhausted or the sickness period extends beyond the family caregiver window (FCW), the client must submit a medical certificate and prove being otherwise available for work. 

### Note

Source topic: `en_EN/common_notes/note_c_0021.dita`

Note:

If the client has a violation, there may be increased entrance requirements .
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Note

Source topic: `en_EN/common_notes/note_c_2752.dita`

Note:

A client is not required to demonstrate good cause for delay when submitting a medical certificate. The Level 1 officer can modify or rescind a disentitlement related to a missing medical certificate for special benefits, regardless of the length of delay, provided all other conditions are met for the requested BT. 

### Note

Source topic: `en_EN/common_notes/note_c_2728.dita`

Note:

For all initial claims and recalculations with a BPC between w/c 2310 and w/c 2361, only the last period of employment requires adjudication if it was previously deferred. 

### Note

Source topic: `en_EN/common_notes/note_c_2854.dita`

Note:

There are no availability criteria for maternity, parental, CCB or FCB. In these situations, the officer reviews the client’s authorization to remain in Canada. 

### Note

Source topic: `en_EN/common_notes/note_c_2653.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

## Regional considerations

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/regional_considerations.dita`

**Quebec region**

Clients who live in Quebec and who request maternity or parental benefits are referred to QPIP. The Quebec government pays maternity, paternity, parental, and adoption benefits to Quebec residents. EI continues to pay maternity and parental benefits to parents who live outside Quebec or who are not considered residents of Quebec.

When a Quebec client is eligible to receive QPIP, a 57 - E.I. Maternity or Parental benefits denied, benefits are payable by the province disentitlement (D57) is imposed. 

## What you need to look for

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/in_nws.dita`

- Did the client apply for a renewal requesting a conversion of benefits?

- If yes, review processing activities for the web application and take notes if necessary:

- What issues did ACP detect?

- Does it indicate why the claim tripped down?

- Has the client worked since the last application for benefits?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies, motor vehicle accident compensation, workers’ compensation benefits (WCB) or wage loss insurance (WLI) payments to consider or allocate?

- Is there a new contentious RFS?

- Is there an ADJ WI?

- If yes, what is the contentious issue?

- Is there a medical certificate that attests to the client’s own illness or injury on file, or has one been uploaded?

- Does the client have a 900-series SIN? 

### In FTS:

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the last renewable week (LRW) been reached?

- Is there an RTW on the claim?

- Is there a registration number?

- Are there any outstanding disentitlements?

- Has the waiting period (WP) been served?

- Are there any outstanding claimant’s reports or claimant’s reports to be processed before the conversion? 

### In RCM:

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/in_rcm.dita`

- Has the ROE been submitted?

- Are there earnings, separation monies, motor vehicle accident compensation, WCB or WLI payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/in_imaging.dita`

- Is there a medical certificate on file attesting to the client’s own illness or injury?

- Is there any other documentation that can impact the conversion claim?

- Is there an INS5168 form? 

## Step by step

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/reviewing_the_file_level_1.dita`

- In NWS, determine if there is a SIR Validation (SIR) WI:

- If yes, go to step 2.

- If no, go to step 4.

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting completion of SIR WI.”

- Bring forward date: Enter today’s date + business 10 days.

- When the CA WI moves to the current workload, determine if the SIR WI has been completed:

- If no, repeat step 2.

- If yes, go to step 4.

- In FTS, determine if there is a registration number related to the conversion or renewal:

- If yes, go to step 5.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if the client is requesting a retroactive conversion to a period for which FCB has been processed:

- If no, go to step 6.

- If yes, go to Reassigning the WI to the Specialized EI Processing/Family Caregiver Level .
               [Reassigning the WI to the Specialized EI Processing/Family Caregiver Level](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#level1_item_4)

- Determine if the client provided a change of address:

- If no, go to step 7.

- If yes, consult Change of address and go to step 7 of this task.
               [Change of address](/en/procedure/activity/change_address.shtml)

- Determine if there is an outstanding AI WI for a medical certificate for FCB or indicating that the patient has died:

- If yes, go to step 8.

- If no, go to step 10.

- In NWS, move the conversion WI to Pending as follows:

- Pending reason: Select Other .

- Comments: “Waiting for FCB unit to action [a medical certificate or a notification of death] on file.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if a decision has been rendered:

- If no, repeat step 8.

- If yes, go to step 10.

- Determine if the WP must be served:

- If no, go to step 11.

- If yes, refer to Cancelling a benefit period . Go to step 11.
               [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml)

- In FTS, determine if the maximum combination of regular and special benefits has been paid:

- If yes, go to Maximum benefits already paid .
               [Maximum benefits already paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#nobenefits)

- If no, go to step 12.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- Determine if there is a pending E-report on the E-Report tab for the period before the conversion:

- If yes, refer to Actioning a pending claimant’s report and then go to step 13.
               [Actioning a pending claimant’s report](/en/procedure/task/pending_cr.shtml)

- If no, go to step 13.

- Determine if there are any rejected E-reports on the Pending/Reject tab for the period before the conversion:

- If yes, re-input the reports. Refer to Actioning a rejected claimant’s report and then go to step 14.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml)

- If no, go to step 14.

- Determine if the client reports having received monies and whether they have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings and then go to step 15.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 15.

- If no monies were received, go to step 15.

- In NWS and in FTS, determine if one of the following conditions applies:

- The client was incarcerated and has since been tried and not found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received monies on separation for a definitive job loss and allocation prevented benefits from being paid.

- If one of the conditions applies, refer to Benefit period extension and then go to step 16.
                   [Benefit period extension](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions applies, go to step 16.

- Determine if the LRW has been reached:

- If no, go to step 17.

- If yes, go to Last renewable week (LRW) has been reached .
               [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#LRWReach)

- Determine if the client has met the entitlement conditions for the requested BT:

- If yes, go to step 18.

- If no, go to Does not meet entitlement conditions .
               [Does not meet entitlement conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#NoEntitlement)

```text
| BT | Determining if the conditions to allow at Level 1 are met |

| Regular [Regular](/en/procedure/generic/knowledge.shtml#Regular_Benefits) | There is no D46 on file. The client was receiving regular benefits before receiving special benefits; or the reason for not returning to work can be allowed at Level 1; and The client is capable of and available for work and poses no restrictions towards accepting employment. The client is in Canada (exceptions are listed in EIR 55 ). [EIR 55](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html) |

| Sickness [Sickness](/en/procedure/generic/knowledge.shtml#Sickness_Benefits) | If necessary, the client provides proof of illness, injury or quarantine. To determine if proof of illness, injury or quarantine is required, refer to Determining if a medical certificate must be submitted — Renewal and continuing claims . When FCB are exhausted or the sickness period extends beyond the FCW, the client provides proof of illness, injury or quarantine and proves being otherwise available for work. [Determining if a medical certificate must be submitted — Renewal and continuing claims](/en/procedure/task/determining_med_cert_req.shtml) |

| Maternity [Maternity](/en/procedure/generic/knowledge.shtml#Maternity_Benefits) | The client provides proof of the pregnancy. |

| Parental [Parental](/en/procedure/generic/knowledge.shtml#Parental_Benefits) | The client provides proof of the birth, adoption or placement. |

| CCB [CCB](/en/procedure/generic/knowledge.shtml#Compassionate_Care_Benefits) | The client submits proof confirming that a family member has a serious medical condition that poses a significant risk of death within 26 weeks and needs care or support from one or more family members. The client provides care or support to an individual identified as a family member. The client is requesting CCB during the 52-week CCW established for a patient. The client is not requesting CCB during the 52-week FCW for the same patient. |
```

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2855.dita)

- Determine if there are any outstanding disentitlements on file:

- If no, go to step 20.

- If yes, and the conversion is being done on a continuing claim, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure go to step 19.

- If yes, and the conversion is being done on a renewal claim, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue: Select the appropriate option (e.g. Availability ).

- Complete the mandatory fields required for the issue.

- Details: Type “Outstanding [type of disentitlement].”

- Determine if the conditions are met to terminate or rescind the disentitlement at Level 1 according to the National Policy on Levels of Decision :

- If yes, and the conversion is being done on a continuing claim, terminate or rescind the disentitlement and go to step 20.

- If no, and the conversion is being done on a continuing claim, reassign the CR WI to Level 2 and go to step 20.

- If yes, and the conversion is being done on a renewal claim, terminate or rescind the disentitlement, complete the ADJ WI and go to step 20.

- If no, and the conversion is being done on a renewal claim, reassign the ADJ WI to Level 2 and go to step 20.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2856.dita)

- Determine if there are any outstanding issues that require adjudication and do not have a related WI:

- If no, go to step 22.

- If yes, and the conversion is being done on a continuing claim, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 21.

- If yes, and the conversion is being done on a renewal claim, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Complete the mandatory fields required for the issue.

- Details: Explain why the WI is being created.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2732.dita)

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If yes, and the conversion is being done on a continuing claim, refer to the appropriate task to take the actions required and then go to step 22.

- If no, and the conversion is being done on a continuing claim, reassign the CR WI to Level 2 and go to step 22.

- If yes, and the conversion is being done on a renewal claim, refer to the appropriate procedure, complete the ADJ WI and go to step 22.

- If no, and the conversion is being done on a renewal claim, reassign the ADJ to Level 2 and go to step 22.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2856.dita)

- Determine if the client is requesting a conversion to sickness benefits:

- If yes, go to step 23.

- If no, go to step 24.

- Determine if the client would have been working or looking for work if not for the sickness or injury. If necessary, refer to Adjudicating otherwise available issues — Continuing claim :

- If yes, go to step 24.

- If no, and the conversion is on a continuing claim, create a CR WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End user: Select Next available user .

- Issue(s): Select Availability .

- Reason: Select Related work item .

- Details: Type “Not within Level 1 authority.”

- Select Save .

- Go to step 24.

- If no, and the conversion is on a renewal claim, select the appropriate claim and create an ADJ WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue(s): Select Availability .

- Details: Type “Not within Level 1 authority.”

- Select Save .

- Go to step 24.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2857.dita)

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion . Go to step 25.

- In FTS, determine if the claim status (CS) is 8 - Converted to manual pay :

- If no, go to step 26.

- If yes, go to step 27.

- In NWS, determine if the client is requesting a conversion to regular or sickness benefits:

- If yes, go to Inputs .
               [Inputs](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#level1_item_3)

- If no, go to step 27.

- Before sending the Operational Centre Memo ( MM06) transaction to IPOC, determine if a Level 2 officer must adjudicate any outstanding issues:

- If yes, go to step 28.

- If no, go to step 30.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting Level 2 decision.”

- Bring forward date: Enter 10 working days.

- When the WI moves to the current workload, determine if a decision has been rendered:

- If no, repeat step 28.

- If yes, go to step 30.

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 30 - New information on manual pay claim .

- Remarks line 1: Type Conversion from [CT20 or CT21] to CT [XX].

- Remarks line 2: Select the appropriate option:

- If it is a conversion to regular benefits , type “Start w/c [XXXX], ENT WEEK [XXXX], WP [WP code] served in w/c [XXXX].”

- If it is a conversion to parental benefits , type “Start w/c [XXXX] to w/c [XXXX], SEX [X], APW or PSW w/c [XXXX], ENT WEEK [XX], NO-CR-CODE” and any other relevant information.

- If it is a conversion to maternity benefits , type “Start w/c [XXXX] to w/c [XXXX], ENT WEEK [XX] (if less than 15 weeks), ADC or EDC w/c [XXXX], NO-CR-CODE” and any other relevant information.

- If it is a conversion to CCB , if necessary, type “CT [12], Certificate number [XXXXXXX], start w/c [XXXX] to w/c [XXXX], ENT WEEK [XXXX], NO-CR-CODE” and other relevant information.

- Remarks lines 3–4: Select the appropriate option:

- If an extension of the BP is required, type “Extend [type], start w/c [XXXX], ENT WEEK [XX]” and other relevant information.

- If a disentitlement is required, type “D[XX] from w/c [XXXX-X] to [XXXX-X]” and any other relevant information.

- If an allocation of earnings is required, type “M175, [type], [amount], [w/c - start date] - [w/c - end date], [amount, if different from last week]” and any other relevant information.

- Remarks line 5: Enter your first name and last name.

- Decision type: Select the appropriate decision type.

- Contentious: Select No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 04 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, determine if there is a client Note to send a saved ACS letter:

- If yes, go to step 34.

- If no, go to step 35.

- In ACS, review and send the saved letter.

- In NWS, determine if the conversion application was submitted using AW:

- If no go to step 36.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#subsequent_claims)

- Complete the CR WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to the appropriate Calculating or recalculating a claim activity):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “LRW reached — [BT] benefits requested.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as zero hours were accumulated after the BPC.”

- If the client has worked since the BPC , type “No conversion is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needs [number of hours] to qualify.”

- In ACS, send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612) : Type the following:
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2858.dita)

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction to clear the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Maximum benefits already paid

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/maximum_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to the appropriate Calculating or recalculating a claim activity ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- Determine the disentitlement code that must be input on the claim:

- If the client is requesting CCB benefits, note that a 51 - Does not meet compassionate care entitlement conditions disentitlement (D51) must be imposed.

- If the client is requesting maternity benefits, note that a 27 - Maternity benefits (maximum special benefits paid) or outside range disentitlement (D27) must be imposed.

- If the client is requesting parental benefits, note that a 35 - Parental benefits, qualifying conditions not met (minor attached or outside range or maximum parental/special benefits paid) disentitlement (D35) must be imposed.

- If the client is requesting regular benefits, note that a D15 must be imposed.

- If the client is requesting sickness benefits, note that a 22 - Illness (maximum sickness/special benefits paid) disentitlement (D22) must be imposed.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2859.dita)

- In NWS, create a ROD as follows:

- Comments: Type “No conversion — maximum benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion or renewal is possible as the client cannot receive the requested [BT] benefits. The client does not qualify for a new claim as zero hours were accumulated after the BPC. [disentitlement code] imposed. Claim is not converted or renewed.”

- If the client has worked since the BPC , type “No conversion or renewal is possible as the client cannot receive the requested [BT] benefits. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. [disentitlement code] imposed. Claim is not converted or renewed.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type the following: “We cannot reactivate your claim for Employment Insurance benefits starting [renewal week - Sunday’s date] as you have received the maximum number of benefit weeks payable to you during this benefit period. To receive [BT] benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you will have to file a new claim.”

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction to clear the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Client does not meet entitlement conditions

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/client_does_not_meet_entitlement_conditions_level_1.dita`

- Determine the disentitlement code that must be input on the claim:

- If the client is requesting CCB benefits, note that a 51 - Does not meet compassionate care entitlement conditions disentitlement (D51), 52 - Compassionate care benefits exhausted disentitlement (D52) or 53 - Compassionate care benefits - No medical proof disentitlement (D53) must be imposed.

- If the client is requesting maternity benefits, note that a 27 - Maternity benefits (maximum special benefits paid) or outside range disentitlement (D27) or a 36 - Maternity not eligible - 15 weeks paid per pregnancy (15 weeks per pregnancy or other benefits claimed during maternity period) disentitlement (D36) must be imposed.

- If the client is requesting parental benefits, note that a 34 - Parental benefits entitlement conditions not met (Failure to prove entitlement to parental) disentitlement (D34) must be imposed.

- If the client is requesting regular benefits, note that no disentitlement is necessary.

- If the client is requesting sickness benefits, note that a 16 - No medical certificate submitted (initial or additional proof required) disentitlement (D16) or 33 - Incapacity proven but not otherwise available disentitlement (D33) must be imposed.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2860.dita)

- In NWS, create a ROD as follows:

- Comments: Type “No conversion — maximum benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion or renewal is possible as the client cannot receive the requested [BT] benefits. The client does not qualify for a new claim as zero hours were accumulated after the BPC. [disentitlement code] imposed. Claim is not converted or renewed.”

- If the client has worked since the BPC , type “No conversion or renewal is possible as the client cannot receive the requested [BT] benefits. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. [disentitlement code] imposed. Claim is not converted or renewed.”

- If a disentitlement has been imposed , type “The claim has been converted from FCB, but the client does not meet the entitlement conditions. A disentitlement [disentitlement code, type and reason] has been imposed from w/c XXXX to w/c XXXX.”

- Determine the BT being requested:

- If the client is requesting special benefits, go to step 4.

- If the client is requesting regular benefits, go to step 5.

- In ACS, create or add to the saved N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065)

- Select the appropriate BT (4315)

- Select the appropriate disentitlement (4316)

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- Go to step 6.

- In ACS, create or add to the saved D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction to clear the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Inputs

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/inputs_level_1.dita`

- Determine if the conversion is on a renewal claim:

- If the conversion is on a renewal claim, go to step 2.

- If the conversion is on a continuing claim, go to Conversion on a continuing claim .
               [Conversion on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#ConversionContinuingClaim)

- In NWS, determine if there is an outstanding ADJ WI:

- If no, go to Conversion on a renewal claim — No outstanding adjudication .
               [Conversion on a renewal claim — No outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#ConversionRenewalNoADJ)

- If yes, go to Conversion on a renewal claim — Outstanding adjudication .
               [Conversion on a renewal claim — Outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#ConversionRenewalADJ) 

#### Conversion on a continuing claim

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/conversion_on_a_continuing_claim_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Earnings week 1: Enter the amount, if necessary.

- Claim type: Select the appropriate option:

- 2 - Regular .

- 3 - Sickness - major attached .

- 9 - Sickness - minor attached .

- Manual Action: Select the appropriate option (only if an outstanding adjudication at Level 2 is required).

- If necessary, select the Special benefits (M106) link and input the following information on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

- If a disentitlement needs to be input or modified, complete the following fields:

- Action: Select the appropriate option.

- Disentitlement: Select the appropriate option.

- Start date: Select the appropriate Monday.

- End date: Select the appropriate date or Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select the appropriate option:

- If the conversion did not require Level 2 adjudication, select 1 - No .

- If the conversion required Level 2 adjudication, select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement is being imposed.

- There is an indefinite disqualification on file.

- If there are decisions that must be communicated to the client, go to step 3.

- If there are no decisions that must be communicated to the client, go to step 9.

- Determine if the client has requested a conversion to sickness benefits:

- If yes, go to step 4.

- If no, go to step 7.

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- If an antedate has been denied, select Antedate denied or postdate message - Initial/Renewal/Continuing claim (2481) .

- If weeks of sickness benefits are payable to the client (no indefinite D16), select Special benefits approved (3046) .

- If a definite or indefinite D16 applies, select Special benefits denied (3065) .

- If there is an allocation, select Allocation of Earnings (2516) .

- If monies allocated prevent the payment of sickness benefits, select Monies allocated that prevent the payment of sickness benefits (3090) .

- If the WP must be served, select Waiting Period Message - (Amount of wks of Waiting Period to serve) or (Deferred WP Denied) (2445 ) .

- Message for Sick Claim - Is claimant in receipt of any other payment? (WLI/PSL/WCB/ MVA) (3092) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In ACS, determine if there is a saved D-01-00-00 letter:

- If yes, go to step 6.

- If no, go to step 8.

- Determine if all decisions in the D-01-00-00 letter are included in the N-00-00-00 letter:

- If yes, delete the D-01-00-00 letter and go to step 8.

- If no, modify and send the D-01-00-00 letter with only the decisions that are left to be communicated and go to step 8.

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- To advise the client of the renewal/revival week:

- Renewal week - Sunday’s date (1246)

- To advise the client that the antedate has been denied:

- Antedate denied or postdate Message - Initial/renewal/continuing claim (2481)

- Select Antedate Denied (2483) .

- Select Antedate denied - Renewal/continuing claims (2484) .

- Select Renewal application not filed on time and no good cause for delay .

- Date to which Antedate is requested (1144): Select the appropriate date.

- To advise the client that the indefinite disqualification cannot be rescinded:

- Disqualifications - Definite / Indefinite - Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542) .

- Select Disqualification message (2543) .

- Select the appropriate options.

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of Earnings - Only from ROE #1 - Monies allocated beyond BPC (2523): Select the appropriate option.

- Allocation of Earnings - Monies allocated beyond BPC are from both ROE #1 + ROE #2 (2517): Select the appropriate option.

- Pension Allocation (2525) (if the client is receiving a pension): Select the appropriate option.

- Weekly Indemnity Allocation (2529) (if the client is receiving an indemnity payment): Select the appropriate option.

- Waiting period message (2444) (if the client has not served the WP).

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, determine if the file requires Level 2 adjudication:

- If yes, create a client Note and type “Send the D-01-00-00 or N-00-00-00 letter.” Go to step 9.

- If no, send the D-01-00-00 or N-00-00-00 letter and any other letters with decisions that must be communicated and go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2856.dita)

- In NWS, complete the Conversion WI. 

#### Conversion on a renewal claim — No outstanding adjudication

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/conversion_on_a_renewal_claim__no_outst_8874a6e6_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount, if necessary.

- Claim type: Select the appropriate option:

- 2 - Regular .

- 3 - Sickness - major attached .

- 9 - Sickness - minor attached .

- If necessary, select the Special benefits (M106) link and input the following information on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

- If a disentitlement needs to be input or modified, complete the following fields:

- Action: Select the appropriate option.

- Disentitlement: Select the appropriate option.

- Start date: Select the appropriate Monday.

- End date: Select the appropriate date or Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select the appropriate option:

- If the conversion did not require Level 2 adjudication, select 1 - No .

- If the conversion required Level 2 adjudication, select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Determine if there is an allocation that must be communicated to the client:

- If yes, go to step 3.

- If no, go to step 10.

- Determine if any of the following situations apply:

- There is a denied antedate.

- There is an MA02 on file.

- A disentitlement or definite disqualification is being imposed manually.

- If none of the situations applies, go to step 4.

- If any of the situations apply, go to step 6.

- In NWS, move the CA Renewal WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting confirmation that automated R-01-00-00 letter was sent.”

- Bring forward date: Enter today’s date + 1 day.

- When the WI moves to the current workload, determine if the automated R-01-00-00 letter was sent:

- If no, go to step 6.

- If yes, go to step 8.

- In FTS, select the File Control Data (M101) transaction as follows:

- Select Claim Action .

- Select Automated Letter Bypass .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- To advise the client of the renewal/revival week:

- Renewal week - Sunday’s date (1246)

- To advise the client that the antedate has been denied:

- Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Select Antedate Denied (2483) .

- Select Antedate denied - Renewal/continuing Claims (2484) .

- Select Renewal application not filed on time and no good cause for delay .

- Date to which Antedate is requested (1144): Select the appropriate date.

- To advise the client that the indefinite disqualification cannot be rescinded:

- Disqualifications - Definite/ Indefinite - Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542) .

- Select Disqualification message (2543) .

- Select the appropriate options.

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of Earnings - Only from ROE #1 - Monies allocated beyond BPC (2523): Select the appropriate option.

- Allocation of Earnings - Monies allocated beyond BPC are from both ROE #1 + ROE #2 (2517): Select the appropriate option.

- Pension Allocation (2525) (if the client is receiving a pension): Select the appropriate option.

- Weekly Indemnity Allocation (2529) (if the client is receiving an indemnity payment): Select the appropriate option.

- Waiting period message (2444) (if the client has not served the WP).

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In ACS, determine if there is a saved N-02-00-00 or D-20-16-03 letter:

- If yes, go to step 9.

- If no, go to step 10.

- Determine if all decisions which must be communicated to the client are included in the D-01-00-00 letter:

- If yes, delete the letter.

- If no, send the letter with only the decisions that are left to be communicated.

- In NWS, determine if the conversion application was submitted using AW:

- If no go to step 11.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#subsequent_claims)

- Complete the WI. 

#### Conversion on a renewal claim — Outstanding adjudication

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/conversion_on_a_renewal_claim__outstand_c972fb4d_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount, if necessary.

- Claim type: Select the appropriate option:

- 2 - Regular .

- 3 - Sickness - major attached .

- 9 - Sickness - minor attached .

- Manual Action: Select the appropriate MA (if there is an outstanding adjudication required).

- If necessary, select the Special benefits (M106) link and input the following information on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

- If a disentitlement needs to be input or modified, complete the following fields:

- Action: Select the appropriate option.

- Disentitlement: Select the appropriate option.

- Start date: Select the appropriate Monday.

- End date: Select the appropriate date or Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select the appropriate option:

- If the conversion did not require Level 2 adjudication, select 1 - No .

- If the conversion required Level 2 adjudication, select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- There is an indefinite disqualification on file.

- A disentitlement or definite disqualification is being imposed manually.

- If there are decisions that must be communicated to the client, go to step 3.

- If there are no decisions that must be communicated to the client, go to step 5.

- In ACS, create and save the D-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- To advise the client of the renewal week:

- Renewal week - Sunday’s date (1246)

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of Earnings - Only from ROE #1 - Monies allocated beyond BPC (2523): Select the appropriate option.

- Allocation of Earnings - Monies allocated beyond BPC are from both ROE #1 + ROE #2 (2517): Select the appropriate option.

- Pension Allocation (2525) (if the client is receiving a pension): Select the appropriate option.

- Weekly Indemnity Allocation (2529) (if the client is receiving an indemnity payment): Select the appropriate option.

- To advise the client that the indefinite disqualification cannot be rescinded:

- Disqualifications - Definite / Indefinite - Previous/Current/Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542) .

- Select Disqualification message (2543) .

- Select the appropriate options.

- Waiting period message (2444) (if the client has not served the WP).

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note and type “Send the D-01-00-00 letter.”

- Determine if the conversion application was submitted using AW:

- If no go to step 6.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_cfcb_convetir_dpppa#subsequent_claims)

- Complete the WI. 

#### Subsequent claims

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/subsequent_claims_level_1.dita`

- Determine if there are 4 weeks or fewer of benefits payable remaining in the BP:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the renewal was finalized 28 calendar days after the renewal application was submitted (i.e. application date + 27 days) or if the Status field on the Summary tab in FTS is 8 - Converted to Manual Pay:

- If yes, go to step 3.

- If no, go to step 4.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Subsequent claim not automated.”

- Due date: Select the [LRW + 3 weeks].

- Language: Select the appropriate option.

- Details: Type “Subsequent claim to be established.”

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Next available user .

- Complete the CA WI. 

#### Reassigning the WI to the Specialized EI Processing/Family Caregiver level

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/reassigning_the_wi_to_the_specialized_e_7f730ded_level_1.dita`

- In NWS, reassign the WI as follows:

- Destination — Level: select 1 – Natl Processing & Payments Svcs (PPS) / Specialized EI Processing / Family Caregiver .

- Reason: Select Unable to complete .

- Details: Type “The client is requesting a retroactive conversion to a period for which FCB have been processed.”

- Select Save . 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Note

Source topic: `en_EN/common_notes/note_c_2855.dita`

Note:

If proof of illness, injury or quarantine is required but the client has not been asked to provide a medical certificate, officers must contact the client to request a valid medical certificate. 

#### Note

Source topic: `en_EN/common_notes/note_c_2856.dita`

Note:

When adjudication cannot be done at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose an MA1 to stop payment. 

#### Note

Source topic: `en_EN/common_notes/note_c_2732.dita`

Note:

When converting a claim to regular or sickness benefits, always determine if the client is available or otherwise available. 

#### Note

Source topic: `en_EN/common_notes/note_c_2857.dita`

Note:

The client is not required to prove being otherwise available for work when requesting sickness benefits while receiving FCB. For more information, refer to BE 2014-04 — Sickness Benefits for Claimants in Receipt of Parents of Critically Ill Children (PCIC) and Compassionate Care (CCB) Benefits .
       [BE 2014-04 — Sickness Benefits for Claimants in Receipt of Parents of Critically Ill Children (PCIC) and Compassionate Care (CCB) Benefits](/en/policy/bememo/be2014-04.shtml)

     [BE 2014-04 — Sickness Benefits for Claimants in Receipt of Parents of Critically Ill Children (PCIC) and Compassionate Care (CCB) Benefits](/en/policy/bememo/be2014-04.shtml) 

#### Callout

Source topic: `en_EN/common_notes/note_c_2858.dita`

“We cannot reactivate your claim for Employment Insurance benefits starting [Renewal week - Sunday’s date] . Please note that we are required to advise you of all decisions made on your claim. No [BT] benefits are payable to you on this claim because the last renewal week has been reached for this benefit period.

To receive [BT] benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you must apply for a new claim.” 

#### Note

Source topic: `en_EN/common_notes/note_c_2859.dita`

Note:

When a disentitlement must be input on the claim and the CS is 8 - Converted to manual pay , send an Operational Centre Memo (MM06) transaction to IPOC as follows:

- Work item : Select 93 - Manual Pay System .

- Work type: Select 30 - New information on manual pay claim . 

#### Note

Source topic: `en_EN/common_notes/note_c_2860.dita`

Note:

When a disentitlement must be input on the claim and the CS is 8 - Converted to manual pay , send an Operational Centre Memo (MM06) transaction to IPOC as follows:

- Work item : Select 93 - Manual Pay System .

- Work type : Select 30 - New information on manual pay claim . 

## Policy reference

Source topic: `en_EN/task/converting_cfcb_convetir_dpppa/policy_reference.dita`

 
