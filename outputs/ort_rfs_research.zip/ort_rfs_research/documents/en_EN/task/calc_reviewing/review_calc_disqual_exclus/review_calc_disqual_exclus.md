# Reviewing the calculation result — Disqualified or disentitled ROE

Source map: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/review_calc_disqual_exclus.ditamap`

## Summary

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/summary.dita`

Summary: A claim calculation that includes a disqualified or disentitled ROE requires review. 

## What you need to know

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Contentious reason for separation (RFS)

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/contentious_reason_for_separation_rfs.dita`

When the calculation result includes a disqualification or disentitlement related to a contentious RFS, the Disentitlement section of the calculation result displays the type of disqualification or disentitlement.

In RCM, block 16 is used to document the decision on a contentious RFS. This information determines if the ROE is used in the calculation of the claim, and ensures that any disqualifications or disentitlements are correctly imposed. The Reason for separation and Special condition fields in block 16 of a contentious ROE should always be coded according to the decision rendered. An ROE with incorrectly coded information in block 16 can result in an incorrect disqualification or disentitlement. However, for claims with a BPC between w/c 2310 and w/c 2361, only the last ROE with a contentious RFS requires adjudication. ACP automatically resolves RFS issues in the qualifying period (QP) before the last ROE, but does not update the Special condition field.

When reviewing the calculation result, if a disqualification or disentitlement is present on a contentious RFS that does not have a related record of decision (ROD) (i.e. an ROE is submitted after the claim is ready to calculate), the RFS must be adjudicated. 

### Disqualifications

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/disqualifications.dita`

During calculation of a claim for benefits, an indefinite disqualification may be imposed when an ROE, with employment ending in the QP shows one of the following:

```text
| RFS | With one of the following special conditions | May impose the following disqualification |

| E - Quit | Blank, Adjudication Deferred, Voluntary Leaving - No Just Cause or Misconduct Proven | D11 |

| G - Mandatory Retirement | Blank, Adjudication Deferred, Voluntary Leaving - No Just Cause or Misconduct Proven | D11 |

| K - Other | Blank, Adjudication Deferred, Voluntary Leaving - No Just Cause or Misconduct Proven | D11 |

| M - Dismissal | Blank, Adjudication Deferred, Voluntary Leaving - No Just Cause or Misconduct Proven | D10 |

| N - Leave of Absence | Blank, Adjudication Deferred, Voluntary Leaving - No Just Cause or Misconduct Proven | D11 |
```

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2389.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2390.dita) 

When the client does not have enough insurable hours since the most recent disqualifying event to establish a claim, all of the insurable hours in the QP (including those from the disqualified ROE) are used to establish the claim and the disqualification is imposed.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2391.dita) 

When the client has enough insurable hours since the most recent indefinite disqualifying event to establish a benefit period (BP), the client is considered a requalifier and the ROE is excluded from the calculation results. When the client is considered a requalifier, the insurable hours from all ROEs in the QP (excluding those from the disqualified ROE) are used to calculate the insurable hours in the QP and no disqualification is imposed.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0870.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2392.dita) 

### Disentitlements

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/disentitlements.dita`

During calculation of a claim for benefits, a disentitlement may be imposed when an ROE, with a period of employment ending in the QP, shows one of the following:

```text
| Special Condition | With one of the following RFS | May impose the following disentitlement |

| Anticipated Loss of Employment | E - Quit, G - Mandatory Retirement, K - Other, M - Dismissal or N - Leave of Absence | D44 |

| Authorized Period of Leave | E - Quit, G - Mandatory Retirement, K - Other, M - Dismissal or N - Leave of Absence | D43 |

| Suspension | E - Quit, G - Mandatory Retirement, K - Other, M - Dismissal or N - Leave of Absence | D42 |
```

These disentitlements do not result in the exclusion of the insurable hours, but prevent payment of benefits for the period of the disentitlement. The period is based on the entries in RCM following adjudication.

A 42 - Suspension from employment (because of misconduct) disentitlement (D42) or 43 - Leave of absence (from employment without just cause) disentitlement (D43) ends when one of the following occurs:

- the period of suspension or leave ends

- the client has lost or voluntarily left the employment

- the client accumulates enough insurable hours with another employer to establish a new claim

A 44 - Anticipated loss of employment (in anticipation of layoff) disentitlement (D44) ends when the employment was expected to end. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2389.dita`

Note:

If adjudication of the RFS has been deferred, the ROE is considered a disqualified event during claim calculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2390.dita`

Note:

For initial and recalculation claims with a BPC between w/c 2310 and w/c 2361, any contentious RFS in the QP that is not the last period of employment does not require adjudication. All ROEs are included in the calculation. This measure does not apply to claims for SE or fishing benefits. 

### Example 1

Source topic: `en_EN/common_notes/note_c_2391.dita`

Example 1:

- ROE 1: September 22/12 to December 15/12, shortage of work, 350 insurable hours

- ROE 2: January 4/12 to March 15/12, dismissal — misconduct proven, 230 insurable hours

- Client requires 420 insurable hours to requalify

The client has 350 insurable hours since the disqualifying event and does not requalify. The claim is established with 580 insurable hours (the total insurable hours within the QP) and the disqualification is imposed. 

### Note

Source topic: `en_EN/common_notes/note_c_0870.dita`

Note:

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is only required on the most recent ROE in the QP, if the reason for separation (RFS) is contentious. In addition, the common entrance requirement of 420 hours of insurable employment is not used to determine if the client requalifies after a disqualifying event. Instead, the client needs to have worked at least one hour in insurable employment since the disqualifying event and to have filed an EI application.

If the RFS since the disqualifying event is either non-contentious or is adjudicated and allowed, a new claim may be established using the hours from all the ROEs. The indefinite disqualification imposed due to the original period of employment no longer applies because the new ROE from the latest period of employment establishes a new BPC without a disqualification. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Example 2

Source topic: `en_EN/common_notes/note_c_2392.dita`

Example 2:

- ROE 1: September 1/12 to December 30/12, shortage of work, 530 insurable hours

- ROE 2: August 1/12 to August 15/12, voluntary leaving - not just cause, 50 insurable hours

- ROE 3: Jan 20/12 to July 12/12, shortage of work, insurable hours = 600

- Client requires 420 insurable hours to requalify

The client has 530 insurable hours from ROE 1 since the disqualifying event and requalifies. Although the client has a total of 1180 insurable hours in the QP, the hours from employer #2 are excluded, the claim is established with 1130 insurable hours (the total hours from ROEs 1 and 3) and no disqualification is imposed. 

## Regional considerations

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/what_you_need_to_look_for.dita`

### NWS:

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/nws.dita`

- Is there a ROD for an indefinite disqualification or a disentitlement?

- Is there a ROD for a deferral of an RFS?

- Is there a note (e.g. in client Note or on calculation worksheet) indicating a disqualification needs to be input? 

### RCM:

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/rcm.dita`

- What is the RFS of the ROE for which a disqualification or disentitlement is imposed?

- What is the Special condition of the ROE for which a disqualification or disentitlement is imposed?

- If a disentitlement is imposed, is a special condition end date displayed in RCM? 

## Step by step

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/level_1.dita`

#### Determining which ROE requires review

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/determining_which_roe_requires_review_level_1.dita`

- In RCM, determine which ROE is causing the indefinite disqualification (e.g. D10 or D11) or disentitlement (e.g. D42, D43, D44) to be imposed.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2393.dita) 

#### Reviewing the ROE

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/reviewing_the_roe_level_1.dita`

- In NWS, determine if there is a ROD for adjudication or deferral of the RFS for the disqualified or disentitled ROE:

- If there is a ROD, go to step 3.

- If there is no ROD, refer to Reviewing an outstanding issue with no Adjudication Issue WI .
               [Reviewing an outstanding issue with no Adjudication Issue WI](/en/procedure/task/calc_determining/outstandingissue_adj_nowi.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2394.dita)

- In RCM, determine if the entries in the Reason for separation , Special condition and End date (if applicable) fields on the ROE correspond to the decision in the ROD:

- If yes, go to step 4.

- If no, correct the ROE, select submit and go to step 4.

- Determine if there is another indefinite disqualification (e.g. D10 or D11), disentitlement (e.g. D42, D43, D44 ) or excluded ROE message appearing in the calculation result which requires review.

- If yes, return to step 1.

- If no, go to step 5.

- Determine if any changes were made in RCM:

- If yes, go to step 9 of Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- If no, refer to step 6 of Reviewing the calculation result .
               [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2393.dita`

Note:

When a disqualification or disentitlement is present, the calculation result indicates the start date of the disqualification or disentitlement. This can help identify the related ROE. 

#### Note

Source topic: `en_EN/common_notes/note_c_2394.dita`

Note:

Although it was determined that there were no outstanding adjudication issues during the Determining if a claim is ready to be calculated procedure, a new ROE requiring adjudication may have been submitted since then. 

## Policy reference

Source topic: `en_EN/task/calc_reviewing/review_calc_disqual_exclus/policy_reference.dita`

 
