# Reviewing the calculation result — Disentitlement from special benefits

Source map: `en_EN/task/calc_reviewing/review_calc_disentccb/review_calc_disentccb.ditamap`

## Summary

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/summary.dita`

Summary: The officer must review a claim calculation that includes or will include a disentitlement from special benefits. 

## What you need to know

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Disentitlements from special benefits

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/disentitlements_from_special_benefits.dita`

The officer must review a calculation result that includes any condition that disentitles the client from special benefits. 

### Automatically generated disentitlements

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/automatically_generated_disentitlements.dita`

A disentitlement from special benefits is automatically created during the calculation of the claim when one of the following conditions is indicated in the Disentitlement or Messages sections of the calculation result:

```text
| Condition in the calculation result | Disentitlement imposed when the calculation result is accepted |

| BPC is greater than the caregiver window | D61 |

| BPC is prior to effective date of caregiver for child | D61 |

| BPC is prior to effective date of caregiver for adult | D61 |

| Caregiver benefits minor attached | D61 |

| Caregiver medical proof required | D63 |

| Caregiver window start date window > BPC | D61 |

| Claim procedure | D15 |

| Compassionate care — no proof | D53 |

| Compassionate care — minor attached or not within the compassionate care window | D51 |

| Maternity — minor attached | D25 |

| No medical certificate submitted | D16 |

| Not capable (minor attachment — I of E caused by illness) | D2 |

| Parental — minor attached, not within the parental window or parental or special benefits exhausted | D35 |

| Parental — no proof of placement | D34 |
```

These conditions are generated when one of the following conditions exist:

- The client is minor attached.

- The client requests benefits outside of the period of time for which the client is entitled to the requested benefit type (BT).

- The required proof for the requested BT is indicated as outstanding on the Registration screen.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2385.dita) 

**Automatically generated disentitlements for claims established with the common entrance requirement (from w/c 2310 to w/c 2361)**

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for benefits. As a result, the following disentitlements are not automatically generated based on hours of insurable employment:

- 2 - Minor attached, reason for separation illness disentitlement (D2)

- 25 - Maternity benefits - Minor attached disentitlement (D25)

- 35 - Parental benefits, qualifying conditions not met disentitlement (D35)

- 51 - Does not meet compassionate care entitlement conditions disentitlement (D51)

- 61 - Family caregiver for children or adults - Does not meet entitlement conditions disentitlement (D61)

However, a D35, D51 or D61 is still automatically generated when the BPC is outside the period for the requested claim type (CT). Additionally, the officer may need to review the other disentitlements listed in the Automatically generated disentitlements section.
       [Automatically generated disentitlements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_disentccb#auto_generated_disentitlement) 

### Manual disentitlements

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/manual_disentitlements.dita`

The officer can also manually impose a disentitlement from special benefits after the claim transactions are generated. These include the following:

- 51 - Does not meet compassionate care entitlement conditions disentitlement (D51)

- 52 - Compassionate care benefits exhausted disentitlement (D52)

- 53 - Compassionate care benefits - No medical proof disentitlement (D53)

- 62 - Family caregiver benefits for children or adults - Benefits exhausted disentitlement (D62)

A record of decision (ROD) must be on file when a client is disentitled from special benefits unless the client is disentitled for being minor attached. If a ROD is required but not on file, the officer must return to the previous task that generated the condition to determine if the disentitlement is correct. 

### Communicating the decision

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/communicating_the_decision.dita`

If the officer determines that the calculation is correct, the officer must advise the client of the decision.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2386.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2385.dita`

Note:

For a maternity or parental claim, if the client applied before the benefit window, a postdate can be considered. For more information, refer to the Postdate Policy .
       [Postdate Policy](/en/policy/nationalpolicy/national_policy_on_postdates.shtml)

     [Postdate Policy](/en/policy/nationalpolicy/national_policy_on_postdates.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2386.dita`

Note:

When an allocation of earnings (e.g. paid sick leave, wage loss insurance, severance pay) prevents payment until after the period in which the client would have been entitled to benefits, the officer does not send a letter to notify the client of the disentitlement from benefits. The officer imposes a disentitlement only to ensure that the client can continue completing claimant’s reports during the period of the allocation and after benefits are payable, without having to submit a renewal for benefits. 

## Regional considerations

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/in_nws.dita`

- Is there a ROD for the disentitlement that applies? 

### In SSO:

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/in_sso.dita`

- Is there an allocation which prevents the payment of benefits beyond the period during which the client is disentitled? 

## Step by step

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/level_1.dita`

#### Reviewing the file for automatically generated disentitlements

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/reviewing_the_file_for_automatically_ge_7db84427_level_1.dita`

- Determine if any of the following conditions are displayed in the calculation result:

- BPC is greater than the caregiver window

- BPC is prior to effective date of caregiver for child

- BPC is prior to effective date of caregiver for adult

- Caregiver benefits minor attached

- Caregiver medical proof required

- Caregiver window start date window > BPC

- Claim procedure

- Compassionate care — no proof

- Compassionate care — minor attached or not within the compassionate care window

- Maternity — minor attached

- No medical certificate submitted

- Not capable (minor attachment — I of E caused by illness)

- Parental — minor attached, not within the parental window or parental/special benefits exhausted

- Parental — no proof of placement

- If yes, go to step 2.

- If no, go to step 8.

- Determine if the condition is indicated because the client is minor attached:

- If no, go to step 3.

- If yes, go to step 8.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1305.dita)

- In NWS, determine if a ROD is on file for the corresponding disentitlement:

- If no, the disentitlement may be imposed in error. Go to step 4.

- If yes, go to step 8.

- Determine if the condition is generated because proof is outstanding:

- If yes, go to step 5.

- If no, go to step 6.

- In SSO, on the Registration screen, indicate that the outstanding proof is due as follows:

- Outstanding information: Select this option.

- In the Due date field for the proof that applies, delete the due date of the calculation WI.

- Select Save .

- On the calculation worksheet, note that the disentitlement that may be imposed in error requires a corresponding ROD. Also note that if the disentitlement does not apply, the officer must ensure that a letter is not sent for the corresponding disentitlement.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2387.dita)

- Choose the appropriate option:

- If a D15 will be imposed in error, return to Determining if proof of entitlement to maternity benefits is required .
               [Determining if proof of entitlement to maternity benefits is required](/en/procedure/task/determining_pembr.shtml)

- If a D16 will be imposed in error, return to Determining if a medical certificate must be submitted — Sickness benefits — Initial claims .
               [Determining if a medical certificate must be submitted — Sickness benefits — Initial claims](/en/procedure/task/calc_determining/det_mc_ra.shtml)

- If a D34 will be imposed in error, return to Determining if proof of entitlement to parental benefits is required .
               [Determining if proof of entitlement to parental benefits is required](/en/procedure/task/determining_pepbr.shtml)

- If a D35 will be imposed in error, return to Determining if the number of parental weeks requested are available .
               [Determining if the number of parental weeks requested are available](/en/procedure/task/determining_npwra.shtml)

- If a D51 will be imposed in error and this is an initial calculation, return to step 10 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If a D52 will be imposed in error and this is a recalculation, return to step 10 of Determining if a claim is ready to be recalculated — CCB .
               [Determining if a claim is ready to be recalculated — CCB](/en/procedure/activity/calc_pcic_benefit.shtml)

- If a D53 will be imposed in error, return to Determining if a medical certificate is acceptable: CCB — Initial Claims .
               [Determining if a medical certificate is acceptable: CCB — Initial Claims](/en/procedure/task/calc_determining/medical_cert_ccb.shtml)

- If a D61 will be imposed in error and this is an initial calculation, return to step 10 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml)

- If a D63 will be imposed in error, return to Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Reviewing the file for manual disentitlements

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/reviewing_the_file_for_manual_disentitlements_level_1.dita`

- Determine if it was previously noted that a disentitlement from special benefits must be manually imposed when the claim is input:

- If yes, go to step 9.

- If no, go to step 12.

- In NWS, determine if a ROD is on file for each disentitlement from special benefits that must be manually imposed when the claim is input:

- If no, the disentitlement may be imposed in error. Go to step 10.

- If yes, go to step 12.

- On the calculation worksheet, note that the disentitlement that may be imposed in error requires a corresponding ROD. Also note that if the disentitlement does not apply, a letter must not be sent for that disentitlement. Ensure that the Registration screen in SSO does not indicate corresponding proof is outstanding.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2388.dita)

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 11 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 11 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 11 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 11 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 11 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Communicating the decision

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/communicating_the_decision_level_1.dita`

- Determine if an allocation prevents the payment of benefits beyond the period during which the client is disentitled:

- If no, go to step 13.

- If yes, go to step 14.

- If the claim is established, on the calculation worksheet, note that an N-00-00-00 letter is required to advise the client of each disentitlement that prevents the payment of special benefits. Based on the claim information, select all of the required attributes, including the following:

- Special benefits Denied (3065) .

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- Attachment List for N-00-00-00 (3116): Select appropriate attachment, if appropriate.

- Refer to step 10 of Reviewing the calculation result . 

#### Note

Source topic: `en_EN/common_notes/note_c_1305.dita`

Note:

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure. 

#### Note

Source topic: `en_EN/common_notes/note_c_2387.dita`

Note:

Although the note may be correct, a disentitlement that requires a ROD cannot be imposed without a ROD on the file. Return to the procedure that corresponds with that disentitlement and review the entitlement condition. 

#### Note

Source topic: `en_EN/common_notes/note_c_2388.dita`

Note:

Although the note may be correct, a disentitlement that requires a ROD cannot be imposed without a ROD on file. Return to the procedure that corresponds with that disentitlement and review the entitlement condition. 

## Policy reference

Source topic: `en_EN/task/calc_reviewing/review_calc_disentccb/policy_reference.dita`

 
