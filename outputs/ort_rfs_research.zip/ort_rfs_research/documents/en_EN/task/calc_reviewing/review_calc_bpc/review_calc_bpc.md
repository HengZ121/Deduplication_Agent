# Reviewing the calculation result — BPC

Source map: `en_EN/task/calc_reviewing/review_calc_bpc/review_calc_bpc.ditamap`

## Summary

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/summary.dita`

Summary: The start date of an EI claim is the BPC date. This date is always a Sunday and is referred to by its w/c. When reviewing the calculation result, the officer must verify that the BPC is correct. 

## What you need to know

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0887.dita) 

### Calculated BPC

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/calculated_bpc.dita`

After a claim is calculated in SSO, the officer must ensure that the BPC displayed is correct.

When calculating a claim, SSO uses a date from the Subsequent or manual BPC field on the Coding Requirements screen or, if no date is indicated, the Antedate to field on the Application Form screen is used. If the Subsequent or manual BPC field on the Coding Requirements screen is completed and the client does not qualify with that BPC but would qualify if the BPC was postdated, SSO will postdate the BPC. If neither field is completed, SSO automatically determines the BPC based on the following information:

- date of filing

- the interruption of earnings (I of E)
         [interruption of earnings](/en/procedure/generic/knowledge.shtml)

- last day worked (LDW) provided by the client

- last day for which paid (LDP) on the last ROE

- amount of the earnings in the last week of insurable employment

- existence of a prior benefit period (BP) (client is submitting a subsequent claim )
         [subsequent claim](/en/procedure/generic/knowledge.shtml#Benefit_period_commencement)

- benefit type (BT) requested

- non-match of the LDW and the LDP on the last ROE

The LDW refers to the LDW as provided by the client. In block 11 on the last ROE, the employer provides the last day for which insurable earnings were paid to the client (LDP). While the LDW and LDP are usually the same, they differ when the client stops working but continues to be paid insurable earnings.

When the LDP on the last ROE is within 14 days of the LDW on the application (LDW plus or minus 13 days), the dates are accepted as displayed. 

### Situations that require a manual BPC

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/situations_that_require_a_manual_bpc.dita`

Although the BPC displayed on the Calculation Result screen is usually correct, a manual entry in the Subsequent or manual BPC field or Antedate to field may be required if one of the following conditions is met:

- The client is part of a Work-Sharing (WS) program, has provided a WS reference code and has applied within 8 weeks after the WS agreement start date (digits 11 to 14 of the reference code).

- The client has reapplied due to a change in the qualifying conditions (i.e. a change in the regional rate of unemployment [RRU]).

- The client received QPIP benefits during the qualifying period (QP).

- The client is entitled to an antedate.

- The client is entitled to a postdate.

- SSO automatically postdates the claim when the recovery week is indefinite based on a medical certificate that indicates terminal or palliative.

- The Administrative Policy applies.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2367.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2368.dita) 

**Work Sharing (WS)**

When a WS client has not applied for benefits within 4 weeks after the I of E, the BPC may be incorrect.

If the client has not applied for benefits within 4 weeks after the I of E but has applied within 8 weeks after an approved WS agreement start date, the claim is considered to be submitted in a timely manner. When this occurs, the officer must input the Sunday of the week in which the WS agreement start date occurs in the Subsequent or manual BPC field.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2369.dita) 

**Changes to the qualifying conditions**

On occasion, the number of hours required to qualify for benefits can change. This is generally due to a change to the RRU, although it can sometimes be due to a legislative change.

The RRU is subject to change every 4 weeks. Once the RRU is established, it is valid for a 4-week period, starting on a Sunday and ending on a Saturday. When the RRU changes in an economic region, clients whose BPs are not established because the entrance requirements were not met may now qualify due to a change in the number of hours required to qualify.

On rare occasions, a legislative change may affect the number of hours required to qualify for benefits. When this occurs, clients whose BPs are not established because they did not have sufficient hours to qualify may now qualify for benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2370.dita) 

An EI application is deemed to have been filed in a timely manner when the application is filed within the 4-week administrative timeframe . If there is a change in the VER that may allow the client to qualify and the client re-applies outside of the 4-week timeframe, the claim is established as of the week of filing. In this case, for the BP to start as early as the week in which the VER changed, the client must submit a formal antedate request to prove that there was good cause for the delay in applying. These BPs must not start earlier than the date of the VER change. If the start date is earlier, the claim is BPNE.
       [4-week administrative timeframe](/en/policy/nationalpolicy/administrative_policy.shtml)

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment is required to establish a claim for regular or special benefits. If the client has a violation on file, increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the entrance requirement is not based on the regional rate of unemployment (RRU). However, the RRU continues to be used to determine the divisor, and the entitlement weeks based on the hours of insurable employment in the qualifying period (QP).
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

**QPIP benefits**

When a client files a claim after receiving QPIP benefits, the officer on the specialized team determines if the client would otherwise have been entitled to EI maternity or parental benefits according to the Equivalencies between QPIP and EI benefits National policy.

If the client would have been otherwise entitled, the officer establishes the claim with a BPC at the beginning of QPIP benefits period. When the claim is established, the officer follows the procedures to renew the client’s benefit period.

If the client would not have been otherwise entitled, the officer establishes the claim as an initial claim based on the date the claim was filed.

**Antedate**

When a client is entitled to an antedate, the officer completes the Antedate to field when calculating the claim in SSO. If the client is entitled to an antedate and the Antedate to field is incorrectly completed or not completed, an incorrect BPC may be displayed in the calculation result. The officer must refer to Entering an antedate in SSO .
       [Entering an antedate in SSO](/en/procedure/task/calc_calculating/input_antedate.shtml)

**Postdate**

The officer can only postdate the BPC in the following situations that may be advantageous to the client:

- The client requires the hours of insurable employment from the last week worked to qualify for benefits.

- The I of E week or the application week is a full work week (FWW).

- Because of earnings in the I of E week, the client would have received only a partial first payment and has requested that the claim be postdated by one week.

- Separation monies or earnings, or a combination of both, in the I of E week or the application week are equal to or greater than the benefit rate.

- The client submitted a claim for maternity or parental benefits before the benefit window.

- The client requests special benefits and can receive the maximum allowable number of weeks of the requested type of special benefits, but earnings in the BPC week prevent payment of the full benefit rate. If a return to work (RTW) date is on the ROE or elsewhere on the claim, the officer considers it when determining if a claim for special benefits can be postdated.

- For teachers only: The client may be entitled to a contractual payment from the employer in addition to a supplemental unemployment benefits (SUB) top-up for maternity and parental benefits. These monies are earnings and prevent payment of EI benefits for those weeks, as they do not meet the criteria for SUB. A postdate could be to the client’s advantage, but the officer must pay attention to both the maternity and parental windows to ensure maximum entitlement remains available.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2371.dita) 

When the recovery week selected is indefinite (based on a medical certificate that indicates terminal or palliative), SSO automatically postdates the claim by one week if there are earnings in week 1. The BPC of a claim with an indefinite recovery week (based on a medical certificate that indicates terminal or palliative) must not be postdated. In these cases, the officer manually enters the BPC corresponding to the last week of work in the Subsequent or manual BPC field on the Coding Requirements screen in SSO to prevent the automatic postdating of a claim.

When the recovery week selected is indefinite (based on a medical certificate that indicates terminal or palliative), an officer can postdate the claim when there are earnings in week 1, only if the client has specifically requested to postdate the claim.

A claim for special benefits (other than sickness benefits) can be postdated when there is clear evidence (e.g. the RTW date) indicating that doing so will allow the client to be paid or payable the full benefit rate for the number of weeks requested or allowable. When information on the file (e.g. the RTW date, the end of a special benefits window or the date of the patient’s death) indicates postdating the claim would not be advantageous to the client, the officer does not postdate the claim.

If the client has worked since the initial application date and needs those hours to qualify for benefits, the officer can use the additional hours to establish the BP. The BPC is based on the most recent I of E, and the client must provide the ROE and any other relevant information. If an initial decision has already been made, the client must reapply.

When a BPC is established after the week in which the client filed the EI application, the officer sends the appropriate notice to the client. A notification is not required when a BPC is postdated for one of the following reasons:

- The client worked a full work week in the week of filing.

- A postdated BPC will allow the maximum payment of maternity and parental benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2372.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2373.dita) 

**Administrative policy**

When the client applies within 4 weeks after the week of the I of E, last week worked, or last week for which wage loss insurance (WLI), workers’ compensation benefits (WCB) or QPIP is paid, the application is considered to have been submitted in a timely manner. WCB, including preventive withdrawal payments, and WLI do not prevent an I of E and are not considered earnings for benefit purposes when they are paid during the waiting period (WP). Therefore, if the client has applied within 4 weeks after receiving any of these payments, the BPC is in the last week of payment if it is to the client’s advantage. This allows the client to serve the WP while receiving WCB, including preventive withdrawal payments, or WLI. If the WP is waived because the client received paid sick leave (PSL) from the employer after the LDW, the BPC is established the week after the last week of payments.
       [WP is waived](/en/procedure/generic/knowledge.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2374.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2375.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2376.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2377.dita) 

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_0887.dita`

Note:

When fact-finding about an initial calculation or recalculation using a Government of Canada ROE, refer to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2367.dita`

Note:

A BPC cannot be postdated beyond the current VER range .
       [VER range](/en/procedure/generic/knowledge.shtml#Variable_entrance_requirement)

     [VER range](/en/procedure/generic/knowledge.shtml#Variable_entrance_requirement) 

### Note

Source topic: `en_EN/common_notes/note_c_2368.dita`

Note:

Budget 2021 established a common entrance requirement (CER) for all BPCs between w/c 2310 and w/c 2361. However, a BPC cannot be postdated beyond the current range of the RRU. The RRU continues to be used for the entitlement weeks and the divisor. 

### Note

Source topic: `en_EN/common_notes/note_c_2369.dita`

Note:

The WS agreement start date is indicated in digits 11 to 14 of the WS reference code. 

### Note

Source topic: `en_EN/common_notes/note_c_2370.dita`

Note:

If a client applies for special benefits and qualifies for the BT requested but not for regular benefits, a notice is not sent to the client because the client already qualifies for the BT requested. 

### Note

Source topic: `en_EN/common_notes/note_c_2371.dita`

Note:

A claim for sickness benefits is postdated only when the medical certificate indicates a specific recovery date that will allow the client to receive the full entitlement to those benefits at the full weekly rate. 

### Note

Source topic: `en_EN/common_notes/note_c_2372.dita`

Note:

A BPC can be postdated up to 4 weeks, but cannot be postdated beyond the current VER range .
       [VER range](/en/procedure/generic/knowledge.shtml#Variable_entrance_requirement)

     [VER range](/en/procedure/generic/knowledge.shtml#Variable_entrance_requirement) 

### Note

Source topic: `en_EN/common_notes/note_c_2373.dita`

Note:

Budget 2021 established a CER for all BPCs between w/c 2310 and w/c 2361. However, a BPC cannot be postdated beyond the current range of the RRU. The RRU continues to be used to determine the entitlement weeks and the divisor. 

### Note

Source topic: `en_EN/common_notes/note_c_2374.dita`

Note:

Preventive withdrawal payments are a part of the WCB in Quebec. 

### Info

Source topic: `en_EN/common_notes/note_c_2375.dita`

**Example 1:**

- reason for separation (RFS): D - Illness or injury

- LDW: April 2, 2024 (w/c 2441)

- earnings last week worked (ELWW): $360

- normal weekly earnings (NWE): $900

- WLI paid from w/c 2442 to w/c 2445: $630 per week

- WLI benefits paid in w/c 2446: $126

- week client applies for regular benefits: w/c 2448

- WP: not waived

- benefit rate: $495

- premium reduction code: 2 - Premium reduction WLI

```text
| w/c | 2441 | 2442 | 2443 | 2444 | 2445 | 2446 | 2447 | 2448 |

| Wages | $360 I of E | [n/a] | [n/a] | [n/a] | [n/a] | BPC | [n/a] | Submission of the EI application |

| WLI | [n/a] | $630 | $630 | $630 | $630 | $126 | [n/a] | [n/a] |
```

The BPC is w/c 2446 because the client applied within 4 weeks after the last WLI payment. This allows the client to serve the WP in the last week of WLI earnings which are not considered earnings in the WP. 

### Info

Source topic: `en_EN/common_notes/note_c_2376.dita`

**Example 2:**

- RFS: D - Illness or injury

- LDW: April 5, 2024 (w/c 2441)

- ELWW: $900

- NWE: $900

- PSL paid w/c 2442: $500

- WLI paid from w/c 2443 to w/c 2445: $630 per week

- week client applies for regular benefits: w/c 2448

- WP: waived

- benefit rate: $495

- premium reduction code: 2 - Premium reduction WLI

```text
| w/c | 2441 | 2442 | 2443 | 2444 | 2445 | 2446 | 2447 | 2448 |

| Wages | $900 | I of E | [n/a] | [n/a] | Administrative Policy BPC (not to client’s advantage) | Actual BPC | [n/a] | Submission of the EI application |

| PSL | [n/a] | $500 | [n/a] | [n/a] | [n/a] | [n/a] | [n/a] | [n/a] |

| WLI | [n/a] | [n/a] | $630 | $630 | $630 | [n/a] | [n/a] | [n/a] |
```

The BPC would be w/c 2445 based on the Administrative Policy. Even if the client applied within 4 weeks after the last WLI payment, if the BPC is established in the last week of WLI, these earnings will be deducted from benefits because the WP is waived. In this case, because the WP is waived, the BPC is w/c 2446, which is the most advantageous to the client. Therefore, the BPC is postdated to the week following the last week of WLI. The officer first applies the Administrative Policy and then the postdate policy to determine the correct BPC. 

### Note

Source topic: `en_EN/common_notes/note_c_2377.dita`

Note:

Do not apply the Administrative Policy if it is not to the client’s advantage. The BPC may be disadvantageous in the following situations:

- The client does not qualify at the earlier date.

- The client’s benefit rate decreases.

- The client is no longer within the range for special benefits.

- The client qualifies for regular benefits but is no longer major attached. 

## Regional considerations

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/in_nws.dita`

- Is there an approved antedate request on file?

- Has the client received WCB, preventive withdrawal payments or WLI benefits after ceasing work?

- If yes, in what weeks were the WCB or WLI benefits paid?

- What is the LDW provided by the client on the application or on other documentation?

- Is the client reapplying due to a change in the qualifying conditions?

- If yes, when was the application filed and what is the client’s normal place of residence?

- Has the client requested a different start date to the BP? 

### In RCM:

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/in_rcm.dita`

- Is there information on the last ROE showing the client continues to work, has not had an I of E, or is receiving salary continuance or other monies such as scheduled paid vacation or paid sick leave (PSL)?

- What is the LDP on the last ROE?

- Is there information on the last ROE showing the client has received WLI after ceasing work? 

### In Imaging:

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/in_imaging.dita`

- Are there letters or other documentation which may impact when the claim is to start?

- Is there information regarding a continuance of pay or other insurable monies? 

### In FTS:

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/in_fts.dita`

- Is there a previous claim in the QP with a BPNE result?

- If yes, what is the current RRU ?
             [RRU](http://srv129.services.gc.ca/eiregions/eng/rates_cur.aspx)

- Were QPIP benefits paid in the QP? 

### In SSO:

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/in_sso.dita`

- If an antedate had been approved, has the antedate information already been entered on the Application Form ?

- If yes, has it been entered correctly?

- Has the WP been waived? 

## Step by step

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/level_1.dita`

#### Reviewing the last day worked (LDW) and last day paid (LDP)

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/reviewing_the_last_day_worked_ldw_and_l_062f17b7_level_1.dita`

- Determine if the LDW on the application and the LDP on the last ROE are within 14 days of each other (LDW plus or minus 13 days):

- If the LDW and LDP are within 14 days of each other, accept the result and go to Determining if the client received QPIP benefits .
               [Determining if the client received QPIP benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_2)

- If the LDW and LDP are not within 14 days of each other, determine if the LDW is before or after the LDP (e.g. LDW is May 1 and LDP is May 30):

- If the LDW is after the LDP, go to step 2.

- If the LDW is before the LDP, go to step 6.

- Fact-find with the client to determine why the LDW on the application is more than 14 days after the LDP on the last ROE.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 7.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Calculation .

- Comments: Type “Last day worked versus last day paid.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client has provided a new LDW which is within 14 days (plus or minus) of the LDP on the ROE:

- If the client has not provided a new LDW which is within 14 days (plus or minus) of the LDP on the ROE, go to step 7.

- If the client has provided a new LDW which is within 14 days (plus or minus) of the LDP on the ROE, refer to Modifying the last day worked in SSO .
               [Modifying the last day worked in SSO](/en/procedure/task/calc_calculating/changing_fdw_ldw.shtml)

- Determine if the ROE confirms that the client has received insurable earnings (e.g. PSL, salary continuance, scheduled paid vacation days, or scheduled insurable days off) after ceasing work:

- If the ROE confirms that the client has received insurable earnings after the LDW, go to Determining if the client received QPIP benefits .
               [Determining if the client received QPIP benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_2)

- If the ROE does not confirm that the client has received insurable earnings after the LDW, go to step 7.

- Fact-find with the employer to determine why the LDW and the LDP dates differ by more than 14 days. If applicable, provide the information received from the client.

- Determine if the employer was contacted during fact-finding:

- If the employer was not contacted, go to step 9.

- If the employer was contacted, go to step 18.

- In ACS, send a registered copy of the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1564.dita)

- In NWS, move the calculation WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Z-02-00-00 letter sent.”

- Bring forward date: Enter the date the letter is sent + 10 business days.

- When the calculation WI moves to the current workload, determine if the information is now on file:

- If no, go to step 12.

- If yes, go to step 18.

- Refer the file to Integrity for employer non-compliance.

- Determine if there has been an attempt to contact the client:

- If contact has not been attempted, fact-find with the client to determine why the LDW and the LDP dates differ by more than 14 days. Go to step 14.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If contact has been attempted and the client responded, go to step 16.

- If contact has been attempted and the client did not respond, on the calculation worksheet, note that a 15 - Claim procedure (D15) disentitlement is required if the client qualifies and go to step 18.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2378.dita)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 15.

- If the client was not contacted, on the calculation worksheet, note that a (D15) disentitlement is required if the client qualifies for benefits. Go to step 17.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Calculation .

- Comments: Type “Last day worked versus last day paid.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client has confirmed the LDW provided on the application:

- If the client provides a new LDW which is within 14 days (plus or minus) of the LDP on the ROE, refer to Modifying the last day worked in SSO .
               [Modifying the last day worked in SSO](/en/procedure/task/calc_calculating/changing_fdw_ldw.shtml)

- If no information has been provided, go to step 17.

- If the client has confirmed the LDW on the application is correct, determine if the LDW is before or after the LDP on the ROE:

- If the LDW is after the LDP, obtain the information from the client to enter an interim ROE .
                   [enter an interim ROE](/en/procedure/activity/interim_roe.shtml)

- If the LDW is before the LDP, accept the ROE as provided and advise the client that the claim will be reviewed when information is received from the employer.

- Go to step 17.

- Accept the calculation as displayed and go to Determining if the client received QPIP benefits .

- In RCM, make any required changes to the ROE according to the information obtained during fact-finding.

- If the employer was contacted, in the Additional information field , document the information obtained.

- Select Validate and determine if an error is displayed:

- If no error is displayed, select Submit and go to step 19.

- If an error is displayed, refer to Correcting an ROE and go to step 19.
                   [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- Review the new or amended information to determine if an I of E has occurred:

- If an I of E has occurred, go to step 9 of Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- If an I of E has not occurred, refer to Indicating in SSO that there is no interruption of earnings .
               [Indicating in SSO that there is no interruption of earnings](/en/procedure/task/calc_calculating/no_interruption_earnings.shtml) 

#### Determining if the client received QPIP benefits

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/determining_if_the_client_received_qpip_benefits_level_1.dita`

- Determine if the client received QPIP benefits during the QP:

- If yes, go to step 2.

- If no, go to Determining if the client is part of Work-Sharing (WS) program .
               [Determining if the client is part of Work-Sharing (WS) program](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_3)

- In SSO, enter the manual BPC on the Coding Requirements screen as follows:

- Subsequent or manual BPC: Select the Sunday of the week in which the QPIP program started.

- On the Annex - Special Benefits screen, complete the following fields:

- If the client qualifies for QPIP maternity benefits, in the Actual date of birth field, select the exact date given by the client.

- Arrival or placement week: Select the date given by the client.

- If the client is male or if it is a claim for adoption:

- Start week: Enter the date given by the client.

- Natural / adoption: Select the correct sex code.

- Weeks requested: Enter the correct number of parental benefits weeks to which the client is entitled.

- Note the Claim type on the Coding Requirements screen and change the information as follows:

- Claim type: Select the correct claim type (CT).

- Determine if any changes were made in SSO:

- If no, go to step 6.

- If yes, go to step 9 of Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Determine if the client is entitled to EI maternity or parental benefits from the QPIP start week:

- If yes, go to step 7.

- If no, go to step 9.

- Note that when a claim is established, it must be renewed. Go to step 8.

- In SSO, remove the manual BPC on the Coding Requirements screen as follows:

- Subsequent or manual BPC: Remove the indicated date.

- On the Coding Requirements screen, change the CT as follows:

- Claim type: Select the correct CT.

- Determine if any changes were made in SSO:

- If no, go to Determining if the client is part of Work-Sharing (WS) program .
               [Determining if the client is part of Work-Sharing (WS) program](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_3)

- If yes, go to step 9 of Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml) 

#### Determining if the client is part of a Work-Sharing (WS) program

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/determining_if_the_client_is_part_of_a__ad7a1065_level_1.dita`

- Determine if the client is part of an approved WS program:

- If yes, go to step 2.

- If no, go to Determining if an antedate is required .
               [Determining if an antedate is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_4)

- Determine if the client applied within 8 weeks after the WS agreement start date:

- If yes, go to step 3.

- If no, go to Determining if an antedate is required .
               [Determining if an antedate is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_4)

- In SSO, enter the manual BPC on the Coding Requirements screen as follows:

- Subsequent or manual BPC: Select the Sunday of the week in which the WS agreement started.

- Determine if any changes were made in SSO:

- If no, go to Determining if an antedate is required .
               [Determining if an antedate is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_4)

- If yes, go to step 9 of Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml) 

#### Determining if an antedate is required

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/determining_if_an_antedate_is_required_level_1.dita`

- In SSO, determine if the expected BPC is displayed on the Calculation Result screen:

- If the expected BPC is not displayed, go to step 2.

- If the expected BPC is displayed, go to Determining if a postdate is required .
               [Determining if a postdate is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_5)

- Determine if an approved antedate must be entered:

- If yes, go to step 3.

- If no, go to Determining if a postdate is required .
               [Determining if a postdate is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_5)

- Determine if the date in the Antedate to field is correct (refer to Entering an antedate in SSO , if necessary):

- If yes, go to Determining if a postdate is required .
               [Determining if a postdate is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_5)

- If no, refer to Entering an antedate in SSO .
               [Entering an antedate in SSO](/en/procedure/task/calc_calculating/input_antedate.shtml) 

#### Determining if a postdate is required

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/determining_if_a_postdate_is_required_level_1.dita`

- Determine if the recovery week is indefinite based on a medical certificate that indicates terminal or palliative:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the BPC has been postdated due to earnings in week 1.

- If no, go to step 3.

- If yes, the BPC is the last week worked unless the client specifically requested to postdate the claim. Go to step 15.

- Determine if postdating the BPC is advantageous to the client or if the client is entitled to a requested postdate:

- If no, go to Determining if an automatic antedate is required .
               [Determining if an automatic antedate is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_6)

- If yes, go to step 4.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2379.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2380.dita)

- Determine if a postdate will result in a BPC that falls after the calendar week of the application:

- If yes, go to step 5.

- If no, go to step 15.

- Determine if the BPC is postdated for one of the following reasons:

- The BT is maternity and parental and the BP is postdated to pay full benefits.

- The week of filing was a full work week.

- If no, go to step 6.

- If yes, go to step 15.

- Determine if the BPC is postdated to fall within the benefit window for maternity or parental benefits:

- If yes, go to step 7.

- If no, go to step 8.

- On the calculation worksheet, note that the N-00-00-00 letter is required. Based on the claim information, select all of the required attributes, including the following:

- Antedate Denied or Postdate Message-Initial/Renewal/Continuing claim (2481)

- Postdate Message (2486)

- Postdate - Initial Claim (2487)

- TEXT: Reason(s) why claim was postdated

- Text - Insert appropriate post-date reason (1068): Type “you do not meet the entitlement requirements for [special benefits type] until [BPC date].”

- BPC date - Sunday’s date (1060)

- Go to step 15.

- Determine if the BPC is postdated by more than one week:

- If no, go to step 9.

- If yes, go to step 10.

- On the calculation worksheet, note that the N-00-00-00 letter may be required. Based on the claim information, select all of the required attributes, including the following:

- Antedate Denied or Postdate Message - Initial/Renewal/Continuing claim (2481)

- Postdate Message (2486)

- Postdate - Initial Claim (2487)

- BPC date - Sunday’s date (1060)

- Go to step 15.

- Determine if fact-finding has already occurred with the client to obtain information on additional insurable hours or earnings accumulated after the EI application was filed:

- If yes, go to step 13.

- If no, fact-find with the client. If the client has worked after the application date and before the date the BPC could be postdated to, the postdate cannot be granted. Advise the client that he or she may qualify if a new application is filed.
               [fact-find](/en/procedure/task/fact_find.shtml)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 12.

- If the client was not contacted, the postdate cannot be granted. Go to step 14.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Issue: Select Calculation .

- Comments: Type “Confirmation of last day worked or paid.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client has accumulated any other insurable hours or earnings after the EI application was submitted and before the date the BPC could be postdated to:

- If yes, the postdate cannot be granted. Go to step 14.

- If no, go to step 15.

- On the calculation worksheet, note that if the client is BPNE N6 with a BPC before July 3, 2016, you must override the automated BPNE letter and manually create one. Also note that when this occurs, in FTS, from the File Control Data (M101) transaction, you must select Claim Action — Automated Letter Bypass to prevent the creation of the automated BPNE letter and manually create one with the following details:

- This letter replaces or Footnote (2365) :

- Footnote: Once we receive your application, we will determine eligibility and establish a new claim if you now qualify for benefits.

- Go to Determining if an automatic antedate is required .
               [Determining if an automatic antedate is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_6)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2381.dita)

- In SSO, on the Coding Requirement s screen, enter the manual BPC as follows:

- Subsequent or manual BPC: Select the Sunday date of the manual BPC.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2382.dita)

- Determine if any changes were made in SSO:

- If no, go to Determining if the Administrative Policy applies .
               [Determining if the Administrative Policy applies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_reviewing/review_calc_bpc#level1_item_6)

- If yes, go to step 9 of Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2383.dita) 

#### Determining if the Administrative Policy applies

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/determining_if_the_administrative_policy_applies_level_1.dita`

- Determine if the client received WCB, including preventive withdrawal payments, or WLI payments and applied no later than 4 weeks after the last week of the payments:

- If yes, go to step 2.

- If no, go to step 10.

- In SSO, on the Calculation Result screen, determine if the WP is waived:

- If no, the BPC is the last week of the WCB, preventive withdrawal payments or WLI. Go to step 3.

- If yes, the BPC is the week following the last week of WCB, preventive withdrawal payments or WLI. Go to step 3.

- In SSO, on the Coding Requirements screen, enter the BPC as follows:

- Subsequent or manual BPC: Enter the Sunday date of the BPC week.

- Determine the type of payment received by the client:

- If WLI (EI Insurable) was paid, go to step 5.

- If WLI (Not EI Insurable) was paid and the information is not displayed in block 19 of the ROE, go to step 7.

- If WLI (Not EI Insurable) was paid and the information is displayed in block 19 of the ROE, go to step 8.

- If WCB or preventive withdrawal payments were paid, on the calculation worksheet, note that when reviewing and inputting the calculation, an M175 - Allocation Set-up (M175) transaction with B - Workers compensation / preventative withdrawal benefits in the Allocation type field must be displayed in SSO. Go to step 8.

- In RCM, update the ROE by inputting the following information in the Additional Information section:

- Additional Information: Enter the information found in the Wage Loss Indemnity (EI Insurable) section.

- Wage Loss Indemnity (EI Insurable): Delete the entries.

- Select Validate and Submit . If there are validation errors, refer to Correcting an ROE before proceeding.
               [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- On the calculation worksheet, note that if an amount corresponding to WLI payments is displayed in the Earnings week 1 field on the M103 - Initial Decision (M103) transaction, the amount must be deleted from the Earnings week 1 field.

- On the calculation worksheet, note that when reviewing and inputting the calculation, an Allocation (M175) transaction with F - Wage Loss Insurance in the Type field must be input in FTS.

- Review the new calculation result and determine if the BPC is to the client’s advantage:

- If no, go to step 9.

- If yes, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2384.dita)

- In SSO, on the Coding Requirements screen, remove the BPC as follows:

- Subsequent or manual BPC: Delete the date displayed.

- Determine if any changes were made in SSO:

- If no, go to step 4 of Reviewing the calculation result .
               [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml)

- If yes, go to step 9 of Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_1564.dita`

Note:

When sending a copy of an original letter, print the letter locally. For instructions on printing locally while teleworking, refer to Telework: Printing documents locally — Instructions .
       [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml)

     [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2378.dita`

Note:

When the information on the ROE must be clarified or corrected, attempt to contact the employer. If the employer cannot be reached, it is acceptable to contact the client to try to obtain the required information. However, the employer must be notified of any changes to the content of the ROE. 

#### Note

Source topic: `en_EN/common_notes/note_c_2379.dita`

Note:

A BPC can be postdated up to 4 weeks but cannot be postdated beyond the current VER range .
       [VER range](/en/procedure/generic/knowledge.shtml#Variable_entrance_requirement)

     [VER range](/en/procedure/generic/knowledge.shtml#Variable_entrance_requirement) 

#### Note

Source topic: `en_EN/common_notes/note_c_2380.dita`

Note:

Budget 2021 established a CER for all BPCs between w/c 2310 and w/c 2361. However, a BPC cannot be postdated beyond the current range of the RRU. The RRU continues to be used for the entitlement weeks and the divisor. 

#### Note

Source topic: `en_EN/common_notes/note_c_2381.dita`

Note:

When a claim is calculated BPNE, an ACS letter can be automatically created. If the client must be notified of multiple decisions, all of the decisions must be included in one letter. Selecting the Automated Letter Bypass function allows you to create a new letter to advise the client of all of the decisions. 

#### Note

Source topic: `en_EN/common_notes/note_c_2382.dita`

Note:

A date in the Subsequent or manual BPC field on the Coding Requirements screen overrides any date entered in the Antedate to field on the Application Form screen. 

#### Note

Source topic: `en_EN/common_notes/note_c_2383.dita`

Note:

When the expected BPC is not displayed, including after entering an antedate or any other adjustments, it may be necessary to discuss the calculation result with a business expertise advisor. Before doing this, ensure that entries in SSO and RCM are correct. 

#### Note

Source topic: `en_EN/common_notes/note_c_2384.dita`

Note:

Do not accept the BPC in the new calculation result if it is not to the client’s advantage. The new BPC may be disadvantageous in the following situations:

- The client does not qualify on the earlier date.

- The client qualifies for regular benefits but is no longer major attached.

- The client’s rate is lower.

- The client is no longer within the range for special benefits. 

## Policy reference

Source topic: `en_EN/task/calc_reviewing/review_calc_bpc/policy_reference.dita`

- EIR 39(3)
         [EIR 39(3)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-39.html)

- Administrative Policy (National Policy)
         [Administrative Policy (National Policy)](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/administrative_policy.shtml) 
