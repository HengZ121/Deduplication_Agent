# Deferring adjudication: Initial claim — Sickness benefits

Source map: `en_EN/task/defer_adj_initial_sickness_ben/defer_adj_initial_sickness_ben.ditamap`

## Summary

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/summary.dita`

Summary: In certain situations, adjudication of a contentious issue can be deferred on initial sickness claims. 

## What you need to know

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/what_you_need_to_know.dita`

### Conditions

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/conditions.dita`

To determine entitlement to benefits when an Adjudication Issue (ADJ) WI is assigned, the officer fact-finds and adjudicates the issue, regardless of whether the ROEs have been received.

On initial claims for sickness benefits, the officer can defer adjudication in the following situations:

- any adjudication issue when the claim is automated BPNE 2;

- any adjudication issue when the claim is a manual BPNE 2 at day 27;

- any adjudication issue when the claim is automated BPNE 1;

- any adjudication issue when the claim is a manual BPNE 1 or 5;

- any adjudication issue when the client has less than 420 insurable hours in the qualifying period (QP);

- the reason for separation (RFS) is B - Strike or lockout (labour dispute) and the claim is BPNE;

- a contentious RFS when the last ROE is the only ROE with a contentious RFS in the QP, the client is otherwise available for work and qualifies for sickness benefits;

- a contentious reason for separation (RFS) before a disqualifying event that results in an indefinite disqualification when the client is otherwise available for work and qualifies for sickness benefits;

- a leave of absence when:

- the leave is not the RFS on the last ROE;

- the client started new employment while on a leave of absence from the previous employment;

- the client stopped working for the new employer for medical reasons;

- the RFS on the last ROE is D - illness or Injury ;

- if not for the illness, the client would have been working for the new employer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3041.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3042.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3043.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3037.dita) 

### Claim action status and processing the claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/claim_action_status_and_processing_the_claim.dita`

During processing, an initial claim displays one of the following claim action statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

- Finalized - Pending LREM

When the Claim action status shows In Progress , all ADJ WIs must be completed before the system can calculate the initial claim. However, in some cases, when the system automates a claim, the adjudication is automatically deferred as well. 

### Deferring adjudication on an automated BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_an_automated__817fd17b.dita`

Claims are automated BPNE 2 and the claim action status changes to Finalized - Pending LREM when the last ROE is not received at the end of the initial wait process (day 27). The officer moves all ADJ WIs to Pending when the status shows Finalized - Pending LREM . If the last ROE is still missing at the end of the extended initial wait process (day 46), adjudication of any issue is deferred by the system when it sets the claim status to Finalized . A record of decision (ROD) is created automatically. The Last record of employment missing option on the Resolve Issue screen must never be used while the claim is still in automation. 

### Deferring adjudication on a manual BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_a_manual_bpne_2_claim.dita`

When the claim action status is In Progress (Manual) and the last ROE is missing at day 27, the officer with the Claim Assessment (CA) WI can only finalize the claim BPNE 2 after all ADJ WIs are completed. The officer with the ADJ WI can defer adjudication of any issue so the officer with the CA WI can complete it. 

### Deferring adjudication on an automated BPNE 1 claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_an_automated__bbd0b525.dita`

Claims are automated BPNE 1 when clients did not accumulate enough insurable hours to establish a claim. The system defers adjudication on any issue when a claim has been automated BPNE 1. A ROD is created automatically. 

### Deferring adjudication on a manual BPNE 1 or 5 claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_a_manual_bpne_fbae7619.dita`

Any adjudication is deferred when a claim will be manually finalized as BPNE 1 or 5. The officer manually finalizes the claim when all of the required information is on file, or when the CA WI has reached the due date. 

### Deferring adjudication on an obvious BPNE claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_an_obvious_bpne_claim.dita`

When reviewing a claim, it may be obvious that clients did not accumulate enough insurable hours to establish a claim for sickness benefits. This occurs when clients have accumulated less than 420 insurable hours in the QP and all ROEs included in the QP are on file. As there is no potential for recalculation, adjudication of any issue is deferred. 

### Deferring adjudication on the last ROE

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_the_last_roe.dita`

A minimum of 600 insurable hours in the QP are required to qualify for sickness benefits. Clients with at least 600 insurable hours in the QP are considered major attached. Some major attached clients may qualify for sickness benefits but would be BPNE for regular benefits. In these cases, the claim is established and an administrative disentitlement is imposed accordingly to prevent payment of regular benefits and allow payment of sickness benefits.

If the last ROE is the only ROE with a contentious RFS in the QP and the client is otherwise available for work, adjudication of a contentious RFS can be deferred when clients qualify for sickness benefits. For all contentious RFS (including leave of absence), there must be no indication that the client is not otherwise available for work (e.g. retirement indicated on the ROE or training course declared). Since clients must prove that they are otherwise available for work to receive sickness benefits, adjudication cannot be deferred if the RFS implies that the client is not otherwise available for work.
       [otherwise available](/en/procedure/activity/availability.shtml)

Fact-finding and adjudication of a contentious RFS can be deferred even if a 16 - No medical certificate submitted - initial or additional proof required disentitlement (D16) is imposed.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1305.dita) 

### Deferring adjudication before a disqualifying event

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_before_a_disqual_7216ebc7.dita`

When there is one or more voluntary leaving or dismissal in the QP, any one of these events can prevent payment of regular benefits in the benefit period (BP). The disqualification is suspended to allow payment of sickness benefits. Adjudication is deferred on any contentious RFS before a disqualifying event that results in an indefinite disqualification 10 - Dismissal - misconduct proven (D10) or 11 - Voluntary leaving - Just cause not proven (D11).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3040.dita) 

To determine a disqualifying event, the officer must first consider the most recent event of voluntary leaving or dismissal in the QP. The most recent event is not always equal to the last employment and can fall anywhere in the QP. If the officer determines that there is no disqualification for that event, fact-finding and adjudication are completed for the preceding voluntary leaving or dismissal in the QP. The officer continues to work in reverse chronological order until:

- an indefinite disqualification is imposed;

- the beginning of the QP is reached; or

- no event results in an indefinite disqualification.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3044.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3045.dita) 

### Deferring adjudication on a labour dispute

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_a_labour_dispute.dita`

When the RFS is B, the officer can defer a decision on an initial claim for sickness benefits if the claim is or will be finalized BPNE and no benefits will be paid. When the claim can be established, deferral is impossible. 

### Deferring adjudication on a leave of absence

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_a_leave_of_absence.dita`

The decision on a leave of absence can be deferred on an initial or renewal claim for sickness benefits when all of the following conditions are met:

- the leave of absence is not the RFS on the last ROE; and

- the client started new employment while on a leave of absence from the previous employment; and

- the client has stopped working for the new employer for medical reasons; and

- the RFS on the last ROE is D - Illness or Injury ; and

- if not for the illness, the client would have been working for their new employer.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3046.dita) 

### Record of decision (ROD) — Creation

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/record_of_decision_rod__creation.dita`

When adjudication is being deferred on issues that do not display a Resolve Issue tab on the ADJ WI, the officer is responsible for creating a ROD for the issue that is being deferred. If a Resolve Issue tab is displayed on the ADJ WI, the officer is responsible for completing all screens. Once the screens are completed, the system creates a ROD automatically. 

### Special condition field in RCM

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/special_condition_field_in_rcm.dita`

There is no Resolve Issue tab on the ADJ WI for leave of absence and strike or lockout (labour dispute) issues. Therefore, when adjudication is deferred, the officer selects Adjudication deferred in the Special condition field of the appropriate ROE in RCM. For all other RFS issues with a Resolve Issue tab on the ADJ WI, the system updates the Special condition field. 

### Deferring adjudication when the ROE is not on file

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_when_the_roe_is__0f07e548.dita`

When all conditions to defer are met, adjudication on a contentious RFS can be deferred even if the ROE is not on file. When the ROE is received the system attempts to locate an electronic decision to update the Special condition field. If it cannot locate one, an ROE RFS WI is created. 

### Communicating the decision

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/communicating_the_decision.dita`

There is no requirement to notify the client of a deferral. 

### Note

Source topic: `en_EN/common_notes/note_c_3041.dita`

Note:

The officer considers whether the client is otherwise available from the last employment, not the period of employment from which the client took the leave of absence. 

### Note

Source topic: `en_EN/common_notes/note_c_3042.dita`

Note:

A transitional measure was implemented on September 27, 2020 for claims with a BPC between w/c 2258 and w/c 2309. Due to this transitional measure, the officer allows any contentious RFS that occurs more than 12 weeks before the client’s most recent I of E. To calculate the 12-week period, the officer subtracts 12 weeks from the week of the most recent I of E. If there are no other contentious issues in the 12-week period before the client’s most recent I of E, the officer can defer adjudication on the most recent RFS. The officer considers any contentious RFS issues that occurred before the 12-week period as non-contentious. 

### Note

Source topic: `en_EN/common_notes/note_c_3043.dita`

Note:

On an initial claim for sickness benefits, with a BPC between w/c 2310 and w/c 2361, the officer can defer adjudication of the RFS for the last period of employment in the QP, when the client is otherwise available and qualifies for sickness benefits, even when there are contentious RFSs on other ROEs in the QP. The officer continues to follow all other deferral conditions noted above, except those for specific BPC ranges. This measure does not apply to claims for self-employment (SE) or fishing benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Note

Source topic: `en_EN/common_notes/note_c_3037.dita`

Note:

The adjudication of an antedate request can never be deferred. Antedate requests must be adjudicated even if the claim results in a BPNE 1 or 5. 

### Note

Source topic: `en_EN/common_notes/note_c_1305.dita`

Note:

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure. 

### Note

Source topic: `en_EN/common_notes/note_c_3040.dita`

Note:

On claims with a BPC between w/c 2310 and w/c 2361, adjudication is only required on the last RFS. Therefore, adjudication deferral before a disqualifying event no longer applies. This measure does not apply on claims for SE or fishing benefits.

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Example 1

Source topic: `en_EN/common_notes/note_c_3044.dita`

Example 1:

```text
| Cut-off date | 700 hours | 500 hours | 300 hours | BPC |

| | ROE 3 - RFS | ROE 2 - RFS | ROE 1 - RFS | |

| | Layoff | Voluntary leaving | Misconduct proven | |
```

- The last employment or most recent disqualifying event is ROE 1. Since misconduct was proven, a disqualification will result. Because a D10 disqualification is being imposed for ROE 1, the adjudication of the RFS on ROE 2 can be deferred. All the hours in the QP are used to calculate the claim. 

### Example 2

Source topic: `en_EN/common_notes/note_c_3045.dita`

Example 2:

```text
| Cut-off date | 700 hours | 300 hours | 600 hours | BPC |

| | ROE 3 - RFS | ROE - 2 RFS | ROE 1 - RFS | |

| | Dismissal | Voluntary Leaving — No just cause | Layoff | |

| | VER = 595 | | | |
```

- The last employment or most recent disqualifying event is ROE 2. The client has worked enough insurable hours after the voluntary leaving for a claim to be established solely based on the hours of ROE 1. Because the client has sufficient insurable hours since the disqualifying event, a D11 disqualification is not imposed. The 300 hours from ROE 2 are excluded from calculation. The RFS on ROE 3 cannot be deferred. The RFS on ROE 3 must be adjudicated to determine whether that ROE is used in the calculation. 

### Example

Source topic: `en_EN/common_notes/note_c_3046.dita`

Example:

ROE 1

Costco — first day worked: December 5, 2021.Last day worked (LDW): June 12, 2022. RFS: N - Leave of absence.

ROE 2

General Motors — first day worked: August 1, 2022. LDW: September 15, 2022. RFS: D - Illness or Injury.

- The client takes a leave of absence from his employment with Costco on June 12, 2022. While on leave, the client begins work for a new employer, General Motors, on August 1, 2022.

- The client becomes ill and stops working for General Motors. The ROE indicates the RFS is D - Illness or Injury and the LDW is September 15, 2022.

- The client is requesting sickness benefits from the date that he stopped working for General Motors (September 15, 2022). The client meets the entitlement requirements for sickness benefits and so the client’s leave of absence from Costco can be deferred.The officer manually imposes an indefinite 43 - Leave from employment without just cause disentitlement (D43) from the date the leave began (June 12, 2022). This prevents the payment of regular benefits from the BPC or date of renewal. 

## Regional considerations

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/in_fts.dita`

- Has the claim been automated BPNE 2? 

### In NWS:

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/in_nws.dita`

- What is the Claim action status?

- Is there more than one employer in the QP?

- Are there any SROCs, WIs, RODs or any other information indicating the client is not otherwise available? 

### In RCM:

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/in_rcm.dita`

- Is there more than one ROE in the QP?

- If yes, is there more than one ROE with a contentious RFS on file?

- Are all ROEs in the QP on file?

- What is the total number of insurable hours in the QP? 

## Step by step

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/reviewing_the_file_level_1.dita`

- In RCM, determine if the last ROE is missing:

- If yes, go to step 2.

- If no, go to step 5.

- In NWS, determine if the claim status is Finalized - Pending LREM:

- If yes, go to step Deferring adjudication on an automated BPNE 2 claim .
               [Deferring adjudication on an automated BPNE 2 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#L1AutomatedN2)

- If no, go to step 3.

- Determine if the claim action status is In Progress (Manual):

- If yes, go to step 4.

- If no, go to step 5.

- Determine if more than 26 days have passed since the date the application was filed:

- If yes, go to Deferring adjudication on a manual BPNE claim .
               [Deferring adjudication on a manual BPNE claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#L1ManualN2)

- If no, go to step 5.

- Determine if the claim will be manually finalized BPNE 1 or 5:

- If no, go to step 6.

- If yes, go to Deferring adjudication on a manual BPNE 1 or 5 claim .
               [Deferring adjudication on a manual BPNE 1 or 5 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#DefADJManualBPNE5)

- In RCM, determine the total number of insurable hours for all ROEs in the QP, including any interim ROEs and Request for Record of Employment (INS3166) forms on file:

- If the total number of hours is less than 420, go to step 7.

- If the total number of hours is 420 or more go to Deferring adjudication in any other situation .
               [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#defer_any_other)

- Determine if the ROEs, interim ROEs or Request for Record of Employment (INS3166) forms are on file for all employers listed on the application for benefits:

- If all ROEs, interim ROE and INS3166 forms are on file, go to Deferring adjudication on an obvious BPNE claim .
               [Deferring adjudication on an obvious BPNE claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#ObviousLevel1)

- If all ROEs, interim ROE and INS3166 forms are not on file, and the issue is not a contentious RFS, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- If all ROEs, interim ROE and INS3166 forms are not on file and the issue is a contentious RFS, go to Deferring adjudication in any other situation .
               [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#defer_any_other) 

#### Deferring adjudication on an automated BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_an_automated__817fd17b_level_1.dita`

- Determine if the client clearly indicates that the missing ROE will not be provided and no interim ROE can be created.

- If the client did not clearly indicate that the missing ROE will not be provided and an interim ROE can be created, go to step 4.

- If the client clearly indicates that the missing ROE will not be provided and no interim ROE can be created, go to step 6.

- In NWS, move the WI for the issue being deferred to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting last ROE.”

- Bring forward date: Enter the date of application + 45 days.

- When the WI moves to the current workload, determine if the last ROE, including any interim ROE or Request for Record of Employment (INS3166) form for the last ROE is on file:

- If no and the bring forward date has not been reached, repeat step 4.

- If no and the bring forward date has been reached, go to step 6.

- If yes, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI.

- If yes, go to step 7.

- If no, go to step 9.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 10.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of the record of employment (if the issue is a contentious RFS] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on a manual BPNE 1 or 5 claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_a_manual_bpne_fbae7619_level_1.dita`

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI:

- If yes, go to step 7.

- If no, go to step 9.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Obviously BPNE .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 12.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — manual BPNE

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim will be manually finalized as BPNE.”

- Select Save .

- Determine if adjudication is being deferred for a leave of absence or a strike or lockout issue:

- If yes, go to step 11.

- If no, go to step 12.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- In NWS, complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on a manual BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_a_manual_bpne_2_claim_level_1.dita`

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI.

- If yes, go to step 6.

- If no, go to step 8.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 9.

- For the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or ROE serial number (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on an obvious BPNE claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_an_obvious_bpne_claim_level_1.dita`

- In NWS, determine if you have a Resolve Issue tab for the ADJ WI:

- If yes, go to step 8.

- If no, go to step 10.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Obviously BPNE .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 15.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — obvious BPNE

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), LDW for the employer or ROE serial number (if the issue is a contentious RFS)] is deferred because the claim is obviously BPNE.

- Select Save .

- Determine if adjudication is being deferred for a leave of absence or a strike or lockout issue:

- If yes, go to step 12.

- If no , go to step 15.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If the validation causes an ROE error, go to step 14.

- If the validation does not cause an ROE error, go to step 15.

- In NWS, determine if there is an ROE Correction WI or CA WI for this ROE:

- If yes, go to step 15.

- If no, create an ROE Correction WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the SCC as shown in FTS.

- End user: Select Myself .

- Serial number: Enter the serial number of the ROE.

- Issue: Select Correction .

- In NWS, complete the ADJ WIs for the adjudication issues being deferred. 

#### Deferring adjudication in any other situation

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_in_any_other_situation_level_1.dita`

- Determine if the facts (including those regarding the RFS) reveal that the client is otherwise available for work:

- If the facts reveal that the client would have been employed or entitled to regular benefits had the client not been sick or injured, go to step 2.

- If the facts do not reveal that the client would have been employed or entitled to regular benefits had the client not been sick or injured, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- In FTS, determine the BPC:

- If the BPC is between w/c 2258 and w/c 2309, go to step 3.

- If the BPC is between w/c 2310 and w/c 2361, go to step 10.

- If the BPC is not in either of these periods, go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3047.dita)

- Determine if the RFS is for a leave of absence:

- If yes, go to step 4.

- If no, go to step 5.

- Determine if all conditions are met to defer the leave of absence at Level 1:

- leave of absence is not the RFS on the last ROE; and

- the client started new employment while on a leave of absence from the previous employment; and

- the client has stopped working for the new employer for medical reasons; and

- the RFS on the client’s last ROE is D - Illness or Injury ; and

- if not for the illness, the client would have been working for the new employer.

- If all conditions are met, go to step 13.

- If all conditions are not met, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the RFS is B - Strike or lockout :

- If no, go to step 6.

- If yes, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious issue.

- Determine if the last ROE is the only ROE with a contentious RFS in the QP:

- If no, go to step 7.

- If yes, go to step 10.

- Determine if the last contentious RFS has been adjudicated:

- If yes, go to step 8.

- If no, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the adjudication of any contentious RFS in the QP resulted in an indefinite disqualification (D10 or D11):

- If yes, go to step 9.

- If no , deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the RFS that must be adjudicated occurred before the event that resulted in a D10 or D11:

- If yes, go to step10.

- If no , deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI of the RFS.

- If yes, go to step 11.

- If no, go to step 13.

- On the Resolve Issue tab of the ADJ WI of the RFS, complete the screen as follows:

- Select The adjudication has been deferred because the client meets the qualifying conditions for special benefits and the conditions to defer have been met .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 18.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows. Select the most appropriate option:

- Comments: Enter the following information:

- contentious issue

- name of the employer

- last day worked for the employer

- deferred adjudication — sickness benefits

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or ROE serial number] is deferred. It is the last ROE and the only one with a contentious reason for separation in the QP. The client qualifies for sickness benefits and is otherwise available for work.” or

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or ROE serial number] is deferred because it occurred before a disqualifying event. The client qualifies for sickness benefits and is otherwise available for work.” or

- Details: Type “Adjudication of leave of absence from (full name of the employer, last day worked for the employer and ROE serial number) is deferred because the client has worked since the leave of absence and has stopped working due to illness. The RFS on the ROE is D - Illness or injury and the client is otherwise available.”

- Select Save .

- In RCM, determine if the ROE is on file:

- If yes, go to step 15.

- If no, go to step 18.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If yes, go to step 17.

- If no, go to step 18.

- In NWS, determine if there is an ROE Issue (ROE) Correction WI or CA WI for this ROE:

- If yes, go to step 18.

- If no, create an ROE Correction WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End user: Select Myself .

- Serial number: Enter the serial number of the ROE.

- Issue: Select Correction .

- Complete the ADJ WI of the RFS for the adjudication issue being deferred. 

#### Note

Source topic: `en_EN/common_notes/note_c_3047.dita`

Note:

On claims with a BPC between w/c 2258 and w/c 2309, calculate the 12-week period before the client’s most recent I of E. When answering question 6, consider any contentious RFS issues that occurred before the 12-week period as not being in the QP.

On claims with a BPC between w/c 2310 and w/c 2361, adjudication is only required on the last RFS. Even if there are other contentious ROEs in the QP, the officer can defer adjudication on the client’s most recent I of E. Therefore, adjudication deferral before a disqualifying event no longer applies. This measure does not apply on claims for SE or fishing benefits.

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Level 2

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/reviewing_the_file_level_2.dita`

- In RCM, determine if the last ROE is missing:

- If yes, go to step 2.

- If no, go to step 5.

- In NWS, determine if the claim status is Finalized - Pending LREM:

- If no , go to step 3.

- If yes, go to Deferring adjudication on an automated BPNE 2 claim .
               [Deferring adjudication on an automated BPNE 2 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#L2AutomatedN2)

- Determine if the claim action status is In Progress (Manual) :

- If yes, go to step 4.

- If no, go to step 5.

- Determine if more than 26 days have passed since the date the application was filed:

- If no, go to step 5.

- If yes, go to Deferring adjudication on a manual BPNE 2 claim .
               [Deferring adjudication on a manual BPNE 2 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#L2ManualN2)

- Determine if the claim will be manually finalized as BPNE 1 or 5:

- If no, go to step 6.

- If yes, go to Deferring adjudication on a manual BPNE 1 or 5 claim .
               [Deferring adjudication on a manual BPNE 1 or 5 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#DefADJManualBPNE5_2)

- In RCM, determine the total number of insurable hours for all ROEs in the QP, including any interim ROEs and Request for Record of Employment (INS3166) forms on file:

- If the total number of hours is less than 420, go to step 7.

- If the total number of hours is 420 or more, go to Deferring adjudication in another situation .
               [Deferring adjudication in another situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#defer_any_other_level2)

- Determine if the ROEs, any interim ROE or Request for Record of Employment (INS3166) forms are on file for all employers listed on the application for benefits:

- If all ROEs, interim ROE and INS3166 forms are on file, go to Deferring adjudication on an obvious BPNE claim .
               [Deferring adjudication on an obvious BPNE claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#ObviousLevel2)

- If all ROEs, interim ROE and INS3166 forms are not on file, and the issue is not a contentious RFS, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- If all ROEs, interim ROE and INS3166 forms are not on file and the issue is a contentious RFS, go to Deferring adjudication in another situation .
               [Deferring adjudication in another situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_sickness_ben#defer_any_other_level2) 

#### Deferring adjudication on an automated BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_an_automated__817fd17b_level_2.dita`

- Determine if the client clearly indicates that the missing ROE will not be provided and no interim ROE can be created.

- If the client did not clearly indicate that the missing ROE will not be provided and an interim ROE can be created, go to step 4.

- If the client clearly indicates that the missing ROE will not be provided and no interim ROE can be created, go to step 6.

- In NWS, move the WI for the issue being deferred to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting last ROE.”

- Bring forward date: Enter the date of application + 45 days.

- When the WI moves to the current workload, determine if the last ROE, including any interim ROE or Request for Record of Employment (INS3166) form for the last ROE is on file:

- If no and the bring forward date has not been reached, repeat step 4.

- If no and the bring forward date has been reached, go to step 6.

- If yes, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI.

- If yes, go to step 7.

- If no, go to step 9.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 10.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), LDW for the employer or ROE serial number (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WIs for the adjudication issues being deferred. 

#### Deferring adjudication on a manual BPNE 1 or 5 claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_a_manual_bpne_fbae7619_level_2.dita`

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI:

- If yes, go to step 7.

- If no, go to step 9.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Obviously BPNE .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 12.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — manual BPNE

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), LDW for the employer or ROE serial number (if the issue is a contentious RFS)] is deferred because the claim will be manually finalized as BPNE.”

- Select Save .

- Determine if adjudication is being deferred for a leave of absence or a strike or lockout issue:

- If yes, go to step 11.

- If no , go to step 12.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- In NWS, complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on a manual BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_a_manual_bpne_2_claim_level_2.dita`

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI.

- If yes, go to step 6.

- If no, go to step 8.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 9.

- For the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), LDW for the employer or ROE serial number (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on an obvious BPNE claim

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_on_an_obvious_bpne_claim_level_2.dita`

- In NWS, determine if you have a Resolve Issue tab for the ADJ WI:

- If yes, go to step 8.

- If no, go to step 10.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Obviously BPNE .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 15.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — obvious BPNE

- Details: Type “Adjudication of [contentious issue, full name of the employer, LDW for the employer or ROE serial number (if the issue is a contentious RFS)] is deferred because the claim is obviously BPNE. Less than 600 insurable hours on file.”

- Select Save .

- Determine if adjudication is being deferred for a leave of absence or a strike or lockout issue:

- If yes, go to step 12.

- If no , go to step 15.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If the validation causes an ROE error, go to step 14.

- If the validation does not cause an ROE error, go to step 15.

- In NWS, determine if there is an ROE Correction WI or CA WI for this ROE:

- If there is an ROE Correction or CA WI, go to step 15.

- If there is no ROE Correction or CA WI, create an ROE Correction WI as follows:

- Complexity: Select Non Complex .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the SCC as shown in FTS.

- End user: Select Next available user .

- Serial number: Enter the serial number of the ROE.

- Issue: Select Correction .

- In NWS, complete the ADJ WI for the adjudication issues being deferred. 

#### Deferring adjudication in any other situation

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/deferring_adjudication_in_any_other_situation_level_2.dita`

- Determine if the facts (including those regarding the RFS) reveal that the client is otherwise available for work according to EIA 18(1)(b) and Digest 11.3.0 — Second entitlement condition: to be otherwise available for work :

- If yes, go to step 2.

- If no, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- In FTS, determine the BPC:

- If the BPC is between w/c 2258 and w/c 2309, go to step 3.

- If the BPC is between w/c 2310 and w/c 2361, go to step 10.

- If the BPC is not in either of these periods, go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3047.dita)

- Determine if the deferral is for a leave of absence:

- If yes, go to step 4.

- If no, go to step 5.

- Determine if all conditions are met to defer the leave of absence at Level 1:

- leave of absence is not the RFS on the last ROE; and

- the client started new employment while on a leave of absence from the previous employment; and

- the client has stopped working for the new employer for medical reasons; and

- the RFS on the client’s last ROE is D - Illness or Injury ; and

- if not for the illness, the client would have been working for the new employer.

- If all conditions are met, go to step 13.

- If all conditions are not met, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the RFS is B - Strike or lockout :

- If no, go to step 6.

- If yes, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious issue.

- Determine if the last ROE is the only ROE with a contentious RFS in the QP:

- If no , go to step 7.

- If yes, go to step 10.

- Determine if the last contentious RFS has been adjudicated:

- If yes, go to step 8.

- If no, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the adjudication of any contentious RFS in the QP resulted in an indefinite disqualification (D10 or D11):

- If yes, go to step 9.

- If no , deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the RFS that must be adjudicated occurred before the event that resulted in a D10 or D11:

- If yes, go to step 10.

- If no , deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI of the RFS.

- If yes, go to step 11.

- If no, go to step 13.

- On the Resolve Issue tab of the ADJ WI of the RFS, complete the screen as follows:

- Select The adjudication has been deferred because the client meets the qualifying conditions for special benefits and has not requested regular benefits at this time .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 18.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows. Select the most appropriate option:

- Comments: Enter the following information:

- contentious issue

- name of the employer

- last day worked for the employer

- deferred adjudication — sickness benefits

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of the record of employment] is deferred. It is the last record of employment and the only one with a contentious reason for separation in the QP. The client qualifies for sickness benefits and is otherwise available for work.” or

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of record of employment] is deferred because it occurred before a disqualifying event. The client qualifies for sickness benefits and is otherwise available for work.” or

- Details: Type “Adjudication of leave of absence from (full name of the employer, last day worked for the employer and ROE serial number) is deferred because the client has worked since the leave of absence and has stopped working due to illness. The RFS on the ROE is D - Illness or injury and the client is otherwise available.”

- Select Save .

- In RCM, determine if the ROE is on file:

- If the ROE is on file, go to step 15.

- If the ROE is not on file, go to step 18.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If the validation causes an ROE error, go to step 17.

- If the validation does not cause an ROE error, go to step 18.

- In NWS, determine if there is an ROE Correction WI or CA WI for this ROE:

- If there is an ROE Correction or CA WI, go to step 18.

- If there is no ROE Correction or CA WI, create an ROE Correction WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the SCC as shown in FTS.

- End user: Select Myself .

- Serial number: Enter the serial number of the ROE.

- Issue: Select Correction .

- Complete the ADJ WI of the RFS for the adjudication issue being deferred. 

## Policy reference

Source topic: `en_EN/task/defer_adj_initial_sickness_ben/policy_reference.dita`

- Digest 11.3.0 — Second entitlement condition: to be otherwise available for work
         [Digest 11.3.0 — Second entitlement condition: to be otherwise available for work](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-11/otherwise-available-for-work.html#a11.3.0)

- EIA 18(1)(b)
         [EIA 18(1)(b)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html) 
