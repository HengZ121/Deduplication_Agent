# Determining if proof of entitlement to maternity benefits is required

Source map: `en_EN/task/determining_pembr/determining_pembr.ditamap`

## Summary

Source topic: `en_EN/task/determining_pembr/summary.dita`

Summary: When calculating a claim for a client who is pregnant, has recently given birth or is applying for maternity benefits, the officer must determine if proof is required to receive maternity benefits. 

## What you need to know

Source topic: `en_EN/task/determining_pembr/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/determining_pembr/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Proof of pregnancy

Source topic: `en_EN/task/determining_pembr/proof_of_pregnancy.dita`

Maternity benefits are payable to a person who is pregnant or has recently given birth and who is unable to work as a result. In order to receive maternity benefits, the client must provide proof of pregnancy. The proof is used to ensure the client is entitled to maternity benefits and is requesting the benefits within the maternity window.

Proof of pregnancy is a signed statement on which the client declares she is pregnant or has recently given birth. The statement must include her expected due date or the actual date she gave birth. If the client is pregnant when she applies, she must provide the actual date of birth (DOB) as soon as possible after the birth.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3210.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0027.dita) 

### Failure to provide proof

Source topic: `en_EN/task/determining_pembr/failure_to_provide_proof.dita`

If proof is not provided, the officer must send the INS5168 form to the client.
       [INS5168](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5168.pdf)

If a client does not provide proof of pregnancy, the officer must indicate that the maternity proof is due in the Outstanding information field of the Registration screen in SSO. The Maternity proof field of the Annex - Special Benefits screen in SSO will automatically prefill with No and when the claim is calculated, SSO will impose an indefinite 15 - Claim Procedure disentitlement (D15) from the BPC. If the client is applying for maternity benefits as the initial benefit type (BT), the officer must also change the BT to regular benefits when establishing the claim. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_3210.dita`

Note:

The attestation at the end of an AW application or a completed Maternity and/or Parental Benefits - Annex 3 (INS5168) form is accepted as a signed statement.
       [Maternity and/or Parental Benefits - Annex 3 (INS5168)](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5168.pdf)

     [Maternity and/or Parental Benefits - Annex 3 (INS5168)](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5168.pdf) 

### Note

Source topic: `en_EN/common_notes/note_c_0027.dita`

Note:

If the reason for separation (RFS) on the last ROE is P - Parental and maternity benefits were requested, additional fact-finding is required. The officer contacts the employer first to ensure the RFS on the ROE is correct. If so, the officer then contacts the client to ensure the requested benefit type (BT) is correct. If the client has applied for the wrong BT, the officer refers to Determining during calculation if the client applied for the wrong benefit type .
       [Determining during calculation if the client applied for the wrong benefit type](/en/procedure/task/calc_determining/wrong_bt_requested.shtml)

     [Determining during calculation if the client applied for the wrong benefit type](/en/procedure/task/calc_determining/wrong_bt_requested.shtml) 

## Regional considerations

Source topic: `en_EN/task/determining_pembr/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/determining_pembr/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/determining_pembr/in_nws.dita`

- Is there information that states that the client is pregnant or has given birth in the last 17 weeks?

- If yes, has the client provided her expected due date or the actual date she gave birth? 

### In Imaging:

Source topic: `en_EN/task/determining_pembr/in_imaging.dita`

- Is there information that states that the client is pregnant or has given birth in the last 17 weeks?

- If yes, has the client provided her expected due date or the actual date she gave birth? 

## Step by step

Source topic: `en_EN/task/determining_pembr/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/determining_pembr/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/determining_pembr/reviewing_the_file_level_1.dita`

- Determine if the client has provided a signed statement attesting to her pregnancy (the attestation at the end of the AW application is acceptable):

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client’s signed statement includes the expected due date or actual date she gave birth:

- If no, go to step 3.

- If yes, go to Proof provided .
               [Proof provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_pembr#_Proof_provided)

- In NWS, determine if fact-finding for proof of pregnancy has already occurred:

- If no, go to Fact-finding .
               [Fact-finding](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_pembr#_Fact-finding_required)

- If yes, go to Proof not provided .
               [Proof not provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_pembr#_Proof_not_provided) 

#### Proof not provided

Source topic: `en_EN/task/determining_pembr/proof_not_provided_level_1.dita`

- In NWS, create a record of decision as follows:

- Comments: Type “failure to provide proof of pregnancy.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Details: Type one of the following:

- If maternity benefits are not the initial BT (e.g. sickness before maternity), type “15 - Claim Procedure disentitlement is imposed from the benefit period commencement. The client has not provided proof of her pregnancy.”

- If maternity benefits are the initial BT, type “benefit type changed to regular benefits and a 15 - Claim Procedure disentitlement is imposed from the benefit period commencement. The client has not provided proof of her pregnancy.”

- On the calculation worksheet, note that when reviewing the Registration screen in SSO, the officer must indicate the Maternity proof is due.

- If maternity benefits are the initial BT, go to step 3.

- If maternity benefits are not the initial BT, go to step 5.

- In NWS, on the Specific Details tab of the Claim Assessment WI or the Specialized Application WI, change the BT as follows:

- Benefit Type: Select Regular benefits .

- Click Save .

- Refer to Calculating a claim for regular benefits .

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 11 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 11 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 11 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is CCB, refer to step 11 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver benefits (FCB), refer to step 11 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Proof provided

Source topic: `en_EN/task/determining_pembr/proof_provided_level_1.dita`

- On the calculation worksheet, note the expected DOB and actual DOB provided. If these dates are not the same as the ones provided on the application, also note that the expected DOB and actual DOB must be added or modified in SSO before calculating the claim.

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 11 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 11 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 11 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is CCB, refer to step 11 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is FCB, refer to step 11 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Fact-finding required

Source topic: `en_EN/task/determining_pembr/fact-finding_required_level_1.dita`

- On the calculation worksheet, note that fact-finding with the client is required to obtain the signed attestation:

- If the client is reached, explain to the client that proof must be provided and mail the client an INS5168 form with a pre-addressed return envelope.
               [INS5168](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Maternity_Parental-INS5168_Annex_3_transcript-Form.doc)

- If the client is not reached, send the client an INS5168 form with a pre-addressed return envelope.
               [INS5168](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Maternity_Parental-INS5168_Annex_3_transcript-Form.doc)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2237.dita)

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 11 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 11 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 11 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is CCB, refer to step 11 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is FCB, refer to step 11 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2237.dita`

Note:

Once fact-finding is complete, return to this task. 

## Policy reference

Source topic: `en_EN/task/determining_pembr/policy_reference.dita`

 
