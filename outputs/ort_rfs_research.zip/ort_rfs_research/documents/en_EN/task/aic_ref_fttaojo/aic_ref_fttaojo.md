# Adjudicating an Integrity case — Refusal of employment or failure to take advantage of a job opportunity

Source map: `en_EN/task/aic_ref_fttaojo/aic_ref_fttaojo.ditamap`

## Summary

Source topic: `en_EN/task/aic_ref_fttaojo/summary.dita`

Summary: An investigator reports the results of an investigation when it is found that a client has not declared a refusal of a formal offer of employment or a refusal to take advantage of a job opportunity while claiming EI benefits. 

## What you need to know

Source topic: `en_EN/task/aic_ref_fttaojo/what_you_need_to_know.dita`

### Processing an Integrity claim review

Source topic: `en_EN/task/aic_ref_fttaojo/processing_an_integrity_claim_review.dita`

Below are the main processing steps for this activity. If the officer determines that the client knowingly made a false or misleading statement, the officer must adjudicate the refusal of employment or the failure to take advantage of a job opportunity, complete the record of decision (ROD), and refer to Misrepresentation to determine the type of sanction to impose. The officer must input the complete decision after determining the sanction.
       [Misrepresentation](/en/procedure/activity/misrepresentation.shtml)

**Reconsidering a decision**

EIA 52 states that a claim for benefits may be reconsidered as long as it results in an overpayment (OP) or an underpayment (UP). The time limit for reconsidering a claim is 36 months from the week benefits were paid or payable. This period is extended to 72 months if there was a false or misleading statement.
       [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

**Determining if a false statement was made**

A false statement is a statement that is incorrect or untrue. A false statement can result from an intentional or negligent action or from an honest mistake.

For example, an employer contacts the call centre to report a client who refused employment, but the client did not report the refusal of employment while receiving benefits. An investigation reveals that the client actually refused employment.

At this point, the officer only knows that the information provided by the client is incorrect. Without an explanation from the client, it cannot be determined if the client intentionally or knowingly failed to provide the correct information. Regardless of whether it was intentional, or an honest mistake, the client did not declare a refusal of an official offer of employment; therefore, the reconsideration timeframe can be extended to 72 months.

**Determining if a false statement was knowingly made**

Knowingly means the officer can reasonably conclude that the client was aware either that the information was untrue when it was provided or that certain information was not reported. There is no element of intent in this consideration. It is not necessary to determine a degree of fault. The officer must only establish that the client likely understood the information provided and did not accurately portray the facts.

If the client received payments by paper cheque, each cheque cashed can be considered a misrepresentation under EIA 38(1)(e). If the client received payments by direct deposit, each direct deposit payment or any excess amount the client received and did not return can be considered a misrepresentation under EIA 38(1)(f).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1809.dita) 

**Reviewing a potential case of voluntary disclosure**

The National Policy on Voluntary Disclosure encourages clients, employers and third parties to come forward and voluntarily disclose misrepresentations. According to this policy, voluntary disclosure occurs when a person admits to having knowingly made a false statement.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

An investigator may recommend that the file be reconsidered in light of the voluntary disclosure policy.

There are 2 essential conditions for approving the voluntary disclosure:

- There is no investigation underway in relation to the voluntary disclosure when a client admits to making a false statement.

- The false statement would have resulted in punitive measures such as a penalty, a warning or prosecution had there been no voluntary disclosure.

According to the voluntary disclosure policy, there is no limit to the number of times that a client can voluntarily disclose misrepresentations. 

### Distinguishing a refusal of employment from a failure to take advantage of a job opportunity

Source topic: `en_EN/task/aic_ref_fttaojo/distinguishing_a_refusal_of_employment__2d97aa41.dita`

Refusing an offer of employment exists if there was an offer of suitable employment, and the offer was made by an employer for whom the client had never worked. Failure to take advantage of a job opportunity, however, exists when the facts show that a client knew there was a suitable job opportunity but did not make a reasonable effort to obtain that job. Unlike a case of refusal of employment, the opportunity to obtain a job must have been available to the client, even if there was not necessarily an offer of employment. 

### Role of the investigator

Source topic: `en_EN/task/aic_ref_fttaojo/role_of_the_investigator.dita`

The investigator must fact-find with the client to gather all the information about the refused employment or the failure to take advantage of a job opportunity. If necessary, the investigator contacts the potential employer to confirm or obtain more information about the employment (e.g. pay offered, nature and type of the employment, work schedule, conditions of employment, etc.). 

### Role of the Level 2 officer

Source topic: `en_EN/task/aic_ref_fttaojo/role_of_the_level_2_officer.dita`

The Level 2 officer is assigned and responsible for processing the Claim Review (CR) Integrity WI. The officer must consult NIIS for each case to find all the relevant information to adjudicate the issue. This includes information such as the statements of the client, the employer or a third party, and the Report of Investigation.

- In the case of a refusal of employment, the officer must determine if the refused employment was suitable, and if it was, the officer must determine if the client had good cause for refusing the employment. The officer must render a decision based on the facts on file and the results of the investigator’s fact-finding.

- When there is a failure to take advantage of a job opportunity, the officer must determine if the employment was suitable and if there is good cause for failing to take advantage of the job opportunity. 

### Returning a file to Integrity

Source topic: `en_EN/task/aic_ref_fttaojo/returning_a_file_to_integrity.dita`

After conducting a full review of the investigation, if the Level 2 officer determines that facts are missing, the officer must return the file to the investigator for further fact-finding and indicate the missing information that is necessary to adjudicate the issue. The Level 2 officer must not adjudicate the issue if facts are missing or incomplete.

Facts are not considered missing or incomplete if the investigator has followed up with the client when the client fails to report for an interview or fails to reply to a request for information. The investigator is not required to send a follow-up letter but must make 2 attempts on 2 different days to contact the client by telephone. If the investigator leaves a message on a voicemail, only one attempt is required and they must allow 48 hours for the client to respond.

If the investigator recommends that the Integrity case be considered as voluntary disclosure, but the investigation type is not 70 in NIIS, the officer returns the file to Integrity.

The Integrity Services Branch does not verify the employer’s or third party’s version against the client’s version in the following situations:

- The investigation results in an actual or potential OP of less than the Integrity investigative threshold.

- There is no other active investigation.

In these situations, the officer does not return the case to Integrity because the employer’s or the third party’s version is missing. The officer is not required to validate the threshold. 

### Communicating with the employer

Source topic: `en_EN/task/aic_ref_fttaojo/communicating_with_the_employer.dita`

The employer must be notified of the decision in writing when a client has good cause for refusing employment. (For example, the client refused the employment because the working conditions offered are different from those anticipated during the job interview.) When the cause for refusal is personal, the employer is not informed of the decision. 

### Defining claim status (CS)

Source topic: `en_EN/task/aic_ref_fttaojo/defining_claim_status_cs.dita`

A claim can be active, terminated, blocked or archived. The claim status impacts which transactions can be input and when the letter of decision is sent:

- Active: The active claim is established and is currently displayed automatically in FTS. It is a claim for which benefits are still payable and that has not been terminated.

- Terminated: A terminated claim appears on the Dormant tab in FTS. It has ended but can be reactivated. Once the transaction to reactivate the claim has been processed, all inputs for the claim must be done the same as for an active claim.

- Blocked: In some cases, the claim that the officer must reconsider is on the Dormant tab in FTS, but there is a new active claim established and displayed on the Summary screen. The officer makes adjustments to this type of claim using BCS if the blocked CS shows 1 - Updateable . Otherwise, IPOC intervention is required.

- Archived: Claims that are more than 7 years old are moved from the Dormant tab to the Archived tab. The officer can view an archived claim by changing the status of the archived claim from 1 - Non-Viewable to 2 - Viewable in FTS. Once the officer requests to make the claim viewable, the status field immediately displays 2 - Viewable and the claim becomes viewable the next business day for 2 weeks. Adjustments to this type of claim are processed with IPOC intervention. 

### Determining the order of FTS inputs

Source topic: `en_EN/task/aic_ref_fttaojo/determining_the_order_of_fts_inputs.dita`

Controlled, multiple-day inputs in FTS are required to establish separate OPs for each decision (e.g. unreported earnings and reason for separation [RFS]). When there is more than one reconsideration decision that results in an OP, the decisions must be input in the following order:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1810.dita) 

Controlled inputs in FTS are also required for UP and OP situations. The officer processes the inputs resulting in the OP first. Once the OP is established, the officer inputs an agreed deduction equal to the benefit rate amount. For more information, the officer refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

### BCS

Source topic: `en_EN/task/aic_ref_fttaojo/bcs.dita`

BCS allows certain types of transactions to be processed on blocked dormant claims. There are 2 options available: Estimate and Claim update .

**Claim update function**

When transactions must be input on a blocked claim, the officer reviews the Blocked Claims System tab in FTS to determine the CS in BCS. If the CS is 1 - Updateable , the officer requests an update using BCS and processes the transactions.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1811.dita) 

An update in BCS can only be done on one BPC at a time. When transactions are input but not processed, Yes appears in the Block Action Pending column and access is denied for input on all other BPCs until the requested transactions are processed. Access to a BPC with a pending action is limited to the officer who initiated that action.

If the officer requests an update that BCS cannot complete, on the next processing day, the “Blocked claim not updated or not calculated” message is displayed along with the exceptions, errors or warnings on the MR05 screen.

Officers review the exceptions, errors or warnings on the Results tab in BCS to see if further action is necessary. If the update cannot be completed using BCS, the system presents an estimate result. The decision can be sent to IPOC using the Forward via MM06 link, which creates the prefilled M106 and MM06.

**Estimate function**

The Estimate function in BCS allows officers to view and evaluate the end results without processing the transactions. Estimates are possible for blocked claims with a CS 1 - Updateable as well as unblocked dormant claims, provided the CS is 05 (inactive) or 06 (terminated) .

BCS Estimate transactions are processed overnight and the results are available on the Results tab the next day. Officers that have requested an estimate can view the end result and forward the request for IPOC intervention using the prefilled MM06 available on the Results tab. 

### Creating an Operational Centre Memo (MM06) transaction for multiple issues

Source topic: `en_EN/task/aic_ref_fttaojo/creating_an_operational_centre_memo_mm0_12498087.dita`

When the MM06 includes multiple issues, if at least one issue is deemed to be a misrepresentation whereas at least another one is not, the officer ensures to include the appropriate OP message code for each issue in the Remarks section. 

### Record of decision (ROD)

Source topic: `en_EN/task/aic_ref_fttaojo/record_of_decision_rod.dita`

The Level 2 officer must record and document each decision in a separate ROD. 

### Note

Source topic: `en_EN/common_notes/note_c_1809.dita`

Note:

A false statement knowingly made does not always result in an OP of benefits. Although a monetary penalty is calculated based on the OP resulting from the misrepresentation, the officer can consider sending a warning letter if the client knowingly made a false statement but this misrepresentation did not result in an OP. 

### Callout

Source topic: `en_EN/common_notes/note_c_1810.dita`

**Determining the input order for multiple transactions**

- full disentitlement

- partial disentitlement

- unreported earnings or unreported allocation of earnings

- indefinite disqualification

- definite disqualification 

### Note

Source topic: `en_EN/common_notes/note_c_1811.dita`

Note:

At this time, BCS cannot process a benefit period (BP) extension, a recalculation of a claim, the removal of a manual action (MA) or the change in the full work week code for a week of special benefits. The officer must send an Operational Centre Memo (MM06) transaction asking IPOC to process these transactions. 

## Regional considerations

Source topic: `en_EN/task/aic_ref_fttaojo/regional_considerations.dita`

**Quebec — Returning the file to Integrity**

In addition to the information already indicated in this procedure, return the file to Integrity as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a c.c.

- In NWS, create a client Note and type “Measure — returned to Integrity” as well as the date (YYYY-MM-DD). 

## What you need to look for

Source topic: `en_EN/task/aic_ref_fttaojo/what_you_need_to_look_for.dita`

### In Imaging:

Source topic: `en_EN/task/aic_ref_fttaojo/in_imaging.dita`

- Are there any documents that are relevant to the case? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/aic_ref_fttaojo/in_integrity_investigations_document_up_6a8da64b.dita`

- Are there any documents that are relevant to the case? 

### In NWS:

Source topic: `en_EN/task/aic_ref_fttaojo/in_nws.dita`

- Review the application for benefits.

- Review SROCs, RODs, Action Item (AI) and Call Back (CB) WIs for information relevant to the case. 

### In FTS:

Source topic: `en_EN/task/aic_ref_fttaojo/in_fts.dita`

- If applicable, review the claimant’s report for the weeks under investigation.

- Is there an exemption from reporting?

- If yes, did the client receive payments by direct deposit?

- What is the CS (active, terminated, blocked or archived)?

- If the claim is blocked, what is the CS in BCS? 

### In NIIS:

Source topic: `en_EN/task/aic_ref_fttaojo/in_niis.dita`

- Review the IC04 Observation screen for a computer-generated investigation.

- Review the IC07 Subject Enquiry screen for all active and prior cases.

- Review the IC08 Case Summary screen to see the actions taken on the case.

- Review the IC50 Report of Clerical Investigation or IC70 Report of Investigation screen.

- Review the IC56 Case Notes screen to ensure you have the complete case.

- Is there an Integrity Investigation Sheet?

- Is there a Report of Interview? 

### In ACS:

Source topic: `en_EN/task/aic_ref_fttaojo/in_acs.dita`

- Was a request for clarification sent to the client by Integrity? 

## Step by step

Source topic: `en_EN/task/aic_ref_fttaojo/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/aic_ref_fttaojo/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/aic_ref_fttaojo/reviewing_the_file_level_2.dita`

- Determine if there is a false statement:

- If no, go to step 2.

- If yes, go to step 3.

- Determine if the request for reconsideration was made within the 36-month time limit:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe.
               [Not within reconsideration timeframe.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_ref_fttaojo#ntweconpd)

- Determine if the request for reconsideration is within the maximum reconsideration timeframe of 72 months:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_ref_fttaojo#ntweconpd)

- Determine if the information gathered by Integrity is complete:

- If the information is complete, go to step 5.

- If the information is incomplete, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_ref_fttaojo#volclosapp)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1667.dita)

- In NWS, create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction ):

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Adjudicate the refusal of employment, with the information provided by the client and the employer (if necessary, refer to Refusing an offer of employment or Failing to take advantage of a job opportunity or Digest 9 — Refusal of employment ) :

- If there is no good cause for the refusal or the failure to take advantage of a job opportunity, go to step 7.

- If there is good cause for the refusal or failure to take advantage of a job opportunity, go to Suitable employment — Good cause .
               [Suitable employment — Good cause](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_ref_fttaojo#emploconable)

- Determine if the client knowingly made a false or misleading statement as described in Digest 18.3.1.4 — Misleading and Digest 18.3.1.5 — Knowingly :

- If there is a false statement that is knowingly made, go to step 8.

- If there is a false statement that is not knowingly made, go to step 11.

- If there is no false statement, go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_ref_fttaojo#recw36mo)

- Determine if the investigator recommends that the file be reconsidered in light of a voluntary disclosure, as described in National Policy on Voluntary Disclosure :

- If the voluntary disclosure criteria are not met, go to step 9.

- If the voluntary disclosure criteria are met but the case type in NIIS is not 70, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_ref_fttaojo#volclosapp)

- If the voluntary disclosure criteria are met and the investigation type in NIIS is 70, go to Voluntary disclosure approved .
               [Voluntary disclosure approved](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_ref_fttaojo#vda)

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — [ refusing an offer of employment or failing to take advantage of a job opportunity ] — [employer’s name] — good cause not proven.”
               [refusing an offer of employment](/en/procedure/task/refusing_offer_empl.shtml) 
               [failing to take advantage of a job opportunity](/en/procedure/task/fta_job_opportunity.shtml)

- Details: Document the decision and rationale for the non-availability issue according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Go to Adjudicating client or third party misrepresentation — Monetary penalty or warning letter to input the appropriate sanctions and decisions.

- Determine the reconsideration period for the false or misleading statement not knowingly made:

- If the false statement was made within the prescribed period of 36 months , go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_ref_fttaojo#recw36mo)

- If the false statement was made within the extended period of 72 months , go to Reconsideration after 36 months .
               [Reconsideration after 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_ref_fttaojo#recon36) 

#### Not within reconsideration timeframe

Source topic: `en_EN/task/aic_ref_fttaojo/not_within_reconsideration_timeframe_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — EIA 52 — not within reconsideration timeframe.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, select the Renewal/Revised (M106) transaction and clear the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, from the Report for Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Not within reconsideration timeframe.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Returning the file to Integrity

Source topic: `en_EN/task/aic_ref_fttaojo/returning_the_file_to_integrity_level_2.dita`

- In NIIS, from the Document tab, select IC70 Report of Investigation or IC50 Report of Clerical Investigation , depending on the case, and complete the following fields:

- Select Recommendation .

- Refer the file to Integrity as follows:

- Select Yes (IC70) .

- Check the box (IC50) .

- Enter the missing or additional information required in the text area.

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1812.dita)

- In FTS, click the Outstanding Registrations link to cancel the registration number as follows:

- Select Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Select Update .

- If applicable, return the paper documents relating to the investigation to the investigator who signed the Report of Investigation.

- In NWS, complete the CR Integrity WI. 

#### Suitable employment — Good cause

Source topic: `en_EN/task/aic_ref_fttaojo/suitable_employment__good_cause_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — [refusal of employment or failure to take advantage of a job opportunity] — [name of the employer] — employment not suitable or good cause shown.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if an MA is imposed to stop payment for the refusal of employment issue :

- If yes, go to step 3.

- If no, go to step 4.

- Select the Renewal/Revised (M106) transaction to remove the MA as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- Go to step 5.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the Z-00-00-00 letter to the employer only if the reasons for refusal are related to the employment. Use the following text:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1813.dita)

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Employment not suitable or good cause.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- Complete the CR Integrity WI. 

#### Voluntary disclosure approved

Source topic: `en_EN/task/aic_ref_fttaojo/voluntary_disclosure_approved_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: “[Integrity case number] — [refusal of employment or failure to take advantage of a job opportunity] — [name of the employer] — good cause not shown.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD for the voluntary disclosure issue as follows:

- Comments: Type “[Integrity case number] — voluntary disclosure approved.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain that the client meets the 2 conditions for the National Policy on Voluntary Disclosure .
               [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 4.

- If the claim is terminated, but may be reactivated:

- On the Dormant tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 4.

- If the claim is blocked or archived, go to step 5.

- Select the Renewal/Revised (M106) transaction to remove the MA and input the disqualification as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select the appropriate MA (if required).

- Rescind: Check the box.

- Action: Select Add .

- Disqualification: Select the appropriate option:

- 6 - Refusal of employment

- 7 - Neglect to avail - Just cause not proven

- Number of weeks: Select the number of weeks between 7 and 12 weeks.

- Effective: Select the w/c for the failure to take advantage of a job opportunity.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 15.

- Determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed , go to step 6.

- If 2 - Not blocked is displayed, return to step 3.

- If any other CS is displayed, go to step 13.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 7.

- If all rows are blank, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1800.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter [the next working day].

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 7.

- If all rows are blank, go to step 9.

- Select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the applicable registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- On the Disqualifications tab, input the disqualification in the Disqualifications section as follows (up to 3 disqualifications in BCS can be imposed or rescinded):

- Action: Select A - Add .

- Type: Select the appropriate option:

- 6 - Refusal of employment

- 7 - Neglect to avail - Just cause not proven

- Effective: Type the w/c for the start date of the disqualification.

- Number of weeks: Select the number of weeks between 7 and 12 weeks.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 12.

- If the transaction shown is correct, click Close and go to step 15.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 10.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the unreported voluntary leaving.

- Work item: Select 91 - Overpayment .

- Work type: Select 1 - Misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D6 or D7 from w/c [XXXX] to [XXXX].”

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Definite Disqualification Messages - D6/D7/D9 - Post-audit (2918)

- D6 - Did not apply for or accept a certain job - Post-audit (2919) or D7 - Neglected to take advantage/Failed to return (2921)

- We/We have re-examined your claim/In addition, we (2916)

- Number of weeks disqualified (1298)

- Text - Name of employer(s) (1502)

- Date of event (1292)

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim

- Overpayment – No misrepresentation and inactive claim

- In ACS, create and send the D-70-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Voluntary disclosure / Administrative Rule - Undeclared Earnings(2664)

- Voluntary disclosure of information

- Subjects of voluntary disclosure (2665)

- Text: Insert appropriate reason(s)(1618): Reason for refusing employment or Reason for not taking advantage of a job opportunity

- Blank/Reminder: Provide information on report (2667)

- Provide full and accurate information on each report and correct any incorrect reports as soon as possible .

- Overpayment messages (2452): Select the appropriate option.

- Right to request a reconsideration (4169)

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select the appropriate option:

- Refusal of employment (D06)

- Neglect to avail (D07)

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Reconsideration within 36 months

Source topic: `en_EN/task/aic_ref_fttaojo/reconsideration_within_36_months_level_2.dita`

- In NWS, create a ROD for the refusal of employment issue as follows:

- Comments: Type “[Integrity case number] — [refusal of employment or failure to take advantage of a job opportunity] — [name of the employer] — good cause not shown.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 3.

- If the claim is terminated, but may be reactivated:

- On the Dormant tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 3.

- If the claim is blocked or archived, go to step 4.

- Select the Renewal/Revised (M106) transaction to remove the MA and input the disqualification as follows:

- Manual Action: Select the appropriate MA (if required).

- Rescind: Check the box.

- Action: Select Add .

- Disqualification: Select the appropriate option:

- 6 – Refusal of employment

- 7 – Neglect to avail – Just cause not proven –

- Number of weeks: Select the number of weeks between 7 and 12 weeks.

- Effective: Select the w/c for the failure to take advantage of a job opportunity.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification

- Contentious: Select 2 - Yes .

- Complete: C - Yes .

- Select Update .

- Go to step 14.

- Determine the blocked claim’s status by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed , go to step 5.

- If 2 - Not blocked is displayed, return to step 2.

- If any other CS is displayed, go to step 12.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 6.

- If all rows are blank, go to step 8.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 6.

- If all rows are blank, go to step 8.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the applicable registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- On the Disqualifications tab, input the disqualification on the Disqualifications section as follows (up to 3 disqualifications in BCS can be imposed or rescinded):

- Action: Select A - Add .

- Type: Select the appropriate option:

- 6 - Refusal of employment

- 7 - Neglect to avail – Just cause not proven

- Number of weeks: Select the number of weeks between 7 and 12 weeks.

- Effective: Select the w/c for the failure to take advantage of a job opportunity.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 11.

- If the transaction shown is correct, click Close and go to step 14.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 9.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the unreported voluntary leaving.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D6 or D7 from w/c [XXXX] to [XXXX].”

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Definite Disqualification Messages – D6/D7/D9 (2918)

- D6 - Did not apply or accept a certain job - Post-audit (2919) or D7 - Neglected to take advantage / Failed to return (2921)

- We/We have re-examined your claim/In addition, we (2916)

- Number of weeks disqualified (1294)

- Text: Name of employer(s) (1502)

- Date of event (1292)

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim

- Overpayment – No misrepresentation and inactive claim

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select the appropriate option:

- Refusal of employment (D06)

- Neglect to avail. (D07)

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Reconsideration after 36 months

Source topic: `en_EN/task/aic_ref_fttaojo/reconsideration_after_36_months_level_2.dita`

- In NWS, create a ROD for the refusal of employment issue as follows:

- Comments: Type: “[Integrity case number] — [refusal of employment or failure to take advantage of a job opportunity] — [name of employer] — good cause not shown.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed , go to step 3.

- If any other CS is displayed, go to step 10.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 4.

- If all rows are blank, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 4.

- If all rows are blank, go to step 6.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following fields:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the applicable registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- On the Disqualifications tab, input the disqualification on the Disqualifications section as follows (up to 3 disqualifications in BCS can be imposed or rescinded):

- Action: Select A - Add .

- Type: Select the appropriate option:

- 6 - Refusal of employment

- 7 - Neglect to avail – Just cause not proven

- Number of weeks: Select the number of weeks between 7 and 12 weeks.

- Effective: Select the w/c for the failure to take advantage of a job opportunity.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 9.

- If the transaction shown is correct, click Close and go to step 12.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 7.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the unreported voluntary leaving.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D6 or D7 from w/c [XXXX] to [XXXX].”

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Decision reconsidered beyond 36 months (2595): Select Decision reconsidered beyond 36 months due to false representations

- Definite Disqualification Messages – D6/D7/D9 - Post-audit (2918)

- D6 - Did not apply for or accept a certain job (2919) or D7 - Neglected to take advantage/Failed to return (2921)

- We/We have re-examined your claim/In addition, we (2916)

- Number of weeks disqualified (1294)

- Text - Name of employer(s) (1502)

- Date of event (1292)

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment messages (2452): Choose one of the following:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim

- Overpayment – No misrepresentation and inactive claim

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select the appropriate option:

- Refusal of employment (D06)

- Neglect to avail (D07) .

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1667.dita`

Note:

Cases with an OP below the Integrity investigative threshold are referred for adjudication only when specific exceptions are met (voluntary disclosure or impact on an active claim). In these cases, the employer’s or any other party’s version does not have to be verified and the file must not be returned to Integrity. 

#### Note

Source topic: `en_EN/common_notes/note_c_1812.dita`

Note:

The regional consideration for officers in the Quebec region is as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a c.c.

- In NWS, create a client Note and type “Measure — returned to Integrity ­ [date].” 

#### Callout

Source topic: `en_EN/common_notes/note_c_1813.dita`

“To whom it may concern:

We have made a decision in accordance with the Employment Insurance Act. We are of the view that a valid reason was given by (client’s first and last name) for the failure to take advantage of the job opportunity.

If you have additional information that could change this decision, or if you wish to discuss this issue, please contact us.

If you do not agree with our decision, which is based on the Employment Insurance Act and its Regulations, you have 30 days following receipt of this notice to submit a written request to the Commission to reconsider its decision. For more details about the reconsideration process, please visit www.ei-ae.gc.ca or your Service Canada centre, or contact us at 1-800-206-7218.

Sincerely,

Employment Insurance Commission

Processing and Payment Services” 

#### Note

Source topic: `en_EN/common_notes/note_c_1800.dita`

Note:

An update in BCS can only be made on one BPC at a time. 

#### Note

Source topic: `en_EN/common_notes/note_c_1791.dita`

Note:

An update in BCS can only be done on one BPC at a time. 

## Policy reference

Source topic: `en_EN/task/aic_ref_fttaojo/policy_reference.dita`

- Digest 9 — Refusal of employment
         [Digest 9 — Refusal of employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-9/table-of-contents.html)

- Digest 17 — Reconsideration, Amendment of a Decision, and Error Correction
         [Digest 17 — Reconsideration, Amendment of a Decision, and Error Correction](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/table-of-contents.html)

- Digest 18 — Policy on Penalties
         [Digest 18 — Policy on Penalties](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/table-of-contents.html)

- EIA 38
         [EIA 38](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-11.html)

- EIA 52
         [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 
