# Processing a converted Work-Sharing utilization report — IPOC

Source map: `en_EN/task/processing_awsur/processing_awsur.ditamap`

## Summary

Source topic: `en_EN/task/processing_awsur/summary.dita`

Summary: A Work-Sharing (WS) employer uploads a weekly utilization report (UR) that determines a client’s entitlement to WS benefits. IPOC is responsible for reviewing and uploading the converted URs to match them with the claimant’s reports and process payments. 

## What you need to know

Source topic: `en_EN/task/processing_awsur/what_you_need_to_know.dita`

### Triage process

Source topic: `en_EN/task/processing_awsur/triage_process.dita`

A triage process was developed to convert URs received through the Data Gateway and upload them to FTS.

If the triage process cannot successfully convert a UR, it moves the UR to the Manual_Macro_Required folder. The IPOC officer checks this folder throughout the day and manually processes any URs in the folder as directed in Actioning Work-Sharing utilization reports not completed by the triage process — IPOC .
       [Actioning Work-Sharing utilization reports not completed by the triage process — IPOC](/en/procedure/task/actioning_ws_urnc_robot_ipoc.shtml) 

### Converting the utilization report (UR) for FTS

Source topic: `en_EN/task/processing_awsur/converting_the_utilization_report_ur_for_fts.dita`

Before processing a UR, the IPOC officer converts and reformats the UR with a macro in order to fit FTS requirements as directed in Receiving and converting a Work-Sharing utilization report — IPOC . The conversion macro also identifies lump-sum payments and MPS claims.
       [Receiving and converting a Work-Sharing utilization report — IPOC](/en/procedure/task/receiving_converting_rsur.shtml)

AWSS combines the declaration on the UR with the client’s declaration from the claimant’s report and automatically generates a Manual Action - Claimant’s Reports (T045) transaction to process the weeks. AWSS only performs the automation if a 76 - Automated Work-Sharing manual action (MA76) is imposed on the claim.

AWSS cannot process actions required when the employer adds comments to the UR. Before processing a UR, the IPOC officer reviews the UR for comments that would not otherwise be caught by edits within the Automated Worksharing screen in FTS. When processing a UR, any errors detected by AWSS are highlighted in red. 

### Claimant’s reports

Source topic: `en_EN/task/processing_awsur/claimants_reports.dita`

WS employees can choose to be exempted from reporting if they only have their WS employment. Clients who are exempted from reporting (i.e. on a NO-CR-CODE) are paid based on the UR declaration.

A WS employee who completes paper claimant’s reports declares only the work and earnings from employment other than WS employment. This includes self-employment earnings. When the paper claimant’s report is received, the IPOC officer enters the information in BPS where the claimant’s report cycles internally. It is also sent to AWSS until it is matched to the WS data received from the employer via the UR. Once the UR and the claimant’s report are received for the same weeks, AWSS combines the data and generates a Manual Action - Claimant’s Reports (T045) transaction to process the weeks. 

### Speed of service for utilization reports (URs)

Source topic: `en_EN/task/processing_awsur/speed_of_service_for_utilization_reports_urs.dita`

Due to the tight speed-of-service deadlines, URs must be treated with the same priority as claimant’s reports and the IPOC officer must input these claimant’s reports within 2 calendar days (day of receipt + 1). URs received by the Data Gateway after 12:00 p.m. on any given day are considered to be received on the next working day. 

### AWSS

Source topic: `en_EN/task/processing_awsur/awss.dita`

AWSS is a behind-the-scenes program that automates much of the payment process. It works in conjunction with BPS and the Automated Worksharing screen in FTS. The fields in the Automated Worksharing screen are prefilled when an electronic UR is uploaded or can be filled by manually entering the requested information. Only IPOC and specialized staff performing IPOC functions can access this screen. 

### Normal weekly hours (NWH)

Source topic: `en_EN/task/processing_awsur/normal_weekly_hours_nwh.dita`

NWH are the hours that the employee would normally have worked during the week in question in the absence of a WS agreement. NWH are used to determine the percentage of work an employee has missed and the amount of payable EI benefits. NWH are determined by the program officer at the beginning of the agreement and do not change throughout the agreement unless the employee changes positions within the company.

However, if an employee has an irregular work schedule, the NWH can vary on the UR. This variance is acceptable. Due to BPS restrictions, only one entry can be input for the NWH. As a result, the IPOC officer must pay special attention when the client works a varied or rotating work schedule. The NWH are calculated as an average of the total hours worked in the schedule.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4126.dita) 

### Processing a week without hours worked

Source topic: `en_EN/task/processing_awsur/processing_a_week_without_hours_worked.dita`

During the WS agreement, WS employees must have a minimum of a half-hour of work on file for each week in order for the weeks to be processed as WS weeks.

If there are no hours worked in a week, that week is not considered a WS week and BPS determines entitlement based on regular EI conditions. It is not considered a WS week if the employee is paid a half-hour (or more) in salary but the employee did not physically work during that week. Attending employer-directed training or meetings is considered physically working, provided the employer is paying the employee’s regular wages while in attendance. 

### Processing statutory holidays, sick days and non-available days reported

Source topic: `en_EN/task/processing_awsur/processing_statutory_holidays_sick_days_b8a1b0bd.dita`

During a week of WS, IPOC ignores statutory holidays, sick days and non-available days reported.

During a non-WS week, where the employee did not work, statutory holidays, sick days and non-available days are treated according to the normal entitlement conditions. 

### Processing a lump-sum payment

Source topic: `en_EN/task/processing_awsur/processing_a_lump-sum_payment.dita`

When the employer or client informs IPOC that a lump-sum payment was issued, the IPOC officer sends an Action Item (AI) WI to the processing centre (Level 1). In the AI WI, the IPOC officer indicates the lump-sum payment and all the other information regarding why and when a payment was issued (e.g. the details of the vacation pay or the payment of a production bonus and the date of the payment).

Once processing officers determine the weeks affected and the allocation amount, they email the IPOC if there are weeks in the allocation period that have not been processed. After receiving the email with the allocation information from the processing centre, IPOC officers review already-processed weeks and input the earnings for weeks that were not weeks of WS. For weeks that have not been processed, IPOC officers copy the information from the lump-sum payment spreadsheet received from processing officers and paste it into the master lump-sum payment spreadsheet in the Upload_to_FTS folder.

When each UR is converted, the macro checks the master lump-sum payment spreadsheet for the agreement number. If a lump-sum payment is identified for the agreement number being processed, the IPOC officer looks for clients who did not work the minimum half-hour required for the week to be considered a WS week. If such a client is identified, the IPOC officer determines if this client and the w/c matches a client and w/c on the lump-sum spreadsheet. If it does and the week is a WS week, the allocated amount is ignored. If it does and the week is not considered a WS week, the amount allocated to this week is added to the UR as earnings.

When the lump-sum payment is for wage loss insurance (WLI) or paid sick leave (PSL) and the week is being processed as a casual sickness week during a WS agreement, a premium reduction code can apply. In this situation, the WLI or PSL payments are deducted dollar for dollar. In general, benefits are not payable for a week in which there is a WLI or PSL allocation with a premium reduction code. In these situations, the Level 1 officer enters 9999 as the allocation amount in the appropriate week to prevent payment. In rare cases, benefits are partially payable or the officer must document the actual allocation amount. In these situations, due to system limitations, the Level 1 officer sends an Operational Centre Memo (MM06) transaction to IPOC to convert the claim to MPS. 

### Inputting a special condition code

Source topic: `en_EN/task/processing_awsur/inputting_a_special_condition_code.dita`

Although AWSS can process most UR declarations, some claims are too complex for the system to automate. In these cases, IPOC uses a special condition code during the input. The special condition code does one of two things:

- helps the system determine the action to be taken;

- forces the reject of the UR declaration, and NWS generates an IPOC System Notification (IPOC SN) Work-Sharing - Special condition WI the following day for the IPOC officer to review and manually input a Manual Action - Claimant’s Reports (T045) transaction in order to process the declaration.

The IPOC officer manually inputs the special condition codes in the Reason for not working field in AWSS.

To access the special condition codes chart, the officer refers to Work-Sharing: Utilization report coding — Input guide .
       [Work-Sharing: Utilization report coding — Input guide](/en/procedure/generic/additionalresources/ws_coding_utilization_report.shtml) 

### Processing apprenticeship training and maternity, parental, compassionate care or family caregiver leave

Source topic: `en_EN/task/processing_awsur/processing_apprenticeship_training_and__e0a46c44.dita`

IPOC may be notified that a WS employee is not working and is instead participating in an apprenticeship program or is on a maternity, parental, compassionate care or family caregiver leave through:

- an employer’s comments on the UR;

- correspondence received from the program officer.

Participating in full-time apprenticeship training instead of working for the WS employer constitutes a separation from WS employment, even though the training is referred under EIA 25 and the separation may only be temporary (i.e. only for the period of the course). If the UR does not clearly indicate a layoff, the IPOC officer completes fact-finding with the WS employer in order to determine if the client will be working during the apprenticeship training. If the client will not be working, the IPOC officer considers this a temporary layoff. If the client is not working during the period of leave, maternity, parental, compassionate care and family caregiver leave are also considered a temporary separation from WS employment.

Although it is not reported as a layoff on the ROE, separation for apprenticeship training or maternity, parental, compassionate care and family caregiver leave is considered a temporary layoff for WS purposes to pay apprenticeship or special benefits. The IPOC officer advises the employer to remove the employee from the UR until the employee returns to work. The IPOC officer selects the special condition code 08 - Laid off when coding the UR, terminates the current WS period and removes the MA76 from the claim. The IPOC officer then creates an AI WI for Level 1. These steps permit a Level 1 officer to convert the claim to pay apprenticeship, maternity, parental, compassionate care or family caregiver benefits when the client applies for the required renewal claim.

For more information and examples, the officer refers to Work-Sharing: Utilization report coding — Input Guide .
       [Work-Sharing: Utilization report coding — Input Guide](/en/procedure/generic/additionalresources/ws_coding_utilization_report.shtml) 

### Inputting a utilization report (UR) manually

Source topic: `en_EN/task/processing_awsur/inputting_a_utilization_report_ur_manually.dita`

Although the UR is normally uploaded as a bulk transaction in the Automated Worksharing screen, the UR can be input manually. This can be a time consuming process and is not recommended unless the conversion macro is not working correctly and the IPOC officer cannot perform the upload function. In such a case, the IPOC officer manually checks the lump-sum payment spreadsheet and the MPS file spreadsheet before processing the UR. Instead of uploading the UR in FTS, the IPOC officer manually inputs the data for every declaration. 

### Fact-finding with the employer

Source topic: `en_EN/task/processing_awsur/fact-finding_with_the_employer.dita`

If the employer cannot be reached right away, the IPOC officer forces the UR declaration to be rejected in AWSS to ensure that the remainder of the UR is processed and the 2-day speed of service for processing URs is met. The IPOC officer can save the unresolved client file for future action. This can easily be retrieved once it is ready for correction.

If the UR declaration is clarified or changed, regardless of how many employees are affected, the IPOC officer documents the changes in an SROC for each affected SIN. If many employees are affected, the IPOC officer advises the employer to upload a new UR instead of documenting each claim file.

The IPOC officer refers to Fact-finding with a Work-Sharing employer for more information.
       [Fact-finding with a Work-Sharing employer](/en/procedure/task/fact_finding_wse.shtml) 

### Archiving the employer folder when a Work-Sharing (WS) agreement has ended

Source topic: `en_EN/task/processing_awsur/archiving_the_employer_folder_when_a_wo_d7bcacfb.dita`

When the WS agreement end date is reached and the final UR has been processed, the IPOC officer moves the employer folder to the Archived_Agreements folder and saves it in the subfolder of the year and month in which the WS agreement ends. 

### Example

Source topic: `en_EN/common_notes/note_c_4126.dita`

Example:

2-week rotating schedule:

- Week 1: 45 hours

- Week 2: 35 hours

45 + 35 = 80 ÷ 2 = 40 hours coded as NWH Although the NWH of 40 is used for the project data information and the calculation of the claim, the employer reports the actual NWH, hours worked and hours missed due to WS on the UR. The payment is calculated based on the averaged NWH.

Actual schedule and what is reported on the UR:

- Week 1: NWH = 45, hours worked = 27, hours missed due to WS = 18

- Week 2: NWH = 35, hours worked = 21, hours missed due to WS = 14

If BPS was able to calculate a WS claim based on varied NWH and the client’s benefit rate was $400 per week, payment to the client would be:

- Week 1: (18 ÷ 45) × $400 = $160

- Week 2: (14 ÷ 35) × $400 = $160

Total payment over the 2-week period would be $320. Payment based on the averaged NWH:

- Week 1: (18 ÷ 40) × $400 = $180

- Week 2: (14 ÷ 40) × $400 = $140

Total payment over the 2-week period would be $320. 

## Regional considerations

Source topic: `en_EN/task/processing_awsur/regional_considerations.dita`

**Quebec Region**

IPOC officers communicate with Processing via the region’s Work-Sharing Reference Tool (WSRT), an Outlook-based communication tool.

**Western Canada and Territories Region**

**Actioning a lump-sum payment**

The specialized regional payment unit is responsible for allocating vacation pay, statutory holiday pay, WLI, and workers’ compensation benefits (WCB). 

## What you need to look for

Source topic: `en_EN/task/processing_awsur/what_you_need_to_look_for.dita`

### In the employer’s Active_Agreements subfolder:

Source topic: `en_EN/task/processing_awsur/in_the_employers_active_agreements_subfolder.dita`

- Has the UR been converted?

- Is this the next UR to be received?

- Is this an original or an amended UR? 

### In the UR:

Source topic: `en_EN/task/processing_awsur/in_the_ur.dita`

- Are there any comments added by the employer in the Comments column?

- Is a special condition code required?

- Did the employer indicate a lump-sum payment? 

### In FTS:

Source topic: `en_EN/task/processing_awsur/in_fts.dita`

- Are there fields highlighted in red that need to be corrected? 

## Step by step

Source topic: `en_EN/task/processing_awsur/step_by_step.dita`

### IPOC

Source topic: `en_EN/task/processing_awsur/ipoc.dita`

#### Reviewing the file

Source topic: `en_EN/task/processing_awsur/reviewing_the_file_ipoc.dita`

- In FTS, select Search to determine if the UR to be processed is the next UR to be received. Determine the last week processed or pending as follows:

- Select Worksharing Employer Records .

- Enter the WS agreement number.

- Select Search .

- In the Report week column, determine the last week uploaded.

- If the UR received has already been processed, refer to Processing an amended Work-Sharing utilization report .
               [Processing an amended Work-Sharing utilization report](/en/procedure/task/processing_amended_wsur.shtml)

- If the UR received is the expected UR, go to step 2.

- If the UR received is not the expected UR, contact the employer to obtain the missing UR. URs must be processed in w/c order, so process the missing URs first. Go to step 2.
               [contact the employer](/en/procedure/task/fact_finding_wse.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4127.dita)

- In the regional Data Gateway folder, select Upload_to_FTS , open the file that contains the converted WS UR and ensure that the fields are entered correctly. Review the UR as follows:

- Verify if the WS agreement number is indicated.

- Determine if there is anything that affects the entire WS agreement that needs fact-finding or clarification (e.g. a statutory holiday that appears to have been included in hours worked or hours missed).
               [fact-finding](/en/procedure/task/fact_finding_wse.shtml)

- Determine if there are non-available days, sick days, PSL amounts and other amounts paid that require special attention or coding. For more information, refer to Work-Sharing: Utilization report coding — Input guide . If the employer indicates a lump-sum payment, go to Processing a lump-sum payment for guidance.
               [Work-Sharing: Utilization report coding — Input guide](/en/procedure/generic/additionalresources/ws_coding_utilization_report.shtml) 
               [Processing a lump-sum payment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/processing_awsur#processing_lump_sum_payment)

- Determine if there are any comments in the UR that require a special condition code or further action (e.g. planned shutdown, apprenticeship or a contentious reason for separation declared):

- If yes, modify the UR fields accordingly, save the changes and complete any additional claim actions required in FTS for specific SINs, as applicable. For more information, refer to Work-Sharing: Utilization report coding — Input guide . Once the UR has been coded, go to Uploading the utilization report (UR) .
                   [Work-Sharing: Utilization report coding — Input guide](/en/procedure/generic/additionalresources/ws_coding_utilization_report.shtml) 
                   [Uploading the utilization report (UR)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/processing_awsur#uploading_ur)

- If no, go to Uploading the utilization report (UR) .
                   [Uploading the utilization report (UR)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/processing_awsur#uploading_ur) 

#### Uploading the utilization report (UR)

Source topic: `en_EN/task/processing_awsur/uploading_the_utilization_report_ur_ipoc.dita`

- Determine if the UR has been converted correctly and can be uploaded in AWSS:

- If yes, go to step 2.

- If no, go to step 3.

- In FTS, select the Automated Worksharing screen to upload the UR as follows:

- Select File .

- Select Retrieve .

- Select Original Data .

- Open the Upload_to_FTS directory.

- Find the UR and double-click it.

- Go to step 4.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4128.dita)

- Select the Automated Worksharing screen and manually input the appropriate UR information in the following fields, if necessary:

- SIN

- Report week

- Normal hours

- Hours worked

- Non-available days

- Sick days

- Paid sick amount

- Other amount paid

- Hours missed

- Agreement number

- Reason for not working: Select the appropriate special condition code, if necessary.

- Determine if there are any comments in the UR that require a special condition code or further action.

- Select Add when the information for a SIN is complete and proceed to the next SIN.

- Complete these steps for each SIN, if necessary.

- When all the data is displayed on the Automated Worksharing screen, select Update .

- Determine if any declarations rejected the initial update due to fields that are highlighted in red and need to be corrected:

- If yes, go to Saving unresolved client files .
               [Saving unresolved client files](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/processing_awsur#saving_unresolved_client_files)

- If no, once all claims are uploaded, delete the UR that was uploaded from the Upload_to_FTS folder. Go to Archiving an ended Work-Sharing (WS) agreement .
               [Archiving an ended Work-Sharing (WS) agreement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/processing_awsur#ipocc_item_2) 

#### Saving unresolved client files

Source topic: `en_EN/task/processing_awsur/saving_unresolved_client_files_ipoc.dita`

- In the Automated Worksharing screen, select the SIN with the box highlighted in red to correct the applicable field:

- Select the box highlighted in red. The data for the specific SIN is displayed at the bottom of the screen in the editing section.

- In the editing section, input the appropriate information. For more information, refer to Work-Sharing: Utilization report coding — Input guide if required.
               [Work-Sharing: Utilization report coding — Input guide](/en/procedure/generic/additionalresources/ws_coding_utilization_report.shtml)

- Select Modify .

- Repeat this step for all fields highlighted in red.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4129.dita)

- Determine if there are client files that cannot be corrected right away:

- If yes, go to step 3.

- If no, select Update to upload all the client files. Once all claims are uploaded, delete the UR that was uploaded from the Upload_to_FTS folder. No further action is required.

- Save the unresolved client files for future action as follows:

- In AWSS, select Update . All client files except those highlighted in red will be uploaded.

- Are you sure you want to transmit?: Select Yes .

- Select File .

- Select Save . A dialogue box is displayed and asks where to save the unresolved client files. Make sure the extension is .XML. This must be saved in the Rejected_Declarations folder.

- The transaction has not been updated. Do you wish to exit?: Select Yes .

- Once the unresolved client files are saved, delete the UR that was uploaded from the Upload_to_FTS folder.

- Once the fact-finding required to code the unresolved client files is completed, go to Actioning rejected utilization report declarations — IPOC .
               [Actioning rejected utilization report declarations — IPOC](/en/procedure/task/actioning_rejected_urd_ipoc.shtml) 

#### Processing a lump-sum payment

Source topic: `en_EN/task/processing_awsur/processing_a_lump-sum_payment_ipoc.dita`

- In the UR, determine if the employer indicated a lump-sum payment on the client’s declaration:

- If no, but earnings were received from the WS employer in a WS week, ignore the earnings and process the UR.

- If no, but earnings were received from the employer in a non-WS week, code the earnings on the UR and process the UR.

- If yes, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4130.dita)

- Determine if the client worked for at least a half-hour:

- If yes, remove the lump-sum amount on the converted UR and process the UR without it.

- If no, process the UR with the lump-sum amount as earnings.

- In NWS, create an AI WI for Level 1 as follows:

- Complexity: Select Level 1 .

- Destination: Select appropriate option:

- Atlantic: SCC: Select the Service Canada Centre (SCC) as shown in FTS.

- Ontario: Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - ON / Work-Sharing - ON .

- Quebec: Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC / Work-Sharing - QC .

- Western Canada and Territories: Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - WT / Work-Sharing - WT .

- End User: Select Next available user .

- Category: Select the appropriate option:

- Pay affected .

- Not pay affected .

- Issue: Select Work-Sharing .

- Comments: Type “Lump-sum payment — client on Work-Sharing.”

- Details: Type “As per the UR for w/c [XXXX], employer [XXXXX] indicated lump-sum payment of $[XXX].” If the earnings were included when the UR was processed, type: “Full lump-sum payment was included as earnings for w/c [XXXX] and week may need to be adjusted once the payment is adjudicated.”

- Return to the initial step. 

#### Archiving an ended Work-Sharing (WS) agreement

Source topic: `en_EN/task/processing_awsur/archiving_an_ended_work-sharing_ws_agreement_ipoc.dita`

- Determine if the UR received and processed is the final UR of the WS agreement:

- If yes, go to step 2.

- If no, no further action is required.

- Move the employer folder to the Archived_Agreements folder by cutting and pasting as follows:

- In the Active_Agreements folder, select the employer folder and cut it.

- In the Archived_Agreements folder, paste the employer folder into the subfolder that indicates the year and month in which the WS agreement ended.

- No further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_4127.dita`

Note:

If fact-finding with the employer is required and a client’s information is amended from the original declaration, document the new information on an SROC on the client’s file in NWS. There is no need to request an amended UR. A new or amended UR can be more efficient if a number of clients are affected by the fact-finding. 

#### Note

Source topic: `en_EN/common_notes/note_c_4128.dita`

Note:

There is no message indicating that the file is being retrieved. The larger the file, the longer it takes to open and display the information. 

#### Note

Source topic: `en_EN/common_notes/note_c_4129.dita`

Note:

If the fields highlighted in red cannot be corrected right away, the unresolved client files can be saved for future action. They will not be uploaded in AWSS but saved in the Rejected_Declarations folder. They can easily be retrieved once they are ready for correction. 

#### Note

Source topic: `en_EN/common_notes/note_c_4130.dita`

Note:

A lump-sum payment is generally an amount of money that exceeds the client’s normal weekly earnings. 

## Policy reference

Source topic: `en_EN/task/processing_awsur/policy_reference.dita`

 
