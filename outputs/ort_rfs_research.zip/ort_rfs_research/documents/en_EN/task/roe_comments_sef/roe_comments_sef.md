# Completing an ROE Comments WI — Fishing ROE

Source map: `en_EN/task/roe_comments_sef/roe_comments_sef.ditamap`

## Summary

Source topic: `en_EN/task/roe_comments_sef/summary.dita`

Summary: Comments identified on a fishing ROE require review to determine if they impact claim calculation or entitlement. When fraud indicators are present and the file is not already under investigation, the officer refers the file to Integrity. 

## What you need to know

Source topic: `en_EN/task/roe_comments_sef/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/roe_comments_sef/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4674.dita) 

ROE comments appear in block 12 for fishing ROEs. The intended use of the Comments block is for the employer to clarify or provide additional information. 

### Comment types

Source topic: `en_EN/task/roe_comments_sef/comment_types.dita`

Comments generally fall into one of 3 categories:

- No impact: information that is not relevant to claim calculation or entitlement, e.g. a personal note such as “Good luck.”

- Repetitive information: information already indicated elsewhere, e.g. comments indicate “end of season, quota reached or shortage of work” and block 11 displays A - End of Fishing, A - Requested by Fisher or B - Other . The Requested by Fisher field is on the fishing ROE Web only.

- Possible impact: information that is relevant to claim calculation or entitlement, e.g. additional details about monies paid on separation or the reason for separation (RFS), additional trip dates. 

### Creating a WI

Source topic: `en_EN/task/roe_comments_sef/creating_a_wi.dita`

During the ACP wait process, ROE Comments WIs are automatically created for comments on the last ROE only . The system assigns ROE Comments WIs to Non-complex officers. 

### Impact on calculation

Source topic: `en_EN/task/roe_comments_sef/impact_on_calculation.dita`

Comments which have no impact or contain repetitive information can be removed from block 12 at this level. If the Non-Complex officer is unable to remove the comments from the ROE, the WI must be reassigned to Level 1 for completion.

Comments which could have a possible impact on the claim calculation or entitlement must be reviewed and any changes updated on the ROE in RCM before removing the comments from block 12 . Comments are copied to the Additional information field in RCM.

If the Level 1 user determines the comments do affect calculation or entitlement, a review of the claim is required to determine if ACP has already finalized the claim. If the claim has been finalized, a recalculation is needed. 

### Contentious issues

Source topic: `en_EN/task/roe_comments_sef/contentious_issues.dita`

Fishing claims are exempt from disqualification under section 30 of the Act when the event occurs in the qualifying period. If a contentious RFS occurs during the benefit period, adjudication is required.

Level 2 adjudication is required for fishing claims that are impacted by a potential labour dispute. 

### ROE errors found during validation

Source topic: `en_EN/task/roe_comments_sef/roe_errors_found_during_validation.dita`

ROEs are automatically validated by the system. In some situations this validation can be performed only when a change is made in RCM, such as deleting a comment. If an error is detected during validation, an ROE Correction WI is not automatically created by the system, but the error prevents ACP from calculating the claim. Whenever possible, the officer must correct the ROE error to maximize automation. 

### Fraud indicators

Source topic: `en_EN/task/roe_comments_sef/fraud_indicators.dita`

Before completing the ROE Comments WI, officers determine if the application is already under investigation for potential fraud. Officers can determine that there is an ongoing Integrity investigation for this application if:

- a 71 - Integrity Services case manual action (MA71) or 71 - Integrity Services case disentitlement (D71) is imposed;

- an SROC created by Integrity is on file;

- an Action Item (AI) WI is assigned to Integrity;

- a Call Back (CB) WI is assigned to Integrity.

If none of these are on the file, officers review the file to determine if fraud indicators are present. If yes, officers:

- determine if the banking information has been changed in FTS and, if so, terminate the direct deposit;

- impose a D71 on skeleton and BPNE 1, 2 or 7 claims or an MA71 on established claims, if necessary;

- complete the registration number to suspend the initial application process to prevent the claim from establishing until an investigation is completed;

- refer the issue to Integrity for investigation;

- complete the Claim Set-Up (CS) WI.

If the only fraud indicator is the fraud warning highlighted in red in FTS, the officers do not refer the issue to Integrity.

For more information, officers refer to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4674.dita`

Note:

This task only applies to an ROE Comments WI in the normal ACP process. For comments on an ROE in the specialized ACP process, refer to Post-EI ERB: Completing an Assessment Issue ROE Comments WI — Fishing ROE .
       [Post-EI ERB: Completing an Assessment Issue ROE Comments WI — Fishing ROE](/en/procedure/task/post_eierb_completing_assessment_issue_roe_comments_wi_fishing_roe.shtml)

     [Post-EI ERB: Completing an Assessment Issue ROE Comments WI — Fishing ROE](/en/procedure/task/post_eierb_completing_assessment_issue_roe_comments_wi_fishing_roe.shtml) 

## Regional considerations

Source topic: `en_EN/task/roe_comments_sef/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/roe_comments_sef/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/roe_comments_sef/in_fts.dita`

- Is the claim established? 

### In NWS:

Source topic: `en_EN/task/roe_comments_sef/in_nws.dita`

- Is the Claim action status In progress ? 

### In RCM:

Source topic: `en_EN/task/roe_comments_sef/in_rcm.dita`

- Are the comments still displayed in block 12 of the ROE? 

## Step by step

Source topic: `en_EN/task/roe_comments_sef/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/roe_comments_sef/non-complex.dita`

#### Reviewing the file for fraud indicators

Source topic: `en_EN/task/roe_comments_sef/reviewing_the_file_for_fraud_indicators_non-complex.dita`

- In NWS, determine if there is documentation indicating that the file is under investigation for potential fraud:

- If no, go to step 2.

- If yes, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_sef#nc_item_7)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1527.dita)

- Review the application and ROEs to determine if known fraud indicators are present and if fraud is suspected. Refer to Fraud indicators: Identifying potentially fraudulent claims — Knowledge :

- If yes, go to step 3.

- If no, go to step 4.

- In FTS, determine if the banking information has been changed to the banking information on the potentially fraudulent application:

- If no, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_sef#nc_item_7)

- If yes, terminate the banking information by referring to Ending a direct deposit and go to Fraud indicators are present .
               [Ending a direct deposit](/en/procedure/task/ending_dd.shtml) 
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_sef#nc_item_7) 

#### Reviewing the file

Source topic: `en_EN/task/roe_comments_sef/reviewing_the_file_non-complex.dita`

- In RCM, review the ROE indicated in the ROE Comments WI and determine if there are comments in block 12 :

- If yes, go to step 5.

- If no, go to step 10.

           [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4675.dita) 

#### Reviewing the conditions to allow at Non-complex level

Source topic: `en_EN/task/roe_comments_sef/reviewing_the_conditions_to_allow_at_no_73969f75_non-complex.dita`

- Determine if the comments can be removed from block 12 according to the table below and complete the necessary actions.

```text
| Conditions present on the ROE. Both conditions must be present to make changes. | In RCM, complete the following fields: |

| Block 12 comments indicate: | Other conditions: | Block 12 | Other changes required |

| any non-contentious reason (e.g. end of season or quota reached) | Block 11: RFS is B - Other | Move the comments to the Additional information field. | Block 11: Select A - End of Fishing . |

| requested by fisher or requested by employee | Block 11: RFS is B - Other. | Move the comments to the Additional information field. | Block 11: Select A - Requested by Fisher . |

| contentious reason (e.g. labour dispute) | Block 11: RFS is B - Other | Move the comments to the Additional information field. | No change required |

| amended ROE (including original ROE serial number) | | Delete the comments. | Block 2 : Serial No. of ROE amended or replaced : Type the original ROE serial number |

| comments that have no impact on calculation or entitlement such as: - personal comments (e.g. Good luck Larry) - other comments (e.g. will return when work is available) | | Delete the comments. | |
```

- If the comments could be removed from block 12 , go to step 6.

- If the comments could not be removed, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_sef#nc_item_6) 

#### Inputs

Source topic: `en_EN/task/roe_comments_sef/inputs_non-complex.dita`

- In RCM, select Validate :

- If validation causes an ROE error, go to step 7.

- If validation does not cause an ROE error, select Submit and go to step 10.

- In NWS, determine if an ROE Correction WI or a Claim Assessment (CA) WI exists for this ROE:

- If no, go to step 8.

- If yes, go to step 10. 

#### Correcting ROE errors

Source topic: `en_EN/task/roe_comments_sef/correcting_roe_errors_non-complex.dita`

- Determine if the ROE can be corrected to fix the validation error. For procedures on correcting an ROE, refer to Completing an ROE Correction WI — Fishing ROE :

- If no, go to step 9.

- If yes, correct the ROE and go to step 10.

- Create an ROE Correction WI with the following fields:

- Complexity: Select Non-Complex .

- Language: Select the appropriate option, based on the employer’s preferred language

- Destination: Type the SCC as shown in the claim file in FTS.

- End user: Select Next available user .

- Serial Number: Type the serial number of the ROE.

- Issue: Select Correction .

- Complete the ROE Comments WI. 

#### Reassigning the issue to Level 1

Source topic: `en_EN/task/roe_comments_sef/reassigning_the_issue_to_level_1_non-complex.dita`

- In NWS, reassign the ROE Comments WI to Level 1 as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 1 .

- Reason: Select Unable to Complete .

- Details: Type “Comments cannot be removed at this level. Level 1 must review them.” 

#### Fraud indicators are present

Source topic: `en_EN/task/roe_comments_sef/fraud_indicators_are_present_non-complex.dita`

- In NWS, determine if any of the following WIs are on file:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4668.dita) 

- If no, go to step 2.

- If yes, go to step 19.

- Determine if any of the following are on file and directly related to the potentially fraudulent application:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1573.dita) 

- If no, go to step 3.

- If yes, go to step 6.

- In NWS, determine if a suspected fraud has previously been referred to Integrity in an AI WI that has not been completed:

- If yes, go to step 4.

- If no, go to step 5.

- Add the information related to the potentially fraudulent application to the existing Integrity AI WI as follows:

- Right-click and select Add details/Further Inquiry .

- Action: Select Additional information .

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the processing unit in the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue(s): Select ROE .

- Comments: Type “Fraud suspected — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- In FTS, determine if the initial claim has already been calculated:

- If yes, go to step 7.

- If no, go to step 10.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If yes, go to step 8.

- If no, go to step 16.

- Determine if an MA71 has already been imposed:

- If no, go to step 9.

- If yes, go to step 16.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 16.

- Determine if there is an outstanding initial registration number related to the fraudulent application:

- If yes, go to step 11.

- If no, go to step 16.

- Determine if a D71 has already been imposed:

- If no, go to step 12.

- If yes, go to step 13.

           [Important](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2918.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

- Go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2664.dita)

- In NWS, determine if the Claim action status is Finalized - Pending LREM :

- If yes, go to step 14.

- If no, go to step 15.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- Go to step 16.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1576.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the initial registration number as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 16.

- Determine if the ROE Comments WI is related to a potentially fraudulent ROE:

- If yes, go to step 17.

- If no, go to step 19.

- In RCM, determine if the ROE has been deleted:

- If no, go to step 18.

- If yes, go to step 19.

- In RCM, open the ROE and delete it as follows:

- Delete: Check the box.

- Additional information : Type “Suspicious ROE. ROE has been deleted to prevent it from being used in benefits calculation until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- In NWS, determine if there is a related ROE Comments WI:

- If yes, go to step 20.

- If no, no further action is required.

- Determine if the status of the ROE Comments WI is Assigned-Active :

- If yes, complete the WI.

- If no, no further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_1527.dita`

Note:

If the only fraud indicator is the fraud warning highlighted in red in FTS, go to step 2. 

#### Example

Source topic: `en_EN/common_notes/note_c_4675.dita`

Example:

Another officer may have removed the comments when adjudicating an RFS. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4668.dita`

- a Claim Review (CR) Integrity ERB-EI Transition WI related to the potentially fraudulent application;

- an AI WI from Integrity indicating that the claim can be established;

- a CB WI related to the potentially fraudulent application. 

#### Callout

Source topic: `en_EN/common_notes/note_c_1573.dita`

- an Integrity AI WI;

- an Integrity SROC;

- a D71 or an MA71;

- in RMDS, on the Employer profile screen, the Under investigation box is checked. 

#### Important

Source topic: `en_EN/common_notes/note_c_2918.dita`

Important:

Before imposing a D71, confirm that the file does not already include one. In such cases, if a transaction is input to impose a D71, the existing D71 is cancelled. 

#### Note

Source topic: `en_EN/common_notes/note_c_2664.dita`

Note:

If error code C072: Invalid Claim action or Action field (C072) is displayed when inputting the Renewal/Revised (M106) transaction, the D71 cannot be imposed. Go to step 13. 

#### Note

Source topic: `en_EN/common_notes/note_c_1576.dita`

Note:

If error code 836: WARNING - Flag 33 claim (Last Record of Employment Missing), claim is still polling for the last record of employment is displayed when attempting to clear the registration number, check the Override box to process the transaction. 

### Level 1

Source topic: `en_EN/task/roe_comments_sef/level_1.dita`

#### Reviewing the file for fraud indicators

Source topic: `en_EN/task/roe_comments_sef/reviewing_the_file_for_fraud_indicators_level_1.dita`

- NWS, determine if there is documentation indicating that the file is under investigation for potential fraud:

- If no, go to step 2.

- If yes, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_sef#level1_item_7)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1527.dita)

- Review the application and ROEs to determine if known fraud indicators are present and if fraud is suspected. Refer to Fraud indicators: Identifying potentially fraudulent claims — Knowledge :

- If yes, go to step 3.

- If no, go to step 4.

- In FTS, determine if the banking information has been changed to the banking information on the potentially fraudulent application:

- If no, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_sef#level1_item_7)

- If yes, terminate the banking information by referring to Ending a direct deposit and go to Fraud indicators are present .
               [Ending a direct deposit](/en/procedure/task/ending_dd.shtml) 
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_sef#level1_item_7) 

#### Reviewing the file

Source topic: `en_EN/task/roe_comments_sef/reviewing_the_file_level_1.dita`

- In RCM, review the ROE indicated in the ROE Comments WI and determine if there are comments in block 12 .

- If yes, go to step 5.

- If no, go to step 22.

           [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4675.dita) 

#### Reviewing the conditions to allow at Level 1

Source topic: `en_EN/task/roe_comments_sef/reviewing_the_conditions_to_allow_at_level_1_level_1.dita`

- Determine if the comments in block 12 can be actioned without clarification from the employer or the client (e.g. lobsters not sold yet):

- If no, fact-find with the employer and go to step 6.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If yes, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4676.dita) 

#### Fact-finding

Source topic: `en_EN/task/roe_comments_sef/fact-finding_level_1.dita`

- When the employer has returned the call or when the ROE Comments WI has moved to the current workload, determine if clarification has been obtained:

- If no, go to step 7.

- If yes, go to step 10. 

#### Required information has not been obtained

Source topic: `en_EN/task/roe_comments_sef/required_information_has_not_been_obtained_level_1.dita`

- Determine if clarification with the employer or client is necessary to verify the ROE:

- If yes, refer the file to Integrity and go to step 8.
               [Integrity](/en/procedure/activity/referal_integrity.shtml)

- If no, go to step 10.

- In RCM, change the ROE as follows:

- Make any required corrections based on the comments in block 12 .

- Comments : Remove the text.

- Additional information : Copy the comments from block 12 and type: “changes made with information available on file as unable to confirm with the employer.”

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805): Select one of the following:

- Multiple Changes to ROE

- A Single Change to ROE

- List of the change

- Attached INS 3413

- Go to step 11. 

#### Required information has been obtained

Source topic: `en_EN/task/roe_comments_sef/required_information_has_been_obtained_level_1.dita`

- In RCM, change the ROE as follows:

- Correct the ROE as necessary based on the comments in block 12 .

- Comments: Remove the text.

- Additional information: Copy the comments from block 12 and do one of the following:

- If the comments were removed from block 12 following clarification with the employer, type “changes confirmed with [full name and position title]” and include details for any unchanged blocks confirmed by the employer.

- If the comments were removed from block 12 with no clarification from the employer, type “Changes made to blocks [#s] per the ORT.”

- In RCM, select Validate:

- If validation causes an ROE error, go to step 12.

- If validation does not cause an ROE error, go to step 13.

- In RCM, correct the ROE to fix the validation error and go to step 13. For procedures on correcting an ROE, refer to Completing an ROE Correction WI — Fisher ROE .

- Select Submit .

- Determine if the original RFS in block 11 has changed to “Strike or lockout” after removing the comments from block 12 .

- If yes, go to step 15.

- If no, go to step 18.

- Determine if adjudication of the labour dispute is now required:

- If yes, go to step 16.

- If no, go to step 18.

- Determine the claim status:

- If the Claim action status is In Progress , go to step 22.

- If the claim is established, go to step 17.

- If the claim is BPNE, go to step 18.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4677.dita)

- In FTS, select the Subsequent Decision - Renewal/Revised (M106) transaction and impose a manual action to stop payment (MA74) by completing the following fields:

- Manual Action: Select 74 - Labour Dispute .

- Registration number: If the registration number is prefilled, select the blank option.

- Select Update .

- From the audit trail in RCM and the ACP tracking information, determine if the comments in block 12 were removed before the claim calculation:

- If no, go to step 19.

- If yes, go to step 20.

- In SSO, review the claim assessment and determine if the ROE changes impact the claim calculation or entitlement (e.g. changes to the RFS, dates or monies may impact calculation or entitlement):

- If yes, go to Comments impact established claim .
               [Comments impact established claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_sef#commentsimpact)

- If no, go to step 20.

- In FTS, select the Registration number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Create Work Item: Check the box.

- Select Update .

- In NWS, open the newly created CR Revised WI and reassign it to yourself as follows:

- Destination: Select Myself .

- Issue: Select the appropriate option.

- Reason: Select Other .

- Details: Type “ROE comments indicate that a review of the RFS is required.”

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2290.dita)

- Complete the ROE Comments WI. 

#### Comments impact an established claim

Source topic: `en_EN/task/roe_comments_sef/comments_impact_an_established_claim_level_1.dita`

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 3.

- If no, go to step 4.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank, enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: This field is prefilled.

- Select Generate registration .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1571.dita)

- In NWS, assign the CR Recalculation WI to yourself.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4678.dita)

- Create a CR Revised WI for the RFS issue as follows:

- Type: Select Revised.

- Issue: Select the appropriate issue.

- Registration number: Type the recalculation registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination - SCC: Select the SCC as shown in FTS.

- Date of registration: Enter today’s date .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2290.dita)

- Reassign the CR Revised WI as follows:

- Destination: Select Myself .

- Reason: Select Related work item .

- Details: Enter the details of the contentious issue that requires adjudication.

- Complete the ROE Comments WI. 

#### Fraud indicators are present

Source topic: `en_EN/task/roe_comments_sef/fraud_indicators_are_present_level_1.dita`

- In NWS, determine if any of the following WIs are on file:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4679.dita) 

- If no, go to step 2.

- If yes, go to step 19.

- Determine if any of the following are on file and directly related to the potentially fraudulent application:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1573.dita) 

- If no, go to step 3.

- If yes, go to step 6.

- In NWS, determine if a suspected fraud has previously been referred to Integrity in an AI WI that has not been completed:

- If yes, go to step 4.

- If no, go to step 5.

- Add the information related to the potentially fraudulent application to the existing Integrity AI WI as follows:

- Right-click and select Add details/Further Inquiry .

- Action: Select Additional information .

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the processing unit in the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue(s): Select ROE .

- Comments: Type “Fraud suspected — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- In FTS, determine if the initial claim has already been calculated:

- If yes, go to step 7.

- If no, go to step 10.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If yes, go to step 8.

- If no, go to step 16.

- Determine if an MA71 has already been imposed:

- If no, go to step 9.

- If yes, go to step 16.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 16.

- Determine if there is an outstanding initial registration number related to the fraudulent application:

- If yes, go to step 11.

- If no, go to step 16.

- Determine if a D71 has already been imposed:

- If no, go to step 12.

- If yes, go to step 13.

           [Important](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2918.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

- Go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2664.dita)

- In NWS, determine if the Claim action status is Finalized - Pending LREM :

- If yes, go to step 14.

- If no, go to step 15.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- Go to step 16.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1576.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the initial registration number as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 16.

- Determine if the ROE Comments WI is related to a potentially fraudulent ROE:

- If yes, go to step 17.

- If no, go to step 19.

- In RCM, determine if the ROE has been deleted:

- If no, go to step 18.

- If yes, go to step 19.

- In RCM, open the ROE and delete it as follows:

- Delete: Check the box.

- Additional information : Type “Suspicious ROE. ROE has been deleted to prevent it from being used in benefits calculation until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- In NWS, determine if there is a related ROE Comments WI:

- If yes, go to step 20.

- If no, no further action is required.

- Determine if the status of the ROE Comments WI is Assigned-Active :

- If yes, complete the WI.

- If no, no further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_4676.dita`

Note:

If during fact-finding, the employer provides details specific to the RFS, create an SROC to document the information. Any other changes are documented in RCM. 

#### Note

Source topic: `en_EN/common_notes/note_c_4677.dita`

Note:

When the RFS is changed on an initial claim with a Claim action status of In Progress , the system creates the appropriate WI to ensure the new RFS is adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_2290.dita`

Note:

The appropriate adjudication task indicates if the issue can be adjudicated at Level 1 or if it must be reassigned to Level 2. 

#### Note

Source topic: `en_EN/common_notes/note_c_1571.dita`

Note:

When the message Success — Registration number created is displayed in SSO, a recalculation registration number is assigned to the claim. NWS creates a CR WI and assigns it to the unassigned (UNA) workload or to the next available user. 

#### Note

Source topic: `en_EN/common_notes/note_c_4678.dita`

Note:

When a recalculation registration number is assigned in SSO, a CR WI is automatically created in NWS. If the claim is already open in NWS, the new CR WI may not be displayed immediately. Close the claim and re-enter the SIN to see the CR WI. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4679.dita`

- a CR Integrity ERB-EI Transition WI related to the potentially fraudulent application;

- an AI WI from Integrity indicating that the claim can be established;

- a CB WI about the potentially fraudulent application. 

## Policy reference

Source topic: `en_EN/task/roe_comments_sef/policy_reference.dita`

 
