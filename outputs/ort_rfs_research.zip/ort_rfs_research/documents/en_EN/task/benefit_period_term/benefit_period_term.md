# Terminating a benefit period

Source map: `en_EN/task/benefit_period_term/benefit_period_term.ditamap`

## Summary

Source topic: `en_EN/task/benefit_period_term/summary.dita`

Summary: When a client requests the termination of a benefit period (BP) or when a renewable claim is not as beneficial to a client as a new BP, the officer determines if the existing BP can be terminated. 

## What you need to know

Source topic: `en_EN/task/benefit_period_term/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/benefit_period_term/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2152.dita) 

### Reviewing a benefit period (BP) when a client submits an application and there is an established claim

Source topic: `en_EN/task/benefit_period_term/reviewing_a_benefit_period_bp_when_a_cl_bdbbe54d.dita`

When a Claim Assessment (CA) or Specialized Application (SA) WI is created, the officer reviews the BP to determine if a renewal, termination or cancellation would be more beneficial for the client.

Generally, when clients who have entitlement weeks remaining on an established BP submit an application, their BP is renewed. Clients are advised on the renewal application that if they want to have a new BP instead of a renewal, they must call the call centre. If the call centre officer cannot complete the termination, the call centre officer creates a Call Back (CB) WI for processing.

Clients can also request to retroactively terminate a BP, even when benefits have been paid. This can occur when clients request that a new BP be established after receiving notice of a renewal or notice of a termination of a disentitlement.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2173.dita) 

**Reviewing the advantages and disadvantages with the client**

When considering a termination, the officer reviews the advantages and disadvantages of terminating the BP with the client. The BP can only be terminated without contacting the client if it is clearly to the client’s advantage. When a client decides to terminate the BP, the decision is final, and cannot be reversed.

**Conditions to terminate a benefit period (BP)**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2174.dita) 

A BP can be terminated when a new BP can be established. To establish a new BP, there must be an interruption of earnings (I of E) in the qualifying period (QP) before the new BPC. 

### Claims with a BPC between w/c 2310 and w/c 2361

Source topic: `en_EN/task/benefit_period_term/claims_with_a_bpc_between_wc_2310_and_wc_2361.dita`

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is required only on contentious reasons for separation (RFSs) on the most recent ROE in the QP.

The officer can terminate the claim to establish a new initial claim with a BPC between w/c 2310 and w/c 2361 if the following conditions are met:

- The client has a BPC in the above range.

- The client has an indefinite disqualification, but has worked enough hours in insurable employment since the BPC to establish a new claim.

- The RFS since the disqualification is either non-contentious or was adjudicated and allowed.

If all these conditions are met, the officer can establish a new claim using the ROEs from all periods of employment in the BP. This is because the indefinite disqualification imposed no longer applies. On a new initial claim, that ROE is no longer the last period of employment and is automatically included in the calculation of a new claim.

In this situation, it is advantageous for the client to terminate the BP and establish a new claim.

**Terminating a claim retroactively**

When a client submits a retroactive request in a timely manner, the request is considered as having been made before the BP was renewed or the disentitlement was terminated. A request is considered to be filed in a timely manner if it is submitted within the 30-day period following the date the claim is finalized or the end of the disentitlement. A request filed after the 30-day period is referred to Level 2 to determine if there is good cause for the delay. If there is good cause for the delay, the request is considered as having been made in a timely manner. When the conditions for the retroactive request are met and a new BP is established, any weeks of benefits paid on or after the new BPC are considered as paid on the new BP.

**Refusing to terminate a claim when there is no new benefit period (BP)**

If the client requests the termination of the BP but cannot or does not want to establish a new BP, the officer does not terminate the BP.

**Qualifying for the new benefit period (BP)**

Before terminating a BP, the officer ensures that the client qualifies for the new BP. A variety of calculators are available to determine this (e.g. the Benefit Rate Calculation Tool or the SSA Tutorial Calculator). If necessary, the officer can use a calculation worksheet . If the client does not qualify on the new BP, the officer does not terminate the old BP.
       [Benefit Rate Calculation Tool](http://wecs-siew.prv/wecs-siew/benefitcalc_e.aspx) 
       [calculation worksheet](/resources/ort/documents/calc_worksheet.xls)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2155.dita) 

**Qualifying for a new benefit period (BP) with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment is required to establish a claim for regular or special benefits. If the client has a violation on file, increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the definitions for major attachment claimant and minor attachment claimant in subsection 6(1) of the Employment Insurance Act are repealed. All claims established with 420 hours of insurable employment qualify for special benefits. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Pilot project no. 24: Waiving the waiting period (WP) for BPCs between March 30 andOctober 10, 2026 (w/c 2493 to w/c2572)

Source topic: `en_EN/task/benefit_period_term/pilot_project_no_24_waiving_the_waiting_8da3a05b.dita`

A temporary measure to waive the one-week WP has been implemented to support clients impacted by major changes in economic conditions due to the imposition of tariffs by the United States. The WP is waived for all initial claims with a BPC between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ), regardless of the requested benefit type (BT). If it is advantageous to the client, the client can decide to serve the WP (e.g. the client must serve the WP to receive supplemental unemployment benefits [SUB]).

A client who established a new EI claim within the last 52 weeks and still has weeks payable on that claim can decide to renew the existing claim or request to terminate the existing claim to submit a new claim under Pilot Project 24. Existing policies for terminating a benefit period (BP) apply and clients who request a termination instead of a renewal must meet the conditions to terminate a claim.

For more information, the officer refers to Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions .
       [Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions](/en/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml) 

### Advantages and disadvantages of terminating a benefit period (BP)

Source topic: `en_EN/task/benefit_period_term/advantages_and_disadvantages_of_termina_36fdc285.dita`

Terminating a BP can be advantageous to a client because the new BP could be established with a higher number of hours or earnings. The new BP could also allow a client to qualify for additional benefits or to requalify after a pension is allocated as earnings.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2175.dita) 

**Assessing the client’s situation**

The following is a non-exhaustive list of elements to assess before determining if terminating the BP is advantageous for the client:

- The end of the BP has not been reached.

- The client remains major attached (has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment and may be eligible for special benefits.

- The client will become eligible for benefits again.

- The client still qualifies.

- The BP duration will be longer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2176.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2177.dita) 

**Advantageous situations**

The following are situations that are clearly to the client’s advantage if the client is applying for a new claim:

- An indefinite disqualification has been imposed in the BP, the client is applying for regular benefits, and the client has worked enough hours to requalify.

- The BPC is between w/c 2310 and w/c 2361, an indefinite disqualification has been imposed in the BP, the client is applying for regular benefits, the RFS after the disqualifying event is either non-contentious or was adjudicated and allowed, the new BPC to be established is between w/c 2310 and w/c 2361 and the client has worked enough hours since the BPC to establish a new claim.

- An indefinite disqualification has been imposed in the BP, and the client is requesting to terminate the BP for a regular claim in favour of a fishing claim.

- A client is minor attached, but has worked enough hours to qualify for special benefits.

- A client is subject to a pension allocation that prevents payment of benefits, and has worked enough hours to requalify.

- A client has exhausted all entitlement to any type of special benefits, and has worked enough hours to qualify for additional special benefits.

**Disadvantages of terminating a benefit period (BP)**

A BP termination can also cause certain disadvantages. By terminating the BP and establishing a new BP, the QP may contain fewer earnings. As a result, the client could receive a lower benefit rate or fewer entitlement weeks compared to a BP renewal followed by the establishment of a new BP. The officer assesses these possibilities.

**Discussing with the client**

When it is not clearly to the client’s advantage, the following advantages and disadvantages must be discussed with the client:

- There is a pension allocation and the client may become requalified (when the pension allocation may not have prevented payment on the existing BP).

- The benefit rate can be increased or decreased.

- Weeks of entitlement can be increased or decreased.

- The duration of the BP can be increased.

- A new WP must be served on the new BP, unless it can be waived or deferred.

- If a definite disqualification has been imposed, it may be carried forward to the new BP.

- If the BP is for special benefits, the new BP may affect the windows and entitlement to these benefits.

- A client that is major attached on an existing BP may be minor attached on a new BP, or vice versa.

- The client may be subject to an increased entrance requirement on the new BP.

- The decision to terminate the BP is final, and cannot be reversed. 

### Notifying the client

Source topic: `en_EN/task/benefit_period_term/notifying_the_client.dita`

If the officer terminates the BP without speaking to the client, the officer must notify the client of the termination by letter and include reconsideration rights. 

### Inputting a benefit period (BP) termination

Source topic: `en_EN/task/benefit_period_term/inputting_a_benefit_period_bp_termination.dita`

The inputs to terminate a BP depend on whether the termination is retroactive.

- If the termination is not retroactive, the BP is terminated with:

- an M149 - Initial Intake Data (M149) transaction if the renewal week has not been input;

- a File Control Data (M101) transaction type 7 (M101-7) if the renewal week has been input.

- If the termination is retroactive, the officer terminates the BP with an M101-7 if weeks have not been processed. If weeks have been processed, the officer also creates the following:

- an IPOC Review (IPOC REV) WI if weeks have not been paid on the existing BP after the renewal week or after the disentitlement was terminated;

- an Operational Centre Memo (MM06) transaction if benefits have been paid on the existing BP after the renewal week or after the disentitlement was terminated.

When the officer retroactively terminates a BP on which weeks have been processed after the renewal week or after the disentitlement was terminated, an OP is created for the weeks that will be payable during the new BP. Once the OP has been established, the officer inputs an agreed deduction in PSCD equal to the benefit rate amount. For more information, the officer refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2152.dita`

Note:

While the inputs to terminate or cancel a BP are the same, it is important to understand the distinction between terminating and cancelling a BP. The result of the input and the effect on the client are different. If the appropriate action to take is unclear, the officer refers to Cancelling, voiding, terminating or withdrawing a claim before proceeding.
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml)

     [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml) 

### Example

Source topic: `en_EN/common_notes/note_c_2173.dita`

Example:

Marcy established a BP before returning to work. She worked for 5 months, was laid off and then applied for benefits. The BP was renewed and Marcy received a notice of the renewal. Shortly after receiving the notice of renewal, she requested a new BP be established instead of renewing the existing BP. This is a retroactive request. 

### Note

Source topic: `en_EN/common_notes/note_c_2174.dita`

Note:

Before terminating a BP, the officer first considers cancelling the BP. The officer can refer to Cancelling a benefit period .
       [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml)

     [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2155.dita`

Note:

To qualify for fishing benefits, the client must not qualify for regular (non-fishing) benefits. A client who qualifies for regular (non-fishing) benefits does not qualify for fishing benefits. 

### Example

Source topic: `en_EN/common_notes/note_c_2175.dita`

Example:

Gunther established a BP and received 2 weeks of benefits at a rate of $130 per week. He then found new employment with significantly higher hourly wages than his previous employment. However, after working 6 months at this new job, he was laid off. Gunther submits a new application for benefits and a CA WI is created. He can renew the old BP but he has worked enough hours to qualify for a new BP. Because of the higher hourly wage, he would be eligible for a higher benefit rate on the new BP if the old BP is terminated in favour of a new BP. The officer reviewing the CA WI discusses the advantages and disadvantages of a BP termination with Gunther. If the officer cannot contact him, the existing BP is renewed. 

### Note

Source topic: `en_EN/common_notes/note_c_2176.dita`

Note:

When assessing whether it is advantageous to terminate a claim with a BPC between w/c 2310 and w/c 2361, the officer considers that the Budget 2021 temporary measures will not apply to new initial claims with a BPC in w/c 2362 or later. Therefore, the officer compares the current renewable claim and the potential new claim by considering the CER, the allocation of separation monies, the weeks of entitlement, the benefit rate, and the adjudication of contentious RFS issues. 

### Note

Source topic: `en_EN/common_notes/note_c_2177.dita`

Note:

The variable best weeks (VBW) questions are not presented on a renewal application. When the BP is being terminated, if it is not evident that the benefit rate will reach its maximum and if the client has not submitted the VBW information, the officer gives the client the opportunity to provide it. 

## Regional considerations

Source topic: `en_EN/task/benefit_period_term/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/benefit_period_term/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/benefit_period_term/in_nws.dita`

- Is there documentation on file regarding the request for termination?

- Has the client submitted a renewal claim?

- Is this a retroactive request?

- If yes, what is the date of the retroactive request?

- Is there documentation of verbal notice regarding the end of the disentitlement (e.g. an SROC or ROD)?

- Has a Claimant Attestation — Highest Weeks of Insurable Earnings (Variable Best Weeks) (INS5241) form been received?
         [Claimant Attestation — Highest Weeks of Insurable Earnings (Variable Best Weeks) (INS5241)](http://forms-formulaires.prv/lc/content/EForms/en/Index.html) 

### In FTS:

Source topic: `en_EN/task/benefit_period_term/in_fts.dita`

- Have weeks of benefits been paid?

- Has a renewal week been input?

- What is the BT?

- If the BP is for special benefits, what are the special benefit windows?

- What is the benefit rate?

- What is the last renewable week (LRW) in the BP?

- What is the remaining entitlement in the BP?

- Are there any ongoing allocations?

- Are there any disqualifications or disentitlements in the BP?

- Has the WP been served, waived or deferred?

- Is the client major or minor attached?

- If this is a retroactive request, were payments made between the BPC and:

- the renewal week?

- the end of the disentitlement? 

## Step by step

Source topic: `en_EN/task/benefit_period_term/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/benefit_period_term/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/benefit_period_term/reviewing_the_file_level_1.dita`

- Determine if IPOC created a Reminder (REM) WI indicating a new BP can now be established:

- If no, go to step 2.

- If yes, go to Terminating a claim retroactively .
               [Terminating a claim retroactively](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#RetroactiveRequest)

- In NWS, review the WI to determine if the client wants a regular BP in favour of a fishing BP:

- If the client does not want to terminate a regular BP in favour of a fishing claim, go to step 3.

- If the client wants to terminate a regular BP in favour of a fishing BP, determine if there is an indefinite disqualification on the regular BP:

- If yes, go to step 3.

- If no, go to Benefit period (BP) not terminated .
                   [Benefit period (BP) not terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#BPnotterminated)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2160.dita)

- Determine if this is a retroactive request that was filed after the 30-day period:

- If yes, go to step 4.

- If no, go to step 9.

- Determine if there is a Level 2 ROD regarding the retroactive request:

- If yes, go to step 8.

- If no, create a Claim Review (CR) Revised WI as follows:

- Type: Select Revised .

- Issue: Select Entitlement .

- Registration number: Enter the revised registration number.

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Select the Service Canada Centre (SCC) as shown in FTS.

- BPC: Enter the BPC.

- Date of registration: Enter the revised registration date.

- Create a client Note and type: “CR Revised WI created today. The issue requiring adjudication is claim procedure — delay in requesting claim termination.”

- Move the Level 1 WI related to the claim termination to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for adjudication of good cause.”

- Bring forward date: Enter today’s date + 10 business days.

- When the Level 1 WI related to the claim termination moves to the current workload, determine if there is a Level 2 ROD for adjudication of the delay in submitting the retroactive request:

- If no, return to step 6.

- If yes, go to step 8.

- Determine if good cause for the delay has been allowed:

- If yes, go to step 9.

- If no, go to Benefit period (BP) not terminated .
               [Benefit period (BP) not terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#BPnotterminated) 

#### Determining if the client qualifies for benefits on a new claim

Source topic: `en_EN/task/benefit_period_term/determining_if_the_client_qualifies_for_1d8c088f_level_1.dita`

- Determine if all the information is on file to establish whether the client qualifies for benefits on a new claim (e.g. an application, all ROEs):

- If no , go to step 10.

- If yes, go to step 17.

- Contact the client for fact finding :

- Ask if the client intends to apply for a new claim.

- Obtain from the client the missing information required to determine if the client qualifies for benefits on a new claim.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2178.dita)

- Determine if the client was contacted during fact-finding:

- If client was contacted, go to step 12.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Benefit period (BP) not terminated .
               [Benefit period (BP) not terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#BPnotterminated)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- BPC: Type the BPC.

- Main Issue: Select Other .

- Comments: Type “BP termination.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the required information was obtained:

- If no, go to step 14.

- If yes, go to step 17.

- Determine if the client indicated that the required information will be submitted:

- If yes, go to step 15.

- If no, go to Benefit period (BP) not terminated .
               [Benefit period (BP) not terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#BPnotterminated)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for the client to submit information.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if the required information has been received:

- If yes, go to step 17.

- If no, go to Benefit period (BP) not terminated .
               [Benefit period (BP) not terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#BPnotterminated)

- Determine if the client qualifies to establish a new BP (refer to the applicable Calculating or recalculating a claim activity):

- If yes, go to step 18.

- If no, go to Benefit period (BP) not terminated .
               [Benefit period (BP) not terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#BPnotterminated)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2160.dita) 

#### Reviewing advantages and disadvantages

Source topic: `en_EN/task/benefit_period_term/reviewing_advantages_and_disadvantages_level_1.dita`

- Determine if it is clearly to the client’s advantage to terminate the BP.

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2179.dita) 

- If any of the conditions apply, go to step 19.

- If none of the conditions applies, go to step 20.

- In NWS, create a ROD as follows:

- BPC: Enter the BPC.

- Comments: Type “Termination of BPC [BPC].”

- Details: Type “BPC [BPC] terminated. The client was not contacted as termination is to the client’s advantage.”

- Go to step 24.

- Contact the client and review the advantages and disadvantages of terminating a claim, including the following. Refer to Fact finding .

- The decision to terminate a BP is final and cannot be reversed.

- A new WP must be served on the new BP unless it is waived or deferred.

- The decision to terminate the BP cannot be appealed once it has been input.

- No letter will be sent to advise the client of the termination.

- Remind the client to submit all ROEs as soon as possible, if they have not yet been submitted.

- If the client did not provide the VBW information and it is not evident that the benefit rate will reach its maximum, use the Variable Best Weeks: INS5241 Highest weeks of insurable earnings client attestation — Form and obtain the VBW information. If the client cannot be contacted by phone at this point, in ACS, create and send the Q-01-00-00 letter, which allows the client to complete and return the form.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2180.dita)

- Determine if the client was contacted during fact-finding:

- If yes, go to step 22.

- If no, go to Benefit period (BP) not terminated .
               [Benefit period (BP) not terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#BPnotterminated)

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- BPC: Type the BPC.

- Main Issue: Select Other .

- Comments: Type “Termination request.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy . Also type “The client was advised of the advantages and disadvantages of termination. The client was also told that the decision is final and cannot be reversed, and that no letter will be sent.”
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client still wants to terminate the BP in favor of a new one:

- If the client wants to terminate the BP, go to step 24.

- If the client no longer wants to terminate the BP, go to Benefit period (BP) not terminated .
               [Benefit period (BP) not terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#BPnotterminated) 

#### Inputs to finalize the termination

Source topic: `en_EN/task/benefit_period_term/inputs_to_finalize_the_termination_level_1.dita`

- Determine if the termination is for weeks of benefits that have been processed after a renewal week or after a disentitlement was terminated:

- If no, go to step 25.

- If yes, go to Terminating a claim retroactively .
               [Terminating a claim retroactively](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#RetroactiveRequest)

- In FTS, determine if the renewal week has been input:

- If no , go to step 26.

- If yes, go to step 28.

- In SSO, on the Registration screen, update the claim type as follows:

- Decision Type: Select Initial .

- Go to step 27.

- On the M149 - Initial Intake Data screen, update the tentative BPC as follows:

- Tent BPC: Enter the BPC of the initial claim to be established.

- Term: “D”.

- Select 4 to transmit the information .

- Go to step 30.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2181.dita)

- In FTS, on the File Control Data (M101) — Claim Action screen, do the following:

- Select Terminate benefit period (M101-7) .

- Select Update .

- In SSO, verify if the correct mainframe is selected and register a new initial claim as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Initial .

- Select Search .

- Review the Name and Address screen:
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2168.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2182.dita) 

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region-new and Economic region-old : The information is prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: Select the appropriate option:

- If the field is blank, enter the SCC based on the client’s address on the application.

- For a commuter claim, enter the SCC associated with the workplace postal code.

- Tax credit: This field is prefilled based on the client’s information.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Ensure that the SCC number is the same as shown in FTS. If the field is blank, enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: If not prefilled, determine the BPC based on the client’s last day worked (LDW) and application date.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select No .
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2170.dita)

- Determine if the client was contacted during fact-finding:

- If no, go to step 31.

- If yes, go to step 32.

- In ACS, create and send the N-06-00-00 letter, completing the appropriate attributes.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2183.dita)

- In NWS, determine if an AI WI or Call Back (CB) WI was created for the termination request:

- If yes, complete the WI and go to step 33.

- If no, go to step 33.

- Determine the BT requested for the calculation:

- If the BT is regular, refer to Calculating or recalculating a claim for regular benefits .
               [Calculating or recalculating a claim for regular benefits](/en/procedure/activity/calculation.shtml)

- If the BT is sickness, refer to Calculating or recalculating a claim for sickness benefits .
               [Calculating or recalculating a claim for sickness benefits](/en/procedure/activity/calc_sick.shtml)

- If the BT is sickness, maternity and parental, refer to Calculating or recalculating a claim for sickness, maternity and parental benefits.
               [Calculating or recalculating a claim for sickness, maternity and parental benefits.](/en/procedure/activity/calc_sick_mat_par.shtml)

- If the BT is maternity and parental, refer to Calculating or recalculating a claim for maternity and parental benefits .
               [Calculating or recalculating a claim for maternity and parental benefits](/en/procedure/activity/calc_mat_par.shtml)

- If the BT is parental, refer to Calculating or recalculating a claim for parental benefits .
               [Calculating or recalculating a claim for parental benefits](/en/procedure/activity/calc_par.shtml)

- If the BT is compassionate care, refer to Calculating or recalculating a claim for CCB .
               [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml)

- If the BT is family caregiver benefits, refer to Calculating or recalculating a claim for family caregiver benefits .
               [Calculating or recalculating a claim for family caregiver benefits](/en/procedure/activity/calc_pcic_benefit.shtml) 

#### Terminating a claim retroactively

Source topic: `en_EN/task/benefit_period_term/terminating_a_claim_retroactively_level_1.dita`

- Determine if IPOC created a Reminder (REM) WI indicating a new BP can now be established:

- If no, go to step 2.

- If yes, go to step 11.

- In FTS, select the File Control Data (M101) - Claim Action transaction and do the following:

- Select Cancel benefit period (M101-7) .

- Select Update .

- Determine if weeks of benefits have been paid after the renewal week or after the disentitlement was terminated:

- If no, go to step 4.

- If yes, go to step 5.

- In NWS, create an IPOC REV WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate language.

- Destination — SCC: Select the IPOC based on the region in which the claim is located in FTS:

- Atlantic: 1826

- Quebec: 2642

- Ontario: 3056

- Western Canada and Territories: 5903

- End User: Select Next available user .

- Issue: Select Pay history summary adjustment .

- BPC: Enter the BPC of claim to be cancelled.

- Comments: Type “Retroactive termination of a BP.”

- Details: Type “Weeks processed on BPC [BPC of the BP to terminate] to be processed on a new BP. Remove from the PHS w/c [w/c the BP was renewed or payable due to the termination of a disentitlement] to w/c [w/c of last week processed]. Advise the Level 1 officer with REM WI when complete.”

- Obtained by: Select the appropriate method.

- Obtained from: Select the appropriate source.

- Source details: Enter the source details.

- Select Save .

- Go to step 9.

- In FTS, determine if a revised registration number exists:

- If yes, go to step 6.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the BP to be terminated.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 35 - Claim Cancellation .

- Remarks line 1 to 4: Type “Benefits paid on BPC [BPC of the BP to terminate] to be paid on a new BP. Remove from the PHS w/c [w/c the BP was renewed or payable due to the termination of a disentitlement] to w/c [w/c of last week processed] and establish an OP for those weeks. Advise adjudicator with REM WI when complete.”

- Remarks line 5: Enter your first name and last name.

- Detection: Select 31 - Other new facts- entitlement review .

- Infraction: Select F - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In FTS, select the Registration Number (M025, M030, M035) transaction and change the registration flag as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for BP termination by IPOC.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI related to the retroactive request moves to the current workload, determine if IPOC created a REM WI:

- If no, return to step 9.

- If yes, go to step 11.

- Determine if IPOC established an OP for the weeks removed:

- If yes, go to step 12.

- If no, go to step 13.

- Input an agreed deduction equal to the benefit rate amount. For more information, refer to Applying an agreed deduction in PSCD .

- In SSO, verify if the correct mainframe is selected and register a new initial claim as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Initial .

- Select Search .

- Review the Name and Address screen:
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2168.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2182.dita) 

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region-new and Economic region-old : The information is prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: Select the appropriate option:

- If the field is blank, enter the SCC based on the client’s address on the application.

- For a commuter claim, enter the SCC associated with the workplace postal code.

- Tax credit: This field is prefilled based on the client’s information.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Ensure that the SCC number is the same as shown in FTS. If the field is blank, enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: If not prefilled, determine the BPC based on the client’s last day worked (LDW) and application date.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select No .
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2170.dita)

- In ACS, create and send the N-06-00-00 letter, completing the appropriate fields.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2183.dita)

- In NWS, determine if there is an AI WI or a CB WI:

- If yes, complete the WI and go to step 16.

- If no, go to step 16.

- When the REM WI is received, determine the BT requested for the calculation:

- If the BT is regular, refer to Calculating or recalculating a claim for regular benefits .
               [Calculating or recalculating a claim for regular benefits](/en/procedure/activity/calculation.shtml)

- If the BT is sickness, refer to Calculating or recalculating a claim for sickness benefits .
               [Calculating or recalculating a claim for sickness benefits](/en/procedure/activity/calc_sick.shtml)

- If the BT is sickness, maternity and parental, refer to Calculating or recalculating a claim for sickness, maternity and parental benefits.
               [Calculating or recalculating a claim for sickness, maternity and parental benefits.](/en/procedure/activity/calc_sick_mat_par.shtml)

- If the BT is maternity and parental, refer to Calculating or recalculating a claim for maternity and parental benefits .
               [Calculating or recalculating a claim for maternity and parental benefits](/en/procedure/activity/calc_mat_par.shtml)

- If the BT is parental, refer to Calculating or recalculating a claim for parental benefits .
               [Calculating or recalculating a claim for parental benefits](/en/procedure/activity/calc_par.shtml)

- If the BT is compassionate care, refer to Calculating or recalculating a claim for CCB .
               [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml)

- If the BT is family caregiver benefits, refer to Calculating or recalculating a claim for family caregiver benefits .
               [Calculating or recalculating a claim for family caregiver benefits](/en/procedure/activity/calc_pcic_benefit.shtml) 

#### Benefit period (BP) not terminated

Source topic: `en_EN/task/benefit_period_term/benefit_period_bp_not_terminated_level_1.dita`

- In FTS, determine if there is an outstanding revised registration number on file for the termination request:

- If yes, go to step 2.

- If no, go to step 3.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claims Allowed: Select NCA - No changes to the claim .

- Contentious: Select the appropriate option:

- If the decision was made at Level 1, select 1 - No .

- If the decision was referred to Level 2, select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NWS, determine if there is a Level 2 ROD denying a retroactive termination:

- If no, go to step 4.

- If yes, go to step 7.

- In NWS, create a ROD as follows:

- BPC: Enter the BPC.

- Comments: Type “Termination of the BPC [BPC].”

- Details: Type “BPC [BPC] not terminated.” Include the reason the BP was not terminated (e.g. client does not qualify on new BP, unable to contact the client to discuss advantages and disadvantages).

- Determine if the client requested the BP termination:

- If no, go to step 7.

- If yes, determine if the client was verbally advised that the BP is not being terminated:

- If the client was not verbally advised, go to step 6.

- If the client was verbally advised, go to step 7.

- In ACS, create and send an F-00-00-00 letter, advising the client of the decision:

- In the Free text (1612) field, type one of the following:

- If the client does not qualify to establish a new BP and the new BT requested is fishing benefits, type “We are writing to inform you that we cannot terminate your claim for Employment Insurance (EI) benefits that began on [BPC of the existing BP], because you do not qualify to establish a new one. As stated in Section 8 of the EI Fishing Regulations, in order to establish a claim for fishing benefits, a client must not qualify for regular non-fishing EI benefits. As a result, it is not possible to terminate a benefit period for regular benefits in favour of a benefit period for fishing benefits.”

- If the client does not qualify to establish a new BP and the new BT requested is not fishing benefits, type “We are writing to inform you that we cannot terminate your claim for Employment Insurance benefits that began on [BPC of the existing BP], because you do not qualify to establish a new one.”

- If the client was not reached to discuss the advantages and disadvantages, type “We are writing to inform you that we cannot terminate your claim for Employment Insurance benefits that began on [BPC of the existing BP], as we were unable to reach you to review the advantages and disadvantages of ending the benefit period.”

- In NWS, determine the type of WI:

- If the WI is an AI or CB WI, complete the WI.

- If the WI is a CA, SA or CR WI, refer to the appropriate Conversion and renewal procedure.
               [Conversion and renewal](/en/procedure/activity/conversions.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2160.dita`

Note:

A client who qualifies for regular (non-fishing) benefits does not qualify for fishing benefits. 

#### Note

Source topic: `en_EN/common_notes/note_c_2178.dita`

Note:

It may also be necessary to review the advantages and the disadvantages. Notify the client that an officer may call again if the client qualifies for benefits on the new claim. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2179.dita`

Conditions under which it is clearly to the client’s advantage to terminate the BP

- An indefinite disqualification has been imposed on the BP, the client is applying for regular benefits, and the client has worked enough hours to requalify.

- The BPC is between w/c 2310 and w/c 2361, an indefinite disqualification has been imposed on the BP, the client is applying for regular benefits, the RFS after the disqualifying event is either non-contentious or was adjudicated and allowed, the new BPC to be established is between w/c 2310 and w/c 2361 and the client has worked enough hours since the BPC to establish a new claim.

- The client is minor attached but has worked sufficient hours to qualify for special benefits.

- The client is subject to a pension allocation that prevents payment of benefits and has worked sufficient hours to requalify.

- The client has exhausted all entitlement to any type of special benefits and has worked sufficient hours to qualify for additional special benefits. 

#### Note

Source topic: `en_EN/common_notes/note_c_2180.dita`

Note:

As a temporary measure under Pilot Project No. 24, the WP is waived on all BPCs between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). A client who established a new EI claim within the last 52 weeks and still has weeks payable on that claim can decide to renew the existing claim or request to terminate the existing claim to submit a new claim under Pilot Project 24.

For more information, the officer refers to Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions .
       [Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions](/en/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml)

     [Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions](/en/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2181.dita`

Note:

If the M149 - Initial Intake Data screen cannot be transmitted, do the following:

- In SSO, select Store to save the information.

- Exit from the SIN file in SSO before proceeding.

- In FTS, select the transaction Initial Intake (M149) and do the following:

- Terminate previous claim: Check the box.

- Tentative BPC: Enter the BPC of the initial claim to be established.

- Select Update to transmit the information.

- Go to step 30. 

#### Note

Source topic: `en_EN/common_notes/note_c_2168.dita`

Note:

The information from the application in NWS is automatically downloaded in SSO. In rare cases, the information is not downloaded and must be manually input. Verify (and correct, if necessary) any prefilled fields with the information provided on the application. 

#### Note

Source topic: `en_EN/common_notes/note_c_2182.dita`

Note:

When the client has only one name, one of the name fields on the Name and Address screen may be empty or contain a non-alphabetical character. However, SSO does not allow the field to be completed in this way.

When a name field is empty or contains a non-alphabetical character, do the following:

- First Name: Enter the appropriate option:

- For a client who selects the Male gender marker, type “Mr.”

- For a client who selects the Female gender marker, type “Ms.”

- For a client who selects the X gender marker, type “N.A.”

- Last Name: Enter the client’s name.

When the First Name field on the Name and Address screen is modified to “N.A.”, modify the M149 - Initial Intake Data (M149) or M159 - Name and Address Change / Transfer (M159) transaction generated by the calculation and type a “.” in the First Name field before inputting it. 

#### Note

Source topic: `en_EN/common_notes/note_c_2170.dita`

Note:

The M149 - Initial Intake Data (M149) transaction cannot be input on the same day as the File Control Data (M101) transaction type 7 (M101-7). 

#### Note

Source topic: `en_EN/common_notes/note_c_2183.dita`

Note:

Do not select the Right to Request a Reconsideration option as the decision to terminate the BP is final and cannot be reversed. 

### Level 2

Source topic: `en_EN/task/benefit_period_term/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/benefit_period_term/reviewing_the_file_level_2.dita`

- Determine if additional information is required to determine if the client showed good cause for the delay in filing the retroactive termination request:

- If yes, go to step 2.

- If no, go to step 5.

- Fact-find with the client to obtain the reason for the delay in requesting the retroactive termination of the BP. Refer to Digest 3 — Antedate to determine questions to ask the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Denying a retroactive termination .
               [Denying a retroactive termination](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#RetroactiveTermination)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows::

- Main Issue: Select Other .

- Comments: Type “Reason for delay in retroactive termination.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Based on a review of all information provided on file and in accordance with the Act, Regulations and jurisprudence, determine if there is good cause for the delay. Refer to Digest 3 — Antedate .

- If there is good cause, go to step 6.

- If there is no good cause, go to Denying a retroactive termination .
               [Denying a retroactive termination](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_term#RetroactiveTermination)

- In NWS, create a ROD as follows:

- Comments: Type “Retroactive termination — Good cause for the delay in applying for claim termination.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In NWS, determine if there is a Level 1 WI associated with the termination request:

- If yes, go to step 9.

- If no, create a CR Revised WI as follows:

- Type: Select Revised .

- Issue: Select Calculation .

- Registration number: Enter the revised registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- BPC: Enter the BPC.

- Date of registration: Enter the date of the revised registration.

- Create a client Note and type: “CR Revised WI created today. Good cause was shown for the delay in requesting the claim termination. The Level 1 officer can proceed with determining if the client meets the conditions to allow the claim termination.”

- In NWS, complete the Level 2 WI. 

#### Denying a retroactive termination

Source topic: `en_EN/task/benefit_period_term/denying_a_retroactive_termination_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Retroactive termination denied.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In ACS, create and send the N-06-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Denial of the claimant’s request to terminate a claim: Select No good cause for being late (2701) .

- BPC date - Sunday’s date (1060)

- Date of claimant’s request to cancel or terminate claim (1462)

- Select Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, complete the Level 2 WI. 

## Policy reference

Source topic: `en_EN/task/benefit_period_term/policy_reference.dita`

- BE Memo 2010-03 – Automatic Renewal of Existing Claim
         [BE Memo 2010-03 – Automatic Renewal of Existing Claim](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2010-03.shtml)

- Digest 1.4.4 — Early termination
         [Digest 1.4.4 — Early termination](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-1/benefit-period-structure.html#a1_4_4)

- Digest 1.4.5 — Cancellation
         [Digest 1.4.5 — Cancellation](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-1/benefit-period-structure.html#a1_4_5)

- Digest 3 — Antedate
         [Digest 3 — Antedate](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-3/table-of-contents.html)

- EIA 10
         [EIA 10](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-10.html)

- BE 2016-02 — Bill C-15 Additional weeks of benefits
         [BE 2016-02 — Bill C-15 Additional weeks of benefits](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2016-02.shtml) 
