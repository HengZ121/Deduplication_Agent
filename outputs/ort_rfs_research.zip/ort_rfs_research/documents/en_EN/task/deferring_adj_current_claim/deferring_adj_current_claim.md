# Deferring adjudication: Client not requesting benefits

Source map: `en_EN/task/deferring_adj_current_claim/deferring_adj_current_claim.ditamap`

## Summary

Source topic: `en_EN/task/deferring_adj_current_claim/summary.dita`

Summary: In certain situations, adjudication of a contentious reason for separation (RFS) can be deferred on an established claim if the client is not requesting benefits from the week of the contentious RFS. 

## What you need to know

Source topic: `en_EN/task/deferring_adj_current_claim/what_you_need_to_know.dita`

### Conditions

Source topic: `en_EN/task/deferring_adj_current_claim/conditions.dita`

Officers can receive information on a new contentious RFS from the call centre, an employer or a third party.

When receiving information on a contentious RFS for an established claim, whether active or dormant, and clients are not requesting benefits, the officer must first determine if adjudication can be deferred. As the claim is already established and there is a possibility that clients may receive benefits that they are not entitled to, deferral of adjudication can only be authorized when the following 2 conditions are met:

- The contentious RFS does not impact any period for which benefits have already been paid.

- The client is not requesting benefits for any period after the contentious RFS.

If these conditions are met, the contentious RFS is adjudicated only if the client later requests regular benefits or submits a new claim.

**Determining if the client is not requesting benefits**

The first condition to allow the deferral of adjudication of a new contentious RFS on an established claim is that the client is not requesting benefits. There are indications on file that show the client is not requesting benefits. These include:

- The Failure to report box is checked.

- The Return to work field displays a date.

- There is no renewal application and no new application on file.

- A 10 - Dismissal - misconduct proven (D10) or 11 - Voluntary leaving - just cause not proven (D11) disqualification has been imposed as a result of adjudication.

- The claim is established BPNE 1 or 5.

**Contentious RFS does not impact benefits already been paid**

The second condition to allow deferral of adjudication on a current established claim is that the contentious RFS does not impact any period for which benefits have already been paid. The contentious RFS must occur after the client stops receiving benefits.

If the contentious RFS occurs before the client stops receiving benefits or if it impacts benefits that have already been paid, the officer cannot defer adjudication of any contentious RFS. 

### Special condition field in RCM

Source topic: `en_EN/task/deferring_adj_current_claim/special_condition_field_in_rcm.dita`

When adjudication is deferred, the officer must select Adjudication deferred in the Special condition field of the applicable ROE in RCM if the ROE is on file. 

### Deferring adjudication when the ROE is not on file

Source topic: `en_EN/task/deferring_adj_current_claim/deferring_adjudication_when_the_roe_is__0f07e548.dita`

If all conditions are met, adjudication of a contentious RFS can be deferred even if the ROE is not on file. 

### Record of decision (ROD) — Creation

Source topic: `en_EN/task/deferring_adj_current_claim/record_of_decision_rod__creation.dita`

The officer must create a ROD in NWS for the deferral. 

### Communicating the decision

Source topic: `en_EN/task/deferring_adj_current_claim/communicating_the_decision.dita`

The client is not verbally notified of the deferral and no letter is sent regarding the deferral since the client is not requesting benefits. 

### Stop payment

Source topic: `en_EN/task/deferring_adj_current_claim/stop_payment.dita`

When a contentious condition exists that requires a decision, a 1 - General suspension of benefits (stop payment) manual action (MA1) or a 75 - Verification of reason for termination of Employment manual action (MA75) can be input to stop payment. If the client is not requesting benefits at the time, the stop payment can be removed. 

## Regional considerations

Source topic: `en_EN/task/deferring_adj_current_claim/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/deferring_adj_current_claim/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/deferring_adj_current_claim/in_fts.dita`

- Is the Failure to report box checked?

- Is there a date in the Return to work date field?

- Is an MA1 or MA75 to stop payment imposed?

- Has a D10 or D11 been imposed because of adjudication of the file?

- Have benefits been paid after the non-adjudicated RFS?

- Is the claim BPNE 1 or 5?

- Has the last renewable week (LRW) been reached? 

### In NWS:

Source topic: `en_EN/task/deferring_adj_current_claim/in_nws.dita`

- Has the client submitted a renewal application?

- Has the client submitted an application for a new claim? 

### In RCM:

Source topic: `en_EN/task/deferring_adj_current_claim/in_rcm.dita`

- Is the ROE on file? 

## Step by step

Source topic: `en_EN/task/deferring_adj_current_claim/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/deferring_adj_current_claim/level_1.dita`

#### Determining if the criteria are met

Source topic: `en_EN/task/deferring_adj_current_claim/determining_if_the_criteria_are_met_level_1.dita`

- In FTS, determine if the contentious RFS impacts a previous BPC:

- If no, go to step 2.

- If yes, adjudication cannot be deferred. Return to the previous task.

- Determine if the LRW has been reached:

- If no, go to step 3.

- If yes, go to step 9.

- Determine if the claim is BPNE 1 or 5:

- If no, go to step 4.

- If yes, go to step 9.

- Determine if the contentious RFS occurred after the BPC was established:

- If yes, go to step 5.

- If no, adjudication cannot be deferred. Return to the previous task.

- Determine if the contentious RFS impacts a period for which benefits have already been paid on the claim:

- If no, go to step 6.

- If yes, adjudication cannot be deferred. Return to the previous task.

- Determine if the Failure to report box is checked:

- If no, go to step 7.

- If yes, go to step 9.

- Determine if there is a date in the Return to work date field:

- If no, go to step 8.

- If yes, go to step 9.

- Determine if a D10 or D11 has been imposed as a result of adjudication:

- If yes, go to step 9.

- If no, adjudication cannot be deferred. Return to the previous task.

- In NWS, determine if one of the following conditions is met:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3064.dita)

- Determine if the client has submitted a new initial application for benefits:

- If no, go to Inputting the decision .
               [Inputting the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/deferring_adj_current_claim#level1_item_2)

- If yes, adjudication cannot be deferred. Return to the previous task. 

#### Inputting the decision

Source topic: `en_EN/task/deferring_adj_current_claim/inputting_the_decision_level_1.dita`

- In NWS, create a ROD for the contentious RFS that is being deferred as follows:

- Comments: Type “[contentious RFS] — [name of the employer] — [last day worked for the employer] — adjudication deferred.”

- Details: Type “Adjudication of [contentious RFS, full name of the employer, last day worked for the employer or serial number of ROE] is deferred because the client has not requested benefits since the contentious RFS occurred.”

- Select Save .

- In RCM, determine if the ROE is on file:

- If yes, go to step 3.

- If no, go to step 4.

- Update block 16 of the ROE as follows:

- Special condition: Select Adjudication deferred .

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3065.dita)

- In FTS, select the Disqualifications/Disentitlements (M161) transaction to impose a disqualification as follows:

- Action: Select Add .

- Disqualification: Select the appropriate disqualification:

- If the disqualification is for a dismissal or suspension, select 10 - Dismissal - misconduct proven

- If the disqualification is for a voluntary leaving or a voluntary leave of absence, select 11 - Voluntary leaving - just cause not proven .

- Effective: Select the w/c of the dismissal or voluntary leaving.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision type: Select the appropriate option.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In FTS, determine if a stop payment is imposed and if there is an outstanding registration number for the contentious RFS being deferred:

- If a stop payment is imposed but there is no registration number, go to step 6.

- If a stop payment is imposed and there is a registration number, go to step 7.

- If a stop payment is not imposed but there is a registration number, go to step 8.

- If none of the above applies, go to step 9.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and remove the stop payment as follows:

- Manual action: Select the appropriate stop payment.

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 9.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI for the RFS being deferred. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3064.dita`

- The client has requested a conversion of benefits.

- The client has submitted a renewal application.

- If none of the conditions are met, go to step 10.

- If any of the conditions are met, refer to the appropriate deferral procedure based on the requested claim type (CT) and benefit type (BT). 

#### Note

Source topic: `en_EN/common_notes/note_c_3065.dita`

Note:

Selecting Validate may cause the ROE to be flagged with an error. It is not necessary to fix the error. The ROE is corrected when the client applies for a subsequent claim. 

## Policy reference

Source topic: `en_EN/task/deferring_adj_current_claim/policy_reference.dita`

 
