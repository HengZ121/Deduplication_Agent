# Adjudicating jury duty

Source map: `en_EN/task/adjudicating_jd/adjudicating_jd.ditamap`

## Summary

Source topic: `en_EN/task/adjudicating_jd/summary.dita`

Summary: Disentitlements related to availability or capability are suspended during the period the client is engaged in jury duty. 

## What you need to know

Source topic: `en_EN/task/adjudicating_jd/what_you_need_to_know.dita`

### Clients engaging in jury duty

Source topic: `en_EN/task/adjudicating_jd/clients_engaging_in_jury_duty.dita`

Clients can be asked to perform jury duty. Clients are considered to be engaged in jury duty when they are sworn in as members of a jury for a specific trial or when they are called for general duty as a group of potential jurors who can later be selected for a specific trial. Jury duty also applies to a coroner’s inquest.

Receiving a subpoena to appear as a witness at a trial is not considered jury duty. In this situation, the agent refers to Availability to determine the client’s entitlement to benefits given the conditions imposed by the court order.
       [Availability](/en/procedure/activity/availability.shtml)

Agents can receive an Adjudication Issue (ADJ) WI, Action Item (AI) WI or Claim Review (CR) Revised WI to adjudicate jury duty when the issue is reported to but cannot be completed at the call centre. Agents can receive an ADJ or AI WI to adjudicate jury duty when the client reports the issue in person at a Service Canada Centre (SCC). The type of WI depends on the claim status. 

### Entitlement to benefits while on jury duty

Source topic: `en_EN/task/adjudicating_jd/entitlement_to_benefits_while_on_jury_duty.dita`

Clients are not disentitled from benefits solely for being engaged in jury duty. When clients declare non-availability only because of jury duty, the claimant’s report is amended to indicate that the client is available.

When a disentitlement related to availability or capability is suspended because the client is engaged in jury duty for less than a full week, the agent advises the client to declare availability only for the number of days of the week the client is engaged in jury duty.

Although disentitlements related to availability or capability are suspended (i.e. temporarily terminated) for the period of jury duty, clients must still fulfill all other provisions of the EIA and EIR to receive benefits. 

### Levels of decision

Source topic: `en_EN/task/adjudicating_jd/levels_of_decision.dita`

Level 1 agents can suspend the following disentitlements to allow benefits while the client is engaged in jury duty:

```text
| Disentitlement | Definition |

| 2 | Minor attached, reason for separation illness |

| 3 | Not available |

| 4 | Failure to prove unable to obtain suitable employment |

| 16 | No medical certificate submitted |

| 22 | Illness (maximum sickness/special benefits paid) |

| 24 | Failure to actively seek employment |

| 25 | Maternity benefits -- Minor attached |

| 27 | Maternity benefits (maximum special benefits paid) or outside range |

| 33 | Incapacity proven but not otherwise available |

| 34 | Parental benefits entitlement conditions not met |

| 36 | Maternity not eligible - 15 weeks paid per pregnancy |
```

No other disentitlement or disqualification can be suspended while the client is engaged in jury duty. Level 2 adjudication is required if the client is requesting benefits during jury duty and if any other type of disentitlement or disqualification is on file. 

### Suspending an existing disentitlement

Source topic: `en_EN/task/adjudicating_jd/suspending_an_existing_disentitlement.dita`

Jury duty is adjudicated only on established claims so that agents can determine if there is an availability or capability disentitlement to suspend.

When the jury duty is for a past period that has already processed, the order of inputs prevents a potential overpayment situation. First, the agent inputs the same disentitlement effective the first week day after the jury duty. The agent then terminates the original disentitlement.

To suspend a D2, D22, D25, D27 or D36 disentitlement during jury duty, the agent must also convert the claim to regular benefits to allow payment. No special benefits are payable on these claims.

To suspend any of the other availability or capability disentitlements during jury duty, the agent converts a claim from special to regular benefits only if the jury duty lasts for one full week or longer.

When the jury duty has not ended at the time of adjudication, the agent creates a Reminder (REM) WI to follow up and to reinstate the disentitlement accordingly. 

### Claim action status and processing the claim

Source topic: `en_EN/task/adjudicating_jd/claim_action_status_and_processing_the_claim.dita`

During processing, an initial or renewal claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

- Finalized - Pending LREM

The agent must wait until the initial or renewal claim is finalized before adjudicating the jury duty issue. 

## Regional considerations

Source topic: `en_EN/task/adjudicating_jd/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/adjudicating_jd/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/adjudicating_jd/in_fts.dita`

- Is there a disentitlement or disqualification?

- If yes, what type?

- Does the jury duty period overlap the disentitlement dates?

- Have the claimant’s reports already processed for the period of jury duty?

- Is there an outstanding registration number for the jury duty issue?

- Did the client declare not available on the claimant’s report for the period of jury duty?

- What is the benefit type? 

### In NWS:

Source topic: `en_EN/task/adjudicating_jd/in_nws.dita`

- What is the Claim action status?

- What type of WI was created for the jury duty issue?

- What is the start and end date for the jury duty?

- Does the jury duty period overlap the disentitlement dates? 

## Step by step

Source topic: `en_EN/task/adjudicating_jd/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/adjudicating_jd/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/adjudicating_jd/reviewing_the_file_level_1.dita`

- In NWS, determine if the Claim action status is one of the following:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1734.dita) 

- If yes, go to step 2.

- If no, go to step 7.

- Determine if the WI for the jury duty issue is an ADJ WI:

- If yes, go to step 3.

- If no, go to step 5.

- In NWS, create an AI WI for the jury duty issue as follows:

- Complexity: Select Level 1 .

- Language : Select the appropriate option.

- Destination: Select the SCC as shown in FTS.

- End User: Select Myself .

- Send to my pending workload: Check the box.

- Reason: Select Other .

- Comments: Type “Waiting for claim to be finalized.”

- Bring forward date: Enter the current date + 5 working days.

- Category: Select Pay affected .

- Issue: Select Availability .

- BPC: Enter the BPC.

- Comments: Type “Adjudicate jury duty issue once claim is finalized”

- Details: Type “Client is engaged in jury duty. When the claim is established, determine if a disentitlement related to availability or capability is imposed. If yes, the disentitlement is suspended for the period of jury duty.”

- Click Save .

- Complete the ADJ WI for the jury duty issue. Go to step 5.

- Move the AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Adjudicate jury duty issue once claim is finalized.”

- Bring forward date: Enter the current date + 5 working days.

- When the WI moves to the current workload, determine if the claim is established:

- If the claim is not yet finalized, return to step 5.

- If the claim is established, go to step 7.

- If the claim is BPNE, go to step 22. 

#### Review the criteria to allow at Level 1

Source topic: `en_EN/task/adjudicating_jd/review_the_criteria_to_allow_at_level_1_level_1.dita`

- Determine if one of the following disentitlements is imposed:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1735.dita) 

- If one of the above disentitlements is imposed, go to step 8.

- If none of the above disentitlements are imposed and there are no other disentitlements or disqualifications, go to No disentitlement to suspend .
               [No disentitlement to suspend](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_jd#jurydut2)

- If none of the above disentitlements are imposed but there is another disentitlement or disqualification imposed, go to Reassign the WI to Level 2 .
               [Reassign the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_jd#reassignthe) 

#### Fact-finding

Source topic: `en_EN/task/adjudicating_jd/fact-finding_level_1.dita`

- Determine if the dates for the jury duty period are on file:

- If information is missing, fact-find with the client and go to step 9.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If all of the information is on file, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1736.dita)

- Determine if the client was contacted during fact-finding:

- If yes, go to step 10.

- If no, go to Reassign the WI to Level 2 .
               [Reassign the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_jd#reassignthe)

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- New SROC: Main Issue: Select Availability .

- New SROC: Comments: Type “Jury duty.”

- Details: Document the fact-finding details according to the National Policy on Fact-Finding, Documentation and Retention .
               [National Policy on Fact-Finding, Documentation and Retention](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Determine the jury duty start date:

- If the jury duty starts before the definite disentitlement end date or if the disentitlement is indefinite, go to step 12.

- If the jury duty starts after the definite disentitlement end date, no further action is required. Go to No disentitlement to suspend .
               [No disentitlement to suspend](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_jd#jurydut2) 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/adjudicating_jd/record_of_decision_rod__creation_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Jury duty—disentitlement terminated.”

- Details: Type “The client is entitled to benefits while on jury duty. The disentitlement is suspended during the period of jury duty.” 

#### Inputs

Source topic: `en_EN/task/adjudicating_jd/inputs_level_1.dita`

- Determine if there is an outstanding registration number for the jury duty issue:

- If yes, go to step 14.

- If no, in FTS, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- Determine if the jury duty is for a past period that has already processed:

- If no, go to step 15.

- If yes, go to Suspending a disentitlement — Weeks processed .
               [Suspending a disentitlement — Weeks processed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_jd#suspenisetitlai) 

#### Suspending a disentitlement — Weeks not processed

Source topic: `en_EN/task/adjudicating_jd/suspending_a_disentitlement__weeks_not_processed_level_1.dita`

- Determine if the disentitlement to be suspended is a D2, D22, D25, D27 or D36:

- If it is not one of these disentitlements, go to step 16.

- If it is one of these disentitlements, the claim must be converted to regular benefits. Go to step 18.

- Determine the duration of the jury duty:

- If the jury duty lasts one full week or longer or the end date is not yet known, go to step 17.

- If the jury duty lasts less than one week, go to step 19.

- Determine if the claim is established for regular benefits:

- If no, the claim must be converted to regular benefits. Go to step 18.

- If yes, go to step 19.

- In FTS, select the Renewal/Revised (M106) transaction, change the claim type and terminate the disentitlement as follows:

- Registration number: Select the applicable registration number.

- Revival: Enter the Sunday of the week in which the jury duty starts.

- Claim type: Select 2 - Regular .

- Action: Select T - Terminate/Modify .

- Disentitlement: Select the applicable code for the disentitlement to be terminated.

- End: Enter the date that precedes the start date of the jury duty. If the jury duty starts on a Monday, enter the Friday date preceding the jury duty.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Click Update .

- Go to step 20.

- In FTS, click on the Disqualifications/Disentitlements link to terminate the disentitlement as follows:

- Click the original disentitlement.

- Click Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following:

- Registration number: Select the applicable registration number.

- Action: Select T - Terminate/Modify .

- End Date: Enter the date that precedes the start date of the jury duty. If jury duty starts on a Monday, enter the Friday date preceding the jury duty.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Click Update .

- Determine if the jury duty ends before the original disentitlement end date:

- If the jury duty ends before the original disentitlement end date or if the jury duty end date is not known, go to step 21.

- If the jury duty ends after the original disentitlement end date, no further action is required. Go to step 22.

- In NWS, create a REM WI to follow up on the jury duty end date as follows:

- Complexity: Select Level 1 .

- Reason: Select Availability .

- Comments: Type “Follow up on jury duty end date is required.”

- Due date: Select one of the following options:

- If the jury duty end date is known, enter the jury duty end date.

- If the jury duty end date is not known, enter the jury duty start date + 4 weeks.

- Language: Select the appropriate option.

- Details: Type “The disentitlement [disentitlement code] has been terminated to allow benefits during the period the client is on jury duty. Follow up is required to determine if the disentitlement must be reinstated once jury duty has ended and to convert the claim if required.”

- Destination: Select the SCC as shown in FTS.

- End User: Select Next available user .

- Click Save .

- In NWS, complete the ADJ WI, AI WI or CR WI for the jury duty issue. 

#### Suspending a disentitlement – Weeks processed

Source topic: `en_EN/task/adjudicating_jd/suspending_a_disentitlement__weeks_processed_level_1.dita`

- Determine if the claim is established for regular benefits:

- If no, go to step 16.

- If yes, go to step 20.

- Determine the disentitlement to be suspended:

- If it is a D2, D22, D25, D27 or D36, the claim must be converted to regular benefits. Go to step 17.

- If it is one of the other disentitlements that can be suspended during jury duty, go to step 20.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Click Update .

- When the MM06 transaction opens, send the information to IPOC as follows:

- BPC: Select the applicable BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 36 - Special benefits on fishing claims or other complex claim cond itions .

- Remarks Line 1: Type “Jury duty - Conversion required.”

- Remarks Line 2: Type “Regular benefits are payable during jury duty.”

- Remarks Line 3: Type “Change to CT2 and suspend DE from XXXX-X [start date of the jury duty] to XXXX-X [end date of jury duty] only.”

- Remarks Line 5: Type your name and telephone number.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Click Update .

- Click the Outstanding Registrations link and transfer the registration number to IPOC as follows:

- Click Modify .

- In the appropriate registration section:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Click Update .

- Go to step 23.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the disentitlement for the period after jury duty as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select the code used for the original disentitlement.

- Start date: Enter the next working day after the end of jury duty.

- End date: Enter the end date of the original disentitlement.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Click Update .

- Click the Disqualifications/Disentitlements link to terminate the original disentitlement as follows:

- Click the original disentitlement.

- Click Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following:

- Registration number: Select the applicable registration number.

- Action: Select T - Terminate/Modify .

- End date: Enter the date that precedes the start of jury duty. If jury duty starts on a Monday, enter the date of the Friday preceding the start of jury duty.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Click Update .

- Determine if the client declared not available due to jury duty on the claimant’s report:

- If no, go to step 23.

- If yes, refer to Modifying a claimant’s report to remove the not available days.
               [Modifying a claimant’s report](/en/procedure/task/modifying_cr.shtml)

- In NWS, complete the WI for the jury duty issue. 

#### No disentitlement to suspend

Source topic: `en_EN/task/adjudicating_jd/no_disentitlement_to_suspend_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Jury duty — no action required.”

- Details: Type “The client is entitled to benefits while on jury duty. There are no disentitlements related to availability or capability during the period of jury duty. No action is required.”

- In FTS, determine if there is an outstanding registration number for the jury duty issue:

- If yes, go to step 3.

- If no, go to step 4.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Click Update .

- In NWS, complete the WI for the jury duty issue. 

#### Reassign the WI to Level 2

Source topic: `en_EN/task/adjudicating_jd/reassign_the_wi_to_level_2_level_1.dita`

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type one of the following:

- “Not within Level 1 authority. The disentitlement is not one that can be suspended during jury duty.”

- “Unable to reach the client. Insufficient facts to suspend the disentitlement. Not within Level 1 authority to maintain the disentitlement.”

- Click OK . 

#### Callout

Source topic: `en_EN/common_notes/note_c_1734.dita`

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

- Finalized - Pending LREM 

#### Callout

Source topic: `en_EN/common_notes/note_c_1735.dita`

2 - Minor attached, reason for separation illness 3 - Not available 4 - Failure to prove unable to obtain suitable employment 16 - No medical certificate submitted 22 - Illness (maximum sickness/special benefits paid) 24 - Failure to actively seek employment 25 - Maternity benefits - Minor attached 27 - Maternity benefits (maximum special benefits paid) or outside range 33 - Incapacity proven but not otherwise available 34 - Parental benefits entitlement conditions not met 36 - Maternity not eligible - 15 weeks paid per pregnancy 

#### Note

Source topic: `en_EN/common_notes/note_c_1736.dita`

Note:

If the client indicates that the end date is not yet known, continue with the procedure. The unknown end date is addressed later. 

### Level 2

Source topic: `en_EN/task/adjudicating_jd/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/adjudicating_jd/reviewing_the_file_level_2.dita`

- In NWS, determine the WI type created for the jury duty issue:

- If it is an ADJ WI, go to step 3.

- If it is an AI or CR WI, go to step 2.

- Determine the reason the AI WI or CR WI was reassigned to Level 2:

- If it was reassigned because the disentitlement or disqualification on file is not one that can be terminated to pay benefits during jury duty, go to Disentitlement or disqualification cannot be suspended .
               [Disentitlement or disqualification cannot be suspended](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_jd#jury_duty1)

- If it was reassigned because the client could not be reached during fact-finding, go to Unable to contact the client — Disentitlement maintained .
               [Unable to contact the client — Disentitlement maintained](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_jd#_Client_not_contacted)

- In NWS, create an AI WI for the jury duty issue as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination: Select the SCC as shown in FTS.

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Availability .

- BPC: Enter the BPC.

- Comments: Type “Adjudicate jury duty issue once claim is finalized.”

- Details: Type “Client is engaged in jury duty. When the claim is established, determine if a disentitlement related to availability or capability is imposed. If yes, the disentitlement is suspended for the period of jury duty.”

- Select Save .

- Complete the ADJ WI for the jury duty issue. 

#### Disentitlement or disqualification cannot be suspended

Source topic: `en_EN/task/adjudicating_jd/disentitlement_or_disqualification_cann_11ed5b79_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Jury duty — benefits not payable.”

- Details: Type “The client is not entitled to benefits while on jury duty. The [disentitlement or disqualification] on file is not one that can be suspended during jury duty.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if there is an outstanding registration number for the jury duty issue:

- If no, go to step 5.

- If yes, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Decision Maintained (2576): Select Decision maintained – still cannot pay benefits .

- Why decision maintained (2587): Select but we still cannot pay you benefits because :

- Text Specify reason(s) maintained and type “the reason you are not entitled to benefits is not a reason that can be suspended during the period you are on jury duty”

- Right to Request a Reconsideration (with Blank option): Select Right to Request a Reconsideration .

- In NWS, complete the WI for the jury duty issue. 

#### Unable to contact the client — Disentitlement maintained

Source topic: `en_EN/task/adjudicating_jd/unable_to_contact_the_client__disentitl_dbfb07f8_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Jury duty — disentitlement maintained.”

- Details: Type “The client has not provided sufficient information regarding jury duty to prove entitlement to benefits. The disentitlement on file is maintained.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if there is an outstanding registration number for the jury duty issue:

- If no, go to step 5.

- If yes, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Decision Maintained (2576): Select Decision maintained – still cannot pay benefits .

- Why decision maintained (2587): Select but we still cannot pay you benefits because :

- Text Specify reason(s) maintained and type “you have not provided sufficient information to determine if you are entitled to benefits during jury duty.”

- Right to Request a Reconsideration (with Blank option): Select Right to Request a Reconsideration .

- In NWS, complete the WI for the jury duty issue. 

## Policy reference

Source topic: `en_EN/task/adjudicating_jd/policy_reference.dita`

- Digest 13.3.7—While on jury service
         [Digest 13.3.7—While on jury service](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-13/parental-benefits-provisions.html#a13_3_7)

- Digest 10.14.5—Jury duty and court orders
         [Digest 10.14.5—Jury duty and court orders](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/personal-business.html#a10_14_5)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml#s2_3) 
