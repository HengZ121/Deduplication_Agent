# Adjudicating a leave of absence — Level 2

Source map: `en_EN/task/adjudicating_loa_l2/adjudicating_loa_l2.ditamap`

## Summary

Source topic: `en_EN/task/adjudicating_loa_l2/summary.dita`

Summary: When a client takes a voluntary leave of absence, entitlement to regular benefits may be affected. Adjudication is required to determine if the client had just cause for the leave of absence from employment. 

## What you need to know

Source topic: `en_EN/task/adjudicating_loa_l2/what_you_need_to_know.dita`

### Adjudicating a leave of absence

Source topic: `en_EN/task/adjudicating_loa_l2/adjudicating_a_leave_of_absence.dita`

Even though the employer authorizes the leave of absence, it does not mean the client had just cause under the EIA for the leave of absence. The reasons for requesting the leave of absence are subject to the same considerations as voluntarily leaving the employment entirely. The officer must determine, based on the information gathered, whether the leave was the only reasonable alternative.

Since the leave of absence is a temporary situation, if the officer determines that the client had no just cause for the leave of absence, a disentitlement is imposed rather than a disqualification. The 43 - Leave from employment without just cause disentitlement (D43) is imposed to indicate an authorized leave of absence without just cause. This disentitlement can be imposed definitely or indefinitely for the period of leave during the benefit period (BP). The client is disentitled for any days during the BP that constitute a leave of absence without just cause until the client:

- resumes the employment;

- loses or voluntarily leaves the employment; or

- accumulates, after the beginning of the leave of absence with another employer, the number of hours of insurable employment required by EIA 7 or 7(1) to qualify to receive benefits.

If the above conditions for terminating the disentitlement have not been met when the claim ends, the disentitlement is carried over to the next BP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1737.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1738.dita) 

### Availability during a leave of absence

Source topic: `en_EN/task/adjudicating_loa_l2/availability_during_a_leave_of_absence.dita`

If requesting regular benefits, the client must be capable of and available for work to be considered entitled. However, if requesting sickness benefits, the client must be otherwise available to be considered entitled. If the client is not otherwise available, the officer reviews the client’s availability. For more information, the officer refers to Availability .
       [Availability](/en/procedure/activity/availability.shtml) 

### Processing an initial or renewal claim

Source topic: `en_EN/task/adjudicating_loa_l2/processing_an_initial_or_renewal_claim.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) .

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can calculate the initial claim or finalize the renewal claim. Once all of the ADJ WIs are completed, the system rescinds the 2 - Contentious Renewal in Automation manual action (MA02). 

### Updating the ROE after adjudication

Source topic: `en_EN/task/adjudicating_loa_l2/updating_the_roe_after_adjudication.dita`

When the leave of absence is adjudicated and the ROE is received, the officer updates block Special condition of the ROE to either Authorized period of leave (not just cause) or Voluntary leaving - Just cause . An initial claim cannot be calculated until block Special condition is updated. When the officer selects Authorized period of leave , the system generates the D43 with the calculation result.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1739.dita) 

On an initial claim, if the client does not have just cause for the leave of absence, the officer drafts the letter of decision and creates a client Note . If the claim is automated, the system creates a Correspondence (COR) Disqualification/Disentitlement WI. The officer with the COR or Claim Assessment (CA) WI sends the letter as indicated in the client Note .

On a renewal claim, if the client does not have just cause for the leave of absence, the officer drafts the letter of decision and, if required, creates a COR Manual Decision WI to notify the client of the decision.

On a continuing claim, if a letter of decision is required for the leave of absence, the officer sends the letter before completing the WI for the leave of absence issue.

**ROE errors found during validation**

ROEs are automatically validated by the system. In some situations, a change must be made in RCM (such as updating block Special condition ) before this validation can occur. When an error is detected during the validation (e.g. a vacation pay type is not indicated on an ROE), ACP does not automatically create an ROE Correction WI, but the error prevents automatic calculation. If possible, the officer must correct the ROE immediately so ACP can calculate the claim. 

### Communication with the employer

Source topic: `en_EN/task/adjudicating_loa_l2/communication_with_the_employer.dita`

The employer must be notified in writing of the decision and provided with the right to request a reconsideration when the reasons for taking the period of leave are work-related , but just cause for leaving was shown. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/adjudicating_loa_l2/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Processing the Adjudication Issue (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/adjudicating_loa_l2/processing_the_adjudication_issue_adj_w_43ed2c2a.dita`

Adjudication of the leave of absence is not required if the employment is not insurable, either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, the ADJ WI must not be completed. The officer follows the procedures and conditions for removal of claims from ACP process. The officer moves the ADJ WI to Pending until the CA or Specialized Application (SA) WI is created. An authorized user must then delete the ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1740.dita) 

### Reason for separation (RFS) — Temporary Budget measures

Source topic: `en_EN/task/adjudicating_loa_l2/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**Adjudicating the last employment in the qualifying period (QP) — BPCs between w/c 2310 and w/c 2361**

Budget 2021 has introduced a temporary simplification measure starting September 26, 2021. For claims with a BPC between w/c 2310 and w/c 2361, the officer will only adjudicate the last period of employment in the QP if it is contentious. If the officer allows the last RFS, all other ROEs in the QP, even if they are contentious, are used to calculate the claim. If, however, the officer does not allow the RFS on the last ROE in the QP, the claim is calculated with a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 

This new measure does not apply to fishing claims and claims for self-employed people. Instead, if clients have insurable employment in the QP with a contentious RFS and a BPC between w/c 2310 and w/c 2361 when they apply for self-employment (SE) or fishing benefits, the officer must adjudicate the contentious RFS following normal adjudication procedures.

When the client declares other employers with a contentious RFS on the same application, if ACP does not allow the issue under auto-adjudication rules, the issue is automatically resolved, and ACP creates a record of decision (ROD) that shows Adjudication not Required . Block Special condition on the ROE is not updated, and the ROE is included in the calculation. An Adjudication Issue (ADJ) WI is not created for the RFS.

ACP does not always automatically create an ADJ WI when the application is received. However, if an ROE with a contentious RFS is received during the automation process, ACP may create an ADJ WI or ROE Issue (ROE) RFS Action WI.

When there is more than one ROE with the same last day paid (LDP), and one of the ROEs is contentious while the other ROE is not, adjudication is not required and both ROEs are included in the calculation.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1741.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1742.dita) 

### Adjudication not required: Reason for separation (RFS) beyond 12 weeks — BPCs between w/c 2258 and w/c 2309

Source topic: `en_EN/task/adjudicating_loa_l2/adjudication_not_required_reason_for_se_2ca905dc.dita`

Adjudication principles on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309 only apply to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the I of E used to establish the claim.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1743.dita) 

### Adjudication not previously required — Specialized ACP process

Source topic: `en_EN/task/adjudicating_loa_l2/adjudication_not_previously_required__s_a89cd8c4.dita`

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the QP. The RFS issues that were not previously adjudicated can be identified because block Special condition was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0126.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_1737.dita`

Note:

For information regarding reason for separation (RFS) issues resulting from a client not complying with the employer’s COVID-19 vaccination policy, the officer refers to the EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo) .
       [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml)

     [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1738.dita`

Note:

When the period of leave is entirely in the qualifying period (QP) and is not the last ROE, the leave of absence has no impact on an initial claim. Any hours of insurable employment accumulated in the QP are included in the claim calculation, regardless of whether the client has just cause for the leave of absence. A leave of absence without just cause results in a disentitlement for the period of leave, but the disentitlement does not apply to the QP. Therefore, if the period of leave is entirely in the QP on an initial claim, the officer can conclude without further fact-finding that the client has just cause for the leave of absence. Communication with the employer is also not required. 

### Note

Source topic: `en_EN/common_notes/note_c_1739.dita`

Note:

For initial claims and recalculations with a BPC between w/c 2310 and w/c 2361, if adjudication is not required, the Special condition field is not updated. 

### Note

Source topic: `en_EN/common_notes/note_c_1740.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. In this situation, adjudication of the leave is required. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Example 1

Source topic: `en_EN/common_notes/note_c_1741.dita`

Example 1:

Peter’s LDP was September 28, 2021 (w/c 2310) with 2 employers. Three periods of employment are provided on his EI application. Peter declared Employer 1 as his last employer and the RFS is shortage of work. In the Other Employers section of the application, Peter declared Employer 2 and the RFS is leave of absence. He also declared Employer 3 and the RFS is voluntary leaving. The interruption of earnings (I of E) is in w/c 2310, and he applied for benefits on September 29, 2021. His BPC is September 26, 2021 (w/c 2310).

There are 2 contentious ROEs on Peter’s file:

- Employer 1: The LDP is September 28, 2021 (w/c 2309). The RFS is A .

- Employer 2: The LDP is September 28, 2021 (w/c 2309). The RFS is N .

- Employer 3: The LDP is May 19, 2021 (w/c 2291). The RFS is E .

Employer 1 and Employer 2 have the same LDP. The RFS with Employer 1 is non-contentious, so adjudication is not required for Employer 2. ACP automatically resolves the RFS for Employer 2 and creates a ROD that shows Adjudication not required .

The RFS with Employer 3 is contentious and is in the QP. However, because it is not the last employer in the QP, adjudication is not required. ACP creates a ROD that shows Adjudication not required .

All ROEs are included in the calculation of the claim. 

### Example 2

Source topic: `en_EN/common_notes/note_c_1742.dita`

Example 2:

Abdul’s LDP was September 24, 2021 (w/c 2309) with both of his employers. He declared Employer 1 as his last employer and the RFS is leave of absence. In the Other Employers section of the application, Abdul declared Employer 2 and the RFS is voluntary leaving. The I of E is in w/c 2309, and he applied for benefits on September 26, 2021. His BPC is September 26, 2021 (w/c 2310).

- Employer 1: The LDP is September 24, 2021 (w/c 2309). The RFS is N .

- Employer 2: The LDP is September 24, 2021 (w/c 2309). The RFS is E .

Employers 1 and 2 have the same LDP and the RFS with both employers are contentious. ACP creates an ADJ WI for Employer 1, automatically resolves the RFS issue for Employer 2 and creates a ROD that shows Adjudication not required . If the leave of absence with Employer 1 is not allowed, the RFS with Employer 2 must be adjudicated. 

### Example

Source topic: `en_EN/common_notes/note_c_1743.dita`

Example:

Mary’s LDP was September 25, 2020 (w/c 2257). Her I of E is in w/c 2257, she submitted her application for benefits on September 26, 2020, and her BPC will be September 27, 2020 (w/c 2258).

There are 3 contentious ROEs on Mary’s file:

ROE 1: LDP September 25, 2020 (w/c 2257).

ROE 2: LDP July 17, 2020 (w/c 2247).

ROE 3: LDP May 31, 2020 (w/c 2241).

To determine which RFS to adjudicate, the officer subtracts 12 weeks from w/c 2257 (week of the I of E). For the example above, the formula is as follows: w/c 2257 (I of E) – 12 = w/c 2245. This determines a 12-week period falling before the Sunday of the I of E that encompasses the weeks from w/c 2245 to w/c 2256. The officer follows normal procedures and adjudicates ROE 1, which is the most recent ROE in the QP, and ROE 2, as it falls between w/c 2245 and w/c 2256, the 12-week period.

The officer allows any contentious RFS that occurs before the 12-week period. ROE 3 is before the 12-week period, so the officer allows the RFS by following the steps of Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
       [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#adj_not_required_beyond_12)

     [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#adj_not_required_beyond_12) 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0126.dita`

Note:

Any contentious RFS issues in the BP must be adjudicated. 

## Regional considerations

Source topic: `en_EN/task/adjudicating_loa_l2/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/adjudicating_loa_l2/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/adjudicating_loa_l2/in_nws.dita`

- Is there a ROD for the leave of absence on this or a previous EI application?

- What is the client’s statement in the Reason for separation section on this EI application or on a previous EI application?

- Are there any SROCs, Action Item (AI) WIs, other WIs or documentation containing checklists or other details relating to the leave of absence on this or a previous EI application?

- Is there a CA WI or ROE Correction WI outstanding?

- What benefit type (BT) is the client applying for? 

### In FTS:

Source topic: `en_EN/task/adjudicating_loa_l2/in_fts.dita`

- What is the claim type (CT) (initial, continuing or renewal)?

- Have claimant’s reports been processed for the period in question?

- If yes, when was the original statement made?

- Is there a manual action (MA) to suspend payments on the claim concerning this issue? 

### In Imaging:

Source topic: `en_EN/task/adjudicating_loa_l2/in_imaging.dita`

- Are there any imaged documents relating to the leave of absence? 

### In RCM:

Source topic: `en_EN/task/adjudicating_loa_l2/in_rcm.dita`

- Is there an ROE for the leave of absence?

- If yes, what is the RFS indicated?

- Are there any comments related to the leave of absence?

- Are there other ROEs since the leave of absence? If yes, does the client have enough hours after the leave of absence to qualify for benefits? 

## Step by step

Source topic: `en_EN/task/adjudicating_loa_l2/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/adjudicating_loa_l2/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/adjudicating_loa_l2/reviewing_the_file_level_2.dita`

- In NWS, determine if there is a ROD for the leave of absence issue already on file:

- If yes, go to Adjudication not required — Decision already on file .
               [Adjudication not required — Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_loa_l2#DecOnFile2)

- If no, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1744.dita)

- In FTS, determine if the BPC falls in a period where special measures apply:

- If the BPC is between w/c 2258 and w/c 2309, go to step 3.

- If the BPC is between w/c 2310 and w/c 2360, go to step 5.

- If the BPC is not in either of the periods, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita)

- Determine if the leave of absence occurred on the most recent ROE:

- If no, go to step 4.

- If yes, go to step 5.

- Determine if the leave of absence occurred within the 12-week period before the I of E:

- If yes, go to step 7.

- If no, go to Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
               [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_loa_l2#adj_not_required_beyond_12)

- Determine if the claim is for SE or fishing benefits:

- If no, go to step 6.

- If yes, go to step 8.

- Determine if the leave of absence occurred on the most recent ROE:

- If yes, go to step 8.

- If no, go to Adjudication not required — Budget 2021 simplification measures.
               [Adjudication not required — Budget 2021 simplification measures.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_loa_l2#adj_not_required_budget_2021)

- Determine if the period of leave is entirely in the QP and is not on the last ROE:

- If no, go to step 8.

- If yes, just cause is shown. Go to step 16.

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 10.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if the employment is not insurable, either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 11.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_loa_l2#Employment_is_not_insurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if there is enough information on file to adjudicate the RFS:

- If no, go to step 12.

- If yes, go to step 15. 

#### Fact-finding

Source topic: `en_EN/task/adjudicating_loa_l2/fact-finding_level_2.dita`

- Fact-find with the client and the employer. Refer to the Fact-Finding Guide and Digest 6 — Voluntarily Leaving Employment to determine the questions to ask.

- Determine if the client or employer was reached during fact-finding:

- If the client or employer was reached, go to step 14.

- If the client or employer was not reached or did not reply to the E-02-00-00 email, the N-10-00-00 letter or the Z-00-00-00 letter, go to step 15.

- In NWS, add to the draft SROC or create a new SROC as follows:

- Issue: Select Reason for separation .

- Comments: Type “Leave of absence — [employer’s name] — [LDW] — [client or employer].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1746.dita) 

#### Adjudicating the leave of absence

Source topic: `en_EN/task/adjudicating_loa_l2/adjudicating_the_leave_of_absence_level_2.dita`

- Determine if just cause is proven for the leave of absence, considering all evidence provided by both the client and the employer, and in accordance with the principles outlined in the EIA, EIR and jurisprudence. Refer to Digest 6.6.0 — Periods of leave as needed.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1747.dita) 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/adjudicating_loa_l2/record_of_decision_rod__creation_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type the appropriate comments based on the decision:

- If the decision is that just cause is not shown for the leave of absence, type “Leave of absence — [employer’s name] — [LDW] — just cause not shown.”

- If the decision is that just cause is shown for the leave of absence, type “Leave of absence — [employer’s name] — [LDW] — just cause shown.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If the decision is just cause is shown, select Save .

- If the decision is just cause not shown , select Draft because you need to verbally communicate the decision.

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 

#### Inputs and communication

Source topic: `en_EN/task/adjudicating_loa_l2/inputs_and_communication_level_2.dita`

- Determine the claim type:

- If this is an initial claim, select one of the following based on the decision:

- Just cause not shown — Initial claim
                   [Just cause not shown — Initial claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_loa_l2#Lv2nojustcauseinit)

- Just cause shown — Initial claim
                   [Just cause shown — Initial claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_loa_l2#Lv2justcauseinit)

- If this is a renewal claim, select one of the following based on the decision:

- Just cause not shown — Renewal claim
                   [Just cause not shown — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_loa_l2#Lv2nojustcauseren)

- Just cause shown — Renewal claim
                   [Just cause shown — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_loa_l2#Lv2justcauseren)

- If this is a continuing claim, select one of the following based on the decision:

- Just cause not shown — Continuing claim
                   [Just cause not shown — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_loa_l2#Lv2nojustcausecont)

- Just cause shown — Continuing claim
                   [Just cause shown — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_loa_l2#Lv2justcausecont) 

#### Just cause not shown — Initial claim

Source topic: `en_EN/task/adjudicating_loa_l2/just_cause_not_shown__initial_claim_level_2.dita`

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 2.

- If the client was not reached by telephone during fact-finding, go to step 3.

- Verbally communicate the decision to the client.

- In RCM, verify if the ROE with the leave of absence has been received:

- If yes, go to step 4.

- If no, go to step 7.

- Update the ROE as follows:

- Reason for issuing this record of employment: Select N - Leave of absence :

- Special condition: Select Authorized period of leave .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional information .

- Select Validate .

- Select Submit button and determine if the validation causes an ROE error:

- If yes, go to step 5.

- If no, go to step 7.

- In NWS, determine if there is a CA or ROE Correction WI for this ROE:

- If yes, go to step 7.

- If no, determine if the ROE can be corrected to fix the validation error. For procedures on correcting an ROE, refer to Completing an ROE Correction WI for a regular ROE .

- If no, go to step 6.

- If yes, correct the ROE and go to step 7.

               [Completing an ROE Correction WI for a regular ROE](/en/procedure/task/completing_roe_correction_regular.shtml)

- Create an ROE Correction WI as follows:

- Complexity: Select Non-complex .

- Language: Select the appropriate option based on the client’s language.

- Destination: Enter the Service Canada centre (SCC) as shown in FTS.

- End user: Select Next available user .

- Serial number: Type the serial number of the ROE.

- Issue: Select Correction .

- In ACS, create and save a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the following attributes:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D43 - Voluntary leave of absence from employment, without just cause (3021) .

- We/In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Enter the appropriate dates.

- Text - Name of employer(s)(1502): Enter the employer’s name.

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the benefit type and the applicable options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [date] to [date] because you took leave from your job with [text — name of employer(s)] on [date of event] without just cause.”

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to send the saved D-01-00-00 or N-00-00-00 ACS letter when completing the CA or COR WI.

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 10.

- If yes, go to step 11.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “[D-01-00-00 or N-00-00-00] letter required — leave of absence issue.”

- Complete the ADJ WI. 

#### Just cause shown — Initial claim

Source topic: `en_EN/task/adjudicating_loa_l2/just_cause_shown__initial_claim_level_2.dita`

- In RCM, determine if the ROE with the leave of absence has been received:

- If yes, go to step 2.

- If no, go to step 5.

- Update the ROE as follows:

- Reason for issuing this record of employment: Select N - Leave of absence .

- Special condition: Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional information .

- Select Validate .

- Select Submit and determine if the validation causes an ROE error:

- If yes, go to step 3.

- If no, go to step 5.

- In NWS, determine if there is a CA or ROE Correction WI for this ROE:

- If yes, go to step 5.

- If no, determine if the ROE can be corrected to fix the validation error. For procedures on correcting an ROE, refer to the Completing an ROE Correction WI for a regular ROE .

- If no, go to step 4.

- If yes, correct the ROE, do so and go to step 5.

               [Completing an ROE Correction WI for a regular ROE](/en/procedure/task/completing_roe_correction_regular.shtml)

- Create an ROE Correction WI as follows:

- Complexity: Select Non-complex .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Next available user .

- Serial number: Type the serial number of the ROE.

- Issue: Select Correction .

- In ACS, if required to inform the employer of the decision, create and send a Z-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved reason for separation and the applicable sub-options.

- Reason for Claim Approval (2783): Select Valid Reason for Leaving or Valid Reason not to Return to Work or Became Employed Elsewhere or Valid reasons for taking a period of leave .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the ADJ WI. 

#### Just cause not shown — Renewal claim

Source topic: `en_EN/task/adjudicating_loa_l2/just_cause_not_shown__renewal_claim_level_2.dita`

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 2.

- If the client was not reached by telephone during fact-finding, go to step 3.

- Verbally communicate the decision to the client.

- In RCM, determine if the ROE with the leave of absence has been received:

- If yes, go to step 4.

- If no, go to step 5.

- Update the ROE as follows:

- Reason for issuing this record of employment: Select N - Leave of absence .

- Special condition: Select Authorized period of leave .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional information .

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1748.dita)

- In FTS, select the Disqualifications/Disentitlements (M161) transaction to impose the disentitlement as follows:

- Action: Select Add .

- Disentitlement: Select 43 - Leave of Absence .

- Start date: Enter the start date for the leave of absence.

- End date: For definite disentitlements, enter the end date for the leave of absence. For indefinite disentitlements, select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non Fraud - Other .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4- An overpayment resulted due to an indefinite disentitlement .

- Decision Type: Select 2 - Renewal .

- Contentious: Select 2 - Yes .

- C omplete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update.

- In ACS, create and save a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the following attributes:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 ( 3021): Select D43 - Voluntary leave of absence from employment, without just cause .

- We/In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Enter the appropriate dates.

- Text - Name of employer(s) (1502): Enter the employer’s name.

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the benefit type and the applicable options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [date] to [date] because you took a leave of absence from your job with [Text - Name of Employer(s)] on [Date of Event] without just cause.”

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note and type “Send the [D-01-00-00 or N-00-00-00] letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 9.

- If yes, go to step 11.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 10.

- If yes, go to step 11.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “[D-01-00-00 or N-00-00-00] letter required — leave of absence issue.”

- Complete the ADJ WI. 

#### Just cause shown — Renewal claim

Source topic: `en_EN/task/adjudicating_loa_l2/just_cause_shown__renewal_claim_level_2.dita`

- In RCM, determine if the ROE with the leave of absence has been received:

- If yes, go to step 2.

- If no, go to step 3.

- Update the ROE as follows:

- Reason for issuing this record of employment: Select N - Leave of absence .

- Special condition: Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional information .

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1748.dita)

- In ACS, if required, create and send a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved reason for separation and the applicable sub-options.

- Reason for Claim Approval (2783): Select Valid Reason for Leaving or Valid Reason not to Return to Work or Became Employed Elsewhere or Valid reasons for taking a period of leave .

- Right to Request a Reconsideration (With Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the ADJ WI. 

#### Just cause not shown — Continuing claim

Source topic: `en_EN/task/adjudicating_loa_l2/just_cause_not_shown__continuing_claim_level_2.dita`

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 2.

- If the client was not reached by telephone during fact-finding, go to step 3.

- Verbally communicate the decision to the client.

- In RCM, determine if the ROE with the leave of absence has been received:

- If yes, go to step 4.

- If no, go to step 5.

- Update the ROE as follows:

- Reason for issuing this record of employment: Select N - Leave of absence .

- Special condition: Select Authorized period of leave .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional information .

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1748.dita)

- In FTS, determine if a 75 - Verification of reason for termination of employment manual action (MA75) is imposed for the leave of absence:

- If yes, go to step 6.

- If no, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1749.dita)

- Select the Renewal/Revised (M106) transaction to remove the MA75 and impose the disqualification as follows:

- Manual action: Select 75 - Verification of reason for termination of employment .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 43 - Leave of absence .

- Start date: Enter the start date for leave of absence.

- End date: For definite disentitlements, enter the end date for the leave of absence. For indefinite disentitlements, select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non Fraud - Other .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- If there is an outstanding Claim Review (CR) Recalculation WI, select D - No to leave the registration open for subsequent transactions.

- If there is no outstanding CR Recalculation WI, select C - Yes to complete the registration number.

- Select Update .

- Go to step 8.

- Select the Disqualifications/Disentitlements (M161) to impose the disentitlement as follows:

- Action: Select Add .

- Disentitlement: Select 43 - Leave of absence .

- Start date: Enter the start date for leave of absence.

- End date: For definite disentitlements, enter the end date for the leave of absence. For indefinite disentitlements, select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non Fraud - Other .

- Message: Select the appropriate option:

- 3 -An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- If there is an outstanding Claim Review (CR) Recalculation WI, select D - No to leave the registration open for subsequent transactions.

- If there is no outstanding CR Recalculation WI, select C - Yes to complete the registration number.

- Select Update .

- In ACS, create and send a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the following attributes:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 ( 3021): Select D43 - Voluntary leave of absence from employment, without just cause .

- We/In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Enter the appropriate dates.

- Text - Name of employer(s) (1502): Enter the employer’s name.

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the benefit type and the applicable options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [date] to [date] because you voluntarily took a leave from your job with [Text - Name of Employer(s)] on [Date of Event] without just cause.”

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI for the leave of absence. 

#### Just cause shown — Continuing claim

Source topic: `en_EN/task/adjudicating_loa_l2/just_cause_shown__continuing_claim_level_2.dita`

- In RCM, determine if the ROE with the leave of absence has been received:

- If yes, go to step 2.

- If no, go to step 3.

- Update the ROE as follows:

- Reason for issuing this record of employment: Select N - Leave of absence .

- Special condition: Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional information .

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1748.dita)

- In FTS, determine if an MA75 is imposed for the leave of absence:

- If yes, go to step 4.

- If no, go to step 5.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1750.dita)

- Select the Renewal/Revised (M106) transaction to remove the MA75 as follows:

- Manual action: Select 75 - Verification of reason for termination of employment .

- Rescind: Check the box.

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- If there is an outstanding CR Recalculation WI, select D - No to leave the registration open for subsequent transactions.

- If there is no outstanding CR Recalculation WI, select C - Yes to complete the registration number.

- Select Update .

- Go to step 6.

- Select the Renewal/Revised (M106) transaction to clear the outstanding registration number as follows:

- Claim allowed: Select NCA - no change on the claim .

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- If there is an outstanding CR Recalculation WI, select D - No to leave the registration open for subsequent transactions.

- If there is no outstanding CR Recalculation WI, select C - Yes to complete the registration number.

- Select Update .

- In ACS, if required to inform the employer of the decision, create and send a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved reason for separation and the applicable sub-options.

- Reason for Claim Approval (2783): Select Valid Reason for Leaving or Valid Reason not to Return to Work or Became Employed Elsewhere or Valid reasons for taking a period of leave .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI for the leave of absence. 

#### Adjudication not required — Decision already on file

Source topic: `en_EN/task/adjudicating_loa_l2/adjudication_not_required__decision_alr_a281283e_level_2.dita`

- In RCM, determine if the ROE with the RFS due to the leave of absence has been received:

- If yes, go to step 2.

- If no, go to step 3.

- Update the ROE as follows:

- Reason for issuing this record of employment: Select N - Leave of absence .

- Special Condition: Select the appropriate option:

- If just cause is not shown, select Authorized period of leave .

- If just cause is shown, select Voluntary leaving - Just cause .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional Information .

- Select Validate .

- Select Submit.

- In NWS, complete the WI for the leave of absence. 

#### Employment is not insurable

Source topic: `en_EN/task/adjudicating_loa_l2/employment_is_not_insurable_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Leave of absence — [employer’s name] — [LDW] — adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the leave of absence is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the leave of absence is therefore not required.”

- Determine the Claim action status:

- If the status is In Progress (Automation) , go to step 3.

- If the status is In Progress (Manual) , go to step 6.

- In NWS, create a Reminder (REM) WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “ACP.”

- Due date: Enter today’s date.

- Language: Select the appropriate option.

- Details: Type “2” and “Processing — [unallocated or user name to whom the CA or SA WI is to be assigned].”

- Destination: Select Level and Canada .

- End User: Select Specific user . Type “SV-ADMIN, ACP-TAD” and select Find User .

- Select Save .

- Move the ADJ WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting removal of the claim from automation process. Employment not insurable. This WI must be deleted once CA or SA WI is created.”

- Bring forward date: Enter today’s date + 2 working days.

- Select OK .

- When the ADJ WI moves to the current workload, confirm that the Claim action status is In Progress (Manual) and a CA or SA WI was created.

- Contact an authorized user (team leader or Business Expertise Advisor) to delete the ADJ WI. 

#### Adjudication not required — Budget 2021 simplification measures

Source topic: `en_EN/task/adjudicating_loa_l2/adjudication_not_required__budget_2021__620824ac_level_2.dita`

- In NWS, create a ROD as follows:

- BPC : Enter the BPC.

- Comments : Type “Leave of absence — [employer’s name] — [LDW] — adjudication not required.”

- Details : Type “Budget 2021 simplification measure — period of employment is not the last employer in the qualifying period. Adjudication is not required. EI Act 29(a).”

- Select Save .

- Complete the ADJ WI for the leave of absence. 

#### Adjudication not required — Reason for separation (RFS) beyond 12 weeks

Source topic: `en_EN/task/adjudicating_loa_l2/adjudication_not_required__reason_for_s_d81cc200_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Leave of absence — [employer’s name] — [LDW] — adjudication not required.”

- Details: Type “Post-Employment Insurance Emergency Response Benefit transitional measure — reason for separation beyond 12 weeks. EIA 153.194.”

- Select Save .

- In RCM, determine if the ROE with the leave of absence has been received:

- If yes, go to step 3.

- If no, go to step 6.

- Update the ROE as follows:

- Reason for issuing this record of employment: Select N - Leave of absence .

- Special condition: Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional information .

- Select Validate .

- Select Submit and determine if the validation causes an ROE error:

- If yes, go to step 4.

- If no, go to step 6.

- In NWS, determine if there is a CA or ROE Correction WI for this ROE:

- If yes, go to step 6.

- If no, determine if the ROE can be corrected to fix the validation error. For procedures on correcting an ROE, refer to the Completing an ROE Correction WI for a regular ROE .

- If no, go to step 5.

- If yes, do so and go to step 6.

               [Completing an ROE Correction WI for a regular ROE](/en/procedure/task/completing_roe_correction_regular.shtml)

- Create an ROE Correction WI as follows:

- Complexity: Select Non-complex .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Next available user .

- Serial number: Type the serial number of the ROE.

- Issue: Select Correction .

- In NWS, complete the ADJ WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1744.dita`

Note:

If the BPC is between w/c 2310 and w/c 2361 and there is a ROD on file that indicates Adjudication not required — Budget 2021 simplification measures , complete the ADJ WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_1746.dita`

Note:

Create a new SROC for each conversation with the employer or the client (e.g. if you contacted the employer twice, create 2 SROCs). 

#### Note

Source topic: `en_EN/common_notes/note_c_1747.dita`

Note:

If you are unable to contact the client or the employer, render a decision based on the information on file. 

#### Note

Source topic: `en_EN/common_notes/note_c_1748.dita`

Note:

Selecting Validate may cause the ROE to be flagged with an error. You are not required to fix the error. The ROE is corrected if and when the client applies for a subsequent claim. 

#### Note

Source topic: `en_EN/common_notes/note_c_1749.dita`

Note:

In some instances a 1 - General suspension of benefits (stop payment) manual action (MA01) may have been imposed instead of the MA75. The process for removing the MA01 is the same as for the MA75. However, before removing the MA01, verify that there are no remaining issues to adjudicate. 

#### Note

Source topic: `en_EN/common_notes/note_c_1750.dita`

Note:

In some instances an MA01 may have been imposed instead of the MA75. The process for removing the MA01 is the same as for the MA75. However, before removing the MA01, verify that there are no remaining issues to adjudicate. 

## Policy reference

Source topic: `en_EN/task/adjudicating_loa_l2/policy_reference.dita`

- Digest 6.6.0 — Periods of leave
         [Digest 6.6.0 — Periods of leave](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/periods-of-leave.html#a6_6_0)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 32
         [EIA 32](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-32.html) 
