# Entering data from a paper ROE — Regular ROE

Source map: `en_EN/task/paperroe_regular/paperroe_regular.ditamap`

## Summary

Source topic: `en_EN/task/paperroe_regular/summary.dita`

Summary: An ROE is necessary to establish a claim for benefits and to determine a client’s entitlement and eligibility for benefits. When a paper ROE is received, the data must be entered into RCM. When fraud indicators are present and the file is not already under investigation, the officer refers the file to Integrity. 

## What you need to know

Source topic: `en_EN/task/paperroe_regular/what_you_need_to_know.dita`

### Paper ROEs

Source topic: `en_EN/task/paperroe_regular/paper_roes.dita`

All paper ROEs submitted by mail or in person are scanned and sent to a GD mailbox to be uploaded to RMDS. ROEs that are uploaded to RMDS and are waiting to be input have a Pending status. Paper ROEs that cannot be scanned because they are damaged or illegible are sent to the processing centre to be input directly into RCM.

Paper ROEs that have the optional pay period worksheet attached cannot be scanned for input. They are sent to the processing centre to be input directly into RCM.

ROEs in the pending workload that Service Canada Centre (SCC) officers cannot input because they are complex or missing information have their status changed to Incomplete in RMDS. Duplicate, employer copy, illegible and SAT ROEs also have their status changed to Incomplete . When the officer confirms the ROE is a duplicate, employer copy, illegible or SAT ROE the officer deletes the PDF file in RMDS.

Before entering a potentially fraudulent ROE in RCM, the SCC officer adds the following comment to the client Note in NWS “ROE [serial number] has been moved to the Incomplete workload in RMDS. ROE is potentially fraudulent.” When the ROE has already been flagged by Integrity as fraudulent, the SCC officer adds the following comment to the client Note in NWS: “ROE [serial number] has been moved to the Incomplete workload in RMDS. The BN for this ROE is under investigation for potential fraud.” The SCC officer does not enter the ROE in RCM, but does change the status to Incomplete in RMDS.

Before entering an ROE that has an Incomplete status in RMDS, in NWS, the Non-complex officer verifies if there is a client Note about a fraudulent ROE. If yes, the officer suspends the application process and refers the file to Integrity, if necessary, before inputting the ROE in RCM. Once the ROE is input in RCM, the officer deletes the ROE.

Non-complex officers input all ROEs with the Incomplete status. On request, Non-complex officers may be required to input ROEs with the Pending status.

Officers use RMDS to retrieve ROEs for input. When an ROE is opened in RMDS, RCM automatically opens in a split screen with the ROE for input.

Officers can refer to the RMDS User Guide .
       [RMDS User Guide](https://esdc.prv/en/service-canada/ei/frontline/roe-web/rmds/user-guide.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3340.dita) 

Errors made while entering data from a paper ROE into RCM could:

- prevent or delay claim automation;

- cause errors in claim calculation;

- increase the workload for users trying to identify and correct the errors.

Any corrections or notes to the ROE must be made in RCM and never directly on the paper version. 

### ROEs uploaded by the client

Source topic: `en_EN/task/paperroe_regular/roes_uploaded_by_the_client.dita`

Clients can submit ROEs using the document upload feature in AW and MSCA. The system accepts only ROEs beginning with A, E, K, L, and Z. The serial number is also mandatory. The system does not check whether the serial number already exists in RCM. The officer can view uploaded ROEs on the Uploaded Documents tab in NWS.

In most cases, when clients upload ROEs in MSCA or in AW, an Action Item (AI) ROE Input WI is created in NWS. The officer completing the AI ROE Input WI views the ROE in NWS and inputs the ROE directly in RCM. If there is an outstanding Claim Set-Up (CS) WI on a new application, an AI ROE Input WI is not created.

If the ROE requires corrections or notes, the officer performs the action in RCM.

This process does not involve RMDS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3341.dita) 

When clients upload their own paper ROE in AW or MSCA but the ROE was issued with the wrong SIN, officers fact-find with employers to confirm that they issued the ROE with the wrong SIN. Officers advise employers that a new or amended ROE is not required and they add an SROC in NWS confirming that the uploaded paper ROE with the wrong SIN belongs to the client.

When clients upload another client’s ROE in AW or MSCA, it cannot be moved under the correct SIN. Officers contact the team leader to remove the document from view. For more information, officers refer to Document upload: Updating documents — Instructions .
       [Document upload: Updating documents — Instructions](/en/procedure/generic/document_upload_updating_document_instruction.shtml) 

### Types of regular ROEs

Source topic: `en_EN/task/paperroe_regular/types_of_regular_roes.dita`

There are 3 types of regular ROEs, identified by the first letter of the serial number:

- ROE Web begins with a W or M.

- ROE SAT begins with an S.

- Paper ROEs begin with an E or an A for English series, or a K for French series.

Even if there is no application for benefits, all paper ROEs received must be entered. If a hard copy of a Web ROE is received it is shredded. If a hard copy of a ROE SAT is received, the next steps are determined by referring to Receiving a paper copy of a ROE SAT .
       [Receiving a paper copy of a ROE SAT](/en/procedure/task/receiving_copy_roe_sat.shtml) 

### Interim ROE

Source topic: `en_EN/task/paperroe_regular/interim_roe.dita`

Under certain circumstances, interim ROEs can be entered to establish a claim when the ROE is not available or cannot be entered (e.g. serial number is partially visible and not available in Easy Access). RCM generates a serial number beginning with an X for regular interim ROEs. 

### Fraudulent paper ROEs

Source topic: `en_EN/task/paperroe_regular/fraudulent_paper_roes.dita`

Even if the information on the ROE matches the information on the application, this does not mean that the application is authentic. Fraudulent ROEs can be paper, ROE Web or ROE SAT.

Fraudulent paper ROEs were created without the knowledge of the true SIN-holder and the employer associated with the Canada Revenue Agency (CRA) business number (BN) indicated in block 5 of the ROE. There are also instances where there are reasons to suspect that the business identified on the ROE is illegitimate or suspicious and was created to issue fraudulent ROEs. These fraudulent ROEs were sent to Service Canada and scanned as documents in support of fraudulent applications for benefits, or uploaded in AW or MSCA. A close examination may reveal a difference in the font and size of the characters in the serial number of these ROEs when compared to the normal format. In some cases, RCM validates the serial number and does not signal the ROE as a duplicate, because that serial number was used to establish an EI claim more than 11 years ago. In other situations, the serial number has been issued within the last 11 years to a different business number than the one used on the fraudulent ROE, however, RCM validates the serial number but does not flag it as a duplicate because the ROE was never used to establish an EI claim.

When a suspicious business is identified, an Integrity officer changes the status of suspicious employers to Under investigation in RMDS, and changes the status of any associated ROEs to Stolen . Then, a SROC is automatically created in NWS for the associated application, indicating that the claim is under investigation.

When entering an ROE that has been marked as stolen, a message is displayed indicating that there is a problem with the status of the serial number. The Non-complex officer follows normal procedures and submits the ROE with the error, which creates an ROE Issue (ROE) Correction WI.

When entering an ROE (paper, scanned or uploaded), the officer may suspect that an ROE is fraudulent even if no error message is displayed about the status of the serial number. Before entering the ROE in RCM, the officer suspends the application process, if necessary, and refers the file to Integrity, if the file is not already under investigation. If no fact-finding is required, the officer follows normal procedures and enters the ROE. Once the ROE is entered in RCM, the officer deletes the ROE.

For more information, officers refer to Fraud indicators: Identifying potentially fraudulent claims — Knowledge.
       [Fraud indicators: Identifying potentially fraudulent claims — Knowledge.](/en/procedure/generic/additionalresources/fraud_indicator.shtml) 

### Amended ROE

Source topic: `en_EN/task/paperroe_regular/amended_roe.dita`

Amended ROEs replace existing ROEs. The serial number of the ROE that has been amended or replaced is typed exactly as shown in block 2 . 

### Fax or photocopy of a paper ROE

Source topic: `en_EN/task/paperroe_regular/fax_or_photocopy_of_a_paper_roe.dita`

When it is clear that a fax or photocopy of a paper or scanned ROE is from the employer (e.g. on letterhead, with fax coversheet from the employer or countersigned by the employer), the ROE is entered as an authentic ROE.

If the ROE’s origin cannot be confirmed, when entering the ROE, Fax or Photocopy is selected as appropriate.

Never ask an employer to fax an ROE. The completed ROE is considered partially sensitive and is designated Protected B. 

### Altered ROE

Source topic: `en_EN/task/paperroe_regular/altered_roe.dita`

An ROE that has been altered (e.g. information has been crossed-out and replaced) and not initialled may not be valid. The changes must be verified to determine if the ROE is valid. Mandatory fields are verified before entering the ROE and non-mandatory fields are verified after data entry by a non-complex user. 

### Invalid ROE

Source topic: `en_EN/task/paperroe_regular/invalid_roe.dita`

A client or employer may submit a document that looks like a valid ROE but does not contain a valid serial number. Any document that is not a valid ROE is never entered in RCM, even as an interim ROE. The employer is contacted and asked to issue a valid ROE (paper or electronic). 

### Parts of a paper ROE

Source topic: `en_EN/task/paperroe_regular/parts_of_a_paper_roe.dita`

There are 3 sections, or copies, of a paper ROE:

- Part 1 is the employee’s copy and is the copy that is normally submitted to Service Canada for data entry.

- Part 2 is Service Canada’s copy that the employer sends to National Services in Bathurst, NB. Once input, these copies can be viewed in Easy Access.

- Part 3 is the employer’s copy that is retained in the employer’s files.

If part 2 or 3 of the ROE is received, it must still be entered. 

### Easy Access

Source topic: `en_EN/task/paperroe_regular/easy_access.dita`

Easy Access stores copies of ROEs submitted by employers to Bathurst. If an ROE is missing or unreadable, some of the information from the ROE can be viewed and a copy can be obtained from Easy Access. 

### CRA business no. field

Source topic: `en_EN/task/paperroe_regular/cra_business_no_field.dita`

This mandatory field must contain all 15 characters of the employer’s business number (e.g. 123456789 RP 0001).

- The first 9 digits represent the employer’s GST number and cannot match the client’s SIN number.

- The 2 letters must be RP on ROEs to indicate the employer’s payroll program.

- The last 4 digits specify the payroll account or department. 

### Entering an ROE

Source topic: `en_EN/task/paperroe_regular/entering_an_roe.dita`

To illustrate the logical sequence for entering an ROE, and the procedures for correcting any corresponding issues, this task is divided into the following 6 sections:

**Section 1: Determine the ROE type (paper, scanned or uploaded)**

Officers who receive a faxed ROE from an employer or client, an uploaded ROE in NWS, or an ROE that cannot be scanned (illegible or damaged) can go to Section 3 to directly input the ROE into RCM without scanning it.

In NWS, the officer with an AI ROE Input WI views the ROE on the Uploaded Documents tab by selecting the correct ROE from available documents. The system identifies the serial number of the uploaded ROE in the Details field of the AI WI. The officer opens RCM to enter the ROE.

**Section 2: Retrieve an ROE from RMDS**

In RMDS, officers retrieve ROEs from one of the following workloads:

Incomplete: when retrieving the next oldest ROE to input that officers at the SCC cannot action.

In Progress: when retrieving an ROE that required fact-finding before input.

Pending: when retrieving the next oldest ROE to be input (only if the team leader informs officers to use this workload).

When a scanned ROE is selected in RMDS, the ROE and RCM open in a split screen for data entry.

**Section 3: Validate the ROE before data entry**

The following blocks are mandatory and must be complete or the ROE cannot be saved in RCM:

- block 1: Serial no.

- block 5: CRA business no.

- block 8: Social insurance no.

- block 11: Last day for which paid .

Identify all errors or omissions in these blocks before fact-finding, to avoid multiple calls to the employer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3342.dita) 

Fact-finding is not in every officer’s work profile. If an officer receives an ROE that requires fact-finding to determine the mandatory fields, and fact-finding is not in the officer’s work profile, the officer changes the WI issue type to AI Communication WI. Then, the officer refers to Reassigning the WI — Fact-finding required .
       [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3343.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3344.dita) 

**Section 4: Enter the SIN and serial number (Input short screen)**

After verifying that all mandatory blocks are complete, you may now enter the ROE in RCM. The ROE Input short screen displays the following fields:

- Social insurance no.

- Interim ROE type

- Serial no. (not mandatory for an interim ROE)

- Serial no. of the ROE amended or replaced

- Printing language: The default selection is the RCM display language.

Fax or photocopy ROE received from the employer : When it is clear that a fax or photocopy of an ROE is from the employer (e.g. on letterhead, with fax coversheet from the employer or countersigned by the employer), the ROE is entered as an authentic ROE. Do not select Fax or Photocopy . No follow-up with the employer is required.

Original ROE or serial number received after interim ROE has been input :

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3923.dita) 

Original ROE received after an amended ROE has been input :

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3930.dita) 

**Section 5: Enter the ROE (Input Regular ROE screen)**

Blocks 1 , 2 (if completed) and 8 are pre-filled on this screen from the ROE Input short screen.

Blocks 5 , 8 and 11 have already been verified in section 1. If further information is required during data entry, return to the blocks as outlined in section 1.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3931.dita) 

**Section 6: Finalize and submit the ROE**

This step allows the user to quickly review the data entered to ensure it corresponds to the data from the paper ROE, and to correct any errors before submitting the ROE. After the ROE is submitted, RCM validates the ROE. If the ROE contains an error, it is highlighted in red on the Search/Correct - Results screen.

For initial claims, ACP generates an ROE Correction WI for the next available user when ROE errors are identified by RCM or by Automated Readiness Trigger for electronic ROEs (W or S series).

ACP does not use any ROEs (paper or electronic) that contain errors or issues that may impact the calculation of an initial claim. The claim remains in the ROE wait process until the related ROE WI is completed or until the wait limit is reached. 

### Note

Source topic: `en_EN/common_notes/note_c_3340.dita`

Note:

A faxed ROE from the client or the employer can be input directly in RCM without scanning. 

### Note

Source topic: `en_EN/common_notes/note_c_3341.dita`

Note:

Officers can work in both RMDS and NWS separately to enter ROEs in RCM, as required. 

### Note

Source topic: `en_EN/common_notes/note_c_3342.dita`

Note:

If a close examination reveals that a paper ROE may be fraudulent, the officer does not fact-find with the employer. The officer suspends the application process, if necessary, and refers the file to Integrity, if the file is not already under investigation. 

### Note

Source topic: `en_EN/common_notes/note_c_3343.dita`

Note:

Temporary workload measure: When fact-finding is required for the ROE, non-complex officers who are able to fact-find change the WI issue type to AI Communications WI before completing the WI. 

### Note

Source topic: `en_EN/common_notes/note_c_3344.dita`

Note:

If block 20 is completed, respect the language preference indicated when contacting the employer. 

### Note

Source topic: `en_EN/common_notes/note_c_3923.dita`

Note:

If an employer provides the correct serial number or ROE after an interim ROE has been entered, enter the correct serial number or original ROE and complete the following fields:

- Serial no.: Type the serial number (provided by the employer) of the original ROE.

- Serial no. of ROE amended or replaced: Type the serial number of the interim ROE.

- Additional information: Type “Serial number of original ROE confirmed with employer after interim ROE input.” 

### Note

Source topic: `en_EN/common_notes/note_c_3930.dita`

Note:

If the original ROE is received after an amended ROE has been entered, complete the following field of the amended ROE:

- Additional information: Type “Original ROE serial XXXXXXXXX was received after amended ROE input. Cannot be data entered.”

- File the ROE. 

### Note

Source topic: `en_EN/common_notes/note_c_3931.dita`

Note:

If ROE fields have been changed and not initialled by the employer, leave the corresponding fields in RCM blank. In the Additional Information field, type the details of the original and altered information for these fields.

If the change has been made to Block 17, ensure that the ROE is saved with an error by doing the following (if applicable):

- 17A: Select Paid because no longer working and leave the amount blank, then type the details of the original and altered information in the Additional Information field.

- 17B: Type the date and leave the amount field blank or type the amount and leave the date field blank, then type the details of the original and altered information in the Additional Information field.

- 17C: Select the type of monies and leave the amount field blank, then type the details of the original and altered information in the Additional Information field. 

## Regional considerations

Source topic: `en_EN/task/paperroe_regular/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/paperroe_regular/what_you_need_to_look_for.dita`

## Step by step

Source topic: `en_EN/task/paperroe_regular/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/paperroe_regular/non-complex.dita`

#### Procedure

Source topic: `en_EN/task/paperroe_regular/procedure.dita`

- Section 1: Determine the ROE type (paper, scanned or uploaded)
         [Section 1: Determine the ROE type (paper, scanned or uploaded)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#deter_ROE_type)

- Section 2: Retrieve an ROE from RMDS
         [Section 2: Retrieve an ROE from RMDS](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#retriveve_roe)

- Section 3: Validate the ROE prior to data entry
         [Section 3: Validate the ROE prior to data entry](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#valROE)

- Section 4: Enter the SIN and serial number (Input short screen)
         [Section 4: Enter the SIN and serial number (Input short screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#EnterSIN)

- Section 5: Enter the ROE (Input Regular ROE screen)
         [Section 5: Enter the ROE (Input Regular ROE screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#EnterROE)

- Section 6: Finalize and submit the ROE
         [Section 6: Finalize and submit the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Finalize)

- Section 7: Reassigning the WI — Fact-finding required
         [Section 7: Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

- Section 8: Fraud indicators are present
         [Section 8: Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Fraud_indicators_are_present) 

#### Section 1: Determine the ROE type (paper, scanned or uploaded)

Source topic: `en_EN/task/paperroe_regular/section_1_determine_the_roe_type_paper__a5f07ed0_non-complex.dita`

- Determine if the ROE was scanned or uploaded:

- If it is a scanned ROE, go to Section 2 .
               [Section 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#retriveve_roe)

- If it is a paper ROE that cannot be scanned, go to Section 3 .
               [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#valROE)

- If it is an uploaded ROE, go to Section 3 .
               [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#valROE)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3932.dita) 

#### Section 2: Retrieve an ROE from RMDS

Source topic: `en_EN/task/paperroe_regular/section_2_retrieve_an_roe_from_rmds_non-complex.dita`

- In RMDS, select the Scanned ROEs tab and do one of the following:

- To input ROEs that have an Incomplete status, go to step 2.

- To input ROEs that have a Pending status, go to step 3.

- To input ROEs that have an In Progress status, go to step 4.

- Select Search Scanned ROEs and do the following:

- PDF status: Select Incomplete .

- Language: Select English or French .

- Select Search .

- Select View ROE . The ROE opens in a split screen with RCM. Go to Section 3 .
               [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#valROE)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3933.dita)

- Select Process Scanned ROE and do the following:

- Select Next English PDF or Next French PDF . The ROE opens in a split screen with RCM.

- Go to Section 3 .
               [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#valROE)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3348.dita)

- Select Search Scanned ROEs and do the following:

- SIN: Enter the client’s SIN.

- PDF status: Select In Progress .

- Language: Select English or French .

- Select Search .

- Select View ROE . The ROE opens in a split screen with RCM.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3349.dita) 

#### Section 3: Validate the ROE before data entry

Source topic: `en_EN/task/paperroe_regular/section_3_validate_the_roe_before_data_entry_non-complex.dita`

- Determine if block 1 is complete (e.g. serial number starts with an “A” and is followed by 8 numbers):

- If block 1 is complete, go to Review block 5: CRA business no .
               [Review block 5: CRA business no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock5)

- If block 1 is not complete, go to one of the following:

- The serial number is incomplete .
                   [The serial number is incomplete](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#serialnumberincomplete)

- The serial number is not valid (Invalid ROE).
                   [The serial number is not valid (Invalid ROE).](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#serialnumbernotvalid)

- Determine if the ROE is displayed in Easy Access:

- If the ROE is displayed, use the serial number shown when entering the ROE. As there may be multiple ROEs, ensure that the correct one is selected. Go to Review block 5: CRA business no .
               [Review block 5: CRA business no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock5)

- If the ROE is not displayed, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to obtain the complete serial number:

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

- If the serial number is obtained, use that serial number when entering the ROE. Go to Review block 5: CRA business no .
               [Review block 5: CRA business no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock5)

- If the serial number is not obtained, go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita)

- Enter the ROE as an interim ROE (after verifying that blocks 5, 8 and 11 are complete):

- Interim ROE type: Select Regular Interim .

- Additional information: Type “The serial number is illegible so the original ROE could not be input.”

- Go to Review block 5: CRA business no .
               [Review block 5: CRA business no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock5)

- If a client or employer submits an ROE with an invalid serial number (e.g. begins with the letter T), do the following:

- Do not enter the ROE.

- Determine which system is being used to view the ROE:

- If it is RMDS, change the status of the scanned ROE to In Progress .

- If it is in NWS, move the AI ROE Input WI to Pending.

- Determine if the paper ROE is potentially fraudulent, if fraud indicators are present and if fraud is suspected by referring to Fraud indicators: Identifying potentially fraudulent claims — Knowledge and reviewing the file.

- If the paper ROE is potentially fraudulent, go to Section 8: Fraud indicators are present .
                   [Section 8: Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Fraud_indicators_are_present)

               [Fraud indicators: Identifying potentially fraudulent claims — Knowledge](/en/procedure/generic/additionalresources/fraud_indicator.shtml)

- Determine if fact-finding is in your work profile:

- If yes, fact-find with the employer to request that a valid ROE be submitted.
                   [fact-find](/en/procedure/task/fact_find.shtml)

- If no, reassign the AI ROE Input WI. Go to Reassigning the WI — Fact-finding required .
                   [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3934.dita)

- Determine if block 5 is complete (e.g. business number is 9 digits, followed by the payroll account number):

- If block 5 is complete but the first 9 digits of block 5 match the client’s SIN, verify the employer’s business number. Go to First 9 digits of block 5 match the SIN .
               [First 9 digits of block 5 match the SIN](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#first9match)

- If block 5 is complete, go to Review block 8: Social insurance no .
               [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If block 5 is not complete, go to one of the following:

- Block 5 is incomplete or has been altered without being initialled .
                   [Block 5 is incomplete or has been altered without being initialled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#block5incomplete)

- All or part of the payroll account number (e.g. RP0001) is missing .
                   [All or part of the payroll account number (e.g. RP0001) is missing](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#allorpartpanmissing)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3927.dita)

- In FTS, select the Employer search and enter the employer’s name:

- If the business number is displayed in the results and it is different than the SIN, use that business number when entering the ROE. Go to Review block 8: Social insurance no .
               [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If the business number displayed in the results is the same as the SIN, go to step 3.

- If the business number is not displayed in the results, go to step 2.

- In RCM, determine if the client has worked for the same employer previously. The business number may be on the prior ROE.

- If the business number is displayed on a previous ROE for the same employer and is different than the SIN indicated on the ROE, use that business number when entering the ROE. Go to Review block 8: Social insurance no .
               [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If there are no other ROEs for that employer or if the business number displayed in the results is the same as the SIN, go to step 3.

- In FTS, select the Claimant (MN04) search and enter the client’s last and first name:

- If the SIN is displayed in the results and is different than the SIN indicated on the ROE, use that SIN and complete the following field when entering the ROE:

- Additional information: Type “Correct SIN obtained from FTS.”

- Go to Review block 8: Social insurance no .
                   [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If the SIN is not displayed in the results, go to step 4.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to obtain the correct business number or SIN.

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

- If the correct business number or SIN is obtained, go to Review block 8: Social insurance no .
               [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If the correct business number or SIN is not obtained, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita)

- In FTS, select the Employer (MN22) search and type the employer’s name:

- If the search by employer name displays the business number, use that business number when entering the ROE. Go to Review block 8: Social insurance no .
               [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If the search by employer name does not display the business number, go to step 2.

- In RCM, determine if the client has worked for the same employer previously. The business number may be on the prior ROE.

- If the business number is displayed on a previous ROE for the same employer, use that business number when entering the ROE. Go to Review block 8: Social insurance no .
               [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If there are no other ROEs for that employer, go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to obtain the business number.

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

- If the business number is obtained, go to Review block 8: Social insurance no .
               [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If the business number is not obtained, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- In FTS, select the Employer (MN22) search and type the first 9 digits of the business number:

- If the search by business number displays only one business number, use that business number when entering the ROE. Go to Review block 8: Social insurance no .
               [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If the search by business number displays more than one business number, go to step 2.

- In RCM, determine if the business number is displayed on a previous ROE from this same employer:

- If the business number is displayed on a previous ROE, use that business number when entering the ROE. Go to Review block 8: Social insurance no .
               [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If there are no other ROEs for that employer, go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to obtain the correct business number.

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

- If the business number is obtained, go to Review block 8: Social insurance no .
               [Review block 8: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock8)

- If the business number is not obtained, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita)

- Determine if block 8 is complete:

- If block 8 is not complete or has been altered and not initialled, go to step 2.

- If block 8 is complete, do the following based on the situation:

- If the SIN starts with a 0 or an 8, go to step 2.

- If the SIN does not start with a 0 or an 8, go to Review block 11: Last day for which paid .
                   [Review block 11: Last day for which paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock11)

- If the client uploaded a paper ROE in AW or MSCA and the ROE has been issued with the wrong SIN, go to step 4.

- In FTS, select the Claimant (MN04) search and enter the client’s last and first name:

- If the SIN is displayed in the results, use that SIN and complete the following field when entering the ROE:

- Additional information: Type “Correct SIN obtained from FTS.”

- Go to Review block 11: Last day for which paid .
                   [Review block 11: Last day for which paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock11)

- If the SIN is not displayed in the results, go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to obtain the SIN:

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

- If the SIN is obtained from the employer, use that SIN when entering the ROE. Go to Review block 11: Last day for which paid .
               [Review block 11: Last day for which paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock11)

- If the SIN is not obtained from the employer, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Fact-find with the employer to confirm the client’s uploaded ROE was issued with the wrong SIN:

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

- If the SIN is confirmed with the employer, go to step 5.

- If the SIN is not confirmed with the employer, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “SIN confirmed for uploaded ROE — employer contact [employer’s name] — [last day worked (LDW)].

- Details: Type “Employer confirmed the uploaded ROE [serial number] was issued with the wrong SIN. The ROE belongs to the client.” Document the fact-finding details according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](http://servicecanada.prv/eng/ei/reference-material/policy-legislation/national_policy_factfinding.shtml#5.4)

- Select Save .

- Review block 11: Last day for which paid .
                   [Review block 11: Last day for which paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock11)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita)

- Determine if block 11 is complete:

- If block 11 is complete, go to Section 4: Enter the SIN and serial number (Input short screen) .
               [Section 4: Enter the SIN and serial number (Input short screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#EnterSIN)

- If block 11 is not complete or has been altered but not initialled, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3935.dita)

- Fact-find with the employer to determine the date of the last day for which the client was paid (last day paid):

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

- If the last day paid is obtained, complete the following field when entering the ROE:

- Additional information: Type “The correct last day paid was obtained from the employer [employer’s name].”

- Go to Section 4: Enter the SIN and serial number (Input short screen) .
                   [Section 4: Enter the SIN and serial number (Input short screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#EnterSIN)

- If the last day paid is not obtained, go to step 3.

- In ACS, send a Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name ( 1334)

- Employer or Third Party Address ( 1336)

- Employer or Third Party Address ( 2440)

- Employer or Third Party Address ( 2441)

- To whom it may concern — Madam or Sir — Madam — Sir — Text ( 2418)

- Opening Sentence to ER re: Request or Clarify ROE/RFS ( 2794)

- Request ROE Opening Sentence — claimant

- Claimant First Name ( 1044)

- Claimant Last Name ( 1046)

- Request for Record of Employment ( 2797)

- Request for Additional ROE Information

- Text — Free Text (Block 2797): Type “Please provide us with the last day for which the employee was paid for the following ROE: XXXXXXXXX.”

- This Letter Replaces or Footnote (2365):

- Footnote: Type in bold text “Instead of replying by mail, if you prefer, you can provide the information to [your name] by telephone at [your telephone number].”

- Attachment List for Z-02-00-00: select

- Employer’s Response for Additional ROE Information .

- In NWS, create a Reminder (REM) WI to follow up on the letter sent to the employer and complete the following fields:

- Complexity: Select Non-Complex .

- Reason: Select Fact-Finding Employer .

- Comments: Type “last day paid information.”

- Due Date: Enter the date that is 10 working days from today.

- Language: Select the appropriate option based on the preferred language of employer.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Myself .

- When the REM WI comes out of pending, or if the employer returns contact, determine if the employer has provided the date of the last day for which the client was paid:

- If the employer has provided the last day paid, use the date provided and complete the following field when entering the ROE:

- Additional information: Type “The correct last day paid was obtained from the employer (type employer’s name).”

- Go to step 8.

- If the employer has not provided the last day paid, go to step 6.

- Contact the client to obtain the date of the last day paid:

- If the last day paid is obtained, complete the following field when entering the ROE:

- Additional information: Type “The correct last day paid was obtained from the client”

- Go to Step 7.

- If the last day paid is not obtained or the client is not reached:

- Complete the REM WI.

- Refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
                   [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- In ACS, send a Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name ( 1334 )

- Employer or Third Party Address ( 1336 )

- Employer or Third Party Address ( 2440 )

- Employer or Third Party Address ( 2441 )

- To whom it may concern — Madam or Sir — Madam — Sir — Text ( 2418 )

- Notification of Changes to a ROE ( 2805 ): select one of the following

- Multiple Changes to ROE

- A Single Change to ROE

- We ( 2687 )

- List of corrections / attached INS 3413 (Block 2806): select List of corrections and type "The last day for which paid has been changed to DD/MM/YYYY.” (Provide the date given by client).

- In NWS, complete the REM WI.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita) 

#### Section 4: Enter the SIN and serial number (Input short screen)

Source topic: `en_EN/task/paperroe_regular/section_4_enter_the_sin_and_serial_numb_0b24b47b_non-complex.dita`

- On the ROE Input short screen, complete the fields as follows:

- Social insurance no.: Type the SIN verified in section 3.

- Interim ROE type: If the serial number is incomplete, select Regular Interim . If this choice is selected, leave the Serial no . field and the Serial no. of ROE amended or replaced field blank.

- Serial no.: Type the serial number verified in section 3.

- Serial no. of the ROE amended or replaced: If block 2 is complete, enter the serial number of the amended or replaced ROE.

- Select Submit .

- Determine if an error message is displayed:

- If no error message is displayed, go to Section 5: Enter the ROE (Input Regular ROE screen) .
               [Section 5: Enter the ROE (Input Regular ROE screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#EnterROE)

- If an error message is displayed, go to the appropriate section below:

- Error message: Invalid Social Insurance Number or Social insurance number must be 9 numeric characters and not all zeros .
                   [Invalid Social Insurance Number or Social insurance number must be 9 numeric characters and not all zeros](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#InvalidSIN)

- Error message: Invalid Serial Number .
                   [Invalid Serial Number](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#InvalidSerial)

- Error message: Serial Number already exists for that SIN in the ROE database .
                   [Serial Number already exists for that SIN in the ROE database](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#serialalreadyexists)

- Error message: This Serial Number (SN) has already been entered for another Social Insurance Number (SIN) or A problem was detected with the status of this Serial Number (SN) .
                   [This Serial Number (SN) has already been entered for another Social Insurance Number (SIN) or A problem was detected with the status of this Serial Number (SN)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#serial)

- Verify if the ROE received is the original ROE, and if it is replacing a faxed or photocopied ROE that has been entered in RCM:

- If the ROE is the original and it is replacing a fax or photocopy that has been entered, go to step 2.

- If the ROE is not the original or is not replacing a fax or photocopy that has been entered, return to Review block 1: Serial no.
               [Review block 1: Serial no.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reviewblock1)

- Open the ROE in RCM to verify if the information on the ROE received is the same as the information on the fax or photocopy that was entered:

- If the information is the same, complete the following field:

- Fax or photocopy: Select Authentic ROE .

- Additional information: Type “Original ROE received, compared to fax or photocopy, and in order.”

- Select Submit .

- Go to section 6, step 6: Determine how to file the ROE .
                   [Determine how to file the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#fileROE)

- If the information is not the same, go to step 3.

- Determine if any changes from the initial ROE have been noted in the audit trail:

- If the changes have been noted in the audit trail, complete the following fields:

- Fax or photocopy: Select Authentic ROE .

- Additional information: Type “Original ROE received, compared to fax or photocopy, changes noted in audit trail.”

- Select Submit .

- Go to section 6, step 6: Determine how to file the ROE .
                   [Determine how to file the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#fileROE)

- If the changes have not been noted in the audit trail, go to step 4.

- Fact-find with the employer to confirm the changes:

- If the employer confirms the changes, complete the following fields:

- Fax or photocopy: Select Authentic ROE .

- Additional information: Type “Original ROE received, confirmed changes in fax or photocopy with employer (include the name of the person contacted).”

- Go to section 6, step 6: Determine how to file the ROE .
                   [Determine how to file the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#fileROE)

- If the employer does not confirm the changes, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita) 

#### Section 5: Enter the ROE — RCM Input page 2

Source topic: `en_EN/task/paperroe_regular/section_5_enter_the_roe__rcm_input_page_2.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3936.dita) 

Enter the blocks of the ROE as follows:

Block 3: Employer’s payroll reference no.: This optional block is for the employer’s referencing purposes.

- If completed, type the reference number as provided.

- If not completed, leave blank.

Block 4: Employer’s name and address:

- If completed, type the employer’s name and address as provided.

- If the employer’s name is absent or illegible, do the following:

- In FTS, select the Employer (MN22) search and enter the employer’s business number:

- If the search by business number displays the employer’s name, type it in the Employer’s name field.

- If the search by business number does not display the employer’s name, fact-find with the employer to obtain it.
                 [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3353.dita) 

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
                     [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Reassigning)

- If the employer’s name is obtained, in the Additional information field, type “Employer’s name obtained from employer (include the name of the person contacted).”

- If the employer’s name is not obtained, leave blank.

                 [fact-find](/en/procedure/task/fact_find.shtml)

- If the employer’s address is absent or illegible, leave blank.
         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita)

Block 5: CRA business no.:

- Enter the business number.

Block 6: Pay period type:

- If completed, select the pay period type from the drop down menu as provided.

- If not completed, leave blank.

Block 7: Employer’s postal code:

- If completed, type the postal code as provided.

- If not completed, leave blank.

Block 8: Social insurance no . :

- The SIN is prefilled from Input short screen.

Block 9: Employee’s name and address:

- If completed, type the employee’s name and address as provided.

- If the employee’s name is missing, do the following:

- Type the SIN into the appropriate field in FTS to obtain client name.

- If the employee’s identity is not verified, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
             [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If the address is illegible or partially incorrect, type the address provided in the application for benefits (if one exists) or leave blank

Block 10: First day worked:

- If completed, type the date as provided.

- If not completed, leave blank.

Block 11: Last day for which paid:

- Enter the last day for which the client was paid.

Block 12: Final pay period ending date:

- If completed, type the date as provided.

- If not completed, leave blank.

Block 13: Occupation:

- If completed, type the occupation as provided.

- If not completed, leave blank.

Block 14: Expected date of recall:

- If completed, select Expected date of recall and enter the date as provided or as follows:

- If only the month and year were provided, enter the last day of that month.

- If only the year was provided, enter December 31 of that year.

- If not completed, select Unstated .

Block 15A: Total insurable hours:

- Type the number of hours as provided. Round up any fractions of an hour (e.g. if the ROE shows 585.25 hours, round up to 586).

Block 15B: Total insurable earnings:

- If completed, type the amount as provided, including dollars and cents.

- If completed, but changes have been made and not initialled, review Block 15C: Pay period details prior to making decisions on how to correct block 15B .

- If not completed, leave blank.

Block 15C: Pay period details (Insurable earnings by pay period):

- If completed (and block 15B had no changes that were not initialled) or modified and initialled), type the amounts as provided.

- If not completed, leave blank.

- If block 15B is modified and block 15C is not completed:

- Block 15B: Total insurable earnings: Leave blank.

- Additional information: Type “Block 15B altered from $XXX.00 to $XXX.00 — not initialled.”

- If block 15B is modified and block 15C is completed:

- Block 15B: Total insurable earnings: Leave blank.

- Block 15C: PP 1 Insurable earnings: Leave blank.

- Additional information: Type “Block 15B modified from $XXX.00 to $XXX.00 — not initialled. Block 15C PP1 = $XXX.00 (original amount input by the employer).”

- If any amounts are modified and not initialled by the employer, complete the following:

- Block 15C: PP 1 Insurable earnings: Leave blank.

- Additional information: Type “Block 15C PP1 = $XXX.00 original amount input by the employer. Block 15C PP XX original amount = $XXX.00 and was altered to $XXX.00 but not initialled by the employer.”

If an Optional Weekly Pay Period Worksheet has been provided, complete the appropriate action as follows:

- If the ROE does not display a weekly pay period:

- Do not enter the amounts of the Optional Weekly Pay Period Worksheet.

- Send the worksheet to Imaging and write “PAˮ on the first page.

- If the ROE displays a weekly pay period type:

- In block 15C , starting at PP 28 , type the additional amounts as provided.

- Send the worksheet to Imaging and write “PAˮ on the first page.

Block 16: Reason for issuing this ROE:

- If completed, select the reason for separation (RFS) as provided, or do one of the following:

- If the RFS provided is C — Return to School and there are no comments in block 18 related to apprenticeship training, complete block 16 as follows:

- Reason for separation: Select E — Quit / Return to school .

- If comments related to apprenticeship training are provided in block 18 , refer to ROE: Actions required for comments found in block 18 of a regular ROE — Instructions .
             [ROE: Actions required for comments found in block 18 of a regular ROE — Instructions](/en/procedure/generic/table_block18.shtml)

- If the RFS provided is G — Retirement , select G — Mandatory Retirement .

- If modified or not completed, complete the following fields:

- Reason for separation: Leave blank.

- Additional information: Type “Block 16 modified from X to X and not initialled, or blank.”

Block 17A: Vacation Pay:

- If there is an amount, do one of the following:

- If Vacation pay type is specified in block 17A or in block 18 , select the correct vacation pay type and enter the amount as provided.

- If Vacation pay type is not specified in block 17A or in block 18 , select Paid because no longer working and enter the amount as provided.

- If not completed, leave blank.

Block 17B: Statutory holiday pay for:

- If completed, type the details as provided. If partially completed, do one of the following:

- If the statutory holiday amount is indicated with no date, input the amount and leave the Date from (ddmmyyyy) field blank.

- If the statutory holiday date indicated with no amount, input the date and leave the Amount ($) field blank.

- If not completed, leave blank.

Block 17C: Other monies (specify): Examples of other monies include pay in lieu of notice, severance pay, pension pay-out, retroactive wage increases or various bonuses.

- If completed, enter the information as provided. Further details may be shown in block 18: Comments . If necessary, consult the table below.

- If not completed, leave blank.

```text
| RCM Field | Issue | Correction |

| 17C | Employer completed block 17C and the type of monies indicated is not listed in the drop-down menu. | Select O — Other and indicate the nature of the monies as provided by the employer in the Additional Information field. |

| | Employer completed block 17C with vacation pay or statutory holiday pay. | Complete the appropriate block 17A or 17B . |

| | Severance pay | Select E — Severance Pay . Note: Severance pay is considered not insurable. |

| | Retiring allowance | Select R — Retiring Allowance/Retirement Leave Credit . |

| | Supplemental | Select the appropriate option: U — Supplemental / SUB Maternity/Parental/Compassionate Care/Family caregiver U — Supplemental / SUB — Layoff U — Supplemental / SUB — Illness U — Supplemental / SUB — Training Note: Leave the Payer name and Meets Regulation 38 fields blank since there is no functionality at this time in RCM. |

| 17C/18 | Severance pay and a comment in block 18 regarding insurable severance pay (rare). | Select Y — Pay in lieu of notice and type the comments in the Additional Information field as provided by the employer. |

| 17C | Pension (not a pay out of pension credits). | Pension must not be entered as O — Other in block 17C on the ROE. Transcribe the information into block 18 . |
```

Block 18: Comments:

Determine if block 18 is completed, and if the comments correspond to any of the comments in ROE: Actions required for comments found in block 18 of a regular ROE — Instructions :
       [ROE: Actions required for comments found in block 18 of a regular ROE — Instructions](/en/procedure/generic/table_block18.shtml)

- If completed, and the comments are found in the chart, complete the RCM inputs indicated.

- If completed, and the comments are not found in the chart, type the comments in block 18 as provided.

- If not completed, leave blank.

Block 19: Special Payments: Special payments include sick, maternity, parental, compassionate care or family caregiver benefits leave or group wage loss indemnity payments (after the last day worked).

- If completed and the special payment type is provided in block 18 , select the special payment type and enter the payment details as provided. If necessary, consult the table below.

- If completed and no additional information appears in block 18 that justifies the special payment type, select Paid sick leave as the special payment and input the payment details as provided. In block 18 , type “no indication of special payment type is provided in block 19.”

- If not completed, leave blank.

```text
| Issue | Correction |

| Paid Sick Leave or Paid Maternity/Parental/Compassionate Care/Family caregiver Leave | Complete block 19: Select the special payment type and input the appropriate payment information in the following fields: Start date, End date , Amount (per day or per week) and Duration , if provided. |

| Wage Loss Indemnity — block 19 information provided clearly shows the payment is Wage Loss Indemnity (EI Insurable) or Wage Loss Indemnity (Not EI Insurable) . This may be determined by reviewing comments provided in block 18 . | Complete block 19: Select the special payment type and input the payment as either Wage Loss Indemnity (EI Insurable) or Wage Loss Indemnity (Not EI Insurable) . Input the appropriate payment information in the following fields: Start date , End date, Amount (per day or per week) and Duration , if provided. Consult ROE: Actions required for comments found in block 18 of a regular ROE — Instructions for information related to comments in block 18 . [ROE: Actions required for comments found in block 18 of a regular ROE — Instructions](/en/procedure/generic/table_block18.shtml) |

| Wage Loss Indemnity — data entry unable to determine if the payment is Wage Loss Indemnity (EI Insurable) or Wage Loss Indemnity (Not EI Insurable) after reviewing comments provided in block 18 . | Complete block 19: Select the special payment type and input the payment as Wage Loss Indemnity (Not EI Insurable) . Input the appropriate payment information in the following fields: Start date, End date, Amount (per day or per week) and Duration , if provided. In block 18 , type “no indication of special payment type is provided in block 19 .” Consult ROE: Actions required for comments found in block 18 of a regular ROE — Instructions for information related to comments in block 18 . [ROE: Actions required for comments found in block 18 of a regular ROE — Instructions](/en/procedure/generic/table_block18.shtml) |
```

Block 20: Communication preferred in:

- If completed, select English or French as provided.

- If not completed, leave blank.

Block 21: Telephone number:

- If completed, enter the telephone number provided.

- If not completed, enter the telephone number provided in block 16 .

- If there is no telephone number provided in block 16 , enter “000 0000000.”

Block 22: Signature/Name of issuer: An ROE produced by a computer requires the printed name only. A signature is required only if the issuer makes changes on the hard copy of the ROE. In this case, the changes must also be initialled. No follow-up is needed when the issuer signs the ROE but does not complete the Name of issuer (please print) field .

- Enter the name of the issuer as shown.

- If the ROE has been produced by computer and does not have a signature, leave blank.

- If the ROE has been completed by hand with no signature, complete the following field:

- Status: Check the Unsigned box.

- If the ROE is signed by the client , complete the following fields:

- Additional information: Type “signed by client.”

- Status: Check the Unsigned box.

Block 22: Date issued:

- If completed, type the date shown.

- If the issue date is incomplete or blank, do the following:

- If the date of receipt is known, complete the following fields:

- Date issued: Type the date that the ROE is received.

- Additional information: Type “Issue date is blank or incomplete and the date of receipt was data entered.”

- If the date of receipt is unknown, complete the following fields:

- Date issued: Leave blank. The ROE will be saved to RCM with the current date as the issue date.

- Additional information: Type “Issue date is blank or incomplete and the date of receipt is unknown.”

Status:

- For data entry purposes, this field is used only in the following situations:

- You need to delete a ROE after the serial number has been entered incorrectly (under the correct SIN).

- The ROE has been entered under the wrong SIN.

- The ROE has been completed by hand and is not signed by the issuer.

- The ROE has been signed by the client.

Fax or photocopy:

- If the authenticity of a fax or photocopy ROE is confirmed (i.e. it is clearly from the employer), leave the default setting Authentic ROE .

- If the authenticity of a fax or photocopy ROE is not confirmed, select Fax or Photocopy as appropriate. 

#### Section 6: Finalize and submit the ROE

Source topic: `en_EN/task/paperroe_regular/section_6_finalize_and_submit_the_roe_non-complex.dita`

- Select Submit .

- Determine if the following error message is displayed: Please review the errors on the page. Are you sure you want to submit the ROE as shown?

- If the error message is not displayed, go to step 4.

- If the error message is displayed, verify that the data entered accurately reflects the information on the paper ROE:

- If the information is accurately reflected, select Yes to submit the ROE. Go to step 4.

- If the information is not accurately reflected, select no to return to input screen and go to step 3.

- Correct the errors. If the amounts in blocks 15B and 15C do not match, do the following:

- Review all of the pay periods in block 15C .

- Ensure that all pay periods are complete according to the pay period type (e.g. maximum of 27 pay periods for a biweekly pay period).

- Review the data entries for accuracy and correct any errors you identify.

- If the pay periods are complete and you did not identify any errors in the data entered, remove the amount in block 15B .

- Select Validate .

- Return to step 1.

- Determine if the ROE is potentially fraudulent:

- If yes, go to step 5.

- If no, go to step 6.

- In RCM, open the ROE and delete it as follows:

- Delete: Check the box.

- Additional information: Type “Suspicious ROE. ROE has been deleted to prevent it from being used in benefits calculation until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- Go to step 6.

- Determine how to file the ROE:

- If the ROE was scanned and uploaded to RMDS and it is a duplicate, employer copy or illegible ROE, delete the PDF file in RMDS as follows:

- Select Scanned ROE .

- Select Search Scanned ROE .

- SIN: Enter the client’s SIN.

- PDF Status: Select Incomplete .

- Select Search .

- Open the ROE by selecting View ROE .

- Select Delete Backpage .

- No further action is required.

- If the ROE was viewed and input in RCM from the Uploaded Documents tab in NWS:

- If fact-finding was conducted, ensure that the WI issue type has been updated to AI Communications WI and complete the WI.

- If no fact-finding was necessary, complete the AI ROE Input WI.

- If the paper ROE is a fax, photocopy or part 1, refer to Preparing documents for imaging to send the ROE to Imaging to be put in the PA pile:
               [Preparing documents for imaging](/en/procedure/task/prep_docs_imaging.shtml)

- If the paper ROE is part 2 and the authenticity of the ROE is not in doubt, do the following:

- Send the original to Bathurst at the following address: NICOLAS DENYS BUILDING 120 HARBOURVIEW BOULEVARD BATHURST NB E2A 7R2

- If the paper ROE may be fraudulent, refer to Preparing documents for imaging to send the ROE to Imaging to be put in the PA pile.
                   [Preparing documents for imaging](/en/procedure/task/prep_docs_imaging.shtml)

- If the paper ROE is part 3 and the authenticity of the ROE is not in doubt, return it to the employer address provided in block 4 .

- If the paper ROE may be fraudulent, refer to Preparing documents for imaging to send the ROE to Imaging to be put in the PA pile.
                   [Preparing documents for imaging](/en/procedure/task/prep_docs_imaging.shtml) 

#### Section 7: Reassigning the WI — Fact-finding required

Source topic: `en_EN/task/paperroe_regular/section_7_reassigning_the_wi__fact-find_3d99d956_non-complex.dita`

- In NWS, reassign the AI ROE Input WI as follows:

- On the Specific Details tab, do the following:

- Issue: Select Communications .

- Select Save .

- Reassign the WI as follows:

- Destination: Select Next available user .

- Reason: Select Unable to complete .

- Details: Type “Requires fact-finding, not within officer’s work profile.”

- Select OK . 

#### Section 8: Fraud indicators are present

Source topic: `en_EN/task/paperroe_regular/section_8_fraud_indicators_are_present_non-complex.dita`

- In NWS, determine if any of the following WIs are on file:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2922.dita) 

- If no, go to step 2.

- If yes, go to step 20.

- Determine if any of the following are on file and directly related to the potentially fraudulent application:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2923.dita) 

- If no, go to step 3.

- If yes, go to step 6.

- In NWS, determine if a suspected fraud has previously been referred to Integrity in an AI WI that has not been completed:

- If yes, go to step 4.

- If no, go to step 5.

- Add the information related to the potentially fraudulent application to the existing Integrity AI WI as follows:

- Right-click and select Add details/Further Inquiry

- Action: Select Additional information

- Details: If a fraudulent application has been completed, type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” Type “ROE [serial number] with business number [CRA business number] contains inconsistencies.” If the ROE could not be entered, type “ROE cannot be entered.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the region where the client lives:

- Processing - ATL

- Processing - QC

- Processing - ON

- Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue(s): Select ROE .

- Comments: Type “Fraud suspected — indicators present.”

- Details: If a fraudulent application has been completed, type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” Type “ROE [serial number] with business number [CRA business number] contains inconsistencies.” If the ROE could not be entered, type “ROE cannot be entered.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- In FTS, determine if the initial claim has already been calculated:

- If yes, go to step 7.

- If no, go to step 13.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If no, go to step 8.

- If yes, go to step 11.

- In FTS, determine if there is an outstanding renewal registration number:

- If yes, go to step 9.

- If no, go to step 10.

- In NWS, determine if the outstanding renewal registration number is related to the fraudulent application:

- If yes, go to step 10.

- If no, go to step 20.

- Determine if the client’s claim has been compromised:

- If yes, go to step 11.

- If no and there is an outstanding renewal registration number related to the fraudulent application, go to step 19.

- If no and there is no outstanding renewal registration number related to the fraudulent application, go to step 20.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2651.dita)

- Determine if an MA71 has already been imposed:

- If no, go to step 12.

- If yes and there is an outstanding renewal registration number related to the fraudulent application, go to step 19.

- If yes and there is no outstanding renewal registration number related to the fraudulent application, go to step 20.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Do the following:

- If there is an outstanding registration number related to the fraudulent application, go to step 19.

- If there is no outstanding registration number related to the fraudulent application, go to step 20.

- Determine if there is an outstanding initial registration number:

- If yes, go to step 14.

- If no, go to step 20.

- In NWS, determine if the outstanding initial registration number related to the fraudulent application:

- If yes, go to step 15.

- If no, go to step 20.

- Determine if a D71 has already been imposed:

- If no, go to step 16.

- If yes, go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2663.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

- Go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3929.dita)

- In NWS, determine if the Claim action Status is Finalized - Pending LREM :

- If yes, go to step 18.

- If no, go to step 19.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- Go to step 20.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1576.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the registration number related to the fraudulent application as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 20.

- In RCM, determine it the ROE can be entered:

- If it is an uploaded ROE, go to step 21.

- If it is a scanned ROE, change the status in RMDS to In Progress . No further action is required.

- If it is a fax, photocopy or paper ROE (part 1, 2 or 3), return to step 6 of Section 6: Finalize and submit the ROE .
               [Section 6: Finalize and submit the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Finalize)

- If yes, return to step 1 of Section 6: Finalize and submit the ROE .
               [Section 6: Finalize and submit the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_regular#Finalize)

- If no, take the following action based on the situation:

- In NWS, determine if there is an AI ROE Input WI:

- If yes, complete the WI.

- If no, return to the previous task. 

#### Note

Source topic: `en_EN/common_notes/note_c_3932.dita`

Note:

If an ROE was scanned and is illegible, send an email to the GD mailbox the scan came from and request a copy of the ROE. If the copy that is then received is also illegible, refer to Section 6, step 6 to delete the PDF file.
       [Section 6, step 6](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fileROE)

If an ROE was uploaded and is illegible, validate the ROE with the client or employer. Refer to Section 3 .
       [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#valROE)

If the uploaded ROE is illegible and fact-finding to validate the ROE is not in your work profile, change the WI issue type to AI Communications WI and reassign the WI to the next available user in NWS.

     [Section 6, step 6](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fileROE) 
     [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#valROE) 

#### Note

Source topic: `en_EN/common_notes/note_c_3933.dita`

Note:

If the scanned document is a blank page or a page other than an ROE, delete it by selecting Delete Backpage . Refer to Section 6, step 6 .
       [Section 6, step 6](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fileROE)

If fact-finding is required at any time during the input of a scanned ROE, change the status of the ROE to In Progress . This status signals to officers that the ROE input is currently being actioned by another officer.

     [Section 6, step 6](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fileROE) 

#### Note

Source topic: `en_EN/common_notes/note_c_3348.dita`

Note:

If fact-finding is required at any time during the input of a scanned ROE, change the status of the ROE to In Progress . This status signals to officers that the ROE input is currently being actioned by another officer. 

#### Note

Source topic: `en_EN/common_notes/note_c_3349.dita`

Note:

If the client’s SIN is not known, search by PDF status and locate the ROE by the client’s name. 

#### Note

Source topic: `en_EN/common_notes/note_c_3352.dita`

Note:

If a paper ROE may be fraudulent, do not fact-find with the employer or enter the ROE. Refer to Section 8: Fraud indicators are present .
       [Section 8: Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fraud_indicators_are_present)

     [Section 8: Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fraud_indicators_are_present) 

#### Note

Source topic: `en_EN/common_notes/note_c_3351.dita`

Note:

If it is a scanned ROE and a callback is required or the ROE is sent to Integrity, change the status in RMDS to In Progress .

If it is an uploaded ROE and a callback is required or the ROE is sent to Integrity, move the AI ROE Input WI to Pending following normal procedures. Refer to Fact-Finding or Creating or reassigning a WI — Integrity , if necessary.
       [Fact-Finding](/en/procedure/task/fact_find.shtml) 
       [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

     [Fact-Finding](/en/procedure/task/fact_find.shtml) 
     [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_3934.dita`

Note:

If it is a scanned ROE and a callback is required or the ROE is sent to Integrity, change the status in RMDS to In Progress .

If it is an uploaded ROE and a callback is required or the ROE is sent to Integrity, move the AI ROE Input WI to Pending following normal procedures. Refer to Fact-Finding or Creating or reassigning a WI — Integrity , if necessary.
       [Fact-Finding](/en/procedure/task/fact_find.shtml) 
       [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

Once the valid ROE is submitted, delete the PDF file in RMDS with the invalid serial number. Refer to section 6, step 6, How to file the ROE, for instructions on how to delete the PDF file in RMDS.

For uploaded ROEs, no action for the invalid scan is necessary.

     [Fact-Finding](/en/procedure/task/fact_find.shtml) 
     [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_3927.dita`

Note:

If it is a scanned ROE and a callback is required or the ROE is sent to Integrity, change the status in RMDS to In Progress . 

#### Note

Source topic: `en_EN/common_notes/note_c_3935.dita`

Note:

If a paper ROE may be fraudulent, do not fact-find with the employer or client, or enter the ROE. Refer to Section 8: Fraud indicators are present .
       [Section 8: Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#Fraud_indicators_are_present)

     [Section 8: Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#Fraud_indicators_are_present) 

#### Note

Source topic: `en_EN/common_notes/note_c_3936.dita`

Note:

If you notice, after selecting Submit , that you have entered the serial number incorrectly but under the correct SIN, complete the following fields:

- Status: Check the Delete box.

- Additional information: Type “ROE deleted — originally entered under incorrect serial number.”

- Select Submit .

Return to the Input short screen and enter the ROE using the correct serial number. 

#### Note

Source topic: `en_EN/common_notes/note_c_3353.dita`

Note:

If a paper ROE may be fraudulent, do not fact-find with the employer. Leave the block blank. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2922.dita`

- a Claim Review (CR) Integrity ERB-EI Transition WI related to the potentially fraudulent application;

- an AI WI from Integrity indicating that the claim can be established;

- a Call Back (CB) WI about the potentially fraudulent application. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2923.dita`

- an Integrity AI WI;

- an Integrity SROC;

- a 71 - Integrity Services case disentitlement (D71) or a 71 - Integrity Services case manual action (MA71);

- in RMDS, on the Employer profile screen, the Under investigation box is checked. 

#### Note

Source topic: `en_EN/common_notes/note_c_2651.dita`

Note:

A claim is considered to be compromised when the client’s information (address or direct deposit information) has been changed. If the claim is compromised, impose an MA71. 

#### Note

Source topic: `en_EN/common_notes/note_c_2663.dita`

Note:

Before imposing a D71, confirm that the file does not already include one. In such cases, if a transaction is input to impose a D71, the existing D71 is cancelled. 

#### Note

Source topic: `en_EN/common_notes/note_c_3929.dita`

Note:

If error code C072: Invalid Claim action or Action field (C072) is displayed when inputting the Renewal/Revised (M106) transaction, the D71 cannot be imposed. Go to step 17. 

#### Note

Source topic: `en_EN/common_notes/note_c_1576.dita`

Note:

If error code 836: WARNING - Flag 33 claim (Last Record of Employment Missing), claim is still polling for the last record of employment is displayed when attempting to clear the registration number, check the Override box to process the transaction. 

## Policy reference

Source topic: `en_EN/task/paperroe_regular/policy_reference.dita`

 
