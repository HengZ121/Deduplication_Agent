# Adjudicating voluntary leaving (Level 1): Other employment — Renewal claim

Source map: `en_EN/task/vllevel1_oe_rc/vllevel1_oe_rc.ditamap`

## Summary

Source topic: `en_EN/task/vllevel1_oe_rc/summary.dita`

Summary: When a client voluntarily leaves employment with the intent of starting other employment, the client’s entitlement to regular benefits on a renewal claim may be affected. Adjudication is required to determine if there was just cause for leaving the employment. 

## What you need to know

Source topic: `en_EN/task/vllevel1_oe_rc/what_you_need_to_know.dita`

### Adjudicating voluntary leaving for other employment

Source topic: `en_EN/task/vllevel1_oe_rc/adjudicating_voluntary_leaving_for_othe_4cb01a91.dita`

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave the employment. If it is determined that the client left the employment without just cause, a disqualification is imposed on the claim for regular benefits, unless the client has enough insurable hours since the voluntary leaving to establish a new claim. In this case, the ROE with the voluntary leaving is excluded from the calculation of the claim.

Voluntary leaving for other employment includes the following situations:

- voluntarily leaving a job to start another within 4 weeks

- voluntarily leaving a job to continue to work full-time in another (when working both jobs at the same time)

- voluntarily leaving one job for another when there is a genuine job offer (but the new job is not obtained for reasons beyond the client’s control)

- voluntarily leaving insurable employment to become self-employed

Voluntary leaving for other employment does not include the following situation:

- voluntarily leaving to look for another job

An ROE is not required to adjudicate a voluntary leaving.

In NWS, there may be a “New ROE” message displayed on the Adjudication Issue (ADJ) WI for the voluntary leaving issue. The message indicates that a new ROE has been received with a reason for separation (RFS) that must be reviewed. The ROE may match the period of employment for that ADJ WI or for another outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4924.dita) 

### Automated adjudication

Source topic: `en_EN/task/vllevel1_oe_rc/automated_adjudication.dita`

On renewal claims, ACP may adjudicate if the voluntary leaving is for one of the following reasons:

- to start another job

- to leave a job to continue working full-time in another job that is held at the same time

If ACP has adjudicated a voluntary leaving and the officer identifies a discrepancy (e.g. ACP has automated a decision based on a gap of less than 2 weeks but the ROE shows a gap of more than 4 weeks), the officer must review the information and amend the decision. 

### Levels of decision

Source topic: `en_EN/task/vllevel1_oe_rc/levels_of_decision.dita`

A Level 1 officer can adjudicate voluntary leaving on a renewal claim when specific conditions are met and the client left employment for one of the following reasons:

- accepting other employment;

- leaving one employment and continuing full-time employment;

- accepting a genuine job offer scheduled to start in the 2 weeks after the last day worked (LDW) from the previous employment;

- beginning self-employment (SE).

When the Level 1 officer cannot adjudicate the issue, the facts are documented and the voluntary leaving is referred to Level 2 for adjudication. 

### Determining full-time employment

Source topic: `en_EN/task/vllevel1_oe_rc/determining_full-time_employment.dita`

Full-time employment means that the employee works the number of hours normally worked by full-time employees in the occupation or industry.

In most cases, full-time employment means working 35 hours or more per week. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/vllevel1_oe_rc/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Previously deferred decision

Source topic: `en_EN/task/vllevel1_oe_rc/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a ROD in NWS. If the RFS was adjudicated and a 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D11 that is on file and update the Special Condition field on the ROE in RCM. 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/vllevel1_oe_rc/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the voluntary leaving is not required if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, an authorized user must delete the ADJ WI.

If the client reports voluntary leaving on the EI application  and the ROE indicates a non-contentious RFS, fact-finding is required. If it is determined that the client’s RFS is non-contentious (e.g. shortage of work, sickness), the WI is completed indicating the non-contentious RFS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4925.dita) 

### Claim action status and processing the claim

Source topic: `en_EN/task/vllevel1_oe_rc/claim_action_status_and_processing_the_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . All ADJ WIs must be completed before the system can finalize the renewal. There is a Resolve Issue tab for ADJ Voluntary leaving WIs which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a record of decision (ROD) based on the Resolve Issue screens. When the renewal is finalized, the system generates the required transactions based on the Resolve Issue screens and removes the payment (MA02). No letter is sent when the client is allowed to voluntarily leave an employment to follow another individual.

In some cases, the ADJ WI may be for a voluntary leaving issue that was previously adjudicated. The officer indicates on the Resolve Issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the special condition that applies based on the previous decision. 

### Adjudication not previously required — Specialized ACP process

Source topic: `en_EN/task/vllevel1_oe_rc/adjudication_not_previously_required__s_a89cd8c4.dita`

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the qualifying period (QP). The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0092.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4924.dita`

Note:

The client may report voluntary leaving on the EI application but the ROE indicates a non-contentious RFS. In this situation, fact-finding is required. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the WI is completed indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_4925.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0092.dita`

Note:

Any contentious RFS issues in the benefit period (BP) must be adjudicated. 

## Regional considerations

Source topic: `en_EN/task/vllevel1_oe_rc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/vllevel1_oe_rc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/vllevel1_oe_rc/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Voluntary Leave section of this or a previous EI application?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details related to the voluntary leaving on this or a previous EI application? 

### In Imaging:

Source topic: `en_EN/task/vllevel1_oe_rc/in_imaging.dita`

- Are there any imaged documents related to the voluntary leaving? 

### In RCM:

Source topic: `en_EN/task/vllevel1_oe_rc/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving? 

## Step by step

Source topic: `en_EN/task/vllevel1_oe_rc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/vllevel1_oe_rc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/vllevel1_oe_rc/reviewing_the_file_level_1.dita`

- Determine if there is a ROD for the voluntary leaving issue on file:

- If there is no ROD for the voluntary leaving issue, go to step 2.

- If there is a ROD for the voluntary leaving issue, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_oe_rc#DecisionOnFile)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred, by referring to Deferring adjudication .

- Determine if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 5.

- If the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_oe_rc#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if there is enough information to adjudicate the voluntary leaving based on the National Policy on Levels of Decision :

- If additional details are needed, go to step 6.

- If additional details are not needed, go to step 9. 

#### Fact-finding

Source topic: `en_EN/task/vllevel1_oe_rc/fact-finding_level_1.dita`

- Fact-find with the client or the employer.

- Determine if the client or employer was contacted during fact-finding:

- If the client or employer was contacted, go to step 8.

- If the client or employer was not contacted or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_oe_rc#Reassigning_the_WIissue)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue : Select Reason for separation .

- Comments : Type “Voluntary leaving — [employer’s name] — [last day worked] — [client or employer].”

- Details : Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/vllevel1_oe_rc/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the RFS is contentious:

- If the RFS is voluntary leaving, go to step 10.

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS) .
               [Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_oe_rc#RFSVL)

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if the conditions are met to adjudicate the issue at Level 1 by referring to the applicable situation.

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4957.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4958.dita) 
           [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4959.dita) 
           [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4960.dita) 
           [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4961.dita) 

- If all the conditions are met, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_oe_rc#Reason_for_separation)

- If all the conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_oe_rc#Reassigning_the_WIissue) 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/vllevel1_oe_rc/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Select For another job .

- Select the reason why the issue is allowed.

- Verify the information on the Record of Decision screen:

- Select I agree .

- In FTS, determine if a D11 was imposed because this RFS adjudication was previously deferred:

- If yes, go to step 5.

- If no, go to step 7.

- Determine if the D11 was only imposed due to this previously deferred RFS issue and no other issues must be adjudicated:

- If no other issues must be adjudicated, refer to step 6.

- If other issues must be adjudicated, refer to the appropriate task for guidance. Go to step 6.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F – Non-fraud - Other

- Message: Select 1 – An overpayment resulted due to a disqualification.

- Contentious: Select 1 - No .

- Complete: Select C – Yes .

- Select Update .

- In RCM, determine if the ROE is on file:

- If no, go to step 8.

- If yes, in RCM, update the Special condition field and go to step 8.

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/vllevel1_oe_rc/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Contact an authorized user (team leader or business expertise advisor) to delete the ADJ WI. 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/vllevel1_oe_rc/non-contentious_reason_for_separation_rfs_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The reason for separation is not voluntary leaving .

- Select Continue .

- Complete the Not voluntary leaving screen as follows:

- Select the appropriate RFS.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Select I agree .

- In RCM, determine if the ROE is on file:

- If yes, go to step 5.

- If no, go to step 7.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select the appropriate RFS option and sub-option, if necessary.

- Select Validate .

- Select Submit .

- Determine if the ROE was flagged in error after validation:

- If yes, fix the validation error and go to step 7.

- If no, go to step 7.

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/vllevel1_oe_rc/decision_already_on_file_level_1.dita`

- Determine if the applicable decision is listed:

- If yes, on the list, select the applicable ROD and select Save . Go to step 4.

- If no, select Decision not in the list .

- Select the applicable special condition based on the decision on file and select Continue .

- Verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/vllevel1_oe_rc/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Client quit [his/her] job and [provide a brief reason for the referral, e.g. employment gap is greater than 4 weeks] — unable to complete at Level 1.”

- Select OK .

- When the Warning window is displayed, select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4957.dita`

Voluntary leaving to accept other employment — Conditions to adjudicate the issue at Level 1 (all conditions must be met)

- the new employment started within 4 weeks of the LDW of the previous employment; and

- the BPC or renewal week is after the week the new employment started; and

- the new employment was supposed to be a permanent position; or

- if the new job was temporary, it was to last longer than the job the client quit; and

- the weekly number of hours at the new employment was equal to or greater than the weekly number of hours worked at the previous employment; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

Examples of situations that can be adjudicated at Level 1

- The client left a permanent job offering 35 working hours per week for another job offering 35 working hours per week or more.

- The client left a temporary full-time job that was expected to last for 20 weeks for another temporary full-time job that was expected to last 20 weeks or more.

Examples of situations that must be adjudicated at Level 2

- The client left a full-time permanent job for a permanent job that is seasonal or part-time.

- The client left a temporary full-time job that was expected to last a year for a new permanent part-time job.

- The client left a full-time permanent job for a new full-time temporary job, despite knowing that this new employment would be of short duration. 

#### Note

Source topic: `en_EN/common_notes/note_c_4958.dita`

Note:

Temporary employment is defined as seasonal, contract or term employment. It is employment with an end date.

Permanent employment is defined as a lasting employment, or an employment that is intended to last or to remain unchanged indefinitely. It has no end date.

Confirmation from the employer or from the ROE is not required to verify the gap between jobs or the duration of employment. However, if at any point you become aware that the new job started later than 4 weeks from the date of leaving, or that the client did not start the new job at all, go to Reassigning the issue to Level 2 .
       [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#Reassigning_the_WIissue)

     [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#Reassigning_the_WIissue) 

#### Callout

Source topic: `en_EN/common_notes/note_c_4959.dita`

Voluntary leaving when there is a reasonable assurance of other permanent employment — Conditions to adjudicate the issue at Level 1 (all conditions must be met)

- the client had a genuine employment offer that was scheduled to start within 2 weeks of the LDW of the previous employment. Confirmation from the prospective employer is required; and

- the client did not start the new employment because the offer was withdrawn or cancelled for reasons unrelated to the client or the client’s actions. Confirmation from the prospective employer is required; and

- the client was unable to withdraw the resignation from the previous employment and unable to return to it; and

- the new job was supposed to be permanent; and

- the weekly number of hours at the new employment would have been equal to or greater than the weekly number of hours worked at the previous employment; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4960.dita`

Voluntary leaving when there is a reasonable assurance of other temporary employment — Conditions to adjudicate the issue at Level 1 (all conditions must be met)

- the client had a genuine job offer that was scheduled to start within 2 weeks of the LDW of the previous employment. Confirmation from the prospective employer is required; and

- The client did not start the new employment because the offer was withdrawn or cancelled for reasons unrelated to the client or the client’s actions. Confirmation from the prospective employer is required; and

- the client was unable to withdraw the resignation from the previous employment and was unable to return to it; and

- the client quit one temporary employment for another temporary employment; and

- the new temporary employment was supposed to last the same amount of time or longer than the previous temporary employment; and

- the weekly number of hours at the new employment would have been equal to or greater than the weekly number of hours worked at the previous employment; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4961.dita`

Voluntary leaving employment to continue working in full-time employment — Conditions to adjudicate the issue at Level 1 (all conditions must be met)

- the client had more than one employment at the same time and voluntarily left one of them; and

- the employment the client kept was full-time and the client was not expecting it to end

Voluntary leaving to begin SE — Conditions to adjudicate the issue at Level 1 (all conditions must be met)

- the SE activities or the operation of the business started within 2 weeks of the date the client quit the employment; and

- the client has ceased SE activities or stopped operating the business; and

- the BPC or renewal week is after the start week of the SE activities or business; and

- the client is not requesting benefits for the SE or business operation period; and

- the client is capable of and available for work and poses no restrictions towards accepting employment. 

## Policy reference

Source topic: `en_EN/task/vllevel1_oe_rc/policy_reference.dita`

- Digest 6 — Voluntarily leaving employment
         [Digest 6 — Voluntarily leaving employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/table-of-contents.html)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html) 
