# Adjudicating an Integrity case — Unreported earnings

Source map: `en_EN/task/aic_unreported_earnings/aic_unreported_earnings.ditamap`

## Summary

Source topic: `en_EN/task/aic_unreported_earnings/summary.dita`

Summary: Investigators inform us of the results of an investigation in which they find that clients have not properly declared their earnings or other remuneration. 

## What you need to know

Source topic: `en_EN/task/aic_unreported_earnings/what_you_need_to_know.dita`

### Processing an Integrity claim review

Source topic: `en_EN/task/aic_unreported_earnings/processing_an_integrity_claim_review.dita`

Below are the main processing steps for this activity. If the officer determines that the client knowingly made a false or misleading statement, the officer must adjudicate the unreported earnings issue, complete the record of decision (ROD), and refer to Misrepresentation to determine the type of sanction to impose. The officer must input the complete decision after determining the sanction.
       [Misrepresentation](/en/procedure/activity/misrepresentation.shtml) 

### Reconsidering a decision

Source topic: `en_EN/task/aic_unreported_earnings/reconsidering_a_decision.dita`

EIA 52 states that a claim for benefits may be reconsidered as long as it results in an overpayment (OP) or an underpayment (UP). The time limit for reconsidering a claim is 36 months from the week benefits were paid or payable. This period is extended to 72 months if there is a false or misleading statement.
       [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

**Determining if a false statement was made**

A false statement is a statement that is incorrect or untrue. It can be the result of an intentional or negligent action, or it can be the result of an honest mistake.

For example, a client declares $100.00 in earnings but a subsequent investigation shows that the client actually earned $225.00. At this point, the officer only knows that the information provided by the client is incorrect. Without an explanation from the client, it cannot be determined if the client intentionally or knowingly reported the incorrect amount. Regardless of whether it was intentional or an honest mistake, the client reported the incorrect amount; therefore the reconsideration timeframe can be extended to 72 months.

**Determining if a false statement was knowingly made**

Knowingly means the officer can reasonably conclude that clients knew the information provided was untrue when they provided or did not report that information. There is no element of intent in this consideration. It is not necessary to determine a degree of fault. The officer must only establish that it is more likely that the clients or employers understood the information provided and did not accurately portray the facts.

In the case of unreported or wrongly declared earnings, the investigator must send a Request for Clarification of Employment Information (INS5098) form to the client so the client can explain the differences. If the client does not return the completed form or if the explanation provided does not explain the differences, the officer can then demonstrate that the client knowingly made a false statement or a misrepresentation.
       [(INS5098)](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5098.pdf)

If the client received payments by paper cheque, each cheque cashed can be considered a misrepresentation under EIA 38(1)(e). If the client received payments by direct deposit, each direct deposit payment or any excess amount the client received and did not return can be considered a misrepresentation under EIA 38(1)(f).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1819.dita) 

**Reviewing a potential case of voluntary disclosure**

The National Policy on Voluntary Disclosure encourages clients, employers and third parties to come forward and voluntarily disclose misrepresentations. According to this policy, voluntary disclosure occurs when a person admits to having knowingly made a false statement.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

An investigator may recommend that the file be reconsidered in light of the National Policy on Voluntary Disclosure .
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

There are 2 essential conditions for approving the voluntary disclosure:

- There is no investigation under way in relation to the voluntary disclosure when a client admits to making a false statement.

- The false statement would have resulted in punitive measures such as a penalty, a warning or prosecution had there been no voluntary disclosure.

According to the National Policy on Voluntary Disclosure , there is no limit to the number of times that a client can voluntarily disclose misrepresentations.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 

### Determining the nature of earnings

Source topic: `en_EN/task/aic_unreported_earnings/determining_the_nature_of_earnings.dita`

To correctly allocate all earnings, the officer must know the reason the earnings are paid or are payable. The nature of the earnings must be established to determine if they come from employment.

As stated in EIR 35 , a payment must come from employment, e.g. wages or other earnings resulting from a loss of employment. Payment can affect the client’s entitlement to benefits. Any amounts resulting from a lottery win, a private medical insurance or an inheritance are never considered earnings as they have no link to employment and therefore do not affect the client’s entitlement to benefits.
       [EIR 35](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-35.html) 

### Allocating earnings

Source topic: `en_EN/task/aic_unreported_earnings/allocating_earnings.dita`

Once it has been established that the amount is considered earnings according to EIR 35 , the officer determines how to allocate it.
       [EIR 35](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-35.html)

EIR 36 stipulates when and how to allocate earnings that are paid or payable. There are 3 ways to allocate earnings, depending on the nature and the reason for the payment:
       [EIR 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html)

- for a specific week during which income was paid or was payable;

- for a specific calendar week during which the event occurred (in the absence of past service);

- depending on the client’s normal weekly earnings.

When determining how to allocate earnings, the officer must consider the 3 following factors:

- type of earnings

- gross amount

- reason for which earnings were paid.

Clients may work for more than one employer during the period of a claimant’s report. When allocating unreported earnings using allocation code A - Amended earnings , officers must consider earnings that were correctly declared from another employer on the original claimant’s report. Earnings from another employer must be added to the unreported earnings for each week and the total amount is allocated.

**Allocating banked hours**

The expression “banked hours” is used to describe different situations. In the most common situation, clients work more hours in a week than they regularly do. The clients do not receive payment for the extra hours but rather accumulate the hours for future time off. The compensatory leave is considered earnings and allocated to the week in which the leave is taken. Any accumulated hours that are paid out upon separation or an anniversary date are allocated to the period worked.

There is also a fraudulent scheme that is referred to as “banking of hours.” It is a method of payment that consists of creating a bank of hours that can range from negative hours (client owes time worked to the employer) or positive hours (employer did not pay all the hours worked).

Here is an example of what a system of banked hours can look like for a client that regularly works 40 hours per week.

```text
| Week | Hours worked | Hours paid | Bank |

| Week 1 | 40 | 40 | 0 |

| Week 2 | 28 | 0 | +28 |

| Week 3 | 43 | 40 | +31 (28 + 3) |

| Week 4 | 0 | 40 | -9 (31-40) |

| Week 5 | 27 | 0 | +18 (-9 + 27) |

| Week 6 | 22 | 40 | 0 (18 -18) |
```

While working, the client also had an active benefit claim. The client claimed and received a full week of benefits for weeks 2 and 5 as no earnings were declared on the claimant’s report. At the end of the season, the employer issues an ROE indicating 40 hours for weeks 1, 3, 4 and 6, and 0 hours for weeks 2 and 5. As the weekly rate of EI benefits is calculated based on the best weeks of insurable earnings, the client’s benefit rate is higher than it would have been if it had been based on the actual hours worked in a given week.

In this type of situation, the earnings are allocated to the period worked and the ROE should reflect the hours shown in the “hours worked” column.

**Coding a full work week (FWW)**

When clients report earnings on their claimant’s report, the earnings are coded along with an FWW code, if necessary. An FWW is coded if the client declared working 35 hours or more (28 in a week containing one of these 4 federal statutory holidays: New Year’s Day, Canada Day, Labour Day, Christmas Day). An investigation could reveal that FWW s have been coded when the client did not work or worked less than an FWW . When an FWW must be removed, the officer documents the decision on a ROD. 

### Allocating earnings from self-employment (SE)

Source topic: `en_EN/task/aic_unreported_earnings/allocating_earnings_from_self-employment_se.dita`

To determine if the monies paid or payable to the client are SE earnings that must be allocated, the officer determines the true nature of the payment, its purpose and its origin. Once the officer determines that the monies are considered earnings, the officer calculates the net income and allocates the monies to the period for which the work was performed.

For more information on determining if the SE monies are considered earnings, if an allocation is necessary and the method for calculating the net income, the officer refers to Allocating self-employment earnings and Digest 5 — Earnings .
       [Allocating self-employment earnings](/en/procedure/task/all_se_earnings.shtml) 
       [Digest 5 — Earnings](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/table-of-contents.html) 

### Self-employment earnings investigations

Source topic: `en_EN/task/aic_unreported_earnings/self-employment_earnings_investigations.dita`

When allocating earnings from a self-employment earnings investigation, the officer may notice that the investigator used a simplified method to calculate the net income and expenses.

The investigator uses a simplified method if the following conditions are met:

- there are more than 10 services or transactions;

- financial statements indicating the net income are available.

If there are 10 or less services or transactions or there is no financial statement indicating the net income, the investigator calculates the net income manually.

The simplified method to calculate income and expenses is as follows:

- Income: The investigator determines income using any available accounting document and the following formula:

- Annual profit ÷ number of weeks the SE company is in operation = weekly income

- Expenses: The investigator determines expenses using the total annual expenses and the following formula:

- Total expenses ÷ number of weeks the SE company is in operation = weekly expenses

When the investigator uses the simplified method to calculate income and expenses, the investigator uses the Self-Employment Calculation — Tool to determine the net weekly income to allocate. The investigator saves a copy of the results and sends it to Imaging or Integrity Investigations Document Upload System.
       [Self-Employment Calculation — Tool](https://014gc.sharepoint.com/:x:/r/sites/ISB-Training-DGSI-Formation/Shared Documents/3-Other References/Self-employment/Self-Employment Calculation Tool COE ENG.xlsx?d=w8f99f47677a7444e9de6b544ed006af7&csf=1&web=1&e=aXfmwL) 

### Returning a file to Integrity

Source topic: `en_EN/task/aic_unreported_earnings/returning_a_file_to_integrity.dita`

After conducting a full review of the investigation, if the Level 2 officer determines that facts are missing, the officer returns the investigation to the investigator for further fact-finding and indicates the information that is missing but necessary to adjudicate the issue. The Level 2 officer must not adjudicate the issue if facts are missing or incomplete.

Facts are not considered missing or incomplete if the investigator has followed up with the client when the client fails to report for an interview or fails to reply to a request for information. The investigator is not required to send a follow-up letter but must make 2 attempts on 2 different days to contact the client by telephone. If the investigator leaves a message on a voicemail, only one attempt is required and they must allow 48 hours for the client to respond.

**Investigation type 70 for voluntary disclosure cases**

If the investigator recommends that the Integrity case be considered as voluntary disclosure, but the investigation type is not 70 in NIIS, the officer returns the file to Integrity.

**Incomplete information from the employer**

When adjudicating a case of unreported earnings, the Level 2 officer can notice that the employer did not fully complete the section about other monies on the Request for Payroll Information (INS5097) form. In this case, the officer returns the case to Integrity for further fact-finding only if:

- The investigator, when reviewing the case, had to contact the employer to clarify other issues on the INS5097 form but did not clarify the section about other monies.

If the employer did not complete the section about other monies, the Level 2 officer adjudicates the case as is. In this situation, it is assumed that no other monies were paid to the client.

If the employer selected Yes in the section about other monies but did not provide details, the Level 2 officer adjudicates the case as is, if the investigator, while reviewing the case, did not have to contact the employer for any other issues on the INS5097 form.

The Integrity Services Branch does not verify the employer’s or third party’s version against the client’s version in the following situations:

- The investigation results in an actual or potential OP of less than the Integrity investigative threshold.

- There is no other active investigation.

In these situations, the officer does not return the case to Integrity because the employer’s or the third party’s version is missing. The officer is not required to validate the threshold. 

### Defining claim status (CS)

Source topic: `en_EN/task/aic_unreported_earnings/defining_claim_status_cs.dita`

A claim can be active, terminated, blocked or archived. The claim status impacts which transactions can be input and when the letter of decision is sent:

- Active: The active claim is established and is currently displayed automatically in FTS. It is a claim for which benefits are still payable and that has not been terminated.

- Terminated: A terminated claim appears on the Dormant tab in FTS. It has ended but can be reactivated. Once the transaction to reactivate the claim has been processed, all inputs for the claim must be done the same as for an active claim.

- Blocked: In some cases, the claim that the officer must reconsider is on the Dormant tab in FTS, but there is a new active claim established and displayed on the Summary screen. The officer makes adjustments to this type of claim using BCS if the blocked CS shows 1 - Updateable . Otherwise, IPOC intervention is required.

- Archived: Claims that are more than 7 years old are moved from the Dormant tab to the Archived tab. The officer can view an archived claim by changing the status of the archived claim from 1 - Non-Viewable to 2 - Viewable in FTS. Once the officer requests to make the claim viewable, the status field immediately displays 2 - Viewable and the claim becomes viewable the next business day for 2 weeks. Adjustments to this type of claim are processed with IPOC intervention. 

### Determining the order of FTS inputs

Source topic: `en_EN/task/aic_unreported_earnings/determining_the_order_of_fts_inputs.dita`

Controlled, multiple-day inputs in FTS are required to establish separate OPs for each decision, such as unreported earnings and reason for separation (RFS). When there is more than one reconsideration decision that results in an OP, the decisions must be input in the following order:

**Determining the input order for multiple transactions**

- full disentitlement

- partial disentitlement

- unreported earnings or unreported allocation of earnings

- indefinite disqualification

- definite disqualification

Controlled inputs in FTS are also required for UP and OP situations. The officer processes the inputs resulting in the OP first. Once the OP is established, the officer inputs an agreed deduction equal to the benefit rate amount. For more information, the officer refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

### BCS

Source topic: `en_EN/task/aic_unreported_earnings/bcs.dita`

BCS allows certain types of transactions to be processed on blocked dormant claims. There are 2 options available: Estimate and Claim update .

**Claim update function**

When transactions must be input on a blocked claim, the officer reviews the Blocked Claims System tab in FTS to determine the CS in BCS. If the CS is 1 - Updateable , the officer requests an update using BCS and processes the transactions.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1820.dita) 

An update in BCS can only be done on one BPC at a time. When transactions are input but not processed, Yes appears in the Block Action Pending column and access is denied for input on all other BPCs until the requested transactions are processed. Access to a BPC with a pending action is limited to the officer who initiated that action.

If an update is requested by the officer but cannot be completed by BCS, on the next processing day, the “Blocked claim not updated or not calculated” message is displayed along with the exception, error or warning on the MR05 screen.

Officers review the exception, error or warning on the Results tab in BCS for further action. If the update cannot be completed using BCS, the system presents an estimate result. The decision can be sent to IPOC using the Forward via MM06 link, which creates the prefilled M106 and MM06. 

### Estimate function

Source topic: `en_EN/task/aic_unreported_earnings/estimate_function.dita`

The Estimate function in BCS allows officers to view and evaluate the end results without processing the transactions. Estimates are possible for blocked claims with a 1 - Updateable status as well as unblocked dormant claims, provided the claim status is 05 (inactive) or 06 (terminated) .

BCS Estimate transactions are processed overnight and the results are available on the Results tab the next day. Officers that have requested an estimate can view the end result and forward the request for IPOC intervention using the prefilled MM06 available on the Results tab.

**Creating an Operational Centre Memo (MM06) transaction for multiple issues**

When the MM06 includes multiple issues, if at least one issue is deemed to be a misrepresentation whereas at least another one is not, the officer ensures to include the appropriate OP message code for each issue in the Remarks section.

When the transaction is related to an allocation and an extension to the BP, the officer sends the MM06 to IPOC for the entire decision. 

### Record of decision (ROD)

Source topic: `en_EN/task/aic_unreported_earnings/record_of_decision_rod.dita`

The Level 2 officer must record and document each decision in a separate ROD. 

### Note

Source topic: `en_EN/common_notes/note_c_1819.dita`

Note:

A false statement made knowingly does not always result in an OP of benefits. Since a monetary penalty is calculated based on the OP resulting from the misrepresentation, the officer can consider sending a warning letter if the client knowingly made a false statement but this misrepresentation does not result in an OP. 

### Note

Source topic: `en_EN/common_notes/note_c_1820.dita`

Note:

At this time, BCS cannot process a benefit period (BP) extension, the recalculation of a claim or the removal of a manual action (MA). The officer must send an Operational Centre Memo (MM06) transaction asking IPOC to process these transactions. 

## Regional considerations

Source topic: `en_EN/task/aic_unreported_earnings/regional_considerations.dita`

**Quebec — Returning the file to Integrity**

In addition to the information already indicated in this procedure, return the file to Integrity as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a Cc.

- In NWS, create a client Note and type “Measure — returned to Integrity” and include the date (YYYY-MM-DD). 

## What you need to look for

Source topic: `en_EN/task/aic_unreported_earnings/what_you_need_to_look_for.dita`

### In NIIS:

Source topic: `en_EN/task/aic_unreported_earnings/in_niis.dita`

- Review the IC07 Subject Enquiry screen for all active and prior cases.

- Review the IC04 Observation screen for a computer generated investigation.

- Review the IC08 Case Summary screen to see the actions taken on the case.

- Review the IC56 Case Notes screen to ensure you have the complete case.

- Review the IC50 Report of Clerical Investigation or IC70 Report of Investigation screen.

- Is there an Integrity Investigation Sheet?

- Is there a Report of Interview? 

### In Imaging:

Source topic: `en_EN/task/aic_unreported_earnings/in_imaging.dita`

- Is there a Request for Payroll Information (INS5097) form?

- Is there a Request for Clarification of Employment Information (INS5098) form?

- Are there any documents that are relevant to the case? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/aic_unreported_earnings/in_integrity_investigations_document_up_6a8da64b.dita`

- Are there any documents that are relevant to the case? 

### In NWS:

Source topic: `en_EN/task/aic_unreported_earnings/in_nws.dita`

- Review the EI application.

- Review SROCs, ROD, Action Item (AI) WIs and Call Back (CB) WIs for information relevant to the case.

- Are there documents related to the issue? 

### In FTS:

Source topic: `en_EN/task/aic_unreported_earnings/in_fts.dita`

- If necessary, review the claimant reports for the weeks under investigation.

- Is there an exemption from reporting?

- If yes, did the client receive payments by direct deposit?

- Review the Transaction History for any inputs that might impact the investigation.

- What is the CS (active, terminated, blocked or archived)?

- If the claim is blocked, what is the CS in BCS?

- Is there an FWW code 1, 2 or 3 in any of the reports under investigation? 

## Step by step

Source topic: `en_EN/task/aic_unreported_earnings/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/aic_unreported_earnings/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/aic_unreported_earnings/reviewing_the_file_level_2.dita`

- Determine if there is a false statement:

- If no, go to step 2.

- If yes, go to step 3.

- Determine if the request for reconsideration was made within the 36-month time limit:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_unreported_earnings#NotWithin)

- Determine if the request for reconsideration is within the maximum reconsideration timeframe of 72 months:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_unreported_earnings#NotWithin)

- In NWS, create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction ):

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if the information gathered by Integrity is complete:

- If the information is complete, go to step 6.

- If the information is incomplete, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_unreported_earnings#Return)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1667.dita)

- If necessary to adjudicate the issue, refer to Earnings or Digest 5 — Earnings .

- If the amount is considered earnings and must be allocated, go to step 7.

- If the amount is not considered earnings and must not be allocated, go to No allocation .
               [No allocation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_unreported_earnings#NoAllocation)

- Determine if the client knowingly made a false or misleading statement as described in Digest 18.3.1.4 — Misleading and Digest 18.3.1.5 — Knowingly :

- If there is a false statement that is knowingly made, go to step 8.

- If there is a false statement that is not knowingly made, go to step 11.

- If there is no false statement, go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_unreported_earnings#Reconsideration)

- Determine if the investigator recommends that the file be reconsidered in light of a voluntary disclosure, as described in National Policy on Voluntary Disclosure :

- If the voluntary disclosure criteria are not met, go to step 9.

- If the voluntary disclosure criteria are met but the investigation type in NIIS is not 70, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_unreported_earnings#Return)

- If the voluntary disclosure criteria are met and the investigation type in NIIS is 70, go to Voluntary disclosure approved .
               [Voluntary disclosure approved](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_unreported_earnings#Voluntary)

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — earnings.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Indicate the earnings type. There could be more than one earnings type.

- Explain the allocation of the earnings in relation to sections 35 and 36 of the EIR and Digest 5 — Earnings .
               [sections 35](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-35.html) 
               [36 of the EIR](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html) 
               [Digest 5 — Earnings](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/table-of-contents.html)

- Go to step 10.

- Continue with Adjudicating client or third party misrepresentation — Monetary penalty or warning letter to determine the appropriate sanctions and input all the decisions.

- Determine the reconsideration timeframe for the false or misleading statement not knowingly made:

- If the false statement was made within the prescribed period of 36 months , go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_unreported_earnings#Reconsideration)

- If the false statement was made within the extended period of 72 months , go to Reconsideration after 36 months .
               [Reconsideration after 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_unreported_earnings#Reconsideration37) 

#### Not within reconsideration timeframe

Source topic: `en_EN/task/aic_unreported_earnings/not_within_reconsideration_timeframe_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — EIA 52 — not within reconsideration timeframe.”

- Details: Document the decision and justification according to the National Fact-Finding and Documentation Policy
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, from the Report of Investigation , select Decision tab and complete the following fields:

- Overpayment: Select No

- Reason: Select Other and type “No allocation of wrongly declared or unreported earnings since not within reconsideration timeframe.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Returning the file to Integrity

Source topic: `en_EN/task/aic_unreported_earnings/returning_the_file_to_integrity_level_2.dita`

- In NIIS, from the Document tab, select IC70 Report of Investigation or IC50 Report of Clerical Investigation and complete the following fields:

- Select Recommendation .

- Refer the file to Integrity as follows:

- Select Yes (IC70) .

- Select the box (IC50) .

- Enter the missing or additional information required in the text area.

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1796.dita)

- In FTS, select the Outstanding Registrations link to cancel the registration number as follows:

- Select Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Select Update .

- If necessary, return the paper documents relating to the investigation to the investigator who signed the Report of Investigation.

- In NWS, complete the CR Integrity WI. 

#### No allocation

Source topic: `en_EN/task/aic_unreported_earnings/no_allocation_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — amount not allocated, not considered earnings.”

- Details: Document the decision and justification according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain why the amount was not allocated in relation to EIR 35 and EIR 36 .
               [EIR 35](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-35.html) 
               [EIR 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html)

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, from the Report of Investigation , select the Decision tab and complete the following fields:

- Overpayment: Select the appropriate option:

- OP for an overpayment.

- UP for an underpayment.

- Reason: Select Other and type "The earnings were not allocated because they are not considered earnings for benefit purposes."

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Voluntary disclosure approved

Source topic: `en_EN/task/aic_unreported_earnings/voluntary_disclosure_approved_level_2.dita`

- In NWS, create a ROD for the earnings issue as follows:

- Comments: Type “[Integrity case number] — earnings.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Indicate the earnings type. There could be more than one earnings type.

- Explain why the earnings were allocated in relation to EIR 35 , EIR 36 and Digest 5 — Earnings .
               [EIR 35](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-35.html) 
               [EIR 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html) 
               [Digest 5 — Earnings](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/table-of-contents.html)

- Explain that the full work week code needs to be removed for some weeks, if necessary.

- Create a ROD for the voluntary disclosure issue as follows:

- Comments: Type “[Integrity case number] — voluntary disclosure approved.”

- Details: Document the details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain that the client meets the 2 conditions for the National Policy on Voluntary Disclosure .
               [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 4.

- If the claim is terminated, but may be reactivated:

- On the Terminated tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 4.

- If the claim is blocked or archived, go to step 10.

- Determine if the full work week code needs to be changed in any of the reports under investigation.

- If yes, go to step 5.

- If no, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1821.dita)

- On the Payment tab, select the appropriate Report week and modify the claimant’s report as follows:

- Change only the information that requires modification .

- Select Modify .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1822.dita) 

- Earnings: For each week, enter the client’s earnings if necessary.

- Full work week: Select the appropriate option:

- 1 - Full work week - week 1

- 2 - Full work week - week 2

- 3 - Full work week both weeks

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Save .

- Select Update .

- Determine if earnings need to be modified on weeks where the full work week code does not need to be changed.

- If yes, go to step 7.

- If no, go to step 8.

- In FTS, select the Allocations (M175) transaction and input the earnings as follows (if necessary, refer to the ROD and the Earnings procedure or to Digest 5 — Earnings to help you determine how to allocate the earnings):

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1823.dita) 

- Registration number: Select the appropriate registration number.

- Type: Select A - Amended earnings .

- Amount: Enter the amount indicated on the Report of Interview.

- Start date: Enter the Sunday of the first week of the earnings to correct.

- End date: Enter the appropriate option:

- If many consecutive weeks have the same amount to allocate, select the Saturday of the last week of that series.

- If there are no consecutive weeks, select the Saturday of that week.

- Last week amount: Select the appropriate option:

- If there are many consecutive weeks and the amount of the last week is different from the start amount, enter that amount.

- If the amount from the last week is the same, leave the field blank.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if an MA is imposed to stop payments for the unreported earnings:

- If an MA is imposed, go to step 9.

- If an MA is not imposed, go to step 23.

- Select the Renewal/Revised (M106) to remove the MA as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 23.

- Determine if the FWW code must be changed in any of the reports under investigation:

- If no FWW code must be changed, go to step 11.

- If a FWW code must be changed for a week of regular benefits, go to step 11.

- If a FWW code must be changed for a week of special benefits, go to step 21.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1824.dita)

- Determine the blocked claim’s CS by reviewing the Blocked Status column under the Blocked tab:

- If 2 - Not blocked is displayed, return to step 3.

- If 1 - Updateable is displayed, go to step 12.

- If any other CS is displayed, go to step 21.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 13.

- If all rows are blank, go to step 15.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column under the Blocked tab:

- If Yes is displayed in one of the rows, return to step 13.

- If all rows are blank, go to step 15.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number

- D - No to leave the registration number open for subsequent transactions

- Select Update .

- Determine if the earnings to be input varies and requires an input on a weekly basis:

- If yes, go to step 17.

- If no, and the amount to input requires a weekly allocation amount, go to step 18.

- Under the Allocation "A" tab, in the Amended Earnings column, input the amended earnings as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1823.dita) 

- Select the week that requires a change. Repeat for every week that requires a change.

- Amended earnings: Type the new amount of earnings.

- FWW: Select the new FWW code (if a change is needed).

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Update .

- Go to step 19.

- Under the Allocations tab, input the allocation in the Allocations section as follows:

- Action: Select A - Add .

- Type: Select the appropriate allocation type.

- Amount: Enter the amount allocated per week.

- Start date: Enter the start date of the allocation.

- End date: Enter the end date of the allocation or 9999 if the end date is indefinite.

- Last week amount: Select the appropriate option:

- If the allocation amount in the last week is less than the normal weekly earnings, enter that amount.

- If the allocation amount in the last week is equal to the normal weekly earnings, leave the box empty.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Update .

- Under the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 20.

- If the transaction shown is correct, click Close and go to step 23.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 16.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (SMP): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim related to the correction of earnings.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1825.dita)

- Work item: Select 91 - Overpayment .

- Work type: Select 1 - Misrepresentation .

- Earnings to be allocated:
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1823.dita) 

- Week: Select the week(s) indicated on the Report of Investigation for which the salary must be corrected.

- Amount: Enter the amount indicated on the Report of Investigation for each concerned week.

- Remarks line 1: Enter the information regarding the modification of the FWW code, if necessary.

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Determine if the case involves more than 52 weeks of unreported earnings:

- If yes, go to step 24.

- If no, go to step 25.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1826.dita)

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Various reasons for penalty and violation (2935): Select Blank .

- Some or all earnings, Self-Employment Earnings or Fishing Earnings not declared / omitted (2953)

- Did not declare any or some earnings / earnings from self-employment

- According to our records / In addition, according to our records (2936)

- did not declare any earnings / declared only some earnings (2955): Select the appropriate option.

- Text - Type of earnings (1072)

- Text field: Employer name or Source of Earnings / Self Employment (2956)

- Blank / based on new information you provided / based on new information your employer provided (2958)

- List of one or more false declarations (3483)

- Dates of Weeks comparing Actual vs Declared Earnings (1494)

- $0.00 - Actual earnings amounts (1492)

- Ex: 500 for $500.00

- Ex: 492 for $492.00

- $0.00 - Earnings declared by claimant (1490)

- Claim possibly affected / claim not affected (2957)

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment .

- Overpayment – No misrepresentation and active claim .

- Overpayment – No misrepresentation and inactive claim .

- This Letter Replaces or Footnote (2365): Select Footnote .

- Text – Footnote (11745): Type “This letter includes only the information related to the benefit period starting on [BPC date]. The information related to the benefit period starting on [BPC date] is included on a separate letter.”

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Various reasons for penalty and violation (2935): Select Blank .

- Some or all earnings, Self-Employment Earnings or Fishing Earnings not declared / omitted (2953)

- Did not declare any or some earnings / earnings from self-employment

- According to our records / In addition, according to our records (2936)

- did not declare any earnings / declared only some earnings (2955): Select the appropriate option.

- Text - Type of earnings (1072)

- Text field: Employer name or Source of Earnings / Self Employment (2956)

- Blank / based on new information you provided / based on new information your employer provided (2958)

- List of one or more false declarations (3483)

- Dates of Weeks comparing Actual vs Declared Earnings (1494)

- $0.00 - Actual earnings amounts (1492)

- Ex: 500 for $500.00

- Ex: 492 for $492.00

- $0.00 - Earnings declared by claimant (1490)

- Claim possibly affected / claim not affected (2957)

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment .

- Overpayment – No misrepresentation and active claim .

- Overpayment – No misrepresentation and inactive claim .

- In ACS, create and send the D-70-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Voluntary disclosure / Administrative Rule - Undeclared Earnings (2664):

- Voluntary disclosure of information

- Subjects of voluntary disclosure (2665)

- your earnings or

- your fishing earnings or

- your self-employment

- Reminder: Provide information on report (2667)

- Option #2: Provide full and accurate information on each report and correct any incorrect reports as soon as possible

- Administrative Rule-Undeclared Earnings

- Text-Name of Employer(s) (1502)

- Period/periods (2668)

- Overpayment messages (2452)

- Right to request a reconsideration (4169)

- In NIIS, from the Report of Investigation , select the Decision tab and complete the following fields:

- Overpayment: Select the appropriate option:

- OP for an overpayment.

- UP for an underpayment.

- Reason: Select Allocation of Earnings .

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Reconsideration within 36 months

Source topic: `en_EN/task/aic_unreported_earnings/reconsideration_within_36_months_level_2.dita`

- In NWS, create a ROD for the earnings issue as follows:

- Comments: Type “[Integrity case number] — earnings.”

- Details: Document the decision and justification according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Indicate the earnings type. There could be more than one earnings type.

- Explain the allocation of the earnings in relation to EIR 35 , EIR 36 and Digest 5 — Earnings .
               [EIR 35](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-35.html) 
               [EIR 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html) 
               [Digest 5 — Earnings](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/table-of-contents.html)

- Explain that the FWW code needs to be removed for some weeks, if necessary.

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 3.

- If the claim is terminated, but may be reactivated:

- Under Dormant tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 3.

- If the claim is blocked or archived, go to step 9.

- Determine if the FWW code needs to be changed in any of the reports under investigation:

- If yes, go to step 4.

- If no, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1821.dita)

- In FTS, on the Payment Tab, select the appropriate Report week and modify the claimant’s report as follows: * Change only the information that requires modification .

- Select Modify .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1827.dita)

- Earnings: For each week, type the client’s earnings if necessary.

- Full work week: Select the appropriate option:

- 1 - Full work week - week 1

- 2 - Full work week - week 2

- 3 - Full work week both weeks

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 6 - Earnings other than declared .

- Select Save .

- Select Update .

- Determine if earnings need to be modified on weeks where the FWW code does not need to be changed.

- If yes, go to step 6.

- If no, go to step 7.

- In FTS, select the Allocations (M175) transaction and input the earnings as follows (if necessary, refer to the ROD and the Earnings procedure or to Digest 5 — Earnings to help you determine how to allocate the earnings):

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1823.dita) 

- Registration number: Select the appropriate registration number.

- Type: Select A - Amended earnings :

- Amount: Enter the amount indicated on the Report of Interview.

- Start date: Enter the Sunday of the first week of the earnings to correct.

- End date: Enter the appropriate option:

- If many consecutive weeks have the same amount to allocate, enter the Saturday of the last week of that series.

- If there are no consecutive weeks, enter the Saturday of that week.

- Last week amount: Select the appropriate option:

- If there are many consecutive weeks and the amount of the last week is different from the start amount, enter that amount.

- If the amount from the last week is the same, leave the field blank.

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 6 - Earnings other than declared .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number

- D - No to leave the registration number open

- Select Update .

- Determine if an MA is imposed to stop payments for the unreported earnings:

- If an MA is imposed, go to step 8.

- If an MA is not imposed, in FTS, select the Renewal/Revised (M106) transaction to complete the registration number as follows:

- Registration number: Select the appropriate registration number.

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update

- Go to step 22.

- In FTS, select the Renewal/Revised (M106) transaction to remove the MA as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- Go to step 22.

- Determine if the FWW code must be changed in any of the reports under investigation:

- If no FWW code must be changed, go to step 10.

- If a FWW code must be changed for a week of regular benefits, go to step 10.

- If a FWW code must be changed for a week of special benefits, go to step 20.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1828.dita)

- Determine the blocked claim’s CS by reviewing the Blocked Status column under the Blocked tab:

- If 2 - Not blocked is displayed, return to step 2.

- If 1 - Updateable is displayed , go to step 11.

- If any other CS is displayed, go to step 20.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 12.

- If all rows are blank, go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column under the Blocked tab:

- If Yes is displayed in one of the rows, return to step 12.

- If all rows are blank, go to step 14.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if the earnings to be input varies and requires an input on a weekly basis:

- If yes, go to step 16.

- If no, and the amount to input requires a weekly allocation amount, go to step 17.

- Under the Allocation "A" tab, in the Amended Earnings column, input the amended earnings as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1823.dita) 

- Select the week that requires a change. Repeat for every week that requires a change.

- Amended earnings: Type the new amount of earnings.

- FWW: Select the new FWW code (if a change is needed).

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 6 - Earnings other than declared .

- Select Update .

- Go to step 18.

- Under the Allocations tab, input the allocation in the Allocations section as follows:

- Action: Select A - Add .

- Type: Select the appropriate allocation type.

- Amount: Enter the amount allocated per week.

- Start date: Enter the start date of the allocation.

- End date: Enter the end date of the allocation or 9999 if the end date is indefinite.

- Last week amount: Select the appropriate option:

- If the allocation amount in the last week is less than the normal weekly earnings, enter that amount.

- If the allocation amount in the last week is equal to the normal weekly earnings, leave the box empty.

- Infraction: Select A - Non-fraud - Earnings and employment.

- Message: Select 6 - Earnings other than declared .

- Select Update .

- Under the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 19.

- If the transaction shown is correct, click Close and go to step 22.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 15 .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (SMP): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 6 - Earnings other than declared .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1823.dita) 

- BPC: Select the BPC of the claim related to the correction of earnings.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1825.dita)

- If the amended reports will create an OP, do the following:

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- If the amended reports will create an UP, do the following:

- Work item: Select 93 - Manual Pay System .

- Work type: Select 33 - Blocked claim requiring payment .

- Earnings to be allocated:

- Week: Select the weeks indicated on the Report of Investigation for which the salary must be corrected.

- Amount: Enter the amount indicated on the Report of Investigation for each concerned week.

- Remarks line 1: Enter the information regarding the modification of the FWW code, if necessary.

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Determine if the case involves more than 52 weeks of unreported earnings:

- If yes, go to step 23.

- If no, go to step 24.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1826.dita)

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Various reasons for penalty and violation (2935): Select Blank .

- Some or all earnings, Self-Employment Earnings or Fishing Earnings not declared / omitted (2953)

- Did not declare any or some earnings / earnings from self-employment

- According to our records / In addition, according to our records (2936)

- did not declare any earnings / declared only some earnings (2955): Select the appropriate option.

- Text - Type of earnings (1072)

- Text field: Employer name or Source of Earnings / Self Employment (2956)

- Blank / based on new information you provided / based on new information your employer provided (2958)

- List of one or more false declarations (3483)

- Dates of Weeks comparing Actual vs Declared Earnings (1494)

- $0.00 - Actual earnings amounts (1492)

- Ex: 500 for $500.00

- Ex: 492 for $492.00

- $0.00 - Earnings declared by claimant (1490)

- Claim possibly affected / claim not affected (2957)

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment .

- Overpayment – No misrepresentation and active claim .

- Overpayment – No misrepresentation and inactive claim .

- This Letter Replaces or Footnote (2365): Select Footnote .

- Text – Footnote (11745): Type “This letter includes only the information related to the benefit period starting on [BPC date]. The information related to the benefit period starting on [BPC date] is included on a separate letter.”

- In ACS, create and send the D-91-00-00. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Various reasons for penalty and violation (2935): Select Blank .

- Some or all earnings, Self-Employment Earnings or Fishing Earnings not declared / omitted (2953)

- Did not declare any or some earnings / earnings from self-employment

- According to our records / In addition, according to our records (2936)

- did not declare any earnings / declared only some earnings (2955): Select the appropriate option.

- Text - Type of earnings (1072)

- Text field: Employer name or Source of Earnings / Self Employment (2956)

- Blank / based on new information you provided / based on new information your employer provided (2958)

- List of one or more false declarations (3483)

- Dates of Weeks comparing Actual vs Declared Earnings (1494)

- $0.00 - Actual earnings amounts (1492)

- Ex: 500 for $500.00

- Ex: 492 for $492.00

- $0.00 - Earnings declared by claimant (1490)

- Claim possibly affected / claim not affected (2957)

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim .

- Overpayment – No misrepresentation and inactive claim .

- In NIIS, from the Report of Investigation , select the Decision tab and complete the following fields:

- Overpayment: Select the appropriate option:

- OP for an overpayment

- UP for an underpayment

- Reason: Select Allocation of Earnings .

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Reconsideration after 36 months

Source topic: `en_EN/task/aic_unreported_earnings/reconsideration_after_36_months_level_2.dita`

- In NWS, create a ROD for the earnings issue as follows:

- Comments: Type “[Integrity case number] — earnings.”

- Details: Document the decision and justification according to the National Fact-Finding and Documentation Policy
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Indicate the earnings type. There could be more than one earnings type.

- Explain the allocation of the earnings in relation to EIR 35 , EIR 36 and Digest 5 — Earnings .
               [EIR 35](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-35.html) 
               [EIR 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html) 
               [Digest 5 — Earnings](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/table-of-contents.html)

- Explain that the FWW code needs to be removed for some weeks.

- In FTS, determine if the FWW code must be changed in any of the reports under investigation:

- If no FWW code must be changed, go to step 3.

- If a FWW code must be changed for a week of regular benefits, go to step 3.

- If a FWW code must be changed for a week of special benefits, go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1828.dita)

- Determine the blocked claim’s CS by reviewing the Blocked Status column under the Blocked tab:

- If 1 - Updateable is displayed , go to step 4.

- If any other CS is displayed, go to step 13.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 5.

- If all rows are blank, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column under the Blocked tab:

- If Yes is displayed in one of the rows, return to step 5.

- If all rows are blank, go to step 7.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if the earnings to be input varies and requires an input on a weekly basis:

- If yes, go to step 9.

- If no, and the amount to input requires a weekly allocation amount, go to step 10.

- Under the Allocation "A" tab, in the Amended Earnings column, input the amended earnings as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1823.dita) 

- Select the week that requires a change. Repeat for every week that requires a change.

- Amended Earnings: Type the new amount of earnings.

- FWW: Select the new FWW code (if a change is needed).

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 6 - Earnings other than declared .

- Select Update

- Go to step 11.

- Under the Allocations tab, input the allocation in the Allocations section as follows:

- Action: Select A - Add .

- Type: Select the appropriate allocation type.

- Amount: Enter the amount allocated per week.

- Start date: Enter the start date of the allocation.

- End date: Enter the end date of the allocation or 9999 if the end date is indefinite.

- Last week amount: Select the appropriate option:

- If the allocation amount in the last week is less than the normal weekly earnings, enter that amount.

- If the allocation amount in the last week is equal to the normal weekly earnings, leave the box empty.

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 6 - Earnings other than declared .

- Select Update .

- Under the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 12.

- If the transaction shown is correct, click Close and go to step 15.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 8.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (SMP): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 6 - Earnings other than declared .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1823.dita) 

- BPC: Select the BPC of the claim related to the correction of earnings.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1825.dita)

- If the amended reports will create an OP, do the following:

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- If the amended reports will create an UP, do the following:

- Work item: Select 93 - Manual Pay System .

- Work type: Select 33 - Blocked claim requiring payment .

- Earnings to be allocated:

- Week: Select the week s indicated on the Report of Investigation for which the salary must be corrected.

- Amount: Enter the amount indicated on the Report of Investigation for each concerned week.

- Remarks line 1: Enter the information regarding the modification of the FWW code, if necessary.

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Determine if the case involves more than 52 weeks of unreported earnings:

- If yes, go to step 16.

- If no, go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1826.dita)

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Decision reconsidered beyond 36 months (2595): Select Decision reconsidered beyond 36 months due to false representations

- Various reasons for penalty and violation (2935): Select Blank .

- Some or all earnings, Self-Employment Earnings or Fishing Earnings not declared / omitted (2953)

- Did not declare any or some earnings / earnings from self-employment

- According to our records / In addition, according to our records (2936)

- did not declare any earnings / declared only some earnings (2955): Select the appropriate option.

- Text - Type of earnings (1072)

- Text field: Employer name or Source of Earnings / Self Employment (2956)

- Blank / based on new information you provided / based on new information your employer provided (2958)

- List of one or more false declarations (3483)

- Dates of Weeks comparing Actual vs Declared Earnings (1494)

- $0.00 - Actual earnings amounts (1492)

- Ex: 500 for $500.00

- Ex: 492 for $492.00

- $0.00 - Earnings declared by claimant (1490)

- Claim possibly affected / claim not affected (2957)

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment .

- Overpayment – No misrepresentation and active claim .

- Overpayment – No misrepresentation and inactive claim .

- This Letter Replaces or Footnote (2365): Select Footnote .

- Text – Footnote (11745): Type “This letter includes only the information related to the benefit period starting on [BPC date]. The information related to the benefit period starting on [BPC date] is included on a separate letter.”

- In ACS, create and send the D-91-00-00. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Decision reconsidered beyond 36 months (2595): Select Decision reconsidered beyond 36 months due to false representations

- Various reasons for penalty and violation (2935): Select Blank .

- Some or all earnings, Self-Employment Earnings or Fishing Earnings not declared / omitted (2953)

- Did not declare any or some earnings / earnings from self-employment

- According to our records / In addition, according to our records (2936)

- did not declare any earnings / declared only some earnings (2955): Select the appropriate option .

- Text - Type of earnings (1072)

- Text field: Employer name or Source of Earnings / Self Employment (2956)

- Blank / based on new information you provided / based on new information your employer provided (2958)

- List of one or more false declarations (3483)

- Dates of Weeks comparing Actual vs Declared Earnings (1494)

- $0.00 - Actual earnings amounts (1492)

- Ex: 500 for $500.00

- Ex: 492 for $492.00

- $0.00 - Earnings declared by claimant (1490)

- Claim possibly affected / claim not affected (2957)

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim .

- Overpayment – No misrepresentation and inactive claim .

- In NIIS, from the Report of Investigation , select the Decision tab and complete the following fields:

- Overpayment: Select the appropriate option:

- OP for an overpayment

- UP for an underpayment

- Reason: Select Allocation of Earnings .

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1667.dita`

Note:

Cases with an OP below the Integrity investigative threshold are referred for adjudication only when specific exceptions are met (voluntary disclosure or impact on an active claim). In these cases, the employer’s or any other party’s version does not have to be verified and the file must not be returned to Integrity. 

#### Note

Source topic: `en_EN/common_notes/note_c_1796.dita`

Note:

The regional consideration for officers in the Quebec region is as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a Cc.

- In NWS, create a client Note and type “Measure — returned to Integrity” and include the date (YYYY-MM-DD). 

#### Note

Source topic: `en_EN/common_notes/note_c_1821.dita`

Note:

In situations where inputs create both a UP and an OP, the inputs resulting in the OP are done first. Once the OP is established, the officer inputs an agreed deduction equal to the benefit rate amount. For more information, the officer refers to Applying an agreed deduction in PSCD . Once the agreed deduction is established in FTS, the underpayment input can be completed.
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml)

     [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_1822.dita`

Note:

When the Detailed Claimant’s Report screen opens, the information displayed the information declared by the client on the original claimant’s report. The Manual Action field is automatically prefilled with 19 - Amended report . 

#### Note

Source topic: `en_EN/common_notes/note_c_1823.dita`

Note:

If the client declared earnings from another employment for a week that is being amended, combine the earnings for both employments for that week. Allocate the total earnings. 

#### Note

Source topic: `en_EN/common_notes/note_c_1824.dita`

Note:

If a FWW code must be changed for a week of special benefits, send an Operational Centre Memo (MM06) transaction to IPOC requesting the input of the transaction. Do not use BCS . 

#### Note

Source topic: `en_EN/common_notes/note_c_1791.dita`

Note:

An update in BCS can only be done on one BPC at a time. 

#### Note

Source topic: `en_EN/common_notes/note_c_1825.dita`

Note:

A separate Operational Centre Memo (MM06) transaction is required for each BPC. 

#### Note

Source topic: `en_EN/common_notes/note_c_1826.dita`

Note:

A maximum of 52 weeks of unreported earnings can be declared on a D-91-00-00 notice. If the case involves more than 52 weeks, send a D-91-00-00 letter for each BP. 

#### Note

Source topic: `en_EN/common_notes/note_c_1827.dita`

Note:

When the Detailed Claimant’s Report screen opens, the information displayed is the information declared by the client on the original claimant’s report. The Manual Action field is automatically prefilled with 19 - Amended report . 

#### Note

Source topic: `en_EN/common_notes/note_c_1828.dita`

Note:

If a FWW code must be changed for a week of special benefits, send an Operational Centre Memo (MM06) transaction to IPOC requesting the input of the transaction. Do not use BCS. 

## Policy reference

Source topic: `en_EN/task/aic_unreported_earnings/policy_reference.dita`

- Digest 5 — Earnings
         [Digest 5 — Earnings](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/table-of-contents.html)

- Digest 17 — Reconsideration, amendment and return of benefit
         [Digest 17 — Reconsideration, amendment and return of benefit](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/table-of-contents.html)

- Digest 18 — Policy on Penalties
         [Digest 18 — Policy on Penalties](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/table-of-contents.html)

- EIA 52
         [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- EIR 35
         [EIR 35](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-35.html)

- EIR 36
         [EIR 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html)

- EIA 38
         [EIA 38](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/page-11.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 
