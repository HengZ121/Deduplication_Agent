# Fact-finding

Source map: `en_EN/task/fact_find/fact_find.ditamap`

## Summary

Source topic: `en_EN/task/fact_find/summary.dita`

Summary: When additional information is required to adjudicate or make changes to a client’s file, the officer contacts the client, employer, or in some cases, a third party to obtain the information. 

## What you need to know

Source topic: `en_EN/task/fact_find/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/fact_find/untitled_section.dita`

- Is the contact information of the person you need to contact on file? Consult the following sources:

- application for benefits

- ROE

- SROCs

- previous claims 

### Temporary process is no longer in effect

Source topic: `en_EN/task/fact_find/temporary_process_is_no_longer_in_effect.dita`

Simplification measures for fact-finding with the employer ended September 25, 2021. Effective September 26, 2021, the officer follows normal procedures. 

### Contacting a person by telephone

Source topic: `en_EN/task/fact_find/contacting_a_person_by_telephone.dita`

The Commission considers the telephone to be the preferred method of fact-finding and communication because it is the most efficient method. When fact-finding is required, the officer determines if the telephone number of the person is on file or can be obtained. If the telephone number is not on file, the officer consults Canada 411 . For employers, the officer can also consult the employer’s web site, if they have one, as it may indicate a telephone number. Officers are not allowed to use social media (Facebook, X [previously Twitter] etc.) to contact a client, employer or third party, or to obtain contact information from another business line system (e.g. Information Technology Renewal Delivery System).
       [Canada 411](http://www.canada411.ca/)

If hearing impaired clients select the teletypewriter as their preferred method of communication, the officer calls them directly using a teletypewriter (if available in the local office) or through the Telephone Relay Service at 1-800-855-0511 using a regular telephone and providing the operator with the client’s teletypewriter number. The operator facilitates communications between the officer and the client by typing what the officer says so that it appears as written text on the client’s teletypewriter screen and by voicing what the client types.

Before calling the person, the officer reviews the file and notes the questions to ask. Some procedures will have provided the information to determine these questions and the information to communicate.

If the person is not reached during a telephone call and it is possible to do so, the officer leaves a message requesting that the person call back. If a second call attempt must be made, the officer calls at a different time of day and at least 24 hours after the first attempt. The officer also considers the time zone of the person to call. If calling an employer, the officer considers the type of business, its operating hours and peak times to ensure the call is made at an appropriate time.

     [Examples](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3416.dita) 

Before providing any details of the reason for the call, the officer makes sure to speak to the intended person. This ensures that the officer is speaking with the correct person and protects the client’s personal information. To ensure that the officer is speaking to the correct person when contacting a client by telephone, the officer validates the client’s identity . Under certain situations, the officer speaks through an interpreter or with a representative authorized to provide information on the client’s behalf. The officer also makes sure to speak to someone who can provide the required information. For example, payroll information should be obtained from someone who deals with payroll. Likewise, information about a reason for separation (RFS) should be obtained from the person or department familiar with the details of the RFS. This person is not necessarily the contact person indicated on the ROE.
       [validates the client’s identity](/en/procedure/generic/additionalresources/validating_cict.shtml) 
       [representative](/en/procedure/activity/app_rep.shtml)

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3417.dita) 

The officer allows the interested party a minimum of 24 hours from the last call attempt to respond. For a telephone call to be considered a successful attempt, the officer must speak with the interested party or leave a message for the individual.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3418.dita) 

**Validating the client’s identity**

The officer must always validate the client’s identity when communicating by telephone. It does not matter if the client or the officer initiates the call, the officer must always validate the client’s identity. If a client has their access code, their identity is validated by completing a primary security check. If the Access code field in FTS is blank or if the client does not pass the primary security check, the officer conducts a detailed security check to validate the client’s identity.
       [validate the client’s identity](/en/procedure/generic/additionalresources/validating_cict.shtml)

If a client still does not pass the required security check, communication by telephone is not possible.

**Validating the client’s address**

When a client is successfully identified, the officer then validates the address on file to ensure that Service Canada has the most recent information. If the address is incorrect, the officer changes it.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3419.dita) 

**Confidentiality**

While information on an EI claim is subject to the Privacy Act , it is not classified as confidential. If there is an appeal, the claim information can be available to the Employment Insurance Board of Appeal (EI BOA), Social Security Tribunal (SST), the Federal and Supreme Courts, other interested parties and the public. If a client requests that information provided remains confidential, the officer explains to whom and under what circumstances the information may be available. Additionally, the officer must advise the client that confidential information cannot be included on file and cannot be considered when making a decision. For more information, the officer refers to the Confidentiality section of the National Fact-Finding and Documentation Policy .
       [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#s4_7)

In cases of informant leads, certain information is protected and must not be documented in NWS. For more information, the officer refers to Receiving and referring an informant lead .
       [Receiving and referring an informant lead](/en/procedure/task/referral_integrity_informant_lead.shtml)

**Privacy**

The officer does not disclose personal or protected information when leaving a message on a client’s voicemail or with another person. In addition, the officer does not provide personal or protected information to third parties without a client’s written authorization, specifically indicating what claim information can be disclosed to the third party (e.g. BPC, benefit rate, weeks of entitlement, or statement of benefits paid). No other information can be disclosed to a third party. For more information, the officer refers to Actioning a written third party request to obtain file information .
       [Actioning a written third party request to obtain file information](/en/procedure/task/actioning_wtpr_fi.shtml)

Third parties can provide information on behalf of the client if they are identified as a designated representative . However, in the case of a deceased client , the officer may have to contact third parties seeking payment on behalf of that client and inform them of the documents required to become the representative. In these circumstances, the officer must be careful not to provide any specific information regarding the client’s file.
       [designated representative](/en/procedure/activity/app_rep.shtml) 
       [deceased client](/en/procedure/activity/deseased_client.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3420.dita) 

**Fact-Finding with a minor (person under the age of majority)**

There is no specific age in Canada at which point a minor is considered mature enough to make decisions that affect them. Each Canadian province and territory is responsible for determining the age of majority in their jurisdiction. However, for simplicity, a minor will be considered a person under the age of 18.

In this section the term “parent” can also mean legal guardian or trusted adult.

When Service Canada initiates contact with minors to obtain information regarding their EI claim, before obtaining any information, the officer must suggest that the minor invite a parent to be present during the conversation. If fact-finding with the minor about a contentious issue, the officer strongly recommends that a parent be present during the discussion.

The minor is not required to have a parent present during discussions with Service Canada. However, the officer suggests that the minor invite a parent to be present to ensure the minor feels safe during these conversations and has a proper understanding of the questions being asked during the interaction. In all cases, the officer documents the suggestion to have a parent present and the minor’s response in an SROC.

**Interpreters**

A third party may act as an interpreter for a client (e.g. in the case of a language barrier), but the client must be with the third party and all questions must be translated by the third party to the client. Similarly, the client’s response must be translated to the officer. In these situations, the third party cannot provide responses on the client’s behalf. They may only act as an interpreter.

If the assistance of an interpreter is required, the officer ensures all of the following conditions are respected:

- The client is present during the call.

- The client provides his or her SIN and full name.

- The client’s identity is validated .
         [The client’s identity is validated](/en/procedure/generic/additionalresources/validating_cict.shtml)

- The client gives permission to speak to the interpreter. 

### Contacting a person electronically

Source topic: `en_EN/task/fact_find/contacting_a_person_electronically.dita`

In accordance with the National Fact-finding and Documentation Policy , the use of email, text message or regular fax to conduct fact-finding or request information is prohibited. This is because our present technology does not support the secure transmission of clients’ personal information (Protected B).
       [National Fact-finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

On occasion, a person may insist on submitting information or documentation by email or fax. At this time, the only secure methods for an employer to submit documentation to Service Canada are by mail or in person at a Service Canada Centre (SCC). Electronic transmission is not promoted, and the officer should discourage employers from using any other methods of transmitting documents.

**Email**

When the officer is unsuccessful at contacting a client by telephone and the client has provided an email address, the officer can contact the client by email for the sole purpose of asking the client to call the officer directly. When this occurs and the client calls the officer as indicated in the email, the officer conducts fact-finding by telephone.

When sending an email to establish contact with a client, the officer completes the E-02-00-00 email template in ACS and does not include any personal, confidential, privileged or claim information.

The officer allows the client 24 hours to respond to the email. When the client did not provide a telephone number or when the officer is unable to leave a telephone message for the client to call back, the officer allows the client 48 hours to respond to the email.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3421.dita) 

The officer cannot send an email to an employer or third party to establish contact.

During fact-finding, a person may request that an officer register to receive secure email messages related to a request for information and documentation. Officers are not permitted to use these secure email services and the Network Use Directive prohibits officers from using a government email address to register for such services.
       [Network Use Directive](https://iservice.prv/eng/is/security/tools_and_resources/toolkit/network_use_directive.shtml)

**Request for officer authentication by fax or email**

There may be occasions when an employer requests a fax or email from an officer to either identify the officer as a Service Canada employee or as a means of conducting fact-finding.

To confirm they are Service Canada employees, officers send the E-02-00-00 email in ACS or fax the Communication: Officer authentication by fax for fact-finding — Template (SC ADM5008) with only the client’s name (Protected A) as an identifier in the Subject field. Officers use these templates to request that the employer contact them to conduct fact-finding by telephone. If employers decide to respond by fax or email, officers advise them not to add any other client information. Identifying information is not required to initiate fact-finding with employers and is only used to authenticate the officers as Service Canada employees. If employers ask specific fact-finding questions or asks for the transmission of specific client information by fax, officers conduct fact-finding by mail.
       [Communication: Officer authentication by fax for fact-finding — Template](/resources/ort/documents/FaxCoversheetTemplate-SC-ADM5008-E-2019Jan21.pdf)

**Receiving electronic information or documentation**

Officers can give clients the option of uploading forms in MSCA.

Once uploaded, the officer can view the documents in NWS by selecting View Documents . A list of the uploaded documents appear and the officer can select a document to review. When the client uploads a new document, a banner is added to outstanding Claim Assessment (CA), Specialized Application (SA), Claim Review (CR), or Action Item (AI) WIs. If a CR or AI WI is in Pending for the same issue type as the document uploaded by the client, the WI moves from Pending to the current workload.

When clients upload ROEs in MSCA, an AI ROE Input WI is created in NWS.

Other than the documents approved for upload in MSCA, the officer does not promote the electronic transmission of information or documents when conducting fact-finding over the telephone. If a person insists on faxing or emailing information or documents (e.g. ROE, employment contract or letters of termination), the officer can accommodate him or her, but warns the person of potential security risks:

- If the person insists, the information will be accepted electronically.

- There are security risks involved, as department technology does not permit secure transmission of personal information outside the firewall;

- ESDC employees can communicate with them only in person, by telephone or by mail.

At this time, there is no policy or legislation in place to support requiring Service Canada employees to provide their employee-specific email address to clients or employers. If the officer does not choose to volunteer this information, the officer advises these clients or employers to provide information or documentation by fax, as indicated above, by mail, or in person at a Service Canada Center (SCC).

If a person submits the information or documentation electronically after being advised of these risks, the officer documents the conversation on the file. Once the electronic documentation is received, the officer does not reply. If the person requests a response, the officer calls the person to confirm receipt. 

### Documenting the file

Source topic: `en_EN/task/fact_find/documenting_the_file.dita`

The officer creates a draft SROC to document the following information:

- the correct contact information of the person you need to contact

- the type of contact attempted (telephone, email, letter)

- the date and time (in the client’s time zone, if necessary) of every communication attempt made

- if a message is left and, if not, why (no voicemail, line always in use, etc.)

- a brief description of the information sought (amount of separation monies, last paid day, to discuss RFS, etc.)

- contact information, including telephone number of the officer to be contacted (in case the client reaches another officer)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3422.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3423.dita) 

The officer includes a brief description of the questions and information required in the draft SROC created during fact-finding. This allows other officers to continue with fact-finding, if necessary.

On the SROC created for fact-finding, the officer documents whether or not the client passed the required security check.

If the officer speaks several times to the same person, the officer creates an SROC for each conversation with the client, the employer or third party (e.g. if the client is contacted twice, there must be 2 SROCs on file).

Also, if the officer contacts the person with whom fact-finding must be made for 2 different contentious issues, the officer documents the details about the fact-finding for each contentious issue in separate SROCs (e.g. if during a conversion with the client the officer obtains information about training and voluntary leaving, 2 separate SROCs must be created).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3424.dita) 

Generally, once the person is contacted and the information is obtained, the officer returns to the previous task to document the information on file and save the SROC. In some scenarios, the fact-finding steps advise the officer to document the information on file and save the SROC before returning to the previous task. The method used to document the information can vary depending on the task and the information obtained (e.g. facts obtained during an ROE verification are documented in RCM, facts about a contentious issue are documented in an SROC).

Once saved, the SROC is part of the documentation of the client’s file.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3425.dita) 

During fact-finding, if information or documentation is received by fax or email, the officer documents it to the file. The officer sends a printed copy of the fax or email to Imaging according to local office procedures. The officer also documents in an SROC when and how the information was received. The SROC containing this information must be separate from the SROC documenting that the person was warned of the risks. The officer is not required to retain an electronic copy of the email.

In some situations, it is clear during Level 2 fact-finding with the client that the contentious issue can not be allowed. When this occurs and the client is advised of the negative decision during the same fact-finding telephone call, the Level 2 officer can document the verbal communication of a negative decision clearly at the end of the SROC created for the fact-finding call related to that issue.

However, when separate telephone calls are made to conduct fact-finding with the client and then to notify the client of the decision, the officer creates separate SROCs. For more information, the officer refers to Verbally communicating a negative decision .
       [Verbally communicating a negative decision](/en/procedure/task/verbal_communication.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3415.dita`

Note:

When fact-finding about a Government of Canada ROE that is missing or requires correction, the officer refers to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Examples

Source topic: `en_EN/common_notes/note_c_3416.dita`

Examples:

If the officer makes a first attempt to contact a client by telephone at 11:00 a.m. and leaves a message on voicemail, the officer makes a second attempt later on the following business day (e.g. 1:30 p.m.).

If the officer makes a first attempt to contact a client by telephone at 1:30 p.m. and leaves a message on voicemail, the officer makes a second attempt later on the following business day (e.g. 3 p.m.). 

### Callout

Source topic: `en_EN/common_notes/note_c_3417.dita`

**Sample telephone scripts**

**Asking for the client**

Hi, this is [officer’s first name] calling from Service Canada. May I speak with [client’s first and last name]?

**Leaving a message with a third party**

Can you please ask [client’s first name] to return my call within the next 24 hours? My name is [officer’s first name] and my phone number is [officer’s phone number]. My hours of work are [hours of work in the client’s time zone]. Thank you.

**Leaving a message on voicemail**

Hi, this is [officer’s first name] calling from Service Canada. Today is [date] and the time is [time]. This message is for [client’s first and last name]. Please call me back at [officer’s phone number] within 24 hours. My hours of work are [hours of work in the client’s time zone]. Thank you. 

### Note

Source topic: `en_EN/common_notes/note_c_3418.dita`

Note:

When leaving a message on voicemail, the officer does not ask clients to disclose their SIN on the officer’s voicemail as identification to avoid compromising their personal information. 

### Info

Source topic: `en_EN/common_notes/note_c_3419.dita`

Note :

On the SROC created during fact-finding, the officer documents whether or not the client passed the required security check and address validation. 

### Note

Source topic: `en_EN/common_notes/note_c_3420.dita`

Note:

If a third party notifies the officer that a client is deceased, and that person is not intending to be the client’s representative, the officer conducts fact-finding with the third party to get contact information about a potential representative. 

### Note

Source topic: `en_EN/common_notes/note_c_3421.dita`

Note:

The officer documents that the email was sent on the SROC created during fact-finding. The officer can confirm in ACS whether an email has been sent to a client using the Search option under Actions in the Email menu. The officer refers to Email examples to view the email content.
       [Email examples](http://esdc.prv/en/service-canada/ei/technologies/ei-correspondence/email-examples.shtml)

At this time, ACS does not confirm whether the email has been sent successfully or is undeliverable. Instead, ACS generates a daily report listing all undeliverable emails sent the previous day. A Non-complex officer reviews the report and adds an SROC to the file documenting that the email was undeliverable. In these cases, the officer continues the fact-finding process as if a valid email has not been sent.

     [Email examples](http://esdc.prv/en/service-canada/ei/technologies/ei-correspondence/email-examples.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3422.dita`

Note:

It is important to save the SROC in a timely manner to prevent accidentally leaving the SROC in draft format.

SROCs and records of decision (RODs) are legal documents that can be saved only by the officer who documented the statement. An SROC or ROD saved in draft format remains on file for 60 days from the date it was created or from the last modification date. After 60 days, NWS automatically deletes the draft SROC or ROD. If an officer is assigned to a file with a draft SROC or ROD, the officer contacts the Team Leader of the officer who created the draft. This officer must review the information on the SROC or ROD and save it. 

### Note

Source topic: `en_EN/common_notes/note_c_3423.dita`

Note:

The officer does not use acronyms when completing the Comments field. 

### Note

Source topic: `en_EN/common_notes/note_c_3424.dita`

Note:

When a request for reconsideration or an appeal to the SST is submitted, only information regarding the issue under reconsideration or appeal must be included. Failure to separate the issues and conversations on SROCs result in additional work to redact the information that is not required and an increased risk of a privacy breach if information that is not relevant to the request for reconsideration or appeal is shared with an interested party (e.g. employer). 

### Note

Source topic: `en_EN/common_notes/note_c_3425.dita`

Note:

If the officer who created the SROC is unavailable to save the draft, the officer now assigned to the file contacts the person with whom fact-finding was originally conducted (client, employer or third party) to confirm the information on the draft SROC. Once the information is confirmed, the officer documents the information and any additional details on a new SROC and saves it. The original draft SROC remains on file until NWS automatically deletes it. 

## Regional considerations

Source topic: `en_EN/task/fact_find/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/fact_find/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/fact_find/untitled_section.dita`

- Is the contact information of the person you need to contact on file? Consult the following sources:

- application for benefits

- ROE

- SROCs

- previous claims 

## Step by step

Source topic: `en_EN/task/fact_find/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/fact_find/non-complex.dita`

#### Reviewing the file

Source topic: `en_EN/task/fact_find/reviewing_the_file_non-complex.dita`

- Determine if the telephone number of the person is on file or can be obtained:

- If the person’s telephone number is not on file and cannot be obtained, go to step 2.

- If the person’s telephone number is on file or can be obtained, go to First communication attempt by telephone .
               [First communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_2)

- In NWS, create a draft SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for the call.

- Type “Telephone number not available.”

- Details: Document the steps taken to try to obtain the telephone number.

- Select Draft .

- Determine if the person you are trying to reach is a client:

- If yes, go to step 4.

- If no, go to step 5.

- Determine if the client has provided an email address:

- If yes, go to Communication attempt by email .
               [Communication attempt by email](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_3)

- If no, go to step 6.

- Determine if your task is ROE verification:

- If yes, go to Person is not reached — ROE verification .
               [Person is not reached — ROE verification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_6)

- If no, go to step 6.

- In NWS, add details to the draft SROC as follows:

- Details: Type “Cannot reach the [client or employer] by telephone.”

- Select Save .

- Return to the previous task for next steps. 

#### First communication attempt by telephone

Source topic: `en_EN/task/fact_find/first_communication_attempt_by_telephone_non-complex.dita`

- Call the person:

- If you do not reach the person, leave a message on a voicemail or with a third party. The message should include the following information:

- name of the person you wish to speak with.

- your name and organization (Service Canada — Employment Insurance).

- instruction to call back within the next 24 hours.

- your telephone number and the hours you can be reached (in the client’s time zone, if necessary).

- Go to step 2.

- If you do not reach the person and you cannot leave a message, go to step 2.

- If you reach the person, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_5)

- In NWS, create a draft SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for the call.

- Enter the details about the issue and, if necessary, identify the person you are calling.

- Details: Enter the appropriate details:

- If a message has been left, enter the following details:

- telephone number called;

- date and time (in the client’s time zone, if necessary) of the message;

- whether the message has been left on a voicemail or with a third party;

- name of the third party, if necessary;

- position of the person, if contacting an employer;

- brief description of the questions and information required from the client or the employer (end date of the final pay period, gross amount of vacation pay, etc.);

- contact information, including telephone number of the officer to be contacted.

- If no message has been left, type “[date and time (in the client’s time zone, if necessary) of the call] — unable to leave a message.” Include a brief description of the questions and information required from the client, or employer, as well as the contact information, including telephone number of the officer to be contacted.

- Select Draft .

- Go to step 3.

- Determine if the person you are trying to reach is a client who has provided an email address:

- If yes, go to Communication attempt by email .
               [Communication attempt by email](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_3)

- If no, go to step 4.

- In NWS, determine if there is a WI for the previous task:

- If there is no WI, hold the task for 24 hours.

- If there is a WI, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].”

- Bring forward date: Enter tomorrow’s date.

- Determine if the person has called back within 24 hours of the first communication attempt by telephone:

- If yes, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_5)

- If no, go to Second communication attempt by telephone .
               [Second communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_4) 

#### Communication attempt by email

Source topic: `en_EN/task/fact_find/communication_attempt_by_email_non-complex.dita`

- In ACS, create and send an E-02-00-00 email to the client as follows:

- On the Email tab, select Actions then New .

- When the template opens, complete the following fields:

- Language: Select the appropriate option.

- Template: Select E-02-00-00 .

- SIN: Enter the client’s SIN.

- Email address: Copy and paste the client’s email address from the Personal Information section of AW.

- Your first name: Enter your first name.

- Telephone number where you can be reached: Enter your telephone number.

- Enter 1 or 2 (for working days): Select 1 working day if the client’s telephone number is on file. Select 2 working days if the client’s telephone number is not on file.

- Your hours of work (using the client’s time zone): Enter your work hours.

- Select Open to preview the email.

- Select Send to send the email.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3426.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3427.dita)

- In NWS, add details to the draft SROC as follows:

- Details: Enter the following details:

- client’s email address

- date and time (in the client’s time zone, if necessary) of the email

- E-02-00-00 email sent requesting contact from the client

- Select Draft .

- In NWS, determine if there is a WI for the previous task:

- If no, hold the task for 24 hours.

- If yes, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].”

- Bring forward date: Enter tomorrow’s date.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3428.dita)

- When the WI moves to the current workload, determine if the client has called back within 24 hours of the email communication attempt (or 48 hours if there is no telephone number on file):

- If no and there is no telephone number on file, go to step 5.

- If no and there is a telephone number on file, go to Second communication attempt by telephone .
               [Second communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_4)

- If yes, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_5)

- Determine if your task is ROE verification:

- If no, go to step 6.

- If yes, go to Person is not reached — ROE verification .
               [Person is not reached — ROE verification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_6)

- In NWS, add details to the draft SROC as follows:

- Details: Type “Cannot reach the client by telephone.”

- Select Save .

- Return to the previous task for next steps. 

#### Second communication attempt by telephone

Source topic: `en_EN/task/fact_find/second_communication_attempt_by_telephone_non-complex.dita`

- Call the person again at a different time of day and at least 24 hours after the first communication attempt:

- If you do not reach the person, leave a message on a voicemail or with a third party. The message must include the following information:

- name of the person you wish to speak with.

- your name and organization (Service Canada — Employment Insurance).

- that this is a second call.

- instruction to call back within the next 24 hours.

- your telephone number and the hours you can be reached (in the client’s time zone, if necessary).

- Go to step 2.

- If you do not reach the person and you cannot leave a message, go to step 2.

- If you reach the person, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_5)

- In NWS, add details to the draft SROC as follows:

- Details: Enter the appropriate details:

- If a message has been left, enter the following details:

- telephone number called;

- date and time (in the client’s time zone, if necessary) of the message;

- whether the message has been left on a voicemail or with a third party;

- name of the third party, if necessary;

- position of the person, if contacting an employer.

- Select Draft .

- Go to step 3.

- If no message has been left, type “[date and time (in the client’s time zone, if necessary) of the call] — unable to leave a message.”

- Select Draft .

- Go to step 5.

- In NWS, determine if there is a WI for the previous task:

- If there is no WI, hold the task for another 24 hours.

- If there is a WI for the task, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].”

- Bring forward date: Enter tomorrow’s date.

- Select Save .

- Determine if the person has called back within 24 hours of the second communication attempt by telephone:

- If yes, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_5)

- If no, go to step 5.

- Determine if your task is ROE verification:

- If yes, go to Person is not reached — ROE verification .
               [Person is not reached — ROE verification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#nc_item_6)

- If no, go to step 6.

- In NWS, add details to the draft SROC as follows:

- Details: Type “Cannot reach the [client or third party] by telephone.”

- Select Save .

- Return to the previous task for next steps. 

#### Person is reached

Source topic: `en_EN/task/fact_find/person_is_reached_non-complex.dita`

- When you reach the person, identify yourself.

- If the fact-finding is with the client, go to step 2.

- If the fact-finding is with an employer or a third party, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3429.dita)

- Validate the client’s identity :

- If the client’s identity cannot be validated, go to step 3.

- If the client’s identity can be validated, go to step 4.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select the appropriate issue, or Other (if the issue is not in the menu).

- Comments: Type “Fact-finding not completed.”

- Details: Type “Unable to validate client’s identity.”

- Select Draft .

- Go to step 7.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 5.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 5.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for the call.

- Enter the details about the issue and, if necessary, indicate that the person reached is the client.

- Details: Enter the details as follows:

- Type “The client’s identity and address have been validated.”

- Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
                       [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Explain the reason for the call and conduct fact-finding.

- Return to the previous task for next steps, including documenting the file. 

#### Person is not reached — ROE verification

Source topic: `en_EN/task/fact_find/person_is_not_reached__roe_verification_non-complex.dita`

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334) .

- Employer or Third Party Address 1 (1336) .

- Employer or Third Party Address 2 (2440) .

- Employer or Third Party Address 3 (2441) .

- Opening Sentence to ER to Request or Clarify ROE/RFS (2794) .

- Select Request ROE Opening Sentence - claimant .

- Request for a Record of Employment (2797) .

- Request for Additional ROE Information

- Text - Free Text (1612): Enter the following information: issue you are inquiring about, your telephone number and work hours (in the employer’s time zone, if necessary) and the date which the information is required.

- Blank / Contact agent / Contact by phone or mail (11326): Select the appropriate option.

- In NWS, add details to the draft SROC as follows:

- Details: Type “Cannot reach the employer by telephone. Z-02-00-00 letter sent. Moved to Pending until [today’s date + 10 business days].”

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select ROE verification .

- Bring forward date: Enter today’s date + 10 business days.

- If the employer calls you within 10 business days of the letter being sent, do the following:

- Identify yourself.

- Explain the reason for the call.

- Conduct fact-finding.

- Return to the previous task for next steps including documenting the file.

- If the employer has not provided the ROE information by telephone or mail within 10 business days of the letter being sent, determine if a telephone number is on file or can be obtained:

- If a telephone number is on file or can be obtained, go to step 6.

- If no telephone number is on file or can be obtained, go to step 7.

- Call one more time:

- If you reach the employer, do the following:

- Identify yourself.

- Explain the reason for the call.

- Conduct fact-finding.

- Return to the previous task for next steps including documenting the file.

- If you do not reach the employer, do not leave a message. Go to step 7.

- In NWS, add details to the draft SROC as follows:

- Details: Document the communication attempt.

- Select Save .

- Return to the previous task for next steps. 

#### Note

Source topic: `en_EN/common_notes/note_c_3426.dita`

Note:

In order to ensure the email is sent to the email address that the client provided, copy the client’s email address from the Personal Information section of AW and paste it into the Email Address field of the template. When copying and pasting, ensure that an additional space is not inadvertently added to the beginning or the end of the email address. The email fails to send if there are extra spaces. 

#### Note

Source topic: `en_EN/common_notes/note_c_3427.dita`

Note:

A draft version of the E-02-00-00 email cannot be saved to send later. To exit the email template without sending, select Cancel . No information entered in the template will be saved.

Officers can confirm in ACS whether an email has been sent to a client using the Search option under Actions in the Email menu. At this time, ACS does not confirm whether the email has been sent successfully or is undeliverable. Instead, ACS generates a daily report listing all undeliverable emails sent the previous day. A Non-complex officer reviews the report and adds an SROC to the file documenting that the email was undeliverable. In these cases, the officer continues the fact-finding process as if a valid email has not been sent. 

#### Note

Source topic: `en_EN/common_notes/note_c_3428.dita`

Note:

If no telephone number is available, hold the task or move the WI to Pending for 48 hours. 

#### Note

Source topic: `en_EN/common_notes/note_c_3429.dita`

Note:

If the person is calling long-distance and will be charged, offer to call the person back to avoid the charges. 

### Level 1

Source topic: `en_EN/task/fact_find/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/fact_find/reviewing_the_file_level_1.dita`

- Determine if the telephone number of the person to call is on file or can be obtained:

- If the person’s telephone number is not on file and cannot be obtained, go to step 2.

- If the person’s telephone number is on file or can be obtained, go to First communication attempt by telephone .
               [First communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_2)

- In NWS, create a draft SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for the call.

- Type “Telephone number not available.”

- Details: Document the steps taken to try to obtain the telephone number.

- Select Draft .

- Determine if the person you are trying to reach is a client:

- If yes, go to step 4.

- If no, go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_6)

- Determine if the client has provided an email address:

- If yes, go to Communication attempt by email .
               [Communication attempt by email](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_3)

- If no, go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_6) 

#### First communication attempt by telephone

Source topic: `en_EN/task/fact_find/first_communication_attempt_by_telephone_level_1.dita`

- Call the person:

- If you do not reach the person, leave a message on a voice mail or with a third party. The message must include the following information:

- name of the person you wish to speak with.

- your name and organization (Service Canada — Employment Insurance).

- instruction for the person to call back within the next 24 hours.

- your telephone number and the hours you can be reached (in the client’s time zone, if necessary).

- Go to step 2.

- If you do not reach the person and you cannot leave a message, go to step 2.

- If you reach the person, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_5)

- In NWS, create a draft SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for the call.

- Enter the details about the issue and if necessary, identify the person you are calling.

- Details: Enter the appropriate details as follows:

- If a message has been left, enter the following details:

- telephone number called;

- date and time (in the client’s time zone, if necessary) of the message;

- whether the message has been left on a voice mail or with a third party;

- name of the third party, if necessary;

- position of the person, if contacting an employer;

- brief description of the questions and information required from the client or employer (end date of the final pay period, gross amount of vacation pay, etc.);

- contact information, including telephone number of the officer to be contacted.

- If no message has been left, type “[date and time (in the client’s time zone, if necessary) of the call] — unable to leave a message.” Include a brief description of the questions and information required from the client or employer, as well as the contact information, including telephone number of the officer to be contacted.

- Select Draft .

- Determine if the person you are trying to reach is a client who has provided an email address:

- If yes, go to Communication attempt by email .
               [Communication attempt by email](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_3)

- If no, go to step 4.

- In NWS, determine if there is a WI for the task:

- If there is no WI, hold the task for 24 hours.

- If there is a WI for the task, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].”

- Bring forward date: Enter tomorrow’s date.

- Determine if the person has called back within 24 hours of the first communication attempt by telephone:

- If yes, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_5)

- If no, go to Second communication attempt by telephone .
               [Second communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_4) 

#### Communication attempt by email

Source topic: `en_EN/task/fact_find/communication_attempt_by_email_level_1.dita`

- In ACS, create and send an E-02-00-00 email to the client as follows:

- On the Email tab, select Actions , then New .

- When the template opens, complete the following fields:

- Language: Select the appropriate option.

- Template: Select E-02-00-00 .

- SIN: Enter the client’s SIN.

- Email address: Copy and paste the client’s email address from the Personal Information section of AW.

- Your first name: Enter your first name.

- Telephone number where you can be reached: Enter your telephone number.

- Enter 1 or 2 (for working days): Select 1 working day if the client’s telephone number is on file. Select 2 working days if the client’s telephone number is not on file.

- Your hours of work (using the client’s time zone): Enter your work hours.

- Select Open to preview the email.

- Select Send to send the email.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3426.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3427.dita)

- In NWS, add details to the draft SROC as follows:

- Details: Enter the following details:

- client’s email address

- date and time (in the client’s time zone, if necessary) of the email

- E-02-00-00 email sent requesting contact from the client

- Select Draft .

- In NWS, determine if there is a WI for the previous task:

- If no , hold the task for 24 hours.

- If yes, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].”

- Bring forward date: Enter tomorrow’s date.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3428.dita)

- When the WI moves to the current workload, determine if the client has called back within 24 hours of the email communication attempt (or 48 hours if there is no telephone number on file):

- If no and there is a telephone number on file, go to Second communication attempt by telephone .
               [Second communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_4)

- If no and there is no telephone number on file, go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_6)

- If yes, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_5) 

#### Second communication attempt by telephone

Source topic: `en_EN/task/fact_find/second_communication_attempt_by_telephone_level_1.dita`

- Call the person again at a different time of day and at least 24 hours after the first communication attempt:

- If you do not reach the person, leave a message on a voice mail or with a third party. The message must include the following information:

- name of the person you wish to speak with.

- your name and organization (Service Canada — Employment Insurance).

- that this is a second call.

- instruction to call back within the next 24 hours.

- your telephone number and the hours you can be reached (in the client’s time zone, if necessary).

- Go to step 2.

- If you reach the person, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_5)

- If you do not reach the person and you cannot leave a message, go to step 2.

- In NWS, add details to the draft SROC as follows:

- Details: Enter the appropriate details:

- If a message has been left, enter the following details:

- telephone number called;

- date and time (in the client’s time zone, if necessary) of the message;

- whether the message has been left on a voice mail or with a third party;

- name of the third party, if necessary;

- position of the person, if contacting an employer.

- Select Draft .

- Go to step 3.

- If no message has been left, enter “[date and time (in the client’s time zone, if necessary) of the call] — unable to leave a message.”

- Select Draft .

- Go to Person is not reached .
                       [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_6)

- In NWS, determine if there is a WI for the previous task:

- If there is no WI, hold the task for another 24 hours.

- If there is a WI for the task, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].

- Bring forward date: Enter tomorrow’s date.

- Determine if the person has called back within 24 hours of the second communication attempt by telephone:

- If yes go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_5)

- If no, go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_6) 

#### Person is reached

Source topic: `en_EN/task/fact_find/person_is_reached_level_1.dita`

- When you reach the person, identify yourself.

- If the fact-finding is with the client, go to step 2.

- If the fact-finding is with an employer or a third party, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3429.dita)

- Validate the client’s identity :

- If the client’s identity cannot be validated, go to step 3.

- If the client’s identity can be validated, go to step 4.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the appropriate issue is not in the menu).

- Comments: Type “Fact-finding not completed.”

- Details: Type “Unable to validate client’s identity.”

- Select Draft .

- Go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_6)

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 5.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 5.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for the call.

- Enter the details about the issue and, if necessary, indicate that the person reached is the client.

- Details: Enter the details as follows:

- Type “The client’s identity and address have been validated.”

- Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
                       [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Explain the reason for the call and conduct fact-finding.

- Return to the previous task for next steps, including documenting the file. 

#### Person is not reached

Source topic: `en_EN/task/fact_find/person_is_not_reached_level_1.dita`

- Select the appropriate procedure based on the task to complete:

- ROE Verification
               [ROE Verification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#verification1)

- Missing ROE
               [Missing ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#MissingROE)

- Assessment Issue WI — Worker’s compensation benefits information
               [Assessment Issue WI — Worker’s compensation benefits information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#asmt1)

- Extending the qualifying period (QP) or benefit period (BP)
               [Extending the qualifying period (QP) or benefit period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#incarceration)

- Fact-finding with an employer or third party
               [Fact-finding with an employer or third party](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#eff1)

- Fact-finding with the client
               [Fact-finding with the client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#cff1)

- Fact-finding with the client — Direct deposit or warrant replacement
               [Fact-finding with the client — Direct deposit or warrant replacement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ClientFactFinding)

- Undeliverable mail or undeliverable Notice of Debt
               [Undeliverable mail or undeliverable Notice of Debt](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#umund)

- Medical certificate
               [Medical certificate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#MedicalCertificate) 

#### ROE Verification

Source topic: `en_EN/task/fact_find/roe_verification_level_1.dita`

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334) .

- Employer or Third Party Address 1 (1336) .

- Employer or Third Party Address 2 (2440) .

- Employer or Third Party Address 3 (2441) .

- Opening Sentence to ER to Request or Clarify ROE/RFS (2794) .

- Select Request ROE Opening Sentence - claimant .

- Request for a Record of Employment (2797) .

- Request for Additional ROE Information:

- Text - Free Text (1612): Enter the following information: issue you are inquiring about, your telephone number and work hours (in the employer’s time zone, if necessary) and the date which the information is required.

- Blank / Contact agent / Contact by phone or mail (11326): Select the appropriate option.

- In NWS, add details to the draft SROC as follows:

- Details: Type “Cannot reach the employer by telephone. Z-02-00-00 letter sent. Moved to Pending until [today’s date + 10 business days].”

- Select Draft .

- In NWS, if there is a WI for the task, move it to Pending as follows:

- Pending reason: Select ROE verification .

- Bring forward date: Enter today’s date + 10 business days.

- If the employer calls you within 10 business days of the letter being sent, do the following:

- Identify yourself.

- Explain the reason for the call.

- Conduct fact-finding.

- Return to the previous task for next steps including documenting the file.

- If the employer does not call you within 10 business days of the letter being sent, determine if a telephone number is on file or can be obtained:

- If a telephone number is on file or can be obtained, go to step 6.

- If no telephone number is on file or can be obtained, go to step 7.

- Call one more time:

- If you reach the employer, do the following:

- Identify yourself.

- Explain the reason for the call.

- Conduct fact-finding.

- Return to the previous task for next steps including documenting the file.

- If you do not reach the employer, do not leave a message. Go to step 7.

- In NWS, add details to the draft SROC as follows:

- Details: Document the communication attempt.

- Select Save .

- Return to the previous task for next steps. 

#### Missing ROE

Source topic: `en_EN/task/fact_find/missing_roe_level_1.dita`

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334) .

- Employer or Third Party Address 1 (1336) .

- Employer or Third Party Address 2 (2440) .

- Employer or Third Party Address 3 (2441) .

- Opening Sentence to ER to Request or Clarify ROE/RFS (2794) .

- Select Request ROE Opening Sentence - claimant .

- Request for a Record of Employment (2797) .

- Select Initial Request for ROE .

- Select Start-end employment / End date of employment (2798) .

- In NWS, highlight the most current application and create a Reminder (REM) WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Missing ROE .

- Comments: Enter the employer’s name.

- Due Date: Enter today’s date + 10 business days.

- Language: Select English or French .

- Details: Type “Follow-up with the employer is required for request for missing ROE. If the employer does not respond to request, send follow-up Z-02-00-00 letter and create follow-up REM WI.”

- Destination: Enter the SCC as shown in FTS.

- End user: Select Myself and complete the following fields:

- Send to my pending workload: Check the box.

- Pending reason: Select Fact finding employer .

- Comments: Type “Missing ROE, first letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- Select Save .

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “Cannot reach the employer by telephone. Z-02-00-00 letter sent. REM WI created for follow-up.”

- Select Draft .

- Return to the previous task for next steps. 

#### Assessment Issue WI — Workers’ compensation benefits information

Source topic: `en_EN/task/fact_find/assessment_issue_wi__workers_compensati_b0eb4cf0_level_1.dita`

- In ACS, create and send the Q-01-00-00 letter to the client with the following attributes:

- Info required-Re: Antedate/Medical or treatment outside/Mat-Par Direct Deposit/Family Caregiver/Text (2886) .

- Choose Specify information requested .

- TEXT - Specify information required (1544): Enter any missing information from the following list of required details:

- the payment start date

- the payment end date*

- the weekly or daily amount

- the first week amount

- the last week amount (if known) or whether the payment is continuing

- the type of workers’ compensation payment

- This letter replaces or Footnote (2365)

- Select Footnote .

- Text - Footnote (1066): Type “If you wish to provide this information by telephone, communicate with [your name] at [your telephone number and your work hours (in the client’s time zone, if necessary] before [date the information is due].”

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3430.dita)

- In NWS, add details to the draft SROC as follows:

- Details: Type “Unable to contact the client by telephone. Q-01-00-00 letter has been sent.”

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Q-01-00-00 letter sent.”

- Bring forward date: Enter today’s date + 10 working days.

- If the client returns the call, do the following:

- Validate the client’s identity .
               [Validate the client’s identity](/en/procedure/generic/additionalresources/validating_cict.shtml)

- Explain the reason for your call.

- Conduct fact-finding.

- Return to the previous task for next steps including documenting the file.

- When the WI is no longer pending if the client has not returned the call, do the following:

- Open the draft SROC and select Save .

- Return to previous task for next steps. 

#### Extending the qualifying period (QP) or benefit period (BP)

Source topic: `en_EN/task/fact_find/extending_the_qualifying_period_qp_or_b_c122ec6a_level_1.dita`

- In NWS, add details to the draft SROC as follows:

- Details: Type “Unable to fact-find by telephone.”

- Select Save .

- Return to the previous task for next steps. 

#### Fact-finding with an employer or third party

Source topic: `en_EN/task/fact_find/fact-finding_with_an_employer_or_third_party_level_1.dita`

- Determine if 2 messages were left at different times of day and at least 24 hours apart for the employer or third party to call back:

- If no, go to step 2.

- If yes, go to step 7.

- In ACS, create and send the Z-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334) .

- Employer or Third Party Address 1 (1336) .

- Employer or Third Party Address 2 (2440) .

- Employer or Third Party Address 3 (2441) .

- Text - Free Text (1612): Enter the following information:

- the issue you are inquiring about;

- your telephone number and work hours (in the client’s time zone, if necessary);

- date by which the information is required.

- In NWS, add details to the draft SROC as follows:

- Details: Type “Cannot reach the [employer or third party] by telephone. Z-00-00-00 letter sent. Moved to Pending until [today’s date + 10 business days].”

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Z-00-00-00 letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- If the employer or third party calls you within 10 business days of the letter being sent, do the following:

- Explain the reason for the call.

- Conduct fact-finding.

- Return to the previous task for next steps including documenting the file.

- If the employer or third party does not call you within 10 business days of the letter being sent, go to step 7.

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “No return call from [employer or third party].”

- Select Save .

- Return to the previous task for next steps. 

#### Fact-finding with the client

Source topic: `en_EN/task/fact_find/fact-finding_with_the_client_level_1.dita`

- Determine if one of the following conditions is met:

- There are 2 telephone messages that were left at different times of day and at least 24 hours apart for the client to call back.

- An email was sent asking the client to call back.

- If any condition is met, go to step 2.

- If no condition is met, go to step 3.

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “No return call from the client.”

- Select Save .

- Return to the previous task for next steps.

- In ACS, create and send the N-10-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Notice to Report for an Interview - in person / by telephone (2707): Select Contact us as soon as possible .

- Text - Agent’s Name (1614) .

- Text - Date of interview (3984): Type “As soon as possible before [today’s date + 10 business days].”

- Text - Time of Interview (1608): Type “Anytime between [hours and days you can be reached in the client’s time zone].”

- Text - Agent phone number (1656) .

- Important Message / Must leave phone number (2708): Select Must leave phone number .

- In NWS, add details to the draft SROC as follows:

- Details: Type “Cannot reach the client by telephone. N-10-00-00 letter sent. Moved to Pending until [today’s date + 10 business days].”

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “N-10-00-00 letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- If the client calls you within 10 business days of the letter being sent, go to step 8.

- If the client does not call you within 10 business days of the letter being sent, in NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “No return call from the client.”

- Select Save .

- Return to the previous task for next steps.

- Validate the client’s identity .

- If the client’s identity cannot be validated, go to step 9.

- If the client’s identity can be validated, go to step 10.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other ( if the issue is not in the menu).

- Comments: Type “Fact-finding not completed.”

- Details: Type “Unable to validate client’s identity.”

- Select Save .

- Go to step 11.

- Explain the reason for the call and conduct fact-finding.

- Return to the previous task. 

#### Fact-finding with the client — Direct deposit or warrant replacement

Source topic: `en_EN/task/fact_find/fact-finding_with_the_client__direct_de_729c73e5_level_1.dita`

- Determine if one of the following conditions is met:

- There are 2 telephone messages that were left at different times of day and at least 24 hours apart for the client to call back.

- An email was sent asking the client to call back.

- If any condition is met, go to step 2.

- If no condition is met, go to step 3.

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “No return call from the client.”

- Select Save .

- Return to the previous task for next steps.

- In ACS, create and send the N-10-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Notice to Report for an Interview - in person / by telephone (2707): Select Contact us as soon as possible .

- Text - Agent’s Name (1614) .

- Text - Date of interview (3984): Type “As soon as possible before [today’s date + 10 business days].”

- Text - Time of Interview (1608): Type “Anytime between [hours and days you can be reached in the client’s time zone].”

- Text - Agent phone number (1656) .

- Important Message / Must leave phone number (2708): Select Must leave phone number .

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “Cannot reach the client by telephone. N-10-00-00 letter sent. Moved to Pending until [today’s date + 10 business days].”

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “N-10-00-00 letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- If the client returns the calls within 10 business days of the letter being sent, go to step 8.

- If the client does not call you within 10 business days of the letter being sent, in NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “No return call from the client.”

- Select Save .

- Return to the previous task for next steps.

- Validate the client’s identity .

- If the client’s identity cannot be validated, go to step 9.

- If the client’s identity can be validated, go to step 10.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Type “Fact-finding not completed.”

- Details: Type “Unable to validate client’s identity.”

- Select Save .

- Go to step 11.

- Explain the reason for the call and conduct fact-finding.

- Return to the previous task. 

#### Undeliverable mail or undeliverable Notice of Debt

Source topic: `en_EN/task/fact_find/undeliverable_mail_or_undeliverable_not_46ca2336_level_1.dita`

- In NWS, add details to the draft SROC as follows:

- Details: Type “Unable to fact-find by telephone.”

- Select Save .

- Return to the previous task for next steps. 

#### Medical certificate

Source topic: `en_EN/task/fact_find/medical_certificate_level_1.dita`

- Determine if one of the following conditions is met:

- There are 2 telephone messages that were left at different times of day and at least 24 hours apart for the client to call back.

- An email was sent asking the client to call back.

- If either condition is met, go to step 2.

- If neither condition is met, go to step 3.

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “No return call from the client.”

- Select Save .

- Return to the previous task for next steps.

- In ACS, send a Q-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Info required - Re: Antedate/Medical or treatment outside Canada/Mat-Par Direct Deposit/Family Caregiver/Text (2886): Select Medical Certificate .

- Message: BF Date - If not received, may delay claim (2897) .

- Date Value (dd-mm-yyyy): Enter today’s date + 10 business days.

- Attachment List for Q-01-00-00 (3120): Select the appropriate attachment.

- In NWS, add details to the draft SROC as follows:

- Details: Type “Cannot reach the client by telephone. Q-01-00-00 letter sent. Moved to Pending until [today’s date + 10 business days].”

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Q-01-00-00 letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- If the client calls you within 10 business days of the letter being sent, go to step 8.

- If the client does not call within 10 business days of the letter being sent, in NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “No return call from the client.”

- Select Save .

- Return to the previous task for next steps.

- Validate the client’s identity .

- If the client’s identity cannot be validated, go to step 9.

- If the client’s identity can be validated, go to step 10.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the appropriate issue is not in the menu).

- Comments: Type “Fact-finding not completed.”

- Details: Type “Unable to validate the client’s identity.”

- Select Save .

- Go to step 11.

- Explain the reason for the call and conduct fact-finding.

- Return to the previous task. 

#### Note

Source topic: `en_EN/common_notes/note_c_3430.dita`

Note:

Some provincial workers’ compensation boards use an end date that means “up to but not including.” Ask the client to provide the date of the last day for which the workers’ compensation benefits were payable, for example, “What is the last day for which your WorkSafeNB benefits were paid?” 

### Level 2

Source topic: `en_EN/task/fact_find/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/fact_find/reviewing_the_file_level_2.dita`

- In ACS, determine if a fact-finding letter other than the E-02-00-00 email has been sent by Level 1 for this issue:

- If a letter has been sent, return to the previous task for next steps.

- If a letter has not been sent, go to step 2.

- Determine if the telephone number of the person is on file or can be obtained:

- If the person’s telephone number is not on file and cannot be obtained, go to step 3.

- If the person’s telephone number is on file or can be obtained, go to First communication attempt by telephone .
               [First communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_2)

- In NWS, create a draft SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for the call.

- Type “Telephone number not available.”

- Details: Document the steps taken to try to obtain the telephone number.

- Select Draft .

- Determine if the person you are trying to reach is a client who has provided an email address:

- If yes, go to step 5.

- If no, go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_6)

- Determine if Level 1 has sent an email to the client requesting a call back:

- If yes, go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_6)

- If no, go to Communication attempt by email .
               [Communication attempt by email](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_3) 

#### First communication attempt by telephone

Source topic: `en_EN/task/fact_find/first_communication_attempt_by_telephone_level_2.dita`

- Call the person:

- If you do not reach the person, leave a message on a voice mail or with a third party. The message should include the following information:

- name of the person you wish to speak with.

- your name and organization (Service Canada – Employment Insurance).

- instruction to call back within the next 24 hours.

- your telephone number and the hours you can be reached (in the client’s time zone, if necessary).

- Go to step 2.

- If you do not reach the person and you cannot leave a message, go to step 2.

- If you reach the person, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_5)

- In NWS, create a draft SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for the call.

- Enter the details about the issue and if necessary, identify the person you are calling.

- Details: Enter the appropriate details:

- If a message has been left, enter the following details:

- telephone number called;

- date and time (in the client’s time zone, if necessary) of the message;

- whether the message has been left on a voicemail or with a third party;

- name of the third party, if necessary;

- position of the person, if contacting an employer;

- brief description of the questions and information required from the client or employer (to discuss RFS, to discuss the client’s delay in filing the claim, etc.);

- contact information, including telephone number of the officer to be contacted.

- If no message has been left, type “[date and time (in the client’s time zone, if necessary, of the call] — unable to leave a message.” Include a brief description of the questions and information required from the client or employer, as well as the contact information, including telephone number of the officer to be contacted.

- Select Draft .

- Based on the fact-finding attempts by Level 1, determine if one of the following conditions is met:

- There are 2 telephone messages that were left at different times of day and at least 24 hours apart for the client to call back:

- An email was sent asking the client to call back.

- If no condition is met, go to step 4.

- If any condition is met, go to step 5.

- Determine if the person you are trying to reach is a client who has provided an email address:

- If yes, go to Communication attempt by email .
               [Communication attempt by email](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_3)

- If no, go to step 5.

- In NWS, determine if there is a WI for the previous task:

- If there is no WI, hold the task for 24 hours.

- If there is a WI, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].”

- Bring forward date: Enter tomorrow’s date.

- Determine if the person has called back within 24 hours of the first communication attempt by telephone:

- If yes, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_5)

- If no, go to step 7.

- Based on the fact-finding attempts by Level 1 and Level 2, determine if 2 messages have been left for the person to call back:

- If yes, save the draft SROC and return to the previous task to go to the next steps.

- If no, go to Second communication attempt by telephone .
               [Second communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_4) 

#### Communication attempt by email

Source topic: `en_EN/task/fact_find/communication_attempt_by_email_level_2.dita`

- In ACS, create and send an E-02-00-00 email to the client as follows:

- On the Email tab, select Actions , then New .

- When the template opens, complete the following fields:

- Language: Select the appropriate option.

- Template: Select E-02-00-00 .

- SIN: Enter the client’s SIN.

- Email address: Copy and paste the client’s email address from the Personal Information section of AW.

- Your first name: Enter your first name.

- Telephone number where you can be reached: Enter your telephone number.

- Enter 1 or 2 (for working days): Select 1 working day if the client’s telephone number is on file. Select 2 working days if the client’s telephone number is not on file.

- Your hours of work (using the client’s time zone): Enter your work hours.

- Select Open to preview the email.

- Select Send to send the email.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3426.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3427.dita)

- In NWS, add details to the draft SROC as follows:

- Details: Enter the following details:

- client’s email address

- date and time (in the client’s time zone, if necessary) of the email

- E-02-00-00 email sent requesting contact from the client

- Select Draft .

- In NWS, determine if there is a WI for the previous task:

- If no , hold the task for 24 hours.

- If yes, move it to Pending as follows:

- Pending reason: Select the appropriate Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].”

- Bring forward date: Enter tomorrow’s date.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3428.dita)

- When the WI moves to the current workload, determine if the client has called back within 24 hours of the email communication attempt (or 48 hours if there is no telephone number on file):

- If no and there is a telephone number on file, go to Second communication attempt by telephone .
               [Second communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_4)

- If no and there is no telephone number on file, go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_6)

- If yes, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_5) 

#### Second communication attempt by telephone

Source topic: `en_EN/task/fact_find/second_communication_attempt_by_telephone_level_2.dita`

- Call the person again at a different time of day than the first communication attempt was made:

- If you do not reach the person, leave a message on a voice mail or with a third party. The message must include the following information:

- name of the person you wish to speak with.

- your name and organization (Service Canada — Employment Insurance).

- that this is a second call.

- instruction to call back within the next 24 hours.

- your telephone number and the hours you can be reached (in the client’s time zone, if necessary).

- Go to step 2.

- If you do not reach the person and cannot leave a message, go to step 2.

- If you reach the person, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_5)

- In NWS, add details to the draft SROC as follows:

- Details: Enter the appropriate details:

- If a message has been left, enter the following details:

- telephone number called;

- date and time (in the client’s time zone, if necessary) of the message;

- whether the message has been left on a voice mail or with a third party;

- name of the third party, if necessary;

- position of the person, if contacting an employer.

- Select Draft .

- Go to step 3.

- If no message has been left, type “[date and time (in the client’s time zone, if necessary) of the call] — unable to leave a message.”

- Select Draft .

- Go to Person is not reached .
                       [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_6)

- In NWS, determine if there is a WI for the previous task:

- If there is no WI, hold the task for 24 hours.

- If there is a WI for the task, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task.]”

- Bring forward date: Enter tomorrow’s date.

- Determine if the person has called back within 24 hours of the second communication attempt by telephone:

- If yes, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_5)

- If no, go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_6) 

#### Person is reached

Source topic: `en_EN/task/fact_find/person_is_reached_level_2.dita`

- When you reach the person, identify yourself.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3429.dita)

- Validate the client’s identity :

- If the client’s identity cannot be validated, go to step 3.

- If the client’s identity can be validated, go to step 4.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Type “Fact-finding not completed.”

- Details: Type “Unable to validate client’s identity.”

- Select Draft .

- Go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level2_item_6)

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 5.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 5.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for the call.

- Enter the details about the issue and, if necessary, indicate that the person reached is the client.

- Details: Enter the details as follows:

- Type “The client’s identity and address have been validated.”

- Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
                   [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Explain the reason for the call and conduct fact-finding.

- Return to the previous task for next steps, including documenting the file. 

#### Person is not reached

Source topic: `en_EN/task/fact_find/person_is_not_reached_level_2.dita`

- Select the appropriate procedure based on the task to complete:

- Fact-finding with an employer or third party
               [Fact-finding with an employer or third party](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#FactFindingEmployerThirdParty)

- Fact-finding with the client
               [Fact-finding with the client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#FactFindingWithTheClient) 

#### Fact-finding with an employer or third party

Source topic: `en_EN/task/fact_find/fact-finding_with_an_employer_or_third_party_level_2.dita`

- Determine if 2 messages were left at different times of day and at least 24 hours apart for the employer or third party to call back:

- If yes, go to step 2.

- If no, go to step 3.

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “No return call from [employer or third party].”

- Select Save .

- Return to the previous task for next steps.

- In ACS, create and send the Z-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334) .

- Employer or Third Party Address 1 (1336) .

- Employer or Third Party Address 2 (2440) .

- Employer or Third Party Address 3 (2441) .

- Text - Free Text (1612): Enter the following information:

- issue you are inquiring about

- your telephone number and work hours (in the client’s time zone, if necessary)

- date by which the information is required

- In NWS, add details to the draft SROC as follows:

- Details: Type “Cannot reach the [employer or third party] by telephone. Z-00-00-00 letter sent. Moved to Pending until [today’s date + 10 business days].”

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Z-00-00-00 letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- If the employer or third party calls you within 10 business days of the letter being sent, do the following:

- Identify yourself.

- Explain the reason for your call.

- Conduct fact-finding.

- Return to the previous task for next steps including documenting the file.

- If the employer or third party does not call you within 10 business days of the letter being sent, go to step 8.

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “No return call from [employer or third party].”

- Select Save .

- Return to the previous task for next steps. 

#### Fact-finding with the client

Source topic: `en_EN/task/fact_find/fact-finding_with_the_client_level_2.dita`

- Determine if one of the following conditions is met:

- There are 2 telephone messages that were left at different times of day and at least 24 hours apart for the client to call back.

- An email was sent asking the client to call back.

- If no condition is met, go to step 2.

- If any condition is met, go to step 7.

- In ACS, create and send the N-10-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Notice to Report for an Interview - in person / by telephone (2707): Select Contact us as soon as possible .

- Text - Agent’s Name (1614 ).

- Text - Date of interview (3984): Type “As soon as possible before [today’s date +10 business days].”

- Text - Time of Interview (1608): Type “Anytime between [hours and days you can be reached, in the client’s time zone].”

- Text - Agent phone number (1656) .

- Important Message / Must leave phone number (2708): Select Must leave phone number .

- In NWS, add details to the draft SROC as follows:

- Details: Type “Cannot reach the client by telephone. N-10-00-00 letter sent. Moved to Pending until [today’s date + 10 business days].”

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “N-10-00-00 letter sent.”

- Bring forward date: Enter the date the letter is sent + 10 business days.

- If the client calls you within 10 business days of the letter being sent, go to step 8.

- If the client does not call you within 10 business days of the letter being sent, go to step 7.

- In NWS, add details to the draft SROC as follows:

- Details: Type “No return call from the client.”

- Select Save .

- Return to the previous task for next steps, including documenting the file.

- Validate the client’s identity .

- If the client’s identity cannot be validated, go to step 9.

- If the client’s identity can be validated, go to step 10.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Type “Fact-finding not completed.”

- Details: Type “Unable to validate client’s identity.”

- Select Save .

- Go to step 11.

- Explain the reason for the call and conduct fact-finding.

- Return to the previous task for next steps, including documenting the file. 

### IPOC

Source topic: `en_EN/task/fact_find/ipoc.dita`

#### Reviewing the file

Source topic: `en_EN/task/fact_find/reviewing_the_file_ipoc.dita`

- Determine if the telephone number of the person is on file or can be obtained:

- If the person’s telephone number is not on file and cannot be obtained, go to step 2.

- If the person’s telephone number is on file or can be obtained, go to First communication attempt by telephone .
               [First communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_2)

- In NWS, create a draft SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for your call.

- Type “Telephone number not available.”

- Details: Document the steps taken to try to obtain the telephone number.

- Select Draft .

- Determine if the person you are trying to reach is a client who has provided an email address:

- If yes, go to Communication attempt by email .
               [Communication attempt by email](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_3)

- If no, go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_6) 

#### First communication attempt by telephone

Source topic: `en_EN/task/fact_find/first_communication_attempt_by_telephone_ipoc.dita`

- Call the person:

- If you do not reach the person, leave a message on a voicemail or with a third party. The message must include the following information:

- name of the person you wish to speak with.

- your name and organization (Service Canada — Employment Insurance).

- instruction to call back within the next 24 hours.

- your telephone number and the hours you can be reached (in the client’s time zone, if necessary).

- Go to step 2.

- If you do not reach the person and you cannot leave a message, go to step 2.

- If you reach the person, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_5)

- In NWS, create a draft SROC with the following information:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for your call.

- Enter the details about the issue.

- Details: Enter the appropriate details:

- If a message has been left, enter the following details:

- telephone number called;

- date and time (in the client’s time zone, if necessary) of the message;

- whether the message has been left on a voice mail or with a third party;

- name of the third party, if necessary;

- brief description of the questions and information required from the client;

- contact information, including telephone number of the officer to be contacted.

- If no message has been left, type “[date and time (in the client’s time zone, if necessary) of the call] — unable to leave a message.” Include a brief description of the questions and information required from the client, as well as the contact information, including telephone number of the officer to be contacted.

- Select Draft .

- Determine if the person you are trying to reach is a client who has provided an email address:

- If yes, go to Communication attempt by email .
               [Communication attempt by email](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_3)

- If no, go to step 4.

- In NWS, determine if there is a WI for the previous task:

- If there is no WI, hold the task for 24 hours.

- If there is a WI, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].”

- Bring forward date: Enter tomorrow’s date.

- Determine if the person has called back within 24 hours of the first communication attempt by telephone:

- If yes go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_5)

- If no, go to Second communication attempt by telephone .
               [Second communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_4) 

#### Communication attempt by email

Source topic: `en_EN/task/fact_find/communication_attempt_by_email_ipoc.dita`

- In ACS, create and send an E-02-00-00 email to the client as follows:

- On the Email tab, select Actions , then New .

- When the template opens, complete the following fields:

- Language: Select the appropriate option.

- Template: Select E-02-00-00 .

- SIN: Enter the client’s SIN.

- Email address: Copy and paste the client’s email address from the Personal Information section of AW.

- Your first name: Enter your first name.

- Telephone number where you can be reached: Enter your telephone number.

- Enter 1 or 2 (for working days): Select 1 working day if the client’s telephone number is on file. Select 2 working days if the client’s telephone number is not on file.

- Your hours of work (using the client’s time zone): Enter your work hours.

- Select Open to preview the email.

- Select Send to send the email.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3426.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3427.dita)

- In NWS, add details to the draft SROC as follows:

- Details: Enter the following details:

- client’s email address

- date and time (in the client’s time zone, if necessary) of the email

- E-02-00-00 email sent requesting contact from the client

- Select Draft .

- In NWS, determine if there is a WI for the previous task:

- If no , hold the task for 24 hours.

- If yes, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].”

- Bring forward date: Enter tomorrow’s date.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3428.dita)

- When the WI moves to the current workload, determine if the client has called back within 24 hours of the email communication attempt (or 48 hours if there is no telephone number on file):

- If no and there is a telephone number on file, go to Second communication attempt by telephone .
               [Second communication attempt by telephone](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_4)

- If no and there is no telephone number on file, go to Person is not reached .
               [Person is not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_6)

- If yes, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#level1_item_5) 

#### Second communication attempt by telephone

Source topic: `en_EN/task/fact_find/second_communication_attempt_by_telephone_ipoc.dita`

- Call the person again at a different time of day and at least 24 hours after the first communication attempt:

- If you do not reach the person, leave a message on a voicemail or with a third party. The message must include the following information:

- name of the person you wish to speak with.

- your name and organization (Service Canada — Employment Insurance).

- that this is a second call.

- instruction to call back within the next 24 hours.

- your telephone number and the hours you can be reached (in the client’s time zone, if necessary).

- Go to step 2.

- If you do not reach the person and you cannot leave a message, go to step 2.

- If you reach the person, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_5)

- In NWS, add details to the draft SROC as follows:

- Details: Enter the appropriate details:

- If a message has been left, enter the following details:

- telephone number called;

- date and time (in the client’s time zone, if necessary) of the message;

- whether the message has been left on a voicemail or with a third party;

- name of the third party, if necessary.

- Select Draft.

- Go to step 3.

- If no message has been left, type “[date and time (in the client’s time zone, if necessary) of the call] — unable to leave a message.”

- Select Draft .

- Go to Person not reached .
                       [Person not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_6)

- In NWS, determine if there is a WI for the previous task:

- If there is no WI, hold the task for another 24 hours.

- If there is a WI for the task, move it to Pending as follows:

- Pending reason: Select the appropriate task or Other (if the task is not in the menu).

- Comments: Type “Fact-finding — [name of the task].”

- Bring forward date: Enter tomorrow’s date.

- Determine if the person has called back within 24 hours of the second communication attempt by telephone:

- If yes, go to Person is reached .
               [Person is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_5)

- If no, go to Person not reached .
               [Person not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/fact_find#ipocc_item_6) 

#### Person is reached

Source topic: `en_EN/task/fact_find/person_is_reached_ipoc.dita`

- When you reach the person, identify yourself.

- If the fact-finding is with the client, go to step 2.

- If the fact-finding is with an employer or a third party, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3429.dita)

- Validate the client’s identity :

- If the client’s identity cannot be validated, go to step 3.

- If the client’s identity can be validated, go to step 4.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Type “Fact-finding not completed.”

- Details: Type “Unable to validate client’s identity.”

- Select Draft .

- Return to the previous task.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 5.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 5.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select the appropriate issue or Other (if the issue is not in the menu).

- Comments: Enter the details as follows:

- If Other is selected in the Main Issue field, document the reason for the call.

- Enter the details about the issue and, if necessary, indicate that the person reached is the client.

- Details: Enter the details as follows:

- Type “The client’s identity and address have been validated.”

- Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
                   [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Explain the reason for the call and conduct fact-finding.

- Return to the previous task for next steps, including documenting the file. 

#### Person is not reached

Source topic: `en_EN/task/fact_find/person_is_not_reached_ipoc.dita`

- If you do not reach the person or the person did not return the call, in NWS, add details to the draft SROC as follows:

- Details: Type “No telephone contact with the person, [reason for no contact].”

- Select Save .

- Return to previous task for next steps. 

## Policy reference

Source topic: `en_EN/task/fact_find/policy_reference.dita`

- National Fact-finding and Documentation Policy
         [National Fact-finding and Documentation Policy](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Sections 7 and 8 of the Privacy Act
         [Sections 7 and 8 of the Privacy Act](http://laws-lois.justice.gc.ca/eng/acts/P-21/section-7.html) 
