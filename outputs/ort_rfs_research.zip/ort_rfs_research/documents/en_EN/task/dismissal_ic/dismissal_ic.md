# Adjudicating a dismissal for unsuitability — Initial claim

Source map: `en_EN/task/dismissal_ic/dismissal_ic.ditamap`

## Summary

Source topic: `en_EN/task/dismissal_ic/summary.dita`

Summary: The Level 1 officer adjudicates cases of dismissal only when clients are dismissed because they were not suitable, did not pass training or were terminated within the probationary period, and not for an ill-intentioned action. 

## What you need to know

Source topic: `en_EN/task/dismissal_ic/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/dismissal_ic/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3258.dita) 

### Adjudicating a dismissal for unsuitability

Source topic: `en_EN/task/dismissal_ic/adjudicating_a_dismissal_for_unsuitability.dita`

Clients may be dismissed for unsuitability during the probationary period or if they do not pass the probationary period or they do not meet the job requirements. 

### Levels of decision

Source topic: `en_EN/task/dismissal_ic/levels_of_decision.dita`

In order for the dismissal to be adjudicated at Level 1, the client’s statement on the application must show that the client was dismissed for being unsuitable or due to a shortage of work. In addition, the employer’s statement or comments on the ROE must indicate that the client was dismissed for being unsuitable ( Not suitable , Did not pass training , or Terminated within the probationary period ) and there must not be any other contentious issues related to the dismissal that would prevent the Level 1 officer from allowing the reason for separation (RFS).

If the client worked for the employer for 12 weeks or less and the employer or the comments on the ROE confirm that the RFS is unsuitability ( Not suitable , Did not pass training or Terminated within the probationary period ), the officer does not fact-find with the client, even if the client did not provide details regarding the employment on the EI application. The officer can allow the dismissal as long as there are no other contentious issues related to the dismissal.

If the employer or ROE comments do not confirm unsuitability, or if the client worked for the employer for more than 12 weeks, the officer fact-finds with the client.

For more information, the officer refers to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

The officer reviews the ROE to determine if there are comments showing that the client was dismissed for unsuitability or if the client’s employment was terminated in the probationary period. On a Web ROE, the employer can select the Terminated within probationary period field. If there is no indication on the ROE or if there is no ROE on file, the officer fact-finds with the employer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3226.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3259.dita) 

### ROE

Source topic: `en_EN/task/dismissal_ic/roe.dita`

An ROE is not required to adjudicate dismissal.

In NWS, there may be a New ROE message displayed on the ADJ WI for the dismissal issue. The message indicates that a new ROE has been received with an RFS that must be reviewed. The ROE may match the period of employment for that or another outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3260.dita) 

### ACP adjudication

Source topic: `en_EN/task/dismissal_ic/acp_adjudication.dita`

ACP automatically adjudicates dismissals when a series of questions on the application are answered according to the unsuitability.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3239.dita) 

### Claim action status and processing the claim

Source topic: `en_EN/task/dismissal_ic/claim_action_status_and_processing_the_claim.dita`

During processing, an initial claim displays of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can process the claim. There is a Resolve Issue tab for ADJ Dismissed or suspended WIs which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a record of decision (ROD) based on the Resolve Issue screens. Before the claim is calculated, the system updates the ROE based on the Resolve Issue screens. No letter is sent when the dismissal for unsuitability is allowed. 

### Previously adjudicated decision

Source topic: `en_EN/task/dismissal_ic/previously_adjudicated_decision.dita`

In some cases, the ADJ WI may be for a dismissal issue that was previously adjudicated. The officer indicates on the Resolve Issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the appropriate special condition based on the previous decision. The system updates the ROE when the ADJ WI is completed. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/dismissal_ic/determining_if_the_file_must_be_referre_f4ff817e.dita`

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/dismissal_ic/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the dismissal or suspension is not required if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, the ADJ WI must not be completed. The officer follows the procedures and conditions for removal of claims from ACP process . The officer moves the ADJ WI to Pending until the Claim Assessment (CA) or Specialized Application (SA) WI is created. An authorized user must then delete the ADJ WI.
       [procedures and conditions for removal of claims from ACP process](https://esdc.prv/en/service-canada/ei/technologies/acp/index.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3240.dita) 

### Reason for separation (RFS) — Temporary Budget measures

Source topic: `en_EN/task/dismissal_ic/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**Adjudicating the last employment in the qualifying period (QP) — BPCs between w/c 2310 and w/c 2361**

Budget 2021 has introduced a temporary simplification measure starting September 26, 2021. For claims with a BPC between w/c 2310 and w/c 2361, the officer will only adjudicate the last period of employment in the QP if it is contentious. If the officer allows the last RFS, all other ROEs in the QP, even if they are contentious, are used to calculate the claim. If, however, the officer does not allow the RFS on the last ROE in the QP, the claim is calculated with a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 

This new measure does not apply to self-employment (SE) and fishing claims. If clients applying for SE or fishing benefits have a BPC w/c 2310 and later, insurable employment in the QP and any contentious RFSs, these RFSs must be adjudicated following normal adjudication procedures.

When the client declares other employers with a contentious RFS on the same application, if ACP does not allow the issue under auto-adjudication rules, the issue is automatically resolved and ACP creates a record of decision (ROD) that shows Adjudication not Required . The Special condition field on the ROE is not updated, and the ROE is included in the calculation. An Adjudication Issue (ADJ) WI is not created for the RFS.

ACP does not always automatically create an ADJ WI when the application is received. However, if an ROE with a contentious RFS is received during the automation process, ACP may create an ADJ WI or ROE Issue (ROE) RFS Action WI.

When there is more than one ROE with the same last day paid (LDP), and one of the ROEs is contentious while the other ROE is not, adjudication is not required and both ROEs will be included in the calculation.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3261.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3262.dita) 

**Adjudication not required: Reason for separation (RFS) beyond 12 weeks — BPCs between w/c 2258 and w/c 2309**

Adjudication principles on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309 only apply to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the interruption of earnings (I of E) used to establish the claim.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3263.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_3258.dita`

Note:

If the adjudication of the dismissal is part of a recalculation, the officer refers to Adjudicating a dismissal for unsuitability — Continuing claim .
       [Adjudicating a dismissal for unsuitability — Continuing claim](/en/procedure/task/dismissal_cc.shtml)

     [Adjudicating a dismissal for unsuitability — Continuing claim](/en/procedure/task/dismissal_cc.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3226.dita`

Note:

On a Web ROE, the employer can select the code M - Dismissal or suspension / Terminated within the probationary period in block 16 - Reason for Issuing the ROE , which is equivalent to comments in block 18 indicating that the client was dismissed due to unsuitability, not passing training or being terminated within the probationary period. 

### Note

Source topic: `en_EN/common_notes/note_c_3259.dita`

Note:

The statement that the client was dismissed without cause is not sufficient to conclude that the client was dismissed for unsuitability. The officer must fact-find with the employer to determine the cause of the dismissal.

Confirmation of the reason for dismissal with the employer is not required if the comment on the ROE shows one of the following reasons:

- Not suitable;

- Did not pass training;

- Terminated within the probationary period. 

### Note

Source topic: `en_EN/common_notes/note_c_3260.dita`

Note:

The client may report dismissal on the EI application but the ROE indicates a non-contentious RFS. In this situation, the officer conducts fact-finding. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the officer completes the WI indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_3239.dita`

Note:

If a claim is between w/c 2310 and w/c 2361 and all ROEs are on file, ACP may automatically resolve ADJ RFS WIs for periods of employment other than the last. 

### Note

Source topic: `en_EN/common_notes/note_c_3240.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the dismissal or suspension is required when the employment is not insurable due to a non-arm’s length issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Example 1

Source topic: `en_EN/common_notes/note_c_3261.dita`

Example 1:

Peter’s LDP was September 28, 2021 (w/c 2310) with 2 employers. Three periods of employment are provided on his EI application. Peter declared Employer 1 as his last employer and the RFS is shortage of work. In the Other Employers section of the application, Peter declared Employer 2 and the RFS is dismissal. He also declared Employer 3 and the RFS is voluntary leaving. The interruption of earnings (I of E) is in w/c 2310, and he applied for benefits on September 29, 2021. His BPC is September 26, 2021 (w/c 2310).

There are 2 contentious ROEs on Peter’s file:

- Employer 1: The LDP is September 28, 2021 (w/c 2309). The RFS is A .

- Employer 2: The LDP is September 28, 2021 (w/c 2309). The RFS is M .

- Employer 3: The LDP is May 19, 2021 (w/c 2291). The RFS is E .

Employer 1 and Employer 2 have the same LDP. Employer 1 has a non-contentious RFS, so adjudication is not required for Employer 2. ACP automatically resolves the RFS for Employer 2 and creates a ROD that shows Adjudication not required .

Employer 3 has a contentious RFS and is in the QP. However, because it is not the last employer in the QP, adjudication is not required. ACP creates a ROD that shows Adjudication not required .

All ROEs are included in the calculation of the claim. 

### Example 2

Source topic: `en_EN/common_notes/note_c_3262.dita`

Example 2:

Abdul’s LDP was September 24, 2021 (w/c 2309) with both of his employers. He declared Employer 1 as his last employer and the RFS is dismissal. In the Other Employers section of the application, Abdul declared Employer 2 and the RFS is voluntary leaving. The I of E is in w/c 2309, and he applied for benefits on September 26, 2021. His BPC is September 26, 2021 (w/c 2310).

- There are 2 contentious ROEs on Abdul’s file:

- Employer 1: The LDP is September 24, 2021 (w/c 2309). The RFS is M .

- Employer 2: The LDP is September 24, 2021 (w/c 2309). The RFS is E .

Employer 1 and 2 have the same LDP and both have a contentious RFS. ACP creates an ADJ WI for Employer 1, automatically resolves the RFS issue for Employer 2 and creates a ROD that shows Adjudication not required . If the dismissal with Employer 1 is not allowed, the RFS with Employer 2 must be adjudicated. 

### Example

Source topic: `en_EN/common_notes/note_c_3263.dita`

Example:

Mary’s LDP was September 25, 2020 (w/c 2257). Her I of E is in w/c 2257, she submitted her EI application on September 26, 2020, and her BPC will be September 27, 2020 (w/c 2258).

There are 3 contentious ROEs on Mary’s file:

ROE 1: LDP September 25, 2020 (w/c 2257).

ROE 2: LDP July 17, 2020 (w/c 2247).

ROE 3: LDP May 31, 2020 (w/c 2241).

To determine which RFS to adjudicate, the officer subtracts 12 weeks from w/c 2257 (week of the I of E). For the example above, the formula is as follows: w/c 2257 (I of E) – 12 = w/c 2245. This determines a 12-week period falling before the Sunday of the I of E that encompasses the weeks from w/c 2245 to w/c 2256. The officer follows normal procedures and adjudicates ROE 1, which is the most recent ROE in the QP, and ROE 2, as it falls between w/c 2245 and w/c 2256, the 12-week period.

The officer allows any contentious RFS that occurs before the 12-week period. ROE 3 is before the 12-week period, so the officer allows the RFS by following the steps of Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
       [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#beyond_12_wks)

     [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#beyond_12_wks) 

## Regional considerations

Source topic: `en_EN/task/dismissal_ic/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/dismissal_ic/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/dismissal_ic/in_nws.dita`

- Is there a ROD for the dismissal in question on the claim file or on a previous claim?

- Is there a dismissal or suspension questionnaire?

- Are there are any SROCs, Action Items (AI) WIs or documentation containing checklists or other details relating to the dismissal?

- Is the appropriate ROE linked to the period of employment for the dismissal issue? 

### In Imaging:

Source topic: `en_EN/task/dismissal_ic/in_imaging.dita`

- Are there any imaged documents relating to the dismissal? 

### In RCM:

Source topic: `en_EN/task/dismissal_ic/in_rcm.dita`

- Was the ROE received for the dismissal? If yes:

- Is the RFS K or M in block 16 of the ROE?

- Are there comments in block 18 of the ROE? 

## Step by step

Source topic: `en_EN/task/dismissal_ic/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/dismissal_ic/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/dismissal_ic/reviewing_the_file_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, determine if the appropriate ROE linked to the period of employment:

- If yes, go to step 2.

- If no, select the appropriate ROE in the list and select Save to create a link.

- If the ROE is not on file, go to step 2.

- Determine if there is a ROD for the dismissal issue on file:

- If there is no ROD for the dismissal issue, go to step 3.

- If there is a ROD for the dismissal issue, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ic#DecisionOnFile)

- Determine if the facts on file clearly indicate that the RFS occurred before the QP:

- If no, go to step 4.

- If yes, go to Reason for separation (RFS) occurred before the qualifying period (QP) .
               [Reason for separation (RFS) occurred before the qualifying period (QP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ic#RFSB4QP)

- In FTS, determine if the BPC is in a period where special measures apply:

- If the BPC is between w/c 2258 and w/c 2309, go to step 5.

- If the BPC is between w/c 2310 and w/c 2360, go to step 7.

- If the BPC is not in either of the periods, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita)

- Determine if the dismissal occurred on the most recent ROE:

- If no, go to step 6.

- If yes, go to step 9.

- Determine if the dismissal occurred within the 12-week period before the I of E:

- If yes, go to step 9.

- If no, go to Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
               [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ic#beyond_12_wks)

- Determine if the claim is for SE benefits or Fishing:

- If no, go to step 8.

- If yes, go to step 9.

- Determine if the dismissal occurred on the most recent ROE:

- If yes, go to step 9.

- If no, go to Adjudication not required – Budget 2021 simplification measures
               [Adjudication not required – Budget 2021 simplification measures](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ic#adj_not_required_budget_2021)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 10.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 12.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ic#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if there is enough information to adjudicate the dismissal based on the National Policy on Levels of Decision :

- If no, go to step 13.

- If yes, go to step 16. 

#### Fact-finding

Source topic: `en_EN/task/dismissal_ic/fact-finding_level_1.dita`

- Fact-find with the client or the employer.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3228.dita)

- Determine if the client or employer was reached during fact-finding:

- If the client or employer was reached, go to step 15.

- If the client or employer was not reached or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to Reassigning the issue to Level 2
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ic#level2)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Dismissal — [employer’s name] — [LDW] — [client or employer].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/dismissal_ic/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the RFS is contentious:

- If the RFS is dismissal, go to step 17.

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS).
               [Non-contentious reason for separation (RFS).](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ic#RFSVL)

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if the client provided details about the RFS on the EI application:

- If no, go to step 18.

- If yes, go to step 19.

- Determine if the following conditions are met:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3264.dita) 

- If all conditions are not met, go to step 19.

- If all conditions are met, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ic#RFSallowed)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3265.dita)

- Determine if all conditions are met to allow adjudication at Level 1:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3266.dita) 

- If all conditions are met, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ic#RFSallowed)

- If all conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ic#level2) 

#### Adjudication not required — Budget 2021 simplification measures

Source topic: `en_EN/task/dismissal_ic/adjudication_not_required__budget_2021__620824ac_level_1.dita`

- In NWS, On the Resolve Issue tab of the ADJ WI, complete the as follows:

- Resolve issue: Select Adjudication not required — Budget 2021 EI Simplification Measures .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/dismissal_ic/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Dismissal screen as follows:

- Select Based on the information on file, the criteria to allow the decision to be made at Level 1 have been met. The employer confirms the reason for separation was not due to any wrong-doing on the part of the client. (National Policy on Levels of Decision) .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/dismissal_ic/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Dismissal or suspension — [employer’s name] — [LDW] — adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the dismissal or suspension is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the shares business. Adjudication of the dismissal or suspension is therefore not required.”

- Determine the Claim action status:

- If the status is Initial — In Progress (Automation) , go to step 3.

- If the status is Initial — In Progress (Manual) , go to step 6.

- In NWS, create a Reminder WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “ACP.”

- Due date: Enter today’s date.

- Language: Select the appropriate option.

- Details: Type “2” and “Processing — [unallocated or user name to whom the CA or SA WI is to be assigned].”

- Destination: Select Level and Canada .

- End User: Select Specific user . Type “SV-ADMIN, ACP-TAD” and select Find User .

- Select Save .

- Move the ADJ WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting removal of claim from automation process. Employment not insurable. This WI must be deleted once CA or SA WI is created.”

- Bring forward date: Enter today’s date + 2 business days.

- Select OK .

- When the ADJ WI moves to the current workload, confirm that the Claim action status is Initial — In Progress (Manual) and a CA or SA WI was created.

- Contact an authorized user (team leader or Business Expertise Advisor) to delete the ADJ WI. 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/dismissal_ic/non-contentious_reason_for_separation_rfs_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Dismissal screen as follows:

- Select The reason for separation is not dismissal or suspension .

- Select Continue .

- Complete the Not dismissal or suspension screen as follows:

- Select the appropriate RFS.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reason for separation (RFS) occurred before the qualifying period (QP)

Source topic: `en_EN/task/dismissal_ic/reason_for_separation_rfs_occurred_befo_370bd688_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Dismissal screen as follows:

- Select The period of employment falls prior to the qualifying period .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/dismissal_ic/decision_already_on_file_level_1.dita`

- Determine if the appropriate decision is listed:

- If yes, on the list, select the appropriate ROD and select Save . Go to step 4.

- If no, select Decision not in the list .

- Select the appropriate special condition based on the decision on file and select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Adjudication not required — Reason for separation (RFS) beyond 12 weeks

Source topic: `en_EN/task/dismissal_ic/adjudication_not_required__reason_for_s_d81cc200_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Dismissal — [employer’s name] — [LDW] — adjudication not required.”

- Details: Type “Post-Employment Insurance Emergency Response Benefit transitional measure — reason for separation beyond 12 weeks. EIA 153.194.”

- Select Save .

- On the Resolve Issue tab of the ADJ WI, complete the Level 1 Dismissal screen as follows:

- Is the decision for this issue already on file?:

- Select Yes .

- Select Decision not in the list .

- Special Condition: Select Misconduct not proven .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reassigning the WI issue to Level 2

Source topic: `en_EN/task/dismissal_ic/reassigning_the_wi_issue_to_level_2_level_1.dita`

- In NWS, reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Client dismissed for reasons other than unsuitable. Not within Level 1 authority.”

- Select OK .

- When the Warning window is displayed, select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_3228.dita`

Note:

If fact-finding with the employer is required to confirm that the client was dismissed for unsuitability, ask the employer to provide more details regarding why the client was dismissed.

For example, was the client unsuitable because they were unable to perform the tasks required or was the client considered unsuitable because they were late to work every day? The client being unable to perform the tasks required requires Level 1 adjudication, but being late requires Level 2 adjudication. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3264.dita`

- the client worked for the employer for 12 weeks or less; and

- the employer, when contacted, confirms that the client was not suitable for the position and there was no misconduct; or

- a comment on the ROE confirms the dismissal is due to the client being unsuitable, not passing training or being terminated within the probationary period; and

- there are no other contentious issues related to the dismissal that would prevent Level 1 from allowing the RFS. 

#### Note

Source topic: `en_EN/common_notes/note_c_3265.dita`

Note:

A client may forget to include an employer on the EI application when the period of employment was for a short time or the client may fail to provide additional information regarding the RFS on the EI application.

The dismissal can be allowed without fact-finding with the client if the following conditions are met:

- The employment was for 12 weeks or less.

- The employer or the ROE comments confirm that the client was dismissed due to unsuitability.

- There are no other contentious issues that would prevent a Level 1 officer from allowing the RFS.

If all of these conditions are not met, fact-find with the client. For more information, refer to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

     [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 

#### Callout

Source topic: `en_EN/common_notes/note_c_3266.dita`

- the client indicates being dismissed due to unsuitability or due to a shortage of work; and

- the employer, when contacted, confirms that the client was not suitable for the position and there was no misconduct; or

- a comment on the ROE confirms the dismissal is due to the client being unsuitable, not passing training or being terminated within the probationary period; and

- there are no other contentious issues related to the dismissal that would prevent the Level 1 officer from allowing the RFS. 

## Policy reference

Source topic: `en_EN/task/dismissal_ic/policy_reference.dita`

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- National Policy on Levels of Decision—Not Misconduct
         [National Policy on Levels of Decision—Not Misconduct](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
