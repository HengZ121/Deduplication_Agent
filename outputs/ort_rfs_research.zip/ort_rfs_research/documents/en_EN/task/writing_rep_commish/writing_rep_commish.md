# Writing representations of the Commission

Source map: `en_EN/task/writing_rep_commish/writing_rep_commish.ditamap`

## Summary

Source topic: `en_EN/task/writing_rep_commish/summary.dita`

Summary: When sending the reconsideration file to the Employment Insurance Board of Appeal (EI BOA) or Social Security Tribunal (SST), the officer also submits written arguments known as representations. The representations reflect the Commission’s position on the reconsidered and subsequently appealed decision and it must therefore be built on the evidence, the law and sound reasoning. 

## What you need to know

Source topic: `en_EN/task/writing_rep_commish/what_you_need_to_know.dita`

### Reviewing the facts and the appellant’s arguments

Source topic: `en_EN/task/writing_rep_commish/reviewing_the_facts_and_the_appellants_arguments.dita`

The Commission’s arguments must be supported by specific and well-documented facts. It is important to review all facts on file, including any new facts presented in the notice of appeal, and comment on the elements of proof. The officer reviews the information contained in the notice of appeal and compare it with the information in the reconsideration file. The notice of appeal can contain new facts that impact the appealed decision. The representations present the Commission’s position on any argument raised by the appellant.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4990.dita) 

**Appellant raises a Canadian Charter of Rights and Freedoms issue**

When an appellant raises a Canadian Charter of Rights and Freedoms issue, the actions to take depend on which group is hearing the appeal.

The SST is empowered to deal with issues of constitutional law. When a Canadian Charter of Rights and Freedoms issue is raised during the process of an SST appeal, the officer immediately advises Business Expertise to contact National Headquarters in order to refer the appeal docket to Legal Services, whose representatives attend the hearing. The officer does not address the issue in the representations unless National Headquarters indicates otherwise.

The EI BOA is not empowered to consider questions of constitutional law. However, following the EI BOA appeal, the appellant may appeal to the SST-Appeal Division, who has expanded the grounds for appeal to include determining if a question of constitutional law remains after a decision is rendered by the EI BOA. Due to this, the officer immediately advises Business Expertise in order to flag the issue to National Headquarters. The officer does not address the application of the Canadian Charter of Rights and Freedoms in the representations. 

### Writing the representations

Source topic: `en_EN/task/writing_rep_commish/writing_the_representations.dita`

The officer uses templates in CAAPS to create the representations. A new CAAPS Add-in option Change to BOA and Change to SST allows the template to be updated with the appropriate text to direct Commission representations to the group hearing the appeal.

The most common issues have a specific template. For issues that occur less frequently, there is a miscellaneous template that contains the basic outline of the information that must be included. In rare circumstances, officers may have to combine aspects found in different templates to properly address the situation (e.g. a client’s reason for separation [RFS] is originally adjudicated as voluntary leaving. However, after performing the reconsideration under EIA 112 , is it is determined the client was actually dismissed).
       [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 

### Preparing the representations

Source topic: `en_EN/task/writing_rep_commish/preparing_the_representations.dita`

When preparing the representations, the officer must consider the following important points:

- Be organized, thorough and objective.

- Write for the audience.

- Address the members of the group hearing the appeal (EI BOA or SST-General Division), and other readers in an impartial manner. Personal opinions or commentaries are not appropriate. Do not use rhetorical questions. 

### Completing the template using the guidelines

Source topic: `en_EN/task/writing_rep_commish/completing_the_template_using_the_guidelines.dita`

The officer must follow the following guidelines when completing the template in CAAPS:

**Issue under appeal**

- Include an opening statement that introduces the issue under appeal. If multiple issues are appealed, they must be introduced as they appear in the reconsideration file.
         [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4991.dita)

- In the opening statement, inform of a concession on an issue, a recommendation that the appealed decision be modified or that the appealed decision be allowed and replaced by a new decision.

- If the results of other decisions made at the same time as the one under appeal are also negative, add a paragraph to inform the group hearing the appeal.

- If text was redacted in the reconsideration file, explain why.

**Relevant facts**

- Summarize the relevant facts of the appealed issue, even if they are not favourable to the Commission’s position.

- Use bullets, if necessary.

- Be brief: include only facts that are essential to the decision.

- Paraphrase (do not copy and paste an entire statement or sections of reference material).

- Never refer to evidence that is not in the reconsideration file.

- The majority of the paragraphs should contain at least one reference to the reconsideration file.

**Commission’s decision**

- State the Commission’s decision after the reconsideration under EIA 112 was performed.

**Client’s appeal**

- Summarize the information the client provided in the notice of appeal, including any new evidence submitted.

**Commission’s position**

- State the major point of argument.

- Explain apparent contradictions in the facts or irregularities in processing.

- Cite the appropriate legislation and jurisprudence and relate it to the case at hand. The representations of the Commission must include, whenever possible, a specific reference to current jurisprudence (Federal Court, Federal Court of Appeal or Supreme Court of Canada decisions ) supporting the decision. Choose the highest court decisions possible to support the Commission’s position in the representations.

- Add jurisprudence only in cases where the included references are not sufficient to support the case. For example, if the dismissal template contains references to the legal test but does not address specific cases and if the client was dismissed for theft, the officer adds supporting jurisprudence.

- When adding jurisprudence, do not use Canadian Umpire Benefits (CUB) decisions not contained in the template or any EI BOA , SST-General Division or SST-Appeal Division decisions. Use only Federal Court, Federal Court of Appeal or Supreme Court of Canada decisions.

- Include a brief quotation from the cited jurisprudence and an outline of the appropriate legal principle, and link it to the facts of the case before the EI BOA or SST-General Division to show how it is relevant. This applies to the jurisprudence already included in the CAAPS template as well as any new jurisprudence added.

- When citing additional jurisprudence, create a hyperlink to the website where the full text of the judicial decision is available (i.e. the CanLII database, the Federal Court website or the Federal Court of Appeals [FCA] website ).
         [CanLII](https://www.canlii.org/) 
         [Federal Court website](https://decisions.fct-cf.gc.ca/fc-cf/en/d/s/index.do?col=54) 
         [Federal Court of Appeals [FCA] website](https://decisions.fca-caf.gc.ca/fca-caf/en/nav.do)

- Construct arguments based on the relationship between the facts and jurisprudence.

- If the appealed decision is regarding a penalty, a warning or a violation, it must be made clear that the Commission exercised its discretion judicially.

- If the appealed decision resulted in an overpayment (OP), and the client is requesting a write-off or disputing a decision to refuse to write off the OP, it must be made clear that only the Commission has the authority to write off an OP.

- Rebut the client’s arguments or any jurisprudence cited. If the client submits jurisprudence that does not apply to the particular circumstances of the case, explain why it does not apply.

- Explain any errors found in the notice of decision.

**Conclusion**

- Provide a closing bottom-line statement that includes a summary argument and a reminder of a concession on an issue or a recommendation that the appealed decision be modified, allowed or replaced by a new decision.

- If necessary, include a reminder regarding the Commission, EI BOA or SST’s jurisdiction and limitations. Refer to Determining if the request for reconsideration is within the Commission’s authority or is subject to an appeal under EIA 113 .
         [Determining if the request for reconsideration is within the Commission’s authority or is subject to an appeal under EIA 113](/en/procedure/task/detercom.shtml) 

### Using the Auto Text feature in CAAPS

Source topic: `en_EN/task/writing_rep_commish/using_the_auto_text_feature_in_caaps.dita`

Sometimes, the officer can insert prewritten text into the representations by using the Auto Text feature in CAAPS. If the appealed decision or the reconsideration file involves any of the following, the officer must ensure that the appropriate prewritten text is selected:

- BPNE - Averaging hours worked in the qualifying period

- BPNE - New entrant or re-entrant

- BPNE - Did not meet VER

- insurability

- voluntary leaving without just cause vs. dismissal for misconduct

- RFS disqualification imposed for leaving employment other than last or on a claim other than an initial claim (EIA 30(7))

- OP resulting from a decision

- determination of earnings under EIR 35

- allocation of earnings under EIR 36

- RFS still to be adjudicated on other employment

- value of violation includes potential OP

- refusal to write-off an OP (EIR 56)

- making a claim for benefits electronically (EIA 91)

- ROE corrections

- Commission’s right to reconsider under EIA 52

- how clients are informed of their rights and responsibilities

- clerical error in notice of decision

For more information, refer to Auto Texts — CAAPS in Common Document Share. 

### Writing representations for particular cases

Source topic: `en_EN/task/writing_rep_commish/writing_representations_for_particular_cases.dita`

In some cases, the Commission’s position is not a straightforward argument for maintaining the appealed decision. To address the circumstance, special arguments must be made in the following cases:

- Incorrect decision — Complete concession: The officer determines that the appealed decision is incorrect due to new facts or a Commission error and must be removed.

- Multiple issues — Some decisions incorrect: The officer determines that one or multiple decisions must be removed, either due to new facts or a Commission error, but the other decisions must remain the same (e.g. a 3 - Not available disentitlement [D3] and a 11 - Voluntary leaving - just cause not proven disentitlement [D11] are imposed, the D3 is incorrect but the D11 is maintained).

- Incorrect decision — New decision required: The officer determines that the appealed decision is incorrect and must be replaced by a new decision (e.g. the D3 is incorrect, because it should be a 1 - Not unemployed disentitlement [D1]). The SST-General Division can make the decision the Commission should have made.

- Decision requires modification: The officer determines that the appealed decision must be modified (e.g. disentitlement terminated or penalty reduced).

- Request for reconsideration was not processed: The representations must explain that due to the lack of a reconsideration decision under EIA 112 , no reconsideration file will be submitted. The officer includes references to the relevant legislation that clarify why the initial request did not meet the requirements of EIA 112 .
         [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
         [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4992.dita) 

### Consulting for a decision in doubt

Source topic: `en_EN/task/writing_rep_commish/consulting_for_a_decision_in_doubt.dita`

While reviewing the case, the officer may be uncertain how to proceed. For more information, the officer consults with a business expertise advisor. 

### Note

Source topic: `en_EN/common_notes/note_c_4990.dita`

Note:

No fact-finding can be done once an appeal is filed. 

### Example

Source topic: `en_EN/common_notes/note_c_4991.dita`

Example:

The issues under appeal are:

- The denial of an antedate request under EIA 10(4);

- A disqualification imposed under EIA 29 and 30 because the client voluntarily left the employment without just cause. 

### Note

Source topic: `en_EN/common_notes/note_c_4992.dita`

Note:

Once an appeal is filed, the Commission cannot interfere in the appeal process. All cases must proceed to the group hearing the appeal (EI BOA or SST-General Division) on all issues, with the appropriate representations. 

## Regional considerations

Source topic: `en_EN/task/writing_rep_commish/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/writing_rep_commish/what_you_need_to_look_for.dita`

### In CAAPS:

Source topic: `en_EN/task/writing_rep_commish/in_caaps.dita`

- Which template is required? 

### In ADMS:

Source topic: `en_EN/task/writing_rep_commish/in_adms.dita`

- What is the issue under appeal? 

## Step by step

Source topic: `en_EN/task/writing_rep_commish/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/writing_rep_commish/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/writing_rep_commish/reviewing_the_file_level_2.dita`

- Review the information in the reconsideration file.

- Determine your position regarding the issues under appeal.

- In CAAPS, on the EI Representations tab, select the applicable template based on the issues and select Open Document .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4993.dita)

- Determine if the appeal involves only an employer:

- If yes, go to step 5.

- If no, go to step 6.

- On the CAAPS Search screen, do the following:

- Business Number: Enter the employer’s business number.

- Select Search .

- Select the related file.

- Select OK .

- On the CAAPS Search screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Select Search .

- Select the related file.

- Select OK .

- On the CAAPS template, select the appropriate add-in:

- For an appeal to the EI BOA, select Change to BOA .

- For an appeal to the SST, select Change to SST .

- Considering your position, do one of the following:

- If all issues under appeal should be conceded, go to Full concession .
               [Full concession](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/writing_rep_commish#concession)

- If some of the issues under appeal should be conceded, go to Partial concession — Multiple issues appealed .
               [Partial concession — Multiple issues appealed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/writing_rep_commish#multiple)

- If the decision is incorrect and should be replaced with a new decision, go to Incorrect decision — New decision required .
               [Incorrect decision — New decision required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/writing_rep_commish#incorrect)

- If a modification is needed, go to Modified decision .
               [Modified decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/writing_rep_commish#modification)

- If the decision should be maintained, go to step 9.

- Complete the Issue under appeal section of the template.

- Determine if other negative decisions have been made at the same time as the one under appeal:

- If yes, go to step 11.

- If no, go to step 12.

- Determine if the employer is an interested party to the issue under appeal:

- If yes, type “The Commission wishes to bring to the attention of the [Employment Insurance Board of Appeal / Social Security Tribunal] that when the decision under appeal was rendered, the Commission also issued a decision under EIA 112 for another issue which is not part of the current appeal and for which the employer is not an interested party.”

- If no, type “The Commission wishes to bring to the attention of the [Employment Insurance Board of Appeal / Social Security Tribunal] that when the decision under appeal was rendered, the Commission also issued a decision under EIA 112 for the following issue, which is not part of the current appeal: [issue(s) for which a request for reconsideration decision was made and that the appellant might also wish to appeal].”

- Determine if information was redacted in the reconsideration file:

- If yes, go to step 13.

- If no, go to step 14.

- At the end of the first paragraph in the Issue under appeal section, explain why the information was redacted by selecting the appropriate option:

- Type “Due to safety and security concerns expressed by the client, the Commission has removed the client’s address and telephone number from all documents in this file. The [Employment Insurance Board of Appeal /Social Security Tribunal] is requested to omit the client’s address from their decision for the same reasons or to not refer to it implicitly.”

- Type “Due to privacy concerns, the Commission has removed [type of information that was redacted (e.g. name of another employer)] from all documents in this file.”

- Determine if there are any auto texts that apply that must be added:

- If no, go to step 15.

- If yes, add the auto texts where appropriate and go to step 15.

- Complete the rest of the template.

- Sign the representations.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4994.dita)

- In the Common Document Share, save the representations using the following naming conventions:

- For an appeal to the EI BOA: A3-CEICRepresentations-[ADMS record number for the appeal to the EI BOA].pdf.

- For an appeal to the SST: GD4-CEICRepresentations-[ADMS record number for the appeal to the SST].pdf.

- Return to the previous task. 

#### Full concession

Source topic: `en_EN/task/writing_rep_commish/full_concession_level_2.dita`

- Complete the Concession_SST/BOA template and include an explanation for the concession (new facts or Commission error).

- Determine if information was redacted in the reconsideration file:

- If yes, go to step 11.

- If no, go to step 12.

- At the end of the first paragraph in the Issue under appeal section, explain why the information was redacted by selecting the appropriate option:

- Type “Due to safety and security concerns expressed by the client, the Commission has removed the client’s address and telephone number from all documents in this file. The [Employment Insurance Board of Appeal / Social Security Tribunal] is requested to omit the client’s address from the decision for the same reasons or to not refer to it implicitly.”

- Type “Due to privacy concerns, the Commission has removed [type of information that was redacted (e.g. name of another employer)] from all documents in this file.”

- Sign the representations.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4994.dita)

- In the Common Document Share, save the representations using the following naming conventions:

- For an appeal to the EI BOA: A3-CEICRepresentations-[ADMS record number for the appeal to the BOA].pdf.

- For an appeal to the SST: GD4-CEICRepresentations-[ADMS record number for the appeal to the SST].pdf.

- Return to the previous task. 

#### Partial concession — multiple issues appealed

Source topic: `en_EN/task/writing_rep_commish/partial_concession__multiple_issues_appealed_level_2.dita`

- Begin to complete the template. When introducing the issue to be conceded in the Issue under appeal section, also state that it is being conceded.

- Determine if information was redacted in the reconsideration file:

- If yes, go to step 11.

- If no, go to step 12.

- At the end of the first paragraph in the Issue under appeal section, explain why the information was redacted by selecting the appropriate option:

- Type “Due to safety and security concerns expressed by the client, the Commission has removed the client’s address and telephone number from all documents in this file. The [Employment Insurance Board of Appeal / Social Security Tribunal] is requested to omit the client’s address from the decision for the same reasons or to not refer to it implicitly.”

- Type “Due to privacy concerns, the Commission has removed [type of information that was redacted (e.g. name of another employer)] from all documents in this file.”

- In CAAPS, on the EI Representations tab, do the following:

- Select the Concession_SST/BOA template.

- Select Open Document .

- Complete the CAAPS Search screen as was done for the template of the maintained issue.

- On the CAAPS template, select the appropriate add-in:

- For an appeal to the EI BOA, select Change to BOA .

- For an appeal to the SST, select Change to SST .

- Complete the Concession_SST/BOA template and include an explanation for the concession (new facts or Commission error).

- Copy and paste the text from the Concession_SST/BOA template into The Commission’s position section of the template for the maintained issue.

- Determine if there are any auto texts that apply and must be added:

- If no, go to step 18.

- If yes, add them where appropriate and go to step 18.

- Complete the rest of the template.

- In the Conclusion section, include a brief reminder of the concession on the relevant issue.

- Sign the representations.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4994.dita)

- In the Common Document Share, save the representations using the following naming conventions:

- For a BOA appeal: A3-CEICRepresentations-[ADMS record number for the appeal to the EI BOA].pdf.

- For an SST appeal:  GD4-CEICRepresentations-[ADMS record number for the appeal to the SST].pdf.

- Return to previous task. 

#### Incorrect decision — New decision required

Source topic: `en_EN/task/writing_rep_commish/incorrect_decision__new_decision_required_level_2.dita`

- Begin to complete the template. Choose the template for the new decision required by the group hearing the appeal (EI BOA or SST-General Division) (e.g. the original decision D3 should be a D1, so use the appropriate D01 template). When introducing the issue on which an incorrect decision was rendered in the Issue under appeal section, also state that it is being conceded but needs to be replaced by a new decision.

- Determine if information was redacted in the reconsideration file:

- If yes, go to step 11.

- If no, go to step 12.

- At the end of the first paragraph in the Issue under appeal section, explain why the information was redacted by selecting the appropriate option:

- Type “Due to safety and security concerns expressed by the client, the Commission has removed the client’s address and telephone number from all documents in this file. The [Employment Insurance Board of Appeal / Social Security Tribunal] is requested to omit the client’s address from their decision for the same reasons or to not refer to it implicitly.”

- Type “Due to privacy concerns, the Commission has removed [type of information that was redacted (e.g. name of another employer)] from all documents in this file.”

- In CAAPS, on the EI Representations tab, do the following:

- Select the Concession_SST/BOA template.

- Select Open Document .

- Complete the CAAPS Search screen as was done for the template being used.

- On the CAAPS template select the appropriate add-in:

- For an appeal to the EI BOA, select Change to BOA .

- For an appeal to the SST, select Change to SST .

- Complete the Concession_SST/BOA template and include an explanation for the incorrect decision (new facts or Commission error).

- Copy and paste the text from the Concession_SST/BOA template into The Commission’s position section of the template for the correct issue. Also include the following:

- a recommendation that the appeal be allowed on the incorrect decision.

- a request that the group hearing the appeal (EI BOA or SST-General Division) make the decision that should have been made.

- Determine if there are any auto texts that apply that must be added:

- If no, go to step 18.

- If yes, add them where necessary and go to step 18.

- Complete the rest of the template.

- In the Conclusion section, include a brief reminder of the recommendation of concession on the relevant issue and a request that the group hearing the appeal (EI BOA or SST-General Division) make the decision that should have been made.

- Sign the representations.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4994.dita)

- In the Common Document Share, save the representations using the following naming conventions:

- For an appeal to the BOA: A3-CEICRepresentations-[ADMS record number for the appeal to the BOA].pdf.

- For an appeal to the SST: GD4-CEICRepresentations-[ADMS record number for the appeal to the SST].pdf.

- Return to the previous task. 

#### Modified decision

Source topic: `en_EN/task/writing_rep_commish/modified_decision_level_2.dita`

- Begin to complete the template. When introducing the issue on which an incorrect decision was made in the Issue under appeal section, also state that a modification is recommended.

- Determine if information was redacted in the reconsideration file:

- If yes, go to step 11.

- If no, go to step 12.

- At the end of the first paragraph in the Issue under appeal section, explain why the information was redacted by selecting the appropriate option:

- Type “Due to safety and security concerns expressed by the client, the Commission has removed the client’s address and telephone number from all documents in this file. The [Employment Insurance Board of Appeal / Social Security Tribunal] is requested to omit the client’s address from their decision for the same reasons or to not refer to it implicitly.”

- Type “Due to privacy concerns, the Commission has removed [type of information that was redacted (e.g. name of another employer)] from all documents in this file.”

- In The Commission’s position section, include the following:

- the reason for the necessary modification (new facts or Commission error);

- the appropriate recommendation;

- a request that the appeal be dismissed with modification.

- Sign the representations.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4995.dita)

- In the Common Document Share, save the representations using the following naming conventions:

- For an appeal to the BOA: A3-CEICRepresentations-[ADMS record number for the appeal to the BOA].pdf.

- For an appeal to the SST: GD4-CEICRepresentations-[ADMS record number for the appeal to the SST].pdf.

- Return to the previous task. 

#### Note

Source topic: `en_EN/common_notes/note_c_4993.dita`

Note:

If all decisions being appealed will be conceded, select the Concession_SST/BOA template. If only some of the decisions being appealed will be conceded, select the template of the issue being maintained. 

#### Note

Source topic: `en_EN/common_notes/note_c_4994.dita`

Note:

In this case, an electronic signature with a cursive font is acceptable and is considered to be equal to a handwritten signature. For more information, refer to the Signing your representations and/or Attestations section of Adobe Acrobat — User guide. 

#### Note

Source topic: `en_EN/common_notes/note_c_4995.dita`

Note:

In this case, an electronic signature with a cursive font is acceptable and is considered to be equal to a handwritten signature. For more information, refer to Signing your representations and/or Attestations section of Adobe Acrobat — User guide. 

## Policy reference

Source topic: `en_EN/task/writing_rep_commish/policy_reference.dita`

- Department of Employment and Social Development Act 43.13(1)
         [Department of Employment and Social Development Act 43.13(1)](https://laws-lois.justice.gc.ca/eng/acts/H-5.7/FullText.html#h-256296)

- Department of Employment and Social Development Act 54(1)
         [Department of Employment and Social Development Act 54(1)](http://laws-lois.justice.gc.ca/eng/acts/H-5.7/FullText.html)

- EIA 38
         [EIA 38](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-38.html)

- Federal Court of Appeal A-694-94, Purcell
         [Federal Court of Appeal A-694-94, Purcell](http://www.ei.gc.ca/eng/policy/appeals/Federal-Court/Federal_Court_of_Appeals/A069494.shtml) 
