# Adjudicating voluntary leaving (Level 1): Referred training or employment activity — Continuing claim

Source map: `en_EN/task/voluntary_leaving_course_l1/voluntary_leaving_course_l1.ditamap`

## Summary

Source topic: `en_EN/task/voluntary_leaving_course_l1/summary.dita`

Summary: When clients voluntarily leave employment to attend referred training or an employment activity, their entitlement to regular benefits on a continuing claim may be affected. Adjudication is required to determine if there is just cause for leaving the employment. 

## What you need to know

Source topic: `en_EN/task/voluntary_leaving_course_l1/what_you_need_to_know.dita`

### Adjudicating voluntary leaving to attend referred training or an employment activity

Source topic: `en_EN/task/voluntary_leaving_course_l1/adjudicating_voluntary_leaving_to_atten_8b0bb5f9.dita`

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave the employment. If it is determined that the client left the employment without just cause, a disqualification is imposed on the claim for regular benefits, unless there are enough insurable hours since the voluntary leaving to establish a new claim. In this case, the ROE with the voluntary leaving is excluded from the calculation of the claim.

A designated authority may authorize clients to leave their employment in order to attend referred training or an employment activity under EIA 25 . In that situation, clients have just cause for leaving their employment, provided they do so in the 2 weeks before the start of the program.
       [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

To confirm that the client has been authorized to leave the employment, the designated authority gives the client an official document sometimes referred to as an authorization to quit or a counsel to leave employment.

An ROE is not required to adjudicate voluntary leaving.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4923.dita) 

### Authorization to quit employment

Source topic: `en_EN/task/voluntary_leaving_course_l1/authorization_to_quit_employment.dita`

Each region has specific procedures in place for submitting the document authorizing the client to quit their employment. In some regions, the client is responsible for submitting a copy to Service Canada. In other regions, the designated authority submits it directly to Service Canada.

When the information is not on file, the officer fact-finds to complete the WI related to the voluntary leaving. When clients state that they have been authorized to quit, but a copy of the authorization is not on file, the officer advises the clients to ask the designated authority to provide it. If the authorization is not submitted, the officer adjudicates the voluntary leaving based on the information on file.

Agreements with the provinces, territories and indigenous groups exist for implementing programs that are similar to Service Canada’s employment programs. These include:

- Labour Market Development Agreements for training-related employment measures managed by the provinces and territories.

- Indigenous Skills and Employment Training Program for training-related employment measures managed by various indigenous groups for indigenous individuals.

Sometimes, an unemployed client is referred to training that starts at a future date and the client becomes employed before the training begins. If the client leaves this employment to attend the training, the issue is referred to Level 2 since the voluntary leaving has not been recommended or approved by the designated authority. 

### Automated adjudication

Source topic: `en_EN/task/voluntary_leaving_course_l1/automated_adjudication.dita`

ACP does not adjudicate voluntary leaving on a continuing claim. 

### Levels of decision

Source topic: `en_EN/task/voluntary_leaving_course_l1/levels_of_decision.dita`

The Level 1 officer may adjudicate and allow benefits when the client’s reason for voluntarily leaving employment is to attend referred training or an employment activity and all of the following conditions are met:

- the client was referred by an authority designated by the Commission prior to the voluntary leave;

- the voluntary leave was approved by the designated authority;

- the referred training or employment activity started within 2 weeks of the date of the voluntary leave;

- the BPC or renewal week is equal to or after the week of voluntary leaving.

When the Level 1 officer cannot adjudicate the issue, the facts are documented and the voluntary leaving is referred to Level 2 for adjudication. 

### Employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_course_l1/employment_is_not_insurable.dita`

Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is not required if the employment is not insurable because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. 

### Actions required following adjudication

Source topic: `en_EN/task/voluntary_leaving_course_l1/actions_required_following_adjudication.dita`

When the voluntary leaving is adjudicated and the ROE is received, the Special condition field of the ROE must be updated to show either Voluntary leaving - Just cause or Voluntary leaving - No just cause . 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/voluntary_leaving_course_l1/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the reason for separation (RFS) was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Previously deferred decision

Source topic: `en_EN/task/voluntary_leaving_course_l1/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and an 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D11 that is on file and update the Special Condition field on the ROE in RCM. 

### Note

Source topic: `en_EN/common_notes/note_c_4923.dita`

Note:

In exceptional cases, a Level 2 officer can consider a longer period of up to 4 weeks as just cause if the client provides a reasonable and credible explanation for leaving employment early (e.g. relocating to attend school). 

## Regional considerations

Source topic: `en_EN/task/voluntary_leaving_course_l1/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/voluntary_leaving_course_l1/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/voluntary_leaving_course_l1/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Voluntary Leave section of this or a previous EI application?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the voluntary leaving on this or a previous EI application? 

### In FTS:

Source topic: `en_EN/task/voluntary_leaving_course_l1/in_fts.dita`

- Is there a 75 - Verification of reason for termination of Employment manual action (MA75) imposed to stop payments?

- Is there a registration number? 

### In Imaging:

Source topic: `en_EN/task/voluntary_leaving_course_l1/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving? 

### In RCM:

Source topic: `en_EN/task/voluntary_leaving_course_l1/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving? 

## Step by step

Source topic: `en_EN/task/voluntary_leaving_course_l1/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/voluntary_leaving_course_l1/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/voluntary_leaving_course_l1/reviewing_the_file_level_1.dita`

- Determine if the facts on file clearly indicate that the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 2.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable.
               [Employment is not insurable.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_course_l1#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if there is enough information to adjudicate the voluntary leaving, or if additional fact-finding is required.

[Required information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4977.dita) 

- If all the required information is not on file, go to step 5.

- If all the required information is on file, go to step 11.

- If the information on file shows that the client was not referred, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_course_l1#reassigntol2) 

#### Fact-finding

Source topic: `en_EN/task/voluntary_leaving_course_l1/fact-finding_level_1.dita`

- Fact-find with the client to obtain the required information.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4929.dita)

- Determine if the client was reached during fact-finding, or if the client responded to the N-10-00-00 ACS letter:

- If the client was reached, go to step 7.

- If the client was not reached or did not reply to the N-10-00-00 letter, Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_course_l1#reassigntol2)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Voluntary leaving — employer’s name — last day worked — client.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client was reminded during fact-finding to submit the missing document that provides the authorization to quit employment.

- If yes, go to step 9.

- If no, go to step 11.

- In NWS, move the WI related to the missing document that provides the authorization to quit employment to Pending as follows:

- Pending reason: Select Fact finding client .

- Bring forward date: Enter the date of the most recent contact + 10 business days.

- When the WI moves to the current workload, determine if the document that provides the authorization to quit employment is on file:

- If yes, go to step 11.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_course_l1#reassigntol2)

- Determine if the information on file shows that a designated authority authorized the client to quit the employment to participate in an employment activity:

- If yes, go to step 12.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_course_l1#reassigntol2) 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/voluntary_leaving_course_l1/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if all the following conditions are met to adjudicate the issue at Level 1:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4978.dita) 

- If all of the conditions are met, the voluntary leaving is allowed at Level 1 ( National Policy on Levels of Decision ). Go to Reason for separation (RFS) allowed .
               [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_course_l1#rfs_allowed)

- If any of the conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_course_l1#reassigntol2) 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/voluntary_leaving_course_l1/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, create a ROD and complete the following fields:

- Comments: Type “Voluntary leaving — employer’s name — last day worked — just cause shown.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In RCM, verify if the ROE related to the voluntary leaving has been received:

- If yes, go to step 3.

- If no, go to step 4.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select E - Quit / Return to School .

- Special condition: Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the voluntary leaving from block 18 to the Additional information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3230.dita)

- In FTS, determine if there is a D11 on file because this RFS adjudication was previously deferred or the D11 is being rescinded as a result of a request for reconsideration:

- If yes, go to step 5.

- If no, go to step 7.

- Determine if the D11 is solely due to this previously deferred RFS issue or reconsidered decision and if other issues must be adjudicated:

- If there are no other issues that need to be adjudicated, go to step 6.

- If other issues need to be adjudicated, refer to the appropriate task for guidance. Then, go to step 6.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F – Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes

- Select Update .

- Determine if an MA75 is imposed and if there is a registration number for the voluntary leaving:

- If an MA75 is imposed but there is no registration number, go to step 8.

- If an MA75 is imposed and there is a registration number, go to step 9.

- If an MA75 is not imposed but there is a revised registration number, go to step 10.

- If none of the above applies, go to step 11.

- Select the Registration Number (M025, M030, M035) transaction and obtain a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to remove the MA75 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 75 -Verification of reason for termination of Employment .

- Rescind: Check the box.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 11.

- Select the Renewal/Revised (M106) transaction to clear the outstanding registration number as follows:

- Claim allowed: Select NCA - no change on the claim .

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI related to the voluntary leaving. 

#### Employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_course_l1/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Complete the WI related to the voluntary leaving. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/voluntary_leaving_course_l1/reassigning_the_issue_to_level_2_level_1.dita`

- In FTS, on the Summary tab, determine if an MA75 has been imposed:

- If yes, go to step 2.

- If no and the client is requesting special benefits, go to step 2.

- If no and the client is requesting regular benefits, select the Renewal/Revised (M106) transaction and impose the MA75 as follows:

- Registration number: Leave the field blank. If a number is displayed, remove it.

- Manual Action: Select 75 - Verification of reason for termination of Employment .

- Select Update .

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Client quit [his/her] job and [provide a brief reason for the referral, e.g. not a referred training] — unable to complete at Level 1.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Required information

Source topic: `en_EN/common_notes/note_c_4977.dita`

Required information:

- start and end dates of the referred training or employment activity

- client’s statement about the reason for leaving the employment to attend training

- name of the referred training or employment activity

- name of the institution or school and the location

- name and contact information of the training counselor

- document completed by a designated authority that provides authorization to quit employment 

#### Note

Source topic: `en_EN/common_notes/note_c_4929.dita`

Note:

If clients state that they were referred by a designated authority but the document that provides the authorization to quit employment is not on file, advise them to submit it as soon as possible. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4978.dita`

**Voluntary leaving to attend referred training or an employment activity  —Conditions to adjudicate the issue at Level 1 (all conditions must be met)**

- The client was referred to the training or employment activity by an authority designated by the Commission before the voluntary leave;

- The voluntary leave was approved by the designated authority.

- The referred training or employment activity started in the 2 weeks following the date of the voluntary leave.

- The BPC or renewal week is equal to or after the week of voluntary leaving. 

#### Note

Source topic: `en_EN/common_notes/note_c_3230.dita`

Note:

Selecting Validate may cause the ROE to be flagged with an error. If this occurs, no further action is required. If the client submits another claim, the ROE is corrected at that time. 

## Policy reference

Source topic: `en_EN/task/voluntary_leaving_course_l1/policy_reference.dita`

- Digest 6–Voluntarily leaving employment
         [Digest 6–Voluntarily leaving employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/table-of-contents.html)

- BE 2010-12–Voluntary Leaving to Attend Approved Training
         [BE 2010-12–Voluntary Leaving to Attend Approved Training](/en/policy/bememo/be2010-12.shtml)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html) 
