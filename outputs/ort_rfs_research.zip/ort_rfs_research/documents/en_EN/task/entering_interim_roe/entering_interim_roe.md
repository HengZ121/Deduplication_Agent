# Entering an interim ROE

Source map: `en_EN/task/entering_interim_roe/entering_interim_roe.ditamap`

## Summary

Source topic: `en_EN/task/entering_interim_roe/summary.dita`

Summary: When an interim ROE is required and the actual ROE information is available or the officer has estimated the ROE information, the interim ROE is entered in RCM. 

## What you need to know

Source topic: `en_EN/task/entering_interim_roe/what_you_need_to_know.dita`

### Entering interim ROE data

Source topic: `en_EN/task/entering_interim_roe/entering_interim_roe_data.dita`

Interim ROEs are entered in RCM. Before data entry, if estimates are required to determine the hours and earnings, refer to Estimating interim ROE information .
       [Estimating interim ROE information](/en/procedure/task/estimating_interim_roe.shtml)

**Required fields for a regular ROE**

The following fields are required for a regular ROE:

- block 4: Employer’s name

- block 6: Pay period type

- block 8: Social Insurance Number

- block 10: First day worked

- block 11: Last day for which paid

- block 12: Final pay period ending date

- block 15A: Total insurable hours

- block 15B: Total insurable earnings

- block 16: Reason for separation

- any other fields for which you have the required information

**Required fields for a fishing ROE**

The following fields are required for a fishing ROE:

- block 4: Employer’s name

- block 9: Social Insurance Number

- block 6A: Trip(s) start date (fresh catch only)

- block 6B: Trip(s) end date (fresh) or date of purchase (cured)

- block 6C: Share of insurable earnings

- block 11: Reason for separation

**Interim ROE serial numbers**

Once the interim ROE information is successfully submitted in RCM, a serial number is automatically assigned (beginning with “X” for regular interim ROEs or “X9” for fishing interim ROEs). 

### Reviewing the impact on a benefit period (BP)

Source topic: `en_EN/task/entering_interim_roe/reviewing_the_impact_on_a_benefit_period_bp.dita`

If the interim ROE is created and impacts a BP, the officer registers a recalculation. 

### BPNE fishing claim (from w/c 2258 to w/c 2321)

Source topic: `en_EN/task/entering_interim_roe/bpne_fishing_claim_from_wc_2258_to_wc_2321.dita`

A temporary measure is implemented from September 27 2020 (w/c 2258) to December 18, 2021 (w/c 2321) for fishing claims with the following BPCs:

- a summer BPNE fishing claim with a BPC from September 27, 2020 (w/c 2258) to June 13, 2021 (w/c 2295);

- a summer BPNE fishing claim with a BPC from October 1, 2021 (w/c 2310) to December 18, 2021 (w/c 2321);

- a winter BPNE fishing claim with a BPC from March 28, 2021 (w/c 2284) to December 18, 2021 (w/c 2321).

A self-employed fisher can use either this year’s fishing earnings or fishing earnings from the 2 previous fishing seasons with a matching fishing CT (i.e. summer to summer and winter to winter), whichever gives the best benefit rate and establishes the EI claim.

When a claim is BPNE, the officer reviews the earnings from an established claim with the same CT in the previous 2 fishing seasons. The previous claim must have a BPC during one of the following periods:

```text
| Summer fishing (CT 6) | Winter fishing (CT 7) |

| September 29, 2019 to June 20, 2020 or September 30, 2018 to June 15, 2019 | March 29, 2020 to December 19, 2020 or March 31, 2019 to December 21, 2019 |
```

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3356.dita) 

An interim ROE is required to use the earnings from a previous fishing claim. To create the interim ROE, the officer reviews the 2 previous fishing seasons with a matching CT to determine which one has the highest earnings. The earnings in the qualifying period (QP) of the current claim need to be subtracted from the highest earnings. The result will be the insurable earnings on the interim ROE. This ensures that when the claim is calculated, the total insurable earnings used to establish the claim are equal to the earnings of the previous fishing claim used. 

### Note

Source topic: `en_EN/common_notes/note_c_3356.dita`

Note:

A fisher can benefit from the measure using a previous season’s earnings only once for a summer claim and once for a winter claim. A client who has an established BPC in the periods mentioned above, even if it’s only the earnings from their most recent qualifying period that were used is considered as having already benefited from this measure. 

## Regional considerations

Source topic: `en_EN/task/entering_interim_roe/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/entering_interim_roe/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/entering_interim_roe/in_fts.dita`

Is there an outstanding registration number for the calculation or recalculation of a claim? 

## Step by step

Source topic: `en_EN/task/entering_interim_roe/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/entering_interim_roe/level_1.dita`

#### Interim ROE — Data entry

Source topic: `en_EN/task/entering_interim_roe/interim_roe__data_entry_level_1.dita`

- Determine if an interim ROE is required for a BPNE fishing claim with a BPC from w/c 2258 to w/c 2321:

- If no, go to step 2.

- If yes, go to Interim ROE — BPNE fishing claim (from w/c 2258 to w/c 2321) .
               [Interim ROE — BPNE fishing claim (from w/c 2258 to w/c 2321)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/entering_interim_roe#level1_item_3)

- In RCM, from the Input screen, complete the fields as follows:

- Social Insurance No.: This information is prefilled when RCM is accessed from NWS or SSO. If the information is not prefilled, enter the client’s SIN.

- Interim ROE Type: Select the appropriate option as follows:

- If you are entering a regular ROE, select Regular Interim .

- If you are entering a fishing ROE, select Fishing Interim .

- Serial No: Leave blank.

- Serial Number of ROE Amended or Replaced: Leave blank.

- Select Submit .

- Determine if an error message is displayed:

- If error message is displayed, resubmit with the correct SIN.

- If an error message is not displayed, do one of the following:

- If you have selected Regular Interim , go to step 4.

- If you have selected Fishing Interim , go to step 5.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3357.dita)

- From the Input Regular ROE screen, enter the blocks of the ROE as follows:

- block 4: Employer’s name: Type the employer’s name.

- block 5: CRA Business no.: If available, type the business number.

- block 6: Pay Period Type: Select the pay period type used to calculate blocks 15A and 15B .

- block 10: First day worked: Type the first day worked.

- block 11: Last day for which paid: Type the last day for which paid.

- block 12: Final pay period ending date: Type the final pay period ending date used to calculate blocks 15A and 15B .

- block 15A: Total insurable hours: Type the number of insurable hours. Round up any fraction of an hour (e.g. if the ROE shows 585.25 hours, round up to 586).

- block 15B: Total insurable earnings: Type the amount of insurable earnings, including dollars and cents.

- block 16: Reason for separation: Select the reason for separation (RFS).

- Additional Information: Type “Interim ROE created” and the reason it was created (e.g. “CRA ruling received and unable to contact employer” or “instructed in Correct an ROE procedure to create an interim ROE”). If the interim ROE was estimated, also indicate how the figures were obtained.

- For all other blocks, enter the information if available.

- Select Submit .

- Go to step 6.

- From the Input Fishing ROE screen, enter the blocks of the ROE as follows:

- block 4: Employer’s name: Type the employer’s name.

- block 7: CRA Business no.: If available, type the business number.

- block 6A: Trip(s) Start Date (fresh catch only): If this is a fresh catch, type the trip start date.

- block 6B: Trip(s) End Date (fresh) or date of purchase (cured): Type the trip end date or date of purchase.

- block 6C: Share of Insurable Earnings: Type the trip share amount of insurable earnings, including dollars and cents.

- block 11: Reason for Separation: Select the RFS.

- Additional Information: Type “Interim ROE created” and the reason it was created (e.g. “CRA ruling received and unable to contact employer” or “instructed in Correct an ROE procedure to create an interim ROE”). If the interim was estimated, also indicate how the figures were obtained.

- For all other blocks, enter the information if available.

- Select Submit .

- Determine if an error message is displayed:

- If an error message is not displayed, go to step 7.

- If an error message is displayed, correct the errors before selecting Submit (refer to Correct an ROE if required). Go to step 7.
               [Correct an ROE](/en/procedure/activity/correct_roe.shtml) 

#### Reviewing the impact on a benefit period (BP)

Source topic: `en_EN/task/entering_interim_roe/reviewing_the_impact_on_a_benefit_period_bp_level_1.dita`

- Determine if the interim ROE is for a period of employment that occurs during the QP of a tentative or established BP:

- If yes, go to step 8.

- If no, go to step 13.

- In FTS, determine if there is an outstanding registration number for the calculation or recalculation of the claim:

- If no, go to step 9.

- If yes, go to step 13.

- In SSO, starting from the main screen and using the recipient’s SIN, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 11.

- If no, go to step 12.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank, enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: This field is prefilled.

- Select Generate registration .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1570.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1571.dita)

- Determine if your WI is an Action Item (AI) WI:

- If it is an AI WI, complete the WI.

- If it is a Claim Assessment (CA) WI, Specialized Application (SA) WI or Claim Review (CR) Recalculation WI, return to Reviewing information for a missing ROE .
               [Reviewing information for a missing ROE](/en/procedure/task/calc_determining/missing_roe.shtml)

- If it is any other WI, return to the originating task. 

#### Interim ROE — BPNE fishing claim (from w/c 2258 to w/c 2321)

Source topic: `en_EN/task/entering_interim_roe/interim_roe__bpne_fishing_claim_from_wc_52bec470_level_1.dita`

- In FTS, determine if the BPNE claim has a BPC between September 27, 2020 (w/c 2258) and June 13, 2021 (w/c 2295) for a summer fishing claim, or March 28, 2021 (w/c 2284) and December 18, 2021 (w/c 2321) for a winter fishing claim:

- If yes, go to step 2.

- If no, the claim remains BPNE. Go to step 14.

- Determine if a BPC for the same fishing CT has already been established during the temporary measure period:

- If a CT 6 was established between September 27, 2020 (w/c 2258) and June 13, 2021 (w/c 2295) or a CT 7 was established between March 28, 2021 (w/c 2284) and December 18, 2021 (w/c 2321) the client is not entitled to establish another claim for the same fishing CT based on the temporary measure and the claim remains BPNE. Go to step 14.

- If there is no previous BPC for the same fishing CT, go to step 3.

- On the Dormant tab, determine if there is an established claim with the same CT requested by the client in the previous 2 fishing seasons:

- If yes, go to step 4.

- If no, the claim remains BPNE. Go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3358.dita)

- On the Rate/Duration tab, obtain the highest insured earnings with the same CT requested by the client in the previous 2 fishing seasons.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3359.dita)

- Calculate the earnings for the interim ROE by subtracting any earnings in the QP for the current claim from the highest insured earnings obtained on the previous matching claim. The total is the insured earnings amount to use on the interim ROE.

[Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3360.dita)

- In NWS, create an SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “Interim ROE information.”

- Details: Document how the earnings were obtained to create the interim ROE as follows:

- Interim record of employment to allow the client to benefit from the temporary fishing measure created based on the following information:

- Benefit period commencement of the claim with the highest earnings = [BPC]

- Claim type of the claim with the highest earnings = [CT]

- Highest earnings $[amount] – current claim earnings during qualifying period $[amount] = $[amount].”

- Select Save .

- In RCM, on the Input screen, complete the fields as follows:

- Social Insurance No.: This field is prefilled when RCM is accessed from NWS or SSO. If the information is not prefilled, enter the client’s SIN.

- Serial No: Leave this field blank.

- Serial Number of ROE Amended or Replaced: Leave this field blank.

- Interim ROE Type: Select Fishing Interim.

- Select Submit .

- Determine if an error message is displayed:

- If yes, resubmit with the correct SIN.

- If no, go to step 9.

- From the Input Fishing ROE screen, complete the blocks of the ROE as follows:

- block 4: Employer’s name: Enter the employer’s name.

- block 7: CRA Business no.: If available, enter the business number.

- block 6A: Trip(s) Start Date (fresh catch only): If this is a fresh catch, enter a date in the week before the BPC. If not, leave this field blank.

- block 6B: Trip(s) End Date (fresh) or date of purchase (cured): Enter a date in the week before the BPC.

- block 6C: Share of Insurable Earnings: Enter the amount of insurable earnings obtained in step 4, including dollars and cents.

- block 11: Reason for Separation: Select the RFS.

- Additional Information: Type “Interim ROE created” and the reason it was created (e.g. “Temporary fishing measure”).

- For all other blocks, enter the information if available.

- Select Submit .

- Determine if an error message is displayed:

- If no, go to step 11.

- If yes, correct any errors before selecting Submit (refer to Correcting an ROE , if required). Go to step 11.
               [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- Determine if this is an initial claim:

- If yes, go to step 12.

- If no, go to step 13.

- On the calculation worksheet, note that the last day worked (LDW) in SSO must be modified to match the date entered in block 6B and a supplementary claim information (SCI) 7 code must be input in SSO on the M103 - Initial Decision (M103) transaction when the claim is input. Go to step 14.

- On the calculation worksheet, note that the LDW in SSO must be modified to match the date entered in block 6B. If the Supplementary claim information field is prefilled with code 7 - Post emergency response benefit , it must be removed. If M - Major attached is indicated in the Record of employment field of the M106 - Subsequent Decision (M106) transaction, it must also be removed so the field is blank.

- Finalize the claim following normal procedures.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3361.dita) 

#### Note

Source topic: `en_EN/common_notes/note_c_3357.dita`

Note:

Once the entries on the Input screen are submitted successfully, the Input Regular ROE or Input Fishing ROE screen is displayed with the SIN prefilled. 

#### Note

Source topic: `en_EN/common_notes/note_c_1570.dita`

Note:

There cannot be more than 2 outstanding registration numbers. If there are already 2 outstanding registration numbers, advise the team leader that multiple registration numbers are preventing a new one from being created. 

#### Note

Source topic: `en_EN/common_notes/note_c_1571.dita`

Note:

When the message Success — Registration number created is displayed in SSO, a recalculation registration number is assigned to the claim. NWS creates a CR WI and assigns it to the unassigned (UNA) workload or to the next available user. 

#### Note

Source topic: `en_EN/common_notes/note_c_3358.dita`

Note:

The previous claim must have a BPC during one of the following periods:

```text
| Summer fishing (CT 6) | Winter fishing (CT 7) |

| September 29, 2019 to June 20, 2020 or September 30, 2018 to June 15, 2019 | March 29, 2020 to December 19, 2020 or March 31, 2019 to December 21, 2019 |
``` 

#### Note

Source topic: `en_EN/common_notes/note_c_3359.dita`

Note:

On a fishing claim that has a BPC between September 27, 2020 (w/c 2258) and November 14, 2021 (w/c 2317) and remains BPNE N5 or N7, the officer must bypass the sending of the automated letter and create a manual letter to inform the client of the decision and provide the accurate insurable earnings. Instead of using the insurable earnings that appear in SSO, use the ones on the fishing ROE that are in the QP. 

#### Example

Source topic: `en_EN/common_notes/note_c_3360.dita`

Example:

On a summer fishing claim (CT 6) with a BPC in w/c 2258, the client requires insured earnings of $2 500 to qualify for benefits. The fishing ROE provided has $1 200 in earnings. The client had a CT 6 in 2018 with a BPC in w/c 2154 and the total insured earnings were $6000. The client had a CT 6 in 2019 with a BPC in w/c 2206 and the total insured earnings were $10200. The highest total insured earnings out of the two seasons were $10 200. $10 200 – $1 200 = $9 000. The interim ROE is created using $9 000 in insured earnings. 

#### Note

Source topic: `en_EN/common_notes/note_c_3361.dita`

Note:

If the claim remains BPNE N5 or N7, bypass the sending of the automated letter and create a manual letter to inform the client of the decision and provide the accurate insurable earnings. Instead of using the insurable earnings that appear in SSO, use the ones on the fishing ROE that are in the QP. 

## Policy reference

Source topic: `en_EN/task/entering_interim_roe/policy_reference.dita`

 
