# Adjudicating non-referred training: CCB — Renewal claim

Source map: `en_EN/task/training_ccb_renewal/training_ccb_renewal.ditamap`

## Summary

Source topic: `en_EN/task/training_ccb_renewal/summary.dita`

Summary: When clients submit a renewal claim for CCB and then attend non-referred training, this may affect their entitlement if the training is during the CCB period. 

## What you need to know

Source topic: `en_EN/task/training_ccb_renewal/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/task/training_ccb_renewal/training_reported_between_september_27__5ecd71c7.dita`

A transitional measure under which ACP automatically adjudicated and allowed all training effective September 27, 2020 has ended on September 11, 2021. The intent of this measure was to prevent any delay in payment to clients who reported training.

The client must still meet the entitlement conditions for CCB while attending non-referred training. A client attending non-referred training may provide information on a claimant’s report or during a conversation with an officer that brings into question the entitlement to CCB. In this case, the officer creates a WI for the training issue and follows normal adjudication procedures, even if ACP initially allowed the training. 

### Impact of training on CCB

Source topic: `en_EN/task/training_ccb_renewal/impact_of_training_on_ccb.dita`

When adjudicating non-referred training for a client receiving CCB, the issue is not availability, but whether the client continues to provide care and support for the patient for whom the benefits are payable. This includes a client who is attending non-referred short-term training courses and targeted initiatives. For a complete list of non-referred short-term courses and targeted initiatives, the officer refers to the job aid .
       [job aid](/en/procedure/generic/additionalresources/shortterm_courses_ti.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4796.dita) 

### Levels of Decision

Source topic: `en_EN/task/training_ccb_renewal/levels_of_decision.dita`

A Level 1 officer can render the decision to allow non-referred training (not EIA 25) while the client is receiving CCB when the training is less than 25 hours per week.

There must be no doubt that the client is still providing care or support. If the client makes any statement that creates doubt that the client is providing care or support, the officer reassigns the issue to Level 2. For more information, the officer refers to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Care or support

Source topic: `en_EN/task/training_ccb_renewal/care_or_support.dita`

Patients may require the care or support of one or more family members because of their state of health or for psychological and emotional support.

Care and support includes situations in which the client simply spends time each day with the patient.

CCB can be paid when the client lives in a different geographical area than the gravely ill family member and arranges for the delivery of care or provides psychological and emotional support from a distance.

If it becomes apparent that the client is not providing care or support, the client is disentitled from benefits. This applies whether or not the client lives in the same geographical area as the patient.

For more information, the officer refers to Digest 23.2.4 — Care or support of seriously ill family member .
       [Digest 23.2.4 — Care or support of seriously ill family member](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-23/compassionate-care-benefits.html#a23_2_4) 

### Processing the claim

Source topic: `en_EN/task/training_ccb_renewal/processing_the_claim.dita`

During processing, a renewal claim displays the Claim actions status In Progress (Manual) .

The processing of claims for CCB is not automated. A trip-down occurs for the Claim Assessment (CA) WI immediately after the registration and the establishment of the claim.

Currently, the system does not allow the client to report training on a claim for CCB. When a client reports attending non-referred training while receiving CCB to an officer, the officer creates an ADJ Availability WI and types “Training” in the Details field.

When adjudicating training, the officer also takes the following actions:

- create a manual record of decision (ROD);

- complete manual inputs related to the training information;

- impose any disentitlements that apply.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4797.dita) 

### Inputting the training information

Source topic: `en_EN/task/training_ccb_renewal/inputting_the_training_information.dita`

When the client reports training on a claim for CCB, IRS or AW does not generate an electronic questionnaire. Therefore, notification of training is only received if the client chooses to provide a training questionnaire or contacts directly an officer. In this case, the officer inputs the training only if the client is completing claimant’s reports. If the client is exempt from completing claimant’s reports, the officer does not input the training in FTS.

When a client reports training on a claim for CCB and no training is coded, the claim is rejected with the error code C519 . 

### Note

Source topic: `en_EN/common_notes/note_c_4796.dita`

Note:

If a client quits employment or refuses an offer of employment to attend a non-referred training course, a non-referred short-term training course or a targeted initiative, the officer adjudicates the reason for separation (RFS) or refusal of employment on a separate WI. 

### Note

Source topic: `en_EN/common_notes/note_c_4797.dita`

Note:

This workaround applies until a system update is done to allow:

- the client to report training on the EI application;

- the client to complete an electronic training course questionnaire for a claim for CCB;

- the officer to create an ADJ Training WI on a claim for CCB. 

## Regional considerations

Source topic: `en_EN/task/training_ccb_renewal/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/training_ccb_renewal/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/training_ccb_renewal/in_fts.dita`

- Is the client exempt from completing claimant’s reports?

- Is there a registration number for the non-referred training issue?

- Is there training information on the Project tab? 

### In NWS:

Source topic: `en_EN/task/training_ccb_renewal/in_nws.dita`

- Is there a ROD for the non-referred training issue?

- Is there an SROC or an Action Item (AI) WI with the training information from either the Training: Non-referred part-time training — Checklist or the Training: INS3141 Training course information — Form? 

### In Imaging:

Source topic: `en_EN/task/training_ccb_renewal/in_imaging.dita`

- Is there non-referred training information or the INS3141 form? 

## Step by step

Source topic: `en_EN/task/training_ccb_renewal/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/training_ccb_renewal/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_ccb_renewal/reviewing_the_file_level_1.dita`

- Determine if there is a WI for the training issue:

- If yes, go to step 2.

- If no, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Myself .

- Issue(s): Select Availability .

- Details: Type “Training.”

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4799.dita)

- Determine if all of the following non-referred training information is on file:

- number of hours of training per week (if the client is attending regular non-referred training)

- location of the training

- start date of training

- If no, go to step 3.

- If yes, go to step 6. 

#### Fact-finding

Source topic: `en_EN/task/training_ccb_renewal/fact-finding_level_1.dita`

- Fact-find with the client.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 5.

- If the client was not reached or did not reply to the N-10-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ccb_renewal#level1_item_6)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — compassionate care benefits.”

- Details: Document the following details:

- name of the course

- course start and end dates

- hours of training per week

- name of the training institution

- Select Save . 

#### Determining if the conditions are met to allow training at Level 1

Source topic: `en_EN/task/training_ccb_renewal/determining_if_the_conditions_are_met_t_790eb5eb_level_1.dita`

- Determine if any of the following conditions are met:

- The client reported training in error.

- The client was attending training before the benefit period (BP).

- The client is not attending training.

- If no, go to step 7.

- If yes, go to Training is not an issue .
                   [Training is not an issue](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ccb_renewal#level1_item_4)

- Determine if the non-referred training is less than 25 hours per week:

- If yes, go to step 8.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ccb_renewal#level1_item_6)

- Determine if the client has made any statement that creates doubt that the client is providing care or support for the family member for whom the benefits are payable while attending non-referred training:

- If no, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ccb_renewal#level1_item_5)

- If yes, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ccb_renewal#level1_item_6) 

#### Training is not an issue

Source topic: `en_EN/task/training_ccb_renewal/training_is_not_an_issue_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training is not an issue.”

- Details: Type “ The facts on file indicate that the client reported the training in error .”

- Select Save .

- Complete the WI for the training issue. 

#### Entitlement conditions are met

Source topic: `en_EN/task/training_ccb_renewal/entitlement_conditions_are_met_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — compassionate care benefits — entitlement in order.”

- Details: Type “The training is less than 25 hours per week and the client is providing care or support for the family member while attending non-referred training.” Document any other details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- In FTS, determine if the client is exempt from completing claimant’s reports:

- If no and the client is completing claimant’s reports, go to step 3.

- If yes, go to step 5.

- Determine if the non-referred training information has been input on the Project tab:

- If no, go to step 4.

- If yes, go to step 5.

- Input the training information on the Project tab as follows:

- Select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Complete the WI for the training issue. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/training_ccb_renewal/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the WI as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type the appropriate option:

- “Unable to contact client for fact-finding.”

- “Not within Level 1 authority — the non-referred training is more than 25 hours per week.”

- “There is doubt as to whether the client is providing care for the family member while attending non-referred training.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_4799.dita`

Note:

On a claim for CCB, an ADJ Training WI cannot currently be created. When a client receiving CCB reports training, create an ADJ Availability WI and indicate in the Details field that the issue is actually training. This workaround applies until a system update is done to allow:

- the client to reports training on the EI application;

- the client to complete an electronic training course questionnaire for a claim for CCB;

- an ADJ Training WI to be created on a claim for CCB. 

### Level 2

Source topic: `en_EN/task/training_ccb_renewal/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_ccb_renewal/reviewing_the_file_level_2.dita`

- Determine if all of the following non-referred training information is on file:

- number of hours of training per week if the client is attending regular non-referred training)

- location of the training

- start date of the training

- If no, go to step 2.

- If yes, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/training_ccb_renewal/fact-finding_level_2.dita`

- Fact-find with the client.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 4.

- If the client was not reached or did not reply to the N-10-00-00 letter, go to step 5.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — compassionate care benefits.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating non-referred training

Source topic: `en_EN/task/training_ccb_renewal/adjudicating_non-referred_training_level_2.dita`

- Determine if any of the following conditions are met:

- The client reported training in error.

- The client was attending training before the BP.

- The client is not attending training.

- If no, go to step 6.

- If yes, go to Training is not an issue .
                   [Training is not an issue](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ccb_renewal#level2_item_4)

- Adjudicate the non-referred training according to the entitlement principles found in Digest 23.5.0 — Attending a course of instruction :

- If the client meets the entitlement conditions, go to Entitlement conditions are met.
               [Entitlement conditions are met.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ccb_renewal#level2_item_5)

- If the client does not meet the entitlement conditions, go to Entitlement conditions are not met .
               [Entitlement conditions are not met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ccb_renewal#level2_item_6) 

#### Training is not an issue

Source topic: `en_EN/task/training_ccb_renewal/training_is_not_an_issue_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training is not an issue.”

- Details: Indicate why the training is not an issue and whether credibility was a factor in the decision.

- Select Save .

- Complete the WI for the training issue. 

#### Entitlement conditions are met

Source topic: `en_EN/task/training_ccb_renewal/entitlement_conditions_are_met_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — compassionate care benefits — entitlement in order.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the client is exempt from completing claimant’s reports.

- If no and the client is completing claimant’s reports go, to step 3.

- If yes, go to step 5.

- Determine if the non-referred training information has been input on the Project tab:

- If no, go to step 4.

- If yes, go to step 5.

- Input the training information on the Project tab as follows:

- Select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Complete the WI for the training issue. 

#### Entitlement conditions are not met

Source topic: `en_EN/task/training_ccb_renewal/entitlement_conditions_are_not_met_level_2.dita`

- Verbally communicate the decision to the client.

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — D51 from w/c [XXXX-X] to [XXXX-X].”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select - Add .

- Disentitlement: Select 51 - Does not meet compassionate care entitlement conditions .

- Start date: Select the disentitlement start date.

- End date: Select the appropriate end date as follows:

- If the training has ended, select the corresponding end date of the disentitlement.

- If the training has not ended, select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate message:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Determine if the client is exempt from completing claimant’s reports:

- If no and the client is completing claimant’s reports, go to step 5.

- If yes, go to step 6.

- Determine if the non-referred training information has been input on the Project tab:

- If yes, go to step 6.

- If no, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Compassionate care benefits denied - D51/D52/D53/Free text (3084) .

- Select D51 – Not entitled to CCB – Various reasons (3085) .

- Select D51 - Client does not provide care or support to the ill family member .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Select the appropriate dates from the drop-down calendar.

- Overpayment messages (2452) .

- Right to Request a Reconsideration (no Blank Option) (4169): Select Right to Request a Reconsideration .

- This letter replaces or Footnote (2365): Type “You have not proven that you are providing care or support for your family member while attending a course of instruction on your own initiative.”

- In NWS, create a client Note and type “Impose the disentitlement for the non-referred training according to the ROD dated [date] and send the saved N-00-00-00 letter.”

- Complete the WI for the training issue. 

## Policy reference

Source topic: `en_EN/task/training_ccb_renewal/policy_reference.dita`

- Digest 23.2.4 — Care or support of gravely ill family member
         [Digest 23.2.4 — Care or support of gravely ill family member](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-23/compassionate-care-benefits.html#a23_2_4)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
