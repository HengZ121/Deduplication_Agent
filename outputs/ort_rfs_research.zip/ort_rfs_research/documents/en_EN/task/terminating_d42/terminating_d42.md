# Terminating a D42 disentitlement

Source map: `en_EN/task/terminating_d42/terminating_d42.ditamap`

## Summary

Source topic: `en_EN/task/terminating_d42/summary.dita`

Summary: The agent must terminate the disentitlement for suspension when the suspension period expires, the client has worked enough hours with another employer to qualify for benefits, has voluntarily left the employment, is dismissed or is laid off. 

## What you need to know

Source topic: `en_EN/task/terminating_d42/what_you_need_to_know.dita`

### Situations when a Suspension from employment disentitlement (D42) can be terminated

Source topic: `en_EN/task/terminating_d42/situations_when_a_suspension_from_emplo_52c27513.dita`

A disentitlement for a suspension (D42) is terminated on the day prior to the date the employer/employee relationship ceases to exist when:

- the client decides to voluntarily leave the employment;

- the client is dismissed;

- the client is laid off due to a shortage of work;

- the suspension period expires;

- the client works enough hours with another employer to qualify for benefits.

The agent must adjudicate the reason for separation (RFS) issue before terminating the D42 disentitlement. 

### Levels of decision

Source topic: `en_EN/task/terminating_d42/levels_of_decision.dita`

Level 1 agents can terminate a disentitlement for a suspension from employment due to misconduct on a renewal claim when:

- the period of suspension expires; or

- the client is laid off; or

- the reason for not returning to work is one of the reasons that can be allowed at Level 1; or

- the client accumulates enough insured hours with another employer after the beginning of the suspension to qualify for benefits; and

- the client is capable of and available for work and poses no restrictions towards the acceptance of employment.

When the Level 1 agent cannot adjudicate the issue, the facts are documented and the RFS is referred to Level 2 for adjudication.

Continuing claims must be reassigned to Level 2. 

### Dismissal during a period of suspension

Source topic: `en_EN/task/terminating_d42/dismissal_during_a_period_of_suspension.dita`

When a client is dismissed during a suspension the RFS must be adjudicated at Level 2. 

### Claim action status and processing a renewal claim

Source topic: `en_EN/task/terminating_d42/claim_action_status_and_processing_a_re_d58d6709.dita`

When there is an outstanding adjudication issue on a renewal claim, the claim action status is In Progress (Automation) . When the claim action status shows In Progress , all Adjudication Issue (ADJ) WIs must be completed before the system can calculate the initial claim or finalize the renewal claim. The MA02 stop payment is removed by the system.

If a letter of decision is required on a renewal claim, before completing the ADJ WI, the agent creates a Correspondence (COR) Manual Decision WI indicating the details of the required letter. If a letter of decision is required on a continuing claim, the agent sends the letter before completing the ADJ WI. 

## Regional considerations

Source topic: `en_EN/task/terminating_d42/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/terminating_d42/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/terminating_d42/in_nws.dita`

- Is there a record of decision (ROD) for the RFS?

- Is there a ROD for availability?

- Are there any SROCs, Action Item (AI) WIs, other WIs or documentation containing checklists or other details relating to the RFS on this or a prior application?

- Are there any SROCs, AI WIs, other WIs or documentation containing checklists or other details relating to the client’s availability?

- Has the client worked since the suspension? 

### In FTS:

Source topic: `en_EN/task/terminating_d42/in_fts.dita`

- Is there a manual action (MA75) imposed?

- Is there a registration number?

- What is the claim type (continuing or renewal)?

- Has the client declared earnings since the suspension? 

### In RCM:

Source topic: `en_EN/task/terminating_d42/in_rcm.dita`

- Has an ROE been submitted?

- How many hours has the client worked since the suspension? 

## Step by step

Source topic: `en_EN/task/terminating_d42/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/terminating_d42/level_1.dita`

#### Determining if the conditions are met to terminate the disentitlement

Source topic: `en_EN/task/terminating_d42/determining_if_the_conditions_are_met_t_8403ce5a_level_1.dita`

- Determine if the claim type is a renewal:

- If yes, go to step 2.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d42#reassignL2)

- Determine if the period of suspension expired:

- If no, go to step 3.

- If yes, go to step 5.

- Determine if the client is capable of and available for work and poses no restrictions towards the acceptance of employment:

- If yes, go to step 4.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d42#reassignL2)

- Determine if one of the following conditions applies:

- The client was laid off or the reason for not returning to work is for one of the reasons that can be allowed at Level 1 based on the National Policy on Levels of Decision . Refer to Voluntary Leaving .
               [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml#1) 
               [Voluntary Leaving](/en/procedure/activity/voluntary_leaving.shtml)

- The client accumulated enough insured hours with another employer after the commencement of the suspension to qualify for benefits. It is not necessary to establish a new benefit period. Refer to Calculating a claim for regular benefits .

- If yes, go to Terminating the disentitlement .
                   [Terminating the disentitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d42#terminating)

- If no, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d42#reassignL2)

               [Calculating a claim for regular benefits](/en/procedure/activity/calculation.shtml) 

#### Terminating the disentitlement

Source topic: `en_EN/task/terminating_d42/terminating_the_disentitlement_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Suspension from employment/disentitlement terminated.”

- Details: Type one of the following:

- “ The client’s period of suspension from employment expired. Disentitlement terminated as of XXXX-X.”

- “The client was laid off due to a shortage of work while on a suspension from employment. Disentitlement terminated as of XXXX-X.”

- “The client accumulated enough hours with another employer after the suspension from employment started to qualify for benefits. Disentitlement terminated as of XXXX-X.”

- “The client voluntarily left the employment while on suspension from employment due to misconduct. Disentitlement terminated as of XXXX-X.”

- Determine if a D42 is imposed:

- If yes, go to step 7.

- If no, go to step 13.

- In FTS, select the Disqualifications/Disentitlements link to terminate the D42 as follows:

- Select the original disentitlement.

- Click Modify .

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify to terminate .

- End Date: Enter the disentitlement end date.

- Detection: Select 31 - Other .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration open for subsequent transactions.

- Click Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements terminated and/or removed (2591) .

- Overpayment Messages (2452) .

- Right to Request a Reconsideration (with blank option) (4169) .

- In NWS, create a client Note and type “Send the A-01-00-00 letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 11.

- If yes, go to step 13.

- Determine if there is a system generated ROD with a negative decision:

- If no, go to step 12.

- If yes, go to step 13.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-00 letter required — suspension issue.”

- In NWS, complete the WI for the RFS issue. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/terminating_d42/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the WI as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type: “End of a suspension period. Not within Level 1 authority.” 

### Level 2

Source topic: `en_EN/task/terminating_d42/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/terminating_d42/reviewing_the_file_level_2.dita`

- Determine if there is a ROD for the contentious issue on file:

- If there is no ROD, go to step 2.

- If there is a ROD, go to step 3. 

#### Adjudicating the end of a suspension

Source topic: `en_EN/task/terminating_d42/adjudicating_the_end_of_a_suspension_level_2.dita`

- Determine why the client is no longer under suspension:

- If the client voluntarily left, refer to Voluntary Leaving and then return to step 3.
               [Voluntary Leaving](/en/procedure/activity/voluntary_leaving.shtml)

- If the client was dismissed, refer to Dismissal and then return to step 3.
               [Dismissal](/en/procedure/activity/dismissal.shtml)

- Determine if the client indicated unavailability for work or posed restrictions towards the acceptance of employment, refer to Availability and then return to step 4.

- In NWS, create a ROD as follows:

- Comments: Type “suspension/disentitlement terminated.”

- Details: Type one of the following:

- “The client voluntarily left the employment while on suspension. Disentitlement terminated as of w/c [XXXX-X].”

- The client was dismissed while on suspension. Disentitlement terminated as of w/c [XXXX-X].”

- Follow the applicable procedure based on your decision and the status of the claim:

- Disentitlement terminated — Renewal claim
               [Disentitlement terminated — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d42#DEterm)

- Disentitlement terminated — Continuing claim
               [Disentitlement terminated — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d42#DEtermCont) 

#### Disentitlement terminated — Renewal claim

Source topic: `en_EN/task/terminating_d42/disentitlement_terminated__renewal_claim_level_2.dita`

- In FTS, determine if there is a D42 — Suspension from employment imposed:

- If yes, go to step 7.

- If no, go to step 13.

- Select the Disqualifications/Disentitlements link to terminate the D42 as follows:

- Select the original disentitlement.

- Click Modify .

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify to terminate .

- End Date: Enter the disentitlement end date.

- Detection: Select 31 - Other .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration open for subsequent transactions.

- Click Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements terminated and/or removed (2591) .

- Overpayment Messages (2452) .

- Right to Request a Reconsideration (with blank option) (4169) .

- In NWS, create a client Note and type “Send the A-01-00-00 letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 11.

- If yes, go to step 13.

- Determine if there is a system generated ROD with a negative decision:

- If no, go to step 12.

- If yes, go to step 13.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-00 letter required – suspension issue.”

- Complete the WI for the RFS issue. 

#### Disentitlement terminated — Continuing claim

Source topic: `en_EN/task/terminating_d42/disentitlement_terminated__continuing_claim_level_2.dita`

- In FTS, determine if there is a D42 — Suspension from employment imposed:

- If yes, go to step 7.

- If no, go to step 10.

- Determine if there is an outstanding registration number for the suspension issue:

- If there is an outstanding registration number, go to step 8.

- If there is no outstanding registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- Select the Disqualifications/Disentitlements (M161) to terminate the D42 as follows:

- Select the original disentitlement.

- Click Modify .

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify to terminate .

- End Date: Enter the disentitlement end date.

- Detection: Select 31 - Other .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements terminated and/or removed (2591) .

- Overpayment Messages (2452) .

- Right to Request a Reconsideration (with blank option) (4169) .

- In NWS, complete the WI for the RFS issue. 

## Policy reference

Source topic: `en_EN/task/terminating_d42/policy_reference.dita`

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 31
         [EIA 31](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-31.html)

- Digest 7 — Misconduct
         [Digest 7 — Misconduct](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-7/table-of-contents.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
