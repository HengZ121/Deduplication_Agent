# Reviewing a fraudulent renewal when payments have been issued — Blocked claim

Source map: `en_EN/task/renewal_payments_issued/renewal_payments_issued.ditamap`

## Summary

Source topic: `en_EN/task/renewal_payments_issued/summary.dita`

Summary: The Integrity investigator creates a Claim Review (CR) Integrity ERB-EI Transition WI to inform the Level 2 officer of the result of an investigation when a client’s personal information has been used to fraudulently renew a claim for EI benefits. 

## What you need to know

Source topic: `en_EN/task/renewal_payments_issued/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/renewal_payments_issued/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4458.dita) 

### Fraudulent renewals

Source topic: `en_EN/task/renewal_payments_issued/fraudulent_renewals.dita`

On March 15, 2020, the Government of Canada introduced the EI Emergency Response Benefit (EI ERB) to provide temporary income support to workers impacted by the COVID-19 pandemic. In the weeks that followed, it was discovered that the personal information of many Canadians was used to fraudulently establish EI ERB claims, EI claims and to renew non-fraudulent claims.

The Level 2 officers who are part of the specialized team follow this procedure when a claim has been renewed by a third party and payments have been issued on a blocked claim.

When an Integrity investigator sends the case for action, the Integrity investigator creates a CR Integrity ERB-EI Transition WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4459.dita) 

When a third party has used the client’s personal information to renew a claim after a client either returned to work or stopped completing claimant’s reports, a processing officer inputs the required transactions to correct the file and the IPOC officer removes the payments from the client’s file.

Fraudulent activity in EI applications is discovered in several different ways, including the following:

- The client receives a T4E without having applied for benefits and contacts the call centre.

- A returned payment raises suspicion about a bank account.

- A client’s claim is transferred to another ITC and the client can no longer complete claimant’s reports.

- A client files a new application and an officer discovers fraud indicators on a previous application while processing the claim.
         [fraud indicators](/en/procedure/generic/additionalresources/fraud_indicator.shtml)

- A client files a new application and a renewal is completed instead of a new claim because there is an existing fraudulent BPC.

- A client has an existing claim and a third party renews the client’s claim. The renewal results in the client’s banking information being changed to a bank account not owned by the client.

- A third party modifies the client’s banking information. The client or third party completes claimant’s reports, which results in misdirected payments.

- A fraudulent ROE was issued in a fraudulent EI application submitted by a third party.

The address and banking information provided by the third party must be updated to the client’s information, even if the client is not requesting benefits. In FTS, ensure that the address and banking information are updated and that the client’s name, language and gender are correct. If there is a fraudulent claim in another ITC, update the client’s information in both ITCs.

When processing a Level 2 CR Integrity - ERB-EI Transition WI, it is possible that some transactions related to the fraudulent application may have already been enteredinput into the file. The officer should still continue with the procedure to ensure that all required actions have been taken. 

### Fraudulent ROEs

Source topic: `en_EN/task/renewal_payments_issued/fraudulent_roes.dita`

In NIIS, Integrity identifies the serial number of the ROEs that do not belong to the client. The Level 2 officer processing the CR Integrity ERB-EI Transition WI deletes the fraudulent ROEs in RCM, if necessary, and determines if the fraudulent ROEs were used to calculate the client’s initial claim. If yes, the Level 2 officer processing the CR Integrity ERB-EI Transition WI creates an AI WI for Level 1 to request a recalculation of the claim.

When a disqualification has been imposed, the level 2 officer also creates and sends the D01-00-00 letter in ACS. 

### Cycling claimant’s reports

Source topic: `en_EN/task/renewal_payments_issued/cycling_claimants_reports.dita`

In some cases, payments were issued to the third party on the fraudulent renewal application, a 71 - Integrity Services case manual action (MA71) was imposed and there are cycling claimant’s reports that were completed by the third party.

On a blocked claim, the Level 2 officer creates an Operational Centre Memo (MM06) transaction for IPOC to remove cycling claimant’s reports completed by the third party if any the following conditions are met:

- The client is not requesting benefits and fraudulent payments must be removed from the client’s file.

- The client is requesting benefits but is not entitled to some or all of those weeks.

- The client is requesting benefits for the same weeks as the cycling claimant’s reports but paycoding is required for some or all of those weeks.

When the client is requesting benefits, the Level 2 officer must also indicate in the MM06 for IPOC to issue payments for which the client is entitled with the appropriate paycoding, if necessary. 

### Defining claim status (CS)

Source topic: `en_EN/task/renewal_payments_issued/defining_claim_status_cs.dita`

A claim can be active, terminated, blocked or archived. The CS impacts which transactions can be input:

Active:

The active claim is established and is currently displayed automatically in FTS. It is a claim for which benefits are still payable and that has not been terminated.

Terminated:

A terminated claim appears on the Dormant tab in FTS. It has ended but can be reactivated. Once the transaction to reactivate the claim has been processed, all inputs for the claim must be done the same as for an active claim.

Blocked:

In some cases, the claim that the officer must reconsider is on the Dormant tab in FTS, but there is a new active claim established and displayed on the Summary tab.

Adjustments to blocked claims require IPOC intervention, except when benefits paid to the client due to fraudulent activities must be established as an overpayment (OP) and the blocked claim’s CS is 1 - Updateable . In this situation, the officer processes adjustments in BCS.

Archived:

A claim that is no longer on the Summary tab or the Dormant tab in FTS is an archived claim. The claim is displayed on the Pay History (under Enquiry ). The summary displays previous BPCs. When the BPC is selected, weeks paid and benefit types (BTs) paid are displayed. Adjustments to archived claims require IPOC intervention. 

### Inputs on a blocked claim — BCS

Source topic: `en_EN/task/renewal_payments_issued/inputs_on_a_blocked_claim__bcs.dita`

BCS allows 2 types of transactions to be processed on blocked dormant claims: Estimate and Claim update . Accessibility depends on the CS in BCS. When only modifying earnings or a FWW code for a week of regular benefits, if the claim is a blocked claim and the status of the claim in BCS is 1 - Updateable , an update can be requested using BCS and the transactions can be processed. When the CS in BCS is 2 - Not blocked , the claim is reactivated , and the officer inputs the decision as on an active claim. For any other CS in BCS, the transactions are processed with IPOC intervention using an MM06. 

### Responsibilities of the IPOC officer

Source topic: `en_EN/task/renewal_payments_issued/responsibilities_of_the_ipoc_officer.dita`

When a third party fraudulently renews a claim for EI benefits, the IPOC officer inputs adjustments in the following situations:

- If payments were issued to a third party and the client is requesting benefits for the same weeks, but is not entitled to the full amount (i.e. the client had earnings in those weeks), the Level 2 officer sends an MM06 transaction to IPOC. An IPOC officer removes the fraudulent payments from the client’s file and issues the payments to which the client is entitled. The IPOC officer actions the claim in MPS until the last renewable week (LRW).

- If payments were issued to a third party and the client is requesting benefits for different weeks, the Level 2 officer sends an MM06 to IPOC. An IPOC officer removes the fraudulent payments from the client’s file and issues the payments to which the client is entitled. The IPOC officer actions the claim in MPS until the LRW.

- If payments were issued to a third party and the client is not requesting benefits, the Level 2 officer sends an MM06 to IPOC to remove the fraudulent payments from the client’s file.

If the IPOC officer actions the claim in MPS, it remains in MPS for the duration of the claim.

**Potentially fraudulent payment**

When a payment is returned, an IPOC System Notification (IPOC SN) Returned payment WI is created for IPOC. The IPOC officer actioning the IPOC SN WI reviews the claim. If the payment is potentially fraudulent, the IPOC officer cancels the payment in SPS and creates an MM06 to cancel the payment in FTS to prevent issues with the client’s T4E at the end of the year. When the claim is active and the payment is for the last weeks processed on the Payments tab, the IPOC officer actioning the MM06 removes the payment details in purge and recreate (P/R). When the claim is returned to CPS, the payment is no longer visible on the Payments tab. For all other situations, the IPOC officer inputs a 39 - Prevent payment of Part II benefits and/or incorrect Part I benefits disentitlement (D39) to prevent the payment from being reissued because it is not possible to remove a payment that is not for the last week processed.

If an MM06 requesting to cancel a potentially fraudulent payment has already been actioned by the IPOC, the processing officer documents the information in the record of decision (ROD). The officer does not request IPOC to cancel payments that have already been cancelled by IPOC.

If an MM06 requesting to cancel a potentially fraudulent payment has not been actioned by the IPOC, the processing officer requests to cancel the returned payment in the MM06. In some situations, such as a payment including a family order agreement (FOA) deduction, a payment cannot be cancelled before receiving a confirmation that the payment is fraudulent or not.

**Removing versus cancelling payments**

The IPOC officer removes a payment from a client’s file when the payment has been received by a third party. The IPOC officer cancels a payment when a third party did not benefit from a payment because it has been returned in SPS or when a cheque has not been cashed.

A payment cannot be removed if a replacement has been issued to the client in SPS. 

### Requesting a payment replacement from IPOC

Source topic: `en_EN/task/renewal_payments_issued/requesting_a_payment_replacement_from_ipoc.dita`

When an EI payment is not received, or is lost, stolen, destroyed or stale-dated, a payment replacement can be issued to the client. Before requesting that IPOC process a payment replacement, the officer reviews the file.

A payment replacement can be requested when:

- the address on file is accurate;

- the name of the client is the same as the one indicated on the original payment;

- the client is entitled to the same amount as the original payment;

- the payment replacement corresponds to the same weeks as the original payment;

- the payment status in SPS is not Cancelled .

If any of the above conditions do not apply, the IPOC officer must remove the original payment from the client’s file and issue a new payment in MPS. 

### Archived Payments in SPS

Source topic: `en_EN/task/renewal_payments_issued/archived_payments_in_sps.dita`

An archived payment is not accessible when the payment reference number is input. The officer receives an AYE05007 No payment records found message. To access archived payments, from the Main Menu drop-down menu, the officer selects Payment Enquiry and, from the Screen drop-down menu, selects Payment Information Enquiry . Then, the officer inputs the client’s SIN, checks the Archived Payments Only box and selects Go .

Occasionally, a payment is archived and must be restored to initiate the trace request. To restore an archived payment, the officer selects the appropriate payment reference number, which brings the officer to the Request to Restore Payments screen, and the officer selects Confirm . The officer can also access this screen by selecting Restore Archived Data from the Main Menu drop-down menu and Request to Restore Payments from the Screen drop-down menu.

SPS processes requests to restore payments every half hour. To determine if the payment information has been restored, from the Main Menu drop-down menu, the officer selects Payment Enquiry , and from the Screen drop-down menu, selects Payment Information Detail Enquiry and inputs the payment reference number in question. If the payment information appears, the payment has been restored. 

### Responsibilities of the third party

Source topic: `en_EN/task/renewal_payments_issued/responsibilities_of_the_third_party.dita`

When a third party fraudulently receives EI payments, the third party is responsible for the resulting OP. Integrity follows up to establish the OP on the third party’s file and refers the case to the Royal Canadian Mounted Police, if necessary. No further action is taken related to the third party’s OP until the third party is identified. 

### Responsibilities of the client

Source topic: `en_EN/task/renewal_payments_issued/responsibilities_of_the_client.dita`

When the client receives EI payments due to fraudulent activities of a third party and is not entitled to those payments, the client is responsible for the resulting OP. In NIIS, Integrity identifies the weeks for which the client is not eligible and the required corrections to establish the OP on the client’s file. 

### Returning the file to Integrity

Source topic: `en_EN/task/renewal_payments_issued/returning_the_file_to_integrity.dita`

The Level 2 officer must consult NIIS for each case to find all the relevant information to review the issue. After conducting a full review of the investigation, if the Level 2 officer determines that facts are missing, the officer returns the file to Integrity for further fact-finding. The officer indicates the information that is missing but necessary to adjudicate the issue. The Level 2 officer does not adjudicate the issue if facts are missing or incomplete.

Missing or incomplete information could include:

- the client’s current address information;

- the client’s current banking information;

- whether the client is requesting benefits or not;

- the renewal week, if the client is requesting benefits;

- the claimant’s report information, if the client is requesting benefits;

- whether payments have been issued to the client or the third party;

- fraudulent ROEs to be deleted or that have been deleted from the client’s file.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1707.dita) 

The officer ensures that the investigator has also included information about any related contentious issues, if necessary.

For more information on navigating NIIS, the officer refers to the National Integrity Investigation System (NIIS) User Reference Guide .
       [National Integrity Investigation System (NIIS) User Reference Guide](https://014gc.sharepoint.com/sites/NIIS-SNEI/NIIS%20Documentation/NIIS%20EI%20Reference%20Guide%2020210406-V01-English.pdf) 

### Note

Source topic: `en_EN/common_notes/note_c_4458.dita`

Note:

This task is only used by Level 2 officers who are part of the specialized team actioning fraudulent EI claims. 

### Note

Source topic: `en_EN/common_notes/note_c_4459.dita`

Note:

If a client’s personal information has been used to fraudulently renew a claim for EI benefits and payments have been issued on an active or terminated claim, the Level 2 officer refers to Reviewing a fraudulent renewal when payments have been issued — Active or terminated claim .
       [Reviewing a fraudulent renewal when payments have been issued — Active or terminated claim](/en/procedure/task/reviewing_a_fraudulent_claim_renewal_client_not_seeking_benefits.shtml)

If a client’s personal information has been used to fraudulently renew a claim for EI benefits and no payment has been issued, the Level 2 officer refers to Reviewing a fraudulent renewal when no payment has been issued .
       [Reviewing a fraudulent renewal when no payment has been issued](/en/procedure/task/reviewing_a_fraudulent_claim_client_seeking_benefits.shtml)

If a client’s personal information has been used to fraudulently establish a claim for EI benefits, the Level 2 officer refers to Adjudicating an Integrity case — Voiding a fraudulent EI claim .
       [Adjudicating an Integrity case — Voiding a fraudulent EI claim](/en/procedure/task/adjudicating_an_integrity_case_voiding_fraudulent_ei_claim.shtml)

If a client’s claim was transferred to another information technology centre (ITC) after a fraudulent renewal, the Level 2 officer refers to Adjudicating an Integrity case — Transferring an EI claim to the client’s information technology centre .
       [Adjudicating an Integrity case — Transferring an EI claim to the client’s information technology centre](/en/procedure/task/adjudicating_integrity_case_transferring_ei_claims_to_client_info_tech_centre.shtml)

     [Reviewing a fraudulent renewal when payments have been issued — Active or terminated claim](/en/procedure/task/reviewing_a_fraudulent_claim_renewal_client_not_seeking_benefits.shtml) 
     [Reviewing a fraudulent renewal when no payment has been issued](/en/procedure/task/reviewing_a_fraudulent_claim_client_seeking_benefits.shtml) 
     [Adjudicating an Integrity case — Voiding a fraudulent EI claim](/en/procedure/task/adjudicating_an_integrity_case_voiding_fraudulent_ei_claim.shtml) 
     [Adjudicating an Integrity case — Transferring an EI claim to the client’s information technology centre](/en/procedure/task/adjudicating_integrity_case_transferring_ei_claims_to_client_info_tech_centre.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1707.dita`

Note:

If an investigator has updated the client’s address and banking information in FTS, the officer does not return the file to Integrity for this information. 

## Regional considerations

Source topic: `en_EN/task/renewal_payments_issued/regional_considerations.dita`

**Quebec — Returning the file to Integrity**

In addition to the information already indicated in this procedure, the officer returns the file to Integrity as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address qc-dgsi-isb-retour@servicecanada.gc.ca as a carbon copy.
             [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca)

- In NWS, create a client Note and type “Measure — returned to Integrity — [DD-MM-YYYY].”

**Quebec — Removing an application in NWS**

The Business Expertise Advisor, and not the team leader, deletes the application in NWS. As indicated in the Step by Step section, officers in the Quebec region use the National Business Expertise Tool (NEXO) to send the request and have the application deleted. A WI is not created in NWS. 

## What you need to look for

Source topic: `en_EN/task/renewal_payments_issued/what_you_need_to_look_for.dita`

### In NIIS:

Source topic: `en_EN/task/renewal_payments_issued/in_niis.dita`

- On the IC08 Case Summary screen, what actions have been taken on the case?

- On the IC50 Report of Clerical Investigation or IC70 Report of Investigation screen, is there:

- an Integrity Investigation Sheet?

- a Report of Interview?

- Has all the information required to make a decision been provided? 

### In Imaging:

Source topic: `en_EN/task/renewal_payments_issued/in_imaging.dita`

- Are there any other paper documents that are relevant to the case? 

### In SPS:

Source topic: `en_EN/task/renewal_payments_issued/in_sps.dita`

- Have any payments been returned or cancelled?

- Have any payments been made to a third party?

- Have any payments been made to the client by mistake?

- What is the status of the payments made on the claim? 

### In NWS:

Source topic: `en_EN/task/renewal_payments_issued/in_nws.dita`

- Is there any information relevant to the case on SROCs, RODs, AI, IPOC Review (IPOC REV) and Call Back (CB) WIs?

- Is there an SROC or a WI indicating that undeliverable mail has been received? 

### In FTS:

Source topic: `en_EN/task/renewal_payments_issued/in_fts.dita`

- Is the client’s banking information correct?

- Is the client’s name and address correct?

- Is the language indicated correct?

- Is the gender indicated correct?

- Does a phone number need to be modified or added?

- Is an MA71 imposed?

- Are there outstanding claimant’s reports that need to be input?

- Are there cycling claimant’s reports?

- Has a renewal week been input?

- What is the CS (active, terminated, blocked or archived)? 

### In RCM:

Source topic: `en_EN/task/renewal_payments_issued/in_rcm.dita`

- Are there fraudulent ROEs to be deleted or that have been deleted from the client’s file? 

### In ACS:

Source topic: `en_EN/task/renewal_payments_issued/in_acs.dita`

- Did Integrity send a request for information to the client? 

## Step by step

Source topic: `en_EN/task/renewal_payments_issued/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/renewal_payments_issued/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/renewal_payments_issued/reviewing_the_file_level_2.dita`

- In NIIS, determine if the information gathered by Integrity is complete :

- If yes, go to step 2.

- If no, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renewal_payments_issued#level2_item_4)

- Determine if the address is the client’s address:

- If yes, go to step 3.

- If no, update the address and go to step 3.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4460.dita) 
               [update the address](/en/procedure/activity/change_address.shtml)

- Determine if the banking information is correct:

- If yes, go to step 4.

- If no, update the banking information and go to step 4.
               [update the banking information](/en/procedure/activity/direct_deposit.shtml)

- Determine if payments were issued to the client or a third party on the fraudulent renewal claim:

- If yes, go to step 5.

- If no, refer to Reviewing a fraudulent renewal when no payment has been issued .
               [Reviewing a fraudulent renewal when no payment has been issued](/en/procedure/task/reviewing_a_fraudulent_claim_client_seeking_benefits.shtml)

- Determine if Integrity identified fraudulent ROEs:

- If yes, go to step 6.

- If no, go to step 22.

- In RCM, determine if the fraudulent ROEs have been deleted:

- If no, go to step 7.

- If yes, go to step 8.

- In RCM, open each ROE identified as fraudulent in NIIS by Integrity and delete it as follows:

- Delete: Check the box.

- Additional information : Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 9.

- Determine if the following text appears in the Additional information section of the deleted ROE: “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- If yes, go to step 9.

- If no, do the following:

- Additional information : Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Determine if there are any fraudulent ROEs in the qualifying period (QP) of one of the client’s established claim:

- If yes, go to step 10.

- If no, go to step 22.

- Determine if any fraudulent ROEs were used to calculate one of the client’s established claim:

- If yes, go to step 11.

- If no, go to step 22.

- In NWS, create an Action Item (AI) WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Claim type: Select Initial .

- Destination — Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / ISB Post Audit Processing .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- BPC: Enter the BPC requiring a recalculation.

- Comments: Select the appropriate option:

- If the recalculation is related to a different BPC than the fraudulent renewal application, do the following:

- Type “Integrity confirmed that [ROE [serial number] is or ROEs [serial numbers] are] fraudulent. The [ROE has or ROEs have] been deleted. Recalculate the client’s claim.”

- Source Details: Enter the Integrity case number.

- Go to step 22.

- If the recalculation is related to the same BPC as the fraudulent renewal application, do the following:

- Type “Integrity confirmed that [ROE [serial number] is or ROEs [serial numbers] are] fraudulent. The [ROE has or ROEs have] been deleted. Recalculation required. If the recalculation does not result in an OP for the client, create an Operational Centre Memo (MM06) transaction for IPOC to recalculate the claim following normal procedures and complete the AI and the CR Recalculation WIs. If the recalculation results in an OP for the client, do not create immediately the Operational Centre Memo (MM06) transaction for IPOC. Complete the AI WI to notify the Level 2 officer of the calculation result (e.g. application becomes BPNE, benefit rate decreases to $[XXX ] ). Move the CR Recalculation WI to Pending until the CR Integrity ERB-EI Transition WI for Level 2 is completed. Once the CR Integrity ERB-EI Transition WI for Level 2 is completed, create an Operational Centre Memo (MM06) transaction for IPOC with information related to the recalculation. When creating the Operational Centre Memo (MM06) transaction for IPOC, select Work item: 93 - Manual Pay System and Work type: 54 - Third party fraud. ”

- Source Details: Enter the Integrity case number.

- Go to step 22.

- Move the CR Integrity - ERB-EI Transition WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type: “Waiting for recalculation result at Level 1.”

- Bring forward date: Enter today’s date + 10 business days.

- Select Save .

- When the CR Integrity - ERB-EI Transition WI moves to the current workload, determine if the Level 1 AI WI has been completed:

- If no, repeat step 12.

- If yes, go to step 14.

- Determine which of the following situations applies:

- If the Level 1 AI WI has been completed and the CR Recalculation WI has been moved to pending by the Level 1 officer, go to step 15.

- If the AI and CR Recalculation WIs have been completed at Level 1, go to step 16.

- Determine whether, as a result of the recalculation, the established claim related to the same BPC as the fraudulent renewal application became BPNE due to a deleted fraudulent ROE:

- If no, go to step 16.

- If yes, go to step 32.

- Determine if there is a contentious reason for separation (RFS) that requires adjudication in the QP:

- If yes, go to step 17.

- If no, go to step 22.

- In FTS, determine the BPC:

- If the BPC is between w/c 2310 and w/c 2361, go to step 18.

- If the BPC is between w/c 2258 and w/c 2309, go to step 19.

- If the BPC is between w/c 2230 and w/c 2257 and it is a claim for special benefits other than sickness benefits, adjudicate each contentious FRS issue, unless the decision can be deferred. Go to step 20.

- If the BPC is w/c 2362 or after, adjudicate each contentious FRS issue, unless the decision can be deferred. Go to step 20.

- If the BPC is between w/c 2230 and w/c 2257 and it is an EI ERB claim , go to step 22.

- Determine if there is a contentious RFS in the QP, on the most recent ROE that belongs to the client :

- If yes, do the following:

- Open the corresponding RFS issue (i.e. the automatically resolved ROD with Adjudication not required ).

- Decision Options: Select Decision no longer valid .

- Select OK .

- Adjudicate the contentious RFS from the most recent ROE belonging to the client.

- Go to step 20.

- If no, go to step 22.

- Determine if the client is requesting regular or sickness benefits:

- If no, adjudicate each RFS issue requiring adjudication on a contentious RFS. Go to step 20.

- If yes, go to step 22.

- Determine if a disqualification or a disentitlement must be imposed due to a deleted fraudulent ROE:

- If yes, go to step 21.

- If no, go to step 22.

- In ACS, select the appropriate ITC and create and send the D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If a disqualification has been imposed, the client is requesting regular benefits and does not have enough hours since the contentious RFS to qualify, select the following attributes:

- Disqualifications – Definite/Indefinite – Previous/Current/Revision (2970): Select D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revised) .

- D11 / D10 / Both / Previous Disq / Revision – Initial or Renewal or Revision (2542): Select Disqualification message for Initial Claim .

- Disqualification message for Initial Claim (2543) .

- D11 / D10-Date of event = BPC/Date of event prior to BPC/ Date of event after BPC (2544) .

- D11 / D10-Min hrs for reg/ Insufficient hrs reg/ Insufficient hrs reg fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting regular benefits and has enough hours since the contentious RFS to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 message/D10 message (2463) .

- If the client is requesting special benefits and does not have enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Special benefits approved (3046): Select the appropriate BT and options.

- Not entitled to regular after special: - (D10/D11) or claim is BPNE) – Initial or renewal claim or D42 - D43 (2540): Select (D11/D10) imposed – Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491) .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D11 / D10 / Both -Min hrs for reg/ Insufficient hrs reg/ Insufficient hrs reg fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting special benefits and has enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (1503)

- Special benefits approved (3046): Select benefit type and the appropriate options.

- If a disentitlement has been imposed, select Disentitlements (2976)

- If an allocation of earnings has been input, select Allocation of Earnings (2516) .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment.

- O/P on a Non-Fraud active claim if the client has an active claim.

- O/P on a Non-Fraud inactive claim if the client does not have an active claim.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Go to step 32.

- Determine if payments were issued to the client on the fraudulent renewal claim:

- If yes, go to step 23.

- If no, go to step 32.

- Determine if benefits paid to the client due to fraudulent activities must be established as an OP:

- If yes, go to step 24.

- If no, go to step 32.

- Review the Blocked Status column under the Blocked tab and determine if the blocked claim’s CS is 1 - Updateable :

- If yes, go to step 25.

- If no , note the w/c and the appropriate paycoding. This information is required on the Operational Centre Memo (MM06). Go to step 26.

- In FTS, select the BPC to be updated from the Blocked Status column and input the appropriate corrections to establish the appropriate OP for the client.

- Determine if a disqualification or a disentitlement has been imposed:

- If yes, go to step 27.

- If no, go to step 28.

- In ACS, select the appropriate ITC and create and send the D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If a disqualification has been imposed, the client is requesting regular benefits and does not have enough hours since the contentious RFS to qualify , select the following attributes:

- Disqualifications – Definite/Indefinite – Previous/Current/Revision (2970): Select D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revised) .

- D11 / D10 / Both / Previous Disq / Revision – Initial or Renewal or Revision (2542) .

- D11 / D10-Date of event = BPC/Date of event prior to BPC/ Date of event after BPC (2544) .

- D11 / D10-Min hrs for reg/ Insufficient hrs reg/ Insufficient hrs reg fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting regular benefits and has enough hours since the contentious RFS to qualify , select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 message/D10 message (2463) .

- If the client is requesting special benefits and does not have enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Special benefits approved (3046): Select the appropriate BT and option s.

- Not entitled to regular after special - D10/D11 or claim is BPNE – Initial or renewal claim or D42 – D43 (2540): Select (D11/D10) imposed – Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491) .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D11 / D10 / Both -Min hrs for reg/ Insufficient hrs reg/ Insufficient hrs reg fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting special benefits and has enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (1503)

- Special benefits approved (3046): Select benefit type and the appropriate options.

- If a disentitlement has been imposed, select Disentitlements (2976)

- If an allocation of earnings has been input, select Allocation of Earnings (2516) .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment.

- O/P on a Non-Fraud active claim if the client has an active claim.

- O/P on a Non-Fraud inactive claim if the client does not have an active claim.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Go to step 30.

- Determine if an allocation of earnings has been input:

- If yes, go to step 29.

- If no , go to step 30.

- In ACS, select the appropriate ITC, and create send the D-20-16-03 letter. Based on the claim information, select all of the required attributes, including the following :

- Allocation of Earnings (2516)

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment.

- O/P on a Non-Fraud active claim if the client has an active claim.

- O/P on a Non-Fraud inactive claim if the client does not have an active claim.

- Determine if any claimant’s report has been modified:

- If yes, go to step 31.

- If no , go to step 32.

- In ACS, select the appropriate ITC and create and send the D20-02-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Earnings from employment or fishing are adjusted / post audit (4090)

- Text-Type of earnings (1072):

- For regular or special benefits, type “earnings from employment.”

- For fishing benefits, type “earnings from fishing.”

- Text-Employer’s Name or Source of Earnings (1504): Enter the employer’s name.

- Before deductions / from self-employment (4093) .

- Blank / based on new information you provided / based on new information your employer provided (2958): Select based on new information you provided .

- List of one or more false declarations (3483) .

- Adjustment to your earnings does not affect your benefits (4097): Select Blank .

- Overpayment Messages (2452): Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment.

- O/P on a Non-Fraud active claim if the client has an active claim.

- O/P on a Non-Fraud inactive claim if the client does not have an active claim.

- Determine if the client is requesting benefits:

- If yes, go to Actioning the fraudulent renewal — Client is requesting benefits .
               [Actioning the fraudulent renewal — Client is requesting benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renewal_payments_issued#level2_item_2)

- If no, go to Actioning the fraudulent renewal — Client is not requesting benefits .
               [Actioning the fraudulent renewal — Client is not requesting benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renewal_payments_issued#level2_item_3) 

#### Actioning the fraudulent renewal — Client is requesting benefits

Source topic: `en_EN/task/renewal_payments_issued/actioning_the_fraudulent_renewal__clien_ea48e855_level_2.dita`

- Determine if, as a result of the recalculation, the established claim related to the same BPC as the fraudulent renewal application became BPNE due to a deleted fraudulent ROE:

- If no, go to step 2.

- If yes, go to step 7.

- Determine if, as a result of the recalculation due to a deleted fraudulent ROE, a disqualification or a disentitlement must be imposed from the same BPC as the fraudulent renewal application:

- If no, go to step 3.

- If yes, go to step 7.

- Determine the renewal week. Refer to Determining the effective date of a renewal or a conversion and Conversion and renewal , if necessary.

- Determine if a payment issued to the third party can be replaced in SPS:

- If yes, go to step 5.

- If no, go to step 7.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4461.dita)

- Refer to NWS to review any completed WI and SROC to determine if any payment replacement has been requested for the same weekperiod. Complete a Payment: INS5207 Missing warrant replacement — Form for the weeks that were paid to a third party as follows:

- SIN: Enter the client’s SIN.

- HRCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- Requestor: Enter your 7-digit user code.

- Week Code(s): Enter the w/c of the payments to be replaced.

- Warrant No(s): Enter any payment reference numbers displayed on the Payment Summary (MN19) screen.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4462.dita)

- Amount(s): Enter any whole dollar amounts displayed on the Payment Summary (MN19) screen.

- Name: Enter the client’s last and first names.

- Address: Enter the client’s address.

- Telephone number: Enter the client’s telephone number.

- Action to take: Type “The payments were fraudulently deposited into a third party’s bank account.” If banking information was updated to the client’s information, type “Replace the payment to the client according to the direct deposit information modified in FTS on [DD-MM-YYYY].” If the client requests payment by cheque, type “Replace the payment to the client by cheque.”

- In NWS, create an IPOC REV WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC of your regional IPOC:

- Atlantic: 1826

- Quebec: 2642

- Ontario: 3056

- Western Canada and Territories: 5903

- End user: Select Next available user .

- Issue(s): Select Payment replacement .

- BPC: Enter the BPC of the claim.

- Comments: Type “Payment replacement.”

- Details: Copy and paste the information from the INS5207 (select the Ctrl + 1 keys to copy and Ctrl + V keys to paste).

- Obtained by: Select the appropriate option.

- Obtained from: Select the appropriate option.

- Source details: Enter the source details.

- Select Save .

- Determine if benefits paid to the third party must be removed from the client’s file:

- If no, go to step 8.

- If yes, note all w/cs and amounts. Go to step 11.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4463.dita)

- Determine if the client is requesting benefits for other weeks:

- If yes, determine which of the following situation applies:

- If, a disqualification or a disentitlement must be imposed from the same BPC as the fraudulent renewal application as a result of the recalculation due to a deleted fraudulent ROE, go to step 9.

- If the established claim became BPNE due to a deleted fraudulent ROE, go to step 15.

- If the 2 previous conditions do not apply, go to step 13.

- If no, determine which of the following situation applies:

- If, a disqualification or a disentitlement must be imposed from the same BPC as the fraudulent renewal application as a result of the recalculation due to a deleted fraudulent ROE, go to step 9.

- If the established claim became BPNE due to a deleted fraudulent ROE, go to step 15.

- If the 2 previous conditions do not apply, go to step 15.

- In FTS, review the Blocked Status column under the Blocked tab and determine if the blocked claim’s CS is 1 - Updateable :

- If yes, go to step 10.

- If no , note the w/cs in which a disqualification or a disentitlement must be imposed from the BPC. This information is required on the Operational Centre Memo (MM06). Go to step 13.

- In FTS, select the BPC to be updated from the Blocked Status column and input the appropriate corrections to establish the appropriate OP for the client. Go to step 15.

- In SPS, for each payment that must be removed, determine if the payment can be cancelled :

- If no, go to step 12.

- If yes, note the payment reference number, the amount (gross benefits and net amount), w/c, BT and claim type (CT). This information is required on the Operational Centre Memo (MM06). Go to step 12.

- Determine if the client is requesting benefits for other weeks:

- If yes, note all w/cs with the appropriate paycoding (earnings, not available days, full work week [FWW], etc.) that will affect entitlement for the weeks requested. Note the appropriate renewal date, if necessary. This information is required on the Operational Centre Memo (MM06) . Go to step 13.

- If yes and the established claim became BPNE due to a deleted fraudulent ROE, do not note the appropriate renewal week and do not mention to renew the claim on the Operational Centre Memo (MM06) . Go to step 13.

- If no, go to step 13.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the Integrity registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Detection: This field is prefilled according to the investigation type in NIIS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Select Update .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4464.dita)

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the Integrity registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 54 - Third party fraud .

- Remarks line 1: Type “Cancel fraudulent renewal w/c [XXXX]. Unknown third party.”

- Remarks lines 2–4: Type the appropriate information:

- For all payments and cycling reports to be removed, type “Remove w/c [XXXX] to [XXXX]. Total amount $[XXXX]. Adjust tax file or T4E. No OP for client.” If payments have been returned or cheques were never cashed, type “Also cancel returned payments or uncashed cheques, as appropriate, for w/c [XXXX] to [XXXX].” For each payment, type “w/c [XXXX] / [T071-2 for current year or T071-8 for the previous year] / reason F / CT [XX] / gross benefits [XXXX] / federal tax [XX] / provincial tax [XX] (if necessary) / net amount [XXXX] / PRN [XXXXXXXXXXXX].”

- If an OP must be established to the client because the client received payments for which they are not entitled, type “Establish OP to the client for w/c [XXXX] to [XXXX]. Client not entitled to benefits received.” Add the appropriate paycoding (disentitlement, earnings, not available days, full work week [FWW], etc).

- If an MA was imposed to stop payments, type “Rescind MA [XX].”

- If payments must be issued to the client , type “ Issue payments for w/c [XXXX] to [XXXX], CT [XX].” If paycoding is required, type “[appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” (add more w/cs if necessary).” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].”

- Remarks line 5: Enter your name and telephone number.

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NWS, create a ROD on the client’s application and not on the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a Reminder (REM) WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen, close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Fraudulent renewal. Third-party OP amount is $[XX].”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In NWS, complete the CR Integrity ERB-EI Transition WI and all other related WIs. 

#### Actioning the fraudulent renewal — Client is not requesting benefits

Source topic: `en_EN/task/renewal_payments_issued/actioning_the_fraudulent_renewal__clien_e67b41de_level_2.dita`

- In SPS, for each payment issued to a third party, determine if the payment must be cancelled :

- If no, go to step 2.

- If yes, note the payment reference number, the amount (gross benefits and net amount), w/c, BT, CT and the date the payment was processed. This information is required on the Operational Centre Memo (MM06) . Go to step 2.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4465.dita)

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the Integrity registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Detection: This field is prefilled according to the investigation type in NIIS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Select Update .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4466.dita)

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the Integrity registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 54 - Third party fraud .

- Remarks line 1: Type “Cancel fraudulent renewal w/c [XXXX]. Unknown third party.”

- Remark lines 2–4: For all payments to be removed including cycling claimant’s reports, type “Remove w/c [XXXX] to [XXXX]. Total amount $[XXXX]. Adjust tax file or T4E. No OP for client.” If payments have been returned or cheques were never redeemed, type “Also cancel returned payments or uncashed cheques, as appropriate, for w/c [XXXX] to [XXXX].” For each payment, type “w/c [XXXX] / [T071-2 for current year or T071-8 for the previous year] / reason F / CT [XX] / gross benefits [XXXX] / federal tax [XX] / provincial tax [XX] (if necessary) / net amount [XXXX] / PRN [XXXXXXXXXXXX].” Type “Client is not requesting benefits.” If an MA was imposed to stop payments, type “Rescind MA [XX].” If as a result of the recalculation due to a deleted fraudulent ROE, a disqualification must be imposed from the same BPC as the fraudulent renewal application, type “D[XX] from w/c [XXXX].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 5: Enter your name and telephone number.

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NWS, create a ROD on the client’s application and not on the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen, close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Fraudulent renewal. Third-party OP amount is $[XX].”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In NWS, complete the CR Integrity ERB-EI Transition WI and all other related WIs. 

#### Returning the file to Integrity

Source topic: `en_EN/task/renewal_payments_issued/returning_the_file_to_integrity_level_2.dita`

- In NIIS, on the Document tab, select IC70 Report of Investigation or IC50 Report of Clerical Investigation screen , depending on the case, and complete the following fields:

- Select Recommendation .

- Return the file to Integrity as follows:

- IC70 Report of Investigation

- Return the case to Integrity Operations: Select Yes .

- IC50 Report of Clerical Investigation

- Return the case to Integrity Operations: Check the box.

- Enter the missing or additional information required in the text area.

- Select OK .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4467.dita)

- In FTS, select the Outstanding Registrations link to cancel the integrity registration number as follows:

- Select Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Select Update .

- If there is an outstanding WI for an antedate request, complete it.

- If necessary, return the paper documents relating to the investigation to the investigator who signed the Report of Investigation.

- In NWS, complete the CR Integrity ERB-EI Transition WI and all other related WIs. 

#### Note

Source topic: `en_EN/common_notes/note_c_4460.dita`

Note:

Once the client’s address is updated, determine if there is an SROC or a WI on file indicating that undeliverable mail has been received. Re-send any letters that should have been sent to the client and whose still applies. For more information, refer to Re-sending undeliverable mail .
       [Re-sending undeliverable mail](/en/procedure/task/rescending_un_mail.shtml)

     [Re-sending undeliverable mail](/en/procedure/task/rescending_un_mail.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_4461.dita`

Note:

A payment is replaced in SPS when a client is entitled to the full amount of benefits paid on the same processed date. In SPS, the payment status must not be Cancelled . The client’s name must be in the Payee Name field. 

#### Note

Source topic: `en_EN/common_notes/note_c_4462.dita`

Note:

In FTS, if banking information has been deleted, the information on the Payment Summary (MN19) screen is no longer available. When this occurs, in the Enquiry menu in FTS, select the Statement of Benefits Paid (T4E) screen, then Itemized Statement . If payment reference numbers are available for the year in question, they are displayed on the itemized statement of benefits paid. 

#### Note

Source topic: `en_EN/common_notes/note_c_4463.dita`

Note:

Benefits paid are removed from the client’s file when a client does not request benefits for a week paid to the third party.

Benefits paid are also removed from the client’s file when a client is not entitled to the full amount of benefits paid on the same processed date or when a client is entitled to the benefits paid to the third party but the in the Payee’s name field in SPS is not the client’s name . In these situations, the processing officer requests the IPOC officer to remove and reissue the payment. 

#### Note

Source topic: `en_EN/common_notes/note_c_4464.dita`

Note:

An IPOC officer automatically processes the cycling claimant’s reports unless otherwise noted in the Remarks section. Therefore, it is important to indicate any other decision that would prevent payment. If the client is not entitled to some of the same weeks as the cycling claimant’s reports, inform the IPOC officer to remove them.

If a second Operation Centre Memo (MM06) transaction is required for the same BPC, type “Page 1 of 2.” at the end of the Remarks section of the first Operational Centre Memo (MM06) transaction and type “Page 2 of 2.” at the beginning of the Remarks section of the second transaction. 

#### Note

Source topic: `en_EN/common_notes/note_c_1713.dita`

Note:

In the Quebec region, instead of creating a REM WI, use the National Business Expertise Tool (NEXO) to advise the business expertise advisor that an application must be deleted. 

#### Note

Source topic: `en_EN/common_notes/note_c_4465.dita`

Note:

A previous anomaly in SPS prevented the payment status from being updated when a payment was deposited. If the status of a direct deposit payment is Issued for more than 5 business days, the payment is considered cashed. If the payment status for a payment issued by cheque is Issued for more than one month, the payment has still not been cashed and must be cancelled.

Payments that cannot be cancelled must be removed from the client’s file. 

#### Note

Source topic: `en_EN/common_notes/note_c_4466.dita`

Note:

If a second Operational Centre Memo (MM06) transaction is required for the same BPC, type “Page 1 of 2.” at the end of the Remarks section of the first Operational Centre Memo (MM06) transaction and type “Page 2 of 2.” at the beginning of the Remarks section of the second transaction. 

#### Note

Source topic: `en_EN/common_notes/note_c_4467.dita`

Note:

Officers in the Quebec region do the following:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address qc-dgsi-isb-retour@servicecanada.gc.ca as a carbon copy.
             [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca)

- In NWS, create a client Note and type “Measure — returned to Integrity — [DD-MM-YYYY].”

     [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca) 

## Policy reference

Source topic: `en_EN/task/renewal_payments_issued/policy_reference.dita`

 
