# Processing the notification of a Social Security Tribunal-General Division decision

Source map: `en_EN/task/proc_sst/proc_sst.ditamap`

## Summary

Source topic: `en_EN/task/proc_sst/summary.dita`

Summary: Once the Social Security Tribunal (SST)-General Division renders a decision on an appeal, the Commission is notified. 

## What you need to know

Source topic: `en_EN/task/proc_sst/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/proc_sst/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4075.dita) 

### Receiving a decision from the Social Security Tribunal (SST)-General Division

Source topic: `en_EN/task/proc_sst/receiving_a_decision_from_the_social_se_9573e481.dita`

After rendering a decision on the appeal, the SST-General Division sends the decision to all interested parties. Paper copies are sent to the appellant and other interested parties, except for the Commission. The SST-General Division notifies the Commission by sending an email to the GD mailbox of the region in which the appeal was processed. The SST-General Division also sends an electronic copy of the decision to the Commission through the 5. SST folder in the Common Document Share. A copy of the decision is also placed in ADMS and can be viewed by selecting View Decision on the Review Decision tab.

In ADMS, when the SST - GD Decision received at APC field on the Appeal Log tab is completed, the appeal record in the officer’s workload is highlighted in red and the selection in the Action required field changes to Review decision . The officer can then review the decision in ADMS and in the Common Document Share. 

### Sharing informationand exchanging documentswith theSST

Source topic: `en_EN/task/proc_sst/sharing_informationand_exchanging_docum_87844918.dita`

The SST and Commission share information through Atrium and ADMS and through the Common Document Share. The appeal processing systems, Atrium (used by the SST) and ADMS (used by appeal processing officers), communicate with each other throughout the appeal process. In the Common Document Share, the folder titled 5. SST is used for exchanging documents and acts like a drop box for each party. The SST puts any documents that must be shared with the Commission in this folder for pick-up and the Commission does the same when sending documents to the SST. Documents are not to be housed in this folder. They are moved to the related SIN folder in the regional SST level of the Common Document Share and kept there. 

### Implementing a Social Security Tribunal (SST)-General Division decision

Source topic: `en_EN/task/proc_sst/implementing_a_social_security_tribunal_dd5efc60.dita`

On the same day the notification is received, the officer retrieves the SST-General Division decision from the 5. SST exchange folder and moves it to the client’s Record-XX folder in the 2.SST-GD-TSS-DG / BOA-CA regional folder of the Common Document Share. That same day , the officer reviews the SST-General Division decision and updates ADMS based on the decision. Depending on the decision, the officer either implements the decision or suspends the implementation until National Headquarters reviews the decision.

**Decision implemented without National Headquarters review**

When the SST-General Division renders a decision that the Commission will not appeal to the SST-Appeal Division, the officer can implement the decision. This includes the following decision types:

- dismissed (including a rejected concession)

- delayed appeal denied

- withdrawn

- dismissed with modifications, when modifications are favorable to the Commission

**Decision that must be reviewed by National Headquarters**

When the SST-General Division allows an appeal, either in whole or in part, National Headquarters reviews the decision to determine if a possible Commission appeal (PCA) must be considered. This includes the following decision types in all cases:

- allowed (includes concessions)

- dismissed with modifications, when modifications are unfavorable to the Commission

If any issues in the appeal are dismissed or withdrawn, the officer implements the decisions on these issues before moving the PCA to National Headquarters’ workload.

The officer enters today’s date in the Date PCA sent to NHQ field to move the record to National Headquarters' workload.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4076.dita) 

If National Headquarters proceeds with the PCA, no further action is required from the officer. National Headquarters creates a new folder in SST-AD and moves all pertinent information from the SST-GD to the SST-AD folder for that appeal.

If National Headquarters decides not to pursue the PCA, it creates a memo explaining its rationale and saves it on the Feedback tab of the Quality Review section in ADMS. If the senior appeals officer did not complete the Quality Review section, a copy is added in the client’s 2.SST-GD-TSS-DG / BOA-CA regional folder. In ADMS, National Headquarters returns the case to the region so the decision can be implemented. The appeal is automatically assigned to the officer who prepared the case or to the officer who last reviewed the SST-General Division decision. If neither of these officers has an active profile in ADMS, the appeal is pending in the workload and the Action Required field displays Assign SCBO . The team leader monitors the regional workload and reassigns cases so decisions can be implemented. The officer assigned to the case then implements the decision.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4077.dita) 

### Employer appeal allowed by the Social Security Tribunal (SST)-General Division

Source topic: `en_EN/task/proc_sst/employer_appeal_allowed_by_the_social_s_5c95179f.dita`

The employer can appeal the Commission’s decision to allow the client benefits without any disqualification or disentitlement when the client voluntarily left or was dismissed from employment. If the SST-General Division allows the employer’s appeal, the disqualification or disentitlement is imposed retroactively and an overpayment (OP) is established for collection. 

### Appeal against denial of delayed request for reconsideration

Source topic: `en_EN/task/proc_sst/appeal_against_denial_of_delayed_reques_d18d86f8.dita`

When the Commission’s decision to deny a delayed request for reconsideration under EIA 112 is appealed to the SST-General Division, the denial is the only issue before the SST. Because the denial of a delayed request for reconsideration is a discretionary decision of the Commission, the SST-General Division cannot simply overturn the Commission’s decision. The SST-General Division must determine if the Commission exercised its discretion in a judicious manner. If it finds that the Commission did not exercise its discretion in a judicious manner, it can allow the appeal against the denial. If the SST-General Division allows the appeal on the issue of the denial, National Headquarters reviews the case to determine if there is a PCA. If there are no grounds for a PCA, the officer processes the request for reconsideration on the substantive issues as a new request for reconsideration and links the 2 files in ADMS. The substantive issues are reconsidered under EIA 112 .
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 

### Social Security Tribunal (SST)-General Division recommendations

Source topic: `en_EN/task/proc_sst/social_security_tribunal_sst-general_di_d3b420b4.dita`

The Commission’s refusal to write off an OP or penalty is not a decision that can be appealed under the EIA, but rather a financial and administrative matter to be resolved by the Chief Financial Officer Branch (CFOB) of the department and for which there is no appeal rights. However, if an appellant files an appeal with the SST-General Division on the Commission’s refusal to write off an OP or penalty, the SST-General Division can recommend that the Commission make suitable arrangements to recover the debt in instalments, or even to write it off. In these cases, the officer goes to Processing a Social Security Tribunal General Division recommendation for debt payment arrangements or a write-off after processing the notification of the SST-General Division decision.
       [Processing a Social Security Tribunal General Division recommendation for debt payment arrangements or a write-off](/en/procedure/task/proc_sst_debt.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4078.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4075.dita`

Note:

For appeals to the SST-General Division, the officer refers to Processing the notification of an Employment Insurance Board of Appeal decision .
       [Processing the notification of an Employment Insurance Board of Appeal decision](/en/procedure/task/trait-avis-dca-ae-proc-notification-eiboa.shtml)

     [Processing the notification of an Employment Insurance Board of Appeal decision](/en/procedure/task/trait-avis-dca-ae-proc-notification-eiboa.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4076.dita`

Note:

An allowed concession is not pursued as a PCA. However, the decision must still be reviewed before the officer can implement it. 

### Note

Source topic: `en_EN/common_notes/note_c_4077.dita`

Note:

Information may initially indicate that a PCA will be pursued and later indicate that it will not be pursued. This is because the decision to pursue the PCA is made in 2 stages. At the first stage, the senior appeals officer reviews the file and determines whether the case should be pursued. If the PCA is not pursued at this stage, the case is returned to the region for the decision to be implemented. If the senior appeals officer recommends pursuing the PCA, the case moves to the second stage.

At the second stage, the senior appeals officer presents the recommendation to the appeals committee for review. If the committee agrees, the PCA is pursued. Otherwise, the PCA is not pursued and the case is returned to the region for the decision to be implemented. 

### Note

Source topic: `en_EN/common_notes/note_c_4078.dita`

Note:

A recommendation from a Tribunal to write off a debt is not an appeal or a review of a decision that establishes the debt as stated in EIA 47(4) . Therefore, collection is reinstated in PSCD.
       [EIA 47(4)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-47.html)

     [EIA 47(4)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-47.html) 

## Regional considerations

Source topic: `en_EN/task/proc_sst/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/proc_sst/what_you_need_to_look_for.dita`

### In ADMS:

Source topic: `en_EN/task/proc_sst/in_adms.dita`

- What is the decision of the SST-General Division member?

- Was a collection of a debt suspended due to the appeal? 

### In the Common Document Share:

Source topic: `en_EN/task/proc_sst/in_the_common_document_share.dita`

- What is the decision of the SST-General Division member?

- Is there a memo from National Headquarters? 

### In PSCD:

Source topic: `en_EN/task/proc_sst/in_pscd.dita`

- Was a collection of a debt suspended due to the appeal? 

### In NWS:

Source topic: `en_EN/task/proc_sst/in_nws.dita`

- Is the issue under appeal an adjudication issue that was automatically resolved ( Resolve Issue screen) or automatically adjudicated? 

## Step by step

Source topic: `en_EN/task/proc_sst/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/proc_sst/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/proc_sst/reviewing_the_file_level_2.dita`

- In the Common Document Share, copy the SST-General Division decision and any additional documentation from the ToHRSDC-ADRHCC folder in the 5. SST exchange folder and paste them in the client’s Record folder in the 2. SST-GD-TSS-DG / BOA-CA regional folder.

- In the 5. SST exchange folder, delete the documentation sent by SST.

- Review the decision and do the following:

- If the appeal is dismissed or dismissed with modifications favourable to the Commission, go to Appeal dismissed .
               [Appeal dismissed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/proc_sst#dismissed)

- If the delayed appeal is denied, go to Delayed appeal denied .
               [Delayed appeal denied](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/proc_sst#denied)

- If the appeal is withdrawn, go to Appeal withdrawn .
               [Appeal withdrawn](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/proc_sst#withdrawn)

- If the appeal is allowed or dismissed with modifications not favourable to the Commission, go to step 4.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4076.dita)

- In ADMS, start completing the Review Decision tab as follows:

- Decision Result: Select the appropriate option:

- If the appeal is allowed, select Allowed .

- If the appeal is dismissed with modifications, select Dismissed with modifications .

- Date PCA sent to NHQ: Enter today’s date.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4079.dita)

- Wait until National Headquarters reviews the SST-General Division decision and determines if a PCA will be pursued:

- If a PCA is not pursued, in ADMS, in the PCA Review section , National Headquarters selects PCA Denied - implement decision in the Result field and enters the current date in the Denied PCA sent to APC field.

- If a PCA is pursued, in ADMS, in the PCA Review section , National Headquarters selects Possible Commission appeal or Commission appeal (blanket) in the Result field. No further action is required unless National Headquarters sends other instructions.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4080.dita)

- Review the memo from National Headquarters to determine if any particular information about how to implement the decision is required. Consider this accordingly when implementing the decision.

- In NWS, determine if the issue under appeal was automatically resolved ( Resolve Issue screen) or automatically adjudicated:

- If yes, go to step 8.

- If no, go to step 9.

- In NWS, invalidate the original decision as follows:

- Double-click the resolved issue in the Client information tree .

- Under Decision Options , select Decision no longer valid .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4081.dita)

- Create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)] — [allowed or allowed with modifications].”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- the action taken for the implementation;

- any impact on a previous decision or claim.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4082.dita)

- Determine if an appeal lock was applied to an OP or penalty while the SST reviewed the appeal:

- If no, go to step 11.

- If yes, refer to Reinstating the collection of a debt and go to step 11.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4083.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4084.dita)

- To implement the decision, make the necessary changes in the appropriate systems:

- If Level 1 support is necessary, go to step 12.

- If Level 1 support is not necessary, go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4085.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4086.dita)

- In NWS, create an Action Item (AI) WI as follows:

- Complexity: Select Level 1 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 1 support required.”

- Details: Enter the ADMS record number and the details of the required actions.

- Obtained on: Select today’s date.

- Source Details: Type “SST decision.”

- Urgent: Check the box.

- Wait until the work is completed at Level 1 and then go to step 14.

- In ADMS, on the Review Decision tab, complete the following field:

- Date decision implemented: Select today’s date. 

#### Appeal dismissed

Source topic: `en_EN/task/proc_sst/appeal_dismissed_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)].”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- the action taken for the implementation;

- any impact on a previous decision or claim.

- Determine if an appeal lock was applied to an OP or penalty while the SST reviewed the appeal:

- If no, go to step 3.

- If yes, refer to Reinstating the collection of a debt and go to step 3.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

- In ADMS, on the Review Decision tab, complete the following fields:

- Decision Result: Select Dismissed .

- Date decision implemented: Select today’s date. 

#### Delayed appeal denied

Source topic: `en_EN/task/proc_sst/delayed_appeal_denied_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — delayed appeal denied.”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- the action taken for the implementation;

- any impact on a previous decision or claim.

- Determine if an appeal lock was applied to an OP or penalty while the SST reviewed the appeal:

- If no, go to step 3.

- If yes, refer to Reinstating the collection of a debt and go to step 3.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

- In ADMS, on the Review Decision tab, complete the following fields:

- Decision Result: Select Delayed appeal denied .

- Date decision implemented: Select today’s date. 

#### Appeal withdrawn

Source topic: `en_EN/task/proc_sst/appeal_withdrawn_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)].”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- the action taken for the implementation;

- any impact on a previous decision or claim.

- Determine if an appeal lock was applied to an OP or penalty while the SST reviewed the appeal:

- If no, go to step 3.

- If yes, refer to Reinstating the collection of a debt and go to step 3.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

- In ADMS, on the Review Decision tab, complete the following fields:

- Decision Result: Select Withdrawn .

- Date withdrawal finalized: Select today’s date. 

#### Note

Source topic: `en_EN/common_notes/note_c_4079.dita`

Note:

This changes the status to Possible Commission Appeal, the required action to Assign SAO , and transfers the appeal to the national workload. National Headquarters reviews the decision to determine whether to pursue a PCA. It is important to do this input within 48 hours of receiving the decision, as the Commission has limited time to file an application for leave to appeal the SST-General Division decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_4080.dita`

Note:

If the Appeals committee later decides not to pursue the PCA, to implement the decision, go to step 6. 

#### Note

Source topic: `en_EN/common_notes/note_c_4081.dita`

Note:

The initial record of decision (ROD) must be invalidated in NWS as the ROE and the automatically resolved or automatically adjudicated ROD can be used when a claim is recalculated or when a new BPC is established. If the change is not made, benefits could be paid incorrectly during automation. 

#### Note

Source topic: `en_EN/common_notes/note_c_4082.dita`

Note:

If the allowed appeal has any impact on a previous decision or claim, create a WI in NWS and assign it to the appropriate level. 

#### Note

Source topic: `en_EN/common_notes/note_c_4083.dita`

Note:

If the decision results in the need to send an Operational Centre Memo (MM06) transaction to IPOC and if a related OP is suspended, do not reinstate the collection action. In the Operational Centre Memo (MM06) transaction, advise IPOC to terminate the lock on the date of the SST decision and apply any underpayments (UPs) to the OP. This ensures that when IPOC processes the decision, the debt is recovered from any potential monies payable. 

#### Note

Source topic: `en_EN/common_notes/note_c_4084.dita`

Note:

When inputting transactions related to an SST appeal, use OP detection code 22 - Appeal to the Social Security Tribunal (SST) / ≤ w/c 1867 Umpire . 

#### Note

Source topic: `en_EN/common_notes/note_c_4085.dita`

Note:

When a decision about a reason for separation (RFS) is changed, in addition to invalidating any automated RODs, change the Special Condition field on the ROE in RCM to reflect the correct decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_4086.dita`

Note:

If necessary, contact the client to obtain the information required to implement the decision (e.g. claimant’s reports). 

## Policy reference

Source topic: `en_EN/task/proc_sst/policy_reference.dita`

 
