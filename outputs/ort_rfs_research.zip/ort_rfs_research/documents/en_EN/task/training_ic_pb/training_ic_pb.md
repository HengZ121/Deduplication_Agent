# Adjudicating non-referred training: Parental benefits — Initial claim

Source map: `en_EN/task/training_ic_pb/training_ic_pb.ditamap`

## Summary

Source topic: `en_EN/task/training_ic_pb/summary.dita`

Summary: When a client reports non-referred training on the EI application or while an initial claim is in progress, adjudication is required to determine entitlement to benefits during the training period. 

## What you need to know

Source topic: `en_EN/task/training_ic_pb/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/task/training_ic_pb/training_reported_between_september_27__5ecd71c7.dita`

A transitional measure under which ACP automatically adjudicated and allowed all training effective September 27, 2020, has ended as of September 11, 2021. The intent of this measure was to prevent any delay in payment to clients who reported training.

The client must still meet the entitlement conditions for parental benefits while attending non-referred training. A client attending non-referred training may provide information on a claimant’s report or during a conversation with an agent that brings into question the entitlement to special benefits. In this case, the agent creates a WI for the training issue and follows normal adjudication procedures, even if ACP initially allowed the training. 

### Adjudication required on manually registered claims

Source topic: `en_EN/task/training_ic_pb/adjudication_required_on_manually_regis_d5cd9e4c.dita`

Training was automatically adjudicated and electronic records of decision (RODs) were created only on claims that were automated in ACP .

The agent manually registers claims that are not automated in ACP. Training is not automatically adjudicated on manually registered claims. Instead, ACP assigns an Adjudication Issue (ADJ) WI to an agent because it could not automate the decision. Adjudication of these training ADJ WIs is required , and the agent follows the appropriate procedures to resolve them. Even if ACP initially allowed training, when a training ADJ WI is assigned (e.g. upon renewal), the agent must adjudicate. Additionally, if it is determined that a disentitlement applies from the start date of the training course, the Level 2 agent imposes a retroactive D3. 

### Impact of training on parental benefits

Source topic: `en_EN/task/training_ic_pb/impact_of_training_on_parental_benefits.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4813.dita) 

When adjudicating non-referred training for a client receiving parental benefits, the issue is whether the client continues to care for the child for whom the benefits are payable. This includes clients who are attending short-term training courses and targeted initiatives. Refer to the job aid for a complete list of non-referred short-term courses and targeted initiatives.
       [job aid](/en/procedure/generic/additionalresources/shortterm_courses_ti.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4814.dita) 

### Targeted initiatives and short-term courses

Source topic: `en_EN/task/training_ic_pb/targeted_initiatives_and_short-term_courses.dita`

When clients report that they are attending a targeted initiative or short-term course, the total daily or weekly attendance hours is not considered. If the client is attending a short-term course referred under EIA 25, refer to Confirming referred training: Special benefits — Initial claim.
       [Confirming referred training: Special benefits — Initial claim.](/en/procedure/task/confirmreftrng_sb_in.shtml) 

### Levels of decision

Source topic: `en_EN/task/training_ic_pb/levels_of_decision.dita`

Level 1 is authorized to allow benefits when both of the following conditions are met:

- The training is under 25 hours per week.

- The training location is in the area where the client resides with the child.

There must be no doubt that the client is still providing care. If the client makes any statement that creates doubt that the client is providing care, the issue must be referred to Level 2. 

### Processing the claim

Source topic: `en_EN/task/training_ic_pb/processing_the_claim.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can process the claim. There is a Resolve Issue tab for ADJ Training WIs that includes screens where the agent documents the decision. When the ADJ WI is completed, the system creates a ROD based on the Resolve Issue screens. When the claim is established, the system also generates the required transactions (e.g. training information, disentitlement) based on the Resolve Issue screens. 

### Communicating the decision

Source topic: `en_EN/task/training_ic_pb/communicating_the_decision.dita`

If the training is not allowed and a disentitlement is imposed, the system creates a Correspondence WI for the N-00-00-00 letter. No letter is sent when the training is allowed. 

### Note

Source topic: `en_EN/common_notes/note_c_4813.dita`

Note:

If adjudication is part of a recalculation, the agent must refer to Adjudicating non-referred training: Parental benefits — Continuing claim .
       [Adjudicating non-referred training: Parental benefits — Continuing claim](/en/procedure/task/training_parental.shtml)

     [Adjudicating non-referred training: Parental benefits — Continuing claim](/en/procedure/task/training_parental.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4814.dita`

Note:

If a client quits employment or refuses an offer of employment to attend a non-referred training course, a non-referred short-term training course or a targeted initiative, agents must adjudicate the reason for separation on a separate WI. 

## Regional considerations

Source topic: `en_EN/task/training_ic_pb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/training_ic_pb/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/training_ic_pb/in_nws.dita`

- Was the training questionnaire completed?

- Is there an SROC or an Action Item (AI) WI with the training information, from either the Part-time Training checklist or the Training Course Information (INS3141) form? 

### In Imaging:

Source topic: `en_EN/task/training_ic_pb/in_imaging.dita`

- Is there non-referred training information or the INS3141 form? 

## Step by step

Source topic: `en_EN/task/training_ic_pb/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/training_ic_pb/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_ic_pb/reviewing_the_file_level_1.dita`

- Determine if the following non-referred training details are on file:

- Required details

- Number of hours of training per week (if the client is attending regular non-referred training)

- Location of the training

- Start date of training

- If not all of the training details are on file, go to step 2.

- If all of the training details are on file, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/training_ic_pb/fact-finding_level_1.dita`

- Fact-find with the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ic_pb#reassign)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue : Select Training .

- Comments : Type “Non-referred training — parental benefits.”

- Details : Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save. 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/training_ic_pb/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the client reported training in error:

- If the client did not report training in error, go to step 6.

- If the client reported training in error, go to Training reported in error .
               [Training reported in error](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ic_pb#TRainingDeclaredInError1)

- Determine the type of training the client is attending:

- If the client is attending a short-term training course or a targeted initiative, go to step 7.

- If the client is attending regular non-referred training, go to step 8.

- Determine if the short-term course or targeted initiative is at a location that requires the client to reside away from the child while attending:

- If the course or initiative is not at a location that requires the client to reside away from the child while attending, go to step 9.

- If the course or initiative is at a location that requires the client to reside away from the child while attending, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ic_pb#reassign)

- Determine if both of the following conditions are met:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4815.dita) 

- If both conditions are met, go to step 9.

- If either condition is not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ic_pb#reassign)

- Determine if the client has made any statement that creates doubt that the client is providing care for the child for whom the benefits are payable while on the non-referred training:

- If there is no doubt that the client is providing care for the child, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ic_pb#TrainingAllowedAtLevel1)

- If there is doubt that the client is providing care for the child, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ic_pb#reassign) 

#### Training reported in error

Source topic: `en_EN/task/training_ic_pb/training_reported_in_error_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Training screen as follows:

- Select The facts on file show training was declared in error by the client .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Entitlement conditions met

Source topic: `en_EN/task/training_ic_pb/entitlement_conditions_met_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Training screen as follows:

- Select B ased on the information on file, the criteria to allow the decision to be made at Level 1 have been met (National Policy on Levels of Decision) .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY) : Enter the end date.

- Verify the information on the Record of Decision screen presented:

- Check I agree .

- Complete the ADJ WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/training_ic_pb/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the WI as follows:

- Destination : Select Next Available User .

- Complexity : Select Level 2 .

- Reason : Select Unable to Complete .

- Details : Type the appropriate reason:

- “Unable to contact client for fact-finding.”

- “Not within Level 1 authority — the non-referred training is more than 25 hours per week.”

- “The non-referred training is at a location that requires the client to reside away from the child.”

- “There is doubt as to whether the client is providing care for the child while on non-referred training.”

- Select OK .

- When the Warning window is displayed, select Ok . 

#### Callout

Source topic: `en_EN/common_notes/note_c_4815.dita`

- Condition #1 : The non-referred training is less than 25 hours per week.

- Condition #2 : The non-referred training is not at a location that requires the client to reside away from the child while attending the course. 

### Level 2

Source topic: `en_EN/task/training_ic_pb/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_ic_pb/reviewing_the_file_level_2.dita`

- Determine if the non-referred training details are on file (e.g. number of hours of training per week if the client is attending regular non-referred training, and location of school):

- If additional details are needed, go to step 2. For help determining the questions to ask the client, refer to Digest 13.1.4 — To care for a child .
               [Digest 13.1.4 — To care for a child](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-13/parental-benefits-payments.html#a13_1_4)

- If additional details are not needed, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/training_ic_pb/fact-finding_level_2.dita`

- Fact-find with the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 5.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue : Select Training .

- Comments : Type “Non-referred training — parental benefits.”

- Details : Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating non-referred training

Source topic: `en_EN/task/training_ic_pb/adjudicating_non-referred_training_level_2.dita`

- Determine if the client reported training in error, completed the training course before the benefit period or is not attending training:

- If none of these conditions are met, go to step 6.

- If any of these conditions are met, go to Training not an issue .
               [Training not an issue](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ic_pb#TrainingNotAnIssue2)

- Adjudicate the non-referred training according to the entitlement principles of Digest 13.1.4 — To care for a child and determine if the client has met the entitlement conditions for parental benefits:

- If the client is engaged in non-referred training and has not met the entitlement conditions for parental benefits, go to Entitlement conditions not met .
               [Entitlement conditions not met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ic_pb#_Entitlement_conditions_not)

- If the client is engaged in non-referred training but has met the entitlement conditions for parental benefits, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_ic_pb#EngagedInNonReferredTRainingAllowed2) 

#### Training not an issue

Source topic: `en_EN/task/training_ic_pb/training_not_an_issue_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Training is not an issue .

- Select Continue .

- Complete the Training is not an issue screen as follows:

- Relevant Facts: Indicate why the training is not an issue.

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale: Select the reason why training is not an issue.

- References: Enter any additional references.

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Entitlement conditions not met

Source topic: `en_EN/task/training_ic_pb/entitlement_conditions_not_met_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Engaged in non-referred training.

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select the appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY) : Enter the end date.

- Complete the Engaged in non-referred training screen as follows:

- Relevant Facts:

- Indicate whether the client has completed the training course.

- Indicate whether the client voluntarily left employment to take the course and provide additional information if necessary.

- Summarize the evidence.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4816.dita) 

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale:

- Based on the evidence, is it determined that the client’s involvement in training prevents him or her from providing care or support for the child/ren?: Select Yes .

- Enter any additional rationale information.

- References: Enter any additional references.

- Decision: Select Not allowed - Disentitlement, parental benefits, entitlement conditions not met (D-34) .

- Disentitlement start: Select the appropriate option:

- Select BPC .

- Select Specific date and enter the start date (Monday to Friday).

- Disentitlement end: Select the appropriate option:

- If the training has ended, select the corresponding end date of the disentitlement.

- If the training has not ended, select Indefinite .

- Overpayment: Review and, if required, modify the prefilled Detection , Infraction and Message fields.

- Select Continue .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4718.dita)

- Verbally communicate the decision to the client.

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Parental benefits denied or suspended.

- Parental benefits denied or suspended - D34/D35/D56/D57/Free text (3074): Select Text: Explain why parental benefits not payable .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select the appropriate option and select the disentitlement dates.

- Text - Insert appropriate reason(s) (1618): Type “You have not proven that you are caring for your child while attending a course of instruction on your own initiative.”

- Overpayment Messages (2452)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note and type “Send the saved N-00-00-00 letter.”

- Complete the ADJ WI. 

#### Entitlement conditions met

Source topic: `en_EN/task/training_ic_pb/entitlement_conditions_met_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Engaged in non-referred training.

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select the appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY) : Enter the end date.

- Complete the Engaged in non-referred training screen as follows:

- Relevant Facts:

- Indicate whether the client has completed the training course.

- Indicate whether the client voluntarily left employment to take the course and provide additional information if necessary.

- Summarize the evidence.

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4816.dita) 

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale:

- Based on the evidence, is it determined that the client’s involvement in training prevents him or her from providing care or support for the child/ren? Select No .

- Enter any additional rationale information.

- References: Enter any additional references.

- Decision: Select Allowed - care entitlement condition is met .

- Select Continue .

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4816.dita`

Note:

If the client voluntarily left employment to take the course, that issue must be adjudicated and resolved in a separate WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4718.dita`

Note:

If the decision is the result of an Integrity case, the prefilled overpayment codes must be changed to match the Report of Investigation. 

## Policy reference

Source topic: `en_EN/task/training_ic_pb/policy_reference.dita`

- Digest 10.12.2 — Persons attending courses on their own initiative
         [Digest 10.12.2 — Persons attending courses on their own initiative](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2)

- Digest 13.1.4 — To care for a child
         [Digest 13.1.4 — To care for a child](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-13/parental-benefits-payments.html#a13_1_4)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
