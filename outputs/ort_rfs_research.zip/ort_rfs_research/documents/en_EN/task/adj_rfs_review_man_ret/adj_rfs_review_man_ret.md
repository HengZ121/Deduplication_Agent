# Actioning an Adjudication Issue RFS Review WI: G - Mandatory retirement

Source map: `en_EN/task/adj_rfs_review_man_ret/adj_rfs_review_man_ret.ditamap`

## Summary

Source topic: `en_EN/task/adj_rfs_review_man_ret/summary.dita`

Summary: When an ROE is received with a reason for separation (RFS) G - Mandatory retirement , and the RFS sub-option is blank, an Adjudication Issue (ADJ) RFS Review WI is created. The system cannot create a link between the ROE and the matching period of employment reported on the initial EI application. 

## What you need to know

Source topic: `en_EN/task/adj_rfs_review_man_ret/what_you_need_to_know.dita`

### Conditions for creating the WI

Source topic: `en_EN/task/adj_rfs_review_man_ret/conditions_for_creating_the_wi.dita`

When none of the periods of employment reported on the application have a contentious RFS, or when all the periods of employment with a contentious RFS are already linked to an ROE, an ADJ RFS Review WI is created. 

### Reviewing the reason for separation (RFS)

Source topic: `en_EN/task/adj_rfs_review_man_ret/reviewing_the_reason_for_separation_rfs.dita`

There may be comments on the ROE.

Human rights legislation in Canada prohibits mandatory retirement. This legislation applies to most employment. Some employers may be able to demonstrate a genuine reason for mandatory retirement, but these cases are rare.

Employers are instructed to choose G - Mandatory retirement as the RFS only in cases of mandatory retirement, and to choose E - Quit in cases of voluntary retirement (includes approved workforce reductions ).
       [approved workforce reductions](/en/procedure/task/vl_wr_ic.shtml)

A mandatory retirement cannot be considered as voluntary leaving. In cases where clients do not voluntarily leave their employment, the separation is initiated by the employer. A Level 2 officer must adjudicate the RFS as a dismissal.

When an ADJ RFS Review WI is received, the Level 1 officer reviews the information on file and fact-finds with the interested parties to determine if the RFS is contentious and requires adjudication. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/adj_rfs_review_man_ret/determining_if_the_file_must_be_referre_f4ff817e.dita`

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

## Regional considerations

Source topic: `en_EN/task/adj_rfs_review_man_ret/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/adj_rfs_review_man_ret/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/adj_rfs_review_man_ret/in_nws.dita`

- Are there are any SROCs, WIs or other documentation containing details related to the RFS? 

### In Imaging:

Source topic: `en_EN/task/adj_rfs_review_man_ret/in_imaging.dita`

- Are there any documents related to the RFS? 

### In RCM:

Source topic: `en_EN/task/adj_rfs_review_man_ret/in_rcm.dita`

- Are there comments in block 18 of the ROE? 

## Step by step

Source topic: `en_EN/task/adj_rfs_review_man_ret/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/adj_rfs_review_man_ret/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/adj_rfs_review_man_ret/reviewing_the_file_level_1.dita`

- Review all documentation on file related to the RFS, including ROE comments. 

#### Fact-finding

Source topic: `en_EN/task/adj_rfs_review_man_ret/fact-finding_level_1.dita`

- Fact-find with the employer and, if necessary, the client, to clarify if the RFS is a mandatory retirement.

- Determine if the employer or client was contacted during fact-finding:

- If yes, go to step 4.

- If no, go to Unable to determine if adjudication is required .
               [Unable to determine if adjudication is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_rfs_review_man_ret#NotContacted)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Clarification — [employer’s name] — [last day worked] — [employer or client].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if adjudication is required

Source topic: `en_EN/task/adj_rfs_review_man_ret/determining_if_adjudication_is_required_level_1.dita`

- Determine if the retirement was mandatory:

- If yes, go to Adjudication required — Mandatory retirement.
               [Adjudication required — Mandatory retirement.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_rfs_review_man_ret#mandatoryRetirement)

- If no, go to step 6.

- Determine if the RFS is contentious:

- If yes, go to step 7.

- If no, go to Adjudication required — Non-contentious reason for separation (RFS) .
               [Adjudication required — Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_rfs_review_man_ret#NotContentious) 

#### Adjudication required — Contentious reason for separation (RFS)

Source topic: `en_EN/task/adj_rfs_review_man_ret/adjudication_required__contentious_reas_3e96d163_level_1.dita`

- In NWS, on the Specific Details tab, update the ADJ RFS Review WI as follows:

- Issue: Select the appropriate RFS.

- Select Save .

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 9.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- To determine the next steps to resolve the ADJ WI, refer to the appropriate adjudication activity ( Dismissal , Labour dispute , Leave of absence , Voluntary leaving ). 

#### Unable to determine if adjudication is required

Source topic: `en_EN/task/adj_rfs_review_man_ret/unable_to_determine_if_adjudication_is_required_level_1.dita`

- In NWS, on the Specific Details tab, update the ADJ RFS Review WI as follows:

- Issue: Select Quit .

- Select Save .

- Reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Unable to reach employer or client in order to clarify RFS.”

- Select OK .

- When the Warning window is displayed, select OK . 

#### Adjudication required — Mandatory retirement

Source topic: `en_EN/task/adj_rfs_review_man_ret/adjudication_required__mandatory_retirement_level_1.dita`

- In NWS, on the Specific details tab, update the ADJ RFS Review WI as follows:

- Issue: Select Dismissal .

- Select Save .

- Reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “RFS is mandatory retirement, which must be adjudicated as a dismissal — not within Level 1 authority.”

- Select OK .

- When the Warning window is displayed, select OK . 

#### Adjudication not required — Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/adj_rfs_review_man_ret/adjudication_not_required__non-contenti_e8b0f7ad_level_1.dita`

- In RCM, update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select the applicable RFS option.

- Select Validate .

- Select Submit .

- Determine if the ROE was flagged in error after validation:

- If yes, fix the validation error, and go to step 9. For procedures on correcting an ROE, refer to Completing an ROE Correction WI — Regular ROE .
               [Completing an ROE Correction WI — Regular ROE](/en/procedure/task/completing_roe_correction_regular.shtml)

- If no, go to step 9.

- In NWS, complete the ADJ RFS Review WI. 

## Policy reference

Source topic: `en_EN/task/adj_rfs_review_man_ret/policy_reference.dita`

- Digest 6 — Voluntary leaving employment
         [Digest 6 — Voluntary leaving employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/table-of-contents.html)

- Digest 7 — Misconduct
         [Digest 7 — Misconduct](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-7/table-of-contents.html) 
