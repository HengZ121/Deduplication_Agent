# Actioning an Adjudication Issue RFS Review WI: B - Other

Source map: `en_EN/task/adj_rfs_review_b_other/adj_rfs_review_b_other.ditamap`

## Summary

Source topic: `en_EN/task/adj_rfs_review_b_other/summary.dita`

Summary: When an ROE is received with a reason for separation (RFS) B - Other , an Adjudication Issue (ADJ) RFS Review WI is created. The system cannot create a link between the ROE and the matching period of employment reported on the initial EI application. 

## What you need to know

Source topic: `en_EN/task/adj_rfs_review_b_other/what_you_need_to_know.dita`

### Conditions for creating the WI

Source topic: `en_EN/task/adj_rfs_review_b_other/conditions_for_creating_the_wi.dita`

When none of the periods of employment reported on the application has a contentious RFS, or when all the periods of employment with a contentious RFS are already linked to an ROE, an ADJ RFS Review WI is created. 

### Reviewing the reason for separation (RFS)

Source topic: `en_EN/task/adj_rfs_review_b_other/reviewing_the_reason_for_separation_rfs.dita`

When an ADJ RFS Review WI is received, the Level 1 officer reviews the information on file and, if necessary, fact-finds with the interested parties to determine if the RFS is contentious and requires adjudication.

There are only 2 RFS options on a paper fishing ROE: A - End of fishing and B - Other . There are 3 RFS options on a Web fishing ROE: A - End of fishing, A - Requested by Fisher and B - Other . In RCM, all 3 options are available when inputting a fishing ROE.

When fact-finding confirms that the RFS is not contentious, the situation is considered to be equivalent to a shortage of work. In RCM, the RFS is changed to A - End of fishing or A - Requested by Fisher and the ADJ RFS Review WI is completed. In NWS, the Adjudication issue status displays RFS Review - Fishing ROE - Resolved .

If the RFS is a labour dispute, the RFS on the fishing ROE is B - Other . The ADJ WI issue is changed from RFS Review to Strike or Lockout . In NWS, the Adjudication issue status changes to Strike or Lockout - Outstanding . To resolve the ADJ WI, the officer refers to Labour dispute .
       [Labour dispute](/en/procedure/activity/labour_dispute.shtml)

If the RFS is neither a labour dispute nor equivalent to a shortage of work, refusal of employment may be an issue. Fishers are required to accept suitable work in fishing when it is offered. In this case, the RFS on the ROE is B - Other . An ADJ Availability WI is created so that a Level 2 officer can adjudicate the refusal of employment. The officer completes the ADJ RFS Review WI, and the Adjudication issue status displays RFS Review - Fishing ROE - Resolved .

If the RFS on the last ROE is left as B - Other , the claim trips down after all adjudication issues have been resolved.

If the officer is unable to contact the employer or client to clarify the RFS, the officer completes the WI. If the claim trips down, the officer with the Claim Assessment (CA) WI determines if there is a claim procedure issue. If the claim is automated, no further action is required on the RFS. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/adj_rfs_review_b_other/determining_if_the_file_must_be_referre_f4ff817e.dita`

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

## Regional considerations

Source topic: `en_EN/task/adj_rfs_review_b_other/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/adj_rfs_review_b_other/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/adj_rfs_review_b_other/in_nws.dita`

- Are there are any SROCs, WIs or other documentation containing details related to the RFS? 

### In Imaging:

Source topic: `en_EN/task/adj_rfs_review_b_other/in_imaging.dita`

- Are there any documents related to the RFS? 

### In RCM:

Source topic: `en_EN/task/adj_rfs_review_b_other/in_rcm.dita`

- Are there comments in block 12 of the ROE? 

## Step by step

Source topic: `en_EN/task/adj_rfs_review_b_other/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/adj_rfs_review_b_other/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/adj_rfs_review_b_other/reviewing_the_file_level_1.dita`

- Determine if there is information on file that allows to determine the RFS:

- If no, go to step 2.

- If yes, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/adj_rfs_review_b_other/fact-finding_level_1.dita`

- To determine the RFS, fact-find with the employer, the client or both.

- Determine if the employer or client or was contacted during fact-finding:

- If yes, go to step 4.

- If no, go to Unable to determine if adjudication is required .
               [Unable to determine if adjudication is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_rfs_review_b_other#NotContacted)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Clarification — [employer’s name] — [last day worked] — [employer or client].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if adjudication is required

Source topic: `en_EN/task/adj_rfs_review_b_other/determining_if_adjudication_is_required_level_1.dita`

- Determine the RFS:

- If the RFS is a labour dispute, go to step 6.

- If the RFS is equivalent to a shortage of work, go to Adjudication not required — Non-contentious reason for separation (RFS) .
               [Adjudication not required — Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_rfs_review_b_other#ShortageOfWork)

- If the RFS is not a labour dispute or equivalent to a shortage of work, go to Adjudication required — Possible refusal of employment .
               [Adjudication required — Possible refusal of employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_rfs_review_b_other#PossibleWorkRefusal) 

#### Adjudication required — Contentious reason for separation (RFS)

Source topic: `en_EN/task/adj_rfs_review_b_other/adjudication_required__contentious_reas_3e96d163_level_1.dita`

- In NWS, on the Specific details tab, update the ADJ RFS Review WI as follows:

- Issue: Select Strike or Lockout .

- Select Save .

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 8.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- To determine the next steps required to resolve the ADJ WI, refer to Labour dispute . 

#### Unable to determine if adjudication is required

Source topic: `en_EN/task/adj_rfs_review_b_other/unable_to_determine_if_adjudication_is_required_level_1.dita`

- In NWS, complete the ADJ RFS Review WI. 

#### Adjudication not required — Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/adj_rfs_review_b_other/adjudication_not_required__non-contenti_e8b0f7ad_level_1.dita`

- In RCM, update the ROE as follows:

- Block 11: Select A - End of fishing or A - Requested by Fisher .

- Select Validate .

- Select Submit .

- Determine if the ROE was flagged in error after validation:

- If yes, fix the validation error, and go to step 8. For procedures on correcting an ROE, refer to Completing an ROE Correction WI — Fishing ROE .
               [Completing an ROE Correction WI — Fishing ROE](/en/procedure/task/completing_roe_correction_fisher.shtml)

- If no, go to step 8.

- In NWS, complete the ADJ RFS Review WI. 

#### Adjudication required — Possible refusal of employment

Source topic: `en_EN/task/adj_rfs_review_b_other/adjudication_required__possible_refusal_5cc98902_level_1.dita`

- In NWS, create an ADJ WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Destination — SCC: Enter the Service Canada Center (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue(s): Select Availability .

- Details: Type “ The RFS on ROE [serial number] is not a labour dispute or shortage of work. Adjudication of possible refusal of employment is required. This is not within Level 1 authority.”

- Complete the ADJ RFS Review WI. 

## Policy reference

Source topic: `en_EN/task/adj_rfs_review_b_other/policy_reference.dita`

- Digest 15.9.1 — Disqualifications and disentitlements
         [Digest 15.9.1 — Disqualifications and disentitlements](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-15/unemployment-fishers.html#a15_9_1)

- Digest 15.10.0 — Labour dispute
         [Digest 15.10.0 — Labour dispute](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-15/labour-dispute.html#a15_10_0) 
