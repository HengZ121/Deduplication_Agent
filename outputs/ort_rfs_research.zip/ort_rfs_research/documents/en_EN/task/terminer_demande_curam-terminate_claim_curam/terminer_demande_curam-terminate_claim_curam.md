# Terminating a claim – Cúram

Source map: `en_EN/task/terminer_demande_curam-terminate_claim_curam/terminer_demande_curam-terminate_claim_curam.ditamap`

## Summary

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/summary.dita`

Summary: During the assessment of a claim or while actioning a client request, the officer may need to determine if it is appropriate to terminate a claim. 

## What you need to know

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4788.dita) 

In Cúram, the benefit period (BP) is referred to as a Product Delivery Case (PDC). The PDC is the period in which clients can claim the weeks of benefits they are entitled to. The PDC contains all the evidence the officer needs to determine if the client is eligible and entitled for that claim.

When a client requests the termination of a claim or when a renewal claim is not as beneficial to the client as a new claim, the officer determines if the existing claim can be terminated. In Cúram, terminating a claim is referred to as overriding the BP. When a claim is terminated, the SE earnings cannot be used again to establish a new claim. 

### Reviewing a benefit period when the client requests the termination of an established claim

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/reviewing_a_benefit_period_when_the_cli_7b8c2bb6.dita`

When a client contacts the call center to request the termination of an established claim, an AI WI is created in NWS. In these cases, the officer contacts the client to obtain all required information and documentation to determine if the client qualifies for a new claim and meets the conditions for termination of the existing claim. 

### Reviewing a benefit period when a client submits an application and there is an established claim

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/reviewing_a_benefit_period_when_a_clien_0ad4a7c1.dita`

In Cúram, a Call-Back task is created when a client submits an application for benefits but has an established claim with entitlement weeks remaining. The client is asked on the application if they would like to renew their existing claim. If yes, the Renewal requested by client – Call back required – Task in Cúram task is created. If no, the Renewal NOT requested by client – Call back required – Cúram task is created.
       [Renewal requested by client – Call back required – Task in Cúram](/en/procedure/task/ren-dem-client-rr-curam-ren-request-client-cbr-curam.shtml) 
       [Renewal NOT requested by client – Call back required – Cúram](/en/procedure/task/renouve-non-client_renewal-not-client.shtml)

If the client requests to renew their existing claim, the officer contacts the client to complete the renewal checklist Renewal: Special benefits for Self-employed People (Part VII.1 Claims) and obtains all required information and documentation. To renew the claim, the officer submits the Renewal evidence transaction in Cúram.
       [Renewal: Special benefits for Self-employed People (Part VII.1 Claims)](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Renewal-Special_benefits_for_Self-Employed_People_(Part%20VII.1%20Claims)-Checklist.doc)

If the client requests to start a new claim, the officer determines if the existing claim can be cancelled or terminated and whether the client qualifies for a new claim. If the client does not qualify for a new claim or it is disadvantageous to start a new claim, the officer contacts the client to complete the renewal checklist Renewal: Special benefits for Self-employed People (Part VII.1 Claims) , obtains all required information and documentation and renews the claim.  If the client qualifies for a new claim and it is advantageous to start a new claim (e.g. the client qualifies for a higher benefit rate), the officer submits the Override Benefit Period transaction. Once the existing claim is cancelled or terminated, the officer advises the client to complete a new paper application.
       [Renewal: Special benefits for Self-employed People (Part VII.1 Claims)](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Renewal-Special_benefits_for_Self-Employed_People_(Part%20VII.1%20Claims)-Checklist.doc) 

### Conditions to terminate a claim

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/conditions_to_terminate_a_claim.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4789.dita) 

A claim can be terminated when a new claim can be established. Before terminating a claim, the officer ensures that the client qualifies for the new claim. To establish a new claim, there must be an interruption of earnings (I of E).

To terminate the existing claim, the officer determines if the client qualifies to establish a new claim. If the client cannot be reached during fact-finding, the existing claim cannot be terminated and is renewed instead. 

### Refusing to terminate a claim when there is no new claim

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/refusing_to_terminate_a_claim_when_ther_bde5a218.dita`

If the client requests the termination of the claim but cannot or does not want to establish a new claim, the officer does not terminate the claim.

Pilot project no. 24: Waiving the waiting period (WP) for BPCs between March 30 and April 11, 2026 (w/c 2493 to w/c 2546)

A temporary measure to waive the one-week WP has been implemented to support clients impacted by major changes in economic conditions due to the imposition of tariffs by the United States. The WP is waived for all initial claims with a BPC between March 30, 2025 (w/c 2493) and April 11, 2026 (w/c 2546), regardless of the requested benefit type (BT). If it is advantageous to the client, the client can decide to serve the WP (e.g. the client must serve the WP to receive supplemental unemployment benefits [SUB]).

A client who established a new EI claim within the last 52 weeks and still has weeks payable on that claim can decide to renew the existing claim or request to terminate the existing claim to submit a new claim under Pilot Project 24. Existing policies for terminating a claim apply and clients who request a termination instead of a renewal must meet the conditions to terminate a claim.

For more information, the officer refers to Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions. 

### Advantages and disadvantages of terminating a claim

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/advantages_and_disadvantages_of_termina_2df9e2f0.dita`

Terminating a claim can be advantageous to a client because the new claim could be established with a higher amount of SE earnings in the new qualifying period (QP). The new claim could also allow a client to qualify for additional benefits.

Claim termination can also cause certain disadvantages. By terminating the existing claim and establishing a new claim, the QP may contain fewer SE earnings. As a result, the client could receive a lower benefit rate compared to a renewal of the claim followed by the establishment of a new claim. The client could also lose access to weeks of benefits that were potentially payable on the terminated claim. The officer assesses these possibilities. 

### Inputting the claim termination

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/inputting_the_claim_termination.dita`

The claim is terminated by submitting the Override Benefit Period evidence in Cúram. 

### Note

Source topic: `en_EN/common_notes/note_c_4788.dita`

Note:

While the inputs to terminate or cancel a claim are similar, it is important to understand the distinction between terminating and cancelling a claim. 

### Note

Source topic: `en_EN/common_notes/note_c_4789.dita`

Note:

Before terminating a claim, the officer first considers cancelling the claim. The officer can refer to Cancelling a claim – Cúram .
       [Cancelling a claim – Cúram](/en/procedure/task/annuler-demande-curam-cancel-claim-curam.shtml)

     [Cancelling a claim – Cúram](/en/procedure/task/annuler-demande-curam-cancel-claim-curam.shtml) 

## Regional considerations

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/what_you_need_to_look_for.dita`

### In NWS

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/in_nws.dita`

- Is the client requesting the termination or cancellation of a claim?

- Has the client submitted an application to renew a claim?

- Is there documentation of verbal notice regarding the end of the disentitlement (e.g. an SROC or ROD)? 

### In Cúram

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/in_curam.dita`

- Is there an established claim?

- If yes, have benefits been paid or are benefits payable?

- Is there a disentitlement on the claim from BPC?

- If yes, has it recently ended, and have benefits been paid since?

- Has a renewal week been input?

- What are the special benefit windows?

- What is the benefit rate?

- What is the LRW in the claim?

- What is the remaining entitlement for the claim?

- Are there any ongoing allocations?

- Are there any disentitlements on the claim?

- Has the WP been served, waived or deferred?

- Has a suspension been imposed to prevent payment?

- Are any fraud indicators present? 

## Step by step

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/level_1.dita`

#### Terminating a claim

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/terminating_a_claim_level_1.dita`

- Fact-find with the client:

- Ask if the client intends to apply for a new claim.

- If no, advise the client that the existing claim cannot be terminated and will be renewed (refer to Renewal requested by client – Call back required – Task in Cúram to complete the renewal). Go to step 9.

- Obtain either the estimated or actual SE earnings in the QP and refer to Earnings: Minimum and maximum self-employed earnings and maximum benefit rate — Table and Self-employed: Information on calculation and entitlement to special benefits — Knowledge to determine if the client would qualify for a new claim.

- If the client meets the minimum SE earnings requirement, keep the client on the telephone and go to step 2.

- If the client is unable to provide the requested information at this time, keep the client on the telephone and go to step 2.

- If the client does not meet the minimum SE earnings requirement, go to step 9.

               [Earnings: Minimum and maximum self-employed earnings and maximum benefit rate — Table](/en/procedure/generic/additionalresources/min_max_se_ti.shtml) 
               [Self-employed: Information on calculation and entitlement to special benefits — Knowledge](/en/procedure/generic/benefits_se_knowledge.shtml)

- If the client was not contacted or did not reply to the N-10-00-00 letter, Claim not terminated .
               [Claim not terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminer_demande_curam-terminate_claim_curam#_Claim_not_terminated)

- Determine if the client has reduced the time normally devoted to SE activities by more than 40% (I of E):

- If yes, keep the client on the telephone and go to step 3.

- If the client is unable to confirm an I of E at this time, keep the client on the telephone and go to step 3.

- If no, go to step 9 .
               [#_Claim_not_terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminer_demande_curam-terminate_claim_curam#_Claim_not_terminated)

- Determine if the client has a valid agreement that has been in place for at least 12 months at the time of the BPC and that the agreement is not terminated or deemed to be terminated (confirm with the client and review the Evidence Dashboard in the Application Case ):

- If yes, keep the client on the telephone and go to step 4.

- If no, go to step 9.

- Determine if the client would qualify for a new claim based on the SE earnings in the QP, the I of E and the agreement information provided:

- If the client is unable to provide some or all the requested information at this time, do the following:

- Advise the client this information is required to determine if the existing claim can be terminated and a new claim can be established

- Provide the officer’s contact information and the date the client must provide the requested information by (today’s date + 10 business days).

- Go to step 5.

- If yes, do the following:

- Refer the client to visit an SCC to complete a paper application for self-employed persons (fastest option). If the client is unable to visit in person, advise the client to complete and return the paper application that will be mailed to the address on file.

- Advise the client:

- Go to step 5.

- If no, advise the client that the existing claim cannot be terminated and will be renewed (refer to Renewal requested by client – Call back required – Task in Cúram to complete the renewal). Go to step 9.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4790.dita) 
               [Renewal requested by client – Call back required – Task in Cúram](/en/procedure/task/ren-dem-client-rr-curam-ren-request-client-cbr-curam.shtml)

- In NWS, add details to the draft external SROC created during fact-finding or create a new external SROC as follows:

- Determine if the client provided the requested information:

- In Cúram, defer the task as follows:

- When the task moves to the current workload, determine if the client obtained the requested information:

- In NWS, add details to the draft external SROC created during fact-finding or create a new external SROC as follows:

- BPC: Type the BPC.

- Main Issue: Select Other .

- Comments: Type “Claim termination.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Go to Claim not terminated
               [Claim not terminated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminer_demande_curam-terminate_claim_curam#_Claim_not_terminated)

- Determine if the client will visit an SCC to complete the paper application:

- If no, go to step 11.

- If yes, go to step 14.

- Locally print the INS5236: Application for Employment Insurance Benefits for Self-Employed Persons .

- In ACS, create and send the Q-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Info Requested Re: ROE / RFS / Conflicting statements / Undeliverable Mail / More Info required (2876) .

- Select: Request for Additional Information Re: Entitlement .

- Text – Specify instructions to claimant (1548) .

- Type “Complete and return the INS5236 form.”

- Message re BF Date-if not received may delay claim (2897) .

- Date of BF (Date letter sent + 10 business days) (1540).

- Attachment List for Q-01/00/00 (3120).

- Text - Specify the attachment(s) (1546): Type “Application for Employment Insurance Benefits for Self-Employed Persons INS5236.”

- Select Local printing .

- Attach the paper application to the printed Q-01-00-00 letter and send them to the client.

- In Cúram, create a record of decision (ROD) as follows:

- From the client’s home screen, select Cases and Applications from the navigation bar.

- Select the appropriate reference number and select Contacts from the navigation bar.

- Select Notes from the menu on the left-hand side and select New Note from the right-hand side.

- From the New Note window, complete the following fields:

- Subject: Type “Termination of claim BPC [BPC].”

- Priority: Select Medium .

- Sensitivity: Select 1 .

- Text: Type “Claim with BPC [BPC] terminated. Client qualifies to establish a new claim.”

- Select Save .

- Terminate the claim as follows:

- Search for the client with their Social Insurance Number (SIN) in the search bar at the top of the screen.

- Select the client’s name to display the Person Evidence Case.

- Select the Cases and Applications tab from the navigation bar.

- Select the Reference Number for the Case Name: Employment Insurance Program Benefits to open the Product Delivery Case.

- Select the Evidence tab of the Product Delivery Case from the navigation bar.

- Select Override Benefit Period.

- When the New Override Benefit Period window opens, select Terminate and enter the termination date (must be a Saturday).

- Select Save .

- Select the ellipses (…) in the top right corner of the Evidence tab.

- From the drop-down menu, select Apply Changes .

- In Cúram, complete the task or return to your previous task. 

#### Claim not terminated

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/claim_not_terminated_level_1.dita`

- In Cúram, create a record of decision (ROD) as follows:

- From the client’s home screen, select Cases and Applications from the navigation bar.

- Select the appropriate reference number and select Contacts from the navigation bar.

- Select Notes from the menu on the left-hand side and select New Note from the right-hand side.

- From the New Note window, complete the following fields:

- Subject: Type “Termination of the BPC [BPC].”

- Priority: Select Medium .

- Sensitivity: Select 1 .

- Text: Type “BPC [BPC] not terminated.” Include the reason the claim was not terminated (e.g. the client does not qualify on a new claim, unable to contact to obtain a paper application etc.).

- Select Save .

- Determine if the client was verbally advised that the claim is not being terminated requested:

- If no, go to step 3.

- If yes, go to step 4.

- In ACS, create and send an F-00-00-00 letter, advising the client of the decision:

- In the Free text (1612) field, type one of the following:

- If the client does not qualify to establish a new claim, type “We are writing to inform you that we cannot terminate your claim for Employment Insurance benefits that began on [BPC of the existing claim], because you do not qualify to establish a new one.”

- If the client was not reached, type “We are writing to inform you that we cannot terminate your claim for Employment Insurance benefits that began on [BPC of the existing claim], as we were unable to reach you to obtain required information.”

- Refer to Renewal requested by client – Call back required – Task in Cúram to complete the claim renewal. 

#### Note

Source topic: `en_EN/common_notes/note_c_4790.dita`

Note:

If the client intends to visit an SCC, the officer advises the client that an appointment may be required. 

## Policy reference

Source topic: `en_EN/task/terminer_demande_curam-terminate_claim_curam/policy_reference.dita`

 
