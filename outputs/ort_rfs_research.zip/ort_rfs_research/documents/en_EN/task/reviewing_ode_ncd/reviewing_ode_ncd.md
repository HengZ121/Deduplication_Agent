# Reviewing the original decision that established a now non collectable debt

Source map: `en_EN/task/reviewing_ode_ncd/reviewing_ode_ncd.ditamap`

## Summary

Source topic: `en_EN/task/reviewing_ode_ncd/summary.dita`

Summary: When a client with a non collectable debt reports a change of address, the original decision must be reviewed to determine if it is within the reconsideration timeframes. If benefits have been suspended due to the undeliverable Notice of Debt, the officer must also review the suspension of benefits. 

## What you need to know

Source topic: `en_EN/task/reviewing_ode_ncd/what_you_need_to_know.dita`

### Processing an undeliverable Notice of Debt from the Canada Revenue Agency (CRA)

Source topic: `en_EN/task/reviewing_ode_ncd/processing_an_undeliverable_notice_of_d_17faaa19.dita`

When the CRA receives a Notice of Debt as undeliverable and is unable to locate the client, a CRA officer inputs an undeliverable mail indicator ( $ ) in the Name and address field. In PSCD, an N - Undeliverable notice of debt lock is automatically imposed to the debt to suspend debt collection.

**National Policy on Undeliverable Notices of Debts**

The National Policy on Undeliverable Notices of Debts specifies that a client must be notified of a decision involving an overpayment (OP) or penalty within the reconsideration timeframes to recover the debt.
       [National Policy on Undeliverable Notices of Debts](/en/policy/nationalpolicy/nationalpolicy_undeliverable_debts.shtml)

**Imposing a disentitlement or manual action (MA)**

If the client has an active claim, a 48 - Moved - address unknown disentitlement (D48) or a 48 - Stop payment due to undeliverable mail manual action (MA48) is also imposed by the officer to suspend the payment of benefits. 

### Inputting a subsequent change of address

Source topic: `en_EN/task/reviewing_ode_ncd/inputting_a_subsequent_change_of_address.dita`

When a subsequent change of address without the undeliverable mail indicator ( $ ) is input, a WI is referred to Level 2 to review the original decision. When a D48 or an MA48 has been imposed, the suspension of benefits is also reviewed.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4645.dita) 

### Reviewing the original decision after a change of address

Source topic: `en_EN/task/reviewing_ode_ncd/reviewing_the_original_decision_after_a_b9895d22.dita`

The Level 2 officer must review the original decision that created the debt to determine if it is within the reconsideration timeframes. According to the National Policy on Undeliverable Notices of Debts , all of the steps in the decision-making process of reconsideration must be conducted within specific timeframes. This includes notifying the client of the decision that created the debt. The debt can be recovered only when the client has been notified of it.
       [National Policy on Undeliverable Notices of Debts](/en/policy/nationalpolicy/nationalpolicy_undeliverable_debts.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4646.dita) 

The decision to create EI Emergency Response Benefit (EI ERB) advance payment debts ( ERB2 - CERB Advance Payment ) was made under EIA 52. To determine if the original decision is still within the reconsideration timeframes, the officer uses the date that the advance payment was issued.

**All weeks covered are within the reconsideration timeframes**

If all weeks covered by the decision are within the reconsideration timeframes, no changes are required to the original decision. In ACS, the Level 2 officer modifies the original decision letters to undeliverable and issues new decision letters. Since the original decision does not change, the officer does not input any new transactions in FTS or BCS. Therefore, the Level 2 officer needs to establish a new debt in PSCD based on the original decision and adjusts the original debt to $0. This process also applies to penalties. This changes the posting date in PSCD and adjusts the limitation date accordingly. PSCD automatically generates a new Notice of Debt to notify the client, and resumes recovery.

**Some weeks covered are outside the reconsideration timeframes**

If some of the weeks covered by the decision are outside of the reconsideration timeframes, the Level 2 officer must change the original decision to remove the original debt and render a new decision. The Level 2 officer:

- renders a new decision;

- changes the status of the original decision letters in ACS to undeliverable;

- issues the appropriate decision letters;

- inputs all transactions required for the reconsideration of the original decision, and modifies the violation, if necessary; l

- ensures that the transactions from the original decision have been deleted.

Since the OP transactions are input through FTS or BCS, no inputs are necessary in PSCD to change the OP. The transactions in FTS or BCS will generate the adjustment to the existing debt and create the new debt. If the original decision included a penalty, the Level 2 officer manually inputs the transactions for the penalty in PSCD.

PSCD automatically generates a new Notice of Debt to notify the client and resumes recovery.

**All weeks covered are outside the reconsideration timeframes**

If all of the weeks covered by the decision are outside of the reconsideration timeframes, the Level 2 officer:

- does the necessary inputs in FTS or BCS to remove the original decision from the systems;

- manually adjusts any penalties in PSCD;

- Changes the status of the original decision letters in ACS to undeliverable.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1479.dita) 

**Adjusting debts that were originally created in DARS**

In some cases, the debt being reviewed was originally created in DARS. When debts are converted from DARS to PSCD, only the active balance is transferred. This means that a debt that was originally created in DARS might have been entirely or partially converted to PSCD.

If the total amount of the debt was converted from DARS to PSCD, the officer can adjust the debt to 0$ directly in PSCD.

If the debt was partially converted from DARS to PSCD, the officer can also adjust the debt to 0$ in PSCD. Officers working for the National Accounts Receivable take the appropriate actions to have the balance of the debt in DARS adjusted and any payments that occurred in DARS applied to the new debt that was created by the officer in PSCD.

Example:

- The original debt in DARS was $1 000.

- The client repaid $250 in DARS.

- The balance converted to PSCD is $750.

The client never received the Notice of Debt and, after reviewing the file, the officer determines that the original decision is still valid. A new debt needs to be established and the balance in PSCD needs to be cancelled. The officer first re-establishes the debt associated with the original decision by creating a new debt of $1 000 in PSCD and then adjusts the converted balance ($750) in PSCD by the value of the original debt (–$1 000). This cancels the debt. An officer from the National Accounts Receivable will to transfer the payment of $250 that occurred in DARS to the new debt. 

### Violation

Source topic: `en_EN/task/reviewing_ode_ncd/violation.dita`

If the original decision includes a violation, the officer updates the notice of violation date when resending the notice of decision. On the Violation (ML01) transaction in FTS, the officer adds a new Notification week and rescinds the one that was initially entered. 

### Reviewing the suspension of benefits

Source topic: `en_EN/task/reviewing_ode_ncd/reviewing_the_suspension_of_benefits.dita`

When a client reports a change of address following the imposition of a D48 or a MA48, the officer must review the suspension of benefits.

**Change of address within the 6-week timeframe**

When a client without a Failure to report indicator reports a change of address within 6 weeks of the imposition of a D48 or a MA48, it is considered a correction of information previously omitted or submitted. To have a D48 or a MA48 rescinded, the client must request the correction of information previously omitted or submitted within 6 weeks.

The suspension of benefits can be rescinded when the following conditions are met:

- The client does not have a Failure to report indicator.

- The client reports the change of address within 6 weeks of the D48 or MA48 being imposed.

The officer must review the suspension of benefits to determine if it can be rescinded or if a definite disentitlement is applicable for the period of the delay.

**Change of address after the 6-week timeframe and claimant’s reports still submitted**

Clients are required to provide Service Canada with their current address to be entitled to benefits. When the client has not contacted Service Canada for a period of over 6 weeks and has been submitting claimant’s reports, the reason for the delay must be adjudicated taking into consideration whether the client’s explanation for the delay in providing the mailing address is reasonable based on the client’s actions and the circumstances. When the client’s explanation for the delay is not reasonable, a definite D48 applies. The officer must also determine whether it can be proven that misrepresentation was knowingly made.

**Change of address and Failure to report indicator on file**

When the client is not requesting payment during the weeks of the D48 or MA48 and a Failure to report indicator is present, a definite D48 is applicable.

When the client is requesting payment during the weeks of the D48 or MA48 and a Failure to report indicator is present, the officer must adjudicate 2 issues: claim procedure and the antedate situation (refer to Claimant’s reports ). Clients are required to show good cause for delay in contacting Service Canada to submit claimant’s reports. When the client does not show good cause for the delay and the client’s explanation of the delay in providing a mailing address is not reasonable, a definite D48 is applicable.
       [Claimant’s reports](/en/procedure/activity/claimant_report.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4645.dita`

Note:

If an undeliverable mail indicator ($) was not present in FTS before the change of address, refer to Reviewing a claim with benefits suspended due to undeliverable mail .
       [Reviewing a claim with benefits suspended due to undeliverable mail](/en/procedure/task/reviewing_claim_ben_un_mail.shtml)

     [Reviewing a claim with benefits suspended due to undeliverable mail](/en/procedure/task/reviewing_claim_ben_un_mail.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4646.dita`

Note:

As of October 20,2025, electronic Notices of Debt are now in use.

Clients with debts who opt for electronic delivery automatically receive email notifications and can access their debt statements in their MSCA inbox. These clients no longer receive paper statements. Instead, they are notified by email whenever a new statement is available.

A Notice of Debt is considered delivered once it is deposited into the MSCA inbox and made accessible to the client. To determine the statement delivery method, the officer refers to the Display Interaction History screen in PSCD. The indicator at the bottom left of the monthly statement of account or the Notice of Debt is P if the document was mailed, or E if it was issued electronically. 

### Note

Source topic: `en_EN/common_notes/note_c_1479.dita`

Note:

Because the system created the OPs for the advance payments, there are no transactions related to the decisions to adjust in FTS or BCS. If the OP is outside of the reconsideration timeframe, the original debt is adjusted to $0 in PCSD. 

## Regional considerations

Source topic: `en_EN/task/reviewing_ode_ncd/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/reviewing_ode_ncd/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/reviewing_ode_ncd/in_nws.dita`

- Is there a Claim Review (CR) WI or an Action Item (AI) WI?

- Is the client requesting the processing of late claimant’s reports? 

### In FTS:

Source topic: `en_EN/task/reviewing_ode_ncd/in_fts.dita`

- Before the change of address, was an undeliverable mail indicator ($) present?

- Is there is a Failure to report indicator on the claim?

- When was a D48 or a MA48 imposed?

- Has the client been completing claimant’s reports since the D48 or MA48 was imposed?

- If yes, has the client indicated on the claimant’s reports that there has been no change of address?

- Is the original decision still within the reconsideration timeframes?

- Is there a violation related to the undeliverable Notice of Debt?

- If yes, does the violation date need to be modified? 

### In ACS:

Source topic: `en_EN/task/reviewing_ode_ncd/in_acs.dita`

- Does the original notice of decision have an undeliverable status? 

## Step by step

Source topic: `en_EN/task/reviewing_ode_ncd/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/reviewing_ode_ncd/level_2.dita`

#### Reviewing the original decision

Source topic: `en_EN/task/reviewing_ode_ncd/reviewing_the_original_decision_level_2.dita`

- In accordance with the National Policy on Undeliverable Notices of Debts and Digest 17.3.1 — Reconsideration (EIA 52 and policy ) review the original decision that created the debt and determine if it is within the reconsideration timeframes.

- If any or all of the weeks covered by the decision fall outside the reconsideration timeframes, changes are required to the original decision. Go to step 2.

- If all of the weeks covered by the decision are within the reconsideration timeframes, no change is required to the original decision. Go to step 3.

- Render the new decision(s), taking into account the new timeframes. Refer to the applicable activity as required for additional information to render the decision (e.g. Unreported earnings , Not unemployed , Out of Canada ). 

#### Reviewing the suspension of benefits

Source topic: `en_EN/task/reviewing_ode_ncd/reviewing_the_suspension_of_benefits_level_2.dita`

- Determine if a D48 or a MA48 is imposed:

- If yes, go to step 4.

- If no, go to step 8.

- Determine if there is enough information to adjudicate the suspension of benefits imposed when the undeliverable Notice of Debt was received:

- If additional details are needed, fact-find with the client, referring to the Undeliverable Mail (and/or disentitlement for moved address unknown) checklist as required, and go to step 5.
               [fact-find](/en/procedure/task/fact_find.shtml) 
               [Undeliverable Mail (and/or disentitlement for moved address unknown)](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Undeliverable_mail-Disentitlement_D48_or_indicator_for_address_unknown-Checklist.doc)

- If additional details are not needed, go to step 7.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 6.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 7.

- In NWS, add to the draft SROC or create a new SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “D48 or MA48.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy and any additional details.
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Adjudicate the suspension of benefits due to the D48 or MA48 according to Digest 16.3.0 — Proof required – Section 49 of the Act , Digest 16.4.0 — Entitlement to benefits – Section 50 of the Act , Digest 18 — Policy on penalties , EIA 49 , EIA 50 and EIR 26 . 

#### Record of decision (ROD)

Source topic: `en_EN/task/reviewing_ode_ncd/record_of_decision_rod_level_2.dita`

- In NWS, create a ROD for each contentious issue that was reviewed as follows:

- Comments: Type the appropriate comments based on the decision.

- If no changes were required to the original decision because the weeks were all within the reconsideration timeframes, type “Undeliverable Notice of Debt — no changes required to original decision.”

- If changes were required to the original decision because some of the weeks fell outside the reconsideration timeframes, type “Undeliverable Notice of Debt — original decision removed and a new decision rendered.”

- If changes were required to the original decision because all of the weeks fell outside the reconsideration timeframes, type “Undeliverable Notice of Debt — original decision removed.”

- If a definite D48 is to be imposed, type “Undeliverable Notice of Debt — Definite D48 imposed. Allowed from w/c [XXXX].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 

#### Determining the inputs required for the original decision

Source topic: `en_EN/task/reviewing_ode_ncd/determining_the_inputs_required_for_the_431742e5_level_2.dita`

- Determine if changes are required to the original decision:

- If no, go to No changes required to the original decision .
               [No changes required to the original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#level2_item_5)

- If yes, go to Changes required to the original decision
               [Changes required to the original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#level2_item_6) 

#### No changes required to the original decision

Source topic: `en_EN/task/reviewing_ode_ncd/no_changes_required_to_the_original_decision_level_2.dita`

- In ACS, if necessary, modify the original decision letter status to undeliverable.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1480.dita)

- In FTS, if there is no registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In PSCD, create a new OP with the value of the original OP:

- Refer to Creating a debt in PSCD and go to step 4.
               [Creating a debt in PSCD](/en/procedure/task/creating_a_debt_in_pscd.shtml)

- In PSCD, adjust the original OP amount to $0:

- Refer to Adjusting a debt in PSCD and then go to step 5.
               [Adjusting a debt in PSCD](/en/procedure/task/adjusting_a_debt_in_pscd.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1481.dita)

- Determine if the original decision under review includes a penalty:

- If yes, go to step 6.

- If no, go to step 8.

- Input a new penalty based on the original decision. Refer to Creating a debt in PSCD for the necessary inputs and return to step 7 of this task.

- Adjust the original penalty to $0. Refer to Adjusting a debt in PSCD for the necessary inputs and return to step 8 of this task.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4647.dita)

- Determine if there is a violation on the claim:

- If no, go to step 9.

- If yes, in FTS, select the Violation (ML01) transaction, add a new notification week and rescind the one that was initially entered as follows:

- Action: Select Add .

- Notification week: Select the current w/c.

- BPC: Select the same BPC that was initially selected.

- Imposed by: Select 1 - Agent .

- Warning Letter: Select 1 - Violation - warning letter issued .

- Actual OP: Enter the potential OP as initially entered, if necessary.

- Potential OP: Enter the potential OP as initially entered, if necessary.

- Select Update .

- Rescind the original Notification week as follows:

- Select the original violation.

- Action: Select Rescind .

- Select Update .

- In ACS, create and send the new decision letters to replace the decision letters whose status was changed to undeliverable.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4648.dita)

- Determine if a D48 or an MA48 is imposed:

- If a D48 is not imposed, complete the WI.

- If a D48 or a MA48 is imposed go to Determining if inputs are required for a suspension of benefits .
               [Determining if inputs are required for a suspension of benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#level2_item_10) 

#### Changes required to the original decision

Source topic: `en_EN/task/reviewing_ode_ncd/changes_required_to_the_original_decision_level_2.dita`

- Determine if the OP being reviewed is for an EI ERB advance payment ( ERB2 – CERB Advance Payment ):

- If no, go to step 2.

- If yes, go to Changes required to the EI Emergency Response Benefit (EI ERB) advance payment original decision
               [Changes required to the EI Emergency Response Benefit (EI ERB) advance payment original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#level2_item_7)

- In ACS, if necessary, modify the original decision letter status to undeliverable.

- In FTS, if there is no registration number, select Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In PSCD and DARS, determine if any recoupments have been applied against the OP:

- If no, go to step 5.

- If yes, go to Operational Centre Memo (MM06) required for the original decision .
               [Operational Centre Memo (MM06) required for the original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#level2_item_8)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 6.

- If the claim is terminated and cannot be reactivated, or if it is blocked or archived, go to step 11.

- If the claim is terminated and can be reactivated, do the following:

- On the Dormant tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 6.

- In FTS, enter all transactions required for the reconsideration of the original decision, including modifying the violation, if necessary. Ensure that the transactions from the original decision have been deleted in the following order:

- On day 1, remove the original decision.

- On day 2, enter the new decision.

- Determine if the original decision included a penalty:

- If yes, go to step 8.

- If no, to resend the notice of decision, go to step 12.

- If necessary, input a new penalty based on the new decision. Refer to Creating a debt in PSCD and return to step 9 of this task.

- Adjust the original penalty to $0. Refer to Adjusting a debt in PSCD for the necessary inputs and return to step 10 of this task.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4647.dita)

- To resend the notice of decision, go to step 12.

- Determine the blocked claim’s status by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed, go to BCS inputs required for the original decision .
               [BCS inputs required for the original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#level2_item_9)

- If 2 - Not blocked is displayed, return to step 5.

- If any other status is displayed, go to Operational Centre Memo (MM06) required for the original decision .
               [Operational Centre Memo (MM06) required for the original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#level2_item_8)

- Determine if there is a violation on the claim:

- If no, go to step 13.

- If yes, in FTS, select the Violation (ML01) transaction, add a new Notification week and rescind the one that was initially entered as follows:

- Action: Select Add .

- Notification week: Select the current w/c.

- BPC: Select the BPC that was initially selected.

- Imposed by: Select 1 - Agent .

- Warning Letter: Select 1 - Violation - warning letter issued .

- Actual OP: Enter the potential OP as initially entered, if necessary.

- Potential OP: Enter the potential OP as initially entered, if necessary.

- Select Update .

- To rescind the original Notification week :

- Select the original violation.

- Action: Select Rescind .

- Select Update .

- In ACS, send a new decision letter to replace the decision letter whose status was changed to undeliverable.

- In NWS, complete the WI. 

#### Changes required to the EI Emergency Response Benefit (EI ERB) advance payment original decision

Source topic: `en_EN/task/reviewing_ode_ncd/changes_required_to_the_ei_emergency_re_e9339dc7_level_2.dita`

- In FTS, if there is no registration number, select Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In PSCD, adjust the original OP amount to $0:

- Refer to Adjusting a debt in PSCD and then go to step 3.
               [Adjusting a debt in PSCD](/en/procedure/task/adjusting_a_debt_in_pscd.shtml)

- Determine if a D48 or an MA48 is imposed:

- If a D48 is not imposed, complete the WI.

- If a D48 or a MA48 is imposed go to Determining if inputs are required for a suspension of benefits .
               [Determining if inputs are required for a suspension of benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#level2_item_10) 

#### Operational Centre Memo (MM06) required for the original decision

Source topic: `en_EN/task/reviewing_ode_ncd/operational_centre_memo_mm06_required_f_ef0194c4_level_2.dita`

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Detection: Select the detection code that was used for the original decision.

- Infraction: Select the infraction code that was used for the original decision.

- Message: Select the OP message code that was used for the original decision.

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 91 - Overpayment .

- Work type: Select the appropriate option:

- 1 - Misrepresentation

- 2 - Non misrepresentation

- Remarks line 1: Type “ Undeliverable Notice of Debt. Rescind decision input on [DD-MM-YYYY] or MM06 dated [DD-MM-YYYY].”

- Remarks line 2: Type “W/cs [XXXX] to [XXXX] are now outside of the reconsideration period.”

- Remarks line 3: Type “Re-input the OP for remaining weeks at current date.” If there is also a penalty, provide the following information:

- P: penalty percentage, including mitigating circumstances

- LMR: 1st, 2nd or 3rd level of misrepresentation (for the penalty percentage)

- MPA: maximum penalty amount

- LVA: legal validation amount

- VLN: violation information (V-1-1 warning letter issued or 0 penalty imposed)

- Integrity case number

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and send the new decision letters to replace the decision letters whose status was changed to undeliverable.

- Determine if a D48 or a MA48 is imposed:

- If a D48 is not imposed, complete the WI.

- If a D48 or a MA48 is imposed go to Determining if inputs are required for a suspension of benefits .
               [Determining if inputs are required for a suspension of benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#level2_item_10) 

#### BCS inputs required for the original decision

Source topic: `en_EN/task/reviewing_ode_ncd/bcs_inputs_required_for_the_original_decision_level_2.dita`

- In BCS, review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 2.

- If all rows are blank, go to step 5.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable status in BCS.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 2.

- If all of the rows are blank, go to step 4.

- In FTS, select the BPC to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select Active claim default (50%) for non-misrepresentation or Blocked claim system default (100%) for misrepresentation .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- Determine the result of the reconsideration decision:

- If the decision results in changes to a disentitlement, go to step 6.

- If the decision results in changes to unreported earnings, go to step 8.

- If the decision results in changes to an unreported allocation of earnings, go to step 9.

- If the decision results in changes to a disqualification, go to step 11.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4649.dita)

- On day 1, in BCS, on the Disentitlements tab, rescind the original disentitlement as follows (up to 4 disentitlements can be imposed, rescinded or terminated in BCS at a time):

- Action: Select Rescind .

- Type: Select the type used to establish the original decision.

- Start date: Enter the start date used to establish the original disentitlement.

- End date: Enter the end date used to establish the original disentitlement.

- Detection: Select the detection code used to establish the original disentitlement.

- Infraction: Select the infraction code used to establish the original disentitlement.

- Message: Select the message code used to establish the original disentitlement.

- Select Update .

- On day 2, if necessary, in BCS, on the Disentitlements tab, input the new disentitlement as follows (up to 4 disentitlements can be imposed, rescinded or terminated in BCS at a time):

- Action: Select A - Add .

- Type: Select the type used to establish the original disentitlement.

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Detection: Select the detection code used to establish the original disentitlement.

- Infraction: Select the infraction code used to establish the original disentitlement.

- Message: Select the message code used to establish the original disentitlement.

- Select Update .

- Go to step 14.

- In BCS, on the Allocation “A” tab, enter the amended earnings as follows:

- Select the week to change. Repeat for every week that requires a change.

- On day 1, enter the original data for all weeks that are included in the original decision.

- On day 2, re-input the earnings for weeks that are still in the reconsideration period.

- Amended earnings: Enter the new amount of earnings.

- FWW: Select the new FWW code (if a change is required).

- Detection: Select the same detection code that was used for the original decision.

- Infraction: Select the same infraction code that was used for the original decision.

- Message: Select the same OP message code that was used for the original decision.

- Select Update .

- Go to step 14.

- In BCS, on the Allocations tab, rescind the original allocation as follows:

- Action: Select Rescind .

- Type: Select the type used to establish the original allocation.

- Start date: Select the start date used to establish the original allocation.

- Detection: Select the detection code used to establish the original allocation.

- Infraction: Select the infraction code used to establish the original allocation.

- Message: Select the message code used to establish the original allocation.

- Select Update .

- If a new allocation is required, go to step 10.

- If a new allocation is not required, go to step 14.

- Enter the allocation in the Allocations section as follows:

- Action: Select A - Add .

- Type: Select the appropriate allocation type.

- Amount: Enter the amount allocated per week.

- Start date: Enter the start date of the allocation.

- End date: Enter the end date of the allocation or 9999 if the end date is indefinite.

- Last week amount: Select the appropriate option:

- If the allocation amount in the last week is less than the normal weekly earnings, enter that amount.

- If the allocation amount in the last week is equal to the normal weekly earnings, leave the box empty.

- Detection: Select the detection code used to establish the original allocation.

- Infraction: Select the infraction code used to establish the original allocation.

- Message: Select the message code used to establish the original allocation.

- Select Update .

- Go to step 14.

- In BCS, on the Disqualifications tab, rescind the original disqualification as follows (up to 3 disqualifications in BCS can be imposed or rescinded at a time):

- Action: Select Rescind .

- Type: Select the type used to establish the original disqualification.

- Effective Week: Select the effective week used to establish the original disqualification.

- Number of Weeks: Select the number of weeks used to establish the original disqualification.

- Detection: Select the detection code used to establish the original disqualification.

- Infraction: Select the infraction code used to establish the original disqualification.

- Message: Select the message code used to establish the original disqualification.

- Select Update .

- In BCS, if necessary, on the Disqualifications tab, impose the new disqualification as follows (up to 3 disqualification can be imposed, rescinded or terminated in BCS at a time):

- Action: Select A - Add .

- Type: Select the type used to establish the original disqualification.

- Start date: Enter the start date of the disqualification.

- End date: Enter the end date of the disqualification or 9999 if the end date is indefinite.

- Detection: Select the detection code used to establish the original disqualification.

- Infraction: Select the infraction code used to establish the original disqualification.

- Message: Select the message code used to establish the original disqualification.

- Select Update .

- In RCM, determine if the ROE is on file:

- If the ROE is not on file, go to step 14.

- If the ROE is on file, update the Special condition field to reflect the reconsideration decision on the reason for separation (RFS). Go to step 14.

- In BCS, on the Pending Transactions tab, review the transaction and do the following:

- If the transaction shown is incorrect, check the Delete box next to the incorrect transaction and select Update . Return to step 5.

- If the transaction shown is correct and another change is required based on the reconsideration of the original decision, return to step 5.

- If the transaction shown is correct and another change is not required based on the reconsideration of the original decision, select Close and go to step 15.

- Determine if the original decision included a penalty:

- If yes, go to step 16.

- If no, to resend the notice of decision, go to step 18.

- If necessary, input a new penalty based on the new decision. Refer to Creating a debt in PSCD and return to step 17 of this task.

- Adjust the original penalty to $0. Go to Adjusting a debt in PSCD for the inputs and go to step 18.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4647.dita)

- Determine if there is a violation on the claim:

- If no, go to step 19.

- If yes, in FTS, select the Violation (ML01) transaction, add a new Notification week and rescind the one that was initially entered as follows:

- Action: Select Add .

- Notification week: Select the current w/c.

- BPC: Select the BPC that was initially selected.

- Imposed by: Select 1 - Agent .

- Warning Letter: Select 1 - Violation - warning letter issued .

- Actual OP: Enter the potential OP as initially entered, if necessary.

- Potential OP: Enter the potential OP as initially entered, if necessary.

- Select Update .

- Rescind the original Notification week :

- Select the original violation.

- Action: Select Rescind .

- Select Update .

- In ACS, create and send the new decision letters to replace the decision letters whose status was changed to undeliverable.

- Determine if a D48 or a MA48 is imposed:

- If a D48 is not imposed, complete the WI.

- If a D48 or a MA48 is imposed, go to Determining if inputs are required for a suspension of benefits .
               [Determining if inputs are required for a suspension of benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#level2_item_10) 

#### Determining if inputs are required for a suspension of benefits

Source topic: `en_EN/task/reviewing_ode_ncd/determining_if_inputs_are_required_for__3e54a822_level_2.dita`

- Determine if a D48 or a MA48 is imposed:

- If no, go in NWS, complete the WI.

- If yes, follow the appropriate procedure:

- Benefits allowed for the previously suspended period .
                   [Benefits allowed for the previously suspended period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#_Benefits_allowed_for_1)

- Benefits not allowed for the previously suspended period .
                   [Benefits not allowed for the previously suspended period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_ode_ncd#_Benefits_not_allowed_1) 

#### Benefits allowed for the previously suspended period

Source topic: `en_EN/task/reviewing_ode_ncd/benefits_allowed_for_the_previously_sus_0af14ca2_level_2.dita`

- In FTS, if there is no revised registration number, select Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if a D48 or a MA48 is imposed:

- If a D48 is imposed, go to step 3.

- If a MA48 is imposed, go to step 4.

- Select the Disqualifications/Disentitlements link to rescind the D48 as follows:

- Select the original D48 disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following:

- Registration number: Select the applicable registration number.

- Action: Select X - Rescind .

- Disentitlement: Select 48 - Moved - address unknown .

- Detection: Select 31 - Other .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 5.

- Select the Renewal/Revised (M106) transaction and rescind the MA48 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 48 - Stop payment due to undeliverable mail .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if any other mail was returned undeliverable:

- If yes, go to step 6.

- If no, go to step 9.

- From the appropriate electronic system (e.g. ACS, FTS, Imaging), print a copy of the undeliverable mail.

- Address an envelope with the client’s new address, insert the undeliverable mail and send it to the client.

- In NWS, create an SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “Undeliverable mail re-sent.”

- Details: Type “[Kind of undeliverable mail] initially sent [insert date] — re-sent to the client’s new address.”

- Select Save .

- In NWS, complete the WI. 

#### Benefits not allowed for the previously suspended period

Source topic: `en_EN/task/reviewing_ode_ncd/benefits_not_allowed_for_the_previously_6f53664a_level_2.dita`

- In FTS, if there is no revised registration number, select Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if a D48 or a MA48 is imposed:

- If a D48 is imposed, go to step 3.

- If a MA48 is imposed, go to step 4.

- Select the Disqualifications/Disentitlements link to terminate the D48 as follows:

- Select the original D48 disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following:

- Registration number: Select the applicable registration number.

- Action: Select T - Terminate/Modify .

- Disentitlement: Select 48 - Moved - address unknown .

- Detection: Select 31 - Other .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 6.

- Select the Renewal/Revised (M106) transaction and rescind the MA48 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 48 - Stop payment due to undeliverable mail .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- Select the Subsequent Decision Disqualifications/Disentitlements (M161) transaction and complete the following:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 48 - Moved - address unknown .

- Detection: Select 31 - Other .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D48 – Moved – Address unknown (B3007) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- Determine if any other mail was returned undeliverable:

- If yes, go to step 8.

- If no, go to step 11.

- From the appropriate electronic system (e.g. ACS, FTS, Imaging), print a copy of the undeliverable mail.

- Address an envelope with the client’s new address, insert the undeliverable mail and send it to the client.

- In NWS, create an SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “Undeliverable mail re-sent.”

- Details: Type “[Kind of undeliverable mail] initially sent [insert date] — re-sent to the client’s new address.”

- Select Save .

- In NWS, complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1480.dita`

Note:

OPs for EI ERB advance payments (contract object type ERB2 - CERB Advance Payment ) created starting November 2021 do not have a letter of decision in ACS. 

#### Note

Source topic: `en_EN/common_notes/note_c_1481.dita`

Note:

If an outstanding balance was converted to PSCD, adjust the debt in PSCD by the amount of the original debt in DARS. 

#### Note

Source topic: `en_EN/common_notes/note_c_4647.dita`

Note:

To rescind the penalty in PSCD, enter the original penalty amount preceded by the minus sign (–) in the Amount field. 

#### Note

Source topic: `en_EN/common_notes/note_c_4648.dita`

Note:

Exceptionally, the notices of decision for EI ERB advance payment debts (contract object type ERB2 - CERB Advance Payment ), created in November 2021 and later, are sent with the Notice of Debt. When the debt is recreated in PSCD, the notice of decision and Notice of Debt are sent. No action in ACS is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_4649.dita`

Note:

When a reconsideration requires multiple transactions, input them in the following order:

- indefinite disentitlement

- definite disentitlement

- unreported earnings and allocations of earnings

- indefinite disqualification

- definite disqualification 

## Policy reference

Source topic: `en_EN/task/reviewing_ode_ncd/policy_reference.dita`

- EIA 10(5)
         [EIA 10(5)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-10.html)

- EIA 49
         [EIA 49](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-49.html)

- EIA 50
         [EIA 50](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-50.html)

- Digest 3 — Antedate
         [Digest 3 — Antedate](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-3/table-of-contents.html)

- Digest 16.3.0 — Proof Required – Section 49 of the Act
         [Digest 16.3.0 — Proof Required – Section 49 of the Act](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-16/introduction.html#a16_3_0)

- Digest 16.4.0 — Entitlement to Benefits –Section 50 of the Act
         [Digest 16.4.0 — Entitlement to Benefits –Section 50 of the Act](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-16/introduction.html#a16_4_0)

- Digest 17.3.1 — Limitations under EIA 52
         [Digest 17.3.1 — Limitations under EIA 52](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/reconsideration.html#a17_3_1)

- Digest 18 — Policy on penalties
         [Digest 18 — Policy on penalties](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/table-of-contents.html)

- Digest Section 18.3.4.2 — Error Correction
         [Digest Section 18.3.4.2 — Error Correction](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/misrepresentation.html#a18_3_4_2)

- National Policy on Undeliverable Notices of Debts
         [National Policy on Undeliverable Notices of Debts](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/nationalpolicy_undeliverable_debts.shtml) 
