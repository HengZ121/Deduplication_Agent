# Archived: Determining if there is labour force attachment in SSA

Source map: `en_EN/task/calc_calculating/labour_force/labour_force.ditamap`

## Summary

Source topic: `en_EN/task/calc_calculating/labour_force/summary.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0394.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#archived)

Summary: SSA displays the Labour Force Attachment prompter screen when the UIC program determines the client is a new entrant/re-entrant (NERE) qualifier with between 420 and 909 insurable hours in the qualifying period (QP) .
       [new entrant/re-entrant (NERE)](/en/procedure/generic/knowledge.shtml) 
       [qualifying period (QP)](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-1/qualifying-period.shtml#a1_2_1) 

### Warning

Source topic: `en_EN/common_notes/note_c_0394.dita`

**This page has been archived on the Web**

UPDATED: 2024-05-15 — This page has been archived because the information is outdated.

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available. 

## What you need to know

Source topic: `en_EN/task/calc_calculating/labour_force/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_calculating/labour_force/untitled_section.dita`

If the LFA prompter is displayed, you must review the claim for any additional weeks of LFA that fall into the NERE qualifying period. The client may have given information about previous insurable employment for which there is no ROE on file. In addition, the workforce history section of the application may contain other weeks of LFA.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2225.dita) 

If the LFA requirement is not met, as indicated upon completion of the LFA prompter, and UIC finds an allocation of wage loss insurance or workers’ compensation benefits, a message is displayed on the SSA Calculation Result on File screen to alert you that additional LFA hours may be present (Refer to Reviewing the calculation result — Messages .)
       [Reviewing the calculation result — Messages](/en/procedure/generic/rcr_screen_messages.shtml)

Once you determine that the LFA requirement is met with 490 or more hours, there is no need to look at further conditions of LFA. For example, if you find weeks of disqualification that bring the LFA total to more than 489 hours, there is no need to look for ROEs in Easy Access, other prescribed weeks or weeks of employment declared by the client.

The step-by-step procedure provides a logical sequence for determining the LFA hours. However, if you recognize that one of the following sections provides the required hours, you may go directly to that section:

- Checking for Quebec Parental Insurance Plan
         [Quebec Parental Insurance Plan](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#qpip)

- Checking for prior disqualification
         [prior disqualification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#wksdisqual)

- Checking for ROEs in Easy Access
         [ROEs in Easy Access](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#easyaccess)

- Checking for other prescribed weeks
         [other prescribed weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#prescribedweeks)

- Checking for the client’s statement of employment
         [statement of employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#otherep)

Plotting the LFA on the calculation worksheet or using the SSA Calculation Worksheet helps in determining LFA hours and in ensuring that no more than 35 hours are allowed in each week unless the actual number of hours of insurable employment is greater than 35 hours.
       [calculation worksheet](/resources/ort/documents/calc_worksheet.xls) 

### Defining LFA

Source topic: `en_EN/task/calc_calculating/labour_force/defining_lfa.dita`

LFA for regular or special benefits claims paid under Part 1 of the EI Act is defined as hours that relate to insurable employment in the labour force.
       [Part 1 of the EI Act](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/index.html)

**Insurable employment**

For EI purposes, the hours that are considered related to insurable employment are as follows:

- hours of insurable employment

- fishing employment earnings that are converted to hours

**Prescribed weeks**

In addition, each of the following prescribed weeks ( EIR 12 ) is equal to 35 LFA hours:
       [EIR 12](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-8.html)

- a week in which EI benefits were paid

- a week in which the waiting period was served
         [waiting period](/en/procedure/generic/knowledge.shtml)

- a week during a benefit period where high earnings (insurable or non-insurable) prevented payment of EI benefits

- a week during a benefit period where a disqualification prevented payment of EI benefits

- a week in which QPIP benefits were paid

- a week in which the client participated in Commission-authorized referred training, a Commission-authorized self-employment program or a Commission-authorized job creation program

- a week in which the client participated in a labour dispute

- a week in which preventative withdrawal payments were paid due to loss of insurable employment

- a week in which wage loss insurance was paid due to loss of insurable employment

- a week in which workers’ compensation benefits were paid, other than a permanent settlement, due to loss of insurable employment 

### Calculating LFA

Source topic: `en_EN/task/calc_calculating/labour_force/calculating_lfa.dita`

For calculation purposes, you must look for the number of LFA hours that fall in the new entrant/re-entrant (NERE) qualifying period, defined as the 52-week period immediately prior to the qualifying period.

The hours in a week of insurable employment are credited hour for hour.

When fishing employment is used to determine LFA for a regular claim (benefits paid under Part 1 of the EI Act ), the earnings are converted to hours using the hourly minimum wage for the province of employment in effect at the time of the employment.
       [Part 1 of the EI Act](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/index.html) 
       [hourly minimum wage](http://srv116.services.gc.ca/dimt-wid/sm-mw/menu.aspx?lang=eng)

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2223.dita) 

For each of the other prescribed weeks ( EIR 12 ), 35 hours are credited regardless of the number of days in the week for which the client was paid, or in which the client was participating in one of the qualifying LFA activities.
       [EIR 12](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-12.html)

If more than one LFA condition applies to a week, the client is credited with 35 hours unless the actual insured hours are higher . For example, if the client worked 36 hours and received one day of workers’ compensation benefits payments in the same week, the client is credited with 36 hours. Conversely, if the client worked for 10 hours and received one day of workers’ compensation benefits payments during the same week, the client is credited with 35 hours.

Completed claimant’s reports are not required to credit weeks of indefinite disqualification.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2224.dita) 

### Automated LFA calculation

Source topic: `en_EN/task/calc_calculating/labour_force/automated_lfa_calculation.dita`

UIC determines from the information on file if the client is a regular or a NERE qualifier .
       [regular](/en/procedure/generic/knowledge.shtml) 
       [NERE qualifier](/en/procedure/generic/knowledge.shtml)

If the client is a NERE qualifier with between 420 and 909 hours of insurable employment in the qualifying period , the LFA prompter is displayed in SSA during calculation.
       [qualifying period](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-1/qualifying-period.html#a1_2_1)

UIC and SSA automatically determine the following:

- prior weeks of EI benefits paid

- prior weeks of EI waiting period served

- hours of insurable employment (regular and fishing) based on the ROEs on file

- hours of insurable employment based on proportional averaging for ROEs on file that have a period of work greater than the period required to be reported

- hours of disqualification for weeks where the client completed claimant’s reports while serving an indefinite disqualification

UIC uses the ROEs in RCM to determine the hours of insurable employment. It uses dormant claims to determine weeks of EI benefits paid, waiting period served or indefinite disqualification served (where claimant’s reports have been completed).

The prompter displays the start and end dates of the NERE qualifying period. It may give 2 ranges: one based on the BPC as determined by SSA, and another that starts one week earlier in case the claim is backdated by one week. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Example

Source topic: `en_EN/common_notes/note_c_2223.dita`

Example:

Fishing earnings = $3600. Hourly minimum wage in New Brunswick for the period worked = $10.00 LFA hours = 360 hours ($3600 divided by $10.00 per hour) 

### Example

Source topic: `en_EN/common_notes/note_c_2224.dita`

Example:

- A client renewed a claim with 20 weeks of regular entitlement remaining.

- An indefinite disqualification was imposed at the time of renewal due to dismissal for misconduct.

- If not for the disqualification, 20 weeks could have been paid before the last renewable week.

- All 20 weeks of the renewal claim’s remaining entitlement fall into the NERE qualifying period of the current claim.

You would credit the client 700 LFA hours (20 weeks at 35 hours per week), even if the client did not complete any claimant’s reports from the renewal date onward. 

## Regional considerations

Source topic: `en_EN/task/calc_calculating/labour_force/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_calculating/labour_force/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/calc_calculating/labour_force/untitled_section.dita`

If the LFA prompter is displayed, you must review the claim for any additional weeks of LFA that fall into the NERE qualifying period. The client may have given information about previous insurable employment for which there is no ROE on file. In addition, the workforce history section of the application may contain other weeks of LFA.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2225.dita) 

If the LFA requirement is not met, as indicated upon completion of the LFA prompter, and UIC finds an allocation of wage loss insurance or workers’ compensation benefits, a message is displayed on the SSA Calculation Result on File screen to alert you that additional LFA hours may be present (Refer to Reviewing the calculation result — Messages .)
       [Reviewing the calculation result — Messages](/en/procedure/generic/rcr_screen_messages.shtml)

Once you determine that the LFA requirement is met with 490 or more hours, there is no need to look at further conditions of LFA. For example, if you find weeks of disqualification that bring the LFA total to more than 489 hours, there is no need to look for ROEs in Easy Access, other prescribed weeks or weeks of employment declared by the client.

The step-by-step procedure provides a logical sequence for determining the LFA hours. However, if you recognize that one of the following sections provides the required hours, you may go directly to that section:

- Checking for Quebec Parental Insurance Plan
         [Quebec Parental Insurance Plan](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#qpip)

- Checking for prior disqualification
         [prior disqualification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#wksdisqual)

- Checking for ROEs in Easy Access
         [ROEs in Easy Access](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#easyaccess)

- Checking for other prescribed weeks
         [other prescribed weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#prescribedweeks)

- Checking for the client’s statement of employment
         [statement of employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#otherep)

Plotting the LFA on the calculation worksheet or using the SSA Calculation Worksheet helps in determining LFA hours and in ensuring that no more than 35 hours are allowed in each week unless the actual number of hours of insurable employment is greater than 35 hours.
       [calculation worksheet](/resources/ort/documents/calc_worksheet.xls) 

### Note

Source topic: `en_EN/common_notes/note_c_2225.dita`

Note:

- In all instances of potential weeks of LFA, the client’s statement is accepted at face value.

- If the client has not indicated additional work on the application or other documents, you are not required to fact-find with the client. 

## Step by step

Source topic: `en_EN/task/calc_calculating/labour_force/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_calculating/labour_force/level_1.dita`

#### Reviewing the file for QPIP information

Source topic: `en_EN/task/calc_calculating/labour_force/reviewing_the_file_for_qpip_information_level_1.dita`

- In NWS, determine if the client answered “yes” to the Information on the Quebec Parental Insurance Plan benefits section of the Web application:

- If the client answered “yes” to Quebec Parental Insurance Plan, go to step 2.

- If the client answered “no” to Quebec Parental Insurance Plan, go to Reviewing the file for weeks of disqualification .
               [Reviewing the file for weeks of disqualification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#level1_item_2)

- In FTS, from the Search menu, select Parental Insurance (Quebec) :

- Enter the client’s SIN.

- Action : Select 6 - 208 weeks before NERE qualifying period.

- Cut off date : Enter the cut-off date of the new BPC.
               [cut-off date](/en/procedure/generic/knowledge.shtml)

- Determine if the message “SIN not found” is displayed:

- If a list of QPIP claims is displayed, go to step 4.

- If the message “SIN not found” is displayed, go to Reviewing the file for weeks of disqualification .
               [Reviewing the file for weeks of disqualification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#level1_item_2)

- Review the ROEs on file to determine if the client would have qualified to receive EI benefits for the same benefit period as the Quebec Parental Insurance Plan claim:

- If the client would not have qualified to receive EI benefits, go to Reviewing the file for weeks of disqualification .
               [Reviewing the file for weeks of disqualification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#level1_item_2)

- If the client would have qualified to receive EI benefits, do the following:

- In the SSA LFA prompter screen, select Prior to NERE QP-Regular .

- Press the ESC key.

- Go to Reviewing the calculation result .
                   [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml) 

#### Reviewing the file for weeks of disqualification

Source topic: `en_EN/task/calc_calculating/labour_force/reviewing_the_file_for_weeks_of_disqualification_level_1.dita`

- In SSA, from the LFA prompter screen:

- Determine the automated total number of hours of LFA.

- If there are any hours of Insurable Employment - Auto , determine from the ROEs on file the weeks in which they fall.

- In FTS, from the Dormant tab, determine if there are any claims where the benefit period would have fallen within the NERE qualifying period:

- If there are any claims where the benefit period would have fallen within the NERE qualifying period, go to step 3.

- If there are no claims where the benefit period would have fallen within the NERE qualifying period, go to Reviewing for insurable employment in Easy Access .
               [Reviewing for insurable employment in Easy Access](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#level1_item_3)

- Determine if a claim that falls in the NERE qualifying period has a disqualification imposed:

- If a claim in the NERE qualifying period has a disqualification imposed, go to step 4.

- If no claim in the NERE qualifying period has a disqualification imposed, go to Reviewing for insurable employment in Easy Access .
               [Reviewing for insurable employment in Easy Access](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#level1_item_3)

- Determine if the client has completed claimant’s reports for any of the weeks of disqualification:

- If the client has not completed claimant’s reports, go to step 5.

- If the client has completed claimant’s reports, note that these weeks are already included in the automated LFA total.

- Calculate the number of weeks of disqualification that fall in the NERE qualifying period.

- Determine if any of the weeks of disqualification in the NERE qualifying period overlap the weeks of automated LFA:

- If there are weeks of overlap, determine which condition (the automated LFA or the week of disqualification) allows more hours, and credit that number of hours for each week of overlap.

- For weeks with no overlap, credit 35 hours for each week of disqualification.

- Total the number of hours from the weeks of disqualification and the automated LFA.

- Determine if the total number of LFA hours is greater than 489:

- If the total is less than 490, note the hours of disqualification as determined in step 6 and go to Reviewing for insurable employment in Easy Access .
               [Reviewing for insurable employment in Easy Access](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#level1_item_3)

- If the total is greater than 489, go to Claim meets LFA conditions .
               [Claim meets LFA conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#meetslfa) 

#### Reviewing for insurable employment in Easy Access

Source topic: `en_EN/task/calc_calculating/labour_force/reviewing_for_insurable_employment_in_e_bd4b9f98_level_1.dita`

- In Easy Access, determine if there are other ROEs falling in the NERE qualifying period that are not found in RCM. (Disregard any Easy Access ROE that is replaced by an amended ROE found in RCM.)

- If there are other ROEs that fall into the NERE qualifying period, go to step 2.

- If there are no other ROEs that fall in the NERE qualifying period, go to Reviewing the file for prescribed weeks .
               [Reviewing the file for prescribed weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#level1_item_4)

- Determine if any of the weeks of the Easy Access ROEs (in the NERE qualifying period) overlap the weeks of disqualification or the automated LFA not listed as Insurable Employment - Auto :

- If there are weeks of overlap, determine which condition allows the most hours and credit that number of hours for each week of overlap.

- For weeks with no overlap, calculate the average number of hours per week on the Easy Access ROE(s) and credit that number of hours for each week.

- Total the number of hours from the Easy Access ROEs, the automated LFA and the weeks of disqualification.

- Determine if the total number of LFA hours is greater than 489:

- If the total is greater than 489, go to Claim meets LFA conditions .
               [Claim meets LFA conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#meetslfa)

- If the total is less than 490, go to step 5.

- On the calculation worksheet, note that if the client does not meet LFA after all conditions are reviewed, an interim ROE based on the information in Easy Access may be required.

- Go to Reviewing the file for prescribed weeks . 

#### Reviewing the file for prescribed weeks

Source topic: `en_EN/task/calc_calculating/labour_force/reviewing_the_file_for_prescribed_weeks_level_1.dita`

- In NWS, review the work history section of the application, all applicable documents (SROCs, Action Item (AI), Call Back (CB) documents) and outstanding AI WIs and CB WIs to determine if any of the following information is provided for prescribed weeks falling in the NERE qualifying period:

- Workers’ Compensation Board payment, other than a permanent settlement, for wage loss

- wage loss insurance payment for wage loss

- preventative withdrawal payment for wage loss

- approved training with no EI benefits paid for those weeks

- approved self-employment program with no EI benefits paid for those weeks

- approved job creation program

- If any prescribed weeks information is provided, go to step 2.

- If no prescribed weeks information is provided, go to Reviewing the file for other employment .
                   [Reviewing the file for other employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#level1_item_5)

- Determine if any of the prescribed weeks overlap the weeks of automated LFA, weeks of disqualification or the Easy Access ROEs.

- If there are weeks of overlap, determine which condition allows the most hours and credit that number of hours for each week of overlap.

- For weeks with no overlap, credit 35 hours for each prescribed week.

- Total the number of hours for the prescribed weeks, the automated LFA, the weeks of disqualification, and the Easy Access ROEs.

- Determine if the total number of LFA hours is greater than 489 hours:

- If the total is less than 490, go to Reviewing the file for other employment .
               [Reviewing the file for other employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#level1_item_5)

- If the total is greater than 489, go to Claim meets LFA conditions .
               [Claim meets LFA conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#meetslfa) 

#### Reviewing the file for other employment

Source topic: `en_EN/task/calc_calculating/labour_force/reviewing_the_file_for_other_employment_level_1.dita`

- Determine if the client has advised of other employment falling in the NERE qualifying period for which there is no ROE in RCM or Easy Access:

- If the client has advised of other employment, go to step 2.

- If the client has not advised of other employment, go to Claim does not meet LFA conditions .
               [Claim does not meet LFA conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#lfanotmet)

- Determine if the client has provided the dates of the employment:

- If the client has provided the dates, go to step 4.

- If the client has not provided the dates, fact-find with the client to obtain the dates, then go to step 3.
               [fact-find](/en/procedure/task/fact_find.shtml)

- Determine if the client was contacted:

- If the client was contacted, go to step 4.

- If the client was not contacted, go to Claim does not meet LFA conditions .
               [Claim does not meet LFA conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#lfanotmet)

- Determine the total number of hours for the other employment, crediting 35 hours for each week of work, and prorating partial weeks. If the client has stated fewer hours per week, use that number of hours. If the client gives a range of hours, use the average of the range.

[Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2226.dita)

- Determine if any of the stated weeks overlap the weeks of disqualification, prescribed weeks,  or the automated LFA not listed as Insurable Employment - Auto :

- If there are weeks of overlap, determine which condition gives the greatest number of hours and credit that number of hours for each week of overlap.

- For weeks with no overlap, use the number of hours determined in step 4.

- Total the number of hours for the other employment, the automated LFA hours, the weeks of disqualification, the ROEs in Easy Access and the prescribed weeks.

- Determine if the total number of LFA hours is greater than 489:

- If the total is less than 490, go to step 8.

- If the total is greater than 489, go to Claim does not meet LFA conditions .
               [Claim does not meet LFA conditions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/labour_force#meetslfa)

- Enter an interim ROE with the following blocks only:

- 4 : Employer’s Name : Type the employer name provided by the client.

- 6 : Pay period type : Select Weekly .

- 10 : First day worked : Type the date given by the client.

- 11 : Last day for which paid : Type the date given by the client.

- 12 : Final pay period ending date : Type the date entered in block 11 .

- 15A : Total insurable hours : Type the number of hours determined in step 4.

- 15B : Total insurable earnings : Type “1.00.”

- 16 : Reason for separation : Select the reason given by client.

- Additional information : Type “LFA only.”

- Go to Claim does not meet LFA conditions . 

#### Claim does not meet LFA conditions

Source topic: `en_EN/task/calc_calculating/labour_force/claim_does_not_meet_lfa_conditions_level_1.dita`

- Determine if there were any ROEs in Easy Access that were not in RCM:

- If any other ROEs were found, go to step 2.

- If no other ROEs were found, go to step 3.

- Enter an interim ROE with the following blocks only:

- 4 : Employer’s Name : Type the employer name as displayed in Easy Access.

- 6 : Pay period type : Select Weekly .

- 10 : First day worked : Type the date as displayed in Easy Access.

- 11 : Last day for which paid : Type the date as displayed in Easy Access.

- 12 : Final pay period ending date : Type the date entered in block 11 .

- 15A : Total insurable hours : Type the number of hours as displayed in Easy Access.

- 15B : Total insurable earnings : Type “1.00”.

- 16 : Reason for separation : Select the reason given by client.

- Additional information : Type “LFA only — ROE in Easy Access.”

- In NWS, create an SROC as follows:

- Issue : Select Calculation .

- Comments : Type “labour force attachment — does not meet LFA”

- Details : Type the sources of the LFA as applicable (Easy Access, client’s statement of work, weeks of disqualification, other prescribed weeks). Indicate the number of hours for each source and the total number of determined LFA hours.

- In SSA, from the LFA prompter screen:

- Select LFA Regular (if not already displayed).

- Verify : Type “N” (if not already displayed as “N”).

- Press the ESC key.

- Go to Reviewing the calculation result .
               [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml) 

#### Claim meets LFA conditions

Source topic: `en_EN/task/calc_calculating/labour_force/claim_meets_lfa_conditions_level_1.dita`

- In NWS, create an SROC as follows:

- Issue : Select Calculation .

- Comments : Type “labour force attachment — meets LFA.”

- Details : Type the source of the LFA (as applicable: Easy Access, client’s statement of work, weeks of disqualification, and other prescribed weeks). Indicate the number of hours for each source and the total number of determined LFA hours.

- In SSA, from the LFA prompter screen:

- Select LFA Regular (if not already displayed).

- Verify : Type “Y” (if not already displayed as “Y”).

- Press the ESC key.

- Go to Reviewing the calculation result .
               [Reviewing the calculation result](/en/procedure/subactivity/calc_result_ccb.shtml) 

#### Example

Source topic: `en_EN/common_notes/note_c_2226.dita`

Example:

- The NERE qualifying period is from September 25, 2011 to September 22, 2012.

- The client stated he worked for an employer from October 19, 2011 to November 23, 2011.

- There are 5 full weeks of work, October 19 to November 22 plus one day, November 22.

- Total hours for the full weeks = 175 hours (35 hours x 5 weeks)

- Hours for the one day = 5 hours (35 hours / 7 days).

- Total LFA hours for this employer = 180. 

## Policy reference

Source topic: `en_EN/task/calc_calculating/labour_force/policy_reference.dita`

- EIA 7(4)
         [EIA 7(4)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-7.html)

- EIR 12
         [EIR 12](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-12.html)

- EIR 76.1(1)
         [EIR 76.1(1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-76.1.html)

- Digest 1.2.7
         [Digest 1.2.7](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-1/qualifying-period.html#a1_2_7) 
