# Determining during calculation of an apprentice claim if the client is entitled to have the waiting period waived

Source map: `en_EN/task/calc_calculating/waiving_wp_ac/waiving_wp_ac.ditamap`

## Summary

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/summary.dita`

Summary: Apprentices may be entitled to have their waiting period (WP) waived. 

## What you need to know

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Waiting period (WP)

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/waiting_period_wp.dita`

Generally, before receiving the first week of benefits, clients must serve a WP for which no benefit is payable. The WP is served in the first week of unemployment for which benefits would otherwise be payable. Under certain conditions, the WP can be waived.
       [WP](/en/procedure/generic/knowledge.shtml#Waiting_period)

**Pilot project no. 24: Waiving the waiting period (WP) for BPCs between March 30 andOctober 10, 2026 (w/c 2493 to w/c2572)**

A temporary measure to waive the one-week WP has been implemented to support clients impacted by major changes in economic conditions due to the imposition of tariffs by the United States. The WP is waived for all initial claims with a BPC between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ), regardless of the requested benefit type (BT). If it is advantageous to the client, the client can decide to serve the WP (e.g. the client must serve the WP to receive supplemental unemployment benefits [SUB]).

For more information, the officer refers to Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions .
       [Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions](/en/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml) 

### Determining if the waiting period (WP) can be waived

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/determining_if_the_waiting_period_wp_ca_77ecbdb6.dita`

Apprenticeship training must be referred by a designated authority under section 25 of the Act to allow payment of EI benefits. Each province and territory has its own government office that oversees apprenticeship training and certification for that province or territory. Clients can either be a registered apprentice within their provincial apprenticeship branch or be referred to training by a designated provincial authority. When clients are referred to apprenticeship training and are enrolled in a training session, a 16-digit reference code is provided (e.g. the province in the case of a labour market development agreement) or a designated authority (e.g. provincial apprenticeship branch). This code must be used to apply for EI benefits.
       [section 25 of the Act](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

In the case of a client attending a mandatory course for an apprenticeship program, the WP is waived when all of the following conditions are met:

- The client is attending a course that is a required part of an apprenticeship program and was referred by a designated authority.

- The client served a WP on a previous claim with a BPC falling on w/c 1309 or after for the same apprenticeship program.

- The client stopped working for one of the following reasons:

- to attend a mandatory course

- due to a shortage of work

- There is a gap of no more than 2 weeks between the BPC and the course start week

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2235.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2235.dita`

Note:

When an apprentice stopped working due to a shortage of work and there is a gap of no more than 2 weeks between the BPC and the course start week, the client is considered unemployed, capable of and available for work. 

## Regional considerations

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/in_nws.dita`

- Is there an apprentice reference code on file?

- If no, has proof of apprenticeship been provided?

- What is the reason the client stopped working before the course?

- What is the course start date?

- Did the client request that the WP be waived? 

### In RCM:

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/in_rcm.dita`

- What is the reason for separation and the last day paid on the most recent ROE? 

### In FTS:

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/in_fts.dita`

- Did the client have a previous claim for attending the same apprenticeship program?

- If yes, what is the BPC on the prior claim and was a WP served on the prior claim for the same apprenticeship program? 

### In Imaging:

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/in_imaging.dita`

- Are there any documents related to the current apprenticeship program? 

## Step by step

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/level_1.dita`

#### Determining if the waiting period (WP) must be waived

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/determining_if_the_waiting_period_wp_mu_99bcfd7b_level_1.dita`

- Determine if additional fact-finding is required:

- If no, go to step 2.

- If yes, go to Fact-finding .
               [Fact-finding](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/waiving_wp_ac#_Fact-finding_is_required)

- Determine if both of the following conditions are met:

- The client is attending a mandatory course for an apprenticeship program.

- The client was referred to the course by a designated authority.

- If both conditions are met, go to step 3.

- If either condition is not met, go to Waiting period (WP) must not be waived .
                   [Waiting period (WP) must not be waived](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/waiving_wp_ac#_Conditions_not_met)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2236.dita)

- Determine if one of the following conditions is met:

- The client stopped working to attend the course and there is a gap of no more than 2 weeks between the BPC and the course start week.

- The client stopped working due to a shortage of work and there is a gap of no more than 2 weeks between the BPC and the course start week.

- If either condition is met, go to step 4.

- If neither condition is met, go to Waiting period (WP) must not be waived .
                   [Waiting period (WP) must not be waived](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/waiving_wp_ac#_Conditions_not_met)

- Determine if the client served a WP on a previous claim for the same apprenticeship program:

- If no, go to Waiting period (WP) must not be waived .
               [Waiting period (WP) must not be waived](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/waiving_wp_ac#_Conditions_not_met)

- If yes, determine if the BPC of the previous claim is w/c 1309 or after:

- If yes, go to Waiting period (WP) must be waived .
                   [Waiting period (WP) must be waived](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/waiving_wp_ac#_Waiting_period_to)

- If no, go to Waiting period (WP) must not be waived .
                   [Waiting period (WP) must not be waived](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/waiving_wp_ac#_Conditions_not_met) 

#### Waiting period (WP) must be waived

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/waiting_period_wp_must_be_waived_level_1.dita`

- On the calculation worksheet, note that when the claim is input in SSO, the officer must waive the WP.

- Return to step 10 of Determining if a claim is ready to be calculated — Regular benefits . 

#### Waiting period (WP) must not be waived

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/waiting_period_wp_must_not_be_waived_level_1.dita`

- In NWS, create a record of decision as follows:

- Comments: Type “Waive the WP — apprentice — denied.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if the client has requested that the WP be waived:

- If yes, on the calculation worksheet, note that the N-12-00-00 letter must be sent when the claim is finalized to advise the client why the WP is not waived and go to step 3.

- If no, go to step 3.

- Return to step 10 of Determining if a claim is ready to be calculated — Regular benefits . 

#### Fact-finding

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/fact-finding_level_1.dita`

- On the calculation worksheet, note that you must fact-find with the employer or the client to determine why the client stopped working.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2237.dita)

- Return to step 10 of Determining if a claim is ready to be calculated — Regular benefits . 

#### Note

Source topic: `en_EN/common_notes/note_c_2236.dita`

Note:

As a temporary measure under Pilot Project No. 24, the WP is waived on all BPCs between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ).Clients can request to serve to WP if it is to their advantage (e.g. clients must serve the WP to receive SUB).

For more information, the officer refers to Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions .
       [Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions](/en/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml)

     [Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions](/en/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2237.dita`

Note:

Once fact-finding is complete, return to this task. 

## Policy reference

Source topic: `en_EN/task/calc_calculating/waiving_wp_ac/policy_reference.dita`

- EIA 13
         [EIA 13](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-13.html)

- EIA 25(1)(a)
         [EIA 25(1)(a)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- EIR 39(1)
         [EIR 39(1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-39.html)

- BE 2007-10 — Decision of the federal court of appeal
         [BE 2007-10 — Decision of the federal court of appeal](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2007-10.shtml) 
