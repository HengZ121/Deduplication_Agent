# Modifying the sickness benefits information on the Annex — Special benefits screen in SSO

Source map: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/ent_recdate_ssa_sb.ditamap`

## Summary

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/summary.dita`

Summary : When calculating a claim that includes a request for sickness benefits, the officer ensures that the correct sickness information is input on the Sickness section of the Annex - Special Benefits screen. 

## What you need to know

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2198.dita) 

### Reviewing the Annex-Special Benefits screen

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/reviewing_the_annex-special_benefits_screen.dita`

When a claim for sickness benefits is registered, the Estimated or actual date of recovery field on the Annex - Special Benefits screen in SSO is blank. Before a claim for sickness benefits is calculated, the officer determines if the recovery date must be changed on the Sickness section of the Annex - Special Benefits screen.

The recovery date must be changed when an acceptable medical certificate has been submitted, whether or not it was requested.

The recovery week must not be changed when an acceptable medical certificate is requested and has not been submitted.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2199.dita) 

When a claim for sickness benefits or sickness benefits followed by maternity benefits is calculated in SSO, if the Estimated or actual date of recovery field is blank and there is no indication that the medical certificate is outstanding in the Outstanding information field, SSO calculates the recovery week as BPC + 8 weeks.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2200.dita) 

When the benefit type (BT) being calculated is sickness and an officer indicates in the Outstanding Information field that the medical certificate is outstanding, SSO automatically creates a 16 - No medical certificate submitted disentitlement (D16) transaction. A recovery date is required but is not entered on the Annex - Special Benefits screen. The officer notes on the worksheet that an indefinite recovery week is manually entered on the M103 - Initial decision (M103) transaction when the claim is input ( Yes must be indicated under Is Indefinite? ).

When the recovery date must be changed, the officer calculating the claim must determine the correct recovery date and input it in the Estimated or actual date of recovery field. 

### Determining the sickness start date

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/determining_the_sickness_start_date.dita`

EIA 18(1)(b) requires that clients prove they are unable to work because of an illness, injury or quarantine.

According to policy, the start date of the sickness is determined as follows:

```text
| Conditions | Reason for separation (RFS) | Start date of the sickness indicated on the medical certificate | Start date of the sickness | Review for D16 required |

| The client is disqualified from or disentitled to benefits as a result of the RFS. | Any | Yes | The Sunday of the same week as the date indicated on the medical certificate. | Yes |

| The client is disqualified from or disentitled to benefits as a result of the RFS. | Any | No | The Sunday of either the week in which the doctor or other medical professional signed the medical certificate or of the medical consultation, whichever is earlier. | Yes |

| The client has sufficient hours to qualify for sickness benefits but not for regular benefits ( 46 - Variable entrance requirement not met - special benefits payable [D46]). | Illness or injury | Yes or no | The BPC date | No |

| The client has sufficient hours to qualify for sickness benefits but not for regular benefits (D46). | Other than illness or injury | Yes | The Sunday of the same week as the date indicated on the medical certificate. | Yes |

| The client has sufficient hours to qualify for sickness benefits but not for regular benefits (D46). | Other than illness or injury | No | The Sunday of either the week the doctor or other medical professional signed the medical certificate or of the medical consultation, whichever is earlier. | Yes |

| No disqualifications or disentitlements. | Illness or injury | Yes or no | The BPC date. | No |

| No disqualifications or disentitlements | Other than illness or injury | Yes | The Sunday of the same week as the date indicated on the medical certificate. | Yes |

| No disqualifications or disentitlements | Other than illness or injury | No | The Sunday of either the week the doctor or other medical professional signed the medical certificate or of the medical consultation, whichever is earlier. | Yes |
```

In all cases where a D16 review is required, the officer determines if the incapacity start date is after the BPC week. If yes, the officer imposes a D16 from the Monday of the BPC week to the Friday before the incapacity start week. 

### Determining the recovery date

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/determining_the_recovery_date.dita`

The recovery date is the first day the client is capable of working.

**Determining the recovery week**

The recovery week is the week up to which sickness benefits are payable. To determine the recovery week, the officer refers to Determining the recovery week — Instructions .
       [Determining the recovery week — Instructions](/en/procedure/generic/determing_the_recovery_week_instruction.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2198.dita`

Note:

The Medical certificate field automatically shows Yes and can only be changed to No by indicating that the medical certificate is missing on the Registration screen. The officer takes this action in Indicating in SSO that information required to calculate a claim is outstanding when calculating the claim.
       [Indicating in SSO that information required to calculate a claim is outstanding](/en/procedure/task/calc_calculating/ind_ssa_mcmiss_sb.shtml)

     [Indicating in SSO that information required to calculate a claim is outstanding](/en/procedure/task/calc_calculating/ind_ssa_mcmiss_sb.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2199.dita`

Note:

While following the steps in Determining if a medical certificate must be submitted: Sickness benefits — Initial claims , the officer determines if an acceptable medical certificate must be requested or has been submitted.
       [Determining if a medical certificate must be submitted: Sickness benefits — Initial claims](/en/procedure/task/calc_determining/det_mc_ra.shtml)

     [Determining if a medical certificate must be submitted: Sickness benefits — Initial claims](/en/procedure/task/calc_determining/det_mc_ra.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2200.dita`

Note:

On claims for sickness benefits with a BPC before April 7, 2024 (w/c 2442), SSO calculates the recovery week as BPC + 15 weeks when the Estimated or actual date of recovery field is blank and there is no indication that the medical certificate is outstanding in the Outstanding information field on the Registration screen. 

## Regional considerations

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/in_nws.dita`

- Has a medical certificate been uploaded that indicates the start date of the sickness? If so, what is that date?

- What recovery information does the medical certificate provide?

- Does the application or do other documents indicate that the client is or will be receiving Canada Pension Plan (CPP) disability benefits?

- Is there a record of decision (ROD) indicating that an RFS has not been allowed? 

### In Imaging:

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/in_imaging.dita`

- Is there a medical certificate that indicates the start date of the sickness? If so, what is that date?

- What recovery information does the medical certificate provide?

- Are there any documents that indicate the client is or will be receiving CPP disability benefits? 

### In RCM:

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/in_rcm.dita`

- How many insurable hours are indicated on any of the ROEs in the qualifying period (QP)? 

## Step by step

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/reviewing_the_file_level_1.dita`

- Determine if an acceptable medical certificate has been submitted:

- If no, go to No acceptable medical certificate on file .
               [No acceptable medical certificate on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/ent_recdate_ssa_sb#No_acceptable_medical)

- If yes, go to Acceptable medical certificate on file .
               [Acceptable medical certificate on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/ent_recdate_ssa_sb#Acceptable_medical_certificate) 

#### No acceptable medical certificate on file

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/no_acceptable_medical_certificate_on_file_level_1.dita`

- Determine if a medical certificate is required:

- If no, to determine the recovery week that must be indicated in the Estimated or actual date of recovery field, refer to Determining the Recovery week — Instructions . Go to step 2.
               [Determining the Recovery week — Instructions](/en/procedure/generic/determing_the_recovery_week_instruction.shtml)

- If yes, the Estimated or actual date of recovery field must be blank . Go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2201.dita)

- In SSO, determine if the option indicated in the Estimated or actual date of recovery field of the Annex - Special Benefits screen is correct:

- If no, go to step 3.

- If yes, go to step 4.

- On the Annex - Special Benefits screen, enter the information as follows:

- Estimated or actual date of recovery field: Take the appropriate action:

- If a recovery date is required, enter the recovery date.

- If no recovery date is required, delete the date in the Date field.

- Return to step 3 of Calculating a claim in SSO . 

#### Acceptable medical certificate on file

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/acceptable_medical_certificate_on_file_level_1.dita`

- Determine if the client is disqualified from or disentitled to benefits as a result of the RFS:

- If no, go to step 2.

- If yes, go to step 3.

- Determine if the RFS on the last ROE is illness or injury:

- If no, go to step 3.

- If yes, the start date of the sickness is the Sunday of the BPC week. Go to step 5.

- Determine if the medical certificate provides the start date of the sickness:

- If yes, go to step 4.

- If no, the start date of the sickness is the Sunday of either the week the doctor or other medical professional signed the medical certificate, or the week of the medical consultation, whichever is earlier. Go to step 4.

- On the calculation worksheet, note that if the start date of the sickness is after the BPC week, a D16 must be imposed from the Monday of the BPC week to the Friday before the incapacity start week.

- To determine the recovery week that must be indicated in the Estimated or actual date of recovery field, refer to Determining the Recovery week — Instructions . Go to step 6.

- In SSO, determine if the information indicated in the Estimated or actual date of recovery field of the Annex - Special Benefits screen is correct:

- If no, go to step 7.

- If yes, go to step 8.

- On the Annex - Special Benefits screen, enter the information as follows:

- Estimated or actual date of recovery field: Take the appropriate action:

- If a recovery date is required, enter the recovery date.

- If no recovery date is required, delete the date in the Date field.

- Return to step 3 of Calculating a claim in SSO . 

#### Note

Source topic: `en_EN/common_notes/note_c_2201.dita`

Note:

When an acceptable medical certificate is requested but has not been submitted, SSO automatically creates a D16 during calculation if the BT is sickness and if the Outstanding Information field indicates the medical certificate is outstanding.

If SSO does not automatically create the D16 during the calculation of the claim, manually create the Disqualifications/Disentitlements (M161) transaction when transmitting the claim.

For a combination of sickness, maternity and parental benefits, change the end date of the D16 to the Friday of the week before the start week of maternity benefits.

An indefinite recovery date is also required but is not entered on the Annex - Special Benefits screen. The officer manually enters the indefinite recovery date on the M103 - Initial decision (M103) transaction when transmitting the claim to prevent SSO from incorrectly postdating the BPC. 

## Policy reference

Source topic: `en_EN/task/calc_calculating/ent_recdate_ssa_sb/policy_reference.dita`

- EIA 18(1)(b)
         [EIA 18(1)(b)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- National Policy on Proof of Incapacity
         [National Policy on Proof of Incapacity](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/proof_of_incapacity_policy.shtml) 
