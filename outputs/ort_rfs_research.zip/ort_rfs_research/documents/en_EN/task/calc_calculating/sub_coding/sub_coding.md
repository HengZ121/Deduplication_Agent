# Entering a supplemental unemployment benefits code in SSO

Source map: `en_EN/task/calc_calculating/sub_coding/sub_coding.ditamap`

## Summary

Source topic: `en_EN/task/calc_calculating/sub_coding/summary.dita`

Summary: When the information on file shows that the client is receiving supplemental unemployment benefits (SUB) payments in the benefit period (BP), the officer must verify and input the appropriate SUB code in SSO. 

## What you need to know

Source topic: `en_EN/task/calc_calculating/sub_coding/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_calculating/sub_coding/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Supplemental unemployment benefits (SUB) plans

Source topic: `en_EN/task/calc_calculating/sub_coding/supplemental_unemployment_benefits_sub_plans.dita`

Employers may provide a SUB plan to supplement their employees’ EI benefits paid during periods of unemployment. When an employer pays a SUB plan, the payments are reported on the ROE in block 17C - Other monies . To be eligible for the SUB payment, a client must be receiving EI benefits for the weeks concerned (except for the waiting period [WP] if this is part of the plan).

Payments issued under an approved SUB plan are not considered earnings for benefit purposes if the plan type matches the benefit type requested. For a SUB plan to be approved, it must meet certain conditions. Once approved, the appropriate SUB code must be input in SSO for the payment to be excluded from earnings if reported on the claimant’s report.

An employer may supplement an employee’s EI benefits through 2 different types of plans: 

### Plans for regular and sickness benefits

Source topic: `en_EN/task/calc_calculating/sub_coding/plans_for_regular_and_sickness_benefits.dita`

SUB plans to supplement regular and sickness benefits ( EIR 37 ) meet the following conditions:
       [EIR 37](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-37.html)

- They are paid during a period of unemployment due to a temporary stoppage of work, for training, illness, injury or quarantine.

- The weekly amount of the SUB payment plus the EI benefit rate from that employment cannot be greater than 95% of the client’s normal weekly earnings (NWE) from the employer paying the SUB.

- normal weekly earnings (NWE) from the employer paying the SUB.

The National Services — SUB Program registers SUB plans for regular, sickness or training benefits and adds them to the database, which is updated weekly. Once the database is updated, the registered plan’s details, including the appropriate SUB code, are available in the Employer Details screen in FTS.

When no registered plan for regular or sickness benefits is listed, the officer must email National Services to verify if the plan has recently been registered. If no SUB plan has been registered, the SUB payments are considered earnings for benefit purposes ( EIR 36 ). The officer selects SUB code 9 - Not approved and no listing issued to employer in SSO and notifies the client that the SUB earnings must be declared.
       [EIR 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2228.dita) 

### Determining if the client is covered under a supplemental unemployment benefits (SUB) plan

Source topic: `en_EN/task/calc_calculating/sub_coding/determining_if_the_client_is_covered_un_8af2cab7.dita`

When a registered SUB plan shows on the Employer Details screen in FTS, the officer determines if the following entitlement conditions are met:

- The ROE indicates that the employee receives SUB or the client reports receiving SUB.

- The client is requesting the benefit type (BT) that is listed under the SUB plan.

- The employer-employee relationship is continuing.

- The client is part of the beneficiary group covered by the SUB plan.

The employment relationship must continue to exist after the temporary stoppage of work. Clients who are dismissed or who voluntarily leave their employment are no longer covered under the SUB plan as the employer-employee relationship is severed.

When there is no registered SUB plan on the Employer Details screen in FTS, the officer fact-finds to determine if the client is entitled to the SUB plan.

The following elements on file can indicate that the client is receiving SUB:

- On the ROE, the employer inputs U in block 17C .

- The client declares SUB in the claimant’s report.

- The client contacts Service Canada to inform that SUB is received. 

### Calculation warnings

Source topic: `en_EN/task/calc_calculating/sub_coding/calculation_warnings.dita`

The C790 warning is displayed when the officer attempts to input the initial transaction or the subsequent decision transaction without a SUB code when the employer number is on the Employer Details screen in FTS and the claim is not BPNE. The officer reviews the SUB plan and determines if the client is entitled to it.

The C791 warning is displayed when the officer attempts to input the initial or subsequent decision transaction with a SUB code when the employer number is not in the Employer Details screen in FTS.

For more information, the officer refers to WECS .
       [WECS](http://wecs-siew.prv/wecs-siew/lookup_e.aspx) 

### Plans for maternity benefits, parental benefits, family caregiver benefits (FCB) and CCB

Source topic: `en_EN/task/calc_calculating/sub_coding/plans_for_maternity_benefits_parental_b_d0e82575.dita`

SUB plans to supplement maternity benefits, parental benefits, FCB and CCB (top-up) (EIR 38) meet the following conditions:
       [(EIR 38)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-38.html)

- The supplement is paid to top up maternity benefits, parental benefits, FCB or CCB.

- The weekly amount of the SUB payment plus the EI benefit rate from that employment is not greater than 100% of the client’s NWE from the employer paying the SUB.

- The SUB payment does not reduce the client’s other accumulated employment benefits such as sick leave, vacation leave or severance pay.

- SUB plans for maternity benefits, parental benefits, FCB and CCB are not registered, but the employer must provide an attestation that the required conditions are met. When the employer includes the SUB information in block 17C of the ROE, this is considered an attestation by the employer.

The SUB code for a plan that meets the required conditions is always code 16 - Approved maternity, parental, compassionate care, or family caregiver for children or adults only (16) . If SUB payments are reported on the claimant’s report, the officer selects SUB code 16 in SSO so that payments are excluded from earnings.

If the SUB plan does not meet the conditions outlined in EIR 38 , the SUB payments are considered earnings for benefit purposes ( EIR 36 ). The officer selects SUB code 9 in SSO and notifies the client that the SUB earnings must be declared. If the client is exempt from completing claimant’s reports, the exemption must be cancelled.
       [EIR 38](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-38.html) 
       [EIR 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html)

When the total of the EI benefits and the SUB plan for maternity benefits, parental benefits, FCB or CCB exceed the client’s NWE from the employer paying SUB, only the part that exceeds that total is considered earnings.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2229.dita) 

### Information for employers

Source topic: `en_EN/task/calc_calculating/sub_coding/information_for_employers.dita`

Information for employers regarding these plans can be found on the Service Canada website at:

- Supplement to Regular, Sickness or Training .
         [Supplement to Regular, Sickness or Training](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/ei-employers-supplemental-unemployment-benefit.html)

- Supplement to maternity, parental, compassionate care and family caregiver benefits .
         [Supplement to maternity, parental, compassionate care and family caregiver benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/ei-employers-maternity-parental-benefits.html)

Employers seeking more information or wishing to register a SUB plan must contact the Employer Contact Centre .
       [Employer Contact Centre](https://www.canada.ca/en/employment-social-development/corporate/contact/employer-contact-center.html) 

### Employer responsibilities

Source topic: `en_EN/task/calc_calculating/sub_coding/employer_responsibilities.dita`

The employer (or the administrator of an approved plan) is responsible for verifying that the client is receiving EI benefits before issuing a SUB payment. The employer verifies this from one of the following:

- A Service Canada system-generated report showing EI payments made to the client. This is available to an employer who requests it when an approved SUB code other than 8 - Approved and no listing issued to employer is selected in SSO for a registered SUB plan.

- EI benefit statements submitted by the client to the employer. This is the only method available when the SUB code selected in SSO is 8 or when the SUB plan is not registered (i.e. supplements for maternity benefits, parental benefits, FCB or CCB). 

### Multiple employers

Source topic: `en_EN/task/calc_calculating/sub_coding/multiple_employers.dita`

When there is more than one employment, the employer paying the SUB is notified of the portion of the benefit rate that stems from that employment. Only that portion of the benefit rate and the NWE from the employer paying the SUB are considered when determining the maximum amount of the SUB payment from that employer. The officer must note that the employer who is making the SUB payments must be notified of what portion of the client’s benefit rate is based on the employment for which the SUB payments are being made. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2228.dita`

Note:

The temporary transitional measure included under EIR 37(3) has been repealed and no longer applies effective January 3, 2021. For BPCs from w/c 2063 to w/c 2271, in the first week following the WP, the combined SUB and EI benefits may exceed the 95% threshold in order to accommodate SUB plans that existed before the change. Effective January 3, 2021 (w/c 2272), monies exceeding the maximum threshold will be considered earnings and deducted from benefits payable. 

### Note

Source topic: `en_EN/common_notes/note_c_2229.dita`

Note:

The temporary transitional measure included under EIR 38(3) has been repealed and no longer applies effective January 3, 2021. For BPCs from w/c 2063 to w/c 2271, in the first week following the WP, the combined SUB and EI benefits may exceed the 100% threshold in order to accommodate SUB plans that existed before the change. Effective January 3, 2021 (w/c 2272), monies exceeding the maximum threshold will be considered earnings and deducted from benefits payable. 

## Regional considerations

Source topic: `en_EN/task/calc_calculating/sub_coding/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_calculating/sub_coding/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/calc_calculating/sub_coding/in_nws.dita`

- What type of benefits has the client requested?

- Is there information indicating that the client may be entitled to SUB payments? 

### In RCM:

Source topic: `en_EN/task/calc_calculating/sub_coding/in_rcm.dita`

- What is the reason for separation?

- Has the employer indicated SUB information in block 17C of the ROE? 

### In FTS:

Source topic: `en_EN/task/calc_calculating/sub_coding/in_fts.dita`

- Does this employer have a registered SUB plan?

- Is the SUB plan to supplement a temporary period of unemployment during the payment of regular or sickness benefits?

- What is the SUB plan type?

- Who is covered in the beneficiaries group? 

## Step by step

Source topic: `en_EN/task/calc_calculating/sub_coding/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_calculating/sub_coding/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/calc_calculating/sub_coding/reviewing_the_file_level_1.dita`

- Based on the information on file, determine how the SUB plan was identified:

- If FTS generated a C790 or C791 warning , go to step 2.

- If the client or employer indicated that SUB is being received, go to step 4.

- Review the file to determine if there is any information indicating that the client could be receiving SUB:

- If yes, go to step 3.

- If no, return to step 8 of Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2230.dita)

- Determine if the requested BT matches the plan type listed in the Employer Details screen in FTS:

- If yes, go to step 4.

- If no, return to step 8 of Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Determine the reason that the client is receiving the SUB payments:

- If the reason is due to shortage of work, training, illness, injury or quarantine, go to Supplemental to regular or sickness benefits .
               [Supplemental to regular or sickness benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/sub_coding#level1_item_2)

- If the reason is to top up maternity benefits, parental benefits, FCB or CCB, go to Supplemental to maternity benefits, parental benefits, family caregiver benefits (FCB) or CCB .
               [Supplemental to maternity benefits, parental benefits, family caregiver benefits (FCB) or CCB](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/sub_coding#sub38) 

#### Supplemental to regular or sickness benefits

Source topic: `en_EN/task/calc_calculating/sub_coding/supplemental_to_regular_or_sickness_benefits_level_1.dita`

- In FTS, select Search — Employer and input the employer’s 15-digit business number to determine if the employer has a registered SUB plan for the BT requested:

- If no, go to step 6.

- If yes, go to step 10.

- Email the National Services — SUB Program and verify if the SUB plan has recently been registered:

- In the subject line, type “URGENT — SUB plan confirmation.”

- In the body of the email, include the following information:

- employer’s name and address;

- employer’s business number;

- SUB type (sickness, temporary shortage of work, or training) based on the information on file;

- client’s name;

- ask if the employer has a registered SUB plan and, if yes, ask for details of the plan, including the start date, plan type, SUB code and group of beneficiaries covered by the plan;

- your name and telephone number.

- In NWS, determine if there is a WI for the task:

- If no, hold the task for 48 hours.

- If yes, move it to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “SUB plan verification.”

- Bring forward date: Enter today’s date + 2 business days.

- When National Services replies or the WI moves to the current workload, create an SROC as follows:

- Main Issue: Select Other .

- Comments: Type “SUB plan for [employer name].”

- Details: Document that National Services was contacted to verify if the SUB plan was registered and the response (including the SUB plan details, if necessary) according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if a SUB plan has been registered:

- If yes, go to step 10.

- If no or no response has been received from National Services, go to step 15.

- Determine if there is enough information on file to determine if the client meets all of the following criteria:

- The client is part of the beneficiary group listed in the Employer Details screen in FTS.

- The client has a work stoppage attributed to the employer with the SUB plan.

- The client continues to have a relationship with the employer (i.e. was not dismissed or did not voluntarily leave).

- If no, go to Fact-finding .
                   [Fact-finding](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/sub_coding#fact-finding)

- If yes, go to Inputting the SUB coding .
                   [Inputting the SUB coding](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_calculating/sub_coding#inputting_the_SUB) 

#### Fact-finding

Source topic: `en_EN/task/calc_calculating/sub_coding/fact-finding_level_1.dita`

- Fact-find with the client (or employer, if necessary) to clarify SUB information, such as:

- Which beneficiary group the client is part of?

- What is the payment type?

- What information the client has to determine that SUB is paid?

- Any other relevant facts.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Earnings .

- Comments: Type “Supplementary unemployment benefit information received from the client.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Inputting the supplemental unemployment benefits (SUB) coding

Source topic: `en_EN/task/calc_calculating/sub_coding/inputting_the_supplemental_unemployment_2781cad0_level_1.dita`

- Determine if the client meets all criteria to be entitled to the SUB plan:

- If yes, go to step 14.

- If no, go to step 16.

- In SSO, on the Determination of Earnings screen, select the SUB code as follows:

- Supplemental Unemployment Benefits: Select the SUB code as displayed in FTS or obtained from National Services.

- If there is more than one employment, make a note that a Z-00-00-00 letter must be sent to notify the employer(s) paying the SUB of the portion of the benefit rate that stems from that employment.

- Go to step 16.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2231.dita)

- On the Determination of Earnings screen, select the SUB code to indicate that the plan is not registered as follows:

- SUB: Select 9 .

- Return to step 8 of Calculating a claim in SSO . 

#### Supplemental to maternity benefits, parental benefits, family caregiver benefits (FCB) or CCB

Source topic: `en_EN/task/calc_calculating/sub_coding/supplemental_to_maternity_benefits_pare_baae0679_level_1.dita`

- Determine if the SUB plan meets the conditions of EIR 38 :

- If yes, go to step 6.

- If no, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2232.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2233.dita)

- On the Determination of Earnings screen, select the SUB code to indicate that the conditions of Regulation 38 are met as follows:

- SUB: Select 16 .

- If there is more than one employment, make a note that a Z-00-00-00 letter must be sent to the employer(s) paying the SUB to notify of the portion of the benefit rate that stems from that employment.

- Go to step 9.

- On the Determination of Earnings screen, select the SUB code to indicate that the conditions of Regulation 38 are not met as follows:

- SUB: Select 9 .

- On the calculation worksheet, note that once the claim is finalized, the client must be notified.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2234.dita)

- Return to step 8 of Calculating a claim in SSO . 

#### Note

Source topic: `en_EN/common_notes/note_c_2230.dita`

Note:

SUB may be indicated in:

- in block 17C of the ROE;

- in the comments in the ROE;

- the information provided by the client. 

#### Note

Source topic: `en_EN/common_notes/note_c_2231.dita`

Note:

Inputting the calculation transactions results in a C791 warning when a recently registered plan has not been added to the database (i.e. a plan registered before the weekly database update). Override this warning when National Services has confirmed the SUB plan details. 

#### Note

Source topic: `en_EN/common_notes/note_c_2232.dita`

Note:

For BPCs from w/c 2063 to w/c 2271, in the first week following the WP, the combined SUB and EI benefits may exceed the 100% threshold. 

#### Note

Source topic: `en_EN/common_notes/note_c_2233.dita`

Note:

By indicating the SUB top-up in block 17C of the ROE, the employer is attesting that the SUB plan meets the conditions of EIR 38. No further confirmation is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2234.dita`

Note:

When the total of the EI benefits and the SUB plan for maternity benefits, parental benefits, FCB or CCB exceed the client’s NWE from the employer paying the SUB, only the part that exceeds that total is considered earnings. 

## Policy reference

Source topic: `en_EN/task/calc_calculating/sub_coding/policy_reference.dita`

- EIR 36(12)
         [EIR 36(12)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html)

- EIR 37
         [EIR 37](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-37.html)

- EIR 38
         [EIR 38](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-38.html)

- Digest 5.5.2
         [Digest 5.5.2](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/excluded-earnings-regulation35.html#a5_5_2)

- Digest 5.5.2.1
         [Digest 5.5.2.1](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/excluded-earnings-regulation35.html#a5_5_2_1)

- Digest 5.5.2.2
         [Digest 5.5.2.2](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/excluded-earnings-regulation35.html#a5_5_2_2) 
