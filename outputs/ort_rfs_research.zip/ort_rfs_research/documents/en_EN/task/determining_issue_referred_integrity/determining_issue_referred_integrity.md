# Determining if an issue must be referred to Integrity

Source map: `en_EN/task/determining_issue_referred_integrity/determining_issue_referred_integrity.ditamap`

## Summary

Source topic: `en_EN/task/determining_issue_referred_integrity/summary.dita`

Summary: When the officer realizes that a client has failed to disclose information or suspects possible abuse of the EI program by a third party or employer, or when the client requests to correct previously provided information, the officer determines if the issue must be referred to Integrity. 

## What you need to know

Source topic: `en_EN/task/determining_issue_referred_integrity/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/determining_issue_referred_integrity/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3169.dita) 

### Referrals to Integrity

Source topic: `en_EN/task/determining_issue_referred_integrity/referrals_to_integrity.dita`

While processing a claim, the officer may discover that a client failed to disclose information.

The officer may also doubt the authenticity of the application and suspect that it was filed by a third party. The officer determines if the issue must be referred to Integrity for a determination of possible abuse.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3170.dita) 

### Ongoing investigation

Source topic: `en_EN/task/determining_issue_referred_integrity/ongoing_investigation.dita`

An ongoing investigation means that Integrity is investigating the case and has not yet sent it for adjudication (no Claim Review [CR] Integrity WI has been created). The existence of an ongoing investigation does not mean that the officer must refer issues to Integrity or move the WI to Pending until the investigation is complete. If the issue does not indicate possible abuse, the officer does not refer the issue to Integrity unless it is related to the ongoing investigation.

An officer can determine if there is an ongoing Integrity investigation from any of the following indicators:

- A 71 - Integrity Services case manual action (MA71) is imposed.

- A 71 - Integrity Services case disentitlement (D71) is imposed.

- An outstanding registration number containing a registration flag 1 - Integrity Services exists.

- An N-04-00-00 letter has been sent to request that a medical certificate be provided.

- A letter beginning with C-00, C-72, C-73 or C-88 has been sent by Integrity.

- For potentially fraudulent claims, an SROC created by Integrity might be on file indicating that the claim is under review.

If any of these indicators are present, the officer determines if the issue is related (same period) to the ongoing investigation before deciding to refer the issue to Integrity.

**Communicating information during an ongoing investigation**

When a client provides new information or requests information regarding an ongoing investigation , the officer forwards the information or request to Integrity with a Call back (CB) WI. If there is already a CB WI related to the issue under investigation , the officer reassigns the CB WI to Integrity. The officer does not assign it directly to the investigator.

**Communicating information when the investigation is complete**

When a client provides new information or requests information regarding an investigation that is complete , the officer forwards the information or request on a CB WI to the ISB Post Audit Processing level in NWS if the CR Integrity WI is unassigned. The CB WI can be assigned directly to the officer if the CR Integrity WI is assigned. 

### Fact-finding

Source topic: `en_EN/task/determining_issue_referred_integrity/fact-finding.dita`

When potential abuse is suspected, the officer must determine, based on the facts on file, if the imposition of a disqualification, disentitlement or an allocation of monies may cause an overpayment (OP). If it is clear that no OP will result, the officer does not refer the issue to Integrity. The officer adjudicates the issue following normal procedures.

If the officer determines that the issue must be referred to Integrity, the officer does not fact-find. Integrity officers initiate fact-finding in the process of the investigation. There are times when the officer may have done some fact-finding before realizing that the issue must be referred to Integrity. In these cases, the officer does not continue fact-finding and refers the issue to Integrity. 

### Common issues that can be referred to Integrity

Source topic: `en_EN/task/determining_issue_referred_integrity/common_issues_that_can_be_referred_to_integrity.dita`

- Benefits payable from another source — Employer non-compliance or client misrepresentation

- 15 - Claim Procedure disentitlement (D15) imposed by Integrity

- Medical certificate — Sickness benefits

- Ordinary place of residence

- ROE — Employer non-compliance issuing an ROE

- ROE — Potentially false or containing false information

- ROE issued by the Government of Canada

- ROE issued with the wrong SIN

- Fraudulent EI and EI Emergency Response Benefit (EI ERB), and the GCKey privacy breach

- Unreported contentious reason for separation (RFS)

- Unreported contentious issue other than reason for separation (RFS)

- Unreported earnings

- Information reported after claimant’s reports have been processed

**Benefits payable from another source — Employer non-compliance or client misrepresentation**

When an employer is a first payer for benefits such as paid sick leave (PSL) or wage loss insurance (WLI) but the employer is not meeting the obligation as first payer, the officer refers the issue to Integrity. The officer moves the WI to Pending until Integrity completes the investigation.

When there is information in the file that suggests that the client may be entitled to benefits from another source but did not declare it, there is possible misrepresentation, and the officer refers the issue to Integrity. To determine if this is the case, the officer examines the EI application and any other documents (e.g. SROCs, Call Back [CB] or Action Item [AI] WIs, checklists, imaged documents). The following chart provides the questions and answers on the EI application that indicate possible misrepresentation for each type of benefits paid from another source.

```text
| Information on file indicates there is a PSL or WLI plan, and the client answered at least one of the questions below as follows: |

| Question | Answer |

| Why did you not apply immediately after you stopped working? - Receiving or waiting to receive payment from my employer, from another insurer or payer - Ill or injured, and physically unable to apply - None of the above | The client selects None of the above . |

| Are you covered under a sickness benefit plan through your employer (paid sick leave or wage loss insurance)? - Yes - No | The client selects No . |

| Do not declare pension or worker’s compensation payments in this section. We will ask you to declare these types of payments later. Have you received or will you receive any of the following monies from this employer or from another source? Check all appropriate boxes. - Severance pay - Pay in lieu of notice - Statutory Holidays - Bonus and incentives (all) - Paid sick leave - Supplemental Unemployment Benefits (SUB) - Paid maternity leave - Group wage loss insurance - Honorarium - Salary Continuance - Profit Sharing - Retiring Allowances - Accumulated Sick Leave Credits - Other - I did not or will not receive additional money from any employer | The client selects I did not or will not receive additional money from any employer . |

| Information on file indicates that the client’s injuries were the result of an accident, and the client answered the question below as follows: |

| Question | Answer |

| Do you have an injury as the result of a motor vehicle accident? - Yes - No | The client selects No . |

| Information on file indicates that there is a preventive withdrawal plan or that the client is receiving preventive withdrawal payments, and the client answered at least one of the questions below as follows: |

| Question | Answer |

| Why did you not apply immediately after you stopped working? - Receiving or waiting to receive payment from my employer, from another insurer or payer - Ill or injured, and physically unable to apply - None of the above | The client selects None of the above . |

| Do not declare pension or worker’s compensation payments in this section. We will ask you to declare these types of payments later. Have you received or will you receive any of the following monies from this employer or from another source? Check all appropriate boxes. - Severance pay - Pay in lieu of notice - Statutory Holidays - Bonus and incentives (all) - Paid sick leave - Supplemental Unemployment Benefits (SUB) - Paid maternity leave - Group wage loss insurance - Honorarium - Salary Continuance - Profit Sharing - Retiring Allowances - Accumulated Sick Leave Credits - Other - I did not or will not receive additional money from any employer | The client selects I did not or will not receive additional money from any employer or does not select Other to declare the monies. |

| Information on file indicates that the client is receiving or will receive workers’ compensation benefits, and the client answered the question below as follows: |

| Question | Answer |

| Have you received or will you receive money through Workers’ Compensation? - Yes - No | The client selects No . |
```

**15 - Claim Procedure disentitlement (D15) imposed by Integrity**

Investigators direct the client to attend client information sessions or fact-finding interviews, or to reply to a request for information related to the current claim for benefits. Investigators also impose a D15 when a client fails to attend the information session or the fact-finding interview or fails to reply to the request for information.

Level 2 officers adjudicate the D15 only when it relates to a missed client information session. When a D15 is imposed for failure to attend a fact-finding interview or to reply to a request for information, Integrity reviews the D15 issue. However, the request for reconsideration officer reviews all cases in which clients have filed a reconsideration under EIA 112 or an appeal to the Social Security Tribunal (SST) on the D15 issue.

When a client contacts Service Canada regarding a missed client information session, the officer determines if there is an outstanding renewal on the client’s file. If an outstanding renewal application is on file and an existing D15 imposed by Integrity requires review, the issue is assigned to a Level 2 officer for adjudication, regardless of the timeframes.

In all other situations, the officer refers the D15 issue to Integrity.

Based on the letter sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent.

**Medical certificate — Sickness benefits**

When there is doubt as to the authenticity of a medical certificate or the signature of the doctor, the officer refers the issue to Integrity.

**Determining if an electronic signature is acceptable**

Acceptable forms of electronic signatures include, but are not limited to, the following:

- a simple electronic signature, which is a name drawn by typing or using the mouse and includes a Read and approved seal, which is displayed directly above the signature block.

- an advanced or qualified digital signature, which is a document signed with a digital certificate issued by a certification authority and then cryptographically sealed.

- a scanned handwritten signature, or an ink stamp on which the signature is engraved and can be uploaded electronically. The signature stamp itself does not need to include the doctor’s or other medical professional’s license number.

The doctor’s or other medical professional’s name typed on a medical document (in any font) is acceptable when other elements on the document, considered as a whole, reasonably lead to the conclusion that it is a legitimate medical certificate.

**Ordinary place of residence**

When the officer suspects that the client provided a false residential address to get a higher benefit rate, a greater number of entitlement weeks or even to qualify, the officer refers the issue to Integrity.

**ROE — Employer non-compliance issuing an ROE**

When the employer does not comply with a formal request sent by registered or certified mail for information that Service Canada (the Commission) is legally authorized to obtain, the officer refers the case to Integrity. One of the following may occur:

- An employer refuses to issue an ROE.

- An employer does not respond to a request for the correction or clarification of an ROE.

**ROE — Potentially false or containing false information**

These ROEs are not related to fraudulent activity by third parties. If the officer detects potential abuse concerning any of the information contained on the ROE, the officer refers the issue to Integrity without requesting an insurability ruling.

Potential abuses include the following:

- The officer suspects that the client never worked at the employment in question and that the employer issued a false ROE.

- The officer suspects an ROE contains false information such as inflated insurable hours or earnings.

- The officer suspects that the employer has misrepresented the reason for separation (RFS). For example:

- The client was laid off due to work shortage, but another employee continues to perform the client’s tasks.

- The client’s tasks are essential to the activities of the business, but the client is laid off due to shortage of work.

- The employer issues an ROE with a contentious RFS (quit or dismissal) and later amends the RFS to shortage of work and the officer suspects the RFS change is fraudulent.

- The serial number is not printed, is wrong, or it is a duplicate, when it is not the same employer to whom the blank ROE was originally given.

- The client may have used a SIN belonging to someone else and the officer suspects the ROE is fraudulent.

- An ROE is entered into RCM with a serial number that has been identified as lost, missing or stolen and the employer name on the ROE is not the same as the employer to whom the ROE was originally issued.

- The employer issues an additional ROE with only a few hours or amends a previously issued ROE adding enough hours so the client can qualify for EI benefits.

During the investigation, if an insurability ruling is required, an Integrity officer requests the ruling.

**ROE issued by the Government of Canada**

When fact-finding about an ROE that is missing or requires correction and the employer is a Government of Canada department or agency served by the Public Service Pay Centre , the officer refers to ROE issued by the Government of Canada — Instructions .
       [department or agency served by the Public Service Pay Centre](https://www.canada.ca/en/public-services-procurement/services/pay-pension/pay-administration/pay-centre-resources/departments-agencies-served-by-pay-centre.html) 
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

If an ROE for a Government of Canada department or agency is requested and not received within the required timeframe, the officer refers to Determining if an interim ROE is required .
       [Determining if an interim ROE is required](/en/procedure/task/determining_interim_roe.shtml)

If an interim ROE can be allowed , the officer creates an interim ROE by referring to Entering an interim ROE . When an interim ROE is created for a Government of Canada department or agency, the officer does not refer the issue to Integrity.
       [Entering an interim ROE](/en/procedure/task/entering_interim_roe.shtml)

The officer refers a missing ROE issue to Integrity only if an interim ROE cannot be created for a Government of Canada department or agency.

If an ROE is issued by a Government of Canada department or agency that is not served by the Public Service Pay Centre, the officer refers to normal procedures.

**ROE issued with the wrong SIN**

The officer refers ROEs that may have been issued with the wrong SIN to Integrity when:

- the employer is not able to provide the SIN for the client to whom the ROE belongs;

- the officer suspects that the ROE does not belong to the client for whom it was issued but the client maintains that it does.

**Fraudulent EI and EI Emergency Response Benefit (EI ERB) claims, and the GCKey privacy breach**

An officer may suspect or a client may report that their personal information was used fraudulently by another party to establish a claim. A third party may also interfere with the payment of benefits.

In some cases, the fraudulent claim prevents the client from receiving other benefit types (BTs) administered by the Canada Revenue Agency (CRA). In other cases, fraudulent activity prevents the client from receiving EI benefits or the EI ERB.

The most common issues related to fraudulent activity are as follows:

- The client is prevented from receiving another BT administered by the CRA due to an established EI or EI ERB claim. The application is fraudulently submitted by a third party.

- The client is receiving EI benefits or the EI ERB. A third party fraudulently submits a new application using the client’s information, but with different direct deposit or address information that does not belong to the client.

- The client is receiving EI benefits or the EI ERB. A third party fraudulently accesses the client’s MSCA and changes the direct deposit or address information.

When the legitimacy of the application is in doubt, the officer reviews the application to determine if any fraud indicators are present and decides if it should be referred to Integrity, even if no payment has been issued to a third party. The officer refers to Fraud indicators: Identifying potentially fraudulent applications — Knowledge for a detailed list of known fraud indicators, such as addresses and bank accounts.
       [Fraud indicators: Identifying potentially fraudulent applications — Knowledge](/en/procedure/generic/additionalresources/fraud_indicator.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3171.dita) 

The officer refers any case in which the client’s personal information has been compromised by a third party to Integrity for investigation.

If the client is trying to establish an EI claim after an EI ERB claim when an MA71 is already imposed for an EI ERB investigation, the officer thoroughly reviews the file before deciding if fraud is also suspected on the new EI application. If the officer suspects fraud, the officer:

- sends another referral to Integrity;

- imposes an MA71 to prevent, if necessary, the additional payment of benefits;

If the officer suspects that a skeleton or BPNE (N1, N2 or N7) claim is fraudulent, the officer imposes a D71 to prevent the claim from being finalized during the investigation.

**Social Insurance Registry (SIR) non-match**

Before the officer attempts to validate a client’s identity, the officer refers to Fraud indicators: Identifying potentially fraudulent applications — Knowledge and reviews the application for fraud indicators.
       [Fraud indicators: Identifying potentially fraudulent applications — Knowledge](/en/procedure/generic/additionalresources/fraud_indicator.shtml)

If a client’s identity cannot be validated on an initial EI claim, and the client was paid the EI ERB, the officer creates an AI WI and refers the claim to Integrity for investigation.

**GCKey — Canada Revenue Agency (CRA) privacy breach**

In response to the GCKey security incident, affected MSCA accounts have been disabled and access codes have been cancelled.

These accounts should contain an SROC indicating that for security reasons, the client has been assigned a temporary access code. In some cases, an MA71 was input and an investigation is ongoing.

The officer refers any case in which the client’s personal information has been compromised by a third party to Integrity for investigation.

For more information, the officer refers to COVID-19 and external communication strategy .
       [COVID-19 and external communication strategy](/en/site/dossier/information_covid19_external_communicatioin_strategy.shtml#_Letter_to_clients)

**Unreported contentious reason for separation (RFS)**

The officer determines if an unreported contentious RFS impacts the current work. If yes, the officer also determines the BT the client received after the last day worked (LDW) of the contentious RFS to determine if the issue must be referred to Integrity.

When the RFS impacts the officer’s work:

- If the client received only special benefits other than sickness after the LDW of the RFS, the officer does not refer the issue to Integrity. The officer refers to the appropriate procedure to adjudicate the RFS, if necessary.

- If the client received only sickness benefits after the LDW of the RFS, the officer determines if the information on file indicates a presumption that the client is not otherwise available:

- If yes, the officer refers the RFS and the availability issues to Integrity. If necessary, the officer imposes a manual action (MA) to stop payment.
             [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3172.dita)

- If no, the officer does not refer the issue to Integrity. The officer refers to the appropriate procedure to adjudicate the RFS, if necessary.

- If the client received regular benefits after the LDW, the officer determines if the RFS can be allowed based on the facts on file:

- If the client did not receive any benefits after the LDW and no OP will result, the officer does not refer the issue to Integrity. The officer refers to the appropriate procedure to adjudicate the RFS, if necessary.
         [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3173.dita)

When the RFS does not impact the officer’s work:

If the officer determines that there is an unreported contentious RFS that impacts a previous claim but does not impact the work the officer is currently doing, the officer does not adjudicate the issue and does not refer it to Integrity. The RFS prompts the creation of an investigation from one of Integrity’s detection programs.

**Unreported issue other than reason for separation (RFS)**

For other unreported contentious issues, such as pay-affected SE, non-referred training, leave of absence, availability, refusal of employment or incarceration, the officer determines if a disentitlement can be applied based on the facts on file before deciding to refer the issue to Integrity. If the client did not have an active claim at the time, no benefits were paid during the period in question or no disentitlement applies, the officer does not refer the issue to Integrity. If benefits were paid during the period in question and the client’s entitlement to those benefits is impacted, the officer imposes an MA to stop payment if required and refers the issue to Integrity.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3174.dita) 

**Unreported earnings**

If the officer discovers unreported earnings while examining the ROE and if the RFS is not contentious, the officer does not refer the issue to Integrity since the discrepancy between the earnings from the ROE and the earnings declared on the claimant’s reports will prompt the creation of a computer post-audit investigation.

If the officer discovers unreported SE earnings, the officer refers the issue to Integrity only if this issue impacts the payment of future benefits. If the officer can determine based on the facts on file that a disentitlement does not apply for the SE issue, the officer continues processing the claim.

If the client is providing information on earnings previously unreported on claimant’s reports, the officer refers to the following section.

**Error code C850**

If an error code C850 is received when the officer attempts to add or modify the client’s direct deposit information, the direct deposit information is listed on a restricted dataset and cannot be added. The officer must not share this information with the client.

If the officer receives the error code C850 when attempting to add or modify a client’s direct deposit information, the officer refers the claim to Integrity by creating an Action Item (AI) WI.

A detailed description of the error code is in WECS .
       [WECS](http://wecs-siew.prv/wecs-siew/lookup_e.aspx)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0089.dita) 

**Information reported after claimant’s reports have been processed**

A client can request to correct previously provided information or provide information that was previously omitted on the claimant’s report. In this situation, the officer determines when the request can be considered a simple error correction and when the issue must be referred to Integrity.

Correction requests for earnings (insurable and SE, including farming) are considered simple error corrections if the correction is actioned within 36 months from the week for which benefits were paid or payable.

For issues other than earnings, the client has 6 weeks from the week the original claimant’s report was processed to request the correction. Any request for correction received within that 6-week time limit is considered an error correction, and the officer makes the correction.

When the client is exempted from completing claimant’s reports, the officer makes the correction for earnings and any other issues when the client requests it within 6 weeks of the last payment of the exemption period was issued.

The officer does not make the correction and refers it to Integrity when an OP results from it and one of the following applies:

- For earnings corrections, the correction is actioned more than 36 months after the week for which benefits were paid or payable.

- For corrections of issues other than earnings, the client requests the correction more than 6 weeks from the week the original claimant’s report was processed.

- If the client is exempted from completing claimant’s reports, the client requests the correction for earnings and any other issues more than 6 weeks of the last payment for the exemption period was issued.

- The correction request includes weeks overlapping the 36-month (for earnings) or the 6-week (for all other issues) time limit.

- The correction request includes earnings and another issue that is beyond the 6-week time limit.

- An Integrity investigation has been initiated that includes any of the weeks.

If the request for correction received outside of timeframes results in an underpayment (UP) or if it is a correction that has no impact on the amount of benefits paid, a Level 2 officer must render a decision.

**Determining the cut-off date (COD) for an issue to be considered an error correction**

For earnings correction requests, the officer determines the COD by adding one week to the current week for notifying the client, and then subtracting 156 weeks.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3175.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3176.dita) 

For issues other than earnings, the client must correct the information within 6 weeks from the week the original claimant’s report was processed.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3177.dita) 

When the client is exempted from completing claimant’s reports, the officer makes the correction for earnings and any other issues when the client requests it within 6 weeks of the last payment of the exemption period was issued.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3178.dita) 

**Date of original statement — Issues other than earnings**

- If the original statement was received on an electronic claimant’s report, use the date the report was processed (if unassisted) or the date it was successfully completed (if assisted).

- If the original statement was received on a paper claimant’s report, use the date preceding the day the report was processed.

- If the original statement was received on any other paper document, use the date the paper document was received.

- If the original statement was received verbally, use the date of the verbal statement, as shown on the SROC or WI.

- If the client is exempted from completing claimant’s reports, use the date the last payment was issued.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3179.dita) 

**Date of request for correction**

- If the request for correction is received on a paper document, use the date the paper document is received.

- If the request for correction is received verbally, use the date of the verbal request, as shown on the SROC or WI. 

### Note

Source topic: `en_EN/common_notes/note_c_3169.dita`

Note:

The restriction on referring issues to Integrity has been lifted for all issues except self-employment (SE). The officer refers the file to Integrity only when the payment of future benefits is impacted by the SE issue. 

### Note

Source topic: `en_EN/common_notes/note_c_3170.dita`

Note:

This task is only to determine whether or not the issue must be referred to Integrity. To refer an issue to Integrity once the decision is made to do so, the officer refers to Creating or reassigning a WI — Integrity .
       [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

For information submitted by an informant, the officer refers to Receiving and referring an informant lead .
       [Receiving and referring an informant lead](/en/procedure/task/referral_integrity_informant_lead.shtml)

For investigations related to absences from Canada, the officer refers to Referring a request for information to the Miramichi Investigation Centre .
       [Referring a request for information to the Miramichi Investigation Centre](/en/procedure/task/referral_integrity_miramichi.shtml)

     [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml) 
     [Receiving and referring an informant lead](/en/procedure/task/referral_integrity_informant_lead.shtml) 
     [Referring a request for information to the Miramichi Investigation Centre](/en/procedure/task/referral_integrity_miramichi.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3171.dita`

Note:

When the application contains one of the addresses on the list of known fraudulent addresses, the officer automatically refers the file to Integrity. 

### Example

Source topic: `en_EN/common_notes/note_c_3172.dita`

Example:

On the ROE, block 16 - Reason for issuing this record of employment indicates E - Quit and block 18 - Comments indicates that the employee voluntarily left to return to school. The client applied for sickness benefits and did not declare the return to school on the EI application. Since the client received sickness benefits after the LDW of the RFS and there is an indication that the client returned to school, there is a presumption the client is not otherwise available for work. 

### Example

Source topic: `en_EN/common_notes/note_c_3173.dita`

Example:

Based on the facts on file, the officer determines that a disqualification may apply for the unreported RFS. However, an existing indefinite disqualification was previously imposed on the claim for another RFS. Since no OP will result, the officer does not refer the issue to Integrity. The officer refers to the appropriate procedure to adjudicate the RFS, if necessary. 

### Example

Source topic: `en_EN/common_notes/note_c_3174.dita`

Example:

The unreported issue is non-referred training. The officer determines that a disentitlement can be applied based on the facts on file, and that the client received benefits during the period in question. In this situation, the officer refers the issue to Integrity. If the officer determines a disentitlement cannot be applied based on the facts on file, the officer does not refer the issue to Integrity. The officer adjudicates the training issue along with any other assigned issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0089.dita`

Note:

If the client subsequently provides a different direct deposit account that is not rejected with the error code C850, the officer still refers the rejected direct deposit account information to Integrity. The officer also includes the rejected direct deposit information in the AI WI sent to Integrity. 

### Example

Source topic: `en_EN/common_notes/note_c_3175.dita`

Example:

The current week is w/c 2541. Adding one week for the notification and subtracting 156 weeks gives w/c 2386 as the COD. Any earnings correction requested by the client can be made from w/c 2386 to w/c 2541. 

### Note

Source topic: `en_EN/common_notes/note_c_3176.dita`

Note:

When the correction is for earnings and another issue, and it is beyond the 6-week time limit, the Level 1 officer refers the correction to Level 2 when there is no OP or when there is a potential UP. When there is a potential OP, the entire request is sent to Integrity and the officer does not make any correction. 

### Example 1

Source topic: `en_EN/common_notes/note_c_3177.dita`

Example 1:

The client completed a claimant’s report for w/c 2512-13 on w/c 2515. The client can request a correction for this claimant’s report until w/c 2521 (w/c 2515 + 6 weeks).

Example 2:

The client made a claimant’s report for w/c 2532-33 on w/c 2533 but it could not be completed without assistance. The client called the call center on w/c 2534 to have the claimant’s report completed by an officer. The client can request a correction for this claimant’s report until w/c 2540 (w/c 2534 + 6 weeks). 

### Example

Source topic: `en_EN/common_notes/note_c_3178.dita`

Example:

The BPC is w/c 2490 and the last payment of the exemption period has been issued on w/c 2533. The client has until w/c 2539 to request a correction for any week since the BPC. 

### Note

Source topic: `en_EN/common_notes/note_c_3179.dita`

Note:

For earnings correction requests, the officer considers the week in which the correction is actioned to calculate the 36-month timeframe, regardless of how the client’s original statement was made. 

## Regional considerations

Source topic: `en_EN/task/determining_issue_referred_integrity/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/determining_issue_referred_integrity/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/determining_issue_referred_integrity/in_fts.dita`

- Is an MA71 imposed?

- Is a D71 imposed?

- Is there an outstanding registration number with a 1 - Integrity Services registration flag?

- Is there a D15 on file?

- Did the client have an active claim and was the client receiving benefits at the time of the unreported contentious issue?

- If yes, what BT did the client receive? 

### In NWS:

Source topic: `en_EN/task/determining_issue_referred_integrity/in_nws.dita`

- Are there SROCs relating to an ongoing investigation?

- Is there a WI for Integrity?

- Is there a client Note relating to the ongoing investigation?

- Did the client provide details about the contentious issue on the new application?

- If the client received sickness benefits at the time of the unreported contentious issue, are there any SROCs, AI WIs or documentation that leads to the presumption that the client is not otherwise available? 

### IN ACS:

Source topic: `en_EN/task/determining_issue_referred_integrity/in_acs.dita`

- Has Integrity sent an N-04-00-00 or N-04-00-01 letter asking for an original medical certificate?

- Has an investigator sent a letter beginning with C-00, C-72, C-73 or C-88? 

### In RCM:

Source topic: `en_EN/task/determining_issue_referred_integrity/in_rcm.dita`

- Is there an ROE with an RFS that leads to a presumption that the client is not otherwise available? 

## Step by step

Source topic: `en_EN/task/determining_issue_referred_integrity/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/determining_issue_referred_integrity/non-complex.dita`

#### Procedures

Source topic: `en_EN/task/determining_issue_referred_integrity/procedures.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3180.dita) 

#### Reassigning the WI to Level 1

Source topic: `en_EN/task/determining_issue_referred_integrity/reassigning_the_wi_to_level_1_non-complex.dita`

- In NWS, reassign the WI to Level 1 as follows: 

#### Note

Source topic: `en_EN/common_notes/note_c_3180.dita`

Note:

The restriction on referring issues to Integrity has been lifted for all issues except SE. The officer refers the file to Integrity only when the SE issue impacts the payment of future benefits. 

### Level 1

Source topic: `en_EN/task/determining_issue_referred_integrity/level_1.dita`

#### Procedures

Source topic: `en_EN/task/determining_issue_referred_integrity/procedures.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3180.dita) 

#### Determining if there is an ongoing investigation

Source topic: `en_EN/task/determining_issue_referred_integrity/determining_if_there_is_an_ongoing_investigation_level_1.dita`

- Determine if there is an ongoing related investigation:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the issue is a D15 imposed by Integrity:

- If yes, and it is due to a missed client information session, go to step 3.

- If yes, and it is due to another reason, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If no, go to step 4.

- Determine if there is an outstanding renewal application on the client’s file:

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If yes, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_issue_referred_integrity#reassigning_the_issue) 

#### Determining if the issue must be referred to Integrity

Source topic: `en_EN/task/determining_issue_referred_integrity/determining_if_the_issue_must_be_referr_33e59f9c_level_1.dita`

- Determine if it is the client requesting to correct a previous original claimant’s report:

- If no, go to step 5.

- If yes, go to Error correction request .
               [Error correction request](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_issue_referred_integrity#_Error_correction_request)

- Determine if the issue is one of the following situations:

- The client wants to communicate information related to an ongoing investigation.

- There is evidence that the client has made a false statement regarding possible entitlement to benefits from another source, or the employer does not meet the obligation as first payer.

- The officer suspects that false information was provided on the ROE concerning the insurability of a client’s employment, the number of hours of insurable employment, the amount of insurable earnings or the period of employment during the qualifying period or has doubts that the client worked at the employment in question.

- An ROE is issued with just enough hours for the client to qualify for benefits, or the RFS appears altered or is changed after the client is notified of a negative decision.

- An employer refuses a request to issue an ROE or does not respond to a request for information regarding an ROE.

- Unable to obtain an ROE from the Government of Canada department served by the Public Service Pay Centre and an interim ROE cannot be created.

- The client reports or the officer discovers that personal information has been compromised.

- There is doubt as to the authenticity of the application.

- There is doubt as to the authenticity of a medical certificate or the signature of the doctor.

- The issue is related to an ongoing investigation of another issue.

- The client’s ordinary place of residence is in question.

- An error code C850 is received when the officer is adding or modifying the direct deposit information.

- If the issue is none of the above, go to step 6.

- If the issue is any of the above, go to Creating or reassigning a WI — Integrity to refer the issue to Integrity.
                   [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine all the unreported contentious issues related to the claim:

- If there is an unreported RFS issue, go to step 7.

- If there is an unreported issue other than an unreported RFS, go to step 9.

- If the only issue is a discrepancy in earnings reported after original claimant’s reports have been processed, go to step 11.

- Determine which BT the client received after the LDW at the employment with the unreported RFS:

- If any of the benefits received were sickness benefits, go to step 8.

- If the client received only regular benefits, go to step 9.

- If the client received only special benefits (other than sickness), the RFS is not referred to Integrity. Go to step 10.

- If the client did not receive any benefits, no further action is required. Return to the previous task.

- Determine if the RFS leads to a presumption that the client is not otherwise available:

- If no, but the client received sickness and regular benefits, go to step 9.

- If no, and the client received only sickness benefits, the RFS is not referred to Integrity. Go to step 10.

- If yes, the file must be referred to Integrity for the otherwise available and RFS issues. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Based on the facts on file, determine if the contentious issue can be allowed within the Level 1 authority (e.g. it is evident from the file that the client quit to take other employment):

- If yes, go to step 10.

- If no or if it is difficult or impossible to determine if it can be allowed without fact-finding, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_issue_referred_integrity#reassigning_the_issue)

- Determine if there is a discrepancy in earnings information after the original claimant’s reports have been processed:

- If yes, go to step 11.

- If no, go to step 13.

- Determine if the information is discovered within 36 months from the week for which benefits were paid or payable:

- If no, go to step 12.

- If yes, go to Modifying a claimant’s report to action the error correction, then go to step 13 of this task.
               [Modifying a claimant’s report](/en/procedure/task/modifying_cr.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3181.dita)

- Determine if an OP will result from the adjustment:

- If an OP will result, refer to Creating and reassigning a WI — Integrity so that Integrity can determine if the voluntary disclosure policy applies.
               [Creating and reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If no OP will result, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_issue_referred_integrity#reassigning_the_issue)

- Refer to the appropriate procedure to action the unreported issue if necessary or return to the previous task. 

#### Error correction request

Source topic: `en_EN/task/determining_issue_referred_integrity/error_correction_request_level_1.dita`

- Determine the information the client is requesting to correct:

- If it is earnings only , go to step 2.

- If it is an issue other than earnings, go to step 3.

- If it is earnings and another issue, go to step 4.

- Determine if the correction can be actioned within the 36-month timeframe:

- If yes, refer to Modifying a claimant’s report to action the correction and to complete the WI.
               [Modifying a claimant’s report](/en/procedure/task/modifying_cr.shtml)

- If no, go to step 5.

- Determine if the correction request is within the Level 1 authority and the 6-week timeframe:

- If yes, refer to the appropriate task to adjudicate the issue and to complete the WI.

- If no, go to step 5.

- Determine if the correction request for earnings and the other issue is within the 6-week timeframe and the Level 1 authority :

- If yes, go to Modifying a claimant’s report to action the earnings correction and to the appropriate task to adjudicate the other issue and to complete the WI.
               [Modifying a claimant’s report](/en/procedure/task/modifying_cr.shtml)

- If no, go to step 5.

- Determine if an OP will result from the correction:

- If yes, refer to Creating and reassigning a WI — Integrity so that Integrity can determine if the voluntary disclosure policy applies.
               [Creating and reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_issue_referred_integrity#reassigning_the_issue) 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/determining_issue_referred_integrity/reassigning_the_issue_to_level_2_level_1.dita`

- Determine if there is a WI for the issue to adjudicate:

- If yes, reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Select the appropriate option:

- For a D15, type “Missed client information session, outstanding renewal application on file.”

- For other issues, type “The unreported (type of issue) has been discovered and is not within Level 1 authority. Adjudication is required.” or “The client requests an error correction but it is beyond the appropriate timeframe and [no OP will result from the correction or an UP will result from the correction]. Adjudication is required.”

- Select Update .

- Go to step 2.

- If no, create an Adjudication Issue (ADJ) WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Select the Service Canada centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select the appropriate issue.

- Details: Select the appropriate option:

- For a D15, type “Missed client information session, outstanding renewal application on file.”

- For other issues, type “The unreported (type of issue) has been discovered and is not within Level 1 authority. Adjudication is required.” or “The client requests an error correction but it is beyond the appropriate timeframe and [no OP will result from the correction or an UP will result from the correction]. Adjudication is required.”

- Select Save .

- Go to the appropriate procedure to action the unreported issue if necessary, or return to the previous task. 

#### Note

Source topic: `en_EN/common_notes/note_c_3181.dita`

Note:

If the information is for an EI ERB claim, the officer does not refer it to Integrity.

For more information on determining the 6-week error correction timeframe based on the original claimant’s report, refer to the National Policy on Levels of Decision — Voluntary disclosure and error correction .
       [National Policy on Levels of Decision — Voluntary disclosure and error correction](/en/policy/nationalpolicy/levels_decision-annex1.shtml#s19)

     [National Policy on Levels of Decision — Voluntary disclosure and error correction](/en/policy/nationalpolicy/levels_decision-annex1.shtml#s19) 

### Level 2

Source topic: `en_EN/task/determining_issue_referred_integrity/level_2.dita`

#### Procedures

Source topic: `en_EN/task/determining_issue_referred_integrity/procedures.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3180.dita) 

#### Determining if there is an ongoing investigation

Source topic: `en_EN/task/determining_issue_referred_integrity/determining_if_there_is_an_ongoing_investigation_level_2.dita`

- Determine if there is an ongoing related investigation:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the issue is a D15 imposed by Integrity:

- If yes, and it is due to a missed client information session, go to step 3.

- If yes, and it is due to another reason, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If no, go to step 4.

- Determine if there is an outstanding renewal application on the client’s file:

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If yes, go to Reviewing a D15 disentitlement — Failure to attend a client information session .
               [Reviewing a D15 disentitlement — Failure to attend a client information session](/en/procedure/task/determining_ent_info_session.shtml) 

#### Determining if the issue must be referred to Integrity

Source topic: `en_EN/task/determining_issue_referred_integrity/determining_if_the_issue_must_be_referr_33e59f9c_level_2.dita`

- Determine if it is the client requesting to correct a previous original claimant’s report:

- If no, go to step 5.

- If yes, go to Error correction request .
               [Error correction request](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_issue_referred_integrity#Error_correction_request_l2)

- Determine if the issue is one of the following situations:

- The client wants to communicate information related to an ongoing investigation.

- There is evidence that the client has made a false statement regarding possible entitlement to benefits from another source, or the employer does not meet the obligation as first payer.

- The officer suspects that false information was provided on the ROE concerning the insurability of a client’s employment, the number of hours of insurable employment, the amount of insurable earnings or the period of employment during the qualifying period, or has doubts that the client worked at the employment in question.

- An ROE is issued with just enough hours for the client to qualify for benefits, or the RFS appears altered or is changed after the client is notified of a negative decision.

- An employer refuses a request to issue an ROE or does not respond to a request for information regarding an ROE.

- Unable to obtain an ROE from the Government of Canada department served by the Public Service Pay Centre and an interim ROE cannot be created.

- The client reports or the officer discovers that personal information has been compromised.

- There is doubt as to the authenticity of the application.

- There is doubt as to the authenticity of a medical certificate or the signature of the doctor.

- The issue is related to an ongoing investigation of another issue.

- The client’s ordinary place of residence is in question.

- An error code C850 is received when the officer is adding or modifying the direct deposit information.

- If the issue is none of the above, go to step 6.

- If the issue is any of the above, go to Creating or reassigning a WI — Integrity to refer the issue to Integrity.
                   [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine all the unreported contentious issues related to the claim:

- If there is an unreported RFS issue, go to step 7.

- If there is an unreported issue other than an unreported RFS, go to step 9.

- If the only issue is a discrepancy in earnings reported after original claimant’s reports have been processed, go to step 10.

- Determine which BT the client received after the LDW at the employment with the unreported RFS:

- If any of the benefits received were sickness benefits, go to step 8.

- If the client received only regular benefits, go to step 9.

- If the client received only special benefits (other than sickness), the RFS is not referred to Integrity. Go to step 9.

- If the client did not receive any benefits, no further action is required. Return to the previous task.

- Determine if the RFS leads to a presumption that the client is not otherwise available:

- If no, but the client received sickness and regular benefits, go to step 9.

- If no, and the client received only sickness benefits, the RFS is not referred to Integrity. Go to step 9.

- If yes, the file must be referred to Integrity for the otherwise available and RFS issues. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine if there is a discrepancy in earnings information after the original claimant’s reports have been processed:

- If yes, go to step 10.

- If no, go to step 12.

- Determine if the information is discovered within 36 months from the week for which benefits were paid or payable:

- If no, go to step 11.

- If yes, go to Modifying a claimant’s report to action the error correction, then go to step 12 of this task.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3181.dita) 
               [Modifying a claimant’s report](/en/procedure/task/modifying_cr.shtml)

- Determine if an OP will result from the adjustment:

- If an OP will result, refer to Creating and reassigning a WI — Integrity so that Integrity can determine if the voluntary disclosure policy applies.
               [Creating and reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If no OP will result, go to Modifying a claimant’s report to allocate the earnings.
               [Modifying a claimant’s report](/en/procedure/task/modifying_cr.shtml)

- Refer to the appropriate procedure to action the unreported issue if necessary or return to the previous task. 

#### Error correction request

Source topic: `en_EN/task/determining_issue_referred_integrity/error_correction_request_level_2.dita`

- Determine the information the client is requesting to correct:

- If it is earnings only , go to step 2.

- If it is an issue other than earnings, go to step 3.

- If it is earnings and another issue, go to step 4.

- Determine if the correction can be actioned within the 36-month timeframe:

- If yes, refer to Modifying a claimant’s report to action the correction and to complete the WI.
               [Modifying a claimant’s report](/en/procedure/task/modifying_cr.shtml)

- If no, go to step 5.

- Determine if the correction request is within the 6-week timeframe:

- If yes, refer to the appropriate task to adjudicate the issue and to complete the WI .

- If no, go to step 5.

- Determine if the correction for earnings and the other issue is within the 6-week timeframe :

- If yes, go to Modifying a claimant’s report to action the earnings correction and to the appropriate task to adjudicate the other issue and to complete the WI.
               [Modifying a claimant’s report](/en/procedure/task/modifying_cr.shtml)

- If no, go to step 5.

- Determine if an OP will result from the correction :

- If yes, refer to Creating and reassigning a WI — Integrity so that Integrity can determine if the voluntary disclosure policy applies.
               [Creating and reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If no, refer to Modifying a claimant’s report or to the appropriate task to adjudicate the issue and to complete the WI.
               [Modifying a claimant’s report](/en/procedure/task/modifying_cr.shtml) 

## Policy reference

Source topic: `en_EN/task/determining_issue_referred_integrity/policy_reference.dita`

 
