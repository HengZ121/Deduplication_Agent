# Converting a claim from maternity to regular benefits

Source map: `en_EN/task/conv_matreg/conv_matreg.ditamap`

## Summary

Source topic: `en_EN/task/conv_matreg/summary.dita`

Summary: After receiving maternity benefits, clients may request regular benefits. 

## What you need to know

Source topic: `en_EN/task/conv_matreg/what_you_need_to_know.dita`

### Qualifying for regular benefits

Source topic: `en_EN/task/conv_matreg/qualifying_for_regular_benefits.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2725.dita) 

For a claim to be converted to regular benefits, the entitlement conditions for regular benefits must be met.

When clients qualify for regular benefits at BPC, a number other than 0 is displayed in the Entitlement weeks field on the Summary tab in FTS. Since major attached clients who qualify for regular benefits from BPC are entitled to all benefits types (BTs), a claim conversion to regular benefits is then possible.

When clients have accumulated more than 600 insurable hours but have not accumulated enough insurable hours to meet the variable entrance requirements (VER) , the Entitlement weeks field on the Summary tab in FTS displays 0 and the client must establish a new claim to collect regular benefits.
       [variable entrance requirements (VER)](/en/procedure/generic/additionalresources/ver_reg_ben.html)

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2726.dita) 

**Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment is required to establish a claim for regular or special benefits. If the client has a violation on file, increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the definitions for major attachment claimant and minor attachment claimant in subsection 6(1) of the Employment Insurance Act are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits, regardless of the conversion date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to regular benefits

Source topic: `en_EN/task/conv_matreg/entitlement_to_regular_benefits.dita`

A client can receive regular benefits after receiving special benefits if the following conditions are met:

- The client must qualify to receive regular benefits.

- The client must not have reached the LRW.

- The client must have received less than the maximum benefit entitlement .
         [maximum benefit entitlement](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

If all the conditions are met, the claim can be renewed or converted accordingly and regular benefits can be paid.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2653.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2727.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0021.dita) 

### Levels of Decision

Source topic: `en_EN/task/conv_matreg/levels_of_decision.dita`

When a client requests to convert her claim from maternity to regular benefits within the maternity period, the officer must determine if the decision is within Level 1 authority before finalizing the conversion. If the client applies for regular benefits before the confinement date, all of the following conditions must be met:

- The client was laid off due to a work shortage before or during the maternity period or was receiving regular benefits before the maternity period.

- The client’s maternity leave at her place of employment was not scheduled for the period for which she is requesting regular benefits.

- The client is capable of and available for work and places no restrictions on the acceptance of employment. She answers as follows in the appropriate checklist:

- “Yes” to questions 5, 6 and 6b of the Maternity to Regular Benefits - Employed checklist

- “Yes” to questions 2, 3 and 4 of the Maternity to Regular Benefits - Not Employed checklist

If the client applies for regular benefits 14 days or more after the date of confinement, all of the following conditions must be met:

- The client is not entitled to maternity benefits.

- The client is laid off for shortage of work or was receiving regular benefits before the confinement date.

- The client’s maternity leave at her place of employment was not scheduled for the period for which she is requesting regular benefits.

- The client is capable of and available for work and places no restrictions on the acceptance of employment. She answers as follows in the appropriate checklist:

- “Yes” to questions 5, 6 and 6b. of the Maternity to Regular Benefits - Employed checklist

- “Yes” to questions 2, 3 and 4 of the Maternity to Regular Benefits - Not Employed checklist

Fact-finding with both the employer and the client is required to determine whether or not the client had provided the employer with the dates of her planned maternity leave.

In all cases, the officer must document the client’s statement about the leave she scheduled with her place of employment.

If the client does not meet any of the criteria listed above, the Level 1 officer must create a WI for each contentious issue and reassign it to Level 2. 

### Outstanding disentitlements

Source topic: `en_EN/task/conv_matreg/outstanding_disentitlements.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies to the conversion. A Level 1 officer can terminate the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . If the information on file allows for the disentitlement to be terminated, the disentitlement is terminated on the Friday of the week before the conversion week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer refers the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer can refer to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Allocation of monies

Source topic: `en_EN/task/conv_matreg/allocation_of_monies.dita`

Whenever clients report receiving monies, the officer must determine if these monies are considered earnings for EI purposes. Once it is determined that the monies are earnings, they must be allocated. To determine how the earnings are allocated, the officer must refer to Earnings .
       [Earnings](/en/procedure/activity/earnings.shtml) 

### Reason for separation (RFS)

Source topic: `en_EN/task/conv_matreg/reason_for_separation_rfs.dita`

When clients voluntarily leave or are dismissed from their employment, their entitlement to regular benefits may be affected. If the RFS cannot be allowed at Level 1 according to the National policy on Levels of Decision , the voluntary leaving or dismissal must be reassigned to Level 2 for adjudication.
       [National policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Availability

Source topic: `en_EN/task/conv_matreg/availability.dita`

When clients request a conversion to regular benefits, their availability for work must be reviewed. Clients must prove that they are immediately available and actively seeking employment with no undue restrictions that would limit their opportunity to become re-employed from the start of the requested regular benefits period. Clients are required to document their job search. If there is any doubt with respect to a client’s availability, the officer must refer to Availability .
       [Availability](/en/procedure/activity/availability.shtml) 

### Temporary foreign workers (900-series SINs)

Source topic: `en_EN/task/conv_matreg/temporary_foreign_workers_900-series_sins.dita`

All foreign workers are given temporary resident status for a limited period of time when they enter Canada. Generally, foreign workers can demonstrate availability to accept work only if they possess a valid work permit which allows them to work in Canada. Therefore, when a foreign worker wants to renew or convert a claim to regular benefits, the validity of their work permits must be reviewed. 

### Effective date of a renewal or a conversion

Source topic: `en_EN/task/conv_matreg/effective_date_of_a_renewal_or_a_conversion.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer can refer to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Return to work (RTW)

Source topic: `en_EN/task/conv_matreg/return_to_work_rtw.dita`

If there is an RTW on the claim that falls on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer refers the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### Conversions from maternity benefits on a continuing claim

Source topic: `en_EN/task/conv_matreg/conversions_from_maternity_benefits_on__e9f3b92a.dita`

**Processing claimant’s reports**

The last week of maternity benefits must be paid before the officer can input the conversion transactions. If claimant’s reports have not yet been processed for the maternity benefits period, they must be processed before inputting the conversion. This requires a 2-day input.

**Previously deferred adjudication on reasons for separation (RFSs)**

After converting a claim to regular benefits, any RFS for which adjudication had previously been deferred must be adjudicated.

When the claim is calculated, if the RFS adjudication is deferred, a disqualification is automatically imposed and appears in FTS on the Disqualification/Disentitlement screen.

The officer always verifies if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 10 - Dismissal - misconduct proven (D10) or 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If there is a ROD on file indicating that adjudication of an RFS was deferred, the RFS must be adjudicated. A Level 1 officer can adjudicate the RFS according to the National Policy on Levels of Decision . If it is not within Level 1 authority, the RFS is reassigned to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2728.dita) 

**Adjudicating new contentious issues**

When converting a continuing claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If there is no existing WI for this issue, the Level 1 officer creates a Claim Review (CR) WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision. If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated. 

### Conversions from maternity benefits on a renewal claim

Source topic: `en_EN/task/conv_matreg/conversions_from_maternity_benefits_on__05aac365.dita`

**Renewal advantages**

When assessing a renewal, it might be to the client’s advantage to establish a new BP instead of renewing the existing BP. The officer must refer to Cancelling, voiding, terminating or withdrawing a claim for more information.
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml)

**Subsequent claim**

The renewal application can be used to establish a subsequent claim when the following conditions are met:

- The claim is renewed and there are 4 or fewer weeks of benefits remaining in the BP.

- The client has worked enough hours to establish a new claim.

ACP can register the subsequent claim if the Claim Assessment (CA) WI for a renewal or subsequent initial claim is finalized within 28 days of the renewal application. When ACP cannot register the subsequent claim because the renewal is not processed within 28 days of the renewal application (i.e. REN WK not found or no match and polling limit exceeded is displayed on the Processing Activities tab in NWS) or when the claim was converted to MPS, the officer processing the CA Renewal WI creates a Reminder (REM) WI. This ensures that an officer will manually register the subsequent claim.

**Adjudicating new contentious issues**

When renewing a claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If the issue is reported on the application, the system creates an Adjudication Issue (ADJ) WI. If a contentious issue is detected while reviewing the claim, the Level 1 officer must create an ADJ WI for each contentious issue and must attempt to adjudicate the issue according to the National Policy on Levels of Decision . If the Level 1 officer cannot adjudicate the issue, the ADJ WI is referred to Level 2 for adjudication. When an ADJ WI is created on a renewal claim, either manually or by the system, the system automatically imposes an 2 - Contentious Renewal in Automation manual action (MA2) to prevent payment of benefits until the contentious issue is adjudicated. When the renewal or a decision must be input manually, the inputs must be done before the CA WI is completed, as the completion of the WI triggers the removal of the MA2 by the system if there is no outstanding ADJ WIs. An officer cannot rescind an MA2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Claim action status and processing of the claim

Source topic: `en_EN/task/conv_matreg/claim_action_status_and_processing_of_the_claim.dita`

The Claim action status Renewal is created when a renewal decision is registered. There are 3 Claim action statuses that may be displayed:

- In Progress (Automation) is displayed on the Client information tree when there is one or more outstanding adjudication issues.

- In Progress (Manual) is displayed on the Client information tree when there is no outstanding adjudication issue and there is an outstanding CA or Specialized Application (SA) WI.

- Finalized is displayed on the Client information tree when all ADJ WIs are completed and the renewal week has been successfully input.

An ADJ WI is created for every new contentious issue. When opening an ADJ WI, the officer must always check to see if there is a Resolve Issue tab. If there is a Resolve Issue tab, the officer can document the decision directly in the ADJ WI by completing all mandatory screens. When the ADJ WI is completed, NWS creates a ROD based on the Resolve Issue screens. When the renewal is finalized, the system also generates the required transactions (e.g. signature code, disentitlement) based on the Resolve Issue screens. If a disentitlement or indefinite disqualification is imposed, the system creates a Correspondence (COR) WI for the D-01-00-00 letter. This means that the officer with the CA or SA WI has no action to perform for these ADJ WIs.

If there is no Resolve Issue tab for the ADJ WI, the officer must create a ROD, generate the required transactions and send the appropriate letter. If there is an outstanding CA or SA WI when the officer completes the ADJ WI, a client Note is created and the officer with the CA or SA WI must follow the instructions to input the transactions or send the letter. 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/task/conv_matreg/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an Action Item (AI), Call Back (CB), Assessment Issue (ASMT) or REM WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### ACS letters

Source topic: `en_EN/task/conv_matreg/acs_letters.dita`

Communication of the renewal decision is not necessary when the only transaction input is the renewal transaction. When another decision is input at the time of the renewal (disentitlement, disqualification or allocation of earnings), communication of the decision is necessary.

Written communication of the decision is usually done by officers who are responsible for sending the appropriate letter. In certain situations, the R-01-00-00 letter is sent automatically. Officers must ensure that the letter was sent and, if it was not sent, they must create and send the letter of decision in ACS.

If a renewal and an allocation are input by the same officer and are processed on the same day, the R-01-00-00 letter is, in most cases, created automatically.

However, the letter is not sent automatically if one of the following conditions is met:

- One of the transactions (M106 or M175) rejects.

- The allocation code on the M175 is A , D , or N .

- An E or W allocation is input for more than one week.

- A stop payment is imposed (MA01, MA02, MA48, MA71, MA72, MA73, MA74, MA75).

- A disqualification or disentitlement is being input.

- A disqualification or disentitlement is already on file and is not being rescinded or terminated.

In some cases, the letter may be sent automatically but additional decisions must be communicated. To prevent duplication of letters, the officer must prevent the letter from being sent automatically by using the Automated Letter Bypass function in FTS. 

### Note

Source topic: `en_EN/common_notes/note_c_2725.dita`

Note:

Clients receiving and entitled to maternity benefits do not have to convert to regular benefits if they are being referred to training. If the client is on a continuing maternity claim, refer to Confirming referred training — Special benefits — Continuing claim to process the training.
       [Confirming referred training — Special benefits — Continuing claim](/en/procedure/task/confirmreftrng_sb_con.shtml)

     [Confirming referred training — Special benefits — Continuing claim](/en/procedure/task/confirmreftrng_sb_con.shtml) 

### Example

Source topic: `en_EN/common_notes/note_c_2726.dita`

Example:

A benefit period (BP) is established on January 7, 2024 for special benefits with 674 insurable hours. The regional rate of unemployment (RRU) is 5.8% and the VER is 700 insurable hours. The claim is established with an administrative disentitlement to prevent the payment of regular benefits because the client qualifies for special benefits but not for regular benefits. In FTS, the Entitlement weeks field indicates 0 weeks. The client receives special benefits after serving the waiting period (WP). 

### Note

Source topic: `en_EN/common_notes/note_c_2653.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2727.dita`

Note:

If a client is not entitled to regular benefits, the officer must determine if the client can establish a new claim. If the client filed a renewal application, it is used to determine if the client qualifies for a new initial claim. 

### Note

Source topic: `en_EN/common_notes/note_c_0021.dita`

Note:

If the client has a violation, there may be increased entrance requirements .
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Note

Source topic: `en_EN/common_notes/note_c_2728.dita`

Note:

For all initial claims and recalculations with a BPC between w/c 2310 and w/c 2361, only the last period of employment requires adjudication if it was previously deferred. 

## Regional considerations

Source topic: `en_EN/task/conv_matreg/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/conv_matreg/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/conv_matreg/in_nws.dita`

- Did the client file a renewal application requesting a conversion of benefits?

- Does the client have a 900-series SIN?

- Has the client worked since the last week paid?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies, motor vehicle accident compensation, workers’ compensation benefits or wage loss insurance payments to consider or allocate?

- Was a RFS previously deferred?

- Is there an ADJ WI?

- If yes, for what issue?

- Is the client available for work? 

### In FTS:

Source topic: `en_EN/task/conv_matreg/in_fts.dita`

- Is there a number other than 0 displayed in the Entitlement weeks field?

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the LRW been reached?

- Has the WP been served, half served, waived or deferred?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Is there an RTW on the claim?

- Are there any pending claimant’s reports or claimant’s reports to be processed before the conversion?

- Is there a registration number? 

### In RCM:

Source topic: `en_EN/task/conv_matreg/in_rcm.dita`

- Has an ROE been submitted?

- Are there earnings, separation monies, motor vehicle accident compensation, WCB or WLI payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/conv_matreg/in_imaging.dita`

- Is there any other documentation which may impact the conversion claim? 

## Step by step

Source topic: `en_EN/task/conv_matreg/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/conv_matreg/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/conv_matreg/reviewing_the_file_level_1.dita`

- In NWS, determine if there is a SIR Validation (SIR) WI:

- If yes, go to step 2.

- If no, go to step 4.

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting completion of SIR WI.”

- Bring forward date: Enter today’s date + 10 days.

- When the CA WI moves to the current workload, determine if the SIR WI has been completed:

- If no, repeat step 2.

- If yes, go to step 4.

- Determine if a registration number related to the conversion is on file:

- If yes, go to step 5.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Go to step 5.

- In FTS, determine if the Summary tab displays a number other than 0 in the Entitlement weeks field:

- If no, go to No entitlement to regular benefits .
               [No entitlement to regular benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_matreg#specben)

- If yes, select the appropriate option:

- If the client has been paid the maximum combination of regular and special benefits , go to Maximum combination of regular and special benefits already paid .
                   [maximum combination of regular and special benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml) 
                   [Maximum combination of regular and special benefits already paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_matreg#max50)

- If the client has been paid all regular weeks of entitlement, go to Maximum regular benefits already paid .
                   [Maximum regular benefits already paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_matreg#maxreg)

- If there is a D10 or D11 disqualification imposed as a result of adjudication, go to step 6.

- If none of the above applies, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- Determine if the client has worked since the BPC:

- If no, go to step 7.

- If yes, determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for regular benefits ):

- If no, go to step 7.

- If yes, continue with the calculation procedure.

               [Calculating or recalculating a claim for regular benefits](/en/procedure/activity/calculation.shtml)

- Determine if there is a pending electronic claimant’s report on the E-Report tab for the period before the conversion:

- If no, go to step 8.

- If yes, refer to Actioning a pending claimant’s report and then go to step 8.
               [Actioning a pending claimant’s report](/en/procedure/task/pending_cr.shtml)

- Determine if there are any rejected electronic claimant’s reports on the Pending/Reject tab for the period before the conversion:

- If no, go to step 9.

- If yes, re-input the claimant’s reports. Refer to Actioning a rejected claimant’s report and then go to step 9.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml)

- Determine if the client reports having received monies and whether they have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings and go to step 10.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 10.

- If no monies were received, go to step 10.

- In NWS and in FTS, determine if one of the following conditions to extend the BP is met:

- The client was incarcerated and has since been tried and has not been found guilty.

- The client received WCB payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If one of the conditions is met, refer to Extension of the benefit period and go to step 11.
                   [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions is met, go to step 11.

- Determine if the LRW has been reached:

- If no, go to step 12.

- If yes, go to Last renewable week (LRW) has been reached .
               [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_matreg#lrw)

- Determine if the client is requesting regular benefits before or after the confinement date:

- If the client is requesting regular benefits before the confinement date, go to step 13.

- If the client is requesting regular benefits after the confinement date, go to step 14.

- Determine if the following conditions are met to allow the conversion at Level 1:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2729.dita) 

- If it is unknown and additional fact-finding is required, go to step 15.

- If yes, go to step 19.

- If no and the conversion is on a continuing claim, in NWS, create a CR WI for Level 2 as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- Select Save .

- Go to step 19.

- If no and the conversion is on a renewal claim, in NWS, create an ADJ WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue(s): Select Availability .

- Details: Type “Not within Level 1 authority.”

- Select Save .

- Go to step 19.

- Determine if the following conditions are met to allow the conversion at Level 1:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2730.dita) 

- If it is unknown and additional fact-finding is required, go to step 15.

- If yes, go to step 19.

- If no and the conversion is on a continuing claim, in NWS, create a CR WI for Level 2 as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- Select Save .

- Go to step 19.

- If no and the conversion is on a renewal claim, in NWS, create an ADJ WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination- SCC: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue(s): Select Availability .

- Details: Type “Not within Level 1 authority.”

- Select Save .

- Go to step 19. 

#### Fact-finding

Source topic: `en_EN/task/conv_matreg/fact-finding_level_1.dita`

- Fact-find with the client or employer. Refer to the National Fact-Finding and Documentation Policy .

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 17.

- If the client was not reached or did not reply to the N-10-00-00 letter, go to step 18.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Conversion .

- Comments: Type “Conversation with the client.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Return to step 14.

- In NWS, create a ROD as follows:

- Comments: Type “Information needed, cannot process conversion.”

- Details: Type “Attempt to contact client made on (insert date). Letter sent on (insert date). Information missing. Cannot input conversion.”

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2731.dita)

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 20.

- If no, go to step 22.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, go to step 21.

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 22.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine the claim type:

- If it is a conversion on a continuing claim, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 22.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If it is a conversion on a renewal claim, in NWS, create an ADJ WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Next Available User .

- Issue: Select Availability .

- Details: Type “outstanding D15 for a missed client information session, Level 2 review required.”

- Select Save .

- Go to step 22.

- Determine if there are any other outstanding disentitlements on file:

- If no, go to step 24.

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 23.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Complete the mandatory fields required for the issue.

- Details: Type “Outstanding [type of disentitlement] disentitlement.”

- Select Save .

- Refer to the appropriate procedure and then go to step 23.

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If yes, complete the steps from the appropriate procedure and go to step 24.

- If no, reassign the WI to Level 2 and go to step 24.

- Determine if there are any outstanding issues on file that require adjudication that do not have a related WI:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2732.dita)

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If no, reassign the WI to Level 2 and go to step 26.

- If yes, complete the steps from the appropriate procedure and go to step 26.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine if the conversion is on a renewal claim:

- If the conversion is on a renewal claim, go to step 28.

- If the conversion is on a continuing claim, go to Conversion on a continuing claim .
               [Conversion on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_matreg#continuin)

- In NWS, determine if there is an outstanding ADJ WI :

- If no , go to Conversion on a renewal — No outstanding adjudication.
               [Conversion on a renewal — No outstanding adjudication.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_matreg#no)

- If yes, go to Conversion on a renewal — Outstanding adjudication .
               [Conversion on a renewal — Outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_matreg#outstanding) 

#### Maximum combination of regular and special benefits already paid

Source topic: `en_EN/task/conv_matreg/maximum_combination_of_regular_and_spec_5cf2309f_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no , go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for regular benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “No conversion — maximum combination of benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC — no conversion.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify — no conversion.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2733.dita)

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Maximum regular benefits already paid

Source topic: `en_EN/task/conv_matreg/maximum_regular_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no , go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for regular benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “No conversion — maximum regular benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the maximum amount of regular benefits has been paid during the benefit period. The client does not qualify for a new claim as no hours were accumulated after the BPC — no conversion.”

- If the client has worked since the BPC , type “No conversion is possible as the maximum amount of regular benefits has been paid during the benefit period. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify — no conversion.”

- In NWS, create a ROD as follows:

- Comments: Type “No regular benefits paid — regular benefits exhausted.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum amount of regular benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC — no conversion.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum amount of regular benefits to which the client is entitled. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC. The client needed [number of hours] to qualify — no conversion.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2734.dita)

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/conv_matreg/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for regular benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “LRW reached — regular benefits requested.”

- Details: Select one of the following:

- If the client has not worked since the BPC , type “No conversion is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as no hours were accumulated after the BPC.”

- If the client has worked since the BPC , type “No conversion is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC. The client needed [number of hours] to qualify.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2735.dita)

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### No entitlement to regular benefits

Source topic: `en_EN/task/conv_matreg/no_entitlement_to_regular_benefits_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for regular benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “No regular benefits entitlement — Disentitlement on file.”

- Details: Type the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as a D46 is on file and the client does not qualify for a new claim as no hours were accumulated after the BPC. No regular benefits payable.”

- If the client has worked since the BPC , type “No conversion is possible as a D46 is on file and the client does not qualify for a new claim as [number of hours] were accumulated after the BPC. The client needed [number of hours] to qualify. No regular benefits payable.”

- In FTS, select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612):
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2736.dita)

- In NWS, complete the WI. 

#### Conversion on a continuing claim

Source topic: `en_EN/task/conv_matreg/conversion_on_a_continuing_claim_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the applicable registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if applicable).

- Claim type: Select 2 - Regular .

- Manual Action: Select the appropriate option (only if there is an outstanding Level 2 adjudication is required).

- If a D15 is also required, complete the following fields:

- Action: Select Add .

- Disentitlement: Select 15 - Claim procedure .

- Start date: Enter the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select the appropriate option:

- If the conversion did not require Level 2 adjudication, select 1 - No .

- If the conversion required Level 2 adjudication, select 2 - Yes .

- Complete: Select the appropriate option:

- If the Level 2 adjudication is required, select D - No to leave the registration number open for subsequent transactions.

- If the Level 2 adjudication is not required, select C - Yes to complete the registration number.

- Select Update .

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement is being imposed.

- There is an indefinite disqualification on file.

- If there are decisions that must be communicated to the client, go to step 3.

- If there are no decisions that must be communicated to the client, go to step 6.

- In ACS, create or add to the saved in the D-01-00-00 letter. Based on the claim information, select all the required attributes, including the following:

- To advise the client of the renewal/revival week:

- Renewal week - Sunday’s date (1246).

- To advise the client that the antedate has been denied:

- Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Select Antedate Denied (2483) .

- Select Antedate denied - Renewal/continuing claims (2484) .

- Select Renewal application not filed on time and no good cause for delay .

- Date to which Antedate is requested (1144): Select the appropriate date.

- To advise the client that the indefinite disqualification cannot be rescinded:

- Disqualifications - Definite / Indefinite - Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542) .

- Select Disqualification message (2543).

- Select the appropriate options.

- To advise the client of the D15:

- Disentitlements (2976): Select D48 and D15 — Moved — Address unknown and claim procedure (3006) .

- D15 - Claim procedure (3009) .

- D15 - Text: Insert appropriate reason for D15: Select the following:

- We / In addition, we (2687) .

- Indefinite / Definite / Multiple Disentitlement dates (2485) .

- Text - Insert appropriate reason(s) (1618): Type the appropriate option:

- “You have not returned our calls following the messages left on [insert dates].”

- “You have not contacted us following the letter sent to you on [insert date].”

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of Earnings - Only from ROE #1 - Monies allocated beyond BPC (2523): Select the appropriate option.

- Allocation of Earnings - Monies allocated beyond BPC are from both ROE #1 + ROE #2 (2517): Select the appropriate option.

- Pension Allocation (2525) (if the client is receiving a pension): Select the appropriate option.

- Weekly Indemnity Allocation (2529) (if the client is receiving an indemnity payment): Select the appropriate option.

- Waiting period message (2444 ) (if the client has not served the WP)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In ACS, determine if there is a saved N-02-00-00 letter:

- If yes, go to step 5.

- If no, go to step 6.

- Determine if all decisions which must be communicated to the client are included in the D-01-00-00 letter:

- If yes, delete the N-02-00-00 letter. Go to step 6.

- If no, send the N-00-00-00 letter with only the decisions that are left to be communicated. Go to step 6.

- Determine if Level 2 adjudication is required:

- If yes, in NWS, create a client Note and type “Send the D-01-00-00 letter.” Go to step 7.

- If no, send the saved D-01-00-00 letter and go to step 8.

- In NWS, reassign any CR WIs for the contentious issue to Level 2 as follows:

- Destination — SCC: Select the SCC as shown in FTS.

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Not within Level 1 authority.”

- Go to step 8.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- In NWS, complete the Conversion WI. 

#### Conversion on a renewal claim — No outstanding adjudication

Source topic: `en_EN/task/conv_matreg/conversion_on_a_renewal_claim__no_outst_8874a6e6_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if applicable).

- Claim type: Select 2 - Regular .

- If a D15 must be imposed, complete the following fields:

- Action: Select Add .

- Disentitlement: Select 15 - Claim procedure .

- Start date: Enter the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select the appropriate option:

- If the conversion did not require Level 2 adjudication, select 1 - No .

- If the conversion required Level 2 adjudication, select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Determine if there is an allocation that must be communicated to the client:

- If yes, go to step 3.

- If no, go to step 7.

- Determine if any of the following situations apply:

- There is a denied antedate.

- There is an MA02 on file.

- A disentitlement or definite disqualification is being imposed manually.

- If none of the situations apply, go to step 4.

- If any of the situations apply, go to step 6.

- In NWS, move the CA Renewal WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting confirmation that automated R-01-00-00 letter was sent.”

- Bring forward date: Enter today’s date + 1 day.

- When the WI moves to the current workload, determine if the automated R-01-00-00 letter was sent:

- If no, go to step 6.

- If yes, go to step 9.

- In FTS, select the File Control Data (M101) transaction as follows:

- Select Claim Action .

- Select Automated Letter Bypass .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- To advise the client of the renewal/revival week:

- Renewal week - Sunday’s date (1246).

- To advise the client that the antedate has been denied:

- Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Select Antedate Denied (2483) .

- Select Antedate denied - Renewal/continuing claims (2484) .

- Select Renewal application not filed on time and no good cause for delay .

- Date to which Antedate is requested (1144): Select the appropriate date.

- To advise the client that the indefinite disqualification cannot be rescinded:

- Disqualifications - Definite / Indefinite - Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542) .

- Select Disqualification message (2543) .

- Select the appropriate options.

- To advise the client of the D15:

- Disentitlements (2976): Select D48 and D15 — Moved — Address unknown and claim procedure (3006) .

- D15 - Claim procedure (3009) .

- D15 - Text: Insert appropriate reason for D15: Select the following:

- We / In addition, we (2687) .

- Indefinite / Definite / Multiple Disentitlement dates (2485) .

- Text - Insert appropriate reason(s) (1618): Type the appropriate option:

- “You have not returned our calls following the messages left on [insert dates].”

- “You have not contacted us following the letter sent to you on [insert date].”

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of Earnings - Only from ROE #1 - Monies allocated beyond BPC (2523): Select the appropriate option.

- Allocation of Earnings - Monies allocated beyond BPC are from both ROE #1 + ROE #2 (2517): Select the appropriate option.

- Pension Allocation (2525) (if the client is receiving a pension): Select the appropriate option.

- Weekly Indemnity Allocation (2529) (if the client is receiving an indemnity payment): Select the appropriate option.

- Waiting period message (2444 ) (if the client has not served the WP).

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In ACS, determine if there is a saved N-02-00-00 or D-20-16-03 letter:

- If yes, go to step 9.

- If no, go to step 10.

- Determine if all decisions which must be communicated to the client are included in the D-01-00-00 letter:

- If yes, delete the letter.

- If no, send the letter with only the decisions that are left to be communicated.

- In NWS, determine if the conversion application was submitted using AW:

- If no go to step 11.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_matreg#subsequent_claims)

- Complete the WI. 

#### Conversion on a renewal claim — Outstanding adjudication

Source topic: `en_EN/task/conv_matreg/conversion_on_a_renewal_claim__outstand_c972fb4d_level_1.dita`

- In FTS, select the Renewal/Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if applicable).

- If a D15 must be imposed, complete the following fields:

- Action: Select Add .

- Disentitlement: Select 15 - Claim procedure .

- Start date: Enter the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Claim type: Select 2 - Regular .

- Contentious: Select the appropriate option:

- If the conversion did not require Level 2 adjudication, select 1 - No .

- If the conversion required Level 2 adjudication, select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- There is an indefinite disqualification on file.

- A disentitlement or definite disqualification is being imposed manually.

- If there are decisions that must be communicated to the client, go to step 3.

- If there are no decisions that must be communicated to the client, go to step 5.

- In ACS, create and save the D-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- To advise the client of the renewal week:

- Renewal week - Sunday’s date (1246).

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of Earnings - Only from ROE #1 - Monies allocated beyond BPC (2523): Select the appropriate option.

- Allocation of Earnings - Monies allocated beyond BPC are from both ROE #1 + ROE #2 (2517): Select the appropriate option.

- Pension Allocation (2525) (if the client is receiving a pension): Select the appropriate option.

- Weekly Indemnity Allocation (2529) (if the client is receiving an indemnity payment): Select the appropriate option.

- To advise the client that the indefinite disqualification cannot be rescinded:

- Disqualifications - Definite / Indefinite - Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542) .

- Select Disqualification message (2543) .

- Select the appropriate options.

- To advise the client of the D15:

- Disentitlements (2976): Select D48 and D15 — Moved — Address unknown and claim procedure (3006) .

- D15 - Claim procedure (3009).

- D15 - Text: Insert appropriate reason for D15: Complete the following:

- We / In addition, we (2687) .

- Indefinite / Definite / Multiple Disentitlement dates (2485) .

- Text - Insert appropriate reason(s) (1618): Type the appropriate option:

- “You have not returned our calls following the messages left on [insert dates].”

- “You have not contacted us following the letter sent to you on [insert date].”

- Waiting period message (2444 ) (If the client has not served the WP).

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note and type “Send the D-01-00-00 letter.”

- Determine if the conversion application was submitted using AW:

- If no go to step 6.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_matreg#subsequent_claims)

- Complete the WI. 

#### Subsequent claims

Source topic: `en_EN/task/conv_matreg/subsequent_claims_level_1.dita`

- Determine if there are 4 weeks or fewer of benefits payable remaining in the BP:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the renewal was finalized 28 calendar days after the renewal application was submitted (i.e. application date + 27 days) or if the Status field on the Summary tab in FTS is 8 - Converted to Manual Pay:

- If yes, go to step 3.

- If no, go to step 4.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Subsequent claim not automated.”

- Due date: Select the [LRW + 3 weeks].

- Language: Select the appropriate option.

- Details: Type “Subsequent claim to be established.”

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Next available user .

- Complete the CA WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2729.dita`

- The client was laid off due to a work shortage before or during the maternity period or was receiving regular benefits before the maternity period.

- The client’s maternity leave at her place of employment was not scheduled for the period for which she is requesting regular benefits.

- The client is capable of and available for work and places no restrictions on the acceptance of employment. She answers as follows in the appropriate checklist:

- “Yes” to questions 5, 6 and 6b of the Maternity to Regular Benefits - Employed checklist.

- “Yes” to questions 2, 3 and 4 of the Maternity to Regular Benefits - Not Employed checklist. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2730.dita`

- The client is not entitled to maternity benefits.

- The client was laid off due to a work shortage of or was receiving regular benefits before the confinement date.

- The client’s maternity leave at her place of employment was not scheduled for the period for which she is requesting regular benefits.

- The client is capable of and available for work and places no restrictions on the acceptance of employment. She answers as follows in the appropriate checklist:

- “Yes” to questions 5, 6 and 6b of the Maternity to Regular Benefits - Employed checklist.

- “Yes” to questions 2, 3 and 4 of the Maternity to Regular Benefits - Not Employed checklist. 

#### Note

Source topic: `en_EN/common_notes/note_c_2731.dita`

Note:

When finalizing the conversion, an indefinite D15 must be imposed and a D-01-00-00 letter must be created and sent to advise the client that she is not entitled to regular benefits. 

#### Note

Source topic: `en_EN/common_notes/note_c_2732.dita`

Note:

When converting a claim to regular or sickness benefits, always determine if the client is available or otherwise available. 

#### Note

Source topic: `en_EN/common_notes/note_c_2721.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose an MA1 to stop payment. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2733.dita`

“We cannot reactivate your claim for Employment Insurance benefits starting [Renewal week - Sunday’s date] as you have received the maximum number of benefit weeks payable to you during this benefit period. The maximum number of benefit weeks paid on this claim cannot exceed a total of [maximum number of regular and special benefit weeks that can be paid] weeks.

To receive benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you will have to apply for a new claim.” 

#### Callout

Source topic: `en_EN/common_notes/note_c_2734.dita`

“We cannot reactivate your claim for Employment Insurance benefits starting [Renewal week - Sunday’s date] as no regular benefits are payable to you on this claim. You have received all of the regular benefits to which you were entitled.

To receive regular benefits, you must work the required minimum number of insurable employment hours. If you want to receive regular benefits in the future, you will have to apply for a new claim.” 

#### Callout

Source topic: `en_EN/common_notes/note_c_2735.dita`

“We cannot reactivate your claim for Employment Insurance benefits starting (Renewal week - Sunday’s date) . Please note that we are required to advise you of all decisions made on your claim.

No regular benefits are payable to you on this claim because the last renewal week has been reached on this BP.

To receive regular benefits, you must work the required minimum number of insurable employment hours. If you want to receive regular benefits in the future, you must apply for a new claim.” 

#### Callout

Source topic: `en_EN/common_notes/note_c_2736.dita`

“We have reactivated your claim for Employment Insurance benefits starting (renewal week - Sunday’s date) . Please note that we are required to advise you of all decisions made on your claim.

As previously mentioned in a letter sent to you on (insert date), no regular benefits are payable to you on this claim because you accumulated (number of insurable employment hours accumulated) of insurable employment between (start date of regular qualifying period - Sunday's date) and (end date of regular qualifying period - Saturday's date) , but according to the unemployment rate in your region when you filed your claim, you needed (number of insurable employment hours required) of insurable employment to qualify for regular benefits.

To receive regular benefits, you must work the required minimum number of insurable employment hours. If you want to receive regular benefits in the future, you must apply for a new claim.” 

## Policy reference

Source topic: `en_EN/task/conv_matreg/policy_reference.dita`

- EIA 12(6)
         [EIA 12(6)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
