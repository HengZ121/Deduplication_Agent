# Actioning a request to obtain a missing ROE when the client is not requesting benefits

Source map: `en_EN/task/actioning_request_missing_roe/actioning_request_missing_roe.ditamap`

## Summary

Source topic: `en_EN/task/actioning_request_missing_roe/summary.dita`

Summary: When a client asks for help obtaining an ROE, the agent reviews the information and helps the client obtain the ROE. 

## What you need to know

Source topic: `en_EN/task/actioning_request_missing_roe/what_you_need_to_know.dita`

### Receiving a request for help obtaining an ROE

Source topic: `en_EN/task/actioning_request_missing_roe/receiving_a_request_for_help_obtaining_an_roe.dita`

A client can request help obtaining an ROE even when the client does not apply for EI benefits. Every employer must issue an ROE for any employee in insurable employment who experiences an interruption of earnings (I of E).

The client can request help obtaining the ROE by telephone, mail, or with a ROE: INS3166 Request for missing ROE — Form .
       [ROE: INS3166 Request for missing ROE — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS3166.pdf)

When fact-finding, the agent validates the client’s identity using the information on the INS3166 form if the client’s information is not available in NWS or FTS.

If the client does not receive the ROE within 10 business days of the date on which the employer agrees to issue it, the client can contact Service Canada for help a second time.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1559.dita) 

**Electronic ROEs**

Employers who complete electronic ROEs do not have to send a paper copy to the employee. They submit the information to Service Canada electronically. Electronic ROEs completed within the last 7 years can be viewed and printed from MSCA.

**Paper ROEs**

The serial number of a paper ROE starts with the letter A , E , K or Z .

A paper ROE has 3 parts:

- Part 1 (employee copy): The original Part 1 is given to the employee and is proof of insurable employment. The client submits this copy to a Service Canada Centre (SCC) when applying for benefits.

- Part 2: The employer sends this copy to the ROE Service Centre in Bathurst, New Brunswick. Service Canada keeps copies of paper ROEs for 11 years.

- Part 3: The employer must keep this copy on file for 6 years.

**Fact-finding with the employer**

If the employer states that the ROE has been issued, the agent contacts and advises the client that the ROE should be received in 10 business days.

If the employer refuses to issue an ROE, the agent refers the file to Integrity for employer non-compliance.

If the employer questions the insurability of the ROE, the agent refers to Responding to an insurability enquiry .
       [Responding to an insurability enquiry](/en/procedure/task/responding_insurability_enquiry.shtml)

**Searching RMDS**

When an ROE is not in the client’s file but the employer states that one has been issued, the agent obtains the serial number and searches the Incomplete workload in RMDS to determine if the ROE is waiting to be input. The agent can print a copy of the PDF version from the Incomplete workload and send it to the client. The agent searches for the ROE from the Scanned ROE menu in RMDS.

If the ROE is not in the Incomplete workload, the agent searches for the ROE from the ROE menu in RMDS to determine if it has been input.

**ROE issued under the wrong SIN**

If the ROE was issued under the wrong SIN, the agent refers to Actioning an ROE issued with the wrong SIN .
       [Actioning an ROE issued with the wrong SIN](/en/procedure/task/actioning_roe_wrong_sin.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1559.dita`

Note:

If the client is applying for benefits and informs Service Canada that the employer refuses to issue an ROE, the agent goes to Determining if an interim ROE is required (Task) .
       [Determining if an interim ROE is required (Task)](/en/procedure/task/determining_interim_roe.shtml)

If the client is not applying for benefits, the agent does not create an interim ROE.

The agent must not provide personal or protected information, including the client’s address, to the employer or third parties without the client’s written authorization.

     [Determining if an interim ROE is required (Task)](/en/procedure/task/determining_interim_roe.shtml) 

## Regional considerations

Source topic: `en_EN/task/actioning_request_missing_roe/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actioning_request_missing_roe/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/actioning_request_missing_roe/in_nws.dita`

- Is there an SROC or Action Item (AI) WI with employment information?

- Is there an SROC with fact-finding for the missing ROE from the client’s previous attempt to obtain the ROE? 

### In Imaging:

Source topic: `en_EN/task/actioning_request_missing_roe/in_imaging.dita`

- Is there a letter or an INS3166 form with the employment information? 

### In RMDS:

Source topic: `en_EN/task/actioning_request_missing_roe/in_rmds.dita`

- Is the ROE in question on file?

- Is the ROE in the Incomplete workload? 

## Step by step

Source topic: `en_EN/task/actioning_request_missing_roe/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/actioning_request_missing_roe/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_request_missing_roe/reviewing_the_file_level_1.dita`

- In RMDS, determine if the ROE is on file:

- If no, go to step 2.

- If yes, go to step 10.

- Determine if actions were taken previously to obtain the ROE by reviewing external SROCs in NWS:

- If no, go to step 3.

- If yes, go to Client’s second attempt to obtain the ROE
               [Client’s second attempt to obtain the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_request_missing_roe#CSOROE)

- Fact-find with the employer to determine if the ROE has been issued. If the employer is reached, consider the following questions:

- If an ROE has been issued for the period of employment:

- ROE Web or ROE SAT:

- What is the serial number?

- In RMDS, if the ROE cannot be found by serial number, advise the employer that the ROE is not showing in the system and either the employer or the payroll service provider must upload it.

- If an electronic ROE was issued under the wrong SIN, advise the employer that a new ROE must be issued under the correct SIN.

- Paper ROE:

- If a paper ROE has been issued, advise the employer to provide the client with a photocopy of the ROE (signed and marked “true copy of the original”). Validate the client’s address. If the employer does not have the correct address, do not provide the address to the employer.

- If a paper ROE was issued under the wrong SIN, advise the employer that a new ROE must be issued under the correct SIN.

- If an ROE has not been issued

- Is the employer issuing a paper or electronic ROE?

- If a paper ROE was issued under the wrong SIN, advise the employer that a new ROE must be issued under the correct SIN.

- If the employer is not issuing an ROE, what are the reasons?
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1560.dita)

- In NWS, add details to the draft external SROC created during fact-finding or create a new external SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “Missing ROE from [employer name].”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Determine if the employer was reached during fact finding:

- If yes, go to step 6.

- If no, contact and advise the client that the file is being referred to Integrity. Refer to Creating or reassigning a WI — Integrity (Task) .
               [Creating or reassigning a WI — Integrity (Task)](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine if the employer issued the ROE under the wrong SIN:

- If yes, go to step 7.

- If no, go to step 8.

- Create a Reminder (REM) WI as follows:

- Reason: Select Missing ROE .

- Comments: Enter the employer’s name.

- Due Date: Enter today’s date + 10 business days.

- Details: Type “Follow up with the employer for a corrected ROE. No initial letter was sent. If the employer does not respond to requests or if the amended ROE is issued with a SIN other than the client’s, refer to Integrity.”

- End user: Select Myself .

- Go to step 8.

- Determine if the employer will issue the ROE:

- If yes, go to step 9.

- If no, contact and advise the client that the file is being referred to Integrity. Refer to Creating or reassigning a WI — Integrity (Task) .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1561.dita) 
               [Creating or reassigning a WI — Integrity (Task)](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Contact the client and explain that the employer will issue the ROE. Advise the client to check the mail if the employer is issuing a paper ROE, or MSCA if the employer is issuing an electronic ROE. If the client does not receive the ROE within 10 business days, advise the client to call back.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1562.dita)

- In NWS, complete the WI. 

#### ROE on file

Source topic: `en_EN/task/actioning_request_missing_roe/roe_on_file_level_1.dita`

- Determine if the employer issued a paper ROE or an electronic ROE:

- If the employer issued a paper ROE, go to step 2.

- If the employer issued an electronic ROE, go to step 3.

- Contact the client to explain that the ROE has been issued and mail the client a copy of the ROE. Go to step 4.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1562.dita)

- Contact the client to explain that the ROE has been issued and it can be viewed on MSCA.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1562.dita)

- In NWS, complete the WI. 

#### Client’s second attempt to obtain the ROE

Source topic: `en_EN/task/actioning_request_missing_roe/clients_second_attempt_to_obtain_the_roe_level_1.dita`

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Select the Request for ROE from Employer (Y-31-00-00) attachment.

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Employer or Third Party Address 2 (2440)

- Employer or Third Party Address 3 (2441)

- Opening Sentence to ER to Request or Clarify ROE/RFS (2794): Select Request ROE Opening Sentence - claimant .

- Request for a Record of Employment (2797):

- Select Initial Request for ROE .

- Select Start-end employment / End date of employment (2798) .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact finding employer .

- Comments: Type “Missing ROE, first letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- In NWS, create an external SROC as follows:

- Details: Type “Client’s second attempt to obtain missing ROE. First Z-02-00-00 letter sent. WI moved to Pending.”

- Click Draft .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1563.dita)

- When the WI moves to the current workload, determine if the employer has issued the ROE:

- If no, go to step 5.

- If yes, go to step 12.

- In ACS, send the Z-02-00-00 letter with the following attributes:

- Opening Sentence to ER re: Request to Clarify ROE/RFS (2794): Select Request ROE Opening Sentence - claimant .

- Request for Record of Employment (2797): Select Follow up request for ROE .

- Previously requested by mail (2799):

- Date ROE requested: Enter the date the original letter was sent.

- End date of period of employment: Enter the employment end date.

- Date of BF: Enter 10 business days from the date the letter is sent.

- Attachment List for Z-02-00-00 (3133): Select Attached: Copy of original letter .

- Indicate on letter how letter mailed (2804): Select Sent by registered mail .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1564.dita)

- In NWS, complete the initial WI.

- In NWS, select External and create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Missing ROE .

- Comments: Enter the employer’s name.

- Due Date: Enter today’s date + 10 business days.

- Language: Select the appropriate language.

- Details: Type “Follow up with the employer for the missing ROE request. If employer does not respond to second letter, refer to Integrity.”

- Destination: Enter the SCC as shown in FTS.

- End user: Select Myself and complete the following fields:

- Send to my pending workload: Check the box.

- Pending reason: Select Fact-finding employer .

- Comments: Type “Missing ROE, second letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- Click Save .

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “The employer did not respond to the first letter. A second letter was sent. REM WI created for follow-up.”

- Click Draft .

- When the WI moves to the current workload, determine if the employer has issued the ROE:

- If no, go to step 10.

- If yes, go to step 12.

- Contact and advise the client that the file is being referred to Integrity. Refer to Creating or reassigning a WI — Integrity .

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “The employer did not respond to the first or second letter — referred to Integrity for employer non-compliance.”

- Click Save .

- Go to step 15.

- Determine if the employer issued a paper ROE or an electronic ROE:

- If the employer issued a paper ROE, go to step 13.

- If the employer issued an electronic ROE, go to step 14.

- Contact the client to explain that the ROE has been issued and mail the client a copy of the ROE. Go to step 15.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1562.dita)

- Contact the client to explain that the ROE has been issued and can be viewed in MSCA.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1562.dita)

- In NWS, complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1560.dita`

Note:

If the employer states that the ROE has been issued and provides a serial number, verify if the ROE is displayed in RMDS in order to avoid additional fact-finding in case the ROE has been issued under an incorrect SIN or has been amended. 

#### Note

Source topic: `en_EN/common_notes/note_c_1561.dita`

Note:

If there is a question of insurability, refer to Responding to an insurability enquiry .
       [Responding to an insurability enquiry](/en/procedure/task/responding_insurability_enquiry.shtml)

     [Responding to an insurability enquiry](/en/procedure/task/responding_insurability_enquiry.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_1562.dita`

Note:

Refer to Fact-finding when contacting the client. If the client’s information is not available in NWS or FTS, validate the client’s identity using information from the INS3166 form.
       [Fact-finding](/en/procedure/task/fact_find.shtml)

     [Fact-finding](/en/procedure/task/fact_find.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_1563.dita`

Note:

If the client is not requesting benefits, do not create an interim ROE. 

#### Note

Source topic: `en_EN/common_notes/note_c_1564.dita`

Note:

When sending a copy of an original letter, print the letter locally. For instructions on printing locally while teleworking, refer to Telework: Printing documents locally — Instructions .
       [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml)

     [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml) 

## Policy reference

Source topic: `en_EN/task/actioning_request_missing_roe/policy_reference.dita`

 
