# Determining if an interim ROE is required

Source map: `en_EN/task/determining_interim_roe/determining_interim_roe.ditamap`

## Summary

Source topic: `en_EN/task/determining_interim_roe/summary.dita`

Summary: An application with a missing ROE must be reviewed to determine if an interim ROE is required. 

## What you need to know

Source topic: `en_EN/task/determining_interim_roe/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/determining_interim_roe/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Situations that require an interim ROE

Source topic: `en_EN/task/determining_interim_roe/situations_that_require_an_interim_roe.dita`

An interim ROE may be required in the following situations:

- The client uses the renewal application with 4 or fewer weeks of benefits remaining to establish a subsequent claim after a renewal, and the client has declared earnings between the renewal date and the BPC of the new claim. If the officer has not received the ROE for this employment by the time the subsequent claim is being calculated, the officer creates an interim ROE with information from the client.

- An ROE is required for an insurability ruling and the client cannot obtain an ROE from the employer.

- The Canada Revenue Agency (CRA) has ruled that the employment is insurable but the employer refuses to issue the ROE. (The employer may be appealing the CRA ruling.)

- The client tries unsuccessfully to get a copy of a previously issued paper ROE from an employer.

- The client tries unsuccessfully to have the employer issue an ROE.

- There are compelling personal issues or conflicts that make it impossible for the client to contact the employer (e.g. alleged harassment of the client).

- The client applied for a fishing claim with a BPC from September 27, 2020 (w/c 2258) to September 19, 2021 (w/c 2309) and the calculation result is BPNE.

Except for the first situation listed above, when the client requests help in obtaining the ROE and the ROE is not on file, the officer must try to communicate with the employer.

When determining if an interim ROE is required, the officer reviews the file and determines if the ROE can be obtained from the client first. If the client indicates difficulties obtaining the ROE from the employer, the officer contacts the employer to attempt to get the ROE. The ROE may be in the Incomplete workload in RMDS waiting to be input, or on the Uploaded Documents tab in NWS. If so, the officer inputs the ROE by following Entering data from a paper ROE — Regular ROE or Entering data from a paper ROE — Fishing .
       [Entering data from a paper ROE — Regular ROE](/en/procedure/task/paperroe_regular.shtml) 
       [Entering data from a paper ROE — Fishing](/en/procedure/task/paperroe_fisher.shtml)

If the ROE is not in the Incomplete workload in RMDS or on the Uploaded Documents tab in NWS but is in Easy Access and the details appear to be accurate, the officer uses that information and the other information on file to create an interim ROE. The officer does not request a copy of the ROE from Easy Access.

An interim ROE is required when an ROE in either paper or electronic format was issued with a temporary 900-series SIN and the client has since become a permanent resident and has a new SIN. In this case, the officer refers to SIN Change .
       [SIN Change](/en/procedure/activity/change_sin.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3161.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3162.dita) 

### Fact-finding with the client

Source topic: `en_EN/task/determining_interim_roe/fact-finding_with_the_client.dita`

Clients can request help in obtaining a missing ROE using various methods (e.g. telephone, mail, in person or by uploaded documents). While the ROE: INS3166 Request for missing ROE — Form is available to the client for such a request, the form may not have been used or may be incomplete. In these cases, the officer conducts fact-finding with the client to complete the INS3166 form. The completed INS3166 form must include Part C - Statement of employment . This attestation is required to allow an interim ROE.
       [ROE: INS3166 Request for missing ROE — Form](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/ROE-INS3166_Request_for_missing_ROE_transcript-Form.doc)

When clients state they do not want the employer to know that they are applying for benefits, they are advised that benefits cannot be paid without all the required ROEs.

When fact-finding with the client, the officer must obtain as much accurate information as possible so if the employer cannot be contacted, or is unwilling or unable to provide the ROE or employment details, the officer can create an interim ROE.

When clients offer to fax a copy of the ROE, the officer advises them that fax lines are not secure and that they can submit a copy of the ROE using the document upload feature in their MSCA. The officer must not request that the client fax a copy, as the ROE is considered to be Protected B. If the client still wishes to fax the ROE, the faxed copy is accepted. If the client states that the ROE is being faxed, the officer waits for up to 2 business days to receive the ROE. 

### Fact-finding with the employer

Source topic: `en_EN/task/determining_interim_roe/fact-finding_with_the_employer.dita`

When conducting fact-finding with the employer to obtain the ROE, the officer confirms the CRA Business Number (BN), the legal name of the company and the company’s operating name. The officer uses that information when verifying the legitimacy of the employment.
       [fact-finding](/en/procedure/task/fact_find.shtml)

An employer may sometimes refuse the client’s request to issue an ROE if the client is currently working. This often happens when the client has an interruption of earnings (I of E) from one employer but is still working for a second employer. The employer must be advised that the ROE is required.

If the employer offers to fax a copy of the ROE, the employer is advised that fax lines are not secure. The officer must not request that the employer fax a copy, as the ROE is considered to be Protected B. If the employer still wishes to fax the ROE, the faxed copy is accepted. If the employer states that the ROE is being faxed, the officer waits for up to 2 business days to receive the ROE.

If the employer states that the ROE is being issued in a timely manner, the officer waits for a period of up to 5 business days to receive the ROE. 

### ROE appears in RMDS but not RCM

Source topic: `en_EN/task/determining_interim_roe/roe_appears_in_rmds_but_not_rcm.dita`

When an ROE is not in the client’s file but a serial number has been obtained, the officer searches for the ROE from the ROE menu in RMDS to determine if it has been entered. If the ROE is already entered in RMDS but not in RCM, one of the following may have occurred:

- The ROE has been issued under a different SIN and may not be for this client.

- The ROE has been amended with a subsequent ROE. This may be an error (e.g. the employer has incorrectly completed block 2 - Serial no. of ROE amended or replaced when issuing a subsequent ROE which replaces the original ROE in RCM).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3163.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_3161.dita`

Note:

When a client wants an ROE but is not applying for benefits, the officer does not create an interim ROE. The officer refers to Actioning a request to obtain a missing ROE when the client is not requesting benefits .
       [Actioning a request to obtain a missing ROE when the client is not requesting benefits](/en/procedure/task/actioning_request_missing_roe.shtml)

     [Actioning a request to obtain a missing ROE when the client is not requesting benefits](/en/procedure/task/actioning_request_missing_roe.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3162.dita`

Note:

The officer does not create an interim ROE for vacation days listed on an ROE that are after the last day paid (LDP). The Unemployment Insurance Calculation (UIC) is programmed to take into account the vacation days that are after the LDP for a permanent or temporary separation from employment based on block 14 - Expected date of recall and block 16 - Reason for issuing this ROE . 

### Note

Source topic: `en_EN/common_notes/note_c_3163.dita`

Note:

If a paper ROE was scanned and uploaded for data entry in RMDS, it may be in the Incomplete workload waiting to be input. The officer searches for the ROE from the Scanned ROE menu in RMDS. If the ROE is in the Incomplete workload, the officer refers to the appropriate Data entry — Paper document procedure to input the ROE.
       [Data entry — Paper document](/en/procedure/activity/depd.shtml)

     [Data entry — Paper document](/en/procedure/activity/depd.shtml) 

## Regional considerations

Source topic: `en_EN/task/determining_interim_roe/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/determining_interim_roe/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/determining_interim_roe/in_nws.dita`

- Is there an uploaded document, SROC or Action Item (AI) WI containing employment information (letter or INS3166 form) or a request for help from the client to obtain a missing ROE?
         [INS3166](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/ROE-INS3166_Request_for_missing_ROE_transcript-Form.doc)

- Is this a renewal application with 4 or less weeks of benefits remaining being used to establish a subsequent claim following a renewal?

- Is the ROE missing for earnings from the renewal date to the new BPC?

- What type of WI do you have?

- Is a CRA insurability ruling required? 

### In RMDS:

Source topic: `en_EN/task/determining_interim_roe/in_rmds.dita`

- Is the ROE in the Incomplete workload? 

### In Imaging:

Source topic: `en_EN/task/determining_interim_roe/in_imaging.dita`

- Is there a document (letter or INS3166 form) containing the employment information?
         [INS3166](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/ROE-INS3166_Request_for_missing_ROE_transcript-Form.doc)

- Is there a CRA ruling indicating the employment is insurable? 

### In Easy Access:

Source topic: `en_EN/task/determining_interim_roe/in_easy_access.dita`

- Is there an ROE from this employer for the period of employment? 

## Step by step

Source topic: `en_EN/task/determining_interim_roe/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/determining_interim_roe/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/determining_interim_roe/reviewing_the_file_level_1.dita`

- Determine the reason an interim ROE may be required:

- If the client wants an ROE but is not applying for benefits, do not create an interim ROE. Refer to Actioning a request to obtain a missing ROE when the client is not requesting benefits .
               [Actioning a request to obtain a missing ROE when the client is not requesting benefits](/en/procedure/task/actioning_request_missing_roe.shtml)

- If the client had a 900-series SIN and has obtained a new SIN, go to SIN change .
               [SIN change](/en/procedure/activity/change_sin.shtml)

- If it is an application for renewal with 4 weeks or less of benefits payable that is used to establish a subsequent claim following a renewal and there is no ROE for earnings in the period between the renewal date and the subsequent BPC, go to Determining if an Interim is required .
               [Determining if an Interim is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#level1_item_4)

- If the ROE is required for any other reason, go to step 2.

- Determine if the ROE has been uploaded in NWS or is in the Incomplete workload in RMDS:

- If yes, go to Entering data from a paper ROE — Regular ROE or Entering data from a paper ROE — Fishing to input the ROE.
               [Entering data from a paper ROE — Regular ROE](/en/procedure/task/paperroe_regular.shtml) 
               [Entering data from a paper ROE — Fishing](/en/procedure/task/paperroe_fisher.shtml)

- If no, but an ROE from this employer covering the same period of employment is in Easy Access and the details of the ROE appear to be accurate, go to Estimating interim ROE information .
               [Estimating interim ROE information](/en/procedure/task/estimating_interim_roe.shtml)

- If neither of the above applies, go to step 3.

- Determine if the client has requested help to obtain a missing ROE:

- If there is information on file indicating the client requested help (documentation on file, uploaded documents, etc.), go to Fact-finding with the client .
               [Fact-finding with the client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#level1_item_2)

- If there is an incomplete INS3166 form on file, go to Fact-finding with the client .
               [INS3166](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/ROE-INS3166_Request_for_missing_ROE_transcript-Form.doc) 
               [Fact-finding with the client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#level1_item_2)

- If there is a completed INS3166 form on file that provides the information required to estimate an interim ROE, go to step 8.
               [INS3166](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/ROE-INS3166_Request_for_missing_ROE_transcript-Form.doc)

- If the client has not requested help, go to Interim ROE not required .
               [Interim ROE not required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#interim_roe_not_required) 

#### Fact-finding with the client

Source topic: `en_EN/task/determining_interim_roe/fact-finding_with_the_client_level_1.dita`

- Fact-find with the client.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3164.dita)

- Determine if the client was reached:

- If the client was reached, go to step 6.

- If the client was not reached, return to the previous task.

- In NWS, create an SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “Interim ROE information.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client has received the paper ROE:

- If no, but the client requests help in obtaining the ROE or the client filled out the INS3166 form , go to step 8.
               [INS3166 form](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/ROE-INS3166_Request_for_missing_ROE_transcript-Form.doc)

- If yes, go to Interim ROE not required .
               [Interim ROE not required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#interim_roe_not_required)

- Determine if the client has requested the ROE from the employer or if the client indicated a circumstance preventing the employer from being contacted to issue the ROE:

- If yes, go to step 9.

- If no, contact the client to advise that the client is responsible for requesting the ROE from the employer and if the ROE cannot be obtained, the client can contact the call centre at 1-800-206-7218. Go to Interim ROE not required .
               [Interim ROE not required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#interim_roe_not_required) 

#### Fact-finding with the employer

Source topic: `en_EN/task/determining_interim_roe/fact-finding_with_the_employer_level_1.dita`

- Fact-find with the employer to determine if an ROE has been issued.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3165.dita)

- Determine if the employer was reached:

- If the employer was reached, go to step 11.

- If the employer was not reached, go to step 12.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “Missing ROE from [employer name].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if an interim ROE is required

Source topic: `en_EN/task/determining_interim_roe/determining_if_an_interim_roe_is_required_level_1.dita`

- Determine if the client or employer stated that an ROE is not being issued:

- If yes, go to step 13.

- If no, go to step 14.

- Determine if the employer is disputing the insurability of the employment:

- If no, go to Missing ROE .
               [Missing ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#missing_ROE)

- If yes, go to Interim ROE not required .
               [Interim ROE not required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#interim_roe_not_required)

- Determine if information on file indicates a serial number for the ROE:

- If yes, go to step 15.

- If no, go to step 16.

- In RMDS, determine if the ROE is found by serial number:

- If no, go to step 16.

- If yes, go to step 21.

- Determine if the employer states the ROE will be provided:

- If yes and the employer is faxing the ROE to Service Canada, go to step 17.

- If yes and the employer will issue the electronic ROE in a timely manner, go to step 17.

- If yes and the employer will provide the client with a paper ROE or true copy of the original paper ROE, go to Missing ROE .
               [Missing ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#missing_ROE)

- If no, go to step 22.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select ROE .

- Comments: Type “ROE request.”

- Bring forward date: Do one of the following:

- If the employer is faxing the ROE, enter today’s date + 2 business days.

- If the employer indicated that the paper or electronic ROE will be issued in a timely manner, enter today’s date + 5 business days.

- When the WI moves to the current workload, determine if the ROE is displayed in RMDS or RCM:

- If the ROE is not displayed in RMDS or RCM, go to step 19.

- If the ROE is displayed in RMDS or RCM, go to step 21.

- Determine if an uploaded or faxed copy of the ROE has been received:

- If the ROE was not received and the bring-forward date is not reached, return to step 17.

- If an uploaded or faxed copy of a paper ROE was received, go to step 20.

- If a faxed copy of an electronic ROE was received, go to step 21.

- If a copy of the ROE has not been received and the bring-forward date is reached go to step 22.

- In RCM, enter the ROE by referring to Data entry — Paper document and go to ROE obtained . If the ROE that was entered has validation errors, correct the errors by referring to Correct an ROE and go to ROE obtained .

- Determine if the ROE is displayed in RCM:

- If the ROE is not displayed in RCM, go to ROE appears in RMDS but not RCM .
               [ROE appears in RMDS but not RCM](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#roe_in_rmds_not_rcm)

- If the ROE is displayed in RCM, go to ROE obtained .
               [ROE obtained](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#roe_obtained)

- Determine if the client has requested help obtaining the ROE:

- If yes, go to Missing ROE .
               [Missing ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_interim_roe#missing_ROE)

- If no, return to the previous task. 

#### Missing ROE

Source topic: `en_EN/task/determining_interim_roe/missing_roe_level_1.dita`

- Determine if a Z-02-00-00 letter and a REM WI were created during fact-finding:

- If no, go to step 2.

- If yes, go to Estimating interim ROE information .
               [Estimating interim ROE information](/en/procedure/task/estimating_interim_roe.shtml)

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334).

- Employer or Third Party Address 1 (1336).

- Employer or Third Party Address 2 (2440).

- Employer or Third Party Address 3 (2441).

- Opening Sentence to ER to Request or Clarify ROE/RFS (2794).

- Select Request ROE Opening Sentence - claimant .

- Request for a Record of Employment (2797).

- Select Initial Request for ROE .

- Select Start-end employment / End date of employment (2798) .

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Missing ROE .

- Comments: Enter the employer’s name.

- Due Date: Enter today’s date + 10 business days.

- Language: Select the appropriate option.

- Details: Select the appropriate option:

- If the employer has not provided the electronic or faxed ROE, type “Follow-up with the employer is required about request for missing ROE. If the employer does not respond to request, send a second Z-02-00-00 letter and create a follow-up REM WI.”

- If the employer is issuing a paper ROE to the client, type “Follow-up with the client is required to determine if the paper ROE or true copy was received. If the client received it and did not submit it, a 15 - Claim procedure disentitlement (D15) may be necessary. If the paper ROE or true copy has not been received, send a second Z-02-00-00 letter to the employer.”

- Destination — SCC: Select the Service Canada Centre (SCC) as shown in FTS.

- End user: Select Myself and complete the following fields:

- Send to my pending workload: Check the box.

- Pending reason: Select the appropriate option.

- Comments: Type “Missing ROE — first letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- Select Save .

- In NWS, create a draft SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “Missing ROE from [employer name].”

- Details: Type the appropriate options:

- “Unsuccessful attempt to reach the employer by telephone to obtain the ROE. A Z-02-00-00 letter was sent. A Reminder work item was created for follow-up.”

- “Employer is issuing a paper ROE or a true copy to the client. A Reminder work item was created for follow-up.”

- Select Draft .

- Go to Estimating interim ROE information .
               [Estimating interim ROE information](/en/procedure/task/estimating_interim_roe.shtml) 

#### ROE obtained

Source topic: `en_EN/task/determining_interim_roe/roe_obtained_level_1.dita`

- Determine if the WI is an AI WI:

- If it is an AI WI, complete the WI.

- If it is a Claim Assessment (CA) WI, Specialized Application (SA) WI or Claim Review (CR) Recalculation WI, return to Reviewing information for a missing ROE .
               [Reviewing information for a missing ROE](/en/procedure/task/calc_determining/missing_roe.shtml)

- If it is any other WI, return to the previous task. 

#### Interim ROE not required

Source topic: `en_EN/task/determining_interim_roe/interim_roe_not_required_level_1.dita`

- Determine if the employer is disputing the insurability of employment:

- If yes, go to step 2.

- If no, go to step 3.

- In NWS, determine if there is an Assessment Issue (ASMT) Insurability WI:

- If yes, go to step 3.

- If no, create an ASMT Insurability WI as follows:

- Complexity: Select Level 1 .

- SCC: Type the SCC as shown in FTS.

- End User: Select the appropriate option as follows:

- If you have the training to complete an ASMT Insurability WI, select Myself .

- If you do not have the training to complete an ASMT Insurability WI, select Next available user .

- Issue(s): Select Insurability .

- Details: Type “Employer disputing insurability of employment.”

- In NWS, determine if the WI is an AI WI:

- If it is an AI WI, complete the WI.

- If it is a CA, SA or CR Recalculation WI, return to Reviewing information for a missing ROE .
               [Reviewing information for a missing ROE](/en/procedure/task/calc_determining/missing_roe.shtml)

- If it is any other WI, return to the previous task. 

#### ROE appears in RMDS but not in RCM

Source topic: `en_EN/task/determining_interim_roe/roe_appears_in_rmds_but_not_in_rcm_level_1.dita`

- Determine if the ROE is issued under the correct SIN:

- If the ROE is issued under the correct SIN but does not appear in RCM, go to step 6.

- If the ROE is not issued under the correct SIN, determine if the original ROE is issued under a previous 900-series SIN for a now permanent resident:

- If no, go to step 2.

- If yes, go to SIN change .
                   [SIN change](/en/procedure/activity/change_sin.shtml)

- Refer to Actioning an ROE issued with the wrong SIN before going to step 3.

- Determine if the ROE that was issued under the wrong client’s SIN is a paper ROE:

- If it is not a paper ROE, go to step 4.

- If it is a paper ROE, go to step 5.

- Use the information from the incorrect ROE (issued under the wrong SIN) to create an interim ROE. In the Additional Information field, type “Interim ROE was entered to replace ROE [serial number of the missing ROE] which was incorrectly issued with a SIN other than the client’s.” For more information, refer to Entering an interim ROE .

- Refer to Data entry — Paper document to enter the paper ROE using the correct SIN. In the Additional Information field , type “This ROE was originally issued under the wrong SIN.” If a validation error occurs when the ROE is entered, correct the error. For more information, refer to Correct an ROE . Go to step 15.

- Determine if there are other ROEs issued under the same SIN by the same employer after the missing ROE was issued:

- If there are no ROEs issued by the same employer after the missing ROE was issued, go to step 7.

- If there are other ROEs issued under the same SIN by the same employer after the missing ROE was issued, determine if one of those ROEs displays the serial number of the missing ROE in block 2 (amended ROE):

- If another ROE has the serial number of the missing ROE in block 2 , go to step 10.

- If no other ROE has the serial number of the missing ROE in block 2 , go to step 7.

- Send an enquiry to your business expertise advisor to determine why the missing ROE is not appearing in RCM.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “Missing ROE from [employer name].”

- Details: Document the fact-finding details not yet detailed and type “Referral sent to Business Expertise Advisor to determine why the missing ROE which has been received is not appearing in RCM. Follow-up required to determine if recalculation is required.”

- Select Save . (Do not leave it as a draft.)

- Use the details of the missing ROE in RMDS to create an interim ROE. In the Additional Information field, type “Interim ROE was created to replace ROE [serial number of the missing ROE] which has been received but is not appearing in RCM.” Go to Entering an interim ROE .

- Determine if the period covered by the subsequent ROE falls entirely after the period covered by the ROE missing in RCM:

- If no, go to step 11.

- If yes, go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3166.dita)

- Determine if the period covered by the subsequent ROE is the same as the period covered by the ROE missing in RCM:

- If yes, go to step 12.

- If no, go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3167.dita)

- Determine if the client is applying for benefits based on a previous I of E that occurred during the period covered by the subsequent ROE:

- If the client is applying for benefits based on a previous I of E, go to step 13.

- If the client is not applying for benefits based on a previous I of E, go to step 15.

- In RCM, update the subsequent ROE to only include the period of employment after the period covered by the original ROE (if necessary, refer to How to complete the Record of Employment ). If an error message is displayed, correct the error (refer to Correct an ROE , if required). Select Accept and go to step 14.

- Use the details of the missing ROE in RMDS to create an interim ROE. In the Additional Information field, enter “Interim ROE was entered to replace ROE [serial number of the missing ROE] which was incorrectly amended by [serial number of more recent ROE].” Go to Entering an interim ROE .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3168.dita)

- In NWS, determine if the WI is an AI WI:

- If it is an AI WI, complete the WI.

- If it is a CA, SA or CR recalculation WI, return to Reviewing information for a missing ROE .
               [Reviewing information for a missing ROE](/en/procedure/task/calc_determining/missing_roe.shtml)

- If it is any other WI, return to the previous task.

- If another ROE has the serial number of the missing ROE in block 2 , go to step 10.

- If no other ROE has the serial number of the missing ROE in block 2 , go to step 7. 

#### Note

Source topic: `en_EN/common_notes/note_c_3164.dita`

Note:

Consider the following questions and fill out the INS3166 form if necessary:
       [INS3166 form](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/ROE-INS3166_Request_for_missing_ROE_transcript-Form.doc)

- Does the client have the ROE?

- If yes, advise the client to submit the ROE. Ask the client to submit a copy using the document upload feature in MSCA. If the client cannot upload the document, request the serial number and ask the client to submit the ROE as soon as possible.

- If no, has the client attempted to contact the employer to obtain the ROE?

- If no, why? Is the client asking for help in obtaining the ROE?

- If yes:

- Did the employer provide the client any information about the ROE?

- Did the employer refuse to issue the ROE?

- Was the client advised that the employer is unable to issue the ROE in a timely manner?

- Has the employer told the client that an ROE will not be issued because the employer is disputing the insurability of the employment?

- Is the employer’s company currently operating?

- Does the client have additional contact information for the employer?

If the client has the ROE and provides a serial number, verify if the ROE is displayed in RMDS while talking with the client on the telephone.

     [INS3166 form](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/ROE-INS3166_Request_for_missing_ROE_transcript-Form.doc) 

#### Note

Source topic: `en_EN/common_notes/note_c_3165.dita`

Note:

Consider the following questions:

- If the employer confirms employment:

- What is the employer’s CRA BN, the legal name of the company and the company’s operating name?

- If an ROE has been issued for the period of employment:

- What is the serial number?

- If a Web or ROE SAT has been issued, advise the employer that the ROE is not showing in the system and must be uploaded by the employer or the payroll service provider.

- If a paper ROE has been issued, advise the employer to provide the client with a photocopy of the ROE (signed and marked “true copy of the original”).

- If the employer offers to fax a copy of a paper ROE, inform the employer that the fax is not secure (but a faxed copy can be accepted). If the employer wishes to fax the ROE, provide the fax number to the employer.

- If an electronic ROE is issued under the wrong SIN, advise the employer that a new ROE must be issued under the correct SIN.

- If a paper ROE is issued under the wrong SIN, can the employer confirm the correct SIN? If the employer can confirm the correct SIN, advise the employer that we can make the correction. If the employer cannot confirm the correct SIN, advise the employer that a new ROE must be issued under the correct SIN.

- If the ROE has been amended by a subsequent ROE, was this an error (i.e. the subsequent ROE does not cover the period of the original ROE)? If the original ROE was amended in error and the client is applying for benefits based on an I of E that occurred during the period covered by the subsequent ROE, request the details to correct the subsequent ROE.

- If an ROE has not been issued:

- Is the employer able to issue an ROE in a timely manner? If no, why?

- Is the employer issuing a paper or electronic ROE?

- Can the employer provide the information required to create an interim ROE?

- If the employer is not issuing an ROE, why not? Is the employer disputing the insurability of the employment?

If the employer states the ROE has been issued and provides a serial number, verify if the ROE is displayed in RMDS in order to avoid additional fact-finding if the ROE has been issued an incorrect SIN or been amended. 

#### Note

Source topic: `en_EN/common_notes/note_c_3166.dita`

Note:

If the period covered by the subsequent ROE falls after the period covered by the ROE missing in RCM, then both ROEs are valid and block 2 of the subsequent ROE should not have been completed. 

#### Note

Source topic: `en_EN/common_notes/note_c_3167.dita`

Note:

If the period covered by the subsequent ROE is the same as the period covered by the ROE missing in RCM, then the subsequent ROE should have been issued for the period after the period covered by the ROE missing in RCM. 

#### Note

Source topic: `en_EN/common_notes/note_c_3168.dita`

Note:

Once the interim ROE is submitted, an overlapping ROEs error message may be displayed if the dates of employment overlap another ROE in RCM. If the message is displayed, the officer is instructed to correct the ROE during the Entering an interim ROE procedure.
       [Entering an interim ROE](/en/procedure/task/entering_interim_roe.shtml)

     [Entering an interim ROE](/en/procedure/task/entering_interim_roe.shtml) 

## Policy reference

Source topic: `en_EN/task/determining_interim_roe/policy_reference.dita`

- EIA 48
         [EIA 48](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-48.html)

- EIA 50
         [EIA 50](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-50.html)

- EIR 14
         [EIR 14](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-14.html)

- EIR 19
         [EIR 19](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-19.html) 
