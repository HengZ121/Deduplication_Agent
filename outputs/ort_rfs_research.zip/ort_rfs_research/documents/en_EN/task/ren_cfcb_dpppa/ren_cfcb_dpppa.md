# Renewing a claim for family caregiver benefits

Source map: `en_EN/task/ren_cfcb_dpppa/ren_cfcb_dpppa.ditamap`

## Summary

Source topic: `en_EN/task/ren_cfcb_dpppa/summary.dita`

Summary: When a client submits a claim for family caregiver benefits and there is an active benefit period (BP) with entitlement weeks remaining, the BP can be renewed. 

## What you need to know

Source topic: `en_EN/task/ren_cfcb_dpppa/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/ren_cfcb_dpppa/untitled_section.dita`

When assessing a renewal, it might be to the client’s advantage to have a new BP established instead of having the existing BP renewed. Refer to Cancelling, voiding, terminating or withdrawing a claim for more information.
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml)

Family caregiver benefits provide temporary income to eligible clients who take leave from work to care for a critically ill or injured patient. For more information on this benefit type (BT), the officer refers to Family caregiver benefits — Knowledge .
       [Family caregiver benefits — Knowledge](/en/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml) 

### Contentious issues

Source topic: `en_EN/task/ren_cfcb_dpppa/contentious_issues.dita`

When renewing a claim, a client may report a new contentious issue (e.g. reason for separation [RFS], farming or availability) that must be adjudicated. If the issue is reported on the application, an Adjudication Issue (ADJ) WI is created by the system. If a contentious issue is detected while reviewing the claim, the Level 1 must create an ADJ WI for each contentious issue and must attempt to adjudicate the issue according to the National Policy on Levels of Decision . If the Level 1 officer cannot adjudicate the issue, the ADJ WI is referred to Level 2 for adjudication.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Effective date of a renewal

Source topic: `en_EN/task/ren_cfcb_dpppa/effective_date_of_a_renewal.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer refers to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Family caregiver window (FCW)

Source topic: `en_EN/task/ren_cfcb_dpppa/family_caregiver_window_fcw.dita`

The FCW is defined as the 52-week period during which family caregiver benefits for adults or children are payable. For more information, the officer refers to Establishing the family caregiver window .
       [Establishing the family caregiver window](/en/procedure/task/establishing_fbw_etablir_fpppa.shtml) 

### Sharing of benefits

Source topic: `en_EN/task/ren_cfcb_dpppa/sharing_of_benefits.dita`

Family caregiver benefits can be shared between eligible family members within individual limits for each BT. Family caregiver benefits can be shared either at the same time or separately during the 52-week window. The officer refers to Family member for information on acceptable family members.
       [Family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

The clients sharing the benefits must agree on the number of weeks each family member claims. Only weeks that have not yet been paid can be shared. When clients disagree on how to share the benefits, a Level 2 officer adjudicates the division of the remaining weeks.

For more information, the officer refers to Adjudicating the sharing of family caregiver benefits — Disagreement on how to share weeks .
       [Adjudicating the sharing of family caregiver benefits — Disagreement on how to share weeks](/en/procedure/task/adjudicating_na_pcic_bw.shtml) 

### Otherwise available

Source topic: `en_EN/task/ren_cfcb_dpppa/otherwise_available.dita`

Clients do not need to prove that they would be otherwise available or otherwise working to receive family caregiver benefits.

Clients who request sickness benefits during their FCW are not required to prove they would be otherwise available for work. When the sickness period extends beyond the FCW, clients must prove that they are otherwise available to work during this extension period and must provide a medical certificate indicating the start date of their incapacity and the expected recovery date. 

### Deferred reason for separation (RFS)

Source topic: `en_EN/task/ren_cfcb_dpppa/deferred_reason_for_separation_rfs.dita`

In some situations, when clients qualify for and request special benefits, fact-finding and adjudication of the contentious RFS can be deferred. For more information, the officer can refer to Deferral of adjudication .
       [Deferral of adjudication](/en/procedure/activity/deferral_adj.shtml) 

### Benefit period (BP) extension

Source topic: `en_EN/task/ren_cfcb_dpppa/benefit_period_bp_extension.dita`

The BP can be extended to a maximum of 104 weeks to pay additional weeks of sickness, maternity, parental, CCB and family caregiver benefits where the client did not receive the maximum entitlement during the initial BP. For more information on BP extensions for combined special benefits, the officer refers to Benefit period extension for special benefits .
       [Benefit period extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Disentitlements

Source topic: `en_EN/task/ren_cfcb_dpppa/disentitlements.dita`

The following disentitlements related to family caregiver benefits are imposed by the officer when the client does not meet the entitlement conditions:

- 61 - Family caregiver benefits for children or adults - Does not meet entitlement conditions

- 62 - Family caregiver benefits for children or adults - Benefits exhausted

- 63 - Family caregiver benefits for children or adults - No medical proof

For more information, the officer refers to Family caregiver benefits — Knowledge .
       [Family caregiver benefits — Knowledge](/en/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4413.dita) 

### Claims in MPS

Source topic: `en_EN/task/ren_cfcb_dpppa/claims_in_mps.dita`

When the claim is in MPS (CS is 8 - Converted to manual pay ), the officer sends an MM06 to IPOC

When completing the MM06 , the officer must ensure that all information required for the renewal is included. This includes the BT being requested, the period for which the benefits are to be paid, the number of weeks being requested (if applicable), any required allocations, BP extensions, disentitlements, etc. 

### Family caregiver benefits and CCB

Source topic: `en_EN/task/ren_cfcb_dpppa/family_caregiver_benefits_and_ccb.dita`

While family caregiver benefits and CCB may be combined, CCB cannot be paid for the same patient at the same time as family caregiver benefits. CCB can be paid either before the FCW opens or after it ends, but cannot be paid during an existing FCW for the same patient. The FCW does not end until the maximum entitlement weeks of family caregiver benefits have been paid or the 52-week window has ended. 

### Subsequent claim

Source topic: `en_EN/task/ren_cfcb_dpppa/subsequent_claim.dita`

When a claim is renewed with 4 or fewer weeks of benefits remaining and the client has worked enough hours to establish a new claim, the renewal application can be used to establish a subsequent claim. 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_4413.dita`

Note:

When the claim is in MPS (claim status [CS] is 8 - Converted to manual pay ) and the client does not meet the entitlement conditions, the officer does not impose the disentitlement in FTS and does not complete an Operational Centre Memo (MM06) transaction , as no benefits are payable. 

## Regional considerations

Source topic: `en_EN/task/ren_cfcb_dpppa/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/ren_cfcb_dpppa/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/ren_cfcb_dpppa/in_nws.dita`

- Are there earnings, monies on separation, motor vehicle accident compensation, workers’ compensation benefits or wage loss insurance payments to consider or allocate?

- Is there an ADJ WI?

- If yes, for what issues?

- Did the client indicate on the application that he or she is providing care or support for a critically ill family member?

- Are there any SROCs or WIs containing the CCB/Family Caregiver: INS5257 Authorization to release medical information — Form ?
         [CCB/Family Caregiver: INS5257 Authorization to release medical information — Form](http://forms-formulaires.prv/lc/content/EForms/en/Detail.html?Form=INS5257)

- Are there any SROCs or WIs containing the Family caregiver: INS5242B Medical certificate — Form ?
         [Family caregiver: INS5242B Medical certificate — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242B.pdf)

- Have any INS5257 or INS5242B forms been uploaded? 

### In FTS:

Source topic: `en_EN/task/ren_cfcb_dpppa/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the last renewable week (LRW) been reached?

- Has the waiting period (WP) been served, half served, waived or deferred?

- Is there a registration number? 

### In RCM:

Source topic: `en_EN/task/ren_cfcb_dpppa/in_rcm.dita`

- Has an ROE been submitted for the renewal?

- Are there earnings, monies on separation, motor vehicle accident compensation, wage loss insurance workers’ compensation benefits or wage loss insurance payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/ren_cfcb_dpppa/in_imaging.dita`

- Is there any other documentation which may impact the renewal claim?

- Are there any documents containing the INS5257 or INS5242B forms? 

## Step by step

Source topic: `en_EN/task/ren_cfcb_dpppa/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/ren_cfcb_dpppa/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/ren_cfcb_dpppa/reviewing_the_file_level_1.dita`

- In FTS, determine if there is a registration number:

- If yes, go to step 2.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- Determine if the WP must be served:

- If no , go to step 3.

- If yes, refer to Cancelling a benefit period . When it does not benefit the client to cancel the BP, go to step 3.
               [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml) 

#### Updating the patient record

Source topic: `en_EN/task/ren_cfcb_dpppa/updating_the_patient_record_level_1.dita`

- On the Search tab, select Caregiver/Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, find the patient record as follows:

- Claimant’s SIN: Enter the client’s SIN.

- Select Search .

- Select the patient record to access the Caregiver/Compassionate care data entry (MCB1) screen.

- From the Caregiver/Compassionate care data entry (MCB1) screen of the duplicate patient record, modify the patient record as follows:

- Action: Select Modify.

- Type: Select the appropriate type of benefits.

- Select Update .

- From the Caregiver/Compassionate care data entry (MCB1) screen of the duplicate patient record, modify the claimant record as follows:

- Action: Select Modify .

- Entitlement weeks: Select 00 .

- Compassionate care status: Select 19 - Claim moved to another certificate .

- Select Update .

- Select Close .

- From the Search for Caregiver/Compassionate care patient (MCB2) search results, select on the duplicate patient record to access the Caregiver/Compassionate care data entry (MCB1) screen and modify the patient record as follows:

- Action: Select Modify .

- Certificate confirmation: Select 9 - Duplicate record .

- Other patient certificate search: Select the appropriate choice from the drop-down menu.

- Other certificate number: Enter the other certificate number.

- Select Update .

- Determine if there are weeks of family caregiver benefits remaining to be paid:

- If yes, go to step 9.

- If no, go to Maximum family caregiver benefits already paid .
               [Maximum family caregiver benefits already paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ren_cfcb_dpppa#max_paid)

- In NWS and in FTS, determine if one of the following conditions exists to extend the BP:

- The client was incarcerated and has since been tried and not found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If one of the conditions exists, refer to Benefit period extension and then go to step 10.
                   [Benefit period extension](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions exist, go to step 10.

- Determine if the LRW has been reached:

- If no, go to step 11.

- If yes, go to Last renewable week (LRW) has been reached .
               [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ren_cfcb_dpppa#LRW)

- Determine the following:

- Did the client provide an acceptable medical certificate ?
               [acceptable medical certificate](/en/procedure/task/determining_pcic_med_cert.shtml)

- Is the client an eligible family member ?
               [eligible family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

- Does the client attest to providing care and support for a critically ill or injured patient ?

- If the answer was yes to all of the above criteria, go to step 12.

- If the answer was no to any of the above criteria, go to Not entitled to family caregiver benefits .
                   [Not entitled to family caregiver benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ren_cfcb_dpppa#not)

               [providing care and support for a critically ill or injured patient](/en/procedure/task/determining_pcic_benefit_child.shtml)

- Determine if the client is entitled to all of the requested family caregiver benefits weeks. Refer to Determining if the client is entitled to the family caregiver benefits weeks requested .

- If yes, go to step 13.

- If no, make a note to include the D62 information in the letter and impose the disentitlement. Go to step 13.

- Determine if there are any outstanding issues that require adjudication:

- If no, go to step 14.

- If yes or uncertain, refer to Determining if a claim is ready to be renewed or converted . Go to step 14.
               [Determining if a claim is ready to be renewed or converted](/en/procedure/task/determ_claim_demande_ren_conv.shtml)

- Determine the renewal week. Refer to Determining the effective date of a renewal or a conversion .

- Determine if the CS is 8 - Converted to manual pay :

- If no, go to step 16.

- If yes, go to step 20. 

#### Inputs

Source topic: `en_EN/task/ren_cfcb_dpppa/inputs_level_1.dita`

- In FTS, select the Renewal/Revised (M106) transaction and input a renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- No claimant’s report: If requested by the client, check the box.

- Select Update .

- On the Search tab, select Caregiver/Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, find the patient record as follows:

- Claimant’s SIN: Enter the client’s SIN .

- Select Search .

- Select the patient record to access the Caregiver/Compassionate care data entry (MCB1) screen.

- Select Entitlement (M112) to access the Caregiver/Compassionate care entitlement (M112) screen.

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Modify .

- Start date: Leave this field blank.

- End date: Leave this field blank.

- Entitlement weeks: Enter the number of entitlement weeks.

- Status: Leave this field blank.

- Select Update .

- Go to step 27.

- Determine if, before submitting the Operational Centre Memo (MM06) transaction to IPOC, a Level 2 officer must adjudicate any outstanding issues:

- If yes, go to step 21.

- If no, go to step 23.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type awaiting Level 2 decision.

- Bring forward date: Enter today’s date + 10 working days.

- When the WI moves to the current workload, determine if a decision has been rendered:

- If no, return to step 21.

- If yes, go to step 23.

- In FTS, on the Caregiver/Compassionate care data entry (MCB1) screen, update the claimant record as follows:

- Action: Select Modify .

- Entitlement weeks: Enter the number of entitlement weeks.

- BPC: Leave this field blank.

- Waiting period served: Leave this field blank.

- Status: Select 12 - Caregiver/Compassionate benefits approved .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 30 - New information on manual pay claim .

- Remarks line 1: Type “ Renewal CT [20 or 21] as of [XXXX]. [number of weeks] weeks to be paid. Window [XXXX] to [XXXX]."

- Remarks line 2: If necessary, provide any disentitlement information.

- Remarks line 3: If necessary, provide any extension information. Provide the NO-CR-CODE and the WP deferral.

- Remarks line 4: Enter your first name and last name.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select: Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the applicable registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update . 

#### Communication

Source topic: `en_EN/task/ren_cfcb_dpppa/communication_level_1.dita`

- In ACS, create and send or add to the saved N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday's date (1246) .

- if benefits are approved:

- Special Benefits approved (3046) .

- Family caregiver for (adults or children) approved (4320) .

- select the period of approved family caregiver benefits.

- Number of family caregiver for adult or children weeks to be paid (4287).

- Enter the number of weeks.

- if benefits are denied:

- Special Benefits Denied (3065): Select Family Caregiver Benefits denied: D61, D62, D63 (4315)

- for all claims:

- Waiting Period Message (2445) (if the client has not served the WP):

- Select the appropriate option

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration

- Determine if there are 4 or more weeks remaining to be paid in the BP:

- If no, go to step 29.

- If yes, go to step 30.

- Determine if the renewal was finalized within 28 days of the renewal application being filed (i.e. filing date + 27 days):

- If yes, go to step 30.

- If no, in NWS, create a Reminder (REM) WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “subsequent claim not automated.”

- Due date: Select the LRW + 3 weeks.

- Details: Type “subsequent claim to be established.”

- Destination: Select the S ervice Canada Centre (SCC) shown in FTS.

- End User: Select Next available user .

- Go to step 30.

- In NWS, complete the WI. 

#### Maximum family caregiver benefits already paid

Source topic: `en_EN/task/ren_cfcb_dpppa/maximum_family_caregiver_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for family caregiver benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “no renewal — maximum benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No renewal is possible as the client cannot receive the requested family caregiver benefits. The client does not qualify for a new claim as zero hours were accumulated after the BPC. D62 imposed.”

- If the client has worked since the BPC , type “No renewal is possible as the client cannot receive the requested family caregiver benefits. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. D62 imposed.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type the following: “We cannot reactivate your claim for Employment Insurance benefits starting [renewal week - Sunday’s date] as you have received the maximum number of benefit weeks payable to you during this benefit period. To receive family caregiver benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you will have to file a new claim.”

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- Determine if the CS is 8 - Converted to manual pay:

- If no, go to step 6.

- If yes, go to step 10.

- In FTS, select the Renewal/Revised (M106) transaction and input the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if necessary)

- Claim type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Add .

- Disentitlement: Select 62 - Family Caregiver for children or adults - Benefits exhausted .

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Go to step 8.

- On the Search tab, select Caregiver/Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, find the patient record as follows:

- Claimant’s SIN: Enter the client's SIN.

- Select Search .

- Select the patient record to access the Caregiver/Compassionate care data entry (MCB1) screen.

- Select Entitlement (M112) to access the Caregiver/Compassionate care entitlement (M112) screen:

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select A - Add .

- Start date: Leave this field blank.

- End date: Leave this field blank.

- Entitlement weeks: Leave this field blank.

- Status: Select 10 - Maximum number of caregiver/compassionate care benefit weeks paid for patient .

- Select Update .

- Go to step 11.

- In FTS, select the Renewal/Revised(M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/ren_cfcb_dpppa/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for family caregiver benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “LRW reached — family caregiver benefits requested.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No renewal is possible as LRW has been reached and no BP extension possible. Client does not qualify for a new claim as zero hours were accumulated after BPC.”

- If the client has worked since the BPC , type “No renewal is possible as LRW has been reached and no BP extension possible. Client does not qualify for a new claim as [number of hours] were accumulated after BPC and the client needed [number of hours] to qualify.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type the following: “We cannot reactivate your claim for Employment Insurance benefits starting [Renewal week - Sunday’s date]. Please note that we are required to advise you of all decisions made on your claim. No family caregiver benefits are payable to you on this claim because the last renewal week has been reached on this benefit period. To receive family caregiver benefits, you must work the required minimum number of insurable employment hours. If you want to receive family caregiver benefits in the future, you will have to file a new claim.”

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Not entitled to family caregiver benefits

Source topic: `en_EN/task/ren_cfcb_dpppa/not_entitled_to_family_caregiver_benefits_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[D61 or D63] imposed. Entitlement not proven — family caregiver benefits.”

- Details: Type the appropriate options:

- “D61 imposed effective [date]. The client is not entitled to benefits. The client is not providing care or support to the critically ill or injured patient.”

- “D61 imposed effective [date]. The client is not entitled to benefits. The client is not recognized as a family member of the critically ill or injured patient.”

- “D63 imposed effective [date]. The client is not entitled to benefits. The client did not provide an acceptable medical certificate.”

- Determine if the CS is 8 - Converted to manual pay:

- If no, go to step 3.

- If yes, go to step 8.

- Determine the renewal week.Refer to Determining the effective date of a renewal or a conversion .

- In FTS, select the Renewal/Revised (M106) transaction and impose the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Add .

- Disentitlement: Select the appropriate disentitlement:

- 61 - Family caregiver for children or adult - Does not meet entitlement conditions ;

- 63 - Family caregiver for children or adult - No medical proof

- Start date: Select the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- On the Search tab, select Caregiver/Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, find the patient record as follows:

- Claimant’s SIN: Enter the client's SIN.

- Select Search .

- Select the record to access the Caregiver/Compassionate care data entry (MCB1) screen.

- Select Entitlement (M112) to access the Caregiver/Compassionate care entitlement (M112) screen.

- Type: Select the appropriate option:

- 20 - Family caregiver for children ;

- 20 - Family caregiver for adults .

- Action: Select Add .

- Start date: Leave the field blank.

- End date: Leave the field blank.

- Entitlement weeks Leave the field blank.

- Status: Select the appropriate option:

- 11 - Missing certificate

- 13 - Not a family member

- 14 - Inadequate medical certificate

- 16 - Medical certificate not issued by a medical practitioner

- Select Update .

- Go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4414.dita)

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send or add to the saved N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special Benefits Denied (3084): Select Family Caregiver Benefits denied: D61, D62, D63 (4315 .

- Waiting Period Message (2445) (if the client has not served the WP):

- Select the appropriate option.

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4414.dita`

Note:

Select status code 14 - Inadequate medical certificate when the client does not attest to providing care and support for a critically ill or injured patient. 

## Policy reference

Source topic: `en_EN/task/ren_cfcb_dpppa/policy_reference.dita`

 
