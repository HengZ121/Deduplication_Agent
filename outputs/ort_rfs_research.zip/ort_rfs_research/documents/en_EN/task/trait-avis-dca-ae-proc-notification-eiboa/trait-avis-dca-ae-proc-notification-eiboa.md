# Processing the notification of an Employment Insurance Board of Appeal decision

Source map: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/trait-avis-dca-ae-proc-notification-eiboa.ditamap`

## Summary

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/summary.dita`

Summary: Once the Employment Insurance Board of Appeal (EI BOA) renders a decision on an appeal, the Commission is notified. 

## What you need to know

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4835.dita) 

### Receiving a decision from the Employment Insurance Board of Appeal (EI BOA)

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/receiving_a_decision_from_the_employmen_6f1ff599.dita`

After rendering a decision on the appeal, the EI BOA sends the decision to all interested parties. The EI BOA sends a notification of the decision to the Commission through ADMS, Common Document Share and by sending an email to the GD mailbox of the region in which the appeal was processed. In ADMS, the EI BOA completes action to populate a date in the Commission notified of BOA Decision field on the Appeal Log screen and adds a copy of the decision in the system. The officer can view it by selecting View Decision on the Review Decision tab. The EI BOA also sends an electronic copy of the decision to the Commission through the 9.BoardofAppeal-Conseild'appel exchange folder in Common Document Share.

In ADMS, when the BOA Decision received at APC field on the Appeal Log tab is completed, the appeal record in the officer’s workload is highlighted in red and the selection in the Action required field changes to Review decision . Then, the officer can review the decision in ADMS and in Common Document Share. 

### Exchanging appeal information with the Employment Insurance Board of Appeal (EI BOA)

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/exchanging_appeal_information_with_the__a25f7268.dita`

The EI BOA and Commission exchange information through ADMS and Common Document Share. In ADMS, EI BOA and appeal processing officers have distinct modules that communicate with each other throughout the appeal process. In Common Document Share, the folder titled 9.BoardofAppeal-Conseild'appel is used for exchanging documents. Additionally, it acts like a drop box for each party. The EI BOA puts any documents that must be exchanged with the Commission in this folder for pick-up and the Commission does the same when sending documents to the EI BOA. Documents are not to be housed in this folder. They are moved to the appropriate SIN or business number (BN) folder in the regional EI BOA folder of Common Document Share and kept there. 

### Implementing an Employment Insurance Board of Appeal (EI BOA) decision

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/implementing_an_employment_insurance_bo_3a134831.dita`

On the same day the notification is received, the officer retrieves the EI BOA decision from the 9.BoardofAppeal-Conseild'appel exchange folder and moves it to the client’s Record-XXXXXX folder in the 2.SST-GD-TSS-DG / BOA-CA regional folder of Common Document Share. That same day , the officer reviews the EI BOA decision and updates ADMS based on the decision. Depending on the decision, the officer either implements the decision or suspends the implementation until National Headquarters reviews the decision. It is important that the officer takes immediate action, as National Headquarters has very limited time to review possible Commission appeals, and any delay may prevent the Commission from pursuing the appeal with the SST-Appeal Division.

**Decision implemented without National Headquarters review**

When the EI BOA renders a decision that the Commission will not appeal to the SST-Appeal Division, the officer can implement the decision. This includes the following decision types:

- dismissed (including a rejected concession)

- delayed appeal denied

- withdrawn

- abandoned

- dismissed with modifications, when modifications are favorable to the Commission 

### Decision that must be reviewed by National Headquarters

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/decision_that_must_be_reviewed_by_natio_4f956620.dita`

When the EI BOA allows an appeal, either in whole or in part, National Headquarters reviews the decision to determine if a possible Commission appeal (PCA) must be considered. This includes the following decision types in all cases:

- allowed (includes concessions)

- dismissed with modifications, when modifications are unfavorable to the Commission

If any issues in the appeal are dismissed or withdrawn, the officer implements the decisions on these issues in ADMS before moving the PCA to National Headquarters’ workload. No other action must be taken in other systems until the PCA review is complete.

The officer enters today’s date in the Date PCA sent to NHQ field to move the record to National Headquarters’ workload.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4836.dita) 

If National Headquarters proceeds with the PCA, no further action is required from the officer. National Headquarters creates a new folder in SST-AD and moves all pertinent information from the 2.SST-GD-TSS-DG / BOA-CA folder to the 3.SST-AD-TSS-DA folder for that appeal.

If National Headquarters decides not to pursue the PCA, it creates a memo explaining its rationale and saves it on the Feedback tab of the Quality Review section in ADMS. In ADMS, National Headquarters returns the case to the region so the decision can be implemented. The appeal is automatically assigned to the officer who prepared the case or to the officer who last reviewed the EI BOA decision. If neither of these officers have an active profile in ADMS, the appeal is pending in the workload and the Action Required field displays Assign SCBO . The Team Leader monitors the regional workload and reassigns cases so decisions can be implemented. The officer assigned to the case then implements the decision.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4837.dita) 

At the first stage, the senior appeals officer reviews the file and determines if the case should be pursued. If the PCA is not pursued at this stage, the case is returned to the region for the decision to be implemented. If the senior appeals officer recommends pursuing the PCA, the case moves to the second stage.

At the second stage, the senior appeals officer presents the recommendation to the appeals committee for review. If the committee agrees, the PCA is pursued. Otherwise, the PCA is not pursued, and the case is returned to the region for the decision to be implemented. 

### Employer appeal allowed by the Employment Insurance Board of Appeal (EI BOA)

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/employer_appeal_allowed_by_the_employme_ebf5a503.dita`

The employer can appeal the Commission’s decision to allow the client benefits without any disqualification or disentitlement when the client voluntarily left or was dismissed from employment. If the EI BOA allows the employer’s appeal, the disqualification or disentitlement is imposed retroactively and an overpayment (OP) is established for collection. 

### Appeal against denial of delayed request for reconsideration

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/appeal_against_denial_of_delayed_reques_d18d86f8.dita`

When the Commission’s discretionary decision to deny a delayed request for reconsideration under EIA 112 is appealed to the EI BOA, the denial is the only issue before the EI BOA. If the EI BOA finds that the Commission did not exercise its discretion in a judicious manner, it can allow the appeal against the denial. If the EI BOA allows the appeal, National Headquarters reviews the case to determine if there is a PCA. If there are no grounds for a PCA, the officer processes the request for reconsideration on the substantive issues as a new request for reconsideration and links the 2 files in ADMS. The substantive issues are reconsidered under EIA 112.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 

### Employment Insurance Board of Appeal (BOA) notified of complete withdrawal or abandonment

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/employment_insurance_board_of_appeal_bo_4b343c77.dita`

In certain cases, the EI BOA does not proceed with making a decision on any of the appealed issues. This occurs in situations before the appeal is completely withdrawn or considered abandoned, such as when the appellant cannot be contacted despite reasonable efforts to do so, or when the appellant failed to communicate with the EI BOA when requested. The EI BOA changes the appeal status to Withdrawal or Abandoned , and moves the appeal to the APC workload of the officer assigned. The officer is responsible for taking appropriate action to reinstate collection actions in PSCD, before completing the Date withdrawal / abandonment finalized field on the Review Decision tab. 

### Employment Insurance Board of Appeal (EI BOA) recommendations

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/employment_insurance_board_of_appeal_ei_c2a1b6e2.dita`

The Commission’s refusal to write off an OP or penalty is not a decision that can be appealed under the EIA, but rather a financial and administrative matter to be resolved by the Chief Financial Officer Branch (CFOB) of the department and for which there is no appeal rights. However, if an appellant files an appeal with the EI BOA on the Commission’s refusal to write off an OP or penalty, the EI BOA can recommend that the Commission make suitable arrangements to recover the debt in instalments, or even to write it off. In these cases, the officer refers to Processing an Employment Insurance Board of Appeal or Social Security Tribunal recommendation about a debt after processing the notification of the EI BOA decision.
       [Processing an Employment Insurance Board of Appeal or Social Security Tribunal recommendation about a debt](/en/procedure/task/proc_sst_debt.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4838.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4835.dita`

Note:

For appeals to the Social Security Tribunal (SST)-General Division, refer to Processing the notification of a Social Security Tribunal-General Division decision .
       [Processing the notification of a Social Security Tribunal-General Division decision](/en/procedure/task/proc_sst.shtml)

     [Processing the notification of a Social Security Tribunal-General Division decision](/en/procedure/task/proc_sst.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4836.dita`

Note:

An allowed concession is generally not pursued as a PCA. However, the decision must still be reviewed before the officer can implement it. This is because, in rare cases, a PCA can be pursued by the Commission when the concession has been allowed, but the result is contrary to the EIA. 

### Note

Source topic: `en_EN/common_notes/note_c_4837.dita`

Note:

Information can initially indicate that a PCA will be pursued and later indicate that it will not be pursued. This is because the decision to pursue the PCA is made in 2 stages. 

### Note

Source topic: `en_EN/common_notes/note_c_4838.dita`

Note:

A recommendation from the EI BOA or SST to write off a debt is not an appeal or a review of a decision that establishes the debt as stated in EIA 47(4) . Therefore, collection is reinstated in PSCD.
       [EIA 47(4)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-47.html)

     [EIA 47(4)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-47.html) 

## Regional considerations

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/what_you_need_to_look_for.dita`

### In ADMS:

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/in_adms.dita`

- What is the decision of the EI BOA member?

- Was a collection of a debt suspended due to the appeal? 

### In Common Document Share:

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/in_common_document_share.dita`

- What is the decision of the EI BOA member?

- Is there a memo from National Headquarters? 

### In PSCD:

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/in_pscd.dita`

- Was a collection of a debt suspended due to the appeal? 

### In NWS:

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/in_nws.dita`

- Is the issue under appeal an adjudication issue that was automatically resolved ( Resolve Issue screen) or automatically adjudicated? 

## Step by step

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/reviewing_the_file_level_2.dita`

- Determine if the EI BOA or National Headquarters returned the file:

- If the EI BOA returned the file after making a decision on the appeal, go to step 2.

- If National Headquarters returned the file due to not pursuing the PCA, go to step 9.

- In Common Document Share, copy the EI BOA decision and any additional documentation from the 2.CEIC – CAAC folder in the 9.BoardofAppeal-Conseild'appel exchange folder. Then, paste them in the client’s Record folder in the 2.SST-GD-TSS-DG / BOA-CA regional folder.

- In the 9.BoardofAppeal-Conseild'appel exchange folder, delete the documentation sent by the EI BOA.

- Review the decision.

- In ADMS, determine if the decision results are correctly displayed for all issues on the Review Decision field:

- If the decision results are correctly displayed, go to step 6.

- If the decision results are incorrectly displayed or the field is blank, select the correct decision. Then, go to step 6.

- Based on the decision results, do the following:

- If the appeal is allowed or dismissed with modifications not favourable to the Commission, go to step 7.

- If the appeal is dismissed or dismissed with modifications favourable to the Commission, go to Appeal dismissed .
               [Appeal dismissed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/trait-avis-dca-ae-proc-notification-eiboa#dismissed)

- If the delayed appeal is denied, go to Delayed appeal denied .
               [Delayed appeal denied](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/trait-avis-dca-ae-proc-notification-eiboa#denied)

- If the appeal is withdrawn or abandoned, go to Appeal withdrawn or abandoned .
               [Appeal withdrawn or abandoned](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/trait-avis-dca-ae-proc-notification-eiboa#withdrawn)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4839.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4840.dita)

- On the Review Decision tab, complete the following field:

- Date PCA sent to NHQ: Enter today’s date.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4841.dita)

- Wait until National Headquarters reviews the EI BOA decision and determines if a PCA will be pursued:

- If a PCA is not pursued, in ADMS, in the PCA Review section, National Headquarters selects PCA Denied - implement decision in the Result field and enters the current date in the Denied PCA sent to APC field.

- If a PCA is pursued, in ADMS, in the PCA Review section, National Headquarters selects Possible Commission appeal or Commission appeal (blanket) in the Result field. No further action is required unless National Headquarters sends other instructions.

- Review the memo from National Headquarters to determine if any particular information about how to implement the decision is required. Consider this accordingly when implementing the decision.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4842.dita)

- In NWS, determine if the issue under appeal was automatically resolved ( Resolve Issue screen) or automatically adjudicated:

- If yes, go to step 11.

- If no, go to step 12.

- Invalidate the original decision as follows:

- Double-click the resolved issue in the Client information tree .

- Under Decision Options , select Decision no longer valid .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4081.dita)

- Create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)] — [allowed or allowed with modifications].”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- the action taken for the decision implementation;

- any impact on a previous decision or claim.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4082.dita)

- In PSCD, determine if an A - Appeal lock was applied to an OP or penalty while the EI BOA reviewed the appeal:

- If no, go to step 14.

- If yes, refer to Reinstating the collection of a debt and go to step 14.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4843.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4844.dita)

- To implement the decision, make the necessary changes in the appropriate systems:

- If Level 1 support is necessary, go to step 15.

- If Level 1 support is not necessary, go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4085.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4086.dita)

- In NWS, create an Action Item (AI) WI as follows:

- Complexity: Select Level 1 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 1 support required.”

- Details: Enter the ADMS record number and the details of the required actions.

- Obtained on: Select today’s date.

- Source Details: Type “EI BOA decision.”

- Urgent: Check the box.

- Wait until the work is completed at Level 1, then go to step 17.

- In ADMS, on the Review Decision tab, complete the following field:

- Date decision implemented: Select today’s date.

- No further action is required. 

#### Appeal dismissed

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/appeal_dismissed_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)].”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- the action taken for the decision implementation;

- any impact on a previous decision or claim.

- In PSCD, determine if an A - Appeal lock was applied to an OP or penalty while the EI BOA reviewed the appeal:

- If no, go to step 9.

- If yes, refer to Reinstating the collection of a debt and go to step 9.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

- In ADMS, on the Review Decision tab, complete the following fields:

- Decision Result: Select Dismissed .

- Date decision implemented: Select today’s date.

- Determine if decisions have been implemented for all issues in the appeal:

- If no, return to step 6.

- If yes, no further action is required. 

#### Delayed appeal denied

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/delayed_appeal_denied_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — delayed appeal denied.”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- the action taken for the decision implementation;

- any impact on a previous decision or claim.

- In PSCD, determine if an A - Appeal lock was applied to an OP or penalty while the EI BOA reviewed the appeal:

- If no, go to step 9.

- If yes, refer to Reinstating the collection of a debt and go to step 9.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

- In ADMS, on the Review Decision tab, complete the following fields:

- Decision Result: Select Delayed appeal denied .

- Date decision implemented: Select today’s date. 

#### Appeal withdrawn or abandoned

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/appeal_withdrawn_or_abandoned_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)].”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- the action taken for the decision implementation;

- any impact on a previous decision or claim.

- In PSCD, determine if an A - Appeal lock was applied to an OP or penalty while the EI BOA reviewed the appeal:

- If no, go to step 9.

- If yes, refer to Reinstating the collection of a debt and go to step 9.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

- In ADMS, on the Review Decision tab, complete the following fields:

- Decision Result: Select Withdrawn .

- Date withdrawal/abandonment finalized: Select today’s date.

- Determine if decisions have been implemented for all issues in the appeal:

- If no, return to step 6.

- If yes, no further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_4839.dita`

Note:

When an appeal contains multiple issues, the officer must implemented decisions on issues that are not subject to PCA in ADMS before sending the PCA to National Headquarters. No other action is required in other systems until the PCA review is complete.

There is no different decision result for an appeal with a delayed appeal denied or abandoned, as these decision results must be on all issues appealed. 

#### Note

Source topic: `en_EN/common_notes/note_c_4840.dita`

Note:

An allowed concession decision must still be reviewed before its implementation. 

#### Note

Source topic: `en_EN/common_notes/note_c_4841.dita`

Note:

This changes the status to Possible Commission Appeal , indicates the required action to Assign SAO , and transfers the appeal to the national workload. National Headquarters reviews the decision to determine if pursuing a PCA is required. It is important to do this input the same day the decision is received, as the Commission has limited time to appeal the EI BOA decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_4842.dita`

Note:

If clarification is required, request guidance from a Business Expertise Advisor. 

#### Note

Source topic: `en_EN/common_notes/note_c_4081.dita`

Note:

The initial record of decision (ROD) must be invalidated in NWS as the ROE and the automatically resolved or automatically adjudicated ROD can be used when a claim is recalculated or when a new BPC is established. If the change is not made, benefits could be paid incorrectly during automation. 

#### Note

Source topic: `en_EN/common_notes/note_c_4082.dita`

Note:

If the allowed appeal has any impact on a previous decision or claim, create a WI in NWS and assign it to the appropriate level. 

#### Note

Source topic: `en_EN/common_notes/note_c_4843.dita`

Note:

If the decision results in the need to send an Operational Centre Memo (MM06) transaction to IPOC, and if a related OP is suspended, do not reinstate the collection action. In the Operational Centre Memo (MM06) transaction, advise IPOC to terminate the lock on the date of the EI BOA decision and apply any underpayments (UPs) to the OP. This ensures that when IPOC processes the decision, the debt is recovered from any potential monies payable. 

#### Note

Source topic: `en_EN/common_notes/note_c_4844.dita`

Note:

When inputting transactions related to an EI BOA appeal, use OP detection code 22 - Appeal to the Social Security Tribunal (SST) / ≤ w/c 1867 Umpire . 

#### Note

Source topic: `en_EN/common_notes/note_c_4085.dita`

Note:

When a decision about a reason for separation (RFS) is changed, in addition to invalidating any automated RODs, change the Special Condition field on the ROE in RCM to reflect the correct decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_4086.dita`

Note:

If necessary, contact the client to obtain the information required to implement the decision (e.g. claimant’s reports). 

## Policy reference

Source topic: `en_EN/task/trait-avis-dca-ae-proc-notification-eiboa/policy_reference.dita`

 
