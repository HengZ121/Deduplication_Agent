# Completing an ROE Comments WI — Regular ROE

Source map: `en_EN/task/roe_comments_reg/roe_comments_reg.ditamap`

## Summary

Source topic: `en_EN/task/roe_comments_reg/summary.dita`

Summary: Comments identified on a regular ROE require review to determine if they impact the claim calculation or entitlement. When fraud indicators are present and the file is not already under investigation, the officer refers the file to Integrity. 

## What you need to know

Source topic: `en_EN/task/roe_comments_reg/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/roe_comments_reg/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4664.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4665.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0070.dita) 

ROE comments appear in block 18 for regular ROEs. The intended use of the Comments field is for the employer to clarify or provide additional information. 

### Comment types

Source topic: `en_EN/task/roe_comments_reg/comment_types.dita`

Comments generally fall into one of 3 categories:

- No impact: information that is not relevant to claim calculation or entitlement (e.g. a personal note to the employee such as “Best of luck in the future”)

- Repetitive information: information already indicated elsewhere (e.g. comments indicate “shortage of work” and block 16 displays A - Shortage of Work )

- Possible impact: information that is relevant to claim calculation or entitlement (e.g. additional details about moneys paid on separation or the reason for separation [RFS]) 

### Creating a WI

Source topic: `en_EN/task/roe_comments_reg/creating_a_wi.dita`

An artificial intelligence model attempts to address comments before the ROE enters the ACP wait process. During the ACP wait process, the system creates an ROE Comments WI for the last ROE only if the artificial intelligence model was unable to address the comments on the ROE. The system assigns ROE Comments WIs to Non-complex officers. 

### Impact on calculation

Source topic: `en_EN/task/roe_comments_reg/impact_on_calculation.dita`

Comments which could impact claim calculation or entitlement must be reviewed and changes must be made on the ROE in RCM. These comments are copied to the Additional information field in RCM before being removed from block 18 .

Comments which have no impact or contain repetitive information are removed from block 18 at the Non-complex Level. If the comments cannot be removed based on the procedure, the officer reassigns the ROE Comments WI to Level 1.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4666.dita) 

### Automation

Source topic: `en_EN/task/roe_comments_reg/automation.dita`

ROE comments alone do not prevent claim automation. If the Level 1 officer determines the comments do affect calculation or entitlement, a review of the claim is required to determine the status. If the claim has been finalized, a recalculation is needed.

If the RFS is changed from a non-contentious to contentious issue and the status of the claim is In Progress (Manual) or the claim has been established, the Level 1 officer must ensure that the new RFS is adjudicated. 

### ROE errors found during validation

Source topic: `en_EN/task/roe_comments_reg/roe_errors_found_during_validation.dita`

ROEs are automatically validated by the system. In some situations, this validation can be performed only when a change is made in RCM, such as deleting a comment. If an error is detected during validation, an ROE Correction WI is not automatically created by the system, but the error prevents ACP from calculating the claim. Whenever possible, the officer must immediately correct the ROE error to maximize automation. 

### Fraud indicators

Source topic: `en_EN/task/roe_comments_reg/fraud_indicators.dita`

Before taking any actions, officers determine if the application is already under investigation for potential fraud. Officers can determine that there is an ongoing Integrity investigation for this application if:

- a 71 - Integrity Services case manual action (MA71) or 71 - Integrity Services case disentitlement (D71) is imposed;

- an SROC created by Integrity is on file;

- an Action Item (AI) WI is assigned to Integrity;

- a Call Back (CB) WI is assigned to Integrity.

If none of these are on the file, officers review the file to determine if fraud indicators are present. If yes, officers:

- determine if the banking information has been changed in FTS and, if so, terminate the direct deposit;

- impose a D71 on skeleton and BPNE 1, 2 or 7 claims or an MA71 on established claims, if necessary;

- complete the registration number to suspend the initial application process to prevent the claim from establishing until an investigation is completed;

- refer the issue to Integrity for investigation;

- complete the Claim Set-Up (CS) WI.

If the only fraud indicator is the fraud warning highlighted in red in FTS, the officers do not refer the issue to Integrity.

For more information, officers refer to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4664.dita`

Note:

This task only applies to an ROE Comments WI in the normal ACP process. For comments on an ROE in the specialized ACP process, the officer refers to Post-EI ERB: Completing an Assessment Issue ROE Comments WI — Regular ROE .
       [Post-EI ERB: Completing an Assessment Issue ROE Comments WI — Regular ROE](/en/procedure/task/post_eierb_completing_assessment_issue_roe_comments_wi_regular_roe.shtml)

     [Post-EI ERB: Completing an Assessment Issue ROE Comments WI — Regular ROE](/en/procedure/task/post_eierb_completing_assessment_issue_roe_comments_wi_regular_roe.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4665.dita`

Note:

For an ROE Comments WI for a Government of Canada ROE that requires fact-finding, the officer refers to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0070.dita`

Note:

For an ROE Comments WI for an Air Canada ROE SAT, the officer refers to Major Employer Events (MEE) — Information Bulletin .
       [Major Employer Events (MEE) — Information Bulletin](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68)

     [Major Employer Events (MEE) — Information Bulletin](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68) 

### Note

Source topic: `en_EN/common_notes/note_c_4666.dita`

Note:

Comments about COVID-19 or the client being in quarantine does not have an impact on calculation and should be actioned at the Non-complex Level. 

## Regional considerations

Source topic: `en_EN/task/roe_comments_reg/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/roe_comments_reg/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/roe_comments_reg/in_fts.dita`

- Is the claim established? 

### In NWS:

Source topic: `en_EN/task/roe_comments_reg/in_nws.dita`

- Is the Claim action status In Progress (Automation) or In Progress (Manual) ? 

### In RCM:

Source topic: `en_EN/task/roe_comments_reg/in_rcm.dita`

- Are the comments still displayed in block 18 of the ROE? 

## Step by step

Source topic: `en_EN/task/roe_comments_reg/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/roe_comments_reg/non-complex.dita`

#### Reviewing the file for fraud indicators

Source topic: `en_EN/task/roe_comments_reg/reviewing_the_file_for_fraud_indicators_non-complex.dita`

- In NWS, determine if there is documentation indicating that the file is under investigation for potential fraud:

- If no, go to step 2.

- If yes, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_reg#nc_item_7)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1527.dita)

- Review the application and ROEs to determine if known fraud indicators are present and if fraud is suspected. Refer to Fraud indicators: Identifying potentially fraudulent claims — Knowledge :

- If yes, go to step 3.

- If no, go to step 4.

- In FTS, determine if the banking information has been changed to the banking information on the potentially fraudulent application:

- If no, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_reg#nc_item_7)

- If yes, terminate the banking information by referring to Ending a direct deposit and go to Fraud indicators are present .
               [Ending a direct deposit](/en/procedure/task/ending_dd.shtml) 
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_reg#nc_item_7) 

#### Reviewing the file

Source topic: `en_EN/task/roe_comments_reg/reviewing_the_file_non-complex.dita`

- In RCM, determine if there are comments in block 18 :

- If yes, go to step 5.

- If no, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4667.dita) 

#### Reviewing the conditions to allow at Non-complex Level

Source topic: `en_EN/task/roe_comments_reg/reviewing_the_conditions_to_allow_at_no_73969f75_non-complex.dita`

- Determine if the comments can be actioned or removed from block 18 according to Comments found in block 18 of a regular ROE :

- If yes, go to step 6.

- If no, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_reg#nc_item_6) 

#### Inputs

Source topic: `en_EN/task/roe_comments_reg/inputs_non-complex.dita`

- In RCM, select Validate :

- If errors are displayed for any block, go to step 7.

- If no error is found, select Submit and go to step 10.

- In NWS, determine if an ROE Correction WI or a Claim Assessment (CA) WI exists for this ROE:

- If no, go to step 8.

- If yes, go to step 10. 

#### Correcting ROE errors

Source topic: `en_EN/task/roe_comments_reg/correcting_roe_errors_non-complex.dita`

- Determine if you can correct the ROE according to Completing an ROE Correction WI — Regular ROE:

- If no , go to step 9.

- If yes, correct the ROE and go to step 10.

- Create an ROE Correction WI with the following fields:

- Complexity: Select Level 1 .

- Language: Select English or French , based on the employer’s preferred language.

- Destination: Type the SCC as shown in the claim file in FTS.

- End user: Select Next available user .

- Serial Number: Type the serial number of the ROE.

- Issue: Select Correction .

- Complete the ROE Comments WI. 

#### Reassigning the issue to Level 1

Source topic: `en_EN/task/roe_comments_reg/reassigning_the_issue_to_level_1_non-complex.dita`

- In NWS, reassign the ROE Comments WI to Level 1 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 1 .

- Reason: Select Unable to complete .

- Details: Type “According to the procedure, comments cannot be removed — Level 1 to review.” 

#### Fraud indicators are present

Source topic: `en_EN/task/roe_comments_reg/fraud_indicators_are_present_non-complex.dita`

- In NWS, determine if any of the following WIs are on file:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4668.dita) 

- If no, go to step 2.

- If yes, go to step 19.

- Determine if any of the following are on file and directly related to the potentially fraudulent application:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1573.dita) 

- If no, go to step 3.

- If yes, go to step 6.

- In NWS, determine if a suspected fraud has previously been referred to Integrity in an AI WI that has not been completed:

- If yes, go to step 4.

- If no, go to step 5.

- Add the information related to the potentially fraudulent application to the existing Integrity AI WI as follows:

- Right-click and select Add details/Further Inquiry .

- Action: Select Additional information .

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [ CRA business number ] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the processing unit in the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories : Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue(s): Select ROE .

- Comments: Type “Fraud suspected — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [ CRA business number ] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- In FTS, determine if the initial claim has already been calculated:

- If yes, go to step 7.

- If no, go to step 10.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If yes, go to step 8.

- If no, go to step 16.

- Determine if an MA71 has already been imposed:

- If no, go to step 9.

- If yes, go to step 16.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 16.

- Determine if there is an outstanding initial registration number related to the fraudulent application:

- If yes, go to step 11.

- If no, go to step 16.

- Determine if a D71 has already been imposed:

- If no, go to step 12.

- If yes, go to step 13.

           [Important](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2918.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

- Go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2664.dita)

- In NWS, determine if the Claim action status is Finalized - Pending LREM :

- If yes, go to step 14.

- If no, go to step 15.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- Go to step 16.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1576.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the initial registration number as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 16.

- Determine if the ROE Comments WI is related to a potentially fraudulent ROE:

- If yes, go to step 17.

- If no, go to step 19.

- In RCM, determine if the ROE has been deleted:

- If no, go to step 18.

- If yes, go to step 19.

- In RCM, open the ROE and delete it as follows:

- Delete: Check the box.

- Additional information: Type “Suspicious ROE. ROE has been deleted to prevent it from being used in benefits calculation until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- In NWS, determine if there is a related ROE Comments WI:

- If yes, go to step 20.

- If no, no further action is required.

- Determine if the status of the ROE Comments WI is Assigned-Active :

- If yes, complete the WI.

- If no, no further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_1527.dita`

Note:

If the only fraud indicator is the fraud warning highlighted in red in FTS, go to step 2. 

#### Note

Source topic: `en_EN/common_notes/note_c_4667.dita`

Note:

Another officer may have removed the comments when adjudicating an RFS. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4668.dita`

- a Claim Review (CR) Integrity ERB-EI Transition WI related to the potentially fraudulent application;

- an AI WI from Integrity indicating that the claim can be established;

- a CB WI related to the potentially fraudulent application. 

#### Callout

Source topic: `en_EN/common_notes/note_c_1573.dita`

- an Integrity AI WI;

- an Integrity SROC;

- a D71 or an MA71;

- in RMDS, on the Employer profile screen, the Under investigation box is checked. 

#### Important

Source topic: `en_EN/common_notes/note_c_2918.dita`

Important:

Before imposing a D71, confirm that the file does not already include one. In such cases, if a transaction is input to impose a D71, the existing D71 is cancelled. 

#### Note

Source topic: `en_EN/common_notes/note_c_2664.dita`

Note:

If error code C072: Invalid Claim action or Action field (C072) is displayed when inputting the Renewal/Revised (M106) transaction, the D71 cannot be imposed. Go to step 13. 

#### Note

Source topic: `en_EN/common_notes/note_c_1576.dita`

Note:

If error code 836: WARNING - Flag 33 claim (Last Record of Employment Missing), claim is still polling for the last record of employment is displayed when attempting to clear the registration number, check the Override box to process the transaction. 

### Level 1

Source topic: `en_EN/task/roe_comments_reg/level_1.dita`

#### Reviewing the file for fraud indicators

Source topic: `en_EN/task/roe_comments_reg/reviewing_the_file_for_fraud_indicators_level_1.dita`

- In NWS, determine if there is documentation indicating that the file is under investigation for potential fraud:

- If no, go to step 2.

- If yes, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_reg#level1_item_7)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1527.dita)

- Review the application and ROEs to determine if known fraud indicators are present and if fraud is suspected. Refer to Fraud indicators: Identifying potentially fraudulent claims — Knowledge :

- If yes, go to step 3.

- If no, go to step 4.

- In FTS, determine if the banking information has been changed to the banking information on the potentially fraudulent application:

- If no, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_reg#level1_item_7)

- If yes, terminate the banking information by referring to Ending a direct deposit and go to Fraud indicators are present .
               [Ending a direct deposit](/en/procedure/task/ending_dd.shtml) 
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_reg#level1_item_7) 

#### Reviewing the file

Source topic: `en_EN/task/roe_comments_reg/reviewing_the_file_level_1.dita`

- In RCM, determine if there are comments in block 18 to be reviewed:

- If yes, go to step 5.

- If no, go to step 21.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4667.dita) 

#### Reviewing the conditions to allow at Level 1

Source topic: `en_EN/task/roe_comments_reg/reviewing_the_conditions_to_allow_at_level_1_level_1.dita`

- Determine if the comments in block 18 can be actioned without clarification from the employer (e.g. the employer has indicated pension information). For a non-exhaustive list of comments that can be actioned or removed from block 18 without clarification, refer to ROE: Actions required for comments found in block 18 of a regular ROE — Instructions :

- If no, fact-find with the employer and go to step 6.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If yes, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4669.dita) 

#### Fact-finding

Source topic: `en_EN/task/roe_comments_reg/fact-finding_level_1.dita`

- When the employer has returned the call, or when the ROE Comments WI has been moved to the current workload, determine if clarification has been obtained.

- If no, refer the file to Integrity and go to step 7.
               [Integrity](/en/procedure/activity/referal_integrity.shtml)

- If yes, go to step 9. 

#### Required information has not been obtained

Source topic: `en_EN/task/roe_comments_reg/required_information_has_not_been_obtained_level_1.dita`

- In RCM, change the ROE as follows:

- Correct the ROE as necessary based on the comments in block 18 .

- Additional information: Copy the comments from block 18 and type “changes made with information available on file, as unable to confirm with the employer.”

- Comments: Remove the comments.

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805): Select one of the following:

- Multiple Changes to ROE

- A Single Change to ROE

- List of the change

- Attached INS 3413

- Go to step 10. 

#### Required information has been obtained

Source topic: `en_EN/task/roe_comments_reg/required_information_has_been_obtained_level_1.dita`

- In RCM, change the ROE as follows:

- Correct the ROE based on the information determined from either the fact-finding or the Comments field.

- Comments: Remove the text.

- Additional information: Copy the comments from block 18 and:

- If the comments were removed from block 18 following clarification from the employer, type “Changes confirmed with [full name and position title]” and include details for any unchanged blocks that the employer has confirmed.

- If the comments were removed from block 18 with no clarification from the employer, type “Changes made to block(s) [#s] in accordance with the ORT.”

- In RCM, select Validate:

- If errors are displayed for any block, go to step 11.

- If no errors are displayed, select Submit and go to step 12.

- In RCM, correct the ROE to fix the validation error, and go to step 12. For information on how to correct an ROE, refer to Completing an ROE Correction WI — Regular ROE .

- In NWS, determine if the Claim action status is In Progress:

- If the claim is not In Progress , go to step 13.

- If the claim is In Progress (Manual) , go to step 15.

- If the claim is In Progress (Automation) , go to step 21.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4670.dita)

- From the audit trail in RCM and the Processing Activities information in NWS, determine if the comments in block 18 were removed before the claim calculation:

- If no, go to step 14.

- If yes, go to step 15.

- In SSO, review the claim assessment and determine if the ROE changes impact the claim calculation or entitlement (e.g. changes to the RFS, dates or monies may impact calculation or entitlement):

- If yes, go to Comments impact an established claim .
               [Comments impact an established claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/roe_comments_reg#CommentsImpactEstClm)

- If no, go to step 15.

- In RCM, determine if the original RFS in block 16 was changed from non-contentious to contentious:

[Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4671.dita) 

- If yes, go to step 16.

- If no, go to step 21.

- In FTS, determine the claim status:

- If the claim is not finalized, go to step 17.

- If the claim is established, go to step 18.

- If the claim is BPNE, go to step 21.

- In NWS, create an Adjudication Issue (ADJ) WI for the RFS as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue: Select the appropriate RFS issue.

- Details: Enter the details of the contentious issue that requires adjudication.

- Go to step 21.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2290.dita)

- Select the Subsequent Decision — Renewal/Revised (M106) transaction and impose a manual action to stop payment (MA75) by completing the following fields:

- Manual Action: Select 75 - Verification of reason for separation of employment .

- Registration number: If the registration number is prefilled, select the blank option.

- Select Update .

- Select the Registration number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Create Work Item: Check the box.

- Select Update .

- In NWS, open the newly created CR Revised WI and reassign it to yourself as follows:

- Destination: Select Myself .

- Issue: Select the appropriate option.

- Reason: Select Other .

- Details: Type “Adjudication of the RFS is required.”

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2290.dita)

- Complete the ROE Comments WI. 

#### Comments impact an established claim

Source topic: `en_EN/task/roe_comments_reg/comments_impact_an_established_claim_level_1.dita`

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 3.

- If no, go to step 4.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank, enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: This field is prefilled.

- Select Generate registration .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1571.dita)

- In NWS, assign the CR Recalculation WI to yourself.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4672.dita)

- In RCM, determine if the original RFS in block 16 was changed from non-contentious to contentious:

[Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4671.dita) 

- If yes, go to step 7.

- If no, go to step 8.

- In NWS, create a CR Revised WI for the RFS issue as follows:

- Type: Select Revised.

- Issue: Select the appropriate issue.

- Registration number: Type the recalculation registration number.

- Complexity: Select Level 1 .

- Language: Select English or French .

- Destination - SCC: Select the SCC as shown in FTS.

- Date of registration: Enter today’s date .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4673.dita)

- Reassign the CR Revised WI as follows:

- Destination: Select Myself .

- Reason: Select Related work item .

- Details: Enter the details of the contentious issue that requires adjudication.

- In NWS, complete the ROE Comments WI. 

#### Fraud indicators are present

Source topic: `en_EN/task/roe_comments_reg/fraud_indicators_are_present_level_1.dita`

- In NWS, determine if any of the following WIs are on file:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4668.dita) 

- If no, go to step 2.

- If yes, go to step 19.

- Determine if any of the following are on file and directly related to the potentially fraudulent application:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1573.dita) 

- If no, go to step 3.

- If yes, go to step 6.

- In NWS, determine if a suspected fraud has previously been referred to Integrity in an AI WI that has not been completed:

- If yes, go to step 4.

- If no, go to step 5.

- Add the information related to the potentially fraudulent application to the existing Integrity AI WI as follows:

- Right-click and select Add details/Further Inquiry .

- Action: Select Additional information .

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — L evel: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the processing unit in the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue(s): Select ROE .

- Comments: Type “Fraud suspected — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [ CRA business number ] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- In FTS, determine if the initial claim has already been calculated:

- If yes, go to step 7.

- If no, go to step 10.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If yes, go to step 8.

- If no, go to step 16.

- Determine if an MA71 has already been imposed:

- If no, go to step 9.

- If yes, go to step 16.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 16.

- Determine if there is an outstanding initial registration number related to the fraudulent application:

- If yes, go to step 11.

- If no, go to step 16.

- Determine if a D71 has already been imposed:

- If no, go to step 12.

- If yes, go to step 13.

           [Important](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2918.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

- Go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2664.dita)

- In NWS, determine if the Claim action status is Finalized - Pending LREM :

- If yes, go to step 14.

- If no, go to step 15.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- Go to step 16.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1576.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the initial registration number as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 16.

- Determine if the ROE Comments WI is related to a potentially fraudulent ROE:

- If yes, go to step 17.

- If no, go to step 19.

- In RCM, determine if the ROE has been deleted:

- If no, go to step 18.

- If yes, go to step 19.

- In RCM, open the ROE and delete it as follows:

- Delete: Check the box.

- Additional information : Type “Suspicious ROE. ROE has been deleted to prevent it from being used in benefits calculation until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- In NWS, determine if there is a related ROE Comments WI:

- If yes, go to step 20.

- If no, no further action is required.

- Determine if the status of the ROE Comments WI is Assigned-Active :

- If yes, complete the WI.

- If no, no further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_4669.dita`

Note:

If during fact-finding, the employer provides details specific to the RFS, create an SROC to document the information . Document all other changes in RCM. 

#### Note

Source topic: `en_EN/common_notes/note_c_4670.dita`

Note:

If the Claim action status on the initial claim is In Progress (Automation) and the RFS is changed to a contentious issue, the system creates the appropriate WI to ensure the new RFS is adjudicated. 

#### Example

Source topic: `en_EN/common_notes/note_c_4671.dita`

Example:

The RFS has changed from A - Shortage of Work to E - Quit based on the comments or fact-finding. 

#### Note

Source topic: `en_EN/common_notes/note_c_2290.dita`

Note:

The appropriate adjudication task indicates if the issue can be adjudicated at Level 1 or if it must be reassigned to Level 2. 

#### Note

Source topic: `en_EN/common_notes/note_c_1571.dita`

Note:

When the message Success — Registration number created is displayed in SSO, a recalculation registration number is assigned to the claim. NWS creates a CR WI and assigns it to the unassigned (UNA) workload or to the next available user. 

#### Note

Source topic: `en_EN/common_notes/note_c_4672.dita`

Note:

When you assign a recalculation registration number in SSO, a CR WI is automatically created in NWS. If you currently have the claim open in NWS, the new CR WI may not be displayed immediately. Close the claim and re-enter the SIN to see the CR WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4673.dita`

Note:

The applicable adjudication task indicates if the issue can be adjudicated at Level 1 or if it must be reassigned to Level 2. 

## Policy reference

Source topic: `en_EN/task/roe_comments_reg/policy_reference.dita`

 
