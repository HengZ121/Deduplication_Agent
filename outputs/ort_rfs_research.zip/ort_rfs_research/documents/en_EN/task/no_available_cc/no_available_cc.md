# Adjudicating otherwise available issues — Continuing claim

Source map: `en_EN/task/no_available_cc/no_available_cc.ditamap`

## Summary

Source topic: `en_EN/task/no_available_cc/summary.dita`

Summary: Clients who are entitled to sickness benefits must prove that if not for the illness or injury, they would be available for work. 

## What you need to know

Source topic: `en_EN/task/no_available_cc/what_you_need_to_know.dita`

### Temporary process is no longer in effect — Relaxed requirements

Source topic: `en_EN/task/no_available_cc/temporary_process_is_no_longer_in_effec_dc8cd340.dita`

The simplification measure for relaxed requirements ends September 25, 2021. Effective September 26, 2021, the officer follows normal procedures to adjudicate all availability issues. 

### Defining otherwise available

Source topic: `en_EN/task/no_available_cc/defining_otherwise_available.dita`

Clients’ availability is reviewed as if they are claiming regular benefits. To establish their entitlement, it is necessary to determine if clients would have been available for work if they had been capable of working.

Clients must prove that they would be otherwise available for work for each day in the period of incapacity. They cannot provide proof of capability weeks or months in advance. The determination of whether clients are otherwise available for work requires a review of the information provided to determine if they have proven their availability. The decision is made on the credibility of the information given. If the facts prove that clients would otherwise be available for work, accept the information. 

### Not otherwise available — Indicators

Source topic: `en_EN/task/no_available_cc/not_otherwise_available__indicators.dita`

If the issue is related to a contentious reason for separation (RFS), the officer does not review the client’s availability, unless the information on file suggests not otherwise available indicators. If there are indicators on file that suggest the client could not be otherwise available, the officer fact-finds with the client.

There are not otherwise available indicators in the following cases:

- voluntary leaving due to retirement

- voluntary leaving to care for a child or immediate family member

- voluntary leaving due to loss of transportation

- voluntary leaving to go back to school

- leave of absence

- dismissal for unavailability

- vacation pay during a closure period due to vacation

When clients must prove that they are otherwise available for work, the officer cannot defer adjudication if the RFS implies that the client is not otherwise available. 

### Incapacity proven but not otherwise available disentitlement (D33)

Source topic: `en_EN/task/no_available_cc/incapacity_proven_but_not_otherwise_ava_ea535296.dita`

When clients do not prove that they are otherwise available for work for part or the entire period of incapacity, a 33 - incapacity proven but not otherwise available disentitlement (D33) must be imposed for the period of time clients are not otherwise available for work.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3874.dita) 

### Incapacity in the maternity window

Source topic: `en_EN/task/no_available_cc/incapacity_in_the_maternity_window.dita`

When clients do not prove that they are otherwise available for work for part or the entire period of incapacity, a D33 must be imposed for the period of time clients are not otherwise available for work.

- the week before the expected date of birth (DOB);

- the week before the actual DOB (if it is on file).

However, if any part of the client’s incapacity falls in the period of prearranged maternity leave, she is not considered otherwise available for work during the entire period of the prearranged maternity leave , and is therefore not entitled to sickness benefits during that period. She is still entitled to maternity benefits during the period of prearranged maternity leave.

When a client is considered otherwise available during the maternity window, an external maternity start week is required to prevent the payment of maternity benefits while the client is entitled to benefits other than maternity.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3875.dita) 

If the client specifically requests sickness benefits for the week of birth, the Level 1 officer can allow the payment of sickness benefits in that week if the actual DOB was the Saturday of that week. If the DOB is any other day of the week, or if the client is requesting sickness benefits beyond the week of birth, the Level 1 officer refers the decision to Level 2.

**Minor attached client**

Sickness benefits can be paid for the 14-day period following the DOB when a minor attached client is receiving regular benefits in the maternity window. A medical certificate is not required to allow this 14-day period, but the client is still required to prove that she is otherwise available for work on each day she requests sickness benefits. Only Level 2 officers can make these decisions.

**Defining minor attached clients — Common entrance requirement (from w/c 2310 to w/c 2361)**

A temporary Budget 2021 measure applies to claims for regular and special benefits, with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure.

**Actual date of birth (DOB) reported**

When the client provides an actual DOB, it is used to determine the length of the maternity window and the start of the parental window (PW). Inputs may be required to ensure that the maternity window and PW are accurate. If a client was receiving sickness benefits before her maternity benefits and she reports an actual DOB, the officer reviews the client’s availability.

If the client provides an actual DOB on an established claim, the officer refers to Actual date of birth provided on an established claim for more information.
       [Actual date of birth provided on an established claim](/en/procedure/task/actual_dob_ec.shtml) 

### Incapacity in the parental window (PW), compassionate care window (CCW) or family caregiver window (FCW)

Source topic: `en_EN/task/no_available_cc/incapacity_in_the_parental_window_pw_co_e46186a2.dita`

Clients who request sickness benefits during the PW, CCW or FCW are not required to prove they would be otherwise available for work, as long as they remain entitled to those benefits. When the sickness period extends beyond the window established for those benefits, or they have exhausted entitlement to those benefits, clients must prove that they are otherwise available to work during that period. They must also provide a medical certificate indicating the start date of their incapacity.

Clients who are not entitled to parental benefits, CCB, or family caregiver benefits must prove that they are available for work to receive regular benefits. If a client is disentitled from regular benefits due to availability and then requests sickness benefits, the client is considered not otherwise available for work and an officer imposes a disentitlement during the period of sickness unless the client proves that the situation has changed since the original decision.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3876.dita) 

### Information reported after claimant’s reports have been processed

Source topic: `en_EN/task/no_available_cc/information_reported_after_claimants_re_82afb561.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3874.dita`

Note:

If a client is entitled to other special benefits but is considered not otherwise available, the client’s entitlement to those other benefits should be considered. The officer does not impose a D33 for those weeks if the client is entitled to and agrees to receive the other benefit type (BT). 

### Example

Source topic: `en_EN/common_notes/note_c_3875.dita`

Example:

The client planned and made arrangements with her employer to start her maternity leave June 3, 2019. The client becomes ill in March 2019, and her doctor recommends that she take sick leave until the delivery date. The client is not due until July 1, 2019. She is not otherwise available as of June 3 because she already made arrangements to be on maternity leave. Therefore, she cannot receive sickness benefits between June 2 and June 30, even though her doctor recommended that she take sick leave during this period. She could, however, receive maternity benefits. 

### Example

Source topic: `en_EN/common_notes/note_c_3876.dita`

Example:

The client applied for parental benefits and was not entitled. The client subsequently applied for regular benefits. The client has to prove that he is available for work while receiving regular benefits. If the client is deemed not available due to caring for the child and the client becomes sick, the client is not considered otherwise available during the period of sickness. The client would still be caring for the child regardless of the benefits requested and therefore, not available for work. 

## Regional considerations

Source topic: `en_EN/task/no_available_cc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/no_available_cc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/no_available_cc/in_nws.dita`

- Are there any documents related to the issue? 

### In FTS:

Source topic: `en_EN/task/no_available_cc/in_fts.dita`

- Have claimant’s reports been processed for the period in question?

- If yes, when was the original statement made?

- Is the client requesting sickness benefits in the maternity window?

- Is the client requesting sickness benefits during the PW, CCW or FCW?

- Is there a registration number assigned for this issue? 

### In Imaging:

Source topic: `en_EN/task/no_available_cc/in_imaging.dita`

- Are there documents related to the issue? 

## Step by step

Source topic: `en_EN/task/no_available_cc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/no_available_cc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/no_available_cc/reviewing_the_file_level_1.dita`

- Determine if adjudication can be deferred by consulting the Deferring adjudication procedure.

- If the client is correcting previously provided information or providing previously omitted information, determine if the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue should be referred to Integrity by consulting Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if the file contains the information required to adjudicate:

- If additional details are needed, go to step 4.

- If additional details are not needed, go to step 7. 

#### Fact-finding

Source topic: `en_EN/task/no_available_cc/fact-finding_level_1.dita`

- Fact-find with the client or the employer. Refer to the Fact-Finding and Documentation Policy if needed.

- Determine if the client or the employer was reached during fact-finding or if the client responded to the N-10-00-00 ACS letter:

- If yes, go to step 6.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#Reassignl1)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Otherwise available — spoke with [client or employer].”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/no_available_cc/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Based on the BT, do one of the following:

- If the client is requesting sickness benefits before or during the maternity window, go to step 8.

- If the client is requesting sickness benefits during the PW, CCW or FCW, go to step 12.

- For all other requests for sickness benefits, go to step 13.

- Determine if all of the conditions are met to allow the otherwise available issue at Level 1:

- The client is requesting sickness benefits before the week of the actual DOB.

- The client stopped working due to illness, or was receiving regular or sickness benefits before the start of the maternity window.

- The client’s maternity leave at her place of employment was not scheduled for the period she is requesting sickness benefits for.

- The client would have been available for work if not for the illness, injury or quarantine.

- If any of the conditions are not met, go to step 9.

- If all of the conditions are met, go to Otherwise available .
                   [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#OWAL1)

- Determine if the only condition that is not met is the following:

- The client is requesting sickness benefits before the week of the actual DOB.

- If yes, go to step 10.

- If no, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#Reassignl1)

- Determine if the request is only for the week of the actual DOB:

- If yes, go to step 11.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#Reassignl1)

- Determine if the DOB is on a Saturday:

- If yes, go to Otherwise available .
               [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#OWAL1)

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#Reassignl1)

- Determine if all of the conditions are met to allow the otherwise available issue at Level 1:

- The client received or was eligible for parental benefits, CCB or family caregiver benefits before becoming incapacitated, injured or quarantined.

- The client is eligible for parental benefits, CCB or family caregiver benefits up to or beyond the recovery date.

- The client submits a medical certificate for the period of incapacity that indicates the incapacity start date and the expected recovery date.

- If all of the conditions are met, go to Otherwise available .
                   [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#OWAL1)

- If any of the conditions are not met, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#Reassignl1)

- Determine if the client would have been employed or entitled to regular benefits if not for the sickness or injury:

- If the client would have been employed or entitled to regular benefits if not for the sickness or injury, go to Otherwise available .
               [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#OWAL1)

- If the client would not have been employed or entitled to regular benefits if not for the sickness or injury, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#Reassignl1) 

#### Otherwise available

Source topic: `en_EN/task/no_available_cc/otherwise_available_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Otherwise available.”

- Details: Type “The conditions to allow sickness benefits at Level 1 have been met ( National Policy on Levels of Decision ).” Include the end date, if applicable.
               [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- Select Save .

- Determine if the previous task was a conversion:

- If no, go to step 3.

- If yes, return to the conversion task to complete the required inputs.

- Determine if the decision concerns a client requesting benefits during the maternity window:

- If yes, go to step 4.

- If no, go to step 6.

- In FTS, determine if an outstanding registration number related to the otherwise available issue is on file:

- If yes, go to step 5.

- If no , select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Go to step 5.

- Refer to the Maternity/Parental input guide for the required inputs.

- Complete the WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/no_available_cc/reassigning_the_issue_to_level_2_level_1.dita`

- Determine if the previous task was a conversion:

- If yes, go to step 2.

- If no, go to step 3.

- In NWS, determine if there is a separate WI related to the otherwise available issue:

- If yes, reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Not otherwise available — not within Level 1 authority.”

- Return to the initial task.

- If no, return to the previous task and complete the required inputs before assigning the Claim Review (CR) WI to Level 2.

- In FTS, determine if a 1 - General suspension of benefits (stop payment) manual action (MA01) is imposed:

- If an MA01 is imposed, go to step 4.

- If an MA01 is not imposed, select the Renewal/Revised (M106) transaction and input the MA01 as follows:

- Registration Number: Leave the field blank. If a number is showing, remove it.

- Manual action: Select 01- General suspension of benefits (stop payment) .

- Select Update .

- Reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Not otherwise available — not within Level 1 authority.” 

### Level 2

Source topic: `en_EN/task/no_available_cc/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/no_available_cc/reviewing_the_file_level_2.dita`

- Determine if adjudication can be deferred by consulting the Deferring adjudication procedure.

- If the client is correcting previously provided information or providing previously omitted information, determine if the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue should be referred to Integrity by consulting Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if there is enough information to make a decision:

- If additional details are needed, go to step 4.

- If additional details are not needed, go to step 7. 

#### Fact-finding

Source topic: `en_EN/task/no_available_cc/fact-finding_level_2.dita`

- Complete fact-finding . Refer to Digest 11 — Sickness Benefits to determine the questions to ask clients and employers (if applicable).

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 6.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Client not contacted .
               [Client not contacted](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#client_not_contacted_l2)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Otherwise available — spoke with [client or employer].”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save . 

#### Adjudicating otherwise available issues

Source topic: `en_EN/task/no_available_cc/adjudicating_otherwise_available_issues_level_2.dita`

- Determine if there is adequate proof that the client would be otherwise available for work if not for the incapacity based on a review of all the information provided on file and in accordance with the Act, Regulations, jurisprudence and Digest 11.3.0 — Second entitlement condition: to be otherwise available for work .

- Determine if the client is otherwise available:

- If yes, go to step 9.

- If no, go to step 10.

- Determine if the decision concerns a client requesting benefits during the maternity window:

- If yes, go to Otherwise available — External maternity start date required .
               [Otherwise available — External maternity start date required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#oa_emdr)

- If no, go to Otherwise available .
               [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#otherwise_avail)

- Determine if the decision concerns a client requesting benefits during the maternity window:

- If yes, go to Not otherwise available — In maternity window .
               [Not otherwise available — In maternity window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#oa_imw)

- If no, go to Not otherwise available .
               [Not otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available_cc#not_otherwise_avail) 

#### Otherwise available — External maternity start date required

Source topic: `en_EN/task/no_available_cc/otherwise_available__external_maternity_05f172c9_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Otherwise available from w/c [XXXX-X] to [XXXX-X].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if there is an outstanding WI for a conversion on the claim:

- If no, go to step 3.

- If yes, go to step 7.

- In FTS, if there is no registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Claim source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- Determine if an MA01 is imposed for the not otherwise available issue:

- If yes, go to step 5.

- If no, go to step 6.

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA01 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In FTS, select the Additional Data (M107) transaction and input the external maternity start date as follows:

- Registration number: Select the appropriate registration number.

- External Maternity — Start week: Enter the maternity benefits start date.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- Complete the WI for the otherwise available issue. 

#### Otherwise available

Source topic: `en_EN/task/no_available_cc/otherwise_available_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Otherwise available.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if an MA01 is imposed and if there is a registration number for the not otherwise available issue:

- If an MA01 is imposed but there is no registration number, go to step 3.

- If an MA01 is imposed and there is a registration number, go to step 4.

- If an MA01 is not imposed but there is a revised registration number, go to step 5.

- If none of the above applies, go to step 6.

- In FTS, if there is no registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA01 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Click Update .

- Go to step 6.

- In FTS, select the Renewal/Revised (M106) transaction and clear the registration number as follows:

- Claim allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- Complete the WI for the otherwise available issue. 

#### Not otherwise available — In maternity window

Source topic: `en_EN/task/no_available_cc/not_otherwise_available__in_maternity_window_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Not otherwise available from w/c [XXXX-X] to [XXXX-X].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .

- If fact-finding by telephone was not attempted, click Draft and go to step 2.

- If the client was reached by telephone during fact-finding, click Draft and go to step 2.

- If the client was not reached by telephone during fact-finding, click Save and go to step 3.

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Verbally communicate the decision to the client .

- Determine if there is an outstanding WI for a conversion on the claim:

- If no, go to step 4.

- If yes, go to step 12.

- In FTS, if there is no registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- Determine if an MA01 is imposed for the not otherwise available issue:

- If yes, go to step 6.

- If no, go to step 7.

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA01 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Click Update .

- Determine if an external maternity start week is required:

- If yes, go to step 8.

- If no, go to step 9.

- In FTS, select the Additional Data (M107) transaction and input the external maternity start date as follows:

- Registration number: Select the appropriate registration number.

- External Maternity — Start week: Enter the maternity benefits start date.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- Determine if a D33 is required because the client is not otherwise available outside the maternity window:

- If yes, go to step 10.

- If no, go to step 11.

- Select the Disqualifications/Disentitlements (M161) transaction and impose the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select: 33 - Incapacity proven but not otherwise available .

- Start date: Select the disentitlement start date.

- End date: Enter the appropriate disentitlement end date as follows:

- If the date to which the client is not otherwise available is known, impose the applicable disentitlement end date.

- If the date to which the client is not otherwise available is not known, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement ;

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits approved (3046)

- Special benefits denied (3065)

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066): Select D-33 - Not otherwise available .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) and select the appropriate option.

- Text - Reasons why not otherwise available (1630): Type the details.

- Select If sickness after maternity (4418) .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Go to step 14.

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits approved (3046) and select appropriate options based on type of special benefits being paid on the claim.

- Special benefits denied (3065) .

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D-33 - Not otherwise available .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) and select the appropriate option.

- Text - Reasons why not otherwise available (1630): Type the details.

- Select If sickness after maternity (4418) .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note and type “Send saved N-00-00-00 letter.” Indicate any additional information that the Level 1 officer must add.

- Complete the WI for the otherwise available issue. 

#### Not otherwise available

Source topic: `en_EN/task/no_available_cc/not_otherwise_available_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Not otherwise available from w/c [XXXX-X] to [XXXX-X].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .

- If fact-finding by telephone was not attempted, click Draft and go to step 2.

- If the client was reached by telephone during fact-finding, click Draft and go to step 2.

- If the client was not reached by telephone during fact-finding, click Save and go to step 3.

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Verbally communicate the decision to the client .

- In FTS, determine if there is a registration number:

- If there is a registration number, go to step 4.

- If there is no registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- In FTS, determine if there is an MA01 imposed for the not otherwise available issue on the file:

- If there is an MA01, go to step 5.

- If there is no MA01, go to step 6.

- Select the Renewal/Revised (M106) transaction to remove the MA01 and impose the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 33 - Incapacity proven but not otherwise available .

- Start date: Select the disentitlement start date.

- End date: Enter the appropriate disentitlement end date as follows:

- If the date to which the client is not otherwise available is known, impose the corresponding disentitlement end date.

- If the date to which the client is not otherwise available is not known, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- Go to step 7.

- Select the Disqualifications/Disentitlements (M161) transaction and impose the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 33 - Incapacity proven but not otherwise available .

- Start date: Select the disentitlement start date.

- End date: Enter the appropriate disentitlement end date as follows:

- If the date to which the client is not otherwise available is known, impose the corresponding disentitlement end date.

- If the date to which the client is not otherwise available is not known, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065) .

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D-33 - Not otherwise available .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) and select the appropriate option.

- Text - Reasons why not otherwise available (1630): Type the details.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Complete the WI for the not otherwise available issue. 

#### Client not contacted

Source topic: `en_EN/task/no_available_cc/client_not_contacted_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Not otherwise available from w/c [XXXX] to [XXXX].”

- Details: Document the decision and rationale according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- In FTS, determine if there is a registration number on file:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Click Update .

- Based on the BT, determine if the client is requesting sickness benefits before or during the maternity window,

- If no, go to step 4.

- If yes, go to step 8.

- Determine if an MA01 is imposed for the otherwise available issue:

- If yes, go to step 5.

- If no, go to step 6.

- Select the Renewal/Revised (M106) transaction, remove the MA01 and impose the D33 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 33 - Incapacity proven but not otherwise available .

- Start date : Select the disentitlement start date.

- End date: Click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- Go to step 7.

- Select the Disqualifications/Disentitlements (M161) transaction and impose the D33 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select: 33 - Incapacity proven but not otherwise available .

- Start date: Select the disentitlement start date.

- End date: Click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- If the client is entitled to receive other special benefits on the claim, select Special benefits approved (3046) and select the appropriate options.

- Special benefits denied (3065) .

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D-33 - not otherwise available .

- Select Indefinite disentitlement start date (1270) .

- Text - Reasons why not otherwise available (1630): Type the details .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Go to step 16.

- Determine if there is an outstanding WI for a conversion on the claim:

- If no, go to step 9.

- If yes, go to step 14.

- Determine if an MA01 is imposed for the not otherwise available issue:

- If yes, go to step 10.

- If no, go to step 11.

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA01 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Click Update .

- Determine if an external maternity start week is required:

- If yes, go to step 12.

- If no, go to step 13.

- In FTS, select the Additional Data (M107) transaction and input the external maternity start date as follows:

- Registration number: Select the appropriate registration number.

- External Maternity — Start week: Enter the maternity benefits start date.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits approved (3046)

- Special benefits denied (3065)

- Sickness benefits denied D2/D16/D22/D33/Free text (3066): Select D-33 - Not otherwise available .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) and select the appropriate option.

- Text - Reasons why not otherwise available (1630): Type the details.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Go to step 16.

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits approved (3046) and select appropriate options based on type of special benefits being paid on the claim .

- Special benefits denied (3065) .

- Sickness benefits denied D2/D16/D22/D33/Free text (3066) .

- Select D-33 - Not otherwise available .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) and select the appropriate option.

- Text - Reasons why not otherwise available (1630): Type the details.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note and type “Send saved N-00-00-00 letter.” Indicate any additional information that the Level 1 officer must add.”

- In NWS, complete the WI for the otherwise available issue or return to the previous task. 

## Policy reference

Source topic: `en_EN/task/no_available_cc/policy_reference.dita`

- Digest 10 — Availability
         [Digest 10 — Availability](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/table-of-contents.html)

- Digest 11 — Sickness Benefits
         [Digest 11 — Sickness Benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-11/table-of-contents.html)

- Digest 12 — Maternity Benefits
         [Digest 12 — Maternity Benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-12/table-of-contents.html)

- Digest 13 — Parental Benefits
         [Digest 13 — Parental Benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-13/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://cms-sgc.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- Payment of Sickness Benefits for the Week of Expected Date of Confinement or Actual Date of Confinement — BE 2020-01
         [Payment of Sickness Benefits for the Week of Expected Date of Confinement or Actual Date of Confinement — BE 2020-01](https://cms-sgc.esdc-edsc.canada.ca/en/policy/bememo/be2020-01.shtml) 
