# Adjudicating availability — Gradual return to work

Source map: `en_EN/task/availability_adj_rw/availability_adj_rw.ditamap`

## Summary

Source topic: `en_EN/task/availability_adj_rw/summary.dita`

Summary: A client reports gradually returning to work following a period of illness. 

## What you need to know

Source topic: `en_EN/task/availability_adj_rw/what_you_need_to_know.dita`

### Temporary process is no longer in effect — Relaxed requirements

Source topic: `en_EN/task/availability_adj_rw/temporary_process_is_no_longer_in_effec_dc8cd340.dita`

The simplification measure for relaxed requirements ends September 25, 2021. Effective September 26, 2021, the officer follows normal procedures to adjudicate all availability issues. 

### Gradual return to work (RTW)

Source topic: `en_EN/task/availability_adj_rw/gradual_return_to_work_rtw.dita`

A doctor can authorize a client to gradually return to work following a period of illness. The client must provide a medical certificate proving a doctor or other medical practitioner’s authorization to return to work and stating any limitations for the gradual RTW. The client’s medical certificate must include details such as the duration of the gradual RTW, the days or hours the client can work and the client’s abilities or lack thereof. 

### Levels of decision — Level 1

Source topic: `en_EN/task/availability_adj_rw/levels_of_decision__level_1.dita`

A Level 1 officer can render the decision to continue paying sickness benefits when:

- the client recovered to the extent of being capable of working, but not full-time due to the illness or injury; and

- the client has submitted the necessary medical certificate confirming the gradual return to work (RTW); and

- the client is entitled to sickness benefits for the period during which the client is unable to work due to illness, injury or quarantine.

The Level 1 officer can also adjudicate a gradual RTW if the client submits an acceptable medical certificate and meets the conditions to remove the 16 - No medical certificate submitted disentitlement (D16) that was imposed by a processing or Integrity officer. For more information, the officer refers to Reviewing a medical certificate submitted by a client with a D16 disentitlement .
       [Reviewing a medical certificate submitted by a client with a D16 disentitlement](/en/procedure/task/review_d16_med_cert.shtml)

When the Level 1 officer cannot adjudicate the issue, the officer documents the facts and refers the issue to Level 2 for adjudication. 

### Levels of decision — Level 2

Source topic: `en_EN/task/availability_adj_rw/levels_of_decision__level_2.dita`

When the issue cannot be adjudicated at Level 1, the Level 2 officer assesses the client’s availability and ability to work. When sickness benefits are exhausted and the client requests regular benefits, the Level 2 officer can input a partial disentitlement if the situation lasts for 1 or 2 weeks. If the situation lasts longer than 2 weeks, the Level 2 officer creates a Renewal/Revised (M106) transaction with the partial disentitlement information, then sends the information to IPOC in an Operational Centre Memo (MM06) transaction to impose the partial disentitlement.

A client who has not completely recovered but has been authorized by a doctor to gradually return to work may receive sickness or regular benefits depending on how many weeks of entitlement remain.

The Level 2 officer must adjudicate any contentious reason for separation (RFS) before determining a client’s entitlement to regular benefits during a gradual RTW period. The officer can refer to Voluntary leaving or Dismissal . If the RFS results in an indefinite disqualification, no regular benefits are payable during the gradual RTW period.
       [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml) 
       [Dismissal](/en/procedure/activity/dismissal.shtml) 

### Guiding questions

Source topic: `en_EN/task/availability_adj_rw/guiding_questions.dita`

To determine if a client is entitled to benefits during a gradual RTW, the officer must consider the following:

- Is the client able to work full or partial days?

- How many hours per day and how many days per week is the client able to work?

- When does the client expect to be fully recovered?

- Will the client be gradually increasing the hours per day or days per week worked during the gradual RTW period? 

### Process chart for a gradual return to work (RTW) and limited capacity

Source topic: `en_EN/task/availability_adj_rw/process_chart_for_a_gradual_return_to_w_e9fb9acc.dita`

### Defining major attached clients

Source topic: `en_EN/task/availability_adj_rw/defining_major_attached_clients.dita`

Major attached: Clients are major attached when they have accumulated at least 600 hours of insurable employment during their qualifying period (QP). The claim type (CT) is 3 for sickness benefits. 

### Defining minor attached clients

Source topic: `en_EN/task/availability_adj_rw/defining_minor_attached_clients.dita`

Minor attached: Clients are minor attached when they have accumulated between 420 and 599 hours of insurable employment during their QP. Minor attached clients have the required number of hours to establish a claim for regular benefits but they do not have the required 600 hours for sickness benefits. Minor attached clients are entitled to sickness benefits only if they stopped working for a reason other than illness. The CT is 9 for sickness benefits in these cases.

**Defining minor and major attached clients — Common entrance requirement (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national common entrance requirement (CER) of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Sickness benefits payable

Source topic: `en_EN/task/availability_adj_rw/sickness_benefits_payable.dita`

A major attached client with weeks of sickness benefits remaining continues to claim sickness benefits during the gradual RTW for a maximum of 26 weeks of sickness benefits per BP for a BPC in w/c 2374 or later and up to 15 weeks of sickness benefits per BP for a BPC in w/c 2373 or earlier.

A minor attached client who stopped working for reasons other than illness continues to claim sickness benefits during the gradual RTW for a maximum of 26 weeks of sickness benefits per BP for a BPC in w/c 2374 or later and up to 15 weeks of sickness benefits per BP for a BPC in w/c 2373 or earlier.

For claims with a BPC between w/c 2310 and w/c 2361, refer to Defining minor and major attached clients — Common entrance requirement (from w/c 2310 to w/c 2361) .
       [Defining minor and major attached clients — Common entrance requirement (from w/c 2310 to w/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#_Defining_minor_and)

To establish an initial claim that has an acceptable medical certificate on file indicating a gradual RTW, the officer enters the gradual RTW end date found on the medical certificate as the recovery date.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2140.dita) 

### Regular benefits payable

Source topic: `en_EN/task/availability_adj_rw/regular_benefits_payable.dita`

A major attached client who has exhausted the maximum weeks of sickness benefits payable but is gradually returning to work may receive regular benefits for any remaining weeks of entitlement. Clients are entitled to benefits only for the number of days each week they are capable of working.

A minor attached client who stops work for reasons other than illness and who has exhausted the maximum weeks of sickness benefits payable but is gradually returning to work receives regular benefits for any remaining weeks of entitlement. Clients are entitled to regular benefits only for the number of days each week they are capable of working.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2141.dita) 

A minor attached client who stops work due to illness is not entitled to sickness benefits. The officer imposes a 2 - Minor attached, reason for separation illness disentitlement (D2) on the claim for sickness benefits. However, this client is entitled to regular benefits during the gradual RTW period. Clients are entitled to regular benefits only for the number of days each week they are capable of working.

For claims with a BPC between w/c 2310 and w/c 2361, refer to Defining minor and major attached clients — Common entrance requirement (from w/c 2310 to w/c 2361) .
       [Defining minor and major attached clients — Common entrance requirement (from w/c 2310 to w/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#_Defining_minor_and)

Level 2 officers can impose the partial disentitlement when it is for 1 or 2 weeks only. If the gradual RTW lasts longer than 2 weeks, the Level 2 officer sends the information to IPOC on an MM06 to impose an 11 - Part-week disentitlement on a continuing basis manual action (MA11). 

### Available for partial working days only

Source topic: `en_EN/task/availability_adj_rw/available_for_partial_working_days_only.dita`

A client may only be capable of working partial days. For example, the client may be limited to working only 4 hours each day due to illness. A major-attached or minor-attached client with an RFS other than illness is entitled to sickness benefits. Once all sickness benefits are paid, regular benefits are not payable if the client is still limited to partial working days. The officer imposes a 3 - Not available disentitlement (D3). 

### Gradual return to work (RTW) and shortage of work

Source topic: `en_EN/task/availability_adj_rw/gradual_return_to_work_rtw_and_shortage_of_work.dita`

Clients who are requesting regular benefits and who are approved by a doctor to gradually return to work may not be able to work due to a shortage of work. In this case, the officer must examine labour market information to assess employment opportunities. If there are no job opportunities available within the client’s restrictions, the officer imposes an indefinite D3. 

### Exceptions

Source topic: `en_EN/task/availability_adj_rw/exceptions.dita`

A client’s insurable employment may be earned while working partial work weeks due to a permanent, partial incapacity for work. In this case, the officer does not impose a disentitlement if the client is seeking work or working within that restriction. The officer can refer to Digest 10.10.3 — Application .
       [Digest 10.10.3 — Application](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/health-physical-capabilities.html#a10_10_3)

If a doctor approves a client’s gradual RTW but the client wants to work fewer days or hours than approved by the doctor, the officer imposes a disentitlement for full weeks until the restriction is removed. For example, a client is approved to work for 4 days each week but wants to work only 3 days each week. The officer imposes a disentitlement for full weeks until the restriction is removed.

If a doctor approves a client’s RTW part-time and this situation is indefinite or permanent, the above principles do not apply. The officer assesses the client’s situation to determine if the employment or hours of work are no longer suitable, as defined in the legislation. When this situation arises, the officer can refer to Adjudicating availability — Preference or restriction and reasonable period .
       [Adjudicating availability — Preference or restriction and reasonable period](/en/procedure/task/availability_adj_res.shtml) 

### Rejected claimant’s reports

Source topic: `en_EN/task/availability_adj_rw/rejected_claimants_reports.dita`

If a client reports returning to work part-time before the recovery week shown in the system and the CT is 3 or 9 , the claimant’s report is rejected. The report is returned to the Service Canada Centre (SCC) for clarification from the client.

The last full week of sickness benefits requested must be paid before the officer can convert the claim from sickness to regular benefits. If claimant’s reports have not yet been processed for the period of sickness benefits, the officer must process them before inputting the conversion the following day. 

### Example

Source topic: `en_EN/common_notes/note_c_2140.dita`

Example:

After receiving 10 weeks of sickness benefits, a client partially recovers and gradually returns to work 3 days per week until completely recovered. Sickness benefits are still payable since the maximum number of weeks payable has not been reached. Even if they are incomplete sickness weeks (e.g. sick 2 days per week), the client continues to claim sickness benefits until reaching the maximum weeks of sickness benefits payable. 

### Example

Source topic: `en_EN/common_notes/note_c_2141.dita`

Example:

After receiving the maximum weeks of sickness benefits payable, a client who has partially recovered, gradually returns to work 3 days per week until completely recovered. No further sickness benefits are payable. Regular benefits can be paid, but a disentitlement is imposed for the 2 days each week the client is unable to work. 

## Regional considerations

Source topic: `en_EN/task/availability_adj_rw/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/availability_adj_rw/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/availability_adj_rw/in_nws.dita`

- What are the specific details of the Action Item (AI), Call Back (CB), Reminder (REM) or Claim Review (CR) WI?

- Is there an SROC or other WIs relating to the gradual RTW?

- Is there a client Note ?

- Is there a contentious RFS that requires adjudication?

- Has a medical certificate or other information relating to the gradual RTW been uploaded?

- Are there documents related to the issue? 

### In FTS:

Source topic: `en_EN/task/availability_adj_rw/in_fts.dita`

- Is there an outstanding registration number?

- Are there remaining weeks of sickness benefits?

- Are there remaining weeks of regular benefits?

- Have the claimant’s reports up to the last full week of sickness benefits been processed?

- What is the recovery date?

- Is there an outstanding D2?

- Is there a D16 on file?

- Is a 1 - General suspension of benefit (stop payment) manual action (MA01) imposed? 

### In Imaging:

Source topic: `en_EN/task/availability_adj_rw/in_imaging.dita`

- Is there a medical certificate or other information relating to the gradual RTW? 

## Step by step

Source topic: `en_EN/task/availability_adj_rw/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/availability_adj_rw/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/availability_adj_rw/reviewing_the_file_level_1.dita`

- Determine if there is at least one week of sickness benefits to be paid:

- If yes, go to step 2.

- If all weeks of sickness benefits have been paid or if a D2 is imposed, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#ReassignLevel2)

- Determine if additional fact-finding is required to adjudicate the issue:

- If yes, go to step 3.

- If no, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2142.dita) 

#### Fact-finding

Source topic: `en_EN/task/availability_adj_rw/fact-finding_level_1.dita`

- Fact-find with the client. Go to Guiding questions to determine which questions to ask the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 5.

- If the client could not be contacted, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#ReassignLevel2)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Availability .

- Comments: Type “Gradual return to work.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- Select Save . 

#### Reviewing the medical certificate

Source topic: `en_EN/task/availability_adj_rw/reviewing_the_medical_certificate_level_1.dita`

- Determine if the medical certificate is on file:

- If the medical certificate is not on file, go to step 7.

- If the medical certificate is on file, go to step 9.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Medical certificate required.”

- Bring forward date: Select the date the client was contacted + 10 business days.

- At the bring forward date, determine if the medical certificate is on file:

- If the medical certificate is on file, go to step 9.

- If the medical certificate is not on file, go to Medical certificate not submitted — 16 - No medical certificate submitted disentitlement (D16) .
               [Medical certificate not submitted — 16 - No medical certificate submitted disentitlement (D16)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#D16Level1)

- Determine if the medical certificate authorizes the gradual RTW:

- If yes, go to Sickness benefits payable .
               [Sickness benefits payable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#sbp)

- If no, but the medical certificate shows proof of incapacity, go to Reviewing a medical certificate submitted by a client receiving sickness benefits .
               [Reviewing a medical certificate submitted by a client receiving sickness benefits](/en/procedure/task/reviewing_mc_crsb.shtml)

- If no, but the medical certificate shows that the client is fully capable of working, go to Converting a claim from sickness to regular benefits .
               [Converting a claim from sickness to regular benefits](/en/procedure/task/conv_sickreg.shtml) 

#### Sickness benefits payable

Source topic: `en_EN/task/availability_adj_rw/sickness_benefits_payable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Gradual return to work — sickness benefits payable.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- In FTS, determine if there is an outstanding registration number for the gradual RTW issue and if the recovery week must be entered or extended:

- If there is no outstanding registration number and the recovery week must be entered or extended, go to step 12.

- If there is an outstanding registration number and the recovery week must be entered or extended, go to step 13.

- If there is an outstanding registration number but the recovery week does not need to be entered or extended, go to step 14.

- If none of the above applies, go to step 14.

- Select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and extend the recovery week as follows:

- Registration number: Select the appropriate registration number.

- Initial claim: Select the Special benefits (M106) link and enter the following information on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the gradual RTW end date.

- Select Save .

- Revival: Select the appropriate option:

- If the claimant’s report corresponding to the prior recovery week has been processed, select the Sunday of the next week to be processed.

- If the claimant’s report corresponding to the prior recovery week has not been processed, leave the field blank.

- Select the Special benefits (M106) link and input the following on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2143.dita)

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Go to step 15.

- Determine the claim status (CS):

- If it is an initial claim, go to step 15.

- If it is a renewal or continuing claim, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Registration number: Select the appropriate registration number.

- Claim allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Determine if the gradual RTW period exceeds the period for which sickness benefits are payable:

- If no, go to step 16.

- If yes, but there are 3 weeks or less of sickness benefits payable, go to step 17.

- If yes, but there are 4 or more weeks of sickness benefits payable, go to step 18.

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits approved (3046) .

- Sickness benefits approved (3047) .

- Sickness approved - Client must provide medical certificate.

- Start date Sickness benefits - Sunday’s date (1252) .

- End date Sickness benefits - Saturday’s date (1254) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- Go to step 21.

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits approved (3046) .

- Sickness approved for maximum number of weeks but not always payable (3050): Select Sickness approved for maximum number of weeks but some weeks already paid .

- Start date Sickness benefits - Sunday’s date (1252) .

- Number of sickness weeks already paid (1388) .

- Sickness maximum of 15 or 26 weeks (12545) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- Go to step 19.

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits approved (3046) .

- Sickness benefits approved (3047) .

- Sickness approved - Client must provide medical certificate .

- Start date Sickness benefits - Sunday’s date (1252) .

- End date Sickness benefits - Saturday’s date (1254) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- This letter replaces or Footnote (2365): Select Footnote .

- Text - Footnote (11745): Type “If you want to request regular benefits following your last payment of sickness benefits, please contact the Employment Insurance Call Centre at 1-800-206-7218.”

- Go to step 21.

- Determine if there are still weeks of regular benefits to be paid:

- If yes, go to step 20.

- If no , go to step 21.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 2 .

- Reason: Select Other .

- Comments: Type “Gradual RTW exceeds sickness period.”

- Due Date: Select the Monday after the last week of sickness benefits is payable.

- Language: Select the appropriate option.

- Benefit type: Select Sickness .

- Details: Type “The client is receiving the remainder of sickness benefits during a gradual RTW. Once the sickness benefits are exhausted, further adjudication is required.”

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next Available User .

- Select Save .

- In NWS, complete the WI. 

#### No medical certificate submitted disentitlement (D16) — Imposing

Source topic: `en_EN/task/availability_adj_rw/no_medical_certificate_submitted_disent_27108b2b_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Gradual return to work — medical certificate not provided — (D16) imposed from [XXXX-X].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- In FTS, determine if there is an outstanding registration number for the gradual RTW issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and remove the MA01 and impose the D16 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits (stop payment) , if necessary.

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 16 - No medical certificate submitted .

- Start: Enter the start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Go to step 4.

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Text - Free Text (1612): Type the appropriate option:

- “We are unable to pay you any benefits as of [date]. You have not provided a medical certificate for the period of your gradual return to work. You must provide a medical certificate that indicates the period of your gradual return to work from start to end and the days per week and hours per day that you can work during this period.”

- “We are unable to pay you any benefits as of [date]. The medical certificate you provided does not indicate the required information to pay you benefits while you are gradually returning to work. You must provide a medical certificate that indicates the period of your gradual return to work from start to end and the days per week and hours per day that you can work during this period.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/availability_adj_rw/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type the appropriate option:

- “Unable to contact the client for fact-finding.”

- “Not within Level 1 authority.” 

#### Note

Source topic: `en_EN/common_notes/note_c_2142.dita`

Note:

If there is a D16 on file, refer to Reviewing a medical certificate submitted by a client with a D16 .
       [Reviewing a medical certificate submitted by a client with a D16](/en/procedure/task/review_d16_med_cert.shtml)

     [Reviewing a medical certificate submitted by a client with a D16](/en/procedure/task/review_d16_med_cert.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2143.dita`

Note:

When the incapacity end date falls between Monday and Saturday, consider the client to be incapable of working up to the Saturday of that week. When the incapacity end date falls on a Sunday, consider the client to be incapable of working up to the preceding Saturday. 

### Level 2

Source topic: `en_EN/task/availability_adj_rw/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/availability_adj_rw/reviewing_the_file_level_2.dita`

- Determine if there is a contentious RFS to be adjudicated:

- If no, go to step 2

- If yes, adjudicate the RFS according to the appropriate procedure and, if the RFS is allowed, go to step 2.

- If yes, adjudicate the RFS according to the appropriate procedure and, if the RFS is not allowed, go to No regular benefits are payable — Disqualification on file .
               [No regular benefits are payable — Disqualification on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#no_regular)

- Determine if additional fact-finding is required to adjudicate the issue:

- If yes, go to step 3.

- If no, go to step 6. 

#### Fact-finding

Source topic: `en_EN/task/availability_adj_rw/fact-finding_level_2.dita`

- Fact-find with the client. Refer to Guiding questions to determine which questions to ask the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 5.

- If the client could not be contacted, go to Client not contacted .
               [Client not contacted](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#client_not_contacted)

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Availability .

- Comments: Type “Gradual return to work.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- Select Save . 

#### Adjudicating availability

Source topic: `en_EN/task/availability_adj_rw/adjudicating_availability_level_2.dita`

- Review the medical certificate for the details of the gradual RTW and the client’s availability:

- If the client can work full days but fewer than 5 days each week, go to step 7.

- If the client cannot work full days (e.g. the client can only work 4 hours per day, 5 days per week), go to Only available for partial days — 3 - Not available disentitlement (D3) .
               [Only available for partial days — 3 - Not available disentitlement (D3)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#limited_capacityonly_available)

- If the client has recovered and is now capable of working, go to Availability to determine the client’s entitlement to regular benefits.
               [Availability](/en/procedure/activity/availability.shtml)

- If the medical certificate does not have details of the gradual RTW, go to Availability to determine the client’s entitlement to regular benefits.
               [Availability](/en/procedure/activity/availability.shtml)

- Determine if the client has returned to work for the gradual RTW period:

- If the client has not returned to work, go to step 8.

- If the client has returned to work, go to Regular benefits are partially payable .
               [Regular benefits are partially payable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#regular_payable)

- Based on labour market information , assess the employment opportunities available within the client’s restrictions:

- If there are employment opportunities, go to Regular benefits are partially payable .
               [Regular benefits are partially payable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#regular_payable)

- If there are no employment opportunities, go to No employment opportunities — 3 - Not available disentitlement (D3) .
               [No employment opportunities — 3 - Not available disentitlement (D3)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/availability_adj_rw#no_jobs) 

#### No regular benefits payable — Disqualification on file

Source topic: `en_EN/task/availability_adj_rw/no_regular_benefits_payable__disqualifi_525ea41b_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “No regular benefits payable — disqualification on file.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- In FTS, determine if there is an outstanding registration number for the gradual RTW issue:

- If yes , go to step 3.

- If no, go to step 4.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Registration number: Select the appropriate registration number.

- Claim Denied: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Text - Free Text (1612): Type “We are unable to pay you any sickness benefits because you have already received the maximum sickness benefits payable. Furthermore, we are unable to pay you any regular benefits. As mentioned in our letter of [date of the letter], to receive regular benefits you must have worked a required minimum number of insurable hours since [voluntarily leaving your employment without just cause/losing your employment due to misconduct] with [employer’s name] on [date].”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI. 

#### Client not contacted

Source topic: `en_EN/task/availability_adj_rw/client_not_contacted_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Gradual return to work — client not contacted — 15 - Claim procedure disentitlement imposed from w/c [XXXX-X].”

- Details: Type the appropriate option:

- “Automated Correspondence Solution letter was sent on [date]. There has been no response from the client. D15 is imposed for failure to provide entitlement information.”

- “Messages have been left for the client on [dates]. There has been no response from the client. D15 is imposed for failure to provide entitlement information.”

- In FTS, determine if there is an outstanding registration number for the gradual RTW issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Disqualifications/Disentitlements (M161) transaction and impose a D15 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 15 - Claim Procedure .

- Start date: Enter the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D48 and D15 — Moved — Adress unknown and claim procedure (3006):

- Select D15 - Claim procedure (3009):

- Select D15 - Text: Insert appropriate reason for D15: Type: “you have not responded to our requests for further information. You must contact us and provide proof of your availability for work.”

- We/In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI. 

#### Not available disentitlement (D3) — Only available for partial days

Source topic: `en_EN/task/availability_adj_rw/not_available_disentitlement_d3__only_a_8087fd91_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Not available full days — 3 - Not available (D3) disentitlement imposed from w/c [XXXX-X].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2144.dita)

- Verbally communicate the decision to the client.

- In FTS, determine if there is an outstanding registration number for the gradual RTW issue:

- If yes, go to step 4.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if the CT needs to be changed from sickness to regular and if an MA01 is imposed:

- If an MA01 is imposed and the CT needs to be changed, go to step 5.

- If an MA01 is imposed but the CT does not need to be changed, go to step 6.

- If an MA01 is not imposed but the CT needs to be changed, go to step 7.

- If none of the above applies, go to step 8.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2145.dita)

- Select the Renewal/Revised (M106) transaction, change the CT, remove the MA01 and impose the D3 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Enter the Sunday of the week regular benefits are to start.

- Claim type: Select 2 - Regular .

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start: Enter the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Go to step 9.

- Select the Renewal/Revised (M106) transaction, remove the MA01 and impose the D3 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start: Enter the start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Go to step 9.

- Select the Renewal/Revised (M106) transaction, change the CT and impose the D3 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Enter the Sunday of the week regular benefits are to start.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start: Enter the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Go to step 9.

- Select the Disqualifications/Disentitlements (M161) transaction and impose the D3 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Enter the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D3 - Not available - Various reasons (2986) .

- D3 - MA11 imposed/restriction – Part-time work only (3002) .

- D3 - Will only accept part time work - # of hours a day .

- We/In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Specify number of hour(s) per day willing to work (1516): Enter the number of hours per day the client can work (type “ hours ” after the number).

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI. 

#### Regular benefits are partially payable

Source topic: `en_EN/task/availability_adj_rw/regular_benefits_are_partially_payable_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Gradual return to work — regular benefits partially payable.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2144.dita)

- Verbally communicate the decision to the client.

- In FTS, determine if the claimant’s reports have been processed up to the last full week of sickness benefits:

- If no , input the claimant’s reports and go to step 4.
               [claimant’s reports](/en/procedure/activity/claimant_report.shtml)

- If yes, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2146.dita)

- In NWS, to allow the claimant’s reports to be processed, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Conversion required.”

- Bring forward date: Select today’s date + 1 business day.

- When the WI moves to the current workload, determine if the claimant’s reports have been processed up to the last full week of sickness benefits:

- If no, action any rejected claimant’s reports and return to step 4.
               [claimant’s reports](/en/procedure/activity/claimant_report.shtml)

- If yes, go to step 6.

- In FTS, determine if there is an outstanding registration number for the gradual RTW issue:

- If yes, go to step 7.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if a D2 is on file and if the CT needs to be changed from sickness to regular:

- If a D2 is on file and the CT needs to be changed, go to step 8.

- If a D2 is on file but the CT does not need to be changed, go to step 9.

- If there is no D2 on file but the CT needs to be changed, go to step 10.

- If none of the above applies, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2145.dita)

- Select the Renewal/Revised (M106) transaction and change the CT and terminate the D2 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Enter the Sunday of the week regular benefits will start.

- Claim type: Select 2 - Regular .

- Action: Select T - Terminate/Modify .

- Disentitlement: Select 2 - Minor attached, reason for separation illness .

- End: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 11.

- Select the Disqualifications/Disentitlements link and terminate the D2 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 11.

- Select the Renewal/Revised (M106) transaction and change the CT as follows:

- Registration number: Select the appropriate registration number.

- Revival: Enter the Sunday of the week regular benefits will start.

- Claim type: Select 2 - Regular .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine the duration of the gradual RTW plan:

- If the gradual RTW plan is for 1 or 2 weeks, go to step 12.

- If the gradual RTW plan is for more than 2 weeks, go to step 14.

- Select the Renewal/Revised (M106) transaction and impose the partial disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start: Enter the disentitlement start date.

- End: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if there is another partial disentitlement to impose:

- If yes, return to step 12.

- If no, go to step 17.

- Select the Renewal/Revised (M106) transaction and indicate the part-week disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 11 - Part week disentitlement on a continuing basis .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Select Update .

- Complete the Operational Centre Memo (MM06) transaction and send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- SCC: Select the SCC as shown in FTS.

- Work item: Select 94 - Manual Action .

- Work type: Select 15 - Manual Action code 11, 12 or 14 .

- Remarks:

- Line 1: Type “MA11.”

- Line 2: Type “D3 is imposed for [number] days per week from w/c [XXXX] to w/c [XXXX].”

- Line 3: Leave the field blank.

- Line 4: Leave the field blank.

- Line 5: Enter your first name and last name.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Select the Outstanding Registrations link and transfer the registration number to IPOC as follows:

- Select Modify .

- In the appropriate registration section:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976) .

- D3 - Not available - Various reasons (2986) .

- D3 - MA11 imposed/restriction – Part-time work only(3002): Select D3 - Part week disentitlement (MA11) input for part time availability .

- We/In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- are/were (2979) .

- Number of days(s) disentitled per week (1278) .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI. 

#### Not available disentitlement (D3) — No employment opportunities

Source topic: `en_EN/task/availability_adj_rw/not_available_disentitlement_d3__no_emp_0a7e22d9_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “No employment opportunities — 3 - Not available disentitlement imposed from w/c [XXXX-X].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- If the client is reached during fact-finding, or if fact-finding is not attempted, select Draft and go to step 2.

- If the client is not reached during fact-finding, select Save and go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2144.dita)

- Verbally communicate the decision to the client.

- In FTS, determine if there is an outstanding registration number for the gradual RTW issue:

- If yes, go to step 4.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if a D2 is on file:

- If yes, go to step 5.

- If no, go to step 6.

- Select the Disqualifications/Disentitlements link and terminate the D2 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End date: Enter the Friday immediately before the D3 start date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if the CT needs to be changed and if an MA01 is imposed:

- If an MA01 is imposed and the CT needs to be changed, go to step 7.

- If an MA01 is imposed but the CT does not need to be changed, go to step 8.

- If an MA01 is not imposed but the CT needs to be changed, go to step 9.

- If none of the above applies, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2145.dita)

- Select the Renewal/Revised (M106) transaction, change the CT, remove the MA01 and impose the D3 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Enter the Sunday of the week regular benefits will start.

- Claim type: Select 2 - Regular .

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start: Enter the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Go to step 11.

- Select the Renewal/Revised (M106) transaction, remove the MA01 and impose the D3 as follows:

- Registration number: Select the appropriate registration number .

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start: Enter the start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Go to step 11.

- Select the Renewal/Revised (M106) transaction, change the CT and impose the D3 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Enter the Sunday of the week regular benefits will start.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start: Enter the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Go to step 11.

- Select the Disqualifications/Disentitlements (M161) transaction and impose the D3 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Enter the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D3 - Not available - Various reasons (2986) .

- D3 - Text Other reason(s) .

- We/In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Text - Specify reason(s) disentitled (1482): Type “have restrictions on your availability to work. A review of labour market information shows that there are no job opportunities available within your restrictions.”

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2144.dita`

Note:

If fact-finding by telephone was attempted but was not successful, select Save . Verbal communication of the decision is not required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2145.dita`

Note:

The CT needs to be changed to 2 if the CT shown in FTS is either 3 or 9 . 

#### Note

Source topic: `en_EN/common_notes/note_c_2146.dita`

Note:

The last week of sickness benefits must be paid before inputting the conversion transactions to change the benefit type (BT) to regular. If claimant’s reports have not yet been processed for the sickness benefits period, process them before inputting the conversion the following day. 

## Policy reference

Source topic: `en_EN/task/availability_adj_rw/policy_reference.dita`

- Digest 10 — Availability
         [Digest 10 — Availability](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/table-of-contents.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 20(2)
         [EIA 20(2)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-20.html)

- EIA 21(1)
         [EIA 21(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-21.html)

- EIR 32
         [EIR 32](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-32.html) 
