# Implementing a decision: Labour dispute — Level 1

Source map: `en_EN/task/implementing_decision_ldl1/implementing_decision_ldl1.ditamap`

## Summary

Source topic: `en_EN/task/implementing_decision_ldl1/summary.dita`

Summary: When clients stop working due to a labour dispute, their entitlement to benefits may be affected. The officer must review the labour dispute posted in Major Employer Events and take the appropriate action.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 

## What you need to know

Source topic: `en_EN/task/implementing_decision_ldl1/what_you_need_to_know.dita`

### Entitlement to benefits during a labour dispute

Source topic: `en_EN/task/implementing_decision_ldl1/entitlement_to_benefits_during_a_labour_dispute.dita`

A labour dispute is any dispute between employers and employees, or between the employees themselves. A labour dispute can be related to employment or non-employment, or the terms and conditions of employment.

Regardless of whether the labour dispute was initiated by a strike or a lockout, the impact on the claim remains the same. When clients lose their employment or are unable to return to work due to a work stoppage resulting from a labour dispute at their place of employment, they are not entitled to EI benefits under the EIA.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0123.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3513.dita) 

### Adjudicating a labour dispute

Source topic: `en_EN/task/implementing_decision_ldl1/adjudicating_a_labour_dispute.dita`

The regional coordinator ensures that the initial fact-finding and decisions regarding labour disputes (e.g. start and end dates, dates of disentitlement and any exemptions from disentitlement) are made based on the region of the employer’s head office.

Once the fact-finding is complete and a decision concerning entitlement has been made, the regional officer posts the decision in Major Employer Events .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

If a labour dispute has not yet been identified and entered in Major Employer Events , the officer completes and email the Labour dispute initial information form to the regional coordinator for Labour Dispute serving the area where the employer’s head office is based.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
       [regional coordinator for Labour Dispute](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml)

Once notified of a labour dispute, the regional coordinator must:

- create a file for the labour dispute in Major Employer Events ;
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- check or track the media, if necessary;

- render decision regarding entitlement to EI benefits as a result of the labour dispute.

The WIs must be moved to Pending until the regional coordinator renders the decision and posts it in Major Employer Events .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

If a client already has an established claim, the officer imposes a 74 - Labour dispute manual action (MA74) stop until a decision about the labour dispute has been rendered.

Once the decision has been posted, the officer implements the decision according to the client’s situation and records it onto a record of decision (ROD).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0124.dita) 

If the labour dispute has been posted in Major Employer Events and officers require assistance determining entitlement, they contact their regional Business Expertise.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Since a labour dispute is a temporary situation, the officer imposes a disentitlement rather than a disqualification.

The 5 - Labour dispute disentitlement (D5) is imposed to indicate the period of the labour dispute. The client is disentitled for any days of work stoppage due to a labour dispute during the benefit period until one of the following occurs:

- the labour dispute ends;

- the client becomes regularly engaged elsewhere in insurable employment.

**Fact-finding with the employer or union**

The officer does not conduct any fact-finding with the employer or the union about the labour dispute.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3514.dita) 

**National labour dispute**

A loss of employment in more than one province because of a work stoppage attributable to a labour dispute is considered a national labour dispute. The regional office where the employer’s head office is located is usually responsible for coordinating and assigning the various tasks and keeping the other regional offices informed, so as to avoid confusion and unnecessary contacts and enquiries. Regional offices use a common email address to communicate with all regional coordinators concurrently: nc-dist-labour_dispute-conflit_collectif-coordinators@hrsdc-rhdcc.gc.ca .
       [nc-dist-labour_dispute-conflit_collectif-coordinators@hrsdc-rhdcc.gc.ca](mailto:nc-dist-labour_dispute-conflit_collectif-coordinators@hrsdc-rhdcc.gc.ca) 

### Levels of decision

Source topic: `en_EN/task/implementing_decision_ldl1/levels_of_decision.dita`

The Level 1 officer can implement the decision using the information provided by the regional coordinator in the Major Employer Events database, whether to impose a disentitlement or to allow benefits for clients who lose their employment because of a work stoppage at their place of employment when all the following conditions are met:
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- The decision is readily apparent.

- No additional fact finding is required.

- The affected parties of the decision are clearly established according to the fact-finding.

If a Level 1 officer cannot implement the decision, the officer refers the RFS to Level 2 for adjudication.

If the client is applying for special benefits or is participating in Section 25 training, the officer must reassign the WI to Level 2 for adjudication 

### Calculating the disentitlement for a part-time employee

Source topic: `en_EN/task/implementing_decision_ldl1/calculating_the_disentitlement_for_a_pa_6c72116b.dita`

When a client loses or is unable to resume part-time employment due to a labour dispute, the officer must calculate the number of days of disentitlement to impose per week.

The number of days of disentitlement per week is based on a comparison between the client’s average weekly earnings in the part-time employment and the average weekly insurable earnings in the calculation period.

To calculate the number of days of disentitlement the officer uses the following formula to find the percentage of the part-time work:

- Average weekly earnings from part-time employment ÷ average weekly insurable earnings in the calculation period × 100

<table class="table table-bordered">
<tbody>
<tr>
<th scope="row">average weekly earnings from part-time work</th>
<td class="align-center">&times; 100 = %</td>
</tr>
<tr>
<th class="align-center" scope="row">average weekly insurable earnings in the calculation period (the weeks used for the best weeks divided by the divisor)</th>
<td> </td>
</tr>
</tbody>
</table>

The calculation result is then applied to the table below to determine the appropriate number of days of disentitlement that must be imposed.

```text
| Percentage (%) | Number of days of disentitlement |

| More than 0 but not more than 10 | 0 |

| More than 10 but not more than 30 | 1 |

| More than 30 but not more than 50 | 2 |

| More than 50 but not more than 70 | 3 |

| More than 70 but not more than 90 | 4 |

| More than 90 | 5 |
```

The officer creates an Operational Centre Memo (MM06) transaction to advise IPOC to impose the partial disentitlement (fewer than 5 days per week). 

### Note

Source topic: `en_EN/common_notes/note_c_0123.dita`

Note:

When the reason for separation (RFS) on the ROE is Strike or Lockout , the initial claim is not automated and a Claim Assessment (CA) WI is created. 

### Note

Source topic: `en_EN/common_notes/note_c_3513.dita`

Note:

A labour dispute has no impact on an initial claim when the period of the work stoppage occurs and ends during the qualifying period (QP). Any insurable hours accumulated from the employment during the QP are included in the calculation of the claim. A work stoppage due to a labour dispute results in a disentitlement for the period of the dispute, but a disentitlement does not apply in the QP. Consequently, once it is determined that the labour dispute both occurred and ended in the QP, no further adjudication of the issue is required. 

### Note

Source topic: `en_EN/common_notes/note_c_0124.dita`

Note:

If the employer’s head office is located in the Western Canada and Territories region and a labour dispute has not been entered in Major Employer Events , officers working in the Western Canada and Territories region send the Labour dispute initial information form to the Technical Expertise Request Application (TERA), not to the regional coordinator.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx)

Officers in all other regions email the Labour dispute initial information form only to the regional labour dispute coordinator for the region where the employer’s head office is located, via the regional Business Expertise Consultant’s GD mailbox.
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
       [regional labour dispute coordinator](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml)

     [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
     [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
     [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
     [regional labour dispute coordinator](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3514.dita`

Note:

The regional coordinator is responsible for completing, coordinating and assigning various tasks to avoid unnecessary contacts and enquiries. The regional coordinators may conduct the fact-finding themselves or assign the initial fact-finding to an officer. This fact-finding is not part of this task. 

## Regional considerations

Source topic: `en_EN/task/implementing_decision_ldl1/regional_considerations.dita`

Atlantic and Western Canada and Territories regions — For events before May 14, 2018, the decisions concerning labour disputes can be found in the following databases:

- Atlantic region: Documents are stored in the regional common document share under EI Document Library / Employer Info / Labour Disputes

- Western Canada and Territories region: WT regional site
         [WT regional site](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/labour-memos.shtml)

Western Canada and Territories region: Officers send the completed Labour dispute initial information form to the Technical Expertise Request Application instead of emailing the regional coordinator when both of the following conditions are met:
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx)

- The employer’s head office is located in the Western Canada and Territories region.

- The labour dispute has not been identified and entered by a regional coordinator into the Major Employer Events .
         [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Officers refer to Business Expertise Advisor Enquiries for more information on how to access the Technical Expertise Request Application.
       [Business Expertise Advisor Enquiries](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/bea-enquiries.shtml) 

## What you need to look for

Source topic: `en_EN/task/implementing_decision_ldl1/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/implementing_decision_ldl1/in_nws.dita`

- Are there any SROCs, RODs or WIs containing documents relating to the labour dispute?

- Are there any documents relating to the labour dispute? 

### In FTS:

Source topic: `en_EN/task/implementing_decision_ldl1/in_fts.dita`

- Is there a D5 disentitlement already on file?

- Is the claim type initial, renewal or continuing?

- Is there an MA74 imposed on the file? 

### In Imaging:

Source topic: `en_EN/task/implementing_decision_ldl1/in_imaging.dita`

- Are there any imaged documents relating to the labour dispute? 

### Major Employer Events:

Source topic: `en_EN/task/implementing_decision_ldl1/major_employer_events.dita`

- Is there any information relating to the labour dispute? 

## Step by step

Source topic: `en_EN/task/implementing_decision_ldl1/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/implementing_decision_ldl1/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/implementing_decision_ldl1/reviewing_the_file_level_1.dita`

- Determine if adjudication can be deferred.

- If no, go to step 2.

- If yes, refer to Deferral of adjudication .
               [Deferral of adjudication](/en/procedure/activity/deferral_adj.shtml)

- Review the Major Employer Events database to determine if the labour dispute occurred and ended in the QP:

- If no or if the labour dispute has not been entered in Major Employer Events , go to step 3.
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- If yes, go to Labour dispute in the qualifying period (QP) only .
               [Labour dispute in the qualifying period (QP) only](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#LabourDisputeinQPOnlyNotLastEmployment)

- In FTS, determine if it is an initial, a renewal or a continuing claim:

- If it is a renewal claim, go to step 4.

- If it is an initial or a continuing claim, go to step 6.

- Review Major Employer Events to determine if the labour dispute occurred and ended before the renewal week:

- If yes, go to step 5.

- If no or if the labour dispute has not been entered in Major Employer Events , go to step 6.
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- In NWS, determine if the client is requesting benefits during the period of the labour dispute:

- If yes, go to step 6.

- If no, go to Labour dispute before the renewal week .
               [Labour dispute before the renewal week](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#Labour_dispute_before_renewal_week)

- Determine if the Labour Dispute: INS5248 Labour dispute questionnaire transcript―Form is on file:

- If no, go to step 7.

- If yes, go to step 13. 

#### Fact-finding

Source topic: `en_EN/task/implementing_decision_ldl1/fact-finding_level_1.dita`

- Make one attempt to contact the client:

- If the client is reached, go to step 8.

- If the client is not reached, go to step 10.

- Complete the Labour Dispute: INS5248 Labour dispute questionnaire transcript―Form .

- In NWS, create an SROC as follows:

- Main issue: Select Reason for Separation .

- Comments: Type “questionnaire for labour dispute.”

- Details: Cut and paste the Labour Dispute: INS5248 Labour dispute questionnaire transcript―Form .
               [Labour Dispute: INS5248 Labour dispute questionnaire transcript―Form](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Labour_dispute-INS5248_Labour_dispute_questionnaire_transcript-Form.doc)

- Select Save .

- Go to step 13.

- In ACS, create and send the Q-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Info Requested Re: ROE / RFS / Conflicting statements / Undeliverable Mail / More Info required (2876) .

- Select: Request for Additional Information Re: Entitlement .

- Text - Name of Employer(s) (1502) .

- Message re BF Date-if not received may delay claim (2897) .

- Date of BF (Date letter sent + 10 business days) (1540).

- Attachment List for Q-01-00-00 (3120) .

- Select: Labour Dispute Questionnaire .

- Move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Q-01-00-00 letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, review the file for a response to the Q-01-00-00 letter and go to step 13. 

#### Reviewing the decision

Source topic: `en_EN/task/implementing_decision_ldl1/reviewing_the_decision_level_1.dita`

- Determine if a regional coordinator identified the labour dispute and entered it in Major Employer Events :

- If yes, go to step 14.

- If no, go to step 15.

- In Major Employer Events , determine if the decision has been made with respect to entitlement to EI benefits:

- If no, go to step 16.

- If yes, go to step 22.

- In Outlook, email the appropriate regional coordinator . Include the following information:

- the completed Labour dispute initial information form, if necessary;
               [Labour dispute initial information](/resources/ort/documents/EIOPP-Form-FormLabourDisputeInitialInfo-2016Nov21-E-V01.docx)

- the Labour Dispute: INS5248 Labour dispute questionnaire transcript―Form , if it is on file;
               [Labour Dispute: INS5248 Labour dispute questionnaire transcript―Form](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx)

- any other relevant information.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3515.dita)

- In FTS, determine if this is an established claim:

- If yes, go to step 17.

- If no, go to step 19.

- Determine if there is an MA74 imposed on the claim:

- If yes, go to step 18.

- If no, select the Renewal/Revised (M106) transaction and do the following:

- Manual action: Select MA74 - Labour Dispute .

- Select Save .

- Go to step 18.

- In ACS, create and send the N-02-00-01 letter. Based on the claim information, select all of the required attributes, including the following:

- Labour Dispute-Benefits are suspended (2679) .

- Suspended Payment .

- Indefinite disentitlement start date (1270) .

- TEXT-Name of employer(s) (1502) .

- Go to step 20.

- In ACS, create and send the N-06-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Labour Dispute-Processing of Claim Delayed (2702) .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting a decision to be made and posted in Major Employer Events regarding entitlement to EI benefits as a result of a labour dispute.”
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Bring forward date: Enter the current date + 10 business days.

- When the WI moves to the current workload, determine if a decision has been posted in Major Employer Events :

- If no, repeat step 20.

- If yes, go to step 22. 

#### Calculating the disentitlement for a part-time employee

Source topic: `en_EN/task/implementing_decision_ldl1/calculating_the_disentitlement_for_a_pa_6c72116b_level_1.dita`

- Determine if the client is a part-time employee:

- If yes, go to step 23.

- If no, go to step 27.

- In FTS and RCM, determine the following:

- the average weekly earnings for the part-time employment;
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3516.dita)

- the weeks used for the best weeks ÷ the divisor.

- Complete the calculation:

- Average weekly earnings from part-time employment ÷ average weekly insurable earnings in the calculation period × 100

- Apply the calculation result to the table and determine the appropriate number of days of disentitlement that must be imposed.

```text
| Percentage (%) | Number of days of disentitlement |

| More than 0 but not more than 10 | 0 |

| More than 10 but not more than 30 | 1 |

| More than 30 but not more than 50 | 2 |

| More than 50 but not more than 70 | 3 |

| More than 70 but not more than 90 | 4 |

| More than 90 | 5 |
```

- In NWS, create an SROC as follows:

- Main issue: Select Reason for Separation .

- Comments: Type “Labour dispute — part-time employment.”

- Details: Type “Based on the client’s average weekly earnings of [amount] ÷ the client’s average weekly earnings of [amount] × 100%, the number of days of disentitlement is [number of days].”

- Select Save . 

#### Determining if the conditions to implement at Level 1 are met

Source topic: `en_EN/task/implementing_decision_ldl1/determining_if_the_conditions_to_implem_7ea19878_level_1.dita`

- In NWS, determine if the client is applying for regular benefits:

- If yes, go to step 28.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#reassign)

- Determine if the client is participating in Section 25 training:

- If no, go to step 29.

- If yes, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#reassign)

- Determine if the client is requesting to be exempt from a disentitlement:

- If no, go to step 30.

- If yes, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#reassign)

- In Major Employer Events , NWS and Imaging, determine if all of the following conditions are met:

- The decision is readily apparent;

- No additional fact-finding is required;

- According to the fact-finding relating to this decision, it is clearly established who this decision applies to.

- If yes, go to step 31.

- If no, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#reassign) 

#### Inputs and communication

Source topic: `en_EN/task/implementing_decision_ldl1/inputs_and_communication_level_1.dita`

- Determine if a partial disentitlement (fewer than 5 days per week) is imposed for a client working as a part-time employee:

- If no, go to step 32.

- If yes, go to step 33.

- In FTS, determine the decision and if it is an initial, a renewal or a continuing claim:

- If this is an initial or renewal claim and entitlement is proven, go to Entitlement proven .
               [Entitlement proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#proven)

- If this is a continuing claim and entitlement is proven, go to Entitlement proven .
               [Entitlement proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#proven)

- If this is an initial or renewal claim and entitlement is not proven, go to Entitlement not proven — Initial or renewal claim .
               [Entitlement not proven — Initial or renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#notproveninitren)

- If this is a continuing claim and entitlement is not proven, go to Entitlement not proven — Continuing claim .
               [Entitlement not proven — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#notprovencont)

- In FTS, determine the decision and if it is an initial, a renewal or a continuing claim:

- If this is an initial or renewal claim and entitlement is proven, go to Entitlement proven .
               [Entitlement proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#proven)

- If this is a continuing claim and entitlement is proven, go to Entitlement proven .
               [Entitlement proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#proven)

- If this is an initial or renewal claim and entitlement is not proven, go to Entitlement not proven — Part-time employment on an initial or renewal claim .
               [Entitlement not proven — Part-time employment on an initial or renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#notprovenintipt)

- If this is a continuing claim and entitlement is not proven, go to Entitlement not proven — Part-time employment on a continuing claim .
               [Entitlement not proven — Part-time employment on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/implementing_decision_ldl1#notprovenptcont) 

#### Labour dispute in the qualifying period (QP) only

Source topic: `en_EN/task/implementing_decision_ldl1/labour_dispute_in_the_qualifying_period_qp_only_level_1.dita`

- In NWS, determine if there is a ROD on file for the labour dispute.

- If no, go to step 2.

- If yes, go to step 3.

- Create a ROD as follows:

- Comments: Type “Labour dispute — work stoppage entirely in the qualifying period.”

- Details: Type “Labour dispute for [employer’s name] both occurred and ended during the qualifying period. A disentitlement does not apply.”

- Select Save .

- Complete the WI for the labour dispute issue. 

#### Labour dispute before the renewal week

Source topic: `en_EN/task/implementing_decision_ldl1/labour_dispute_before_the_renewal_week_level_1.dita`

- In NWS, determine if there is a ROD on file for the labour dispute:

- If no, go to step 2.

- If yes, go to step 3.

- Create a ROD as follows:

- Comments: Type “Labour dispute — before the renewal week — no benefits requested.”

- Details: Type “Labour dispute for [employer’s name] both occurred and ended before the renewal week and the client is not requesting benefits for the period of the work stoppage. A disentitlement does not apply.”

- Select Save .

- Complete the WI for the labour dispute issue. 

#### Entitlement proven

Source topic: `en_EN/task/implementing_decision_ldl1/entitlement_proven_level_1.dita`

- In NWS, create a ROD as follows:

- Comments:

- Type “Labour dispute — entitlement proven.”

- Details: Document the decision according to the information noted in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Save .

- If this is a continuing claim, go to step 2.

- If this is an initial or renewal claim, go to step 5.

- In FTS, determine if there is an MA74 imposed on the file:

- If yes, go to step 3

- If no, go to step 5.

- Determine if there is a registration number for the labour dispute issue:

- If yes, go to step 4.

- If no, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Disqualifications/Disentitlements (M106) transaction and remove the MA74 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 74 - Labour dispute .

- Rescind: Check the box.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: C - Yes .

- Select Update .

- Complete the WI for the labour dispute issue. 

#### Entitlement not proven — Initial or renewal claim

Source topic: `en_EN/task/implementing_decision_ldl1/entitlement_not_proven__initial_or_renewal_claim_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Select the appropriate option:

- Labour dispute: Type “Labour dispute — entitlement not proven. D5 imposed.”

- Details: Document the decision and rationale according to the National Policy on Levels of Decision and EIA 36 .
               [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml#s7) 
               [EIA 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.shtml)

- Select Save .

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose the D5 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 5 - Labour dispute .

- Start date: Enter the disentitlement start date as found in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- End date: Select indefinite or enter the disentitlement end date, if known.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D5, D12, D13, D14, D23 (3011): Select D5 - Labour dispute .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding Correspondence (COR) Manual Decision WI:

- If no, go to step 6.

- If yes, go to step 8.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 7.

- If yes, go to step 8.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “Send the saved D-01-00-00 letter.”

- Select Save .

- In NWS, complete the ADJ WI for the labour dispute issue. 

#### Entitlement not proven — Continuing claim

Source topic: `en_EN/task/implementing_decision_ldl1/entitlement_not_proven__continuing_claim_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Select the appropriate option:

- Labour dispute: Type “Labour dispute — entitlement not proven — D5 imposed.”

- Details: Document the decision and rationale according to the information noted in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Save .

- In FTS, determine if there is a registration number for the labour dispute issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if there is an MA74 imposed on the claim:

- If yes, go to step 4.

- If no, go to step 5.

- Select the Disqualifications/Disentitlements (M106) transaction to cancel the MA74 and impose the D5 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 74 - Labour dispute .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 5 - Labour dispute .

- Start date: Enter the disentitlement start date as found in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- End date: Select Indefinite or enter the disentitlement end date, if known.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 6.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose the D5 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 5 - Labour dispute .

- Start date: Enter the disentitlement start date as found in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- End date: Select Indefinite or enter the disentitlement end date, if known.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement.

- 4 - An overpayment resulted due to an indefinite disentitlement.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D5, D12, D13, D14, D23 (3011): Select: D5 - Labour dispute .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI for the labour dispute issue. 

#### Entitlement not proven — Part-time employment on an initial or renewal claim

Source topic: `en_EN/task/implementing_decision_ldl1/entitlement_not_proven__part-time_emplo_9ab761ac_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Select the appropriate option:

- Labour dispute: Type “Labour dispute — entitlement not proven. D5 imposed.”

- Details: Document the decision and rationale according to National Policy on Levels of Decision and EIA 36 .
               [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml#s7) 
               [EIA 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.shtml)

- Select Save .

- In FTS, determine if there is a registration number for the labour dispute issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 11 - Part week disentitlement on a continuing basis .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 94 - Manual Action .

- Work type: Select 15 - Manual Action code 11, 12 or 14 .

- Remarks line 1: Type “Labour dispute — part-time employment.”

- Remarks line 2: Type “MA11, partial D5 is imposed for [number] days per week starting [date] to [indefinite or disentitlement end date, if known].”

- Remarks line 5: Enter your first name and last name.

- Detection: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select 31 - Other new facts - entitlement review.

- In other cases, leave the field blank.

- Infraction: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select B - Non-fraud - Availability, capability.

- In other cases, leave the field blank.

- Message: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select 4 - An overpayment resulted due to an indefinite disentitlement.

- In other cases, leave the field blank.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D5, D12, D13, D14, D23 (3011): Select: D5 - Labour dispute .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding Correspondence (COR) Manual Decision WI:

- If no, go to step 9.

- If yes, go to step 11.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 10.

- If yes, go to step 11.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-01 letter required — labour dispute issue.”

- Select Save .

- In NWS, complete the ADJ WI for the labour dispute issue. 

#### Entitlement not proven — Part-time employment on a continuing claim

Source topic: `en_EN/task/implementing_decision_ldl1/entitlement_not_proven__part-time_emplo_247490a0_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Select the appropriate option:

- Labour dispute: Type “Labour dispute — entitlement not proven — D5 imposed.”

- Details: Document the decision and rationale according to the information noted in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- Select Save .

- In FTS, determine if there is a registration number for the labour dispute issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 11 - Part week disentitlement on a continuing basis .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 94 - Manual Action .

- Work Type: Select 15 - Manual Action code 11, 12 or 14 .

- Remarks line 1: Type “Labour dispute — part-time employment.”

- Remarks line 2: Type “MA11, partial D5 is imposed for [number] days per week starting [date] to [indefinite or disentitlement end date, if known].”

- Remarks line 3: If necessary, type “MA74 to be rescinded.”

- Remarks line 5: Enter your first name and last name.

- Detection: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select 31 - Other new facts - entitlement review.

- In other cases, leave the field blank.

- Infraction: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select B - Non-fraud - Availability, capability.

- In other cases, leave the field blank.

- Message: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select 4 - An overpayment resulted due to an indefinite disentitlement.

- In other cases, leave the field blank.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D5, D12, D13, D14, D23 (3011): Select D5 - Labour dispute .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI for the labour dispute issue. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/implementing_decision_ldl1/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the ADJ WI to Level 2 as follows:

- Destination: Select the appropriate option:

- Atlantic: Select Next available user .

- Quebec: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC / Labour Dispute - QC .

- Ontario: Select Next available user .

- Western Canada and Territories: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Labour dispute not within Level 1 authority.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_3515.dita`

Note:

Officers in the Western Canada and Territories region: Send the completed Labour dispute initial information form to the Technical Expertise Request Application when the employer’s head office is located in the Western Canada and Territories region and the labour dispute has not been identified and entered in the Major Employer Events . For more information on how to access the Technical Expertise Request Application, refer to Business Expertise Advisor Enquiries .
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
       [Business Expertise Advisor Enquiries](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/bea-enquiries.shtml)

Officers in all other regions: Send an email of the completed Labour dispute initial information form to the regional coordinator for the Western Canada and Territories region when the employer’s head office is located in the Western Canada and Territories region and the labour dispute has not been determined and entered in the Major Employer Events .
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

     [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
     [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
     [Business Expertise Advisor Enquiries](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/bea-enquiries.shtml) 
     [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
     [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 

#### Note

Source topic: `en_EN/common_notes/note_c_3516.dita`

Note:

The information on the ROE should be sufficient to determine the average weekly earnings for the part-time employment. If not, refer to Digest 8.9.3 or conduct fact-finding with the client.
       [Digest 8.9.3](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/disentitlement-daysofweek.html#a8_9_3)

     [Digest 8.9.3](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/disentitlement-daysofweek.html#a8_9_3) 

## Policy reference

Source topic: `en_EN/task/implementing_decision_ldl1/policy_reference.dita`

- Digest 8 — Labour disputes
         [Digest 8 — Labour disputes](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.html)

- EIA 36
         [EIA 36](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-36.html)

- EIR 52(2)
         [EIR 52(2)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-52.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml#s7) 
