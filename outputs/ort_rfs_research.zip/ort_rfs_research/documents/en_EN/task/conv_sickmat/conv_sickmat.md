# Converting a claim from sickness to maternity benefits

Source map: `en_EN/task/conv_sickmat/conv_sickmat.ditamap`

## Summary

Source topic: `en_EN/task/conv_sickmat/summary.dita`

Summary: A client receiving sickness benefits who reports that she is pregnant and provides an expected date of birth (DOB) or an actual DOB can request to have her claim converted to maternity benefits. 

## What you need to know

Source topic: `en_EN/task/conv_sickmat/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/conv_sickmat/untitled_section.dita`

Maternity benefits are available to people who are pregnant or have given birth. Maternity benefits provide income support during a leave due to a pregnancy or childbirth and can be paid up to 12 weeks before the expected DOB.

A client who wants to have parental benefits immediately follow her maternity benefits can apply for maternity and parental benefits at the same time. This allows the system to automatically convert the claim to parental benefits immediately after the maternity benefits are paid in full or the maternity end week is reached. If necessary, the system splits the last claimant’s report and continues to pay benefits without any interruption.

When maternity benefits are paid in full or the maternity end week is reached, the system automatically changes the sex code to 8 and displays the parental start week and the parental end week.

If the client completes both forms at the same time but there is an interruption between the two types of benefits, ignore the date provided by the client and process the claims simultaneously. If the client requests to modify the start date of maternity benefits, before converting the claim , the officer must determine the impact a modification would have on the claim and communicates with the client to explain the impact on the claim. 

### Qualifying for maternity benefits

Source topic: `en_EN/task/conv_sickmat/qualifying_for_maternity_benefits.dita`

Maternity benefits can be paid if one of the following conditions is met:

- The client is major attached (has accumulated at least 600 hours of insurable employment).
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

- The BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2800.dita) 

**Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits, regardless of the conversion date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to maternity benefits

Source topic: `en_EN/task/conv_sickmat/entitlement_to_maternity_benefits.dita`

To be entitled to maternity benefits, a client must meet both following conditions:

- The client must provide proof of the pregnancy.

- Request benefits during the maternity window. 

### Proof of pregnancy

Source topic: `en_EN/task/conv_sickmat/proof_of_pregnancy.dita`

As proof of the pregnancy, the client must provide a signed statement attesting the pregnancy and the expected DOB. The attestation at the end of an EI application is accepted as a signed statement. A completed and signed Maternity or parental: INS5168 Annex 3 — Form is also accepted as proof of pregnancy. If the officer completes the INS5168 form with the client, a verbal attestation is not acceptable. The officer mails the INS5168 form to the client to sign and return. The client can also download the form and return it by mail or upload it in MSCA. When the client completes the form electronically with an e-signature, it is considered a signed statement. The client must also advise Service Canada of the actual DOB as soon as possible.
       [Maternity or parental: INS5168 Annex 3 — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5168.pdf) 
       [INS5168](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Maternity_Parental-INS5168_Annex_3_transcript-Form.doc) 

### Payment of benefits

Source topic: `en_EN/task/conv_sickmat/payment_of_benefits.dita`

Up to 15 weeks of maternity benefits may be paid in a benefit period (BP). The 15 weeks payable for a single pregnancy may be paid over 2 BPs. A client does not have to collect maternity benefits successively. Payments of maternity benefits can alternate with the payment of another benefit type (BT). Once a claim has been established, a client may receive a combination of regular and special benefits within the BP. The maximum entitlement to benefits varies based on the BT received. The maximum number of weeks payable for each BT cannot be exceeded.
       [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2801.dita) 

### Extending the benefit period (BP)

Source topic: `en_EN/task/conv_sickmat/extending_the_benefit_period_bp.dita`

Under certain conditions, the BP can be extended to allow clients more time to receive the benefits to which they are entitled. The BP can be extended for a maximum of 104 weeks to pay additional weeks of benefits when all of the conditions are met before the BP ends. For more information, the officer refers to Extension of the benefit period .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Maternity window

Source topic: `en_EN/task/conv_sickmat/maternity_window.dita`

The maternity window is defined as the period in which maternity benefits are payable. It starts on the earlier of the following two dates:

- 12 weeks before the expected DOB (expected DOB – 12 weeks); or

- the actual DOB.

The maternity window ends on the later of the following two dates:

- 17 weeks after the expected DOB (expected DOB + 17 weeks); or

- 17 weeks after the actual DOB (actual DOB + 17 weeks).

To provide the client with the most advantageous maternity window, the actual DOB should be provided as soon as possible after the birth.

The expected or actual DOB can be used to determine the period during which maternity benefits are payable. The expected or actual DOB is input on the M106 at the same time as the data required to establish the maternity claim.

**Actual date of birth (DOB) provided**

If the client provides both the expected DOB and the actual DOB, the officer determines which date provides the longest maternity window for the client and enters it in the Confinement field during the conversion.

**Extending the maternity window**

To allow the client more time to collect maternity benefits to which they are entitled, the maternity window can be extended by one week for each week that a newborn is hospitalized within that period. The maximum extension of the maternity window is 52 weeks after the actual DOB (actual DOB + 52 weeks). The number of weeks of maternity entitlement remains the same. The officer extends the maternity window by inputting an external maternity end week. The officer calculates the maternity window by adding the number of full or partial weeks of hospitalization to the initial maternity end week. 

### Termination of pregnancy

Source topic: `en_EN/task/conv_sickmat/termination_of_pregnancy.dita`

If benefits are requested when a pregnancy is terminated within the first 19 weeks, the claim must be treated as a sickness claim .
       [sickness claim](/en/procedure/activity/calc_sick.shtml)

If benefits are requested when a pregnancy is terminated after the nineteenth week, the claim must be treated as a maternity claim.

If clients request maternity benefits before the start of the maternity window and state that they are not available for or actively seeking employment due to the pregnancy, the officer enters claim type (CT) 2 - Regular and inputs a 3 - Not Available disentitlement (D3) on the M106. 

### Disentitlements

Source topic: `en_EN/task/conv_sickmat/disentitlements.dita`

The following disentitlements related to maternity benefits are imposed when the client does not meet the entitlement conditions:

- A 25 - Maternity benefits - Minor attached (D25) is imposed if the client has not accumulated at least 600 insurable hours.

- A 27 - Maternity benefits (maximum special benefits paid) or outside range (D27) is imposed when a client requests maternity benefits and the maximum combination of regular and special benefits has already been paid or the request falls outside the maternity window.
         [maximum combination of regular and special benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

- A 36 - Maternity not eligible - 15 weeks paid per pregnancy (D36) is imposed when a client requests maternity benefits and the maximum 15 weeks of maternity benefits have already been paid.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1305.dita) 

### Outstanding disentitlements

Source topic: `en_EN/task/conv_sickmat/outstanding_disentitlements.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies on the renewal (conversion). A Level 1 officer can terminate or rescind the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . If the information on file allows for the disentitlement to be terminated, it ends on the Friday of the week before the conversion week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2752.dita) 

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer reassigns the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Allocation of separation monies

Source topic: `en_EN/task/conv_sickmat/allocation_of_separation_monies.dita`

If a client loses their employment after the start of the BP and receives separation monies, the officer allocates the separation monies.

For more information about allocating monies on separation, the officer refers to Allocating separation monies and Digest 5.12 — Moneys paid or payable by reason of a lay-off or separation .
       [Allocating separation monies](/en/procedure/task/all_monies_sep.shtml) 
       [Digest 5.12 — Moneys paid or payable by reason of a lay-off or separation](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/moneys-paid-layoff-separation.html#a5_12_0) 

### Temporary Foreign workers (900-series SIN)

Source topic: `en_EN/task/conv_sickmat/temporary_foreign_workers_900-series_sin.dita`

All foreign workers are given temporary resident status for a limited period of time when they enter Canada. Generally, foreign workers can demonstrate availability to accept work only if they possess a valid work permit which allows them to work in Canada.

Maternity, parental, CCB and family caregiver benefits can be paid to clients who qualify to receive these benefits, even if their SIN has expired, under the following 3 conditions:

- The clients’ SINs are valid during the qualifying period (QP).

- The clients are authorized to be in Canada (e.g. hold a visitor or study permit or a Refugee Protection Claimant Document).

- The clients remain in Canada (i.e. there is no information on the claim indicating that the client is or will be out of Canada).

Foreign clients applying for maternity, parental, CCB and family caregiver benefits do not need to prove their availability, so a work permit or valid SIN is not necessary during the BP. In these situations, the officer reviews the client’s authorization to remain in Canada.

If a client whose SIN has expired leaves the country, the client is disentitled from receiving maternity, parental, CCB and family caregiver benefits. 

### Effective date of a renewal or a conversion

Source topic: `en_EN/task/conv_sickmat/effective_date_of_a_renewal_or_a_conversion.dita`

When a client wishes to renew or convert a claim, the officer determines the effective date. For more information, the officer refers Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Return to work (RTW)

Source topic: `en_EN/task/conv_sickmat/return_to_work_rtw.dita`

If there is an RTW on the claim that is on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer reassigns the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### Renewal week required

Source topic: `en_EN/task/conv_sickmat/renewal_week_required.dita`

A renewal week is required when changing the CT to 4 - Maternity or parental , 14 - Standard parental , 16 - Extended parental , 74 - Self-employed - Maternity , 75 - Self-employed - Standard parental or 79 - Self-employed - Extended parental . If no renewal week is input for these CTs on conversions, the transaction is rejected with error code 242 . 

### Conversion a continuing claim from sickness benefits on a continuing claim

Source topic: `en_EN/task/conv_sickmat/conversion_a_continuing_claim_from_sick_b156caf0.dita`

Conversion requests that follow the payment of sickness benefits are established in the week following the last payment of sickness benefits if the client has made the conversion request within 3 weeks of the last week in which sickness benefits were processed (the week the last claimant’s report for sickness benefits was processed + 3).

If the request is made 4 or more weeks after the week in which the last payment of sickness benefits was processed, the effective date of conversion is the week before the week the request was made, according to the automatic backdating policy.

**Processing claimant’s reports**

Before the officer can input the conversion transactions, the last week of sickness benefits must be paid. If claimant’s reports have not been processed for the sickness benefit period, they must be processed before inputting the conversion. This requires a 2-day input.

**Adjudicating new contentious issue**

When converting a continuing claim, a client may report a new contentious issue (e.g. reason for separation [RFS], farming or availability) that must be adjudicated. If there is no existing WI for this issue, the Level 1 officer creates a Claim Review (CR) WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision. If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated. 

### Conversion from sickness benefits on a renewal claim

Source topic: `en_EN/task/conv_sickmat/conversion_from_sickness_benefits_on_a__852beadf.dita`

**Renewal advantages**

When assessing a renewal, it might be to the client’s advantage to establish a new BP instead of renewing the existing BP. For more information, the officer refers to Cancelling, voiding, terminating or withdrawing a claim .
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml)

**Subsequent claim**

The renewal application can be used to establish a subsequent claim when the following conditions are met:

- The claim is renewed and there are 4 or fewer weeks of benefits remaining in the BP.

- The client has worked enough hours to establish a new claim.

ACP can register the subsequent claim if the Claim Assessment (CA) WI for a renewal or subsequent initial claim is finalized within 28 days of the renewal application.

When ACP cannot register the subsequent claim because the renewal is not processed within 28 days of the renewal application (i.e. REN WK not found or no match and polling limit exceeded is displayed on the Processing Activities tab in NWS) or when the claim was converted to MPS, the officer processing the CA Renewal WI creates a Reminder (REM) WI. This ensures that an officer will manually register the subsequent claim.

**Adjudicating contentious issues**

When renewing a claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If the issue is reported on the EI application, the system creates an Adjudication Issue (ADJ) WI. If a contentious issue is detected while reviewing the claim, the Level 1 creates an ADJ WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If the Level 1 officer cannot adjudicate the issue, the ADJ WI is referred to Level 2 for adjudication. When an ADJ WI is created on a renewal claim, either manually or by the system, the system automatically imposes a 2 - Contentious Renewal in Automation manual action (MA2) to prevent payment of benefits until the contentious issue is adjudicated and the renewal is completed. When the renewal or a decision must be input manually, the inputs must be done before the CA or ADJ WI is completed, because the system deletes the MA2 when the CA and ADJ WIs are completed and there are no outstanding ADJ WIs. An officer cannot remove an MA2.
       [National Policy on Levels of Decision](/ui/éen/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Claim action status and processing of the claim

Source topic: `en_EN/task/conv_sickmat/claim_action_status_and_processing_of_the_claim.dita`

The Claim action status Renewal is created when a renewal decision is registered. There are 3 Claim action statuses that may be displayed:

- In Progress (Automation) is displayed on the Client information tree when there are one or more outstanding adjudication issues.

- In Progress (Manual) is displayed on the Client information tree when there are no outstanding adjudication issue and there is an outstanding CA or Specialized Application (SA) WI.

- Finalized is displayed on the Client information tree when all ADJ WIs are completed and the renewal week has been successfully input.

An ADJ WI is created for every new contentious issue. When opening an ADJ WI, the officer must always verify if there is a Resolve Issue tab. If there is a Resolve Issue tab, the officer documents the decision directly in the ADJ WI by completing all mandatory screens. When the ADJ WI is completed, NWS creates a record of decision (ROD) based on the Resolve Issue screens. When the renewal is finalized, the system also generates the required transactions (e.g. signature code, disentitlement) based on the Resolve Issue screens. If a disentitlement is imposed, the system creates a Correspondence WI for the D-01-00-00 letter. This means that the officer with the CA or SA WI has no action to perform for these ADJ WIs.

If there is no Resolve Issue tab for the ADJ WI, the officer creates a ROD, generates the required transactions and sends the appropriate letter. If there is an outstanding CA or SA WI when the officer completes the ADJ WI, a client Note is created and the officer with the CA or SA WI follows the instructions to input the transactions or send the letter. 

### ACS letters

Source topic: `en_EN/task/conv_sickmat/acs_letters.dita`

Communication of the renewal decision is not necessary when the only transaction input is a renewal. When another decision is input at the time of the renewal(disentitlement, disqualification or allocation of earnings), communication of the decision is necessary.

Written communication of the decision is usually done by officers who are responsible for sending the appropriate letter. 

### Selecting the appropriate benefit types (BT)

Source topic: `en_EN/task/conv_sickmat/selecting_the_appropriate_benefit_types_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular . The officer manually updates this field by choosing the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For a conversion request on a continuing claim or any other conversion request, the officer selects the new requested BT.

When creating an Action Item (AI), Call Back (CB), Assessment Issue (ASMT) or Reminder (REM) WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### Note

Source topic: `en_EN/common_notes/note_c_2800.dita`

Note:

If a client has been found responsible for a violation for an earlier claim, an increased number of hours may bee needed to qualify for maternity benefit. 

### Note

Source topic: `en_EN/common_notes/note_c_2801.dita`

Note:

Under PUnder Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_1305.dita`

Note:

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure. 

### Note

Source topic: `en_EN/common_notes/note_c_2752.dita`

Note:

A client is not required to demonstrate good cause for delay when submitting a medical certificate. The Level 1 officer can modify or rescind a disentitlement related to a missing medical certificate for special benefits, regardless of the length of delay, provided all other conditions are met for the requested BT. 

## Regional considerations

Source topic: `en_EN/task/conv_sickmat/regional_considerations.dita`

**Quebec region**

Clients who live in Quebec and who request benefits due to a pregnancy, birth or adoption must apply to QPIP . The Quebec government pays these benefits to Quebec residents. In some cases, the Quebec government also pays QPIP benefits to a parent living outside of Quebec if both parents lived in Quebec when the initial claim for maternity or parental benefits for the birth or adoption of the same child was made. When a client applying for EI benefits lives in Quebec or indicates that the other parent is entitled to QPIP benefits, the officer on the specialized team that is responsible for liaising with QPIP determines whether the client is entitled to the requested EI benefits.
       [QPIP](/en/procedure/generic/additionalresources/qpip_knowledge.shtml)

When a client living in Quebec is entitled to receive QPIP benefits, an officer from the specialized QPIP team imposes an indefinite 57 - E.I. Maternity or Parental benefits denied, benefits are payable by the province disentitlement (D57). 

## What you need to look for

Source topic: `en_EN/task/conv_sickmat/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/conv_sickmat/in_nws.dita`

- Did the client file a renewal application requesting a conversion of benefits?

- Does the client have a 900-series SIN?

- Has the client worked since the last week paid?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies, motor vehicle accident compensation, workers’ compensation benefits (WCB) or wage loss insurance (WLI) payments to consider or allocate?

- Is there a new contentious RFS?

- Is there an ADJ WI?

- If yes, for what issue?

- What is the expected DOB or the actual DOB?

- Has a medical certificate been uploaded? 

### In FTS:

Source topic: `en_EN/task/conv_sickmat/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the LRW been reached?

- Has the waiting period (WP) been served, waived or deferred?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Is there an RTW on the claim?

- Are there any pending claimant’s reports or claimant’s reports to be processed before the conversion?

- Is there a registration number? 

### In RCM:

Source topic: `en_EN/task/conv_sickmat/in_rcm.dita`

- Has the ROE been submitted?

- Are there earnings, separation monies, motor vehicle accident compensation, WCB or WLI payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/conv_sickmat/in_imaging.dita`

- Is there a medical certificate?

- Are there any restrictions noted on the medical certificate?

- Is there any other documentation which may impact the conversion claim? 

## Step by step

Source topic: `en_EN/task/conv_sickmat/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/conv_sickmat/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/conv_sickmat/reviewing_the_file_level_1.dita`

- Determine if one of the following situations applies:

- In FTS, the client’s residential address is in Quebec and no EI maternity benefits have been paid for the same BPC.

- In NWS, the client indicated on the EI application, on the Maternity or parental: INS5168 Annex 3 — Form or in the details on file one of the following:

- She received QPIP benefits in the last 2 years or will receive QPIP benefits.

- The other parent has received, is receiving or will receive QPIP benefits.

- If no, go to step 2.

- If yes, go to Reassigning the WI .
               [Reassigning the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#level1_item_5)

- In NWS, determine if there is a SIR WI:

- If yes, go to step 3.

- If no, go to step 5.

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting completion of SIR WI.”

- Bring forward date: Enter today’s date + 10 business days.

- When the CA WI moves to the current workload, determine if the Validation (SIR) WI has been completed:

- If no, repeat step 3.

- If yes, go to step 5.

- In FTS, determine if a registration number related to the renewal or conversion is on file:

- If yes, go to step 6.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Select Update .

- Go to step 6.

- Determine if the maximum combination of regular and special benefits has been paid:

- If yes, go to Maximum combination of regular and special benefits paid .
               [Maximum combination of regular and special benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#maxcomb)

- If no, determine if 15 weeks of maternity benefits have been paid:

- If no, go to step 7.

- If yes, go to Maximum maternity benefits paid .
                   [Maximum maternity benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#maxmat)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- Determine if the pregnancy was terminated within the first 19 weeks:

- If yes, the client may be entitled to sickness benefits. Refer to Renewing a claim for sickness benefits .
               [Renewing a claim for sickness benefits](/en/procedure/task/renew_sb.shtml)

- If no, go to step 8.

- In FTS, determine if there is a pending electronic claimant’s report on the E-Report tab for the period before the conversion:

- If there is no electronic claimant’s report, go to step 9.

- If there is a pending electronic claimant’s report, refer to Actioning a pending claimant’s report and then go to step 9.
               [Actioning a pending claimant’s report](/en/procedure/task/pending_cr.shtml)

- Determine if there are any rejected electronic claimant’s reports on the Pending/Reject tab for the period before the conversion:

- If no, go to step 10.

- If yes, re-input the reports. Refer to Actioning a rejected claimant’s report and then go to step 10.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml)

- Determine if the client reports having received monies and whether they have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings and then go to step 11.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 11.

- If no monies were received, go to step 11.

- In NWS and in FTS, determine if one of the following conditions is met to extend the BP:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2802.dita) 

- If one of the conditions is met, refer to Benefit period extension and then go to step 12.
               [Benefit period extension](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions is met, go to step 12.

- Based on the Claim duration section of the Rate/Duration tab in FTS, determine if one of the following conditions is met:

- The client is requesting benefits before the end of the week displayed in the Latest renewable week field.

- The client is requesting special benefits before the end of the week displayed in the End of the initial benefit period field.

- The client is requesting special benefits after the end of the week displayed in the End of the initial benefit period field, but is entitled to an automatic extension of the BP and is requesting special benefits before the end of the extended BP.

- If any condition is met, go to step 13.

- If none of the conditions is met, go to Last renewable week (LRW) has been reached .
                   [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#lrw)

               [extension of the BP](/en/procedure/activity/extension_benefit_period.shtml)

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 14.

- If no, go to step 16.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, go to step 15.

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 16.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine the CT:

- If it is a conversion on a continuing claim, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 16.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If it is a conversion on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next Available User .

- Issue: Select Availability .

- Details: Type “Outstanding D15 for a missed client information session, Level 2 review required.”

- Select Save.

- Go to step 16.

- Determine if there are any other outstanding disentitlements on file:

- If no, go to step 18.

- If yes and the conversion is on a continuing claim, create a CR WI as follows:

- Type: Select Revised .

- Issue: Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number .

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 17.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself

- Issue: Select the appropriate option.

- Details: Type “Outstanding [type of disentitlement] disentitlement.

- Select Save .

- Refer to the appropriate procedure and then go to step 17.

- Determine if the conditions are met to terminate or rescind the disentitlement at Level 1 according to the National Policy on Levels of Decision :

- If yes, terminate or rescind the disentitlement and go to step 18.

- If no, reassign the WI to Level 2 and go to step 18.

- Determine if there are any outstanding issues that require adjudication that do not have a related WI:

- If no, go to step 20.

- If yes and the conversion is on a continuing claim, create a CR WI as follows:

- Type: Select Revised .

- Issue: Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number .

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 19.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Next Available User .

- Issue: Select the appropriate option.

- Details: Indicate the reason the WI is being created.

- Select Save .

- Refer to the appropriate procedure and then go to step 19.

- Determine if the conditions are met to render a decision at Level 1 according to the National Policy on Levels of Decision :

- If no, reassign the WI to Level 2 and go to step 20.

- If yes, complete the steps from the appropriate procedure and go to step 20.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- In FTS, on the Rate/Duration tab, determine if the client is minor attached:

- If the BPC is between w/c 2310 to w/c 2361 and the Major Attached box is checked, go to step 21.

- If the client has 600 hours or more or the Major Attached box is checked, go to step 21.

- If the client has fewer than 600 hours and the Major Attached box is not checked, go to Minor attached .
               [Minor attached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#minor)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2757.dita)

- Determine if, on the initial EI application for benefits, the client indicated when maternity benefits should start or if there is a signed Maternity or parental: INS5168 Annex 3 — Form on file:

- If no, go to step 22.

- If yes, go to step 28.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2755.dita) 

#### Fact-finding

Source topic: `en_EN/task/conv_sickmat/fact-finding_level_1.dita`

- Fact-find with the client to determine the expected or actual DOB using the INS5168 form. Mail a copy of the INS5168 form for the client to sign and return. The client can also download the form and return it by mail or upload it in MSCA. Refer to the National Fact-Finding and Documentation Policy if needed.

- Determine if the client was contacted during fact-finding or if the client responded to the N-10-00-00 ACS letter:

- If the client was reached, go to step 24.

- If the client was not reached or did or did not reply to the letter, go to step 25.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Conversion .

- Comments: Type “Conversation with the client — INS5168 form information.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client was asked to provide the INS5168 form:

- If the INS5168 form was requested but is not on file, go to step 26.

- If the INS5168 form was requested and is on file, go to step 28.

- If the client was not reached and the INS5168 form is not on file, go to INS5168 form not provided .
               [INS5168 form not provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#annex3)

- If the client was not reached and the INS5168 form is on file, go to step 28.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact finding with client .

- Comments: Type “Awaiting the INS5168 form.”

- Bring forward date: Enter the date the client was reached + 10 business days.

- When the WI moves to the current workload, determine if the INS5168 form is on file:

- If no, go to INS5168 form not provided .
               [INS5168 form not provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#annex3)

- If yes, go to step 28.

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine if the conversion date is during the maternity window:

- If yes, go to step 30.

- If no, go to Outside the maternity window .
               [Outside the maternity window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#omw)

- Determine if the conversion is on a renewal claim:

- If the conversion is on a renewal claim, go to step 31.

- If the conversion is on a continuing claim, go to Conversion on a continuing claim .
               [Conversion on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#conversion)

- In NWS, determine if there is an outstanding ADJ WI:

- If no, go to Converting a renewal claim — No outstanding adjudication .
               [Converting a renewal claim — No outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#no)

- If yes, go to Converting a renewal claim — Outstanding adjudication .
               [Converting a renewal claim — Outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#oa) 

#### Maximum combination of regular and special benefits already paid

Source topic: `en_EN/task/conv_sickmat/maximum_combination_of_regular_and_spec_5cf2309f_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for maternity and parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D27 imposed — maximum combination of benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum combination of weeks of regular and special benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC. A D27 is imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum combination of weeks of regular and special benefits. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. A D27 is imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D27 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday

- Earnings week 1: Enter the amount (if necessary).

- Claim Type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 27 - Maternity benefits (maximum special benefits paid) or outside range .

- Start: Select the Monday of the week in which the client wants the maternity benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: To complete the registration number, select C - Yes .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Maternity benefits denied: D25/D27/D36/Free text (3070) .

- Text: - Explain why maternity benefits are not payable .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Text - Insert appropriate reason(s) (1618): Type
                   [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2771.dita)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Maximum maternity benefits already paid

Source topic: `en_EN/task/conv_sickmat/maximum_maternity_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for maternity and parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D36 imposed — maternity benefits exhausted.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the maximum entitlement to maternity benefits has been paid. The client does not qualify for a new claim as no hours were accumulated after the BPC. A D36 is imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the maximum entitlement to maternity benefits has been paid. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. A D36 is imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D36 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if necessary).

- Action: Select Add .

- Disentitlement: Select 36 - Maternity not eligible - 15 weeks paid per pregnancy

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: To complete the registration number, select C - Yes .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Maternity benefits denied: D25/D27/D36/Free text (3070) .

- Select D36 - Max 15 weeks paid per pregnancy or per claim - Fails to prove pregnancy (3073) .

- Select D36 - Max 15 weeks maternity already paid on this claim .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/conv_sickmat/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for maternity and parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “Last renewable week reached — maternity benefits requested.”

- Details: Select one of the following:

- If the client has not worked since the BPC , type “No conversion is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as no hours were accumulated after BPC.”

- If the client has worked since the BPC , type “No conversion is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as [number of hours] were accumulated after BPC and the client needed [number of hours] to qualify.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type the following:
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2803.dita)

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### INS5168 form not provided

Source topic: `en_EN/task/conv_sickmat/ins5168_form_not_provided_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Awaiting the INS5168 form — D15 from w/c [XXXX-X] to [9999-9].”

- Details: Type “The client was advised to provide the Maternity or parental: INS5168 Annex 3 — Form. As of today, the INS5168 form was not provided. Indefinite D15 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the disentitlement D15 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the Sunday of the week in which the client wants the maternity benefits to start being paid.

- Earnings week 1: Enter the amount (if necessary).

- Claim Type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 15 - Claim procedure .

- Start: Select the Monday of the week in which the client wants the maternity benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: To complete the registration number, select C - Yes .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Maternity benefits denied: D25/D27/D36/Free text (3070) .

- Select D36 - Max 15 weeks paid per pregnancy or per claim - Fails to prove pregnancy (3073) .

- Select D36 - Fails to prove her pregnancy .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select Indefinite disentitlement dates and enter date.

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Client is minor attached

Source topic: `en_EN/task/conv_sickmat/client_is_minor_attached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for maternity and parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D25 imposed: Maternity benefits — minor attached.”

- Details: Type “The client is not entitled to maternity benefits. D25 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D25 and as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the Sunday of the week in which the client wants the maternity benefits to start being paid.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 25 - Maternity Benefits - Minor Attached .

- Start: Select the Monday of the week in which the client wants the maternity benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: To complete the registration number, select C - Yes .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Maternity benefits denied: D25/D27/D36/Free text (3070) .

- Select D25 - Does not qualify - Not enough hours or earnings (3071) .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select Indefinite disentitlement dates and enter date.

- Enter the Number of insurable employment hours accumulated (1366) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI. 

#### Benefits requested outside of the maternity window

Source topic: `en_EN/task/conv_sickmat/benefits_requested_outside_of_the_mater_214d8489_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Maternity Benefits outside of the maternity window.”

- Details: Type “The client wants maternity benefits to start outside of the maternity window. No conversion.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D27 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week in which the client wants the maternity benefits to start being paid.

- Earnings week 1: Enter the amount (if applicable).

- Claim Type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 27 - Maternity benefits (maximum special benefits paid) or outside range .

- Start: Select the Monday of the week in which the client wants the maternity benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: To complete the registration number, select C - Yes .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Maternity benefits denied: D25/D27/D36/Free text (3070) .

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Conversion on a continuing claim

Source topic: `en_EN/task/conv_sickmat/conversion_on_a_continuing_claim_level_1.dita`

- In FTS, select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week in which the client wants the maternity benefits to start being paid.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select 4 - Maternity / parental .

- Manual Action: Select the appropriate MA. (e.g. If there is an outstanding adjudication required, select 1 - General suspension of benefits [stop payment] .)

- Select the Special benefits (M106) link and enter the following information in the Maternity section (if the confinement week has not already been entered):

- Confinement: Enter the expected or actual DOB.

- Select Save .

- No claimant’s report: Check the box (if requested by the client).

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To leave the registration number open for subsequent transactions, select D - No .

- To complete the registration number, select C - Yes .

- Select the appropriate option:

- If the client is not requesting that parental benefits start after maternity benefits, select Update .

- If the client is requesting that parental benefits start after maternity benefits, select Store .

- Select the Additional Data (M107) transaction and enter the external maternity start date as follows:

- Registration number: Select the appropriate registration number.

- External Maternity — Start week: Enter the week in which the client wants the maternity benefits to start being paid.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To leave the registration number open for subsequent transactions, select D - No .

- To complete the registration number, select C - Yes .

- Select the appropriate option:

- If the client is not requesting that parental benefits start after maternity benefits, select Update .

- If the client is requesting that parental benefits start after maternity benefits, select Store .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2761.dita)

- Determine if a child for whom maternity benefits are being requested was hospitalized during the maternity window:

- If yes, go to step 4.

- If no and the client is not requesting that parental benefits start after maternity benefits, go to step 5.

- If no and the client is requesting that parental benefits start after maternity benefits, refer to Converting a claim from maternity to parental benefits .
               [Converting a claim from maternity to parental benefits](/en/procedure/task/conv_matpar.shtml)

- In FTS, to extend the maternity window, select the Additional Data (M107) transaction and enter the extended maternity window end week as follows:

- Registration number: Select the appropriate registration number.

- External Maternity — End week: Enter the extended maternity window end week.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To leave the registration number open for subsequent transactions, select D - No .

- To complete the registration number, select C - Yes .

- Select the appropriate option:

- If the client is not requesting that parental benefits start after maternity benefits, select Update . Go to step 5.

- If the client is requesting that parental benefits start after maternity benefits, select Store and refer to Converting a claim from maternity to parental benefits .
                   [Converting a claim from maternity to parental benefits](/en/procedure/task/conv_matpar.shtml)

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement is being imposed.

- If there are decisions that must be communicated to the client, go to step 6.

- If there are no decisions that must be communicated to the client, go to step 9.

- In ACS, create and save or add to the saved N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following if not already input and the situation applies.

- Renewal week - Sunday’s date (1246) .

- If an antedate has been denied: Select Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Select Antedate denied (2483) .

- Special benefits approved (3046): Select Maternity and/or Parental benefits (standard/extended) approved or denied with sickness options (3054) .

- If there is an allocation: Select Allocation of Earnings (2516)

- Waiting period messages (2445): Select the appropriate option.

- Complete a report - General message or for sickness benefits (3091) .

- Determine if Level 2 adjudication is required:

- If yes, in NWS, create a client Note and type “Send the N-00-00-00 letter.” Go to step 8.

- If no, send the saved N-00-00-00 letter and go to step 9.

- In NWS, reassign the CR WI for the contentious issue to Level 2 as follows:

- Destination — SCC: Select the SCC as shown in FTS.

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Not within Level 1 authority.”

- Go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- In NWS, complete the Conversion WI. 

#### Conversion on a renewal claim — No outstanding adjudication

Source topic: `en_EN/task/conv_sickmat/conversion_on_a_renewal_claim__no_outst_8874a6e6_level_1.dita`

- In FTS, select the Renewal / Revised (M106) transaction and input the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week in which the client wants the maternity benefits to start being paid.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select 4 - Maternity / parental.

- If the LRW has been reached, Notify system to: Select E - Accept a renewal week effective after the last renewable week of the benefit period .

- Select the Special benefits (M106) link and enter the following in the Maternity section (if the confinement week has not already been entered):

- Confinement: Enter the expected or actual DOB.

- Select Save .

- No claimant’s report: Check the box (if requested by the client).

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To leave the registration number open for subsequent transactions, select D - No .

- To complete the registration number, select C - Yes .

- Select the appropriate option:

- If the client is not requesting that parental benefits start after maternity benefits, select Update .

- If the client is requesting that parental benefits start after maternity benefits, select Store .

- Select the Additional Data (M107) transaction and enter the external maternity start date as follows:

- Registration number: Select the appropriate registration number.

- External Maternity — Start week: Enter the week in which the client wants the maternity benefits to start being paid.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To leave the registration number open for subsequent transactions, select D - No .

- To complete the registration number, select C - Yes .

- Select the appropriate option:

- If the client is not requesting that parental benefits start after maternity benefits, select Update .

- If the client is requesting that parental benefits start after maternity benefits, select Store .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2762.dita)

- Determine if a child for whom maternity benefits are being requested was hospitalized during the maternity window:

- If yes, go to step 4.

- If no and the client is not requesting that parental benefits start after maternity benefits, go to step 5.

- If no and the client is requesting that parental benefits start after maternity benefits, refer to Converting a claim from maternity to parental benefits .
               [Converting a claim from maternity to parental benefits](/en/procedure/task/conv_matpar.shtml)

- In FTS, to extend the maternity window, select the Additional Data (M107) transaction and enter the extended maternity window end week as follows:

- Registration number: Select the appropriate registration number.

- External Maternity —End week: Enter the extended maternity window end week.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To leave the registration number open for subsequent transactions, select D - No .

- To complete the registration number, select C - Yes .

- Select the appropriate option:

- If the client is not requesting that parental benefits start after maternity benefits, select Update . Go to step 5.

- If the client is requesting that parental benefits start after maternity benefits, select Store and refer to Converting a claim from maternity to parental benefits .
                   [Converting a claim from maternity to parental benefits](/en/procedure/task/conv_matpar.shtml)

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement or definite disqualification is being input manually.

- If there are decisions that must be communicated to the client, go to step 6.

- If there are no decisions that must be communicated to the client, go to step 7.

- In ACS, create and send or add to the saved N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following if not already input and the situation applies.

- Renewal week - Sunday’s date (1246) .

- If an antedate has been denied: Select Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Select Antedate Denied (2483) .

- Special benefits approved (3046): Select Maternity and/or Parental benefits (standard/extended) approved or denied with sickness options (3054) .

- If there is an allocation: Select Allocation of Earnings (2516)

- Waiting period messages (2445): Select the appropriate option.

- Complete a report - General message or for sickness benefits (3091) .

- In NWS, determine if the conversion application was submitted using AW:

- If no go to step 8.

- If yes, go to Subsequent claim s.
               [Subsequent claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#subsequent_claims)

- Complete the CA WI. 

#### Conversion on a renewal claim — Outstanding adjudication

Source topic: `en_EN/task/conv_sickmat/conversion_on_a_renewal_claim__outstand_c972fb4d_level_1.dita`

- In FTS, select the Renewal / Revised (M106) transaction and input the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week in which the client wants the maternity benefits to start being paid.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select 4 - Maternity / parental.

- If the LRW has been reached, Notify system to: Select E - Accept a renewal week effective after the last renewable week of the benefit period .

- Select the Special benefits (M106) link and enter the following in the Maternity section (if the confinement week has not already been entered):

- Confinement: Enter the expected or actual DOB.

- Select Save .

- No claimant’s report: Check the box (if requested by the client).

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To leave the registration number open for subsequent transactions, select D - No .

- To complete the registration number, select C - Yes .

- Select the appropriate option:

- If the client is not requesting parental benefits to start after maternity benefits, select Update .

- If the client is requesting parental benefits to start after maternity benefits, select Store .

- Select the Additional Data (M107) transaction and enter the external maternity start date as follows:

- Registration number: Select the appropriate registration number.

- External Maternity — Start week: Enter the week in which the client wants the maternity benefits to start being paid.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To leave the registration number open for subsequent transactions, select D - No .

- To complete the registration number, select C - Yes .

- Select the appropriate option:

- If the client is not requesting that parental benefits start after maternity benefits, select Update .

- If the client is requesting that parental benefits start after maternity benefits, select Store .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2762.dita)

- Determine if a child for whom maternity benefits are being requested was hospitalized during the maternity window:

- If yes, go to step 4.

- If no and the client is not requesting that parental benefits start after maternity benefits, go to step 5.

- If no and the client is requesting that parental benefits start after maternity benefits, refer to Converting a claim from maternity to parental benefits .
               [Converting a claim from maternity to parental benefits](/en/procedure/task/conv_matpar.shtml)

- In FTS, to extend the maternity window, select the Additional Data (M107) transaction and enter the extended maternity window end week as follows:

- Registration number: Select the appropriate registration number.

- External Maternity —End week: Enter the extended maternity window end week.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To leave the registration number open for subsequent transactions, select D - No .

- To complete the registration number, select C - Yes .

- Select the appropriate option:

- If the client is not requesting that parental benefits start after maternity benefits, select Update . Go to step 5.

- If the client is requesting that parental benefits start after maternity benefits, select Store and refer to Converting a claim from maternity to parental benefits .
                   [Converting a claim from maternity to parental benefits](/en/procedure/task/conv_matpar.shtml)

- Determine any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement or definite disqualification is being input manually.

- If there are decisions that must be communicated to the client, go to step 6.

- If there are no decisions that must be communicated to the client, go to step 8.

- In ACS, create and save or add to the saved the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following if not already input and the situation applies.

- Renewal week - Sunday’s date (1246) .

- If an antedate has been denied: Select Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Select Antedate denied (2483) .

- Special benefits approved (3046): Select Maternity and/or Parental benefits (standard/extended) approved or denied with sickness options (3054) .

- If there is an allocation: Select Allocation of Earnings (2516) .

- Waiting period messages (2445): Select the appropriate option.

- Complete a report - General message or for sickness benefits (3091) .

- In NWS, create a client Note and type “Send N-00-00-00 letter.”

- Determine if the conversion application was submitted using AW:

- If no go to step 9.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickmat#subsequent_claims)

- Complete the CA WI. 

#### Subsequent claims

Source topic: `en_EN/task/conv_sickmat/subsequent_claims_level_1.dita`

- Determine if there are 4 weeks or fewer of benefits payable remaining in the BP:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the renewal was finalized 28 calendar days after the renewal application was submitted (i.e. application date + 27 days) or if the Status field on the Summary tab in FTS displays 8 - Converted to Manual Pay:

- If yes, go to step 3.

- If no, go to step 4.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Subsequent claim not automated.”

- Due date: Select the [LRW + 3 weeks].

- Language: Select the appropriate option.

- Details: Type “Subsequent claim to be established.”

- Destination— SCC: Select the SCC as shown in FTS.

- End User: Select Next available user .

- Complete the CA WI. 

#### Reassigning the WI

Source topic: `en_EN/task/conv_sickmat/reassigning_the_wi_level_1.dita`

- In NWS, reassign the WI related to the conversion and the following related WIs, if necessary (CB, AI and REM) as follows:

- Destination: Select Level 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC/QPIP .

- Reason: Select Unable to complete .

- Details: Type “Decision required to determine whether EI or QPIP applies.”

- Select OK .

- No further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2802.dita`

- The client was incarcerated and has since been tried and has not been found guilty.

- The client received WCB payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid. 

#### Note

Source topic: `en_EN/common_notes/note_c_2721.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose an MA1 to stop payment. 

#### Note

Source topic: `en_EN/common_notes/note_c_2757.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, 420 hours of insurable employment is required to establish a claim for regular or special benefits, regardless of the conversion date. If the client has 420 or more insurable hours, select the major attached option. 

#### Note

Source topic: `en_EN/common_notes/note_c_2755.dita`

Note:

When maternity benefits are requested, if an RFS indicated on the related ROE or declared by the client in the EI application is P - Parental , additional fact-finding is required. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2771.dita`

“you have received the maximum number of benefit weeks payable to you during this benefit period. The maximum number of benefit weeks paid on this claim cannot exceed a total of [maximum number of regular and special benefit weeks that can be paid] weeks.

To receive benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you must apply for a new claim.” 

#### Callout

Source topic: `en_EN/common_notes/note_c_2803.dita`

“We cannot reactivate your claim for Employment Insurance benefits starting [Renewal week - Sunday’s date] . Please note that we are required to advise you of all decisions made on your claim.

No maternity benefits are payable to you on this claim because the last renewable week has been reached on this benefit period.

To receive maternity benefits, you must work the required minimum number of insurable employment hours. If you want to receive maternity benefits in the future, you must apply for a new claim.” 

#### Note

Source topic: `en_EN/common_notes/note_c_2761.dita`

Note:

When the maternity window includes a period where the client received another BT, enter the date equal to the renewal week in the External Maternity — Start week field . 

#### Note

Source topic: `en_EN/common_notes/note_c_2762.dita`

Note:

When the maternity window includes a period where the client received a different BT, enter the date equal to the renewal week in the External Maternity — Start week field . 

## Policy reference

Source topic: `en_EN/task/conv_sickmat/policy_reference.dita`

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- EIA 22(1)
         [EIA 22(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-22.html)

- BE 2016-02 — Bill C-15 Additional weeks of benefits
         [BE 2016-02 — Bill C-15 Additional weeks of benefits](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2016-02.shtml) 
