# Determining if additional information or processing time is required to calculate a claim

Source map: `en_EN/task/calc_determining/missing_information/missing_information.ditamap`

## Summary

Source topic: `en_EN/task/calc_determining/missing_information/summary.dita`

Summary: Before calculating a claim, the officer determines if additional information or processing time is required. 

## What you need to know

Source topic: `en_EN/task/calc_determining/missing_information/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/missing_information/untitled_section.dita`

The officer must review the notes made while reviewing the claim file to determine if all facts required to complete the calculation are on file. 

### Determining if additional information is required

Source topic: `en_EN/task/calc_determining/missing_information/determining_if_additional_information_i_6a7c3e74.dita`

The client may not have provided all of the information needed to calculate the claim. In addition, some information already provided may require clarification, either from the client or the employer. When additional information or clarification is required, fact-finding is required.

The individual procedures provide instructions on who to contact to obtain the information. As a rule, these instructions must be followed, but the officer must also use their experience and judgment. For example, if the officer is instructed to contact the client for a piece of information directly related to the ROE and the officer also needs to speak with the employer about another issue, it is acceptable to request the information from the employer. The employer may be able to quickly provide the information the officer needs, saving an additional telephone call to the client.

When contacting the employer about an issue with the ROE, the officer must speak to the person who issued the ROE. If the issue is the reason for separation (RFS), contact the client’s direct supervisor if possible, because the supervisor is more likely to know why the client is no longer working. 

### Determining if additional processing time is required

Source topic: `en_EN/task/calc_determining/missing_information/determining_if_additional_processing_ti_8174bd2d.dita`

When no additional fact-finding is required, the officer determines if the claim can be calculated.

If all of the required information is on file, the officer can calculate the claim.

If all of the required information is not on file or if another task has advised the officer to move the calculation WI to Pending, the officer moves the WI to Pending. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

## Regional considerations

Source topic: `en_EN/task/calc_determining/missing_information/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_determining/missing_information/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/missing_information/untitled_section.dita`

The officer must review the notes made while reviewing the claim file to determine if all facts required to complete the calculation are on file. 

## Step by step

Source topic: `en_EN/task/calc_determining/missing_information/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_determining/missing_information/level_1.dita`

#### Determining if fact-finding is required

Source topic: `en_EN/task/calc_determining/missing_information/determining_if_fact-finding_is_required_level_1.dita`

- Determine from the notes made while reviewing the claim file if there are any issues that require clarification or correction, or if there is any missing information:

- If yes, go to step 2.

- If no, go to Determining if additional processing time is required .
               [Determining if additional processing time is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_information#_Determining_if_additional)

- Determine if only the client needs to be contacted:

- If no, go to step 3.

- If yes, go to step 10. 

#### Fact-finding with the employer

Source topic: `en_EN/task/calc_determining/missing_information/fact-finding_with_the_employer_level_1.dita`

- Fact-find with the employer.

- Determine if the employer was reached during fact-finding:

- If yes, go to step 5.

- If no, go to step 6.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select the issue you called about or Other , if the issue is not in the menu.

- Comments: Enter the details as follows:

- If Other is selected in the Issue field, enter the issue you called about.

- Enter the details about the issue and if necessary, about the person you called.

- Details : Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Go to step 9.

- Determine if the issue is for ROE verification:

- If the issue is not for ROE verification, go to step 7.

- If the issue is for ROE verification, refer to Correcting an error during calculation or recalculation — Regular ROE and then go to step 9.
               [Correcting an error during calculation or recalculation — Regular ROE](/en/procedure/task/correcting_roe_error_calculation_regular.shtml)

- Determine if the client could possibly provide the required information:

- If the client cannot provide the required information, go to step 8.

- If the client can provide the required information, go to step 10.

- Determine if the claim can be processed without the information from the employer:

- If the claim can be processed, go to step 9.

- If the claim cannot be processed, send an enquiry to your Business Expertise Advisor to determine your next steps before going to step 9.

- Determine if fact-finding with the client is required:

- If fact-finding is required, go to step 10.

- If fact-finding is not required, go to Determining if additional processing time is required .
               [Determining if additional processing time is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_information#_Determining_if_additional) 

#### Fact-finding with the client

Source topic: `en_EN/task/calc_determining/missing_information/fact-finding_with_the_client_level_1.dita`

- Fact-find with the client.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2278.dita)

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 12.

- If the client was not reached , go to step 13.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main issue: Select the issue you called about or Other , if the issue is not in the menu.

- Comments: Enter the details as follows:

- If Other is selected in the Issue field, type the issue you called about.

- Type the details about the issue and if necessary, about the person you called.

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Go to Determining if additional processing time is required .
               [Determining if additional processing time is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_information#_Determining_if_additional)

- Determine if the information could be obtained from the employer:

- If no, on the calculation worksheet, note that a 15 - Claim Procedure (D15) transaction is required when the final claim input is done and go to Determining if additional processing time is required .
               [Determining if additional processing time is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_information#_Determining_if_additional)

- If yes, determine if the client was contacted because the employer could not be contacted:

- If yes, go to step 14.

- If no, go back to step 3 noting that if the employer cannot provide the information, a 15 - Claim Procedure disentitlement (D15) transaction is required when the final claim input is done.

- Determine if the claim can be finalized with the facts on file:

- If yes, go to Determining if additional processing time is required .
               [Determining if additional processing time is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_information#_Determining_if_additional)

- If no, send an enquiry to your business expertise advisor to determine your next steps. Go to Determining if additional processing time is required .
               [Determining if additional processing time is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_information#_Determining_if_additional) 

#### Determining if additional processing time is required

Source topic: `en_EN/task/calc_determining/missing_information/determining_if_additional_processing_ti_8174bd2d_level_1.dita`

- Determine if you have obtained all the facts required to calculate the claim:

- If yes, go to step 16.

- If no, go to step 17.

- Determine if another task requires to move the calculation WI to pending:

- If yes, go to step 17.

- If no, go to Calculating the claim .
               [Calculating the claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_information#_Calculating_the_claim)

- In NWS, move the WI to Pending as follows:

- Pending reason : Select the appropriate reason.

- Comments : Type a brief description of what you are awaiting.

- Bring forward date : Select the appropriate option:

- If another task has told you to move the calculation WI to pending, enter the bring forward date previously indicated.

- If you have not obtained all the facts required to calculate the claim, enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if the pending date has been reached:

- If no, move the WI back to Pending as follows:

- Use previous information : Check the box.

- Repeat step 18 until the pending date is reached. Go to Calculating the claim .
                   [Calculating the claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_information#_Calculating_the_claim)

- If yes, go to Calculating the claim .
               [Calculating the claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_information#_Calculating_the_claim) 

#### Calculating the claim

Source topic: `en_EN/task/calc_determining/missing_information/calculating_the_claim_level_1.dita`

- Determine the benefit type (BT) requested for the calculation:

- If the BT is regular, return to Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, return to Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, return to Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, return to Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, return to Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, return to Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, return to Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2278.dita`

Note:

When the recalculation of a claim results in an established claim with an earlier BPC, claimant’s reports for the complete period from the new BPC to the old BPC could be required. If the information on file indicates this could happen and fact-finding with the client is required, obtain the claimant’s report information. This reduces the need to contact the client a second time. 

## Policy reference

Source topic: `en_EN/task/calc_determining/missing_information/policy_reference.dita`

 
