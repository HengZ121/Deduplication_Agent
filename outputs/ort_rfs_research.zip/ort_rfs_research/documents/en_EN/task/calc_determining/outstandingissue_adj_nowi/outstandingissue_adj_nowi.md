# Reviewing an outstanding issue with no Adjudication Issue WI

Source map: `en_EN/task/calc_determining/outstandingissue_adj_nowi/outstandingissue_adj_nowi.ditamap`

## Summary

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/summary.dita`

Summary: Contentious issues may affect the claim calculation. All potential issues must therefore be identified and adjudicated before the claim is calculated. 

## What you need to know

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Identifying contentious issues

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/identifying_contentious_issues.dita`

The officer calculating the claim must identify outstanding contentious issues and ensure they are adjudicated.

When ACP identifies possible issues requiring adjudication on an initial online application, it creates an Adjudication Issue (ADJ) WI. ACP does not create WIs to adjudicate contentious issues on paper applications. In these cases, the appropriate WIs are manually created for the contentious issues. All ADJ WIs must be completed before the claim can be calculated.

While fact-finding on another issue or reviewing the documents on file, the officer completing the calculation of the claim may identify contentious issues for which there is no WI.

When an issue requiring adjudication is identified on an initial claim or during recalculation and there is no outstanding WI for that issue, the officer creates the appropriate WI and either adjudicates the issue or reassigns the WI to a Level 2 officer for adjudication before calculating or recalculating the claim.

     [Examples](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2284.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2285.dita) 

### Recalculating a BPNE claim

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/recalculating_a_bpne_claim.dita`

When a client does not meet the entrance requirements, a benefit period (BP) cannot be established and the claim is finalized BPNE. If it is necessary to manually create a Claim Review (CR) WI on a claim that was finalized BPNE, reassign the CR WI to the Revised BPNE level. 

### Reviewing the file for an implied antedate

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/reviewing_the_file_for_an_implied_antedate.dita`

Clients who file a claim for special benefits more than 4 weeks after the last day worked (LDW) are asked why they delayed in filing. Clients can imply that they are requesting an antedate in their response to the question on the EI application. A client’s response can be considered an antedate request without having to submit a formal antedate request when the only reason for delay is one of the following:

- The client was receiving, or waiting to receive, payment from an employer or from another insurer or payer, which includes incapacity payments and severance or termination payments.

- The client was ill or injured and physically unable to apply.

- The client was providing care or support for an ill family member.

- The client was providing care or support for a critically ill or injured patient.

Although implied antedates occur most commonly on special benefits claims because the question about the delay is asked on the application, if the information on file about the delay is identical, claims for other benefit types (BTs) are treated in the same manner.

If there is any information on file indicating that the application was submitted late for more than one reason or for any other reason than those listed above, this is not considered an implied antedate request. In this situation, no further action is taken regarding the filing delay and no WI is created unless the client submits a formal antedate request. 

### Reason for separation (RFS) — Temporary budget measures

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**Contentious reason for separation (RFS) issues on claims with a BPC between w/c 2310 and 2361**

As part of Budget 2021, a temporary simplification measure has been introduced on September 26, 2021. If the last period of employment on the application has a contentious RFS, an ADJ WI is created. If there are other periods of employment with a contentious RFS, ACP automatically resolves the issue and creates a record of decision (ROD) indicating Adjudication not required .

When the last RFS is not allowed, but there is another period of employment with the same last day paid (LDP) and a contentious RFS that has been automatically resolved, that employment now requires adjudication. Since the RFS issue was initially automatically resolved, a Claim Assessment (CA) WI is created and processing activities in NWS display a message indicating that the last ROE requires adjudication. The officer amends the decision on the automatically resolved ROD, which results in the creation of an ADJ WI. If the ADJ WI is not automatically assigned to the officer but is within Level 1 authority, the officer assigns the ADJ WI to him or herself and adjudicates the contentious RFS. If the issue cannot be adjudicated, the officer documents the facts in an SROC and reassigns the ADJ WI to Level 2.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2286.dita) 

**Contentious reason for separation (RFS) issues on claims with a BPC between w/c 2258 and w/c 2309**

Effective September 27, 2020, the specialized ACP process considers all RFS issues in the QP on regular or sickness claims with a BPC between w/c 2258 and w/c 2309 as non-contentious. If the officer identifies contentious RFS issues in the QP when reviewing the calculation or recalculation of a claim for regular or sickness benefits with a BPC between w/c 2258 and w/c 2309, the officer does not create a WI or adjudicate the contentious RFS. If the ROE is on file, the officer leaves the Special condition field on the ROE blank. SSO will consider these ROEs as non-contentious and include them in the calculation or recalculation of the claim.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2287.dita) 

The officer continues to follow normal procedures for all other benefit types (BTs) by creating a WI if adjudication of a contentious RFS issue is required. If the officer identifies a contentious RFS issue on a renewal or continuing claim, regardless of the BPC, the officer follows normal procedures and creates the WI to adjudicate the issue.

If the officer identifies any other contentious issue for which there is no outstanding WI, the officer follows normal procedures. The officer creates the appropriate WI and either adjudicates the issue or reassigns the WI to a Level 2 officer for adjudication before calculating or recalculating the claim. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the RFS was undisclosed on a previous claim, and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Examples

Source topic: `en_EN/common_notes/note_c_2284.dita`

Examples:

The following are examples of contentious issues that may be identified when there is no related WI:

- voluntary leaving

- dismissal

- availability

- vacation

- out of Canada

- training

- self-employment

- jury duty

- antedate (implied or formally requested)

- not otherwise available 

### Note

Source topic: `en_EN/common_notes/note_c_2285.dita`

Note:

From August 9, 2021, to September 11, 2021, the system does not create ADJ WIs on initial claims for the following issues:

- Farming

- Self-employment

- Teacher

During this period, the officer is not expected to identify, create WIs for or adjudicate these contentious issues when establishing an initial claim. However, if the client subsequently declares farming, self-employment or teaching during fact-finding on another issue or on reports (during processing of the initial claim or during the benefit period), normal adjudication and reconsideration procedures apply. 

### Note

Source topic: `en_EN/common_notes/note_c_2286.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the qualifying period (QP) . Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Note

Source topic: `en_EN/common_notes/note_c_2287.dita`

Note:

The specialized ACP process ended on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating these issues. If the officer identifies any other contentious issue for which there is no outstanding WI, the officer follows normal procedures. The officer creates the appropriate WI and adjudicates or reassigns the issue. 

## Regional considerations

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/what_you_need_to_look_for.dita`

## Step by step

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/reviewing_the_file_level_1.dita`

- Determine if there is an issue that requires adjudication, but for which there is no WI:

- If yes, go to step 2.

- If no, go to No outstanding issues .
               [No outstanding issues](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/outstandingissue_adj_nowi#_No_outstanding_issues)

- Determine if this is an initial calculation or a recalculation:

- If this is an initial calculation, go to Outstanding issue on an initial calculation .
               [Outstanding issue on an initial calculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/outstandingissue_adj_nowi#_Initial_calculation)

- If this is a recalculation, go to Outstanding issue on a recalculation .
               [Outstanding issue on a recalculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/outstandingissue_adj_nowi#recalc) 

#### Outstanding issue on an initial calculation

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/outstanding_issue_on_an_initial_calculation_level_1.dita`

- Determine if one of the outstanding issues requiring adjudication for which there is no WI is a formal or implied antedate:

- If yes, go to step 2.

- If no, go to step 3.

- In NWS, create an Action Item (AI) WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Myself .

- Category: Select Pay affected .

- Issue: Select Antedate .

- BPC: Enter the BPC.

- Comments: Type “Antedate or implied antedate — adjudication required.”

- Details: Enter the details of the antedate request that requires adjudication.

- Determine if one of the outstanding issues requiring adjudication for which there is no WI is an RFS issue in the QP:

- If yes, go to step 4.

- If no, go to step 6.

- Determine if the BPC is between w/cs 2310 and w/c 2360 and if the processing activities in NWS display the UIC warning – Last ROE requires adjudication :

- If no, go to step 5.

- If yes, open the corresponding RFS issue (i.e. the automatically resolved ROD with Adjudication not required ) and, in the Decision Options menu, select Amend decision . Select OK and go to step 8.

- Determine if the BPC is between w/c 2258 and w/c 2309, and if the client is requesting regular or sickness benefits:

- If no, go to step 6.

- If yes, go to step 8.

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 7.

- If yes, determine if the issue must be referred to Integrity by referring Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- In NWS, for each issue requiring adjudication for which there is no WI, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Check the appropriate box based on the issue.

- Complete any mandatory fields required for the issue type.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2288.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2289.dita)

- Determine the BT requested for the initial calculation:

- If the BT is regular, refer to step 15 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 15 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 15 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 15 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 15 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 15 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 15 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Outstanding issue on a recalculation

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/outstanding_issue_on_a_recalculation_level_1.dita`

- In NWS, determine if one of the outstanding issues requiring adjudication for which there is no WI is a formal or implied antedate:

- If yes, go to step 2.

- If no, go to step 3.

- Create an AI WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Category: Select Pay affected .

- Issue: Select Antedate .

- BPC: Enter the BPC.

- Comments: Type “Antedate or implied antedate — adjudication required.”

- Details: Enter the details of the antedate request that requires adjudication.

- Determine if one of the outstanding issues requiring adjudication for which there is no WI is an RFS issue in the QP:

- If yes, go to step 4.

- If no, go to step 6.

- Determine if the BPC is between w/cs 2310 and w/c 2360 and if the processing activities in NWS display the UIC warning – Last ROE requires adjudication :

- If no, go to step 5.

- If yes, open the corresponding RFS issue (i.e. the automatically resolved ROD with Adjudication not required ) and, in the Decision Options menu, select Decision no longer valid . Select OK and go to step 7.

- Determine if the BPC is between w/c 2258 and w/c 2309, and if the client is requesting regular or sickness benefits:

- If no, go to step 6.

- If yes, go to step 12.

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 7.

- If yes, determine if the issue must be referred to Integrity by referring Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- For each issue requiring adjudication for which there is no WI, create a CR WI as follows:

- Type: Select Revised .

- Issue: Select the appropriate issue.

- Registration number: Type the recalculation registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- Date of registration: Enter the date of the recalculation registration.

- Reassign each CR Revised WI as follows:

- Destination: Select Myself .

- Reason: Select Related work item .

- Details: Enter the details of the contentious issue that requires adjudication.

- Determine the destination for the WI and if the claim was previously finalized as BPNE:

- If you are assigning each WI to the next available officer and the claim was previously finalized as BPNE, go to step 10.

- If you are assigning each WI to the next available officer and the claim was not previously finalized as BPNE, go to step 11.

- If you will complete each WI yourself, go to step 12.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2290.dita)

- Reassign each CR Revised WI as follows:

- Destination: Select the Revised BPNE level.

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Enter the details of the contentious issue that requires adjudication.

- Go to step 12.

- Reassign each CR Revised WI as follows:

- Destination: Select Next Available User .

- Reason: Select Unable to complete .

- Details: Enter the details of the contentious issue that requires adjudication.

- Determine the BT requested for the recalculation:

- If the BT is regular, refer to step 15 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 15 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 15 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 15 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 15 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 15 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 15 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### No outstanding issues

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/no_outstanding_issues_level_1.dita`

- Determine the BT requested for the recalculation:

- If the BT is regular, refer to step 15 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 15 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 15 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 15 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 15 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 15 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 15 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2288.dita`

Note:

If there is a contentious RFS issue in the QP on an initial claim with a tentative BPC of w/c 2361 or later for which there is no WI, create the appropriate WI to adjudicate the issue. 

#### Note

Source topic: `en_EN/common_notes/note_c_2289.dita`

Note:

The appropriate adjudication task indicates if the issue can be adjudicated at Level 1 or if it must be reassigned to Level 2 

#### Note

Source topic: `en_EN/common_notes/note_c_2290.dita`

Note:

The appropriate adjudication task indicates if the issue can be adjudicated at Level 1 or if it must be reassigned to Level 2. 

## Policy reference

Source topic: `en_EN/task/calc_determining/outstandingissue_adj_nowi/policy_reference.dita`

 
