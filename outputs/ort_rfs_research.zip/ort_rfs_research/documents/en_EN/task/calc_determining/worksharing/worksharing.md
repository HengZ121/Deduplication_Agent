# Determining if a client without a reference code is part of a Work-Sharing program

Source map: `en_EN/task/calc_determining/worksharing/worksharing.ditamap`

## Summary

Source topic: `en_EN/task/calc_determining/worksharing/summary.dita`

Summary: When Work-Sharing (WS) clients apply for benefits without providing the reference code for the WS program, the officer determines if they are eligible for benefits under the WS program. 

## What you need to know

Source topic: `en_EN/task/calc_determining/worksharing/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/worksharing/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Work-Sharing (WS) applications

Source topic: `en_EN/task/calc_determining/worksharing/work-sharing_ws_applications.dita`

When applying for EI benefits online, clients are asked if they are part of a group of employees in a WS program and if they were given a reference code to submit their application. If they answer yes, they are prompted to enter the 16-digit code. When they enter the reference code, a specialized application for benefits is presented. If they answer no, they are presented with a regular application for benefits.
       [reference code](/en/procedure/generic/additionalresources/knowledge_reltws.shtml#Reference_Code)

Clients may answer no but also indicate that they are part of a WS program by selecting Work-Sharing as their reason for separation (RFS). Additionally, clients may have a valid reference code but simply not provide it on the application. When a client applies for benefits without a reference code, the officer may need to confirm the details with the regional WS coordinator. If it is later determined that the client is part of a WS program, the officer calculating the claim ensures that a manual action 76 - Automated Work-Sharing (MA76), and if applicable, the exemption from reporting , are imposed on the claim.
       [exemption from reporting](/en/procedure/activity/exemption_reporting.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2336.dita) 

**Work-Sharing (WS) agreement ends beyond the prior BPC + 103**

To continue to receive benefits during the WS agreement, clients whose WS agreements are active when they reach the 104 th week of their BP must reapply for a new initial claim for regular benefits.

This information is provided to the client in a letter that is sent when the former claim is established with a WS end date beyond the 104 th week of the BP.

The letter also informs the client to indicate Work-Sharing as the RFS on the application. The client does not receive a new reference code for this application and the reference code issued at the start of the WS agreement has expired.

The officer who sends the letter also provides the details of the WS agreement in a ROD. The officer notes this information on the calculation worksheet as it is used to complete the Project Data - Work-sharing (M171 ) transaction when the claim calculation is input. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2336.dita`

Note:

If the hours that the client normally worked each week before the WS agreement are not on file, the officer obtains the information during fact-finding with the client, the employer or the regional WS coordinator. 

## Regional considerations

Source topic: `en_EN/task/calc_determining/worksharing/regional_considerations.dita`

WS claims in the Ontario region and a specialized Quebec region are assigned to specialized units for processing. WS claims in the Atlantic region and areas outside the specialized Quebec region are not assigned to specialized units for processing.

If necessary, the officer contacts the appropriate regional WS coordinator or GD mailbox according to the WS claim’s region.

```text
| Region | Contact |

| Atlantic | esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca [esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca](mailto:esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca) |

| Quebec — specialized region | Work-Sharing Reference Tool |

| Quebec — outside specialized region | esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca [esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca](mailto:esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca) |

| Ontario | on-eibp_tpae-worksha@servicecanada.gc.ca [on-eibp_tpae-worksha@servicecanada.gc.ca](mailto:on-eibp_tpae-worksha@servicecanada.gc.ca) |

| Western Canada and the Territories | bc-ipoc_copa-ws_tp-gd@servicecanada.gc.ca [bc-ipoc_copa-ws_tp-gd@servicecanada.gc.ca](mailto:bc-ipoc_copa-ws_tp-gd@servicecanada.gc.ca) |
``` 

## What you need to look for

Source topic: `en_EN/task/calc_determining/worksharing/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/calc_determining/worksharing/in_nws.dita`

- Is there any documentation (SROC, Action Item [AI], or Call Back [CB] WI) indicating that the client is part of a WS program?

- Is there an SROC or AI WI with a transcribed exemption from reporting declaration? 

### In FTS:

Source topic: `en_EN/task/calc_determining/worksharing/in_fts.dita`

- Is this a subsequent claim for WS benefits? 

### In RCM:

Source topic: `en_EN/task/calc_determining/worksharing/in_rcm.dita`

- Does the reason for separation (RFS) on the ROE indicate H - Work-Sharing ? 

## Step by step

Source topic: `en_EN/task/calc_determining/worksharing/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_determining/worksharing/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/calc_determining/worksharing/reviewing_the_file_level_1.dita`

- Determine if the client's reference code or WS agreement details are on file:

- If no, go to step 2.

- If yes, go to Work-Sharing (WS) claim .
               [Work-Sharing (WS) claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/worksharing#_Work-sharing_claim)

- In NWS, determine if additional fact-finding is required to clarify whether the client is part of a WS program:

- If no, go to step 3.

- If yes, go to Fact-finding required .
               [Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/worksharing#_Fact-finding_required_1)

- Determine if the ROE indicates the RFS as H - Work-Sharing:

- If no, go to Not a Work-Sharing (WS) claim .
               [Not a Work-Sharing (WS) claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/worksharing#not_Work-sharing_claim)

- If yes, go to Fact-finding required .
               [Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/worksharing#_Fact-finding_required_1)

- Determine if the client is part of a WS program:

- If no, go to Not a Work-Sharing (WS) claim .
               [Not a Work-Sharing (WS) claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/worksharing#not_Work-sharing_claim)

- If yes, go to Work-Sharing (WS) claim .
               [Work-Sharing (WS) claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/worksharing#_Work-sharing_claim) 

#### Not a Work-Sharing (WS) claim

Source topic: `en_EN/task/calc_determining/worksharing/not_a_work-sharing_ws_claim_level_1.dita`

- Return to step 11 of Determining if a claim is ready to be calculated — Regular benefits . 

#### Work-Sharing (WS) claim

Source topic: `en_EN/task/calc_determining/worksharing/work-sharing_ws_claim_level_1.dita`

- Determine if this is a WS claim from the Quebec or Ontario region.

- If yes, go to step 2.

- If no, go to step 3.

- In NWS, determine if the calculation WI is assigned to the regional WS unit:

- If yes, go to step 3.

- If no, go to step 5.

- In FTS, determine if there is an MA76 imposed on the claim:

- If no, go to step 4.

- If yes, refer to step 11 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- On the calculation worksheet, note that when the calculation of the claim is input, an MA76 must be input on the M103. Also note that, if necessary, the NO-CR-CODE for exemption from reporting must also be input. The client may not have been given the option to request the exemption if the application was completed without a reference code. In this case fact-find with the client and offer the option of exemption from reporting. (Refer to Exemption from reporting .) Go to step 11 of Determining if a claim is ready to be calculated — Regular benefits .

- In NWS, reassign the calculation WI as follows:

- Destination — Level: Select the appropriate option:

- Ontario: 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - ON / Work-Sharing - ON

- Quebec: 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC / Work-Sharing - QC

- Reason: Select Unable to complete .

- Details: Type “Benefit type is not within level of authority.”

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2337.dita) 

#### Fact-finding required

Source topic: `en_EN/task/calc_determining/worksharing/fact-finding_required_level_1.dita`

- On the calculation worksheet, note that you must fact-find with the client, the employer or the regional WS unit, as appropriate, to determine if the client is part of a WS program. If yes, what the normal weekly hours were. Also note that if fact finding does not confirm that the client is part of a WS program and the ROE indicates the RFS as H - Work-Sharing , you will need to contact the employer to determine if there has been an interruption of earnings (I of E) and update the ROE if necessary. Refer to step 11 of Determining if a claim is ready to be calculated — Regular benefits .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2237.dita) 

#### Note

Source topic: `en_EN/common_notes/note_c_2337.dita`

Note:

If the calculation WI is part of a grouping, re-assign all WI that are grouped. 

#### Note

Source topic: `en_EN/common_notes/note_c_2237.dita`

Note:

Once fact-finding is complete, return to this task. 

## Policy reference

Source topic: `en_EN/task/calc_determining/worksharing/policy_reference.dita`

- EIA 24
         [EIA 24](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-24.html)

- EIA 48
         [EIA 48](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-48.html)

- EIA 49
         [EIA 49](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-49.html)

- EIA 50
         [EIA 50](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-50.html)

- Digest 19.2.15—Apprentices
         [Digest 19.2.15—Apprentices](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-19/referred-claimants.html#a19_2_15)

- Digest 16.2.0—Claim required - Section 48 of the Act
         [Digest 16.2.0—Claim required - Section 48 of the Act](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-16/introduction.html#a16_2_0)

- Digest 16.3.0—Proof required – Section 49 of the Act
         [Digest 16.3.0—Proof required – Section 49 of the Act](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-16/introduction.html#a16_3_0)

- Digest 16.4.0—Entitlement to benefits – Section 50 of the Act
         [Digest 16.4.0—Entitlement to benefits – Section 50 of the Act](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-16/introduction.html#a16_4_0) 
