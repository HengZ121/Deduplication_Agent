# Determining if there is an interruption of earnings

Source map: `en_EN/task/calc_determining/interruption_earnings/interruption_earnings.ditamap`

## Summary

Source topic: `en_EN/task/calc_determining/interruption_earnings/summary.dita`

Summary: An interruption of earnings (I of E) is required to establish a benefit period (BP). 

## What you need to know

Source topic: `en_EN/task/calc_determining/interruption_earnings/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/interruption_earnings/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2267.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0887.dita) 

### Interruption of earnings (I of E)

Source topic: `en_EN/task/calc_determining/interruption_earnings/interruption_of_earnings_i_of_e.dita`

To establish a BP, a client must have an I of E from insurable employment during the qualifying period (QP). It is not necessary for the I of E to have occurred during the most recent period of employment. If there is an I of E in the QP, a BP can be established. If there is no I of E, the BP cannot be established.

An I of E occurs when one of the following conditions is met:

- A client has a regular I of E.

- A client has a special I of E.

- A client has an I of E due to Work-Sharing (WS).

**Earnings that prevent an interruption of earnings (I of E)**

All monies that are considered earnings and are allocated for benefit purposes according to EIR 35 and 36 can prevent an I of E except for the following:
       [EIR 35](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-35.html) 
       [36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html)

- separation monies allocated as a result of separation from employment

- workers’ compensation benefits (unless paid in a lump sum or as a pension for full and final settlement)

- wage loss insurance (WLI) — group plan

- pension

- statutory holiday pay when receiving regular benefits

**Regular interruption of earnings (I of E)**

An I of E occurs when a client is laid off or separated from insurable employment and has a period of 7 or more consecutive days without work and without earnings from that employment. This is referred to as a regular I of E.

The 7-day requirement for a regular I of E is deemed to be fulfilled when the employer is reasonably sure that 7 consecutive days of no work and no earnings will occur and thus issues an ROE. The fact that the layoff may turn out to be less than 7 days has no bearing provided the ROE was properly issued.

If the ROE was issued with the expectation that the client would not be called back to work within 7 days, the I of E has occurred.

However, if the client returned to the same employment within 7 days and the claim has not been finalized, the I of E is deemed not to have taken place and the BP is not established unless an I of E has occurred at another time in the QP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2268.dita) 

**Special interruption of earnings (I of E)**

An I of E occurs when a client’s normal weekly earnings (NWE) are reduced by more than 40% and the client stops working due to illness, injury, quarantine, pregnancy, or the need to provide care for a newborn or newly adopted child, or to provide care or support to a family member. This is referred to as a special I of E.

**Work-Sharing (WS) interruption of earnings (I of E)**

An I of E occurs when a client’s NWE are reduced by 10% or more and the client is employed in WS employment. 

### Special situations

Source topic: `en_EN/task/calc_determining/interruption_earnings/special_situations.dita`

The officer reviews the file for special situations when determining if an I of E has occurred.

**Working 2 or more jobs**

A client working for multiple employers must only have an I of E from one employment even if the client continues to work for another employer, as each period of employment is considered individually.

**Reduced hours**

A client who has a reduction in hours (e.g. from full-time to part-time) does not have a regular I of E, unless there is an I of E elsewhere in the QP.

**Two jobs with the same employer**

A client who works at 2 distinct and separate jobs at the same time with one employer is considered to have 2 separate periods of employment with that employer. When there are 7 consecutive days of no work and no earnings from either employment, an I of E exists.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2269.dita) 

**Contract renewal**

A renewal of an expired contract (e.g. term contracts, promotion to a new job, a transfer to another job with the same employer) does not provide a regular I of E unless a period of 7 consecutive days with no work and no earnings occurs.

**Business sold**

When an employee ceases to be employed because the business is sold, an I of E occurs even if the employee’s services are retained by the new owner. A period of 7 consecutive days of no work and no earnings does not have to occur.

**Bankruptcy**

If an employer declares bankruptcy, a regular I of E occurs when the receiver takes over the operation of the business. If an employee continues to work for an employer who declares bankruptcy, a regular I of E does not occur until the employee stops work, even if no wages are paid.

**Compensatory leave**

This type of leave is the result of an employee working a greater number of hours than are normally worked and is entitled to the leave to compensate for the extra time worked. An I of E does not occur until the end of the compensatory leave, regardless of whether the employee is remunerated for the leave.

**Real estate sales**

A regular I of E occurs for a client who holds a provincially issued real estate license and works on commission selling or purchasing real estate when the license is suspended or revoked.

**Commission sales**

A regular I of E for a client employed under a contract of service with earnings consisting mainly of commissions occurs when the contract of service is terminated.

**Period of leave where the pay is deferred**

This is normally referred to as a self-funded leave. No matter how or when the client is paid, an I of E does not occur during the self-financed leave period. Teachers are an exception to this rule.

Even if teachers receive their salary over the non-teaching period, teachers have an I of E at the beginning of the non-teaching period provided it is at least 7 days.

**Preventive withdrawal**

When an employee accepts a lower-paying position to remain employed and is receiving preventative withdrawal payments, the I of E occurs on the last day of work before the beginning of the lower-paid work.

**Pay for a period greater than a week**

When a person is employed under a contract of service where the usual earnings are payable for a period greater than a week, no I of E occurs during the period of the employment contract, regardless of the amount of work performed in the period and regardless of when or how the earning are paid.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2270.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2267.dita`

Note:

When determining if an I of E has occurred, self-employment (SE) and non-insurable employment are not considered. 

### Note

Source topic: `en_EN/common_notes/note_c_0887.dita`

Note:

When fact-finding about an initial calculation or recalculation using a Government of Canada ROE, refer to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2268.dita`

Note:

An I of E is considered to have occurred if an ROE in the QP has at least one pay period containing no earnings or if block 18 of an ROE in the QP indicates a 7-day break in work. If information on file or on an ROE indicates that the client continues to work, fact-finding with the employer may be required.

Fact-finding is not required to determine if a client returned to work before the 7-day break.

If it is later learned that the employer issued the ROE knowing that the client would be called back to work within the 7-day period, the claim could be subject to cancellation, voiding or postdating (if an I of E occurred later). This is usually determined during an investigation by Integrity. 

### Example

Source topic: `en_EN/common_notes/note_c_2269.dita`

Example:

- A client who works 20 hours per week as a grocery store check-out clerk is hired by the same employer to work 10 hours per week as a cleaner.

- The client is subsequently laid off from the cleaning job but the check-out job continues.

The client has an I of E as a result of the layoff from the cleaning job. 

### Example

Source topic: `en_EN/common_notes/note_c_2270.dita`

Example:

The employee is hired to work in insurable employment for the period April 1 to 30. The work was completed a week early, on April 23. No I of E has occurred until April 30. 

## Regional considerations

Source topic: `en_EN/task/calc_determining/interruption_earnings/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_determining/interruption_earnings/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/calc_determining/interruption_earnings/in_nws.dita`

- Is there information on file (documented on an SROC or other WI) showing the client continues to work or continues to receive earnings?

- Is there documentation (SROCs or other) showing the client had an I of E?

- What does the client state is the reason for separation (RFS) from employment? 

### In RCM:

Source topic: `en_EN/task/calc_determining/interruption_earnings/in_rcm.dita`

- What is the RFS on each ROE in the QP?

- Are there any comments on the ROE indicating the client continues to work? 

### In Imaging:

Source topic: `en_EN/task/calc_determining/interruption_earnings/in_imaging.dita`

- Are there imaged letters or other documents regarding any break in work? 

## Step by step

Source topic: `en_EN/task/calc_determining/interruption_earnings/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_determining/interruption_earnings/level_1.dita`

#### Determining if there is insurable employment in the qualifying period (QP)

Source topic: `en_EN/task/calc_determining/interruption_earnings/determining_if_there_is_insurable_emplo_0464cc22_level_1.dita`

- Determine if the client has insurable employment in the QP:

- If no, go to step 2.

- If yes, go to step 4.

- Determine if the client qualifies for a QP extension (refer to Reviewing for a possible qualifying period extension ):

- If yes, go to step 3.

- If no, go to step 13 of the initial task.

- Determine if the client has insurable employment in the extended QP:

- If yes, go to step 4.

- If no, go to step 13 of the initial task. 

#### Determining if there is an interruption of earnings (I of E)

Source topic: `en_EN/task/calc_determining/interruption_earnings/determining_if_there_is_an_interruption_3f90f2a7_level_1.dita`

- In RCM, determine if the RFS on the last ROE is WS:

- If yes, go to step 5.

- If no, go to step 6.

- Determine if the client’s earnings were reduced by more than 10% of the average NWE when the client was employed in WS employment:

- If no, go to step 6.

- If yes, the client has had an I of E. Go to Interruption of earnings (I of E) .
               [Interruption of earnings (I of E)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/interruption_earnings#_Client_has_an)

- In RCM, determine if an ROE indicates that the client has had a lay off or separation from employment during the QP:

- If yes, go to step 7.

- If no, go to step 8.

- Determine if a regular I of E has occurred from at least one of the ROEs showing a layoff or separation during the QP (i.e. 7 days of no work and no earnings):

- If no, go to step 8.

- If yes, the client has had an I of E. Go to Interruption of earnings (I of E) .
               [Interruption of earnings (I of E)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/interruption_earnings#_Client_has_an)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2271.dita)

- In RCM, determine if an ROE indicates the client ceased working during the QP due to illness, injury, quarantine, pregnancy, or the need to provide care for a new born or adopted child, or to provide care or support to a family member:

- If yes, go to step 9.

- If no, go to step 10.

- Determine if the client’s earnings were reduced by more than 40% of the average NWE when the client ceased to work due to illness, injury, quarantine, pregnancy, or the need to care for a new born or adopted child, or to provide care or support to a family member:

- If no, fact-finding is required to verify if there has been an I of E. Go to step 10.

- If yes, the client has had an I of E. Go to Interruption of earnings (I of E) .
               [Interruption of earnings (I of E)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/interruption_earnings#_Client_has_an)

- Determine if there is an ROE in the QP which requires fact-finding with the employer to verify if an I of E has occurred during the QP (e.g. the ROE indicates the client continues to work or information on file indicates the client received workers’ compensation benefits or WLI monies during the period of employment):

- If no, go to step 11.

- If yes, go to step 12.

- Determine if fact-finding with the client has occurred to verify if there has been an I of E:

- If no, go to step 12.

- If yes, go to No interruption of earnings (I of E) .
               [No interruption of earnings (I of E)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/interruption_earnings#noIOE)

- On your calculation worksheet, note that fact-finding with the client or the employer is required to determine if there has been an I of E.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2237.dita)

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 10 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 10 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 10 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 10 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 10 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 10 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 10 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Interruption of earnings (I of E)

Source topic: `en_EN/task/calc_determining/interruption_earnings/interruption_of_earnings_i_of_e_level_1.dita`

- Determine if the client is continuing in employment:

- If yes, go to step 2.

- If no, go to step 3.

- On the calculation worksheet, note that an ROE is required for the continuing employment.

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 10 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 10 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 10 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 10 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 10 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 10 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 10 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### No interruption of earnings (I of E)

Source topic: `en_EN/task/calc_determining/interruption_earnings/no_interruption_of_earnings_i_of_e_level_1.dita`

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “No interruption of earnings.”

- Details: Type “An interruption of earnings has not occurred.”

- Refer to Indicating in SSO that there is no interruption of earnings .
               [Indicating in SSO that there is no interruption of earnings](/en/procedure/task/calc_calculating/no_interruption_earnings.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2271.dita`

Note:

If an ROE was issued with the expectation that the client would not be called back to work within 7 days, an I of E has occurred. However, if the client returned to the same employment within 7 days and the claim has not been finalized, the I of E is deemed not to have taken place. The BP is not established unless an I of E has occurred at another time in the QP. 

#### Note

Source topic: `en_EN/common_notes/note_c_2237.dita`

Note:

Once fact-finding is complete, return to this task. 

## Policy reference

Source topic: `en_EN/task/calc_determining/interruption_earnings/policy_reference.dita`

- EIR 14
         [EIR 14](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-14.html)

- EIR 35
         [EIR 35](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-35.html)

- EIR 36
         [EIR 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html)

- Digest 2 — Interruption of earnings
         [Digest 2 — Interruption of earnings](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-2/table-of-contents.html) 
