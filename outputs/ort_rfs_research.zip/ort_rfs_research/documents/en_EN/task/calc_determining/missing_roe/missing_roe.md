# Reviewing information for a missing ROE

Source map: `en_EN/task/calc_determining/missing_roe/missing_roe.ditamap`

## Summary

Source topic: `en_EN/task/calc_determining/missing_roe/summary.dita`

Summary: The client has not provided the ROEs for all of the employment in the qualifying period (QP). 

## What you need to know

Source topic: `en_EN/task/calc_determining/missing_roe/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/missing_roe/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2279.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Determining if an ROE is missing

Source topic: `en_EN/task/calc_determining/missing_roe/determining_if_an_roe_is_missing.dita`

The officer reviews both:

- the Incomplete workload in RMDS to determine if the ROE is waiting to be input;

- the Uploaded Documents tab in NWS to determine if an ROE or other proof of employment has been uploaded.

If the ROE is not in the Incomplete workload or on the Uploaded Documents tab, the officer reviews Imaging to determine if the ROE is on file but not input in RCM.

If a client reports being unable to obtain an ROE and provides a statement to that effect, or in those rare cases where the officer requests proof of employment, such as pay stubs or time sheets, refer to Determining if an interim ROE is required .
       [Determining if an interim ROE is required](/en/procedure/task/determining_interim_roe.shtml)

If the client states that an ROE will not be issued because the employment is not insurable, the officer reviews the insurability of the employment. 

### Calculating the claim with a missing ROE

Source topic: `en_EN/task/calc_determining/missing_roe/calculating_the_claim_with_a_missing_roe.dita`

The officer does not finalize the claim until all ROEs affecting the calculation are on file, or until the calculation WI is due, whichever occurs first.

If the due date of the calculation WI has been reached, the officer finalizes the claim without the missing ROE, even if that means the claim is BPNE. If it is the last ROE that is missing, the claim is finalized BPNE 2 the day before the due date.

If a ruling request has been made to Canada Revenue Agency (CRA) to determine the insurability of a period of employment, and the ROE for that employment is not on file, the officer calculates the claim without that ROE and without creating an interim ROE. When the insurability ruling is received, the claim is reviewed, and recalculated if required.

If the client qualifies for benefits with the ROEs provided, the officer determines if the client has worked enough hours since the last day worked (LDW) of the period of employment covered by the missing ROE to meet the VER.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2280.dita) 

For claims with a BPC of w/c 2362 or later, or w/c 2309 or earlier, the officer imposes a D15 as soon as the claim is established if the client has not worked enough hours since the LDW of the period of employment on the missing ROE to meet the VER. The D15 prevents the payment of benefits until the missing ROE is received and the reason for separation (RFS) is reviewed. 

### Common Entrance Requirement (CER) (from w/c 2310 to w/c 2361)

Source topic: `en_EN/task/calc_determining/missing_roe/common_entrance_requirement_cer_from_wc_02182d12.dita`

As part of Budget 2021, the Government of Canada announced that a common entrance requirement of 420 hours of insurable employment is required to establish a claim for regular or special benefits. If the client has a violation on file, increased entrance requirements may apply. The common entrance requirement applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the common entrance requirement is not based on the regional rate of unemployment (RRU) and the client is not required to meet the VER.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Note

Source topic: `en_EN/common_notes/note_c_2279.dita`

Note:

For an initial calculation or recalculation using a missing Government of Canada ROE, refer to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2280.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, the officer does not impose a 15-Claim Procedure disentitlement (D15) because contentious RFSs in the QP other than the last do not require adjudication. If a violation is on file, the client must meet the increased entrance requirement after the period of employment on the missing ROE.
       [increased entrance requirement](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirement](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

## Regional considerations

Source topic: `en_EN/task/calc_determining/missing_roe/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_determining/missing_roe/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/calc_determining/missing_roe/in_nws.dita`

- What is the due date of the calculation WI?

- What option did the client select on the application for benefits for the ROE Info of the missing ROE?

- Do the SROCs or Action Item (AI) WIs provide a statement of employment or an ROE: INS3166 Request for missing ROE — Form ?
         [ROE: INS3166 Request for missing ROE — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS3166.pdf)

- Is there an AI or Call Back (CB) WI providing other proof of insurable employment?

- Is there an uploaded document on the Uploaded Documents tab (proof of employment or an INS3166 form)? 

### In NWS/RCM:

Source topic: `en_EN/task/calc_determining/missing_roe/in_nwsrcm.dita`

- Is another ROE missing in addition to the last one? 

### IN RMDS:

Source topic: `en_EN/task/calc_determining/missing_roe/in_rmds.dita`

- Is the ROE in the Incomplete workload? 

### In SSO:

Source topic: `en_EN/task/calc_determining/missing_roe/in_sso.dita`

- Does the client qualify using all ROEs present?

- Does the client have sufficient hours since the LDW of the period of employment covered by the missing ROE to be exempt from disqualification? 

### In Imaging:

Source topic: `en_EN/task/calc_determining/missing_roe/in_imaging.dita`

- Has the ROE been imaged?

- Are there any documents that provide proof of insurable employment such as pay stubs or time sheets? 

## Step by step

Source topic: `en_EN/task/calc_determining/missing_roe/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_determining/missing_roe/level_1.dita`

#### Reviewing the file for a missing ROE

Source topic: `en_EN/task/calc_determining/missing_roe/reviewing_the_file_for_a_missing_roe_level_1.dita`

- Determine if each period of employment with a missing ROE was already reviewed:

- If no, go to step 2 to review them.

- If yes, go to step 8.

- Determine if the ROE is in the Incomplete workload in RMDS, the View Documents tab in NWS, or in Imaging:

- If no, go to step 3.

- If yes, do one of the following:

- If the ROE is a regular ROE, go to Entering data from a paper ROE — Regular ROE . Then return to step 1.
                   [Entering data from a paper ROE — Regular ROE](/en/procedure/task/paperroe_regular.shtml)

- If the ROE is a fishing ROE, go to Entering data from a paper ROE — Fishing . Then return to step 1.
                   [Entering data from a paper ROE — Fishing](/en/procedure/task/paperroe_fisher.shtml)

- If the ROE is a laser ROE, go to Entering data from a paper ROE — Laser ROE . Then return to step 1.
                   [Entering data from a paper ROE — Laser ROE](/en/procedure/task/entering_data_paper_roe_laser_roe.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2281.dita) 

#### Determining if the ROE is missing due to insurability

Source topic: `en_EN/task/calc_determining/missing_roe/determining_if_the_roe_is_missing_due_t_bcf9e2e9_level_1.dita`

- In NWS, in the most current Web application, determine if the client indicated the ROE will not be issued because the employment is not insurable:

- If yes, go to step 4.

- If no, go to step 7.

- Determine if the insurability of this employment has already been reviewed:

- If the insurability has not been reviewed, refer to Insurability before continuing.
               [Insurability](/en/procedure/activity/asmt_insurability.shtml)

- If the insurability has been reviewed and the employment is not insurable, go to step 5.

- If the insurability has been reviewed and the employment is insurable, go to step 6.

- If the insurability has been reviewed and an Assessment Issue (ASMT WI) Insurability WI is outstanding, on the calculation worksheet, note that a manual action 73 - Canada Revenue Agency case (MA73) may be required and go to step 5.

- Determine if there are other insurable periods of employment in the QP:

- If yes, go to step 8.

- If no, go to No insurable employment .
               [No insurable employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_roe#_No_insurable_periods)

- Determine if the client has provided other proof of insurable employment:

- If the client has provided other proof, go to step 7.

- If the client has not provided other proof, go to step 8.

- Note on the calculation worksheet that you must determine if an interim ROE applies for the missing ROE. Refer to Determining if an interim ROE is applicable and go to step 8.

- Determine if there are other periods of employment with a missing ROE that need to be reviewed:

- If yes, return to step 1.

- If no, go to Determining if an ROE is still missing .
               [Determining if an ROE is still missing](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_roe#level1_item_3) 

#### Determining if an ROE is still missing

Source topic: `en_EN/task/calc_determining/missing_roe/determining_if_an_roe_is_still_missing_level_1.dita`

- Determine if all required ROEs are now on file:

- If no, go to step 10.

- If yes, go to All ROEs on file .
               [All ROEs on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_roe#_All_ROEs)

- In RCM, determine if the last ROE is missing:

- If no, go to Last ROE on file — Other ROE is missing .
               [Last ROE on file — Other ROE is missing](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_roe#_Last_ROE_not)

- If yes, go to Last ROE is missing .
               [Last ROE is missing](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/missing_roe#_Last_ROE_missing) 

#### No insurable employment

Source topic: `en_EN/task/calc_determining/missing_roe/no_insurable_employment_level_1.dita`

- On the calculation worksheet, note that the claim can be calculated today as BPNE N1.

- Determine the benefit type (BT) requested for the calculation:

- If the BT is regular, refer to step 7 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 7 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 7 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 7 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 7 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 7 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 7 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Last ROE on file — Other ROE is missing

Source topic: `en_EN/task/calc_determining/missing_roe/last_roe_on_file__other_roe_is_missing_level_1.dita`

- In NWS, determine if the due date of the calculation WI has been reached:

- If the WI due date has been reached, on the calculation worksheet, note that if the client qualifies for benefits with the ROEs provided, but the client has not worked enough hours since the LDW of the period of employment covered by the missing ROE to meet the VER, a D15 may apply. Go to step 3.

- If the WI due date has not yet been reached, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2282.dita)

- On the calculation worksheet, note that after the claim review, the calculation WI is moved to Pending until the due date.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2283.dita)

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 7 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 7 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 7 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 7 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 7 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 7 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 7 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Last ROE is missing

Source topic: `en_EN/task/calc_determining/missing_roe/last_roe_is_missing_level_1.dita`

- In NWS, determine if 27 days or more have passed since the client applied (the WI due date minus 1 day has been reached):

- If no, go to step 2.

- If yes, go to step 3.

- On the calculation worksheet, note that after the claim review, the calculation WI is moved to Pending until one day before the due date. Go to step 4.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2283.dita)

- Determine if the last ROE is missing because there is an outstanding insurability ruling:

- If there is an outstanding insurability ruling, on the calculation worksheet, note that the last day worked will need to be changed in SSO to the period of the last insurable employment. Go to step 4.

- If there is no outstanding insurability ruling, on the calculation worksheet, note that the claim can be calculated today without the last ROE. Go to Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 7 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 7 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 7 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 7 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 7 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 7 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 7 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### All ROEs on file

Source topic: `en_EN/task/calc_determining/missing_roe/all_roes_on_file_level_1.dita`

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 7 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 7 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 7 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 7 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 7 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 7 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 7 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2281.dita`

Note:

If the ROE is in Imaging, it can be in the Incomplete workload in RMDS. In this case, go to section 2 of the appropriate data entry procedure to input the ROE in RMDS.
       [data entry](/en/procedure/activity/depd.shtml)

     [data entry](/en/procedure/activity/depd.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2282.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, if there is a missing ROE in the QP, a D15 is not imposed. 

#### Note

Source topic: `en_EN/common_notes/note_c_2283.dita`

Note:

When the WI moves to the active workload, return to this task. 

## Policy reference

Source topic: `en_EN/task/calc_determining/missing_roe/policy_reference.dita`

- EIA 7
         [EIA 7](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-7.html)

- EIA 8
         [EIA 8](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-8.html)

- EIA 48
         [EIA 48](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-48.html)

- EIA 49
         [EIA 49](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-49.html)

- EIA 50
         [EIA 50](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-50.html) 
