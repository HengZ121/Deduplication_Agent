# Reviewing the file for benefits paid or payable from another source

Source map: `en_EN/task/calc_determining/rev_psl_wli/rev_psl_wli.ditamap`

## Summary

Source topic: `en_EN/task/calc_determining/rev_psl_wli/summary.dita`

Summary: When a client applies for EI benefits, the officer determines if the client is receiving or is entitled to receive benefits from another source. 

## What you need to know

Source topic: `en_EN/task/calc_determining/rev_psl_wli/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/rev_psl_wli/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Pilot Project No. 24: Separation monies — w/c 2493 to w/c2572

Source topic: `en_EN/task/calc_determining/rev_psl_wli/pilot_project_no_24_separation_monies___97f46b0b.dita`

A temporary measure under Pilot Project No. 24 applies to separation monies paid due to a separation from employment on claims with a BPC or allocation start date between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). When separation monies are paid for that period, they are not allocated. Separation monies that are not allocated cannot extend a benefit period (BP). This measure applies to all benefit types (BTs) for initial, renewal and continuing claims.

This measure applies to the following monies when paid due to separation:

- vacation pay

- pay in lieu of notice

- severance pay

- retirement allowance and retirement leave credits

- sick leave credits

- closure bonus

- separation and retirement bonus

- settlement payments

To be considered under the temporary measures, one of the following conditions must be met:

- the BPC is between March 30, 2025 (w/c 2493), and October 10 , 2026 (w/c 2572 ).

- the separation monies would otherwise be allocated under EIR 36(9) to 36(11) and the first week of allocation falls within the period beginning March 30, 2025 (w/c 2493) to October 10 , 2026 (w/c 2572 ).
         [EIR 36(9)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285) 
         [36(11)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285)

If neither condition is met, the officer allocates the separation monies using the usual earnings procedures. For more information, including examples, the officer refers to BE Memo BE-2025-05 .
       [earnings](/en/procedure/activity/earnings.shtml) 
       [BE Memo BE-2025-05](/en/policy/bememo/be2025-02.shtml) 

### Budget 2021

Source topic: `en_EN/task/calc_determining/rev_psl_wli/budget_2021.dita`

A Budget 2021 measure applies to separation monies that are reviewed between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361) and are paid due to a temporary layoff or a permanent separation from employment. When separation monies are reviewed during that period, they are not considered earnings and are not allocated, regardless of the BPC. Separation monies that are not allocated cannot extend a benefit period (BP). This measure applies to all benefit types (BTs) for initial, renewal and continuing claims. 

### End of temporary measure

Source topic: `en_EN/task/calc_determining/rev_psl_wli/end_of_temporary_measure.dita`

The Budget 2021 temporary measure under which separation monies were no longer considered earnings expires on September 24, 2022 (w/c 2361). As of September 25, 2022 (w/c 2362), separation monies are again considered earnings and a transitional provision applies to ensure that clients are not penalized by a late review.

New allocations with an allocation start date on or after September 25, 2022 (w/c 2362) apply to initial, renewal and continuing claims and could extend the BP, if necessary. 

### Modifying an existing allocation

Source topic: `en_EN/task/calc_determining/rev_psl_wli/modifying_an_existing_allocation.dita`

When modifying an existing allocation, the rules that applied to that claim when the allocation was initially input still apply. 

### Transitional provision

Source topic: `en_EN/task/calc_determining/rev_psl_wli/transitional_provision.dita`

As of September 25, 2022 (w/c 2362), when reviewing separation monies, if the allocation start date is between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361), monies paid or payable due to a temporary layoff or a permanent separation from employment are not considered earnings and are not allocated. The allocation start date is the date the allocation would start, even if no BP was established for that period.

For more information, officers consult the BE Memo 2022-04 .
       [BE Memo 2022-04](/en/policy/bememo/be2022_04.shtml) 

### Benefits from another source

Source topic: `en_EN/task/calc_determining/rev_psl_wli/benefits_from_another_source.dita`

Clients must apply for benefits from other sources that might otherwise be paid by EI. These sources, which are often referred to as the first payer, include the following:

- paid sick leave (PSL)

- group wage loss insurance (WLI)

- preventive withdrawal payments

- motor vehicle accident insurance

Clients may also apply for benefits from other sources that are not considered to be a first payer. These include the following:

- workers’ compensation benefits (WCB)

- Wage Earner Protection Program (WEPP)

When the client receives payments from another source, the officer refers to Earnings: Determination, allocation and references — Table to determine if the monies are earnings. If the payments are considered earnings, the officer allocates the monies to the period for which they are paid.
       [Earnings: Determination, allocation and references — Table](/en/procedure/generic/additionalresources/eiortjobaid_earn_chart.shtml)

When clients report they are capable of working, but information on file indicates benefits from another source to compensate for loss of income due to an illness or injury are or may be payable, the officer may have to review the clients’ availability to be looking for work. 

### Obligations of employers enrolled in the Premium Reduction Program (PRP)

Source topic: `en_EN/task/calc_determining/rev_psl_wli/obligations_of_employers_enrolled_in_th_5dffdb3d.dita`

When a client stops working for an employer due to illness, injury or quarantine, the officer must verify FTS and determine if the employer is enrolled in the EI Premium Reduction Program (PRP). Employers enrolled in the PRP have been granted a reduction of their EI premiums payable because they have demonstrated that they provide their employees a specific amount of PSL or WLI benefits that meets the standards of the PRP. The details of the specific benefits provided by the employer are available in FTS. Many employers have multiple business numbers. Whenever possible, it is important to search for the employer using the business number indicated on the ROE, as not all business numbers have the same entitlement to employee benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1615.dita) 

If the client is not entitled to the benefits as shown in the details of the plan, the officer fact-finds with the employer to determine why the client is not entitled to the benefits. 

### Client obligations

Source topic: `en_EN/task/calc_determining/rev_psl_wli/client_obligations.dita`

The officer ensures that clients are aware of their obligation to apply for benefits from a first payer, and to notify Service Canada once a decision is rendered.

When a client who is entitled to benefits from a first payer chooses not to apply for those benefits, the benefits to which the client could have been entitled are considered to have been paid for the period for which the monies could have been paid or payable had the client applied to receive them. In this situation, the officer allocates the monies at an amount that is equal to the no benefits payable amount. The same principle applies when the client has applied for benefits but the amount is not yet known and the client does not want to receive EI benefits while waiting for a decision.

When calculating a claim or recalculating a BPNE claim that becomes established, the officer refers to Earnings: Earnings deduction calculation — Table to determine the no benefits payable amount.
       [Earnings: Earnings deduction calculation — Table](/en/procedure/generic/additionalresources/bp_erw_table.shtml) 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/calc_determining/rev_psl_wli/determining_if_the_file_must_be_referre_f4ff817e.dita`

If an employer does not meet the obligation as the first payer, the officer refers the case to Integrity before making a decision.
       [Integrity](/en/procedure/activity/referal_integrity.shtml) 

### Paid sick leave (PSL)

Source topic: `en_EN/task/calc_determining/rev_psl_wli/paid_sick_leave_psl.dita`

An employer may provide a period of PSL to an employee who is unable to work due to illness, injury or quarantine. An employee’s entitlement to PSL may be based on a predetermined amount of paid sick time allowed by the employer each year, or it may be based on a formula related to an employee’s years of service. The employer can even advance future sick leave entitlements to an employee who does not have enough entitlement to cover the entire period of leave. PSL is considered benefits that might otherwise be paid by EI.

Clients who are entitled to PSL and who stop working due to illness or injury must exhaust their sick leave credits before they are eligible to receive EI sickness benefits. If a client is entitled to PSL and does not apply to use it, the sick leave entitlement is still deemed earnings and is allocated to the period for which the entitlement would have been paid or payable if the client had requested the paid leave from the employer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1616.dita) 

### Group wage loss insurance (WLI) plans

Source topic: `en_EN/task/calc_determining/rev_psl_wli/group_wage_loss_insurance_wli_plans.dita`

Group WLI plans provide benefits to individuals for loss of income due to an illness or injury.

Group WLI plans are designed to cover a group of workers who work for the same employer. Group WLI provided for loss of income is considered a benefit that might otherwise be paid by EI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1617.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2310.dita) 

### Preventive withdrawal payments

Source topic: `en_EN/task/calc_determining/rev_psl_wli/preventive_withdrawal_payments.dita`

Preventive withdrawal payments may be paid to an employee who stops working because the working conditions present physical danger to the employee’s health, danger to an unborn child or to a child the employee is breast-feeding.

Preventive withdrawal payments are paid under provincial legislation and are currently only available in the province of Quebec.

Preventive withdrawal payments provided for loss of income are considered benefits that might otherwise be paid by EI. If the client is entitled to these benefits under provincial law, the benefits are still considered earnings, even if the client chooses not to apply for them.

Preventive withdrawal payments are allocated to the weeks for which those payments are paid or payable, or for which they would have been paid or payable for if the client had applied. 

### Motor vehicle accident insurance

Source topic: `en_EN/task/calc_determining/rev_psl_wli/motor_vehicle_accident_insurance.dita`

Motor vehicle accident insurance provides benefits to insured individuals due to a vehicle accident. Motor vehicle accident insurance provided for the loss of income is considered a benefit that might otherwise be paid by EI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2311.dita) 

### Workers’ compensation benefits (WCB)

Source topic: `en_EN/task/calc_determining/rev_psl_wli/workers_compensation_benefits_wcb.dita`

WCB are provided to workers as a result of a workplace-related illness or injury. Clients wishing to receive WCB must apply for that benefit. Although WCB that are provided for loss of income are considered earnings, it is not mandatory for clients to apply for these benefits, as they are not considered benefits that might otherwise be paid by EI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2312.dita) 

### Wage Earner Protection Program (WEPP)

Source topic: `en_EN/task/calc_determining/rev_psl_wli/wage_earner_protection_program_wepp.dita`

WEPP provides workers with guaranteed payment of wages owed when their employer declares bankruptcy or becomes subject to a receivership. It is not mandatory for clients to apply for WEPP and WEPP is not considered a benefit that might otherwise be paid by EI. Clients who want to receive compensation from WEPP must apply for WEPP. Monies paid by WEPP to compensate for unpaid wages, earned unpaid vacation pay, severance and termination pay are earnings.

None of the monies paid by WEPP are insurable. However, unpaid wages due to bankruptcy are insurable and should already be included on the ROE. When a client reports receiving a WEPP payment that includes unpaid wages, the officer determines if the unpaid wages are included on the original ROE. Wages and vacation pay paid under WEPP are taxable. EI and Canada Pension Plan (CPP) premiums are not deducted from the amount paid. However, there is a 6.82% reduction in the amount paid, which represents the equivalent deduction for EI and CPP premiums.

WEPP monies paid for unpaid earned vacation pay, severance and termination pay are paid as a result of the separation from employment and are allocated from the date of bankruptcy, based on the client’s normal weekly earnings (NWE). Monies paid to compensate expenses for travelling salespeople are not earnings and are not allocated.

The amount to allocate is the amount paid to the client by WEPP before tax. The client receives a decision letter notifying them of the amount to be paid by WEPP. The letter also indicates that the amount has already been reduced by 6.82%. In other words, the amount indicated on the letter and pay stub represents the actual gross payment to be paid by WEPP to the claimant. No other calculation is necessary to complete the allocation.

Major Employer Events may contain information concerning the allocation of the monies received under WEPP.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

**Budget 2021**

As part of Budget 2021, the following changes have been made to the deductions and allocations of WEPP payments:

- Bankruptcies and receiverships that are declared on or after November 20, 2021 are no longer subject to a 6.82% deduction. The WEPP approval letter sent to the client no longer shows a deduction of 6.82%.

- Separation monies that are reviewed between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361) and are paid due to a temporary layoff or a permanent separation from employment are not considered earnings and are not allocated, regardless of the BPC.

- Separation monies that are reviewed on or after September 25, 2022 (w/c 2362) and are paid due to a temporary layoff or a permanent separation from employment with an allocation start date between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361) are not considered earnings and are not allocated. 

### Waiting for a decision on benefits from another source

Source topic: `en_EN/task/calc_determining/rev_psl_wli/waiting_for_a_decision_on_benefits_from_006f49ce.dita`

When an application for benefits from another source is pending or there is a dispute regarding the entitlement, the client can be paid EI benefits while waiting for a decision.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1618.dita) 

### Communicating the decision

Source topic: `en_EN/task/calc_determining/rev_psl_wli/communicating_the_decision.dita`

When clients declare that they applied for benefits from other sources which might otherwise be payable by EI, the N-00-00-00 letter is sent to the clients. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_1615.dita`

Note:

When an employer has PRP information on file, there may be a date indicated in the Last update filed field. This date can be for any change made in the employer record and must not be used as an effective date of the PRP. 

### Note

Source topic: `en_EN/common_notes/note_c_1616.dita`

Note:

Clients who have received PSL from their employer after their last day worked (LDW) may be entitled to have their waiting period (WP) waived. 

### Note

Source topic: `en_EN/common_notes/note_c_1617.dita`

Note:

A WLI plan that is not a group plan has the following characteristics:

- It is not considered a benefit that might otherwise be paid by EI.

- It is not earnings.

- It cannot be related to a group of persons who are all employed by the same employer.

- It is not financed in whole or in part by the employer.

- It is voluntarily purchased by the insured person.

- It is completely portable, in that the rate of premium and the protection provided remain the equivalent, should the client become employed by any other employer within the same occupation.

- It provides constant benefits, that is, there is no provision calling for automatic benefits increments in accordance with a pre-arranged benefit schedule based on current earnings.

- Its premium rates are not dependent on the experience of the employer’s group of workers. 

### Note

Source topic: `en_EN/common_notes/note_c_2310.dita`

Note:

When a client receives WLI payments in the period immediately preceding the regular BPC, the calculated BPC of any BT can be backdated during the review of the calculation result. 

### Note

Source topic: `en_EN/common_notes/note_c_2311.dita`

Note:

When motor vehicle accident insurance is considered earnings, it prevents an interruption of earnings (I of E). 

### Note

Source topic: `en_EN/common_notes/note_c_2312.dita`

Note:

When a client receives any WCB in the period immediately preceding the regular BPC, the calculated BPC of any BT can be backdated during the review of the calculation result. 

### Note

Source topic: `en_EN/common_notes/note_c_1618.dita`

Note:

It is not necessary to obtain a signed statement from clients specifying that they will reimburse the EI benefits received if the benefits from the other source are approved and determined to be earnings. 

## Regional considerations

Source topic: `en_EN/task/calc_determining/rev_psl_wli/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_determining/rev_psl_wli/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/calc_determining/rev_psl_wli/in_nws.dita`

- Does information on file indicate that PSL is not exhausted?

- Is there information regarding monies from another source?

- Is there any documentation on file indicating that the client has applied for, or is entitled to benefits from another source?

- If yes, is the type of benefits indicated and is the weekly amount available? 

### In RCM:

Source topic: `en_EN/task/calc_determining/rev_psl_wli/in_rcm.dita`

- Does the last ROE indicate PSL or WLI payments?

- Is possible WLI entitlement indicated in the Comments field?

- What is the business number of the last employer? 

### In Imaging:

Source topic: `en_EN/task/calc_determining/rev_psl_wli/in_imaging.dita`

- Is there information regarding monies from another source? 

### In FTS:

Source topic: `en_EN/task/calc_determining/rev_psl_wli/in_fts.dita`

- Does the Employer Details — Premium Reduction Program screen show registered WLI information?

- If yes, is there possible PSL? Are there weeks of WLI? Does the status indicate the employer has a reduction of EI premiums? 

## Step by step

Source topic: `en_EN/task/calc_determining/rev_psl_wli/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_determining/rev_psl_wli/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/calc_determining/rev_psl_wli/reviewing_the_file_level_1.dita`

- Determine if one of the following conditions is met:

- The information on file indicates that there are benefits paid or potentially payable from another source.

- The client reports having applied for benefits from a first payer but claims not to be entitled to those benefits.

- The last employer has a reduction in premiums and the reason for separation (RFS) on the ROE is illness, injury or quarantine.

- If one of the conditions is met, go to step 2.

- If none of the conditions are met, go to Next procedure .
                   [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#next)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2313.dita)

- Determine if additional information is required to confirm that the client is receiving or is entitled to receive benefits from another source:

- If additional information is required, go to step 3.

- If additional information is not required, go to step 4

- On the calculation worksheet, note that fact-finding with the client or the employer is required to obtain the following information and advise the client of any necessary information:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2314.dita) 

- If benefits from a first payer could be payable and an application to benefits from another source has not been submitted, ensure that the client is aware of the obligation to apply for those benefits and to inform Service Canada of any decision that is received.

- If the client has applied or will apply for benefits from another source, does the client want to receive EI benefits while waiting for a decision?

- If the RFS is illness, the employer’s status indicates a reduction in premiums, and PSL or WLI information on the ROE does not correspond to the information on the Employer Details — Premium Reduction Program screen, why did the client not receive PSL or WLI as indicated on the Employer Details screen in FTS and what are the details of the benefits that could be received?

- If the client received PSL or WLI after the LDW, what are the details of the benefits received and were the benefits paid included in the calculation of the insurable hours and earnings on the ROE?

- Go to Next procedure .
               [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#next)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2315.dita)

- Determine if the client is requesting EI benefits while waiting for a decision on benefits from another source:

- If yes, go to step 5.

- If no, go to step 7.

- In ACS, determine if the N-00-00-00 letter has been sent:

- If yes, go to step 6.

- If no, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Also applied for other disability benefits - Client must Repay EI (3062)

- Determine if the calculation WI has been pended for 10 business days from the date the client agreed to submit an application for benefits from another source:

- If yes, go to step 7.

- If no, on the calculation worksheet, note that after the claim review, you must move the calculation WI to Pending for 10 business days from the date the client agreed to submit an application for benefits from another source. Go to Next procedure .
               [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#next)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2316.dita)

- Determine if the client is requesting regular benefits:

- If no, go to Reviewing entitlement to paid sick leave (PSL ).
               [Reviewing entitlement to paid sick leave (PSL](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#psl_sbs)

- If yes, on the calculation worksheet, note that if the information on file indicates benefits are payable or may be payable from another source after the BPC, you must review the client’s availability to be looking for work before calculation. Go to Reviewing entitlement to paid sick leave (PSL ).
               [Reviewing entitlement to paid sick leave (PSL](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#psl_sbs) 

#### Reviewing entitlement to paid sick leave (PSL)

Source topic: `en_EN/task/calc_determining/rev_psl_wli/reviewing_entitlement_to_paid_sick_leave_psl_level_1.dita`

- Determine if the client received PSL after the LDW:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the client received all of the PSL entitlement after the LDW:

- If yes, go to step 3.

- If no, go to step 5.

- Determine if the PSL is considered earnings that must be allocated by referring to Earnings: Determination, allocation and references — Table :

- If yes, go to step 8.

- If no, go to Reviewing entitlement to wage loss insurance (WLI ).
               [Reviewing entitlement to wage loss insurance (WLI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#wli_sbs)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2317.dita)

- Determine if the client is entitled to receive PSL after the LDW (i.e. the RFS on the last ROE is illness and the client has entitlement to PSL remaining):

- If yes, go to step 5.

- If no, go to Reviewing entitlement to wage loss insurance (WLI) .
               [Reviewing entitlement to wage loss insurance (WLI)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#wli_sbs)

- Determine if the information on file indicates that the employer has deliberately prevented the client from receiving all of the PSL entitlement:

- If no, go to step 6.

- If yes, refer to Referral to Integrity and go to step 7.
               [Referral to Integrity](/en/procedure/activity/referal_integrity.shtml)

- In NWS, create a Reminder (REM) WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Paid sick leave.”

- Due date: Select the current date + 90 business days.

- Language: Select the appropriate option.

- Details: Type “Paid sick leave could be payable.”

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Select Save .

- Calculate the last day the client would be payable if all of the PSL entitlement was paid to the client.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2318.dita)

- In RCM, determine if the ROE shows the PSL that is paid or payable in the Special payments field:

- If no, go to step 9.

- If yes, go to step 10.

- In RCM, add the PSL details in the Special Payments field as follows:

- Block 19 — Start date: Enter the first day the PSL was paid or payable.

- Block 19 — End date: Enter the last day the PSL was paid or payable.

- Block 19 — Amount: Enter the daily or weekly amount of the PSL.

- Block 19 — (per day or per week): Select one of the following:

- If the daily rate was input in the Amount field, select per day .

- If the weekly rate was input in the Amount field, select per week .

- Block 19 — Duration: Select one of the following:

- If the daily rate was input in the Amount field, enter the total number of days the PSL was paid or payable.

- If the weekly rate was input in the Amount field, enter the total number of weeks the PSL was paid or payable.

- Select Validate:

- If no errors are displayed, select Submit and go to step 10.

- If errors are displayed, refer to Correcting an ROE and go to step 10.
                   [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2319.dita)

- On the calculation worksheet, make a note to determine if the WP can be waived before calculating the claim in SSO. Go to Reviewing entitlement to wage loss insurance (WLI ). 

#### Reviewing entitlement to wage loss insurance (WLI)

Source topic: `en_EN/task/calc_determining/rev_psl_wli/reviewing_entitlement_to_wage_loss_insurance_wli_level_1.dita`

- Determine if the client received group WLI after the LDW:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the type of WLI is considered earnings that must be allocated by referring to Earnings: Determination, allocation and references — Table :

- If yes, go to step 8.

- If no, go to Reviewing entitlement to preventive withdrawal payments .
               [Reviewing entitlement to preventive withdrawal payments](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#prevntivewithdrawal_sbs)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2317.dita)

- Determine if the client is entitled to receive group WLI after the LDW (i.e. the RFS on the last ROE is illness and the employer’s status indicates a reduction in premiums):

- If yes, go to step 4.

- If no, go to Reviewing entitlement to preventive withdrawal payments .
               [Reviewing entitlement to preventive withdrawal payments](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#prevntivewithdrawal_sbs)

- Determine if the employer is preventing the client from applying for WLI:

- If no, go to step 5.

- If yes, refer to Referral to Integrity and go to step 5.
               [Referral to Integrity](/en/procedure/activity/referal_integrity.shtml)

- Determine if the client has made reasonable efforts to obtain group WLI:

- If the client has applied or will be applying for group WLI, go to step 6.

- If the client has not applied and will not be applying for group WLI, go to step 8.

- Determine if the client is requesting EI benefits while waiting for a decision on benefits from WLI:

- If yes, go to step 7.

- If no, go to step 10.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Wage loss insurance.”

- Due date: Select the current date + 90 business days.

- Language: Select the appropriate option.

- Details: Type “Decision pending on WLI from [source], follow up is required. Review the file for benefits paid or payable from another source and allocate if necessary.”

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Select Save .

- Go to Reviewing entitlement to preventive withdrawal payments .
               [Reviewing entitlement to preventive withdrawal payments](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#prevntivewithdrawal_sbs)

- In RCM, determine if the ROE shows the group WLI that is paid or payable in the Special payments field:

- If no, go to step 9.

- If yes, go to step 10.

- In RCM, add the WLI details in the Special Payments field as follows:

- Block 19 — Start date: Enter the first day the WLI was paid or payable.

- Block 19 — End date: Enter the last day the WLI was paid or payable.

- Block 19 — Amount: Enter the daily or weekly amount of the WLI.

- Block 19 — (per day or per week): Select one of the following:

- If the daily rate was input in the Amount field, select per day .

- If the weekly rate was input in the Amount field, select per week .

- Block 19 — Duration: Select one of the following:

- If the daily rate was input in the Amount field, enter the total number of days the WLI was paid or payable.

- If the weekly rate was input in the Amount field, enter the total number of weeks the WLI was paid or payable.

- Select Validate:

- If no errors are displayed, select Submit and go to step 10.

- If errors are displayed, refer to Correcting an ROE and go to step 10.
                   [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- On the calculation worksheet, note that when reviewing and inputting the calculation, you must ensure an M175 - Allocation Set-up (M175) transaction is input with an allocation code F - Wage loss insurance . If the amount has not been obtained, consider that the amount of the potential WLI is equal to the no benefits payable amount. Also note that when reviewing the BPC, an automatic backdate may be required. Go to Reviewing entitlement to preventive withdrawal payments . 

#### Reviewing entitlement to preventive withdrawal payments

Source topic: `en_EN/task/calc_determining/rev_psl_wli/reviewing_entitlement_to_preventive_wit_00b1718c_level_1.dita`

- Determine if the client received preventive withdrawal payments after the LDW:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the preventive withdrawal payments are considered earnings that must be allocated by referring to Earnings: Determination, allocation and references — Table :

- If yes, go to step 7.

- If no, go to Reviewing entitlement to motor vehicle accident insurance .
               [Reviewing entitlement to motor vehicle accident insurance](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#mvai_sbs)

- Determine if the client could be entitled to receive preventive withdrawal payments after the LDW:

- If yes, go to step 4.

- If no, go to Reviewing entitlement to motor vehicle accident insurance .
               [Reviewing entitlement to motor vehicle accident insurance](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#mvai_sbs)

- Determine if the client has made reasonable efforts to obtain preventive withdrawal payments:

- If the client has applied or will be applying for preventive withdrawal payments, go to step 5.

- If the client has not applied and will not be applying for preventive withdrawal payments, refer to Referral to Integrity and go to step 7.
               [Referral to Integrity](/en/procedure/activity/referal_integrity.shtml)

- Determine if the client is requesting EI benefits while waiting for a decision on benefits from preventive withdrawal payments:

- If yes, go to step 6.

- If no, go to step 7.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Preventive withdrawal payments.”

- Due date: Select the current date + 90 business days.

- Language: Select the appropriate option.

- Details: Type “Decision pending on preventive withdrawal payments from [source], follow up is required. Review the file for benefits paid or payable from another source and allocate if necessary.”

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Select Save .

- Go to Reviewing entitlement to motor vehicle accident insurance .
               [Reviewing entitlement to motor vehicle accident insurance](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#mvai_sbs)

- On the calculation worksheet, note that when reviewing and inputting the calculation, you must ensure an Allocation (M175) transaction is input with an allocation code B - Workers’ Compensation / Preventative Withdrawal benefits to impose an allocation of the preventive withdrawal payments paid or payable. If the amount has not been obtained, consider that the amount of the potential preventive withdrawal payments is equal to the no benefits payable amount. Go to Reviewing entitlement to motor vehicle accident insurance . 

#### Reviewing entitlement to motor vehicle accident insurance

Source topic: `en_EN/task/calc_determining/rev_psl_wli/reviewing_entitlement_to_motor_vehicle__49f6f1b9_level_1.dita`

- Determine if the client received or could be entitled to receive motor vehicle accident insurance after the LDW:

- If yes, go to step 2.

- If no, go to Reviewing entitlement to workers’ compensation benefits (WCB) .
               [Reviewing entitlement to workers’ compensation benefits (WCB)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#wcb_sbs)

- Determine if the motor vehicle accident insurance is considered earnings that must be allocated by referring to Earnings: Determination, allocation and references — Table :

- If yes, go to step 3.

- If no, go to Reviewing entitlement to workers’ compensation benefits (WCB) .
               [Reviewing entitlement to workers’ compensation benefits (WCB)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#wcb_sbs)

- Determine if the client has made reasonable efforts to obtain motor vehicle accident insurance:

- If the client has applied or will be applying for motor vehicle accident insurance, go to step 4.

- If the client has received motor vehicle accident insurance, go to step 6.

- If the client has not applied and will not be applying for motor vehicle accident insurance, refer to Referral to Integrity and go to step 6.
               [Referral to Integrity](/en/procedure/activity/referal_integrity.shtml)

- Determine if the client is requesting EI benefits while waiting for a decision on benefits from motor vehicle accident insurance:

- If yes, go to step 5.

- If no, go to step 6.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Motor vehicle accident insurance.”

- Due date: Select the current date + 90 business days.

- Language: Select the appropriate option.

- Details: Type “Decision pending on motor vehicle accident insurance from [source], follow up is required. Review the file for benefits paid or payable from another source and allocate if necessary.”

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Select Save .

- Go to Reviewing entitlement to workers’ compensation benefits (WCB) .
               [Reviewing entitlement to workers’ compensation benefits (WCB)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#wcb_sbs)

- On the calculation worksheet, note that when reviewing and inputting the calculation, you must ensure an Allocation (M175) transaction is input with an allocation code E - Earnings to impose an allocation of the motor vehicle accident insurance paid or payable. If the amount has not been obtained, consider that the amount of the potential motor vehicle accident insurance is equal to the no benefits payable amount.

- Determine if the client has an I of E by referring to Earnings: Determination, allocation and references — Table and Determining if there is an interruption of earnings if required:

- If yes, go to Reviewing entitlement to workers’ compensation benefit (WCB) .
               [Reviewing entitlement to workers’ compensation benefit (WCB)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#wcb_sbs)

- If no, refer to Indicating in SSO that there is no interruption of earnings .
               [Indicating in SSO that there is no interruption of earnings](/en/procedure/task/calc_calculating/no_interruption_earnings.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2320.dita) 

#### Reviewing entitlement to workers’ compensation benefits (WCB)

Source topic: `en_EN/task/calc_determining/rev_psl_wli/reviewing_entitlement_to_workers_compen_25cd01a5_level_1.dita`

- Determine if the client received WCB after the LDW:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the WCB are considered earnings that must be allocated by referring to Earnings: Determination, allocation and references — Table :

- If yes, go to step 7.

- If no, go to Reviewing entitlement to the Wage Earner Protection Program (WEPP) .
               [Reviewing entitlement to the Wage Earner Protection Program (WEPP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#WEPP_sbs)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2317.dita)

- Determine if the client could be entitled to receive WCB after the LDW:

- If yes, go to step 4.

- If no, go to Reviewing entitlement to the Wage Earner Protection Program (WEPP) .
               [Reviewing entitlement to the Wage Earner Protection Program (WEPP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#WEPP_sbs)

- Determine if the client has applied or will be applying for WCB:

- If the client has applied or will be applying for WCB, go to step 5.

- If the client has not applied and will not be applying for WCB, go to Reviewing entitlement to the Wage Earner Protection Program (WEPP) .
               [Reviewing entitlement to the Wage Earner Protection Program (WEPP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#WEPP_sbs)

- Determine if the client is requesting EI benefits while waiting for a decision on benefits from WCB:

- If yes, go to step 6.

- If no, go to Reviewing entitlement to the Wage Earner Protection Program (WEPP) .
               [Reviewing entitlement to the Wage Earner Protection Program (WEPP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#WEPP_sbs)

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “WCB.”

- Due date: Select the current date + 90 business days.

- Language: Select the appropriate option.

- Details: Type “Decision pending on WCB from [source], follow up is required. Review the file for benefits paid or payable from another source, and allocate if necessary.”

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Select Save .

- Go to Reviewing entitlement to the Wage Earner Protection Program (WEPP ).
               [Reviewing entitlement to the Wage Earner Protection Program (WEPP](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#WEPP_sbs)

- On the calculation worksheet, make a note to input the WCB information when calculating the claim in SSO. Also note that when reviewing and inputting the calculation, you must ensure an M175 - Allocation Set-up (M175) transaction is input with an allocation code B - Workers compensation / preventative withdrawal benefits . If the amount has not been obtained, consider that the amount of the potential WCB is equal to the no benefits payable amount. Also note that when reviewing the BPC, an automatic backdate may be required. Go to Reviewing entitlement to the Wage Earner Protection Program (WEPP) . 

#### Reviewing entitlement to the Wage Earner Protection Program (WEPP)

Source topic: `en_EN/task/calc_determining/rev_psl_wli/reviewing_entitlement_to_the_wage_earne_fb0ceeba_level_1.dita`

- Determine if the client received WEPP after the LDW:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the WEPP payments are considered earnings that must be allocated by referring to Allocating Wage Earner Protection Program monies :

- If yes, go to step 5.

- If no, go to Next procedure .
               [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#next)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2321.dita)

- Determine if the client could be entitled to receive WEPP payments after the LDW (i.e. the RFS on the last ROE indicates bankruptcy):

- If yes, go to step 4.

- If no, go to Next procedure .
               [Next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/rev_psl_wli#next)

- Determine if the client has applied or will be applying for WEPP payments:

- If the client has applied or will be applying for WEPP payments, go to step 6.

- If the client has not applied and will not be applying for WEPP payments, go to step 7.

- On the calculation worksheet, note that when reviewing and inputting the calculation, you must input an Allocation (M175) transaction with the appropriate allocation code to impose an allocation that will prevent payment of EI benefits. If the amount of the allocation has not been obtained, consider it equal to the no benefits payable amount. Go to step 7.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “WEPP payments.”

- Due date: Select the current date + 90 business days.

- Language: Select the appropriate option.

- Details: Type “Decision pending on WEPP payments from [source], follow up is required. Review the file for benefits paid or payable from another source and allocate if necessary.”

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Select Save .

- Determine if the ROE already includes the hours and earnings for the period that is unpaid due to the bankruptcy:

- If no, go to step 8.

- If yes, go to step 9.

- In RCM, correct ROE to as follows:

- Block 11: Enter the correct LDW.

- Block 15A: Enter the correct insurable hours.

- Block 15B: Enter the correct insurable earnings.

- Block 17: Enter the correct monies on separation.

- Select Validate:

- If no errors are displayed, select Submit and go to step 9.

- If errors are displayed for any block, refer to Correcting an ROE and go to step 9.
                   [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- Go to Next procedure .

- If no errors are displayed, select Submit and go to step 9.

- If errors are displayed for any block, refer to Correcting an ROE and go to step 9. 

#### Next procedure

Source topic: `en_EN/task/calc_determining/rev_psl_wli/next_procedure_level_1.dita`

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 13 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 13 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 13 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 13 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 13 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to step 13 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to step 13 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2313.dita`

Note:

If a client reports having applied for benefits from a first payer but claims not to be entitled to those benefits, fact-find to determine why the client is not entitled to those benefits. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2314.dita`

- Is there entitlement to benefits from another source?

- Have benefits from another source been received?

- What are the details of any benefits from another source that the client could be entitled to receive?

- Is there a pending application?

- Have the benefits been exhausted? 

#### Note

Source topic: `en_EN/common_notes/note_c_2315.dita`

Note:

Once fact-finding is complete, return to step 1 of this task. 

#### Note

Source topic: `en_EN/common_notes/note_c_2316.dita`

Note:

When the WI moves to the active workload, return to step 1 of this task. 

#### Note

Source topic: `en_EN/common_notes/note_c_2317.dita`

Note:

Monies that are considered earnings are allocated even if they are not earnings in the WP. 

#### Note

Source topic: `en_EN/common_notes/note_c_2318.dita`

Note:

If the last day the client would be payable is beyond the application date, consult with a Business Expertise Advisor for instructions. 

#### Note

Source topic: `en_EN/common_notes/note_c_2319.dita`

Note:

If insurable PSL is entered in the Special Payments field of the ROE for a period that occurs after the last day paid (LDP) in block 11 , RCM generates a validation error as the hours and earnings from the PSL are insurable. When this occurs, correct the ROE to indicate the last day of PSL as the LDP in block 11 and enter the PSL in blocks 15A and 15B . 

#### Note

Source topic: `en_EN/common_notes/note_c_2320.dita`

Note:

When motor vehicle accident insurance is considered earnings, it prevents an I of E. When this occurs, determine if the client has had another I of E during the qualifying period (QP). 

#### Note

Source topic: `en_EN/common_notes/note_c_2321.dita`

Note:

A Budget 2021 measure applies to separation monies that are reviewed between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361) and are paid due to a temporary layoff or a permanent separation from employment. When separation monies are reviewed during that period, they are not considered earnings and are not allocated, regardless of the BPC. If the WEPP payment includes separation monies (severance pay, vacation pay or termination pay), do not allocate it.

A transitional provision to the Budget 2021 applies to separation monies that are reviewed on or after September 25, 2022 (w/c 2362). When the allocation start date is between September 26, 2021 (w/c2310) and September 24, 2022 (w/c 2361), monies paid or payable due to a temporary layoff or a permanent separation from employment are not considered earnings and are not allocated. 

## Policy reference

Source topic: `en_EN/task/calc_determining/rev_psl_wli/policy_reference.dita`

- EIA 49
         [EIA 49](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-49.html)

- EIR 77.997
         [EIR 77.997](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-14.html#docCont) 
