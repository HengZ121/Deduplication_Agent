# Verifying ROEs before calculation

Source map: `en_EN/task/calc_determining/review_roe/review_roe.ditamap`

## Summary

Source topic: `en_EN/task/calc_determining/review_roe/summary.dita`

Summary: ROEs in the qualifying period (QP) must be verified before calculating the claim. 

## What you need to know

Source topic: `en_EN/task/calc_determining/review_roe/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/review_roe/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2329.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2330.dita) 

### Verifying an ROE

Source topic: `en_EN/task/calc_determining/review_roe/verifying_an_roe.dita`

Before calculating the claim, the officer must verify the following information relating to the ROE:

- The employee’s name on the ROE matches the client’s name on the application.

- Any separation monies listed by the employer as Other are correctly coded.

- Whether amounts provided by the client for normal weekly earnings (NWE) or earnings last week worked (ELWW) must be input.

- Any information in the Comments block or Additional information field of the ROE has been correctly coded.

- Any validation errors on the ROE have been corrected.

The officer reviews the entire ROE to determine if any fact-finding is necessary. Any required information is noted on the officer’s personal worksheet ( not in a client Note ). Once the officer determines all the additional facts needed, the officer contacts the relevant party.

If this is a recalculation that includes a previously missing ROE and if at any time it is suspected that the client misrepresented the facts relating to the situation by concealing the ROE, the officer considers a referral to Integrity .
       [referral to Integrity](/en/procedure/activity/referal_integrity.shtml) 

### Employee’s name

Source topic: `en_EN/task/calc_determining/review_roe/employees_name.dita`

The ROE is a legal document. The client’s name on the ROE must match the name on the application within reasonable tolerances (e.g. Bob for Robert). When the name does not match, the officer must confirm with the client that it is the client’s ROE.

If the officer suspects or is certain that the ROE may have been issued with the wrong SIN, the officer refers to Misdirected documents .
       [Misdirected documents](/en/procedure/activity/misdirected_documents.shtml) 

### Normal weekly earnings (NWE) and earnings last week worked (ELWW)

Source topic: `en_EN/task/calc_determining/review_roe/normal_weekly_earnings_nwe_and_earnings_b1573162.dita`

The officer must verify that the client provided amounts for the normal weekly earnings or earnings last week worked after filing the application.
       [normal weekly earnings](/en/procedure/generic/knowledge.shtml#NWE) 
       [earnings last week worked](/en/procedure/generic/knowledge.shtml#NLWW)

NWE and ELWW are used during the calculation of a claim to determine when the interruption of earnings occurred, and to determine the BPC and the allocation of separation monies. UIC automatically calculates an average NWE and an average ELWW amount for each ROE. The averaged NWE and ELWW are indicated in the Employment History File of each ROE. When the client provides NWE and ELWW amounts which appear reasonable, the amounts provided by the client are used in the calculation of the claim. The officer must enter the amounts into the Allocation of monies section of the ROE.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2331.dita) 

### Separation monies

Source topic: `en_EN/task/calc_determining/review_roe/separation_monies.dita`

The information contained in block 17C for regular ROEs must be reviewed to ensure that other monies have been coded correctly. The determination of insurability or non-insurability of monies contained in block 17C can affect the benefit rate. Also, the allocation of separation monies depends on how the other monies in 17C have been coded. If the ROE is validated, the coding is accepted as entered by the employer unless the selection in block 17C: Other Monies is one of the following:

- O - Other;

- B - Bonus with no sub-menu selection;

- B - Bonus and the sub-menu selection is Other .

When the details for these monies are not provided, the officer reviews the Comments block and Additional information field to determine if the employer has provided the required details for these monies. When this information is not provided, the officer must fact-find with the employer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0717.dita) 

### Comments block and Additional information field

Source topic: `en_EN/task/calc_determining/review_roe/comments_block_and_additional_information_field.dita`

The officer must review the Comments block and Additional information field of each ROE in the QP. These fields can provide additional information from the employer or can inform the officer of a difference noted during data entry of the ROE.

In some instances, procedures related to the data entry of an ROE or the review of ROE comments instruct the officer to deliberately create an error on the ROE if there is a difference that would not on its own create a validation error (e.g. a change was made to the original ROE but not initialled by the employer). When this occurs, the difference is indicated in the Additional information field of the ROE. These procedures prevent automated calculation of the claim until an officer can review the information.

**Comments block indicates the amended ROE was issued due to error and the only change is the reason for separation (RFS)**

The RFS must reflect the reason the ROE was issued at the time of the original separation from employment.

The employer is not required to issue a new ROE when, for example, a client is permanently laid off during a period of leave if there are no separation monies paid to the client when this occurs. This is because the ROE already reflects the reason it was issued at the time of the original separation. If the employer issues an amended ROE with a new RFS in these cases, the officer changes the RFS on the amended ROE back to the original RFS to reflect the RFS at the time of the original separation.

This contrasts with situations in which the employer amends an ROE because they completed the ROE incorrectly at the time of the original separation. In these cases, the officer does not change the RFS of the amended ROE back to the original RFS, as the new RFS now reflects the correct RFS at the time of the original separation. 

### Validation errors

Source topic: `en_EN/task/calc_determining/review_roe/validation_errors.dita`

When there is an error on an ROE required for calculation, the calculation of the claim is prevented in SSO until the error is corrected.

In RCM, ROE error messages are displayed in red by the blocks in error. When an ROE is corrected, the changes require validation to determine if errors are still present or if new ones have occurred. The ROE is considered successfully corrected and available for use in the claim assessment only once no error messages remain.

When a validation error is found on an ROE, the officer refers to either:

- Correcting an ROE error during calculation or recalculation — Regular ROE ;
         [Correcting an ROE error during calculation or recalculation — Regular ROE](/en/procedure/task/correcting_roe_error_calculation_regular.shtml)

- Correcting an ROE error during calculation or recalculation — Fisher ROE .
         [Correcting an ROE error during calculation or recalculation — Fisher ROE](/en/procedure/task/correcting_roe_error_calculation_fisher.shtml)

The validation rules for ROE Web and ROE SAT are different from those in RCM. Consequently, ROE Web and ROE SAT may have RCM validation errors that prevent calculation in SSO, even if they are not flagged in red on the RCM Search/Correct - Results screen. Therefore, all ROEs in the QP must be reviewed. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2329.dita`

Note:

For an initial calculation or a recalculation using a Government of Canada ROE that requires correction, the officer refers to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2330.dita`

Note:

For validation errors on an ROE Correction WI, an ROE Comments WI, an initial calculation or a recalculation with an Air Canada ROE SAT, the officer refers to Major Employer Events (MEE) — Information Bulletin .
       [Major Employer Events (MEE) — Information Bulletin](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68)

     [Major Employer Events (MEE) — Information Bulletin](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68) 

### Note

Source topic: `en_EN/common_notes/note_c_2331.dita`

Note:

The fields in the Allocation of monies section of the ROE must only be used when the amounts calculated by UIC need to be overridden because the NWE or ELWW amounts have been provided by the client. When one field is completed, both fields must be completed in order to obtain a correct calculation result. If one amount is not known, in the corresponding field in RCM, enter the averaged amount indicated in the Employment History File. 

### Note

Source topic: `en_EN/common_notes/note_c_0717.dita`

Note:

A temporary measure under Pilot Project No. 24 applies to separation monies paid due to a separation from employment on claims with a BPC or allocation start date between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). When separation monies are paid for that period, they are not allocated.

If the monies are paid because of the separation, the officer leaves the date fields of the ROE blank and UIC does not allocate the monies. If the monies are paid for any other reason, the officer enters the appropriate dates in the ROE, and UIC allocates the amounts as usual. 

## Regional considerations

Source topic: `en_EN/task/calc_determining/review_roe/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_determining/review_roe/what_you_need_to_look_for.dita`

### In RCM:

Source topic: `en_EN/task/calc_determining/review_roe/in_rcm.dita`

- Which ROEs fall in the QP?

- What is the client’s name on the ROE?

- Are there entries in block 17C: Other Monies ?

- Is there any information in block 18: Comments or the Additional Information field? 

### In NWS:

Source topic: `en_EN/task/calc_determining/review_roe/in_nws.dita`

- What is the client’s name on the current or previous application?

- Are there any documents with information regarding the ROEs?

- Is the client disputing the ROE information?

- Has the client provided an NWE or ELWW amount?

- If yes, does it appear reasonable when compared to the ROE? 

### In Imaging:

Source topic: `en_EN/task/calc_determining/review_roe/in_imaging.dita`

- Are there any documents related to the ROE or employment (e.g. the client has provided an NWE or ELWW amount)? 

## Step by step

Source topic: `en_EN/task/calc_determining/review_roe/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_determining/review_roe/level_1.dita`

#### Determining if an ROE must be reviewed

Source topic: `en_EN/task/calc_determining/review_roe/determining_if_an_roe_must_be_reviewed_level_1.dita`

- In RCM, on the Search/Correct - Results screen, determine if there is an ROE in the QP that has not yet been reviewed or that requires correction:

- If yes, select the ROE in question and go to Reviewing the employee’s name .
               [Reviewing the employee’s name](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_2)

- If no, close the RCM window and go to Determining the next procedure .
               [Determining the next procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_7)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2332.dita) 

#### Reviewing the employee’s name

Source topic: `en_EN/task/calc_determining/review_roe/reviewing_the_employees_name_level_1.dita`

- In RCM and NWS, determine if both the given name and surname in block 9 of the ROE match the names on the client’s current or previous application:

- If both names match or if it has already been determined that this ROE was issued under the correct SIN, go to Reviewing separation monies .
               [Reviewing separation monies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_3)

- If only the surname matches, go to step 2.

- If only the given name matches, go to step 3.

- If neither name matches, go to step 4.

- Determine if the given name is a nickname or shortened version of the name on the application or the ROE:

- If the given name is a nickname or shortened version, go to Reviewing separation monies .
               [Reviewing separation monies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_3)

- If given name is not a nickname or shortened version, go to step 5.

- Determine if the last name meets the criteria for a spelling equivalency (Mc/Mac, St/Saint, ie/ei, eu/ue).

- If the last name meets the spelling equivalency criteria, go to Reviewing separation monies .
               [Reviewing separation monies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_3)

- If the last name does not meet the spelling equivalency criteria, go to step 5.

- Determine if both of the following conditions are met:

- The given name is a nickname or shortened version of the name on the application or the ROE.

- The last name meets the criteria for a spelling equivalency (Mc/Mac, St/Saint, ie/ei, eu/ue).

- If both conditions are met, go to Reviewing separation monies .
                   [Reviewing separation monies](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_3)

- If both conditions are not met, go to step 5.

- On the calculation worksheet, note that the officer must refer to Determining if an ROE has been issued with the wrong SIN to determine if the ROE was issued with the wrong SIN. Return to Determining if an ROE must be reviewed to determine if there is another ROE in the QP that requires review or correction. 

#### Reviewing separation monies

Source topic: `en_EN/task/calc_determining/review_roe/reviewing_separation_monies_level_1.dita`

- Determine if block 17C: Other Monies contains any entries:

- If there are no entries, go to Determining if the Allocation of monies section must be completed .
               [Determining if the Allocation of monies section must be completed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_4)

- If there are entries, go to step 2.

- Determine if any of the entries display Bonus :

- If any entry displays Bonus , go to step 3.

- If no entry displays Bonus , go to step 6.

- Determine if the selection in the Bonus submenu is Other or blank:

- If either Other or blank is selected, go to step 4.

- If neither Other nor blank is selected, go to step 6.

- Determine if block 18: Comments , the Additional information field or any document on file provides the required details of the bonus money:

- If the details are not provided, go to step 5.

- If the details are provided, do the following:

- Determine the type of bonus money paid ( Digest 5.14 ).
                   [Digest 5.14](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/bonuses-gratuities-tips.html#a5_14_0)

- Bonus submenu: Select the correct type from the drop-down. Do not leave it as Other unless you are certain the money should be allocated on separation and included as insurable separation money.

- Go to step 6.

- On the calculation worksheet, note that you need to call the employer and ask the following questions:

- When was the bonus money paid?

- What were the conditions under which bonus money was payable?

- Was it due to productivity of the employee or the employee’s work group? If so, how was the payment determined? Based on an hourly rate, based on the number of pieces produced?

- Was it paid because of an event (i.e. Christmas)?

- Was it paid because the company overall showed a profit and the payment was not related to the individual productivity of the employee or the employee’s work group?

- Was it a condition of the contract of employment as part of the normal salary or wages paid? If so, for what period was it paid?

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2333.dita)

- Determine if any of the entries in block 17C, Other Monies are listed as Other .

- If none of the entries are listed as Other , go to Determining if the Allocation of monies section must be completed .
               [Determining if the Allocation of monies section must be completed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_4)

- If any of the entries are listed as Other , go to step 7.

- Determine if block 18: Comments , the Additional information field or any document on file provides the required details of the other money.

- If the details are not provided, go to step 8.

- If the details are provided, do the following:

- Determine the type of money paid ( Digest 5 & Earnings Chart ).
                   [Digest 5](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/table-of-contents.html) 
                   [Earnings Chart](/en/procedure/generic/additionalresources/chart_insurable_earnings.shtml)

- In block 17C: Other Monies (Specify) , select the correct type from the drop-down. Do not leave it as Other unless you are certain the money should be allocated on separation and included as insurable separation money.

- Go to Determining if the Allocation of monies section must be completed .
                   [Determining if the Allocation of monies section must be completed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_4)

- On the calculation worksheet, note that you need to call the employer and ask the following questions:

- When was the other money paid?

- What was the other money paid for?

- Why was the other money paid? Was it paid due to separation or for some other reason such as banked overtime?

- Go to Determining if the Allocation of monies section must be completed .
               [Determining if the Allocation of monies section must be completed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_4) 

#### Determining if the Allocation of monies section must be completed

Source topic: `en_EN/task/calc_determining/review_roe/determining_if_the_allocation_of_monies_1626dd3a_level_1.dita`

- Determine if the client has provided an NWE or ELWW amount after filing the application :

- If no, go to Reviewing the Comments block and Additional information field .
               [Reviewing the Comments block and Additional information field](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_5)

- If yes, determine if the amount provided appears reasonable when compared to the ROE:

- If no, ignore the amount provided and go to Reviewing the Comments block and Additional information field .
                   [Reviewing the Comments block and Additional information field](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_5)

- If yes, go to step 2.

- In the Allocation of monies section, complete the following fields:

- Average normal weekly earnings: Enter the NWE amount provided by the client.

- Average earnings last week worked: Enter the ELWW amount provided by the client.

- Go to Reviewing the Comments block and Additional information field .
               [Reviewing the Comments block and Additional information field](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_5) 

#### Reviewing the Comments block and Additional information field

Source topic: `en_EN/task/calc_determining/review_roe/reviewing_the_comments_block_and_additi_e83124b3_level_1.dita`

- Determine if any information in block 18: Comments or the Additional information field of the ROE requires action:

- If no information requires action, go to Validating the ROE .
               [Validating the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_6)

- If any information requires action, determine if it relates to the RFS:

- If it relates to the RFS, go to step 2.

- If it does not relate to the RFS, go to step 5.

- Determine if the RFS in block 16 must be changed. (Refer to ROE comments job aid .)

- If a change is required, go to step 3.

- If no change is required, go to step 4.

- Determine if a change to the RFS results in a difference between the ROE and the RFS as stated by the client on the application:

- If there is no difference, go to step 4.

- If there is a difference:

- Note that fact-finding with the client is required.

- Go to step 4.

- Determine if any information in block 18: Comments or the Additional information field is related to the earnings:

- If the information is related to earnings, go to step 5.

- If the information is not related to earnings, go to step 7.

- Determine if the earnings on the ROE must be changed. (Refer to the Earnings chart .)

- If the earnings on the ROE require changes, go to step 6.

- If the earnings do not require changes, go to step 7.

- Determine if additional details related to the earnings are needed:

- If additional details are not needed, go to step 7.

- If additional details are needed, note that fact-finding with the employer is required.

- Determine if the Additional information field indicates that a change was made to the ROE and not initialled by the employer:

- If no change was made, go to Validating the ROE .
               [Validating the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_6)

- If a change was made and not initialled, note that fact-finding with the employer is required to confirm that the change is correct and go to Validating the ROE .
               [Validating the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/review_roe#level1_item_6) 

#### Validating the ROE

Source topic: `en_EN/task/calc_determining/review_roe/validating_the_roe_level_1.dita`

- Select Validate .

- Determine if there are any errors present:

- If there are no errors present, go to step 3.

- If there are errors present, determine if any fact-finding is required for the ROE correction. (Refer to Correcting an error during calculation or recalculation — Regular ROE or Correcting an error during calculation or recalculation — Fisher ROE .)

- If no fact-finding is required, correct the ROE and go to step 3.

- If fact-finding is required, note the information required to correct the ROE and go to step 3.

               [Correcting an error during calculation or recalculation — Regular ROE](/en/procedure/task/correcting_roe_error_calculation_regular.shtml) 
               [Correcting an error during calculation or recalculation — Fisher ROE](/en/procedure/task/correcting_roe_error_calculation_fisher.shtml)

- If changes were made to the ROE, select Submit .

- Return to Determining if an ROE must be reviewed to determine if there is another ROE in the QP that requires review or correction. 

#### Determining the next procedure

Source topic: `en_EN/task/calc_determining/review_roe/determining_the_next_procedure_level_1.dita`

- Determine if you are calculating the claim in SSO:

- If you are determining if the claim is ready to be calculated, go to step 2.

- If you are calculating the claim in SSO, refer to step 5 of Calculating a claim in SSO .
               [Calculating a claim in SSO](/en/procedure/subactivity/calc_ssa_sb.shtml)

- Determine the benefit type (BT) requested for the calculation:

- If the BT is regular, return to step 7 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, return to step 7 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, return to step 7 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, return to step 7 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, return to step 7 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, return to step 7 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, return to step 7 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2332.dita`

Note:

You must go through the following steps and review each ROE falling in the QP. 

#### Note

Source topic: `en_EN/common_notes/note_c_2333.dita`

Note:

You are not limited to the above questions. The answers to those may lead to other questions. You may determine that the employer has used the term “bonus money” when in fact the money was paid for some other reason such as a retiring allowance. 

## Policy reference

Source topic: `en_EN/task/calc_determining/review_roe/policy_reference.dita`

 
