# Determining if a previous claim is renewable — Sickness benefits

Source map: `en_EN/task/calc_determining/renclaim_sb/renclaim_sb.ditamap`

## Summary

Source topic: `en_EN/task/calc_determining/renclaim_sb/summary.dita`

Summary: When a client applies for benefits and has a previous claim, the officer must determine if the client’s previous claim can be renewed. 

## What you need to know

Source topic: `en_EN/task/calc_determining/renclaim_sb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/renclaim_sb/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Determining if a previous claim is renewable

Source topic: `en_EN/task/calc_determining/renclaim_sb/determining_if_a_previous_claim_is_renewable.dita`

When the client starts the electronic application, ACP interfaces with the mainframe in order to determine if a previous benefit period (BP) exists and, if so, whether it is renewable. Depending on the claim data found, the client is presented with either the initial or renewal application for benefits. When ACP cannot determine whether renewability is an option at the onset of the application, the long form of the application is presented. The long form of the initial application and of the renewal application includes questions that are unique to each.
       [benefit period](/en/procedure/generic/knowledge.shtml#Establishing_a_benefit_period)

If ACP determines that a previous BP is renewable, it assigns a renewal registration number and attempts to renew the claim. If unable to automate the renewal, ACP creates a CA Renewal WI. It is rare (i.e. an anomaly) for ACP to assign an initial registration number or create a CA Initial WI when there is a renewable claim.

One scenario where a claim may be registered as initial, but should be a renewal is when the client applies more than 4 weeks after the last renewable week of the previous claim. In such cases, if ACP is unable to automate the claim, an initial registration number is assigned and a CA WI created. If the client then requests an antedate for a week that falls within the preceding BP and the antedate is allowed, the claim is processed as a renewal.

It is also possible that an officer actioning a Claim Setup (CS) WI or registering a paper application might incorrectly assign an initial registration number or terminate the previous claim when inputting an Initial Intake (M149) transaction.

Unless there is documentation indicating that the client has opted to start a new claim (the officer refers to Terminating a benefit period ), an application for benefits must always be processed as a renewal when a previous claim has a week or more remaining that is payable (the officer refers to Maximum entitlement to benefits ).
       [Terminating a benefit period](/en/procedure/task/benefit_period_term.shtml) 
       [Maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

To qualify for sickness benefits, clients must meet one of the following conditions:

- Clients must be major attached (have at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment. Refer to Defining minor and major attached clients – Common entrance requirement (from w/c2310 to w/c 2361) .
         [major attached](/en/procedure/generic/knowledge.shtml#major_attached) 
         [Defining minor and major attached clients – Common entrance requirement (from w/c2310 to w/c 2361)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/renclaim_sb#_Defining_minor_and)

- Clients must be minor attached (has fewer than 600 hours of insurable employment) and qualify for regular benefits with a reason for separation (RFS) other than illness, injury or quarantine.
         [minor attached](/en/procedure/generic/knowledge.shtml#minor_attached)

- Clients who are subject to increased entrance requirements must have sufficient insurable hours to establish a regular BP.
         [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Defining major and minor attached clients

Source topic: `en_EN/task/calc_determining/renclaim_sb/defining_major_and_minor_attached_clients.dita`

Clients are major attached when they have accumulated at least 600 hours of insurable employment during their qualifying period (QP). The claim type (CT) is 3 - Sickness - major attached .

Clients are minor attached when they have accumulated between 420 and 599 hours of insurable employment during their QP. Minor attached clients have the required number of hours to establish a claim for regular benefits but they do not have the required 600 hours for sickness benefits. Minor attached clients are entitled to sickness benefits only if the reason for separation (RFS) is other than illness. The CT is 9 - Sickness - minor attached .

**Defining minor and major attached clients — Common entrance requirement (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national common entrance requirement (CER) of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits, regardless of the renewal date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

## Regional considerations

Source topic: `en_EN/task/calc_determining/renclaim_sb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_determining/renclaim_sb/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/calc_determining/renclaim_sb/in_nws.dita`

- Is there an SROC, Action Item (AI) or Call Back (CB) WI indicating that the client wants to start a new claim rather than renew the previous claim?

- If the client is minor attached, what is the RFS from the last employment? 

### In Imaging:

Source topic: `en_EN/task/calc_determining/renclaim_sb/in_imaging.dita`

- Is there a document indicating that the client wants to start a new claim rather than renew the previous claim? 

### In FTS:

Source topic: `en_EN/task/calc_determining/renclaim_sb/in_fts.dita`

- Is the renewable claim dormant or active?

- Have weeks of benefits already been paid on the renewable claim?

- Does the client have a violation on the renewable claim?

- Is the client major or minor attached on the renewable claim?

- If the client is minor attached, is the client entitled to sickness benefits? 

## Step by step

Source topic: `en_EN/task/calc_determining/renclaim_sb/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_determining/renclaim_sb/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/calc_determining/renclaim_sb/reviewing_the_file_level_1.dita`

- Determine if there is a previous claim:

- If yes, go to step 2.

- If no, go to Calculating the current claim .
               [Calculating the current claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/renclaim_sb#_Calculating_the_current)

- Determine if the previous claim can be renewed:

- If yes, go to step 3.

- If no, go to Calculating the current claim .
               [Calculating the current claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/renclaim_sb#_Calculating_the_current)

- In NWS and Imaging, determine if there is documentation indicating that the client wants to start a new claim rather than renew the previous claim:

- If no documentation is on file, go to step 4.

- If the documentation is on file, go to Calculating the current claim .
               [Calculating the current claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/renclaim_sb#_Calculating_the_current)

- Determine if either of the following conditions is met on the previous claim (refer to Maximum entitlement to benefits ):

- The client received the maximum number of weeks of sickness benefits.

- The client received the maximum combination of regular and special benefits.

- If neither condition is met, go to step 5.

- If either condition is met, go to step 7.

- In FTS, determine if any of the following conditions are met on the previous claim:

- The client received special benefits.

- The client is subject to increased entrance requirements and qualifies for regular benefits.

- The client is not subject to increased entrance requirements and is major attached or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.

- If no condition is met, go to step 6.

- If any condition is met, go to Renewing the previous claim .
                   [Renewing the previous claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/renclaim_sb#renew)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2298.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2299.dita)

- In NWS, determine if the client became sick while receiving regular benefits:

- If yes, go to Renewing the previous claim .
               [Renewing the previous claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/renclaim_sb#renew)

- If no, determine the reason the client has currently stopped working at the last employment:

- If the client stopped working due to sickness, go to step 7.

- If the client stopped working due to any reason other than sickness, go to Renewing the previous claim .
                   [Renewing the previous claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/renclaim_sb#renew)

- Determine if the client qualifies for the benefit type (BT) requested on the new claim:

- If yes, go to Calculating the current claim .
               [Calculating the current claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/renclaim_sb#_Calculating_the_current)

- If no, go to Renewing the previous claim .
               [Renewing the previous claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/renclaim_sb#renew) 

#### Calculating the current claim

Source topic: `en_EN/task/calc_determining/renclaim_sb/calculating_the_current_claim_level_1.dita`

- Refer to step 3 of Determining if a claim is ready to be calculated — Sickness benefits . 

#### Renewing the previous claim

Source topic: `en_EN/task/calc_determining/renclaim_sb/renewing_the_previous_claim_level_1.dita`

- Determine if this is an initial calculation or a recalculation:

- If this is an initial calculation, go to step 2.

- If this is a recalculation, go to step 3.

- In NWS, on the Specific Details tab of the Claim Assessment or Specialized Application WI, change the claim type as follows:

- Claim Type: Select Renewal .

- Select Save .

- Determine if a renewal is within your user profile:

- If it is within your user profile, go to step 4.

- If it is not within your user profile, go to step 6.

- Determine if the renewal is blocked:

- If no, go to step 5.

- If yes, refer to Voiding a benefit period before proceeding to step 5.
               [Voiding a benefit period](/en/procedure/task/benefit_period_void.shtml)

- Refer to Conversion and renewal for guidance on how to action the WI.

- In NWS, reassign the calculation WI as follows:

- Destination: Select Next available user .

- Reason: Select Unable to complete .

- Details: Type “Renewals not within profile.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_2298.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, the definitions of major and minor attached clients do not apply regardless of the renewal date. 

#### Note

Source topic: `en_EN/common_notes/note_c_2299.dita`

Note:

All insurable hours included in the QP , including hours from any excluded employment, are used to determine if the client is major or minor attached. When a client has 600 or more insurable hours in the QP, but some of those insurable hours were excluded from the calculation, the excluded hours are not included in the Qualifying period - Insured hours field on the Rate/Duration tab in FTS. In this situation, the Major Attached box is checked on the Rate/Duration tab to identify the client as major attached.
       [QP](/en/procedure/generic/knowledge.shtml#Qualifying_periodl)

     [QP](/en/procedure/generic/knowledge.shtml#Qualifying_periodl) 

## Policy reference

Source topic: `en_EN/task/calc_determining/renclaim_sb/policy_reference.dita`

- Digest 1.4.0 - Benefit period structure
         [Digest 1.4.0 - Benefit period structure](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-1/benefit-period-structure.html#a1_4_0)

- EIA 10
         [EIA 10](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-10.html) 
