# Determining if a medical certificate must be submitted: Sickness benefits — Initial claims

Source map: `en_EN/task/calc_determining/det_mc_ra/det_mc_ra.ditamap`

## Summary

Source topic: `en_EN/task/calc_determining/det_mc_ra/summary.dita`

Summary: Clients applying for sickness benefits must always obtain a medical certificate, which proves their inability to work due to illness and, in some cases, must submit the medical certificate before benefits can be paid. 

## What you need to know

Source topic: `en_EN/task/calc_determining/det_mc_ra/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/det_mc_ra/untitled_section.dita`

In NWS:

- Has a medical certificate or a Sickness: INS5140 Medical certificate — Form been uploaded?

- Is there an SROC or Action Item (AI) WI with a medical certificate transcribed?

In Imaging:

- Is there a medical certificate?

In RCM:

- Has the last ROE been received?

- If yes, what is the RFS? 

### Applying for sickness benefits

Source topic: `en_EN/task/calc_determining/det_mc_ra/applying_for_sickness_benefits.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2254.dita) 

An acceptable medical certificate completed by a doctor or by another approved medical practitioner confirming the client’s sickness must be obtained for each week the client requests sickness benefits.
       [acceptable](/en/procedure/task/determining_med_cert_valid.shtml)

Clients applying for sickness benefits using a paper application are advised to submit a medical certificate with the application. Clients applying for sickness benefits using AW can upload the medical certificate immediately. If clients do not submit the medical certificate and the last RFS is illness, clients are advised that it must be submitted if the duration of the illness or injury is greater than 9 weeks. Otherwise, clients are advised to keep the medical certificate for 6 years since it can be requested at a later date. Clients applying for sickness benefits using AW who indicate an RFS other than illness are advised to submit the medical certificate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0045.dita) 

### Determining if a medical certificate must be submitted

Source topic: `en_EN/task/calc_determining/det_mc_ra/determining_if_a_medical_certificate_mu_d4cdaa5c.dita`

A client applying for sickness benefits using a paper application is advised to submit a medical certificate with the application. A client applying for sickness benefits using the online application who indicates the reason for separation (RFS) from the last employer is illness is advised to keep the medical certificate for 6 years and that it may be requested at a later date. A client applying online for sickness benefits who indicates an RFS other than illness is advised to submit the medical certificate.

It is not always necessary for a client to submit a medical certificate. However, if one is submitted, the officer must review it to ensure it is acceptable and use it to determine the recovery week.

To determine if a client has submitted a medical certificate, the officer reviews the file for uploaded or transcribed documents in NWS, and imaged documents in Imaging.

Linguistic Services must translate medical certificates that are completed in a language other than English or French to be considered acceptable. 

### Medical certificate is not required to be submitted

Source topic: `en_EN/task/calc_determining/det_mc_ra/medical_certificate_is_not_required_to__220d00fd.dita`

The officer must request a medical certificate only when the client is required to submit it.

The client is not required to submit a medical certificate if all of the following conditions are met:

- The client is major attached (i.e. the client has worked at least 600 hours of insurable employment).

- The RFS on the last ROE is sickness or injury and the client is applying for either sickness benefits or sickness benefits combined with maternity benefits or the client is requesting sickness benefits on an initial subsequent claim immediately following a renewal claim for sickness and the RFS was sickness on the last ROE.

- None of the following disqualifications or disentitlements apply to the claim, regardless of whether they were imposed due to the adjudication or the deferral of a contentious RFS:

- 10 - Dismissal - misconduct proven (D10);

- 11 - Voluntary leaving - just cause not proven (D11);

- 42 - Suspension from employment (D42);

- 43 - Leave of absence (D43);

- 44 - Anticipated loss of employment (D44).

**Common entrance requirement — Temporary measure (from w/c 2310 to w/c 2361)**

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the definitions of major and minor attached do not apply. For the duration of the measure, clients whose claim is established with 420 hours of insurable employment or more qualify for special benefits. The officer ensures that all other qualifying and entitlement conditions are met. 

### Medical certificate must be submitted

Source topic: `en_EN/task/calc_determining/det_mc_ra/medical_certificate_must_be_submitted.dita`

The client must submit an acceptable medical certificate in any of the following situations:

- The client is minor attached and the RFS for the most recent period of employment is not sickness.

- The RFS on the last ROE is not sickness.

- One of the following disqualifications or disentitlements applies to the claim, regardless of whether it was imposed due to the adjudication or the deferral of a contentious RFS:

- D10

- D11

- D42

- D43

- D44

- There is a medical certificate on file that is not acceptable . This applies even when the RFS on the last ROE is sickness or injury, and the client is applying for either sickness benefits or sickness benefits combined with maternity benefits.
         [acceptable](/en/procedure/task/determining_med_cert_valid.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0878.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2255.dita) 

### Imposing a disentitlement

Source topic: `en_EN/task/calc_determining/det_mc_ra/imposing_a_disentitlement.dita`

If a medical certificate is requested but has not been submitted, the officer must note that the medical certificate must be input as missing in the Outstanding information field of the Registration screen in SSO. The Medical certificate field of the Annex - Special Benefits screen in SSO is automatically prefilled with No and an indefinite disentitlement ( 16 - No medical certificate submitted [D16]) is imposed by SSO from BPC when the claim is calculated. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2254.dita`

Note:

The temporary measure for medical certificates ends September 25, 2021. For all benefit periods (BPs) with a BPC or renewal week of September 26, 2021 (w/c 2310) or later, the officer follows normal procedures.

For BPs with a BPC or renewal week between March 15, 2020 (w/c 2230) and September 19, 2021 (w/c 2309), a client is not required to provide a medical certificate to receive sickness benefits. For more details, the officer refers to the previous version of this task by selecting the link at the bottom of the page. 

### Note

Source topic: `en_EN/common_notes/note_c_0045.dita`

Note:

When a medical certificate is uploaded, the officer or the client must complete a Medical Certificate electronic questionnaire. The electronic questionnaire is not medical proof. The officer does not use it to determine a recovery week or period of incapacity. 

### Note

Source topic: `en_EN/common_notes/note_c_0878.dita`

Note:

Even if the RFS on the last ROE is sickness, if any of the disqualifications or disentitlements above apply to the claim, or the medical certificate is not acceptable, the client must submit an acceptable medical certificate. 

### Note

Source topic: `en_EN/common_notes/note_c_2255.dita`

Note:

For information on determining the recovery week, the officer can refer to Modifying the sickness benefits information on the annex for special benefits in SSO .
       [Modifying the sickness benefits information on the annex for special benefits in SSO](/en/procedure/task/calc_calculating/ent_recdate_ssa_sb.shtml)

     [Modifying the sickness benefits information on the annex for special benefits in SSO](/en/procedure/task/calc_calculating/ent_recdate_ssa_sb.shtml) 

## Regional considerations

Source topic: `en_EN/task/calc_determining/det_mc_ra/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_determining/det_mc_ra/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/calc_determining/det_mc_ra/untitled_section.dita`

In NWS:

- Has a medical certificate or a Sickness: INS5140 Medical certificate — Form been uploaded?

- Is there an SROC or Action Item (AI) WI with a medical certificate transcribed?

In Imaging:

- Is there a medical certificate?

In RCM:

- Has the last ROE been received?

- If yes, what is the RFS? 

## Step by step

Source topic: `en_EN/task/calc_determining/det_mc_ra/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_determining/det_mc_ra/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/calc_determining/det_mc_ra/reviewing_the_file_level_1.dita`

- Determine if there is a medical certificate on file:

- If yes and the medical certificate is not in English or French, go to step 2.

- If yes and the medical certificate is in English or French, go to step 9.

- If no, go to step 10.

- Determine if a request for translation has been sent:

- If yes, go to step 3.

- If no, go to Medical certificate requires translation .
               [Medical certificate requires translation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/det_mc_ra#translation)

- Determine if the translation has been received:

- If yes, go to step 4.

- If no, go to Medical certificate requires translation .
               [Medical certificate requires translation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/det_mc_ra#translation)

- Determine if the translation has been saved:

- If no, go to step 5.

- If yes, go to step 9.

- Save a copy of the translation received from Linguistic Services.

- In NWS, create a new SROC to record the translation as follows:

- Main Issue: Select Medical Proof .

- Comments: Type “Medical certificate translation.”

- Details: Type “Medical certificate translation received as follows: [copy the translation as provided on the email from Linguistic Services].”

- Select Save .

- In Outlook, delete the emails regarding the translation request and response (both sent and received).

- Send the original medical certificate and the saved copy of the translation to Imaging to be put away.

- Determine if the medical certificate is acceptable (refer to Determining if a medical certificate is acceptable ):

- If the medical certificate is not acceptable, go to step 11.

- If the medical certificate is acceptable, go to Acceptable medical certificate on file .
               [Acceptable medical certificate on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/det_mc_ra#_Acceptable_medical_certificate)

- If the authenticity of the medical certificate or the doctor’s signature raises doubts, refer the medical certificate to Integrity for review.
               [Integrity](/en/procedure/activity/referal_integrity.shtml)

- Determine if all of the following conditions are met:

- The client is major attached (has accumulated at least 600 insurable hours) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.

- The RFS on the last ROE is sickness or injury and the client is applying for either sickness benefits or sickness benefits combined with maternity benefits or the client is requesting sickness benefits on an initial subsequent claim immediately following a renewal claim for sickness benefits, and the RFS on the last ROE was sickness.

- None of the following disqualifications or disentitlements apply to the claim, regardless of whether they were imposed due to the adjudication or the deferral of a contentious RFS:

- D10

- D11

- D42

- D43

- D44

- If no, go to step 11.

- If yes, go to Medical certificate not requested and not on file .
               [Medical certificate not requested and not on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/det_mc_ra#_Medical_certificate_not)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2256.dita)

- Determine if fact-finding for an acceptable medical certificate has occurred:

- If yes, go to Acceptable medical certificate requested and not on file .
               [Acceptable medical certificate requested and not on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/det_mc_ra#_Acceptable_medical_certificate_1)

- If no, go to Fact-finding .
               [Fact-finding](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_determining/det_mc_ra#_Fact-finding_required) 

#### Acceptable medical certificate on file

Source topic: `en_EN/task/calc_determining/det_mc_ra/acceptable_medical_certificate_on_file_level_1.dita`

- Determine the benefit type (BT) requested for the initial calculation:

- If the BT is sickness, refer to step 12 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml) 

#### Medical certificate not requested and not on file

Source topic: `en_EN/task/calc_determining/det_mc_ra/medical_certificate_not_requested_and_n_3b68c096_level_1.dita`

- Determine the BT requested for the initial calculation:

- If the BT is sickness, refer to step 12 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml) 

#### Acceptable medical certificate requested and not on file

Source topic: `en_EN/task/calc_determining/det_mc_ra/acceptable_medical_certificate_requeste_68ee8138_level_1.dita`

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “Medical certificate not submitted — disentitlement imposed.”

- Details: Type “Not allowed — no medical certificate submitted from beginning date of claim. Reference: EIA 18.”

- On the calculation worksheet, note that when reviewing the Registration screen in SSO, the officer must indicate that an acceptable medical certificate was not received.

- Determine the BT requested for the initial calculation:

- If the BT is sickness, refer to step 12 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml) 

#### Medical certificate requires translation

Source topic: `en_EN/task/calc_determining/det_mc_ra/medical_certificate_requires_translation_level_1.dita`

- Determine if a request for translation has been sent:

- If no, go to step 2.

- If yes, go to step 6.

- Black out the client’s SIN and any images (e.g. an X-ray) from the medical certificate being sent for translation.

- Save a copy of the medical certificate that requires translation into PDF format.

- In Outlook, open and complete the Medical Certificate: Email to request translation — Template as follows:

- To: EDSC.SSIO.ServicesLinguistiques-LinguisticServices.ISSO.ESDC@servicecanada.gc.ca (this field is prefilled).
               [EDSC.SSIO.ServicesLinguistiques-LinguisticServices.ISSO.ESDC@servicecanada.gc.ca](/resources/ort/documents/Foreign-Language-204190.msg)

- Subject: Foreign Language — 204190 (this field is prefilled).

- Your name: Enter your name.

- Your email address: Enter your email address.

- Cost centre: 204190 (this field is prefilled).

- Document title to be translated: Enter the file name of the document.

- Word count: N/A (this field is prefilled).

- Source language and target language: Type “[Language of document] to [language of client displayed in FTS].” (e.g. Polish to English).

- Date required by: Enter today’s date + 21 calendar days.

- Additional instructions: N/A (this field is prefilled).

- Attach the medical certificate.

- Select Send .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2257.dita)

- On the calculation worksheet, note that the calculation WI must be moved to Pending for 10 business days. Go to step 9.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2258.dita)

- Determine if a follow-up request for the translation has been sent:

- If no, go to step 7.

- If yes, go to step 10.

- In the email application, forward a copy of the original email sent as follows:

- To: Type “ EDSC.SSIO.ServicesLinguistiques-LinguisticServices.ISSO.ESDC@servicecanada.gc.ca .”
               [EDSC.SSIO.ServicesLinguistiques-LinguisticServices.ISSO.ESDC@servicecanada.gc.ca](mailto:EDSC.DGPSI.ServicesLinguistiques-LinguisticServices.BISB.ESDC@servicecanada.gc.ca)

- In the body of the email, type “Follow-up required for translation request previously submitted.”

- Select Send .

- On the calculation worksheet, note that the calculation WI must be moved to Pending for 5 business days.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2258.dita)

- Determine the BT requested for the initial calculation:

- If the BT is sickness, refer to step 12 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- Send an enquiry to your business expertise advisor for follow-up before proceeding. 

#### Fact-finding

Source topic: `en_EN/task/calc_determining/det_mc_ra/fact-finding_level_1.dita`

- On the calculation worksheet, note that fact-finding with the client to request an acceptable medical certificate is required. Also note that if the client is reached and indicates that an acceptable medical certificate will be submitted, the calculation WI will be moved to Pending as follows:

- If the client does not provide an exact date, the WI is moved to Pending for 10 business days.

- If the client does provide an exact date, the WI is moved to Pending until 5 business days after the date the medical certificate is due.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2237.dita)

- Determine the BT requested for the initial calculation:

- If the BT is sickness, refer to step 12 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2256.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, the definitions of major and minor attached clients do not apply. 

#### Note

Source topic: `en_EN/common_notes/note_c_2257.dita`

Note:

Do not include the client’s SIN or any images in the email or the medical certificate. If a SIN or an image is documented on the medical certificate, it must be blacked out before the medical certificate is sent. 

#### Note

Source topic: `en_EN/common_notes/note_c_2258.dita`

Note:

Once the WI returns to the normal workload, return to this task. 

#### Note

Source topic: `en_EN/common_notes/note_c_2237.dita`

Note:

Once fact-finding is complete, return to this task. 

## Policy reference

Source topic: `en_EN/task/calc_determining/det_mc_ra/policy_reference.dita`

- EIA 49
         [EIA 49](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-49.html) 
