# Completing an ROE Issue RFS Action WI: B - Other — Fishing ROE

Source map: `en_EN/task/completing_roe_fishing_roe/completing_roe_fishing_roe.ditamap`

## Summary

Source topic: `en_EN/task/completing_roe_fishing_roe/summary.dita`

Summary: When a fishing ROE (serial number starting with Z or Y ) is received with a reason for separation (RFS) B - Other on an initial Web application, if the system is unable to create a link between the ROE and a matching period of employment or determine if the issue requires adjudication, an ROE Issue (ROE) RFS Action WI is created. 

## What you need to know

Source topic: `en_EN/task/completing_roe_fishing_roe/what_you_need_to_know.dita`

### Linking the ROE and the matching period of employment

Source topic: `en_EN/task/completing_roe_fishing_roe/linking_the_roe_and_the_matching_period_f71580ff.dita`

When an ROE RFS Action WI is received and a link has not yet been created between the ROE and a period of employment, the Non-complex agent must review the applicable ROE in RCM and the periods of employment listed in NWS. The Non-complex agent determines if one of the periods of employment listed in NWS matches the employer’s name on the ROE.

**Variations in the employer’s name**

Minor spelling differences between the employer’s name on the ROE and the period of employment are accepted. The agent must also consider that the employer may do business under more than one name. For example, the ROE indicates that the employer’s name is 123456 ONT Inc., but the client reported working for ABC Fisheries. If the documentation on file or the Employer search (by business number) in FTS indicates that 123456 ONT Inc. operates as ABC Company, the names are equivalent and considered to be a match.

**Reviewing the dates on the ROE**

Only one ROE can be matched to each period of employment listed in NWS. The agent must review the Search / Correct - Results screen in RCM to determine if the ROE in the ROE RFS Action WI is the one with the last day paid (LDP) closest to the last day worked (LDW) for one of the periods of employment. The agent creates a link between the ROE and the period of employment with the matching employer’s name and best match for LDP and LDW. If either the employer’s name does not match or the LDP and LDW are not a good match, the agent does not create a link between the ROE and the period of employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2670.dita) 

**More than one ROE for one period of employment**

There may be more than one ROE but only one period of employment for the same employer.

**Example 1**

- Period of employment information declared on application:
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2671.dita)

- Search / Correct - Results in RCM:

```text
| SN | Employer | FDW / TSD | LDP / TED | Modified | Input | RFS | Audit | EHF |

| Z/Y12345678 | ABC Fisheries | 04/04/2016 | 08/04/2016 | 07/10/2016 | 04/10/2016 | B | | |

| Z/Y12341234 | ABC Fisheries | 29/03/2016 | 01/04/2016 | 07/10/2016 | 04/10/2016 | B | | |
```

- ROE RFS Action WI #1 for Z/Y12345678

- The agent completes the period of employment information section as follows:

- Matching POE : Select ABC Fisheries .

- ROE RFS Action WI #2 for Z/Y12341234

- The agent completes the period of employment information section as follows:

- Matching POE : Select POE not in the list .

There may also be more than one period of employment for the same employer.

**Example 2**

- Period of employment information declared on application:
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2672.dita) 
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2673.dita)

- Search / Correct - Results in RCM:

```text
| SN | Employer | FDW / TSD | LDP / TED | Modified | Input | RFS | Audit | EHF |

| Z/Y12345678 | ABC Fisheries | 10/06/2015 | 10/10/2015 | 15/12/2015 | 15/12/2015 | B | | |

| Z/Y12341234 | ABC Fisheries | 12/04/2015 | 13/05/2015 | 15/12/2015 | 15/12/2015 | B | | |
```

- ROE RFS Action WI #1 for Z/Y12345678

- The agent completes the period of employment information section as follows:

- Matching POE : Select ABC Fisheries (LDW 02/10/2015).

- ROE RFS Action WI #2 for Z/Y12341234

- The agent completes the period of employment information section as follows:

- Matching POE : Select ABC Fisheries (LDW 30/05/2015).

**ROE already linked**

If the ROE is linked to a period of employment with a corresponding electronic record of decision (ROD) or an outstanding Adjudication Issue (ADJ) WI, the ROE RFS Action WI is completed without further action by the Non-complex agent. 

### Completing the Resolve Issue section

Source topic: `en_EN/task/completing_roe_fishing_roe/completing_the_resolve_issue_section.dita`

If the ROE is not linked to a period of employment or if the ROE is linked to a period of employment without a corresponding electronic ROD or ADJ WI, the agent must complete the Resolve Issue section of the ROE RFS Action WI before completing the WI. When resolving the issue, the agent must review the ROE and the existing RODs.

**Comments in block 18**

If the ROE was issued with comments in block 12 , the agent must determine if the correct RFS is indicated on the ROE. Any required changes to the RFS details must be made in the Resolve Issue section of the ROE RFS Action WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2674.dita) 

**Reason for separation (RFS) options on fishing ROEs**

There are only 2 RFS options on a paper fishing ROE: A - End of fishing and B - Other . There are 3 RFS options on a Web fishing ROE: A - End of fishing, A - Requested by Fisher and B - Other . In RCM, all 3 options are available when inputting a fishing ROE. There is no Special Condition option on a fishing ROE.

**Reviewing existing records of decision (RODs) on file**

If there is an existing ROD indicating that the RFS is contentious, the agent must not modify the RFS details when completing the Resolve Issue section of the ROE RFS Action WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2675.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_2670.dita`

Note:

The LDP is the final trip end date (fresh) or date of purchase (cured) on a fishing ROE. 

### Callout

Source topic: `en_EN/common_notes/note_c_2671.dita`

- Employer: ABC Fisheries

- First day worked: 29/03/2016

- Last day worked: 08/04/2016

- Reason for separation: Quit 

### Callout

Source topic: `en_EN/common_notes/note_c_2672.dita`

- Employer: ABC Fisheries

- First day worked: 01/06/2015

- Last day worked: 02/10/2015

- Reason for separation: Strike or Lockout 

### Callout

Source topic: `en_EN/common_notes/note_c_2673.dita`

- Employer: ABC Fisheries

- First day worked: 01/04/2015

- Last day worked: 30/05/2015

- Reason for separation: Shortage of work 

### Note

Source topic: `en_EN/common_notes/note_c_2674.dita`

Note:

If there are comments in block 12 of the last ROE , the system creates an ROE Comments WI. The agent actioning the ROE Comments WI evaluates the comments in block 12 and may move the comments into the Additional information field in RCM. 

### Note

Source topic: `en_EN/common_notes/note_c_2675.dita`

Note:

When an option is selected in the POE Information section of the Resolve Issue tab, the system displays the actions that will be taken once the ROE RFS Action WI is completed. If adjudication of the RFS issue is required, an ADJ WI is automatically reactivated or created. 

## Regional considerations

Source topic: `en_EN/task/completing_roe_fishing_roe/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/completing_roe_fishing_roe/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/completing_roe_fishing_roe/in_nws.dita`

- What is the serial number and the RFS indicated in the Specific Details tab of the ROE RFS Action WI?

- What periods of employment are indicated in the Matching POE list of the ROE RFS Action WI?

- Is there a ROD indicating that the RFS has been adjudicated?

- If yes, what are the details of the decision?

- Is there an SROC clarifying the employer’s name? 

### In RCM:

Source topic: `en_EN/task/completing_roe_fishing_roe/in_rcm.dita`

- What ROEs are displayed on the Search / Correct - Results screen?

- What is the employer’s name in block 4 of the ROE?

- What is the final trip end date (fresh) or date of purchase (cured) in block 6B of the ROE?

- Is there an audit trail for the ROE?

- Does the audit trail contain a new value for the RFS in block 11 ?

- Are there comments in block 12 or the Additional information field of the ROE? 

### In FTS:

Source topic: `en_EN/task/completing_roe_fishing_roe/in_fts.dita`

- Does the Employer search indicate that the employer operates under another name? 

## Step by step

Source topic: `en_EN/task/completing_roe_fishing_roe/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/completing_roe_fishing_roe/non-complex.dita`

#### Linking the ROE and the matching period of employment

Source topic: `en_EN/task/completing_roe_fishing_roe/linking_the_roe_and_the_matching_period_f71580ff_non-complex.dita`

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, determine if there is a matching period of employment already selected in the Matching POE list:

- If no, go to step 2.

- If yes, go to step 6.

- Determine if the Matching POE list includes one or more periods of employment with the same employer’s name as the ROE:

- If there are one or more periods of employment with the same employer’s name as the ROE, go to step 3.

- If there is no period of employment with the same employer’s name as the ROE, select POE not in the list . Click Save and go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2676.dita)

- In RCM, review the Search / Correct - Results screen to determine if the ROE in the ROE RFS Action WI is the one with the same employer’s name and the LDP closest to the LDW for one of the periods of employment on the Matching POE list in the ROE RFS Action WI in NWS:

- If the ROE is for the same employer and the LDP on the ROE is the best match to the LDW for one of the periods of employment, go to step 4.

- If the ROE is for the same employer but the LDP on the ROE is not the best match to the LDW for one of the periods of employment, go to step 5.

- If the ROE is not for the same employer or the LDP on the ROE is clearly not a good match to the LDW for one of the periods of employment, go to step 5.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the POE information section as follows:

- Matching POE : Select the period of employment with the same employer’s name and best match for LDP and LDW.

- Click Save .

- Go to step 6.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the POE information section as follows:

- Matching POE : Select POE not in the list .

- Click Save .

- Go to step 6.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, determine if the Resolve Issue section is displayed:

- If the Resolve Issue section is displayed, go step 7.

- If the Resolve Issue section is not displayed, go to step 12. 

#### Ensuring the reason for separation (RFS) details are correct

Source topic: `en_EN/task/completing_roe_fishing_roe/ensuring_the_reason_for_separation_rfs__9dc9245b_non-complex.dita`

- In RCM, review block 12 and the Additional information field of the ROE and determine if there are comments related to the RFS:

- If yes, go to step 8.

- If no, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2677.dita)

- Determine if the ROE requires any of the following changes:

```text
| If the comments on the ROE indicate: | The RFS option in the ROE RFS Action WI must be changed to: |

| End of fishing | A - End of fishing |

| End of season (or an equivalent comment) | A - End of fishing |

| Quota reached | A - End of fishing |

| Requested by the fisher | A - End of fishing |
```

- If the ROE requires a change to A - End of fishing , go to step 9.

- If the ROE does not require changes, go to step 11.

           [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2678.dita)

- In NWS, determine if there is a ROD on file for the period of employment indicating that the RFS is other than shortage of work or end of fishing (e.g. labour dispute, voluntary leaving):

- If no, go to step 10.

- If yes, go to step 11.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Do the Reason for Separation details need to be modified?: Select Yes and select A - End of fishing .

- Go to step 12.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Do the Reason for Separation details need to be modified?: Select No .

- Go to step 12. 

#### Completing the WI

Source topic: `en_EN/task/completing_roe_fishing_roe/completing_the_wi_non-complex.dita`

- Complete the ROE RFS Action WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2676.dita`

Note:

When comparing the employer’s name on the period of employment and the ROE, accept minor spelling differences in the employer’s name. Consider that the employer may do business under more than one name (e.g. 123456 ONT INC does business as ABC Fisheries). In this case, review the documentation on file or use the Employer search (by business number) in FTS to determine if the employer’s name on the ROE is equivalent to the employer’s name on the period of employment. 

#### Note

Source topic: `en_EN/common_notes/note_c_2677.dita`

Note:

When actioning an ROE Comments WI, the agent may have moved the comments in block 12 of the ROE to the Additional information field in RCM. 

#### Warning

Source topic: `en_EN/common_notes/note_c_2678.dita`

Warning:

Do not modify the ROE in RCM. The next step explains how to modify the RFS details in the ROE RFS Action WI. 

## Policy reference

Source topic: `en_EN/task/completing_roe_fishing_roe/policy_reference.dita`

 
