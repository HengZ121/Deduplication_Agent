# Converting a claim from sickness to parental benefits

Source map: `en_EN/task/conv_sickpar/conv_sickpar.ditamap`

## Summary

Source topic: `en_EN/task/conv_sickpar/summary.dita`

Summary: After receiving sickness benefits, clients can request a conversion to parental benefits. 

## What you need to know

Source topic: `en_EN/task/conv_sickpar/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/conv_sickpar/untitled_section.dita`

Parental benefits allow parents to be away from their work to care for a newborn child or a child placed with the client for the purpose of adoption. Benefits may be requested and received from the date of birth (DOB), adoption or placement of the child. 

### Type of parental benefits

Source topic: `en_EN/task/conv_sickpar/type_of_parental_benefits.dita`

Parental benefits can be paid at either the standard parental benefit rate, or the extended parental benefits rate. The maximum number of parental entitlement weeks for a birth or adoption varies depending on the type of parental benefits the client receives and whether benefits are shared with other legally recognized parents. 

### Weeks of entitlement

Source topic: `en_EN/task/conv_sickpar/weeks_of_entitlement.dita`

A client is entitled to a maximum of 35 weeks of standard parental benefits or 61 weeks of extended parental benefits per birth or placement for adoption. The maximum parental entitlement is also the maximum number of parental entitlement weeks that can be paid in a benefit period (BP). The parental benefits can be paid over 2 BPs, but cannot be paid outside of the parental window (PW). The number of weeks of parental benefits a client is entitled to receive is not affected by the number of children born at the same time (twins, triplets, etc.) or by the number of children adopted at the same time. 

### Sharing parental benefits

Source topic: `en_EN/task/conv_sickpar/sharing_parental_benefits.dita`

Parents can share parental benefits. For more information and definitions, the officer can refer to Parents: Definition — Table .
       [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

The type of parental benefits requested by the first parent to apply for parental benefits determines the type of parental benefits all parents are entitled to receive for the same birth, adoption or placement, regardless of which parent is paid first. When fact-finding with parents who applied for benefits after the first parent, the officer informs the other parents of this. Once at least one week of parental benefits has been paid to any parent, all parents requesting parental benefits for the same birth, adoption or placement are only entitled to receive the type of parental benefits selected by the first parent who applied for parental benefits.

The maximum shareable entitlement is 40 weeks of standard parental benefits or 69 weeks of extended parental benefits for children born or placed for adoption on or after March 17, 2019. For children born or placed for adoption before this date, the maximum shareable entitlement is 35 weeks of standard parental benefits or 61 weeks of extended parental benefits. The maximum entitlement for one client remains at 35 weeks of standard or 61 weeks of extended benefits. Clients can change the number of weeks that each parent receives at any time before all benefits are paid. When clients cannot agree on the number of weeks they will each receive, the officer reassigns the issue to a Level 2 officer who adjudicates the division of the remaining weeks.

Clients who apply for parental benefits must provide the name and SIN of the other parent for control purposes. If the client does not provide the name and SIN of the other parent, or in the case of a single parent or a parent whose family situation is such that information on the child’s other parent cannot be obtained, the officer can still allow the claim.

**Validating shared parental benefits**

A Parental Client Record is created for every client requesting parental benefits. The Parental Client Record consists of the client’s SIN, the arrival or placement week (APW) and the other parent’s SIN, if it has been provided. Once a claim is finalized, the system links Parental Client Records for all clients who are sharing parental benefits for the same child. The Parental sharing validation process creates a Claim Review (CR) Parental Benefits Validation WI when one of the following conditions is met:

- The parental benefit type on all linked Parental Client Records is not the same.

- The total number of parental weeks requested on all linked Parental Client Records exceeds the maximum number of shareable parental benefit weeks.

**FTS**

The officer inputs the other parent’s SIN using the Parental Benefits Validation transaction in the Enquiry menu in FTS. This screen also displays linked parents’ SINs and the associated APW.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0138.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1486.dita) 

**Other parent’s SIN**

When the client has provided the other parent’s SIN, the officer manually enters it on the day following the parental input.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2717.dita) 

If the client’s SIN has already been linked to the other parent, no entry is necessary. 

### Qualifying for parental benefits

Source topic: `en_EN/task/conv_sickpar/qualifying_for_parental_benefits.dita`

Parental benefits can be paid if one of the following qualifying conditions is met:

- The client is major attached (has accumulated at least 600 hours of insurable employment).
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

- The BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2774.dita) 

**Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits, regardless of the conversion date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to parental benefits

Source topic: `en_EN/task/conv_sickpar/entitlement_to_parental_benefits.dita`

Parental benefits are payable during the PW to parents providing care for a child. To be entitled to parental benefits, the client must provide proof of birth, adoption or placement. A client does not have to collect all of the weeks of parental benefits consecutively. Payments of parental benefits can alternate with the payment of another benefit type (BT) or a return to work (RTW). Parental benefits can be paid in one BP or over 2 BP, as long as the maximum number of parental weeks is not exceeded and the end of the PW has not been reached. 

### Proof of birth, adoption or placement

Source topic: `en_EN/task/conv_sickpar/proof_of_birth_adoption_or_placement.dita`

Parents must supply proof of birth, adoption or placement depending on their relationship to the child or children. For more information, the officer refers to Parents: Definition —Table .
       [Parents: Definition —Table](/en/procedure/generic/parents_definition_table.shtml) 

### Extending the benefit period (BP)

Source topic: `en_EN/task/conv_sickpar/extending_the_benefit_period_bp.dita`

Under certain conditions, the BP can be extended to give clients more time to receive the benefits to which they are entitled. The BP can be extended for a maximum of 104 weeks to pay additional weeks of benefits when all of the conditions are met before the BP ends. For more information, the officer refers to Extension of the benefit period .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Parental window (PW)

Source topic: `en_EN/task/conv_sickpar/parental_window_pw.dita`

The PW is the period during which parental benefits can be paid. The PW starts and ends as follows:

- Start week:

- The APW is determined by the parent’s relationship to the child. For more information, the officer refers to Parents: Definition—Table .
             [Parents: Definition—Table](/en/procedure/generic/parents_definition_table.shtml)

- End week:

- For standard parental benefits, the end week is 52 weeks after the APW (APW + 52).

- For extended parental benefits, the end week is 78 weeks after the APW (APW + 78).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2804.dita) 

### Extending the benefit period (BP) and parental window (PW)

Source topic: `en_EN/task/conv_sickpar/extending_the_benefit_period_bp_and_par_bc66fc4a.dita`

Hospitalization of the child for whom parental benefits are being claimed is grounds to extend the BP and PW. The BP and PW can also be extended for personnel of the Canadian military who are unable to collect their parental benefits because of an imperative military requirement. For more information, the officer refers to Extension of the benefit period .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

The PW is also extended when a client entitled to parental benefits is entitled to a BP extension for special benefits. When this occurs, the BP and PW are both extended. For more information, the officer refers to Benefit period: Extension for special benefits — Table .
       [Benefit period: Extension for special benefits — Table](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml) 

### Terminating parental benefits during the parental window (PW) — Entitlement conditions are no longer met

Source topic: `en_EN/task/conv_sickpar/terminating_parental_benefits_during_th_507d8ff1.dita`

A client must meet the entitlement conditions for each week of parental benefits claimed. If the officer is informed that the client is no longer caring for the child during the PW, the officer imposes a definite or indefinite 34 - Parental benefits entitlement conditions not met disentitlement (D34) starting the Monday after the week in which the client is no longer entitled to benefits. For more information, the officer refers to Determining entitlement to parental benefits when the client is no longer caring for the child .
       [Determining entitlement to parental benefits when the client is no longer caring for the child](/en/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml) 

### Disentitlements

Source topic: `en_EN/task/conv_sickpar/disentitlements.dita`

The following disentitlements related to parental benefits are imposed when the client does not meet the entitlement conditions:

- A D34 is imposed when a client does not meet the entitlement conditions for one of the following reasons:

- The child’s DOB or date of placement is not indicated.

- There is no proof of placement for the purposes of adoption.

- There is no statement of the intent to care for the child.

- The client stops caring for the child during the PW.

- A 35 - Parental benefits - Qualifying Conditions Not Met disentitlement (D35) is imposed for one of the following reasons:

- The client is minor attached (less than 600 hours of insurable employment during the qualifying period).

- The parental benefits are exhausted.

- The maximum combination of special benefits has been paid.
             [maximum combination of special benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

- The maximum combination of regular and special benefits has been paid.
             [maximum combination of regular and special benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

- The claim was not made during the PW.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2653.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2720.dita) 

### Outstanding disentitlements

Source topic: `en_EN/task/conv_sickpar/outstanding_disentitlements.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies on the renewal (conversion). A Level 1 officer can terminate or rescind the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . If the information on file allows for the disentitlement to be terminated, it ends on the Friday of the week before the renewal (conversion) week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2805.dita) 

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer reassigns the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Allocation of separation monies

Source topic: `en_EN/task/conv_sickpar/allocation_of_separation_monies.dita`

If a client loses their employment after the start of the BP and receives separation monies, the officer allocates the separation monies.

For more information on allocating separation monies, the officer refers to Allocating separation monies and Digest 5.12 — Moneys paid or payable by reason of a lay-off or separation .
       [Allocating separation monies](/en/procedure/task/all_monies_sep.shtml) 
       [Digest 5.12 — Moneys paid or payable by reason of a lay-off or separation](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/moneys-paid-layoff-separation.html) 

### Temporary Foreign workers (900-series SIN)

Source topic: `en_EN/task/conv_sickpar/temporary_foreign_workers_900-series_sin.dita`

All foreign workers are given temporary resident status for a limited period of time when they enter Canada. Generally, foreign workers can demonstrate availability to accept work only if they possess a valid work permit which allows them to work in Canada.

Maternity, parental, CCB and family caregiver benefits can be paid to clients who qualify to receive these benefits, even if their SIN has expired, under the following 3 conditions:

- The clients’ SINs are valid during the QP.

- The clients are authorized to be in Canada (e.g. hold a visitor or study permit or a Refugee Protection Claimant Document).

- The clients remain in Canada (i.e. there is no information on the claim indicating that the client is or will be out of Canada).

Foreign clients applying for maternity, parental, CCB and family caregiver benefits do not need to prove their availability, so a work permit or valid SIN is not necessary during the BP. In these situations, the officer reviews the client’s authorization to remain in Canada.

If a client whose SIN has expired leaves the country, the client is disentitled from receiving maternity, parental, CCB and family caregiver benefits. 

### Effective date of a renewal or a conversion

Source topic: `en_EN/task/conv_sickpar/effective_date_of_a_renewal_or_a_conversion.dita`

When a client wishes to renew or convert a claim, the officer determines the effective date. For more information, the officer refers to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Return to work (RTW)

Source topic: `en_EN/task/conv_sickpar/return_to_work_rtw.dita`

If there is an RTW on the claim that falls on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer reassigns the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### Renewal week required

Source topic: `en_EN/task/conv_sickpar/renewal_week_required.dita`

A renewal week is required when changing the claim type (CT) to 4 - Maternity or parental , 14 - Standard parental , 16 - Extended parental , 74 - Self-employed - Maternity , 75 - Self-employed - Standard parental or 79 - Self-employed Extended parental . If no renewal week is input for these CTs on conversions, the transaction is rejected with error code 242 . 

### Conversion from sickness benefits on a continuing claim

Source topic: `en_EN/task/conv_sickpar/conversion_from_sickness_benefits_on_a__b2af2ade.dita`

Conversion requests that follow the payment of sickness benefits are established in the week following the last payment of sickness benefits if the client has made the conversion request within 3 weeks of the last week that sickness benefits were processed (the week the last claimant’s report for sickness benefits was processed + 3).

If the conversion is made 4 or more weeks after the week that the last payment of sickness benefits was processed, the effective date of conversion is the week before the week the request was made, according to the automatic backdating policy.

**Processing claimant’s reports**

Before the officer can input the conversion transactions, the last week of sickness benefits must be paid. If claimant’s reports have not been processed for the sickness benefits period, they must be processed before inputting the conversion. This requires a 2-day input.

**Adjudicating new contentious issues**

When converting a continuing claim, a client may report a new contentious issue (e.g. reason for separation [RFS], farming or availability) that must be adjudicated. If there is no existing WI for this issue, the Level 1 officer creates a CR WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision. If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated. 

### Conversions from sickness benefits on a renewal claim

Source topic: `en_EN/task/conv_sickpar/conversions_from_sickness_benefits_on_a_21ee4906.dita`

**Renewal advantages**

When assessing a renewal, it might be to the client’s advantage to establish a new BP instead of renewing the existing BP. For more information, the officer refers to Cancelling, voiding, terminating or withdrawing a claim .
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml)

**Adjudicating contentious issues**

When renewing a claim, a client may report a new contentious issue (e.g. [RFS], farming, availability) that must be adjudicated. If the issue is declared on the EI application, the system creates an Adjudication Issue (ADJ) WI in NWS. If a contentious issue is detected while reviewing the claim, the Level 1 officer must create an ADJ WI for each contentious issue and must attempt to adjudicate the issue according to the National Policy on Levels of Decision . If the Level 1 officer cannot adjudicate the issue, the ADJ WI is referred to Level 2 for adjudication. When an ADJ WI is created on a renewal claim, either manually or by the system, the system automatically imposes a 2 - Contentious Renewal in Automation manual action (MA2) to prevent payment of benefits until the contentious issue is adjudicated and the renewal is completed. If the renewal or a decision must be input manually, the inputs must be done before the Claim Assessment (CA) or ADJ WI is completed because the system deletes the MA2 when the CA and ADJ WIs are completed and there are no outstanding ADJ WIs. An officer cannot remove an MA2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

**Subsequent claim**

The renewal application can be used to establish a subsequent claim when the following conditions are met:

- The claim is renewed and there are 4 or fewer weeks of benefits remaining in the BP.

- The client has worked enough hours to establish a new claim.

ACP can register the subsequent claim if the Claim Assessment (CA) WI for a renewal or subsequent initial claim is finalized within 28 days of the renewal application.

When ACP cannot register the subsequent claim because the renewal is not processed within 28 days of the renewal application (i.e. REN WK not found or no match and polling limit exceeded is displayed on the Processing Activities tab in NWS) or when the claim was converted to MPS, the officer processing the CA Renewal WI creates a Reminder (REM) WI. This ensures that an officer will manually register the subsequent claim. 

### Claim action status and processing of the claim

Source topic: `en_EN/task/conv_sickpar/claim_action_status_and_processing_of_the_claim.dita`

The Claim action status Renewal is created when a renewal decision is registered in NWS. There are 3 Claim action statuses that may be displayed:

- In Progress (Automation) is displayed on the Client information tree when there are one or more outstanding adjudication issues.

- In Progress (Manual) is displayed on the Client information tree when there is no outstanding adjudication issue and there is an outstanding CA or Specialized Application (SA) WI.

- Finalized is displayed on the Client information tree when all ADJ WIs are completed and the renewal week has been successfully input.

An ADJ WI is created for every new contentious issue. When opening an ADJ WI, the officer must always check to see if there is a Resolve Issue tab. If there is a Resolve Issue tab, the officer documents the decision directly in the ADJ WI by completing all mandatory screens. When the ADJ WI is completed, NWS creates a record of decision (ROD) based on the Resolve Issue screens. When the renewal is finalized, the system also generates the required transactions (e.g. signature code, disentitlement) based on the Resolve Issue screens. If a disentitlement or indefinite disqualification is imposed, the system creates a Correspondence WI for the D-01-00-00 letter. This means that the officer with the CA or SA WI has no action to perform for these ADJ WIs.

When there is no Resolve Issue tab for the ADJ WI, the officer must create a ROD, generate the required transactions and send the appropriate letter. If there is an outstanding CA or SA WI when the officer completes the ADJ WI, a client Note is created and the officer with the CA or SA WI must follow the instructions to input transactions or send the letter. 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/task/conv_sickpar/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a Claim Review (CR WI), in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an Action Item (AI), Call Back (CB), Assessment Issue (ASMT) or REM WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for EI benefits, the officer selects the BT indicated in FTS. 

### ACS letters

Source topic: `en_EN/task/conv_sickpar/acs_letters.dita`

Communication of the renewal decision is not necessary when the only transaction input is a renewal. When another decision is input at the time of the renewal (disentitlement, disqualification or allocation of earnings), communication of the decision is necessary.

Written communication of the decision is usually done by officers who are responsible for sending the appropriate ACS letter. 

### Note

Source topic: `en_EN/common_notes/note_c_0138.dita`

Note:

The Parental Benefits Validation screen only displays linked SINs. The other parent’s SIN provided on AppliWeb or MSCA or input in FTS is not displayed in the screen until it has been linked to the other parent’s SIN by the parental benefits validation process which only occurs once the claims are finalized. 

### Note

Source topic: `en_EN/common_notes/note_c_1486.dita`

Note:

FTS does not display the Parental Benefits Validation screen for claims established before September 28, 2019 as they do not have a Parental Client Record. The parental benefits validation process cannot validate these claims. If the officer inputs a Renewal/Revised (M106) transaction with parental information on these claims on or after September 30, 2019 a Parental Client Record is created. 

### Note

Source topic: `en_EN/common_notes/note_c_2717.dita`

Note:

This is necessary because the Parental Benefits Validation transaction is not accessible until the Parental Client Record is created (after the parental benefits inputs are processed). 

### Note

Source topic: `en_EN/common_notes/note_c_2774.dita`

Note:

If a client has been found responsible for a violation for an earlier claim, an increased number of hours may be needed to qualify for parental benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_2804.dita`

Note:

Under certain conditions, the PW may be extended to allow the client more time to collect weeks of entitlement. 

### Note

Source topic: `en_EN/common_notes/note_c_2653.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2720.dita`

Note:

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure. As a result, the officer does not impose a D35 on claims with a BPC between w/c 2310 and w/c 2361 when the client has accumulated the required number of hours in the QP. However, the officer still determines if a D35 should be imposed for any other reason listed above. 

### Note

Source topic: `en_EN/common_notes/note_c_2805.dita`

Note :

A client is not required to demonstrate good cause for delay when submitting a medical certificate. The Level 1 officer modifies or rescinds a disentitlement related to a missing medical certificate for special benefits, regardless of the length of delay, provided all other conditions are met for the requested BT. 

## Regional considerations

Source topic: `en_EN/task/conv_sickpar/regional_considerations.dita`

**Quebec region**

Clients who live in Quebec and who request benefits due to a pregnancy, birth or adoption must apply to QPIP. The Quebec government pays these benefits to Quebec residents. In some cases, the Quebec government also pays QPIP benefits to a parent living outside of Quebec if both parents lived in Quebec when the initial claim for maternity or parental benefits for the birth or adoption of the same child was made. When a client applying for EI benefits lives in Quebec or indicates that the other parent is entitled to QPIP benefits, an officer on the specialized team that is responsible for liaising with QPIP determines whether the client is entitled to the requested EI benefits.

When a client living in Quebec is entitled to receive QPIP benefits, an officer from the specialized QPIP team imposes an indefinite 57 - E.I. Maternity or Parental benefits denied, benefits are payable by the province disentitlement (D57). 

## What you need to look for

Source topic: `en_EN/task/conv_sickpar/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/conv_sickpar/in_nws.dita`

- What type of parental benefits and how many weeks of parental benefits is the client requesting?

- Did the client file a renewal application requesting a conversion?

- Does the client have a 900-series SIN?

- Has the client worked since the last week paid?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies, motor vehicle accident compensation, workers’ compensation benefits (WCB) or wage loss insurance (WLI) payments to consider or allocate?

- Is there an ADJ WI?

- If yes, for what issue?

- Is the DOB, arrival or placement provided?

- Is the SIN of the other parent provided?

- Are the parents sharing parental benefits?

- Is the number of requested parental weeks specified?

- Is there an electronic questionnaire or an SROC with the other parent’s SIN?

- Has a medical certificate been uploaded? 

### In FTS:

Source topic: `en_EN/task/conv_sickpar/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the last renewable week (LRW) been reached?

- Has the waiting period (WP) been served, waived or deferred?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Is there an RTW on the claim?

- Are there any pended claimant’s reports or claimant’s reports to be processed before the conversion?

- Is there a registration number? 

### In RCM:

Source topic: `en_EN/task/conv_sickpar/in_rcm.dita`

- Has an ROE been submitted?

- Are there earnings, separation monies, motor vehicle accident compensation, WCB or WLI payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/conv_sickpar/in_imaging.dita`

- Is there a medical certificate?

- Are there any restrictions noted on the medical certificate?

- Is there any other documentation which may impact the conversion claim?

- Is there documentation with the other parent’s SIN? 

## Step by step

Source topic: `en_EN/task/conv_sickpar/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/conv_sickpar/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/conv_sickpar/reviewing_the_file_level_1.dita`

- Determine if one of the following situations applies:

- In FTS, the client’s residential address is in Quebec and no EI maternity benefits have been paid for the same BPC.

- The client indicated on the EI application, on the Maternity or Parental: INS5168 Annex 3 ― Form or in the information on file one of the following:

- The client received QPIP benefits in the last 2 years or will receive QPIP benefits.

- The other parent has received, is receiving or will receive QPIP benefits.

- If no, go to step 2.

- If yes, go to Reassigning the WI .
               [Reassigning the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#level1_item_6)

- In NWS, determine if there is a SIR Validation (SIR) WI:

- If yes, go to step 3.

- If no, go to step 5.

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for the SIR WI to be completed.”

- Bring forward date: Enter today’s date + 10 business days.

- When the CA WI moves to the current workload, determine if the SIR WI has been completed:

- If no, repeat step 3.

- If yes, go to step 5.

- In FTS, determine if a registration number related to the conversion is on file:

- If yes, go to step 6.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Select Update .

- Go to step 6.

- Determine if the maximum combination of regular and special benefits has been paid:

- If yes, go to Maximum combination of regular and special benefits paid .
               [Maximum combination of regular and special benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#maxcomb)

- If no, determine if the maximum number of parental benefits have been paid for the birth or placement:

- If no, go to step 7.

- If yes, go to Maximum parental benefits paid .
                   [Maximum parental benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#maxpar)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- Determine if there is a pending electronic claimant’s report on the E-Report tab for the period before the conversion:

- If there is no pending electronic claimant’s report, go to step 8.

- If there is a pending electronic claimant’s report, refer to Actioning a pending claimant’s report and then go to step 8.
               [Actioning a pending claimant’s report](/en/procedure/task/pending_cr.shtml)

- Determine if there are any rejected electronic claimant’s report on the Pending/Reject tab for the period before the conversion:

- If no, go to step 9.

- If yes, re-input the claimant’s reports. Refer to Actioning a rejected claimant’s report and then go to step 9.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml)

- Determine if the client reports having received monies and whether they have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings and then go to step 10.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 10.

- If no monies were received, go to step 10.

- In NWS and in FTS, determine if one of the following conditions is met to extend the BP:

- The client was incarcerated and has since been tried and has not been found guilty.

- The client received WCB payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- The child for whom parental benefits are claimed was hospitalized during the PW.

- If one of the conditions is met, refer to Benefit period extension and then go to step 11.
                   [Benefit period extension](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions is met, go to step 11.

- Based on the Claim duration section of the Rate/Duration tab in FTS, determine if one of the following conditions is met:

- The client is requesting benefits before the end of the week displayed in the Latest renewable week field.

- The client is requesting special benefits before the end of the week displayed in the End of the initial benefit period field.

- The client is requesting special benefits after the end of the week displayed in the End of the initial benefit period field, but is entitled to an automatic extension of the BP and is requesting special benefits before the end of the extended BP.

- If any condition is met, go to step 12.

- If none of the conditions is met, go to Last renewable week (LRW) has been reached .
                   [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#LRW)

               [extension of the BP](/en/procedure/activity/extension_benefit_period.shtml)

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 13.

- If no, go to step 15.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, go to step 14.

- If no, the issue is referred to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 15.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine the CT:

- If it is a conversion on a continuing claim, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 15.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If it is a conversion on a renewal claim, in NWS, create an ADJ WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next Available User .

- Issue: Select Availability .

- Details: Type “Outstanding D15 for a missed client information session, Level 2 review required.”

- Select Save .

- Go to step 15.

- Determine if there are any other outstanding disentitlements on file:

- If no , go to step 17.

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue: Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself.

- Select Save .

- Refer to the appropriate procedure and go to step 16.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue: Select the appropriate option.

- Complete the mandatory fields required for the issue type.

- Details: Type “Outstanding [DXX].”

- Select Save .

- Refer to the appropriate procedure and go to step 16.

- Determine if the conditions are met to terminate or rescind the disentitlement at Level 1 according to the National Policy on Levels of Decision :

- If no, reassign the WI to Level 2 and go to step 17.

- If yes, terminate or rescind the disentitlement and go to step 17.

- Determine if there are any outstanding issues that require adjudication that do not have a related WI:

- If no , go to step 19.

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue: Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save.

- Refer to the appropriate procedure and go to step 18.

- If yes and the conversion is on a renewal claim create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue: Select the appropriate option (e.g. availability).

- Complete the mandatory fields required for the issue type.

- Details: Indicate the reason the WI is being created.

- Select Save .

- Refer to the appropriate procedure and then go to step 18.

- Determine if the conditions are met to adjudicate at Level 1 according to the National Policy on Levels of Decision :

- If no, reassign the WI to Level 2 and go to step 19.

- If yes, complete the steps from the appropriate procedure and go to step 19.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- In FTS, on the Rate/Duration tab, determine if the client is minor attached:

- If the BPC is between w/c 2310 to w/c 2361 and the Major Attached box is checked, go to step 20.

- If the client has 600 hours or more or the Major Attached box is checked, go to step 20.

- If the client has fewer than 600 hours and the Major Attached box is not checked, go to Minor attached .
               [Minor attached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#minor)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2796.dita)

- Determine if the client has provided all of the following:

- A signed statement attesting to the parental situation (the attestation at the end of the EI application is acceptable).

- All of the necessary information (e.g. child’s DOB, adoption details, nature of the relationship, type of parental benefits requested).

- If the client is a legally recognized parent, confirmation that the client is a legally recognized parent on the child’s birth certificate (a verbal statement from the client documented to the client’s file is acceptable).

- If the adoption or placement raises doubt, written proof of the adoption or placement.

- If no, go to step 21.

- If yes, go to step 27. 

#### Fact-finding

Source topic: `en_EN/task/conv_sickpar/fact-finding_level_1.dita`

- Fact-find with the client to obtain the following:

- If there is no signed statement or INS 5168 form on file, fact-find using the Maternity or Parental: INS 5168 Annex 3 ― Form .
               [Maternity or Parental: INS 5168 Annex 3 ― Form](https://esdc.prv/en/service-canada/ei/reference-material/forms/documents/checklists/form_5168.doc)

- If the type of parental benefits requested is not indicated, what type of parental benefits do they wish to receive? Make sure the client is aware that the type of parental benefits first requested by one of the parents cannot be changed, even if the parental benefits can be shared.

- If the client is a legally recognized parent, is the client legally recognized on the child’s birth certificate?

- If an adoption or placement raises doubt, request written proof of the adoption or placement.

- If the client is not a biological parent, an adoptive parent, a legally recognized parent on the child’s birth certificate, or caring for a child with the intention to adopt, what is the nature of the client’s relationship to the child?

- If the client’s statement does not include all of the necessary information, obtain the necessary information.

- Determine if the client was reached during fact-finding or if the client responded to the N-10-00-00 ACS letter:

- If the client was reached, go to step 23.

- If the client was not reached, go to step 24.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Conversion .

- Comments: Type “Parental benefits requested”.

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy . If used during fact-finding, copy and paste the INS5168 form. If an Annex 3 was used during fact-finding, copy and paste the Annex 3 . If the parental benefits are requested for an adoption, type: “I attest that the child was placed with me by a recognized authority. I further attest that I consider the placement to be permanent and that it is my intention to adopt the child placed with me since [YYYY-MM-DD]. I understand that the information provided is subject to verification and that making a false statement is subject to an administrative penalty or criminal proceedings for knowingly making this false or misleading statement.”
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 
               [Annex 3](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Maternity_Parental-INS5168_Annex_3_transcript-Form.doc)

- Select Save .

- Determine if the officer is awaiting documentation:

- If the client was contacted and the officer is awaiting documentation, go to step 25.

- If the client was contacted and the officer is not awaiting documentation, go to step 27.

- If the client was not contacted and did not respond to the N-10-00-00 ACS letter, go to Proof of birth, adoption or placement not provided .
               [Proof of birth, adoption or placement not provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#proof)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact finding with client .

- Comments: Type “Awaiting documentation for parental benefits.”

- Bring forward date: Enter [Date that the client was contacted + 10 business days].

- When the WI moves to the current workload, determine if the information has been received:

- If yes, go to step 27.

- If no, determine if the INS 5168 Annex 3 form is required:

- If no, go to step 27.

- If yes, go to Proof of birth, adoption or placement not provided .
                   [Proof of birth, adoption or placement not provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#proof) 

#### Adjudicating entitlement to parental benefits

Source topic: `en_EN/task/conv_sickpar/adjudicating_entitlement_to_parental_benefits_level_1.dita`

- Determine if adjudication of entitlement to parental benefits is required (e.g. the nature of the relationship to the child is not clear, the parents are disputing the type of parental benefits they wish to receive, the parents are disputing how they wish to share the parental benefits):

- If adjudication is required, go to step 28.

- If adjudication is not required, go to step 29.

- Determine if the conversion is on a continuing or a renewal claim:

- If the conversion is on a continuing claim, in NWS, create a CR WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select the appropriate option.

- Details: Type “Level 2 adjudication of entitlement to parental benefits is required.”

- Select Save .

- Go to step 29.

- If the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select the appropriate option.

- Complete the mandatory fields required for the issue.

- Details: Indicate the reason the WI is being created.

- Select Save .

- Go to step 30.

- Determine if the Level 2 officer is adjudicating entitlement to parental benefits:

- If yes, go to step 30.

- If no, go to step 32.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting adjudication of entitlement to parental benefits”

- Bring forward date: Enter [Date that the client was contacted + 10 business days].

- When the WI moves to the current workload, determine if the issue has been adjudicated:

- If no, return to step 30.

- If yes, go to step 32.

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine the parental start week, the type of parental benefits and the number of weeks of parental benefits the client is entitled to.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2722.dita)

- Determine if the client is requesting the conversion during the PW:

- If yes, go to step 35.

- If no, go to Outside of the PW .
               [Outside of the PW](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#OPW)

- Determine if the conversion is requested on a renewal claim:

- If the conversion is requested on a renewal claim, go to step 36.

- If the conversion is requested on a continuing claim, go to Conversion on a continuing claim .
               [Conversion on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#conversion)

- In NWS, determine if there is an outstanding ADJ WI:

- If no, go to Conversion on renewal — No outstanding adjudication .
               [Conversion on renewal — No outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#no)

- If yes, go to Conversion on renewal — Outstanding adjudication .
               [Conversion on renewal — Outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#oa) 

#### Maximum combination of regular and special benefits already paid

Source topic: `en_EN/task/conv_sickpar/maximum_combination_of_regular_and_spec_5cf2309f_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim by referring to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D35 imposed — maximum combination of benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as no hours were accumulated after BPC. D35 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as [number of hours] were accumulated after BPC and the client needed [number of hours] to qualify. D35 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D35 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Action: Select Add .

- Disentitlement: Select 35 - Parental benefits, qualifying conditions not met .

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select: Parental benefits denied or suspended: D34/D35/D56/D57/Free text (3074) .

- Text: Explain why Parental benefits not payable .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Text - Insert appropriate reason(s) (1618) : Type: “you have received the maximum number of benefit weeks payable to you during this benefit period. The maximum number of benefit weeks paid on this claim cannot exceed a total of [maximum number of regular and special benefit weeks that can be paid] weeks. To receive benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you must apply for a new claim.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Maximum parental benefits already paid

Source topic: `en_EN/task/conv_sickpar/maximum_parental_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type: “D35 imposed — parental benefits exhausted.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type: “No conversion is possible as the maximum entitlement to parental benefits has been paid. The client does not qualify for a new claim as no hours were accumulated after the BPC. D35 imposed.”

- If the client has worked since the BPC , type: “No conversion is possible as the maximum entitlement to parental benefits has been paid. The client does not qualify for a new claim as [number of hours] were accumulated after BPC and the client needed [number of hours] to qualify. D35 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the disentitlement D35 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 35 - Parental benefits, qualifying conditions not met .

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Parental benefits denied or suspended: D34/D35/D56/D57/Free text (3074):

- Select D35 - Not qualified or entitled (various reasons) (3077) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/conv_sickpar/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “Last renewable week reached — parental benefits requested.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type: “No conversion is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as no hours were accumulated after BPC.”

- If the client has worked since the BPC , type: “No conversion is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as [number of hours] were accumulated after BPC and the client needed [number of hours] to qualify.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): “We cannot reactivate your claim for Employment Insurance benefits starting [renewal week - Sunday’s date] . Please note that we are required to advise you of all decisions made on your claim. No parental benefits are payable to you on this claim because the last renewable week has been reached on this benefit period. To receive parental benefits, you must work the required minimum number of insurable employment hours. If you want to receive parental benefits in the future, you must apply for a new claim.”

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Proof of birth, adoption or placement not provided

Source topic: `en_EN/task/conv_sickpar/proof_of_birth_adoption_or_placement_no_f03d3aa2_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “D34 imposed: proof of birth or of adoption/placement not provided.”

- Details: Type “the client was advised to provide [required information]. As of today, the proof of birth or of adoption/placement has not been provided. Indefinite D34 imposed.”

- In FTS, select the Renewal / Revised (M106 ) transaction and input the disentitlement D34 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 34 - Parental benefits entitlement conditions not met .

- Start : Select the Monday of the week during which the client wants the parental benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065) :

- Parental benefits denied or suspended: D34/D35/D56/D57/Free text (3074) : Select D34 - No proof provided (various reasons) (3076) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Client is minor attached

Source topic: `en_EN/task/conv_sickpar/client_is_minor_attached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D35 imposed: Parental benefits — qualifying conditions not met.”

- Details: Type the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client is minor attached. The client does not qualify for a new claim as no hours were accumulated after the BPC. D35 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client is minor attached. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC. The client needed [number of hours] to qualify. D35 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and impose the D35 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if necessary).

- Claim Type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 35 - Parental benefits, qualifying conditions not met .

- Start: Select the disentitlement start date.

- End : Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Parental benefits denied or suspended: D34/D35/D56/D57/Free text (3074):

- Select D35 - Not qualified or entitled (various reasons) (3077) .

- Select D35 - Not qualified - Not enough insurable hours .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select Indefinite disentitlement dates and enter the date.

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI. 

#### Benefits requested outside of theparental window(PW)

Source topic: `en_EN/task/conv_sickpar/benefits_requested_outside_of_theparent_72254d85_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “D35 imposed: Parental Benefits — qualifying conditions not met.”

- Details: Type “The client requests parental benefits outside of the parental window. D35 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D35 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week in which the client wants the parental benefits to start being paid.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select 2 - Regular benefits .

- Action: Select Add .

- Disentitlement: Select 35 - Parental Benefits - Qualifying Conditions Not Met .

- Start: Select the Monday of the week during which the client wants the parental benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Parental benefits denied or suspended: D34/D35/D56/D57/Free text (3074): Select D35 - Not qualified or entitled (various reasons) (3077) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Conversion on a continuing claim

Source topic: `en_EN/task/conv_sickpar/conversion_on_a_continuing_claim_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week in which the payment of parental benefits starts.

- Earnings week 1: Enter the amount (if necessary)

- Claim type: Select one of the following:

- If the client is entitled to standard parental benefits, select 14 - Parental standard .

- If the client is entitled to extended parental benefits, select 16 - Parental extended .

- Manual Action: Select the appropriate option (only if Level 2 adjudication is required).

- Select the Special benefits (M106) link and enter the following in the Parental section:

- Arrival/Placement Week: Enter the week of birth.

- Start week: Enter the parental start week.

- Entitlement Weeks: Enter the number of weeks of entitlement.

- Natural/Adoption: Select the appropriate code (5, 6, 7 or 8).
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2777.dita)

- Select Save .

- No claimant’s report: Check the box (if requested by the client).

- Supplementary claim information: If the client is entitled to extended parental benefits, select 99 - Parental extended .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- If the Level 2 adjudication is required, select D - No to leave the registration number open for subsequent transactions.

- If the Level 2 adjudication is not required, select C - Yes to complete the registration number.

- Select Update .

- Determine if the client has provided the other parent’s SIN:

- If yes, go to step 3.

- If no, go to step 8.

- In FTS, on the Parental Benefits Validation screen, determine if the other parent’s SIN is linked to the client’s SIN:

- If no, go to step 4.

- If yes, go to step 8.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Parental validation pending processing of transactions.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, verify if all the transactions have been processed successfully:

- If no, return to step 4.

- If yes, go to step 6.

- In FTS, on the Parental Benefits Validation screen, determine if the other parent’s SIN is linked to the client’s SIN:

- If no, go to step 7.

- If yes, go to step 8.

- In FTS, in the Enquiry menu, select Parental Benefits Validation and enter the other parent’s SIN as follows:

- SIN: Enter the other parent’s SIN.

- Select Add .

- When the question Are you sure you want to add (link) this SIN? appears, select Yes .

- Select Close .

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement is being imposed.

- If there are decisions that must be communicated to the client, go to step 9.

- If there are no decisions that must be communicated to the client, go to step 12.

- In ACS, create and save or add to the saved N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- If the antedate has been denied, select Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Special benefits approved (3046): Select Maternity and/or Parental benefits (standard/extended) approved or denied with sickness options (3054) .

- If there is an allocation, select Allocation of Earnings (2516) .

- Waiting period messages (2445) .

- Determine if Level 2 adjudication is required:

- If yes, in NWS, create a client Note and type “Send the N-00-00-00 letter.” Go to step 11.

- If no, send the saved N-00-00-00 letter and go to step 12.

- In NWS, reassign any CR WI for the contentious issue to Level 2 as follows:

- Destination — SCC: Select the SCC as shown in FTS.

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Not within Level 1 authority.”

- Go to step 12.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- In NWS, complete the Conversion WI. 

#### Conversion on a renewal claim — No outstanding adjudication

Source topic: `en_EN/task/conv_sickpar/conversion_on_a_renewal_claim__no_outst_8874a6e6_level_1.dita`

- In FTS, select the Renewal / Revised (M106) transaction and input the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week in which the payment of parental benefits starts.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select one of the following:

- If the client is entitled to standard parental benefits, select 14 - Parental standard .

- If the client is entitled to extended parental benefits, select 16 - Parental extended .

- If the LRW has been reached, Notify system to: Select E - Accept a renewal week effective after the last renewable week of the benefit period .

- Select the Special benefits (M106) link and enter the following in the Parental section:

- Arrival/Placement Week: Enter the week of birth.

- Start week: Enter the parental start week.

- Entitlement Weeks: Enter the number of weeks of entitlement.

- Natural/Adoption: Select the appropriate code (5, 6, 7 or 8).
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2777.dita)

- Select Save .

- No claimant’s report: Check the box (if requested by the client).

- Supplementary claim information: If the client is entitled to extended parental benefits, select 99 - Parental extended .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number

- Select Update .

- Determine if the client has provided the other parent’s SIN:

- If yes, go to step 3.

- If no, go to step 8.

- In FTS, on the Parental Benefits Validation screen, determine if the other parent’s SIN is linked to the client’s SIN:

- If no, go to step 4.

- If yes, go to step 8.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Parental validation pending processing of transactions.”

- Bring forward date: Enter the next day.

- When the WI moves to the current workload, in FTS, verify if all the transactions have been processed successfully:

- If no, return to step 4.

- If yes, go to step 6.

- In FTS, on the Parental Benefits Validation screen, determine if the other parent’s SIN is linked to the client’s SIN:

- If no, go to step 7.

- If yes, go to step 8.

- In FTS, in the Enquiry menu, select Parental Benefits Validation and enter the other parent’s SIN as follows:

- SIN: Enter the other parent’s SIN.

- Select Add .

- When the question Are you sure you want to add (link) this SIN? appears, select Yes .

- Select Close .

- Determine if any of the following situations apply:

- There is an allocation of earnings.

- There is an MA2 on file.

- There is a denied antedate.

- A disentitlement or definite disqualification is being input manually.

- If yes, go to step 9.

- If no, go to step 10.

- In ACS, create and send or add to the saved the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246)

- If an antedate has been denied, select Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Special benefits approved (3046): Select Maternity and/or Parental benefits (standard/extended) approved or denied with sickness options (3054) .

- To advise the client of the allocation, select Allocation of Earnings (2516) .

- Waiting period messages (2445)

- In NWS, determine if the conversion application was submitted using AW:

- If no go to step 11.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#subsequent_claims)

- Complete the CA WI. 

#### Conversion on a renewal claim — Outstanding adjudication

Source topic: `en_EN/task/conv_sickpar/conversion_on_a_renewal_claim__outstand_c972fb4d_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week in which the payment of parental benefits starts.

- Earnings week 1: Enter the amount (if necessary)

- Claim type: Select one of the following:

- If the client is entitled to standard parental benefits, select 14 - Parental standard .

- If the client is entitled to extended parental benefits, select 16 - Parental extended .

- If the LRW has been reached, Notify system to: Select E - Accept a renewal week effective after the last renewable week of the benefit period .

- Select the Special benefits (M106) link and enter the following in the Parental section:

- Arrival/Placement Week: Enter the week of birth.

- Start week: Enter the parental start week.

- Entitlement Weeks: Enter the number of weeks of entitlement.

- Natural/Adoption: Select the appropriate code (5, 6, 7 or 8).
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2777.dita)

- Select Save .

- No claimant’s report: Check the box (if requested by the client).

- Supplementary claim information: If the client is entitled to extended parental benefits, select 99 - Parental extended .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number

- D - No to leave the registration number open for subsequent transactions

- Select Update .

- Determine if the client has provided the other parent’s SIN:

- If yes, go to step 3.

- If no, go to step 8.

- In FTS, on the Parental Benefits Validation screen, determine if the other parent’s SIN is linked to the client’s SIN:

- If no, go to step 4.

- If yes, go to step 8.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Parental validation pending processing of transactions.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, determine if all the transactions have been processed successfully:

- If no, return to step 4.

- If yes, go to step 6.

- In FTS, on the Parental Benefits Validation screen, determine if the other parent’s SIN is linked to the client’s SIN:

- If no, go to step 7.

- If yes, go to step 8.

- In FTS, in the Enquiry menu, select Parental Benefits Validation and enter the other parent’s SIN as follows:

- SIN: Enter the other parent’s SIN.

- Select Add .

- When the question Are you sure you want to add (link) this SIN? appears, select Yes .

- Select Close .

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement or definite disqualification is being imposed manually.

- If yes, go to step 9.

- If no, go to step 11.

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246)

- If an antedate has been denied, select Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Special benefits approved (3046) , select Maternity and/or Parental benefits (standard/extended) approved or denied with sickness options (3054) .

- If there is an allocation, select Allocation of Earnings (2516) .

- Waiting period messages (2445) .

- In NWS, create a client Note and type “Send N-00-00-00 letter.”

- Determine if the conversion application was submitted using AW:

- If no go to step 12.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_sickpar#subsequent_claims)

- Complete the CA WI. 

#### Subsequent claims

Source topic: `en_EN/task/conv_sickpar/subsequent_claims_level_1.dita`

- Determine if there are 4 weeks or fewer of benefits payable remaining in the BP:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the renewal was finalized 28 calendar days after the renewal application was submitted (i.e. application date + 27 days) or if the Status field on the Summary tab in FTS is 8 - Converted to Manual Pay:

- If yes, go to step 3.

- If no, go to step 4.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Subsequent claim not automated.”

- Due date: Select the [LRW + 3 weeks].

- Language: Select the appropriate option.

- Details: Type “Subsequent claim to be established.”

- Destination — SCC : Select the SCC as shown in FTS.

- End User: Select Next available user .

- Complete the CA WI. 

#### Reassigning the WI

Source topic: `en_EN/task/conv_sickpar/reassigning_the_wi_level_1.dita`

- In NWS, reassign the WI related to the conversion and the following related WIs, if necessary (CB, AI and REM), as follows:

- Destination: Select Level 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC/QPIP .

- Reason: Select Unable to complete .

- Details: Type “Decision required to determine whether EI or QPIP applies.”

- Select OK .

- No further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Note

Source topic: `en_EN/common_notes/note_c_2721.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose an MA1 to stop payment. 

#### Note

Source topic: `en_EN/common_notes/note_c_2796.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, 420 hours of insurable employment is required to establish a claim for regular or special benefits regardless of the conversion date. If the client has 420 or more insurable hours, select the major attached option. 

#### Note

Source topic: `en_EN/common_notes/note_c_2722.dita`

Note:

In order to determine the number of parental weeks the client is entitled to, consider the following:

- number of weeks requested

- type of parental benefits the client is entitled to

- PW

- BP

- return to work date (if available)

- WP (if one will be served)

- number of weeks the other parent is entitled to (if available) 

#### Note

Source topic: `en_EN/common_notes/note_c_2777.dita`

Note:

If the client is a legally recognized parent on the child’s birth certificate, select the applicable natural parent sex code options. 

## Policy reference

Source topic: `en_EN/task/conv_sickpar/policy_reference.dita`

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- EIA 12(6)
         [EIA 12(6)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 23(1)
         [EIA 23(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-23.html) 
