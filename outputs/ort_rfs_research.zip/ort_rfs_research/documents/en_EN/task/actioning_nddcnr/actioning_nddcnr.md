# Actioning a Notice of Debt declared by the client as not received

Source map: `en_EN/task/actioning_nddcnr/actioning_nddcnr.ditamap`

## Summary

Source topic: `en_EN/task/actioning_nddcnr/summary.dita`

Summary: When a client indicates a Notice of Debt was not received even though the Notice of Debt has not been returned to Service Canada by the Canada Revenue Agency (CRA) as undeliverable, either the Notice of Debt must be resent or the original decision must be reviewed to determine if it is within the reconsideration timeframes. 

## What you need to know

Source topic: `en_EN/task/actioning_nddcnr/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/actioning_nddcnr/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1478.dita) 

### Processing a Notice of Debt declared by the client as not received

Source topic: `en_EN/task/actioning_nddcnr/processing_a_notice_of_debt_declared_by_2192f853.dita`

When a client indicates a Notice of Debt was not received and an undeliverable mail indicator ($) is not present in FTS, the officer determines the address to which the Notice of Debt was sent, when it was sent and whether it must be resent. If the Notice of Debt was sent to an address where the client does not or no longer resides, a Change of Address may be required to correct the client’s mailing address. A client opting to get electronic statements receives no paper statements by mail. The client is notified by email when a new statement is available in the MSCA inbox. A Notice of Debt is considered delivered once it is deposited into the MSCA inbox and made accessible to the client.
       [Change of Address](/en/procedure/activity/change_address.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0161.dita) 

### Determining if the client provided sufficient evidence

Source topic: `en_EN/task/actioning_nddcnr/determining_if_the_client_provided_suff_90ba3d48.dita`

When the Notice of Debt was sent to a correct mailing address but the client indicates that they haven’t received it because they moved shortly after, the Level 2 officer must determine if the client has provided sufficient evidence to prove that the Notice of Debt was not received. If the client provides sufficient evidence, the Level 2 officer must reconsider the original decision. If the client is unable to provide sufficient evidence, the Level 2 officer reprints the Notice of Debt.

If the client opted to receive electronic statements but reports not having received them, the Level 2 officer determines if the client has provided sufficient evidence to prove that the Notice of Debt was not received.

**Reviewing the original decision**

When the Notice of Debt is sent to the wrong address or when the client provides sufficient evidence to show that the Notice of Debt was not received because they moved, the Level 2 officer reviews the original decision that created the debt to determine if it is within the reconsideration timeframes. According to the Digest 17.3.0 Reconsideration (EIA 52 and policy) , all of the steps in the decision-making process of a reconsideration must be conducted within specific timeframes. This includes notifying the client of the decision that created the debt. Only when the client has been notified of the debt can it be recovered.
       [17.3.0 Reconsideration (EIA 52 and policy)](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/reconsideration.html#a17_3_0)

- If the weeks covered by the decision are within the reconsideration timeframes, no changes are required to the original decision. The Level 2 officer:

- modifies the status of the original decision letters in ACS to undeliverable;

- issues new decision letters;

- re-establishes a new debt in PSCD based on the original decision;

- adjusts the original debt to $0.

PSCD automatically generates a new Notice of Debt to notify the client, and resumes recovery.

- If some of the weeks covered by the decision are outside of the reconsideration timeframes, the Level 2 officer changes the original decision to remove the original debt and render a new decision. The Level 2 officer:

- renders a new decision;

- changes the status of the original decision letters in ACS to undeliverable;

- issues the appropriate decision letters;

- enters all transactions required for the reconsideration of the original decision, including modifying the violation if necessary;

- ensure that the transactions from the original decision have been deleted.

If the new decision results in a new OP or penalty, PSCD automatically generates a new Notice of Debt to notify the client of the debt and begins recovery.

- If all of the weeks covered by the decision are outside of the reconsideration timeframes, the Level 2 officer:

- does the necessary inputs so that the original decision is removed from the systems, including PSCD;

- changes the status of the original decision letters in ACS to undeliverable.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1479.dita) 

**Adjusting debts that were originally created in DARS**

In some cases, the debt being reviewed was originally created in DARS. When debts are converted from DARS to PSCD, only the active balance is transferred. This means that a debt that was originally created in DARS might have been entirely or partially converted to PSCD.

If the total amount of the debt was converted from DARS to PSCD, the officer can adjust the debt to $0 directly in PSCD.

If the debt was partially converted from DARS to PSCD, the officer can also adjust the debt to $0 in PSCD. Officers working for the National Accounts Receivable take the appropriate actions to have the balance of the debt in DARS adjusted and any payments that occurred in DARS applied to the new debt that was created by the officer in PSCD.

Example:

- The original debt in DARS was $1 000.

- The client repaid $250 in DARS.

- The balance converted to PSCD is $750.

The client never received the Notice of Debt and, after reviewing the file, the officer determines that the original decision is still valid. A new debt needs to be established and the balance in PSCD needs to be cancelled. The officer first re-establishes the debt associated with the original decision by creating a new debt of $1 000 in PSCD and then adjusts the converted balance ($750) in PSCD by the value of the original debt (–$1 000). This cancels the debt. An officer from the National Accounts Receivable will transfer the payment of $250 that occurred in DARS to the new debt. 

### Violation

Source topic: `en_EN/task/actioning_nddcnr/violation.dita`

If the original decision includes a violation, the officer updates the notice of violation date when resending the notice of decision. On the Violation (ML01) transaction in FTS, the officer adds a new notification week and rescinds the one that was initially entered. 

### Note

Source topic: `en_EN/common_notes/note_c_1478.dita`

Note:

When a client indicates a Notice of Debt was not received and an undeliverable mail indicator ($) is present in FTS, refer to Actioning the receipt of an undeliverable Notice of Debt .
       [Actioning the receipt of an undeliverable Notice of Debt](/en/procedure/task/actioning_receipt_und.shtml)

     [Actioning the receipt of an undeliverable Notice of Debt](/en/procedure/task/actioning_receipt_und.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0161.dita`

Note:

As of October 20, 2025, electronic Notices of Debt are now in use.

Clients with debts who opt for electronic delivery automatically receive email notifications and can access their debt statements in their MSCA inbox. These clients no longer receive paper statements. Instead, they are notified by email whenever a new statement is available.

A Notice of Debt is considered delivered once it is deposited into the MSCA inbox and made accessible to the client. To determine the statement delivery method, the officer refers to the Display Interaction History screen in PSCD. The indicator at the bottom left of the monthly statement of account or the Notice of Debt is P if the document was mailed, or E if it was issued electronically. 

### Note

Source topic: `en_EN/common_notes/note_c_1479.dita`

Note:

Because the system created the OPs for the advance payments, there are no transactions related to the decisions to adjust in FTS or BCS. If the OP is outside of the reconsideration timeframe, the original debt is adjusted to $0 in PCSD. 

## Regional considerations

Source topic: `en_EN/task/actioning_nddcnr/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actioning_nddcnr/what_you_need_to_look_for.dita`

### In ACS:

Source topic: `en_EN/task/actioning_nddcnr/in_acs.dita`

- When was the decision letter sent? 

### In FTS:

Source topic: `en_EN/task/actioning_nddcnr/in_fts.dita`

- What were the original inputs?

- Is the client’s mailing address correct?

- If yes, was it recently updated?

- Is there an undeliverable mail indicator ($) ? 

### In NWS:

Source topic: `en_EN/task/actioning_nddcnr/in_nws.dita`

- Is there evidence of the client not residing at the address to which the Notice of Debt was sent?

- Is there a ROD for the original decision? 

### In Imaging:

Source topic: `en_EN/task/actioning_nddcnr/in_imaging.dita`

- Is there evidence of the client not residing at the address to which the Notice of Debt was sent? 

### In PSCD:

Source topic: `en_EN/task/actioning_nddcnr/in_pscd.dita`

- What is the date of the original debt?

- To what address was the Notice of Debt sent?

- Is there evidence of the client not residing at the address to which the Notice of Debt was sent?

- Is there an N - Undeliverable notice of debt lock on the original debt?

- Is the indicator P if the Notice of debt was mailed, or E if it was issued electronically? 

## Step by step

Source topic: `en_EN/task/actioning_nddcnr/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/actioning_nddcnr/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_nddcnr/reviewing_the_file_level_1.dita`

- In FTS, determine if an undeliverable mail indicator ($) is on file:

- If no, go to step 2.

- If yes, go to Actioning the receipt of an undeliverable Notice of Debt .
               [Actioning the receipt of an undeliverable Notice of Debt](/en/procedure/task/actioning_receipt_und.shtml)

- In PSCD, determine if the indicator is P if the Notice of Debt was mailed, or E if it was issued electronically:

- If the indicator is P , go to step 3.

- If the indicator is E , go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#level2)

- If the client’s mailing address is incorrect, go to Change of Address before continuing to step 4.

- Determine if there has been a change of address since the Notice of Debt was issued:

- If yes, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#level2)

- If no, go to Resending the Notice of Debt .
               [Resending the Notice of Debt](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#_Resending_the_Notice) 

#### Resending the Notice of Debt

Source topic: `en_EN/task/actioning_nddcnr/resending_the_notice_of_debt_level_1.dita`

- In PSCD, from the Review BP Account screen, resend the Notice of Debt as follows:

- Social Insurance Number: Enter the client’s SIN.

- Select Search .

- Select Related Links .

- Select Display Interaction History .

- Select Correspondence .

- Select the Reprint icon to reprint the Notice of Debt.

- In NWS, create an SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “Insurance.”

- Details: Type “The Notice of Debt mailed on [DD-MM-YYYY] was not returned undeliverable to the CRA, but the client declares not having received it — re-sent to the client’s address.”

- Select Save .

- Complete the WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/actioning_nddcnr/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the Action Item (AI) WI as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Do the following:

- I f the Notice of Debt was sent by mail, type “The Notice of Debt mailed on [DD-MM-YYYY] was not returned undeliverable to the CRA, but the client declares not having received it.”

- If the Notice of Debt was sent electronically, type “The Notice of Debt was electronically sent on [DD-MM-YYYY], but the client declares not having received it.” 

### Level 2

Source topic: `en_EN/task/actioning_nddcnr/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_nddcnr/reviewing_the_file_level_2.dita`

- Determine if the notice of debt was sent to the wrong address:

- If yes, go to Reviewing the original decision .
               [Reviewing the original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#level2_item_2)

- If no, go to step 2.

- Determine if there is sufficient evidence showing that the client did not reside at the address to which the Notice of Debt was mailed, or that the client was not able to access the Notice of Debt sent electronically:

- If there is sufficient evidence, go to Reviewing the original decision .
               [Reviewing the original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#level2_item_2)

- If there is not sufficient evidence, go to Client did not provide sufficient evidence .
               [Client did not provide sufficient evidence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#_Client_did_not) 

#### Reviewing the original decision

Source topic: `en_EN/task/actioning_nddcnr/reviewing_the_original_decision_level_2.dita`

- In accordance with the Digest 17.3.1 — Limitations under EIA 52 , review the original decision that created the debt and determine if it is within the reconsideration timeframes.

- If all of the weeks covered by the decision are within the reconsideration timeframes, no changes are required to the original decision. Go to step 5.

- If any or all of the weeks covered by the decision fall outside the reconsideration timeframes, changes are required to the original decision. Go to step 4.

- Render a new decision taking into account the new timeframes. Refer to the applicable activity as required for additional information to render the decision (e.g. Unreported earnings , Not unemployed , Out of Canada ).

- Determine if changes are required to the original decision.

- If no, go to No changes required to the initial decision .
               [No changes required to the initial decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#_No_changes_required)

- If yes, go to Changes required to the initial decision .
               [Changes required to the initial decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#_Changes_required_to_1) 

#### No changes required to the initial decision

Source topic: `en_EN/task/actioning_nddcnr/no_changes_required_to_the_initial_decision_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “undeliverable Notice of Debt — no changes required.”

- In ACS, if not already done, modify the original decision letter status to undeliverable.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1480.dita)

- In FTS, if there is no registration number, select Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In PSCD, create a new OP with the value of the original OP:

- Refer to Creating a debt in PSCD and go to step 5.
               [Creating a debt in PSCD](/en/procedure/task/creating_a_debt_in_pscd.shtml)

- In PSCD, adjust the original OP to $0:

- Refer to Adjusting a debt in PSCD and go to step 6.
               [Adjusting a debt in PSCD](/en/procedure/task/adjusting_a_debt_in_pscd.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1481.dita)

- Determine if the original decision under review includes a penalty:

- If yes, go to step 7.

- If no go to step 9.

- Input a new penalty based on the original decision. For additional information, go to Implementing client misrepresentation on an active claim — Penalty and go to step 8.

- Adjust the original penalty to $0. For more information go to Modifying or rescinding a penalty — Misrepresentation remains and go to step 9.

- Determine if there is a violation on the claim:

- If no, go to step 10.

- If yes, in FTS, select the Violation (ML01) transaction, add a new notification week and rescind the one that was initially entered as follows:

- Action: Select Add .

- Notification week: Select the current w/c.

- BPC: Select the BPC that was initially selected.

- Imposed by: Select 1 - Agent .

- Warning Letter: Select 1 - Violation - warning letter issued .

- Actual OP: Enter the potential OP as initially entered, if necessary.

- Potential OP: Enter the potential OP as initially entered, if necessary.

- Select Update .

- Rescind the original Notification week as follows:

- Select the original violation.

- Action: Select Rescind .

- Select Update .

- In ACS, create and send the new decision letters to replace the decision letters whose status was changed to undeliverable.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1482.dita)

- In NWS, complete the WI. 

#### Changes required to the original decision

Source topic: `en_EN/task/actioning_nddcnr/changes_required_to_the_original_decision_level_2.dita`

- Determine if the OP being reviewed is for an EI ERB advance payment ( ERB2 – CERB Advance Payment ):

- If no, go to step 2.

- If yes, go to Changes required to the EI Emergency Response Benefit (EI ERB) advance payment original decision
               [Changes required to the EI Emergency Response Benefit (EI ERB) advance payment original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#level2_item_3)

- In FTS, if there is no registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update.

- In PSCD, determine if any recoupments have been applied against the OP:

- If no, go to step 4.

- If yes, go to Operational Centre Memo (MM06) required for the original decision.
               [Operational Centre Memo (MM06) required for the original decision.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#level2_item_5)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 5.

- If the claim is terminated and cannot be reactivated, or if it is blocked or archived, go to step 9.

- If the claim is terminated and can be reactivated, do the following:

- Under the Terminated tab, select the appropriate BPC.

- Select Reactivate.

- Go to step 5.

- In FTS, enter all transactions required for the reconsideration of the original decision, including modifying the violation, if necessary. Ensure that the transactions from the original decision have been deleted in the following order:

- On day 1, remove the original decision.

- On day 2, enter the new decision.

- Determine if the original decision included a penalty:

- If yes, go to step 7.

- If no, to resend the notice of decision, go to step 27.

- If necessary, input a new penalty based on the new decision. For additional information go to Implementing client misrepresentation on an active claim — Penalty and go to step 8.

- Adjust the original penalty amount to $0. For additional information go to Modifying or rescinding a penalty – Misrepresentation remains and go to step 9.

- To resend the notice of decision, go to step 27.

- Determine the blocked claim’s status by reviewing the Blocked Status column under the Blocked tab:

- If 1 - Updateable is displayed, go to BCS inputs required for the original decision .
               [BCS inputs required for the original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#level2_item_4)

- If 2 - Not blocked is displayed, go back to step 4.

- If any other status is displayed, go to Operational Centre Memo (MM06) required for the original decision .
               [Operational Centre Memo (MM06) required for the original decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_nddcnr#level2_item_5) 

#### Changes required to the EI Emergency Response Benefit (EI ERB) advance payment original decision

Source topic: `en_EN/task/actioning_nddcnr/changes_required_to_the_ei_emergency_re_e9339dc7_level_2.dita`

- In FTS, if there is no registration number, select Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In PSCD, adjust the original OP amount to $0:

- Refer to Adjusting a debt in PSCD and then go to step 3.
               [Adjusting a debt in PSCD](/en/procedure/task/adjusting_a_debt_in_pscd.shtml)

- In NWS, complete the WI. 

#### BCS inputs required for the original decision

Source topic: `en_EN/task/actioning_nddcnr/bcs_inputs_required_for_the_original_decision_level_2.dita`

- In BCS, review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 11.

- If all rows are blank, go to step 14.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable status in BCS.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column under the Blocked tab:

- If Yes is displayed in one of the rows, return to step 11.

- If all of the rows are blank, go to step 13.

- In FTS, select the BPC to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select Active claim default (50%) for non-misrepresentation or Blocked claims system default (100%) for misrepresentation.

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- Determine the result of the reconsideration decision:

- If the decision results in changes to a disentitlement, go to step 15.

- If the decision results in changes to unreported earnings, go to step 17.

- If the decision results in changes to an unreported allocation of earnings, go to step 18.

- If the decision results in changes to a disqualification, go to step 20.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1483.dita)

- In BCS, on the Disentitlements tab, rescind the original disentitlement as follows (up to 4 disentitlements can be imposed, rescinded or terminated in BCS at a time):

- Action: Select Rescind .

- Type: Select the type used to establish the original decision.

- Start date: Enter the start date used to establish the original disentitlement.

- End date: Enter the end date used to establish the original disentitlement.

- Detection: Select the detection used to establish the original disentitlement.

- Infraction: Select the infraction used to establish the original disentitlement.

- Message: Select the message used to establish the original disentitlement.

- Select Update .

- In BCS, under the Disentitlements tab, impose the new disentitlement as follows (up to 4 disentitlements can be imposed, rescinded or terminated in BCS at a time):

- Action: Select A - Add .

- Type: Select the type used to establish the original disentitlement.

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Detection: Select the detection used to establish the original disentitlement.

- Infraction: Select the infraction used to establish the original disentitlement.

- Message: Select the message used to establish the original disentitlement.

- Select Update .

- Go to step 23.

- In BCS, on the Allocation “A” tab, enter the amended earnings as follows:

- Select the week to change. Repeat for every week that requires a change.

- On day 1, enter the original data for all weeks that are included in the original decision .

- On day 2, re-input the earnings for weeks that are still in the reconsideration period .

- Amended earnings: Enter the new amount of earnings. (Enter 0 if the week is now outside of the reconsideration timeframes.)

- FWW: Select the new FWW code (if a change is required).

- Detection: Select the same detection code that was used for the original decision.

- Infraction: Select the same infraction code that was used for the original decision.

- Message: Select the same overpayment message code that was used for the original decision.

- Select Update .

- Go to step 23.

- In BCS, under the Allocations tab, rescind the original allocation as follows:

- Action: Select Rescind .

- Type: Select the type used to establish the original allocation.

- Start date: Select the start date used to establish the original allocation.

- Detection: Select the detection code used to establish the original allocation.

- Infraction: Select the infraction code used to establish the original allocation.

- Message: Select the message code used to establish the original allocation.

- Select Update .

- If a new allocation is required, go to step 19.

- If a new allocation is not required, go to step 23.

- Enter the allocation in the Allocation section as follows:

- Action: Select A - Add .

- Type: Select the appropriate allocation type.

- Amount: Enter the amount allocated per week.

- Start date: Enter the start date of the allocation.

- End date: Enter the end date of the allocation or 9999 is the end date is indefinite.

- Last week amount: Select the appropriate option:

- If the allocation amount in the last week is less than the normal weekly earnings, enter that amount.

- If the allocation amount in the last week is equal to the normal weekly earnings, leave the box empty.

- Detection: Select the detection code used to establish the original allocation.

- Infraction: Select the infraction code used to establish the original allocation.

- Message: Select the message code used to establish the original allocation.

- Select Update .

- Go to step 23.

- In BCS, on the Disqualifications tab, rescind the original disqualification as follows (up to 3 disqualifications in BCS can be imposed or rescinded at a time):

- Action: Select Rescind .

- Type: Select the type used to establish the original disqualification.

- Effective Week: Select the effective week used to establish the original disqualification.

- Number of Weeks: Select the number of weeks used to establish the original disqualification.

- Detection: Select the detection code used to establish the original disqualification.

- Infraction: Select the infraction code used to establish the original disqualification.

- Message: Select the message code used to establish the original disqualification.

- Select Update .

- In BCS, if necessary, on the Disqualifications tab, impose the new disqualification as follows (up to 3 disqualification can be imposed, rescinded or terminated in BCS at a time):

- Action: Select A - Add .

- Type: Select the type used to establish the original disqualification.

- Start date: Enter the start date of the disqualification.

- End date: Enter the end date of the disqualification or “9999” if the end date is indefinite.

- Detection: Select the detection code used to establish the original disqualification.

- Infraction: Select the infraction code used to establish the original disqualification.

- Message: Select the message code used to establish the original disqualification.

- Select Update .

- In RCM, determine if the ROE is on file:

- If the ROE is not on file, go to step 23.

- If the ROE is on file, update the Special condition field to reflect the reconsideration decision on the reason for separation (RFS). Go to step 23.

- In BCS, on the Pending Transactions tab, review the transaction and do the following:

- If the transaction shown is incorrect, check the Delete box next to the incorrect transaction and select Update . Return to step 14.

- If the transaction shown is correct and another change is not required based on the reconsideration of the original decision, select Close and go to step 24.

- Determine if the original decision included a penalty:

- If yes, go to step 25.

- If no, to resend the notice of decision, go to step 27.

- Input a new penalty based on the new decision. For additional information, go to Implementing client misrepresentation on an active claim — Penalty and go to step 26.

- Adjust the original penalty to $0. For additional information, go to Modifying or rescinding a penalty — Misrepresentation remains and go to step 27.

- Determine if there is a violation on the claim:

- If no, go to step 28.

- If yes, in FTS, select the Violation (ML01) transaction, add a new Notification week and rescind the one that was initially entered as follows:

- Action: Select Add .

- Notification week: Select the current w/c.

- BPC: Select the BPC that was initially selected.

- Imposed by: Select 1 - Agent .

- Warning Letter: Select 1 - Violation - warning letter issued .

- Actual OP: Enter the potential OP as initially entered, if necessary.

- Potential OP: Enter the potential OP as initially entered, if necessary.

- Select Update .

- To rescind the original Notification week :

- Select the original violation.

- Action: Select Rescind .

- Select Update .

- In ACS, send a new decision letter to replace the decision letter whose status was changed to undeliverable.

- In NWS, complete the WI. 

#### Client did not provide sufficient evidence

Source topic: `en_EN/task/actioning_nddcnr/client_did_not_provide_sufficient_evidence_level_2.dita`

- In PSCD, from the Review BP account – Debtor overview screen, resend the Notice of Debt that the client states was not received as follows:

- Select Related Links .

- Select Display Interaction History .

- Select Correspondence .

- Select the Reprint icon to reprint the Notice of Debt.

- In NWS, create an SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “Insurance.”

- Details: Do the following:

- If the Notice of Debt was sent by mail, type “The Notice of Debt mailed on [DD-MM-YYYY] was not returned undeliverable to the CRA, but the client declares not having received it — re-sent to the client’s address.”

- If the Notice of Debt was sent electronically, type “The Notice of Debt was sent electronically on [DD-MM-YYYY], but the client declares not having received it — client advised to access MSCA to view the Notice of Debt.”

- Select Save .

- Complete the WI. 

#### Operational Centre Memo (MM06) required for the original decision

Source topic: `en_EN/task/actioning_nddcnr/operational_centre_memo_mm06_required_f_ef0194c4_level_2.dita`

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Detection: Select the detection code that was used for the original decision.

- Infraction: Select the infraction code that was used for the original decision.

- Message: Select the OP message code that was used for the original decision.

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 91 - Overpayment .

- Work type: Select the appropriate option:

- 1 - Misrepresentation

- 2 - Non misrepresentation

- Remarks line 1: Type “ Undeliverable Notice of Debt . Rescind decision input on [DD-MM-YYYY] or MM06 of [DDMM-YYYY].”

- Remarks line 2: Type “W/cs [XXXX] to [XXXX] are now outside of the reconsideration period.”

- Remarks line 3: Type “Re-input the OP for remaining weeks at current date.”

- Remarks line 4: Enter instructions for the penalty, if necessary.

- Remarks line 5: Enter your name and telephone number.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, send a new decision letter to replace the decision letter whose status was changed to undeliverable.

- In NWS, complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1480.dita`

Note:

OPs for EI ERB advance payments (contract object type ERB2 - CERB Advance Payment ) created starting November 2021 do not have a letter of decision in ACS. 

#### Note

Source topic: `en_EN/common_notes/note_c_1481.dita`

Note:

If an outstanding balance was converted to PSCD, adjust the debt in PSCD by the amount of the original debt in DARS. 

#### Note

Source topic: `en_EN/common_notes/note_c_1482.dita`

Note:

Exceptionally, the notices of decision for EI ERB advance payment debts (contract object type ERB2 - CERB Advance Payment), created in November 2021 and later, are sent with the Notice of Debt. When the debt is recreated in PSCD, the notice of decision and Notice of Debt are sent. No action in ACS is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_1483.dita`

Note:

When a reconsideration requires multiple transactions, input them in the following order:

- full disentitlement

- partial disentitlement

- unreported earnings and allocations of earnings

- indefinite disqualification

- definite disqualification 

## Policy reference

Source topic: `en_EN/task/actioning_nddcnr/policy_reference.dita`

- Digest 17.3.0 Reconsideration (EIA 52 and policy)
         [Digest 17.3.0 Reconsideration (EIA 52 and policy)](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/reconsideration.html#a17_3_0)

- National Policy on Undeliverable Notices of Debts
         [National Policy on Undeliverable Notices of Debts](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/nationalpolicy_undeliverable_debts.shtml) 
