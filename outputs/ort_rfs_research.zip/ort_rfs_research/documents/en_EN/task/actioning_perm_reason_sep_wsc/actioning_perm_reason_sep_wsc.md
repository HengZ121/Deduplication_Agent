# Actioning a permanent reason for separation on a Work-Sharing claim

Source map: `en_EN/task/actioning_perm_reason_sep_wsc/actioning_perm_reason_sep_wsc.ditamap`

## Summary

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/summary.dita`

Summary: When an agent is notified that a client has stopped working for a Work-Sharing (WS) employer before the end of the WS agreement, the agent reviews the client’s entitlement to benefits before the claim is renewed or converted. 

## What you need to know

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/what_you_need_to_know.dita`

### Processing a permanent reason for separation (RFS) in a Work-Sharing (WS) claim

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/processing_a_permanent_reason_for_separ_8f141ff4.dita`

When the client receiving WS benefits stops working for the WS employer, the Level 1 agent reviews the client’s entitlement to WS benefits and ensures the claimant’s reports for the WS period are processed.

**Converting the claim**

A client can report a separation from a WS employer when requesting a different benefit type (BT). When this occurs, the client’s entitlement to WS benefits and claimant’s reports for the WS period are processed before the claim is converted or renewed.

**Employer utilization report (UR)**

The WS employer can also submit a notification of separation from employment when the WS employer submits the weekly UR. When a UR indicating that the client no longer works for the WS employer is received, the IPOC agent documents the information on the UR in the client’s file.

**Contentious reason for separation (RFS)**

If the RFS is contentious, the IPOC agent creates an Action Item (AI) WI to ensure the Level 1 agent adjudicates the RFS. The IPOC agent also changes the WS end week to the week before the week in which the separation occurred. This ensures that the client is not paid for the week of the separation before the agent adjudicates the RFS. 

### Determining the last week of Work-Sharing (WS) entitlement

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/determining_the_last_week_of_work-shari_675ef026.dita`

To determine the last week that the client is entitled to WS benefits, the agent reviews the WS information. If the client is dismissed or quits during a WS agreement, the RFS is contentious. The RFS must be adjudicated before the agent can determine the last week the client is entitled to WS benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1493.dita) 

**Imposing an indefinite disqualification**

If the RFS is not allowed, an indefinite disqualification is imposed on the week in which the voluntary leaving or dismissal occurred and continues for the length of the benefit period (BP).

**Non-contentious or allowed reason for separation (RFS)**

If the RFS is not contentious or if the contentious RFS is allowed, clients can choose the BT they want for the last week they participated in the WS agreement. When the RFS is allowed, the Level 1 agent contacts clients to determine whether to process the week as WS or as another BT. If the agent is unable to contact clients to confirm what BT they want to claim, the agent processes the week as a week of WS. If clients later contact Service Canada and request a different BT in that week, the agent reviews the information and amends the decision, if necessary. If the agent is able to contact the client and the client chooses to remain on WS benefits for the week of separation, only earnings received outside of the WS employment can be deducted from the weeks. Earnings can be allocated with an end date that is after the period in which WS benefits are payable. In this case, the agent only inputs the allocation that occurs after the period in which WS benefits are payable. Because there is no method to indicate in the system that the earnings are from a WS employer, this ensures the earnings are not deducted from the WS benefits.

When a claim is converted to another BT in the week of the separation, any earnings or other monies allocated to that week are subject to the normal considerations applied to the waiting period (WP) or a week of benefits.

**Advantages of claiming another benefit type (BT) for the week in which the reason for separation (RFS) occurs**

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1494.dita) 

**Claimant’s report**

If the client notified Service Canada of the separation from the WS employer, it is possible that the WS agreement is still in place and there can be claimant’s reports cycling. A claimant’s report for a WS period is processed when IPOC actions the UR. If a claimant’s report for the period the client was participating in WS has not been processed, it means IPOC has not yet actioned the UR. When this occurs, the agent sends an IPOC Review (IPOC REV) WI to IPOC to obtain the UR information. If a claimant’s report for the period the client was participating in WS is not cycling, the agent fact-finds with the client to obtain the missing claimant’s report and determines if the UR for the period the client participated in WS has been actioned.

**Conversion or renewal claim**

When the claimant’s reports for the period that the client participated in WS have been processed, the agent updates the WS information in FTS and refers to the appropriate Conversion and renewal task.
       [Conversion and renewal](/en/procedure/activity/conversions.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1495.dita) 

If the client has applied within the appropriate timeframes, the claim is renewed on the week after the last WS week processed. 

### Subsequent claim

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/subsequent_claim.dita`

When it is advantageous for the client, the existing BP can be voluntarily terminated at the request of the client in favour of a subsequent BP based on the WS earnings. 

### Note

Source topic: `en_EN/common_notes/note_c_1493.dita`

Note:

During the week of the separation, any hours not worked after the separation are not considered missed due to the WS agreement. 

### Callout

Source topic: `en_EN/common_notes/note_c_1494.dita`

It can be advantageous for the client to claim another BT in the week in which the RFS occurs. Factors to consider include, but are not limited to, the following:

- The week must still meet the definition of a WS week (at least a half hour worked with the WS employer). If it does not, the client has no choice, and the week must be processed as a week of regular or special benefits.

- If a disqualification has been imposed.

- If any monies have been paid on separation.

- The amount of work and earnings allocated to that week.

- If the WP has been served.

- If the client meets entitlement conditions for the BT requested. 

### Note

Source topic: `en_EN/common_notes/note_c_1495.dita`

Note:

WS benefits are processed with a regular benefit claim type (CT). The conversion or renewal task required depends on whether the client is requesting a renewal of regular benefits or a conversion to another BT. 

## Regional considerations

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/regional_considerations.dita`

In the Western Canada and Territories region, the regional payment unit is responsible for inputting the WS agreement data. The processing agent contacts the regional WS coordinator by sending an IPOC REV WI to the Western Canada and Territories region (SCC 5903) with a request that the information be input.

In the Ontario and Quebec regions, the WS unit processes all WS claims. 

## What you need to look for

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/in_fts.dita`

- Have claimant’s reports been processed until the end of the client’s participation in WS?

- Are there any pending claimant’s reports or any claimant’s reports to be processed before the conversion?

- Is there a 76 - Automated worksharing manual action (MA76) imposed on file?

- Is there a registration number on file? 

### In NWS:

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/in_nws.dita`

- Is there a record of decision (ROD) related to the RFS?

- What is the information regarding the RFS?

- Did an IPOC agent create an AI WI because a notification was received indicating a contentious RFS on a UR? 

### In RCM:

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/in_rcm.dita`

- Is there a contentious ROE from the WS employer?

- If yes, what is the RFS code?

- Are there comments related to the RFS? 

### In Imaging:

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/in_imaging.dita`

- Is there documents related to the RFS? 

## Step by step

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/reviewing_the_file_level_1.dita`

- Determine if any of the following conditions are met:

- The client has indicated a contentious RFS from the WS employer on the application.

- There is a contentious RFS on the ROE from the WS employer.

- There is an AI WI created by IPOC for a contentious RFS on a WS claim.

- If any of the conditions are met, go to step 2.

- If none of the conditions are met, go to step 14.

- In NWS, determine if there is a ROD for the adjudication of the RFS:

- If no, go to step 3.

- If yes, go to step 14.

- Determine if there is a WI for the adjudication of the RFS:

- If yes, go to step 4.

- If no, go to step 6.

- Determine if the WI for the adjudication of the RFS is assigned:

- If no, go to step 5.

- If yes and the WI is assigned to another agent, go to step 7.

- If yes and the WI is assigned to yourself, go to step 9.

- In NWS, reassign the WI to yourself as follows:

- Destination: Select Myself .

- Complexity: Select Level 1 .

- Reason: Select Other .

- Details: Type “adjudicate the RFS.”

- Click OK .

- Go to step 9.

- In NWS, create an Adjudication Issue (ADJ) WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination: Enter the Service Canada centre (SCC) as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate issue (e.g. Voluntary leaving ).

- Complete the mandatory fields required for the issue.

- Details: Indicate the reason the WI is being created.

- Go to step 9.

- Move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting adjudication of the RFS.”

- Bring forward date: Enter today’s date + 10 days.

- When the WI moves to the current workload, determine if there is a ROD for the adjudication of the RFS:

- If no, repeat step 7.

- If yes, go to step 9.

- Determine if the conditions are met to adjudicate at Level 1:

- If no, go to step 10.

- If yes, refer to the appropriate task for adjudication. Go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1496.dita)

- Reassign the WI to Level 2 as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type “Outstanding issue on file [issue requiring adjudication] requires review by Level 2.”

- In FTS, select the Renewal/Revised (M106) transaction and impose a manual action to stop payments (MA01) as follows:

- Manual Action: Select 1 - General suspension of benefits .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In NWS, move the AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting adjudication of the RFS.”

- Bring forward date: Enter today’s date + 10 days.

- When the WI moves to the current workload, determine if there is a ROD for the adjudication of the RFS:

- If no, repeat step 12.

- If yes, go to step 14. 

#### Reviewing entitlement to Work-Sharing (WS) for the last week

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/reviewing_entitlement_to_work-sharing_w_b4fd84f4_level_1.dita`

- Determine if one of the following conditions is met:

- The RFS is not contentious.

- The RFS is allowed as just cause.

- If one of the conditions is met, go to step 15.

- If none of the conditions are met, the week before the week of the separation is processed as the last week of WS benefits. Go to step 18.

- Determine if the client worked at least a half hour with the WS employer:

- If no, the week before the week in which the separation occurs is processed as the last week of WS benefits. Go to step 18.

- If yes, determine if fact-finding with the client is required to obtain the following information:

- What BT does the client want to receive for the week of the separation?

- Any details required for claimant’s reports for the WS period that must be modified or that have not been received. Refer to Claimant’s report for more information.

- If fact-finding is required, fact-find with the client and go to step 16.
                       [fact-find](/en/procedure/task/fact_find.shtml)

- If fact-finding is not required, go to step 18.

                   [Claimant’s report](/en/procedure/activity/claimant_report.shtml)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 17.

- If the client was not contacted and did not reply to the N-10-00-00 letter, the week in which the separation occurs is processed as the last week of WS benefits. Go to step 18.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Separation from WS employer during WS agreement.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save.

- Determine if this is a WS claim from the Western Canada and Territories region:

- If yes, go to step 19.

- If no, go to step 23.

- Determine if any of the following must be input or modified:

- The WS agreement end date (must equal the last week of WS benefits).

- Claimant’s reports for WS benefits.

- If any inputs or modifications are required, go to step 20.

- If no inputs or modifications are required, refer to Conversion and renewal .
                   [Conversion and renewal](/en/procedure/activity/conversions.shtml)

- In NWS create an IPOC REV WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate language.

- Destination — SCC: Select 5903 Vancouver IPOC .

- End User: Select Next available user .

- Issue: Select Work-Sharing .

- BPC: Type the BPC of the claim.

- Comments: Type “Claimant’s report information for Work-Sharing period.”

- Details: Type the agreement start and end date, and any claimant’s report information for the WS period that must be modified or that have not been input.

- Obtained by: Select the appropriate method.

- Obtained from: Select the appropriate source.

- Source details: Enter the source details.

- Click Save .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting processing of WS information and the claimant’s reports.”

- Bring forward date: Enter today’s date + 2 days.

- When the WI moves to the current workload, determine if the Project Data — Training (M171) transaction and the claimant’s report have been processed:

- If no, repeat step 21.

- If yes, go to step 23.

- In FTS, determine if the WS end week indicated on the claim is correct:

- If no, go to step 24.

- If yes, go to Work-Sharing (WS) end week is correct .
               [Work-Sharing (WS) end week is correct](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_perm_reason_sep_wsc#CorrectEndWeek)

- Determine if the current WS end week is later than the correct WS end week:

- If yes, go to Current Work-Sharing (WS) end week is later than the correct WS end week .
               [Current Work-Sharing (WS) end week is later than the correct WS end week](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_perm_reason_sep_wsc#Later)

- If no, go to Current Work-Sharing (WS) end week is not later than the correct WS end week .
               [Current Work-Sharing (WS) end week is not later than the correct WS end week](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_perm_reason_sep_wsc#NotLater) 

#### Work-Sharing (WS) end week is correct

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/work-sharing_ws_end_week_is_correct_level_1.dita`

- In FTS, determine if the claimant’s reports have been processed up to and including the last week of the WS agreement:

- If no, go to step 26.

- If yes, go to step 35.

- Determine if there are cycling claimant’s reports up to and including the last week of the WS agreement:

- If no, go to step 27.

- If yes, go to step 31.

- Determine if any details are required for claimant’s reports for the WS period. Refer to Claimant’s report for more information:

- If fact-finding is required, fact-find with the client and go to step 28.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If fact-finding is not required, go to step 30.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 29.

- If the client was not contacted and did not reply to the N-10-00-00, the week in which the separation occurs is processed as the last week of WS benefits. Go to step 35.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Separation from WS employer during WS agreement.”

- Details: Document the fact-finding details according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save.

- Refer to Inputting a claimant’s report to input the claimant’s reports up to and including the last week of the WS agreement. Do not include STUAE coding (so the claimant’s reports can cycle). Go to step 31.

- Determine if there are URs for the period up to and including the last week to be processed as WS benefits:

- If no, go to step 32.

- If yes, go to step 35.

- In NWS, create an IPOC REV WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate language.

- Destination — SCC: Select the IPOC based on the region in which the claim is located in FTS:

- Atlantic: Select 1826 Moncton IPOC .

- Ontario: Select 3056 Belleville IPOC .

- Quebec: Select 2642 Montreal IPOC (3) .

- Western Canada and Territories: Select 5903 Vancouver IPOC .

- End User: Select Next available user .

- Issue: Select Work-Sharing .

- BPC: Type the BPC of the claim.

- Comments: Type “WS – RFS adjudicated – WS end week is correct.”

- Details: Type “Client is requesting WS benefits for w/c [XXXX].” Type SIN, WS agreement number, client's name and WS end week.

- Obtained by: Select the appropriate method.

- Obtained from: Select the appropriate source.

- Source details: Enter the source details.

- Click Save .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting processing of last WS claimant’s reports.”

- Bring forward date: Enter the appropriate date:

- If the UR is on file, enter today’s date + 1 day.

- If the UR is not on file, enter today’s date + 2 days.

- When the WI moves to the current workload, determine if the claimant’s reports have been processed:

- If no, repeat step 32.

- If yes, go to step 35.

- Determine if a renewal or conversion from WS benefits is required:

- If no, go to step 36.

- If yes, return to the appropriate Conversion and renewal task.
               [Conversion and renewal](/en/procedure/activity/conversions.shtml)

- Complete the WI. 

#### Current Work-Sharing (WS) end week is later than the correct WS end week

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/current_work-sharing_ws_end_week_is_lat_260af063_level_1.dita`

- In FTS, determine if there are cycling claimant’s reports on or after the correct WS end week:

- If yes, go to step 26.

- If no, go to step 32.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1497.dita)

- S elect the Renewal/Revised (M106) transaction and rescind the exemption from reporting and the cycling claimant’s reportsas follows:

- Manual action: Select 76R - Automated work-sharing Rescind/Removal of Cycling Reports .

- Click Update .

- Select the Project Data — Worksharing (M171) transaction and change the end week of the WS agreement as follows:

- End date: Select the last week to be processed as WS benefits.

- Click Update .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting for completed MA76R.”

- Bring forward date: Enter today’s date + 1 day.

- When the WI moves to the current workload, determine if the exemption from reporting and the cycling claimant’s reports have been processed:

- If no, repeat step 28.

- If yes, go to step 30.

- In FTS, select the Renewal/Revised (M106) transaction and input an MA76 as follows:

- Manual action : Select 76 - Automated work-sharing .

- Claim action: Select the appropriate option:

- If the client is entitled to an exemption from reporting, select W - Worksharing - No claimant’s reports.

- If the client is not entitled to an exemption from reporting, select H - Worksharing with claimant’s reports.

- Click Update .

- Re-input the claimant’s reports up to and including the last week of the agreement that were previously removed with the MA76R. Go to step 38.

- Select the Project Data — Worksharing (M171) transaction and change the end week of the WS agreement as follows:

- End date: Select the last week to be processed as WS benefits.

- Click Update .

- Determine if the client is exempt from reporting:

- If no, go to step 34.

- If yes, go to step 38.

- Determine if any details are required for claimant’s reports for the WS period. Refer to Claimant’s report for more information:

- If fact-finding is required, fact-find with the client and go to step 35.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If fact-finding is not required, go to step 37.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 36.

- If the client was not contacted and did not reply to the N-10-00-00, the week in which the separation occurs is processed as the last week of WS benefits. Go to step 42.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Separation from WS employer during WS agreement.”

- Details: Document the fact-finding details according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save.

- Refer to Inputting a claimant’s report to input the claimant’s reports up to and including the last week of the WS agreement. Do not include STUAE coding (so the claimant’s reports can cycle). Go to step 38.

- Determine if there are URs for the period up to and including the last week to be processed as WS benefits:

- If no, go to step 39.

- If yes, go to step 42.

- In NWS, create an IPOC REV WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate language.

- Destination — SCC: Select the IPOC based on the region in which the claim is located in FTS:

- Atlantic: Select 1826 Moncton IPOC .

- Ontario: Select 3056 Belleville IPOC .

- Quebec: Select 2642 Montreal IPOC (3) .

- Western Canada and Territories: Select 5903 Vancouver IPOC .

- End User: Select Next available user .

- Issue: Select Work-Sharing .

- BPC: Type the BPC of the claim.

- Comments: Type “WS – RFS adjudicated – WS end week is later than the correct WS end week.”

- Details: Type “The correct WS end week is [XXXX]. Client is requesting WS benefits for w/c [XXXX].” Type SIN, WS agreement number and client’s name.

- Obtained by: Select the appropriate method.

- Obtained from: Select the appropriate source.

- Source details: Enter the source details.

- Click Save .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting processing of last WS claimant’s reports.”

- Bring forward date: Enter the appropriate date:

- If the UR is on file, enter today’s date + 1 day.

- If the UR is not on file, enter today’s date + 2 days.

- When the WI moves to the current workload, determine if the claimant’s reports have been processed:

- If no, repeat step 40.

- If yes, go to step 42.

- Determine if a renewal or conversion from WS benefits is required:

- If no, go to step 43.

- If yes, return to the applicable Conversion and renewal task.
               [Conversion and renewal](/en/procedure/activity/conversions.shtml)

- Complete the WI. 

#### Current Work-Sharing (WS) end week is not later than the correct WS end week

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/current_work-sharing_ws_end_week_is_not_749c5a96_level_1.dita`

- Determine if the claimant’s reports have been processed up to and including the WS end week currently on the claim file:

- If no, go to step 26.

- If yes, go to step 28.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting processing of last WS claimant’s reports.”

- Bring forward date: Enter the appropriate date:

- If the UR is on file, enter today’s date + 1 day.

- If the UR is not on file, enter today’s date + 2 days.

- When the WI moves to the current workload, determine if the claimant’s reports have been processed:

- If no, repeat step 26.

- If yes, go to step 28.

- If a renewal must be input for the next week to be processed, determine if the correct WS end week is the same as the renewal week:

- If no, refer to Conversion and renewal to input a renewal for the next week to be processed. Use the W or H WS coding as required.
               [Conversion and renewal](/en/procedure/activity/conversions.shtml)

- If yes, go to step 29.

- In FTS, select the Project Data — Worksharing (M171) transaction and change the WS end week of the agreement as follows:

- End date: Select the last week to be processed as WS benefits.

- Click Update .

- Go to step 36.

- In FTS, determine if there is an outstanding registration number:

- If yes, go to step 31.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- Go to step 31.

- Select the Renewal/Revised (M106) transaction and create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Detection: Leave the field blank.

- Infraction: Leave the field blank.

- Message: Leave the field blank.

- Click Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 92 - Purge and Recreate .

- Work type: Select 16 - Work-sharing .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “WS - [agreement number].”

- Remarks line 2: Type “Change the agreement end date of w/c [XXXX] for w/c [XXXX].”

- Remarks line 3 : Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Click Update.

- Click the Outstanding Registrations link to transfer the registration number to IPOC as follows:

- Click Modify .

- In the appropriate registration section:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Click Update .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting for IPOC to complete the work.”

- Bring forward date: Enter today’s date + 2 days.

- When the WI moves to the current workload, determine if the claimant’s reports have been processed:

- If no, repeat step 34.

- If yes, go to step 36.

- Determine if the client is exempt from reporting:

- If no, go to step 37.

- If yes, go to step 43.

- Determine if any details are required for claimant’s reports for the WS period. Refer to Claimant’s report for more information:

- If fact-finding is required, fact-find with the client and go to step 38.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If fact-finding is not required, go to step 40.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 39.

- If the client was not contacted and did not reply to the N-10-00-00, the week in which the separation occurs is processed as the last week of WS benefits. Go to step 40.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Separation from WS employer during WS agreement.”

- Details: Document the fact-finding details according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save.

- Refer to Inputting a claimant’s report to input the claimant’s reports up to and including the last week of the WS agreement. Do not include STUAE coding (so the claimant’s reports can cycle). Go to step 44.

- Determine if there are URs for the period up to and including the last week to be processed as WS benefits:

- If no, go to step 42.

- If yes, go to step 44.

- Move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting processing of last WS claimant’s reports.”

- Bring forward date: Enter the appropriate date :

- If the UR is on file, e nter today’s date + 1 day.

- If the UR is not on file, enter today’s date + 2 days.

- When the WI moves to the current workload, determine if the claimant’s reports have been  processed:

- If no, repeat step 42.

- If yes, go to step 44.

- Determine if a renewal or conversion from WS benefits is required:

- If no, go to step 45.

- If yes, return to the appropriate Conversion and renewal task.
               [Conversion and renewal](/en/procedure/activity/conversions.shtml)

- Complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1496.dita`

Note:

If fact-finding is required at Level 1 to adjudicate the RFS, the agent also fact-finds for any other required information:

- Did the client work at least a half hour with the WS employer?

- If yes, what BT does the client want to receive for the week of the separation?

- Any details required for claimant’s reports for the WS period that must be modified or that have not been received. Refer to Claimant’s report for more information.
         [Claimant’s report](/en/procedure/activity/claimant_report.shtml)

     [Claimant’s report](/en/procedure/activity/claimant_report.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_1497.dita`

Note:

Note the claimant’s reports information up to and including the new WS end week, as they will need to be re-input later. 

## Policy reference

Source topic: `en_EN/task/actioning_perm_reason_sep_wsc/policy_reference.dita`

- EIR 26(1)
         [EIR 26(1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-26.html)

- EIR 44
         [EIR 44](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-44.html) 
