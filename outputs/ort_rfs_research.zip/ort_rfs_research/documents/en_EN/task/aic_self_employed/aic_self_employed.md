# Adjudicating an Integrity case — Self-employed

Source map: `en_EN/task/aic_self_employed/aic_self_employed.ditamap`

## Summary

Source topic: `en_EN/task/aic_self_employed/summary.dita`

Summary: Investigators inform us of the results of an investigation in which they find that clients did not declare their self-employment (SE). 

## What you need to know

Source topic: `en_EN/task/aic_self_employed/what_you_need_to_know.dita`

### Processing an Integrity claim review

Source topic: `en_EN/task/aic_self_employed/processing_an_integrity_claim_review.dita`

Below are the main processing steps for this activity. If the officer determines that the client knowingly made a false or misleading statement, the officer must adjudicate the SE issue, complete the record of decision (ROD), and refer to Misrepresentation to determine the type of sanction to impose. Input the complete decision after determining the sanction.
       [Misrepresentation](/en/procedure/activity/misrepresentation.shtml)

**Reconsidering a decision**

EIA 52 states that a claim for benefits may be reconsidered as long as it results in an overpayment (OP) or an underpayment (UP). The time limit for reconsidering a claim is 36 months from the week benefits were paid or payable. This period is extended to 72 months if there is a false or misleading statement.
       [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

**Determining if a false statement was made**

A false statement is a statement that is incorrect or untrue. It can be the result of an intentional or negligent action, or it can be the result of an honest mistake.

For example, a client is self-employed but, when completing the application for benefits, answers No to the question “Are you self-employed, other than fishing or farming?” At this point, the officer only knows that the information provided by the client is incorrect. Without an explanation from the client, it cannot be determined if the client intentionally or knowingly provided incorrect information.

Regardless of whether it was intentional or an honest mistake, the client did not report the SE; therefore the reconsideration timeframe can be extended to 72 months.

**Determining if a false statement was knowingly made**

Knowingly means the officer can reasonably conclude that clients knew the information provided was untrue when they provided or did not declare that information. There is no element of intent in this consideration. It is not necessary to determine a degree of fault. The officer must only establish that it is more likely that clients understood the information provided and did not accurately portray the facts.

If the client received payments by paper cheque, each cheque cashed can be considered a misrepresentation under EIA 38(1)(e). If the client received payments by direct deposit, each direct deposit payment or any excess amount the client received and did not return can be considered a misrepresentation under EIA 38(1)(f).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1814.dita) 

**Reviewing a potential case of voluntary disclosure**

The National Policy on Voluntary Disclosure encourages clients, employers and third parties to come forward and voluntarily disclose misrepresentations. Under this policy, voluntary disclosure occurs when a person admits to having knowingly made a false statement.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

An investigator may recommend that the file be reconsidered in light of the National Policy on Voluntary Disclosure .
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

There are 2 essential criteria for accepting the voluntary disclosure:

- There is no investigation under way in relation to the voluntary disclosure when a client admits to making a false statement.

- The false statement would have resulted in punitive measures such as a penalty, a warning or prosecution had there been no voluntary disclosure.

According to the National Policy on Voluntary Disclosure , there is no limit to the number of times that a client can voluntarily disclose information.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 

### Role of the investigator

Source topic: `en_EN/task/aic_self_employed/role_of_the_investigator.dita`

- The investigator must obtain all facts and documentation in relation to the 6 circumstances and any evidence related to the client’s SE. Furthermore, the investigator must gather the following evidence in all situations, regardless of the recommendation:

- documents outlining all expenses and the dates of these expenses (these documents must be clear and legible)

- documents related to the client’s gross income

         [6 circumstances](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-4/independent-workers-full-week.html#a4_6_4_1)

- The investigator must not determine what constitutes operating costs. The investigator must instead understand the context of these expenses and communicate that information to the Level 2 officer.

- The investigator calculates the earnings that must be applied and refers the complete investigation to the Level 2 officer. The Level 2 officer must apply the net earnings. 

### Role of the Level 2 officer

Source topic: `en_EN/task/aic_self_employed/role_of_the_level_2_officer.dita`

The Level 2 officer is responsible for processing the Claim Review (CR) Integrity WI that is assigned to him or her. The officer must consult NIIS for each case to find all the relevant information to adjudicate the issue. This includes information such as the statements of the client, the employer or a third party, and the Report of Investigation.

- The Level 2 officer must establish if the client was engaged in SE and if the client was engaged in work to a minor extent. The Level 2 officer renders a decision based on the facts on file and the results of the investigator’s fact-finding.

- When the Level 2 officer establishes that the client was engaged in work that was” minor in extent”, the officer calculates, with the facts from the investigator:

- gross income

- deductible expenses to determine the net income

- amount to allocate for the employment period 

### Determining if the client is self-employed

Source topic: `en_EN/task/aic_self_employed/determining_if_the_client_is_self-employed.dita`

When the officer establishes that the client is a self-employed worker or is engaged in the operation of a business either on his or her own account, in a partnership or as a co-adventurer, the client is generally deemed to be not unemployed and, to this effect, the client must be disentitled.

The officer must determine from the facts presented that the client is not unemployed or that the employment is to such a minor extent that a person would not rely on that employment as a principal means of livelihood.

**Determining if the self-employment (SE) is minor in extent**

There are 6 factors to consider in determining if the client is employed to such a minor extent that a person would not rely on that employment as a principal means of livelihood (refer to EIR 30(3) ):
       [EIR 30(3)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-30.html)

- time spent on the SE

- nature and amount of the capital and resources invested

- financial success or failure of the employment or business

- continuity of the employment or business

- nature of the employment or business

- client's intention and willingness to seek and immediately accept alternate employment 

### Farming

Source topic: `en_EN/task/aic_self_employed/farming.dita`

A client engaged in farming activities can receive EI benefits during the off-season (October 1 to March 31) if the client shows that he is not employed or that the employment is so minor in extent that the client is not prevented from accepting full-time employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1815.dita) 

### Imposing a disentitlement

Source topic: `en_EN/task/aic_self_employed/imposing_a_disentitlement.dita`

When it is determined that the employment is not minor in extent, and full weeks of disentitlement apply, a 1 - Not unemployed disentitlement (D1) is imposed. This disentitlement is applicable to all benefit types.

Partial weeks of disentitlement are input on claims for regular or fishing benefits using a 3 - Not available disentitlement (D3). Partial weeks of disentitlement do not apply to special benefits, but earnings from farming are allocated. 

### Allocating self-employment (SE) earnings

Source topic: `en_EN/task/aic_self_employed/allocating_self-employment_se_earnings.dita`

When the client is considered not unemployed because of the SE and the client is not entitled to benefits, earnings are not allocated. Earnings from this activity are only allocated when the client is employed to a minor extent.

However, an investigation on the unemployment status must always include information on earnings and the unemployment status. Both these elements are inseparable. If it is established that the client is not unemployed, a D1 is imposed. If it is established that the client is unemployed, the earnings are allocated, and a new investigation is not required. 

### Returning a file to Integrity

Source topic: `en_EN/task/aic_self_employed/returning_a_file_to_integrity.dita`

After conducting a full review of the investigation, if the Level 2 officer determines that facts are missing, the officer must return the investigation to the investigator for further fact-finding and indicate the information that is missing but necessary to adjudicate the issue. The Level 2 officer must not adjudicate the issue if facts are missing or incomplete.

Facts are not considered missing or incomplete if the investigator has followed up with the client when the client fails to report for an interview or fails to reply to a request for information. The investigator is not required to send a follow-up letter but must make 2 attempts on 2 different days to contact the client by telephone. If the investigator leaves a message on a voicemail, only one attempt is required and they must allow 48 hours for the client to respond.

If the investigator recommends that the Integrity case be considered as voluntary disclosure, but the investigation type is not 70 in NIIS, the officer returns the file to Integrity.

The Integrity Services Branch does not verify the employer’s or third party’s version against the client’s version in the following situations:

- The investigation results in an actual or potential OP of less than the Integrity investigative threshold.

- There is no other active investigation.

In these situations, the officer does not return the case to Integrity because the employer’s or the third party’s version is missing. The officer is not required to validate the threshold. 

### Defining claim status (CS)

Source topic: `en_EN/task/aic_self_employed/defining_claim_status_cs.dita`

A claim can be active, terminated, blocked or archived. The CS impacts which transactions can be input and when the letter of decision is sent:

- Active: The active claim is established and is currently displayed automatically in FTS. It is a claim for which benefits are still payable and that has not been terminated.

- Terminated: A terminated claim appears on the Dormant tab in FTS. It has ended but can be reactivated. Once the transaction to reactivate the claim has been processed, all inputs for the claim must be done the same as for an active claim.

- Blocked: In some cases, the claim that the officer must reconsider is on the Dormant tab in FTS, but there is a new active claim established and displayed on the Summary screen. The officer makes adjustments to this type of claim using BCS if the blocked CS shows 1 - Updateable . Otherwise, IPOC intervention is required.

- Archived: Claims that are more than 7 years old are moved from the Dormant tab to the Archived tab. The officer can view an archived claim by changing the status of the archived claim from 1 -Non-Viewable to 2 - Viewable in FTS. Once the officer requests to make the claim viewable, the status field immediately displays 2 - Viewable and the claim becomes viewable the next business day for 2 weeks. Adjustments to this type of claim are processed with IPOC intervention. 

### Determining the order of FTS inputs

Source topic: `en_EN/task/aic_self_employed/determining_the_order_of_fts_inputs.dita`

Controlled, multiple-day inputs in FTS are required to establish separate OPs for each decision (e.g. unreported earnings and reason for separation [RFS]). When there is more than one reconsideration decision that results in an OP, the decisions must be input in the following order:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1816.dita) 

Controlled inputs in FTS are also required for UP and OP situations. The officer processes the inputs resulting in the OP first. Once the OP is established, the officer inputs an agreed deduction equal to the benefit rate amount. For more information, the officer refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

### BCS

Source topic: `en_EN/task/aic_self_employed/bcs.dita`

BCS allows certain types of transactions to be processed on blocked dormant claims. There are 2 options available: Estimate and Claim update .

**Claim update function**

When transactions must be input on a blocked claim, the officer reviews the Blocked Claims System tab in FTS to determine the CS in BCS. If the CS is 1 - Updateable , the officer requests an update using BCS and processes the transactions.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1666.dita) 

An update in BCS can only be done on one BPC at a time. When transactions are input but not processed, Yes appears in the Block Action Pending column and access is denied for input on all other BPCs until requested transactions are processed. Access to a BPC with a pending action is limited to the officer who initiated that action.

If an update is requested by the officer but cannot be completed by BCS, on the next processing day, the “Blocked claim not updated or not calculated” message is displayed along with the exception, error or warning on the MR05 screen. Officers review the exception, error or warning on the Results tab in BCS for further action. If the update cannot be completed using BCS, the system presents an estimate result. The decision can be sent to IPOC using the Forward via MM06 link, which creates the prefilled M106 and MM06.

**Estimate function**

The Estimate function in BCS allows officers to view and evaluate the end results without processing the transactions. Estimates are possible for blocked claims with a CS 1 - Updateable as well as unblocked dormant claims, provided the CS is 05 (inactive) or 06 (terminated) .

BCS Estimate transactions are processed overnight and the results are available on the Results tab the next day. Officers that have requested an estimate can view the end result and forward the request for IPOC intervention using the prefilled MM06 available under the Results tab.

**Creating an Operational Centre Memo (MM06) transaction for multiple issues**

When the MM06 includes multiple issues, if at least one issue is deemed to be a misrepresentation whereas at least another one is not, the officer ensures to include the appropriate OP message code for each issue in the Remarks section. 

### Record of decision (ROD)

Source topic: `en_EN/task/aic_self_employed/record_of_decision_rod.dita`

The Level 2 officer must record and document each decision in a separate ROD. 

### Note

Source topic: `en_EN/common_notes/note_c_1814.dita`

Note:

A false statement knowingly made does not always result in an OP of benefits. Since a monetary penalty is calculated based on the OP resulting from the misrepresentation, the officer can consider sending a warning letter if the client knowingly made a false statement but this misrepresentation did not result in an overpayment. 

### Note

Source topic: `en_EN/common_notes/note_c_1815.dita`

Note:

The 6 factors mentioned above must also be analysed in the same capacity as a self-employed worker. 

### Callout

Source topic: `en_EN/common_notes/note_c_1816.dita`

**Determining the input order for multiple transactions**

- full disentitlement

- partial disentitlement

- unreported earnings / unreported allocation of earnings

- indefinite disqualification

- definite disqualification 

### Note

Source topic: `en_EN/common_notes/note_c_1666.dita`

Note:

At this time, BCS cannot process a benefit period extension, the recalculation of a claim or the removal of a manual action (MA). The officer must send an Operational Centre Memo (MM06) transaction asking IPOC to process these transactions. 

## Regional considerations

Source topic: `en_EN/task/aic_self_employed/regional_considerations.dita`

**Quebec — Returning the file to Integrity**

In addition to the information already indicated in this procedure, do the following:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a Cc.

- In NWS, create a client Note and type “Measure — returned to Integrity” and include the date (YYYY-MM-DD). 

## What you need to look for

Source topic: `en_EN/task/aic_self_employed/what_you_need_to_look_for.dita`

### In NIIS:

Source topic: `en_EN/task/aic_self_employed/in_niis.dita`

- Review the IC07 Subject Enquiry screen for all active and prior cases.

- Review the IC04 Observation screen for a computer generated investigation.

- Review the IC08 Case Summary screen to see the actions taken on the case.

- Review the IC56 Case Notes screen to ensure you have the complete case.

- Review the IC50 Report of Clerical Investigation or IC70 Report of Investigation screen.

- Is there an Integrity Investigation Sheet?

- Is there a Report of Interview? 

### In Imaging:

Source topic: `en_EN/task/aic_self_employed/in_imaging.dita`

- Are there any documents that are relevant to the case? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/aic_self_employed/in_integrity_investigations_document_up_6a8da64b.dita`

- Are there any documents that are relevant to the case? 

### In NWS:

Source topic: `en_EN/task/aic_self_employed/in_nws.dita`

- Review the application for benefits.

- Review SROCs, RODs, Action Item and Call Back (CB) WIs for information relevant to the case. 

### In FTS:

Source topic: `en_EN/task/aic_self_employed/in_fts.dita`

- If applicable, review the claimant reports for the weeks under investigation.

- Is there an exemption from reporting?

- If yes, did the client receive payments by direct deposit?

- What is the CS (active, can be reactivated, blocked or archived)?

- If the claim is blocked, what is the CS in BCS? 

### In ACS:

Source topic: `en_EN/task/aic_self_employed/in_acs.dita`

- Was a Request for Clarification letter sent to the client by Integrity? 

## Step by step

Source topic: `en_EN/task/aic_self_employed/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/aic_self_employed/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/aic_self_employed/reviewing_the_file_level_2.dita`

- Determine if there is a false statement:

- If no, go to step 2.

- If yes, go to step 3.

- Determine if the request for reconsideration was made within the 36-month time limit:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_self_employed#nowithinreconsideration)

- Determine if the request for reconsideration is within the maximum reconsideration timeframe of 72 months:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_self_employed#nowithinreconsideration)

- Determine if the information gathered by Integrity is complete:

- If the information is complete, go to step 5.

- If the information is incomplete, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_self_employed#Returning)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1667.dita)

- In NWS, create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction ):

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Adjudicate the unreported SE. Refer to Adjudicating self-employment , Adjudicating farming or Digest 4 — Week of Unemployment :

- If the client is determined to be not unemployed in relation to the SE or to the farming activities, go to step 7.

- If the client proves that the SE is minor in extent, go to Minor in extent .
               [Minor in extent](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_self_employed#Minor)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1817.dita)

- Determine if the client knowingly made a false or misleading statement, as described in Digest 18.3.1.5 — Knowingly and Digest 18.3.1.4 — Misleading :

- If there is a false statement that is knowingly made, go to step 8.

- If there is a false statement that is not knowingly made, go to step 11.

- If there is no false statement, go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_self_employed#reconsideration36)

- Determine if the investigator recommends that the file be reconsidered in light of a voluntary disclosure, as described in National Policy on Voluntary Disclosure :

- If the voluntary disclosure criteria are not met, go to step 9.

- If the voluntary disclosure criteria are met but the investigation type in NIIS is not 70, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_self_employed#Returning)

- If the voluntary disclosure criteria are met and the investigation type in NIIS is 70, go to Voluntary disclosure approved .
               [Voluntary disclosure approved](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_self_employed#voluntarydisclosure)

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — [not unemployed, self-employed or farming].”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- For each of the following 6 criteria, document the relevant facts to support the decision:

- nature of the employment or business

- continuity of the employment or business

- financial success or failure of the employment or business

- nature and amount of the capital

- time spent

- client’s intention and willingness

- Go to Adjudicating client or third party misrepresentation — Monetary penalty or warning letter to determine the appropriate sanctions and input all the decisions.

- Determine the reconsideration timeframe for the false or misleading statement not knowingly made:

- If the false statement was made within the prescribed period of 36 months , go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_self_employed#reconsideration36)

- If the false statement was made within the extended period of 72 months , go to Reconsideration after 36 months .
               [Reconsideration after 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_self_employed#reconsideration37) 

#### Not within reconsideration timeframe

Source topic: `en_EN/task/aic_self_employed/not_within_reconsideration_timeframe_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — EIA 52 — not within reconsideration timeframe.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Not within reconsideration timeframe, no adjudication on the SE or farming activities.”

- Penalty: Select No .

- Warming: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Returning the file to Integrity

Source topic: `en_EN/task/aic_self_employed/returning_the_file_to_integrity_level_2.dita`

- In NIIS, from the Document tab, select IC70 Report of Investigation or IC50 Report of Clerical Investigation , depending on the case, and complete the following fields:

- Select Recommendation .

- Refer the file to Integrity as follows:

- Select Yes (IC70).

- Check the box (IC50).

- Enter the missing or additional information required in the text area.

- Select OK .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1796.dita)

- In FTS, click the Outstanding Registrations link to cancel the registration number as follows:

- Click Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Click Update .

- If applicable, return the hard-copy documents used in the investigation to the signatory investigator of the investigation report.

- In NWS, complete the CR Integrity WI. 

#### Minor in extent

Source topic: `en_EN/task/aic_self_employed/minor_in_extent_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — self-employed — minor in extent.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if this is an active claim.

- If yes, go to step 3.

- If no, go to step 4.

- Select the Additional Data (M107) transaction and input the signature code as follows:

- Signature: Select 2 - Self-employed not on SE project

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1818.dita)

- Go to Adjudicating an Integrity case — Unreported Earnings to allocate the SE earnings and to determine the next steps. 

#### Voluntary disclosure approved

Source topic: `en_EN/task/aic_self_employed/voluntary_disclosure_approved_level_2.dita`

- In NWS, create a ROD for the SE issue as follows:

- Comments: Type “[Integrity case number] — not unemployed, self-employed or farming.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD for the voluntary disclosure issue as follows:

- Comments: Type “[Integrity case number] — voluntary disclosure approved.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain that the client meets the 2 conditions for the National Policy on Voluntary Disclosure .
               [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 4.

- If the claim is terminated, but may be reactivated:

- Under the Terminated tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 4.

- If the claim is blocked or archived, go to step 9.

- Determine if the first week of the disentitlement is a partial or a full week:

- If the first week is a partial week, go to step 5.

- If the first week is a full week, go to step 6.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the D3 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if an MA is imposed to stop payments for the unreported SE:

- If an MA is imposed, go to step 7.

- If an MA is not imposed, go to step 8.

- In FTS, select the Renewal/Revised (M106) transaction to remove the MA and input the D1 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 1 - Not unemployed .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 19.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the D1 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 1 - Not unemployed .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 19.

- Determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed , go to step 10.

- If 2 - Not blocked is displayed, return to step 3.

- If any other CS is displayed, go to step 17.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 11.

- If all rows are blank, go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column under the Blocked tab:

- If Yes is displayed in one of the rows, return to step 11.

- If all rows are blank, go to step 13.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the applicable registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Under the Disentitlements tab, input the disentitlement on the Disentitlements section as follows (up to 4 disentitlements in BCS can be imposed, rescinded or terminated):

- Action: Select A - Add .

- Type: Select the appropriate disentitlement.

- 3 - Not available (if the first week of disentitlement is partial)

- 1 - Not unemployed (for a full week of disentitlement)

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select T – Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Update .

- Under the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 16.

- If the transaction shown is correct, select Close and go to step 19.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 14.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim related to the unreported SE.

- Work item: Select 91 - Overpayment .

- Work type: Select 1 - Misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D1 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 2: Type “D3 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 3: Type “ACS letter already sent.”

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Various reasons for penalty and violation (2935): Select the appropriate option.

- You have been self-employed

- According to our records / In addition, according to our records (2936)

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared / omitted (2953): Select the appropriate option.

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292) : Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim

- Overpayment – No misrepresentation and inactive claim

- In ACS, create and send the D-70-00-00 letter. Based on the client information, select all of the required attributes, including the following:

- Voluntary disclosure / Administrative Rule - Undeclared Earnings (2664):

- Voluntary disclosure of information

- Subjects of the voluntary disclosure (2665)

- Option #6: Your self-employment

- Blank/Reminder: Provide information on report (2667)

- Provide full and accurate information on each report and correct any incorrect reports as soon as possible .

- Overpayment messages (2452): Select the appropriate option

- Right to Request a Reconsideration (4169)

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other and type “D1 — not unemployed.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR WI Investigations and control. 

#### Reconsideration within 36 months

Source topic: `en_EN/task/aic_self_employed/reconsideration_within_36_months_level_2.dita`

- In NWS, create a ROD for the SE issue as follows:

- Comments: Type “[Integrity case number] — not unemployed, SE or farming activities.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- For each of the following 6 criteria, document the relevant facts to support the decision:

- nature of the employment or business

- continuity of the employment or business

- financial success or failure of the employment or business

- nature and amount of the capital

- time spent

- client’s intention and willingness

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 3.

- If the claim is terminated, but may be reactivated:

- Under the Terminated tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 3.

- If the claim is blocked or archived, go to step 8.

- Determine if the first week of the disentitlement is a partial or a full week:

- If the first week is a partial week, go to step 4.

- If the first week is a full week, go to step 5.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the D3 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if a MA is imposed to stop payments for the unreported SE:

- If an MA is imposed, go to step 6.

- If an MA is not imposed, go to step 7.

- In FTS, select the Renewal/Revised (M106) transaction to remove the MA and input the D1 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 1 - Not unemployed .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement.

- Infraction: Select A - Non-fraud - Earnings and Employment .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted in an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number for subsequent transactions.

- Select Update .

- Go to step 18.

- Select the Disqualifications/Disentitlements (M161) transaction and input the D1 as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 1 - Not unemployed .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement.

- Infraction: Select A - Non-fraud - Earnings and Employment .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted in an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number for subsequent transactions.

- Select Update .

- Go to step 18.

- Determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed , go to step 9.

- If 2 - Not blocked is displayed, return to step 2.

- If any other CS is displayed, go to step 16.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 10.

- If all rows are blank, go to step 12.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column under the Blocked tab:

- If Yes is displayed in one of the rows, return to step 10.

- If all rows are blank, go to step 12.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- On the Disentitlements tab, input the disentitlement on the Disentitlements section as follows (up to 4 disentitlements in BCS can be imposed, rescinded or terminated):

- Action: Select A - Add .

- Type: Select the appropriate disentitlement:

- 3 - Not available (if the first week of disentitlement is partial)

- 1 - Not unemployed (for a full week of disentitlement)

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select the appropriate option:

- For a D3, select B - Non-fraud - Availability, capability .

- For a D1, select A - Non-fraud - Earnings and Employment .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Update .

- Under the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 15.

- If the transaction shown is correct, click Close and go to step 18.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 13.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select A - Non-fraud - Earnings and Employment .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted in an indefinite disentitlement .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the undeclared SE.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D1 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 2: Type “D3 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 3: Type “ACS letter already sent.”

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Various reasons for penalty and violation (2935): Select the appropriate option.

- You have been self-employed

- According to our records / In addition, according to our records (2936)

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared / omitted (2953): Select the appropriate option.

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292) : Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim

- Overpayment – No misrepresentation and inactive claim

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other and type “D1 - Not unemployed.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Reconsideration after 36 months

Source topic: `en_EN/task/aic_self_employed/reconsideration_after_36_months_level_2.dita`

- In NWS, create a ROD for the SE issue as follows:

- Comments: Type “[Integrity case number] — not unemployed, self-employed or farming activities.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- For each of the following 6 criteria, document the relevant facts to support the decision:

- nature of the employment or business

- continuity of the employment or business

- financial success or failure of the employment or business

- nature and amount of the capital

- time spent

- client’s intention and willingness

- In FTS, determine the blocked claim’s CS by reviewing the Blocked Status column under the Blocked tab:

- If 1 - Updateable is displayed , go to step 3.

- If any other CS is displayed, go to step 10.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 4.

- If all rows are blank, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column under the Blocked tab:

- If Yes is displayed in one of the rows, return to step 4.

- If all rows are blank, go to step 6.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Under the Disentitlements tab, input the disentitlement on the Disentitlements section as follows (up to 4 disentitlements in BCS can be imposed, rescinded or terminated):

- Action: Select A - Add .

- Type: Select the appropriate disentitlement:

- 3 - Not available (if the first week of disentitlement is partial)

- 1 - Not unemployed (for a full week of disentitlement)

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select the appropriate option:

- For a D3, select B - Non-fraud - Availability, capability .

- For a D1, select A - Non-fraud - Earnings and Employment .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Update .

- Under the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 10.

- If the transaction shown is correct, select Close and go to step 12.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 7.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select A - Non-fraud - Earnings and Employment .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement

- 4 - An overpayment resulted in an indefinite disentitlement

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the undeclared SE.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D1 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 2: Type “D3 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 3: Type “ACS letter already sent.”

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Decision reconsidered beyond 36 months (2595): Select Decision reconsidered beyond 36 months due to false representations

- Various reasons for penalty and violation (2935): Select the appropriate option.

- You have been self-employed

- According to our records / In addition, according to our records (2936)

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared / omitted (2953): Select the appropriate option.

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292) : Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim

- Overpayment – No misrepresentation and inactive claim

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other and type “D1 — not unemployed.”

- Penalty: Select No .

- Warming: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1667.dita`

Note:

Cases with an OP below the Integrity investigative threshold are referred for adjudication only when specific exceptions are met (voluntary disclosure or impact on an active claim). In these cases, the employer’s or any other party’s version does not have to be verified and the file must not be returned to Integrity. 

#### Note

Source topic: `en_EN/common_notes/note_c_1817.dita`

Note:

When the Level 2 officer determines that the client is employed “minor in extent”, the officer must allocate the employment earnings from the facts obtained by the investigator. 

#### Note

Source topic: `en_EN/common_notes/note_c_1796.dita`

Note:

The regional consideration for officers in the Quebec region is as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a Cc.

- In NWS, create a client Note and type “Measure — returned to Integrity” and include the date (YYYY-MM-DD). 

#### Note

Source topic: `en_EN/common_notes/note_c_1818.dita`

Note:

All other fields on the Additional Data (M107) transaction must be blank. A registration number is not required. 

#### Note

Source topic: `en_EN/common_notes/note_c_1791.dita`

Note:

An update in BCS can only be done on one BPC at a time. 

## Policy reference

Source topic: `en_EN/task/aic_self_employed/policy_reference.dita`

- Digest 4 — Week of Unemployment
         [Digest 4 — Week of Unemployment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-4/table-of-contents.html)

- Digest 17 — Reconsideration, Amendment of a Decision, and Error Correction
         [Digest 17 — Reconsideration, Amendment of a Decision, and Error Correction](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/table-of-contents.html)

- Digest 18 — Policy on Penalties
         [Digest 18 — Policy on Penalties](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/table-of-contents.html)

- EIR 30(3)
         [EIR 30(3)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-30.html)

- EIA 9
         [EIA 9](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-9.html)

- EIA 11
         [EIA 11](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-11.html)

- EIA 38
         [EIA 38](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-11.html)

- EIR 52
         [EIR 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 
