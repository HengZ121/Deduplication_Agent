# Adjudicating non-referred training: Regular or fishing benefits — Initial claim

Source map: `en_EN/task/training_non_reftraining/training_non_reftraining.ditamap`

## Summary

Source topic: `en_EN/task/training_non_reftraining/summary.dita`

Summary: When a client reports non-referred training on the EI application or while an initial claim is in progress, adjudication is required to determine entitlement to benefits during the training period. 

## What you need to know

Source topic: `en_EN/task/training_non_reftraining/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/task/training_non_reftraining/training_reported_between_september_27__5ecd71c7.dita`

A transitional measure under which ACP automatically adjudicated and allowed all training effective September 27, 2020 ended on September 11, 2021. The intent of this measure was to prevent any delay in payment to clients who reported training. To receive regular benefits, clients must still be able to prove that they are capable of and available for work while attending non-referred training.

If the client reports not being available while attending the non-referred training, either on a claimant’s report or when speaking to an officer, the officer creates a WI for the training issue and follows normal adjudication procedures. If the Level 1 officer cannot allow the client’s availability, the Level 1 officer reassigns the WI to Level 2.

The Commission has the authority to impose a retroactive 3 - Not available disentitlement (D3) if the client is unable to prove availability, even if ACP initially allowed the training. When the Level 2 officer determines that the client has not proven availability from the start date of the course, the officer imposes a retroactive D3. For more information on availability, the officer refers to Digest 10.3 — Credibility and 10.12 — Courses of instruction/employment measures .
       [10.3 — Credibility](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/credibility.html#a10_3_0) 
       [10.12 — Courses of instruction/employment measures](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_0) 

### Adjudication required on manually registered claims

Source topic: `en_EN/task/training_non_reftraining/adjudication_required_on_manually_regis_d5cd9e4c.dita`

The officer manually registers claims that are not automated in ACP. Training is not automatically adjudicated on manually registered claims. Instead, ACP assigns an Adjudication Issue (ADJ) WI to an officer because it could not automate the decision. Adjudication of these training ADJ WIs is required, and the officer follows the appropriate procedures to resolve them. Even if ACP initially allowed training, when a training ADJ WI is assigned (e.g. upon renewal), the officer must adjudicate. Additionally, if it is determined that a disentitlement applies from the start date of the training course, the Level 2 officer imposes a retroactive D3. 

### Impact of training on regular or fishing benefits

Source topic: `en_EN/task/training_non_reftraining/impact_of_training_on_regular_or_fishin_e0a51eda.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4817.dita) 

Taking a training course on one’s own initiative creates an availability issue. When clients are receiving regular benefits, they must be available for and actively seeking employment. Training should not limit a client’s employment opportunities. A client receiving fishing benefits may also take training. The adjudication and inputs are the same whether the claim is for regular or fishing benefits.

This includes clients who are attending short-term training courses and targeted initiatives. For a complete list of non-referred short-term courses and targeted initiatives, the officer refers to the job aid .
       [job aid](/en/procedure/generic/additionalresources/shortterm_courses_ti.shtml)

Before adjudicating availability during non-referred training, it is important to first consider whether the client could be referred to the course under EIA 25 . This step ensures that entitlement to benefits is correctly determined. Clients are considered unemployed and capable of and available for work when attending referred training.
       [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4818.dita) 

**Long-tenured workers**

A client who reports attending full-time training may be identified as a long-tenured worker. If the conditions are met, a client who is identified as a long-tenured worker and who wishes to attend self-funded full-time training can be referred to that training by Service Canada.

To be considered a long-tenured worker, a client must meet the following 2 conditions:

- have paid at least 30% of the maximum EI premiums for at least 7 of the last 10 years;

- not have received more than 35 weeks of regular benefits in the last 156 weeks (3 years) before the BPC of the current claim.

Service Canada has the authority to approve full-time training for a long-tenured worker. However, before adjudicating training, the officer adjudicates other contentious issues to determine if the client is entitled to benefits. This can help the client better understand the decision-making process, as the client may assume that for a referred training situation, contentious issues are automatically allowed.

When a client is identified as a long-tenured worker, the officer refers to Adjudicating training for a long-tenured worker — Initial claim .
       [Adjudicating training for a long-tenured worker — Initial claim](/en/procedure/task/rend-dec-form-ld-ini-adj-tra-lt-worker-ini.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0159.dita) 

### Availability during non-referred training

Source topic: `en_EN/task/training_non_reftraining/availability_during_non-referred_training.dita`

When clients report that they are attending full-time training on their own initiative, the officer refers to BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training and the Digest of Benefit Entitlement Principles 10.12.2.8 — Hours of work . T he BE Memo and the Digest explain that, under FCA A-29-22 , when adjudicating availability, the officer consider s the clients’ work history while attending training, in addition to other factors (i.e. the number of hours clients are attending training). Clients can rebut the presumption of non-availability if they can demonstrate having a regular work history outside of the training hours while taking full-time training. Using any previous ROEs, the officer reviews the number of hours the client worked while attending training to determine if the client can rebut the presumption of non-availability. Clients must also demonstrate a willingness and ability to remain available for a similar work schedule. Clients must not reduce or restrict their available hours of work beyond what is reasonable, given their work history, while attending training.
       [BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training](/en/policy/bememo/be2023-05.shtml) 
       [Digest of Benefit Entitlement Principles 10.12.2.8 — Hours of work](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2_8) 
       [FCA A-29-22](https://www.canlii.org/en/ca/fca/doc/2023/2023fca169/2023fca169.html)

The officer determines the total number of hours per week that is being spent on the training, including:

- class time

- study time

- time spent working on assignments

- time spent doing research

Additional fact-finding or follow-up is not required when a client reports training of up to 9 hours per week.

Clients attending a training course equal to or greater than 10 hours per week must be willing to seek and accept all hours of work that are available to them in the labour market, including evenings, nights, shift work, inconvenient or long hours and overtime. A client who is unwilling or unable to quit the course in order to accept these hours of work, or whose job search efforts demonstrate such an unwillingness or inability, may not be able to prove availability for work.

The client’s individual circumstances must be examined to determine if the client is avoiding suitable employment because of an unwillingness or inability to work certain hours. If so, a disentitlement may be imposed.

Correspondence courses are treated the same as any other training. 

### Checklists

Source topic: `en_EN/task/training_non_reftraining/checklists.dita`

When clients report that they are participating in a short-term course or targeted initiative, the officer completes the appropriate checklist:

- For clients participating in a program with Women in Science and Engineering, the officer completes the Training: Women in Science and Engineering — Checklist .
         [Training: Women in Science and Engineering — Checklist](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Training-Women_in_Science_and_Engineering-Checklist.doc)

- For clients taking a short-term training course or participating in Employment Assistance Services, the officer completes the Training: Short-term or employment assistance services — Checklist .
         [Training: Short-term or employment assistance services — Checklist](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Training-Short-term_or_employment_assistance_services-Checklist.doc)

- For clients who are taking regular non-referred training, the officer completes the Training: Non-referred training for regular benefits — Checklist .
         [Training: Non-referred training for regular benefits — Checklist](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Training-Non-referred_training_for_regular_benefits-Checklist.doc) 

### Automated decisions

Source topic: `en_EN/task/training_non_reftraining/automated_decisions.dita`

When a client reports non-referred training on the EI application, in a claimant’s report or on MSCA, an electronic questionnaire is created and can be accessed in NWS. If the electronic questionnaire meets the Levels of Decision criteria for Level 1 adjudication, ACP can automate the adjudication of the non-referred training. In this case, ACP creates a record of decision (ROD) and inputs the training project data in FTS.

If ACP creates an Adjudication Issue (ADJ) WI and the client calls the EI call centre, the call centre officer may be able to adjudicate the non-referred training and complete the WI. 

### Processing the claim

Source topic: `en_EN/task/training_non_reftraining/processing_the_claim.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can process the claim. There is a Resolve Issue tab for ADJ Training WI which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a ROD based on the Resolve Issue screens. When the claim is established, the system also generates the required transactions (e.g. training information, disentitlement) based on the Resolve Issue screens. 

### Communicating the decision

Source topic: `en_EN/task/training_non_reftraining/communicating_the_decision.dita`

If the training is not allowed and a disentitlement is imposed, the system creates a Correspondence (COR) WI for the D-01-00-00 letter. No letter is sent when the training is allowed. 

### Note

Source topic: `en_EN/common_notes/note_c_4817.dita`

Note:

If adjudication is part of a recalculation, the officer refers to Adjudicating non-referred training: Regular or fishing benefits — Continuing claim (Task) .
       [Adjudicating non-referred training: Regular or fishing benefits — Continuing claim (Task)](/en/procedure/task/training_fishing.shtml)

     [Adjudicating non-referred training: Regular or fishing benefits — Continuing claim (Task)](/en/procedure/task/training_fishing.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4818.dita`

Note:

If a client quits employment or refuses an offer of employment to attend a non-referred training course, a non-referred short-term training course or a targeted initiative, the officer adjudicates the reason for separation on a separate WI. 

### Note

Source topic: `en_EN/common_notes/note_c_0159.dita`

Note:

To determine if a client is a long-tenured worker, the officer refers to Determining if a client is a long-tenured worker .
       [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml)

     [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml) 

## Regional considerations

Source topic: `en_EN/task/training_non_reftraining/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/training_non_reftraining/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/training_non_reftraining/in_fts.dita`

- Is there training information on the Project tab? 

### In NWS:

Source topic: `en_EN/task/training_non_reftraining/in_nws.dita`

- Has the training questionnaire been completed?

- Is there an SROC with the training information, , from either the Training: Non-referred part-time training — Checklist or the Training: INS3141 Training course information — Form
         [Training: Non-referred part-time training — Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Training-Non-referred_part-time_training-Checklist.doc) 
         [Training: INS3141 Training course information — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ESDC-INS3141.pdf) 

### In Imaging:

Source topic: `en_EN/task/training_non_reftraining/in_imaging.dita`

- Is there non-referred training information or the INS3141 form? 

### In the LMDAAccess module of EIBIS:

Source topic: `en_EN/task/training_non_reftraining/in_the_lmdaaccess_module_of_eibis.dita`

- Is there a Notice of Intent to refer the client to training? 

## Step by step

Source topic: `en_EN/task/training_non_reftraining/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/training_non_reftraining/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_non_reftraining/reviewing_the_file_level_1.dita`

- In FTS, determine if there is referred training information displayed on the Project tab:

- If no, go to step 2.

- If yes, refer to Confirming referred training: Regular or fishing benefits — Initial claim .
               [Confirming referred training: Regular or fishing benefits — Initial claim](/en/procedure/task/training_ic.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2699.dita)

- In FTS, in the Claimaint category field in the Special Coding tab, determine if the client has been categorized:

- If the Claimaint category field is blank, refer to Determining if a client is a long-tenured worker :

- If the client is identified as a long-tenured worker, go to step 3.

- If the client is not identified as a long-tenured worker, go to step 4.

               [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml)

- In NWS, review the training questionnaire from the application or the training checklist on file and determine if the client states to attend full-time training:

- If no, go to step 4.

- If yes, adjudicate the claim as referred training. Refer to Adjudicating training for a long-tenured worker — Initial claims .
               [Adjudicating training for a long-tenured worker — Initial claims](/en/procedure/task/rend-dec-form-ld-ini-adj-tra-lt-worker-ini.shtml)

- In EIBIS determine if there is a Notice of Intent as follows:

- Enter your user name and password (same as Windows, firstname.lastname).

- Select Submit .

- Select LMDAAccess and enter the client’s SIN.

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4819.dita) 

- If there is no Notice of Intent, go to step 5.

- If there is a Notice of Intent to refer the client to training, refer to Confirming referred training: Regular or fishing benefits — Initial claim .
               [Confirming referred training: Regular or fishing benefits — Initial claim](/en/procedure/task/training_ic.shtml)

- Determine if adjudication can be deferred by consulting the Deferring adjudication procedure.

- Determine, if there is enough information to adjudicate the non-referred training:

- If additional details are needed, go to step 7.

- If additional details are not needed, go to step 10. 

#### Fact-finding

Source topic: `en_EN/task/training_non_reftraining/fact-finding_level_1.dita`

- Fact-find with the client. If not already on file, use the appropriate checklist.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 9.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining#ReassignToLevel2)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — regular benefits.”

- Details: If completed during fact-finding, copy and paste the checklist. Document additional fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/training_non_reftraining/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the client reported training in error:

- If no, go to step 11.

- If yes, go to Training reported in error .
               [Training reported in error](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining#TRainingDeclaredInError1)

- Determine the type of training the client is attending:

- If the client is attending regular non-referred training, go to step 12.

- If the client is attending a short-term training course or a targeted initiative, go to step 13.

- Determine the number of hours per week spent on the regular non-referred training:

- If the number of hours is 10 to 14 , go to step 13.

- If the number of hours is 15 or more , go to step 14.

- If the number of hours is 9 or less , go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining#TrainingAllowedAtLevel1)

- Determine if the following conditions are met for the regular non-referred training of 10 to 14 hours per week, for the short-term training course or for the targeted initiative:

- The client is available and capable of working and is not limiting the acceptance of employment (or the hours or days of availability) because of the training.

- If the course conflicts with a full-time job, the client is willing to quit or change the course schedule to accept the full-time employment.

- If both conditions are met, go to Entitlement conditions met .
                   [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining#TrainingAllowedAtLevel1)

- If one of the conditions is not met, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining#ReassignToLevel2)

- Determine if the following conditions are met for the regular non-referred training:

- All of the course obligations occur outside the normal work hours of their usual occupation.

- The client is willing to quit the course or change the course schedule to accept full-time employment.

- The client is available and capable of working and is not limiting acceptance of employment.

- If all of the conditions are met, go to Entitlement conditions met .
                   [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining#TrainingAllowedAtLevel1)

- If any of the conditions are not met, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining#ReassignToLevel2)

- If both conditions are met, go to Entitlement conditions met .

- If one of the conditions is not met, go to Reassigning the issue to Level 2 .

- If all of the conditions are met, go to Entitlement conditions met .

- If any of the conditions are not met, go to Reassigning the issue to Level 2 . 

#### Training reported in error

Source topic: `en_EN/task/training_non_reftraining/training_reported_in_error_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Training screen as follows:

- Select The facts on file show training was declared in error by the client .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Entitlement conditions met

Source topic: `en_EN/task/training_non_reftraining/entitlement_conditions_met_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Training screen as follows:

- Select Based on the information on file, the criteria to allow the decision to be made at Level 1 have been met (National Policy on Levels of Decision) .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select the appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/training_non_reftraining/reassigning_the_issue_to_level_2_level_1.dita`

- In FTS, input or update any outstanding claimant’s reports for the period before the training start date.

- In NWS, reassign the WI as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type the appropriate reason:

- “Unable to contact client for fact-finding.”

- “Not within Level 1 authority.”

- Select OK .

- When the Warning window is displayed, select Ok . 

#### Note

Source topic: `en_EN/common_notes/note_c_2699.dita`

Note:

For subsequent claims, the referred training information may be displayed on the Project tab of the previous BPC. In FTS, review the previous BPC on the Dormant tab. 

#### Note

Source topic: `en_EN/common_notes/note_c_4819.dita`

Note:

If a Notice of Intent to refer the client to training has been entered by the referring authority, it is displayed at the bottom of the screen, below Claimant Information , EI Claim Info and Allocation of Earnings . 

### Level 2

Source topic: `en_EN/task/training_non_reftraining/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_non_reftraining/reviewing_the_file_level_2.dita`

- In FTS, determine if there is referred training information displayed on the Project tab:

- If no, go to step 2.

- If yes, refer to Confirming referred training: Regular or fishing benefits — Initial claim .
               [Confirming referred training: Regular or fishing benefits — Initial claim](/en/procedure/task/training_ic.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2699.dita)

- In FTS, in the Claimaint category field in the Special Coding tab, determine if the client has been categorized:

- If the Claimaint category field is blank, refer to Determining if a client is a long-tenured worker :

- If the client is identified as a long-tenured worker, go to step 3.

- If the client is not identified as a long-tenured worker, go to step 4.

               [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml)

- In NWS, review the training questionnaire from the application or the training checklist on file and determine if the client reports attending full-time training:

- If no, go to step 4.

- If yes, adjudicate the claim as referred training. Refer to Adjudicating training for a long-tenured worker — Initial claims .
               [Adjudicating training for a long-tenured worker — Initial claims](/en/procedure/task/rend-dec-form-ld-ini-adj-tra-lt-worker-ini.shtml)

- In EIBIS determine if there is a Notice of Intent as follows:

- Enter your user name and password (same as Windows, firstname.lastname).

- Select Submit .

- Select LMDAAccess and enter the client’s SIN.

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4819.dita) 

- If there is no Notice of Intent, go to step 5.

- If there is a Notice of Intent to refer the client to training, refer to Confirming referred training: Regular or fishing benefits — Initial claim .
               [Confirming referred training: Regular or fishing benefits — Initial claim](/en/procedure/task/training_ic.shtml)

- Determine if adjudication can be deferred by consulting the Deferring adjudication procedure.

- Determine, if there is enough information to adjudicate the non-referred training:

- If additional details are needed, go to step 7.

- If additional details are not needed, go to step 10. 

#### Fact-finding

Source topic: `en_EN/task/training_non_reftraining/fact-finding_level_2.dita`

- Fact-find with the client. If not already on file, use the appropriate checklist .

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 9.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 10.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — regular benefits.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating non-referred training

Source topic: `en_EN/task/training_non_reftraining/adjudicating_non-referred_training_level_2.dita`

- Determine if the client reported training in error, was engaged in the training before the benefit period or is not attending training:

- If none of these conditions are met, go to step 11.

- If any of these conditions are met, go to Training not an issue .
               [Training not an issue](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining#TrainingNotAnIssue2)

- Adjudicate the non-referred training according to the entitlement principles of Digest 10.12.2 — Persons attending courses on their own initiative and BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training and determine if the client has proven being available:

- If the client has proven being available, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining#entitlement_met_l2)

- If the client has not proven being available, go to Entitlement conditions not met .
               [Entitlement conditions not met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining#entitlement_not_met_l2) 

#### Training not an issue

Source topic: `en_EN/task/training_non_reftraining/training_not_an_issue_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Training is not an issue .

- Select Continue .

- Complete the Training is not an issue screen as follows:

- Relevant Facts: Indicate why the training is not an issue.

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale: Select the reason why training is not an issue.

- References: Enter any additional references.

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Entitlement conditions not met

Source topic: `en_EN/task/training_non_reftraining/entitlement_conditions_not_met_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Engaged in non-referred training .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select the appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Complete the Engaged in non-referred training screen as follows:

- Relevant Facts:

- Indicate whether the client has completed the training course.

- Indicate whether the client voluntarily left employment to take the course and provide additional information if applicable.

- Summarize the evidence.

- Indicate whether the client agreed to comply with the relevant job search and suitable employment expectations.

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4816.dita)

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale:

- Based on the evidence, is it determined that the client’s actions are directed at finding suitable employment?: Select No .

- Does the Commission determine that he client has proven that s/he is capable of and available for work and unable to obtain suitable employment while attending a course of instruction?: Select No .

- Enter any other supporting jurisprudence.

- Enter any additional rationale information.

- References: Enter any additional references.

- Decision: Select Not allowed - Disentitlement, not available (D-3) .

- Disentitlement start: Select the appropriate option:

- Select BPC .

- Select Specific date and enter the start date of the disentitlement (Monday to Friday).

- Disentitlement end: Select the appropriate option:

- If the end date of the course has not been reached or is unknown, select Indefinite .

- Select Specific date and enter the end date of the course.

- Overpayment: Review and, if required, modify the prefilled codes in the Detection , Infraction and Message fields.

- Select Continue .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4718.dita)

- Verbally communicate the decision to the client.

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- Determine if the type of training the client is attending:

- If the client is attending regular non-referred training, go to step 7.

- If the client is attending a short-term course or a targeted initiative, go to step 8.

- In ACS, save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D3 - Not available - Various Reasons (2986) .

- Select D3 - On a non-approved training course – Availability not proven/Restrictions while on a training course/ Not looking for work (2987) .

- We / In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- Go to step 9.

- In ACS, save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D3 - Not available - Various Reasons (2986) .

- Select D3 - No reply to written request/text: Why not available/text: Why not available for only ONE day (2992) .

- Select D3 - Text: Indicate reason why client not available .

- We / In addition, we (2687) .

- Indefinite / Definite disentitlement dates / Date being disentitled (13020) .

- Text - Specify reason(s) disentitled (1482): Type “you are participating in a short-term course [or the type of initiative] on your own initiative.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note and type “Send the saved D-01-00-00 letter.”

- Complete the ADJ WI. 

#### Entitlement conditions met

Source topic: `en_EN/task/training_non_reftraining/entitlement_conditions_met_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Engaged in non-referred training .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select the appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Complete the Engaged in non-referred training screen as follows:

- Relevant Facts:

- Indicate whether the client has completed the training course.

- Indicate whether the client voluntarily left employment to take the course and provide additional information if applicable.

- Summarize the evidence.

- Indicate whether the client agreed to comply with the relevant job search and suitable employment expectations.

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4816.dita)

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale:

- Based on the evidence, is it determined that the client’s actions are directed at finding suitable employment?: Select Yes .

- Does the Commission determine that he client has proven that s/he is capable of and available for work and unable to obtain suitable employment while attending a course of instruction?: Select Yes .

- Enter any additional rationale information.

- References: Enter any additional references.

- Decision: Select Allowed - availability in order .

- Select Continue .

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4816.dita`

Note:

If the client voluntarily left employment to take the course, that issue must be adjudicated and resolved in a separate WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4718.dita`

Note:

If the decision is the result of an Integrity case, the prefilled overpayment codes must be changed to match the Report of Investigation. 

## Policy reference

Source topic: `en_EN/task/training_non_reftraining/policy_reference.dita`

- BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training
         [BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2023-05.shtml)

- Digest 10.12.2 — Persons attending courses on their own initiative
         [Digest 10.12.2 — Persons attending courses on their own initiative](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 25
         [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- EIR 9.002
         [EIR 9.002](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-9.002.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
