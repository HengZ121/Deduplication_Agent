# Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim

Source map: `en_EN/task/conv_regsick_eia25/conv_regsick_eia25.ditamap`

## Summary

Source topic: `en_EN/task/conv_regsick_eia25/summary.dita`

Summary: Clients receiving regular benefits who are unable to work because of illness, injury or quarantine may request a conversion to sickness benefits while also being referred under EIA 25. 

## What you need to know

Source topic: `en_EN/task/conv_regsick_eia25/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/conv_regsick_eia25/untitled_section.dita`

For a claim to be converted to sickness benefits, the entitlement conditions for sickness benefits must be met.

The officer reviews all documentation in the electronic claim to ensure all issues and information have been addressed as appropriate. The system does not generate a new WI or send a notification for outstanding Claim Assessment (CA) or Specialized Application (SA) WIs when documents are uploaded in all situations. 

### Qualifying for sickness benefits

Source topic: `en_EN/task/conv_regsick_eia25/qualifying_for_sickness_benefits.dita`

A client qualifies for sickness benefits if one of the following qualifying conditions is met:

- The client is major attached (has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

- The client is minor attached (has fewer than 600 insurable hours) and qualifies for regular benefits with a reason for separation (RFS) other than illness, injury or quarantine.
         [minor attached](/en/procedure/generic/knowledge.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2791.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0021.dita) 

**Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits, regardless of the conversion date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to sickness benefits

Source topic: `en_EN/task/conv_regsick_eia25/entitlement_to_sickness_benefits.dita`

A client is entitled to sickness benefits if the following conditions are met:

- The client is unable to work because of illness, injury or quarantine.

- The client is otherwise available for work.

The client can receive up to 26 weeks of sickness benefits per benefit period (BP) for a BPC in w/c 2374 or later, and up to 15 weeks of sickness benefits per BP for a BPC in w/c 2373 or earlier. Once a claim has been established, a client may receive a combination of regular and special benefits within the BP. The maximum entitlement to benefits varies based on the benefits type (BT) received. The maximum number of weeks payable for each BT cannot be exceeded.
       [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2653.dita) 

The officer imposes a 22 - Illness (maximum sickness/special benefits paid) disentitlement (D22) when a client requests sickness benefits but the maximum weeks of sickness benefits have already been paid.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2792.dita) 

### Extending of the benefit period (BP)

Source topic: `en_EN/task/conv_regsick_eia25/extending_of_the_benefit_period_bp.dita`

The BP can be extended to a maximum of 104 weeks to pay additional weeks of sickness benefits when all of the conditions are met during the initial BP. The officer must refer to Benefit period extension for more information.
       [Benefit period extension](/en/procedure/activity/extension_benefit_period.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Determining if a medical certificate must be submitted

Source topic: `en_EN/task/conv_regsick_eia25/determining_if_a_medical_certificate_mu_d4cdaa5c.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2793.dita) 

When clients request a conversion to sickness benefits, they must obtain an acceptable medical certificate . The medical certificate must attest to their incapacity. Clients are asked to keep the medical certificate for 6 years and, if requested, submit it for processing purposes.
       [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

If a client requests a conversion from regular to sickness benefits for an initial period of incapacity, the officer can allow the conversion week + 8 weeks without a medical certificate if all following conditions are met:

- the client is major attached (i.e. has accumulated at least 600 hours of insurable employment) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment;

- there are no outstanding disqualifications, disentitlements or manual actions (MAs).

For information on when a medical certificate must be submitted, the officer refers to Determining if a medical certificate must be submitted — Renewal and continuing claims .
       [Determining if a medical certificate must be submitted — Renewal and continuing claims](/en/procedure/task/determining_med_cert_req.shtml)

When an acceptable medical certificate is requested but has not been submitted, a 16 - No medical certificate submitted disentitlement (D16) is imposed. 

### Sickness benefits requested for a partial week

Source topic: `en_EN/task/conv_regsick_eia25/sickness_benefits_requested_for_a_partial_week.dita`

Sickness benefits can be requested for a partial week. A partial week is defined as a week in which both of the following conditions are met:

- The first day of sickness declared by the client falls on a day other than a Saturday, Sunday or Monday.

- The client is requesting sickness benefits for that week.

When this occurs in the conversion week, the officer determines if the client is entitled to regular benefits for the partial week.

If the client is entitled to regular benefits, the partial week is processed as a week of regular benefits before the claim is converted to sickness benefits. The conversion to sickness benefits is effective the following week.

If the client is not entitled to regular benefits for the partial week due to a disentitlement or disqualification from regular benefits, the claim is converted to sickness benefits for that week and a D16 is imposed for the days before the period of sickness. This occurs when one of the following disentitlements or disqualification is imposed:

- 10 - Dismissal - misconduct proven disqualification (D10)

- 11 - Voluntary leaving - just cause not proven disqualification (D11)

- 42 - Suspension from employment disentitlement (D42)

- 43 - Leave of absence disentitlement (D43)

- 44 - Anticipated loss of employment disentitlement (D44)

- 46 - Variable entrance requirement not met - special benefits payable disentitlement (D46)

If the client is not entitled to regular benefits because all the weeks of entitlement have been paid, the claim is converted to sickness benefits and an 18 - Special benefits - claimant not entitled to regular benefits disentitlement (D18) is imposed for the days before the period of sickness. 

### Determining the incapacity period

Source topic: `en_EN/task/conv_regsick_eia25/determining_the_incapacity_period.dita`

To allow the payment of sickness benefits, the officer must determine the period in which the client is incapable of working by determining:

- the incapacity start date

- the end date of the incapacity

- the expected recovery date

- the recovery week to be input

**Incapacity start date**

For a conversion from regular to sickness benefits when no medical certificate needs to be submitted, the incapacity start date is the conversion week.

The officer refers to Sickness: Incapacity start date — Table to determine if an incapacity start date is required. If yes, the incapacity start date is the Sunday of the week in which the doctor or other medical professional indicates that the client was unable to work for medical reasons.
       [Sickness: Incapacity start date — Table](/en/procedure/generic/additionalresources/incapacity_start_date_sb.shtml)

If no specific incapacity start date is provided, the incapacity start date is the Sunday of whichever week is the earliest of the following options:

- the week the doctor or other medical professional signed the medical certificate;

- the week the medical consultation.

When the incapacity start date reported by the client is before the date indicated on the medical certificate, a D16 is imposed for the period of incapacity that is not covered by the medical certificate.

If the incapacity start date, signature date or date of medical consultation is not indicated, the medical certificate is not acceptable. The officer must conduct fact-finding with the client to obtain a new medical certificate that indicates the incapacity start date. For more information, the officer refers to Determining if a medical certificate is acceptable .
       [Determining if a medical certificate is acceptable](/en/procedure/task/determining_med_cert_valid.shtml)

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2794.dita) 

**Incapacity end date**

The incapacity end date is the last day the client is incapable of working. The period of incapacity ends the day before the recovery date.

**Recovery date**

The recovery date is the first day the client is capable of working. The medical certificate is used to determine the recovery date.

**Recovery week**

The recovery week is the week up to which sickness benefits are payable.

The officer refers to Determining the recovery week — Instructions to determine the recovery week.
       [Determining the recovery week — Instructions](/en/procedure/generic/determing_the_recovery_week_instruction.shtml)

**Payment of casual sickness benefits**

A client who is receiving regular benefits, including fishing benefits, can declare up to 4 consecutive weeks of casual sickness benefits. If the client declares a fifth consecutive week of casual sickness, the claimant’s report is rejected with the error code C465 . If the client requests additional sickness benefits after declaring 4 consecutive weeks, whether benefits have been paid or not, a conversion to a claim for sickness benefits is required.

A maximum of 8 weeks of casual sickness benefits in total can be paid in a BP. If the client declares a ninth week of casual sickness, the claimant’s report is rejected with the error code C484 . A client who has already received 8 weeks of casual sickness benefits and who is still incapable of working must submit a medical certificate and convert to a claim for sickness benefits.

**Determining the recovery week when casual sickness benefits have been paid**

When a client has already received casual sickness benefits and requests a conversion to a claim for sickness benefits, the client does not need to submit a medical certificate if fewer than 8 weeks of casual sickness benefits have been paid in the BP. The officer determines the recovery week as follows:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0830.dita) 

The officer determines the number of weeks of casual sickness benefits paid in a BP by referring to the Casual sickness weeks field on the Summary or Special Benefits tab in FTS. When determining the recovery week, the officer must use only the casual sickness weeks counter to obtain the number of weeks of casual sickness benefits paid.

For more information on determining the recovery week, the officer refers to Determining the recovery week — Instructions .
       [Determining the recovery week — Instructions](/en/procedure/generic/determing_the_recovery_week_instruction.shtml)

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2795.dita) 

### Levels of Decision

Source topic: `en_EN/task/conv_regsick_eia25/levels_of_decision.dita`

A decision to allow sickness benefits following regular benefits can be adjudicated at Level 1 under the National Policy on Levels of Decision . However, if there are any issues that cannot be adjudicated by Level 1 under the National Policy on Levels of Decision , the file is referred for Level 2 adjudication.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Deferring adjudication of a contentious reason for separation (RFS)

Source topic: `en_EN/task/conv_regsick_eia25/deferring_adjudication_of_a_contentious_079e1a82.dita`

When clients report a contentious RFS, the officer must fact-find and adjudicate the issue, and notify the client of the decision. In some situations, when clients qualify for and request special benefits, fact-finding and adjudication of the contentious RFS can be deferred.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2783.dita) 

### Determining if the client is otherwise available for work

Source topic: `en_EN/task/conv_regsick_eia25/determining_if_the_client_is_otherwise__0a32fe55.dita`

Clients must prove that, had it not been for the illness or injury, they would have been available for work ( otherwise available ) on each day for which sickness benefits are requested. The client’s statement of being otherwise available for work is accepted as sufficient proof unless there is information on file that indicates otherwise. When clients are not otherwise available, a 33 - Incapacity proven but not otherwise available disentitlement (D33) is imposed.
       [otherwise available](/en/procedure/activity/availability.shtml) 

### Incarceration

Source topic: `en_EN/task/conv_regsick_eia25/incarceration.dita`

Clients who are in prison are not considered available for work. This is also the case for clients whose sentences include a stay in a rehabilitation or psychiatric institution. A 12 - Inmate of Penal Institution (D12) disentitlement is imposed. Otherwise, clients must prove that they have received permission to be away from the institution for the purpose of seeking employment before becoming sick. 

### Outside the region or out of Canada

Source topic: `en_EN/task/conv_regsick_eia25/outside_the_region_or_out_of_canada.dita`

Sickness benefits can be paid to a client who undergoes medical treatment that is not readily or immediately available in the client’s area of residence in an accredited hospital outside of the client’s region or out of Canada .
       [out of Canada](/en/procedure/activity/out_canada.shtml) 

### Determining if the client is a teacher

Source topic: `en_EN/task/conv_regsick_eia25/determining_if_the_client_is_a_teacher.dita`

All clients that are employed in teaching are entitled to sickness benefits during the teaching period. No further fact-finding or adjudication is necessary.

However, during the non-teaching period, only clients who are not employed in teaching are entitled to sickness benefits. When sickness benefits are requested, further fact-finding may be necessary to determine if the client’s employment situation has changed or if the client meets one of the conditions specified in EIR 33(2), in which case sickness benefits may be payable. 

### Outstanding disentitlements

Source topic: `en_EN/task/conv_regsick_eia25/outstanding_disentitlements.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies to the conversion. A Level 1 officer can terminate or rescind the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision. If the information on file allows for the disentitlement to be terminated, the disentitlement is terminated on the Friday of the week before the conversion week.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0469.dita) 

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer refers the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer can refer to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Allocation separation monies

Source topic: `en_EN/task/conv_regsick_eia25/allocation_separation_monies.dita`

If clients lose their employment after beginning to receive special benefits and receive separation monies, the officer must allocate the separation monies.

For more information about allocating separation monies, the officer refers to Allocating separation monies and Digest 5.12 — Moneys paid or payable by reason of a lay-off or separation .
       [Allocating separation monies](/en/procedure/task/all_monies_sep.shtml) 
       [Digest 5.12 — Moneys paid or payable by reason of a lay-off or separation](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/moneys-paid-layoff-separation.shtml#a5_12_0) 

### Determining the date of conversion or renewal

Source topic: `en_EN/task/conv_regsick_eia25/determining_the_date_of_conversion_or_renewal.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer can refer to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Return to work (RTW)

Source topic: `en_EN/task/conv_regsick_eia25/return_to_work_rtw.dita`

If there is an RTW on the claim that falls on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer refers the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### Conversion from regular benefits on a continuing claim

Source topic: `en_EN/task/conv_regsick_eia25/conversion_from_regular_benefits_on_a_c_75d1747a.dita`

**Processing claimant’s reports**

Before the officer can input the conversion transactions, the last week of regular benefits must be processed. If claimant’s reports have not yet been processed for the regular benefits period, they must be processed before inputting the conversion. This requires a 2-day input.

**Adjudicating contentious issues**

When converting a continuing claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If there is no existing WI for this issue, the Level 1 officer creates a Claim Review (CR) WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

The Level 1 officer does not reassign the Conversion WI to Level 2 for any reason.

**Communicating the decision**

Communication of the conversion decision is not necessary when the only transaction input is the conversion transaction. When another decision is input at the time of the conversion (disentitlement, disqualification or allocation of earnings), communication of the decision is necessary.

Officers who are responsible for communicating the decision usually send the appropriate letter. Officers must ensure that the letter was sent, and if the letter was not sent, they must create and send the letter of decision in ACS. 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/task/conv_regsick_eia25/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an Action Item (AI), Call Back (CB), Assessment Issue (ASMT) or Reminder (REM) WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### Client referred under EIA 25

Source topic: `en_EN/task/conv_regsick_eia25/client_referred_under_eia_25.dita`

Generally, it is assumed that clients who are receiving special benefits are on a leave of absence and would not be referred to training under EIA 25 as they have a job to return to. However, regardless of an individual’s attachment to the labour force, it is the referring authority’s decision to refer a client. If a referral is made for a client claiming special benefits, as long as the eligible client meets the entitlement conditions for the BT claimed, special benefits can be paid. The claim type must not be changed to regular benefits. However, the claim is processed in MPS.

If there is a 3 - Not available disentitlement (D3) imposed on the claim because the client did not prove availability while attending a course of instruction, and the client is referred to training under EIA 25, this disentitlement is terminated on the day before the training begins.

**Authorization to voluntarily leave employment for referred training**

If the client is referred to training by a designated authority before voluntarily leaving a job, the officer must follow the Adjudicating voluntary leaving (Level 1) — Course of instruction procedure to determine if the voluntary leaving is authorized. The voluntary leaving and the confirmation of the referred training are separate issues.
       [Adjudicating voluntary leaving (Level 1) — Course of instruction](/en/procedure/activity/voluntary_leaving.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2791.dita`

Note:

For claims beginning w/c 2362 or later and w/c 2309 or earlier, if fewer than 600 hours of insurable employment were used to establish the BPC, the client is considered minor attached. In this situation, sickness benefits can be paid only if the RFS is not illness or injury.

Major attached client (N5) can qualify for sickness benefits on an initial claim. However, if the client initially requested regular benefits, the claim cannot be converted to special benefits on a conversion request. 

### Note

Source topic: `en_EN/common_notes/note_c_0021.dita`

Note:

If the client has a violation, there may be increased entrance requirements .
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Note

Source topic: `en_EN/common_notes/note_c_2653.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2792.dita`

Note:

If a client is not entitled to sickness benefits, the officer must determine if the client can establish a new claim. 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_2793.dita`

Note:

The temporary measure for medical certificates ended September 25, 2021. For all BPs with a BPC or renewal week of September 26, 2021 (w/c 2310) or later, the officer follows normal procedures.

For BPs with a BPC or renewal week between March 15, 2020 (w/c 2230) and September 19, 2021 (w/c 2309), a client is not required to provide a medical certificate to receive sickness benefits. For more details, the officer refers to the previous version of this task by selecting the link at the bottom of the page. 

### Example

Source topic: `en_EN/common_notes/note_c_2794.dita`

Example:

- BPC is in w/c 2407

- D10 imposed from BPC — regular benefits not payable

- sickness reported from w/c 2411

- medical certificate received, signed by the doctor in w/c 2414

- no start date of the incapacity is indicated

- recovery week is w/c 2418

Because the medical certificate does not indicate the incapacity start date:

- a D16 is imposed from w/c 2411 to w/c 2413 (the week before the date of the doctor’s signature);

- Sickness benefits are allowed starting from the Sunday of the week the doctor signed the medical certificate (w/c 2414 to w/c 2418). 

### Callout

Source topic: `en_EN/common_notes/note_c_0830.dita`

[conversion week] + [8 weeks] – [weeks of paid casual sickness] = [recovery week]. 

### Example 1

Source topic: `en_EN/common_notes/note_c_2795.dita`

Example 1:

Three consecutive weeks of casual sickness benefits have been paid in the BP.

- w/c 2386 (March 12, 2023) = BPC;

- w/c 2387 to w/c 2393 (March 19 to May 6, 2023) = 7 weeks of regular benefits;

- w/c 2394-1 — the client becomes ill;

- w/c 2394 to w/c 2396 (May 7 to 27, 2023) = 3 weeks of casual sickness benefits paid on a claim for regular benefits (CT 2);

- w/c 2397 (May 28, 2023) conversion to sickness benefits requested.

The officer considers the 3 weeks of casual sickness benefits paid in the BP when determining the recovery week.

Recovery week:

[conversion week (w/c 2397)] + [8 weeks (w/c 2405)] – [3 weeks of casual sickness paid in the BP] = [recovery week w/c 2402 (July 8, 2023)]

If all of the relevant conversion conditions are met, the officer establishes the recovery week as w/c 2402.

Example 2:

There are 2 separate periods of casual sickness benefits totaling 6 weeks paid in the BP:

- w/c 2386 (March 12, 2023) = BPC;

- w/c 2387 to w/c 2393 (March 19 to May 6, 2023) = 7 weeks of regular benefits;

- w/c 2394-1 — the client becomes ill;

- w/c 2394 to w/c 2395 (May 7 to 20, 2023) = 2 weeks of casual sickness benefits paid on a claim for regular benefits (CT 2);

- w/c 2396 to w/c 2405 (May 21 to July 29, 2023) = 10 weeks of regular benefits;

- w/c 2406-1 — the client becomes ill again;

- w/c 2406 to w/c 2409 (July 30 to August 26, 2023) = 4 weeks of casual sickness benefits paid on a claim for regular benefits (CT 2);

- A total of 6 weeks of casual sickness has been paid in the BP;

- The client has not recovered and is requesting sickness benefits after w/c 2409;

- w/c 2410 (August 27, 2023) = conversion to sickness benefits required as 4 consecutive weeks of casual sickness have been paid and the client has not recovered.

The officer considers all 6 weeks of casual sickness benefits paid in the BP when determining the recovery week.

Recovery week:

[conversion week (w/c 2410)] + [8 weeks (w/c 2418)] – [6 weeks of casual sickness paid in the BP] = [recovery week w/c 2412 (September 16, 2023)]

If all of the relevant conversion conditions are met, the officer establishes the recovery week as w/c 2412.

Example 3:

The maximum allowable 8 weeks of casual sickness benefits have been paid in the BP:

- The client must submit a medical certificate. The recovery week is based on the medical certificate information. 

### Note

Source topic: `en_EN/common_notes/note_c_2783.dita`

Note:

Deferral of fact-finding and adjudication for a contentious RFS can be considered even if a D16 is imposed. 

### Note

Source topic: `en_EN/common_notes/note_c_0469.dita`

Note:

A client is not required to demonstrate good cause for delay when submitting a medical certificate. The Level 1 officer can modify or rescind a disentitlement related to a missing medical certificate for special benefits, regardless of the length of delay, provided all other conditions are met for the requested benefit type (BT). 

## Regional considerations

Source topic: `en_EN/task/conv_regsick_eia25/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/conv_regsick_eia25/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/conv_regsick_eia25/in_nws.dita`

- Did the client apply for a renewal requesting a conversion of benefits??

- If yes, review processing activities for the web application and take notes if necessary:

- What issues did ACP detect?

- Does it indicate why the claim tripped down?

- Has the client worked since the last week paid?

- Is there a ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies, motor vehicle accident compensation, workers’ compensation benefits (WCB) or wage loss insurance (WLI) payments to consider or allocate? o Is there an Adjudication Issues (ADJ) WI?

- Is there an ADJ WI?

- If yes, for what issue?

- Is the client otherwise available for work?

- Is there information about referred training on file?

- Is there a completed electronic questionnaire?

- Is there any information on file that indicates the client may not be otherwise available for work?

- Has a medical certificate been uploaded?

- Are there documents related to the issue? 

### In FTS:

Source topic: `en_EN/task/conv_regsick_eia25/in_fts.dita`

- What is the number of insurable hours on file?

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Have any weeks of casual sickness benefits been paid to the client?

- Has the last renewable week (LRW) been reached?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Is there an RTW on the claim?

- Are there any pending claimant’s report or claimant’s report to be processed before the conversion?

- Is there a registration number?

- Is there information about referred training on file?

- Has referred training information been input on the Project tab for the training period (codes 9, 35, 53, 95, 97 and 98)? 

### In RCM:

Source topic: `en_EN/task/conv_regsick_eia25/in_rcm.dita`

- Has an ROE been submitted?

- What is the RFS on the last ROE before the conversion?

- Are there earnings, separation monies, motor vehicle accident compensation, WCB or WLI payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/conv_regsick_eia25/in_imaging.dita`

- Is there a medical certificate on file?

- What is the recovery date?

- What is the incapacity start date?

- Is there any referred training information from the client, the province or territory, or another designated authority?

- Is there any other documentation which may impact the conversion claim? 

## Step by step

Source topic: `en_EN/task/conv_regsick_eia25/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/conv_regsick_eia25/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/conv_regsick_eia25/reviewing_the_file_level_1.dita`

- In NWS, determine if there is a SIR Validation (SIR) WI:

- If yes, go to step 2.

- If no, go to step 4.

- Move the Claim Assessment (CA) WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for the SIR WI to be completed.”

- Bring forward date: Enter today’s date + 10 business days.

- When the CA WI moves to the current workload, determine if the SIR WI has been completed:

- If no, repeat step 2.

- If yes, go to step 4.

- In FTS, determine if a registration number related to the conversion is on file:

- If yes, go to step 5.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Go to step 5.

- In FTS, determine if the maximum combination of regular and special benefits has been paid:

- If yes, go to Maximum combination of regular and special benefits paid .
               [Maximum combination of regular and special benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regsick_eia25#maxcomb)

- If no, determine if the maximum number of weeks of sickness benefits has been paid:

- If no, go to step 6.

- If yes, go to Maximum weeks of sickness benefits paid .
                   [Maximum weeks of sickness benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regsick_eia25#maxben)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- In FTS, determine if there is a pending electronic claimant’s report on the E-Report tab for the period before the conversion:

- If there is no pending electronic claimant’s report, go to step 7.

- If there is a pending electronic claimant’s report, refer to Actioning a pending claimant’s report and go to step 7.
               [Actioning a pending claimant’s report](/en/procedure/task/pending_cr.shtml)

- Determine if there are any rejected electronic claimant’s reports on the Pending/Reject tab for the period before the conversion:

- If no, go to step 8.

- If yes, re-input the claimant’s reports. Refer to Actioning a rejected claimant’s report and go to step 8.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml)

- Determine if the client reports having received monies and whether they have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings and go to step 9.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 9.

- If no monies were received, go to step 9.

- In NWS and in FTS, determine if one of the following conditions to extend the BP is met:

- The client was incarcerated, and has since been tried and not found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If one of the conditions is met, refer to Extension of the benefit period and then go to step 10.
                   [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions is met, go to step 10.

- Determine if the LRW has been reached:

- If no, go to step 11.

- If yes, go to Last renewable week (LRW) reached .
               [Last renewable week (LRW) reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regsick_eia25#lwrreached)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2784.dita)

- In FTS, on the Rate/Duration tab, determine if the client is minor attached:

- If the client has fewer than 600 hours and the Major Attached box is not checked, go to step 12.

- If the client has more than 600 hours or the Major Attached box is checked, go to step 13.

- If the BPC is between w/c 2310 to w/c 2361 and the Major Attached box is checked, go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2796.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2758.dita)

- In NWS, determine if the most recent RFS is illness, injury or quarantine:

- If no, go to step 13.

- If yes, go to Minor attached .
               [Minor attached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regsick_eia25#minorattached)

- Determine if the training information is on file:

- If yes, go to step 14.

- If no, refer to Confirming referred training: Conversion from regular to special benefits — Continuing claim .
               [Confirming referred training: Conversion from regular to special benefits — Continuing claim](/en/procedure/task/training_cc_rsb.shtml)

- Determine if a D3 has been imposed as a result of the client not being available while attending a course of instruction:

- If no , go to step 15.

- If yes, note that the D3 must be terminated on the day before the referred training begins and go to step 15.

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 16.

- If no, go to step 18.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, go to step 17.

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 18.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine the claim type:

- If it is a conversion on a continuing claim, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 18.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If it is a conversion on a renewal claim, In NWS, create an ADJ WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next Available User .

- Issue(s): Select Availability .

- Details: Type “Outstanding D15 for a missed client information session, Level 2 review required.”

- Select Save .

- Go to step 18.

- If no, go to step 20.

- Determine if there are any other outstanding disentitlements on file:

- If yes and the conversion is on a continuing claim, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 19.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC : Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Details: Type “Outstanding [type of disentitlement] disentitlement.”

- Select Save .

- Refer to the appropriate procedure and go to step 19.

- Determine if the conditions are met to terminate or rescind the disentitlement at Level 1 according to the National Policy on Levels of Decision are met:

- If yes, terminate or rescind the disentitlement and go to step 20.

- If no, reassign the WI to Level 2 and go to step 20.

- Determine if there are outstanding issues that require adjudication that do not have a related WI:

- If yes and the conversion is on a continuing claim, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 21.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC : Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Details: Type “Outstanding [type of disentitlement] disentitlement.”

- Select Save .

- Refer to the appropriate procedure and go to step 21.

- If no, go to step 22.

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If yes, complete the steps from the appropriate procedure and go to step 22.

- If no, reassign the WI to Level 2 and go to step 22..

- Determine if the client would have been otherwise available for work if not for the sickness or injury. If necessary, refer to Adjudicating otherwise available issues — Continuing claim :

- If yes, go to step 23.

- If no, in NWS, create a CR WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Next available user .

- Issue(s): Select Availability .

- Reason: Select Related work item .

- Details: Type “Not within Level 1 authority.”

- Select Save .

- Go to step 23.

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine the first week that the client declared being sick:

- If the client first declared being sick in the conversion week, go to step 25.

- If the client first declared being sick before the conversion week, go to step 28.

- If the client first declared being sick after the conversion week, the effective week of the conversion is the first week the client is requesting sickness benefits. Ensure claimant’s reports for the weeks before the conversion week are processed before converting the claim. Go to step 28.

- Determine if the client’s request for sickness benefits starts the Sunday or Monday of the conversion week:

- If the client’s request for sickness benefits does not start the Sunday or Monday of the conversion week, a partial week of sickness benefits may be payable. Go to step 26.

- If the client’s request for sickness benefits starts the Sunday or Monday of the conversion week, go to step 28.

- In FTS, determine if the client is entitled to regular benefits for the partial week:

- If the client is not entitled to regular benefits for the partial week because entitlement to regular benefits has been exhausted, go to step 27.

- If the client is not entitled to regular benefits for the partial week due to a D10, D11, D42, D43, D44 or D46, go to step 28.

- If the client is entitled to regular benefits for the partial week, that week is paid as a week of regular benefits and the conversion to sickness benefits occurs the next week. Go to step 28.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2786.dita)

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “D18 imposed. Special benefits — client is not entitled to regular benefits.”

- Details: Type “The client is requesting a partial week of sickness benefits and has received the maximum amount of regular benefits. The client is not entitled to sickness benefits or regular benefits from [date of the conversion week] to [day before the client declared being sick]. D18 imposed.”

- Determine if there is an acceptable medical certificate on file:

- If yes, go to step 36.

- If no, determine if a medical certificate must be submitted — Renewal and continuing claims :

- If yes, go to step 29.

- If no, go to step 40.

               [determine if a medical certificate must be submitted — Renewal and continuing claims](/en/procedure/task/determining_med_cert_req.shtml) 

#### Fact-finding to obtain a medical certificate

Source topic: `en_EN/task/conv_regsick_eia25/fact-finding_to_obtain_a_medical_certificate_level_1.dita`

- Fact-find with the client to obtain the medical certificate.

- Determine if the client was contacted during fact-finding or if the client responded to the N-10-00-00 letter:

- If the client was contacted, go to step 31.

- If the client was not contacted, did not respond to the N-10-00-00 letter, or there is information missing, go to step 35.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Conversion .

- Comments: Type “Conversation with the client — medical certificate.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client indicated a medical certificate would be submitted:

- If yes, go to step 33.

- If no, go to step 35.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact-Finding with client .

- Comments: Type “Awaiting medical certificate.”

- Bring forward date: Enter [10 days from the day the client was asked to submit a medical certificate].

- When the WI moves to the current workload, determine if an acceptable medical certificate has been submitted:

- If no, go to step 35.

- If yes, go to step 36.

- In NWS, create a ROD as follows:

- Comments: Type “D16 imposed. Medical certificate not submitted.”

- Details: Enter one of the following:

- If a D18 has been imposed in the week of the conversion, type “An acceptable medical certificate has not been submitted. Indefinite D16 imposed from [first day in the conversion week that the client is declared sick].”

- If a D18 has not been imposed in the week of the conversion, type “An acceptable medical certificate has not been submitted. Indefinite D16 imposed from [first day in the conversion week].”

- Go to step 40.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2797.dita)

- Determine if an incapacity start date is required (refer to Sickness: Incapacity start date — Table ):

- If yes, go to step 37.

- If no, go to step 40.

- Determine if the incapacity start date is indicated on the medical certificate:

- If yes, for the incapacity start date, use the Sunday of the same week as the date indicated on the medical certificate.

- If no, for the incapacity start date, use the Sunday of the week the doctor or other medical professional signed the medical certificate, or the week of the medical consultation, whichever is earlier.

- Determine if there is a gap between the first day of sickness declared by the client and the proven incapacity start date:

- If yes, go to step 39.

- If no, go to step 40.

- In NWS, create a ROD as follows:

- Comments: Type “D16 imposed. Incapacity start date not proven.”

- Details: Type “Incapacity start date reported by the client does not match the medical certificate. D16 imposed from [first day of the conversion week that the client reported being sick] to [the Friday before the proven incapacity start date].”

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2798.dita) 

#### Determining the recovery week

Source topic: `en_EN/task/conv_regsick_eia25/determining_the_recovery_week_level_1.dita`

- To determine the recovery week, refer to Determining the recovery week — Instructions week and then go to step 41. 

#### Converting the claim to sickness benefits

Source topic: `en_EN/task/conv_regsick_eia25/converting_the_claim_to_sickness_benefits_level_1.dita`

- Determine if the referred training information is displayed on the Project tab:

- If the referred training information is displayed on the Project tab, go to step 42.

- If the referred training information is not displayed on the Project tab, go to step 44.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 36 - Special benefits on Fishing claims or other complex claim conditions .

- Remarks line 1: Type “EIA 25 — special benefits.”

- Remarks line 2: Type “[REN WK] [XXXX], CT [3 or 9], LST DY WK [XXXX], REC WK [XXXX].”

- Remarks line 3: If necessary, type “[NO-CR], [claimant’s report information], [manual action rescind information], [any disentitlement information].”

- Remarks line 4: Enter the appropriate information.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 46.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 36 - Special benefits on Fishing claims or other complex claim conditions .

- Remarks line 1: Type “EIA 25 — special benefits.”

- Remarks line 2: Type “REN WK [XXXX], CT [3 or 9], LST DY WK [XXXX], REC WK [XXXX].”

- Remarks line 3: If necessary, type “NO-CR, [claimant’s report information], [manual action rescind information], [any disentitlement information].”

- Remarks line 4: Type “T171 — STRT-WK/DY [the course start w/c], END-WK-DY [the course end w/c], PROJ-HRRC [the Responsibility Centre code or institution code, if applicable], PROJ-NO [the 10-digit agreement number; use preceding zeros if the number is less than 10 digits], TRAIN-ID [the training ID code], BREAK START/END WK [the w/c code, of any break weeks].”

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction to transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update . 

#### Communicating decisions

Source topic: `en_EN/task/conv_regsick_eia25/communicating_decisions_level_1.dita`

- Determine if sickness benefits have been allowed for 8 weeks or less:

- If yes, go to step 48.

- If no, go to step 49.

- Determine what must be communicated to the client:

- If an allocation of earnings and any other decisions must be communicated:

- Advise the client of the revival week, the number of weeks payable, the allocation and any other decisions. Go to step 50.

- If an allocation of earnings must be communicated:

- Advise the client of the revival week, the number of weeks payable and the allocation. Go to step 50.

- If no other decision must be communicated:

- Advise the client of the revival week and the number of weeks payable. Go to step 50.

- Determine what must be communicated to the client:

- If an allocation of earnings and any other decisions must be communicated:

- Advise the client of the revival week, the allocation and any other decisions. Go to step 50.

- If an allocation of earnings must be communicated:

- Advise the client of the revival week and the allocation. Go to step 50.

- If no other decision must be communicated:

- No letter is required. Go to step 51.

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- If an antedate has been denied, select Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- If the client is payable weeks of sickness benefits (no indefinite D16), select Special benefits approved (3046) .

- If a D16 is applicable (definite or indefinite), select Special benefits denied (3065) .

- If there is an allocation, select Allocation of Earnings (2516) .

- If monies allocated prevent the payment of sickness benefits, select Allocated monies that prevent payment of sickness benefits (3090) .

- If the waiting period (WP) must be served, select Waiting period messages (2445) .

- Message for Sickness claim - Is client receiving any other payment? (WLI/PSL/WCB/MVA) (3092) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In ACS, determine if there is a saved D-01-00-00 letter:

- If yes, go to step 52.

- If no, go to step 53.

- Determine if all decisions in the D-01-00-00 letter are included in the N-00-00-00 letter:

- If yes, delete the D-01-00-00 letter.

- If no, modify the D-01-00-00 letter with only the decisions that are left to be communicated.

- In NWS, determine if the file requires Level 2 adjudication:

- If yes, create a client Note and type “Send the N-00-00-00 letter.”

- If no, send the N-00-00-00 letter and any other letters with decisions that must be communicated.

- In NWS, determine if an AW application was filed to convert the claim:

- If yes, go step 55.

- If no, go to step 57.

- Determine if there are fewer than 4 weeks payable remaining on the BP:

- If yes, go to step 56.

- If no, go to step 57.

- Determine if the conversion was finalized within 28 days of the conversion application:

- If yes, go to step 57.

- If no, in NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Subsequent claim not automated.”

- Due date: Select [LRW + 3 weeks].

- Details: Type “Subsequent claim to be established.”

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Go to step 57.

- In NWS, complete the Conversion WI. 

#### Maximum combination of regular and special benefits paid

Source topic: `en_EN/task/conv_regsick_eia25/maximum_combination_of_regular_and_spec_917028fd_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D22 imposed — maximum combination of benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC. D22 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as [number of hours] hours were accumulated after the BPC and the client needed [number of hours] hours to qualify. D22 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction and impose the D22 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 22 - Illness (maximum sickness / special benefits paid) .

- Start date: Select the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Sickness benefits denied: D2/D16/D22/D33/Free text (3066) .

- Select D22 - Max sickness paid / max sickness paid but approved regular or maternity benefits/max combination of special benefits reached (3069) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Maximum weeks of sickness benefits paid

Source topic: `en_EN/task/conv_regsick_eia25/maximum_weeks_of_sickness_benefits_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D22 imposed — sickness benefits exhausted.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as maximum sickness benefits have been paid. The client does not qualify for a new claim as no hours were accumulated after the BPC. D22 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as maximum sickness benefits have been paid. The client does not qualify for a new claim as [number of hours] hours were accumulated after the BPC and the client needed [number of hours] hours to qualify. D22 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction to impose the D22 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular benefits .

- Action: Select Add .

- Disentitlement: Select 22 - Illness (maximum sickness / special benefits paid) .

- Start date: Select the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Sickness benefits denied: D2/D16/D22/D33/Free text (3066) .

- Select D22 - Max sickness paid / max sickness paid but approved regular or maternity benefits/max combination of special benefits reached (3069) .

- Select D22 - Max weeks of sickness benefits already paid .

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- Sickness maximum of 15 or 26 weeks (12545)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Client is minor attached

Source topic: `en_EN/task/conv_regsick_eia25/client_is_minor_attached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D2 imposed. Minor attached; RFS — illness.”

- Details: Type the appropriate option.

- If the client has not worked since the BPC , type “No conversion is possible as the client is minor attached. The client does not qualify for a new claim as no hours were accumulated after the BPC. D2 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client is minor attached. The client does not qualify for a new claim as [number of hours] hours were accumulated after the BPC and the client needed [number of hours] hours to qualify. D2 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction to impose the 2 - Minor Attached, reason for separation illness disentitlement (D2) as follows:

- Registration number: Select the appropriate registration number.

- Revival/Renewal: Select the appropriate Sunday.

- Claim type: Select 9 - Sickness - minor attached .

- Select the Special Benefits (M106) link and enter the following information under Sickness:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

- Action: Select Add .

- Disentitlement: Select 2 - Minor Attached, reason for separation illness .

- Start date: Select the Monday of the renewal week.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Sickness benefits denied: D2/D16/D22/D33/Free text (3066) .

- Select D2 – Not enough hours/Not enough fishing earnings (3067) .

- Select D2 - Minor attached - Not enough insurable hours .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select Definite disentitlement dates and enter the dates.

- Enter the Number of insurable employment hours accumulated (1366) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Last renewable week (LRW) reached

Source topic: `en_EN/task/conv_regsick_eia25/last_renewable_week_lrw_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “LRW reached — sickness benefits requested.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as no hours were accumulated after the BPC.”

- If the client has worked since the BPC , type “No conversion is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as [number of hours] hours were accumulated after the BPC and the client needed [number of hours] hours to qualify.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612):
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2799.dita)

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and clear the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Note

Source topic: `en_EN/common_notes/note_c_2784.dita`

Note:

If all weeks of entitlement to regular benefits have been paid and the claim is on the Dormant tab with the message “special benefits potentially payable,” the claim may be renewable for special benefits. 

#### Note

Source topic: `en_EN/common_notes/note_c_2796.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, 420 hours of insurable employment is required to establish a claim for regular or special benefits regardless of the conversion date. If the client has 420 or more insurable hours, select the major attached option. 

#### Note

Source topic: `en_EN/common_notes/note_c_2758.dita`

Note:

The system codes claims with a BPC from September 27, 2020 to September 19, 2021 that received a credit of 300 insurable hours as major attached. This means that clients transitioning from the EI Emergency Response Benefit (EI ERB) who have fewer than 600 hours may also qualify for special benefits. 

#### Note

Source topic: `en_EN/common_notes/note_c_2786.dita`

Note:

Before inputting the conversion transactions, the last week of regular benefits must be processed. If claimant’s reports have not been processed for the regular benefits period, they must be processed before inputting the conversion. 

#### Note

Source topic: `en_EN/common_notes/note_c_2797.dita`

Note:

When finalizing the conversion, impose an indefinite D16 and sends an N-00-00-00 indicating the period that the client is not entitled to benefits. 

#### Note

Source topic: `en_EN/common_notes/note_c_2798.dita`

Note:

When finalizing the conversion, impose an indefinite D16 and send a N-00-00-00 letter indicating the period that the client is not entitled to sickness benefits. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2799.dita`

“We cannot reactivate your claim for Employment Insurance benefits starting [renewal week - Sunday’s date] . Please note that we are required to advise you of all decisions made on your claim.

No sickness benefits are payable to you on this claim because the last renewable week has been reached on this benefit period.

To receive sickness benefits, you must work the required minimum number of insurable employment hours. If you want to receive sickness benefits in the future, you will have to file a new claim.” 

## Policy reference

Source topic: `en_EN/task/conv_regsick_eia25/policy_reference.dita`

- EIA 12(6)
         [EIA 12(6)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 21(1)
         [EIA 21(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-21.html)

- National Policy on Proof of Incapacity
         [National Policy on Proof of Incapacity](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/proof_of_incapacity_policy.shtml)

- National Policy on Casual Sickness
         [National Policy on Casual Sickness](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/casual_sickness_pollicy.shtml)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
