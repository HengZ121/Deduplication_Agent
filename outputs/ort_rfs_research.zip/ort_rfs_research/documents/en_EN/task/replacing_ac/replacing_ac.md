# Issuing an access code

Source map: `en_EN/task/replacing_ac/replacing_ac.ditamap`

## Summary

Source topic: `en_EN/task/replacing_ac/summary.dita`

Summary: When a client reports having lost or forgotten an access code, it is possible to reissue the original access code by mail or to issue a temporary access code. 

## What you need to know

Source topic: `en_EN/task/replacing_ac/what_you_need_to_know.dita`

### Function of the access code

Source topic: `en_EN/task/replacing_ac/function_of_the_access_code.dita`

An access code is a 4-digit number issued when BPS processes an Initial Intake (M149) or a Renewal/Revised (M106) transaction. The system generates the access code automatically on the first benefit statement mailed to the client. Only 2 of the 4 numbers show on the enquiry screens in FTS. It can take up to a week for clients to receive their access code depending on mail delivery.

The SIN and access code allow clients to:

- obtain personal information about their claim for benefits through any of the following channels:

- MSCA-EI

- the Telephone Information Service (TIS)

- a Service Canada Centre (SCC)

- call centres

- complete electronic claimant’s reports through TRS or IRS.

The access code does not expire as long as the client record exists. After 7 years of inactivity, client records are removed from the database and the access code expires.

     [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4492.dita) 

### Replacing an access code

Source topic: `en_EN/task/replacing_ac/replacing_an_access_code.dita`

Clients can replace their own access code using TIS. When clients lose or forget their access code, they are unable to access TIS or complete electronic claimant’s reports. However, it is possible for a Service Canada officer to reissue the original access code or issue a temporary one. Replacing the access code with either the original code or a temporary code automatically restores the client’s access to these services. 

### Detailed security check

Source topic: `en_EN/task/replacing_ac/detailed_security_check.dita`

A detailed security check must be conducted with the client before providing information or issuing an access code. The officer does not accept requests to reissue an access code from a third party, unless it is from the designated representative. In the case of a representative, ensure that there is no electronic document indicating that the client has recovered and no longer requires the services of the representative. Representatives are identified in FTS with the indicator “REP”. For additional information, refer to Appointment of representative — Limited physical or mental capacity .
       [Appointment of representative — Limited physical or mental capacity](/en/procedure/activity/app_rep.shtml) 

### Validating the client’s address

Source topic: `en_EN/task/replacing_ac/validating_the_clients_address.dita`

When a client is successfully identified, the officer validates the address on file to ensure that Service Canada has the most recent information. If the address is incorrect, the officer changes it. 

### Rescinding a security code 6 imposed by Integrity

Source topic: `en_EN/task/replacing_ac/rescinding_a_security_code_6_imposed_by_a517edff.dita`

Due to attempts by unknown sources to identify EI access codes associated with some client’s files, a security code 6 – Claimant does not want to use the service may have been imposed by Integrity. This code prevents the client from completing claimant’s reports. When this code is input, Integrity adds an SROC in NWS that states:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4493.dita) 

When speaking to a client impacted by this situation, the officer conducts a detailed security check to authenticate the client. If the authentication is successful, the officer rescinds the security code, assigns a temporary access code and explains to the client how to change it. If the client fails the detailed security check, the officer sends a CB WI to Integrity.

For more information, the officer refers to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Reissuing the access code

Source topic: `en_EN/task/replacing_ac/reissuing_the_access_code.dita`

There are 2 options for issuing access codes.

**Reissuing the original access code**

The original code is sent to the client by mail the same day or the next business day, if the request for the code is received on a Friday. Therefore, it can take up to a week for clients to receive their access code, depending on mail delivery.

Exceptions:

The access code cannot be reissued in the following circumstances:

- claim is contentious or BPNE (claim status [CS] 01)

- claim is dormant — moved to MN09 (CS 05 or 06)

- client is deceased (CS 07)

- claim is in purge and recreate (P/R) (CS 99)

- temporary access code is already assigned (TIS security code 50, 51, 60 or 61)

- claim is transferred (CS 04 to 09)

- claim is in MPS — claim information on the Manual Pay tab in FTS

- a new SIN

In the above cases, a temporary access code must be issued.

**Issuing a temporary access code**

When clients have an electronic claimant’s report that is past due or imminent (within the next 5 business days), or when they receive a new SIN, the officer issues a temporary code.

Clients must change the temporary code they have received to a 4-digit number of their choice using TIS. The officer confirms with clients that they have access to a touch-tone telephone, since they need it to access TIS. To make the change, they are instructed to enter the temporary code and then to input their new code. TIS then confirms that the change is successful.

If clients receive a new SIN, they cannot use the access code linked to the old SIN and the officer cannot reissue it. When an IPOC officer has updated the client’s electronic file with the new SIN, the officer contacts the client to issue a temporary access code. 

### Warning

Source topic: `en_EN/common_notes/note_c_4492.dita`

Warning:

If fraudulent activity is suspected on an EI or EI Emergency Response Benefit (EI ERB) claim, the officer does not issue an access code. For more information, the officer refers to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml)

     [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Callout

Source topic: `en_EN/common_notes/note_c_4493.dita`

For security reasons, the client cannot submit a report electronically. Please verify the claimant’s identity by using the detailed security check and proceed with the completion of the client’s report.

If claimant’s identity cannot be confirmed, do not input any transactions. Accept the client information related to the request or enquiry and forward the information to Regional Integrity Operations using a Call Back Work Item in NWS.” 

## Regional considerations

Source topic: `en_EN/task/replacing_ac/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/replacing_ac/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/replacing_ac/in_nws.dita`

- What personal information did the client indicate in the Personal Information section of the application?

- Is there an SROC stating that for security reasons, the client cannot submit a report electronically? 

### In FTS:

Source topic: `en_EN/task/replacing_ac/in_fts.dita`

- Is this a new claim that has not been registered?

- Is the client’s personal information available?

- Is there a claimant’s report due within the next 5 business days?

- Is there a security code 6 – Claimant does not want to use the service on the Electronic Security screen? 

## Step by step

Source topic: `en_EN/task/replacing_ac/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/replacing_ac/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/replacing_ac/reviewing_the_file_level_1.dita`

- Determine if the client is impacted by a security code 6 – Claimant does not want to use the service imposed by Integrity:

- If yes, go to Rescinding a security code 6 imposed by Integrity .
               [Rescinding a security code 6 imposed by Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/replacing_ac#level1_item_3)

- If no, go to step 2.

- Determine if the client must be contacted by telephone or if the call is already in progress with the client:

- If the client must be contacted by telephone, go to step 3.

- If the call is already in progress with the client, go to step 4.

- Contact the client by referring to the appropriate fact-finding task. Determine if the client was reached during fact-finding:

- If the client was reached, go to step 5.

- If the client was not reached or did not reply to the N-10-00-00 letter, complete the WI. No further action is required.

- In FTS, determine if the Initial Intake (M149) transaction has recently been transmitted:

- If yes, explain that the access code may be delayed in the mail.

- If no, go to step 5. 

#### Conducting a detailed security check

Source topic: `en_EN/task/replacing_ac/conducting_a_detailed_security_check_level_1.dita`

- Conduct a detailed security check with the client:

- If the client fails the detailed security check, go to Detailed security check — Failed .
               [Detailed security check — Failed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/replacing_ac#dscf)

- If the client passes the detailed security check, go to step 6.

           [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4494.dita) 

#### Detailed security check — Passed

Source topic: `en_EN/task/replacing_ac/detailed_security_check__passed_level_1.dita`

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 7.

- If the client’s address is different than the one on file, refer to Change of address and then go to step 7.
               [Change of address](/en/procedure/activity/change_address.shtml)

- Determine if the next claimant’s report is due within the next 5 business days:

- If no, reissue the original access code. Go to step 8.

- If yes, issue a temporary access code. Go to step 9.

- In FTS, reissue the original access code as follows:

- Under the Transaction menu, select Electronic Security (MD60, M101-15) .

- Select Reissue .

- Provide clients with the first 2 digits of the access code as shown on this screen. Inform them that the access code will be issued in the next pay run and will appear on the next benefit statement.

- Select Update .

- Select OK .

- Go to step 11.

- Determine if the client has access to a touch-tone telephone:

- If no, go to step 10.

- If yes, in FTS, to issue a temporary access code, do the following:

- Under the Transaction menu, select Electronic Security (MD60, M101-15) .

- Select Issue Temporary .

- Provide the client with the temporary access code (it is displayed until you update it).

- Select Update .

- Slect OK .

- Tell the client to contact TIS, select option 1, enter SIN, then select option 3.

- Remind the client to choose a code that is easy to remember.

- Go to step 11.

- In FTS, issue a temporary access code and make it permanent as follows:

- Under the Transaction menu, select Electronic Security (MD60, M101-15) .

- Select Issue Temporary .

- Provide the client with the temporary access code (it is displayed until you update it).

- Select Update .

- Select Rescind to remove the TIS security code and make the temporary code a permanent one.

- Determine if there is a WI for this task:

- If yes, complete the WI.

- If no, return to originating task. 

#### Detailed security check — Failed

Source topic: `en_EN/task/replacing_ac/detailed_security_check__failed_level_1.dita`

- Do not provide any claim information. Determine if the client can go to a SCC in person:

- If yes, provide clients with the address of the closest SCC and tell them to present their identification. Go to step 2.

- If no, tell clients to telephone 1-800-206-7218 for service in English and 1‑800‑808‑6352 for service in French when they have the information. Go to step 2.

- In NWS, create an SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Access code request — security check failed.”

- Details: Type the appropriate option:

- “Client requested access code to be replaced, but failed detailed security check — client is unable to attend a SCC and has been told to contact us with information.”

- “Client requested access code to be replaced, but failed detailed security check — client directed to present identification at SCC (insert SCC address).”

- Determine if there is a WI for this task:

- If yes, complete the WI.

- If no, return to originating task. 

#### Rescinding a security code 6 imposed by Integrity

Source topic: `en_EN/task/replacing_ac/rescinding_a_security_code_6_imposed_by_a517edff_level_1.dita`

- While on the telephone with the client, conduct a detailed security check .

- After conducting the detailed security check, do one of the following:

- If the client failed the detailed security check, go to step 3.

- If the client passed the detailed security check, go to step 5.

- Do not provide any claim information. Advise client that another officer will contact them to verify their identity.

- In NWS, create a CB WI for Integrity as follows:

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client resides based on the following table:

```text
| Region | Assign to Level | NWS path |

| Atlantic | Integrity - ATL | 4 - National Integrity (ISB) ⇒ Integrity - ATL |

| Quebec | I - Distribution Centre - QC | 4 - National Integrity (ISB) ⇒ Integrity - QC ⇒ I - A - Regional Operations - QC ⇒ I - Distribution Centre - QC |

| Ontario | Integrity - ON | 4 - National Integrity (ISB) ⇒ Integrity - ON |

| Western Canada and Territories | I - Distribution Centre - WT | 4 - National Integrity (ISB) ⇒ Integrity - WT ⇒ I - A - Regional Operations - WT ⇒ I - Distribution Centre - WT |
```

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Integrity .

- Comments: Type “Security code 6 on file. Identity not validated.”

- Details: Explain why the issue is being referred to Integrity.

- No further action is required.

- In FTS, determine if the Security code 6 – Claimant does not want to use the service is on file:

- If yes, go to step 6.

- If no, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4495.dita)

- Rescind the security code 6 as follows:

- Under the Transaction menu, select Electronic Security (MD60, M101-15) .

- Telemessage: Select Rescind .

- Select Update .

- Issue a temporary access code as follows:

- Under the Transaction menu, select Electronic Security (MD60, M101-15) .

- Security Access Code: Select Issue Temporary .

- Provide the client with the temporary access code (it is displayed until you update it).

- Select Update .

- Select OK .

- Advise the client to contact TIS to select a new access code. 

#### Warning

Source topic: `en_EN/common_notes/note_c_4494.dita`

Warning:

If fraudulent activity is suspected on an EI or EI ERB claim, the officer does not issue an access code. For more information, refer to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml)

     [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_4495.dita`

Note:

The Security code 6 – Claimant does not want to use the service is visible in the tombstone section of FTS and also on the Electronic Security (MD60, M101-15) screen. 

### Level 2

Source topic: `en_EN/task/replacing_ac/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/replacing_ac/reviewing_the_file_level_2.dita`

- Determine if the client is impacted by a security code 6 - Claimant does not want to use the service imposed by Integrity:

- If yes, go to Rescinding a security code 6 imposed by Integrity .
               [Rescinding a security code 6 imposed by Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/replacing_ac#level2_item_3)

- If no, go to step 2.

- Determine if the client must be contacted by telephone or if the call is already in progress with the client:

- If the client must be contacted by telephone, go to step 3.

- If the call is already in progress with the client, go to step 4.

- Contact the client by referring to the appropriate fact-finding task. Determine if the client was reached during fact-finding:

- If the client was reached, go to step 5.

- If the client was not reached or did not reply to the N-10-00-00 letter, complete the WI. No further action is required.

- In FTS, determine if the Initial Intake (M149) transaction has recently been transmitted:

- If yes, explain that the access code may be delayed in the mail.

- If no, go to step 5. 

#### Conducting a detailed security check

Source topic: `en_EN/task/replacing_ac/conducting_a_detailed_security_check_level_2.dita`

- Conduct a detailed security check with the client:

- If the client fails the detailed security check, go to Detailed security check — Failed .
               [Detailed security check — Failed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/replacing_ac#dscf2)

- If the client passes the detailed security check, go to step 6.

           [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4496.dita) 

#### Detailed security check — Passed

Source topic: `en_EN/task/replacing_ac/detailed_security_check__passed_level_2.dita`

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 7.

- If the client’s address is different than the one on file, refer to Change of address and then go to step 7.
               [Change of address](/en/procedure/activity/change_address.shtml)

- Determine if the next claimant’s report is due within the next 5 business days:

- If no, reissue the original access code. Go to step 8.

- If yes, issue a temporary access code. Go to step 9.

- In FTS, reissue the original access code as follows:

- Under the Transaction menu, select Electronic Security (MD60, M101-15) .

- Select Reissue .

- Provide clients with the first 2 digits of the access code as shown on this screen. Inform them that the access code will be issued in the next pay run and will appear on the next benefit statement.

- Select Update .

- Select OK .

- Go to step 11.

- Determine if the client has access to a touch-tone telephone:

- If no, go to step 10.

- If yes, in FTS, to issue a temporary access code, do the following:

- Under the Transaction menu, select Electronic Security (MD60, M101-15) .

- Select Issue Temporary .

- Provide the client with the temporary access code (it is displayed until you update it).

- Select Update .

- Select OK .

- Tell the client to contact TIS, select option 1, enter SIN, then select option 3.

- Remind the client to choose a code that is easy to remember.

- Go to step 11.

- In FTS, issue a temporary access code and make it permanent as follows:

- Under the Transaction menu, select Electronic Security (MD60, M101-15) .

- Select Issue Temporary .

- Provide the client with the temporary access code (it is displayed until you update it).

- Select Update .

- Select Rescind to remove the TIS security code and make the temporary code a permanent one.

- Determine if there is a WI for this task:

- If yes, complete the WI.

- If no, return to originating task. 

#### Detailed security check — Failed

Source topic: `en_EN/task/replacing_ac/detailed_security_check__failed_level_2.dita`

- Do not provide any claim information. Determine if the client can go to a SCC in person:

- If yes, provide clients with the address of the closest SCC and tell them to present their identification. Go to step 2.

- If no, tell clients to telephone 1-800-206-7218 for service in English and 1‑800‑808‑6352 for service in French when they have the information. Go to step 2.

- In NWS, create an SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Access code request — security check failed.”

- Details: Type the appropriate option:

- “Client requested access code to be replaced, but failed detailed security check — client is unable to go to a SCC and has been told to contact us with information.”

- “Client requested access code to be replaced, but failed detailed security check — client directed to present identification at SCC (insert SCC address).”

- Determine if there is a WI for this task:

- If yes, complete the WI.

- If no, return to originating task. 

#### Rescinding a security code 6 imposed by Integrity

Source topic: `en_EN/task/replacing_ac/rescinding_a_security_code_6_imposed_by_a517edff_level_2.dita`

- While on the telephone with the client, conduct a detailed security check .

- After conducting the detailed security check, do one of the following:

- If the client failed the detailed security check, go to step 3.

- If the client passed the detailed security check, go to step 5.

- Do not provide any claim information. Advise client that another officer will contact them to verify their identity.

- In NWS, create a CB WI for Integrity as follows:

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client resides based on the following table:

```text
| Region | Assign to Level | NWS path |

| Atlantic | Integrity - ATL | 4 - National Integrity (ISB) ⇒ Integrity - ATL |

| Quebec | I - Distribution Centre - QC | 4 - National Integrity (ISB) ⇒ Integrity - QC ⇒ I - A - Regional Operations - QC ⇒ I - Distribution Centre - QC |

| Ontario | Integrity - ON | 4 - National Integrity (ISB) ⇒ Integrity - ON |

| Western Canada and Territories | I - Distribution Centre - WT | 4 - National Integrity (ISB) ⇒ Integrity - WT ⇒ I - A - Regional Operations - WT ⇒ I - Distribution Centre - WT |
```

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Integrity .

- Comments: Type “Security code 6 on file. Identity not validated.”

- Details: Explain why the issue is being referred to Integrity.

- No further action is required.

- In FTS, determine if the Security code 6 - Claimant does not want to use the service is on file:

- If yes, go to step 6.

- If no, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4497.dita)

- Rescind the security code 6 as follows:

- Under the Transaction menu, select Electronic Security (MD60, M101-15) .

- Telemessage: Select Rescind .

- Select Update .

- Issue a temporary access code as follows:

- Under the Transaction menu, select Electronic Security (MD60, M101-15) .

- Security Access Code: Select Issue Temporary .

- Provide the client with the temporary access code (it is displayed until you update it).

- Select Update .

- Select OK .

- Advise the client to contact TIS to select a new access code. 

#### Warning

Source topic: `en_EN/common_notes/note_c_4496.dita`

Warning:

If fraudulent activity is suspected on an EI or EI ERB claim, the agent does not issue an access code. For more information, refer to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml)

     [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_4497.dita`

Note:

The Security code 6 - Claimant does not want to use the service is visible in the tombstone section of FTS and also on the Electronic Security (MD60, M101-15) screen. 

## Policy reference

Source topic: `en_EN/task/replacing_ac/policy_reference.dita`

 
