# COVID-19: Adjudicating contentious reason for separation issues on conversions from special to regular benefits — Level 2

Source map: `en_EN/task/covid19_adjcrsicsrb/covid19_adjcrsicsrb.ditamap`

## Summary

Source topic: `en_EN/task/covid19_adjcrsicsrb/summary.dita`

Summary: Before a claim can be renewed or converted from special benefits (including sickness benefits) to regular benefits, an agent resolves all outstanding reason for separation (RFS) issues in the 12-week period before the interruption of earnings (I of E) used to establish the claim. 

## What you need to know

Source topic: `en_EN/task/covid19_adjcrsicsrb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/covid19_adjcrsicsrb/untitled_section.dita`

An Action Item (AI) WI is created to adjudicate RFS issues when a client requests a conversion from special benefits, including sickness benefits, to regular benefits. This WI addresses all contentious RFS issues that meet the criteria below.

As of September 27, 2020, a new specialized ACP process streamlines the processing of initial applications for regular and sickness benefits with a BPC between w/c 2258 and w/c 2309 that meet specific criteria. Claims automated in the specialized ACP process are established without adjudicating contentious RFS issues in the client’s qualifying period (QP). The Special condition field of the ROE is blank or deferred, and UIC considers the RFS non-contentious at that time . As a result, the contentious ROE is included in the calculation and no disqualifications is imposed.

When a client requests a conversion from special benefits (including sickness benefits) to regular benefits, the agent reviews any RFS issues in order to prevent the payment of benefits to which the client is not entitled. The agent adjudicates each contentious RFS in the 12-week period before the I of E used to establish the claim (even though it was previously considered non-contentious by UIC during the initial calculation). The contentious RFS that must be adjudicated may be one of the following:

- a previously deferred adjudication of an RFS;

- a Special condition field that was left blank (i.e. the RFS was previously ignored);

- a new ROE that was received after the claim was calculated;

- a client declares a contentious RFS when no ROE is on file.

Note the following exception : Contentious RFS issues in the QP do not have to be adjudicated on sickness claims that went through the specialized ACP process and that are being recalculated because the client has requested a conversion to regular benefits from BPC. 

### Calculating the 12-week period

Source topic: `en_EN/task/covid19_adjcrsicsrb/calculating_the_12-week_period.dita`

As of September 27, 2020, a transitional measure has been implemented for adjudicating a contentious RFS on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309. Under this new measure, adjudication principles only apply to the last employment and to RFS issues within the 12-week period before the I of E used to establish the claim.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2937.dita) 

### Effective date of disqualification or disentitlement

Source topic: `en_EN/task/covid19_adjcrsicsrb/effective_date_of_disqualification_or_d_794fdf40.dita`

When the AI WI was created, a 1 - General suspension of benefits (stop payment) manual action (MA01) was imposed while an agent reviews the file. If adjudication results in a negative decision and a disqualification or disentitlement applies, the effective date is the beginning of the week of the conversion (disqualifications take effect on Sundays, and disentitlements take effect on Mondays). There may be cases where the client received some weeks of regular benefits before the manual action (MA) was imposed. In these situations, the disqualification or disentitlement is effective the same week the MA01 was imposed. No overpayments (OPs) are created in these situations.

In all other situations where no MA was imposed, the disqualifications or disentitlements are effective from the beginning of the week the issue is adjudicated. No OPs are created in these situations. 

### Recalculation

Source topic: `en_EN/task/covid19_adjcrsicsrb/recalculation.dita`

If adjudication has resulted in a negative decision, the agent imposes an indefinite disqualification or disentitlement on the claim for regular benefits. The only exception is when the client requalifies. Due to the one-time credit of insurable hours , the client needs 120 hours of insurable employment since the most recent indefinite disqualifying event to requalify. The hours credit alone is not sufficient.
       [one-time credit of insurable hours](/en/site/dossier/post_ei_erb_hc_ch.shtml#main-content)

If the client has at least 120 hours of insurable employment since the most recent disqualifying event, the ROE with the disqualifying event is excluded and no disqualification is imposed. The insurable hours from all other ROEs in the QP (except those from the excluded ROE) are used to calculate the total insurable hours.

Normally, to determine if a recalculation is required, the agent reviews changes to either the benefit rate or the weeks of entitlement. Since all claims with a BPC between w/c 2258 and w/c 2309 will include 50 weeks of entitlement, a recalculation is only required if the client’s benefit rate is greater than the minimum $500. Therefore, once all of the contentious RFS issues have been adjudicated, the agent determines if a recalculation is required.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2938.dita) 

A recalculation is not required in the following scenarios:

- A disqualification or disentitlement was imposed on the last ROE.

- The client has the minimum benefit rate of $500.
         [minimum benefit rate](/en/site/dossier/updated_post_eierb_min_br_ar.shtml)

When it is determined that a recalculation is required, the agent creates a Claim Review (CR) Recalculation WI. 

### Example

Source topic: `en_EN/common_notes/note_c_2937.dita`

Example:

Mary’s last day worked (LDW) was September 25, 2020 (w/c 2257). Her I of E is in w/c 2257, she applied for benefits on September 26, 2020, and her BPC will be September 27, 2020 (w/c 2258).

There are 3 contentious ROEs on Mary’s file:

ROE 1: LDW September 25, 2020 (w/c 2257). ROE 2: LDW July 17, 2020 (w/c 2247). ROE 3: LDW May 31, 2020 (w/c 2241).

To determine which RFS to adjudicate, the agent subtracts 12 weeks from w/c 2257 (week of the I of E). For the example above, the formula is as follows: w/c 2257 (I of E) – 12 = w/c 2245. This determines the 12-week period before the Sunday of the I of E that encompasses the weeks from w/c 2245 to w/c 2256. The agent follows normal procedures and adjudicates ROE 1, which is the most recent ROE in the QP, and ROE 2, since it falls between w/c 2245 and w/c 2256 (the 12-week period).

The agent allows any contentious RFS that occurs before the 12-week period. ROE 3 is before the 12-week period, so the agent allows the RFS by following the steps of Adjudication not required – Reason for separation (RFS) beyond 12 weeks .
       [Adjudication not required – Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#level2_item_9)

     [Adjudication not required – Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#level2_item_9) 

### Info

Source topic: `en_EN/common_notes/note_c_2938.dita`

The client has 420 hours of insurable employment since the last disqualifying event. This means that the client requalifies, so ROE 2 is excluded and no disqualification is imposed. Since the client’s benefit rate is $500 (the minimum), no recalculation is required as there is no impact on the client’s benefit rate.

The client has 120 hours of insurable employment since the last disqualifying event. UIC adds the 480 insurable hours credit to these 120 hours. This means that the client requalifies, so ROE 2 is excluded and no disqualification is imposed. Since the client’s benefit rate is greater than $500 (the minimum), a recalculation is required. Excluding ROE 2 may result in a decrease to the client’s benefit rate.
       [480 insurable hours credit](/en/site/dossier/post_ei_erb_hc_ch.shtml)

     [480 insurable hours credit](/en/site/dossier/post_ei_erb_hc_ch.shtml) 

## Regional considerations

Source topic: `en_EN/task/covid19_adjcrsicsrb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/covid19_adjcrsicsrb/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/covid19_adjcrsicsrb/in_nws.dita`

- When was the application for benefits filed?

- Has the client requested a conversion of benefits?

- Is there an ROE on file?

- If no, is there employment information on file?

- Is there a ROD for deferring the RFS adjudication?

- Was an RFS previously ignored (i.e. the Special condition field on the ROE was left blank)?

- Are there any SROCs, AI WIs or documentation with additional information or details on the contentious RFS? 

### In FTS:

Source topic: `en_EN/task/covid19_adjcrsicsrb/in_fts.dita`

- Is there an MA01 imposed on the claim?

- If yes, did the client receive regular benefits before the MA01 was imposed? 

### In RCM:

Source topic: `en_EN/task/covid19_adjcrsicsrb/in_rcm.dita`

- Has an ROE with a contentious RFS been submitted? 

### In Imaging:

Source topic: `en_EN/task/covid19_adjcrsicsrb/in_imaging.dita`

- Are there any imaged documents that may provide additional information on the contentious RFS? 

## Step by step

Source topic: `en_EN/task/covid19_adjcrsicsrb/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/covid19_adjcrsicsrb/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/covid19_adjcrsicsrb/reviewing_the_file_level_2.dita`

- Determine if all of the following conditions are met:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2939.dita) 

- If all conditions are met, go to step 2.

- If all conditions are not met, go to the appropriate task for the particular RFS issue.

- Determine if one or more of the following are present in the 12-week period before the I of E used to establish the claim:

- a contentious RFS;

- a previously deferred adjudication of an RFS;

- a Special condition field that was left blank (i.e. the RFS was previously ignored).

- If yes, go step 3.

- If no, go to Adjudication Not Required .
                   [Adjudication Not Required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_9)

- Determine if the facts on file clearly indicate that the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If the facts do not clearly indicate that the employment is not insurable for one of these reasons, go to step 4.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_10)

- Determine if there is enough information on file to adjudicate the RFS:

- If no, go to step 5.

- If yes, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/covid19_adjcrsicsrb/fact-finding_level_2.dita`

- Fact-find with the client and the employer for each RFS issue. Refer to the Fact-Finding Guide and the appropriate section of the Digest for the RFS issue (i.e. Digest 7 — Misconduct , or Digest 6 — Voluntarily Leaving Employment ) to determine the questions to ask.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2940.dita)

- Determine if the client or employer was contacted during fact-finding:

- If the client or employer was contacted, go to step 7.

- If the client or employer was not contacted or did not reply to the letter, go to step 8.

- In NWS, add details to the draft SROC created during fact-finding, or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “[Appropriate RFS issue] — [employer’s name] — [LDW] — [client or employer].”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2941.dita) 

#### Adjudicating the reason for separation (RFS) issue

Source topic: `en_EN/task/covid19_adjcrsicsrb/adjudicating_the_reason_for_separation_rfs_issue_level_2.dita`

- Determine if misconduct or just cause is proven (according to each identified RFS issue) by considering all evidence provided by both the client and the employer, and the principles outlined in the EIA, EIR and case law. Refer to Digest 7 — Misconduct , to Digest 6 — Voluntary leaving employment , or to Digest 6.6.0 — Periods of leave as needed.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1747.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2942.dita) 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/covid19_adjcrsicsrb/record_of_decision_rod__creation_level_2.dita`

- In NWS, create a separate ROD for each decision and complete the following fields:

- Comments: Type “[RFS issue] — [employer’s name] — [LDW or start date of suspension] — [decision (e.g. misconduct proven or not proven, voluntary leaving with just cause or no just cause)].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .

- Based on the decision rendered, determine if verbal communication of a negative decision is required. Refer to Communication . If required, verbally communicate the decision to the client.
                   [Communication](/en/procedure/activity/communication.shtml) 
                   [verbally communicate the decision](/en/procedure/task/verbal_communication.shtml)

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to Inputting the decision .
               [Inputting the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_5)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1351.dita) 

#### Inputting the decision

Source topic: `en_EN/task/covid19_adjcrsicsrb/inputting_the_decision_level_2.dita`

- Determine if adjudication resulted in a negative decision (i.e. misconduct proven or just cause not shown):

- If yes, go to Disqualification or disentitlement required .
               [Disqualification or disentitlement required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_7)

- If no, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_6)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2943.dita) 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/covid19_adjcrsicsrb/reason_for_separation_rfs_allowed_level_2.dita`

- In RCM, determine if the ROE with the RFS issue for the decision being input has been received:

- If yes, go to step 2.

- If no, go to step 3.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment : Select the appropriate option based on the RFS issue:

- M - Dismissal

- E - Quit

- N - Leave of Absence

- Special condition : Select the appropriate option based on the RFS issue:

- Misconduct not proven

- Voluntary leaving - Just cause

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Click Validate .

- Click Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2944.dita)

- Determine the RFS issue for this decision:

- If it is a dismissal or suspension, go to step 4.

- If it is a leave of absence or voluntary leaving, go to step 5.

- In ACS, inform the employer of the decision by sending a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775) : Select Approved claim of employee or former employee .

- Reason for Claim Approval (2783) :

- If fact-finding determined that misconduct was not proven, select No Misconduct .

- If the employer failed to provide information regarding the dismissal, select Insufficient information to prove Misconduct .

- In an instance of suspension, select Suspension not Misconduct .

- Warning to Employer Re Monies paid to Claimant (2788) :

- If the employer is required to pay wages, pension, etc. (if there are challenge or grievance procedures underway), select Warning to ER: To inform us if pays any monies to employee .

- If there is no information on whether challenge or grievance procedures are underway, select Blank .

- You / We are writing to inform you that you (2793).

- Right to Request a Reconsideration (with Blank option) (4169) : Select Right to Request a Reconsideration .

- Go to step 6.

- In ACS, if the employer must be informed of the decision, create and send a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved reason for separation and the appropriate sub-options.

- Reason for Claim Approval (2783): Select the appropriate option:

- Valid Reason for Leaving .

- Valid Reason not to Return to Work .

- Became Employed Elsewhere .

- Valid reasons for taking a period of leave

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Determine if there is a ROD for another contentious RFS that requires the decision to be input:

- If yes, return to Inputting the decision .
               [Inputting the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_5)

- If no, go to Rescinding the manual action (MA) .
               [Rescinding the manual action (MA)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_11) 

#### Disqualification or disentitlement required

Source topic: `en_EN/task/covid19_adjcrsicsrb/disqualification_or_disentitlement_required_level_2.dita`

- In RCM, determine if the ROE with the RFS issue for the decision being input has been received:

- If yes, go to step 2.

- If no , go to step 3.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select the appropriate option based on the RFS issue:

- M - Dismissal

- E - Quit

- N - Leave of Absence

- Special condition: Select the appropriate option based on the RFS issue:

- Misconduct proven

- Suspension

- Voluntary leaving - No just cause

- Authorized Period of Leave

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Click Validate .

- Click Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2944.dita)

- Determine if the decision being input is for an RFS issue from the client’s last employment:

- If yes, go to step 6.

- If no, go to step 4.

- Determine if the client has at least 120 hours of insurable employment since the disqualifying event:

- If yes, go to step 5.

- If no, go to step 6.

- In NWS, create a ROD and complete the following fields:

- Comments: Type “[RFS issue] — [employer’s name] — [LDW] — gained relief.”

- Details: Type “No disqualification imposed as client has sufficient hours since this disqualifying event to establish a new claim.”

- Go to step 13.

- Determine if there is a revised registration number for the RFS issue:

- If no, go to step 7.

- If yes, go to step 8.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- In FTS, determine if an MA01 is imposed for the RFS issue:

- If yes, go to step 9.

- If no, go to step 12.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2945.dita)

- Determine if the client received regular benefits before the MA01 was imposed:

- If yes, go step 10.

- If no, go to step 11.

- Select the Renewal/Revised (M106) transaction and remove the MA01 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Action: Select Add .

- Disqualification or Disentitlement: Make the appropriate selection and then select the appropriate option:

- Disqualification:

- 10 - Dismissal - misconduct proven

- 11 - Voluntary Leave - Just Cause not proven

- Disentitlement:

- 42 - Suspension from employment

- 43 - Leave of absence

- Start: Enter the date the MA01 was imposed:

- For a disqualification: Enter Sunday’s date.

- For a disentitlement: Enter Monday’s date.

- End: Enter the disentitlement end date, or select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select the appropriate option:

- 1 - An overpayment resulted due to a disqualification

- 3 - An overpayment resulted due to a definite disentitlement

- 4 - An overpayment resulted due to an indefinite disentitlement

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- Go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2946.dita)

- Select the Renewal/Revised (M106) transaction and remove the MA01 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Action: Select Add .

- Disqualification or Disentitlement: Make the appropriate selection and then select the appropriate options:

- Disqualification:

- 10 - Dismissal - misconduct proven

- 11 - Voluntary Leave - Just Cause not proven

- Start: Enter the Sunday of the week of the conversion.

- Disentitlement:

- 42 - Suspension from employment

- 43 - Leave of absence

- Start : Enter the Monday of the week of the conversion.

- End : Enter the disentitlement end date, or select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select the appropriate option:

- 1 - An overpayment resulted due to a disqualification

- 3 - An overpayment resulted due to a definite disentitlement

- 4 - An overpayment resulted due to an indefinite disentitlement

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

- Go to step 13.

- Select the Disqualifications/Disentitlements (M161) and impose the disqualification or disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disqualification or Disentitlement: Make the appropriate selection and then select the appropriate options:

- Disqualification:

- 10 - Dismissal - misconduct proven

- 11 - Voluntary Leave - Just Cause not proven

- Effective: Enter the Sunday of the current week.

- Disentitlement:

- 42 - Suspension from employment

- 43 - Leave of absence

- Start date: Enter the Monday of the current week.

- End date: Enter the disentitlement end date, or select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select the appropriate option:

- 1 - An overpayment resulted due to a disqualification

- 3 - An overpayment resulted due to a definite disentitlement

- 4 - An overpayment resulted due to an indefinite disentitlement

- Decision type: Select 3 - Revised.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Click Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2947.dita)

- Determine if there is a ROD for another contentious RFS that requires the decision to be input:

- If no, go to step 14.

- If yes, return to Inputting the decision .
               [Inputting the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_5)

- Determine the RFS issue in order to send the appropriate letter:

- If it is 10 - Dismissal - Misconduct proven (D10), go to step 15.

- If it is 42 - Suspension from employment because of misconduct (D42) suspension with proven misconduct, go to step 16.

- If it is 43 - Leave of absence from employment without just cause (D43), go to step 17.

- If it is 11 - Voluntary leaving - just cause not proven (D11), go to step 18.

- In ACS, create and save a D-01-00-00 letter for the D10. Based on the claim information, select all of the required attributes, including the following:

- If the client does not have enough hours since the dismissal to qualify, select the following attributes:

- Disqualifications – Definite / Indefinite – Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revised) .

- D11 / D10 / Both / Previous Disq / Revision (Initial or Renewal or Revision) (2542): Select Disqualification message for Initial Claim .

- Disqualification message for Initial Claim (2543): Select Initial Claim - D10 Misconduct .

- D10 Date of event = BPC/Date of event prior to BPC/ Date of event after BPC (2546): Select Date of event after BPC and the appropriate sub-options.

- D10 Min hours required to qualify for regular benefits/Not enough hours worked since event for regular/Not enough hours worked since event for regular and not enough fishing earnings for fishing benefits (2547):

- If the client has not worked since the disqualifying event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious there are insufficient hours since the disqualifying event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but there is insufficient information or knowledge to complete this block, select Min hrs required to qualify for regular benefits .

- If the client has enough hours since the dismissal to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (1503): Select D10 message .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Go to Reviewing for recalculation to determine if a recalculation is required.
               [Reviewing for recalculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_8)

- In ACS, create and save the D-01-00-00 letter for the D42. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 (3021): Select D42 - Suspension due to misconduct .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Date of suspension from employment (1470): Enter the appropriate date

- Text - Name of Employer(s) (1502): Enter the employer’s name.

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- Go to Reviewing for recalculation to determine if a recalculation is required.
               [Reviewing for recalculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_8)

- In ACS, create and save a D-01-00-00 letter for the D43. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 (3021): Select D43: Voluntary leave of absence from employment, without just cause .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of authorized leave from employment (1478): Select the appropriate date.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Go to Reviewing for recalculation to determine if a recalculation is required.
               [Reviewing for recalculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_8)

- In ACS, create and save a D-01-00-00 letter for the D11. Based on the claim information, select all of the required attributes, including the following:

- If the client does not have hours since the voluntary leaving to qualify, select the following attributes:

- Disqualifications – Definite/Indefinite – Previous/Current/Revision (2970): Select D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revised) .

- D11 / D10 / Both / Previous Disq / Revision(Initial/Renewal or Revision) (2542): Select Disqualification message for Initial Claim .

- Disqualification message for Initial Claim (2543): Select Initial Claim - D11 Voluntary leaving .

- D11 Date of event = BPC/Date of event prior to BPC/ Date of event after BPC (2544): Select Date of event after BPC and the appropriate sub-options.

- D11 Min hrs required to qualify for regular benefits/ Insufficient hrs accumulates since event for regular/ Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious that there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but there is insufficient information or knowledge to complete this block, select Min hrs required to qualify for regular benefits .

- If the client has enough hours since the voluntary leaving to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 message - D10 message (2463): Select D11 message .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Go to Reviewing for recalculation to determine if a recalculation is required.
               [Reviewing for recalculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_8) 

#### Reviewing for recalculation

Source topic: `en_EN/task/covid19_adjcrsicsrb/reviewing_for_recalculation_level_2.dita`

- Determine if one of the following conditions applies:

- A disqualification or disentitlement was imposed on the last ROE.

- The client’s benefit rate is $500.

- If one of the conditions applies, a recalculation is not required. Go to step 20.

- If none of the conditions applies, go to step 21.

- In ACS, send the saved D-01-00-00 letter. Go to step 23.

- Create a CR Recalculation WI as follows:

- Registration number: Enter the registration number as shown on the MA01.

- Type: Select Recalculation .

- Complexity: Select Level 1 .

- Date of registration: Enter the creation date of the revised registration number that added the MA01.

- In NWS, create a client Note and type “New policy measure. Recalculation required due to excluded ROE after conversion to regular benefits. Add the appropriate attributes before sending the saved D-01-00-00 letter.”

- Go to step 24.

- In FTS, determine if an MA01 is imposed for the RFS issue:

- If no, go to step 24.

- If yes, go to Rescinding the manual action (MA) .
               [Rescinding the manual action (MA)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_11)

- In NWS, complete the WI. 

#### Adjudication not required

Source topic: `en_EN/task/covid19_adjcrsicsrb/adjudication_not_required_level_2.dita`

- In NWS, for each contentious RFS identified in the 12-week period before the I of E used to establish the claim, create a ROD as follows:

- Comments: Type “[Appropriate RFS issue] — [employer’s name] — [LDW] — Adjudication not required.”

- Details: Type the appropriate option:

- “Post-Employment Insurance Emergency Response Benefit transitional measure — client is not requesting a conversion from special to regular benefits.”

- “Post-Employment Insurance Emergency Response Benefit transitional measure — BPC does not fall between w/c 2258 and w/c 2309.”

- “Post-Employment Insurance Emergency Response Benefit transitional measure — reason for separation beyond 12 weeks. EIA 153.194.”

- Click Save .

- Go to Rescinding the manual action (MA) .
               [Rescinding the manual action (MA)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_11) 

#### Employment is not insurable

Source topic: `en_EN/task/covid19_adjcrsicsrb/employment_is_not_insurable_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Appropriate RFS issue] — [employer’s name] — [LDW] —Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Go to Rescinding the manual action (MA) .
               [Rescinding the manual action (MA)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_adjcrsicsrb#level2_item_11) 

#### Rescinding the manual action (MA)

Source topic: `en_EN/task/covid19_adjcrsicsrb/rescinding_the_manual_action_ma_level_2.dita`

- Determine if a stop payment (MA01) is imposed and if there is a registration number for the contentious RFS issue:

- If an MA01 is imposed but there is no registration number, go to step 2.

- If an MA01 is imposed and there is a registration number, go to step 3.

- If an MA01 is not imposed but there is a revised registration number, go to step 4.

- If none of the above applies, go to step 5.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA01 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Click Update .

- Go to step 5.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- If there is an outstanding CR Recalculation WI, select D - No to leave the registration open for subsequent transactions.

- If there is no outstanding CR Recalculation WI, select C - Yes to clear the registration number.

- Click Update .

- In NWS, complete the WI. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2939.dita`

- Condition 1 — The client is requesting a conversion from special benefits to regular benefits.

- Condition 2 — The BPC is between w/c 2258 and w/c 2309.

- Condition 3 — The Issue field on the AI WI is Reason for separation and the comments indicate adjudication after conversion. 

#### Note

Source topic: `en_EN/common_notes/note_c_2940.dita`

Note:

If the employee’s disciplinary record contains documentary evidence related directly to the dismissal or suspension, request a copy of the client’s file from the employer. In cases of railway misconduct, request a copy of the hearing transcript as well. 

#### Note

Source topic: `en_EN/common_notes/note_c_2941.dita`

Note:

Create a new SROC for each conversation with the employer or the client (e.g. if the employer was contacted twice, create 2 SROCs). 

#### Note

Source topic: `en_EN/common_notes/note_c_1747.dita`

Note:

If you are unable to contact the client or the employer, render a decision based on the information on file. 

#### Note

Source topic: `en_EN/common_notes/note_c_2942.dita`

Note:

Railway misconduct is only proven when the transcript of the disciplinary committee hearing is obtained or when the client has provided sufficient facts about the railway rule or regulation violation to prove misconduct without the transcript. 

#### Note

Source topic: `en_EN/common_notes/note_c_1351.dita`

Note:

If fact-finding by telephone was attempted but was not successful, click Save regardless of the decision, because verbal communication of the decision is not required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2943.dita`

Note:

If there are multiple RFS issues that have been adjudicated, follow the appropriate path for each decision rendered. 

#### Note

Source topic: `en_EN/common_notes/note_c_2944.dita`

Note:

Clicking Validate may cause the ROE to be flagged with an error. If this occurs, no further action is required. If a recalculation is required, the ROE will be corrected at that time. 

#### Note

Source topic: `en_EN/common_notes/note_c_2945.dita`

Note:

In some instances, a 75 - Verification of reason for termination of Employment manual action (MA75) may have been imposed instead of the MA01. The process for removing the MA75 is the same as for the MA01. However, before removing the MA01, verify that there are no remaining issues to adjudicate. 

#### Note

Source topic: `en_EN/common_notes/note_c_2946.dita`

Note:

If the client received regular benefits before the stop-pay was imposed, and a disqualification or disentitlement is required, the effective date is the beginning of the week in which the MA01 was imposed (disqualifications take effect on Sundays, and disentitlements take effect on Mondays). Do not create an OP in this situation. 

#### Note

Source topic: `en_EN/common_notes/note_c_2947.dita`

Note:

The current week is the week in which the decision on the adjudication is made. Do not create an OP in this situation. 

## Policy reference

Source topic: `en_EN/task/covid19_adjcrsicsrb/policy_reference.dita`

- EIA 153.194
         [EIA 153.194](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-42.html#h-1261577)

- EIA 153.16
         [EIA 153.16](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-41.html#h-1258228) 
