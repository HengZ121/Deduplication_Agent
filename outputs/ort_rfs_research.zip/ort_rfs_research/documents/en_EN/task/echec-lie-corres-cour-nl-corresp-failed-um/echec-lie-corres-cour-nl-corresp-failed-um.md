# Correspondence Failed – Undeliverable mail — Cúram

Source map: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/echec-lie-corres-cour-nl-corresp-failed-um.ditamap`

## Summary

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/summary.dita`

Summary: Undeliverable mail is any document, other than a Notice of Debt, returned to Service Canada because the recipient does not reside or no longer resides at that address. When undeliverable mail is received, the officer tries to obtain a new address so that the undeliverable mail can be resent to the client. When the undeliverable mail is related to a D-80--00 letter sent from Curam, a Correspondence Failed – Undeliverable mail task is created in Curam. 

## What you need to know

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/what_you_need_to_know.dita`

### Undeliverable mail

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/undeliverable_mail.dita`

When a decision is made on a claim, the client must be notified of the decision. When a letter or document is returned to Service Canada as undeliverable, an officer updates the status of the letter in ACS to Undeliverable . This triggers the creation of a Correspondence Failed – Undeliverable Mail task in Curam which is specific for letter types related to claims processed in Curam.. 

### Actioning the receipt of undeliverable mail

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/actioning_the_receipt_of_undeliverable_mail.dita`

A client must provide a valid mailing address in order to maintain entitlement to benefits. When the client’s mailing address is no longer valid, if a questionnaire or a direction to report is sent and the client fails to respond, or if any mail sent to the client is returned undeliverable, benefits may be suspended. In order to regain entitlement to benefits, the client must provide a valid mailing address for their normal place of residence.

When undeliverable mail is received, the officer tries to obtain a new address so the undeliverable mail can be resent to the client. 

### Fraud indicators

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/fraud_indicators.dita`

Before contacting clients to validate their address, the officer determines if the claim is already under investigation for potential fraud. Officers can determine that there is an ongoing Integrity investigation for this application if:

- a 71 - Integrity Services case disentitlement (D71) is imposed in Curam or Legacy;

- a suspension – Integtrity Services Case is imposed in Curam.

- The Special Caution flag is displayed in Curam

- an SROC created by Integrity is on file in NWS;

- an Action Item (AI) WI is assigned to Integrity in NWS;

- a Call Back (CB) WI is assigned to Integrity in NWS;

- a Claim Review (CR) WI created by Integrity is on file in NWS.

- Documentation on file in Curam indicates Integrity is involved in the claim.

If none of these is on file, the officer reviews the claim to determine if there are any fraud indicators by referring to Fraud indicators: Identifying potentially fraudulent claims — Knowledge . If there are fraud indicators, the officer:
       [Fraud indicators: Identifying potentially fraudulent claims — Knowledge](/en/procedure/generic/additionalresources/fraud_indicator.shtml)

- determines if the banking information has been changed in FTS or in Curam and, if so, terminates the direct deposit;

- imposes a D71 or a suspension on the claim, if necessary.

- inputs the Special Caution flag in Curam.

- refers the claim to Integrity for investigation. 

### Obtaining the address from the client

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/obtaining_the_address_from_the_client.dita`

When a new address is obtained from the client, the officer refers to Change of Address and then resends the undeliverable mail to the client’s new address.
       [Change of Address](/en/procedure/task/ajou_mod_sup_adresse_client-add_mod_end_client_address_curam.shtml) 

### Imposing a disentitlement or suspension when a new address cannot be established

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/imposing_a_disentitlement_or_suspension_8cd7c12e.dita`

When a new address cannot be obtained for an active Curam claim, the officer imposes an indefinite 48 - Moved - address unknown disentitlement (D48) or a suspension – Stop payment due to undeliverable mail . Benefits remain suspended until the client provides a new address. This is an administrative disentitlement used to indicate that payment of benefits is suspended because the client has not supplied a current address. If the claim is not established, a D48 or a suspension cannot be imposed. The officer imposes an administrative 15 - Claim procedure disentitlement (D15) . 

### Resending undeliverable mail

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/resending_undeliverable_mail.dita`

[Important](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3308.dita) 

If a new address is obtained for the client, officers attempt to recreate and send the mail. If the undeliverable mail is an automated D-80-00-00 letter related to a Curam claim, officers attempt to recreate and send the letter from Curam. From the Person Case, select the Contacts tab from the navigation bar. From the Communications list, officers locate the rejected/undeliverable letter from the list of correspondence and select the 3 dots ( … ) to preview the letter. The officer then uses the Create Correspondence option to recreate and send the required letter, using the same options/attributes that appear in the original letter. If the D-80-00-00 letter cannot be recreated and sent from Curam, the officer manually creates a N-70-00-00 or F-00-00-00 letter in ACS to communicate all information to the client.

For all other letter types, the officer recreates and sends the appropriate letter type in ACS and, if required, re-issues the access code.

**Resending a warning letter that includes an unclassified violation**

To determine if a violation has been imposed in Curam, from the Application Case, officers select Evidence from the navigation bar. If a violation has been imposed, an officer will see it in the Qualification/Calculation Related row on the Evidence Dashboard . To update the Notification Week , officers select the Violation to open the evidence and select Edit make the required change.

If the undeliverable mail is a D-91-00-00 warning letter (i.e. a non-monetary penalty) that includes an unclassified violation (in Curam on the Violation evidence, the Type field shows Violation - warning letter issued ), the Non-complex officer images the envelope for further action by a Level 1 officer.

The Level 1 officer determines if an overpayment (OP) is associated with the D-91-00-00 letter and if the Notice of Debt was returned as undeliverable. If no OP is associated with the D-91-00-00 warning letter that includes an unclassified violation, the Level 1 officer creates and sends a new notice of decision containing the same information as the original notice of decision. In addition, the Level 1 officer inputs a new notification week on the Violation evidence in Curam.

**Resending a warning letter that does not include an unclassified violation**

If the undeliverable mail is a D-91-00-00 warning letter that does not include an unclassified violation (In Curam, on the Violation evidence, the Type field shows Warning Letter ), the Non-complex officer addresses an envelope with the client’s new address, encloses the undeliverable mail and sends it to the client.

**Resending a notice of decision unrelated to a Notice of Debt**

If the undeliverable mail is a notice of decision that is unrelated to a Notice of Debt, the Non-complex officer addresses an envelope with the client’s new address, encloses the undeliverable mail and sends it to the client.

**Resending a notice of decision resulting in an overpayment (OP)**

If the undeliverable mail is a notice of decision that set up an OP or a penalty, and the Notice of Debt was not returned as undeliverable, the Non-complex officer addresses an envelope with the client’s new address, encloses the undeliverable mail and sends it to the client. Since the Notice of Debt was delivered, the client was notified of the debt and therefore is not entitled to a new right to request a reconsideration timeframe.

**Resending a letter that is not a notice of decision**

If the undeliverable mail is an ACS letter that is not a notice of decision (e.g. a questionnaire), the Non-complex officer addresses an envelope with the client’s new address, encloses the undeliverable mail and sends it to the client.

**Issuing a new notice of decision when the Notice of Debt is actioned**

If the undeliverable mail is a notice of decision that set up an OP or a penalty, and the Notice of Debt was also returned as undeliverable, the new notice of decision will be sent at the time the Notice of Debt is actioned.

**Resending a benefit statement**

If the undeliverable mail is a benefit statement, it may contain an access code. When the benefit statement contains an access code, the letter P is displayed in front of the Service Canada return address. The Non-complex officer does not open the envelope containing the benefit statement and access code since the officer must not see the client’s full access code. If the undeliverable mail contains the P privacy code, the non-complex officer sends an NSD ticket to the ACS Support Team to have the ACS status code changed to Undeliverable which will generate a Curam task, assigned to a Level 1 officer. The non-complex officer shreds the original letter and the Level 1 officer reissues the access code through Curam.

**T4E**

If the undeliverable mail is a T4E, the envelope must not be opened because that would constitute a breach of privacy. Therefore, all mail that contains a T4E must be destroyed. Mail that contains a T4E can be identified by a bracket (┌ ) in the left-hand corner of the address window. 

### Important

Source topic: `en_EN/common_notes/note_c_3308.dita`

Important:

Currently the Preview Letter and the Create Correspondence functions are not working in Curam. As a work around, officers will review the file to confirm the issue is a BPNE 4 decision.

To confirm, officers review the file, including:

- Client Notes in Curam.

- SE Agreement Evidence from the Application Case.

- SROCs in NWS.

After completing a thorough review of the claim, the officer manually creates and sends an N-70-00-00 letter in ACS communicating all important information to the client. 

## Regional considerations

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/what_you_need_to_look_for.dita`

### In Curam:

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/in_curam.dita`

- Is there any documentation containing a new address for the client?

- Has a new address been input?

- Has a D48 or a suspension – Stop payment due to undeliverable mail been imposed?

- Are fraud indicators present? 

### In NWS:

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/in_nws.dita`

- Is there an SROC related to the undeliverable mail?

- Is there a WI related to the undeliverable mail?

- Is there an SROC or any documentation containing a new address for the client? 

### In Imaging:

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/in_imaging.dita`

- Is there information indicating a new address is available? 

### In FTS:

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/in_fts.dita`

- Has a new address been input?

- Has a D48 or MA48 been imposed? 

### In PSCD:

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/in_pscd.dita`

- Is a new address available? 

## Step by step

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/non-complex.dita`

#### Reviewing the file

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/reviewing_the_file_non-complex.dita`

- Determine if the undeliverable mail letter is for a Curam claim:

- If no, go to Actioning the receipt of undeliverable mail to follow Legacy procedures.
               [Actioning the receipt of undeliverable mail](/en/procedure/task/actioning_receipt_un_mail.shtml)

- If yes, go to step 2.

- Determine if the undeliverable mail is a T4E:

- If no, go to step 3.

- If yes, shred it. No further action is required.

- In ACS, locate the letter returned as undeliverable, using the Correspondence ID of the letter.

- If the letter in question is a D-80-00-00 letter, update the ACS status of the letter to Undeliverable.

- If the letter in question is a I-10-00-00 letter, submit a ticket through the National Service Desk (NSD) to the ACS Support Team with the letter’s Correspondence ID# number to request that the ACS status be updated to Undeliverable. Shred the original letter.

- For all other letter types that have been returned as undeliverable, create an AI WI in NWS as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option based on the client’s language.

- Destination - SCC: Select National IPOC – select Curam .

- End User: Select Next available user .

- Issue: Select Undeliverable mail .

- Details: Type “[Type of undeliverable mail] originally sent on [date] was received as undeliverable on [date].”

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3309.dita)

- In NWS, create a new SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “Curam claim – undeliverable mail.”

- Details: Type “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date]. The status of the letter has been updated to Undeliverable in ACS.”

- Select Save .

- No further action required. 

#### Note

Source topic: `en_EN/common_notes/note_c_3309.dita`

Note:

Updating the ACS status of the D-80-00-00 and I-10-00-00 letters to Undeliverable will trigger the creation of a Correspondence Failed - Undeliverable Mail task in Curam, which will be assigned to a dual-trained officer. 

### Level 1

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/reviewing_the_file_level_1.dita`

- In Curam and Legacy, determine if there is documentation on file indicating that the application is under investigation for potential fraud:

- Determine if there are known fraud indicators and if fraud is suspected by referring to Fraud indicators: Identifying potentially fraudulent claims — Knowledge and reviewing the file:

- In FTS, determine if the banking information has been changed to the banking information from the potentially fraudulent application:

- In FTS, determine if the client has provided a new address:

- Determine if a new address for the client is available from a third-party source (e.g. directory assistance or the telephone book).

- In PSCD, determine if the client’s new address is available as follows:

- Determine if the client was contacted during fact-finding:

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows: 

#### New address confirmed

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/new_address_confirmed_level_1.dita`

- In Curam, review the letter in question as follows:

- From the Application Case, select Contacts from the navigation bar.

- Select Communications from the menu on the left-hand side of the screen.

- Select > beside the letter in question.

- Select the 3 dots ( … ) on the right side of the screen, beside Edit . From the drop-down menu, select Preview .

- Letters not sent from Curam are reviewed from ACS.

- Determine the type of undeliverable mail that was returned:

- If the undeliverable mail is a D-80 -00-00 letter, go to step 3.

- If the undeliverable mail is a D-91-00-00 warning letter that includes an unclassified violation, (in Curam on the Violation evidence, the Type field shows Violation - warning letter issued ), go to step 5.

- If the undeliverable mail is a notice of decision that set up an OP or a penalty, go to step 8.

- If the undeliverable mail is a D-91-00-00 letter that does not include an unclassified violation (In Curam, on the Violation evidence, the Type field shows Warning Letter ), go to step 8.

- If the undeliverable mail is a notice of decision unrelated to a Notice of Debt, go to step 9.

- If the undeliverable mail is any other ACS letter, go to step 10.

- If the undeliverable mail is a I-10-00-00 letter containing the client’s access code, go to step 11.

- If the undeliverable mail is a benefit statement with an access code, go to step 11.

- If the undeliverable mail is none of the above, go to step 10.

- Review and recreate the undeliverable D-80-00-00 letter as follows:

- From the Person Case, select the Contacts tab from the navigation bar.

- Select Communications from the left side menu.

- Locate the undelivered D-80-00-00 letter from the list of correspondence and select the 3 dots ( … ) on the right side to preview the letter.

- In ACS, create and send the N-70-00-00 letter with the same information as communicated in the original D-80-00-00 letter. Go to step 13.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3310.dita)

- Determine if there is an OP related to the D-91-00-00 warning letter that includes an unclassified violation:

- If no, go to step 6.

- If yes, go to step 8.

- In Curam, update the Violation evidence with a new Notification Week as follows:

- From the Application Case, select Evidence from the navigation bar.

- Locate the Violation evidence from the Qualification/Calculation Related row on the Evidence Dashboard .

- Select the Violation to open the evidence and select Edit from the right hand-side.

- On the Notification Week field, enter today’s date.

- Select Save .

- In ACS, create and send a new D-91-00-00 decision letter with the same information as the original decision. Go to step 13.

- Determine if the Notice of Debt that is related to the undeliverable notice of decision was returned as undeliverable:

- If the Notice of Debt was not returned as undeliverable, go to step 9.

- If the Notice of Debt was returned as undeliverable, go to step 13.

- From the appropriate electronic system (i.e. ACS, FTS, Imaging) print a copy of the undeliverable mail.

- Address an envelope with the client’s new address, enclose the undeliverable mail and send it to the client. Go to step 13.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1520.dita)

- Determine if the access code has been reissued:

- If no, go to step 12.

- If yes, go to step 15.

- In Curam re-issue the access code as follows:

- From the Person Case, select Home from the navigation bar.

- From the Home screen, under Access Code , the first 2 digits of the client’s access code are displayed, along with the date the original code was issued.

- Select the 3 dots ( … ) on the right side and select Re-Issue from the drop-down menu.

- Select Save .

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “Curam claim. Undeliverable mail – new address confirmed.”

- Details: Type one of the following options:

- “[Type of undeliverable mail] originally sent [date] received as undeliverable on [date] — resent to the client’s new address.” Also document if the original letter was a D-80-00-00 letter sent from Curam and if a N-70-00-00 or F-00-00-00 letter has been sent instead.

- “Notice of decision not resent to the client’s new address as the Notice of Debt was also undeliverable.”

- “Access code reissued.” Also document if the original letter was a I-10-00-00 letter sent from Curam and if a F-00-00-00 letter has been sent instead.

- Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- In Curam, document the actions taken as follows:

- Return to the Correspondence Failed – Undeliverable Mail task.

- Select Add Comments and type the appropriate option:

- “[Type of undeliverable mail] originally sent [date] received as undeliverable on [date] — resent to the client’s new address.” Also document if the original letter was a D-80-00-00 letter sent from Curam and if the N-70-00-00 or F-00-00-00 letter has been sent instead.

- “Notice of decision not resent to the client’s new address as the Notice of Debt was also undeliverable.”

- “Access code reissued.” Also document if the original letter was a I-10-00-00 letter sent from Curam and if a F-00-00-00 letter has been sent instead.

- Select Save .

- In Cúram, complete the task as follows:

- From the Correspondence Failed – Undeliverable Mail task, select the 3 dots ( … ) at the top right-hand corner of the screen.

- From the drop-down menu, select Complete .

- Select Yes .

- In NWS, determine if an AI WI exists for the Curam correspondence issue?

- If yes, complete the AI WI and go to step 17.

- If no, go to step 17.

- In NWS, determine if there are any other WIs on file for additional letters received as Undeliverable?

- If yes, action each impacted letter.

- If no, no further action required. 

#### New address unconfirmed or unknown

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/new_address_unconfirmed_or_unknown_level_1.dita`

- Determine if a new address for the client is unconfirmed or unknown:

- If the new address is unconfirmed, go to step 2.

- If the new address is unknown, go to step 3.

- In ACS, create and send the Q-01-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Information Requested Re: ROE / RFS / Undeliverable Mail / Additional Info required (2876)

- Undeliverable Mail Active/Inactive claim (2878): Select the appropriate option:

- Undeliverable Mail active claim

- Undeliverable Mail inactive claim

- Determine if the claim is active:

- If no, go to step 4.

- If yes, go to step 9.

- In Curam, determine if a 48 - Moved - address unknown (D48) disentitlement or a suspension - Stop payment due to undeliverable mail is imposed:

- If no, go to step 5.

- If yes, go to step 10.

- In Curam, impose a 48 - Moved - address unknown (D48) disentitlement as follows:

- From the Cases and Clients screen, select the Employment Insurance Program Benefits link to the appropriate Product Delivery Case.

- Select the Evidence tab from the navigation bar.

- Select New Evidence .

- From the Category drop-down menu, select All .

- From the Type menu, locate Return to Work and Disentitlements and select Add .

- From the Reason drop-down menu, select D48 - Moved - address unknown .

- Start Date: Enter the Monday of the next claimant’s report period.

- End Date: Indefinite - Enter BPC + 103..

- Enter all relevant details in the Comments field.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3311.dita)

- Apply the disentitlement as follows:

- From the Evidence Dashboard , select In Edit Evidence from the left-hand side menu.

- Select the 3 dots ( … ) on the right-hand side of the In Edit Evidence navigation bar (beside Open in New Tab ). From the drop-down menu, select Apply Changes .

- From the Apply Changes window, select D48 - Moved - address unknown disentitlement (be sure to select the correct disentitlement) and enter the following Overpayment (OP) Codes :

- Detection Code: Select 31- Other new facts - entitlement review .

- Infraction Code: Select B - Non-fraud - Availability, capability .

- Message Code: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Save .

- In Curam, create a Record of Decision as follows:

- From the Person Case, select Cases and Applications from the navigation bar and select the appropriate reference number.

- Select Notes from the left-hand side menu and then select New Note .

- From the New Note window, complete the following fields:

- Subject: Type “Undeliverable mail - D48 imposed.”

- Priority: Select Medium .

- Sensitivity: Select 1 .

- Text: Type “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] and the new address is [unconfirmed or unknown]. A valid address is required to maintain entitlement to benefits. A D48 will be imposed on [date].” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
                   [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In NWS, create and save an SROC as follows:

- Main Issue: Select Undeliverable mail .

- Comments: Type “Curam claim. Undeliverable mail - address unconfirmed.”

- Details: Type “Curam claim. [Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] and the new address is [unconfirmed or unknown]. A D48 has been imposed in Curam. Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3312.dita)

- In Curam, determine if a 15-Claim Procedure (D15) disentitlement is imposed:

- If no, go to step 10.

- If yes, go to step 14.

- In Curam, impose a 15 - Claim Procedure (D15) disentitlement as follows:

- From the Cases and Clients screen, select the Employment Insurance Program Benefits link to the appropriate Product Delivery Case.

- Select the Evidence tab from the navigation bar.

- Select New Evidence .

- From the Category drop-down menu, select All .

- From the Type menu, locate Return to Work and Disentitlements and select Add .

- From the Reason drop-down menu, select D15 - Claim Procedure .

- Start Date: Enter the Monday of the next claimant’s report period.

- End Date: Indefinite -Enter BPC + 103.

- Enter all relevant details in the Comments field.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3311.dita)

- Apply the disentitlement as follows:

- From the Evidence Dashboard , select In Edit Evidence from the left-hand side menu.

- Select the 3 dots ( … ) on the right-hand side of the In Edit Evidence navigation bar (beside Open in New Tab ). From the drop-down menu, select Apply Changes .

- From the Apply Changes window, select D15 - Claim Procedure disentitlement (be sure to select the correct disentitlement) and enter the following Overpayment (OP) Codes :

- Detection Code: Select 31- Other new facts - entitlement review .

- Infraction Code: Select B - Non-fraud - Availability, capability .

- Message Code: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Save .

- In Curam, create a Record of Decision as follows:

- From the Person Case, select Cases and Applications from the navigation bar and select the appropriate reference number.

- Select Notes from the left-hand side menu and then select New Note .

- From the New Note window, complete the following fields:

- Subject: Type “Undeliverable mail - D15 imposed.”

- Priority: Select Medium .

- Sensitivity: Select 1 .

- Text: Type “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] and the new address is [unconfirmed or unknown]. A valid address is required to maintain entitlement to benefits. A D15 will be imposed on [date].” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
                   [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Go to step 11.

- In NWS, create and save an SROC as follows:

- Main Issue: Select Undeliverable mail .

- Comments: Type “Curam claim. Undeliverable mail - address unconfirmed.”

- Details: Type “Curam claim. [Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] and the new address is [unconfirmed or unknown]. A D15 has been imposed in Curam.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3312.dita)

- In Curam, document the actions taken as follows:

- Return to the Correspondence Failed - Undeliverable Mail task.

- Select Add Comments and type “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] and the new address is [unconfirmed or unknown]. A [D48/D15] has been imposed in Curam.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- In Cúram, complete the task as follows:

- From the Correspondence Failed - Undeliverable Mail task, select the 3 dots ( … ) at the top right-hand corner of the screen.

- From the drop-down menu, select Complete .

- Select Yes .

- In NWS, determine if an AI WI exists for the Curam correspondence issue?

- If yes, complete the AI WI. Go to step 19.

- If no, go to step 19 .

- In NWS, determine if there are any other WIs on file for additional letters received as Undeliverable?

- If yes, action each impacted letter.

- If no, no further action required. 

#### Fraud indicators are present

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/fraud_indicators_are_present_level_1.dita`

- Determine if there is a CB WI or AI WI from Integrity on file that is directly related to the potentially fraudulent application:

- If there is only a CB WI on file, go to step 7.

- If there is an AI WI from Integrity indicating that the investigation is complete and the claim can proceed, return to step 1 of Reviewing the File.

- If neither is on file, go to step 2.

- Determine if the Correspondence Failed – Undeliverable Mail task is related to a renewal application:

- If yes, go to step 3.

- If it is related to an initial application, go to step 4.

- Determine if a suspension has already been imposed:

- If yes, go to step 7.

- If no, impose a suspension as follows:

- In Curam, impose a suspension to stop payments as follows:

- From the Product Delivery Cas e, select the 3 dots ( … ) from the upper right-hand corner of the screen.

- Select Suspend Case from the drop-down menu.

- From the Reason field, select Integrity Services Case from the drop-down menu.

- Select Save .

- Go to step 7.

- Determine if a 71-Integrity Services Case (D71) disentitlement has already been imposed:

- If no, go to step 5.

- If yes, go to step 7.

           [Important](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3313.dita)

- In Curam impose a D71 – Integrity Services Case (D71) disentitlement as follows:

- From the Cases and Clients screen, select the Employment Insurance Program Benefits link to the appropriate Product Delivery Case.

- Select the Evidence tab from the navigation bar.

- Select New Evidence .

- From the Category drop-down menu, select All .

- From the Type menu, locate Return to Work and Disentitlements and select Add .

- From the Reason drop-down menu, select D71 – Integrity Services Case.

- Enter the appropriate disentitlement dates in the Start Date and End Date fields.

- Enter all relevant details in the Comments field including the fraud indicators, letter type and whether the letter was returned as undeliverable or was rejected.

- Select Save .

- Apply the disentitlement as follows:

- From the Evidence Dashboard , select In Edit Evidence from the left-hand side menu.

- Select the 3 dots ( … ) on the right-hand side of the In Edit Evidence navigation bar (beside Open in New Tab ). From the drop-down menu, select Apply Changes .

- From the Apply Changes window, select Other Disentitlements (be sure to select the correct disentitlement) and enter the following Overpayment (OP) Codes :

- Detection Code: Select 31- Other new facts – entitlement review .

- Infraction Code: Select F- Non-fraud – Other .

- Message Code: Select 3 – An overpayment resulted due to a definite disentitlement .

- Select Save.

- In NWS, create and save a SROC as follows:

- Main Issue: Select Undeliverable mail .

- Comments: Type “Curam claim. Refer to Integrity.”

- Details: Type “[Type of undeliverable mail] initially sent on [DD-MM-YYYY] was received as undeliverable on [DD-MM-YYYY] — ongoing investigation.” Document the relevant details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3314.dita)

- In Curam, document the actions taken as follows:

- From the Correspondence Failed – Undeliverable Mail task, select Add Comments .

- Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file]. No attempt was made to contact the client due to the presence of fraud indicators. The application process is suspended until the end of the investigation.”

- Complete the Correspondence Failed – Undeliverable Mail task as follows:

- From the Task homepage, select the 3 dots ( … ) at the top right-hand corner of the screen.

- From the drop-down menu, select Complete .

- Select Yes .

- In NWS, refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue: Select Undeliverable mail .

- Comments: Type “Suspected fraud — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file]. No attempt was made to contact the client due to the presence of fraud indicators. The application process is suspended until the end of the investigation.”

- Select Save .

- No further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_3310.dita`

Note:

If the undeliverable mail is a D-80-00-00 letter, the officer attempts to create and send the N-70-00-00 letter to communicate the claim details with the client. If the N-70-00-00 letter does not contain all of the necessary attributes, the officer creates and sends the F-00-00-00 letter instead. 

#### Note

Source topic: `en_EN/common_notes/note_c_1520.dita`

Note:

If working from home, refer to Telework: Printing documents locally — Instructions to reprint the letter and send it in an envelope addressed to the client’s new address.
       [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml)

     [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_3311.dita`

Note:

Currently, Curam is unable to accept an indefinite disentitlement. As a temporary work around, officers enter BPC + 103. 

#### Note

Source topic: `en_EN/common_notes/note_c_3312.dita`

Note:

At this time, SROCs must be created and saved in NWS for all actions completed in Curam. 

#### Important

Source topic: `en_EN/common_notes/note_c_3313.dita`

Important:

Before imposing a D71, confirm that the file does not already include one. In such cases, if a transaction is entered to impose a D71, the existing D71 will be cancelled. 

#### Note

Source topic: `en_EN/common_notes/note_c_3314.dita`

Note:

At this time, SROCs must be created and saved in NWS to document all actions completed in Curam. 

## Policy reference

Source topic: `en_EN/task/echec-lie-corres-cour-nl-corresp-failed-um/policy_reference.dita`

 
