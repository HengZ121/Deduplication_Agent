# Adjudicating client or third party misrepresentation — Monetary penalty or warning letter

Source map: `en_EN/task/iam_dmp_wlac/iam_dmp_wlac.ditamap`

## Summary

Source topic: `en_EN/task/iam_dmp_wlac/summary.dita`

Summary: An administrative penalty (monetary or warning letter) must be imposed if a client or a third party acting on behalf of the client makes a misrepresentation for which neither the voluntary disclosure policy nor prosecution is applicable. 

## What you need to know

Source topic: `en_EN/task/iam_dmp_wlac/what_you_need_to_know.dita`

### Adjudicating misrepresentation — Determining the penalty

Source topic: `en_EN/task/iam_dmp_wlac/adjudicating_misrepresentation__determi_d589cb2a.dita`

The first step in a case of misrepresentation is determining if a penalty must be imposed. 

### Imposing a monetary penalty

Source topic: `en_EN/task/iam_dmp_wlac/imposing_a_monetary_penalty.dita`

A monetary penalty is an administrative fine imposed under EIA 38 if a client or third party attempted to obtain or was actually paid benefits as a result of misrepresentation. A penalty is distinct from an overpayment (OP). The calculation of a penalty is progressive. Repetitive misrepresentation is subject to more severe consequences, including higher penalties. The purpose of a penalty is to discourage further abuse of the EI program.
       [EIA 38](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-38.html)

**Calculating the timeframe to impose a monetary penalty**

A monetary penalty may be imposed up to 36 months after the misrepresentation. Processing and postal delays must be taken into consideration when determining whether the misrepresentation falls within the 36-month limitation period.

For an active or terminated (non-blocked) claim, add one week (for notification) to the current w/c and subtract 156 weeks (36 months). If the misrepresentation occurred in that week or later, a monetary penalty can be imposed.

For a blocked claim where the input is completed using BCS, the OP is established the same way as an active claim. When BCS calculates the OP, a Penalty link is available and a Penalty determination window opens to assist with the calculation of the 156 weeks.

For a blocked or archived claim that requires IPOC intervention, the officer must first determine if there is an IPOC backlog. Some regions have access to weekly IPOC updates on their workloads. The officer adds one week (for notification) plus the IPOC backlog weeks to the current w/c and subtracts 156 weeks. If the misrepresentation occurred in that week or later, a monetary penalty can be imposed. 

### Calculating the penalty based on the net overpayment (OP)

Source topic: `en_EN/task/iam_dmp_wlac/calculating_the_penalty_based_on_the_ne_2aee99c1.dita`

The penalty amount is calculated based on:

- the net OP amount from the misrepresentation

- the level of the misrepresentation

- mitigating circumstances

**Determining the net overpayment (OP)**

The net OP is the dollar value of all OP(s) less the value of any underpayments resulting from the misrepresentation. Only the net OP within the 36-month time limit is used to calculate the penalty amount.

The OP for each week containing a misrepresentation is calculated by subtracting the benefits that should have been paid to the client from the benefits that were paid to the client.

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3488.dita) 

**Determining the number of misrepresentations**

An application for benefits, a record of interview, a completed claimant’s report or direct deposit are each considered one misrepresentation even though they may contain several false or misleading statements within them.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3489.dita) 

The submission of a false ROE or an ROE containing false or misleading information is also considered one misrepresentation.

Clients exempt from completing claimant’s reports under EIR 26.1(2) are advised to report any earnings or entitlement-related issues that may impact benefits. If an investigation reveals that the client knowingly failed to do so, each payment received in error by paper cheque or direct deposit is considered one misrepresentation.
       [EIR 26.1(2)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-26.1.html)

If the client received payments by paper cheque, each cheque cashed can be considered a misrepresentation under EIA 38(1)(e). If the client received payments by direct deposit, each direct deposit payment or any excess amount the client received and did not return can be considered a misrepresentation under EIA 38(1)(f).

Example:

A client was exempt from reporting and received 6 payments. The client was not available during the period of the payments but did not report the non-availability. This is determined to be a false statement.

```text
| If payments were received by paper cheque, each cheque cashed is one misrepresentation (EIA 38(1)(e)). | If payments were received by direct deposit, each payment received and not returned is one misrepresentation (EIA 38(1)(f)). |

| Total misrepresentations = 6 | Total misrepresentations = 6 |
```

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3490.dita) 

**Level of misrepresentation**

The level of misrepresentation sets a maximum penalty based on a percentage of the net OP.

```text
| Level of misrepresentation | Maximum penalty |

| First | up to 50% of the net OP |

| Second | up to 100% of the net OP |

| Third or more | up to 150% of the net OP |
```

The level of misrepresentation is determined by the highest level of the penalty imposed before the reconsidered period and not by the number of decision notices sent to the client or third party.

**Determining the level of misrepresentation**

The notification date of a previous penalty, warning letter, or prosecution judgment is used to determine the level of the current misrepresentation. The notification date is deemed to be the Saturday of the week following the date on the penalty notice, warning letter or the prosecution judgment date.

If the client or third party was not notified of a sanction within the last 260 weeks, the current investigation is assessed as a first level misrepresentation.

If the current misrepresentation occurred after the client or third party was notified of a sanction for a first level misrepresentation within the last 260 weeks, this would be considered a second level misrepresentation.

Similarly, if the current misrepresentation occurred after the client or third party was notified of a sanction for a second level misrepresentation within the last 260 weeks, this would be considered a third level misrepresentation.

Example

First investigation on February 13, 2013 (w/c 1860)

```text
| BPC | 1805 |

| Reconsidered period | w/c 1840 to 1843 |

| Net OP based on 2 misrepresentations | $600 |

| Information in PSCD | None |
```

Penalty is calculated as follows:

```text
| Level of misrepresentation | First |

| Mitigating circumstances | 10% |

| Penalty = (50 – 10)% × $600 | $240 |

| Notice of decision (2 misrepresentations) | February 13, 2013 (w/c 1860) |

| Notification date | February 23, 2013 (w/c 1861) |
```

Second investigation on July 10, 2013 (w/c 1880)

```text
| BPC | 1850 |

| Reconsidered period | w/c 1851 to 1857 |

| Net OP based on 3 misrepresentations | $800 |

| Information in PSCD: Notification date | w/c 1861 |
```

Penalty is calculated as follows:

```text
| Level of misrepresentation | First |

| Mitigating circumstances | None |

| Penalty = 50% × $800 | $400 |

| Notice of decision (3 misrepresentations) | July 3, 2013 (w/c 1880) |

| Notification date | July 13, 2013 (w/c 1881) |
```

Third investigation on September 27, 2013 (w/c 1892)

```text
| BPC | 1850 |

| Reconsidered period | w/c 1870 to 1875 |

| Net OP based on 3 misrepresentations | $800 |

| Information in PSCD: Notification date | w/c 1861 and 1881 |
```

Penalty is calculated as follows:

```text
| Level of misrepresentation | Second |

| Mitigating circumstances | 25% |

| Penalty = (100 – 25)% × $800 | $600 |

| Notice of decision (3 misrepresentations) | September 27, 2013 (w/c 1892) |

| Notification date | October 5, 2013 (w/c 1893) |
```

Fourth investigation on January 15, 2014 (w/c 1908)

```text
| BPC | 1878 |

| Reconsidered period | w/c 1897 to 1901 |

| Net OP based on 2 misrepresentations | $700 |

| Information in PSCD: Notification date | w/c 1861, 1881, and 1893 |
```

Penalty is calculated as follows:

```text
| Level of misrepresentation | Third |

| Mitigating circumstances | 20% |

| Penalty = (150 – 20)% × $700 | $910 |

| Notice of decision | January 15, 2014 (w/c 1908) |

| Notification date | January 25, 2014 (w/c 1909) |
```

In this example, since the weeks involved in the second investigation (w/c 1851 to 1857) are before the notification date of the first penalty (w/c 1861), the second investigation is deemed a first level misrepresentation for the purpose of calculating the penalty.

The third investigation is considered as a second level misrepresentation for the calculation of the penalty because the reconsidered weeks (w/c 1870 to 1875) are after the notification date of the first penalty (w/c 1861) which was a first level misrepresentation.

The fourth investigation is considered as third level misrepresentation for the calculation of the penalty because the reconsidered weeks (w/c 1897 to 1901) are after the notification date of the third penalty (w/c 1893) which was a second level misrepresentation.

There may be cases where the client, employer or third party is in the process of appealing an earlier decision. If, in the meantime, a second investigation is launched for misrepresentation covering a period after the notification date of the decisions being appealed, this misrepresentation is nevertheless deemed repetitive. This does not change until all the steps of the appeal process have been completed and the decision being appealed is no longer considered as misrepresentation. When the final appeal decision is implemented, all subsequent decisions must be amended accordingly.

**Mitigating circumstances**

The Level 2 officer must review all documents, facts and information on file to determine whether there are mitigating circumstances that could reduce the sanction for the misrepresentation. The existence of mitigating circumstances must never be assumed. There must be a clear indication that such circumstances exist. Mitigating circumstances usually relate to the time when the misrepresentation occurred, but there are some that may exist up to and including the time the case is being reviewed by an adjudicator or even after the decision has been reached.

Many situations or factors may be considered as mitigating circumstances. The adjudicator must take the client’s or third party’s particular situation into consideration. The following is not an exhaustive list.

**Considering factors for mitigating circumstances**

Illness:

- Illness of family member

- medical circumstances

- state of mental illness or depression

- stress

Financial:

- other debt obligations

- consequences of repayment

- ability to pay

- penalty must reflect socio-economic status

Emotional:

- death of a close friend

- death of spouse

- marital problem

Addiction:

- gambling addiction

- drug addiction

- alcoholism

Other:

- honesty and remorse

- new immigrant, unfamiliar with system

- physical

**Taking into consideration other potential situations**

- The under-reported earnings were only marginally above the allowable earnings and the OP of benefits is minimal.

- The person failed to take reasonable care and did not accurately fill out multiple claimant’s reports completed at the same time.

- Although monies were under-reported, the employer’s pay period was not on a calendar week basis, making accurate declaration of earnings difficult to compute.

- The unreported earnings were for one claimant’s report period during a longer period of correctly reported earnings.

- The person had to estimate employment earnings when completing the claimant’s report and under-reported the amount earned. The evidence on the file supports that this was a genuine error that occurred while making a good-faith effort to accurately report the work and earnings.

- The person reported net versus gross earnings, even if this occurred on multiple claimant’s reports, the evidence indicates this was a genuine error or misunderstanding, or no evidence contradicts the person’s representation of genuine error or misunderstanding.

- The person failed to report a single week of employment and there is no prior misrepresentation.

- The claimant’s reports were completed a long time after the period covered making accurate reporting more difficult, although not unreasonably so.

- The person did not report the first days or first week of a new job either on the appropriate or a subsequent claimant’s report but ceases to complete claimant’s reports or declares employment for subsequent weeks.

- The person failed to declare earnings to offset a cash shortage caused by a lengthy delay on our part in issuing benefits.

- The client, acting on the advice of a third party not familiar with the EI program, made a false statement which would not have occurred had he or she contacted a Service Canada centre.

- The person reported one week of employment although both weeks were worked, on a 2-week claimant’s report, even if this occurred on multiple claimant’s reports, the evidence indicates this was a genuine error or misunderstanding, or no evidence contradicts the person’s representation of genuine error or misunderstanding.

- The file reveals prior problems in completing claimant’s reports although such misunderstanding does not justify the false statements completely.

A percentage value is assigned to the mitigating circumstances. The maximum percentage value based on the level of misrepresentation is reduced by the percentage value of the mitigating circumstances when calculating the penalty amount. 

### Calculating the penalty

Source topic: `en_EN/task/iam_dmp_wlac/calculating_the_penalty.dita`

```text
| Level of misrepresentation | Penalty calculation |

| First | (50% – % assigned to mitigating circumstances) × net OP |

| Second | (100% – % assigned to mitigating circumstances) × net OP |

| Third or more | (150% – % assigned to mitigating circumstances) × net OP |
``` 

### Calculating the penalty cap per benefit period (BP)

Source topic: `en_EN/task/iam_dmp_wlac/calculating_the_penalty_cap_per_benefit_5dc4e5e4.dita`

There are also penalty limits per BP that must be considered. The penalty cap is per BP and is not based on the total OP when it spans more than one BP. The total penalty amount that can be assessed per BP relative to the level of misrepresentation is limited as follows:

**Level of misrepresentation**

```text
| Level of misrepresentation | Maximum penalty per BP |

| First | $5 000 |

| Second | $8 000 |

| Third or more | $10 000 |
```

In addition to the limit restriction for each level, consideration must also be given to the amount of penalty already imposed on the BP. The Debt Information - Account Balance section of the Debtor Overview screen in PSCD indicates the previously imposed initial penalty amounts. These amounts are used to calculate the maximum penalty amount per BP due to the penalty cap.

Example 1

First investigation on September 18, 2012 (w/c 1839)

```text
| BPC | 1805 |

| Reconsidered period | w/c 1817 to 1833 |

| Net OP based on 16 misrepresentations | $12 552 |

| Information in PSCD: | None |
```

Penalty is calculated as follows:

```text
| Level of misrepresentation | First |

| Maximum limit for BPC 1805 | $5 000 |

| Mitigating circumstances | 10% |

| Penalty = (50 – 10)% × $12 552 | $5 020.80 |

| Maximum penalty imposed | $5 000 |

| Notice of decision (16 misrepresentations) | September 18, 2012 (w/c 1839) |

| Notification date | September 29, 2012 (w/c 1840) |
```

Second investigation on February 12, 2013 (w/c 1860)

```text
| BPC | 1805 |

| Reconsidered period | w/c 1841 to 1843 |

| Net OP based on 2 misrepresentations | $700 |

| Information in PSCD: Notification date | w/c 1861 |
```

Penalty is calculated as follows:

```text
| Level of misrepresentation | Second |

| Maximum limit for BPC 1805 | $8 000 |

| Mitigating circumstances | None |

| Penalty = (100 – 0)% × $700 | $700 |

| Penalty imposed | $700 |

| Notice of decision (2 misrepresentations) | February 12, 2013 (w/c 1860) |

| Notification date | February 23, 2013 (w/c 1861) |
```

Third investigation on September 25, 2013 (w/c 1892)

```text
| BPC | 1850 |

| Reconsidered period | w/c 1870 to 1875 |

| Net OP based on 6 misrepresentations | $2 000 |

| Information in PSCD: Notification date | w/c 1861 and 1881 |
```

Penalty is calculated as follows:

```text
| Level of misrepresentation | Third |

| Mitigating circumstances | None |

| Maximum limit for BPC 1850 | $10 000 |

| Penalty = (150 – 0)% × $2,000 | $3 000 |

| Penalty imposed | $3 000 |

| Notice of decision (6 misrepresentations) | September 25, 2013 (w/c 1892) |

| Notification date | October 5, 2013 (w/c 1893) |
```

In this example, the calculated penalty amount for the first investigation was rounded to the nearest dollar ($5 021), but since this is a first level misrepresentation, the maximum limit for BPC 1805 is $5 000. Therefore, a $5 000 penalty was imposed instead of $5 021.

If a new investigation is conducted on BPC 1805 and the misrepresentation occurred in w/c 1840 or earlier, a warning letter is sent to the client. The maximum authorized penalty amount for a first level misrepresentation has already been reached.

The second investigation discovered a second level misrepresentation. The maximum penalty amount for BPC 1805 was calculated as follows:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3491.dita) 

The third investigation revealed a third level misrepresentation. The maximum penalty amount for a third level misrepresentation is $10 000 per BP. No other penalties have been imposed on BPC 1850.

Example 2

First investigation on September 18, 2012 (w/c 1839)

```text
| BPC | 1772 and 1805 |

| Reconsidered period | w/c 1782 to 1822 |

| Net OP based on 8 misrepresentations | $6 800 (BPC 1772) |

| Net OP based on 9 misrepresentations | $7 650 (BPC 1805) |

| Information in PSCD: | None |
```

Penalty is calculated as follows:

```text
| Level of misrepresentation | First |

| Maximum limit for BPC 1772 | $5 000 |

| Maximum limit for BPC 1805 | $5 000 |

| Mitigating circumstances | None |

| Penalty (50 – 0)% × $6 800 | $3 400 (BPC 1772) |

| Penalty (50 – 0)% × $7 650 | $3 825 (BPC 1805) |

| Penalty imposed | $3 400 (BPC 1772) |

| Penalty imposed | $3 825 (BPC 1805) |
```

In this example, the misrepresentation spans 2 BPs. Since the penalty cap is per BP, a penalty is imposed at 50% of the net OP for each BP, regardless of the fact that the total penalty amount exceeds $5,000. 

### Calculating the legal validation amount

Source topic: `en_EN/task/iam_dmp_wlac/calculating_the_legal_validation_amount.dita`

In some situations, the calculated penalty amount exceeds the maximum indicated by EIA 38(2) . To respect this limitation, the penalty amount must be reduced to 3 times the client’s weekly benefit rate for each misrepresentation. If the BP was not established, the maximum benefit rate that was in effect when the misrepresentation occurred is used to calculate the legal validation amount.
       [EIA 38(2)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-38.html)

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3492.dita) 

### Exceptions to penalty calculation

Source topic: `en_EN/task/iam_dmp_wlac/exceptions_to_penalty_calculation.dita`

There are 3 exceptions where the penalty is calculated based on the benefit rate rather than the net OP:

- When a claim is cancelled (BPNE).

- When a subsequent investigation reveals that the misrepresentation occurred during a period already covered by the first penalty and for which no OP can be created.

- When an ROE is knowingly altered and the misrepresentation is identified before benefits are paid. 

### Calculating a penalty on a BPNE claim

Source topic: `en_EN/task/iam_dmp_wlac/calculating_a_penalty_on_a_bpne_claim.dita`

Even though no benefits are paid on a BPNE, a penalty under EIA 38(2)(c) may still be assessed. Because no benefit rate is determined on a BPNE, the penalty is based on the maximum benefit rate in effect at the time the misrepresentation was committed. The penalty is calculated as follows:
       [EIA 38(2)(c)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-38.html) 
       [maximum benefit rate](/en/procedure/generic/additionalresources/max_ben_rate_mwie.shtml)

**Calculating the penalty**

```text
| Level of misrepresentation | Penalty calculation | Maximum penalty per BP |

| First | (100% – % for mitigating circumstances) × Maximum benefit rate × Number of misrepresentations | $5 000 |

| Second | (200% – % for mitigating circumstances) × Maximum benefit rate × Number of misrepresentations | $8 000 |

| Third or more | (300% – % for mitigating circumstances) × Maximum benefit rate × Number of misrepresentations | $10 000 |
```

In the case of a BPNE claim, the claimant’s report is never considered as a misrepresentation. However, in all other situations where a claim was established, each payment received by the client can be considered a misrepresentation.

If the client received payments by paper cheque, each cheque cashed can be considered a misrepresentation under EIA 38(1)(e). If the client received payments by direct deposit, each direct deposit payment or any excess amount the client received and did not return can be considered a misrepresentation under EIA 38(1)(f) .
       [EIA 38(1)(f)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-38.html#216536)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3493.dita) 

Example:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3494.dita) 

### Subsequent investigation for the same period — No overpayment (OP) created

Source topic: `en_EN/task/iam_dmp_wlac/subsequent_investigation_for_the_same_p_289bc14f.dita`

Occasionally, a subsequent investigation reveals that a misrepresentation was made during the same period covered by an earlier penalty. Since the OP was established based on a prior decision, the new misrepresentation will not result in an OP.

In these situations, the penalty is imposed on the new decision, taking into account the penalty that could have been imposed on the first decision had all the facts been known at the time.

Example

First investigation: Unreported voluntary leaving

```text
| BPC | w/c 1839 |

| Benefit rate | $300 |

| Indefinite D11 | Starting w/c 1839 |

| OP | $6 000 |

| Level of misrepresentation | First |

| Mitigating circumstances | None |

| Penalty imposed | $900 |

| Notification date | w/c 1867 |

| Second investigation | Unreported earnings |

| Earnings applied | w/c 1844 to 1853 |

| Number of misrepresentations | 5 |

| OP | None |

| Level of misrepresentation | First |

| Mitigating circumstances | None |

| Penalty imposed | $2 100 |
```

The first investigation resulted in a $6 000 OP but only a $900 penalty due to the legal validation:

3 × (one misrepresentation × $300) = $900

Since the second investigation involves 5 new misrepresentations for the same period covered in the previous decision, a penalty may be imposed taking into account the initial $6 000 OP.

The penalty amount is calculated as follows: 50% of $6 000 = $3 000

Legal validation: 6 misrepresentations × rate ($300) × 3 = $5 400

Since the calculated penalty amount ($3 000) is less than the legal validation ($5 400), the penalty amount to be imposed for the second investigation is:

$3 000 – $900 (the first penalty amount) = $2 100 

### ROE knowingly altered and the misrepresentation is identified before benefits are paid

Source topic: `en_EN/task/iam_dmp_wlac/roe_knowingly_altered_and_the_misrepres_7bfffbdc.dita`

A client may submit an ROE on which the reason for separation (RFS) was knowingly altered, but the misrepresentation was identified before any benefits are paid. The claim is established with a benefit rate, but no benefits are paid because of the disqualification, so no OP occurs.

Since there is no OP, the penalty is calculated as follows:

Calculating the penalty

```text
| Level of misrepresentation | Penalty calculation (RFS knowingly altered) |

| First | (100% – % for mitigating circumstances) × actual benefit rate × 2 misrepresentations (one count for the application and one count for the ROE) |

| Second | (200% – % for mitigating circumstances) × actual benefit rate × 2 misrepresentations (one count for the application and one count for the ROE) |

| Third or more | (300% – % for mitigating circumstances) × actual benefit rate × 2 misrepresentations (one count for the application and one count for the ROE) |
```

The application and ROE are considered a misrepresentation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3495.dita) 

Example:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3496.dita) 

When the misrepresentation spans more than one BP, the legal validation calculation must be applied separately to each BP. 

### Issuing a warning letter

Source topic: `en_EN/task/iam_dmp_wlac/issuing_a_warning_letter.dita`

According to EIA 41.1 , a warning letter can be issued instead of imposing a monetary penalty. Warning letters are considered a penalty within the meaning of the EI legislation, but do not carry the greater consequence of a monetary sanction.
       [EIA 41.1](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-41.1.html)

Warning letters can be issued up to 72 months after the misrepresentation. Processing and postal delays must be taken into consideration when determining whether the misrepresentation falls within the 72-month limitation period.

When determining if a decision resulting in an OP can be input and a warning letter can be issued, the officer adds one week (for notification) to the current w/c and subtract 312 weeks (72 months). If the misrepresentation occurred in that week or later, the officer issues a warning letter.

When inputs must be done with IPOC intervention, the officer first determines if there is an IPOC backlog. The officer adds one week (for notification) plus the IPOC backlog weeks to the current w/c, and subtracts 312 weeks. If the misrepresentation occurred in that week or later, the officer issues a warning letter.

A warning letter is issued when:

- Mitigating circumstances make a monetary penalty punitive.

- The misrepresentation occurred more than 36 months ago and the time limit to impose a penalty has passed.

- The penalty amount to be imposed is less than $20. 

### Third party misrepresentation

Source topic: `en_EN/task/iam_dmp_wlac/third_party_misrepresentation.dita`

Third parties can act on behalf of a client or on their own behalf using the information or identity of another individual.

When a third party makes a misrepresentation with neither the knowledge nor consent of a client, the third party is responsible for the resulting net OP and is subject to any applicable sanctions imposed for the misrepresentation.

When a third party makes a misrepresentation with both the client’s knowledge and consent, it is considered collusion between the client and third party. In this situation, the client must repay the net OP and any applicable sanction can be imposed on both the client and the third party. 

### Discretionary decision

Source topic: `en_EN/task/iam_dmp_wlac/discretionary_decision.dita`

A determination of misrepresentation and the resulting sanction is a discretionary decision. This means the Commission must consider any information provided and show how it concludes that the misleading statement was made knowingly. The Commission must be able to explain why facts are relevant or irrelevant. In the case of a monetary penalty, the record of decision (ROD) must clearly show how the penalty amount was calculated. 

### Callout

Source topic: `en_EN/common_notes/note_c_3488.dita`

OP = benefits paid – benefits that should have been paid 

### Note

Source topic: `en_EN/common_notes/note_c_3489.dita`

Note:

For BPCs of 2063 and after, all payments will be listed as one-week payments in FTS. However, there is no change in how an officer counts false statements on biweekly claimant’s reports. One claimant’s report constitutes one count of false statements, even if the client receives 2 payments for one biweekly claimant’s report. 

### Note

Source topic: `en_EN/common_notes/note_c_3490.dita`

Note:

For BPCs of 2063 and after, all payments will be listed as one-week processed payments in FTS. Effective April 10, 2017, all individual payments processed by the CPS will be combined into one payment issued to the client. However, there is no change in how an officer counts misrepresentations on biweekly claimant’s reports. One claimant’s report constitutes one count of false statement, even if the client receives 2 payments for one biweekly claimant’s report or receives one payment for two or more bi-weekly claimant’s reports processed at the same time.

A series of 2-week claimant’s reports are processed automatically for clients who are exempt from completing claimant’s reports. The payments are shown in FTS, but the claimant’s reports are not. When counting misrepresentations, the officer considers both paper cheques and direct deposits starting from the BPC and counting every 2-week period as one claimant’s report and one payment. If the claim ends with only a single weekly payment processed in the final week, that single week counts as one claimant’s report and one payment. 

### Callout

Source topic: `en_EN/common_notes/note_c_3491.dita`

Penalty cap per BPC for a second level misrepresentation $8 000

Subtract the total amount of penalties already imposed on BPC 1805 – $5 000

Maximum penalty amount for BPC 1805 $3 000 

### Callout

Source topic: `en_EN/common_notes/note_c_3492.dita`

- The client failed to declare that he or she voluntarily left employment on September 22, 2012 (w/c 1839) on the claimant’s report commencing September 16, 2012 (w/c 1839).

- Thereafter, the client received 10 weeks of benefits at a rate of $300 per week.

- As a result of the disqualification input, a net OP of $3 000 was established.

- First misrepresentation, a 5% reduction was allowed due to mitigating circumstances.

- The penalty amount is determined as follows:

- First misrepresentation: 45% of $3 000 = $1 350

- Only one misrepresentation was committed, that is having failed to declare the voluntary leaving.

In accordance with EIA 38(2) , the penalty cannot exceed 3 times the client’s weekly rate of benefit for each misrepresentation:
       [EIA 38(2)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-38.html)

3 × $300 × one misrepresentation = $900

Therefore, the penalty to impose must be $900.00, not $1 350.00.

The legal validation calculation must be applied separately to each BP when the misrepresentation spans more than one BP. 

### Note

Source topic: `en_EN/common_notes/note_c_3493.dita`

Note:

For BPCs of w/c 2063 and after, all payments will be listed as one-week payments in FTS, even though the claimant’s reports are processed biweekly. Therefore, officers count each pair of payments listed as one payment and one false statement based on one claimant’s report. 

### Callout

Source topic: `en_EN/common_notes/note_c_3494.dita`

In July 2012, a client attempted to collect benefits by filing:

- a false ROE

- an application for benefits containing false or misleading information

- 3 claimant’s reports (no benefits paid)

In July 2012, the maximum weekly benefit rate was $501. This was the client’s first incident of misrepresentation. The client provided mitigating circumstances that warrant a 30% reduction in the penalty amount.

In this example, the client made 2 misrepresentations, one by submitting the false ROE and one by completing the application for benefits.

The penalty amount is calculated as:

(100 – 30)% × $501 × 2 = $701

If the claim had been established and the client received 3 payments for the 3 claimant’s reports, there would be 5 misrepresentations: one for the false ROE, one for the application, and 3 for the payments received. In that case, the penalty amount would be calculated as:

(100 – 30)% × $501 × 5 = $1 754 

### Note

Source topic: `en_EN/common_notes/note_c_3495.dita`

Note:

If adjudication of the RFS results in no disqualification, the misrepresentation must still be adjudicated. 

### Callout

Source topic: `en_EN/common_notes/note_c_3496.dita`

In July 2022, a client attempted to collect benefits by filing a false ROE.

In July 2022, the maximum weekly benefit rate was $638. This was the client’s first incident of misrepresentation. The client provided no mitigating circumstances that warrant a reduction in the penalty amount.

In this example, the client made 2 misrepresentations, one by submitting the false ROE and one by completing the application for benefits.

The penalty amount is calculated as:

(100 – 0)% × $638 × 2 = $1276

Example

```text
| BPC | w/c 2350 |

| Benefit rate | $638 |

| First investigation | Unreported voluntary leaving |

| Indefinite D11 | Starting w/c 2350 |

| OP | None |

| Level of misrepresentation | First |

| Mitigating circumstances | None |

| Penalty imposed | $1276 |
``` 

## Regional considerations

Source topic: `en_EN/task/iam_dmp_wlac/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/iam_dmp_wlac/what_you_need_to_look_for.dita`

### In ACS:

Source topic: `en_EN/task/iam_dmp_wlac/in_acs.dita`

- On what date was a previous notice of misrepresentative decision sent to the client or third party? 

### In PSCD:

Source topic: `en_EN/task/iam_dmp_wlac/in_pscd.dita`

- On the Debtor Overview screen, in the Debt Information - Account Balance section:

- Are there any debts (OP or penalty) with infraction code U, V, W, X, Y or Z (misrepresentation) that have been established within the past 260 weeks?

- What is the OP or penalty document date?

- What are the initial amounts of any previous penalties? 

### In FTS:

Source topic: `en_EN/task/iam_dmp_wlac/in_fts.dita`

- Does the misrepresentation involve multiple BPs?

- On which BPC, and in which week(s), did the misrepresentation(s) occur?

- Did the person complete claimant’s reports or was the person exempt from reporting?

- Was the client paid by paper cheque or direct deposit?

- What was the client’s weekly benefit rate on the BPC containing the misrepresentation?

- For the weeks involved in the misrepresentation, what amount of benefits was paid to the client? What amount should have been paid?

- Was or will the claim be cancelled (BPNE) as a result of the reconsideration related to the misrepresentation?

- Is the claim, on which the misrepresentation was made, active or terminated (non-blocked)?

- Is the claim, on which the misrepresentation was made, blocked or archived?

- If the claim is blocked, what is the claim status in BCS? 

### In Imaging:

Source topic: `en_EN/task/iam_dmp_wlac/in_imaging.dita`

- Is there any document containing mitigating circumstances? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/iam_dmp_wlac/in_integrity_investigations_document_up_6a8da64b.dita`

- Is there any document containing mitigating circumstances? 

### In NIIS:

Source topic: `en_EN/task/iam_dmp_wlac/in_niis.dita`

- On the Subject Enquiry (IC07) screen, are there prior cases for which a penalty was imposed?

- Was the misrepresentation made by a third party on behalf of the client?

- If yes, was it made with the knowledge and consent of the client?

- Is there an Integrity Investigation Sheet? If so, does it contain mitigating circumstances?

- Is there a Report of Interview? If so, does it contain a misrepresentation or mitigating circumstances? 

### In NWS:

Source topic: `en_EN/task/iam_dmp_wlac/in_nws.dita`

- Was a misrepresentation made on the application for benefits?

- Does any of the electronic claim documentation indicate mitigating circumstances? 

## Step by step

Source topic: `en_EN/task/iam_dmp_wlac/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/iam_dmp_wlac/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/iam_dmp_wlac/reviewing_the_file_level_2.dita`

- Determine if you are within the 36-month time limit defined by EIA 40(b) to impose a monetary penalty for the misrepresentation:

- If within the 36-month time limit, go to Misrepresentation within 36 months — Penalty or warning letter .
               [Misrepresentation within 36 months — Penalty or warning letter](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/iam_dmp_wlac#within36)

- If not within the 36-month time limit, go to Misrepresentation after 36 months — Warning letter .
               [Misrepresentation after 36 months — Warning letter](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/iam_dmp_wlac#beyond36) 

#### Misrepresentation within 36 months — Penalty or warning letter

Source topic: `en_EN/task/iam_dmp_wlac/misrepresentation_within_36_months__pen_217054b3_level_2.dita`

- Consider the net OP resulting from the misrepresentation (within the 36-month time limit).

- Count the number of misrepresentations (false or misleading statements made knowingly).

- Determine the current level of misrepresentation.

- Identify any mitigating circumstances that warrant a reduction to the penalty amount and determine the percentage by which the penalty will be reduced.

- Determine if the RFS has been knowingly altered before benefits were paid:

- If yes, determine the penalty amount as follows:

```text
| Level of misrepresentation | Penalty calculation (RFS knowingly altered) |

| First | (100% – % for mitigating circumstances) × actual benefit rate × 2 misrepresentations (one count for the application and one count for the ROE) |

| Second | (200% – % for mitigating circumstances) × actual benefit rate × 2 misrepresentations (one count for the application and one count for the ROE) |

| Third or more | (300% – % for mitigating circumstances) × actual benefit rate × 2 misrepresentations (one count for the application and one count for the ROE) |
```

- If no, go to step 7.

- Determine if the claim is BPNE or will be made BPNE as a result of the misrepresentation:

- If yes, determine the penalty amount as follows:

```text
| Level of misrepresentation | Penalty calculation (BPNE) |

| First | (100% – % for mitigating circumstances) x maximum benefit rate x number of misrepresentations |

| Second | (200% – % for mitigating circumstances) x maximum benefit rate x number of misrepresentations |

| Third or more | (300% – % for mitigating circumstances) x maximum benefit rate x number of misrepresentations |
```

- If no, determine the penalty amount as follows:

```text
| Level of misrepresentation | Penalty calculation |

| First | (50% – % for mitigating circumstances) x net OP |

| Second | (100% – % for mitigating circumstances) x net OP |

| Third or more | (150% – % for mitigating circumstances) x net OP |
```

- Determine the maximum penalty amount that can be applied to this BPC:

- In PSCD, on the Debtor Overview screen, review the Debt Information - Account Balance section to obtain the prior penalty amounts established on this BPC (if any).

- Consider the level of misrepresentation determined in step 4:

```text
| Level of misrepresentation | Maximum penalty per BP |

| First | $5 000 |

| Second | $8 000 |

| Third or more | $10 000 |
```

- Calculate the maximum penalty amount for this BPC as follows:
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3497.dita)

- Determine the legal validation amount as follows:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3498.dita)

- Determine the actual penalty amount to impose (rounded to the nearest dollar). The penalty amount will be the lesser of:

- the calculated penalty amount (step 6 or 7);

- the maximum penalty amount (step 8); or

- the legal validation amount (step 9).

- Based on the actual penalty amount from step 10, determine if a warning letter is a more appropriate sanction than a monetary penalty:

- If the penalty amount is less than $20, go to step 12.

- If a monetary penalty is not an appropriate sanction (for example, the maximum penalty amount has already been reached for this BPC prior to calculating this new penalty), go to step 12.

- If neither of the above situations applies, go to step 13.

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — misrepresentation — warning letter.”

- Details: Refer to the Fact-Finding and Documentation Policy . Include the following details:

- a summary of the false statements or omissions;

- the client’s or third party’s explanation;

- the rationale for determining false statements were made knowingly;

- any mitigating circumstances considered;

- the level of the misrepresentation;

- the actual or estimated net OP;

- the rationale for imposing a warning instead of monetary penalty (e.g. penalty amount was less than $20, maximum penalty amount was already imposed).

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3499.dita)

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — misrepresentation — penalty.”

- Details: Refer to the Fact-Finding and Documentation Policy . Include the following details:

- a summary of the false statements or omissions;

- the client’s or third party’s explanation;

- the rationale for determining false statements were made knowingly;

- any mitigating circumstances considered;

- the level of misrepresentation;

- the actual or estimated net OP;

- the penalty amount and an explanation of the penalty calculation (refer to steps 6 to 10).

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3499.dita)

- Before the misrepresentation decision can be implemented, you must consider a notice of violation. Go to Adjudicating client or third party misrepresentation — Violation for next steps. 

#### Misrepresentation after 36 months — Warning letter

Source topic: `en_EN/task/iam_dmp_wlac/misrepresentation_after_36_months__warn_dfce0540_level_2.dita`

- Consider the net OP resulting from the misrepresentation.

- Count the number of misrepresentations (false or misleading statements made knowingly).

- Determine the current level of misrepresentation.

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — misrepresentation — warning letter.”

- Details: Refer to the Fact-Finding and Documentation Policy . Include the following details:

- a summary of the false statements or omissions;

- the client or third party’s explanation;

- the rationale for determining false statements were made knowingly;

- any mitigating circumstances considered;

- the level of misrepresentation;

- the actual or estimated net OP;

- the rationale for imposing a warning instead of monetary penalty (e.g. misrepresentation occurred more than 36 months ago).

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3499.dita)

- Before the misrepresentation and warning letter decisions can be implemented, a notice of violation must be considered. Go to Adjudicating client or third party misrepresentation — Violation for next steps. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3497.dita`

Maximum penalty (based on the level of the misrepresentation) minus prior penalty amounts on this BPC 

#### Callout

Source topic: `en_EN/common_notes/note_c_3498.dita`

For established claims:

3 x client’s weekly benefit rate x the number of misrepresentations

OR

For BPNE claims:

3 x maximum benefit rate when the misrepresentation occurred x the number of misrepresentations. 

#### Note

Source topic: `en_EN/common_notes/note_c_3499.dita`

Note:

When the penalty applies to the third party, create an External SROC instead of a ROD, with Integrity as the Main Issue , under the third party’s SIN. The Comments and Details are the same as above. 

## Policy reference

Source topic: `en_EN/task/iam_dmp_wlac/policy_reference.dita`

- EIA 38
         [EIA 38](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-38.html)

- EIA 40
         [EIA 40](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-40.html)

- EIA 41.1
         [EIA 41.1](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-41.1.html)

- Integrity Operations Manual 33
         [Integrity Operations Manual 33](https://014gc.sharepoint.com/:w:/r/sites/DOD_IOG/GOIIOM%2033/0-Chapter%2033%20-%20Adjudication%20of%20CGIs%20-%20Earnings%20while%20on%20claim-EI.docx)

- National Policy on Fact-Finding and Documentation
         [National Policy on Fact-Finding and Documentation](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
