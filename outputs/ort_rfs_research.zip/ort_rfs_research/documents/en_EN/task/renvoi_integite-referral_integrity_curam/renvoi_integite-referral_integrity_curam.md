# Referral to Integrity — Cúram

Source map: `en_EN/task/renvoi_integite-referral_integrity_curam/renvoi_integite-referral_integrity_curam.ditamap`

## Summary

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/summary.dita`

Summary: When processing a claim, the officer may suspect a client, an employer or a third party of committing abuse. Clients may also report that their personal information has been compromised and used to establish a claim or to interfere with the payment of benefits. When it is determined that there is potential abuse, the officer refers the issue to Integrity for investigation. 

## What you need to know

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/untitled_section.dita`

**In Cúram:**

- Has a suspension been imposed to stop payment?

- Has a D71 been imposed?

- Does the potential abuse impact an active claim?

- Is an Special Caution flag displayed?

- What type of Special Caution flag is displayed?

- Is there any documentation relating to an ongoing investigation?

**In FTS:**

- Has an MA71 been imposed?

- Has a D71 been imposed?

**In NWS:**

- Are there any SROCs relating to an ongoing investigation? 

### Note

Source topic: `en_EN/common_notes/note_c_0146.dita`

Note:

The restriction on referring issues to Integrity has been lifted for all issues except self-employment (SE). The officer refers the file to Integrity only when the SE issue impacts the payment of future benefits. 

### Danger

Source topic: `en_EN/common_notes/note_c_4478.dita`

**Warning:**

Do not share this information with the client. This bank account has been detected as restricted and cannot be added. 

### Note

Source topic: `en_EN/common_notes/note_c_4479.dita`

Note:

This warning message is presented as error code C850 in FTS, and a detailed explanation can be found in WECS .
       [WECS](http://wecs-siew.prv/wecs-siew/lookup_e.aspx)

     [WECS](http://wecs-siew.prv/wecs-siew/lookup_e.aspx) 

### Note

Source topic: `en_EN/common_notes/note_c_4480.dita`

Note:

If the client subsequently provides a different direct deposit account that is not rejected with the warnings message, the officer still refers the rejected direct deposit account information to Integrity. The officer also includes the rejected direct deposit information in the AI WI sent to Integrity. 

## Regional considerations

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/untitled_section.dita`

**In Cúram:**

- Has a suspension been imposed to stop payment?

- Has a D71 been imposed?

- Does the potential abuse impact an active claim?

- Is an Special Caution flag displayed?

- What type of Special Caution flag is displayed?

- Is there any documentation relating to an ongoing investigation?

**In FTS:**

- Has an MA71 been imposed?

- Has a D71 been imposed?

**In NWS:**

- Are there any SROCs relating to an ongoing investigation? 

## Step by step

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/reviewing_the_file_level_1.dita`

- Determine if the reason for referral is a failure to attend a client information session:

- If no, go to step 2.

- If yes, go to step 7.

- Determine if the reason for referral is to forward information to Integrity about an ongoing investigation :

- If no, go to step 3.

- If yes, go to step 7.

- Determine if the SIN is available for the issue being referred:

- If yes, go to step 4.

- If no, go to step 15.

- Determine if the reason for referral is the presence of the restricted bank account warnings message:

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4481.dita) 

- If no, go to step 5.

- If yes, go to Referring the issue to Integrity – Restricted bank account warning .
               [Referring the issue to Integrity – Restricted bank account warning](/#level1_item_3)

- Determine the reason of the referral to Integrity:

- If the issue is related to an unreported contentious RFS and the client received regular or sickness benefits after the LDW of the RFS, go to step 6.

- If it is any other issue, go to step 7.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4482.dita)

- Determine if the contentious RFS was unreported on a previous claim: 

#### Inputting the Special Caution flag

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/inputting_the_special_caution_flag_level_1.dita`

- In Cúram, determine if a Special Caution flag is displayed on the client’s profile image:

- Input the Special Caution flag as follows:

- From the client’s main profile screen, the Person Case , select the 3 dots ( … ) in the top right-hand corner.

- From the drop-down menu, select New Special Caution .

- Category: Select Under Investigation .

- Type: Select the appropriate option based on whether a suspension will be imposed to stop payment.

- Start Date: Enter today’s date.

- End Date: Enter the end date. If unknown or indefinite, leave this field blank.

- Select Save . 

#### Imposing a suspension to stop payment

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/imposing_a_suspension_to_stop_payment_level_1.dita`

- Determine if the issue for referral impacts the payment of future benefits or if a fraudulent claim is suspected:

- If the payment of future benefits may be impacted, go to step 10.

- If the payment of future benefits is not impacted, go to step 12.

- If a potentially fraudulent claim is suspected, go to Fraud indicators are present .
               [Fraud indicators are present](/#fip)

- Determine if a suspension has already been imposed to stop payment:

- If no, go to step 11.

- If yes, go to step 12.

- In Cúram, input a suspension to stop payment as follows:

- From the Product Delivery Case , select the 3 dots (…) from the upper right-hand corner of the screen.

- Select Suspend Case from the drop-down menu.

- From the Reason field, select Integrity Services Case from the drop-down menu.

- Select Save .

- Go to step 12.

- In NWS, create a draft SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Referral to Integrity.”

- Details: Type “Cúram claim. Special Caution flag has been input in Cúram and a suspension has been imposed to prevent payment.” Explain why the issue was referred to integrity.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2926.dita) 

#### Referring the issue to Integrity

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/referring_the_issue_to_integrity_level_1.dita`

- In NWS, determine if there is a CB WI directly related to the reason for referral :

- Reassign the CB WI to Integrity as follows:

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- Complexity: Select Level 1 .

- Reason: Select Other .

- Details: Type “Ongoing investigation.” Explain why the issue is being referred to Integrity. If doubt arose while speaking with the client, provide all relevant details and dates of SROCs to be reviewed.

- In NWS determine if there is an existing AI WI assigned to Integrity that is not completed:

- If no, go to step 16.

- If yes, add the information to the existing AI WI. Go to step 19.

- In NWS, determine if the client’s SIN is on file:

- If yes, go to step 17.

- If no, go to step 18.

- In NWS, create an AI WI as follows:

- Urgent: Do one of the following:

- If the issue for referral impacts the payment of future benefits, check the box.

- If the issue for referral does not impact the payment of future benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB ) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Category: Do one of the following:

- Issue: Select Integrity .

- Comments: Type one of the following:

- Details: Explain why the issue is being referred to Integrity. If it is an unreported RFS that impacts the payment of benefits on a current claim, type “Payment of benefits is pending the outcome of the investigation.”

- Go to step 18.

- In NWS, create a General Inquiry (GEN) WI as follows:

- Select Create General Inquiry .

- First name: Enter the client’s first name.

- Last name: Enter the client’s last name.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Issue: Select ROE .

- Comments: Type “Referral to Integrity.”

- Details: Explain the reason for the referral to Integrity.”

- Go to step 19. 

#### Reviewing the impacts of the referral

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/reviewing_the_impacts_of_the_referral_level_1.dita`

- In Cúram, determine if there is a task related to the reason for referral:

- If yes, move it to Defer as follows:

- From the Task Homepage , select 3 dots ( … ) at the top right-hand corner of the screen.

- From the drop-down menu, select Defer .

- Restart Date: Enter today’s date + 21 working days.

- Comments: Type “Referral to Integrity.”

- Select Save .

- Go to step 20.

- If no or the task is not related to the issue, return to the previous procedure.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4483.dita)

- When the task moves to the current workload, determine if there is documentation from integrity (an AI WI in NWS) for the investigation and if it is completed or if there is a decision related to the investigation on file:

- If no, repeat step 19.

- If yes, go to step 21.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4484.dita)

- In NWS, add to the drafted SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Referral to Integrity.”

- Details: Document all actions taken on the claim in Cúram.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2926.dita)

- In Cúram, document the referral to Integrity in a Note as follows:

- From the client’s home page, select Cases and Applications from the navigation bar.

- Select the appropriate reference number and select Contacts from the navigation bar.

- Select Notes from the menu on the left-hand side and select New Note from the right-hand side.

- From the New Note window, complete the following fields:

- Text: Explain why the issue was referred to Integrity.”

- Select Save .

- In Cúram, complete the task as follows:

- From the Task Homepage , select the 3 dots ( …) at the top right-hand corner of the screen.

- From the drop-down menu, select Complete .

- Select Yes . 

#### Fraud indicators are present

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/fraud_indicators_are_present_level_1.dita`

- In Cúram, determine if a Special Caution flag is displayed on the client’s profile image:

- Input the Special Caution flag as follows:

- From the client’s main profile screen, the Person Case , select the 3 dots ( … ) in the top right-hand corner.

- From the drop-down menu, select New Special Caution .

- Category: Select Under Investigation .

- Type: Select the appropriate option based on whether or not a suspension will be imposed to stop payment.

- Start Date: Enter today’s date.

- End Date: Enter the end date. If unknown or indefinite, leave this field blank.

- Select Save .

- In NWS, determine if there is a CB WI or AI WI from Integrity on file that is directly related to the potentially fraudulent application:

- If there is only a CB WI on file, move the the Cúram task to Defer as follows:

- From the Task Homepage , select … at the top right-hand corner of the screen.

- From the drop-down menu, select Defer .

- Restart Date: Enter the date of application + 27 days.

- Comments: Type “Referral to Integrity.”

- Select Save .

- If there is an AI WI from Integrity indicating that the claim can be established, return to step 1 of the previous procedure.

- If neither WI is on file, go to step 4.

- Determine if the task is related to a fraudulent renewal application:

- If yes, go to step 5.

- If it is related to a fraudulent initial application, go to step 8.

- Determine if the client’s continuing claim has been compromised:

- If yes, go to step 6.

- If no, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4485.dita)

- Determine if a suspension is already imposed:

- If no, go to step 7.

- If yes, go to step 15.

- In Cúram, input a suspension to stop payment as follows:

- From the Product Delivery Case , select the 3 dots (…) from the upper right-hand corner of the screen.

- Select Suspend Case from the drop-down menu.

- From the Reason field, select Integrity Services Case from the drop-down menu.

- Select Save .

- Go to step 11.

- Determine if a D71 is already imposed:

- If no, go to step 9.

- If yes, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4366.dita)

- In Cúram impose a D71 – Integrity Services Case disentitlement (D71) as follows:

- From the Cases and Clients screen, select the Employment Insurance Program Benefits link to the appropriate Product Delivery Case.

- Select the Evidence tab from the navigation bar.

- Select New Evidence .

- From the Category drop-down menu, select All .

- From the Type menu, locate Return to Work and Disentitlements and select Add .

- From the Reason drop-down menu, select D71 – Integrity Services Case.

- Enter the appropriate disentitlement dates in the Start Date and End Date fields.

- Enter all relevant details in the Comments field.

- Select Save .

- Apply the changes to save the D71 as follows:

- From the Evidence Dashboard , select In Edit Evidence from the left-hand side menu.

- Select the 3 dots ( … ) on the right-hand side of the In Edit Evidence navigation bar (beside Open in New Tab ). From the drop-down menu, select Apply Changes .

- From the Apply Changes window, select Other Disentitlements (be sure to select the correct disentitlement) and enter the following Overpayment (OP) Codes :

- Detection Code: Select 31 - Other new facts – entitlement review .

- Infraction Code: Select F- Non-fraud – Other .

- Message Code: Select 3 – An overpayment resulted due to a definite disentitlement .

- Select Save .

- Determine if there is documentation on file indicating that Integrity is already aware of the potential fraud for this issue:

- If no, go to step 12.

- If yes, go to step 15.

- In NWS, determine if the client’s SIN is on file:

- If yes, go to step 13.

- If no, go to step 14.

- In NWS, create an AI WI as follows:

- Urgent: Do one of the following:

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB ) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Category: Do one of the following:

- If this is an initial claim or if a suspension is imposed, select Pay affected .

- If the investigation involves a terminated claim or if no suspension is imposed, select Not pay affected .

- Issue: Select Integrity .

- Comments: Type one of the following:

- If there is no ongoing investigation, type “There is doubt about [subject of doubt].”

- If there is an ongoing investigation, type “There is doubt about [subject of doubt] — ongoing investigation.”

- Details: Explain why the issue is being referred to Integrity. If it is an unreported RFS that impacts the payment of benefits on a current claim, type “Payment of benefits is pending the outcome of the investigation.”

- Go to step 15.

- In NWS, create a General Inquiry (GEN) WI as follows:

- Select Create General Inquiry .

- First name: Enter the client’s first name.

- Last name: Enter the client’s last name.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Issue: Select ROE .

- Comments: Type “Referral to Integrity.”

- Details: Explain the reason for the referral to Integrity.”

- Go to step 15.

- In NWS, create and save an SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Referral to Integrity.”

- Details: Explain why the issue was referred to integrity.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2926.dita)

- In Cúram, document the referral to Integrity in a Note as follows:

- From the client’s home page, select Cases and Applications from the navigation bar.

- Select the appropriate reference number and select Contacts from the navigation bar.

- Select Notes from the menu on the left-hand side and select New Note from the right-hand side.

- From the New Note window, complete the following fields:

- Subject: Type “[Client Name] – Referral to Integrity.”

- Priority: Select Medium .

- Sensitivity: Select 1 .

- Text: Explain why the issue was referred to Integrity.”

- Select Save .

- No further action is required. Return to the previous procedure, if necessary. 

#### Refer the issue to Integrity — Restricted bank account warning

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/refer_the_issue_to_integrity__restricte_a5c11661_level_1.dita`

- In Cúram, determine if a Special Caution flag is displayed on the client’s profile image:

- If no, go to step 2.

- If yes, go to step 3.

- Input the Special Caution flag as follows:

- From the client’s main profile screen, the Person Case , select the 3 dots ( … ) in the top right-hand corner.

- From the drop-down menu, select New Special Caution .

- Category: Select Under Investigation .

- Type: Select the appropriate option based on whether or not a suspension will be imposed to stop payment.

- Start Date: Enter today’s date.

- End Date: Enter the end date. If unknown or indefinite, leave this field blank.

- Select Save .

- In NWS, determine if there is an existing AI WI assigned to Integrity that is not completed:

- In NWS, create an AI WI as follows:

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue(s): Select Integrity .

- Comments: Type “Direct deposit — restricted bank account warning.”

- Details: Type “Cúram claim. Added or modified information related to the direct deposit account [XXXXX XXXX XXXXXXX] was rejected with a restricted bank account warning.”

- In NWS, create a new SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Referral to Integrity — banking information.”

- Details: Type “Banking information rejected with a restricted bank account warning message.” Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2926.dita)

- In Cúram, document the referral to Integrity in a Note as follows:

- From the client’s home page, select Cases and Applications from the navigation bar.

- Select the appropriate reference number and select Contacts from the navigation bar.

- Select Notes from the menu on the left-hand side and select New Note from the right-hand side.

- From the New Note window, complete the following fields:

- Text: Type “Added or modified information related to the direct deposit account [XXXXX XXXX XXXXXXX] was rejected with a restricted bank account warning in Curam.”

- Select Save .

- No further action is required. Return to the previous procedure, if necessary. 

#### Warning

Source topic: `en_EN/common_notes/note_c_4481.dita`

Warning:

Do not share this information with the client. This bank account has been detected as restricted and cannot be added. 

#### Note

Source topic: `en_EN/common_notes/note_c_4482.dita`

Note:

If the client received only special benefits other than sickness after the LDW of the RFS, the officer does not refer the issue to Integrity. 

#### Note

Source topic: `en_EN/common_notes/note_c_2926.dita`

Note:

At this time, SROCs must be created and saved in NWS for all actions completed in Cúram. 

#### Note

Source topic: `en_EN/common_notes/note_c_4483.dita`

Note:

If the claim is a renewal claim and there is no deferred task, impose a suspension to prevent payments in case the claim is automated before the investigation is complete. 

#### Note

Source topic: `en_EN/common_notes/note_c_4484.dita`

Note:

The task must stay Deferred as long as the investigation has not been completed or there is no decision related to the investigation on file. 

#### Note

Source topic: `en_EN/common_notes/note_c_4485.dita`

Note:

A claim is considered to be compromised when the client’s information (address or direct deposit information) has been changed. If the claim is compromised, impose a suspension. 

#### Note

Source topic: `en_EN/common_notes/note_c_4366.dita`

Note:

Before imposing a D71, confirm that one has not already been imposed. If a transaction to impose a D71 is input when one already exists, the D71 is cancelled. 

### Level 2

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/reviewing_the_file_level_2.dita`

- Determine if the reason for referral is a failure to attend a client information session:

- If no, go to step 2.

- If yes, go to step 7.

- Determine if the reason for referral is to forward information to Integrity about an ongoing investigation :

- If no, go to step 3.

- If yes, go to step 7.

- Determine if the reason for referral is the restricted bank account warning message:

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4481.dita) 

- If no, go to step 4.

- If yes, go to Referring the issue to Integrity — Restricted bank account warning .
               [Referring the issue to Integrity — Restricted bank account warning](/#level2_item_3)

- Determine the reason of the referral to Integrity:

- If the issue is related to an unreported contentious RFS and the client received regular or sickness benefits after the LDW of the RFS, go to step 5.

- If it is any other issue, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4482.dita)

- Determine if the contentious RFS was unreported on a previous claim:

- If yes, go to step 6.

- If no, no further action is required. Return to the previous task. 

#### Inputting the Special Caution flag

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/inputting_the_special_caution_flag_level_2.dita`

- In Cúram, determine if a Special Caution flag is displayed on the client’s profile image:

- If no, go to step 7.

- If yes, go to step 8.

- Input the Special Caution flag as follows:

- From the client’s main profile screen, the Person Case , select the 3 dots ( … ) in the top right-hand corner.

- From the drop-down menu, select New Special Caution .

- Category: Select Under Investigation .

- Type: Select the appropriate option based on whether a suspension will be imposed to stop payment.

- Start Date: Enter today’s date.

- End Date: Enter the end date. If unknown or indefinite, leave this field blank.

- Select Save . 

#### Imposing a stop payment

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/imposing_a_stop_payment_level_2.dita`

- Determine if the issue for referral impacts the payment of future benefits on an initial, renewal or continuing claim or if a fraudulent claim is suspected:

- If the payment of future benefits may be impacted, go to step 9.

- If the payment of future benefits is not impacted, go to step 11.

- If a potentially fraudulent claim is suspected, go to Fraud indicators are present .
               [Fraud indicators are present](/#initial-task)

- Determine if a suspension has already been imposed to stop payment:

- If no, go to step 10.

- If yes, go to step 11.

- In Cúram, input a suspension to stop payment as follows:

- From the Product Delivery Case , select the 3 dots (…) from the upper right-hand corner of the screen.

- Select Suspend Case from the drop-down menu.

- From the Reason field, select Integrity Services Case from the drop-down menu.

- Go to step 11.

- Select Save .

- In NWS, create a draft SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Referral to Integrity.”

- Details: Type “Cúram claim. Special Caution flag has been input in Cúram and a suspension has been imposed to prevent payment.” Explain why the issue was referred to integrity.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2926.dita) 

#### Referring the issue to Integrity

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/referring_the_issue_to_integrity_level_2.dita`

- In NWS, determine if there is a CB WI directly related to the reason for referral :

- If yes, go to step 13.

- If no, go to step 14.

- Reassign the CB WI to Integrity as follows:

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- Complexity: Select Level 1 .

- Reason: Select Other .

- Details: Type “Ongoing investigation.” Explain why the issue is being sent to Integrity. If doubt arose while speaking with the client, provide all relevant details and the dates of SROCs to be reviewed.

- In NWS, determine if there is an existing AI WI assigned to Integrity that is not completed:

- In NWS, determine if the client’s SIN is on file:

- In NWS, create an AI WI as follows:

- Urgent: Select the appropriate option:

- If the issue for referral impacts the payment of future benefits, check the box.

- If the issue for referral does not impact the payment of future benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Category: Do one of the following:

- If this is an initial claim or if a suspension is imposed, select Pay affected .

- If the investigation involves a terminated claim or if no suspension is imposed, select Not pay affected .

- Issue: Select Integrity .

- Comments: Type one of the following:

- If there is no ongoing investigation, type “There is doubt about [subject of doubt].”

- If there is an ongoing investigation, type “There is doubt about [subject of doubt] — ongoing investigation.”

- Details: Explain why the issue is being referred to Integrity. If it is an unreported RFS that impacts the payment of benefits on a current claim, type “Payment of benefits is pending the outcome of the investigation.”

- Go to step 18.

- In NWS, create a General Inquiry (GEN) WI as follows:

- Select Create General Inquiry .

- First name: Enter the client’s first name.

- Last name: Enter the client’s last name.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Issue: Select ROE .

- Comments: Type “Referral to Integrity.”

- Details: Explain the reason for the referral to Integrity.”

- Go to step 18. 

#### Reviewing the impacts of the referral

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/reviewing_the_impacts_of_the_referral_level_2.dita`

- In Cúram, determine if there is a task related to the reason for referral:

- If yes, move it to Defer as follows:

- From the Task Homepage , select 3 dots ( … ) at the top right-hand corner of the screen.

- From the drop-down menu, select Defer .

- Restart Date: Enter today’s date + 21 working days.

- Comments: Type “Referral to Integrity.”

- Select Save .

- Go to step 19.

- If no or the task is not related to the issue, return to the previous task.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4486.dita)

- When the task moves to the current workload, determine if there is documentation from integrity (likely an AI WI in NWS) for the investigation and if it is completed or if there is a decision related to the investigation on file:

- If no, repeat step 18.

- If yes, go to step 20.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4484.dita)

- In NWS, create and save an SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Referral to Integrity.”

- Details: Explain why the issue was referred to integrity.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2926.dita)

- In Cúram, document the referral to Integrity in a Note as follows:

- From the client’s home page, select Cases and Applications from the navigation bar.

- Select the appropriate reference number and select Contacts from the navigation bar.

- Select Notes from the menu on the left-hand side and select New Note from the right-hand side.

- From the New Note window, complete the following fields:

- Subject: Type “[Client Name] – Referral to Integrity.”

- Priority: Select Medium .

- Sensitivity: Select 1 .

- Text: Explain why the issue was referred to Integrity.”

- Select Save .

- In Cúram, complete the task as follows:

- From the Task Homepage , select the 3 dots ( …) at the top right-hand corner of the screen.

- From the drop-down menu, select Complete .

- Select Yes . 

#### Fraud indicators are present

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/fraud_indicators_are_present_level_2.dita`

- In Cúram, determine if an Special Caution flag is displayed on the client’s profile image:

- Input the Special Caution flag as follows:

- In NWS, determine if there is a CB WI or AI WI from Integrity on file that is directly related to the potentially fraudulent application:

- If there is only a CB WI on file, move the Cúram task to Defer as follows:

- From the Task Homepage , select … at the top right-hand corner of the screen.

- From the drop-down menu, select Defer .

- Restart Date: Enter the date of application + 27 days.

- Comments: Type “Referral to Integrity.”

- Select Save .

- If there is an AI WI from Integrity indicating that the claim can be established, return to step 1 of the previous procedure.

- If neither WI is on file, go to step 4.

- Determine if the task is related to a fraudulent renewal application:

- If yes, go to step 5.

- If it is related to a fraudulent initial application, go to step 8.

- Determine if the client’s continuing claim has been compromised:

- If yes, go to step 6.

- If no, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4487.dita)

- Determine if a suspension is already imposed:

- If no, go to step 7.

- If yes, go to step 11.

- In Cúram, input a suspension to stop payment as follows:

- From the Product Delivery Case , select the 3 dots (…) from the upper right-hand corner of the screen.

- Select Suspend Case from the drop-down menu.

- From the Reason field, select Integrity Services Case from the drop-down menu.

- Go to step 11.

- Determine if a D71 is already imposed:

- If no, go to step 9.

- If yes, go to step 11.

- In Cúram impose a D71 – Integrity Services Case disentitlement (D71) as follows:

- From the Cases and Clients screen, select the Employment Insurance Program Benefits link to the appropriate Product Delivery Case.

- Select the Evidence tab from the navigation bar.

- Select New Evidence .

- From the Category drop-down menu, select All .

- From the Type menu, locate Return to Work and Disentitlements and select Add .

- From the Reason drop-down menu, select D71 – Integrity Services Case.

- Enter the appropriate disentitlement dates in the Start Date and End Date fields.

- Enter all relevant details in the Comments field.

- Select Save .

- Apply the changes to save the D71 as follows:

- From the Evidence Dashboard , select In Edit Evidence from the left-hand side menu.

- Select the 3 dots ( … ) on the right-hand side of the In Edit Evidence navigation bar (beside Open in New Tab ). From the drop-down menu, select Apply Changes .

- From the Apply Changes window, select Other Disentitlements (be sure to select the correct disentitlement) and enter the following Overpayment (OP) Codes :

- Detection Code: Select 31 - Other new facts – entitlement review .

- Infraction Code: Select F- Non-fraud – Other .

- Message Code: Select 3 – An overpayment resulted due to a definite disentitlement .

- Select Save.

- Determine if there is documentation on file indicating that Integrity is already aware of the potential fraud for this issue:

- If no, go to step 12.

- If yes, go to step 15.

- In NWS, determine if the client’s SIN is on file:

- If yes, go to step 13.

- If no, go to step 14.

- In NWS, create an AI WI as follows:

- Urgent: Do one of the following:

- If the issue for referral impacts the payment of future benefits, check the box.

- If the issue for referral does not impact the payment of future benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Category: Do one of the following:

- Issue: Select Integrity .

- Comments: Type one of the following:

- Details: Explain why the issue is being referred to Integrity. If it is an unreported RFS that impacts the payment of benefits on a current claim, type “Payment of benefits is pending the outcome of the investigation.”

- Go to step 15.

- In NWS, create a General Inquiry (GEN) WI as follows:

- Select Create General Inquiry .

- First name: Enter the client’s first name.

- Last name: Enter the client’s last name.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Issue: Select ROE .

- Comments: Type “Referral to Integrity.”

- Details: Explain the reason for the referral to Integrity.”

- Go to step 15.

- In NWS, create and save an SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Referral to Integrity.”

- Details: Explain why the issue was referred to integrity.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2926.dita)

- In Cúram, document the referral to Integrity in a Note as follows:

- From the client’s home page, select Cases and Applications from the navigation bar.

- Select the appropriate reference number and select Contacts from the navigation bar.

- Select Notes from the menu on the left-hand side and select New Note from the right-hand side.

- From the New Note window, complete the following fields:

- Text: Explain why the issue was referred to Integrity.”

- Select Save .

- No further action is required. Return to the previous procedure, if necessary. 

#### Referring the issue to Integrity — Restricted bank account warning

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/referring_the_issue_to_integrity__restr_9c4e0537_level_2.dita`

- In Cúram, determine if an Special Caution flag is displayed on the client’s profile image:

- If no, go to step 2.

- If yes, go to step 3.

- Input the Special Caution flag as follows:

- From the client’s main profile screen, the Person Case , select the 3 dots ( … ) in the top right-hand corner.

- From the drop-down menu, select New Special Caution .

- Category: Select Under Investigation .

- Type: Select the appropriate option based on whether or not a suspension will be imposed to stop payment.

- Start Date: Enter today’s date.

- End Date: Enter the end date. If unknown or indefinite, leave this field blank.

- Select Save .

- In NWS, determine if there is an existing AI WI assigned to Integrity that is not completed:

- In NWS, create an AI WI as follows:

- In NWS, create a new SROC as follows:

- In Cúram, document the referral to Integrity in a Note as follows:

- No further action is required. Return to the previous task, if necessary. 

#### Note

Source topic: `en_EN/common_notes/note_c_4486.dita`

Note:

If the claim is a renewal claim and there is no deferred task, impose a suspensin to prevent payments in case the claim is automated before the investigation is complete. 

#### Note

Source topic: `en_EN/common_notes/note_c_4487.dita`

Note:

A claim is considered to be compromised when the client’s information (address or direct deposit information) has been changed. If the claim is compromised, impose suspension. 

## Policy reference

Source topic: `en_EN/task/renvoi_integite-referral_integrity_curam/policy_reference.dita`

 
