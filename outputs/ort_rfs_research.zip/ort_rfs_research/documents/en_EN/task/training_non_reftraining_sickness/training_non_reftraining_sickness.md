# Adjudicating non-referred training: Sickness benefits — Initial claim

Source map: `en_EN/task/training_non_reftraining_sickness/training_non_reftraining_sickness.ditamap`

## Summary

Source topic: `en_EN/task/training_non_reftraining_sickness/summary.dita`

Summary: When a client reports non-referred training on the EI application or while an initial claim is in progress, adjudication is required to determine entitlement to benefits during the training period. 

## What you need to know

Source topic: `en_EN/task/training_non_reftraining_sickness/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/task/training_non_reftraining_sickness/training_reported_between_september_27__5ecd71c7.dita`

A transitional measure under which ACP automatically adjudicated and allowed all training effective September 27, 2020 has ended on September 11, 2021. The intent of this measure was to prevent any delay in payment to clients who reported training.

The client must still meet the entitlement conditions for sickness benefits while attending non-referred training. A client attending non-referred training may provide information on a claimant’s report or during a conversation with an agent that brings into question the entitlement to sickness benefits. In this case, the agent creates a WI for the contentious training issue and follows normal adjudication procedures, even if ACP initially allowed the training. 

### Adjudication required on manually registered claims

Source topic: `en_EN/task/training_non_reftraining_sickness/adjudication_required_on_manually_regis_d5cd9e4c.dita`

Training was automatically adjudicated and electronic records of decision (ROD) were created only on claims that were automated through ACP.

The agent manually registers claims that are not automated through ACP. Training is not automatically adjudicated on manually registered claims. Instead, ACP assigns an Adjudication Issue (ADJ) WI to an agent because it could not automate the decision. Adjudication of these training ADJ WIs is required , and the agent follows the appropriate procedures to resolve them. Even if ACP initially allowed training, when a training ADJ WI is assigned (e.g. upon renewal), the agent must adjudicate. Additionally, if it is determined that a disentitlement applies from the start date of the training course, the Level 2 agent imposes a retroactive D3. 

### Impact of training on sickness benefits

Source topic: `en_EN/task/training_non_reftraining_sickness/impact_of_training_on_sickness_benefits.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4820.dita) 

Clients who apply for sickness benefits and prove their incapacity must also prove that they are otherwise available for work. This means that if not for the illness or injury, the client would be available for work. To help determine availability and entitlement during the training period, complete the Non-referred training checklist for sickness benefits . No distinction is made between part-time and full-time training .
       [Non-referred training checklist for sickness benefits](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Training-Non-referred_training_for_sickness_benefits-Checklist.doc)

This includes clients who are attending short-term training courses and targeted initiatives. Refer to the job aid for a complete list of non-referred short-term courses and targeted initiatives.
       [job aid](/en/procedure/generic/additionalresources/shortterm_courses_ti.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4814.dita) 

### Otherwise available during non-referred training

Source topic: `en_EN/task/training_non_reftraining_sickness/otherwise_available_during_non-referred_training.dita`

Additional fact-finding or follow-up is not required when a client reports training of up to 9 hours per week.

When training is equal to or greater than 10 hours, but less than 15 hours per week, it must be determined that if not for the medical situation, the client would be available and capable of working, and that upon recovery, the intention is to look for full-time work. The client must also be willing to quit the course to accept full-time employment once recovered from the illness or injury.

When clients report that they are attending full-time training on their own initiative, the officer refers to BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training and the Digest of Benefit Entitlement Principles 10.12.2.8 — Hours of work . Both the BE Memo and the Digest explain that, under FCA A-29-22 , when adjudicating availability, the officer must consider the clients’ work history while attending training, in addition to other factors (i.e. the number of hours clients are attending training). Clients can rebut the presumption of non-availability if they can demonstrate having a regular work history outside of the training hours while taking full-time training. Using any previous ROEs, the officer reviews the number of hours the client worked while attending training to determine if the client can rebut the presumption of non-availability. Clients must also demonstrate a willingness and ability to remain available for a similar work schedule. Clients must not reduce or restrict their available hours of work beyond what is reasonable, given their work history, while attending training.
       [BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training](/en/policy/bememo/be2023-05.shtml) 
       [Digest of Benefit Entitlement Principles 10.12.2.8 — Hours of work](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2_8) 
       [FCA A-29-22](https://www.canlii.org/en/ca/fca/doc/2023/2023fca169/2023fca169.html)

When a client is devoting 15 or more hours per week to training, the agent must determine the total number of hours per week that is being spent on the training, including :

- class time

- study time

- time spent working on assignments

- time spent doing research

Correspondence courses are treated the same as any other training, with the following conditions applied:

- the course obligations must be outside the client’s normal working hours;

- upon recovery, the client must be willing to quit the course to accept full-time employment;

- upon recovery, the client must not limit the acceptance of full-time employment in favour of the training. 

### Targeted initiatives and short-term courses

Source topic: `en_EN/task/training_non_reftraining_sickness/targeted_initiatives_and_short-term_courses.dita`

When clients receiving sickness benefits report that they are attending a targeted initiative or short-term course, the total daily or weekly attendance hours is not considered.

If the client is attending a short-term course referred under EIA 25, refer to Confirming referred training: Special benefits — Initial claim .
       [Confirming referred training: Special benefits — Initial claim](/en/procedure/task/confirmreftrng_sb_in.shtml) 

### Automated decisions

Source topic: `en_EN/task/training_non_reftraining_sickness/automated_decisions.dita`

When a client reports non-referred training on the EI application, in a claimant’s report or on MSCA, an electronic questionnaire is created and can be viewed in NWS. If the electronic questionnaire meets the Levels of Decision criteria for Level 1 adjudication, ACP can automate the adjudication of the non-referred training. In this case, ACP creates a record of decision (ROD) and inputs the training project data in FTS.

If ACP creates an Adjudication Issue (ADJ) WI and the client calls the EI call centre, the call centre agent may be able to adjudicate the non-referred training and complete the WI. 

### Processing the claim

Source topic: `en_EN/task/training_non_reftraining_sickness/processing_the_claim.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can process the claim. There is a Resolve Issue tab for ADJ Training WIs that includes screens where the agent documents the decision. When the ADJ WI is completed, the system creates a ROD based on the Resolve Issue screens. When the claim is established, the system also generates the required transactions (e.g. training information, disentitlement) based on the Resolve Issue screens. If the training is not allowed and a disentitlement is imposed, the system creates a Correspondence (COR) WI for the N-00-00-00 letter. No letter is sent when the training is allowed. 

### Note

Source topic: `en_EN/common_notes/note_c_4820.dita`

Note:

If adjudication is part of a recalculation, the agent must refer to Adjudicating non-referred training: Sickness benefits — Continuing claim .
       [Adjudicating non-referred training: Sickness benefits — Continuing claim](/en/procedure/task/training_sickness.shtml)

     [Adjudicating non-referred training: Sickness benefits — Continuing claim](/en/procedure/task/training_sickness.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4814.dita`

Note:

If a client quits employment or refuses an offer of employment to attend a non-referred training course, a non-referred short-term training course or a targeted initiative, agents must adjudicate the reason for separation on a separate WI. 

## Regional considerations

Source topic: `en_EN/task/training_non_reftraining_sickness/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/training_non_reftraining_sickness/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/training_non_reftraining_sickness/in_fts.dita`

- Is there training information in the Project tab? 

### In NWS:

Source topic: `en_EN/task/training_non_reftraining_sickness/in_nws.dita`

- Was the training questionnaire completed?

- Is there an SROC with the training information, from either the Part-time Training checklist or the INS3141? 

### In Imaging:

Source topic: `en_EN/task/training_non_reftraining_sickness/in_imaging.dita`

- Is there non-referred training information or the Training Course Information (INS3141)? 

### In the LMDAAccess module of EIBIS:

Source topic: `en_EN/task/training_non_reftraining_sickness/in_the_lmdaaccess_module_of_eibis.dita`

- Is there a Notice of Intent to refer the client to training? 

## Step by step

Source topic: `en_EN/task/training_non_reftraining_sickness/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/training_non_reftraining_sickness/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_non_reftraining_sickness/reviewing_the_file_level_1.dita`

- In FTS, determine if there is referred training information displayed on the Project tab:

- If referred training information is displayed on the Project tab, refer to Confirming referred training: Special Benefits—Initial claim .
               [Confirming referred training: Special Benefits—Initial claim](/en/procedure/task/confirmreftrng_sb_in.shtml)

- If referred training information is not displayed on the Project tab, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2699.dita)

- In EIBIS , determine if there is a Notice of Intent as follows:

- Enter your user name and password (same as Windows, firstname.lastname).

- Select Submit .

- Select LMDAAccess and enter the client’s SIN.

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4821.dita) 

- If there is no Notice of Intent, go to step 3.

- If there is a Notice of Intent to refer the client to training, refer to Confirming referred training: Special Benefits—Initial claim .
               [Confirming referred training: Special Benefits—Initial claim](/en/procedure/task/confirmreftrng_sb_in.shtml)

- Determine if adjudication can be deferred by consulting the Deferring adjudication procedure.

- Determine if there is enough information to adjudicate the non-referred training:

- If additional details are needed, go to step 5.

- If additional details are not needed, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/training_non_reftraining_sickness/fact-finding_level_1.dita`

- Fact-find with the client. For help determining the questions to ask the client, refer to the Fact-Finding Guide .

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 7.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining_sickness#reassign)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — sickness benefits.”

- Details: If completed during fact-finding, copy and paste the Non-referred training checklist for sickness benefits . Document any additional fact-finding details according to the Fact-Finding and Documentation Policy .
               [Non-referred training checklist for sickness benefits](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Training-Non-referred_training_for_sickness_benefits-Checklist.doc) 
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/training_non_reftraining_sickness/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the client reported training in error:

- If the client did not report training in error, go to step 9.

- If the client declared reported training in error, go to Training reported in error .
               [Training reported in error](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining_sickness#TRainingDeclaredInError1)

- Determine the type of training the client is attending:

- If the client is attending regular non-referred training for 10 to 14 hours per week, go to step 10.

- If the client is attending a short-term training course or a targeted initiative, go to step 11.

- If the client is attending regular non-referred training 15 hours or more per week, go to step 11.

- If the client is attending regular non-referred training for 9 hours or less per week, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining_sickness#TrainingAllowedAtLevel1)

- Determine if the following conditions are met for the non-referred training:

- The client declares that if not for the medical situation, he would be available and capable of working.

- The client’s intention upon recovery is one of the following:

- to return to employment, as the course or program will be completed prior to recovery.

- to leave the course or program and resume employment activities.

- to continue the course or program and resume employment activities to the same extent as prior to the illness or injury.

- If all of the conditions are met, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining_sickness#TrainingAllowedAtLevel1)

- If any of the conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining_sickness#reassign)

- Determine if the following conditions are met for the non-referred training:

- All of the course obligations occur outside the normal work hours of the client’s usual occupation.

- The client declares that if not for the medical situation, he would be available and capable of working.

- The client’s intention upon recovery is one of the following:

- to return to employment, as the course or program will be completed prior to recovery.

- to leave the course or program and resume employment activities.

- to continue the course or program and resume employment activities to the same extent as prior to the illness or injury.

- If all of the conditions are met, go Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining_sickness#TrainingAllowedAtLevel1)

- If any of the conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining_sickness#reassign) 

#### Training reported in error

Source topic: `en_EN/task/training_non_reftraining_sickness/training_reported_in_error_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Training screen as follows:

- Select The facts on file show training was declared in error by the client .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Entitlement conditions met

Source topic: `en_EN/task/training_non_reftraining_sickness/entitlement_conditions_met_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Training screen as follows:

- Select Based on the information on file, the criteria to allow the decision to be made at Level 1 have been met (National Policy on Levels of Decision) .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select the appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/training_non_reftraining_sickness/reassigning_the_issue_to_level_2_level_1.dita`

- In FTS, input or update any outstanding claimant’s reports for the period before the training start date.

- In NWS, reassign the WI as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type the applicable reason for the reassignment:

- “Unable to contact client for fact-finding.”

- “Not within Level 1 authority.”

- Select OK .

- When the Warning window is displayed, select Ok . 

#### Note

Source topic: `en_EN/common_notes/note_c_2699.dita`

Note:

For subsequent claims, the referred training information may be displayed on the Project tab of the previous BPC. In FTS, review the previous BPC on the Dormant tab. 

#### Note

Source topic: `en_EN/common_notes/note_c_4821.dita`

Note:

If a Notice of Intent to refer the client to training has been entered by the referring authority, it is displayed at the bottom of the screen, below Claimant Information , EI Claim Info and Allocation of Earnings (if applicable). 

### Level 2

Source topic: `en_EN/task/training_non_reftraining_sickness/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_non_reftraining_sickness/reviewing_the_file_level_2.dita`

- In FTS, determine if there is referred training information displayed on the Project tab:

- If referred training information is not displayed on the Project tab, go to step 2.

- If referred training information is displayed on the Project tab, refer to Confirming referred training: Special Benefits—Initial claim .
               [Confirming referred training: Special Benefits—Initial claim](/en/procedure/task/confirmreftrng_sb_in.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2699.dita)

- In EIBIS , determine if there is a Notice of Intent as follows:

- Enter your user name and password (same as Windows, firstname.lastname).

- Select Submit .

- Select LMDAAccess and enter the client’s SIN.

- Select Submit .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4821.dita)

- If there is no Notice of Intent, go to step 3.

- If there is a Notice of Intent to refer the client to training, refer to Confirming referred training: Special Benefits—Initial claim .
               [Confirming referred training: Special Benefits—Initial claim](/en/procedure/task/confirmreftrng_sb_in.shtml)

- Determine if adjudication can be deferred by consulting the Deferring adjudication procedure.

- Determine if there is enough information to adjudicate the non-referred training:

- If additional details are needed, go to step 5.

- If additional details are not needed, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/training_non_reftraining_sickness/fact-finding_level_2.dita`

- Fact-find with the client. For help determining the questions to ask the client, refer to the Fact-Finding Guide .

- Determine if the client was contacted during fact-finding:

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 8.

- If the client was contacted, go to step 7.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training—sickness benefits.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating non-referred training

Source topic: `en_EN/task/training_non_reftraining_sickness/adjudicating_non-referred_training_level_2.dita`

- Determine if the client reported training in error, completed the training course before the benefit period or is not attending training:

- If none of these conditions are met, go to step 9.

- If any of these conditions are met, go to Training not an issue .
               [Training not an issue](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining_sickness#TrainingNotAnIssue2)

- Adjudicate the non-referred training according to Digest 11.3.0 — Second entitlement condition: to be otherwise available for work and Digest 10.12.2 — Persons attending courses on their own initiative and BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training and determine if the client has proven being entitled to benefits:

- If the client has not proven being entitled to benefits, go to Entitlement conditions not met .
               [Entitlement conditions not met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining_sickness#entitlement_conditions_not_met)

- If the client has proven being entitled to benefits, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_non_reftraining_sickness#entitlement_conditions_met) 

#### Entitlement conditions not met

Source topic: `en_EN/task/training_non_reftraining_sickness/entitlement_conditions_not_met_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Engaged in non-referred training .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select the appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Complete the Engaged in non-referred training screen as follows:

- Relevant Facts:

- Indicate whether the client has completed the training course.

- Indicate whether the client voluntarily left employment to take the course and provide additional information if applicable.

- Summarize the evidence.

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4816.dita)

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale:

- Based on the evidence, is it determined that if it were not for illness or incapacity the client would be otherwise available for work?: Select No .

- Enter any other supporting jurisprudence.

- Enter any additional rationale information.

- References: Enter any additional references.

- Decision: Select Not allowed - Disentitlement, not otherwise available (D-33) .

- Disentitlement start: Select the appropriate option:

- Select BPC .

- Select Specific date and enter the start date (Monday to Friday).

- Disentitlement end: Select the appropriate option:

- If the training has ended, select the corresponding end date of the disentitlement.

- If the training has not ended, select Indefinite .

- Overpayment: Review and, if required, modify the prefilled codes in the Detection , Infraction and Message fields.

- Select Continue .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4718.dita)

- Verbally communicate the decision to the client.

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Select I agree .

- In ACS, save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066)

- D33 - Not otherwise available (11034) .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Text - Reasons why not otherwise available (1630) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note and type “Send the saved N-00-00-00 letter.”

- Complete the ADJ WI. 

#### Training not an issue

Source topic: `en_EN/task/training_non_reftraining_sickness/training_not_an_issue_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Training is not an issue .

- Select Continue .

- Complete the Training is not an issue screen as follows:

- Relevant Facts: Indicate why the training is not an issue.

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale: Select the applicable reason why training is not an issue.

- References: Enter any additional references.

- Verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Entitlement conditions met

Source topic: `en_EN/task/training_non_reftraining_sickness/entitlement_conditions_met_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Engaged in non-referred training .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select the appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Complete the Engaged in non-referred training screen as follows:

- Relevant Facts:

- Indicate whether the client has completed the training course.

- Indicate whether the client voluntarily left employment to take the course and provide additional information if applicable.

- Summarize the evidence.

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4816.dita)

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale:

- Based on the evidence, is it determined that if it were not for illness or incapacity the client would be otherwise available for work?: Select Yes .

- Enter any additional rationale information.

- References: Enter any additional references.

- Decision: Select Allowed - otherwise available .

- Select Continue .

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4816.dita`

Note:

If the client voluntarily left employment to take the course, that issue must be adjudicated and resolved in a separate WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4718.dita`

Note:

If the decision is the result of an Integrity case, the prefilled overpayment codes must be changed to match the Report of Investigation. 

## Policy reference

Source topic: `en_EN/task/training_non_reftraining_sickness/policy_reference.dita`

- Digest 11.3.0 — Second entitlement condition: to be otherwise available for work
         [Digest 11.3.0 — Second entitlement condition: to be otherwise available for work](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-11/otherwise-available-for-work.html#a11_3_0)

- Digest 10.12.2 — Persons attending courses on their own initiative
         [Digest 10.12.2 — Persons attending courses on their own initiative](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training
         [BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2023-05.shtml) 
