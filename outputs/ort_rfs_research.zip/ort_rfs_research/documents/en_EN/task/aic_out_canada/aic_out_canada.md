# Adjudicating an Integrity case — Out of Canada

Source map: `en_EN/task/aic_out_canada/aic_out_canada.ditamap`

## Summary

Source topic: `en_EN/task/aic_out_canada/summary.dita`

Summary: Investigators inform us of the results of an investigation in which they find that clients did not indicate all periods during which they were out of Canada. 

## What you need to know

Source topic: `en_EN/task/aic_out_canada/what_you_need_to_know.dita`

### Processing an Integrity claim review

Source topic: `en_EN/task/aic_out_canada/processing_an_integrity_claim_review.dita`

Below are the main processing steps for this activity. If the agent determines that the client knowingly made a false or misleading statement, the agent must adjudicate the period out of Canada, complete the record of decision (ROD) and refer to Misrepresentation to determine the type of sanction to impose. The agent must input the complete decision after determining the sanction.
       [Misrepresentation](/en/procedure/activity/misrepresentation.shtml)

**Reconsidering a decision**

EIA 52 states that a claim for benefits may be reconsidered as long as it results in an overpayment (OP) or an underpayment (UP). The time limit for reconsidering a claim is 36 months from the week benefits were paid or payable. This period is extended to 72 months if there is a false or misleading statement.
       [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

**Determining if a false statement was made**

A false statement is a statement that is incorrect or untrue. It can be the result of an intentional or negligent action, or it can be the result of an honest mistake.

For example, a client was out of Canada for one week but did not report the absence from Canada on the claimant’s report. At this point, the agent only knows that the information provided by the client is incorrect. Without an explanation from the client, it cannot be determined if the client intentionally or knowingly failed to provide this information. Regardless of whether it was intentional, or an honest mistake, the client did not report the absence from Canada; therefore, the reconsideration timeframe can be extended to 72 months.

**Determining if a false statement was knowingly made**

Knowingly means the agent can reasonably conclude that clients knew the information provided was untrue when they provided or did not report that information. There is no element of intent in this consideration. It is not necessary to determine a degree of fault. The agent must only establish that it is more likely that clients understood the information provided and did not accurately portray the facts.

In the case of an unreported absence from Canada, the investigator must send an INS5211 - Customs letter form to the client so the client can provide the reason for the absence and explain why it was not reported. If the client does not return the completed form or if the explanation for not reporting the absence does not prove it was unintentional or an honest mistake, it can then be determined that the client knowingly made a false statement or a misrepresentation.

If the client received payments by paper cheque, each cheque cashed can be considered a misrepresentation under EIA 38(1)(e). If the client received payments by direct deposit, each direct deposit payment or any excess amount the client received and did not return can be considered a misrepresentation under EIA 38(1)(f).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1803.dita) 

**Reviewing a potential case of voluntary disclosure**

The National Policy on Voluntary Disclosure encourages clients, employers and third parties to come forward and voluntarily disclose misrepresentations. According to this policy, voluntary disclosure occurs when a person admits to having knowingly made a false statement.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

An investigator may recommend that the file be reconsidered in light of the National Policy on Voluntary Disclosure .
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

There are 2 essential conditions for approving the voluntary disclosure:

- There is no investigation under way in relation to the voluntary disclosure when a client admits to making a false statement.

- The false statement would have resulted in punitive measures such as a penalty, a warning or prosecution had there been no voluntary disclosure.

According to the National Policy on Voluntary Disclosure , there is no limit to the number of times that a client can voluntarily disclose misrepresentations.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 

### Reviewing periods out of Canada

Source topic: `en_EN/task/aic_out_canada/reviewing_periods_out_of_canada.dita`

The client must declare all time spent outside of Canada regardless of duration.

Since November 22, 2009, the question “Were you outside Canada between Monday and Friday during the period from DD MM to DD MM?” has appeared on electronic claimant’s reports.

When a client incorrectly reports availability for work during a period that was spent out of Canada, such a statement does not automatically mean that a misrepresentation was committed. If the client’s explanation for the false statement is credible, it cannot be established that the statement was made knowingly , and therefore, no penalty is imposed. A statement of availability for which a client cannot provide any proof or explanation is however, considered a misrepresentation.

**Vacation out of Canada**

A client on vacation out of Canada does not qualify for regular benefits because the client is considered not available for work. The 13 - Outside Canada (D13) and 3 - Not available (D3) disentitlements are imposed for the vacation period out of Canada.

**Allowing benefits while out of Canada**

EIR 55 sets out exceptions and specific reasons why a client receiving regular or sickness benefits can be out of Canada. These reasons include the following:
       [EIR 55](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

- medical treatment

- illness of an immediate family member

- funeral

- approved training

- job search

In most cases, a client cannot combine the exceptions to receive benefits for 2 or more periods of 7 or 14 days. However, if the client is out of Canada for a certain period of time to visit a seriously ill or injured relative, and during the absence from Canada, that family member passes away, the client may benefit from the exceptions under EIR 55(1)(b) and 55(1)(d) . The client could be entitled to benefits for a period up to 14 days while out of Canada.
       [EIR 55(1)(b) and 55(1)(d)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

A 59 - Outside Canada - Allowed (D59) disentitlement is imposed for allowable absences and must have a valid and definite end date. It does not prevent payment, but is used as a notification that the client was out of the country. A D59 is not used when the client receives parental or maternity benefits, or CCB, or if the client is out of Canada for a period of less than 24 hours.

If the period outside Canada for which the reason does not meet the relief conditions of EIR 55(1) follows a period allowed, the allowed period of 7 days is calculated starting from the day after the departure date. The disentitlement applies starting on the eighth or fifteenth day after the allowed period (refer to Digest 10.11.8 — Out of Canada ), unless that day is the date of return.
       [EIR 55(1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html) 
       [Digest 10.11.8 — Out of Canada](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/absence-from-home.html#a10_11_8)

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1804.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1805.dita) 

### Imposing a disentitlement

Source topic: `en_EN/task/aic_out_canada/imposing_a_disentitlement.dita`

The D13 disentitlement is imposed for periods outside Canada when the reason is not accepted and is imposed for each complete calendar weekday (including statutory holidays) that the client is outside of Canada. This means that the disentitlement for being outside Canada is not imposed on the date of departure nor the date of the return, as those are partial days.

Disentitlements for non-availability (D3) are imposed based on the adjudication of the client’s availability. Therefore, they may be imposed for the dates of departure and return if the client’s availability is not proven for these days. This also applies to disentitlements for other types of benefits when the client cannot prove they meet the entitlement conditions for the type of benefits claimed, during the period outside Canada.

If the period outside of Canada for which the reason is not accepted follows a period allowed under EIR 55, when a disentitlement is imposed, the allowed period of 7 days is calculated starting from the day after the departure date. The disentitlement applies starting on the eighth or fifteenth day after the allowed period (refer to Digest 10.11.8 — Out of Canada ), unless that day is the date of return.
       [Digest 10.11.8 — Out of Canada](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/absence-from-home.html#a10_11_8) 

### Returning a file to Integrity

Source topic: `en_EN/task/aic_out_canada/returning_a_file_to_integrity.dita`

After conducting a full review of the investigation, if the Level 2 agent determines that facts are missing, the agent must return the file to the investigator for further fact-finding and indicates the information that is missing and necessary to adjudicate the issue. The Level 2 agent must not adjudicate the issue if facts are missing or incomplete.

Facts are not considered missing or incomplete if the investigator has followed up with the client when the client fails to report for an interview or fails to reply to a request for information. The investigator is not required to send a follow-up letter but must make 2 attempts on 2 different days to contact the client by telephone. If the investigator leaves a message on a voicemail, only one attempt is required and they must allow 48 hours for the client to respond.

If the investigator recommends that the Integrity case be considered as voluntary disclosure, but the investigation type is not 70 in NIIS, the officer returns the file to Integrity.

The Integrity Services Branch does not verify the employer’s or third party’s version against the client’s version in the following situations:

- The investigation results in an actual or potential OP of less than the Integrity investigative threshold.

- There is no other active investigation.

In these situations, the agent does not return the case to Integrity because the employer’s or the third party’s version is missing. The agent is not required to validate the threshold. 

### Defining claim status (CS)

Source topic: `en_EN/task/aic_out_canada/defining_claim_status_cs.dita`

A claim can be active, terminated, blocked or archived. The CS impacts which transactions can be input and when the letter of decision is sent:

- Active: The active claim is established and is currently displayed automatically in FTS. It is a claim for which benefits are still payable and that has not been terminated.

- Terminated: A terminated claim appears on the Dormant tab in FTS. It has ended but can be reactivated. Once the transaction to reactivate the claim has been processed, all inputs for the claim must be done the same as for an active claim.

- Blocked: In some cases, the claim that the agent must reconsider is on the Dormant tab in FTS, but there is a new active claim established and displayed on the Summary screen. The agent makes adjustments to this type of claim using BCS if the blocked status shows 1 - Updateable . Otherwise, IPOC intervention is required.

- Archived: Claims that are more than 7 years old are moved from the Dormant tab to the Archived tab. The officer can view an archived claim by changing the status of the archived claim from 1 - Non-Viewable to 2 - Viewable in FTS. Once the officer requests to make the claim viewable, the status field immediately displays 2 - Viewable and the claim becomes viewable the next business day for 2 weeks. Adjustments to this type of claim are processed with IPOC intervention. 

### Determining the order of FTS inputs

Source topic: `en_EN/task/aic_out_canada/determining_the_order_of_fts_inputs.dita`

Controlled, multiple-day inputs in FTS are required to establish separate OPs for each decision (i.e. unreported earnings and reason for separation [RFS]). When there is more than one reconsideration decision that results in an OP, the decisions must be input in the following order:

**Determining the input order for multiple transactions**

- full disentitlement

- partial disentitlement

- unreported earnings / unreported allocation of earnings

- indefinite disqualification

- definite disqualification

Controlled inputs in FTS are also required for UP and OP situations. The agent processes the inputs resulting in the OP first. Once the OP is established, the agent inputs an agreed deduction equal to the benefit rate amount. For more information, the agent refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

### BCS

Source topic: `en_EN/task/aic_out_canada/bcs.dita`

BCS allows certain types of transactions to be processed on blocked dormant claims. There are 2 options available: Estimate and Claim update .

**Claim update function**

When transactions must be input on a blocked claim, the Blocked Claims System tab in FTS must be reviewed to determine the CS in BCS. If the CS is 1 - Updateable , an update is requested using BCS and the transactions can be processed.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1806.dita) 

An update in BCS can only be done on one BPC at a time. When transactions are input but not processed, Yes appears in the Block Action Pending column and access is denied for input on all other BPCs until the requested transactions are processed. Access to a BPC with a pending action is limited to the agent who initiated that action.

If an update is requested by the agent but cannot be completed by BCS, on the next processing day, the “Blocked claim not updated or not calculated” message is displayed along with the exception, error or warning on the MR05 screen.

Agents review the exception, error or warning on the Results tab in BCS for further action. If the update cannot be completed using BCS, the system presents an estimate result. The decision can be sent to IPOC using the Forward via MM06 link, which creates the prefilled M106 and MM06.

**Estimate function**

The Estimate function in BCS allows agents to view and evaluate the end results without processing the transactions. Estimates are possible for blocked claims with a CS 1 - Updateable as well as unblocked dormant claims, provided the CS is 05 (inactive) or 06 (terminated) .

BCS Estimate transactions are processed overnight and the results are available on the Results tab the next day. Agents that have requested an estimate can view the end result and forward the request for IPOC intervention using the prefilled MM06 available on the Results tab. 

### Creating an Operational Centre Memo (MM06) transaction for multiple issues

Source topic: `en_EN/task/aic_out_canada/creating_an_operational_centre_memo_mm0_12498087.dita`

When the MM06 includes multiple issues, if at least one issue is deemed to be a misrepresentation whereas at least another one is not, the agent ensures to include the appropriate OP message code for each issue in the Remarks section. 

### Record of decision (ROD)

Source topic: `en_EN/task/aic_out_canada/record_of_decision_rod.dita`

The Level 2 agent must record and document each decision in a separate ROD. 

### Note

Source topic: `en_EN/common_notes/note_c_1803.dita`

Note:

A false statement knowingly made does not always result in an OP of benefits. Since a monetary penalty is calculated based on the OP resulting from the misrepresentation, the agent can consider a warning letter if the client knowingly made a false statement but this misrepresentation does not result in an OP. 

### Example 1

Source topic: `en_EN/common_notes/note_c_1804.dita`

Example 1:

A client leaves Canada on May 9, 2016 to attend a bona fide job interview. The client is allowed 7 consecutive days to be out of Canada for this purpose. The client will not be returning to Canada until May 20, 2016. To determine the 7-day allowable period, the agent must exclude the day of departure (May 9, 2016) and count 7 consecutive days beginning with May 10, 2016. The 7-day allowable period will end as of May 16, 2016. A D59 is imposed for the allowable period from May 9, 2016 to May 16, 2016. Since the client is not returning to Canada until a later date, a 13 - Outside Canada disentitlement (D13) is imposed effective May 17, 2016 up to and including May 19, 2016, the day before the date of return. A D3 is also imposed if the client cannot prove availability for the same period. 

### Example 2

Source topic: `en_EN/common_notes/note_c_1805.dita`

Example 2:

A client leaves Canada on May 9, 2016 to attend a bona fide job interview. The client is allowed 7 consecutive days to be out of Canada for this purpose. The client will be returning to Canada on May 17, 2016 (the 8th day). A D59 is imposed for the allowable period from May 9, 2016 to May 16, 2016. Since the client is returning to Canada on the 8th day, the client is not disentitled for being out of Canada on that day. 

### Note

Source topic: `en_EN/common_notes/note_c_1806.dita`

Note:

At this time, BCS cannot process a benefit period extension, the recalculation of a claim or the removal of a manual action (MA). The agent must send an Operational Centre Memo (MM06) transaction asking IPOC to process these transactions. 

## Regional considerations

Source topic: `en_EN/task/aic_out_canada/regional_considerations.dita`

**Quebec — Returning the file to Integrity**

In addition to the information already indicated in this procedure, return the file to Integrity as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a Cc.

- In NWS, create a client Note and type “Measure — returned to Integrity” and include the date (YYYY-MM-DD). 

## What you need to look for

Source topic: `en_EN/task/aic_out_canada/what_you_need_to_look_for.dita`

### In NIIS:

Source topic: `en_EN/task/aic_out_canada/in_niis.dita`

- Review the IC07 Subject Enquiry screen for all active and prior cases.

- Review the IC04 Observation screen for a computer generated investigation.

- Review the IC08 Case Summary screen to see the actions taken on the case.

- Review the IC56 Case Notes screen to ensure you have the complete case.

- Review the IC50 Report of Clerical Investigation or IC70 Report of Investigation screen.

- Is there an Integrity Investigation Sheet?

- Is there a Report of Interview? 

### In Imaging:

Source topic: `en_EN/task/aic_out_canada/in_imaging.dita`

- Are there any documents that are relevant to the case? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/aic_out_canada/in_integrity_investigations_document_up_6a8da64b.dita`

- Are there any documents that are relevant to the case? 

### In NWS:

Source topic: `en_EN/task/aic_out_canada/in_nws.dita`

- Review the application for benefits.

- Review SROCs, RODs, Action Item (AI) and Call Back (CB) WIs for information relevant to the case.

- Are there documents related to the issue? 

### In FTS:

Source topic: `en_EN/task/aic_out_canada/in_fts.dita`

- If applicable, review the claimant reports for the weeks under investigation.

- Is there an exemption from reporting?

- If yes, did the client receive payments by direct deposit?

- What is the CS (active, terminated, blocked or archived)?

- If the claim is blocked, what is the CS in BCS? 

### In ACS:

Source topic: `en_EN/task/aic_out_canada/in_acs.dita`

- Was an INS5211 - Customs letter sent to the client by Integrity? 

## Step by step

Source topic: `en_EN/task/aic_out_canada/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/aic_out_canada/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/aic_out_canada/reviewing_the_file_level_2.dita`

- Determine if there is a false statement:

- If no, go to step 2.

- If yes, go to step 3.

- Determine if the request for reconsideration was made within the 36-month time limit:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_out_canada#nowithinreconsideration)

- Determine if the request for reconsideration is within the maximum reconsideration timeframe of 72 months:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_out_canada#nowithinreconsideration)

- Determine if the information gathered by Integrity is complete:

- If the information is complete, go to step 5.

- If the information is incomplete, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_out_canada#refering)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1667.dita)

- In NWS, create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction ):

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Adjudicate the undeclared period spent out of Canada. (if necessary, refer to Out of Canada or Digest 10 — Availability .)

- If a disentitlement for the period out of Canada must be imposed, go to step 7.

- If entitlement is in order, go to Entitlement in order .
               [Entitlement in order](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_out_canada#CaseInOrder)

- Determine if the client knowingly made a false or misleading statement as described in Digest 18.3.1.4 — Misleading and Digest 18.3.1.5 — Knowingly :

- If there is a false statement that is knowingly made, go to step 8.

- If there is a false statement that is not knowingly made, go to step 13.

- If there is no false statement, go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_out_canada#reconsideration36)

- Determine if the investigator recommends that the file be reconsidered in light of a voluntary disclosure, as described in National Policy on Voluntary Disclosure :

- If the voluntary disclosure criteria are not met, go to step 9.

- If the voluntary disclosure criteria are met but the investigation type in NIIS is not 70, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_out_canada#refering)

- If the voluntary disclosure criteria are met and the investigation type in NIIS is 70, go to Voluntary disclosure approved .
               [Voluntary disclosure approved](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_out_canada#voluntarydisclosure)

- Determine if a D13 and another disentitlement apply:

- If a D13 and another disentitlement apply, go to step 10.

- If only a D13 applies, go to step 11.

- In NWS, create a ROD for the D3 or other disentitlement as follows (if necessary, refer to the applicable Out of Canada procedure for guidance on the details to include):

- Comments: Type “[Integrity case number] — [disentitlement code] from XXXX to XXXX.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In NWS, create a ROD for the out of Canada issue as follows:

- Comments: Type “[Integrity case number] — out of Canada.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Go to step 12.

- Continue with Adjudicating client or third party misrepresentation — Monetary penalty or warning letter to determine the appropriate sanctions and input all the decisions.

- Determine the reconsideration timeframe for the false or misleading statement not knowingly made :

- If the false statement was made within the prescribed period of 36 months , go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_out_canada#reconsideration36)

- If the false statement was made within the extended period of 72 months , go to Reconsideration after 36 months .
               [Reconsideration after 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_out_canada#reconsideration37) 

#### Not within reconsideration timeframe

Source topic: `en_EN/task/aic_out_canada/not_within_reconsideration_timeframe_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — EIA 52 — not within reconsideration timeframe.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, from the Report for Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Not within reconsideration timeframe, no adjudication for the out of Canada issue.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the Claim Review (CR) Integrity WI. 

#### Returning the file to Integrity

Source topic: `en_EN/task/aic_out_canada/returning_the_file_to_integrity_level_2.dita`

- In NIIS, from the Document tab, select IC70 Report of Investigation or IC50 Report of Clerical Investigation , depending on the case, and complete the following fields:

- Select Recommendation .

- Refer the file to Integrity as follow:

- Select Yes (IC70) .

- Check the box (IC50) .

- Enter the missing or additional information required in the text area.

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1807.dita)

- In FTS, click the Outstanding Registrations link to cancel the registration number as follows:

- Select Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Select Update .

- Return the paper documents relating to the investigation to the Investigator who signed the Report of Investigation.

- In NWS, complete the CR Integrity WI. 

#### Entitlement in order

Source topic: `en_EN/task/aic_out_canada/entitlement_in_order_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — out of Canada — entitlement in order.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain why entitlement is considered in order, e.g. the client declared himself or herself unavailable on the claimant’s reports and was not paid benefits.

- In FTS, determine if an MA is imposed to stop payments for the out of Canada issue:

- If an MA is imposed, go to step 3.

- If an MA is not imposed, go to step 4.

- Select the Renewal/Revised (M106) transaction to remove the MA as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number

- Select Update .

- Go to step 5.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, from the Report for Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Entitlement in order.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Voluntary disclosure approved

Source topic: `en_EN/task/aic_out_canada/voluntary_disclosure_approved_level_2.dita`

- Determine if a D13 and another disentitlement apply:

- If a D13 and another disentitlement apply, go to step 2.

- If only a D13 applies, go to step 3.

- In NWS, create a ROD for the D3 or other disentitlement as follows (if needed, refer to the applicable Out of Canada procedure for guidance on the details to include):

- Comments: Type “[Integrity case number] — [enter the disentitlement code] from XXXX to XXXX.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In NWS, create a ROD for the out of Canada issue as follows:

- Comments: Type “[Integrity case number] — out of Canada.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD for the voluntary disclosure issue as follows:

- Comments: Type “[Integrity case number] — voluntary disclosure approved.”

- Details: Document the decision and rationale according to the National Fact-Finding, Documentation and Retention .
               [National Fact-Finding, Documentation and Retention](http://servicecanada.prv/eng/ei/reference-material/policy-legislation/national_policy_factfinding.shtml)

- Explain that the client meets the 2 conditions for the use of the National Policy on Voluntary Disclosure .
               [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 6.

- If the claim is terminated, but may be reactivated:

- On the Terminated tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 6.

- If the claim is blocked or archived, go to step 13.

- Determine if there is an allowed period for the absence from Canada:

- If yes, go to step 7.

- If no, go to step 8.

- Select the Disqualifications/Disentitlements (M161) transaction and input the D59 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 59 - Outside Canada - Allowed .

- Start date: Enter the start date for the allowed period.

- End date: Enter the end date for the allowed period.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if the decision is to impose a D13 and another disentitlement (D3, D33, D34, D51 or D61):

- If imposing a D13 and another disentitlement, go to step 9.

- If imposing only a D13, go to step 10.

- Select the Disqualifications/Disentitlements (M161) transaction and input the (D3, D33, D34, D51 or D61) as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select the appropriate disentitlement .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if an MA is imposed to stop payments for the out of Canada issue:

- If an MA is imposed, go to step 11.

- If an MA is not imposed, go to step 12.

- In FTS, select the Renewal/Revised (M106) to remove the MA and input the D13 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 13 - Outside Canada .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 23.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the D13 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 13 - Outside Canada .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 23.

- Determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 2 - Not blocked is displayed, return to step 5.

- If 1 - Updateable is displayed, go to step 14.

- If any other CS is displayed, go to step 21.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 15.

- If all rows are blank, go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 15.

- If all rows are blank, go to step 17.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following fields:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 -Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- On the Disentitlements tab, input the disentitlement on the Disentitlements section as follows (up to 4 disentitlements in BCS can be imposed, rescinded or terminated):

- Action: Select A - Add .

- Type: Select the appropriate disentitlements.

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 20.

- If the transaction shown is correct, click Close and go to step 23.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 18.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the unreported out of Canada period.

- Work item: Select 91 - Overpayment .

- Work type: Select 1 - Misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D-13 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 2: Type the appropriate option:

- If there is another disentitlement and an allowed period, type “D [3, 33, 34, 51 or 61] from w/c [XXXX-X] to [XXXX-X] and D59 from w/c [XXXX-X] to [XXXX-X].”

- If there is another disentitlement but no allowed period, type “D [3, 33, 34, 51 or 61] from w/c [XXXX-X] to [XXXX-X].”

- If there is no other disentitlement but there is an allowed period, type “D59 from w/c [XXXX-X] to [XXXX-X].”

- If none of the above applies, leave blank.

- Remarks line 3: Type “ACS letter already sent.”

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1808.dita) 

- Date claimant called or information sent (1542)

- D13 or D38 Outside Canada (Interstate option) / on vacation within or outside Canada (2924)

- D-13 Outside Canada / D-03 Possibly on vacation (option Interstate message)

- We/We have reconsidered (2916)

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- blank / according to our records / contrary to what you told us (2925)

- Blank / Additionally, you were on vacation / Text: Indicate why was not available (2927)

- Blank / Various explanations why certain amount of days allowed out of Canada (2932)

- Various reasons for penalty and violation (2935): Select Blank .

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment - No misrepresentation and active claim

- Overpayment - No misrepresentation and inactive claim

- In ACS, create and send the D-70-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Voluntary disclosure / Administrative Rule - Undeclared Earnings (2664):

- Voluntary disclosure of information

- Subjects of the voluntary disclosure (2665)

- Option #7: Text-Insert appropriate reason(s) (1618): Type “Period Outside Canada”

- Blank/Reminder: Provide information on report (2667)

- Provide full and accurate information on each report and correct any incorrect reports as soon as possible .

- Overpayment messages (2452): Select the appropriate option.

- Right to Request a Reconsideration (4169)

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Outside Canada .

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Reconsideration within 36 months

Source topic: `en_EN/task/aic_out_canada/reconsideration_within_36_months_level_2.dita`

- Determine if a D13 and another disentitlement apply:

- If a D13 and another disentitlement apply, go to step 2.

- If only a D13 applies, go to step 3.

- In NWS, create a ROD for the D3 or other disentitlement as follows (if needed, refer to the applicable Out of Canada procedure for guidance on the details to include):

- Comments: Type “[Integrity case number] — [enter the disentitlement code] from XXXX to XXXX.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In NWS, create a ROD for the out of Canada issue as follows:

- Comments: Type “[Integrity case number] — out of Canada.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 5.

- If the claim is terminated, but may be reactivated:

- On the Terminated tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 5.

- If the claim is blocked or archived, go to step 12.

- Determine if there is an allowed period for the absence from Canada:

- If yes, go to step 6.

- If no, go to step 7.

- Select the Disqualifications/Disentitlements (M161) transaction and input the D59 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 59 - Outside Canada - Allowed .

- Start date: Enter the start date for the allowed period.

- End date: Enter the end date for the allowed period.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if the decision is to impose a D13 and another disentitlement (D3, D33, D34, D51 or D61):

- If imposing a D13 and another disentitlement, go to step 8.

- If imposing only a D13, go to step 9.

- Select the Disqualifications/Disentitlements (M161) transaction and input the D3, D33, D34, D51 or D61 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select the appropriate disentitlement.

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if an MA is imposed to stop payments for out of Canada issue:

- If an MA is imposed, go to step 10.

- If an MA is not imposed, go to step 11.

- In FTS, select the Renewal/Revised (M106) transaction to remove the MA and input the D13 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 13 - Outside Canada .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 22.

- Select the Disqualifications/Disentitlements (M161) transaction and input the D13 as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 13 - Outside Canada .

- Start date: Enter the start date for the disentitlement.

- End date: Enter the end date for the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 22.

- Determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 2 - Not blocked is displayed, return to step 4.

- If 1 - Updateable is displayed, go to step 13.

- If any other CS is displayed, go to step 20.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 14.

- If all rows are blank, go to step 16.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 14.

- If all rows are blank, go to step 16.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following fields:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- On the Disentitlements tab, input the disentitlement on the Disentitlements section as follows (up to 4 disentitlements in BCS can be imposed, rescinded or terminated):

- Action: Select A - Add .

- Type: Select the appropriate disentitlement.

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 23.

- If the transaction shown is correct, select Close and go to step 26.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 17.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the request for the unreported out of Canada period.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D13 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 2: Type the appropriate option:

- If there is another disentitlement and an allowed period, type “D [3, 33, 34, 51 or 61] from w/c [XXXX-X] to [XXXX-X] and D59 from w/c [XXXX-X] to [XXXX-X].”

- If there is another disentitlement but no allowed period, type “D [3, 33, 34, 51 or 61] from w/c [XXXX-X] to [XXXX-X].”

- If there is no other disentitlement but there is an allowed period, type “D59 from w/c [XXXX-X] to [XXXX-X].”

- If none of the above applies, leave blank.

- Remarks line 3: Type “ACS letter already sent.”

- Remarks line 5: Enter your name and telephone number.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1808.dita) 

- Date claimant called or information sent (1542)

- D13 or D38 Outside Canada (Interstate option) / on vacation within or outside Canada (2924):

- D-13 Outside Canada / D-03 Possibly on vacation (option Interstate message)

- We/We have reconsidered (2916)

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- blank / according to our records / contrary to what you told us (2925)

- Blank / Additionally, you were on vacation / Text: Indicate why was not available (2927)

- Blank / Various explanations why certain amount of days allowed out of Canada (2932)

- Various reasons for penalty and violation (2935): Select Blank .

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment.

- Overpayment - No misrepresentation and active claim .

- Overpayment - No misrepresentation and inactive claim .

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Outside of Canada .

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Reconsideration after 36 months

Source topic: `en_EN/task/aic_out_canada/reconsideration_after_36_months_level_2.dita`

- Determine if a D13 and another disentitlement apply:

- If a D13 and another disentitlement apply, go to step 2.

- If only a D13 applies, go to step 3.

- In NWS, create a ROD for the D3 or other disentitlement as follows (if needed, refer to the applicable Out of Canada procedure for guidance on the details to include):

- Comments: Type “[Integrity case number] — [enter the disentitlement code, e.g. D34) from XXXX to XXXX.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In NWS, create a ROD for the out of Canada issue as follows:

- Comments: Type “[Integrity case number] — out of Canada.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed, go to step 5.

- If any other CS is displayed, go to step 12.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 6.

- If all rows are blank, go to step 8.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 6.

- If all rows are blank, go to step 8.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following fields:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- On the Disentitlements tab, input the disentitlement on the Disentitlements section as follows (up to 4 disentitlements in BCS can be imposed, rescinded or terminated):

- Action: Select A - Add .

- Type: Select the appropriate disentitlement.

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Click Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 11.

- If the transaction shown is correct, click Close and go to step 14.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 9.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the undeclared out of Canada.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D13 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 2: Type the appropriate option:

- If there is another disentitlement and an allowed period, type “D [3, 33, 34, 51 or 61] from w/c [XXXX-X] to [XXXX-X] and D59 [XXXX-X] to [XXXX-X].”

- If there is another disentitlement but no allowed period, type “D [3, 33, 34, 51 or 61] from w/c [XXXX-X] to [XXXX-X].”

- If there is no other disentitlement but there is an allowed period, type “D59 from w/c [XXXX-X] to [XXXX-X].”

- If none of the above applies, leave blank.

- Remarks line 3: Type “ACS letter already sent.”

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1808.dita) 

- Date claimant called or information sent (1542)

- Decision reconsidered beyond 36 months (2595): Select Decision reconsidered beyond 36 months due to false representations

- D13 or D38 Outside Canada (Interstate option) / on vacation within or outside Canada (2924):

- D-13 Outside Canada / D-03 Possibly on vacation (option Interstate message)

- We/We have reconsidered (2916)

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- blank / according to our records / contrary to what you told us (2925)

- Blank / Additionally, you were on vacation / Text: Indicate why was not available (2927)

- Blank / Various explanations why certain amount of days allowed out of Canada (2932)

- Various reasons for penalty and violation (2935): Select Blank .

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment - No misrepresentation and active claim

- Overpayment - No misrepresentation and inactive claim

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Outside Canada .

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR WI for Investigation and Control. 

#### Note

Source topic: `en_EN/common_notes/note_c_1667.dita`

Note:

Cases with an OP below the Integrity investigative threshold are referred for adjudication only when specific exceptions are met (voluntary disclosure or impact on an active claim). In these cases, the employer’s or any other party’s version does not have to be verified and the file must not be returned to Integrity. 

#### Note

Source topic: `en_EN/common_notes/note_c_1807.dita`

Note:

The regional consideration for agents in the Quebec region is as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a Cc.

- In NWS, create a client Note and type “Measure — returned to Integrity” and include the date (YYYY-MM-DD). 

#### Note

Source topic: `en_EN/common_notes/note_c_1791.dita`

Note:

An update in BCS can only be done on one BPC at a time. 

#### Note

Source topic: `en_EN/common_notes/note_c_1808.dita`

Note:

If imposing a D13 and another disentitlement, adjust the letter attributes accordingly. If needed, refer to the applicable Out of Canada procedure for guidance on the information to include.
       [Out of Canada](/en/procedure/activity/out_canada.shtml)

     [Out of Canada](/en/procedure/activity/out_canada.shtml) 

## Policy reference

Source topic: `en_EN/task/aic_out_canada/policy_reference.dita`

- Digest 10 — Availability
         [Digest 10 — Availability](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/table-of-contents.html)

- Digest 17 — Reconsideration, Amendment of a decision, and Error Corrections
         [Digest 17 — Reconsideration, Amendment of a decision, and Error Corrections](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/table-of-contents.html)

- Digest 18 — Policy on Penalties
         [Digest 18 — Policy on Penalties](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/table-of-contents.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 37(b)
         [EIA 37(b)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-37.html)

- EIA 38
         [EIA 38](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-11.html)

- EIA 152(2)(b)
         [EIA 152(2)(b)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-152.html)

- EIR 55
         [EIR 55](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

- EIA 52
         [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 
