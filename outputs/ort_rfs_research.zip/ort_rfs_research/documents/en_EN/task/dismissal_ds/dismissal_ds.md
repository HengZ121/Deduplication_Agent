# Adjudicating a dismissal or suspension — Continuing claim

Source map: `en_EN/task/dismissal_ds/dismissal_ds.ditamap`

## Summary

Source topic: `en_EN/task/dismissal_ds/summary.dita`

Summary: Dismissal or suspension from employment may affect a client’s entitlement to regular benefits. The officer must determine whether the client was dismissed or suspended because of misconduct. 

## What you need to know

Source topic: `en_EN/task/dismissal_ds/what_you_need_to_know.dita`

### Defining misconduct

Source topic: `en_EN/task/dismissal_ds/defining_misconduct.dita`

If there is an indication of misconduct, Level 2 must follow the Fact-finding procedure and render a decision.

We can define misconduct as:

- a wrongful act or breach of an obligation in the employment contract, committed voluntary, deliberately, knowingly or of such a careless or negligent nature that it appears to have been committed deliberately, and

- which has a negative effect on the continuation of the employer-employee relationship.

In this respect, the Commission must:

- offer the client and employer the possibility of providing information on the reason for separation;

- take this information into account in its decision.

When there are contradictory statements, allow both parties to provide an explanation or clarification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1737.dita) 

### Client does not want employer to be contacted

Source topic: `en_EN/task/dismissal_ds/client_does_not_want_employer_to_be_contacted.dita`

If the client does not want the employer to be contacted, officers must explain that they are legally required to fact-find with the employer. 

### Railway misconduct

Source topic: `en_EN/task/dismissal_ds/railway_misconduct.dita`

In the interest of public safety, the rules governing railway employees in the course of their duties, particularly those in the operating groups, are very strict. Railway employees are subject to suspension or dismissal for causes which, in other industries, would not carry such severe penalties. When an employee from the railway sector (railway employee) is dismissed or suspended, the officer must request a copy of the hearing transcript issued by the disciplinary committee, as well as all of the other files containing evidence regarding the separation. 

### Mandatory retirement

Source topic: `en_EN/task/dismissal_ds/mandatory_retirement.dita`

Human rights legislation in Canada prohibits mandatory retirement. Very few occupations are exempt from this legislation. Some employers may be able to demonstrate a genuine reason for mandatory retirement, but these cases are rare.

In cases of mandatory retirement, clients do not voluntarily leave their employment. The separation is initiated by the employer. Consequently, a Level 2 officer must adjudicate the RFS as a dismissal and determine whether clients lost their employment due to misconduct. Normally, in the case of mandatory retirement, the facts on file support a decision of misconduct not proven. Written notice to the employer that EI benefits have been allowed is not required as there is no allegation of misconduct. 

### Imposing a disqualification or disentitlement

Source topic: `en_EN/task/dismissal_ds/imposing_a_disqualification_or_disentitlement.dita`

Once it is determined that the client was dismissed for misconduct, the officer must determine whether an indefinite disqualification or disentitlement applies.

If it is determined that the client lost the employment due to misconduct, an indefinite disqualification is imposed on the claim for regular benefits beginning the Sunday of the week the event took place, unless the client has worked enough insurable hours since the misconduct to establish a new claim.

When the dismissal or suspension is adjudicated and the ROE has been received, the Special condition field of the ROE must be updated.

**Disentitled due to a suspension**

There may be situations where the employee is suspended from his duties for having acted in a way that resembles misconduct. The employer generally uses that suspension to review the evidence and determine if a disciplinary measure is sufficient or if a definitive dismissal is appropriate.

A client suspended because of misconduct is not entitled to benefits for each day of the suspension. The 42 - Suspension from employment disentitlement (D42) is imposed to indicate a suspension from work for proven misconduct.

A client can gain relief from a D42 if one of the following conditions is met:

- The period of suspension expires.

- The client loses or voluntarily leaves his or her employment.

- After the period of suspension begins, the client accumulates with another employer the number of hours of insured employment required to establish a new claim.

**Dismissed or suspended within 3 weeks of anticipated layoff**

If the client was dismissed within 3 weeks of an anticipated layoff or the end of term employment, the 44 - Loss of employment in anticipation of layoff disentitlement (D44) is imposed. If the client was dismissed more than 3 weeks before the anticipated layoff and in all other cases except suspension , the 10 - Dismissal - misconduct proven indefinite disqualification (D10) is imposed.

**Effect of disqualification or disentitlement on special benefits**

The D10 disqualification and the D42 and D44 disentitlements are suspended when special benefits are claimed and otherwise payable. 

### Employment is not insurable

Source topic: `en_EN/task/dismissal_ds/employment_is_not_insurable.dita`

Adjudication of the dismissal or suspension is required when the employment is not insurable due to a non-arm’s length issue. Adjudication of the dismissal or suspension is not required if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. 

### Automated adjudication

Source topic: `en_EN/task/dismissal_ds/automated_adjudication.dita`

ACP does not automate a Level 2 decision for dismissal. 

### Previously deferred decision

Source topic: `en_EN/task/dismissal_ds/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a D10 disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D10 that is on file and update the Special Condition field on the ROE in RCM. 

### Notifying the employer

Source topic: `en_EN/task/dismissal_ds/notifying_the_employer.dita`

The employer must be notified in writing of the decision and provided with the right to request reconsideration in cases where misconduct was not proven unless the employer advises that the client was dismissed for unsuitability. In that case, no misconduct is alleged and therefore no notification is required. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/dismissal_ds/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the reason for separation (RFS) was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1737.dita`

Note:

For information regarding reason for separation (RFS) issues resulting from a client not complying with the employer’s COVID-19 vaccination policy, the officer refers to the EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo) .
       [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml)

     [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml) 

## Regional considerations

Source topic: `en_EN/task/dismissal_ds/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/dismissal_ds/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/dismissal_ds/in_nws.dita`

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the dismissal or suspension on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Dismissal section of this or a previous EI application? 

### In FTS:

Source topic: `en_EN/task/dismissal_ds/in_fts.dita`

- Have claimant’s reports been processed for the period in question?

- If yes, when was the original statement made?

- Is there a 75 - Verification of reason for termination of Employment manual action (MA75) imposed to stop payments?

- What is the benefit type (BT)? 

### In RCM:

Source topic: `en_EN/task/dismissal_ds/in_rcm.dita`

- Is there an ROE for the dismissal or suspension?

- If yes, what is the RFS indicated?

- Are there any comments related to the dismissal or suspension? 

### In Imaging:

Source topic: `en_EN/task/dismissal_ds/in_imaging.dita`

- Are there any imaged documents that may provide additional information on the dismissal or suspension? 

## Step by step

Source topic: `en_EN/task/dismissal_ds/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/dismissal_ds/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/dismissal_ds/reviewing_the_file_level_2.dita`

- Determine if the facts on file clearly indicate that the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds#NotInsurable)

- If the facts do not clearly indicate that the employment is not insurable for one of these reasons, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if there is enough information on file to make a decision:

- If additional details are needed, go to step 5.

- If additional details are not needed, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/dismissal_ds/fact-finding_level_2.dita`

- Fact-find with the client and the employer by referring to the Fact Finding Guide or Digest 7 — Misconduct to determine the questions to ask.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3231.dita)

- Determine if the client or employer was reached during fact-finding:

- If the client or employer was reached, go to step 7.

- If the client or employer was not reached or did not reply to the E-02-00-00 email, the N-10-00-00 letter or the Z-00-00-00 letter, go to step 8.

- In NWS, add details to the draft SROC created during fact-finding, or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “[Dismissal or Suspension] — [employer’s name] — [last day worked or start date of suspension] — [client or employer].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3232.dita) 

#### Adjudicating a dismissal or suspension

Source topic: `en_EN/task/dismissal_ds/adjudicating_a_dismissal_or_suspension_level_2.dita`

- Determine if misconduct is proven by considering all evidence provided by both the client and the employer, and the principles outlined in the EIA, EIR and case law. Refer to Digest 7 — Misconduct as needed.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3233.dita) 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/dismissal_ds/record_of_decision_rod__creation_level_2.dita`

- In NWS, create a ROD and complete the following fields:

- Comments: Type the appropriate comments based on the decision:

- If the decision is that misconduct not proven, type “[Dismissal or Suspension] — [employer’s name] — [last day worked or start date of suspension] — misconduct not proven.”

- If the decision is that misconduct proven, type “[Dismissal or Suspension] — [employer’s name] — [last day worked or start date of suspension] — misconduct proven.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If the decision is Misconduct not proven, select Save .

- If the decision is Dismissal — Misconduct proven or Suspension — Misconduct proven, select Draft, because you need to verbally communicate the decision.

- If the decision is Dismissed or suspended before anticipated layoff or end of term of employment — Misconduct proven, select Draft , because you may need to verbally communicate the decision.

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2139.dita) 

#### Inputs and communication

Source topic: `en_EN/task/dismissal_ds/inputs_and_communication_level_2.dita`

- Select the appropriate section based on the decision:

- Dismissal — Misconduct proven
               [Dismissal — Misconduct proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds#Misc)

- Dismissal — Misconduct not proven
               [Dismissal — Misconduct not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds#NoMisc)

- Suspension — Misconduct proven
               [Suspension — Misconduct proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds#SuspMisc)

- Suspension — Misconduct not proven
               [Suspension — Misconduct not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds#SuspNoMisc)

- Dismissed or suspended before anticipated layoff or end of term of employment — Misconduct proven
               [Dismissed or suspended before anticipated layoff or end of term of employment — Misconduct proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds#D44)

- Dismissal - Misconduct not proven — Rescinding a D10
               [Dismissal - Misconduct not proven — Rescinding a D10](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds#Dismmisc) 

#### Dismissal — Misconduct proven

Source topic: `en_EN/task/dismissal_ds/dismissal__misconduct_proven_level_2.dita`

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 2.

- If the client was not reached by telephone during fact-finding, go to step 3.

- Verbally communicate the decision to the client.

- In RCM, determine if the ROE with the dismissal has been received:

- If the ROE has been received, go to step 4.

- If the ROE has not been received, go to step 5.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select M - Dismissal .

- Special condition: Select Misconduct proven .

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3234.dita)

- In FTS, determine if an MA75 is imposed for the dismissal:

- If an MA75 is imposed, go to step 6.

- If an MA75 is not imposed, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3235.dita)

- Select the Renewal/Revised (M106) transaction and remove the MA75 as follows:

- Manual Action: Select 75 - Verification of reason for termination of employment .

- Rescind: Check the box.

- Action: Select Add .

- Disqualification: Select 10 - Dismissal - misconduct proven .

- Effective: Enter the w/c for the effective start date of the dismissal.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration open for subsequent transactions

- Select Update .

- Go to step 8.

- Select the Disqualifications/Disentitlements (M161) and impose the disqualification as follows:

- Action: Select Add .

- Disqualification: Select 10 - Dismissal - misconduct proven .

- Effective: Enter the w/c for the effective start date of the dismissal.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration open for subsequent transactions.

- Select Update .

- In ACS, create and send the D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits and does not have enough hours since the dismissal to qualify, select the following attributes:

- Disqualifications – Definite/indefinite – previous/current/revision (2970): Select D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revision) .

- D11 / D10 / Both / Previous disqualification / Revision – Initial/Renewal or Revision (2542): Select Disqualification message .

- Disqualification message (2543): Select D10 - Misconduct .

- D10 - No benefits payable (Date of event: before, on, or after the BPC date) (2546): Select D10 - Date of event after BPC and the appropriate options.

- D10 - Min hrs req for reg ben/Insuf. hrs accum. since event reg/Insufficient hrs reg+fishing (2547):

- If the client has not worked since the disqualifying event, select Minimum hours required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious the client does not have enough hours since the disqualifying event to qualify, select Insufficient hours accumulated since event for regular benefits or Insufficient hours accumulated since event for regular benefits and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but you do not have the information or knowledge to complete this block, select Minimum hours required to qualify for regular benefits .

- If the client is requesting regular benefits and has enough hours since the dismissal to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message / D10 Message (1503): Select D10 message .

- If the client is requesting special benefits and does not have enough hours since the dismissal to qualify for regular benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- Not entitled to regular after special: - (D10/D11) or (Claim is BPNE) - Initial or renewal claim or D42 – D43 (2540): Select (D11/D10) imposed - Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491): Select D10 imposed - Special benefits allowed .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D10 Min hours required to qualify for regular benefits/Not enough hours worked since event for regular/Not enough hours worked since event for regular and not enough fishing earnings for fishing benefits (2547):

- If the client has not worked since the disqualifying event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious there are insufficient hours since the disqualifying event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but you do not have the information or knowledge to complete this block, select Min hrs required to qualify for regular benefits .

- If the client is requesting special benefits and has enough hours since the dismissal to qualify for regular benefits, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (1503): Select D10 message .

- Special benefits approved (3046): Select BT and the appropriate options.

- Right to a Request Reconsideration (with Blank option) (4169): Select Right to request a reconsideration .

- In NWS, complete the WI related to the dismissal. 

#### Dismissal — Misconduct not proven

Source topic: `en_EN/task/dismissal_ds/dismissal__misconduct_not_proven_level_2.dita`

- In RCM, determine if the ROE with the dismissal has been received:

- If yes, go to step 2.

- If no , go to step 3.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select M - Dismissal .

- Special condition: Select Misconduct not proven .

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3234.dita)

- In FTS, determine if an MA75 is imposed for the dismissal:

- If an MA75 is imposed, go to step 4.

- If an MA75 is not imposed and the registration number is not a recalculation registration number, go to step 5.

- If an MA75 is not imposed but the registration number is a recalculation registration number, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3235.dita)

- Select Renewal/Revised (M106) transaction and remove the MA75 as follows:

- Manual Action: Select 75 - Verification of reason for termination of employment .

- Rescind: Check the box.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration open for subsequent transactions.

- Select Update .

- Go to step 6.

- Select the Renewal/Revised (M106) transaction and complete the outstanding registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- If there is an outstanding CR Recalculation WI, select D - No to leave the registration open for subsequent transactions.

- If there is no outstanding CR Recalculation WI, select C - Yes to clear the registration number.

- Select Update .

- In ACS, in cases of alleged misconduct inform the employer of the decision by sending the Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved reason for separation .

- Reason for Claim Approval (2783):

- If fact-finding determined that misconduct was not proven, select No Misconduct .

- If the employer failed to provide information regarding the dismissal, select Insufficient information to prove Misconduct .

- Warning to Employer Re Monies paid to Claimant (2788):

- If the employer is required to pay wages, pension, etc. (if there are challenge or grievance procedures underway), select Warning to ER: To inform us if pays any monies to employee .

- If there is no information on whether challenge or grievance procedures are underway, select Blank .

- You / We are writing to inform you that you (2793) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI related to the dismissal. 

#### Suspension — Misconduct proven

Source topic: `en_EN/task/dismissal_ds/suspension__misconduct_proven_level_2.dita`

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 2.

- If the client was not reached by telephone during fact-finding, go to step 3.

- Verbally communicate the decision to the client.

- In RCM, determine if the ROE with the suspension has been received:

- If yes, go to step 4.

- If no, go to step 5.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select M - Dismissal .

- Special condition: Select Suspension .

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3234.dita)

- In FTS, determine if an MA75 is imposed for the suspension:

- If an MA75 is imposed, go to step 6.

- If an MA75 is not imposed, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3235.dita)

- Select Renewal/Revised (M106) transaction and remove the MA75 as follows:

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 42 - Suspension from employment .

- Start date: Enter the start date.

- End date: Enter the end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration open for subsequent transactions.

- Select Update .

- Go to step 8.

- Select the Disqualifications/Disentitlements (M161) transaction and impose the disentitlement as follows:

- Action: Select Add .

- Disentitlement: Select 42 - Suspension from employment .

- Start date: Enter the start date.

- End date: Enter the end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3- An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- If there is an outstanding CR Recalculation WI, select D - No to leave the registration open for subsequent transactions.

- If there is no outstanding CR Recalculation WI, select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the following attributes:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 (3021): Select D42 - Suspension due to misconduct .

- We/In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Enter the appropriate dates.

- are/were (2979) .

- since/on (3022) .

- Date of suspension from employment (1470): Enter the appropriate date.

- Text - Name of employer(s) (1502): Enter the employer’s name.

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [X] to [X]. You were suspended from your employment with [text - name of employer(s)] on [date of event] due to misconduct.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI related to the suspension. 

#### Suspension — Misconduct not proven

Source topic: `en_EN/task/dismissal_ds/suspension__misconduct_not_proven_level_2.dita`

- In RCM, determine if the ROE with the suspension has been received:

- If yes, go to step 2.

- If no, go to step 3.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select M - Dismissal .

- Special condition: Select Misconduct not proven .

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3234.dita)

- In FTS, determine if an MA75 is imposed for the suspension:

- If an MA75 is imposed, go to step 4.

- If an MA75 is not imposed and the registration number is not a recalculation registration number, go to step 5.

- If an MA75 is not imposed but the registration number is a recalculation registration number, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3235.dita)

- Select the Renewal/Revised (M106) transaction and remove the MA75 as follows:

- Manual Action: Select 75 - Verification of reason for termination of employment .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration open for subsequent transactions.

- Select Update .

- Go to step 6.

- Select the Renewal/Revised (M106) transaction and clear the outstanding registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration open for subsequent transactions.

- Select Update .

- In ACS, inform the employer of the decision by sending the Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved reason for separation .

- Reason for Claim Approval (2783): Select Suspension not Misconduct .

- Warning to Employer Re Monies paid to Claimant (2788):

- If the employer is required to pay wages, pension, etc. (if there are challenge or grievance procedures underway), select Warning to ER: To inform us if pays any monies to employee .

- If there is no information on whether challenge or grievance procedures are underway, select Blank .

- You / We are writing to inform you that you (2793) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI related to the suspension. 

#### Dismissed or suspended before anticipated layoff or end of term of employment — Misconduct proven

Source topic: `en_EN/task/dismissal_ds/dismissed_or_suspended_before_anticipat_d569b6c0_level_2.dita`

- Determine if the client was dismissed or suspended more than 3 weeks before the anticipated layoff or the end of the term of employment:

- If the client was dismissed or suspended more than 3 weeks before the layoff or end of term, refer to Continuing claim: Dismissal — Misconduct proven .
               [Continuing claim: Dismissal — Misconduct proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds#NoMisc)

- If the client was dismissed or suspended 3 weeks or less before the layoff or end of term, go to step 2.

- In NWS, save the draft ROD. Verbal communication of the decision is not required.

- In RCM, determine if the ROE with the dismissal or suspension has been received:

- If yes, go to step 4.

- If no, go to step 5.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select M - Dismissal .

- Special condition: Select Anticipated loss of employment .

- End date: Enter the date the employment was expected to end.

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1748.dita)

- In FTS, determine if an MA75 is imposed for the dismissal or suspension:

- If an MA75 is imposed, go to step 6.

- If an MA75 is not imposed, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3235.dita)

- Select the Renewal/Revised (M106) transaction and remove the MA75 as follows:

- Manual Action: Select 75 - Verification of reason for termination of employment .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 44 - Anticipated loss of employment .

- Start date: Enter the day after the last day worked.

- End date: Enter the date of the anticipated loss of employment.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 3 -An overpayment resulted due to a definite disentitlement .

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration open for subsequent transactions.

- Select Update .

- Go to step 8.

- Select the Disqualifications/Disentitlements (M161) and impose the disentitlement as follows:

- Action: Select Add .

- Disentitlement: Select 44 - Anticipated loss of employment .

- Start date: Enter the day following the last day of work.

- End date: Enter the date of the anticipated loss of employment.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration open for subsequent transactions.

- Select Update .

- In ACS, create and send the D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits and does not have enough hours since the dismissal to qualify, select the following attributes:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 (3021): Select D44 - Loses employment due to misconduct within 3 weeks of layoff or end of term .

- We/In addition , we (2687) .

- Definite disentitlement start date (1272) .

- Definite disentitlement end date (1274) .

- Text - Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292) .

- being laid off / the end of your term (3023) .

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [X] to [X]. You were [dismissed/suspended] from your employment with [text - name of employer(s)] on [date of event] due to misconduct within 3 weeks of [being laid off/the end of term].”

- Right to a Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI related to the dismissal or suspension. 

#### Dismissal - Misconduct not proven — Rescinding a D10

Source topic: `en_EN/task/dismissal_ds/dismissal_-_misconduct_not_proven__resc_fbea1934_level_2.dita`

- In RCM, determine if the ROE with the dismissal has been received:

- If yes, go to step 2.

- If no, go to step 3.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select M - Dismissal .

- Special condition: Select Misconduct not proven .

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1748.dita)

- Determine if the D10 is solely due to the previously deferred RFS issue or reconsidered decision and if other issues must be adjudicated:

- If no other issues must be adjudicated, go to step 4.

- If other issues must be adjudicated, refer to the appropriate task for guidance. Then, go to step 4.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Determine if the decision is made following a request for reconsideration under EIA 112:

- If no, go to step 6.

- If yes, return to the previous task.

- In ACS, if required to inform the employer of the decision, create and send the Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved reason for separation and the appropriate options.

- Reason for Claim Approval (2783): Select No Misconduct .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI related to the dismissal. 

#### Employment is not insurable

Source topic: `en_EN/task/dismissal_ds/employment_is_not_insurable_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Dismissal or Suspension] — [employer’s name] — [last day worked or start date of suspension] — adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the dismissal or suspension is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the dismissal or suspension is therefore not required.”

- Complete the WI related to the dismissal or suspension. 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_3231.dita`

Note:

If the employee’s disciplinary record contains documentary evidence related directly to the dismissal or suspension, we should request a copy of the client’s file from the employer. In cases of railway misconduct, we must also request a copy of the hearing transcript. 

#### Note

Source topic: `en_EN/common_notes/note_c_3232.dita`

Note:

Create a new SROC for each conversation with the employer or the client (e.g. if you reached the employer twice, create 2 SROCs). 

#### Note

Source topic: `en_EN/common_notes/note_c_3233.dita`

Note:

Railway misconduct is only proven when the officer is able to obtain the transcript of the disciplinary committee hearing or when the client has provided sufficient facts regarding the railway rule or regulation violation to prove misconduct without the transcript. 

#### Note

Source topic: `en_EN/common_notes/note_c_2139.dita`

Note:

If fact-finding by telephone was attempted but was not successful, select Save regardless of the decision, because verbal communication of the decision is not required. 

#### Note

Source topic: `en_EN/common_notes/note_c_3234.dita`

Note:

Selecting Validate may cause the ROE to be flagged with an error. If this occurs, no further action is required. Should the client apply for a subsequent claim, the ROE will be corrected at that time. 

#### Note

Source topic: `en_EN/common_notes/note_c_3235.dita`

Note:

In some instances, an MA01 may have been imposed instead of the MA75. The process for removing the MA01 is the same as for the MA75. However, before removing the MA01, verify that there are no remaining issues to adjudicate. 

#### Note

Source topic: `en_EN/common_notes/note_c_1748.dita`

Note:

Selecting Validate may cause the ROE to be flagged with an error. You are not required to fix the error. The ROE is corrected if and when the client applies for a subsequent claim. 

## Policy reference

Source topic: `en_EN/task/dismissal_ds/policy_reference.dita`

- Digest 7 — Misconduct
         [Digest 7 — Misconduct](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-7/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- EIA 31
         [EIA 31](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-31.html)

- EIA 33
         [EIA 33](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-33.html) 
