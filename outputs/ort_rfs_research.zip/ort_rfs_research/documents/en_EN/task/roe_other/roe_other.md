# Completing an ROE Issue RFS Action WI: K - Other

Source map: `en_EN/task/roe_other/roe_other.ditamap`

## Summary

Source topic: `en_EN/task/roe_other/summary.dita`

Summary: When an ROE is received with a reason for separation (RFS) K - Other on an initial Web application, if the system is unable to create a link between the ROE and a matching period of employment or determine if the issue requires adjudication, an ROE Issue (ROE) RFS Action WI is created. 

## What you need to know

Source topic: `en_EN/task/roe_other/what_you_need_to_know.dita`

### Linking the ROE and the matching period of employment

Source topic: `en_EN/task/roe_other/linking_the_roe_and_the_matching_period_f71580ff.dita`

When an ROE RFS Action WI is received and a link has not yet been created between the ROE and a period of employment, the Non-complex officer must review the applicable ROE in RCM and the periods of employment listed in NWS. The Non-complex officer determines if one of the periods of employment listed in NWS matches the employer’s name on the ROE.

**Variations in the employer’s name**

Minor spelling differences between the employer’s name on the ROE and the period of employment are accepted. The officer must also consider that the employer may do business under more than one name. For example, the ROE indicates that the employer’s name is 123456 ONT Inc., but the client reported working for ABC Company. If the documentation on file or the Employer search (by business number) in FTS indicates that 123456 ONT Inc. operates as ABC Company, the names are equivalent and considered to be a match.

**Reviewing the dates on the ROE**

Only one ROE can be matched to each period of employment listed in NWS. The officer must review the Search / Correct - Results screen in RCM to determine if the ROE in the ROE RFS Action WI is the one with the last day for which paid (LDP) closest to the last day worked (LDW) for one of the periods of employment. The officer creates a link between the ROE and the period of employment with the matching employer’s name and best match for LDP and LDW. If either the employer’s name does not match or the LDP and LDW are not a good match, the officer does not create a link between the ROE and the period of employment.

**More than one ROE for one period of employment**

There may be more than one ROE but only one period of employment for the same employer.

**Example 1**

- Period of employment information declared on application:
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4689.dita)

- Search / Correct - Results in RCM:

```text
| SN | Employer | FDW / TSD | LDP / TED | Modified | Input | RFS | Audit | EHF |

| W12345678 | ABC Company | 01/07/2015 | 04/12/2015 | 22/12/2015 | 22/12/2015 | K | | |

| W12341234 | ABC Company | 01/01/2015 | 30/06/2015 | 22/12/2015 | 22/12/2015 | K | | |
```

- ROE RFS Action WI #1 for W12345678

- The officer completes the period of employment information section as follows:

- Matching POE : Select ABC Company .

- ROE RFS Action WI #2 for W12341234

- The officer completes the period of employment information section as follows:

- Matching POE : Select POE not in the list .

There may also be more than one period of employment for the same employer.

**Example 2**

- Period of employment information declared on application:
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4690.dita) 
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2684.dita)

- Search / Correct - Results in RCM:

```text
| SN | Employer | FDW / TSD | LDP / TED | Modified | Input | RFS | Audit | EHF |

| W12345678 | ABC Company | 01/07/2015 | 04/12/2015 | 22/12/2015 | 22/12/2015 | K | | |

| W12341234 | ABC Company | 01/01/2015 | 30/06/2015 | 22/12/2015 | 22/12/2015 | K | | |
```

- ROE RFS Action WI #1 for W12345678

- The officer completes the period of employment information section as follows:

- Matching POE : Select ABC Company (LDW 30/11/2015).

- ROE RFS Action WI #2 for W12341234

- The officer completes the period of employment information section as follows:

- Matching POE : Select ABC Company (LDW 30/07/2015).

**ROE already linked**

If the ROE is linked to a period of employment with a corresponding electronic record of decision (ROD) or an outstanding Adjudication Issue (ADJ) WI, the ROE RFS Action WI is completed without further action by the Non-complex officer. 

### Completing the Resolve Issue section

Source topic: `en_EN/task/roe_other/completing_the_resolve_issue_section.dita`

If the ROE is not linked to a period of employment or if the ROE is linked to a period of employment without a corresponding electronic ROD or ADJ WI, the officer must complete the Resolve Issue section of the ROE RFS Action WI before completing the WI. When resolving the issue, the officer must review the ROE and the existing RODs.

**Comments in block 18**

If the ROE was issued with comments in block 18 , the officer must determine if the correct RFS is indicated on the ROE. Any required changes to the RFS details must be made in the Resolve Issue section of the ROE RFS Action WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4691.dita) 

**Reviewing existing records of decision (RODs) on file**

If the RFS is contentious and there is an existing ROD, the officer must determine if the information on the ROE contradicts the decision on file. When a ROD is not found or when the information on the ROE contradicts the ROD, the officer indicates that no decision matches the ROE when completing the Resolve Issue section of the ROE RFS Action WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2675.dita) 

### Callout

Source topic: `en_EN/common_notes/note_c_4689.dita`

- Employer: ABC Company

- First day worked: 01/01/2015

- Last day worked: 04/12/2015

- Reason for separation: Quit 

### Callout

Source topic: `en_EN/common_notes/note_c_4690.dita`

- Employer: ABC Company

- First day worked: 01/08/2015

- Last day worked: 30/11/2015

- Reason for separation: Quit 

### Callout

Source topic: `en_EN/common_notes/note_c_2684.dita`

- Employer: ABC Company

- First day worked: 01/01/2015

- Last day worked: 30/07/2015

- Reason for separation: Quit 

### Note

Source topic: `en_EN/common_notes/note_c_4691.dita`

Note:

If there are comments in block 18 of the last ROE , the system creates an ROE Comments WI. The officer actioning the ROE Comments WI evaluates the comments in block 18 and may move the comments into the Additional information field in RCM. 

### Note

Source topic: `en_EN/common_notes/note_c_2675.dita`

Note:

When an option is selected in the POE Information section of the Resolve Issue tab, the system displays the actions that will be taken once the ROE RFS Action WI is completed. If adjudication of the RFS issue is required, an ADJ WI is automatically reactivated or created. 

## Regional considerations

Source topic: `en_EN/task/roe_other/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/roe_other/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/roe_other/in_nws.dita`

- What is the serial number and the RFS indicated in the Specific Details tab of the ROE RFS Action WI?

- What periods of employment are indicated in the Matching POE list of the ROE RFS Action WI?

- Is there a ROD indicating that the RFS has been adjudicated?

- If yes, what are the details of the decision?

- Is there an SROC clarifying the employer’s name? 

### In RCM:

Source topic: `en_EN/task/roe_other/in_rcm.dita`

- What ROEs are displayed on the Search / Correct – Results screen?

- What is the employer’s name in block 4 of the ROE?

- What is the last day for which paid in block 11 of the ROE?

- Is the RFS in block 16 one of the following?

- K - Other / Change of payroll frequency

- K - Other / Change of ownership

- K - Other / Requested by Employment Insurance

- K - Other / Change of Service Provider

- Is there an audit trail for the ROE?

- Does the audit trail contain a new value for the RFS in block 16 ?

- Are there comments in block 18 or the Additional information field of the ROE? 

### In FTS:

Source topic: `en_EN/task/roe_other/in_fts.dita`

- Does the Employer search indicate that the employer operates under another name? 

## Step by step

Source topic: `en_EN/task/roe_other/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/roe_other/non-complex.dita`

#### Linking the ROE and the matching period of employment

Source topic: `en_EN/task/roe_other/linking_the_roe_and_the_matching_period_f71580ff_non-complex.dita`

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, determine if there is a matching period of employment already selected in the Matching POE list:

- If no, go to step 2.

- If yes, go to step 6.

- Determine if the Matching POE list includes one or more periods of employment with the same employer’s name as the ROE:

- If there are one or more periods of employment with the same employer’s name as the ROE, go to step 3.

- If there is no period of employment with the same employer’s name as the ROE, select POE not in the list . Select Save and go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2685.dita)

- In RCM, review the Search / Correct – Results screen to determine if the ROE in the ROE RFS Action WI is the one with the same employer’s name and the LDP closest to the LDW for one of the periods of employment on the Matching POE list in the ROE RFS Action WI in NWS:

- If the ROE is for the same employer and the LDP on the ROE is the best match to the LDW for one of the periods of employment, go to step 4.

- If the ROE is for the same employer but the LDP on the ROE is not the best match to the LDW for one of the periods of employment, go to step 5.

- If the ROE is not for the same employer or the LDP on the ROE is clearly not a good match to the LDW for one of the periods of employment, go to step 5.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the POE information section as follows:

- Matching POE : Select the period of employment with the same employer’s name and best match for LDP and LDW.

- Select Save .

- Go to step 6.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the POE information section as follows:

- Matching POE : Select POE not in the list .

- Select Save .

- Go to step 6.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, determine if the Resolve Issue section is displayed:

- If the Resolve Issue section is displayed, go step 7.

- If the Resolve Issue section is not displayed, go to step 21. 

#### Ensuring the reason for separation (RFS) details are correct

Source topic: `en_EN/task/roe_other/ensuring_the_reason_for_separation_rfs__9dc9245b_non-complex.dita`

- In RCM, review block 16 of the ROE and determine if the RFS is one of the following:

- K - Other / Change of payroll frequency

- K - Other / Change of ownership

- K - Other / Requested by Employment Insurance

- K - Other / Change of Service Provider

- If yes, go to step 8.

- If no , go to step 9.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Do the Reason for Separation details need to be modified?: Select Yes and then A - Shortage of work .

- Go to step 21.

- In RCM, review block 18 and the Additional information field of the ROE and determine if there are comments related to the RFS:

- If yes, go to step 10.

- If no , go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4684.dita)

- Determine if the ROE requires any of the following changes:

```text
| If the comments on the ROE indicate: | The RFS options in the ROE RFS Action WI must be changed as follows: |

| RFS | RFS sub-option |

| Commission de la construction du Québec (CCQ) vacation leave | K - Other | not applicable |

| shortage of work or employer-initiated business closure due to the Coronavirus or COVID-19 | A - Shortage of work | not applicable |

| COVID-19, Coronavirus or the employee requested the ROE due to COVID-19 | A - Shortage of work | not applicable |

| end of contract, season or term | A - Shortage of work | not applicable |

| job ended | A - Shortage of work | not applicable |

| plant closure | A - Shortage of work | not applicable |

| position eliminated | A - Shortage of work | not applicable |

| restructuring | A - Shortage of work | not applicable |

| seasonal work | A - Shortage of work | not applicable |

| work shortage | A - Shortage of work | not applicable |

| shutdown | A - Shortage of work | not applicable |

| summer break, summer job — end of contract | A - Shortage of work | not applicable |

| layoff | A - Shortage of work | not applicable |

| temporary shutdown or layoff | A - Shortage of work | not applicable |

| 7 consecutive days without working | A - Shortage of work | not applicable |

| casual | A - Shortage of work | not applicable |

| name of show or film production | A - Shortage of work | not applicable |

| change of payroll frequency | A - Shortage of work | not applicable |

| change of ownership | A - Shortage of work | not applicable |

| requested by Employment Insurance | A - Shortage of work | not applicable |

| change of service provider | A - Shortage of work | not applicable |

| bankruptcy | A - Shortage of work | Employer bankruptcy or receivership |

| employee requested | No change | Other - At the employee’s request |

| return to school with no apprenticeship training details | E - Quit | Quit - Return to school |

| Queen’s Regulations/Orders | No change | Other - Canadian Forces - Queen’s Regulations/Orders |

| medical leave of absence | D - Illness or injury | not applicable |

| unpaid medical leave | D - Illness or injury | not applicable |

| illness or surgery related comment | D - Illness or injury | not applicable |

| illness or quarantine due to the Coronavirus or COVID-19 | D - Illness or injury | not applicable |

| client refuses to report to work due to the Coronavirus or COVID-19 | E - Quit | E - Quit / Health Reasons |

| quit without notice | E - Quit | not applicable |

| resigned | E - Quit | not applicable |

| personal reasons | E - Quit | not applicable |

| job abandonment | E - Quit | not applicable |

| with cause | M - Dismissal | not applicable |

| to go to another job | E - Quit | Quit - Take another job |

| to follow spouse | E - Quit | Quit - Follow spouse |

| employer relocation | E - Quit | Quit - Employer relocation |

| care for a dependant | E - Quit | Quit - Care for a dependant |

| to become self-employed | E - Quit | Quit - To become self-employed |

| voluntary retirement | E - Quit | Quit - Voluntary retirement |

| health reasons | E - Quit | Quit - Health reasons |

| return to school | E - Quit | Quit - Return to school |

| attendance | M - Dismissal | not applicable |

| poor performance | M - Dismissal | not applicable |

| not suitable, etc. | M - Dismissal | not applicable |

| did not pass the probationary period | M - Dismissal | Dismissal - Terminated within probationary period |

| terminated within probationary period | M - Dismissal | Dismissal - Terminated within probationary period |
```

- If the ROE requires a change to A - Shortage of work or D - Illness or injury , go to step 11.

- If the ROE requires other changes, note the changes required and go to step 12.

- If the ROE does not require changes, go to step 13.
               [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4685.dita)

- In NWS, determine if there is a ROD on file for the period of employment indicating that the RFS is other than shortage of work or illness or injury (e.g. dismissal or suspension, leave of absence, voluntary leaving):

- If no, go to step 12.

- If yes, go to step 13.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Do the Reason for Separation details need to be modified?: Select Yes and the applicable RFS changes required (as indicated in step 10).

- Go to step 14.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Do the Reason for Separation details need to be modified?: Select No .

- Go to step 14. 

#### Selecting a special condition for the decision on file

Source topic: `en_EN/task/roe_other/selecting_a_special_condition_for_the_d_d5caef0c_non-complex.dita`

- Determine which special condition options are displayed:

- If multiple options are displayed, go to step 15.

- If No Decision Matches the ROE is the only option displayed, go to step 19.

- If no special condition options are displayed, go to step 21.

- In NWS, determine if there is a ROD on file for the period of employment:

- If yes, go to step 16.

- If no , go to step 19.

- Review the decision indicated in the ROD:

- If the ROD indicates that adjudication was deferred, go to step 17.

- If the ROD does not indicate that adjudication was deferred, go to step 18.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Select the Special Condition for the decision on file: Select Adjudication Deferred .

- Go to step 21.

- In RCM, review the ROE and determine if there is information which contradicts the decision on file (e.g. the decision on file has a different RFS than the ROE; the decision on file indicates voluntary leaving for another employment, but the comments from the employer on the ROE indicate that the employee quit due to a conflict with a manager):

- If there is contradictory information regarding the RFS on the ROE, go to step 19.

- If there is no contradictory information regarding the RFS on the ROE, go to step 20.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Select the Special Condition for the decision on file: Select No Decision Matches the ROE .

- Go to step 21.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Select the Special Condition for the decision on file: Select the option that matches the decision in the ROD:

- If the decision indicates Suspension from employment (D-42) , select Suspension .

- If the decision indicates Anticipated Loss of Employment (D-44) , select Anticipated Loss of Employment and enter the disentitlement dates from the decision.

- Go to step 21. 

#### Completing the WI

Source topic: `en_EN/task/roe_other/completing_the_wi_non-complex.dita`

- Complete the ROE RFS Action WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2685.dita`

Note:

When comparing the employer’s name on the period of employment and the ROE, you may accept minor spelling differences to the employer’s name. You must also consider that the employer may do business under more than one name (e.g. 123456 ONT INC does business as ABC Company). In this case, you must review the documentation on file or use the Employer search (by business number) in FTS to determine if the employer’s name on the ROE is equivalent to the employer’s name on the period of employment. 

#### Note

Source topic: `en_EN/common_notes/note_c_4684.dita`

Note:

When actioning an ROE Comments WI, the agent may have moved the comments in block 18 of the ROE to the Additional information field in RCM. 

#### Warning

Source topic: `en_EN/common_notes/note_c_4685.dita`

Warning:

Do not modify the ROE in RCM. The next step explains how to modify the RFS details in the ROE RFS Action WI. 

## Policy reference

Source topic: `en_EN/task/roe_other/policy_reference.dita`

 
