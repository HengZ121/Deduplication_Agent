# Adjudicating voluntary leaving (Level 1): Workforce reduction — Continuing claim

Source map: `en_EN/task/voluntary_leaving_work_reduction_l1/voluntary_leaving_work_reduction_l1.ditamap`

## Summary

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/summary.dita`

Summary: When a client voluntarily leaves employment due to workforce reduction, entitlement to regular benefits on a continuing claim may be affected. Adjudication is required to determine if there is just cause for leaving the employment. 

## What you need to know

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/what_you_need_to_know.dita`

### Adjudicating voluntary leaving for a workforce reduction

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/adjudicating_voluntary_leaving_for_a_wo_b21e16ff.dita`

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave the employment. If it is determined that the client left the employment without just cause, a disqualification is imposed on the claim for regular benefits, unless the client has enough insurable hours since the voluntary leaving to establish a new claim. In this case, the ROE with the voluntary leaving is excluded from the calculation of the claim.

The objective of a workforce reduction program is to ensure the economic viability of a company, an organization, a firm or a plant. To remain competitive, employers may have to restructure their workforce, which could include permanently reducing the number of employees. The group covered under a workforce reduction program may be all the employees (including seasonal, temporary or on call employees) or it could be limited to a sector, a particular group of workers or a particular work site. Workforce reduction could also include as little as one employee. Employees who leave under an approved workforce reduction program have a complete severance from their employment. The details of the workforce reduction program must be documented.

The appropriate regional workforce reduction coordinator renders all decisions on a workforce reduction program. The regional coordinator ensures that the initial fact-finding is completed and that decisions on workforce reduction programs are made and posted in Major Employer Events .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

If a decision has not yet been posted in Major Employer Events , the officer completes the email template and sends it to the regional workforce reduction coordinator for the region where the employer’s head office is located.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596) 
       [regional workforce reduction coordinator](https://esdc.prv/en/service-canada/ei/contacts/workforce_reduction_coor.shtml)

Workers who agree to leaving their jobs under an approved workforce reduction program to preserve the job of a co-worker are not subject to disqualification for leaving according to EIR 51 , and may receive benefits if they meet the other entitlement conditions of the EIA (e.g. they are available for and actively seeking employment).
       [EIR 51](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html)

A workforce reduction program is defined in EIR 51(2) as a program:
       [EIR 51(2)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html)

- that is initiated by the employer;

- that has as its objective a permanent reduction in the number of employees;

- that offers employees the option to leaving employment voluntarily;

- whose elements are documented by the employer.

Employers planning a workforce reduction program may submit a request to Service Canada for confirmation that their plan meets the requirements of the EI Regulations.

The request should contain information confirming:

- the plan was initiated by the employer;

- the objective is to permanently reduce the workforce; and

- the employees covered by the program.

Service Canada cannot provide a blanket decision that applies to all employees, but provides an employer with prior confirmation that an employer’s workforce reduction program meets the conditions of EIR 51 .
       [EIR 51](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html)

Regions usually have procedures in place for documenting approved workforce reduction program. For information about approved workforce reduction programs, the officer refers to Major Employer Events . Employers are often advised to confirm the existence of a valid workforce reduction program in the Comments block of the ROE. If there is no documentation confirming the workforce reduction program as valid, or if the employer has not documented the ROE to that effect, the officer must fact-find with the employer.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

An ROE is not required to adjudicate a voluntary leaving. 

### Automated adjudication

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/automated_adjudication.dita`

ACP does not adjudicate voluntary leaving on a continuing claim. 

### Levels of decision

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/levels_of_decision.dita`

Level 1 officers may adjudicate and allow benefits when the reason for the voluntary leaving is according to an approved workforce reduction program under EIR 51 ( National Policy on Levels of Decision ).
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

When the Level 1 cannot adjudicate the issue, the facts are documented and the voluntary leaving is referred to Level 2 for adjudication. 

### Employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/employment_is_not_insurable.dita`

Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is not required if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. 

### Actions required following adjudication

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/actions_required_following_adjudication.dita`

When the voluntary leaving is adjudicated and the ROE is received, the Special condition field of the ROE must be updated to show either Voluntary leaving - Just cause or Voluntary leaving - No just cause . 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the reason for separation (RFS) was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Previously deferred decision

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D11 that is on file and update the Special Condition field on the ROE in RCM. 

## Regional considerations

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/regional_considerations.dita`

Atlantic and Western Canada and Territories regions — For events before May 14, 2018, information on approved workforce reduction programs can be found in the following databases:

- Atlantic region: Documents are stored in the regional common document share under EI Document Library / Employer Info / WorkForceReduction

- Western Canada and Territories region: WT regional site
         [WT regional site](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/wfr.shtml)

Business expertise advisors can access the list of regional coordinators by referring to Regional Workforce Reduction Coordinators .
       [Regional Workforce Reduction Coordinators](https://esdc.prv/en/service-canada/ei/contacts/index.shtml) 

## What you need to look for

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Voluntary Leave section of this or a previous EI application?

- Are there any SROCs, Action Item (AI) WIs, or documentation containing checklists or other details relating to the voluntary leaving on this or a previous EI application? 

### In FTS:

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/in_fts.dita`

- Is there a 75 - Verification of reason for termination of Employment manual action (MA75) imposed to stop payments?

- Is there a registration number? 

### Major Employer Events:

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/major_employer_events.dita`

- Is there any information relating to the workforce reduction program? 

### In Imaging:

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving? 

### In RCM:

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving? 

## Step by step

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/reviewing_the_file_level_1.dita`

- Determine if the facts on file clearly indicate that the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 2.

- If the facts on file clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable.
               [Employment is not insurable.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_work_reduction_l1#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Review Major Employer Events to determine if the employer has an approved workforce reduction program:

- If no, go to step 5.

- If yes, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_work_reduction_l1#Reason_for_separation) 

#### Fact-finding

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/fact-finding_level_1.dita`

- Fact-find with the employer to determine the client’s reason for the RFS.

- Determine if the employer was reached during fact-finding:

- If the employer was reached, go to step 7.

- If the employer was not reached or did not reply to the Z-00-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_work_reduction_l1#Reassigning_the_issueWI)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — employer.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the employer indicates that the client left under an approved workforce reduction program:

- If yes, go to step 9.

- If no and the RFS indicated by the employer can be resolved at Level 1, go to the applicable procedure to adjudicate Voluntary leaving .
               [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml)

- If no and the RFS indicated by the employer cannot be resolved at Level 1, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_work_reduction_l1#Reassigning_the_issueWI)

- Contact a business expertise advisor to determine if the workforce reduction program has been approved and not yet entered in the Major Employer Events .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4935.dita)

- In NWS move the WI for the voluntary leaving to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “awaiting business expertise advisor’s answer.”

- Bring forward date: Enter the date the request is sent + 10 business days.

- When an answer is received from the business expertise advisor or when the WI moves to the current workload, determine if there is an approved workforce reduction program in Major Employer Events :

- If there is an approved workforce reduction program in the MEE — Information Bulletin, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_work_reduction_l1#Reason_for_separation)

- If there is no approved workforce reduction program in the MEE — Information Bulletin, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_work_reduction_l1#Reassigning_the_issueWI) 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “voluntary leaving — [employer’s name] — [last day worked] — just cause.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In RCM, verify if the ROE for the employment that the client voluntarily left has been received:

- If yes, go to step 3.

- If no go to step 4.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select E - Quit .

- Special condition: Select Voluntary leaving - Just cause .

- Move any comments related to the voluntary leaving from block 18 of the ROE to the Additional information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3230.dita)

- In FTS, determine if there is a D11 on file because this RFS adjudication was previously deferred:

- If yes, go to step 5.

- If no, go to step 7.

- Determine if the D11 is solely due to this previously deferred RFS issue and no other issues must be adjudicated:

- If no other issues must be adjudicated, go to step 6.

- If other issues must be adjudicated, go to the appropriate task for guidance. Then, go to step 6.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F – Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Determine if an MA75 is imposed and if there is a registration number for the voluntary leaving:

- If an MA75 is imposed but there is no registration number, go to step 8.

- If an MA75 is imposed and there is a registration number, go to step 9.

- If an MA75 is not imposed but there is a revised registration number, go to step 10.

- If none of the above applies, go to step 11.

- Select the Registration Number (M025, M030, M035) transaction and obtain a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to remove the MA75 as follows:

- Registration number: Select the applicable registration number.

- Manual action: Select 75 - Verification of reason for termination of Employment .

- Rescind: Check the box.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 11.

- Select the Renewal/Revised (M106) transaction to clear the outstanding registration number as follows:

- Claim allowed: Select NCA - No change to the claim .

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI related to the voluntary leaving. 

#### Employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “voluntary leaving — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Complete the WI related to the voluntary leaving. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/reassigning_the_issue_to_level_2_level_1.dita`

- In FTS, on the Summary tab, determine if an MA75 has been imposed:

- If yes, go to step 2.

- If no and the client is requesting special benefits, go to step 2.

- If no and the client is requesting regular benefits, select the Renewal/Revised (M106) transaction and impose the MA75 as follows:

- Registration number: Leave the field blank. If a number is displayed, remove it.

- Manual Action: Select 75 - Verification of reason for termination of Employment .

- Select Update .

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “client quit [his/her] job and [provide a brief reason for the referral (e.g.no approved workforce reduction information is available)] — unable to complete at Level 1.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_4935.dita`

Note:

If the employer is from the West and Territories region, contact the Liaison Enquiry Team instead of the Business Expertise Advisor. Refer to W-T Region Workforce Reduction Procedures .
       [W-T Region Workforce Reduction Procedures](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/wfr.shtml)

     [W-T Region Workforce Reduction Procedures](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/wfr.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_3230.dita`

Note:

Selecting Validate may cause the ROE to be flagged with an error. If this occurs, no further action is required. If the client submits another claim, the ROE is corrected at that time. 

## Policy reference

Source topic: `en_EN/task/voluntary_leaving_work_reduction_l1/policy_reference.dita`

- Digest 6.7.0 — Workforce Reduction
         [Digest 6.7.0 — Workforce Reduction](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/workforce-reduction.html#a6_7_0)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- EIR 51
         [EIR 51](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html) 
