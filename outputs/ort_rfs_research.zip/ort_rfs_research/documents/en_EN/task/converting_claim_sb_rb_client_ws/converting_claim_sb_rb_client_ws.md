# Converting a claim from special benefits to regular benefits for a client participating in a Work-Sharing program

Source map: `en_EN/task/converting_claim_sb_rb_client_ws/converting_claim_sb_rb_client_ws.ditamap`

## Summary

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/summary.dita`

Summary: After receiving special benefits, clients who qualify for regular benefits and enter into a valid Work-Sharing (WS) agreement with their employer can request WS benefits. 

## What you need to know

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/untitled_section.dita`

In NWS:

- When was the application for WS benefits filed?

- Does the client have a 900-series SIN?

- Has the client worked since the last week paid?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies, workers’ compensation benefits (WCB), motor vehicle accident compensation or wage loss insurance (WLI) payments to consider or allocate?

- Was a RFS previously deferred?

- Is there an ADJ WI?

- If yes, for what issue?

- Is there a valid WS reference code?

- If no, are the details of the WS agreement on file?

In FTS:

- What is the number of insurable hours on file?

- Is there a number other than 0 displayed in the Entitlement weeks field?

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the last renewable week (LRW) been reached?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Are there any pending claimant’s reports or claimant’s reports to be processed before the conversion?

- Is there a registration number for the conversion request?

- Is the project data on file?

- Is there an MA02 imposed on the claim?

In RCM:

- Has an ROE been submitted?

- Are there earnings, separation monies, motor vehicle accident compensation, WCB or WLI payments to consider or allocate?

In Imaging:

- Is there any other documentation which may impact the conversion claim? 

### Reference codes

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/reference_codes.dita`

When clients agree to a reduction in normal working hours in order to share available work as part of a valid WS agreement, they are given a reference code and advised to apply for EI regular benefits. This is because the claim type (CT) must be regular benefits in order to allow processing of WS benefits.
       [reference code](/en/procedure/generic/additionalresources/knowledge_reltws.shtml#Waiting_Period)

When clients complete an online application using a reference code, a specialized application for benefits is presented instead of the standard application for benefits. When a client applies for benefits without a reference code and it is later determined that the client is part of a WS program, the officer processing the claim ensures that all the information regarding WS is input.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2886.dita) 

### Qualifying for conversion

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/qualifying_for_conversion.dita`

The officer can convert a claim for special benefits to regular benefits for a client participating in a WS program when all of the following conditions are met:

- The client is requesting benefits during the BP.

- The client qualifies for regular benefits.

- There are weeks of entitlement to regular benefits remaining that can be paid or special benefits that could be payable.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2887.dita) 

### Levels of Decision

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/levels_of_decision.dita`

A decision to allow regular benefits following special benefits can be rendered at Level 1 under the National Policy on Levels of Decision . If there are any issues that cannot be adjudicated by Level 1 under the National Policy on Levels of Decision , the file is referred for Level 2 adjudication.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 

### Outstanding disentitlement

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/outstanding_disentitlement.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies to the conversion. A Level 1 officer can terminate the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . If the information on file allows for the disentitlement to be terminated, the disentitlement is terminated on the Friday of the week before the conversion week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer refers the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer can refer to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Allocation of monies

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/allocation_of_monies.dita`

Whenever clients report receiving monies, the officer determines if these monies are considered earnings for EI purposes. If it is determined that the monies are earnings, they must be allocated. To determine how the earnings are allocated, the officer refers to Earnings .
       [Earnings](/en/procedure/activity/earnings.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2888.dita) 

### Qualifying for regular benefits

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/qualifying_for_regular_benefits.dita`

The duration of the BP is the length of time in which the client can claim benefits to which they are entitled. The length of a BP is 52 weeks, including the week of the BPC as well as the WP. A BP for regular benefits ends when one of the following occurs:

- All the weeks to which the client is entitled have been paid.

- The maximum regular benefits have been paid.
         [maximum regular benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml#regular)

- The maximum combined special and regular benefits have been paid.
         [maximum combined special and regular benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml#combine)

- The 52-week duration is reached.

- The client requests the termination of the BP.

Under certain circumstances, the BP can be extended to allow the client more time to receive the benefits to which they are entitled. For more information, the officer refers to Extension of the benefit period .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml) 

### Work-Sharing (WS) agreement continues beyond BPC + 103

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/work-sharing_ws_agreement_continues_bey_2550a6a5.dita`

There is no limit to the number of weeks that a BP can be extended due to WS. The BP is extended by one week for each week of WS benefits processed. Benefits can be paid beyond BPC + 103, but they must be paid in MPS once BPC + 103 is reached.

If the WS agreement’s end date is greater than BPC + 103, the officer enters the client’s BPC + 103 week in the End date field of the M171.

If a claim reaches BPC + 103, clients must submit a new EI application for regular benefits to receive benefits for the remainder of the WS agreement. The officer advises the client by letter. The officer also documents this information, along with the agreement details, on a record of decision (ROD).

When the new claim is assessed, the client can establish a new BP in CPS or renew the existing BP in MPS to receive benefits during the remainder of the WS agreement. 

### Weeks of entitlement

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/weeks_of_entitlement.dita`

When clients qualify for regular benefits at the BPC, the maximum number of weeks of entitlement to regular benefits is displayed in the Entitlement weeks field on the Summary tab in FTS. If all of the weeks of regular benefits to which the client is entitled have not been paid, there is entitlement to regular benefits remaining.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2889.dita) 

If a client has no more weeks of entitlement to regular benefits and special benefits could not be payable, the officer determines if the client can establish a new claim. If the client filed a renewal application, it is used to determine if the client qualifies for a new initial claim. 

### Adjudicating deferred reason for separation (RFS)

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/adjudicating_deferred_reason_for_separation_rfs.dita`

After converting a claim to regular benefits, any deferred or new RFS must be adjudicated.

Normally, a disqualification is imposed when adjudication of the RFS is deferred but special benefits are allowed. However, for all initial calculations and recalculations when the BPC is between September 27, 2020 (w/c 2258) and September 25, 2021 (w/c 2309), UIC considers the RFS as non-contentious when the special condition on the ROE is blank or deferred. Consequently, no disqualification is imposed when the adjudication of the RFS is deferred on these claims.

Officers always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 10 - Dismissal - misconduct proven (D10) or 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If there is a ROD on file indicating that adjudication of an RFS was deferred or if there is an RFS that has not yet been adjudicated, the RFS must be adjudicated. A Level 1 officer can adjudicate the RFS according to the National Policy on Levels of Decision . If it is not within Level 1 authority, the RFS is reassigned to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 

### Disqualifications

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/disqualifications.dita`

The serving of a disqualification can be carried forward or suspended while the client receives WS benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2890.dita) 

If there is an outstanding disqualification on the claim for a reason other than voluntary leaving or misconduct, the disqualification must be referred to Level 2 for adjudication. The Level 2 officer determines if the outstanding disqualification must be carried forward or suspended for the duration of the WS benefits. 

### Outstanding disentitlements

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/outstanding_disentitlements.dita`

The serving of a disentitlement is automatically deferred while the client receives WS benefits unless it is one of the following disentitlements:

- 5 - Labour dispute (D5)

- 12 - Inmate of penal institution (D12)

- 13 - Outside Canada (D13)

- 14 - Void benefit period (D14)

- 15 - Claim Procedure (D15)

- 21 - Claimant refuses payment (D21)

- 38 - On vacation in Canada (D38)

- 39 - Prevent payment of part II benefits and/or incorrect Part I benefits (D39)

- 42 - Suspension from employment (D42)

- 43 - Leave of absence (D43)

- 48 - Moved-address unknown (D48)

If there is an outstanding disentitlement on the claim that will not be automatically deferred, the officer reviews the disentitlement to determine if it still applies on the renewal. A Level 1 officer can terminate the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . When the information on file allows for the disentitlement to be terminated, the disentitlement ends on the Friday of the week before the renewal week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 

### Adjudicating new contentious issues

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/adjudicating_new_contentious_issues.dita`

When converting a continuing claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If there is no existing WI for this issue, the Level 1 officer creates a Claim Review (CR) WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

On a renewal claim, if the issue is reported on the application, the system creates an Adjudication Issue (ADJ) WI. If there is a ROD on file indicating that adjudication of an RFS was deferred or if there is an RFS that has not yet been adjudicated, the RFS must be adjudicated. If a contentious issue is detected while reviewing the claim and the Level 1 officer is unable to adjudicate the issue according to the National Policy on Levels of Decision , the Level 1 officer verifies there is an ADJ WI for each contentious issue or creates an ADJ WI for each contentious issue and refers the issue to the Level 2 for adjudication. When an ADJ WI is created on a renewal claim, either manually or by the system, the system automatically imposes a 2 - Contentious Renewal in Automation manual action (MA2) to prevent payment of benefits until the contentious issue is adjudicated. The officer must complete the manual inputs related to a contentious issue for which there is no ADJ WI before the Claim Assessment (CA) WI is completed, as the completion of the CA WI triggers the removal of the MA2 by the system when there is no outstanding ADJ WI.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2891.dita) 

### Temporary foreign workers (900-series SIN)

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/temporary_foreign_workers_900-series_sin.dita`

All foreign workers are given temporary resident status for a limited period of time when they enter Canada. Generally, foreign workers can demonstrate availability to accept work only if they possess a valid work permit which allows them to work in Canada. Therefore, when foreign workers wish to renew a claim for regular benefits, the officer checks the validity of their work permits. 

### Renewal advantages

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/renewal_advantages.dita`

When assessing a renewal, it might be to the client’s advantage to establish a new BP instead of renewing the existing BP. Refer to Cancelling, voiding, terminating or withdrawing a claim for more information.
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml) 

### Subsequent claim

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/subsequent_claim.dita`

The renewal application can be used to establish a subsequent claim when the following conditions are met:

- The claim is renewed and there are 4 or fewer weeks of benefits remaining in the BP.

- The client has worked enough hours to establish a new claim.

ACP can register the subsequent claim if the Claim Assessment (CA) WI for a renewal or subsequent initial claim is finalized within 28 days of the renewal application.

When ACP cannot register the subsequent claim because the renewal is not processed within 28 days of the renewal application (i.e. REN WK not found or no match and polling limit exceeded is displayed on the Processing Activities tab in NWS) or when the claim was converted to MPS, the officer processing the CA Renewal WI creates a Reminder (REM) WI. This ensures that an officer will manually register the subsequent claim. 

### Processing claimant’s reports

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/processing_claimants_reports.dita`

The last week of special benefits must be paid before the officer can input the conversion transactions. If claimant’s reports have not yet been processed for the special BP, they must be processed before inputting the conversion. 

### Effective date of conversion

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/effective_date_of_conversion.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date.  For more information, the officer can refer to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Maximum combination of regular and special benefits

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/maximum_combination_of_regular_and_spec_7bee3d77.dita`

When regular and special benefits are combined, the maximum number of weeks payable is the equivalent of 50 weeks paid or deemed paid at the basic benefit rate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2653.dita) 

When the client has received both extended parental benefits and regular benefits, weeks in which no benefits are paid to the client are  deemed to be weeks for which benefits were paid at the basic benefit rate. 

### Conversion from extended parental benefits to regular benefits

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/conversion_from_extended_parental_benef_ce01975c.dita`

The officer inputs the conversion transactions directly in FTS without any action from IPOC as long as CPS has paid fewer than 50 weeks of benefits.  When 50 weeks of combined regular and special benefits are paid through CPS, an error is generated. The officer actioning the error refers to Actioning a rejected transaction — Error codes C725 and C726 and manually calculates the number of weeks that may still be payable to the client along with any necessary extension of the BP. IPOC processes any remaining weeks of entitlement in MPS.
       [Actioning a rejected transaction — Error codes C725 and C726](/en/procedure/task/actioning_rt_c725_c726.shtml) 

### Exemption from reporting

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/exemption_from_reporting.dita`

During the application process, clients applying for WS benefits have the option to be exempt from completing claimant’s reports. If the client has agreed to the conditions for the exemption from completing claimant’s reports, the officer ensures the exemption is input. For additional information, refer to Exemption from reporting .
       [Exemption from reporting](/en/procedure/activity/exemption_reporting.shtml) 

### Claim action status and processing of the claim

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/claim_action_status_and_processing_of_the_claim.dita`

The Claim action status Renewal is created when a renewal decision is registered. There are 3 Claim action statuses that can be displayed:

- In Progress (Automation) is displayed on the Client information tree when there is one or more outstanding adjudication issues.

- In Progress (Manual) is displayed on the Client information tree when there is no outstanding adjudication issue and there is an outstanding CA or Specialized Application (SA) WI.

- Finalized is displayed on the Client information tree when all ADJ WIs are completed and the renewal week has been successfully input.

An ADJ WI is created for every new contentious issue. When opening an ADJ WI, the officer always checks to see if there is a Resolve Issue tab. If there is a Resolve Issue tab, the officer can document the decision directly in the ADJ WI by completing all mandatory screens. When the ADJ WI is completed, NWS creates a ROD based on the Resolve Issue screens. When the renewal is finalized, the system also generates the required transactions (e.g. signature code, disentitlement) based on the Resolve Issue screens. If a disentitlement or indefinite disqualification is imposed, the system creates a Correspondence (COR) WI for the D-01-00-00 letter. This means that the officer with the CA or SA WI has no action to perform for these ADJ WIs.

When there is no Resolve Issue tab for the ADJ WI, the officer creates a ROD, generates the required transactions and sends the appropriate letter. If there is an outstanding CA or SA WI when the officer completes the ADJ WI, a client Note is created and the officer with the CA or SA WI follows the instructions to input the transactions or send the letter. 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a Claim Review (CR) WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an Action Item (AI), Call Back (CB), Assessment Issue (ASMT) or Reminder (REM WI), the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### ACS letters

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/acs_letters.dita`

Communication of the renewal decision is not necessary when the only transaction input is the renewal transaction. When another decision is input at the time of the renewal (disentitlement, disqualification or allocation of earnings), communication of the decision is necessary.

Written communication of the decision is usually done by officers who are responsible for sending the appropriate ACS letter. Under particular situations, the R-01-00-00 letter is sent automatically. Officers ensure that the letter was sent and, if the letter was not sent, they create and send the letter of decision in ACS.

If a renewal and an allocation are input by the same officer and are processed on the same day, the R-01-00-00 letter is, in most cases, created automatically.

There are some exceptions. The letter does not automate if one of the following conditions is met:

- One of the transactions (M106 or M175) rejects.

- The allocation code on the M175 is A , D , or N .

- An E or W allocation is input for more than one week.

- A stop payment is imposed (MA01, MA02, MA48, MA71, MA72, MA73, MA74, MA75).

- A disqualification or disentitlement is being input.

- A disqualification or disentitlement is already on file and is not being rescinded or terminated.

In some cases, the letter can be automated but additional decisions must be communicated. To prevent duplication of letters, the officer prevents the automated letter from being sent by using the Automated Letter Bypass function in FTS. 

### Note

Source topic: `en_EN/common_notes/note_c_2885.dita`

Note:

This task deals with converting a claim for WS benefits when the benefit type (BT) prior to the renewal request is not regular benefits. If the BT prior to the conversion is regular benefits, refer to Renewing a claim for regular benefits for a client participating in a Work-Sharing program .
       [Renewing a claim for regular benefits for a client participating in a Work-Sharing program](/en/procedure/task/renewing_claim_rb_client_participating_ws.shtml)

     [Renewing a claim for regular benefits for a client participating in a Work-Sharing program](/en/procedure/task/renewing_claim_rb_client_participating_ws.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2886.dita`

Note:

Reference codes are valid for a limited time only. Clients who apply for benefits after the reference code expires must file a regular application for benefits. Clients who complete the regular application for benefits who want to be exempted from reporting and meet the criteria must request the exemption through the Call Centre or via an INS5173. 

### Note

Source topic: `en_EN/common_notes/note_c_2887.dita`

Note:

When a client receives WS benefits, the waiting period (WP) or any portion of the WP that has not been served and any outstanding WP earnings are automatically deferred while WS benefits are paid. The client does not need to request that the WP be deferred. 

### Note

Source topic: `en_EN/common_notes/note_c_2888.dita`

Note:

Earnings that arise from WS employment are not deducted in a WS week. This prevents income earned from the WS employment from reducing benefits. This includes wages, paid sick leave, paid vacation time and a lump sum payout of vacation pay. Only earnings received from outside the WS employment are deducted from a WS week. When the week is considered a non-WS week, earnings from the WS employment are considered and subject to the normal allowable rules. 

### Note

Source topic: `en_EN/common_notes/note_c_2889.dita`

Note:

When a client’s BP has been extended only to pay the maximum number of weeks of special benefits, the claim cannot be renewed for WS benefits even if entitlement weeks to regular benefits are remaining. Refer to Benefit period extension for special benefits job aid for additional information.
       [Benefit period extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

     [Benefit period extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2890.dita`

Note:

A disqualification for voluntary leaving or misconduct is not suspended in order to pay WS benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_2891.dita`

Note:

An officer cannot rescind an MA02. 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_2653.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

## Regional considerations

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/regional_considerations.dita`

In the Ontario and Quebec regions, the WS unit processes all WS claims. 

## What you need to look for

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/untitled_section.dita`

In NWS:

- When was the application for WS benefits filed?

- Does the client have a 900-series SIN?

- Has the client worked since the last week paid?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies, workers’ compensation benefits (WCB), motor vehicle accident compensation or wage loss insurance (WLI) payments to consider or allocate?

- Was a RFS previously deferred?

- Is there an ADJ WI?

- If yes, for what issue?

- Is there a valid WS reference code?

- If no, are the details of the WS agreement on file?

In FTS:

- What is the number of insurable hours on file?

- Is there a number other than 0 displayed in the Entitlement weeks field?

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the last renewable week (LRW) been reached?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Are there any pending claimant’s reports or claimant’s reports to be processed before the conversion?

- Is there a registration number for the conversion request?

- Is the project data on file?

- Is there an MA02 imposed on the claim?

In RCM:

- Has an ROE been submitted?

- Are there earnings, separation monies, motor vehicle accident compensation, WCB or WLI payments to consider or allocate?

In Imaging:

- Is there any other documentation which may impact the conversion claim? 

## Step by step

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/reviewing_the_file_level_1.dita`

- In NWS, determine if there is a SIR Validation (SIR) WI:

- If yes, go to step 2.

- If no, go to step 4.

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “waiting for the SIR WI to be completed.”

- Bring forward date: Enter today’s date + 10 days.

- When the CA WI moves to the current workload, determine if the SIR WI has been completed:

- If no, repeat step 2.

- If yes, go to step 4.

- In NWS, determine the type of application:

- If the client applies with a specialized application, go to step 5.

- If the client applies with a standard application, refer to Conversion and renewal and to go to Project data — Client applies with a standard application .
               [Conversion and renewal](/en/procedure/activity/conversions.shtml) 
               [Project data — Client applies with a standard application](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_claim_sb_rb_client_ws#Project_data)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2892.dita)

- Determine if this is a WS claim from the Quebec or Ontario region:

- If no, go to step 6.

- If yes, determine if the CA WI is assigned to the regional WS unit or if you work for the regional WS unit :

- If yes, go to step 6.

- If no, go to Reassign the WI to the WS unit .
                   [Reassign the WI to the WS unit](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_claim_sb_rb_client_ws#level1_item_4)

- In FTS, determine if a registration number related to the conversion is on file:

- If yes, go to step 7.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update.

- Go to step 7.

- Determine if the client reports having received monies that do not arise from WS employment and whether they have been allocated:

- If the client reports having received monies and they have not been allocated, refer to Earnings . Go to step 8.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and they have been allocated, go to step 8.

- If no monies were reported, go to step 8.

- In NWS and in FTS, determine if one of the following conditions exists to extend the BP:

- The client was incarcerated and has since been tried and not found guilty.

- The client received workers' compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If none of the conditions exist, go to step 9.

- If one of the conditions exists, refer to Extension of the benefit period . Go to step 9.
                   [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

- Determine if a D10 or D11 disqualification is imposed as a result of adjudication:

- If yes and the client has worked since the BPC, go to step 10.

- If yes and the client has not worked since the BPC, go to No benefits payable due to a D10 or D11 .
               [No benefits payable due to a D10 or D11](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_claim_sb_rb_client_ws#D10D11)

- If no, go to step 11.

- Determine if the client qualifies for a new claim:

- If no, go to No benefits payable due to a D10 or D11 .
               [No benefits payable due to a D10 or D11](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_claim_sb_rb_client_ws#D10D11)

- If yes, refer to Calculating or recalculating a claim for regular benefits .
               [Calculating or recalculating a claim for regular benefits](/en/procedure/activity/calculation.shtml)

- Determine if there are weeks of entitlements to regular benefits remaining that can be paid :

- If yes, go to step 12.

- If no, go to Claim not renewable for Work-Sharing (WS) benefits .
               [Claim not renewable for Work-Sharing (WS) benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_claim_sb_rb_client_ws#NotRenw)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 13.

- If no, go to step 15.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, go to step 14.

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 15.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- In NWS, create an ADJ WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option

- Destination - SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next Available User .

- Issue(s): Select Availability .

- Details: Type “outstanding D15 for a missed client information session, Level 2 review required.”

- Select Save .

- Determine if any of the following issues that do not have a corresponding WI are present:

- There is a disqualification imposed other than a D10 or D11.

- There is an outstanding disentitlement on file other than a D5, D12, D13, D14, D15, D21, D38, D39, D42, D43 or a D48.

- There is an outstanding issue that requires adjudication.

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 16.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Details: Type “Outstanding [type of disentitlement] disentitlement.”

- Select Save .

- Refer to the appropriate procedure and go to step 16.

- If no, go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2732.dita)

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If no, reassign the WI to Level 2 and go to step 17.

- If yes, complete the steps from the appropriate procedure and go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- In NWS, determine if there is an outstanding adjudication:

- If no, go to Converting a claim — No outstanding adjudication .
               [Converting a claim — No outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_claim_sb_rb_client_ws#Finalize_conversion)

- If yes, go to Converting a claim — Outstanding adjudication .
               [Converting a claim — Outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_claim_sb_rb_client_ws#Finalize_conversion2) 

#### Project data — Client applies with a standard application

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/project_data__client_applies_with_a_sta_46a27bc7_level_1.dita`

- In FTS, input the project data as follow:

- Select the Project data - Worksharing (M171) transaction.

- Start Date: Enter the WS agreement start date which is the w/c of the renewal.

- End Date: Enter the WS agreement end date.

- Project SCC: Enter the Service Canada Processing Centre of the project.

- Project number: Enter the project number (digits 1 to 10 of the reference code).

- Weekly hours: Enter the normal weekly hours (NWH) worked before the WS agreement. Include a 0 or a 5 at the end to indicate the hour or half hour. Do not include the decimal (e.g. 40 NWH are entered as 400 and 37.5 NWH are entered as 375).

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2893.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2894.dita)

- Determine if the WS agreement end date is beyond the BPC + 103:

- If yes, go to step 3.

- If no, go to step 5.

- If the WS agreement end date is beyond the BPC + 103, in ACS, create and send the F-00-00-00 letter. Based on the claim information, select all the required attributes, including the following :

- Free text (1612): Type:
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2895.dita)

- In NWS, create a new ROD as follows:

- Main Issue: Select Other .

- Comments: Type “Work-Sharing beyond client’s last renewable week (BPC + 103).”

- Details: Type “The client’s Work-Sharing agreement ends after the client’s last renewable week. The client has been advised by letter to reapply for benefits at the conclusion of this claim. At that time, the client will apply for regular benefits without a reference code. The following details can be used to complete the project data for the subsequent claim:

- Employer name: Enter the employer’s name.

- Original project start week: Enter the project start week.

- Project end week: Enter the project end week.

- Service Canada Centre: Enter the project SCC.

- Agreement number: Enter the agreement number.

- Weekly hours: Enter the weekly hours.”

- Select Save .

- In FTS, select the Renewal/Revised (M106) transaction and input a MA76 as follows:

- Manual action: Select 76 - Automated work-sharing .

- If the client is entitled for an exemption from reporting, Claim action: Select W - Worksharing – No claimant’s reports.

- If the client in not entitled for an exemption from reporting, Claim action: Select H - Worksharing with claimant’s reports.

- Click Update .

- No further action is required. 

#### Conversion onarenewalclaim — No outstanding adjudication

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/conversion_onarenewalclaim__no_outstand_aece20f5_level_1.dita`

- In FTS, select the Renewal/Revised (M106) transaction and complete the following fields:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Manual action: Select the appropriate option only if Level 2 adjudication is required.

- Claim action: Select one of the following:

- If the client has requested and is entitled to be exempt from completing claimant’s reports, select W - Worksharing - No claimant's reports .

- If the client has not requested or is not entitled to be exempt from completing claimant’s reports, select H - Worksharing with claimant's reports .

- Contentious: Select the appropriate option:

- If the conversion does not require Level 2 adjudication, select 1 – No .

- If the conversion requires Level 2 adjudication, select 2 – Yes .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In FTS, determine if the project data is on the Project tab:

- If yes, go to step 3.

- If no, select the Project data - Worksharing (M171) transaction and input the project data as follows:

- Start Date: Enter the WS agreement start date.

- End Date: Enter the WS agreement end date (the w/c of the start date + the amount of weeks indicated in digits 15 and 16 of the reference code).

- Project SCC: Enter the Service Canada Processing Centre of the project.

- Project number: Enter the project number (digits 1 to 10 of the reference code).

- Weekly hours: Enter the normal weekly hours (NWH) worked prior to the WS agreement. Include a 0 or a 5 at the end to indicate the hour or half hour. Do not include the decimal (e.g. 40 NWH is entered as 400 and 37.5 NWH is entered as 375).

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2893.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2896.dita)

- Determine if the WS agreement end date is beyond the BPC + 103:

- If yes, go to step 4.

- If no, go to step 6.

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all the required attributes, including the following:

- Free text (1612): Type:
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2895.dita)

- In NWS, create a new ROD as follows:

- Main Issue: Select Other .

- Comments: Type “Work-Sharing beyond client’s last renewable week (BPC + 103).”

- Details: Type “The client’s Work-Sharing agreement ends after the client’s last renewable week. The client has been advised by letter to reapply for benefits at the conclusion of this claim. At that time, the client will apply for regular benefits without a reference code. The following details can be used to complete the project data for the subsequent claim:

- Employer name: Enter the employer’s name.

- Original project start week: Enter the project start week.

- Project end week: Enter the project end week.

- Service Canada Centre: Enter the project SCC.

- Agreement number: Enter the agreement number.

- Weekly hours: Enter the weekly hours.”

- Select Save .

- Determine if there is an allocation of earnings that must be communicated to the client:

- If yes, go to step 7.

- If no, go to step 15.

- In NWS, determine if there is an outstanding ADJ WI:

- If no, go to step 8.

- If yes, go to step 14.

- Determine if one of the following situations applies:

- A disentitlement or definite disqualification is being input manually.

- There is an indefinite disqualification preventing payment on the renewal claim.

- If no, go to step 9.

- If yes, go to step 10.

- Determine if an MA02 is imposed on the claim:

- If yes, go to step 10.

- If no, go to step 14.

- Select the File Control Data (M101) transaction as follows:

- Select Claim Action .

- Select Automated Letter Bypass .

- In ACS, create and send a D-01-00-00 letter. Based on the claim information, select all the required attributes, including the following:

- To advise the client that the indefinite disqualification cannot be rescinded: Select Disqualifications - Definite / Indefinite - Previous / Current / Revision (2970) : Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542) .

- Select Disqualification message (2543) .

- To advise the client of the D15 : Select Disentitlements (2976) .

- To advise the client of the allocation : Select Allocation of Earnings (2516) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In ACS, determine if there are any saved letters for the renewal claim:

- If yes, go to step 13.

- If no, go to step 15.

- Determine if all decisions which must be communicated to the client were included in the D-01-00-00 letter:

- If yes, delete the saved letters. Go to step 15.

- If no, send the letters with only the decisions that are left to be communicated. Go to step 15.

- In NWS, create a client Note and type “Send D-20-16-03 letter.”

- Determine if 4 weeks or less are remaining payable on the BP before the LRW is reached:

- If yes, go to step 16.

- If no, go to step 17.

- Determine if the conversion is being finalized within 28 days of the application being filed (i.e. filing date + 27 days):

- If yes, go to step 17.

- If no, in NWS, create a Reminder (REM) WI for the subsequent claim as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “subsequent claim registration.”

- Due date: Enter the LRW .

- Language: Select the appropriate option.

- Details: Type “manual registration of subsequent claim required.”

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Select Save .

- Go to step 17.

- Complete the CA WI. 

#### Conversion on arenewalclaim — Outstanding adjudication

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/conversion_on_arenewalclaim__outstandin_ff822067_level_1.dita`

- In FTS, select the Renewal/Revised (M106) transaction and complete the following fields:

- Registration number : Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Manual action: Select the appropriate option only if Level 2 adjudication is required.

- Claim action: Select one of the following:

- If the client has requested and is entitled to be exempt from completing claimant’s reports: W - Worksharing - No claimant's reports .

- If the client has not requested or is not entitled to be exempt from completing claimant’s reports, H - Worksharing with claimant's reports .

- Contentious: Select the appropriate option:

- If the conversion does not require Level 2 adjudication, select 1 – No .

- If the conversion requires Level 2 adjudication, select 2 – Yes .

- Complete: Select D – No to leave the registration number open for subsequent transactions.

- Click Update .

- In FTS, determine if the project data is on the Project tab:

- If yes, go to step 3.

- If no, select the Project data – Worksharing (M171) transaction and input the project data as follows:

- Start Date: Enter the WS agreement start date.

- End Date: Enter the WS agreement end date (the w/c of the start date + the amount of weeks indicated in digits 15 and 16 of the reference code).

- Project SCC: Enter the Service Canada Processing Centre of the project.

- Project number: Enter the project number (digits 1 to 10 of the reference code).

- Weekly hours: Enter the NWH worked prior to the WS agreement. Include a 0 or a 5 at the end to indicate the hour or half hour. Do not include the decimal. E.g. 40 NWH is entered as 400 and 37.5 NWH is entered as 375.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2893.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2896.dita)

- Determine if the WS agreement end date is beyond the BPC + 103:

- If yes, go to step 4.

- If no, go to step 6.

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all the required attributes, including the following:

- Free text (1612): Type:
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2895.dita)

- In NWS, create a new ROD as follows:

- Main Issue: Select Other .

- Comments: Type “Work-Sharing beyond client’s last renewable week (BPC + 103).”

- Details: Type “The client’s Work-Sharing agreement ends after the client’s last renewable week. The client has been advised by letter to reapply for benefits at the conclusion of this claim. At that time, the client will apply for regular benefits without a reference code. The following details can be used to complete the project data for the subsequent claim:

- Employer name: Enter the employer’s name.

- Original project start week: Enter the project start week.

- Project end week: Enter the project end week.

- Service Canada Centre: Enter the project SCC.

- Agreement number: Enter the agreement number.

- Weekly hours: Enter the weekly hours.”

- Select Save .

- In FTS, determine if there is an allocation of earnings that must be communicated to the client:

- If yes, go to step 7.

- If no, go to step 9.

- In ACS, create and save a D-01-00-00 letter. Based on the claim information, select all the required attributes, including the following:

- Allocation of Earnings (2516) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note and type “Send the D-01-00-00 letter.”

- Determine if 4 weeks or less are remaining payable on the BP before the LRW is reached:

- If yes, go to step 10.

- If no, go to step 11.

- Determine if the renewal is being finalized within 28 days of the application being filed (i.e. filing date + 27 days):

- If yes, go to step 11.

- If no, in NWS, create a REM WI for the subsequent claim as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “subsequent claim registration.”

- Due date: Enter the LRW.

- Language: Select the appropriate option.

- Details: Type “manual registration of subsequent claim required.”

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Select Save .

- Go to step 11.

- Complete the Conversion WI for the conversion request. 

#### No benefits payable due to a D10 or D11

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/no_benefits_payable_due_to_a_d10_or_d11_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “WS benefits requested — benefits not payable.”

- Details: Type “No renewal for WS benefits is possible as [reason WS benefits are not payable].” Choose the appropriate option:

- If the client has not worked since the BPC , type “The client does not qualify for a new claim as no hours were accumulated after the BPC.”

- If the client has worked since the BPC , type “The client does not qualify for a new claim as [number of hours] were accumulated after the BPC. The client needed [number of hours] to qualify.”

- In FTS, select the Renewal/Revised (M106) transaction and complete the following fields:

- Claim denied: Check the box.

- Contentious: Select 1 – No .

- Complete: Select C – Yes .

- Click Update .

- In ACS, create and send the D-01-00-01 letter. Based on the claim information, select all the required attributes, including the following :

- Renewal week - Sunday’s date (1246).

- Disqualifications - Definite / Indefinite - Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542) .

- Select Disqualification message (2543) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the CA WI. 

#### Claim not renewable forWork-Sharing (WS)benefits

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/claim_not_renewable_forwork-sharing_wsbenefits_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim:

- If the client does not qualify for a new claim, go to step 3.

- If the client qualifies for a new claim, continue with Calculating or recalculating a claim for a regular benefits .
               [Calculating or recalculating a claim for a regular benefits](/en/procedure/activity/calculation.shtml)

- In NWS, create a ROD as follows:

- Comments: Type “no conversion — WS benefits not payable.”

- Details: Choose the appropriate option:

- If the client has not worked since the BPC , type “No conversion for WS benefits is possible as the client is not entitled to WS benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC.”

- If the client has worked since the BPC , type “No conversion for WS benefits is possible as the client is not entitled to WS benefits. The client does not qualify for a new claim as [number of hours] was accumulated after the BPC. The client needed [number of hours] to qualify.”

- In FTS, select the Renewal/Revised (M106) transaction and complete as follows:

- Claim denied: Check the box.

- Contentious: Select 1 – No .

- Complete: Select C – Yes .

- Click Update .

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all the required attributes, including the following :

- Free text (1612): Type: “We cannot reactivate your claim for Employment Insurance Work-Sharing benefits starting [renewal week - Sunday’s date]. Please note that we are required to advise you of all decisions made on your claim. No Work-Sharing benefits are payable to you on this claim because you have received all of the regular benefits to which you are entitled. To receive Work-Sharing benefits, you must be entitled to regular benefits. To receive regular benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you will have to apply for a new claim. You may be able to receive special benefits such as sickness, maternity, parental, compassionate care and caregiver benefits. If any of these benefit types apply to your situation, please contact us to find out whether you are eligible.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the CR WI. 

#### Reassign the WI to the Work-Sharing (WS) unit

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/reassign_the_wi_to_the_work-sharing_ws_unit_level_1.dita`

- In NWS, reassign the WI as follows:

- Destination — Level : Select the appropriate option:

- Ontario: 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - ON / Work-Sharing - ON .

- Quebec: 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC / Work-Sharing - QC .

- Reason: Select Unable to complete .

- Details: Type “BT is processed by specialized unit.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_2892.dita`

Note:

Although it is rare for a WS application to be submitted without a reference code, fact-finding with the client or the regional WS unit could be required to confirm that the client is participating in a WS agreement and to obtain the WS project information required for the project data.
       [fact-finding](/en/procedure/task/fact_find.shtml)

     [fact-finding](/en/procedure/task/fact_find.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Note

Source topic: `en_EN/common_notes/note_c_2732.dita`

Note:

When converting a claim to regular or sickness benefits, always determine if the client is available or otherwise available. 

#### Note

Source topic: `en_EN/common_notes/note_c_2721.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose an MA1 to stop payment. 

#### Note

Source topic: `en_EN/common_notes/note_c_2893.dita`

Note:

Only hours or half hours can be entered in the Weekly Hours field. Hours must be rounded up to the closer of the next hour or half hour. For example, 27 ¼ hours becomes 27.5 hours (entered as 275) and 38 ¾ hours becomes 39 hours (entered as 390). 

#### Note

Source topic: `en_EN/common_notes/note_c_2894.dita`

Note:

If the number of hours normally worked in a week exceeds 60 hours, the claim must be processed in MPS . Contact EI Operational Processes and Procedures at nc-bm-gdp-gd@servicecanada.gc.ca to review the file to determine if an averaging formula can be used to simplify the work and prevent MPS processing.
       [MPS](/en/procedure/activity/mps.shtml) 
       [nc-bm-gdp-gd@servicecanada.gc.ca](mailto:nc-bm-gdp-gd@servicecanada.gc.ca)

     [MPS](/en/procedure/activity/mps.shtml) 
     [nc-bm-gdp-gd@servicecanada.gc.ca](mailto:nc-bm-gdp-gd@servicecanada.gc.ca) 

#### Callout

Source topic: `en_EN/common_notes/note_c_2895.dita`

“Your current Work-Sharing agreement is valid until [Saturday of the last agreement week]. Under the Employment Insurance Act, the maximum duration for a benefit period is 104 weeks. Therefore, your Employment Insurance claim will end on or before [day 6 of BPC + 103].

If you are still participating in a Work-Sharing agreement at the end of your claim, take the following steps to avoid delays in benefit payments:

1. Apply for benefits

Submit an application for regular benefits after your claim ends (no reference code is needed for this new application). Enter [day 6 of BPC + 103] as your last day of work and choose I have a Work-Sharing agreement as the reason for separation.

2. Request a record of employment

Request your Work-Sharing employer issue a record of employment (ROE) for work up to [day 6 of BPC + 103], using code H-Work-Sharing . If you have had any other work since [day 1 of BPC], request each employer issue an ROE for all work up to, but not past, [day 6 of BPC + 103].

If you have any questions, contact us as indicated below.” 

#### Note

Source topic: `en_EN/common_notes/note_c_2896.dita`

Note:

If the number of hours normally worked in a week exceeds 60 hours the claim must be processed in MPS . Contact EI Operational Processes and Procedures at nc-bm-gdp-gd@servicecanada.gc.ca to review the file to determine if an averaging formula can be used to simplify the work and prevent MPS processing.
       [MPS](/en/procedure/activity/mps.shtml) 
       [nc-bm-gdp-gd@servicecanada.gc.ca](mailto:nc-bm-gdp-gd@servicecanada.gc.ca)

     [MPS](/en/procedure/activity/mps.shtml) 
     [nc-bm-gdp-gd@servicecanada.gc.ca](mailto:nc-bm-gdp-gd@servicecanada.gc.ca) 

## Policy reference

Source topic: `en_EN/task/converting_claim_sb_rb_client_ws/policy_reference.dita`

- EIA 10 (10)
         [EIA 10 (10)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-10.html#215961)

- EIA 10 (13)
         [EIA 10 (13)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-10.html#215973)

- EIA 12
         [EIA 12](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIR 26 (1)
         [EIR 26 (1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-26.1.html)

- EIR 44
         [EIR 44](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-44.html) 
