# Implementing client misrepresentation on a blocked claim — Penalty

Source map: `en_EN/task/iam_boa_bcs_cp/iam_boa_bcs_cp.ditamap`

## Summary

Source topic: `en_EN/task/iam_boa_bcs_cp/summary.dita`

Summary: When a penalty is being imposed against the client for making a misrepresentation on a blocked claim with updateable status, all decisions related to the misrepresentation must be input and the client must be notified. 

## What you need to know

Source topic: `en_EN/task/iam_boa_bcs_cp/what_you_need_to_know.dita`

### Adjudicating misrepresentation — Implementing the decision on a blocked claim

Source topic: `en_EN/task/iam_boa_bcs_cp/adjudicating_misrepresentation__impleme_3863da4d.dita`

The final step in adjudicating misrepresentation is to implement the decision by completing the appropriate inputs and notifying the client.

This implementation task applies to blocked claims that are updateable in BCS. It includes the following:

- inputting the reconsidered decision(s) in BCS and RCM (if applicable) to establish the overpayment (OP) or underpayment

- inputting the penalty in PSCD

- sending the decision letter in ACS

- clearing the case in NIIS

- completing the WI in NWS

When a third party makes a misrepresentation with the both the client’s knowledge and consent, it is considered collusion between the client and third party. In this situation, the client must repay the net OP and any applicable sanction can be imposed on both the client and the third party. 

### BCS

Source topic: `en_EN/task/iam_boa_bcs_cp/bcs.dita`

BCS allows certain types of transactions to be processed on blocked dormant claims. There are 2 options available: Estimate and Claim update .

**Updating a blocked claim**

When transactions must be input on a blocked claim, the Blocked tab in FTS must be reviewed to determine the BCS status. If the status of the claim is 1 - Updateable , an update is requested using BCS and the transactions can be processed.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3456.dita) 

Different transactions may need to be input over multiple days to obtain the correct OP messages. When inputting multiple transactions, the following order must be respected:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3457.dita) 

An update in BCS can only be done on one BPC at a time. When transactions are input but not processed, Yes appears in the Block Action Pending column and access is denied for input on all other BPCs until requested transactions are processed. Access to a BPC with a pending action is limited to the agent who initiated that action.

When updating a claim using BCS for misrepresentation cases, the agent must move the WI to Pending for the next day to allow BCS to calculate and establish the OP. Penalty inputs in PSCD and violation inputs in the Violation (ML01) transaction are done once the OP amount is known.

Once the transactions have been processed, BCS displays information that can be used to determine the penalty amount. The Results tab displays the net OP amount. In addition, the Penalty link provides details about the OP amount that was established for weeks within the 36-month period, if part of the reconsideration period is beyond the limitation for imposing a monetary penalty.

The Penalty determination window displays the net OP calculated for the 156-week period from the date the OP was established and from the current date. The information based on the current date can be used if there is a delay in reviewing the data and establishing the penalty.

If an update is requested by the agent but cannot be completed by BCS, on the next processing day, the “Blocked claim not updated or not calculated” message is displayed along with the exception, error or warning on the MR05 screen. Agents review the exception, error or warning on the Results tab in BCS for further action. If the update cannot be completed using BCS, the system presents an estimate result. The decision can be sent to IPOC using the Forward via MM06 link which creates the prefilled Renewal/Revised ( M106) and MM06 transactions.

**Estimate function**

The Estimate function in BCS allows agents to view and evaluate the end results without processing the transactions. Estimates are possible for blocked claims with a 1 - Updateable status as well as unblocked dormant claims, provided the CS is 05 (inactive) or 06 (terminated) .

BCS Estimate transactions are processed overnight and the results are available on the Results tab the next day. Agents that have requested an estimate can view the end result and forward the request for IPOC intervention using the prefilled MM06 available under the Results tab. 

### Coding a full work week (FWW)

Source topic: `en_EN/task/iam_boa_bcs_cp/coding_a_full_work_week_fww.dita`

When clients report earnings on their claimant’s report, the earnings are coded along with an FWW code, if applicable. An FWW is coded if the client declared working 35 hours or more (28 hours or more in a week containing one of these 4 federal statutory holidays: New Year’s Day, Canada Day, Labour Day, Christmas Day). An investigation could reveal that FWWs have been coded when the client did not work or worked less than an FWW. When an FWW must be removed, document the decision on a record of decision (ROD). 

### Inputting the special condition in RCM

Source topic: `en_EN/task/iam_boa_bcs_cp/inputting_the_special_condition_in_rcm.dita`

If the reconsideration decision is related to the RFS and the ROE is on file, the Special condition field must be updated in RCM to show the decision. The RCM input can be done at any time. 

### Completing the case in NIIS

Source topic: `en_EN/task/iam_boa_bcs_cp/completing_the_case_in_niis.dita`

Level 2 agents have access to NIIS to view selected information and to complete cases they have adjudicated. Although the Level 2 decisions are documented in NWS, the Decision tab on the Report of Investigation ( IC50 or IC70 ) screen must be completed to close the case. This ensures that NIIS has a complete record of the investigation.

It is important to note that the FTS and PSCD inputs, not the amounts entered on the Decision tab, update the OP and penalty values on the Subject Enquiry (IC07) screen in NIIS. If the OP and penalty values are not automatically updated, they can be manually updated by an NIIS regional coordinator so that Integrity staff receive proper credit for their work.
       [NIIS regional coordinator](https://esdc.prv/en/service-canada/isb/io/bso/iccm_coordinators.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3456.dita`

Note:

At this time, BCS cannot process a benefit period (BP) extension, the recalculation of a claim, the removal of a manual action (MA) or a change in the FWW code for a week of special benefits. The agent must send and Operational Centre Memo (MM06) transaction asking IPOC to process these transactions. 

### Callout

Source topic: `en_EN/common_notes/note_c_3457.dita`

**Input order for multiple transactions**

- full disentitlement

- partial disentitlement

- unreported earnings / unreported allocation of earnings

- indefinite disqualification

- definite disqualification 

## Regional considerations

Source topic: `en_EN/task/iam_boa_bcs_cp/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/iam_boa_bcs_cp/what_you_need_to_look_for.dita`

### In PSCD:

Source topic: `en_EN/task/iam_boa_bcs_cp/in_pscd.dita`

- Once the reconsideration transactions have processed, what is the net OP resulting from the misrepresentation? 

### In FTS:

Source topic: `en_EN/task/iam_boa_bcs_cp/in_fts.dita`

- Is the misrepresentation on an active or dormant claim?

- Is there a FWW code 1, 2 or 3 in any of the reports under investigation? 

### In NWS:

Source topic: `en_EN/task/iam_boa_bcs_cp/in_nws.dita`

- On the reconsideration ROD:

- What transactions (allocation, disentitlement, disqualification, recalculation, etc.) are required?

- On the misrepresentation or penalty ROD:

- Does the misrepresentation involve the RFS?

- Does the misrepresentation involve the submission of a false ROE or an ROE containing false information?

- What is the level of misrepresentation?

- What is the number of misrepresentations (false or misleading statements knowingly made)?

- What is the amount of the penalty being imposed?

- Are there documents related to the issue? 

### In NIIS:

Source topic: `en_EN/task/iam_boa_bcs_cp/in_niis.dita`

- On the Report of Investigation (IC50 or IC70) screen:

- What is the investigation type?

- What is the Integrity case number?

- On the Observation (IC04) screen:

- If applicable, what are the client’s actual earnings to be allocated? 

### In Imaging:

Source topic: `en_EN/task/iam_boa_bcs_cp/in_imaging.dita`

- Is there a Request for Payroll Information (INS5097) or Request for Clarification of Employment Information (INS5098) showing the client’s actual earnings to be allocated? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/iam_boa_bcs_cp/in_integrity_investigations_document_up_6a8da64b.dita`

- Is there any document containing mitigating circumstances? 

### In RCM:

Source topic: `en_EN/task/iam_boa_bcs_cp/in_rcm.dita`

- If the misrepresentation involved the client’s RFS, is the ROE on file? 

## Step by step

Source topic: `en_EN/task/iam_boa_bcs_cp/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/iam_boa_bcs_cp/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/iam_boa_bcs_cp/reviewing_the_file_level_2.dita`

- Determine if the misrepresentation inputs involve the removal of an MA, a change in an FWW code for a week of special benefits, a claim recalculation or a BP extension:

- If no, go to step 2.

- If yes, go to Implementing client misrepresentation on an archived claim — Penalty .
               [Implementing client misrepresentation on an archived claim — Penalty](/en/procedure/task/iam_cp_bhc.shtml)

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 3.

- If all rows are blank, go to step 5.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “waiting for an updateable status in BCS.”

- Bring forward date: Enter [the next business day].

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column under the Blocked tab:

- If Yes is displayed in one of the rows, repeat step 3.

- If all rows are blank, go to step 5. 

#### Inputting the decision in FTS

Source topic: `en_EN/task/iam_boa_bcs_cp/inputting_the_decision_in_fts_level_2.dita`

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised (or 2 - Renewal , if applicable).

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Click Update .

- Determine if the reconsideration decision requires the input of multiple transactions. If yes, the following order must be respected:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3457.dita)

- Determine the result of the reconsideration decision:

- If the decision results in a disentitlement, go to step 8.

- If the decision results in unreported earnings, go to step 9.

- If the decision results in an unreported allocation of earnings, go to step 10.

- If the decision results in a disqualification, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3458.dita)

- Under the Disentitlements tab, input the disentitlement on the Disentitlements section as follows (up to 4 disentitlements in BCS can be imposed, rescinded or terminated):

- Action: Select A - Add .

- Type: Select the appropriate disentitlement.

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select the appropriate option:

- For a 1 - Not unemployed (D1) disentitlement, select U - Fraud - Earnings and employment .

- For any other disentitlement, select V - Fraud - Availability, Capability.

- Message: Select the appropriate message:

- For a definite disentitlement, select 3 - An overpayment resulted due to a definite disentitlement .

- For an indefinite disentitlement, select 4 - An overpayment resulted due to an indefinite disentitlement .

- Click Update.

- Go to step 13.

- Under the Allocation "A" tab, in the Amended Earnings column, input the amended earning as follows:

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3459.dita) 

- Select the week that requires a change and enter the new amount of earnings. Repeat for every week that requires a change.

- Amended earnings: Enter the new amount of earnings.

- FWW: Select the new FWW code (if a change is needed) .

- Infraction: Select U - Fraud - Earnings and employment .

- Message: Select 7 - You misrepresented your earnings .

- Click Update .

- Go to step 13.

- Under the Allocations tab, input the allocation in the Allocations section as follows:

- Action: Select A - Add .

- Type: Select the appropriate allocation type.

- Amount: Enter the amount allocated per week.

- Start date: Enter the start date of the allocation.

- End date: Enter the end date of the allocation or 9999 if the end date is indefinite.

- Last week amount: Select the appropriate option:

- If the allocation amount in the last week is less than the normal weekly earnings, enter that amount.

- If the allocation amount in the last week is equal to the normal weekly earnings, leave the box empty.

- Infraction: Select U - Fraud - Earnings and employment .

- Message: Select (the appropriate message).

- Click Update .

- Go to step 13.

- Under the Disqualifications tab, input the disqualification on the Disqualifications section as follows (up to 3 disqualifications in BCS can be imposed or rescinded):

- Action: Select A - Add .

- Type: Select the appropriate disqualification type.

- Effective Week: Select the disqualification start date.

- Number of Weeks: Select the appropriate option.

- For an indefinite disqualification, 9999 will be prefilled.

- For a definite disqualification, select a number from 1 to 12 according to decision.

- Infraction: Select Z - Fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Click Update .

- Determine if the ROE is on file:

- If no, go to step 13.

- If yes, in RCM, update the Special condition field to reflect the reconsideration decision on the RFS. Go to step 13.

- Under the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 14.

- If the transaction shown is correct, click Close and go to step 15.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Click Update .

- Select the appropriate option:

- If the decision resulted in a disentitlement, return to step 8.

- If the decision resulted in unreported earnings, return to step 9.

- If the decision resulted in an unreported allocation of earnings, return to step 10.

- If the decision resulted in a disqualification, return to step 11.

- In NWS, move the Claim Review (CR) Integrity WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “ Penalty to be input once OP is established.”

- Bring forward date: Select or enter the next business day.

- When the CR Integrity WI moves to the current workload, in BCS, verify in the Results tab in BCS if the OP has been established:

- If the OP result was changed to an estimate and there are errors showing, the transactions have not processed. Go to step 17.

- If the transactions have processed with no errors and the OP is established, go to step 22.

- Click Exceptions/Errors/Warnings to view the WECS codes.

- Determine if the error can be fixed using BCS:

- If yes, click Re-input Transactions and correct the information.

- If no, go to Inputting the decision using the Forward via MM06 link in BCS.
               [Inputting the decision using the Forward via MM06 link](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/iam_boa_bcs_cp#MM06)

- In FTS, remove the SIN from the Rejected Transactions Retrieval (MR05) screen as follows:

- Completed by: Enter your user code.

- Click Search .

- Delete: Check the box next to the appropriate SIN and transaction.

- Click Update .

- In NWS, move the CR Integrity WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “ Penalty to be input once OP is established.”

- Bring forward date: Select or enter the next business day.

- When the CR Integrity WI moves to the current workload, in BCS, verify in the Results tab in BCS if the OP has been established:

- If the transactions have processed with no errors and the OP is established, go to step 22.

- If the OP result was changed to an estimate and there are errors showing, the transactions have not processed. Go to Inputting the decision using the Forward via MM06 link in BCS .
               [Inputting the decision using the Forward via MM06 link](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/iam_boa_bcs_cp#MM06) 

#### Inputting a penalty

Source topic: `en_EN/task/iam_boa_bcs_cp/inputting_a_penalty_level_2.dita`

- Determine the penalty amount as follows:

- If the period under review falls within the 36-month limitation period, multiply the net OP amount found on the Results tab by the applicable percentage.

- If the period under review falls near the 36-month limitation period, on the Results tab, click Penalty to determine the penalty amount based on net OP within the 36-month limitation period and multiply it by the applicable percentage.

- In PSCD, enter the penalty.

- Refer to Creating a debt in PSCD and then go to step 24.
               [Creating a debt in PSCD](/en/procedure/task/creating_a_debt_in_pscd.shtml) 

#### Sending an ACS letter

Source topic: `en_EN/task/iam_boa_bcs_cp/sending_an_acs_letter_level_2.dita`

- Determine if the case involves more than 52 weeks of unreported earnings:

- If yes, go to step 25.

- If no, go to step 26.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3460.dita)

- In ACS, create and send the D-91-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Decision reconsidered beyond 36 months (2595): Select the appropriate option.

- Opening Sentence for post audit penalty and violation letter (2905)

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Definite Disqualification Messages - D06/D07/D09 (2918)

- D13 or D38 - Outside Canada (Interstate option)/on vacation within or outside Canada (2924)

- Various reasons for penalty and violation: Found work / Self Employment / Capability / Training / Availability / Full work week / Text (2935): Select Blank .

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared/omitted (2953)

- No reply from client/reply received with an explanation/reply received with no explanation (2938)

- False representation message/Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452)

- This Letter Replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “This letter includes only the information for the calendar year [20XX]. The information for calendar year [20XX] is included in a separate letter.”

- In ACS, create and send the D-91-00-00 letter to inform the client of the reconsideration and penalty decisions. Unless specified, select the most appropriate option for each of the following attributes:

- Decision reconsidered beyond 36 months (2595): Select the appropriate option.

- Opening Sentence for post audit penalty and violation letter (2905)

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Definite Disqualification Messages - D06/D07/D09 (2918)

- D13 or D38 - Outside Canada (Interstate option)/on vacation within or outside Canada (2924)

- Various reasons for penalty and violation: Found work / Self Employment / Capability / Training / Availability / Full work week / Text (2935): Select the applicable option, or if the period of disentitlement and an explanation are required, select Failed to provide information: Text: Specify what we have learned .

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared/omitted (2953)

- No reply from client/reply received with an explanation/reply received with no explanation (2938)

- False representation message/Number of omissions or false representations (2941)

- Levels of misrepresentation (12292)

- Penalty message / Warning message (2950): Select Penalty message .

- Overpayment Messages (2452)

- Determine if a sanction also applies to a third party:

- If yes, go to Implementing third party misrepresentation to impose the sanctions on the third party and to complete the case.
               [Implementing third party misrepresentation](/en/procedure/task/implementing_tp_misrepresentation.shtml)

- If no, go to step 29.

- In NIIS, on the Decision tab of the Report of Investigation (IC50 or IC70) screen, clear the case as follows:

- Overpayment: Indicate whether an OP resulted from the misrepresentation.

- Reason: Select the appropriate option based on the decision that resulted in the OP.

- Amount: Enter the total net OP that resulted from the misrepresentation.

- Penalty: Select Yes .

- Amount: Enter the penalty amount.

- Warning: Select No .

- Violation: Select No .

- In NWS, complete the CR Integrity WI. 

#### Inputting the decision using the Forward via MM06 link in BCS

Source topic: `en_EN/task/iam_boa_bcs_cp/inputting_the_decision_using_the_forwar_a2e92a33_level_2.dita`

- In BCS, under the Results tab, select the estimated result that must be sent to IPOC and click the Forward via MM06 link.

- Determine the result of the reconsideration decision:

- If the decision results in a disentitlement, go to step 3.

- If the decision results in unreported earnings, go to step 5.

- If the decision results in an unreported allocation of earnings, go to step 7.

- If the decision results in a disqualification, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3461.dita)

- When the Renewal/Revised (M106) transaction opens, complete the missing information as follows:

- Infraction: Select the appropriate option :

- For a 1 - Not unemployed (D1) disentitlement, select U - Fraud - Earnings and employment .

- For any other disentitlement, select V - Fraud - Availability, Capability .

- Message: Select the appropriate message.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Click Update .

- When the Operational Centre Memo (MM06) transaction opens, complete the missing information as follows:

- Work item: Select the appropriate option:

- If the transaction impacts cycling claimant’s reports on a blocked claim, select 93 - Manual Pay System .

- If there are no cycling claimant’s reports, select 91 - Overpayment .

- Work type: Select the appropriate option:

- If the Work item is 91 , select 1 - Misrepresentation .

- If the Work item is 93 , select 33 - Blocked claim requiring payment .

- Remarks line 2: Indicate all of the following, where applicable:

- Whether additional information is being provided on another Operational Centre Memo (MM06) transaction (e.g. page 1 of 3, page 2 of 3).

- Whether it is urgent. If so, provide the reason (e.g. URGENT approaching time limitation for penalty).

- Whether changes are required to the FWW.

- Remarks line 3: Type all of the following:

- P: penalty percentage including mitigating circumstances

- LMR: 1st, 2nd or 3rd level of misrepresentation (for the penalty percentage)

- MPA: maximum penalty amount

- LVA: legal validation amount

- Integrity case number

- Remarks line 4: Type “Add [missing fields] to D-91-00-00 letter and send.”

- Remarks line 5: Indicate your name and telephone number.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the last Operational Centre Memo (MM06) transaction.

- D - No if more than one Operational Centre Memo (MM06) transaction is required.

- Click Update .

- Go to step 11.

- When the Renewal/Revised (M106) transaction opens, complete the missing information as follows:

- Infraction: Select U - Fraud - Earnings and employment .

- Message: Select 7 - You misrepresented your earnings .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Click Update .

- When the Operational Centre Memo (MM06) transaction opens, complete the missing information as follows:

- Work item: Select the appropriate option:

- If the transaction impacts cycling claimant’s reports on a blocked claim, select 93 - Manual Pay System .

- If there are no cycling claimant’s reports, select 91 - Overpayment .

- Work type: Select the appropriate option:

- If the Work item is 91 , select 1 - Misrepresentation .

- If the Work item is 93 , select 33 - Blocked claim requiring payment .

- Remarks line 2: Indicate all of the following, where applicable:

- Whether additional information is being provided on another Operational Centre Memo (MM06) transaction (e.g. page 1 of 3, page 2 of 3).

- Whether it is urgent. If so, provide the reason (e.g. URGENT approaching time limitation for penalty).

- Whether changes are required to the FWW.

- Remarks line 3: Type all of the following:

- P: penalty percentage including mitigating circumstances

- LMR: 1st, 2nd or 3rd level of misrepresentation (for the penalty percentage)

- MPA: maximum penalty amount

- LVA: legal validation amount

- Integrity case number

- Remarks line 4: Type “Add [missing fields] to D-91-00-00 letter and send.”

- Remarks line 5: Indicate your name and telephone number.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the last Operational Centre Memo (MM06) transaction.

- D - No if more than one Operational Centre Memo (MM06) transaction is required.

- Click Update .

- Go to step 11.

- When the Renewal/Revised (M106) transaction opens, complete the missing information as follows:

- Infraction: Select U - Fraud - Earnings and employment .

- Message: Select the appropriate message.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Click Update .

- When the Operational Centre Memo (MM06) transaction opens, complete the missing information as follows:

- Work item: Select the appropriate option:

- If the transaction impacts cycling claimant’s reports on a blocked claim, select 93 - Manual Pay System .

- If there are no cycling claimant’s reports, select 91 - Overpayment .

- Work type: Select the appropriate option:

- If the Work item is 91 , select 1 - Misrepresentation .

- If the Work item is 93 , select 33 - Blocked claim requiring payment .

- Remarks line 2: Indicate all of the following, where applicable:

- Whether additional information is being provided on another Operational Centre Memo (MM06) transaction (e.g. page 1 of 3, page 2 of 3).

- Whether it is urgent. If so, provide the reason (e.g. URGENT approaching time limitation for penalty).

- Whether changes are required to the FWW.

- Remarks line 3: Type all of the following:

- P: penalty percentage including mitigating circumstances

- LMR: 1st, 2nd or 3rd level of misrepresentation (for the penalty percentage)

- MPA: maximum penalty amount

- LVA: legal validation amount

- Integrity case number

- Remarks line 4: Type “Add [missing fields] to D-91-00-00 letter and send.”

- Remarks line 5: Indicate your name and telephone number.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the last Operational Centre Memo (MM06) transaction.

- D - No if more than one Operational Centre Memo (MM06) transaction is required.

- Click Update .

- Go to step 11.

- When the Renewal/Revised (M106) transaction opens, complete the missing information as follows:

- Infraction: Select Z - Fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Click Update .

- When the Operational Centre Memo (MM06) transaction opens, complete the missing information as follows:

- Work item: Select the appropriate option:

- If the transaction impacts cycling claimant’s reports on a blocked claim, select 93 - Manual Pay System .

- If there are no cycling claimant’s reports, select 91 - Overpayment .

- Work type: Select the appropriate option:

- If the Work item is 91 , select 1 - Misrepresentation .

- If the Work item is 93 , select 33 - Blocked claim requiring payment .

- Remarks line 2: Indicate all of the following, where applicable:

- Whether additional information is being provided on another Operational Centre Memo (MM06) transaction (e.g. page 1 of 3, page 2 of 3).

- Whether it is urgent. If so, provide the reason (e.g. URGENT approaching time limitation for penalty).

- Whether changes are required to the FWW.

- Remarks line 3: Type all of the following:

- P: penalty percentage including mitigating circumstances

- LMR: 1st, 2nd or 3rd level of misrepresentation (for the penalty percentage)

- MPA: maximum penalty amount

- LVA: legal validation amount

- Integrity case number

- Remarks line 4: Type “Add [missing fields] to D-91-00-00 letter and send.”

- Remarks line 5: Indicate your name and telephone number.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the last Operational Centre Memo (MM06) transaction.

- D - No if more than one Operational Centre Memo (MM06) transaction is required.

- Click Update .

- Go to step 11.

- In FTS, remove the SIN from the Rejected Transactions Retrieval (MR05) screen as follows:

- Completed by: Enter your user code.

- Click Search .

- Delete: Check the box next to the appropriate SIN and transaction.

- Click Update .

- Determine if the case involves more than 52 weeks of unreported earnings:

- If yes, go to step 13.

- If no, go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3460.dita)

- In ACS, create and save the D-91-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Decision reconsidered beyond 36 months (2595): Select the appropriate option.

- Opening Sentence for post audit penalty and violation letter (2905)

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Definite Disqualification Messages - D06/D07/D09 (2918)

- D13 or D38 - Outside Canada (Interstate option)/on vacation within or outside Canada (2924)

- Various reasons for penalty and violation: Found work / Self Employment / Capability / Training / Availability / Full work week / Text (2935): Select Blank .

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared/omitted (2953)

- No reply from client/reply received with an explanation/reply received with no explanation (2938)

- False representation message/Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452)

- This Letter Replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “This letter includes only the information for the calendar year [20XX]. The information for calendar year [20XX] is included in a separate letter.”

- In ACS, create and save the D-91-00-00 letter to inform the client of the reconsideration and penalty decisions. Unless specified, select the most appropriate option for each of the following attributes:

- Decision reconsidered beyond 36 months (2595): Select the appropriate option.

- Opening Sentence for post audit penalty and violation letter (2905)

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Definite Disqualification Messages - D06/D07/D09 (2918)

- D13 or D38 - Outside Canada (Interstate option) /on vacation within or outside Canada (2924)

- Various reasons for penalty and violation: Found work / Self Employment / Capability / Training / Availability / Full work week / Text (2935): Select the applicable option, or if the period of disentitlement and an explanation are required, select Failed to provide information: Text: Specify what we have learned .

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared/omitted (2953)

- No reply from client/reply received with an explanation/reply received with no explanation (2938)

- False representation message/Number of omissions or false representations (2941)

- Levels of misrepresentation (12292)

- Penalty message / Warning message (2950): Do one of the following:

- If you know the penalty amount, select Penalty message and enter the original penalty amount and number of false representations.

- If you are unsure of the penalty amount, leave this attribute blank (and indicated on the MM06 that IPOC must add or amend this field).

- Overpayment Messages (2452)

- Determine if a sanction also applies to a third party:

- If yes, go to Implementing third party misrepresentation to impose the sanctions on the third party and to complete the case.
               [Implementing third party misrepresentation](/en/procedure/task/implementing_tp_misrepresentation.shtml)

- If no, go to step 16.

- In NIIS, on the Decision tab of the Report of Investigation (IC50 or IC70) screen, clear the case as follows:

- Overpayment: Indicate whether an OP resulted from the misrepresentation.

- Reason: Select the appropriate option based on the decision that resulted in the OP.

- Amount: Enter the estimated total net OP that resulted from the misrepresentation.

- Penalty: Select Yes .

- Amount: Enter the penalty amount.

- Warning: Select No .

- Violation: Select No .

- In NWS, complete the CR Integrity WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1791.dita`

Note:

An update in BCS can only be done on one BPC at a time. 

#### Note

Source topic: `en_EN/common_notes/note_c_3458.dita`

Note:

When there are multiple reconsideration decisions, complete each applicable step. 

#### Warning

Source topic: `en_EN/common_notes/note_c_3459.dita`

Warning:

If the client declared earnings from another employment for a week that is being amended, combine the earnings for both employments for that week. Allocate the total earnings. 

#### Note

Source topic: `en_EN/common_notes/note_c_3460.dita`

Note:

If the case involves more than 52 weeks of unreported earnings, a D-91-00-00 letter is required for each calendar year. The penalty information for the entire case is only included in the letter for the most recent calendar year. 

#### Note

Source topic: `en_EN/common_notes/note_c_3461.dita`

Note:

When there are multiple reconsideration decisions, complete each applicable step.

Multiple reconsideration decisions can be combined on one Operational Centre Memo (MM06) transaction but a separate Operational Centre Memo (MM06) transaction is required for each BPC. 

## Policy reference

Source topic: `en_EN/task/iam_boa_bcs_cp/policy_reference.dita`

- EIA 38
         [EIA 38](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-38.html) 
