# Actioning rejected utilization report declarations — IPOC

Source map: `en_EN/task/actioning_rejected_urd_ipoc/actioning_rejected_urd_ipoc.ditamap`

## Summary

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/summary.dita`

Summary: When a utilization report (UR) is uploaded to FTS, not all declarations are processed. When conditions require special attention, the declaration will be rejected from the upload. The IPOC officer reviews the rejected declarations to determine the required action. 

## What you need to know

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/what_you_need_to_know.dita`

### Automated Worksharing screen in FTS

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/automated_worksharing_screen_in_fts.dita`

The Automated Worksharing screen in FTS has a number of built-in edits. If a declaration does not meet the edit requirements or the IPOC officer added a special condition code to the declaration, the part of the declaration that requires further review is highlighted in red. Any declaration highlighted in red will be rejected when the screen is uploaded. 

### Triage process

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/triage_process.dita`

A triage process was developed to convert URs received through the Data Gateway and upload them to FTS.

Since the triage process cannot action UR declarations with comments, a workaround was created to notify an IPOC officer to review all UR declarations with comments.

The triage process converts the UR and inputs special condition code 11 - Non-available and sick days are greater than 5 in all declarations that contain a comment. IPOC officers need to familiarize themselves with this workaround because there are 2 scenarios where declarations can be coded with special condition code 11 . The 2 scenarios are:

- An IPOC officer inputs special condition code 11 to reject a UR declaration if not available days and sick days are greater than 5. NWS generates an IPOC System Notification (IPOC SN) Work-sharing - Special condition WI. The rejected client record is also available for review on the WD0242 EDS report.

- The triage process inputs special condition code 11 to reject a UR declaration with a comment. The SIN is added to an .XML file in the Rejected_Declarations subfolder.

The IPOC officer reviews all other information on the UR to determine the correct action to take to address the special condition code. 

### Saving rejected declarations

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/saving_rejected_declarations.dita`

The triage officer uploads the URs that were converted during the triage process to AWSS and saves any rejected UR declarations in the Rejected_Declarations folder.

When an IPOC officer is uploading a UR the IPOC officer converted manually, declarations highlighted in red remain on the Automated Worksharing screen. The IPOC officer can save the rejected declaration for future action. The IPOC officer saves the declarations in the Rejected_Declarations subfolder using the name of the employer, the agreement number and the w/c in the file name.

The naming convention contains the following information, in order, without spaces or dashes between the information, except where the dash is specifically indicated:

- IPOC [dash]

- UR [dash]

- the 10-digit agreement number (if the agreement number has fewer than 10 digits, add the required number of zeros before the agreement number)

- the first 6 characters of the employer’s name, including spaces (if the employer’s name has fewer than 6 characters, add the required number of spaces after the last character)

- the w/c [dash]

- REJECT

     [Examples](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1551.dita) 

All declarations that are rejected from a single UR are saved together in one file.

The rejected declarations saved by either the triage officer or the IPOC officer will be saved in .XML format and cannot be opened directly from the saved document. To review the rejected declarations, the IPOC officer retrieves the saved file from the Automated Worksharing screen in FTS. 

### Examples

Source topic: `en_EN/common_notes/note_c_1551.dita`

Examples:

IPOC-UR-0123456789Employ2400-REJECT

IPOC-UR-0123456789Empl  2400-REJECT 

## Regional considerations

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/what_you_need_to_look_for.dita`

## Step by step

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/step_by_step.dita`

### IPOC

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/ipoc.dita`

#### Uploading the rejected declarations

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/uploading_the_rejected_declarations_ipoc.dita`

- In FTS, select the Automated Worksharing screen to upload the rejected declarations that have been saved:

- Select File .

- Select Retrieve .

- Select Saved Data .

- Open the Rejected_Declarations folder.

- Select the saved file and select Open .

- On the Automated Worksharing screen, determine if special condition code 11 is displayed in the Reason Not Working field for the declaration:

- If yes, open to the original UR to review the declaration and determine the required action. Go to step 3.

- If no, go to step 3.

- Determine if fact-finding is required:

- If no, go to step 4.

- If yes, refer to Fact-finding with a Work-Sharing employer . Go to step 4.
               [Fact-finding with a Work-Sharing employer](/en/procedure/task/fact_finding_wse.shtml)

- Determine if the declaration must be uploaded to FTS:

- If yes, go to step 5.

- If no, go to step 6.

- On the Automated Worksharing screen in FTS, do the following:

- Determine if there are non-available days, sick days, paid sick leave (PSL) amounts and other amounts paid that require special attention or coding.

- Determine if there are any comments in the UR that require a special condition code or further action (e.g. planned shutdown, apprenticeship or a contentious reason for separation).

- Edit the appropriate fields and select Modify . For coding guidance, refer to Work-Sharing: Utilization report coding — Input guide .
               [Work-Sharing: Utilization report coding — Input guide](/en/procedure/generic/additionalresources/ws_coding_utilization_report.shtml)

- Select Update .

- Select Yes .

- If remaining unresolved records appear:

- Select File .

- Select Save .

- Use the same file name when saving. Make sure the extension is .XML.

- Select Yes to replace the existing file with the most recent version.

- If there are no more records to be corrected:

- Do you wish to delete the current XML file?: Select Yes .

- A pop-up window confirms that the file was deleted.

- Select Ok .

- Determine if further action is required (e.g. a WI or other claim inputs):

- If yes, complete the necessary actions and go to step 7.

- If no, go to step 7.

- Once all claims are uploaded, delete the UR that was uploaded from the Upload_to_FTS folder. No further action is required. 

## Policy reference

Source topic: `en_EN/task/actioning_rejected_urd_ipoc/policy_reference.dita`

 
