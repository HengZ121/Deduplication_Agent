# Adjudicating a dismissal for unsuitability — Renewal claim

Source map: `en_EN/task/dismissal_rc/dismissal_rc.ditamap`

## Summary

Source topic: `en_EN/task/dismissal_rc/summary.dita`

Summary: The Level 1 officer adjudicates cases of dismissal only when clients are dismissed because they were not suitable, did not pass training or were terminated within the probationary period, and not for any ill-intentioned action. 

## What you need to know

Source topic: `en_EN/task/dismissal_rc/what_you_need_to_know.dita`

### Adjudicating a dismissal for unsuitability

Source topic: `en_EN/task/dismissal_rc/adjudicating_a_dismissal_for_unsuitability.dita`

Clients may be dismissed for unsuitability during the probationary period or if they do not pass the probationary period or do not meet the job requirements. 

### Levels of decision

Source topic: `en_EN/task/dismissal_rc/levels_of_decision.dita`

In order for the dismissal to be adjudicated at Level 1, the client’s statement on the renewal application must show that the client was dismissed for being unsuitable or due to a shortage of work. In addition, the employer’s statement or comments on the ROE must indicate that the client was dismissed for being unsuitable ( Not suitable , Did not pass training , or Terminated within the probationary period ) and there must not be any other contentious issues related to the dismissal that would prevent the Level 1 officer from allowing the reason for separation (RFS).

If the client worked for the employer for 12 weeks or less and the employer or the comments on the ROE confirm that the RFS is unsuitability ( Not suitable , Did not pass training , or Terminated within the probationary period ), the officer does not fact-find with the client, even if the client did not provide details regarding the employment on the EI application. The officer can allow the dismissal as long as there are no other contentious issues related to the dismissal.

If the employer or ROE comments do not confirm unsuitability, or if the client worked for the employer for more than 12 weeks, the officer fact-finds with the client.

For more information, the officer refers to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

The officer reviews the ROE to determine if the employer indicated that the client was dismissed for unsuitability or if the client ’s employment was terminated in the probationary period. If there is no indication on the ROE or if there is no ROE on file, the officer fact-finds with the employer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3226.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3267.dita) 

### Claim action status and processing the claim

Source topic: `en_EN/task/dismissal_rc/claim_action_status_and_processing_the_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . All Adjudication (ADJ) WIs must be completed before the system can finalize the renewal. There is a Resolve Issue tab for ADJ Dismissed or suspended WIs which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a record of decision (ROD) based on the Resolve Issue screens. When the renewal is finalized, the system generates the required transactions based on the Resolve Issue screens and removes the stop payment (MA02). No letter is sent when the dismissal for unsuitability is allowed. 

### Previously adjudicated decision

Source topic: `en_EN/task/dismissal_rc/previously_adjudicated_decision.dita`

In some cases, the ADJ WI may be for a dismissal issue that was previously adjudicated. The officer indicates on the Resolve Issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the applicable special condition based on the previous decision. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/dismissal_rc/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Previously deferred decision

Source topic: `en_EN/task/dismissal_rc/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 10 - Dismissal - misconduct proven (D10) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D10 that is on file and update the Special Condition field on the ROE in RCM. 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/dismissal_rc/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the dismissal or suspension is not required if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, an authorized user must delete the ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3240.dita) 

### Claim action status and processing the claim

Source topic: `en_EN/task/dismissal_rc/claim_action_status_and_processing_the_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . All Adjudication (ADJ) WIs must be completed before the system can finalize the renewal. There is a Resolve Issue tab for ADJ Dismissed or suspended WIs which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a record of decision (ROD) based on the Resolve Issue screens. When the renewal is finalized, the system generates the required transactions based on the Resolve Issue screens and removes the stop payment (MA02). No letter is sent when the dismissal for unsuitability is allowed. 

### Adjudication not previously required — Specialized ACP process

Source topic: `en_EN/task/dismissal_rc/adjudication_not_previously_required__s_a89cd8c4.dita`

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the qualifying period (QP). The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0092.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_3226.dita`

Note:

On a Web ROE, the employer can select the code M - Dismissal or suspension / Terminated within the probationary period in block 16 - Reason for Issuing the ROE , which is equivalent to comments in block 18 indicating that the client was dismissed due to unsuitability, not passing training or being terminated within the probationary period. 

### Note

Source topic: `en_EN/common_notes/note_c_3267.dita`

Note:

The statement that the client was dismissed “without cause” is not sufficient to conclude that the client was dismissed for unsuitability. The officer must fact-find with the employer to determine the cause of the dismissal.

Confirmation of the reason for dismissal with the employer is not required if the comment on the ROE shows one of the following reasons:

- Not suitable;

- Did not pass training;

- Terminated within the probationary period. 

### Note

Source topic: `en_EN/common_notes/note_c_3240.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the dismissal or suspension is required when the employment is not insurable due to a non-arm’s length issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0092.dita`

Note:

Any contentious RFS issues in the benefit period (BP) must be adjudicated. 

## Regional considerations

Source topic: `en_EN/task/dismissal_rc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/dismissal_rc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/dismissal_rc/in_nws.dita`

- Is there a ROD for dismissal on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Dismissal section of this or a previous EI application?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the dismissal?

- Is the appropriate ROE linked to the period of employment for the dismissal issue? 

### In Imaging:

Source topic: `en_EN/task/dismissal_rc/in_imaging.dita`

- Are there any imaged documents relating to the dismissal? 

### In RCM:

Source topic: `en_EN/task/dismissal_rc/in_rcm.dita`

- Is there an ROE for the dismissal?

- If yes, is the RFS K or M in block 16 of the ROE?

- Are there comments related to the dismissal? 

## Step by step

Source topic: `en_EN/task/dismissal_rc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/dismissal_rc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/dismissal_rc/reviewing_the_file_level_1.dita`

- In NWS, determine if there is a ROD for the dismissal issue on file:

- If there is a ROD for the dismissal issue, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_rc#DecisionOnFile)

- If there is no ROD for the dismissal issue, go to step 2.

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred, refer to Deferring adjudication .

- Determine if the facts on file clearly indicate that the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_rc#NotInsurable)

- If neither of these reasons applies, go to step 5.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita) 

#### Fact-finding

Source topic: `en_EN/task/dismissal_rc/fact-finding_level_1.dita`

- Determine if there is enough information to adjudicate the dismissal based on the National Policy on Levels of Decision :

- If additional details are needed, fact-find with the client or employer and go to step 6.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If additional details are not needed, go to step 8.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3268.dita)

- Determine if the client or employer was contacted during fact-finding:

- If the client or employer was not contacted or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_rc#level2)

- If the client or employer was contacted, go to step 7.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Dismissal — [employer’s name] — [last day worked] — [client or employer].”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/dismissal_rc/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the RFS is contentious:

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS) .
               [Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_rc#RFSVL)

- If the RFS is dismissal, go to step 9.

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if the client provided details regarding the RFS on the EI application:

- If no, go to step 10.

- If yes, go to step 11.

- Determine if the following conditions are met:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3269.dita) 

- If all conditions are not met, go to step 11.

- If all conditions are met, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_rc#RFSallowed)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3265.dita)

- Determine if all conditions are met to allow adjudication at Level 1:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3270.dita) 

- If all conditions are met, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_rc#RFSallowed)

- If all conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_rc#level2) 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/dismissal_rc/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Dismissal screen as follows:

- Select Based on the information on file, the criteria to allow the decision to be made at Level 1 have been met. The employer confirms the reason for separation was not due to any wrong-doing on the part of the client. (National Policy on Levels of Decision) .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In FTS, determine if a D10 was imposed because this RFS adjudication was previously deferred:

- If yes, go to step 4.

- If no, go to step 6.

- Determine if the D10 was only imposed due to this previously deferred RFS issue and if other issues must be adjudicated:

- If no other issues must be adjudicated, go to step 5.

- If other issues must be adjudicated refer to the appropriate tasks for instructions. Then go to step 5.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-Fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In RCM, determine if the ROE is on file:

- If no, go to step 7.

- If yes, in RCM, update the Special condition field and go to step 7.

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/dismissal_rc/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Dismissal or suspension — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the dismissal or suspension is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the dismissal or suspension is therefore not required.”

- Contact an authorized user (team leader or business expertise advisor) to delete the ADJ WI. 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/dismissal_rc/non-contentious_reason_for_separation_rfs_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Dismissal screen as follows:

- Select The reason for separation is not dismissal or suspension .

- Select Continue .

- Complete the Not dismissal or suspension screen as follows:

- Select the appropriate RFS.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In RCM, determine if the ROE is on file:

- If yes, go to step 5.

- If no, go to step 7.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select the appropriate RFS option and sub-option, if necessary.

- Select Validate .

- Select Submit .

- Determine if the ROE was flagged in error after validation:

- If yes, fix the validation error and go to step 7.

- If no, go to step 7.

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/dismissal_rc/decision_already_on_file_level_1.dita`

- Determine if the applicable decision is listed:

- If yes, on the list, select the applicable ROD and select Save . Go to step 4.

- If no, select Decision not in the list .

- Select the special condition that applies based on the decision on file and select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/dismissal_rc/reassigning_the_issue_to_level_2_level_1.dita`

- Reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity Level: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type one of the following:

- “Client dismissed for reasons other than unsuitable. Not within Level 1 authority.”

- “Unable to contact employer to confirm details of dismissal.”

- Select OK .

- When the Warning window is displayed, select Ok . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_3268.dita`

Note:

If fact-finding with the employer is required to confirm that the client was dismissed for unsuitability, ask the employer to provide more details regarding why the client was dismissed.

For example, was the client unsuitable because they were unable to perform the tasks required or was the client considered unsuitable because they were late to work every day? The client being unable to perform the tasks required requires Level 1 adjudication, but being late requires Level 2 adjudication.

A dismissal can be allowed without fact-finding with the client if the following conditions are met:

- The employment was for 12 weeks or less.

- The employer or the ROE comments confirm that the client was dismissed due to unsuitability.

If these conditions are not met, fact-find with both the client and the employer. For more information, refer to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

     [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

#### Callout

Source topic: `en_EN/common_notes/note_c_3269.dita`

- the client worked for the employer for 12 weeks or less; and

- the client did not provide any details on the EI application about that employment; and

- the employer, when contacted, confirms that the client was not suitable for the position and there was no misconduct; or

- a comment on the ROE confirms the dismissal is due to the client being unsuitable, not passing training or being terminated within the probationary period; and

- there are no other contentious issues related to the dismissal that would prevent the Level 1 officer from allowing the RFS. 

#### Note

Source topic: `en_EN/common_notes/note_c_3265.dita`

Note:

A client may forget to include an employer on the EI application when the period of employment was for a short time or the client may fail to provide additional information regarding the RFS on the EI application.

The dismissal can be allowed without fact-finding with the client if the following conditions are met:

- The employment was for 12 weeks or less.

- The employer or the ROE comments confirm that the client was dismissed due to unsuitability.

- There are no other contentious issues that would prevent a Level 1 officer from allowing the RFS.

If all of these conditions are not met, fact-find with the client. For more information, refer to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

     [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 

#### Callout

Source topic: `en_EN/common_notes/note_c_3270.dita`

- the client indicates being dismissed due to unsuitability or due to a shortage of work; and

- the employer, when contacted, confirms the client was not suitable for the position and there was no misconduct; or

- a comment on the ROE confirms the dismissal is due to the client being unsuitable, not passing training” or being terminated within the probationary period; and

- there are no other contentious issues related to the dismissal that would prevent the Level 1 officer from allowing the RFS. 

## Policy reference

Source topic: `en_EN/task/dismissal_rc/policy_reference.dita`

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- National Policy on Levels of Decision—Not Misconduct
         [National Policy on Levels of Decision—Not Misconduct](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
