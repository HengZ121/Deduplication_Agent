# Adjudicating voluntary leaving: Continuing claim — Level 2

Source map: `en_EN/task/voluntary_leaving_l2/voluntary_leaving_l2.ditamap`

## Summary

Source topic: `en_EN/task/voluntary_leaving_l2/summary.dita`

Summary: When a client voluntarily leaves employment, entitlement to regular benefits on a continuing claim may be affected. If the reason for separation (RFS) cannot be allowed at Level 1 according to the National policy on Levels of Decision , the voluntary leaving must be adjudicated at Level 2 to determine if the client had just cause for leaving the employment.
       [National policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

## What you need to know

Source topic: `en_EN/task/voluntary_leaving_l2/what_you_need_to_know.dita`

### Adjudicating voluntary leaving

Source topic: `en_EN/task/voluntary_leaving_l2/adjudicating_voluntary_leaving.dita`

The adjudication process is the same (though the inputs are different) for the following types of voluntary leaving:

- permanently leaving employment

- taking a temporary leaving of absence from employment (refer to Adjudicating a leave of absence — Level 2 )
         [Adjudicating a leave of absence — Level 2](/en/procedure/task/adjudicating_loa_l2.shtml)

- leaving employment early in anticipation of a layoff or the end of the term of employment

**ROE**

An ROE is not required to adjudicate a voluntary leaving.

When the voluntary leaving is adjudicated and the ROE has been received, the Special condition field of the ROE must be updated.

**Determining just cause**

When clients voluntarily leave their employment, you must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave. If it is determined that the client left the employment without just cause, an indefinite disqualification is imposed on the claim for regular benefits beginning on the Sunday of the week the event took place, unless the client has worked enough insurable hours since voluntary leaving to establish a new claim.

When the Level 1 officer cannot allow the voluntary leaving according to the National policy on Levels of Decision , the Level 2 officer must fact-find to determine if the client has just cause and render a decision. It must first be proven that the client left the employment voluntarily. Once it is established that the client initiated the leaving, just cause is determined as follows:
       [National policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- If the client demonstrates that there was no reasonable alternative to leaving the employment, just cause is proven.

- If the client does not demonstrate that there is no reasonable alternative to leaving the employment, just cause is not proven.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1737.dita) 

### Fact-finding

Source topic: `en_EN/task/voluntary_leaving_l2/fact-finding.dita`

The adjudicating officer gathers all relevant information and completes all fact-finding before adjudicating the issue. The Level 2 officer must:

- offer the client and the employer the opportunity to provide information concerning the RFS;

- allow both parties to provide an explanation or clarification when there are contradictory statements;

- give the client the opportunity to provide a final rebuttal;

- take this information into account when adjudicating the issue; and

- give the client the benefit of the doubt when the facts provided by the client and those provided by the employer are equally credible.

**Fact-finding — Voluntary leaving for personal reasons**

In cases where clients voluntarily leaving their employment strictly for personal reasons (e.g. returning to school, changing careers, providing care for an ill child), it is unnecessary to contact the employer again after the initial fact-finding if:

- the facts are credible, and

- considering all factors, it is unlikely that the employer has any information about the existence or absence of other reasonable alternatives for the client.

**Client wishes that employer not be contacted**

In cases where the voluntary leaving is not strictly for personal reasons and the client does not want the employer to be contacted, officers must explain that they are legally required to fact-find with the employer.

**Refusing employment**

Voluntarily leaving an employment can also include:

- refusing employment that is offered as an alternative to an anticipated loss of employment (the voluntary leaving occurs when the loss of employment occurs);

- refusing to resume an employment (the voluntary leaving occurs when the employment is meant to resume; and

- refusing to continue an employment after the work, undertaking or business of the employer is transferred to another employer.

**Mandatory retirement**

Human rights legislation in Canada prohibits mandatory retirement. Very few occupations are exempt from this legislation. Some employers may be able to demonstrate a genuine reason for mandatory retirement, however these cases are rare.

In cases of mandatory retirement, clients do not voluntarily leave their employment. The separation is initiated by the employer. Consequently, a Level 2 officer must adjudicate the reason for separation as a dismissal and determine whether the client lost the employment due to misconduct.
       [dismissal](/en/procedure/task/dismissal_ds.shtml)

**Non-insurable employment**

Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is not required if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. 

### Imposing a disqualification or disentitlement

Source topic: `en_EN/task/voluntary_leaving_l2/imposing_a_disqualification_or_disentitlement.dita`

Once it is determined that the client did not have just cause for voluntarily leaving the employment, the officer must determine whether an indefinite disqualification or disentitlement applies.

**Imposing a disentitlement**

If the client voluntarily left the employment within 3 weeks of an anticipated layoff or the end of term employment, the 44 - Loss of employment in anticipation of layoff disentitlement (D44) is imposed. The D44 is imposed for a definite period only (maximum 3 weeks).

**Imposing a disqualification**

If the client voluntarily left more than 3 weeks before the anticipated layoff and in all other cases , the 11 - Voluntary leaving - just cause not proven indefinite disqualification (D11) is imposed.

**Suspending a disqualification or disentitlement**

The D11 disqualification and the D44 disentitlement are suspended when special benefits are claimed and otherwise payable. 

### Previously deferred decision

Source topic: `en_EN/task/voluntary_leaving_l2/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D11 that is on file and update the Special Condition field on the ROE on RCM. 

### Automated adjudication

Source topic: `en_EN/task/voluntary_leaving_l2/automated_adjudication.dita`

ACP does not automate a Level 2 decision for voluntary leaving. 

### Notifying the employer

Source topic: `en_EN/task/voluntary_leaving_l2/notifying_the_employer.dita`

The employer must be notified in writing of the decision and provided with the right to request a reconsideration in the case of voluntary leaving when the reasons for leaving are work-related , but just cause for leaving was shown. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/voluntary_leaving_l2/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1737.dita`

Note:

For information regarding reason for separation (RFS) issues resulting from a client not complying with the employer’s COVID-19 vaccination policy, the officer refers to the EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo) .
       [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml)

     [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml) 

## Regional considerations

Source topic: `en_EN/task/voluntary_leaving_l2/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/voluntary_leaving_l2/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/voluntary_leaving_l2/in_nws.dita`

- What is the client’s statement in the Voluntary Leave section of this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the voluntary leaving on this or a previous EI application? 

### In FTS:

Source topic: `en_EN/task/voluntary_leaving_l2/in_fts.dita`

- Have claimant’s reports been processed for the period in question?

- If yes, when was the original statement made?

- Is there a manual action (MA) to suspend payments on the claim concerning this issue?

- What is the benefit type? 

### In Imaging:

Source topic: `en_EN/task/voluntary_leaving_l2/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving? 

### In RCM:

Source topic: `en_EN/task/voluntary_leaving_l2/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving? 

## Step by step

Source topic: `en_EN/task/voluntary_leaving_l2/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/voluntary_leaving_l2/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/voluntary_leaving_l2/reviewing_the_file_level_2.dita`

- Determine if the facts on file clearly indicates that the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_l2#NotInsurable)

- If the facts do not clearly indicate that the employment is not insurable for one of these reasons, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if there is enough information on file to adjudicate the RFS:

- If additional information is needed, go to step 5.

- If additional information is not needed, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/voluntary_leaving_l2/fact-finding_level_2.dita`

- Fact-find with the client and the employer. Refer to the Fact-Finding Guide and Digest 6 — Voluntary leaving employment to determine the questions to ask.

- Determine if the client or employer was contacted during fact-finding:

- If the client or employer was contacted, go to step 7.

- If the client or employer was not contacted or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to step 8.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Voluntary leaving — [employer’s name] — LDW — [client].”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1746.dita) 

#### Adjudicating voluntary leaving

Source topic: `en_EN/task/voluntary_leaving_l2/adjudicating_voluntary_leaving_level_2.dita`

- Determine if just cause is proven, considering all evidence provided by both the client and the employer, and in accordance with the principles outlined in the Act, Regulations and case law. Refer to Digest 6 — Voluntary leaving employment as needed.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1747.dita) 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/voluntary_leaving_l2/record_of_decision_rod__creation_level_2.dita`

- In NWS, create a ROD and complete the following fields:

- Comments: Enter the appropriate comments based on the decision:

- If the decision is that just cause is not shown, type “voluntary leaving — [employer’s name] — [last day worked] — just cause not shown.”

- If the decision is that just cause is shown, type “voluntary leaving — [employer’s name] — [last day worked] — just cause shown.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- If the decision is Voluntary leaving — Just cause shown, click Save because you do not need to verbally communicate the decision.

- If the decision is Voluntary leaving — Just cause not shown, click Draft because you need to verbally communicate the decision.

- If the decision is Leaving before anticipated layoff or end of term of employment — Just cause not shown, click Draft because you may need to verbally communicate the decision.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1351.dita) 

#### Inputs and communication

Source topic: `en_EN/task/voluntary_leaving_l2/inputs_and_communication_level_2.dita`

- Select one of the following based on the decision:

- Voluntary leaving — Just cause not shown
               [Voluntary leaving — Just cause not shown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_l2#VLnjc)

- Voluntary leaving — Just cause shown
               [Voluntary leaving — Just cause shown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_l2#VLjc)

- Voluntary leaving before anticipated end of employment — Just cause not shown
               [Voluntary leaving before anticipated end of employment — Just cause not shown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_l2#D44)

- Rescinding a Voluntary leaving - just cause not proven indefinite disqualification (D11) — Previously deferred decision or following a request for reconsideration
               [Rescinding a Voluntary leaving - just cause not proven indefinite disqualification (D11) — Previously deferred decision or following a request for reconsideration](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_l2#rd11) 

#### Voluntary leaving — Just cause not shown

Source topic: `en_EN/task/voluntary_leaving_l2/voluntary_leaving__just_cause_not_shown_level_2.dita`

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 2.

- If the client was not reached by telephone during fact-finding, go to step 3.

- Verbally communicate the decision to the client.

- In RCM, determine if the ROE with the voluntary leaving has been received:

- If the ROE has been received, go to step 4.

- If the ROE has not been received, go to step 5.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select E - Quit .

- Special condition: Select Voluntary leaving - No just cause .

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Click Validate .

- Click Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4979.dita)

- In FTS, determine if an MA75 is imposed for the voluntary leaving:

- If an MA75 is imposed, go to step 6.

- If an MA75 is not imposed, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1750.dita)

- Select the Renewal/Revised (M106) transaction to remove the MA75 and impose the disqualification as follows:

- Manual action: Select 75 - Verification of reason for termination of employment .

- Rescind: Check the box.

- Action: Select Add .

- Disqualification: Select 11 - Voluntary Leave - Just Cause not proven .

- Effective: Enter the week code for the effective start date of the voluntary leaving.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F – Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration open for subsequent transactions.

- Click Update .

- Go to step 8.

- Select the Disqualifications/Disentitlements (M161) to impose the disqualification as follows:

- Action: Select Add .

- Disqualification: Select 11 - Voluntary Leave - Just Cause not proven .

- Effective: Enter the week code for the effective start date of the voluntary leaving.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F – Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration open for subsequent transactions.

- Click Update .

- In ACS, create and send a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits and does not have hours since the voluntary leaving to qualify, select the following attributes:

- Disqualifications – Definite/Indefinite - Previous/current/revision (2970): Select D11 / D10 / Both / Previous disqualification / Revision (Initial/Renewal or Revision) (2542) .

- D11 / D10 / Both / Previous disqualification / Revision (Initial/Renewal or Revision) (2542): Select Disqualification message .

- Disqualification message (2543): Select D11 - Voluntary leaving .

- D11 — No benefits payable (Date of event: before, om, or after the BPC date) (2544): Select Date of event after BPC and the applicable sub-options.

- D11 - Min hrs req for reg/Insuf. hrs accum. since event reg/Insuf. hrs/reg+earnings/ fishing (2545):

- If the client has not worked since the event select Minimum hours required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hours accumulated since event for regular or Insufficient hours accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but you do not have the information or knowledge to complete this block, select Minimum hours required to qualify for regular benefits .

- If the client is requesting regular benefits and has enough hours since the voluntary leaving to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE Excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 message - D10 message (2463): Select D11 message .

- If the client is requesting special benefits and does not have enough hours since the voluntary leaving to qualify for regular benefits, select the following attributes:

- Special benefits approved (3046) and the applicable options.

- Not Entitled to Regular AFTER Special: D10/D11 or Claim is BPNE Initial or Renewal claim or D42 - D43 (2540): Select (D11/D10) imposed – Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491): Select D11 imposed – Special benefits allowed .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the applicable date.

- D11 - Min hrs req for reg ben/Insuf. hrs accum. Since event reg/Insuf. hrs/reg+ earnings/fishing (2545):

- If the client has not worked since the event select Minimum hours required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hours accumulated since event for regular or Insufficient hours accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but you do not have the information or knowledge to complete this block, select Minimum hours required to qualify for regular benefits .

- If the client is requesting special benefits and has enough hours since the voluntary leaving to qualify for regular benefits, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text - Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (2463): Select D11 message .

- Special benefits approved (3046): Select benefit type and the applicable options.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI related to the voluntary leaving. 

#### Voluntary leaving — Just cause shown

Source topic: `en_EN/task/voluntary_leaving_l2/voluntary_leaving__just_cause_shown_level_2.dita`

- In RCM, determine if the ROE with the voluntary leaving has been received:

- If the ROE has been received, go to step 2.

- If the ROE has not been received, go to step 3.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select E - Quit .

- Special condition: Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Click Validate .

- Click Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4979.dita)

- In FTS, determine if an MA75 is imposed for the voluntary leaving:

- If an MA75 is imposed, go to step 4.

- If an MA75 is not imposed and the registration number is not a recalculation registration number, go to step 5.

- If an MA75 is not imposed but the registration number is a recalculation registration number, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1750.dita)

- Select the Renewal/Revised (M106) transaction to remove the MA75 as follows:

- Manual Action: Select 75 - Verification of reason for termination of employment .

- Rescind: Check the box.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete : Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration open for subsequent transactions.

- Click Update .

- Go to step 6.

- In FTS, select the Renewal/Revised (M106) transaction to clear the outstanding registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number.

- Click Update .

- In ACS, if required to inform the employer of the decision, create and send a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved reason for separation and the applicable sub-options.

- Reason for Claim Approval (2783): Select Valid Reason for Leaving or Valid Reason not to Return to Work or Became Employed Elsewhere .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI related to the voluntary leaving. 

#### Voluntary leaving before anticipated end of employment — Just cause not shown

Source topic: `en_EN/task/voluntary_leaving_l2/voluntary_leaving_before_anticipated_en_d591facb_level_2.dita`

- Determine if the client left the employment more than 3 weeks before the anticipated layoff or the end of the term of employment:

- If the client left the employment more than 3 weeks before the layoff or end of term, refer to Voluntary leaving: Just cause not shown — Continuing claim .
               [Voluntary leaving: Just cause not shown — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_l2#VLjc)

- If the client left the employment 3 weeks or less before the layoff or end of term, go to step 2.

- In NWS, save the draft ROD.

- In RCM, determine if the ROE with the voluntary leaving has been received:

- If the ROE has been received, go to step 4.

- If the ROE has not been received, go to step 5.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select E - Quit .

- Special condition: Select Anticipated loss of employment .

- End date: Enter the date the employment was expected to end.

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Click Validate .

- Click Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4979.dita)

- In FTS, determine if an MA75 is imposed for the voluntary leaving:

- If an MA75 is imposed, go to step 6.

- If an MA75 is not imposed, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1750.dita)

- Select the Renewal/Revised (M106) transaction to remove the MA75 as follows:

- Manual Action: Select 75 - Verification of reason for termination of employment .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 44 - Anticipated loss of employment .

- Start date: Enter the date after the last day worked.

- End date: Enter the date of the anticipated loss of employment.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Decision type: Select 3 - Revised .

- Contentious : Select 2 - Yes .

- Complete : Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Click Update .

- Go to step 8.

- In FTS, select the Disqualifications/Disentitlements (M161) to impose the disentitlement as follows:

- Action: Select Add .

- Disentitlement: Select 44 - Anticipated loss of employment .

- Start date: Enter the day following the last day of work.

- End date: Enter the date of the anticipated loss of employment.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Decision Type: Select 3 - Revised .

- Contentious : Select 2 - Yes .

- Complete : Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In ACS, create and send a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the following attributes:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 (3021): Select D44 - Leaves employment without just cause within 3 weeks of layoff or end of term .

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the benefit type and the applicable options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text – Footnote (11745): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [X] to [X]. You voluntarily left your employment with [Text - Name of Employer(s)] on [Date of Event] without just cause within 3 weeks of [being laid off/the end of term].”

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI related to the voluntary leaving. 

#### Rescinding a Voluntary leaving - just cause not proven indefinite disqualification (D11) — Previously deferred decision or after a request for reconsideration

Source topic: `en_EN/task/voluntary_leaving_l2/rescinding_a_voluntary_leaving_-_just_c_63f16b91_level_2.dita`

- In RCM, determine if the ROE with the voluntary leaving has been received:

- If the ROE has been received, go to step 2.

- If the ROE has not been received, go to step 3.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment : Select E - Quit .

- Special condition : Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the RFS from block 18 to the Additional information field.

- Click Validate .

- Click Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4979.dita)

- Determine if the D11 is solely due to the previously deferred RFS issue or reconsidered decision and if other issues must be adjudicated:

- If no other issues must be adjudicated, go to step 4.

- If other issues must be adjudicated, refer to the appropriate task for guidance. Then, go to step 4.

- Click the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Click Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: F – Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Click Update .

- Determine if the decision is made following a request for reconsideration under EIA 112:

- If no, go to step 6.

- If yes, return to the originating task.

- In ACS, if required to inform the employer of the decision, create and send a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved reason for separation and the applicable sub-options.

- Reason for Claim Approval (2783): Select Valid Reason for Leaving or Valid Reason not to Return to Work or Became Employed Elsewhere .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the WI related to the voluntary leaving. 

#### Employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_l2/employment_is_not_insurable_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “voluntary leaving — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Complete the WI related to the voluntary leaving. 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_1746.dita`

Note:

Create a new SROC for each conversation with the employer or the client (e.g. if you contacted the employer twice, create 2 SROCs). 

#### Note

Source topic: `en_EN/common_notes/note_c_1747.dita`

Note:

If you are unable to contact the client or the employer, render a decision based on the information on file. 

#### Note

Source topic: `en_EN/common_notes/note_c_1351.dita`

Note:

If fact-finding by telephone was attempted but was not successful, click Save regardless of the decision, because verbal communication of the decision is not required. 

#### Note

Source topic: `en_EN/common_notes/note_c_4979.dita`

Note:

Clicking Validate may cause the ROE to be flagged with an error. You are not required to fix the error. The ROE is corrected if and when the client applies for a subsequent claim. 

#### Note

Source topic: `en_EN/common_notes/note_c_1750.dita`

Note:

In some instances an MA01 may have been imposed instead of the MA75. The process for removing the MA01 is the same as for the MA75. However, before removing the MA01, verify that there are no remaining issues to adjudicate. 

## Policy reference

Source topic: `en_EN/task/voluntary_leaving_l2/policy_reference.dita`

- Digest 6 — Voluntary leaving employment
         [Digest 6 — Voluntary leaving employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- BE 2010-12 — Voluntary Leaving to Attend Approved Training
         [BE 2010-12 — Voluntary Leaving to Attend Approved Training](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2010-12.shtml)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- EIA 32
         [EIA 32](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-32.html)

- EIA 33
         [EIA 33](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-33.html) 
