# Adjudicating voluntary leaving (Level 1): Workforce reduction — Renewal claim

Source map: `en_EN/task/vl_wr_rc/vl_wr_rc.ditamap`

## Summary

Source topic: `en_EN/task/vl_wr_rc/summary.dita`

Summary: When a client voluntarily leaves employment due to workforce reduction, entitlement to regular benefits on a renewal claim may be affected. Adjudication is required to determine if there is just cause for leaving the employment. 

## What you need to know

Source topic: `en_EN/task/vl_wr_rc/what_you_need_to_know.dita`

### Adjudicating voluntary leaving for a workforce reduction

Source topic: `en_EN/task/vl_wr_rc/adjudicating_voluntary_leaving_for_a_wo_b21e16ff.dita`

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave the employment. If it is determined that the client left the employment without just cause, a disqualification is imposed on the claim for regular benefits, unless there are enough insurable hours since the voluntary leaving to establish a new claim. In this case, the ROE with the voluntary leaving is excluded from the calculation of the claim.

The objective of a workforce reduction program is to ensure the economic viability of a company, an organization, a firm or a plant. To remain competitive, employers may have to restructure their workforce, which could include permanently reducing the number of employees. The group covered under a workforce reduction program may be all the employees (including seasonal, temporary or on call employees) or it could be limited to a sector, a particular group of workers or a particular work site. Workforce reduction could also include as little as one employee. Employees who leave under an approved workforce reduction program have a complete severance from their employment. The details of the workforce reduction program must be documented.

The appropriate regional workforce reduction coordinator renders all decisions on a workforce reduction program. The regional coordinator ensures that the initial fact-finding is completed and that decisions on workforce reduction programs are made and posted in Major Employer Events .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

If a decision has not yet been posted in Major Employer Events , the officer completes the email template and sends it to the regional workforce reduction coordinator for the region where the employer’s head office is located.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596) 
       [regional workforce reduction coordinator](https://esdc.prv/en/service-canada/ei/contacts/workforce_reduction_coor.shtml)

Workers who agree to leaving their jobs under an approved workforce reduction program to preserve the job of a co-worker are not subject to disqualification for leaving according to EIR 51 , and may receive benefits if they meet the other entitlement conditions of the EIA (e.g. they are available for and actively seeking employment).
       [EIR 51](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html)

A workforce reduction program is defined in EIR 51(2) as a program:
       [EIR 51(2)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html)

- that is initiated by the employer;

- that has as its objective a permanent reduction in the number of employees;

- that offers employees the option to leaving employment voluntarily;

- whose elements are documented by the employer.

Employers planning a workforce reduction program may submit a request to Service Canada for confirmation that their plan meets the requirements of the EIR.

The request should contain information confirming:

- the plan was initiated by the employer;

- the objective is to permanently reduce the workforce;

- the employees covered by the program.

Service Canada cannot provide a blanket decision that applies to all employees, but provides an employer with prior confirmation that an employer’s workforce reduction program meets the conditions of EIR 51 .
       [EIR 51](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html)

Regions usually have procedures in place for documenting approved workforce reduction programs. For information about approved workforce reduction programs, the officer refers to Major Employer Events . Employers are often advised to confirm the existence of a valid workforce reduction program in the Comments block of the ROE. If there is no documentation confirming the workforce reduction program as valid, or if the employer has not documented the ROE to that effect, the officer must fact-find with the employer.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

An ROE is not required to adjudicate a voluntary leaving.

In NWS, there may be a “New ROE” message displayed on the Adjudication Issue (ADJ) WI for the voluntary leaving issue. The message indicates that a new ROE has been received with a reason for separation (RFS) that must be reviewed. The ROE may match the period of employment for that ADJ WI or for another outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4936.dita) 

### Automated adjudication

Source topic: `en_EN/task/vl_wr_rc/automated_adjudication.dita`

ACP does not automate a decision for voluntary leaving due to workforce reduction. 

### Levels of decision

Source topic: `en_EN/task/vl_wr_rc/levels_of_decision.dita`

When the reason for the voluntary leaving is according to an approved workforce reduction program under EIR 51 ( National Policy on Levels of Decision ), Level 1 officers may adjudicate and allow benefits.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

When the Level 1 cannot adjudicate the issue, the facts are documented and the voluntary leaving is referred to Level 2 for adjudication. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/vl_wr_rc/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the reason for separation (RFS) was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Previously deferred decision

Source topic: `en_EN/task/vl_wr_rc/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D11 that is on file and update the Special Condition field on the ROE in RCM. 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/vl_wr_rc/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the voluntary leaving is not required if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, an authorized user must delete the ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4925.dita) 

### Claim action status and processing the claim

Source topic: `en_EN/task/vl_wr_rc/claim_action_status_and_processing_the_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . All ADJ WIs must be completed before the system can finalize the renewal. There is a Resolve Issue tab for ADJ Voluntary Leaving WIs which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a record of decision (ROD) based on the Resolve Issue screens. When the renewal is finalized, the system generates the required transactions based on the Resolve Issue screens and removes the stop payment (MA02). No letter is sent when the client is allowed to voluntarily leave an employment due to an approved workforce reduction program.

In some cases, the ADJ WI may be for a voluntary leaving issue that was previously adjudicated. The officer indicates on the Resolve Issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the applicable special condition based on the previous decision. 

### Adjudication not previously required — Specialized ACP process

Source topic: `en_EN/task/vl_wr_rc/adjudication_not_previously_required__s_a89cd8c4.dita`

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the qualifying period (QP). The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0092.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4936.dita`

Note:

The client may report voluntary leaving on the application for benefits but the ROE indicates a non-contentious RFS. In this situation, fact-finding is required. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the WI is completed indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_4925.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0092.dita`

Note:

Any contentious RFS issues in the benefit period (BP) must be adjudicated. 

## Regional considerations

Source topic: `en_EN/task/vl_wr_rc/regional_considerations.dita`

Atlantic and Western Canada and Territories regions — For events before May 14, 2018, the decisions concerning labour disputes can be found in the following databases:

- Atlantic region : Documents are stored in the regional common document share under EI Document Library / Employer Info / WorkForceReduction

- Western Canada and Territories region: WT regional site
         [WT regional site](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/wfr.shtml)

Business expertise advisors can access the list of regional coordinators by referring to Regional Workforce Reduction Coordinators .
       [Regional Workforce Reduction Coordinators](https://esdc.prv/en/service-canada/ei/contacts/index.shtml) 

## What you need to look for

Source topic: `en_EN/task/vl_wr_rc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/vl_wr_rc/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Voluntary Leave section of this or a previous EI application?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the voluntary leaving on this or a previous EI application?

- Is the appropriate ROE linked to the period of employment for the voluntary leaving issue? 

### Major Employer Events:

Source topic: `en_EN/task/vl_wr_rc/major_employer_events.dita`

- Is there any information relating to the workforce reduction program? 

### In Imaging:

Source topic: `en_EN/task/vl_wr_rc/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving on this or a prior application? 

### In RCM:

Source topic: `en_EN/task/vl_wr_rc/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving? 

## Step by step

Source topic: `en_EN/task/vl_wr_rc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/vl_wr_rc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/vl_wr_rc/reviewing_the_file_level_1.dita`

- Determine if there is a ROD for the voluntary leaving issue on file:

- If there is no ROD for the voluntary leaving issue, go to step 2.

- If there is a ROD for the voluntary leaving issue, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_rc#DEC)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred, by referring to Deferring adjudication .

- Determine if the facts on file clearly indicate that the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 5.

- If the facts on file clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_rc#NOTINS)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Review Major Employer Events to determine if the employer has an approved workforce reduction program:

- If no, go to step 6.

- If yes, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_rc#RFSallowed) 

#### Fact-finding

Source topic: `en_EN/task/vl_wr_rc/fact-finding_level_1.dita`

- Fact-find with the employer to determine the client’s RFS.

- Determine if the employer was reached during fact-finding:

- If the employer was reached, go to step 8.

- If the employer was not reached or did not reply to the Z-00-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_rc#ressigntol2)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — employer.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/vl_wr_rc/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the RFS is contentious:

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS) .
               [Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_rc#RFSVL)

- If the RFS is voluntary leaving, go to step 10.

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if the employer indicates that the client left under an approved workforce reduction program:

- If yes, go to step 11.

- If no and the RFS indicated by the employer can be resolved at Level 1, go to the appropriate procedure to adjudicate the Voluntary leaving .
               [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml)

- If no and the RFS indicated by the employer cannot be resolved at Level 1, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_rc#ressigntol2)

- Contact a business expertise advisor to determine if the workforce reduction program has been approved and not yet entered in Major Employer Events .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4935.dita)

- In NWS move the WI for the issue to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “awaiting business expertise advisor’s answer.”

- Bring forward date: Enter the date the request is sent + 10 business days.

- When an answer is received from the business expertise advisor or when the WI moves to the current workload, determine if there is an approved workforce reduction program in Major Employer Events :

- If there is an approved workforce reduction program in the MEE — Information Bulletin, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_rc#RFSallowed)

- If there is no approved workforce reduction program in the MEE — Information Bulletin, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_rc#ressigntol2) 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/vl_wr_rc/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Select Due to an approved workforce reduction program .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In FTS, determine if there is a D11 on file because this RFS adjudication was previously deferred:

- If yes, go to step 5.

- If no, go to step 7.

- Determine if the D11 is solely due to this previously deferred RFS issue and no other issues must be adjudicated:

- If no other issues must be adjudicated, go to step 6.

- If other issues must be adjudicated, go to the appropriate task for guidance. Then go to step 6.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F – Non-fraud - Othe .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In RCM, determine if the ROE is on file:

- If no, go to step 8.

- If yes, in RCM, update the Special condition field and go to step 8.

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/vl_wr_rc/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “voluntary leaving — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Contact an authorized user (team leader or business expertise advisor) to delete the ADJ WI. 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/vl_wr_rc/non-contentious_reason_for_separation_rfs_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The reason for separation is not voluntary leaving .

- Select Continue .

- Complete the Not voluntary leaving screen as follows:

- Select the appropriate RFS.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In RCM, determine if the ROE is on file:

- If yes, go to step 5.

- If no, go to step 7.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select the appropriate RFS option and sub-option, if necessary.

- Select Validate .

- Select Submit .

- Determine if the ROE was flagged in error after validation:

- If yes, fix the validation error and go to step 7.

- If no, go to step 7.

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/vl_wr_rc/decision_already_on_file_level_1.dita`

- Determine if the applicable decision is listed:

- If yes, on the list, select the applicable ROD and select Save . Go to step 5.

- If no, select Decision not in the list .

- Select Continue .

- Select the applicable Special condition option based on the decision on file and Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/vl_wr_rc/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “client quit [his/her] job and [provide a brief reason for the referral (e.g.no approved workforce reduction information is available)] — unable to complete at Level 1.”

- Select OK .

- When the Warning window is displayed, select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_4935.dita`

Note:

If the employer is from the West and Territories region, contact the Liaison Enquiry Team instead of the Business Expertise Advisor. Refer to W-T Region Workforce Reduction Procedures .
       [W-T Region Workforce Reduction Procedures](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/wfr.shtml)

     [W-T Region Workforce Reduction Procedures](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/wfr.shtml) 

## Policy reference

Source topic: `en_EN/task/vl_wr_rc/policy_reference.dita`

- Digest 6.7.0 — Workforce Reduction
         [Digest 6.7.0 — Workforce Reduction](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/workforce-reduction.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- EIR 51
         [EIR 51](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html) 
