# Completing a Claim Set-Up Registration WI: Possible duplicate application — Level 1

Source map: `en_EN/task/completing_claim_regwi_l1/completing_claim_regwi_l1.ditamap`

## Summary

Source topic: `en_EN/task/completing_claim_regwi_l1/summary.dita`

Summary: A Claim Set-Up (CS) Registration WI is reassigned to Level 1 for review when there is a possible duplicate application. 

## What you need to know

Source topic: `en_EN/task/completing_claim_regwi_l1/what_you_need_to_know.dita`

### Actioning a Claim Set-Up (CS) WI

Source topic: `en_EN/task/completing_claim_regwi_l1/actioning_a_claim_set-up_cs_wi.dita`

ACP cannot register a new application when there is an outstanding initial or renewal registration. There can be no more than one outstanding initial or renewal registration number on a claim. When there is a possible duplicate application, the Non-complex officer reviews both applications to determine if all the information provided by the client is the same on both applications. If it is not, an initial registration number is outstanding and the discrepancy is not a new period of employment in the qualifying period (QP) or the benefit period (BP) with a contentious reason for separation (RFS) or a newly declared training, teaching, farming, or self-employment (SE) issue, the Non-complex officer reassigns the CS WI to Level 1 for completion. The Level 1 determines if another registration number is required. If all the information provided by the client is not the same on both applications and a renewal registration number is outstanding or if the initial claim has already been established, the Non-complex officer reassigns the WI to Level 1.

A CS Registration WI can also be created when a client completes another application after the initial claim is Finalized LREM but the BPNE 2 ( 22 - Last Record of Employment missing manual action [MA22]) claim is on the Summary tab in FTS. In this case, the Unresolved claim on EN05 Manual Action not acceptable for automation message is displayed on the Processing Activities tab and ACP creates a CS Registration WI.

The Non-complex officer reassigns the CS WI to Level 1 to determine if it is a duplicate application. The Level 1 officer reviews the new application to determine if the client has worked since the initial application. If the client has not worked since the initial application, the officer determines if the last ROE is now on file and if ACP registered the ROE for recalculation.

The officer completes the CS WI and no further action is required if:

- the last ROE is not on file;

- a ROE: INS3166 Request for missing ROE — Form has been completed for the missing ROE;

- an interim ROE must be created;

- there is an outstanding recalculation registration for the BPNE 2 claim.

If the last ROE is on file and there is no outstanding recalculation registration for the BPNE 2 claim, the officer obtains a recalculation registration number. If the client has worked since the initial application, the Level1 officer determines whether the client wants to establish the BPNE 2 claim or a new initial claim. 

### Duplicate applications

Source topic: `en_EN/task/completing_claim_regwi_l1/duplicate_applications.dita`

Most cases of duplicate applications occur when the client tries to complete a claimant’s report with IRS and instead completes another application in error or an error is made in the application and a second one is submitted. The Level 1 officer determines if fact-finding is required to clarify the differences in the 2 applications. Some differences could impact the calculation of the claim, but an additional registration number is not required in all cases. The Level 1 officer determines if the initial claim was established and, if so, takes action to recalculate or review the claim, if necessary. When the recalculation or the revision is not within the officer’s authority, the Level 1 officer assigns the appropriate registration number and the related WI is assigned to the next available user. When the initial claim has not been calculated, the Level 1 officer determines if a Claim Assessment (CA) WI or a Specialized Application (SA) WI has been created or if the claim is in the ACP wait process. If there is an outstanding CA WI or SA WI, the Level 1 officer completes the CS WI. If the claim is in the ACP wait process, the Level 1 officer follows the instructions in the Step by step section to determine the actions to take on the file.

The client could also be trying to renew the claim or convert the benefit type (BT). In these cases, another registration number may be required. The registration will need to be made once the outstanding initial or renewal registration no longer appears on the FTS Outstanding Registrations tab. When the client submitted a renewal application to reactivate an established claim for a different BT than the one previously claimed, the Level 1 officer determines if there is an outstanding Action Item (AI) WI or a Claim Review (CR) WI related to the conversion request. If yes, the Level 1 officer completes the CS WI. If no, The Level 1 officer obtains a renewal registration number in FTS. 

### Obtaining the missing information

Source topic: `en_EN/task/completing_claim_regwi_l1/obtaining_the_missing_information.dita`

An officer can impose an indefinite 15 - Claim Procedure disentitlement (D15) depending on the claim status (CS) when a possible duplicate application has been received, the client is not reached and fact-finding is required to clarify the information contained in both applications.

The officer imposes a D15, effective from one of the following:

- the BPC week when the initial claim is not already established;

- the Monday of the next report to be received displayed in FTS when the initial claim is already established.

When the officer processes a CA WI (for an initial, extended initial or subsequent claim), an SA WI or a CR Recalculation WI and must impose a D15, the Level 1 officer sends an ACS letter to inform the client of the disentitlement and to advise the client to submit the missing information as soon as possible. When the claim is in the ACP wait process or the CA WI or SA WI is not within the officer’s authority, the officer creates and saves the ACS letter and creates a client Note . 

### Levels of decision

Source topic: `en_EN/task/completing_claim_regwi_l1/levels_of_decision.dita`

If the client does not respond to the requests to provide additional information regarding the application, it is considered as a failure to report for an interview. The National Policy on Levels of Decision specifies that a Level 1 officer can rescind a D15 when the requested information is provided within 6 weeks of the date the D-01-00-00 letter was sent. For additional information, the Level 1 officer refers to Reviewing a D15 disentitlement — Failure to report for a telephone interview .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
       [Reviewing a D15 disentitlement — Failure to report for a telephone interview](/en/procedure/task/claim_procedure_ftr_telehone_review_d15.shtml) 

### Fraud Indicators

Source topic: `en_EN/task/completing_claim_regwi_l1/fraud_indicators.dita`

Before a claim is registered, the officer determines if the application is already under investigation for potential fraud. The officer can determine that there is an ongoing Integrity investigation for this application if:

- a 71 - Integrity Services case manual action (MA71) or 71 - Integrity Services case disentitlement (D71) is imposed;

- an SROC created by Integrity is on file;

- an AI WI is assigned to Integrity;

- a Call Back (CB) WI is assigned to Integrity.

If none of these are on the file, the officer reviews the file to determine if fraud indicators are present. If yes, the officer:

- determines if the banking information has been changed in FTS and if so, terminates the direct deposit;

- imposes a D71 on skeleton and BPNE 1, 2 or 7 claims or an MA71 on established claims when required;

- completes the registration number to suspend the initial application process to prevent the claim from establishing until an investigation is completed;

- refers the issue to Integrity for investigation.

- completes the CS WI.

For more information, the officer refers to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims —Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims —Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### New application without fraud indicators — 71 - Integrity Services case manual action (MA71) on file

Source topic: `en_EN/task/completing_claim_regwi_l1/new_application_without_fraud_indicator_82f0e5e9.dita`

If an application with no fraud indicators is received and an MA71 is on file for a previous application identified as potentially fraudulent, the officer continues to follow the procedure to register the new application. 

### Fraudulent application received on a continuing claim

Source topic: `en_EN/task/completing_claim_regwi_l1/fraudulent_application_received_on_a_co_7ee5f16f.dita`

If a fraudulent application is received on a continuing claim, the officer determines if the initial claim in FTS is legitimate. The officer then verifies in FTS if the client’s address and direct deposit information has been changed on the legitimate continuing claim:

- If yes, the officer considers the claim as compromised and imposes an MA71.

- If no, the officer considers the claim as not compromised. No MA71 is required and the officer sends an AI WI to Integrity for investigation. This ensures that the MA71 does not penalize the true SIN holder on the legitimate claim, since the claim has not been compromised. 

## Regional considerations

Source topic: `en_EN/task/completing_claim_regwi_l1/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/completing_claim_regwi_l1/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/completing_claim_regwi_l1/in_nws.dita`

- What is the last day worked on the application?

- When was the application received?

- Is there an initial or renewal claim in progress?

- Is there an ROE Recalculation claim event?

- Is the Unresolved claim on EN05 Manual Action code is not acceptable for automation message displayed on the Processing Activities tab?

- Is the claim in the ACP wait process? 

### In FTS:

Source topic: `en_EN/task/completing_claim_regwi_l1/in_fts.dita`

- Is the initial claim established?

- Is there an outstanding initial or renewal registration number?

- Is there a BPNE 2 (MA22) claim on the Summary tab?

- Is there a BPNE 1, a BPNE 5 or a BPNE 7 claim on the Summary tab?

- Is there a previous claim on the Dormant tab that is still renewable?

- What is the last renewable week on the Summary tab?

- Is the Failure to report box checked? 

## Step by step

Source topic: `en_EN/task/completing_claim_regwi_l1/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/completing_claim_regwi_l1/level_1.dita`

#### Reviewing the file for fraud indicators

Source topic: `en_EN/task/completing_claim_regwi_l1/reviewing_the_file_for_fraud_indicators_level_1.dita`

- In NWS, determine if there is documentation indicating that the application for which the CS WI was created is under investigation for potential fraud:

- If no, go to step 2.

- If yes, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_claim_regwi_l1#level1_item_7)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2643.dita)

- Determine if known fraud indicators are present and if fraud is suspected by referring to Fraud indicators: Identifying potentially fraudulent claims — Knowledge and reviewing the file:

- If yes, go to step 3.

- If no, go to step 4.

- In FTS, determine if the banking information has been changed to the banking information on the potentially fraudulent application:

- If no, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_claim_regwi_l1#level1_item_7)

- If yes, terminate the banking information by referring to Ending a direct deposit and go to Fraud indicators are present .
               [Ending a direct deposit](/en/procedure/task/ending_dd.shtml) 
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_claim_regwi_l1#level1_item_7) 

#### Determining if this is a duplicate application

Source topic: `en_EN/task/completing_claim_regwi_l1/determining_if_this_is_a_duplicate_application_level_1.dita`

- In FTS, select Direct Deposit and compare the information on the system to the direct deposit information on the application:

- If the direct deposit information on the system is correct, go to step 5.

- If the direct deposit information on the system is incorrect, refer to Direct Deposit for guidance if necessary and go to step 5.
               [Direct Deposit](/en/procedure/activity/direct_deposit.shtml)

- In NWS, determine if the Unresolved claim on EN05 Manual Action code is not acceptable for automation message is displayed on the Processing Activities tab:

- If yes, go to step 6.

- If no, go to step 14.

- In FTS, determine if there is a BPNE 2 claim on the Summary tab:

- If yes, go to step 7.

- If no, go to step 14.

- Determine if the client has worked since the initial application:

- If yes, go to step 8.

- If no, go to Duplicate application .
               [Duplicate application](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_claim_regwi_l1#level1_item_4)

- Fact-find with the client to determine if the client wants to establish the BPNE 2 claim.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2644.dita)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 10.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Unable to reach the client .
               [Unable to reach the client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_claim_regwi_l1#level1_item_3)

- Determine if the client wants to establish a new claim:

- If the client wants to establish a new claim, go to step 11.

- If the client wants to establish the BPNE 2 claim, go to Not a duplicate application .
               [Not a duplicate application](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_claim_regwi_l1#level1_item_5)

- In FTS, select the File Control Date (M101)/Claim Action transaction and move the BPNE 2 claim to the Dormant tab as follows:

- Select Terminate benefit period (M101-7) .

- Select Update .

- In NWS, move the CS Registration WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for BPNE 2 claim to move to Dormant tab.”

- Bring forward date: Enter today’s date + 2 business days.

- When the BPNE 2 claim moves to the Dormant tab in FTS, go to Not a duplicate application .

- In NWS, review the 2 applications and determine if they are identical or if they contain differences:

- If both applications contain different information, go to step 15.

- If both applications are identical, go to step 23.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2645.dita)

- Review both applications and determine if the only difference is the last day worked (LDW) for the last employer:

- If yes, go to step 16.

- If no, go to step 18.

- Determine if the initial claim has been calculated:

- If yes, go to step 17.

- If no, go to step 18.

- Determine if the LDW on the second application is before or equal to the BPC week, or if it matches the ROE:

- If no, go to step 18.

- If yes, go to step 23.

- Determine if fact-finding is required to clarify the differences in both applications:

- If yes, go to step 19.

- If no, go to step 22.

- Fact-find with the client to clarify the differences and any discrepancies in the information provided on the applications.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 21.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Unable to reach the client .
               [Unable to reach the client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_claim_regwi_l1#level1_item_3)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Issue: Select Other .

- Comments: Type “Application clarification.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the application is a duplicate application submitted in error or an application to add or change information provided in the first application (e.g. BT, pension or workforce history):

- If yes, go to Duplicate application .
               [Duplicate application](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_claim_regwi_l1#level1_item_4)

- If no, go to Not a duplicate application .
               [Not a duplicate application](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_claim_regwi_l1#level1_item_5)

- In NWS, complete the CS WI. 

#### Unable to reach the client

Source topic: `en_EN/task/completing_claim_regwi_l1/unable_to_reach_the_client_level_1.dita`

- In FTS, determine if there is a BPNE 2 claim on the Summary tab:

- If no, go to step 2.

- If yes, go to step 16.

- Determine if the initial claim has been registered:

- If no, go to step 3.

- If yes, go to step 7.

- Determine if there is an outstanding CS WI related to the initial claim registration:

- If yes, go to step 4.

- If no and there is not an outstanding initial or renewal registration number or 2 outstanding registration numbers, go to step 10.

- If no and there is an outstanding initial or renewal registration number or 2 outstanding registration numbers, go to step 16.

- In NWS, determine the status of the outstanding CS WI:

- If it is assigned to another officer, go to step 5.

- If it is unassigned, go to step 6.

- If it is assigned to you, go to step 7.

- Determine in which workload the outstanding CS WI is:

- If it is in the pending workload, go to step 6.

- If it is in the current workload, contact the officer to request the WI be reassigned to you. Go to step 7.

- In NWS, open the CS WI and reassign it to yourself as follows:

- Destination: Select Myself .

- Reason: Select Other .

- Details: Type “Related WI.”

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2646.dita)

- Determine if the calculation of the initial claim has been finalized:

- If no, go to step 8.

- If yes, go to step 12.

- In NWS, determine if a CA WI has been created:

- If yes, go to step 9.

- If no, go to step 10.

- Determine if the due date of the CA WI or SA WI has been reached:

- If yes and the CA WI or SA WI is within your authority, refer to Calculation of a claim — Index and follow the appropriate task to calculate the claim. Go to step 13.
               [Calculation of a claim — Index](/en/procedure/generic/additionalresources/index_calc_claim.shtml)

- If yes and the CA WI or SA WI is not within your authority, go to step 13.

- If no, move the CA WI or SA WI to Pending until the due date is reached. Go to step 13.

- In NWS, move the CS WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Verify if the calculation has been automated or if the CA WI has been created.”

- Bring forward date: Select the appropriate option:

- If the date of application + 28 days has not been reached, enter the date of application + 28 days. Go to step 11.

- If the outstanding initial registration number does not have a WI in Pending and the application was filed more than 28 days ago, go to step 13.

- When the CS WI moves back to the current workload, in FTS, determine if the calculation of the initial claim has been finalized:

- If yes and the claim is established, go to step 14.

- If yes and the claim is BPNE 1, BPNE 2, BPNE 5 or BPNE 7, go to step 16.

- If no and a CA WI or SA WI has been created, return to step 9.

- If no and no CA WI or SA WI has been created, return to step 10.

- Determine which of the following situations applies:

- If the claim is established and there is no outstanding renewal registration number, go to step 14.

- If the claim is established and there is an outstanding renewal registration number, go to step 15.

- If the claim is BPNE 1, BPNE 2, BPNE 5 or BPNE 7, go to step 16.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose the D15 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select - Add .

- Disentitlement: Select 15 - Claim procedure .

- BPC date: Check the box.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- If the initial claim is in the ACP wait process or to leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Go to step 17.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Select Update .

- Select the Disqualifications/Disentitlements (M161) transaction and impose the D15 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select - Add .

- Disentitlement: Select 15 - Claim procedure .

- Start date: Enter the Monday of the next report to be received displayed in FTS.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Go to step 17.

- In NWS, create a new SROC as follows:

- BPC: Select the appropriate BPC.

- Main Issue: Select Status of claim .

- Comments: Type “Application not registered.”

- Details: Type “The client’s application submitted on [DD-MM-YYYY] was not registered because the client could not be reached.”

- Select Save .

- Go to step 22.

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “Failure to provide entitlement information.”

- Details: Type “No return call from the client. 15 - Claim Procedure disentitlement imposed for failure to provide entitlement information. Information missing."

- Select Save .

- Determine which of the following situations applies to the client:

- If the initial claim is in the ACP wait process, go to step 19.

- If there is a CA WI or a SA WI and it is not within your authority, go to step 19.

- If there is CA WI or SA WI and it is within your authority, go to step 21.

- If the claim has already been established, go to step 21.

- In ACS, create and save a D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976)

- D48 and D15 — Moved — Adress unknown and claim procedure (3006)

- D15 - Claim procedure (3009): Select D15 - Text: Insert appropriate reason for D15 .

- We / In addition, we (2687)

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- Indefinite disentitlement start date (1270)

- Text - Insert appropriate reason(s) (1618): Type the appropriate reason:

- “You have not returned our calls following messages left on [DD-MM-YYYY] and [DD-MM-YYYY].”

- “You have not contacted us following the letter sent to you on [DD-MM-YYYY].”

- Overpayment Messages (2452): Select Blank .

- In NWS, create a client Note and type “Determine if the D15 disentitlement still applies and rescind it if necessary. Send D-01-00-00 letter if required.” Go to step 22.

- In ACS, create and send the D-01-00-01 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976)

- D48 and D15 — Moved — Adress unknown and claim procedure (3006)

- D15 - Claim procedure (3009): Select D15 - Text: Insert appropriate reason for D15 .

- We / In addition, we (2687)

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- Indefinite disentitlement start date (1270)

- Text - Insert appropriate reason(s) (1618) Type the appropriate reason:

- “You have not returned our calls following messages left on [DD-MM-YYYY] and [DD-MM-YYYY].”¸

- “You have not contacted us following the letter sent to you on [DD-MM-YYYY].”

- Overpayment Messages (2452): Select Blank .

- In NWS, complete the CS WI. 

#### Duplicate application

Source topic: `en_EN/task/completing_claim_regwi_l1/duplicate_application_level_1.dita`

- In FTS, determine if there is a BPNE 2 claim on the Summary tab:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the last ROE for the BPNE 2 claim is now on file or if there is an INS3166 for the missing ROE:

- If the last ROE for the BPNE 2 claim is now on file, go to step 3.

- If there is an INS3166 for the missing ROE and an interim ROE must be created, go to step 40.

- If none of the above applies, go to step 40.

- Determine if ACP registered the ROE for recalculation (there will be an ROE Recalculation claim event in the Client information tree):

- If no, go to step 21.

- If yes, go to step 40.

- Determine if the initial claim has been calculated:

- If no, go to step 5.

- If yes, go to step 12.

- In NWS, determine if a CA WI or SA WI has been created:

- If no, go to step 6.

- If yes, go to step 40.

- Refer to Calculation: Removal from the ACP wait process — Instructions to determine if the required conditions are met to interrupt the ACP wait process:

- If no go to step 7.

- If yes, create the Reminder (REM) WI as indicated in that task and go to step 40.

- Determine which of the following situations applies to the client:

- If only an allocation not related to the ROE must be modified (the type of payment to be allocated is mentioned in both applications but the information is different), go to step 8.

- If only a new allocation not related to the ROE must be entered (the amount to be allocated is mentioned in the duplicate application but not in the first application), go to step 11.

- If the only difference between both applications is related to monies to be allocated already mentioned on the ROE, go to step 40.

- If none of the above situations apply, go to step 8.

- In NWS, move the CS WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Verify if the calculation has been automated or if the CA WI has been created.”

- Bring forward date: Enter the date of application + 28 days. If the outstanding registration number does not have a WI in Pending and the application was filed more than 28 days ago, enter the date of application + 44 days.

- When the CS WI moves to the current workload, determine if the calculation of the initial claim has been finalized:

- If no, go to step 10.

- If yes, go to step 18.

- In NWS, determine if a CA WI has been created:

- If no, repeat step 8.

- If yes, go to step 40.

- Determine if the allocation is related to wage loss insurance (WLI) earnings:

- If yes, go to step 29.

- If no, go to step 31.

- In NWS, determine if there is an outstanding CR Recalculation WI for the same BPC:

- If yes, go to step 13.

- If no, go to step 17.

- Determine if recalculation is within your authority:

- If yes, go to step 14.

- If no and the CR Recalculation WI is not assigned to you, go to step 40.

- If no and the CR Recalculation WI is assigned to you, go to Reassigning the WI.
               [Reassigning the WI.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_claim_regwi_l1#level1_item_6)

- Determine the status of the outstanding CR Recalculation WI:

- If it is assigned to another officer, go to step 15.

- If it is unassigned, go to step 16.

- If it is assigned to you, continue with the Recalculation procedure.
               [Recalculation](/en/procedure/activity/recalculation.shtml)

- Determine if the outstanding WI is in the officer’s active or pending workload:

- If it is in the pending workload, go to step 16.

- If it is in the active workload, contact the officer to reassign the WI to your workload. Continue with the Recalculation procedure.
               [Recalculation](/en/procedure/activity/recalculation.shtml)

- Open the CR WI and reassign it to your workload as follows:

- Destination: Select Myself .

- Reason: Select Other .

- Details: Type “Related WI.”

- Continue with the Recalculation procedure.
               [Recalculation](/en/procedure/activity/recalculation.shtml)

- In RCM, determine if the information on the ROE has been changed as a result of fact-finding with the employer:

- If no, go to step 18.

- If yes, go to step 21.

- Determine if the information in the duplicate application could change the calculation result (e.g. extension of the QP or another employer in the QP):

- If no, go to step 19.

- If yes, go to step 21.

- Determine if a revised registration number is required to change the information in the calculated claim:

- If yes, go to step 20.

- If no, go to step 38.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Create Work Item : Check the box.

- Select Update .

- Go to step 25.

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 23.

- If no, go to step 24.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank, enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: This field is prefilled.

- Select Generate registration .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1570.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1571.dita)

- Determine if the recalculation or the revision is within your authority:

- If yes, go to step 26.

- If no, go to step 40.

- In NWS, open the newly created CR WI and reassign it to yourself as follows:

- Destination: Select Myself .

- Reason: Select Other .

- Details: Do one of the following:

- If a claim recalculation is required, type “Claim recalculation required.” then continue with the Recalculation procedure.
                   [Recalculation](/en/procedure/activity/recalculation.shtml)

- If a claim review is required, type “Claim review required.” then go to step 27.

- Determine if a new allocation must be entered or if an existing allocation must be modified:

- If yes, go to step 28.

- If no, go to step 39.

- Determine which of the following situations applies to the client:

- If the allocation is related to paid sick leave (PSL) or WLI earnings that have not been allocated, go to step 29.

- If the allocation is not related to PSL or WLI earnings and a new allocation must be entered, go to step 31.

- If an existing allocation must be modified, go to step 34.

- In FTS, on the Search — Employer screen, review the Employer Details — Premium Reduction Program to determine if any premium reduction plan information is available. Refer to Allocating incapacity monies , if necessary.

- Select the Renewal / Revised (M106) transaction and input the premium reduction code in the Supplementary claim information field based on the information indicated on the Premium Reduction Program tab on the Employer Details screen:

- If no information is displayed, enter 11 - No Premium Reduction .

- If Yes is displayed in the Wage Loss Insurance column only, select 12 - Premium Reduction WLI .

- If Yes is displayed in the Paid Sick Leave column only, select 13 - Premium Reduction PSL .

- If Yes is displayed in both Wage Loss Insurance and Paid Sick Leave columns, select 14 - Premium Reduction WLI and PSL .

- Select the Allocations (M175) transaction to input the allocation as follows:

- Registration number: Select the appropriate registration number.

- Type: Select the appropriate allocation type.

- Amount: Type the amount.

- Start date: Enter the start week of the allocation.

- End date: Enter the end week of the allocation.

- Last week amount: Enter the amount if the last week amount is different. If it is not, leave the field blank.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 8 - Your earnings were not deducted .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- If the initial claim is in the ACP wait process or to leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Determine if the initial claim is in the ACP wait process:

- If no, go to step 33.

- If yes, go to step 40.

- In ACS, create and send the D-20-16-03 letter. Based on the claim information, select all of the required attributes, including the following:

- Allocation of earnings (2516)

- Do not report monies already declared (2456)

- Overpayment Messages (2452)

- Go to step 36.

- In FTS, determine the corrections to make. Modify the allocation as follows:

- Select the Allocations link on the Summary tab.

- Select the appropriate allocation and select Modify .

- Registration number: Select the appropriate registration number.

- Action: Select Modify .

- Correct the information in the following boxes if needed:

- Amount

- Start date

- End date

- Last week amount

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 8 - Your earnings were not deducted .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- In ACS, send the D-20-16-03 letter. Based on the claim information, select all of the required attributes, including the following:

- Amending Allocation (2442)

- Do not report monies already declared (2456)

- Overpayment Messages (2452)

- Determine if the other monies were declared on the claimant’s report:

- If yes, go to step 37.

- If no, go to step 40.

- In FTS, determine if there are any rejected claimant’s reports on the Pending/Reject tab:

- If no, go to step 40.

- If yes, refer to Actioning a rejected claimant’s report to re-input the claimant’s reports. Go to step 40.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml)

- Determine if the differences between both applications require changes to the calculated claim (e.g. change to the tax deduction, change of address in the same economic region, change of direct deposit information):

- If yes, go to step 39.

- If no, go to step 40.

- In FTS, enter the transactions required to change the information in the calculated claim.

- In NWS, complete the CS WI. 

#### Not a duplicate application

Source topic: `en_EN/task/completing_claim_regwi_l1/not_a_duplicate_application_level_1.dita`

- Determine if the application must be moved to Pending until an outstanding registration number is completed (e.g. a conversion or renewal application after an outstanding initial or recalculation registration number is finalized):

- If the application must be moved to Pending, go to step 2.

- If the application does not need to be moved to Pending, go to step 4.

- In NWS, move the CS WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Unable to register application as outstanding registration number is not completed.”

- Bring forward date: Select the appropriate option:

- If the outstanding registration number has an unassigned WI, enter the due date of the unassigned WI. If the due date has been reached, enter today’s date + 10 business days.

- If the outstanding registration number has a WI in Pending, enter the bring-forward date of the WI in Pending.

- If the outstanding registration number does not have a WI in Pending and the outstanding registration number is for an application filed within the last 28 days, enter the date of application + 28 days.

- If the outstanding registration number does not have a WI in Pending and the application was filed more than 28 days ago, enter the date of application + 44 days.

- When the CS WI moves to the current workload, determine if the outstanding registration number is complete:

- If no, return to step 2.

- If yes, go to step 4.

- Determine which of the following situations applies:

- If an initial claim must be registered, go to step 5.

- If a renewal application must be registered, go to step 25.

- If no registration number is required (i.e. claim is BPNE 2 and the last ROE is still missing), go to step 28.

- In SSO, verify that the correct mainframe is selected and register the claim as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Initial .

- Select Search .

- Review the Name and Address screen.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2168.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2647.dita) 

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: Both fields are prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: Do the following:

- If the field is blank, enter the SCC shown on the WI History tab of the CS WI.

- For a commuter claim, enter the SCC associated with the workplace postal code.

- Tax credit: This field is prefilled based on the client’s information.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: If the field is blank, enter the SCC shown on the WI History tab of the CS WI (the same one input in the Responsible SCC field).

- Service unit: Type “01.”

- Tentative BPC: If the field is blank, determine the BPC based on the client’s LDW and application date. If the registration number being obtained is for a subsequent claim, select the week after the previous claim’s LRW.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select Yes to generate the Initial Intake (M149) transaction.

- Select Generate registration .
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2648.dita)

- Select Next .

- On the M149 - Initial Intake Data screen, select Update .

- In SSO, determine if an error message is displayed for the Intake Data (M149) screen:

- If yes, go to step 7.

- If no, go to step 28.

- In SSO, review the M149 - Initial Intake Data screen to determine the error code and select it to display its description.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2649.dita)

- Based on the error code description, determine if the current claim can be terminated online or if IPOC action is required:

- If IPOC action is required, go to step 9.

- If the claim can be terminated online, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2650.dita)

- Determine what IPOC action is required:

- To terminate an MPS claim, go to step 12.

- To clear overlapping weeks on the Pay History (MHQ1) screen, go to step 10.

- Determine if any of the overlapping weeks have been paid:

- If no, go to step 12.

- If yes, go to step 17.

- In SSO, correct the rejected M149 - Initial Intake Data transaction and update the BPC as follows:

- Tentative BPC: Enter the correct tentative BPC.

- Terminate previous claim: Check Yes .

- Select Update to transmit the information.

- Go to step 28.

- In NWS, create an IPOC Review (IPOC REV) WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate language.

- Destination — SCC: Select the SCC based on your regional IPOC:

- Atlantic: 1826

- Quebec: 2642

- Ontario: 3056

- Western Canada and Territories: 5903

- End User: Select Next available user .

- Issue: Select the appropriate issue:

- MPS - Claim termination request.

- Pay history summary adjustment.

- BPC: Enter the BPC of claim that must be terminated.

- Comments: Type “Claim termination to start a new claim — [error code].”

- Details: Type the appropriate option:

- To terminate an MPS claim, type “In order to start a new claim, please terminate the CS08 BPC [XXXX].”

- To modify the Pay History (MHQ1) screen, type “In order to start a new claim, please clear PHS for weeks [XXXX] and greater.”

- Obtained by: Select the appropriate method.

- Obtained from: Select the appropriate source.

- Source details: Enter the source details.

- Select Save .

- In NWS, move the CS WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Request to [remove MPS claim/clear PHS] sent to IPOC.”

- Bring forward date: Enter today’s date + 2 days.

- When the CS WI moves to the current workload, determine if IPOC has completed the requested action:

- If no, repeat step 13.

- If yes, go to step 15.

- Ensure that the SIN is not open in SSO.

- In FTS, select the Initial Intake (M149) transaction to update the BPC as follows:

- Tentative BPC: Enter the correct tentative BPC.

- Select Update .

- Go to step 28.

- In FTS, determine if there is a revised registration number for the issue:

- If there is a registration number, go to step 18.

- If there is no registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction to automatically generate an Operational Centre Memo (MM06) as follows:

- Registration number: Select the revised registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - No .

- Complete: Select D - No .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim that needs to be terminated.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 35 - Claim Cancellation .

- Remarks Line 1: Type “In order to start a new claim, please clear PHS for weeks XXXX and greater.

- Remarks Line 2: Type “[your name and telephone number].”

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 97 - Internal Adjustment .

- Contentious: Select 2 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction to transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, move the CS WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Request to clear PHS sent to IPOC.”

- Bring forward date: Enter today’s date + 7 days.

- When the CS WI moves to the current workload, determine if the overlapping weeks have been cleared from the Pay History (MHQ1) screen:

- If no, repeat step 21.

- If yes, go to step 23.

- Ensure that the SIN is not open in SSO.

- In FTS, select the Initial Intake (M149) transaction to update the BPC as follows:

- Tentative BPC: Enter the correct tentative BPC.

- Select Update .

- Go to step 28.

- Determine if the client submitted a renewal application to reactivate an established claim for a different BT than the one previously claimed:

- If yes, go to step 26.

- If no, go to step 27.

- Determine if there is an outstanding AI WI or a CR WI related to the conversion request:

- If no, go to step 27.

- If yes, go step 28.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- In NWS, complete the CS WI. 

#### Reassigning the WI

Source topic: `en_EN/task/completing_claim_regwi_l1/reassigning_the_wi_level_1.dita`

- In NWS, reassign the CR Recalculation WI to the next available user as follows:

- Destination: Select Next available user .

- Complexity: Select Level 1 .

- Reason: Select Unable to complete .

- Details: Type “Not within officer’s authority.”

- Complete the CS WI. 

#### Fraud indicators are present

Source topic: `en_EN/task/completing_claim_regwi_l1/fraud_indicators_are_present_level_1.dita`

- In NWS, determine if any of the following WIs are on file and directly related to the potentially fraudulent application for which a CS WI has been created:

- a CR Integrity ERB-EI Transition WI;

- an AI WI from Integrity indicating that the claim can be established;

- a CB WI;

- an SROC with the following indicated in the Comments field: “Decision made by the specialized team."

- a ROD confirming that the EI application was submitted by a third party.

- If no, go to step 2.

- If yes, go to step 12.

- Determine if any of the following are on file and directly related to the potentially fraudulent application for which a CS WI has been created:

- an Integrity AI WI;

- an Integrity SROC;

- a D71 or an MA71;

- in RMDS, on the Employer profile screen, the Under investigation box is checked .

- If no, go to step 3.

- If yes, go to step 12.

- In FTS, determine if the claim is established:

- If yes, go to step 4.

- If no, go to step 7.

- Determine if the client’s continuing claim has been compromised:

- If yes, go to step 5.

- If no, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2651.dita)

- Determine if an MA71 is already imposed:

- If no, go to step 6.

- If yes, go to step 10.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave the field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 7.

- In NWS, determine if a suspected fraud has previously been referred to Integrity in an AI WI that has not been completed:

- If yes, go to step 8.

- If no, go to step 9.

- Add the information related to the potentially fraudulent application to the existing Integrity AI WI as follows:

- Right-click and select Add details/Further inquiry .

- Action: Select Additional Information .

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- If it is a renewal application, go to step 10.

- If it is an initial application, go to step 12.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the processing unit in the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue: Select SIR validation .

- Comments: Type “Fraud suspected — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- If it is a renewal application, go to step 10.

- If it is an initial application, go to step 12.

- Determine if there is an outstanding registration number related to the fraudulent renewal application:

- If yes, go to step 11.

- If no, go to step 12.

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the registration number related to the fraudulent renewal application as follows:

- Action: Select Cancel .

- Select Update .

- No further action is required.

- In NWS, complete the CS WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2643.dita`

Note:

If the fraud warning is in FTS to highlight in red the SIN field on the tombstone data and to show a red warning symbol, or if an MA71 is on file for a previous application with fraud indicators, go to step 2. 

#### Note

Source topic: `en_EN/common_notes/note_c_2644.dita`

Note:

It may be necessary to review the differences between the 2 applications. Notify the client that an officer may call again if there are differences that need to be discussed. 

#### Note

Source topic: `en_EN/common_notes/note_c_2645.dita`

Note:

Both applications must be thoroughly reviewed, question by question, to identify the differences. 

#### Note

Source topic: `en_EN/common_notes/note_c_2646.dita`

Note:

ACP cannot register a new application when there is an outstanding initial or renewal registration. There can be no more than one outstanding initial or renewal registration number on a claim and no more than 2 outstanding registration numbers. If there is an outstanding initial or renewal registration number or 2 outstanding registration numbers, go to step 16. If not, register the claim and go to step 9. 

#### Note

Source topic: `en_EN/common_notes/note_c_1570.dita`

Note:

There cannot be more than 2 outstanding registration numbers. If there are already 2 outstanding registration numbers, advise the team leader that multiple registration numbers are preventing a new one from being created. 

#### Note

Source topic: `en_EN/common_notes/note_c_1571.dita`

Note:

When the message Success — Registration number created is displayed in SSO, a recalculation registration number is assigned to the claim. NWS creates a CR WI and assigns it to the unassigned (UNA) workload or to the next available user. 

#### Note

Source topic: `en_EN/common_notes/note_c_2168.dita`

Note:

The information from the application in NWS is automatically downloaded in SSO. In rare cases, the information is not downloaded and must be manually input. Verify (and correct, if necessary) any prefilled fields with the information provided on the application. 

#### Note

Source topic: `en_EN/common_notes/note_c_2647.dita`

Note:

When the client has only one name, one of the name fields on the Name and Address screen may be empty or contain a non-alphabetical character. However, SSO does not allow the field to be completed in this way.

When a name field is empty or contains a non-alphabetical character, do the following:

- First Name: Enter the appropriate option:

- For a client who selects the Male gender marker, type “Mr.”

- For a client who selects the Female gender marker, type “Ms.”

- For a client who selects X as the gender marker, type “N.A.”

- Last Name: Enter the client’s name.

When the First Name field on the Name and Address screen is modified to “N.A.”, modify the Initial Intake (M149) or Name and Address Change / Transfer (M159) transaction generated by the calculation and type “.” in the First Name field before transmitting it. 

#### Note

Source topic: `en_EN/common_notes/note_c_2648.dita`

Note:

At this step, a registration number is assigned to the claim. If Yes is selected, the Initial Intake (M149) transaction is automatically generated.

If No is selected, the Initial Intake (M149) transaction is not generated. 

#### Note

Source topic: `en_EN/common_notes/note_c_2649.dita`

Note:

In most cases, the error code received is error 230, indicating that there is an active claim on the system. If the error is not 230, follow the instructions provided in WECS. 

#### Note

Source topic: `en_EN/common_notes/note_c_2650.dita`

Note:

For more information on terminating a claim, refer to Terminating a benefit period .
       [Terminating a benefit period](/en/procedure/task/benefit_period_term.shtml)

     [Terminating a benefit period](/en/procedure/task/benefit_period_term.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2651.dita`

Note:

A claim is considered to be compromised when the client’s information (address or direct deposit information) has been changed. If the claim is compromised, impose an MA71. 

## Policy reference

Source topic: `en_EN/task/completing_claim_regwi_l1/policy_reference.dita`

 
