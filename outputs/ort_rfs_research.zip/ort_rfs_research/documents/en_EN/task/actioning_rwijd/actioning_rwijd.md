# Actioning a Reminder WI for jury duty

Source map: `en_EN/task/actioning_rwijd/actioning_rwijd.ditamap`

## Summary

Source topic: `en_EN/task/actioning_rwijd/summary.dita`

Summary: If a disentitlement related to availability or capability is terminated because the client is engaged in jury duty, the agent must follow up and reinstate the disentitlement when the jury duty ends. 

## What you need to know

Source topic: `en_EN/task/actioning_rwijd/what_you_need_to_know.dita`

### Entitlement to benefits while on jury duty

Source topic: `en_EN/task/actioning_rwijd/entitlement_to_benefits_while_on_jury_duty.dita`

A disentitlement related to availability or capability is suspended during the period in which the client is engaged in jury duty. When the disentitlement is terminated, the agent creates a Reminder (REM) WI for follow up to ensure the disentitlement is reinstated appropriately once the jury duty has ended.

The following disentitlements are suspended during a period of jury duty:

```text
| Disentitlement | Definition |

| 2 | Minor attached, reason for separation illness |

| 3 | Not available |

| 4 | Failure to prove unable to obtain suitable employment |

| 16 | No medical certificate submitted |

| 22 | Illness (maximum sickness / special benefits paid) |

| 24 | Failure to actively seek employment |

| 25 | Maternity benefits - Minor attached |

| 27 | Maternity benefits (maximum special benefits paid) or outside range |

| 33 | Incapacity proven but not otherwise available |

| 34 | Parental benefits entitlement conditions not met |

| 36 | Maternity not eligible - 15 weeks paid per pregnancy |
``` 

### Converting a claim back to special benefits

Source topic: `en_EN/task/actioning_rwijd/converting_a_claim_back_to_special_benefits.dita`

Claims for special benefits are converted to regular benefits to allow payment when a D2, D22, D25, D27 or D36 disentitlement is suspended during jury duty. When any other availability or capability disentitlement is suspended during jury duty, a claim for special benefits is converted to regular benefits only if the jury duty lasts for one full week or longer.

Depending on the client’s circumstances when the jury duty ends, the claim may need to be converted back to special benefits. 

### Client not contacted

Source topic: `en_EN/task/actioning_rwijd/client_not_contacted.dita`

When the client cannot be contacted to determine continuing entitlement to benefits, the agent reinstates the disentitlement that was suspended during jury duty. The agent does not convert a claim back to special benefits until entitlement to a specific benefit type is determined. 

## Regional considerations

Source topic: `en_EN/task/actioning_rwijd/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actioning_rwijd/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/actioning_rwijd/in_fts.dita`

- What is the benefit type?

- What type of disentitlement was terminated for the period of jury duty?

- Does the jury duty period overlap the disentitlement dates?

- Is there an outstanding registration number for the jury duty issue? 

### In NWS:

Source topic: `en_EN/task/actioning_rwijd/in_nws.dita`

- What is the jury duty end date?

- Does the jury duty period overlap the disentitlement dates? 

## Step by step

Source topic: `en_EN/task/actioning_rwijd/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/actioning_rwijd/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_rwijd/reviewing_the_file_level_1.dita`

- In NWS, determine if the client has provided the jury duty end date:

- If no, go to step 2.

- If yes, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/actioning_rwijd/fact-finding_level_1.dita`

- Fact-find with the client.

- Determine if the client was contacted during fact-finding:

- If yes, go to step 4.

- If no, go to Unable to contact the client — Disentitlement reinstated .
               [Unable to contact the client — Disentitlement reinstated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_rwijd#clincon)

- Add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Availability .

- Comments: Type “Jury duty.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save . 

#### Reviewing the jury duty period

Source topic: `en_EN/task/actioning_rwijd/reviewing_the_jury_duty_period_level_1.dita`

- Determine if the jury duty has ended:

- If the jury duty is continuing, go to step 6.

- If jury duty has ended, go to step 8.

- Move the REM WI to pending as follows:

- Pending reason: Select Other .

- Comments: Type “Follow up on jury duty end date is required.”

- Bring forward date: Enter the current date + 5 business days.

- When the WI moves to the current workload, return to step 1.

- Determine the original disentitlement end date and do one of the following:

- If the jury duty end date is before the original disentitlement end date or if the original disentitlement end date is indefinite, the disentitlement must be reinstated. Go to step 9.

- If the jury duty end date is after the original disentitlement end date, the disentitlement is not reinstated. Go to step 12. 

#### Jury duty end date is in the disentitlement period — Disentitlement reinstated

Source topic: `en_EN/task/actioning_rwijd/jury_duty_end_date_is_in_the_disentitle_661fd467_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Jury duty ended — disentitlement reinstated.”

- Details: Type “The client was entitled to benefits during jury duty. The disentitlement is reinstated as of [date] because jury duty has ended.”

- In FTS, determine if there is an outstanding registration number for the jury duty issue:

- If yes, go to step 11.

- If no, in FTS, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and reinstate the original disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select the code of the original disentitlement.

- Start date: Enter the first weekday after the jury duty.

- End date: Do one of the following:

- If the original disentitlement was definite, enter the original end date.

- If the original disentitlement was indefinite, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Click Update .

- Determine if the disentitlement is one of the following:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1582.dita) 

- If it is not one of the above disentitlements, go to step 13.

- If it is one of the above disentitlements, refer to Conversion and Renewal , if required, to change the claim type back to special benefits.
               [Conversion and Renewal](/en/procedure/activity/conversions.shtml)

- In NWS, complete the REM WI. 

#### Jury duty end date is after the disentitlement period — Disentitlement not reinstated

Source topic: `en_EN/task/actioning_rwijd/jury_duty_end_date_is_after_the_disenti_a66548db_level_1.dita`

- Determine if the disentitlement is one of the following:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1582.dita) 

- If it is not one of the above disentitlements, go to step 2.

- If it is one of the above disentitlements, refer to Conversion and Renewal , if required, to change the claim type back to special benefits.
               [Conversion and Renewal](/en/procedure/activity/conversions.shtml)

- In NWS, complete the REM WI. 

#### Unable to contact the client — Disentitlement reinstated

Source topic: `en_EN/task/actioning_rwijd/unable_to_contact_the_client__disentitl_6265d4ff_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Client not contacted — Disentitlement reinstated.”

- Details: Type “The client has not responded to our request for information. It cannot be determined if the client is still engaged in jury duty. Therefore, continuing entitlement to benefits is not proven.”

- Determine if there is an outstanding registration number for the jury duty issue:

- If yes, go to step 3.

- If no, in FTS, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and reinstate the original disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select the code for the original disentitlement.

- Start date: Enter the Monday of the next payable week.

- End date: Enter the end date of the original disentitlement.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Click Update .

- In NWS, complete the REM WI. 

#### Callout

Source topic: `en_EN/common_notes/note_c_1582.dita`

- 2 - Minor attached, reason for separation illness

- 16 - No medical certificate submitted

- 22 - Illness (maximum sickness/special benefits paid)

- 25 - Maternity benefits - Minor attached

- 27 - Maternity benefits (maximum special benefits paid) or outside range

- 33 - Incapacity proven but not otherwise available

- 34 - Parental benefits entitlement conditions not met

- 36 - Maternity not eligible - 15 weeks paid per pregnancy 

## Policy reference

Source topic: `en_EN/task/actioning_rwijd/policy_reference.dita`

- Digest 13.3.7—While on jury service
         [Digest 13.3.7—While on jury service](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-13/parental-benefits-provisions.html#a13_3_7)

- Digest 10.14.5—Jury duty and court orders
         [Digest 10.14.5—Jury duty and court orders](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/personal-business.html#a10_14_5)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html) 
