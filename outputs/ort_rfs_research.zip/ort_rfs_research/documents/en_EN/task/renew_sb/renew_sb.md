# Renewing a claim for sickness benefits

Source map: `en_EN/task/renew_sb/renew_sb.ditamap`

## Summary

Source topic: `en_EN/task/renew_sb/summary.dita`

Summary: When a client submits a claim for sickness benefits and there is a benefit period (BP) with entitlement weeks remaining, the BP can be renewed. 

## What you need to know

Source topic: `en_EN/task/renew_sb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/renew_sb/untitled_section.dita`

If the benefit type (BT) before the renewal request is sickness, the officer follows the steps in this task to renew a claim for sickness benefits. If the previous BT is not sickness, the officer refers to the appropriate conversion task.

When assessing a renewal, it might be to the client’s advantage to establish a new BP instead of renewing the existing BP. For more information, the officer refers to Cancelling, voiding, terminating or withdrawing a claim .
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml)

The officer reviews all documentation in the electronic file to ensure all issues and information have been addressed as appropriate. The system does not generate a new WI or notify of an outstanding Claim Assessment (CA) or Specialized Application (SA) WI for uploaded documents in all situations. 

### Entitlement to sickness benefits

Source topic: `en_EN/task/renew_sb/entitlement_to_sickness_benefits.dita`

Sickness benefits can be paid if the following entitlement conditions are met:

- The client obtains proof of illness, injury or quarantine.

- The client is otherwise available for work.

The client can receive up to 26 weeks of sickness benefits per BP for a BPC in w/c 2374 or later and up to 15 weeks of sickness benefits per BP for a BPC in w/c 2373 or earlier. Once a claim has been established, a client may receive a combination of regular and special benefits within the BP. The maximum entitlement to benefits varies based on the BT received. The maximum number of weeks payable for each BT cannot be exceeded.
       [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

A 22 - Illness (maximum sickness/special benefits paid) disentitlement (D22) is imposed when a client requests sickness benefits and the maximum number of weeks of sickness benefits have already been paid.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4449.dita) 

### Defining major and minor attached clients

Source topic: `en_EN/task/renew_sb/defining_major_and_minor_attached_clients.dita`

Clients are major attached when they have accumulated at least 600 hours of insurable employment during their qualifying period (QP). The claim type (CT) is 3 - Sickness - major attached .

Clients are minor attached when they have accumulated between 420 and 599 hours of insurable employment during their QP. Minor attached clients have the required number of hours to establish a claim for regular benefits, but they do not have the required 600 hours for sickness benefits. Minor attached clients are entitled to sickness benefits only if the reason for separation (RFS) is other than illness. The CT is 9 - Sickness - minor attached . 

### Defining minor and major attached clients — Common entrance requirement (CER) (from w/c 2310 to w/c 2361)

Source topic: `en_EN/task/renew_sb/defining_minor_and_major_attached_clien_18ce3e14.dita`

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The common entrance requirement applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

During this period, the officer does not use the CT 9 - Sickness - minor attached .

**Limited capability**

To be entitled to sickness benefits, clients must demonstrate an incapacity to work. In some cases, clients may be incapable of performing the full scope of their duties but could continue to work on modified duties, for a limited number of days each week or could be capable of and available for other types of work. In these cases, clients may be unable to prove incapacity and the claim is referred to Level 2.

**Otherwise available for work**

Clients must prove that, had it not been for illness or injury, they would have been available for work ( otherwise available ) on each day for which sickness benefits are requested. The client’s statement of being otherwise available for work is accepted as sufficient proof unless there is information on file that indicates otherwise. When clients are not otherwise available, a 33 - Incapacity proven but not otherwise available disentitlement (D33) is imposed.
       [otherwise available](/en/procedure/activity/availability.shtml) 

### Contentious issues

Source topic: `en_EN/task/renew_sb/contentious_issues.dita`

When renewing a claim, a client may report a new contentious issue that must be adjudicated, such as reason for separation (RFS), farming or availability. If the issue is reported on the application, the system creates an Adjudication Issue (ADJ) WI. If a contentious issue is detected while reviewing the claim, the Level 1 officer creates an ADJ WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If unable to create an ADJ WI, the officer creates a Claim Review (CR) WI. For more information on the required type of WI, the officer refers to Contentious issue: Creation of a WI — Instructions .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
       [Contentious issue: Creation of a WI — Instructions](/en/procedure/generic/additionalresources/creation_wi_ci.shtml)

For more information, the officer refers to Determining if a claim is ready to be renewed or converted .
       [Determining if a claim is ready to be renewed or converted](/en/procedure/task/determ_claim_demande_ren_conv.shtml) 

### Deferred reason for separation (RFS)

Source topic: `en_EN/task/renew_sb/deferred_reason_for_separation_rfs.dita`

Sometimes, when a client asks for a claim to be renewed, fact-finding and adjudication of the RFS can be deferred. For more information, the officer refers to Deferral of adjudication .
       [Deferral of adjudication](/en/procedure/activity/deferral_adj.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4450.dita) 

### Effective date of a renewal

Source topic: `en_EN/task/renew_sb/effective_date_of_a_renewal.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer refers to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Claim in MPS

Source topic: `en_EN/task/renew_sb/claim_in_mps.dita`

When the claim is in MPS with claim status (CS) 8 - Converted to Manual Pay , the officer sends an Operational Centre Memo (MM06) transaction to IPOC to renew the claim. If the claim is in MPS, it stays in MPS for the remainder of the BP and the client must complete paper claimant’s reports.

When inputting the MM06, the officer ensures that all information required for the renewal is included. This includes the renewal week, the claim type (CT), the recovery week, claimant’s reports (if the information is available), any required allocations, BP extensions, disentitlements, etc. If there is any outstanding ADJ or AI WIs and a decision on a contentious issue is required, the Level 1 officer waits for their completion before sending the MM06 to IPOC. 

### Subsequent claim

Source topic: `en_EN/task/renew_sb/subsequent_claim.dita`

The renewal application can be used to establish a subsequent claim when the following conditions are met:

- The claim is renewed with 4 or fewer weeks of benefits remaining in the BP.

- The client has worked enough hours to establish a new claim.

If the CA WI for a renewal or subsequent initial claim is finalized within 28 days of the renewal application, ACP can register the subsequent claim.

When ACP cannot register the subsequent claim because the renewal is not processed within 28 days of the renewal application (i.e. REN WK not found or no match and polling limit exceeded is displayed on the Processing Activities tab) or when the claim was converted to MPS, the officer processing the CA Renewal WI must create a Reminder (REM) WI for the subsequent claim to be registered. 

### Duration of the benefit period (BP)

Source topic: `en_EN/task/renew_sb/duration_of_the_benefit_period_bp.dita`

The duration of the BP is the length of time in which clients can claim benefits to which they are entitled. The length of a BP is 52 weeks, including the week of the BPC and the waiting period (WP). A BP for sickness benefits ends when one of the following occurs:

- All the weeks to which the client is entitled have been paid.

- The maximum combined special and regular benefits have been paid.
         [maximum combined special and regular benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

- The 52-week duration is reached.

- The client requests the termination of the BP.

Under certain circumstances, the BP can be extended to allow clients more time to receive the benefits to which they are entitled. For further information, the officer refers to Extension of the benefit period .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Proof of incapacity

Source topic: `en_EN/task/renew_sb/proof_of_incapacity.dita`

Clients applying for sickness benefits must be able to provide a medical certificate which proves the inability to work due to illness.

A medical certificate completed by a doctor or other medical practitioner confirming the client’s sickness must be obtained for each week the client requests sickness benefits.

Clients applying for sickness benefits using AW can upload the medical certificate immediately. If clients do not submit the medical certificate and the last RFS is illness, clients are advised that it must be submitted if the duration of the illness or injury is greater than 9 weeks. Otherwise, clients are advised to keep the medical certificate for 6 years since it can be requested at a later date. If the last RFS is not illness, clients are advised they must provide a medical certificate and can upload it later using MSCA.

If a medical certificate is required and not provided, a 16 - No medical certificate submitted (D16) disentitlement must be imposed on the claim.

An officer must not request a medical certificate unless it is required. If a medical certificate is received but not required, the officer reviews it and updates the recovery date according to the information on the medical certificate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4451.dita) 

When the officer receives an acceptable medical certificate as proof of incapacity on a claim with a D16, the officer refers to Reviewing a medical certificate submitted by a client with a D16 disentitlement .
       [Reviewing a medical certificate submitted by a client with a D16 disentitlement](/en/procedure/task/review_d16_med_cert.shtml)

If the authenticity of a medical certificate or the signature of the doctor raises doubts, the officer refers the medical certificate to Integrity for review. For more information, the officer refers to Creating or reassigning a WI — Integrity .
       [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

**Acceptable medical certificate**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2793.dita) 

The client must obtain a medical certificate completed by a doctor or other medical professional confirming the client’s sickness for each week the client requests sickness benefits. The medical certificate must attest to the client’s inability to work and state the probable duration of the illness, injury, or quarantine.

When a medical certificate is submitted but is considered unacceptable, the client is contacted and asked to submit a new medical certificate. If a new acceptable medical certificate is not submitted, a D16 is imposed.

For more information, the officer refers to Determining if a medical certificate is acceptable .
       [Determining if a medical certificate is acceptable](/en/procedure/task/determining_med_cert_valid.shtml) 

### Period of incapacity

Source topic: `en_EN/task/renew_sb/period_of_incapacity.dita`

To allow the payment of sickness benefits, the officer must determine the period in which the client is incapable of working. This is done by determining the following information:

- the incapacity start date;

- the end date of the incapacity;

- the expected recovery date;

- the recovery week to be input.

**Incapacity start date**

If the RFS is D - Illness or injury on a renewal claim and no medical certificate must be submitted, the incapacity start date is the renewal week.

The officer refers to Sickness: Incapacity start date — Table to determine if an incapacity start date is required. If yes, the incapacity start date is the Sunday of the week in which the doctor or other medical professional indicates that the client was unable to work for medical reasons.
       [Sickness: Incapacity start date — Table](/en/procedure/generic/additionalresources/incapacity_start_date_sb.shtml)

If no specific incapacity start date is provided, the incapacity start date is the Sunday of whichever week is the earliest:

- the week that the doctor or other medical professional signed the medical certificate;

- the week of the medical consultation.

When the incapacity start date reported by the client is before the date indicated on the medical certificate, a D16 is imposed for the period of incapacity that is not covered by the medical certificate.

If the medical certificate does not indicate the incapacity start date, signature date or date of the medical consultation, it is not acceptable. The officer must conduct fact-finding with the client to obtain a new medical certificate that indicates the incapacity start date. For more information, refer to Determining if a medical certificate is acceptable .
       [Determining if a medical certificate is acceptable](/en/procedure/task/determining_med_cert_valid.shtml)

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4452.dita) 

**Incapacity end date**

The incapacity end date is the last day the client is incapable of working. The period of incapacity ends the day before the recovery date.

**Recovery date**

The recovery date is the first day the client is capable of working. The medical certificate is used to determine the recovery date.

**Recovery week**

The recovery week is the week up to which sickness benefits are payable. To determine the recovery week, the officer refers to Determining the recovery week — Instructions .
       [Determining the recovery week — Instructions](/en/procedure/generic/determing_the_recovery_week_instruction.shtml) 

### Claim action status and processing of the claim

Source topic: `en_EN/task/renew_sb/claim_action_status_and_processing_of_the_claim.dita`

The Claim action status Renewal is created when a renewal decision is registered. There are 3 Claim action statuses that may be displayed:

- In Progress (Automation) is displayed on the Client information tree when there is one or more outstanding adjudication issues.

- In Progress (Manual) is displayed on the Client information tree when there is no outstanding adjudication issue and there is an outstanding CA or SA WI.

- Finalized is displayed on the Client information tree when all ADJ WIs are completed and the renewal week has been successfully input. 

### Completing the WI

Source topic: `en_EN/task/renew_sb/completing_the_wi.dita`

If the Level 1 officer cannot adjudicate the issue, the WI is referred to Level 2 for adjudication. When an ADJ WI is created on a renewal claim, either manually or by the system, the system automatically imposes a 2 - Contentious Renewal in Automation manual action (MA02) to prevent payment of benefits until the contentious issue is adjudicated and the renewal is complete. When the renewal inputs or a decision must be input manually, the inputs must be done before the ADJ WI is completed, as the system removes the MA02 when the WI is completed. An officer cannot rescind an MA02.

The Level 1 officer who is referring the file to Level 2 for adjudication must:

- initiate fact-finding;

- input the renewal;

- reassign the WI.

When opening an ADJ WI, the officer must always check to see if there is a Resolve Issue tab. If there is a Resolve Issue tab, the officer can document the decision directly in the ADJ WI by completing all mandatory screens. When the ADJ WI is completed, NWS creates a record of decision (ROD) based on the Resolve Issue screens.

When the renewal is finalized, the system also generates the required transactions (e.g. signature code, disentitlement) based on the Resolve Issue screens. If a disentitlement is imposed, the system creates a Correspondence (COR) WI for the D-01-00-00 letter. This means that the officer with the CA or SA WI has no action to perform for these ADJ WIs.

When there is no Resolve Issue tab for the ADJ WI or if the WI is a CR, the officer must create a ROD, generate the required transactions and send the appropriate letter. If there is an outstanding CA or SA WI when the officer completes the ADJ WI, a client Note is created and the officer with the CA or SA WI must follow the instructions to input the transactions or send the letter. 

### ACS letters

Source topic: `en_EN/task/renew_sb/acs_letters.dita`

Communication of the renewal decision is not necessary when the only transaction input is the renewal transaction and when a medical certificate is not required to be submitted and was not provided. When another decision is input at the time of the renewal (disentitlement, disqualification or allocation of earnings), communication of the decision is necessary.

Officers who are responsible for communicating the decision usually send the appropriate letter. Officers must ensure that the letter was sent, and if the letter was not sent, they must create and send the letter of decision in ACS.

If a renewal and an allocation are input by the same officer and are processed on the same day, the R-01-00-00 letter is, in most cases, created automatically.

There are some exceptions. The letter is not automated if one of the following conditions is met:

- One of the transactions (M106 or M175) is rejected.

- The allocation code on the M175 is A .

- An E or W allocation is input for more than one week.

- One of the following manual action (MA) to stop payments is imposed:

- 1 - General suspension of benefits (stop payment) (MA01)

- 2 - Contentious Renewal in Automation (MA02)

- 48 - Stop payment due to undeliverable mail (MA48)

- 71 - Integrity Services case (MA71)

- 72 - Additional training information required (MA72)

- 73 - Canada Revenue Agency case (MA73)

- 74 - Labour Dispute (MA74)

- 75 - Verification of reason for termination of Employment (MA75)

- A disqualification or disentitlement is being input.

- A disqualification or disentitlement is already on file and is not being rescinded or terminated.

In some cases, the letter may be automated but additional decisions must be communicated. To prevent duplication of letters, the officer must prevent the automated letter from being sent by using the Automated Letter Bypass function in FTS. 

### Fraud indicators

Source topic: `en_EN/task/renew_sb/fraud_indicators.dita`

When the officer suspects that the application is fraudulent, the officer refers to Creating or reassigning a WI — Integrity before proceeding in this procedure.
       [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

For more information, the officer refers to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Suspicious ROEs

Source topic: `en_EN/task/renew_sb/suspicious_roes.dita`

Many fraudulent applications have been submitted with suspicious ROEs and could have been used to calculate a client’s claim. The following are some indicators that an ROE may be suspicious:

- The employer name or occupation on the ROE does not match other ROEs in RCM (e.g. the client’s employment history is with the School District 123, but an ROE is received from a plumbing company).

- The employer name on the ROE does not match the employment information provided by the client on previous applications.

- The employer name on the ROE does not match the last employer on the initial application.

- The employer name indicated as the last employer on the initial application is a large well-known corporation, but the name indicated on the ROE (block 4 - Employer’s name ) is a person’s name (e.g. the last employer on the application is Wal-Mart, but the employer on the ROE is John Doe).

- The ROE is a paper ROE issued by a large company that normally issues electronic ROEs (or vice versa). 

### No fraud indicators present on renewal application — 71 - Integrity Services case manual action (MA71) imposed

Source topic: `en_EN/task/renew_sb/no_fraud_indicators_present_on_renewal__82acd80b.dita`

When a previous initial application is potentially fraudulent, an MA71 was imposed, no benefits were paid, and a renewal application with no fraud indicators is received, the officer:

- creates an IPOC Review (IPOC REV) Claim removal WI for the IPOC officer to remove the claim from the client’s file;

- creates an SROC to document the action taken;

- refers to the calculation procedures to process the client’s application as a new initial claim.

When a previous renewal application is potentially fraudulent, an MA71 was imposed, no benefits were paid, and a subsequent renewal application with no fraud indicators is received, the officer:

- inputs the return to work (RTW) equal to the first day of the appropriate week;

- rescinds the MA71;

- creates an SROC to document the action taken;

- processes the renewal for the client.

The officer verifies whether any suspicious ROEs are under investigation by entering the business number (BN) in RMDS. If a BN is under investigation and the ROE is still on file, the officer deletes the ROE.

If benefits were paid on the potentially fraudulent application, the officer notifies Integrity that the client’s claim is blocked due to an MA71 and moves the CA WI to Pending until the investigation is complete.

If a suspicious ROE was used to calculate the client’s claim, the officer notifies Integrity about this and indicates that the client has submitted a renewal application. The officer then moves the CA WI to Pending until the investigation is complete.

To notify Integrity that a client’s claim is blocked due to an MA71, or that a suspicious ROE was used in the initial calculation, the officer creates an urgent AI WI so that the investigation can be prioritized. 

### Note

Source topic: `en_EN/common_notes/note_c_4449.dita`

Note:

If a client is not entitled to sickness benefits, the officer determines if the client can establish a new claim. If the client submitted a renewal application, it is used to determine if the client qualifies for a new initial claim. 

### Note

Source topic: `en_EN/common_notes/note_c_4450.dita`

Note:

Deferral of fact-finding and adjudication for a contentious RFS can be considered even if a 16 - No medical certificate submitted disentitlement (D16) is imposed. 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_4451.dita`

Note:

When a medical certificate is uploaded, the officer or the client must complete a Medical Certificate electronic questionnaire. The electronic questionnaire is not medical proof. The officer does not use it to determine a recovery week or period of incapacity. For detailed information on when the medical certificate must be requested, the officer refers to Determining if a medical certificate must be submitted — Renewal and continuing claims 

### Note

Source topic: `en_EN/common_notes/note_c_2793.dita`

Note:

The temporary measure for medical certificates ended September 25, 2021. For all BPs with a BPC or renewal week of September 26, 2021 (w/c 2310) or later, the officer follows normal procedures.

For BPs with a BPC or renewal week between March 15, 2020 (w/c 2230) and September 19, 2021 (w/c 2309), a client is not required to provide a medical certificate to receive sickness benefits. For more details, the officer refers to the previous version of this task by selecting the link at the bottom of the page. 

### Example

Source topic: `en_EN/common_notes/note_c_4452.dita`

Example:

- The BPC is in w/c 2407;

- The 10 - Dismissal - misconduct proven disqualification (D10) is imposed from BPC (regular benefits not payable);

- Sickness is declared from w/c 2411;

- The medical certificate is received and signed by the doctor or other medical professional in w/c 2414;

- No start date of the incapacity is indicated;

- The recovery date is w/c 2418;

Because the medical certificate does not indicate the incapacity start date:

- a D16 is imposed from w/c 2411 to w/c 2413 (the week before the date of the doctor or other medical professional’s signature);

- sickness benefits are allowed starting from the Sunday of the week that the doctor signed the medical certificate (w/c 2414 to w/c 2418). 

## Regional considerations

Source topic: `en_EN/task/renew_sb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/renew_sb/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/renew_sb/in_nws.dita`

- When was the application for renewal of benefits filed?

- Review processing activities for the web application and take notes if necessary:

- What issues did ACP detect?

- Does it indicate why the claim tripped down?

- Has the client worked since the last week paid?

- Is there an ROE on file?

- If no, is there employment information on file?

- Is there a medical certificate on file or has one been uploaded?

- Is there any information on file that indicates that the client may not be otherwise available for work?

- Is there an ADJ WI?

- If yes, for what issues? 

### In FTS:

Source topic: `en_EN/task/renew_sb/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- Has the last renewable week (LRW) been reached?

- Has the WP been served, half served, waived or deferred?

- Is there a registration number?

- Is there a D16?

- Is there an MA71? 

### In RCM:

Source topic: `en_EN/task/renew_sb/in_rcm.dita`

- What is the RFS on the ROE before the renewal?

- Is there an ROE on file?

- Are there any suspicious ROEs? 

### In Imaging:

Source topic: `en_EN/task/renew_sb/in_imaging.dita`

- Is there a medical certificate on file?

- Is there any other documentation which may impact the renewal claim? 

## Step by step

Source topic: `en_EN/task/renew_sb/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/renew_sb/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/renew_sb/reviewing_the_file_level_1.dita`

- In FTS, determine if there is a registration number:

- If yes, go to step 2.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- Determine if there are weeks of sickness benefits to be paid:

- If yes, go to step 3.

- If no, go to Maximum sickness benefits already paid .
               [Maximum sickness benefits already paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#Maximum)

- Determine if the WP must be served:

- If no, go to step 4.

- If yes and the client has not worked since the beginning of the BP, go to step 4.

- If yes and the client has worked since the beginning of the BP, the existing claim can be cancelled in favour of a new BP. Refer to Cancelling a benefit period . Go to step 4.
               [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml)

- In NWS and in FTS, determine if one of the following conditions exists to extend the BP:

- The client was incarcerated and has since been tried and not found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If one of the conditions exists, refer to Benefit period extension and then go to step 5.
               [Benefit period extension](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions exists, go to step 5.

- Determine if the LRW has been reached:

- If no, go to step 6.

- If yes, go to Last renewable week (LRW) has been reached .
               [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#LRW)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4453.dita)

- Determine the renewal week. Refer to Determining the effective date of a renewal or a conversion .

- Determine if there are any outstanding issues that require adjudication:

- If no, go to step 8.

- If yes or uncertain, refer to Determining if a claim is ready to be renewed or converted . Go to step 8.
               [Determining if a claim is ready to be renewed or converted](/en/procedure/task/determ_claim_demande_ren_conv.shtml)

- Determine if the client is minor attached:

- If no or if the BPC is between w/c 2310 and w/c 2361, go to step 9.

- If yes and the most recent RFS is not illness, injury or quarantine, go to step 9.

- If yes and the most recent RFS is illness, injury or quarantine, go to Client is minor attached .
               [Client is minor attached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#Minor)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4454.dita)

- Determine if the client would have been working or looking for work if not for the sickness or injury (for more information, refer to Adjudicating otherwise available issues — Renewal claim ):

- If yes, go to step 10.

- If no, create an ADJ WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue(s): Select Availability .

- Details: Type “Otherwise available — not within Level 1 authority.”

- Go to step 10.

- Determine if a medical certificate must be submitted :

- If yes, go to step 11.

- If no, go to step 22.

- Determine if an acceptable medical certificate is on file:

- If yes, go to step 12.

- If no, go to step 15.

- Determine if an incapacity start date is required (refer to Sickness: Incapacity start date — Table ):

- If yes, go to step 13.

- If no, go to step 22.

- Determine if the incapacity start date is noted on the medical certificate:

- If yes, for the incapacity start date, use the Sunday of the same week as the date indicated on the medical certificate.

- If no, for the incapacity start date, use the Sunday of either the week that the doctor or other medical professional signed the medical certificate, or the week of the medical consultation, whichever is earlier.

- Determine if there is a gap between the possible effective renewal date and the incapacity start date determined from the medical certificate:

- If yes, go to step 15.

- If no, use the date determined from the medical certificate and go to step 22. 

#### Fact-finding

Source topic: `en_EN/task/renew_sb/fact-finding_level_1.dita`

- Using the steps in the Fact-finding procedure, contact the client to request the missing medical certificate or an additional medical certificate for the gap period.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 17.

- If the client was not contacted or did not respond to the N-10-00-00 letter, go to step 21.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Medical .

- Comments: Type “Conversation with the client — medical proof needed.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client indicates that a medical certificate will be submitted:

- If the client indicates that a medical certificate will be submitted, go to step 19.

- If the client indicates that a medical certificate will not be submitted, go to step 21.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Medical certificate .

- Comments: Type “Awaiting medical certificate.”

- Bring forward date: Enter the day the client was contacted + 10 business days.

- When the WI moves to the current workload, determine if the medical certificate has been received:

- If yes, return to step 12.

- If no, go to step 21.

- In NWS, create a ROD as follows:

- Comments: Type the appropriate option:

- “D16 imposed — Medical certificate not submitted.”

- “D16 imposed — Incapacity start date not proven.”

- Details: Type the appropriate option:

- “The client has not submitted a medical certificate. Indefinite D16 imposed from [the first day of the renewal week].”

- “The incapacity start date declared by the client does not match the medical certificate. D16 imposed from [the first day of the renewal week in which the client declared sickness] to [the Friday before the incapacity start date].”

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4455.dita) 

#### Determining the recovery week

Source topic: `en_EN/task/renew_sb/determining_the_recovery_week_level_1.dita`

- Determine the recovery week by referring to Determining the Recovery week — Instructions and go to inputs . 

#### Inputs

Source topic: `en_EN/task/renew_sb/inputs_level_1.dita`

- In RCM, determine if there are any suspicious ROEs that have not already been deleted:

- If yes, note the BNs and go to step 24.

- If no, go to step 26.

- In RMDS, determine if the BN is under investigation as follows:

- Select Paper and then select Employer .

- Business No.: Enter the BN.

- Select Search .

- Select the BN and select Open .

- When the Employer profile screen opens, determine if the Under investigation box in the lower left-hand corner is checked:

- If yes, go to step 25.

- If no, go to step 26.

- In RCM, delete the ROE with the BN that is under investigation as follows:

- Delete: Check the box.

- Additional information: Select the appropriate option:

- If the ROE was not used to calculate the client’s established claim or the fraudulent established claim, type “Suspicious ROE has been deleted to prevent it from being used in benefits calculation. If its legitimacy is confirmed, it can be restored.”

- Select Validate .

- Select Submit .

- Go to step 26.

- If the ROE was used to calculate the client’s established claim or the fraudulent established claim, type “Suspicious ROE has been deleted. If its legitimacy is confirmed, it can be restored.”

- Select Validate .

- Select Submit .

- Go to step 26.

- Determine which of the following situations applies, then go to the appropriate step:

- If there are no fraudulent ROEs on file, go to step 27.

- If fraudulent ROEs were not used to calculate the client’s initial claim, go to step 27.

- If fraudulent ROEs were used to calculate the client’s initial claim, go to step 36.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If yes, go to step 28.

- If no, go to step 30.

- Determine if benefits were paid after the potentially fraudulent application was submitted:

- If yes, go to step 29.

- If no, go to step 30.

- Determine if there is an outstanding CR Integrity ERB-EI Transition WI:

- If no, go to step 30.

- If yes, check the Urgent box in the CR Integrity ERB-EI Transition WI and go to step 37.

- In FTS, determine if an MA71 was imposed: Note: Review Action Item (AI) WIs and SROCs on file to determine why the MA71 was imposed.

- If yes and it was imposed due to the fraudulent initial application and no benefits were paid, go to step 31.

- If yes and it was imposed due to the fraudulent initial application and benefits were paid, go to step 36.

- If yes and it was imposed due to a previous fraudulent renewal application and benefits were paid, go to step 36.

- If yes and it was imposed due to a previous fraudulent renewal application and no benefits were paid, go to step 39.

- If yes and it was imposed for any other reason, go to step 47.

- If no, go to step 47.

- In NWS, create an IPOC REV Claim removal WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the appropriate IPOC based on the region of the claim in FTS:

- Atlantic: 1826

- Quebec: 2642

- Ontario: 3056

- Western Canada and Territories: 5903

- End User: Select Next available user .

- Issue(s): Select Claim Removal .

- BPC: Enter the claim’s BPC.

- Comments: Type “Claim removal.”

- Details: Type “Void the BPC in w/c [XXXX]. Fraudulent application. No payments issued on the BPC.” If there is a violation on the Violation History (ML02) screen, type “Update the ML02 screen for the BPC in w/c [BPC with the violation that affects the voided BPC] and remove the BPC in w/c [voided BPC] from the affected BPCs.” Type “Advise Level 1 officer to establish the new BPC with a REM WI.”

- Obtained by: Select the appropriate option.

- Obtained from: Select the appropriate option.

- Source details: Enter the source details.

- Select Save .

- Move the CA WI to Pending as follows:

- Pending reason: Select the appropriate option.

- Comments: Type “The IPOC officer has to void the claim and create a REM WI so a new claim can be established”

- Bring forward date: Enter today’s date + 2 business days.

- When the CA WI moves to the current workload, determine if the IPOC officer has sent the REM WI to establish the claim:

- If no, repeat step 32.

- If yes, go to step 34.

- Create an SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Potentially fraudulent initial claim — claim voided.”

- Details: Type “Initial claim is potentially fraudulent. The claim has been voided and is pending an investigation.”

- In SSO, verify that the correct mainframe is selected and register the claim as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Initial .

- Select Search .

- Review the Name and Address screen:
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2168.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4456.dita) 

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region-new and Economic region-old: The information is prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: Select the appropriate option:

- If the field is blank, enter the SCC based on the client’s address on the application.

- For a commuter claim, enter the SCC associated with the workplace postal code.

- Tax credit: This field is prefilled based on the client’s information.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: If the field is blank, enter the SCC shown in the WI History tab of the CS WI (the same one input in the Responsible SCC field).

- Service unit: Type “01.”

- Tentative BPC: If not prefilled, determine the BPC based on the client’s last day worked (LDW) and application date. If the registration being obtained is for a subsequent claim, select the week after the previous claim’s LRW.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select Yes to generate the Initial Intake (M149) transaction.

- Select Generate registration .
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4398.dita)

- Select Next .

- On the M149 - Initial Intake Data screen, select Update .

- Go to Determining if a claim is ready to be calculated — Sickness benefits to process the client’s EI application as a new initial claim.
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- Create an AI WI for Integrity as follows:

- Urgent: Check the box.

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue(s): Select Other .

- Comments: Type the appropriate option:

- “Client blocked.”

- “Suspicious ROE used in calculation.”

- Details: Type the appropriate option:

- “The application dated [DD-MM-YYYY] was submitted by the client and is blocked by an MA71.”

- “A suspicious ROE was used in the calculation of the claim and a new application was submitted by the client.”

- Select Save .

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for investigation to end.”

- Bring forward date: Enter today’s date + 10 business days.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4457.dita)

- Once the CR Integrity ERB-EI Transition WI is complete, do the following:

- If a fraudulent initial claim has been voided and an initial claim must be established, refer to Determining if a claim is ready to be calculated — Sickness benefits to process the client’s EI application as a new initial claim.
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If processing a renewal claim is required and the CS is 0 - Active , go to step 39.

- If processing a renewal claim is required and the CS is 8, go to step 59.

- In FTS, determine if the client’s address is correct:

- If yes, go to step 40.

- If no, update the address and go to step 40.
               [update the address](/en/procedure/activity/change_address.shtml)

- Determine if the client’s banking information is correct:

- If yes, go to step 41.

- If no, update the banking information and go to step 41.
               [update the banking information](/en/procedure/activity/direct_deposit.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4447.dita)

- To determine the RTW date, choose the appropriate option:

- If cycling claimant’s reports are on file, the RTW date is the first day of the first week of the cycling claimant’s reports.

- If there are no cycling claimant’s reports the RTW date is the first day of the next week to be processed.

- Select the Additional Data (M107) transaction and input the RTW date as follows:

- Registration number: Leave this field blank.

- Return to work: Input the RTW date as determined in step 41.

- Select Update .

- In NWS, create an SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Potentially fraudulent renewal — Return to work input.”

- Details: Type “The renewal is potentially fraudulent. A return to work date has been input and the stop payment was rescinded pending an investigation.”

- In FTS, select the Renewal/Revised (M106) transaction to rescind the MA71 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 71 - Integrity Services case .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- Determine if there are cycling claimant’s reports:

- If yes, go to step 46.

- If no, go to step 47.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Renewal to be input.”

- Bring forward date: Enter the next business day.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4448.dita)

- In FTS, determine if the CS is 8:

- If no, go to step 48.

- If yes, go to step 59.

- Select the Renewal / Revised (M106) transaction and input the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount, if necessary.

- Claim type: Select one of the following:

- 3 - Sickness - major attached .

- 9 - Sickness - minor attached .

- Select the Special benefits (M106) link and input the following information on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

- If a D16 is also required, input the following:

- Action: Select Add .

- Disentitlement: Select 16 - No medical certificate submitted .

- Start: Select the Monday of the renewal week.

- End: Select the appropriate option:

- The Friday before the incapacity start date.

- Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement.

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select the appropriate option:

- If the renewal did not require Level 2 adjudication, select 1 - No .

- If the renewal required Level 2 adjudication, select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, or if there is an MA02 on file, select D - No .

- Select Update . 

#### Communication on an active claim

Source topic: `en_EN/task/renew_sb/communication_on_an_active_claim_level_1.dita`

- Determine if there is an allocation of earnings that must be communicated to the client:

- If yes, go to step 50.

- If no, go to step 53.

- Determine if one of the following situations applies:

- There is a denied antedate.

- A disentitlement or a definite disqualification is being imposed manually.

- The client submitted an acceptable medical certificate.

- If no, go to step 51.

- If yes, go to step 52.

- Determine if an MA02 is imposed on the claim:

- If yes, go to step 52.

- If no, go to step 53.

- In FTS, select the File Control Data (M101) transaction as follows:

- Select Claim Action .

- Select Automated Letter Bypass .

- Go to step 54.

- Determine which of the following situations applies and do the following:

- If a medical certificate must be submitted or the RFS is sickness and an acceptable medical certificate is on file, go to step 54.

- If the RFS is sickness, no medical certificate must be submitted and no acceptable medical certificate is on file, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#level1_item_8)

- In ACS, add details to the draft N-00-00-00 letter or create one. Based on the claim information, select all of the required attributes, including the following:

- To advise the client of the renewal week (for all claims):

- Renewal week - Sunday’s date (1246) .

- To advise the client that the antedate has been denied:

- Antedate denied or postdate Message - Initial/renewal/continuing claims (2481) .

- Antedate denied (2483) .

- Antedate denied - Renewal/continuing claims (2484) .

- Renewal application not filed on time and no good cause for delay .

- Date to which Antedate is requested (1144) .

- To advise the client of the number of weeks payable (no indefinite D16):

- Special benefits approved (3046) .

- Sickness benefits approved (3047) .

- To advise the client that sickness benefits have been approved to recovery date (less than 15 weeks):

- Special benefits approved (3046) .

- Sickness benefits approved (3047) .

- Sickness approved - Client must provide medical certificate .

- Start date Sickness benefits - Sunday’s date (1252) .

- End date Sickness benefits - Saturday’s date (1254) .

- To advise the client of the D16 disentitlement (definite or indefinite):

- Special benefits denied (3065) .

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- D16 - No medical certificate provided / incapacity ended / gradual return (3068) .

- D16 - No medical certificate provided .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of earnings - Only from ROE #1 - Monies allocated beyond BPC (2523)

- Allocation of earnings - Monies allocated beyond BPC are from both ROE #1 + ROE #2 (2517)

- Pension allocation (2525) (if the client is receiving a pension).

- Weekly indemnity allocation (2529) (if the client is receiving an indemnity payment).

- Allocated monies that prevent payment of sickness benefits (3090) (if necessary).

- For all claims:

- Waiting period message (2445) (if the client has not served the WP).

- Message for sickness claim - Is client receiving any other payment? (WLI / PSL / WCB / MVA) (3092) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- Determine if there is an outstanding adjudication for Level 2:

- If yes, save the letter and go to step 56.

- If no, send the letter and go to step 57.

- In NWS, create a client Note and type “Send the draft N-00-00-00 letter.” Go to Subsequent claims .

- In ACS, determine if there is another draft letter:

- If yes, go to step 58.

- If no, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#level1_item_8)

- Determine if all decisions which must be communicated to the client are included in the N-00-00-00 letter:

- If yes, delete the other draft letter. Go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#level1_item_8)

- If no, send the letter with only decisions that are left to be communicated. Go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#level1_item_8) 

#### Claim in MPS

Source topic: `en_EN/task/renew_sb/claim_in_mps_level_1.dita`

- Before sending the Operational Centre Memo (MM06) transaction to IPOC, determine if a Level 2 officer must adjudicate any outstanding issues:

- If yes, go to step 60.

- If no, go to step 62.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting Level 2 decision.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if a decision has been rendered:

- If no, repeat step 60.

- If yes, go to step 62.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 30 - New information on a manual pay claim .

- Remarks line 1: Type “Input renewal w/c [XXXX], CT [XX].”

- Remarks lines 2–4: Type “RCV WK [XXXX].” Also, enter the appropriate information:

- If the claimant’s reports information is available, type “M152 CR from w/c [XXXX] to [XXXX], sickness [sick days]. If necessary, type “earnings $[XXXX], NA [not available days], FWW [XX]” and other relevant information regarding the claimant’s reports input for each period (e.g. M152 CR from w/c 2424 to 2426, earnings $400, sickness 5).

- If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].”

- If an extension of the BP is required, type “Extend BP Type [X], Start week [XXXX], Number of weeks [X].”

- If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].”

- If a disqualification must be imposed, type “D[XX] from w/c [XXXX].”

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 04 - Insurance Payment Operational Centre .

- Select Update . 

#### Communication on an MPS claim

Source topic: `en_EN/task/renew_sb/communication_on_an_mps_claim_level_1.dita`

- Determine which of the following situations applies and do the following:

- If a medical certificate must be submitted or the RFS is sickness and an acceptable medical certificate is on file, go to step 66.

- If the RFS is sickness, an allocation must be communicated to the client, no medical certificate must be submitted and no acceptable medical certificate is on file, go to step 69.

- If the RFS is sickness, no allocation must be communicated to the client, no medical certificate must be submitted and no acceptable medical certificate is on file, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#level1_item_8)

- In ACS, add details to the draft N-00-00-00 letter and send it, or create one and send it. Based on the claim information, select all of the required attributes, including the following:

- To advise the client of the renewal week (for all claims):

- Renewal week - Sunday’s date (1246) .

- To advise the client that the antedate has been denied:

- Antedate denied or postdate Message - Initial/renewal/continuing claims (2481) .

- Antedate denied (2483) .

- Antedate denied - Renewal/continuing Claims (2484) .

- Renewal application not filed on time and no good cause for delay .

- Date to which Antedate is requested (1144) .

- To advise the client of the number of weeks payable (no indefinite D16):

- Special benefits approved (3046) .

- Sickness benefits approved (3047) .

- To advise the client that sickness benefits have been approved to recovery date (less than 15 weeks):

- Special benefits approved (3046) .

- Sickness benefits approved (3047) .

- Sickness approved - Client must provide medical certificate .

- Start date Sickness benefits - Sunday’s date (1252) .

- End date Sickness benefits - Saturday’s date (1254) .

- To advise the client of the D16 disentitlement (definite or indefinite):

- Special benefits denied (3065) .

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- D16 - No medical certificate provided / incapacity ended / gradual return (3068) .

- D16 - No medical certificate provided .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of earnings - Only from ROE #1 - Monies allocated beyond BPC (2523)

- Allocation of earnings - Monies allocated beyond BPC are from both ROE #1 + ROE #2 (2517)

- Pension allocation (2525) (if the client is receiving a pension).

- Weekly indemnity allocation (2529) (if the client is receiving an indemnity payment).

- Allocated monies that prevent payment of sickness benefits (3090) (if necessary).

- For all claims:

- Waiting period message (2445) (if the client has not served the WP).

- Message for sickness claim - Is client receiving any other payment? (WLI / PSL / WCB / MVA) (3092)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In ACS, determine if there is another draft letter:

- If yes, go to step 68.

- If no, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#level1_item_8)

- Determine if all decisions which must be communicated to the client are included in the N-00-00-00 letter:

- If yes, delete the other draft letter. Go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#level1_item_8)

- If no, send the letter with only decisions that are left to be communicated. Go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_sb#level1_item_8)

- Create and send the D-20-16-03 letter. 

#### Subsequent claims

Source topic: `en_EN/task/renew_sb/subsequent_claims_level_1.dita`

- Determine if there are 4 or less weeks remaining to be paid in the BP:

- If yes and the CS is 0, go to step 71.

- If yes and the CS is 8, go to step 72.

- If no, go to step 7 3.

- Determine if the renewal was finalized within 28 days of the renewal application being filed (i.e. application date + 27 days):

- If no, go to step 72.

- If yes, go to step 73.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Subsequent claim not automated.”

- Due date: Select the LRW + 3 weeks.

- Details: Type “Subsequent claim to be established.”

- Destination: Select the SCC as shown in FTS.

- End User: Select Next available user.

- Complete the CA WI. 

#### Maximum sickness benefits already paid

Source topic: `en_EN/task/renew_sb/maximum_sickness_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D22 imposed. Maximum sickness benefits paid.”

- Details: Select one of the following:

- If the client has not worked since the BPC , type “No renewal is possible as maximum sickness benefits have been paid. The client does not qualify for a new claim as no hours were accumulated after BPC. D22 imposed.”

- If the client has worked since the BPC , type: “No renewal is possible as maximum sickness benefits have been paid. The client does not qualify for a new claim as [number of hours] hours were accumulated after BPC. The client needed [number of hours] hours to qualify. D22 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D22 and the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Type the amount (if necessary).

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 22 - Illness (maximum sickness / special benefits paid) .

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D22 - Max sickness paid/max sickness paid but approved regular or maternity benefits/max combination of special benefits reached (3069) and select the appropriate option:

- D22 - Max weeks of sickness benefits already paid .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select Indefinite disentitlement start date (1270) and enter dates.

- Sickness maximum of 15 or 26 weeks (12545)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the CA WI. 

#### Client is minor attached

Source topic: `en_EN/task/renew_sb/client_is_minor_attached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D2 imposed. Minor attached, reason for separation — illness.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No renewal is possible as the client is minor attached. The client does not qualify for a new claim as no hours were accumulated after BPC. D2 imposed.”

- If the client has worked since the BPC , type “No renewal is possible as the client is minor attached. The client does not qualify for a new claim as [number of hours] hours were accumulated after BPC. The client needed [number of hours] hours to qualify. D2 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the 2 - Minor Attached, reason for separation illness disentitlement (D2) and the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select 9 - Sickness - minor attached .

- Select the Special benefits (M106) link and input the following on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

- Action: Select Add .

- Disentitlement: Select 2 - Minor Attached, reason for separation illness .

- Start date: Enter the disentitlement start date.

- End date: Enter Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D2 – Not enough hours/Not enough fishing earnings (3067) .

- Select D2 - Minor attached – Not enough insurable hours .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select Definite disentitlement start date (1272) and enter dates.

- Enter the Number of insurable employment hours accumulated (1366) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the CA WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/renew_sb/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “LRW reached — sickness benefits requested.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No renewal is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as no hours were accumulated after BPC.”

- If the client has worked since the BPC , type “No renewal is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as [number of hours] hours were accumulated after BPC. The client needed [number of hours] hours to qualify.”

- In ACS, send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type the following: “We cannot reactivate your claim for Employment Insurance benefits starting (Renewal week - Sunday’s date) . Please note that we are required to advise you of all decisions made on your claim. No sickness benefits are payable to you on this claim because the last renewable week has been reached on this benefit period. To receive sickness benefits, you must work the required minimum number of insurable employment hours. If you want to receive sickness benefits in the future, you must file a new claim.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the CA WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4453.dita`

Note:

The claim may be renewable for special benefits if all regular entitlement has been paid out, and the claim is on the Dormant tab, with the message “special benefits potentially payable.” 

#### Note

Source topic: `en_EN/common_notes/note_c_4454.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, the definitions of major and minor attached clients do not apply regardless of the renewal date. However, if the client has 420 or more hours of insurable employment, select the major attached option. 

#### Note

Source topic: `en_EN/common_notes/note_c_4455.dita`

Note:

If the client did not submit a medical certificate, impose an indefinite D16 when finalizing the renewal.

When a medical certificate is on file, impose a D16 from the renewal week to the Friday before the incapacity start date.

In both cases, create and send an N-00-00-00 letter to inform the client that sickness benefits have been denied. 

#### Note

Source topic: `en_EN/common_notes/note_c_2168.dita`

Note:

The information from the application in NWS is automatically downloaded in SSO. In rare cases, the information is not downloaded and must be manually input. Verify (and correct, if necessary) any prefilled fields with the information provided on the application. 

#### Note

Source topic: `en_EN/common_notes/note_c_4456.dita`

Note:

When the client has only one name, one of the name fields on the Name and Address screen may be empty or contain a non-alphabetical character. However, SSO does not allow the field to be completed in this way.

When a name field is empty or contains a non-alphabetical character, do the following:

- First Name: Enter the appropriate option:

- For a client who selects the Male gender marker, type “Mr.”

- For a client who selects the Female gender marker, type “Ms.”

- For a client who selects the X gender marker, type “N.A.”

- Last Name: Enter the client’s name.

When the First Name field on the Name and Address screen is modified to “N.A.” , modify the Initial Intake (M149) or Name and Address Change / Transfer (M159) transaction generated by the calculation and type a “.” in the First Name field before inputting it. 

#### Note

Source topic: `en_EN/common_notes/note_c_4398.dita`

Note:

The Initial Intake (M149) transaction cannot be input on the same day as the File Control Data (M101) transaction type 7 (M101-7). 

#### Note

Source topic: `en_EN/common_notes/note_c_4457.dita`

Note:

When the investigation is complete, a CR Integrity ERB-EI Transition WI is created. In the CR Integrity ERB-EI Transition WI, ensure that the Urgent box is checked. Do not process the CA WI until the CR Integrity ERB-EI Transition WI related to the potentially fraudulent application has been completed.

If the following WIs are outstanding, do not process the CA WI until they are completed:

- IPOC Manual Pay (IPOC MPS) Third party fraud WI

- IPOC Overpayment (IPOC O/P) Third party fraud WI 

#### Note

Source topic: `en_EN/common_notes/note_c_4447.dita`

Note:

In FTS, ensure that the correct address and banking information are on file (update the information, if necessary). Ensure also that the client’s name, language and gender are correct. If there is a fraudulent claim in another ITC, update the information in both ITCs. 

#### Note

Source topic: `en_EN/common_notes/note_c_4448.dita`

Note:

The next day, the cycling claimant’s reports will show error code C420: WARNING - Claim status changed to 02 (found work) on the Pending/reject tab. Delete the rejected transactions on the Rejected Transactions Retrieval (MR05) screen. 

## Policy reference

Source topic: `en_EN/task/renew_sb/policy_reference.dita`

- EIA 12(6)
         [EIA 12(6)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- National Policy on Proof of Incapacity
         [National Policy on Proof of Incapacity](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/proof_of_incapacity_policy.shtml)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
