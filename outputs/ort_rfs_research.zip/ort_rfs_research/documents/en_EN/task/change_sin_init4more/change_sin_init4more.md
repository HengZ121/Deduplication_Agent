# Changing a SIN: Initial claim — More than 4 weeks after the interruption of earnings

Source map: `en_EN/task/change_sin_init4more/change_sin_init4more.ditamap`

## Summary

Source topic: `en_EN/task/change_sin_init4more/summary.dita`

Summary: When a client reports having obtained a new SIN, the officer replaces the old SIN on the client’s EI records in the following situations:

- the initial application was submitted more than 4 weeks after the interruption of earnings (I of E);

- the initial application date is within 4-weeks of I of E and the claim assessment is not performed within this period. 

## What you need to know

Source topic: `en_EN/task/change_sin_init4more/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/change_sin_init4more/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2505.dita) 

### Receiving notification of a new SIN

Source topic: `en_EN/task/change_sin_init4more/receiving_notification_of_a_new_sin.dita`

A client may receive a new SIN at any time during the claim. The client can report the change in person, by telephone or by mail. When notification of a new SIN is received, the officer confirms the new SIN in the Social Insurance Registry (SIR) database before making any changes to the record.

When permanent residents or Canadian citizens apply for EI benefits with a 900-series SIN, they receive a message informing them that they must apply for a new permanent SIN and report the new SIN when they receive it. 

### Updating the EI application

Source topic: `en_EN/task/change_sin_init4more/updating_the_ei_application.dita`

On an initial claim, when 4 weeks or less have passed since the most recent I of E occurred and the claim assessment is performed within this period, the officer refers to Changing a SIN: Initial claim — Within 4 weeks of the interruption of earnings and asks the client to reapply for benefits with the new SIN. If the client reapplies within 4 weeks of the I of E, ACP registers the claim or, if ACP cannot determine the tentative BPC, it creates a Claim Set-Up (CS) Tentative BPC WI.
       [Changing a SIN: Initial claim — Within 4 weeks of the interruption of earnings](/en/procedure/task/change_sin_init4less.shtml)

However, when 4 or less weeks have passed since the most recent I of E occurred on an initial claim and the claim assessment is not performed within this period, the client cannot reapply with the new SIN because ACP would not calculate the BPC correctly. In this situation, referring to this procedure, the officer manually establishes the claim with the new SIN using the information from the EI application that was submitted under the old SIN. Then, the officer deletes the application with the old SIN, as it is considered an error.

The same instructions are appropriate when more than 4 weeks have passed since the most recent I of E on an initial claim. The officer continues to refer to this procedure.

All SROCs, records of decision (RODs), Action Item (AI) or Call Back (CB) WIs created under the 900-series SIN remain accessible under the 900-series SIN and are not transferred to the new permanent SIN. To access this documentation, the officer refers to the old SIN. 

### Updating the ROEs

Source topic: `en_EN/task/change_sin_init4more/updating_the_roes.dita`

All paper and electronic ROEs in RCM that were issued with the old SIN and used to calculate the claim must be re-entered as interim ROEs with the new SIN. This applies to both paper and electronic ROEs. In addition, the processing officer documents the SIN change under both the new and old SIN and submits the information to IPOC using an Operational Centre Memo (MM06) transaction. An IPOC officer then takes all the required actions related to the SIN change on any continuing, renewal or dormant claims.
       [interim ROEs](/en/procedure/activity/interim_roe.shtml)

The processing officer ensures that all ROEs issued since the new SIN became valid have been correctly issued with the new SIN. If an employer issues an ROE with the old SIN and the new SIN is already valid, the officer deletes the ROE and asks the employer to reissue the ROE with the new SIN. In addition to creating an interim ROE, the officer creates a Reminder (REM) WI while awaiting the ROE. 

### Updating the electronic file

Source topic: `en_EN/task/change_sin_init4more/updating_the_electronic_file.dita`

The client must not submit claimant’s reports with the old SIN because that claim will not be established. When the claim is registered with the new SIN, the system issues an access code and instructions on when to submit the claimant’s report.

Earlier claims established with the old SIN that are now dormant must also be updated. The officer sends an MM06 to IPOC to have the updates made to dormant claims. 

### Obtaining the missing information

Source topic: `en_EN/task/change_sin_init4more/obtaining_the_missing_information.dita`

The officer imposes an indefinite 15 - Claim Procedure disentitlement (D15) from the BPC under the 900-series SIN when the client is not reached and fact-finding is required to confirm the client’s full name or parent’s last name at birth (EI application only).

The officer sends an ACS letter to notify the client of the disentitlement and asks the client to provide the missing information as soon as possible. 

### Levels of decision — Rescinding a Claim Procedure disentitlement (D15)

Source topic: `en_EN/task/change_sin_init4more/levels_of_decision__rescinding_a_claim__193609eb.dita`

If the client does not respond to the requests to provide missing information, it is considered as a failure to report for an interview. The National Policy on Levels of Decision specifies that a Level 1 officer rescinds a D15 when the requested information is provided within 6 weeks of the date the D-01-00-00 letter was sent. For more information, the Level 1 officer refers to Reviewing a D15 disentitlement — Failure to report for a telephone interview .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
       [Reviewing a D15 disentitlement — Failure to report for a telephone interview](/en/procedure/task/claim_procedure_ftr_telehone_review_d15.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2505.dita`

Note:

When a client reports having obtained a new SIN, if the initial application date is within 4 weeks of the I of E and the claim assessment is  performed within this period, the officer refers to Changing a SIN: Initial claim — Within 4 weeks of the interruption of earnings .
       [Changing a SIN: Initial claim — Within 4 weeks of the interruption of earnings](/en/procedure/task/change_sin_init4less.shtml)

     [Changing a SIN: Initial claim — Within 4 weeks of the interruption of earnings](/en/procedure/task/change_sin_init4less.shtml) 

## Regional considerations

Source topic: `en_EN/task/change_sin_init4more/regional_considerations.dita`

**Quebec:**

The Business Expertise Advisor, rather than the Team Leader, deletes the application in NWS. Using the consultative tool, the officer advises the Business Expertise Advisor. No WI is created. 

## What you need to look for

Source topic: `en_EN/task/change_sin_init4more/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/change_sin_init4more/in_fts.dita`

- What personal information is on the application with the old SIN?

- Have claimant’s reports been completed with the old SIN?

- Are there any BPCs established with the old SIN? 

### In NWS:

Source topic: `en_EN/task/change_sin_init4more/in_nws.dita`

- Is there an SROC or AI WI related to the SIN change? 

### In Imaging:

Source topic: `en_EN/task/change_sin_init4more/in_imaging.dita`

- Is there documentation related to the SIN change? 

### In SIR:

Source topic: `en_EN/task/change_sin_init4more/in_sir.dita`

- Does the information in the SIR database with the client’s new SIN match the personal information found on the original application (old SIN)?

- On which date was the new SIN issued? 

### In RCM:

Source topic: `en_EN/task/change_sin_init4more/in_rcm.dita`

- Have ROEs been submitted?

- What types of ROEs have been submitted (what letter does the serial number start with?)

- Have ROEs been issued before or after the SIN change? 

## Step by step

Source topic: `en_EN/task/change_sin_init4more/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/change_sin_init4more/level_1.dita`

#### Determining if the SIN change can be input

Source topic: `en_EN/task/change_sin_init4more/determining_if_the_sin_change_can_be_input_level_1.dita`

- In the SIR, compare the following SIR database information with the client’s new SIN to the initial application submitted under the old SIN:

- the client's full name

- the parent’s last name at birth (EI application only)

- If there are differences, go to step 2.

- If there are no differences, go to SIN change can be input .
                   [SIN change can be input](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/change_sin_init4more#can_be_input)

- Fact-find with the client.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 4.

- If the client was not reached or did not reply to the N10-00-00 letter, go to SIN change cannot be input — Unable to reach the client for missing information .
               [SIN change cannot be input — Unable to reach the client for missing information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/change_sin_init4more#Impose) 

#### SIN change can be input

Source topic: `en_EN/task/change_sin_init4more/sin_change_can_be_input_level_1.dita`

- In NWS, on the claim with the old SIN, add details to the draft SROC created during fact-finding or create SROC on the claim with the old SIN as follows:

- Main Issue: Select Other .

- Comments: Type “SIN change — new SIN obtained.”

- Details: Type “New SIN — [new SIN]. This application must be deleted.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- With the new SIN, create an external SROC as follows:

- Main Issue: Select Other .

- Comments: Type “SIN change.”

- Details: Type “New SIN obtained — old SIN is [old SIN].”

- Select Save . 

#### Updating the EI application

Source topic: `en_EN/task/change_sin_init4more/updating_the_ei_application_level_1.dita`

- In FTS, determine if there is a skeleton claim set up with the old SIN:

- If yes, go to step 7.

- If no, go to step 9.

- Select the File Control Data (M101) transaction and terminate the benefit period for the old SIN as follows:

- Claim Action: Select Terminate benefit period (M101-7) .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and cancel the registration assigned to the old SIN as follows:

- Registration number: Select appropriate registration number.

- Action: Select Cancel .

- Select Update .

- In SSO, verify that the correct information technology centre (ITC) is selected. Using the application completed with the old SIN, register the claim using the new SIN as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s new SIN.

- Registration type: Select Initial .

- Select Search .

- Review the Name and Address screen:

- Complete the following fields using data from the original application completed with the old SIN:

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: Both fields are prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Enter the client’s personal information in the following fields:

- First name

- Last name

- Gender

- Language - speaking

- Language - writing

- Date of birth

- Ordinary place of residence different (for a claim other than a commuter claim)

- Mailing address

- Postal code

- Telephone

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: For a commuter claim, enter the Service Canada Centre (SCC) associated with the workplace postal code. If the field is blank, enter the SCC of the region where the client resides:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Last job: Enter the correct National Occupation Classification (NOC) code for the client’s last job title.

- Tax credit: Select the appropriate option.

- Select Next .

- On the Application Form screen, do the following:

- Enter the following employment information from the old SIN application:

- Application received: Enter the date the application was received.

- Reason for separation: Select the appropriate option.

- First day worked: Enter the first day worked.

- Last day worked: Enter the last day worked (LDW).

- Select Next .

- On the Registration screen, do the following:

- Pay SCC: Verify that the SCC is the same as shown in FTS. If the field is blank, enter the SCC of the region where the client resides:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: If this field is not prefilled, determine the BPC based on the client’s LDW and the application date. If the registration is for a subsequent claim, select the week after the last renewable week (LRW) of the previous claim.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select Yes to generate the M149 – Initial Intake Data (M149) transaction.

- Select Generate registration .
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2506.dita)

- Select Next .

- On the M149 - Initial Intake Data screen, select Update .

- Determine if an error message appears:

- If no error message appears, go to step 11.

- If an error code appears, do the following:

- In FTS, select the Initial Intake Data (M149) transaction and complete it as follows:

- Tentative BPC: Enter the correct BPC.

- Select Update .

- If the error persists, select the error code to review the information in WECS and take the appropriate action.

- In NWS, using the new SIN, reassign the newly created Claim Assessment (CA) WI to yourself as follows:

- Destination: Select Myself .

- Reason: Select Related Work Item .

- Details: Type “SIN change.”

- In FTS, determine if the direct deposit information appears with the old SIN:

- If no, go to step 13.

- If yes, enter the direct deposit information using the new SIN. Refer to Adding a direct deposit — Claim on file and go to step 13.
               [Adding a direct deposit — Claim on file](/en/procedure/task/adding_dd.shtml)

- Determine if claimant’s reports have been submitted using the old SIN:

- If yes, copy the information to the appropriate claimant’s report checklist — Claimant’s report: Original without pay coding or Claimant’s report: Original with pay coding and then go to step 14.
               [Claimant’s report: Original without pay coding](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Original_without_pay_coding-Checklist.doc) 
               [Claimant’s report: Original with pay coding](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Original_with_pay_coding-Checklist.doc)

- If no, go to step 15.

- In NWS, add details to the draft SROC or create an SROC using the new SIN as follows:

- Main Issue: Select Client Reports .

- Comments: Type “SIN change.”

- Details: Type “Ignore paper application created during registration. Original application has been deleted but can be displayed with old SIN. Claimant’s reports have been transferred from old SIN as follows: [checklist].”

- Select Save .

- Create a REM WI using the old SIN to have the application deleted as follows:

- Select the appropriate application from the Client information tree of the old SIN.

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due Date: Enter today’s date.

- Language: Select the language used on the application.

- Details: Type “The wrong SIN was provided on the application.”

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Specific User and assign it to your team leader or the staff member who has deletion rights.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2502.dita) 

#### Updating the ROEs

Source topic: `en_EN/task/change_sin_init4more/updating_the_roes_level_1.dita`

- Determine if the client provided proof of the authorization to work in Canada for each period of employment in the qualifying period (QP) during which the client had a 900-series SIN:

- If yes, go to step 17.

- If no, refer to Determining if an insurability ruling is required — 900-series SIN and go to step 17.
               [Determining if an insurability ruling is required — 900-series SIN](/en/procedure/task/insurability_ruling_900series.shtml?continue)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2501.dita)

- In RCM, create an interim ROE using the new SIN for each ROE that affects the current claim and was input with the old SIN as follows:

- On the Input screen, complete the fields as follows:

- Social Insurance No.: Enter the new SIN.

- Serial Number: Leave this field blank.

- Serial Number of amended ROE or replaced: Leave this field blank.

- Interim ROE Type: Select Regular Interim or Fishing Interim .

- Printing Language: Select the language used on the original ROE.

- Select Submit .

- On the Input Regular ROE or Input Fishing ROE screen, enter the same information as shown on the original ROE with the old SIN.

- Additional information: Type “SIN change — old SIN [old SIN and serial number of original ROE].”

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2503.dita)

- For all the ROEs issued with the old SIN, determine the ROE issue date:

- If the issue date is after the effective date of the new SIN, go to step 19.

- If the issue date is before the effective date of the new SIN, go to Determining if the electronic file requires updating .
               [Determining if the electronic file requires updating](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/change_sin_init4more#determining)

- Delete each ROE that was incorrectly issued with the old SIN as follows:

- Select Search/Correct .

- Social Insurance No.: Enter the old SIN.

- Serial Number: Leave this field blank.

- Select Submit .

- Select a serial number to open an ROE.

- Status: Check the Delete box.

- Additional information: Type “SIN change — [new SIN].”

- Select Submit .

- Fact find with the employer and do the following:

- Ask the employer to reissue the ROE using the new SIN.

- Inform the employer that the ROE issued with the old SIN has been deleted.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2499.dita)

- In NWS, add details to the draft SROC or create a new SROC with the new SIN as follows:

- Main issue: Select ROE .

- Comments: Type “SIN change — [new SIN].”

- Details : Type “[Employer’s name] incorrectly issued the record of employment with the old SIN.” If necessary, type “Unable to contact the employer by telephone — a second letter was sent.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the employer was reached during fact-finding:

- If the employer was reached, go to step 23.

- If the employer was not reached or did not reply to the Z-02-00-00 letter, go to step 29.

- Determine if the employer states the ROE will be provided:

- If yes and the employer is faxing the ROE to Service Canada, go to step 24.

- If yes and the employer will issue the electronic ROE in a timely manner, go to step 24.

- If yes and the employer will provide the client with a paper ROE or true copy of the original paper ROE, go to 24.

- If no, go to step 28.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select ROE .

- Comments: Type “ROE request.”

- Bring forward date: Do one of the following:

- If the employer is faxing the ROE, enter today’s date + 2 business days.

- If the employer indicated that the electronic ROE will be issued in a timely manner, enter today’s date + 5 business days.

- If the employer is sending a paper ROE, enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if the ROE is displayed in RMDS or RCM:

- If the ROE is not displayed in RMDS or RCM, go to step 26.

- If the ROE is displayed in RCM, go to step 31.

- Determine if the paper copy, or an uploaded or faxed copy of the ROE has been received:

- If the ROE was not received and the bring-forward date is not reached, return to step 24.

- If an uploaded or faxed copy of a paper ROE was received, go to step 27.

- If a copy of the ROE has not been received and the bring-forward date is reached, go to step 28.

- In RCM, enter the ROE by referring to Data entry — Paper document . If the ROE that was entered has validation errors, correct the errors by referring to Correct an ROE and go to step 31.

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Opening Sentence to ER to Request or Clarify ROE/RFS (2794): Select Request ROE Opening Sentence - claimant .

- Request for a Record of Employment (2797) .

- Select Initial Request for ROE .

- Select Start-end date of employment / End date of employment (2798) .

- Go to step 30.

- In ACS, send a registered copy of the Z-02-00-00 letter with the following attributes:

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794): Select Request ROE Opening Sentence — claimant .

- Request for a Record of Employment (2797): Select Follow up request for ROE .

- Previously requested by mail (2799):

- Date ROE requested: Type the date the original letter was sent.

- End date of period of employment: Type the employment end date.

- Date of BF: Enter 10 business days from the date the letter is sent.

- Attachment List for Z-02-00-00 (3133): Select Attached: Copy of original letter .

- Indicate on letter how letter mailed (2804): Select Sent by registered mail .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1564.dita)

- In NWS, create a REM WI using the new SIN as follows:

- Complexity: Select Level 1.

- Reason: Select Missing ROE .

- Comments: Type “The employer must issue a new ROE.”

- Due date: Enter 10 working days from the date on which a valid ROE was requested.

- Details: Type “SIN change. The employer issued an ROE with the old SIN although the new SIN is now valid. An interim ROE was created. The employer must issue a new ROE. If the employer does not comply, refer the file to Integrity.”

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Next Available User . 

#### Determining if the electronic file requires updating

Source topic: `en_EN/task/change_sin_init4more/determining_if_the_electronic_file_requ_3dcd09c9_level_1.dita`

- In FTS, determine if there are earlier BPCs established with the old SIN:

- If no, go to Electronic file update not required .
               [Electronic file update not required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/change_sin_init4more#Electronicupdate)

- If yes, go to Electronic file update required .
               [Electronic file update required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/change_sin_init4more#Electronicupdate1)

- In NWS, using the old SIN determine if there is a WI related to the SIN change that was not deleted.

- If no, no further action is required.

- If yes, complete the WI.

- In FTS, using the old SIN select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the registration number assigned to the initial application with the old SIN.

- Memo (MPS): Check the box.

- Detection: Select 31 - Other new facts .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the request for a SIN change.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 34 - Social insurance number change .

- Remarks line 1: Type “SIN change to new SIN [new SIN].”

- Remarks line 2 to 4: Enter the appropriate options:

- The list of all BPCs with the old SIN.

- If a D15 is imposed from the BPC under the 900-series SIN for the same BPC that will be established with the permanent SIN and the D15 is not required for the permanent SIN, type “Do not transfer BPC [XXXX] from old SIN. BPC [XXXX] is on new SIN.”

- If necessary, type “Calculation result under new SIN has been reviewed.”

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Transfer the registration number to IPOC, selecting the appropriate registration number from the Registration Number (M025, M030, M035) transaction as follows:

- Registration number: Select the registration number assigned to the initial application with the old SIN.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, using the old SIN, determine if there is a WI related to the SIN change that was not deleted:

- If no, no further action is required.

- If yes, complete the WI. 

#### SIN change cannot be input — Unable to reach the client for missing information

Source topic: `en_EN/task/change_sin_init4more/sin_change_cannot_be_input__unable_to_r_79064342_level_1.dita`

- In NWS, using the old SIN, create a ROD as follows:

- Comments: Type “Unable to reach the client.”

- Details: Type “15 - Claim Procedure disentitlement imposed — SIN change. New SIN not validated.”

- Select Save .

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose a D15 as follows:

- Registration number: Select the registration number assigned to the initial application with the old SIN.

- Action: Select Add .

- Disentitlement: Select 15 - Claim Procedure .

- BPC date: Check the box (the Start date is prefilled with 55/55/5555 ).

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976)

- D48 and D15 – Moved – Address unknown and claim procedure (3006)

- D15 - Claim procedure (3009)

- D15 - TEXT: insert appropriate reason for D15

- We / In addition, we (2687)

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- Indefinite disentitlement start date (1270)

- Text - Insert appropriate reason(s) (1618): Type the appropriate option:

- “you have not returned our call[s] following the message[s] left on [date[s]].”

- “you have not contacted us following the letter sent to you on [date].”

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Complete the WI related to the SIN change.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2504.dita) 

#### Note

Source topic: `en_EN/common_notes/note_c_2506.dita`

Note:

At this step, a registration number is assigned to the claim. If Yes is selected, the M149 – Initial Intake Data (M149) transaction is automatically generated.

If No is selected, the M149 – Initial Intake Data (M149) transaction is not generated. 

#### Note

Source topic: `en_EN/common_notes/note_c_2502.dita`

Note:

In the Quebec region, do not create a WI. Using the consultative tool, inform the Business Expertise Advisor that the application must be deleted. 

#### Note

Source topic: `en_EN/common_notes/note_c_2501.dita`

Note:

When an ROE issued under the permanent SIN contains a period of employment during which the client had a 900-series SIN, proof of the authorization to work in Canada is required for this period. 

#### Note

Source topic: `en_EN/common_notes/note_c_2503.dita`

Note:

All ROEs used to calculate the claim are entered as interim ROEs with the new SIN. An ROE under the 900-series SIN with the status Void - Not Insurable following a Canada Revenue Agency (CRA) insurability ruling must also be entered as an interim ROE under the new SIN with the status Void - Not Insurable . 

#### Note

Source topic: `en_EN/common_notes/note_c_2499.dita`

Note:

It is the client’s responsibility to provide the new SIN to the employer. Do not provide the new SIN to the employer. 

#### Note

Source topic: `en_EN/common_notes/note_c_1564.dita`

Note:

When sending a copy of an original letter, print the letter locally. For instructions on printing locally while teleworking, refer to Telework: Printing documents locally — Instructions .
       [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml)

     [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2504.dita`

Note:

A claim can be established with an expired SIN, but a D15 must be imposed to prevent payment of benefits until a valid SIN is provided. 

## Policy reference

Source topic: `en_EN/task/change_sin_init4more/policy_reference.dita`

 
