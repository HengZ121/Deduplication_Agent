# Adjudicating entitlement to benefits: Labour dispute — Level 2

Source map: `en_EN/task/adjudicating_eb_ldl2/adjudicating_eb_ldl2.ditamap`

## Summary

Source topic: `en_EN/task/adjudicating_eb_ldl2/summary.dita`

Summary: When clients stop working due to a labour dispute, their entitlement to benefits may be affected. Adjudication is required to determine the client’s entitlement to benefits during the labour dispute. 

## What you need to know

Source topic: `en_EN/task/adjudicating_eb_ldl2/what_you_need_to_know.dita`

### Entitlement to benefits during a labour dispute

Source topic: `en_EN/task/adjudicating_eb_ldl2/entitlement_to_benefits_during_a_labour_dispute.dita`

A labour dispute is any dispute between employers and employees or between the employees themselves. A labour dispute can be related to employment or non-employment, or to the terms and conditions of employment.

Regardless of whether the labour dispute was initiated by a strike or a lockout, the impact on the claim remains the same. When clients lose their employment or are unable to return to work due to a work stoppage resulting from a labour dispute at their place of employment, they are not entitled to EI benefits under the EIA.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0123.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1719.dita) 

### Adjudicating a labour dispute

Source topic: `en_EN/task/adjudicating_eb_ldl2/adjudicating_a_labour_dispute.dita`

When regional coordinators make decisions concerning labour disputes, they are entered in Major Employer Events . The officer must review the regional adjudication of the labour dispute prior to taking any action on the claim. If additional adjudication is required, the officer can refer to Digest 8 — Labour Dispute .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596) 
       [Digest 8 — Labour Dispute](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0124.dita) 

If the labour dispute has been posted in Major Employer Events and officers require assistance determining entitlement, they contact their regional Business Expertise .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

Since a labour dispute is a temporary situation, the officer imposes a disentitlement rather than a disqualification.

The 5 - Labour dispute disentitlement (D5) is imposed to indicate the period of the labour dispute. The client is disentitled for any days of work stoppage due to a labour dispute during the benefit period (BP) until one of the following occurs:

- The labour dispute ends.

- The client becomes regularly engaged elsewhere in insurable employment.

Clients are not disentitled from benefits if they prove that all of the following exception conditions are met:

- They are not participating in the labour dispute.

- They are not financing the labour dispute.

- They have no direct interest in the labour dispute.

A disentitlement is terminated the day before the date on which the client meets all of the exempting conditions. When a client no longer meets at least one of the exempting conditions, a disentitlement must be imposed from that day.

For doubtful cases involving clients who state that they do not have a direct interest in or are not financing or participating in the labour dispute, the officer must consult with the regional coordinator in order to ensure that decisions are consistent. 

### Suspending or terminating the disentitlement

Source topic: `en_EN/task/adjudicating_eb_ldl2/suspending_or_terminating_the_disentitlement.dita`

When clients prove they meet certain conditions and are entitled to benefits, the disentitlement may be suspended or terminated.

**Special benefits and referred training**

A disentitlement is suspended if clients establish that they are otherwise entitled to benefits. The clients must prove that they had begun to make the necessary arrangements for leave from their employment before the work stoppage, for any of the following reasons:

- maternity leave

- parental leave

- compassionate care leave

- family caregiver leave

- sickness

- referred training

**Employed elsewhere**

When a client begins working elsewhere during a labour dispute, a Level 2 officer must render a decision on whether the D5 can be terminated. Both of the following conditions must be met for the D5 to be terminated:

- The employment is insurable.

- The client is regularly employed in insurable employment at a place other than where the labour dispute exists.

For more information, refer to Digest 8 — Labour disputes .
       [Digest 8 — Labour disputes](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1720.dita) 

**Termination of employment**

During a labour dispute, if clients decide to voluntarily leave their employment or are dismissed by the employer, the officer must determine if they meet the conditions to terminate the disentitlement.

The officer must take into account that it is not because the employer-employee relationship has been severed that a client becomes entitled to benefits. It is the absence of direct interest, participation and financing in the labour dispute that must be reviewed to determine a client’s entitlement to benefits.

If the officer determines the client is entitled to benefits during the labour dispute, the officer must adjudicate the RFS before terminating the disentitlement.

Indicators that confirm that the severance of the employer-employee relationship is complete and final include:

- termination of individual employment;

- payment of amounts due on termination of employment;

- loss of all rights of recall and employment-related benefits;

- the employee’s status in the company;

- the reasons for the severance of employment given by the employer (e.g. incompetence, misconduct not related to the dispute);

- the reasons for the severance given by the client.

Indicators that cast doubt on the complete and final severance of the employer-employee relationship include:

- a simultaneous resignation or lay-off of several workers;

- a long period of employment tied in with benefits such as a pension;

- neither the employer nor employee has taken the appropriate steps to make the termination of employment final;

- the client is still a member of the union in dispute with the employer. 

### Imposing the disentitlement for a part-time employee

Source topic: `en_EN/task/adjudicating_eb_ldl2/imposing_the_disentitlement_for_a_part-_4bcf6773.dita`

When a client loses or is unable to resume part-time employment due to a labour dispute, the officer must create an Operational Centre Memo (MM06) to advise IPOC to impose a partial D5. 

### Note

Source topic: `en_EN/common_notes/note_c_0123.dita`

Note:

When the reason for separation (RFS) on the ROE is Strike or Lockout , the initial claim is not automated and a Claim Assessment (CA) WI is created. 

### Note

Source topic: `en_EN/common_notes/note_c_1719.dita`

Note:

A labour dispute has no impact on an initial claim when the period of the work stoppage both occurs and ends during the qualifying period (QP). Any insurable hours accumulated from the employment during the QP are included in the calculation of the claim. A work stoppage due to a labour dispute results in a disentitlement for the period of the dispute, but a disentitlement does not apply in the QP. When it is determined that the labour dispute both occurred and ended in the QP, no further adjudication of the issue is required. 

### Note

Source topic: `en_EN/common_notes/note_c_0124.dita`

Note:

If the employer’s head office is located in the Western Canada and Territories region and a labour dispute has not been entered in Major Employer Events , officers working in the Western Canada and Territories region send the Labour dispute initial information form to the Technical Expertise Request Application (TERA), not to the regional coordinator.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx)

Officers in all other regions email the Labour dispute initial information form only to the regional labour dispute coordinator for the region where the employer’s head office is located, via the regional Business Expertise Consultant’s GD mailbox.
       [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
       [regional labour dispute coordinator](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml)

     [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1) 
     [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
     [Labour dispute initial information](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Form-FormLabourDisputeInitialInfo-2025Mar24-E-Final.docx) 
     [regional labour dispute coordinator](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1720.dita`

Note:

When in doubt of the validity of the other employment, the officer must contact the client and complete the Subsequent employment — Labour dispute questionnaire (INS3619) form. Once the form has been completed, the officer attaches it to an email and sends it to the appropriate regional coordinator for assistance with making the decision.
       [Subsequent employment — Labour dispute questionnaire (INS3619)](http://forms-formulaires.prv/lc/apps/EForms/pdf/en/ESDC-INS3619.pdf) 
       [regional coordinator](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml)

     [Subsequent employment — Labour dispute questionnaire (INS3619)](http://forms-formulaires.prv/lc/apps/EForms/pdf/en/ESDC-INS3619.pdf) 
     [regional coordinator](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml) 

## Regional considerations

Source topic: `en_EN/task/adjudicating_eb_ldl2/regional_considerations.dita`

Atlantic and Western Canada and Territories regions: For events before May 14, 2018, the decisions concerning labour disputes can be found in the following databases:

- Atlantic region: Documents are stored in the regional common document share under EI Document Library / Employer Info / Labour Disputes

- Western Canada and Territories region: WT regional site
         [WT regional site](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/labour-memos.shtml)

Western Canada and Territories region: Officers in the Western Canada and Territories region send any request that requires a review (to determine the validity of information or the client’s entitlement to benefits) to the Technical Expertise Request Application. For more information on how to access the Technical Expertise Request Application, the officer refers to Business Expertise Advisor Enquiries .
       [Business Expertise Advisor Enquiries](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/bea-enquiries.shtml)

Atlantic region: Officers in the Atlantic region send any request that requires a case review (in order to determine the validity of information or the client’s entitlement to benefits) to the Business Expertise Request Tool .
       [Business Expertise Request Tool](https://dialogue.spprod.service.gc.ca/grp/Na-Bea-Cseo/LibPpsStp/WpTabOngletPpsStpEiAe.aspx) 

## What you need to look for

Source topic: `en_EN/task/adjudicating_eb_ldl2/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/adjudicating_eb_ldl2/in_nws.dita`

- Are there any documents, SROCs, RODs or WIs containing documents relating to the labour dispute?

- Are there any documents, SROCs, RODs or WIs containing documents relating to an otherwise entitled to benefits issue?

- Are there any documents, SROCs, RODs or WIs containing documents relating to a request to be exempt from the labour dispute disentitlement?

- Are there any documents, SROCs, RODs or WIs containing documents relating to the termination of employment issue?

- Are there any documents, SROCs, RODs or WIs containing documents relating to other insurable employment? 

### In FTS:

Source topic: `en_EN/task/adjudicating_eb_ldl2/in_fts.dita`

- Is there a D5 already on file?

- Is there a 74 - Labour dispute manual action (MA74) imposed on the file?

- Is the claim type initial, renewal or continuing? 

### In Imaging:

Source topic: `en_EN/task/adjudicating_eb_ldl2/in_imaging.dita`

- Are there any imaged documents relating to the labour dispute?

- Are there any imaged documents relating to an otherwise entitled to benefits issue?

- Are there any imaged documents relating to a request to be exempt from the labour dispute disentitlement?

- Are there any imaged documents relating to the termination of employment issue?

- Are there any imaged documents relating to other insurable employment? 

### In the MEE — Information Bulletin:

Source topic: `en_EN/task/adjudicating_eb_ldl2/in_the_mee__information_bulletin.dita`

- Is there any information relating to the labour dispute? 

## Step by step

Source topic: `en_EN/task/adjudicating_eb_ldl2/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/adjudicating_eb_ldl2/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/adjudicating_eb_ldl2/reviewing_the_file_level_2.dita`

- Determine if adjudication can be deferred.

- If no, go to step 2.

- If yes, refer to Deferral of adjudication .
               [Deferral of adjudication](/en/procedure/activity/deferral_adj.shtml)

- Review the Major Employer Events database to determine if the labour dispute both occurred and ended in the QP:

- If no or if the labour dispute has not been entered in Major Employer Events , go to step 3.
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

- If yes, go to Labour dispute in the qualifying period (QP) only .
               [Labour dispute in the qualifying period (QP) only](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_eb_ldl2#LabourDisputeinQPOnlyNotLastEmployment)

- In FTS, determine if it is an initial, a renewal or a continuing claim:

- If it is a renewal claim, go to step 4.

- If it is an initial or a continuing claim, go to step 6.

- Review Major Employer Events to determine if the labour dispute occurred and ended before the renewal week:

- If yes, go to step 5.

- If no or if the labour dispute has not been entered in Major Employer Events , go to step 6.
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1)

- In NWS, determine if the client is requesting benefits during the period of the labour dispute:

- If yes, go to step 6.

- If no, go to Labour dispute before the renewal week .
               [Labour dispute before the renewal week](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_eb_ldl2#_Labour_dispute_prior)

- Determine if there is enough information in Major Employer Events and from the client to adjudicate the labour dispute issue:

- If additional information is needed from the client, go to step 7.

- If no additional information is needed, go to step 10.

- If the Major Employer Events is not complete, send an email to the regional labour dispute coordinator for more information, move the WI to Pending until a response is received, and then repeat step 6.
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596) 
               [regional labour dispute coordinator](https://esdc.prv/en/service-canada/ei/contacts/coordinator_labour_dispute.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1721.dita) 

#### Fact-finding

Source topic: `en_EN/task/adjudicating_eb_ldl2/fact-finding_level_2.dita`

- Fact-find with the client. Refer to Digest 8 — Labour dispute .

- Determine if the client was contacted during fact-finding:

- If yes, go to step 9.

- If no, go to step 10.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- New SROC: Main Issue: Select Other .

- New SROC: Comments: Type “labour dispute — [Employer’s name] — entitlement to benefits.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudication

Source topic: `en_EN/task/adjudicating_eb_ldl2/adjudication_level_2.dita`

- Determine if the case raises any doubts as to the client’s entitlement:

- If yes, go to step 11.

- If no, go to step 14.

- In Outlook, create and send an email to the appropriate regional labour dispute coordinator with a request to review the case and determine the validity of the information as well as the client’s entitlement to EI benefits during the labour dispute (if necessary, attach the INS3619 form).

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1722.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Request sent to the regional coordinator to review case and determine validity of the information as well as client’s entitlement to EI benefits during the labour dispute.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if a decision has been made for this particular case:

- If no, return to step 12.

- If yes, go to step 14.

- Determine if the client is entitled to benefits during the labour dispute considering all evidence provided by the client or employer. Refer to Digest 8 — Labour dispute as needed. 

#### Inputs and communication

Source topic: `en_EN/task/adjudicating_eb_ldl2/inputs_and_communication_level_2.dita`

- Determine if the client is a part-time employee:

- If no, go to step 16.

- If yes, go to step 17.

- In FTS, determine the decision and if it is an initial, renewal or continuing claim:

- If this is an initial or renewal claim and entitlement is proven, go to Entitlement proven — Initial or renewal claim .
               [Entitlement proven — Initial or renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_eb_ldl2#proveninitren)

- If this is a continuing claim and entitlement is proven, go to Entitlement proven — Continuing claim .
               [Entitlement proven — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_eb_ldl2#provencont)

- If this is an initial or renewal claim and entitlement is not proven, go to Entitlement not proven — Initial or renewal claim .
               [Entitlement not proven — Initial or renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_eb_ldl2#notproveninit)

- If this is a continuing claim and entitlement is not proven, go to Entitlement not proven — Continuing claim .
               [Entitlement not proven — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_eb_ldl2#notprovencont)

- In FTS, determine the decision and claim type:

- If this is an initial or renewal claim and entitlement is proven, go to Entitlement proven — Part-time employment on an initial or renewal claim .
               [Entitlement proven — Part-time employment on an initial or renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_eb_ldl2#provenptinit)

- If this is a continuing claim and entitlement is proven, go to Entitlement proven — Part-time employment on a continuing claim .
               [Entitlement proven — Part-time employment on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_eb_ldl2#provenptcont)

- If this is an initial or renewal claim and entitlement is not proven, go to Entitlement not proven — Part-time employment on an initial or renewal claim .
               [Entitlement not proven — Part-time employment on an initial or renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_eb_ldl2#notprovenptinit_renewal)

- If this is a continuing claim and entitlement is not proven, go to Entitlement not proven — Part-time employment on a continuing claim .
               [Entitlement not proven — Part-time employment on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_eb_ldl2#notprovenptcont) 

#### Labour dispute in the qualifying period (QP) only

Source topic: `en_EN/task/adjudicating_eb_ldl2/labour_dispute_in_the_qualifying_period_qp_only_level_2.dita`

- In NWS, determine if there is a ROD on file for the labour dispute.

- If no, go to step 2.

- If yes, go to step 3.

- Create a ROD as follows:

- Comments: Type “Labour dispute — Work stoppage entirely in the qualifying period.”

- Details: Type “Labour dispute for [employer’s name] both occurred and ended during the qualifying period. A disentitlement does not apply.”

- Select Save .

- Complete the WI for the labour dispute issue. 

#### Labour dispute before the renewal week

Source topic: `en_EN/task/adjudicating_eb_ldl2/labour_dispute_before_the_renewal_week_level_2.dita`

- In NWS, determine if there is a ROD on file for the labour dispute.

- If no, go to step 2.

- If yes, go to step 3.

- Create a ROD as follows:

- Comments: Type “Labour dispute — before the renewal week — no benefits requested.”

- Details: Type “Labour dispute for [employer’s name] both occurred and ended before the renewal week and the client is not requesting benefits for the period of the work stoppage. A disentitlement does not apply.”

- Select Save .

- Complete the WI for the labour dispute issue. 

#### Entitlement proven — Initial or renewal claim

Source topic: `en_EN/task/adjudicating_eb_ldl2/entitlement_proven__initial_or_renewal_claim_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Employer’s name] — entitlement proven during the labour dispute.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy and Digest 8 — Labour dispute .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 
               [Digest 8 — Labour dispute](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.shtml)

- Select Save .

- Determine if this is a renewal claim:

- If yes, go to step 3.

- If no, go to step 11.

- In FTS, determine if a D5 is imposed on the claim:

- If yes, go to step 4.

- If no, go to step 11.

- Select the Disqualifications/Disentitlements link and terminate the D5 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualification/Disentitlements (M161) transaction opens, complete the following fields:

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration open for subsequent transactions.

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Labour Dispute Disentitlement Suspended (2592) .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In ACS, inform the employer of the decision by sending a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved claim of employee or former employee .

- Reason for Claim Approval (2783):

- Select the appropriate option.

- Messages to Yer - Monies paid to client and Benefits rate for SUB (2788):

- Select Warning to ER: To inform us if pays any monies to employee .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding Correspondence (COR) Manual Decision WI:

- If no, go to step 9.

- If yes, go to step 11.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 10.

- If yes, go to step 11.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-01 letter required — labour dispute issue.”

- Select Save .

- In NWS, complete the Adjudication Issue (ADJ) WI for the labour dispute issue. 

#### Entitlement proven — Continuing claim

Source topic: `en_EN/task/adjudicating_eb_ldl2/entitlement_proven__continuing_claim_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Employer’s name] — entitlement proven during the labour dispute.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy and Digest 8 — Labour dispute .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 
               [Digest 8 — Labour dispute](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.shtml)

- Select Save .

- In FTS, determine if there is a D5 or an MA74 imposed on the claim:

- If there is a D5 imposed, go to step 3.

- If there is no D5 but there is an MA74 imposed, go to step 4.

- If there is no D5 and no MA74 imposed, go to step 5.

- Select the Disqualifications/Disentitlements (M106) transaction and terminate the D5 as follows:

- Registration number : Select the appropriate registration number.

- Action: Select Terminate/Modify .

- Disentitlement: Select 5 - Labour dispute .

- End date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 6.

- Select the Disqualifications/Disentitlements (M106) transaction and remove the MA74 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 74 - Labour dispute .

- Rescind: Check the box.

- Contentious: Select 2 -Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 8.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 8.

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Labour Dispute Disentitlement Suspended (2592) .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In ACS, inform the employer of the decision by sending a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved claim of employee or former employee .

- Reason for Claim Approval (2783):

- Select the appropriate option.

- Messages to Yer - Monies paid to client and Benefit rate for SUB (2788):

- Select Warning to ER: To inform us if pays any monies to employee .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI for the labour dispute issue. 

#### Entitlement not proven — Initial or renewal claim

Source topic: `en_EN/task/adjudicating_eb_ldl2/entitlement_not_proven__initial_or_renewal_claim_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Employer’s name] — entitlement not proven — D5 imposed.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy and Digest 8 — Labour dispute .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 
               [Digest 8 — Labour dispute](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.shtml)

- Select Save .

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose the D5 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 5 - Labour dispute .

- Start date: Enter the disentitlement start date displayed in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

- End date: Select indefinite or enter the disentitlement end date, if known.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement.

- 4 - An overpayment resulted due to an indefinite disentitlement.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 4.

- If the client was not reached by telephone during fact-finding, go to step 5.

- Verbally communicate the decision to the client.

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D5, D12, D13, D14, D23 (3011): Select D5 .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 8.

- If yes, go to step 10.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 9.

- If yes, go to step 10.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — labour dispute issue.”

- Select Save .

- In NWS, complete the WI for the labour dispute issue. 

#### Entitlement not proven — Continuing claim

Source topic: `en_EN/task/adjudicating_eb_ldl2/entitlement_not_proven__continuing_claim_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Employer’s name — entitlement not proven — D5 imposed.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy and Digest 8 — Labour dispute .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 
               [Digest 8 — Labour dispute](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.shtml)

- Select Save .

- In FTS, determine if there is a registration number for the labour dispute issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if there is a D5 or an MA74 imposed on the claim:

- If there is no D5 but there is an MA74 imposed, go to step 4.

- If there is no D5 and no MA74 imposed, go to step 5.

- If there is a D5 but no MA74 imposed, go to step 6.

- Select the Disqualifications/Disentitlements (M106) transaction to remove the MA74 and impose the D5 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 74 - Labour dispute .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 5 - Labour dispute .

- Start date: Enter the disentitlement start date displayed in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

- End date: Select indefinite or enter the disentitlement end date, if known.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement.

- 4 - An overpayment resulted due to an indefinite disentitlement.

- Contentious: Select 2 - Yes .

- Complete: Select C-Yes .

- Select Update .

- Go to step 8.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose the D5 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 5 - Labour dispute .

- Start date: Enter the disentitlement start date displayed in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

- End date: Select indefinite or enter the disentitlement end date, if known.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement.

- 4 - An overpayment resulted due to an indefinite disentitlement.

- Contentious: Select 2 - Yes .

- Complete: Select C-Yes .

- Select Update .

- Go to step 8.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 7.

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Decision Maintained (2576) .

- Decision Maintained - still cannot pay benefits .

- Right to Request a Reconsideration (with Blank option) (4169) .

- Go to step 11.

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 9.

- If the client was not reached by telephone during fact-finding, go to step 10.

- Verbally communicate the decision to the client.

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D5, D12, D13, D14, D23 (3011): Select D5 - Labour dispute .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, complete the WI for the labour dispute issue. 

#### Entitlement proven — Part-time employment on an initial or renewal claim

Source topic: `en_EN/task/adjudicating_eb_ldl2/entitlement_proven__part-time_employmen_2df88268_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Employer’s name] — entitlement proven during the labour dispute.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy and Digest 8 — Labour dispute .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 
               [Digest 8 — Labour dispute](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.shtml)

- Select Save .

- Determine if this is a renewal claim:

- If yes, go to step 3.

- If no, go to step 14.

- In FTS, determine if a D5 is imposed on the claim:

- If yes, go to step 4.

- If no, go to step 10.

- In FTS, determine if there is a registration number for the labour dispute issue:

- If yes, go to step 5.

- If no, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: 94 - Manual Action .

- Work type: 15 - Manual Action code 11, 12 or 14 .

- Remarks line 1: Type “Labour dispute — entitled to benefits.”

- Remarks line 2: Type “D5 to be terminated as of [date].”

- Remarks line 5: Enter your first name and last name.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Labour Dispute Disentitlement Suspended (2592) .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In ACS, inform the employer of the decision by sending a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved claim of employee or former employee .

- Reason for Claim Approval (2783):

- Select the appropriate option.

- Messages to Yer - Monies paid to client and Benefit rate for SUB (2788):

- Select Warning to ER: To inform us if pays any monies to employee .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 12.

- If yes, go to step 14.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 13.

- If yes, go to step 14.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-01 letter required — labour dispute issue.”

- Select Save .

- Complete the ADJ WI for the labour dispute issue. 

#### Entitlement proven — Part-time employment on a continuing claim

Source topic: `en_EN/task/adjudicating_eb_ldl2/entitlement_proven__part-time_employmen_b2c375bd_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Employer’s name] — entitlement proven during the labour dispute.”

- Details: Document the decision according to the information noted in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

- Select Save .

- In FTS, determine if there is a D5 or an MA74 imposed on the file:

- If there is a D5 but no MA74 imposed, go to step 3.

- If there is no D5 but there is an MA74 imposed, go to step 9.

- If there is no D5 and no MA74 imposed, go to step 11.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 94 - Manual Action .

- Work type: Select 15- Manual Action code 11, 12 or 14 .

- Remarks line 1: Type “Labour dispute — entitled to benefits.”

- Remarks line 2: Type “D5 to be terminated as of [date].”

- Remarks line 5: Enter your first name and last name.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Labour Dispute Disentitlement Suspended (2592) .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In ACS, inform the employer of the decision by sending a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved claim of employee or former employee .

- Reason for Claim Approval (2783):

- Select the appropriate option.

- Messages to Yer - Monies paid to client and Benefit rate for SUB (2788):

- Select Warning to ER: To inform us if pays any monies to employee .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In FTS, determine if there a registration number for the labour dispute issue:

- If yes, go to step 10.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Disqualifications/Disentitlements (M106) transaction and complete as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 74 - Labour dispute.

- Rescind: Check the box.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: C - Yes .

- Select Update .

- Complete the WI for the labour dispute issue. 

#### Entitlement not proven — Part-time employment on an initial or renewal claim

Source topic: `en_EN/task/adjudicating_eb_ldl2/entitlement_not_proven__part-time_emplo_9ab761ac_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Employer’s name] — entitlement not proven — D5 imposed.”

- Details: Document the decision according to the information noted in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

- Select Save .

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 11 - Part week disentitlement on a continuing basis .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 94 - Manual Action .

- Work type: Select 15 - Manual Action code 11, 12 or 14 .

- Remarks line 1: Type “Labour dispute — part-time employment.”

- Remarks line 2: Type “MA11, partial D5 to be imposed for [number] days per week starting [date] to [indefinite or disentitlement end date, if known].”

- Remarks line 5: Enter your first name and last name.

- Detection: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select 31 - Other new facts - entitlement review.

- In other cases, leave the field blank.

- Infraction: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select B - Non-fraud - Availability, capability.

- In other cases, leave the field blank.

- Message: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select 4 - An overpayment resulted due to an indefinite disentitlement.

- In other cases, leave the field blank.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 22.

- If the client was not reached by telephone during fact-finding, go to step 24.

- Verbally communicate the decision to the client.

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following

- Disentitlements (2976):

- D5, D12, D13, D14, D23 (3011): Select D5 - Labour dispute .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 11.

- If yes, go to step 13.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 12.

- If yes, go to step 13.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — labour dispute issue.”

- Select Save .

- In NWS, complete the ADJ WI for the labour dispute issue. 

#### Entitlement not proven — Part-time employment on a continuing claim

Source topic: `en_EN/task/adjudicating_eb_ldl2/entitlement_not_proven__part-time_emplo_247490a0_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Employer’s name] — entitlement not proven — D5 imposed.”

- Details: Document the decision and rationale according to the information noted in Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

- Select Save .

- In FTS, determine if there a registration number for the labour dispute issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 11 - Part week disentitlement on a continuing basis .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 94 - Manual Action .

- Work type: Select 15 - Manual Action code 11, 12 or 14 .

- Remarks line 1: Type “Labour dispute — part-time employment.”

- Remarks line 2: Type “MA11, partial D5 to be imposed for [number] days per week starting [date] to [indefinite or disentitlement end date, if known].”

- Remarks line 3: If necessary, type “MA74 to be rescinded.”

- Remarks line 5: Enter your first name and last name.

- Detection: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select 31 - Other new facts - entitlement review.

- In other cases, leave the field blank.

- Infraction: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select B - Non-fraud - Availability, capability.

- In other cases, leave the field blank.

- Message: Select the appropriate option:

- If it is a continuing claim and a MA74 must be rescinded, select 4 - An overpayment resulted due to an indefinite disentitlement.

- In other cases, leave the field blank.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 7.

- If the client was not reached by telephone during fact-finding, go to step 8.

- Verbally communicate the decision to the client.

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D5, D12, D13, D14, D23 (3011): Select D5 - Labour dispute .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, complete the WI for the labour dispute issue. 

#### Note

Source topic: `en_EN/common_notes/note_c_1721.dita`

Note:

The officer does not conduct any fact-finding with the employer or the union about the labour dispute. 

#### Note

Source topic: `en_EN/common_notes/note_c_1722.dita`

Note:

Officers in the Western Canada and Territories region send any request that requires a review (in order to determine the validity of information or the client’s entitlement to benefits) to the Business Expertise Advisor Enquiries .
       [Business Expertise Advisor Enquiries](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/bea-enquiries.shtml)

Officers in the Atlantic region send any request that requires a case review (in order to determine the validity of information or the client’s entitlement to benefits) to the Business Expertise Request Tool.

     [Business Expertise Advisor Enquiries](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/bea-enquiries.shtml) 

## Policy reference

Source topic: `en_EN/task/adjudicating_eb_ldl2/policy_reference.dita`

- EIA 12(3)
         [EIA 12(3)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIA 25
         [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- EIA 34
         [EIA 34](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-34.html)

- EIA 36
         [EIA 36](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-36.html)

- EIR 52(2)
         [EIR 52(2)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-52.html)

- Digest 8 — Labour disputes
         [Digest 8 — Labour disputes](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.html) 
