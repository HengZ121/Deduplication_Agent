# Processing a Claim Review Recalculation WI — Government of Canada ROE

Source map: `en_EN/task/cr_recalc_wi_goc_roe/cr_recalc_wi_goc_roe.ditamap`

## Summary

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/summary.dita`

Summary: A Claim Review (CR) Recalculation WI is created when a Government of Canada ROE is issued on behalf of departments serviced by the Public Service Pay Centre. The officer with the CR Recalculation WI reviews the file to determine if all the required ROE information is present to complete a final recalculation. 

## What you need to know

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2990.dita) 

### Recalculations

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/recalculations.dita`

A CR Recalculation WI is created when a missing or amended ROE is received.

Regardless of whether there is a related Action Item (AI) WI with Integrity Services, the officer reviews the CR WI to determine if the information required to recalculate the claim is on file. If ROE information is still required from the employer, the officer contacts the Client Contact Centre at 1-855-686-4729, selects a preferred language and presses 6 in the options menu.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2991.dita) 

The officer may be put on hold before the call is connected. Before initiating fact-finding, the officer must identify that he or she is an EI officer calling from Service Canada and confirm that the other person on the line is a Client Service Representative. If the Client Service Representative needs to conduct additional fact-finding to provide the requested information, the Client Service Representative calls the officer back within 24 hours of obtaining the information. If the Client Service Representative is unable to address the issue, the Client Service Representative calls and informs the officer that the inquiry has been escalated. The Public Service Pay Centre agent who resolves the issue calls the EI officer back.

If fact-finding with the employer is unsuccessful, the officer:

- sends the Z-02-00-00 letter;

- completes the related registration number; and

- completes the CR Recalculation WI.

Officers do not refer these claims to Integrity.

To avoid multiple recalculations, the officer recalculates the claim only when all of the required ROE information is present.

Another CR Recalculation WI is created if a new or amended ROE is subsequently received. 

### Note

Source topic: `en_EN/common_notes/note_c_2990.dita`

Note:

This procedure applies only if the CR Recalculation WI is for an ROE from a Government of Canada department serviced by the Public Service Pay Centre . For ROEs issued by government departments not serviced by the Public Service Pay Centre, normal fact-finding, ROE correction and recalculation procedures apply.
       [Government of Canada department serviced by the Public Service Pay Centre](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html)

The direct telephone line to conduct fact-finding with the Public Service Pay Centre’s Client Contact Centre is being gradually implemented according to the following schedule:

Western Canada and Territories Region: January 14, 2019 Ontario Region: February 11, 2019 Atlantic Region: February 25, 2019 Quebec Region: March 11, 2019

To process a CR Recalculation WI for an ROE from a Government of Canada department serviced by the Public Service Pay Centre before the telephone line is available, refer to Processing a Claim Review Recalculation WI — Government of Canada ROE (Archived).
       [Government of Canada department serviced by the Public Service Pay Centre](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html)

     [Government of Canada department serviced by the Public Service Pay Centre](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html) 
     [Government of Canada department serviced by the Public Service Pay Centre](https://www.tpsgc-pwgsc.gc.ca/remuneration-compensation/services-paye-pay-services/paye-centre-pay/calendrier-schedule-eng.html) 

### Note

Source topic: `en_EN/common_notes/note_c_2991.dita`

Note:

Although 6 is not listed in the options menu, by pressing it, the officer is directed to a Client Service Representative, who is dedicated to assisting Service Canada with ROE corrections. 

## Regional considerations

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/what_you_need_to_look_for.dita`

## Step by step

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/level_1.dita`

#### Procedure

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/procedure_level_1.dita`

- Determine if the ROE is from a government department that is serviced by the Public Service Pay Centre:

- If yes, go to step 2.

- If no, normal ROE correction and recalculation procedures apply. Return to the originating task or refer to the appropriate procedure to complete the CR Recalculation WI.

- Determine if any of the following conditions apply:

- Employer contact is required to verify or to correct the information on the ROE.

- An ROE has been issued that covers only a partial period of the employment declared by the client.

- A duplicate ROE has been issued for the same period of employment as a previously issued ROE.

- An ROE has been issued that partially overlaps a previously issued ROE.

- If any of the conditions apply, go to step 3.

- If none of the conditions apply, go to step 15.

- Fact-find with the employer. Contact the Client Contact Centre at 1-855-686-4729, select a preferred language and press 6 in the options menu. Once connected, identify that you are an EI officer calling from Service Canada and confirm that you are speaking to a Client Service Representative before initiating fact-finding.

- In NWS, create an SROC as follows:

- New SROC: Main Issue: Select ROE .

- New SROC: Comments: Type “Public Service Pay Centre fact-finding.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Draft .

- Determine if the employer provided the requested information:

- If no, go to step 6.

- If yes, go to step 12.

- Determine if the employer must conduct additional fact-finding to provide the requested information:

- If yes, go to step 7.

- If no, go to step 9.

- Move the CR WI to Pending as follows:

- Pending reason: Select ROE verification .

- Bring forward date: Enter today’s date + 1 working day.

- When the CR WI moves to the current workload, determine if the employer provided the requested information:

- If no, go to step 9.

- If yes, go to step 12.

- Determine if the enquiry requires escalation:

- If yes, go to step 10.

- If no, go to step 15.

- Move the CR WI to Pending as follows:

- Pending reason: Select ROE verification .

- Bring forward date: Enter today’s date + 2 working days.

- When the CR WI moves to the current workload, determine if the employer  provided the requested information:

- If yes, go to step 12.

- If no, go to step 13.

- In NWS, open the draft SROC and do the following:

- Details: Enter the information provided by the employer.

- Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 15.

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all the required attributes, including the following:

- Employer or Third Party Name (1334): Type “Public Services and Procurement Canada.”

- Employer or Third Party Address 1 (1336): Type “Public Service Pay Centre — Mail Facility.”

- Employer or Third Party Address 2 (2440): Type “PO Box 6500.”

- Employer or Third Party Address 3 (2441): Select Address in Canada .

- Employer or Third Party City (1340): Type “Matane.”

- Employer or Third Party Province (1342): Type “QC.”

- Employer or Third Party Postal Code or Zip Code (1344): Select Canada and type “G4W 0H6.”

- Employer Third Party Country (1346): Click Insert .

- Opening Sentence to ER to Request or Clarify ROE/RFS (2794) .

- Select Request ROE Opening Sentence - claimant .

- Request for a Record of Employment (2797) .

- Select Request for Additional ROE Information .

- Text - Free Text (1612): Enter the information required.

- Blank / Contact agent / Contact by Phone or mail (11326).

- In NWS, open the draft SROC and add the following:

- Details: Type “The employer has not provided the requested information. Z-02-00-00 letter sent.”

- Click Save .

- Go to Unable to recalculate the claim .
               [Unable to recalculate the claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cr_recalc_wi_goc_roe#UnabletoRecalculateClaim)

- Determine if all the required information and ROEs are on file to complete a final recalculation:

- If yes, go to step 16.

- If no, go to Unable to recalculate the claim .
               [Unable to recalculate the claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cr_recalc_wi_goc_roe#UnabletoRecalculateClaim)

- In RCM, if applicable, delete any interim ROEs that were issued to calculate the initial claim.

- Recalculate the claim and complete the CR Recalculation WI. If necessary, return to the originating task or refer to the applicable procedure:

- If the benefit type (BT) is regular, refer to Calculating or recalculating a claim for regular benefits .
               [Calculating or recalculating a claim for regular benefits](/en/procedure/activity/calculation.shtml)

- If the BT is sickness, refer to Calculating or recalculating a claim for sickness benefits .
               [Calculating or recalculating a claim for sickness benefits](/en/procedure/activity/calc_sick.shtml)

- If the BT is sickness, maternity and parental, refer to Calculating or recalculating a claim for sickness, maternity and parental benefits .
               [Calculating or recalculating a claim for sickness, maternity and parental benefits](/en/procedure/activity/calc_sick_mat_par.shtml)

- If the BT is maternity and parental, refer to Calculating or recalculating a claim for maternity and parental benefits .
               [Calculating or recalculating a claim for maternity and parental benefits](/en/procedure/activity/calc_mat_par.shtml)

- If the BT is parental, refer to Calculating or recalculating a claim for parental benefits .
               [Calculating or recalculating a claim for parental benefits](/en/procedure/activity/calc_par.shtml)

- If the BT is compassionate care, refer to Calculating or recalculating a claim for CCB .
               [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml)

- If the BT is family caregiver, refer to Calculating or recalculating a claim for family caregiver benefits .
               [Calculating or recalculating a claim for family caregiver benefits](/en/procedure/activity/calc_pcic_benefit.shtml) 

#### Unable to recalculate the claim

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/unable_to_recalculate_the_claim_level_1.dita`

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Click Update .

- In NWS, create a new SROC as follows:

- New SROC: Main Issue: Select ROE .

- New SROC: Comments: Type the appropriate option:

- "ROE from Government of Canada is missing."

- "ROE verification with Government of Canada is required."

- Details: Type the appropriate option:

- "ROE issued by Government of Canada on [date the ROE was issued]. The recalculation was not completed because another ROE required to cover the entire period of employment is missing. Waiting for the required ROE to complete the recalculation."

- "ROE issued by Government of Canada on [date the ROE was issued]. The recalculation was not completed because employer verification is required to complete the recalculation.”

- Click Save .

- Complete the CR Recalculation WI. 

## Policy reference

Source topic: `en_EN/task/cr_recalc_wi_goc_roe/policy_reference.dita`

 
