# Performing a reconsideration under EIA 112 related to EI ERB eligibility

Source map: `en_EN/task/perf-rec-eia112-eierb-cra/perf-rec-eia112-eierb-cra.ditamap`

## Summary

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/summary.dita`

Summary: When the reconsideration officer receives a request for reconsideration related to a decision on the client’s eligibility for the EI Emergency Response Benefit (EI ERB) or to the advance payment overpayment (OP), and the client could have been eligible for emergency benefits paid through the Canada Revenue Agency (CRA), the reconsideration officer determines if the client meets the eligibility criteria for the EI ERB. 

## What you need to know

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/untitled_section.dita`

**EI Emergency Response Benefit (EI ERB)**

The EI ERB was payable to clients requesting regular or sickness benefits who had a BPC between March 15, 2020, and September 27, 2020. Clients were eligible for up to 28 weeks of benefits at a weekly benefit rate of $500. The EI ERB was payable until October 3, 2020, and the last day clients were able to request the EI ERB was December 2, 2020.

The reconsideration officer refers to Review of an EI ERB claim and the EI ERB Digest for more information about the EI ERB.
       [Review of an EI ERB claim](/en/procedure/activity/reviewing_an_ei_erb_claim.shtml) 
       [EI ERB Digest](/en/policy/generic/ei_erb_digest.shtml) 

### Canada Emergency Student Benefit (CESB)

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/canada_emergency_student_benefit_cesb.dita`

The CESB provided financial support to post-secondary students and recent post-secondary and high school graduates who were unable to find work due to COVID-19. Students who received the CERB or EI ERB and were subsequently found to be ineligible are required to repay these benefits.

Students with a Canada Emergency Response Benefit (CERB) or EI ERB OP who can show that they would have met the eligibility criteria for the CESB are only required to repay $750 for each 4-week period that they were ineligible for CERB or EI ERB. In this situation, students with a disability or with dependants are not required to repay the debt. The CRA is responsible for determining whether the client could have been eligible for the CESB. The reconsideration officer only determines whether a client who was a student while receiving the EI ERB was eligible for the benefits received through Service Canada.

To request that their debts be reduced, students must apply and submit the required documentation to the CRA. The reconsideration officer refers clients who want more information to Student CERB debt reduction .
       [Student CERB debt reduction](https://www.canada.ca/en/revenue-agency/services/benefits/apply-for-cerb-with-cra/return-payment/student-cerb-debt.html)

If the eligibility criteria are met, the CRA determines how many periods of the CESB the client is eligible for. 

### EI Emergency Response Benefit (EI ERB) eligibility criteria

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/ei_emergency_response_benefit_ei_erb_el_e7478a53.dita`

Reconsideration officers review the eligibility criteria as outlined in the chart below to determine whether a client was eligible for the EI ERB. A client who meets the definition of a claimant under EIA 153.5(2) must also meet the corresponding eligibility criteria under EIA 153.9(1) .
       [EIA 153.5(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242424) 
       [EIA 153.9(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242424)

Definition of claimant — EIA 153.5(2)
       [EIA 153.5(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#1242442)

For the purposes of this section and sections 153.6 to 153.13, the definition of a claimant in subsection 2(1) applies to a person that falls into at least one of the following 4 categories. It is a person:

Eligibility — EIA 153.9(1)
       [EIA 153.9(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#1242533)

A claimant is eligible for the employment insurance emergency response benefit if they:

EIA 153.5(2)(a)
       [EIA 153.5(2)(a)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#1244363)

- who ceases working, whether employed or self-employed, for reasons related to COVID-19;

EIA 153.9(1)(a)
       [EIA 153.9(1)(a)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#1242534)

- reside in Canada;

- are at least 15 years of age;

- have insurable earnings of at least $5,000 in 2019 or in the 52 weeks preceding the day on which they make the claim under section 153.8;

- whether employed or self-employed, cease working for at least seven consecutive days within the two-week period in respect of which they claimed the benefit; and

- have no income from employment or self-employment in respect of the seven consecutive days on which they cease working.

EIA 153.5(2)(b)
       [EIA 153.5(2)(b)](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/page-23.html#1257848)

- who could have had a benefit period established ( EIA 7 (2) ) on or after March 15, 2020 with respect to any of the benefits referred to in paragraph (3)(a) (regular, sickness, and sickness benefits for the self-employed).
         [EIA 7 (2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-2.html#215835)

EIA 153.9(1)(b)
       [EIA 153.9(1)(b)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#1244379)

- they have no income from employment or self-employment for at least seven consecutive days within the two-week period in respect of which they claimed the benefit.

EIA 153.5(2)(c)
       [EIA 153.5(2)(c)](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/page-23.html#1244365)

- who is unable to start working for reasons related to COVID-19 and to whom, at any time during the period beginning on December 29, 2019, and ending on October 3, 2020, at least one benefit referred to in paragraph (3)(b) [ regular benefits ] has been paid or was payable, if, during that period:

- the established benefit period of that person with respect to those benefits has ended;

- all of those benefits have been paid to that person; or

- some of those benefits cannot be paid to that person by virtue of subsection 12(6);

EIA 153.5(2)(d)
       [EIA 153.5(2)(d)](https://laws-lois.justice.gc.ca/eng/acts/e-5.6/page-23.html#1245232)

- who is unable to start working for reasons related to COVID-19 and to whom, at any time during the period beginning on December 29, 2019, and ending on October 3, 2020, at least one benefit referred to in paragraph (3)(c) [ fishing benefits ] has been paid or was payable, if, during that period:

- the established benefit period of that person with respect to those benefits has ended;

- all of those benefits have been paid to that person; or

- some of those benefits cannot be paid to that person by virtue of subsection 8(18) of the Employment Insurance (Fishing) Regulations .
             [Employment Insurance (Fishing) Regulations](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-445)

EIA 153.9(1)(c)
       [EIA 153.9(1)(c)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#1244380)

- they are a claimant referred to in paragraph 153.5(2)(c) or (d) and they:

- reside in Canada;

- are at least 15 years of age;

- have insurable earnings of at least $5,000 in 2019 or within the 52 weeks preceding the day on which they make the claim under section 153.8; and

- have no income from employment or self-employment for at least seven consecutive days within the two-week period in respect of which they claimed the benefit. 

### Levels of Decision

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/levels_of_decision.dita`

A Level 1 officer can render the decision to maintain, modify or rescind an initial decision related to an EI ERB claim when:

- A request for reconsideration was received under section 112 of the EIA; and

- the request for reconsideration is related to a decision on an EI ERB claim under EIA 153.5(2) and 153.9(1), (2) or (4); and

- a Level 1 officer rendered the decision; or

- an Integrity Program Services Officer or Integrity Services Officer rendered the decision on an EI ERB investigation under EIA 153.5(2) and 153.9(1), (2) or (4); and

- the officer making the decision has been formally trained in requests for reconsideration; and

- the request for reconsideration was received within the prescribed 30-day timeframe; or

- if the request for reconsideration was delayed, but was received no more than 120 days after the client was notified of the initial decision; and

- there are no contentious issues related to the EI ERB claim that would prevent the Level 1 from rendering a decision; and

- there is no ongoing Integrity EI ERB investigation.

Only a Level 2 officer can render the decision when the disentitlement was imposed beyond 36 months.

**Reviewing the reconsideration timeframe**

The reconsideration officer confirms if false statements were made and whether the initial decision was made within the 36-month or 72-month reconsideration timeframe according to EIA 52, which is adapted for EI ERB under EIA 153.6(1)(a).

When determining whether conditions have been met to extend the reconsideration timeframe to 72 months, the officer reviews each 2-week period separately. It is possible that the officer determines that the reconsideration timeframe can be extended for one 2-week period but not for another.

When the original decision was made outside of the reconsideration timeframe, the officer completes the necessary inputs to remove the decision for the weeks that fall outside of the reconsideration timeframe and documents this decision in a record of decision (ROD) (e.g. false statements are not present, but a 31 - EI ERB entitlement conditions not met disentitlement [D31] was imposed outside of the 36-month reconsideration timeframe). 

### Determining the client’s eligibility for the EI Emergency Response Benefit (EI ERB)

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/determining_the_clients_eligibility_for_bedc887d.dita`

If a client meets any of the eligibility criteria in the first week of the EI ERB claim period, no further review is required and the officer considers that the eligibility criteria are met, as long as there are no other circumstances that would make the client ineligible. When the client meets the EI ERB eligibility criteria and the request for reconsideration is related to the advance payment OP, the officer refers to Performing a reconsideration under EIA 112 related to the advance payment to determine if the advance payment OP can be reconciled.
       [Performing a reconsideration under EIA 112 related to the advance payment](/en/procedure/task/performing_reconsideration_under_eia_112_eierb_apo.shtml)

If the client was not eligible in the first week of the EI ERB period, the officer continues to review all subsequent weeks to determine if the eligibility criteria are met in later weeks.

If the client meets the eligibility criteria in a later week and there are no other circumstances that would make the client ineligible, EI ERB is allowed from the week the client is eligible. A D31 is imposed for the period the client did not meet the eligibility criteria. When eligibility has not been proven and the client could have been eligible for CESB, the reconsideration officer creates the OP and refers the client to the CRA for a Student CERB debt reduction .
       [Student CERB debt reduction](https://www.canada.ca/en/revenue-agency/services/benefits/apply-for-cerb-with-cra/return-payment/student-cerb-debt.html) 

### Determining if the client otherwise qualifies for EI benefits

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/determining_if_the_client_otherwise_qua_c9940911.dita`

If a client does not meet the definition of an EI ERB claimant according to EIA 153.5(2)(a), (c) or (d) and the matching criteria under EIA 153.9(1)(a) or (c), the officer determines if the client otherwise qualifies for regular or sickness benefits during the EI ERB period. The number of hours required to qualify for EI benefits depends on whether a temporary measure is in place during the week being reviewed:

- If the week being reviewed is between w/c 2230 and w/c 2250, the client must have met the VER or worked 600 insurable hours.

- If the week being reviewed is between w/c 2251 and w/c 2257, the client must have worked 420 insurable hours.

- If the week being reviewed is only in w/c 2258, the client must be able to demonstrate the EI ERB eligibility in an earlier week in order to establish an EI ERB claim for the w/c 2258.

- If the client has a violation, there can be increased entrance requirements .
         [increased entrance requirements](/en/procedure/generic/additionalresources/increased_entrance_requirements.shtml)

When determining if the client qualifies, the officer obtains the appropriate regional rate of unemployment (RRU) for the week being reviewed to ensure an accurate result. The officer determines the number of hours in the qualifying period (QP) based on information in ROEs, interim ROEs, the Employment History File, etc. The officer determines if a QP extension can be granted to allow the client to qualify for benefits.

Since entitlement is not a consideration for EI ERB, the client is not required to submit a medical certificate or other proof of entitlement to sickness benefits. If the client has an interruption of earnings (I of E) and meets the hours requirement for regular or sickness benefits, the client otherwise qualifies for EI benefits.

**Reviewing documents in the Integrity Investigation Document Upload System**

When the request is related to a D31 imposed by Integrity, the officer reviews documents submitted during the investigation in the Integrity Investigation Document Upload System, including the client’s response to the C-74-01-03 or C-74-01-06 letter.

To request access to the Integrity Investigation Document Upload System, the officer sends an email to esdc.isb.bso-dgsi.ssa.edsc@servicecanada.gc.ca with the following details:
       [esdc.isb.bso-dgsi.ssa.edsc@servicecanada.gc.ca](mailto:ESDC.ISB.BSO-DGSI.SSA.EDSC@servicecanada.gc.ca)

- Request type: Viewing documents only

- Name: [officer’s name]

- Email address: [officer’s email address]

- Program: EI

The officer selects Employment Insurance (EI) on the Program Selection screen and searches for the document using the SIN or investigation number. 

### Advance payment overpayments (OPs)

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/advance_payment_overpayments_ops.dita`

If it was determined that the client did not serve some or all 4 weeks of the 65 - Lump Sum Payment ($2000) - Canadian Emergency Response code (D65), the system created an OP for the full or partial amount of the advance payment.

Some clients may not have realized the need to complete claimant’s reports to confirm their eligibility for the advance payment or purposefully did not complete claimant’s reports to avoid being overpaid. If no claimant’s reports were completed, an OP was created.

An SROC with “ CERB advance payment OP ” indicated in the Comments field was added to the files of affected clients. All clients identified by the system as having an OP received a letter explaining the decision and their reconsideration rights, along with a Notice of Debt explaining the OP amount. The officer accesses PSCD to view the Notice of Debt.

Instead of repaying the advance payment OP amount to Service Canada, clients may request that eligible weeks in the EI ERB period be applied against the OP. In order to use eligible weeks from the EI ERB period to reconcile the advance payment OP, the officer ensures that the claim meets the conditions set out in Advance Payment Reconciliation policy .
       [Advance Payment Reconciliation policy](/en/policy/generic/ei_erb_digest.shtml#ch_6_2) 

### Reconsidering EI Emergency Response Benefit (EI ERB) eligibility when there is an ongoing request for reconsideration related to the advance payment overpayment (OP)

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/reconsidering_ei_emergency_response_ben_4ac54448.dita`

The officer considers the eligibility review to be inherently linked to the advance payment issue. If there is any indication in NWS or on the Reconsideration: INS5210 Request for reconsideration of an E) decision — Form (INS5210) that the reconsideration request is related to the advance payment OP, the officer first determines eligibility for the whole period that the client received the EI ERB. If the officer determines that the client is not eligible for the EI ERB, the officer ensures the decision will be made in the appropriate reconsideration timeframe and either maintains the eligibility decision or imposes a retroactive D31 and also maintains the decision related to the reconciliation of the advance payment OP. 

### Inherently linked EI Emergency Response Benefit (EI ERB) eligibility and advance payment overpayment (OP) requests filed on separate dates

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/inherently_linked_ei_emergency_response_3af37a51.dita`

When requests related to the advance payment OP and EI ERB eligibility were filed on separate dates, the officer first determines whether either of the requests were delayed. If there is any indication of a delayed request, the officer chooses the period of delay that is most beneficial to the client.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3954.dita) 

The officer requests the deletion of one of the ADMS records and the related request for reconsideration (RFR) WI. 

### Insurability ruling required when the client declares an employment out of Canada

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/insurability_ruling_required_when_the_c_d018a1c4.dita`

When determining the client’s eligibility to the EI ERB under EIA 153.9(1)(a) or (c), the officer must determine whether the declared earnings are insurable or not. When the client provides a proof of work for an employment out of Canada, and the client requires these earnings to meet the $5 000 income requirement, the officer requests a CRA ruling on the insurability of this employment. 

### Determining if an overpayment (OP) can be written off

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/determining_if_an_overpayment_op_can_be_0b279491.dita`

When processing a request for reconsideration involving an OP, the officer reviews the file to ensure that the criteria to write off the OP were considered. If the write-off criteria were not considered, the officer refers to Detecting if Level 2 adjudication is required for a potential overpayment write-off - Level 1 to determine whether the criteria to write-off the OP are met.
       [Detecting if Level 2 adjudication is required for a potential overpayment write-off - Level 1](/en/procedure/task/determining_conditions_wo_op.shtml)

When the Level 1 reconsideration officer reviews for a possible write-off and determines that the criteria are not met to write off the OP, the officer creates an SROC to document the reason the file was not referred to Level 2 for adjudication. When the criteria are met, the Level 1 officer creates an Action Item (AI) WI for a Level 2 reconsideration officer to make a decision regarding the write-off.

The Level 2 reconsideration officer is responsible for adjudicating the write-off and documenting the decision and rationale in an ROD. For information on adjudicating an OP write-off, the Level 2 officer refers to Adjudicating a write-off - Level 2 .
       [Adjudicating a write-off - Level 2](/en/procedure/task/adjudicating_write_off.shtml) 

### Reassigning the WI

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/reassigning_the_wi.dita`

If necessary, the officer reassigns the RFR WI as follows:

- When the client had self-employment (SE) earnings, the officer reassigns the WI to the level 7 - National RFR and Appeals / Specialized RFR Processing / RFR EI ERB Eligibility / Self Employment in NWS only if fact-finding confirms both of the following situations:

- The client was not eligible for EI ERB based on the insurable employment requirement.

- The client had $5 000 in SE earnings or could have met the earnings requirement with a combination of insurable earnings and SE earnings.

         [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3955.dita)

- When there is evidence on file that the client’s income exceeds $1 000 over a 4-week period, the officer reassigns the WI to the level 7 - National RFR and Appeals / Specialized RFR Processing / RFR EI ERB Earnings over $1000 in NWS . 

### Example

Source topic: `en_EN/common_notes/note_c_3954.dita`

Example:

The EI ERB eligibility request is delayed but there is a separate advance payment OP request that was submitted in a timely manner. The officer considers the EI ERB request to have been submitted in a timely manner and does not review the period of delay for any of the issues. 

### Note

Source topic: `en_EN/common_notes/note_c_3955.dita`

Note:

The officer must gather all supporting documents related to the client’s SE earnings. 

## Regional considerations

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/what_you_need_to_look_for.dita`

### In ADMS:

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/in_adms.dita`

- Who is the requester?

- Is a third party representing an interested party?

- Was the collection action suspended?

- What is the issue under review?

- What is the result of the decision?

- What is the ADMS number?

- Is the file held in abeyance? 

### In Imaging:

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/in_imaging.dita`

- Are there any documents related to the issue? 

### In NIIS:

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/in_niis.dita`

- Review the Case Summary (IC08) screen. What are the actions taken on file?

- Review the Report of Investigation (IC70) screen.

- Review the Investigation Information Sheets (IC71) . What facts were gathered from the client or employer?

- Is there a Report of Interview (IC72) screen? 

### In the Integrity Investigation Document Upload System:

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/in_the_integrity_investigation_document_2f4ba789.dita`

- Are there any documents related to the case? 

### In SPS:

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/in_sps.dita`

- Is the original payment information available? 

### In NWS:

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/in_nws.dita`

- Is there any information relevant to the issue on SROCs, RODs and Action Item (AI) and Call Back (CB) WIs? 

### In FTS:

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/in_fts.dita`

- Is an EI ERB claim highlighted in red on the Dormant tab?

- Is the claim in MPS?

- Is the claim active, terminated, or blocked?

- If the claim is blocked, what is the claim status (CS) in BCS?

- Is there a previous EI claim in any of the 4 information technology centres (ITCs)?

- If yes, what is the BPC? 

### In RCM:

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/in_rcm.dita`

- Is there a new ROE?

- Are there ROEs for the period of a possible QP extension?

- What hours information is in the Employment History File? 

### In PSCD:

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/in_pscd.dita`

- What is the OP amount?

- Was a letter about the advance payment OP sent to the client?

- What is the original ERB2 - CERB Advance Payment OP amount?

- Which account is suspended due to the review? 

## Step by step

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/reviewing_the_file_level_1.dita`

- In FTS, determine if there is an A - Appeal lock on the Overpayment tab:

- If yes, go to step 2.

- If no, apply the A - Appeal lock. Refer to Suspending the collection of a debt and go to step 2.
               [Suspending the collection of a debt](/en/procedure/task/suscoll.shtml)

- Determine if there is any indication the client received more than $1 000 over a 4-week period while receiving the EI ERB:

- If no, go to step 3.

- If yes, in NWS, reassign the WI to the 7 - National RFR and Appeals / Specialized RFR Processing / RFR EI ERB Earnings over $1000 level.

- In NWS, determine if there is an unassigned RFR WI for the advance payment OP:

- If yes, reassign the RFR WI to yourself and go to step 4.

- If no, go to step 8.

- Determine if the request for reconsideration for either the EI ERB eligibility or the advance payment OP issue is considered delayed:

- If yes, go to step 5.

- If no, go to step 8.

- Determine if there is a delayed request on only one of the issues being reconsidered:

- If the requests are delayed for both issues, go to step 6.

- If yes, the delayed request is not an issue. Go to step 8.

- Determine if the delayed request for reconsideration for one of the requests is within 120 days from the date the initial decision was communicated:

- If yes, allow the short delay and go to step 7.

- If no and the delayed request exceeds 120 days for both issues, reassign the issue to Level 2.

- Determine which ADMS record will be retained and move the INS5210 form and all other supporting documentation into one folder in the Common Document Share.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3956.dita)

- Determine if the initial decision was made entirely within the 36-month reconsideration timeframe:

- If yes, go to step 9.

- If no, reassign the issue to Level 2.

- In NIIS, determine if there is an outstanding Integrity investigation related to the EI ERB:

- If no, go to step 10.

- If yes, move the WI to Pending until the investigation is completed. Go to step 10.

- Determine if Integrity imposed a D31:

- If yes, go to step 11.

- If no, go to step 13.

- Determine if an Integrity Services Officer imposed the D31:

- If yes, go to step 12.

- If no, reassign the issue to Level 2.

- Review the details of investigation:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3957.dita)

- Fact-find with the client to gather the following information:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3958.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3959.dita)

- Determine if fact-finding reveals that the client had additional employment, SE or foreign employment in the QP or BP:

- If yes and it is insurable employment or a combination of insurable employment, SE or foreign employment, go to step 15.

- If yes, and the client only worked in SE or foreign employment with no periods of insurable employment, go to step 30.

- If no, but the client worked in insurable employment in the QP or extended QP, go to step 15.

- If no and there is no evidence of any insurable employment, SE or foreign employment during the QP or extended QP, and the client does not dispute this fact, go to Eligibility not proven .
               [Eligibility not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level1_item_5)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3960.dita) 

#### Determining if the client otherwise qualifies for regular or sickness benefits during the EI Emergency Response Benefit (EI ERB) period

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/determining_if_the_client_otherwise_qua_916daa47_level_1.dita`

- In RCM, determine the number of hours worked in the QP using the Calculation: Worksheet — Tool to manually plot the QP. Determine if the client could have established a claim for regular or sickness benefits in the first week for which the EI ERB was paid, or in any subsequent weeks according to one of the following criteria of EIA 153.5(2)(b) :

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3961.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3962.dita) 

- If no, but there are subsequent weeks to be reviewed repeat step 15.

- If no and all weeks in the EI ERB period have been reviewed, go to step 16.

- If yes, go to step 21.

- Determine if the client qualifies for a QP extension as of the week being reviewed. If necessary, refer to Determining if a qualifying period extension is required :

- If yes, go to step 17.

- If no, but it is not clear if the client qualifies, go to step 18.

- If no and it is clear the client does not qualify, go to step 23.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3963.dita)

- Determine if an interim ROE is required because of hours that are not on the ROE but fall in the extended QP:

- If yes, refer to Interim ROE . Go to step 18.
               [Interim ROE](/en/procedure/activity/interim_roe.shtml)

- If no, go to step 18.

- Determine if any ROEs overlap the QP cut-off date (COD):

- If yes, go to step 19.

- If no, take note of the hours on the ROE and go to step 20.

- Review the Employment History File for each ROE that overlaps the COD to determine the number of hours that fall in the QP. Take note of the hours that fall in the QP.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3962.dita)

- Determine if the client has enough hours to establish a claim for regular or sickness benefits. If necessary, refer to Calculation: Information on calculation and entitlement to benefits — Knowledge . Include the hours in the QP and the extended QP:

- If yes, go to step 21.

- If no, go to step 23.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3964.dita)

- Determine if the following condition is met according to EIA 153.9(1)(b) :

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3965.dita) 

- If yes, go to step 22.

- If no, go to Eligibility not proven .
               [Eligibility not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level1_item_5)

- Determine if the client met the hours requirement in a week after the first week of EI ERB:

- If yes, take note of the week and go to step 23.

- If no and eligibility is proven from the BPC, go to Eligibility proven .
               [Eligibility proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level1_item_4) 

#### Determining if the client meets the definition of a claimant according to EIA 153.5(2)(a), (c) or (d)

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/determining_if_the_client_meets_the_def_79378918_level_1.dita`

- Determine if the client had $5 000 in earnings from insurable employment in 2019 or in the 52 weeks before the first 2-week EI ERB claim:

- If no, go to step 24.

- If yes, go to step 26.

- Review the next 2-week EI ERB claim and repeat step 22 until one of the following occurs:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3966.dita)

- Determine if the client met the $5 000 insurable earnings requirement in the EI ERB period being reviewed:

- If yes, go to step 26.

- If no, go to step 30.

- Determine if the client meets all of the following criteria of EIA 153.5(2)(c) or (d) :

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3967.dita) 

- If yes, go to step 27.

- If no, go to step 28.

- Determine if the client meets all of the following criteria of EIA 153.9(1)(c) :

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3968.dita) 

- If no, go to step 30.

- If yes, go to Eligibility proven — Partial or entire period .
               [Eligibility proven — Partial or entire period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level1_item_4)

- Determine if the client stopped working due to COVID-19, and is unable to resume employment due to COVID-19 according to EIA 153.5(2)(a) :

- If yes, go to step 29.

- If no, but the client was otherwise able to establish an EI claim under EIA 153.5(2)(b) in a later week, go to Eligibility proven — Partial or entire period .
               [EIA 153.5(2)(b)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242425) 
               [Eligibility proven — Partial or entire period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level1_item_4)

- Determine if the client meets all of the following criteria of EIA 153.9(1)(a) :

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3969.dita) 

- If yes, go to Eligibility proven — Partial or entire period .
               [Eligibility proven — Partial or entire period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level1_item_4)

- If no, but the client was otherwise able to establish an EI claim under EIA 153.5(2)(b) in a later week, go to Eligibility proven — Partial or entire period .
               [EIA 153.5(2)(b)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242425) 
               [Eligibility proven — Partial or entire period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level1_item_4)

- Determine if the client had $5000 in earnings from SE or could meet the $5 000 requirement with a combination of insurable earnings and SE income:

- If no, go to Eligibility not proven .
               [Eligibility not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level1_item_5)

- If yes, in NWS, reassign the WI to level 7 - National RFR and Appeals / Specialized RFR Processing / RFR EI ERB Eligibility / Self Employment .

- Determine if the client received $5 000 in earnings from an employment out of Canada, or could meet this requirement with a combination of insurable and out of Canada employment:

- If no, go to Eligibility not proven .
               [Eligibility not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level1_item_5)

- If yes, send the relevant out of Canada employment information to the CRA for an insurability ruling. 

#### Eligibility proven — Part or entire period

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/eligibility_proven__part_or_entire_period_level_1.dita`

- Determine if an OP remains following the reconsideration decision:

- If yes, go to step 2.

- If no, go to step 7.

- Determine if the client is disputing the obligation to repay the OP:

- If no, refer to Detecting if Level 2 adjudication is required for a potential overpayment write-off - Level 1 , then go to step 3.
               [Detecting if Level 2 adjudication is required for a potential overpayment write-off - Level 1](/en/procedure/task/determining_conditions_wo_op.shtml)

- If yes, consider this a formal write-off request. Go to step 4.

- Determine if there is a potential OP write-off situation that needs Level 2 adjudication:

- If yes, go to step 4.

- If no, go to step 7.

- In NWS, create an AI WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: 7 - National RFR and Appeals / RFRA-ATL

- Quebec: 7 - National RFR and Appeals / RFRA-QC

- Ontario: 7 - National RFR and Appeals / RFRA-ON

- Western Canada and Territories: 7 - National RFR and Appeals / RFRA-WT

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 2 adjudication required — OP write-off.”

- Details: Enter the following information:

- The ADMS record number.

- The criteria that were met to have the OP written off.

- Obtained on: Enter today’s date.

- Source Details: Type “Request for reconsideration.”

- Urgent: Check the box.

- Move the RFR WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting adjudication from the Level 2 officer.”

- Bring forward date: Enter the appropriate date.

- When the RFR WI moves to the current workload, verify if the decision was made:

- If no, return to step 5.

- If yes, go to step 7.

- Create a ROD (or add to a previously drafted ROD) as follows:

- Comments: Enter the appropriate option:

- If eligibility is proven for the whole period, type “Request for reconsideration [ADMS record number] — EI Emergency Response Benefit — eligibility proven.”

- If eligibility is proven for a partial period, type “Request for reconsideration [ADMS record number] — EI Emergency Response Benefit — eligibility proven for a partial period.”

- Details: Document the decision and rationale using the Request for Reconsideration: EI Emergency Response Benefit – EI ERB Eligibility – Template .
               [Request for Reconsideration: EI Emergency Response Benefit – EI ERB Eligibility – Template](/resources/ort/documents/EIOPP-AddRes-RODERBEligibility-EN.docx)

- Select Save .

- If necessary, communicate the decision to the client. Refer to Verbally communicating a reconsideration under EIA 112 decision .

- Determine if a D31 must be imposed for a partial period:

- If no, go to step 10.

- If yes, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3970.dita)

- Determine if a D31 was previously imposed:

- If yes and the decision is rescinded or modifications are required, refer to Reconsideration EIA 112: Implementing a decision — EI ERB eligibility .
               [Reconsideration EIA 112: Implementing a decision — EI ERB eligibility](/en/procedure/task/recon-eia112-impl-eierb.shtml)

- If no, go to step 11.

- Determine if the client disputes an OP related to the advance payment:

- If no, go to step 12.

- If yes, refer to Performing a reconsideration under EIA 112 of the EI ERB advance payment overpayment .
               [Performing a reconsideration under EIA 112 of the EI ERB advance payment overpayment](/en/procedure/task/performing_reconsideration_under_eia_112_eierb_apo.shtml)

- In ACS, create and send the X-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Insert ADMS Record ID (4059)

- Notice of Administrative Review Decision(s) addressed to client - Client Requested Reconsideration (11980)

- Date Request for Reconsideration received (4063)

- Date of Commission’s decision (4065): Select the date on the initial decision letter.

- List of issues (11981)

- Decision completely rescinded or removed / maintained / modified or replaced by a new decision (11982): Select the appropriate option:

- Decision completely rescinded or removed

- Decision modified or replaced by a new decision

- Blank / When employer is an interested party (11984)

- Determine if the initial decision was rescinded, modified or maintained:

- If the decision was rescinded, go to step 14.

- If the decision was maintained, go to step 15.

- If the decision was modified, go to step 16.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision result: Select Decision rescinded .

- Reason: Select the appropriate reason.

- Date RFR Decision Implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Select Save .

- Go to step 17.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained .

- Date RFR Decision implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Select Save .

- Go to step 17.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained with Modifications .

- Date RFR Decision implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Select Save .

- Determine if ADMS inputs are complete for all decisions:

- If yes, go to step 18.

- If no, complete the missing fields. Go to step 18.

- In NWS, complete the WI. 

#### Eligibility not proven

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/eligibility_not_proven_level_1.dita`

- Determine if an OP remains following the reconsideration decision:

- If yes, go to step 2.

- If no, go to step 7.

- Determine if the client is disputing the obligation to repay the OP:

- If no, refer to Detecting if Level 2 adjudication is required for a potential overpayment write-off - Level 1 , then go to step 3.
               [Detecting if Level 2 adjudication is required for a potential overpayment write-off - Level 1](/en/procedure/task/determining_conditions_wo_op.shtml)

- If yes, consider this a formal write-off request. Go to step 4.

- Determine if there is a potential OP write-off situation that needs Level 2 adjudication:

- If yes, go to step 4.

- If no, go to step 7.

- In NWS, create an AI WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: 7 - National RFR and Appeals / RFRA-QC .

- Ontario: 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 2 adjudication required — OP write-off.”

- Details: Enter the following information:

- The ADMS record number.

- The criteria that were met to have the OP written off.

- Obtained on: Enter today’s date.

- Source Details: Type “Request for reconsideration.”

- Urgent: Check the box.

- Move the RFR WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting adjudication from the Level 2 officer.”

- Bring forward date: Enter the appropriate date.

- When the RFR WI moves to the current workload, verify if the decision was made:

- If no, return to step 5.

- If yes, go to step 7.

- Communicate the decision to the client. Refer to Verbally communicating a reconsideration under EIA 112 decision .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3971.dita)

- In NWS, create a ROD (or add to a previously drafted ROD) as follows:

- Comments: Type “Request for reconsideration [ADMS record number] — EI Emergency Response Benefit — eligibility not proven.”

- Details: Document the decision and rationale using the Request for Reconsideration: EI Emergency Response Benefit – EI ERB Eligibility – Template .
               [Request for Reconsideration: EI Emergency Response Benefit – EI ERB Eligibility – Template](/resources/ort/documents/EIOPP-AddRes-RODERBEligibility-EN.docx)

- Select Save .

- Determine if there is an ongoing request for reconsideration for an EI ERB advance payment OP:

- If no, go to step 10.

- If yes, note that the advance payment OP issue will be maintained because the client is not eligible for the EI ERB. Go to step 10.

- Determine if a D31 was previously imposed:

- If no, refer to Reconsideration EIA 112: Implementing a decision — EI ERB eligibility .
               [Reconsideration EIA 112: Implementing a decision — EI ERB eligibility](/en/procedure/task/recon-eia112-impl-eierb.shtml)

- If yes and modifications are required, refer to Reconsideration EIA 112: Implementing a decision— EI ERB eligibility .
               [Reconsideration EIA 112: Implementing a decision— EI ERB eligibility](/en/procedure/task/recon-eia112-impl-eierb.shtml)

- If yes and modifications are not required, reinstate the collection of the debt . Go to step 11.
               [reinstate the collection of the debt](/en/procedure/task/reinstcoll.shtml)

- In ACS, create and send the X-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Insert ADMS Record ID (4059)

- Notice of Administrative Review Decision addressed to client - Client Requested Reconsideration (11980)

- Date Request for Reconsideration received (4063)

- Date of Commission’s decision (4065): Select the date on the initial decision letter.

- List of issues (11981)

- Decision completely rescinded or removed / maintained / modified or replaced by a new decision (11982): Select the appropriate option:

- Decision completely rescinded or removed

- Decision modified or replaced by a new decision

- Blank / When employer is an interested party (11984)

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained .

- Date RFR Decision implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Select Save .

- Determine if ADMS inputs are complete for all decisions:

- If yes, go to step 14.

- If no, complete the missing fields. Go to step 14.

- In NWS, complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_3956.dita`

Note:

Email a Team Leader to request deletion of the ADMS record that was not retained. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3957.dita`

- In NIIS, review the Report of Investigation (IC70) screen and the Investigation Information Sheets (IC71) .

- In Imaging, review the client’s response to the C-74 letter.

- In the Integrity Investigation Document Upload System, review the documents related to the investigation.

- In NWS, review the ROD related to the investigation.

- In ACS, review the letters sent by Integrity. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3958.dita`

- periods of employment that fall in the QP or BP for which there is a missing ROE;

- periods of SE for which there is a T1 or T5;

- periods of foreign employment;

- conditions to extend the QP;

- issues pertinent to the review of the EI ERB eligibility (e.g. insurability of employment, reason for separation [RFS] and circumstances of SE). 

#### Note

Source topic: `en_EN/common_notes/note_c_3959.dita`

Note:

Take the appropriate action to ensure all ROEs are entered into RCM. If any documents are missing, advise the client to submit them in AW using the document upload function. 

#### Note

Source topic: `en_EN/common_notes/note_c_3960.dita`

Note:

If there are earnings from SE or foreign employment, reassign the WI to the level 7 - National RFR and Appeals / Specialized RFR Processing / RFR EI ERB Eligibility / Self Employment in NWS only if fact-finding confirms both of the following situations:

- The client was not eligible for EI ERB based on the insurable employment requirement.

- The client had $5 000 in earnings from SE or foreign employment or could have met the earnings requirement with a combination of insurable earnings and earnings from SE or foreign employment. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3961.dita`

- The client had an I of E and worked enough hours in the QP to establish a claim for regular benefits.

- The client had an I of E and worked enough hours in the QP to establish a claim for sickness benefits.

- The self-employed client had an I of E due to sickness, entered into an agreement with Service Canada to pay EI premiums at least 12 months before the BPC and met the minimum SE earnings requirement in the QP for the 2019 calendar year. 

#### Note

Source topic: `en_EN/common_notes/note_c_3962.dita`

Note:

When determining the number of hours needed to qualify for regular or sickness benefits, determine if a temporary measure was in place. 

#### Note

Source topic: `en_EN/common_notes/note_c_3963.dita`

Note:

The QP can never be extended beyond the BPC week of a previous EI claim. 

#### Note

Source topic: `en_EN/common_notes/note_c_3964.dita`

Note:

Determine if the client could have qualified for regular benefits based on the VER in the first week for which the EI ERB was paid. To determine if the client could have qualified for sickness benefits, determine if the client worked the required number of hours needed for sickness benefits or if the client could have been minor attached in the first week for which the EI ERB was paid. The client was not required to request sickness benefits or submit a medical certificate.
       [VER](/en/procedure/generic/knowledge.shtml#Variable_entrance_requirement) 
       [minor attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

If the client is not eligible in the first week, continue to determine eligibility from the next week onward until eligibility has been proven or the EI ERB claim ends.

Determine if the client is entitled to a QP extension, which would allow the claim to be established.

When determining if the client meets the VER, determine if increased entrance requirements apply due to a violation.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [VER](/en/procedure/generic/knowledge.shtml#Variable_entrance_requirement) 
     [minor attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client) 
     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

#### Callout

Source topic: `en_EN/common_notes/note_c_3965.dita`

- The client had no income from employment or SE for at least 7 consecutive days in the 2-week period for which benefits were claimed. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3966.dita`

- The client met the $5 000 requirement in earnings from insurable employment.

- The end of the EI ERB period is reached. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3967.dita`

- The client was unable to start working for reasons related to COVID-19.

- The client had a previous claim for which regular or fishing benefits were paid or payable between December 29, 2019, and October 3, 2020, and one of the following conditions applies:

- The claim has ended.

- Entitlement was exhausted.

- The client did not receive full entitlement due to having received the maximum 50 weeks of combined regular and special benefits or the maximum of 50 weeks of combined fishing and special benefits. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3968.dita`

- the client resides in Canada;

- the client is at least 15 years old;

- the client had no income from employment or SE for at least 7 consecutive days within the 2-week period for which the client requested the benefits. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3969.dita`

- the client resides in Canada;

- the client is at least 15 years old;

- the client ceased the employment or SE for at least 7 consecutive days;

- the client had no income from employment or SE in the 2-week period for which the client requested the benefits. 

#### Note

Source topic: `en_EN/common_notes/note_c_3970.dita`

Note:

If an OP is created as a result of a partial disentitlement, or eligibility was proven and the D31 is rescinded, and the client asked for reconsideration of the advance payment OP, refer to Performing a reconsideration under EIA 112 of the EI ERB advance payment overpayment before sending the X-01-00-00 letter and completing ADMS inputs. If the client was a student but received the EI ERB through Service Canada, once the correct OP amount is known, advise the client to contact the CRA for a student CERB debt reduction .
       [Performing a reconsideration under EIA 112 of the EI ERB advance payment overpayment](/en/procedure/task/performing_reconsideration_under_eia_112_eierb_apo.shtml) 
       [student CERB debt reduction](https://www.canada.ca/en/revenue-agency/services/benefits/apply-for-cerb-with-cra/return-payment/student-cerb-debt.html)

     [Performing a reconsideration under EIA 112 of the EI ERB advance payment overpayment](/en/procedure/task/performing_reconsideration_under_eia_112_eierb_apo.shtml) 
     [student CERB debt reduction](https://www.canada.ca/en/revenue-agency/services/benefits/apply-for-cerb-with-cra/return-payment/student-cerb-debt.html) 

#### Note

Source topic: `en_EN/common_notes/note_c_3971.dita`

Note:

If the client could have applied for the CESB, refer the client to the CRA for a student CERB debt reduction .
       [student CERB debt reduction](https://www.canada.ca/en/revenue-agency/services/benefits/apply-for-cerb-with-cra/return-payment/student-cerb-debt.html)

     [student CERB debt reduction](https://www.canada.ca/en/revenue-agency/services/benefits/apply-for-cerb-with-cra/return-payment/student-cerb-debt.html) 

### Level 2

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/reviewing_the_file_level_2.dita`

- In FTS, determine if there is an A - Appeal lock on the Overpayment tab:

- If yes, go to step 2.

- If no, apply the A - Appeal lock. Refer to Suspending the collection of a debt and go to step 2.
               [Suspending the collection of a debt](/en/procedure/task/suscoll.shtml)

- Determine if there is any indication the client received more than $1 000 over a 4-week period while receiving the EI ERB:

- If no, go to step 3.

- If yes, in NWS, reassign the WI to the 7 - National RFR and Appeals / Specialized RFR Processing / RFR EI ERB Earnings over $1000 level.

- In NWS, determine if there is an unassigned RFR WI for the advance payment OP:

- If yes, reassign the RFR WI to yourself and go to step 4.

- If no, go to step 8.

- Determine if the request for reconsideration for either the EI ERB eligibility or the advance payment OP issue is considered delayed:

- If yes, go to step 5.

- If no, go to step 8.

- Determine if there is a delayed request on only one of the issues being reconsidered:

- If the requests are delayed for both issues, go to step 6.

- If yes, the delayed request is not an issue. Go to step 8.

- Determine if the delayed request for reconsideration for one of the requests is within 120 days from the date the initial decision was communicated:

- If yes, allow the short delay and go to step 7.

- If no and the delayed request for reconsideration exceeds 120 days for both issues, choose the most beneficial delay for the client. Refer to Adjudicating a delayed request for reconsideration , and then return to step 7.
               [Adjudicating a delayed request for reconsideration](/en/procedure/task/delayeddr.shtml)

- Determine which ADMS record will be retained and move the INS5210 form and all other supporting documentation into one folder in the Common Document Share.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3956.dita)

- Review all 2-week periods and determine if any false statements were made:

- If no, go to step 9.

- If yes, go to step 10.

- Determine if the initial decision was made entirely within the 36-month reconsideration timeframe:

- If yes, go to step 11.

- If no, the D31 must be removed for any period after the 36-month reconsideration timeframe. Go to step 11.

- Determine if the initial decision was made within the 72-month reconsideration timeframe:

- If yes, go to step 11.

- If no, the D31 must be removed for any period after the 72-month reconsideration timeframe, go to step 11.

- In NIIS, determine if there is an ongoing Integrity investigation related to the EI ERB:

- If no, go to step 12.

- If yes, move the WI to Pending until the investigation is completed. Go to step 12.

- Determine if Integrity imposed a D31:

- If yes, go to step 13.

- If no, go to step 14.

- Review the details of investigation:

- In NIIS, review the Report of Investigation (IC70) screen and the Investigation Information Sheets (IC71) .

- In Imaging, review the client’s response to the C-74 letter.

- In the Integrity Investigation Document Upload System, review the documents related to the investigation.

- In NWS, review the ROD related to the investigation.

- In ACS, review the letters sent by Integrity.

- Fact-find with the client to gather the following information:

- periods of employment that fall in the QP or BP for which there is a missing ROE;

- periods of SE for which there is a T1 or T5;

- periods of foreign employment;

- conditions to extend the QP;

- issues pertinent to the review of the EI ERB eligibility (e.g. insurability of employment, RFS and circumstances of SE).

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3959.dita)

- Determine if fact-finding reveals that the client had additional employment, SE or foreign employment in the QP or BP:

- If yes and it is insurable employment or a combination of insurable employment, SE or foreign employment, go to step 16.

- If yes, and the client only worked in SE or foreign employment with no periods of insurable employment, go to step 31.

- If no, but the client worked in insurable employment in the QP or extended QP, go to step 16.

- If no and there is no evidence of any insurable employment, SE or foreign employment during the QP or extended QP, and the client does not dispute this fact, go to Eligibility not proven .
               [Eligibility not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level2_item_5)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3960.dita) 

#### Determining if the client otherwise qualifies for regular or sickness benefits during the EI Emergency Response Benefit (EI ERB) period

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/determining_if_the_client_otherwise_qua_916daa47_level_2.dita`

- In RCM, determine the number of hours worked in the QP using the Calculation: Worksheet — Tool to manually plot the QP. Determine if the client could have established a claim for regular or sickness benefits in the first week for which the EI ERB was paid, or in any subsequent weeks according to one of the following criteria of EIA 153.5(2)(b) :

- The client had an I of E and worked enough hours in the QP to establish a claim for regular benefits.

- The client had an I of E and worked enough hours in the QP to establish a claim for sickness benefits.

- The self-employed client had an I of E due to sickness, entered into an agreement with Service Canada to pay EI premiums at least 12 months before the BPC and met the minimum SE earnings requirement in the QP for the 2019 calendar year.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3962.dita)

- If no, but there are subsequent weeks to be reviewed repeat step 16.

- If no and all weeks in the EI ERB period have been reviewed, go to step 17.

- If yes, go to step 22.

- Determine if the client qualifies for a QP extension as of the week being reviewed. If necessary, refer to Determining if a qualifying period extension is required :

- If yes, go to step 18.

- If no, but it is not clear if the client qualifies, go to step 19.

- If no and it is clear the client does not qualify, go to step 24.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3963.dita)

- Determine if an interim ROE is required because of hours that are not on the ROE but fall in the extended QP:

- If yes, refer to Interim ROE . Go to step 19.
               [Interim ROE](/en/procedure/activity/interim_roe.shtml)

- If no, go to step 19.

- Determine if any ROEs overlap the QP COD:

- If yes, go to step 20.

- If no, take note of the hours on the ROE and go to step 21.

- Review the Employment History File for each ROE that overlaps the COD to determine the number of hours that fall in the QP. Take note of the hours that fall in the QP.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3962.dita)

- Determine if the client has enough hours to establish a claim for regular or sickness benefits. If necessary, refer to Calculation: Information on calculation and entitlement to benefits — Knowledge . Include the hours in the QP and the extended QP:

- If yes, go to step 22.

- If no, go to step 24.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3964.dita)

- Determine if the following condition is met according to EIA 153.9(1)(b) :

- The client had no income from employment or SE for at least 7 consecutive days in the 2-week period for which benefits were claimed.

- If yes, go to step 23.

- If no, go to Eligibility not proven .
                   [Eligibility not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level2_item_5)

- Determine if the client met the hours requirement in a week after the first week of EI ERB:

- If yes, take note of the week and go to step 24.

- If no and eligibility is proven from the BPC, go to Eligibility proven — Part or entire period .
               [Eligibility proven — Part or entire period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level2_item_4) 

#### Determining if the client meets the definition of a claimant according to EIA 153.5(2)(a), (c) or (d)

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/determining_if_the_client_meets_the_def_79378918_level_2.dita`

- Determine if the client had $5 000 in earnings from insurable employment in 2019 or in the 52 weeks before the first 2-week EI ERB claim:

- If no, go to step 25.

- If yes, go to step 27.

- Review the next 2-week EI ERB claim and repeat step 22 until one of the following occurs:

- The client met the $5 000 requirement in earnings from insurable employment.

- The end of the EI ERB period is reached.

- Determine if the client met the $5 000 insurable earnings requirement in the EI ERB period being reviewed:

- If yes, go to step 27.

- If no, go to step 31.

- Determine if the client meets all of the following criteria of EIA 153.5(2)(c) or (d) :

- The client was unable to start working for reasons related to COVID-19.

- The client had a previous claim for which regular or fishing benefits were paid or payable between December 29, 2019, and October 3, 2020, and one of the following conditions applies:

- The claim has ended.

- Entitlement was exhausted.

- The client did not receive full entitlement due to having received the maximum 50 weeks of combined regular and special benefits or the maximum of 50 weeks of combined fishing and special benefits.

- If yes, go to step 28.

- If no, go to step 29.

- Determine if the client meets all of the following criteria of EIA 153.9(1)(c) :

- the client resides in Canada;

- the client is at least 15 years old;

- the client had no income from employment or SE for at least 7 consecutive days within the 2-week period for which the client requested the benefits.

- If no, go to step 31.

- If yes, go to Eligibility proven — Partial or entire period .
               [Eligibility proven — Partial or entire period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level2_item_4)

- Determine if the client stopped working due to COVID-19, and is unable to resume employment due to COVID-19 according to EIA 153.5(2)(a) :

- If yes, go to step 30.

- If no, but the client was otherwise able to establish an EI claim under EIA 153.5(2)(b) in a later week, go to Eligibility proven — Partial or entire period .
               [EIA 153.5(2)(b)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242425) 
               [Eligibility proven — Partial or entire period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level2_item_4)

- Determine if the client meets all of the following criteria of EIA 153.9(1)(a) :

- the client resides in Canada;

- the client is at least 15 years old;

- the client ceased the employment or SE for at least 7 consecutive days;

- the client had no income from employment or SE in the 2-week period for which the client requested the benefits.

- If yes, go to Eligibility proven — Partial or entire period .
               [Eligibility proven — Partial or entire period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level2_item_4)

- If no, but the client was otherwise able to establish an EI claim under EIA 153.5(2)(b) in a later week, go to Eligibility proven — Partial or entire period .
               [EIA 153.5(2)(b)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242425) 
               [Eligibility proven — Partial or entire period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level2_item_4)

- Determine if the client had $5000 in earnings from SE or could meet the $5 000 requirement with a combination of insurable earnings and SE income:

- If no, go to Eligibility not proven .
               [Eligibility not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level2_item_5)

- If yes, in NWS, reassign the WI to level 7 - National RFR and Appeals / Specialized RFR Processing / RFR EI ERB Eligibility / Self Employment .

- Determine if the client received $5 000 in earnings from an employment out of Canada, or could meet this requirement with a combination of insurable and out of Canada employment:

- If no, go to Eligibility not proven .
               [Eligibility not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/perf-rec-eia112-eierb-cra#level2_item_5)

- If yes, send the relevant out of Canada employment information to the CRA for an insurability ruling. 

#### Eligibility proven — Part or entire period

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/eligibility_proven__part_or_entire_period_level_2.dita`

- Determine if an OP remains following the reconsideration decision:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client is disputing the obligation to repay the OP:

- If no, go to step 3.

- If yes, refer to Adjudicating a write-off - Level 2 to determine if the debt can be written off, then go to step 3.
               [Adjudicating a write-off - Level 2](/en/procedure/task/adjudicating_write_off.shtml)

- In NWS, create a ROD for the reconsideration timeframe decision:

- Comments: Type “Request for reconsideration [ADMS record number] — reconsideration timeframe.”

- Details: Document the decision and rationale using the Reconsideration under Employment Insurance Act 52 — Template .
               [Reconsideration under Employment Insurance Act 52 — Template](/resources/ort/documents/rod/en/EIOPP-Template-Section52-2019Nov07-E-V01.docx)

- Select Save .

- In NWS, create a ROD as follows:

- Comments: Enter the appropriate option:

- If eligibility is proven for the whole period, type “Request for reconsideration [ADMS record number] — EI Emergency Response Benefit — eligibility proven.”

- If eligibility is proven for a partial period, type “Request for reconsideration [ADMS record number] — EI Emergency Response Benefit — eligibility proven for a partial period.”

- Details: Document the decision and rationale using the Request for Reconsideration: EI Emergency Response Benefit – EI ERB Eligibility – Template .
               [Request for Reconsideration: EI Emergency Response Benefit – EI ERB Eligibility – Template](/resources/ort/documents/EIOPP-AddRes-RODERBEligibility-EN.docx)

- Select Save .

- If necessary, communicate the decision to the client. Refer to Verbally communicating a reconsideration under EIA 112 decision .

- Determine if an OP will remain following the reconsideration decision:

- If yes, go to step 7.

- If no, go to step 8.

- Determine if the client is disputing the obligation to repay the OP:

- If no, go to step 8.

- If yes, refer to Adjudicating a write-off - Level 2 . Then, go to step 8.
               [Adjudicating a write-off - Level 2](/en/procedure/task/adjudicating_write_off.shtml)

- Determine if a D31 must be imposed for a partial period:

- If no, go to step 9.

- If yes, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3970.dita)

- Determine if a D31 was previously imposed:

- If no, go to step 10.

- If yes and the decision is rescinded or modifications are required, refer to Reconsideration under EIA 112: Implementing a decision — EI ERB eligibility .
               [Reconsideration under EIA 112: Implementing a decision — EI ERB eligibility](//en/procedure/task/recon-eia112-impl-eierb.shtml)

- Determine if the client disputes an OP related to the advance payment:

- If no, go to step 11.

- If yes, refer to Performing a reconsideration under EIA 112 of the EI ERB advance payment overpayment .
               [Performing a reconsideration under EIA 112 of the EI ERB advance payment overpayment](/en/procedure/task/performing_reconsideration_under_eia_112_eierb_apo.shtml)

- In ACS, create and send the X-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Insert ADMS Record ID (4059)

- Notice of Administrative Review Decision addressed to client - Client Requested Reconsideration (11980)

- Date Request for Reconsideration received (4063)

- Date of Commission’s decision (4065): Select the date on the initial decision letter.

- List of issues (11981)

- Decision completely rescinded or removed / maintained / modified or replaced by a new decision (11982): Select the appropriate option:

- Decision completely rescinded or removed

- Decision modified or replaced by a new decision

- Blank / When employer is an interested party (11984)

- Determine if the initial decision was rescinded, modified or maintained:

- If the decision was rescinded, go to step 13.

- If the decision was maintained, go to step 14.

- If the decision was modified, go to step 15.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision result: Select Decision rescinded .

- Reason: Select the appropriate reason.

- Date RFR Decision Implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Select Save .

- Go to step 16.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained .

- Date RFR Decision implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Select Save .

- Go to step 16.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained with Modifications .

- Date RFR Decision implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Select Save .

- Determine if ADMS inputs are complete for all decisions:

- If yes, go to step 17.

- If no, complete the missing fields. Go to step 17.

- In NWS, complete the WI. 

#### Eligibility not proven

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/eligibility_not_proven_level_2.dita`

- Determine if an OP remains following the reconsideration decision:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client is disputing the obligation to repay the OP:

- If no, go to step 3.

- If yes, refer to Adjudicating a write-off - Level 2 to determine if the OP can be written off, then go to step 3.
               [Adjudicating a write-off - Level 2](/en/procedure/task/adjudicating_write_off.shtml)

- Communicate the decision to the client. Refer to Verbally communicating a reconsideration under EIA 112 decision .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3971.dita)

- In NWS, create a ROD for the reconsideration timeframe decision:

- Comments: Type “Request for reconsideration [ADMS record number] — reconsideration timeframe.”

- Details: Document the decision and rationale using the Reconsideration under Employment Insurance Act 52 — Template .
               [Reconsideration under Employment Insurance Act 52 — Template](/resources/ort/documents/rod/en/EIOPP-Template-Section52-2019Nov07-E-V01.docx)

- Select Save .

- In NWS, create a ROD as follows:

- Comments: Type “Request for reconsideration [ADMS record number] — EI Emergency Response Benefit — eligibility not proven.”

- Details: Document the decision and rationale using the Request for Reconsideration: EI Emergency Response Benefit – EI ERB Eligibility – Template .
               [Request for Reconsideration: EI Emergency Response Benefit – EI ERB Eligibility – Template](/resources/ort/documents/EIOPP-AddRes-RODERBEligibility-EN.docx)

- Select Save .

- Determine if an OP will remain following the reconsideration decision:

- If yes, go to step 7.

- If no, go to step 8.

- Determine if the client is disputing the obligation to repay the OP:

- If no, go to step 8.

- If yes, refer to Adjudicating a write-off - Level 2 . Then, go to step 8.
               [Adjudicating a write-off - Level 2](/en/procedure/task/adjudicating_write_off.shtml)

- Determine if there is an ongoing request for reconsideration for an EI ERB advance payment OP:

- If no, go to step 9.

- If yes, note that the advance payment OP issue will be maintained because the client is not eligible for the EI ERB. Go to step 9.

- Determine if a D31 was previously imposed:

- If no, refer to Reconsideration EIA 112: Implementing a decision — EI ERB eligibility .
               [Reconsideration EIA 112: Implementing a decision — EI ERB eligibility](/en/procedure/task/recon-eia112-impl-eierb.shtml)

- If yes and modifications are required, refer to Reconsideration EIA 112: Implementing a decision — EI ERB eligibility .
               [Reconsideration EIA 112: Implementing a decision — EI ERB eligibility](/en/procedure/task/recon-eia112-impl-eierb.shtml)

- If yes and modifications are not required, reinstate the collection of the debt . Go to step 10.
               [reinstate the collection of the debt](/en/procedure/task/reinstcoll.shtml)

- In ACS, create and send the X-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Insert ADMS Record ID (4059)

- Notice of Administrative Review Decision addressed to client - Client Requested Reconsideration (11980)

- Date Request for Reconsideration received (4063)

- Date of Commission’s decision (4065): Select the date on the initial decision letter.

- List of issues (11981)

- Decision completely rescinded or removed / maintained / modified or replaced by a new decision (11982): Select the appropriate option:

- Decision completely rescinded or removed

- Decision modified or replaced by a new decision

- Blank / When employer is an interested party (11984)

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained .

- Date RFR Decision implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Select Save .

- Determine if ADMS inputs are complete for all decisions:

- If yes, go to step 13.

- If no, complete the missing fields. Go to step 13.

- In NWS, complete the WI. 

## Policy reference

Source topic: `en_EN/task/perf-rec-eia112-eierb-cra/policy_reference.dita`

- EIA 7
         [EIA 7](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-2.html#h-215831)

- EIA 10
         [EIA 10](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-3.html#215914)

- EIA 52
         [EIA 52](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-8.html#216685)

- EIA 112
         [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- EIA 153.5(2)
         [EIA 153.5(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#1242442)

- EIA 153.9
         [EIA 153.9](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#1242533)

- EI Emergency Response Benefit Digest
         [EI Emergency Response Benefit Digest](https://ort-orl.esdc-edsc.canada.ca/en/policy/generic/ei_erb_digest.shtml) 
