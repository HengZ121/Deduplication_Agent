# Terminating a D5 disentitlement: Labour dispute — Renewal or continuing claim

Source map: `en_EN/task/terminating_d5dld_rcc/terminating_d5dld_rcc.ditamap`

## Summary

Source topic: `en_EN/task/terminating_d5dld_rcc/summary.dita`

Summary: The agent must terminate the 5 - Labour dispute disentitlement (D5) when the labour dispute period expires or the client has become regularly engaged elsewhere in insurable employment. 

## What you need to know

Source topic: `en_EN/task/terminating_d5dld_rcc/what_you_need_to_know.dita`

### Terminating a labour dispute disentitlement

Source topic: `en_EN/task/terminating_d5dld_rcc/terminating_a_labour_dispute_disentitlement.dita`

A D5 is terminated on the day before the date on which the labour dispute ends or the day before the date on which the client became regularly employed elsewhere in insurable employment.

**Employed elsewhere**

When a client begins working elsewhere during a labour dispute, both of the following conditions must be met for the D5 to be terminated:

- The employment is insurable;

- The client becomes regularly employed in insurable employment at a place other than where the labour dispute exists.

The agent must adjudicate the other employment before terminating the D5. If the client is a part-time employee, the agent must create an Operational Centre Memo (MM06) to advise IPOC to terminate the disentitlement.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4784.dita) 

**Labour dispute has ended**

The regional office ensures that the initial fact-finding and decisions regarding labour disputes (e.g. start and end dates, dates of disentitlement and any exemptions from disentitlement) are made based on the region of the employer. Once the fact-finding is complete and a decision concerning entitlement has been made, the regional officer posts the decision in the Major Employer Events .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

Since all labour dispute decisions are rendered by the regional officer (business expertise adviser or consultant) only , the agent must not conduct any fact-finding with the employer or the u nion.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4785.dita) 

Once the decision has been posted, the agent must copy and paste the decision onto a record of decision (ROD). 

### Levels of decision

Source topic: `en_EN/task/terminating_d5dld_rcc/levels_of_decision.dita`

The Level 1 agent can implement the decision made by the regional office on whether to impose a disentitlement or to allow benefits for clients who lose their employment because of a work stoppage at their place of employment when all the following conditions are met:

- the decision is readily apparent;

- no additional fact finding is required;

- according to the fact-finding related to this decision, it is clearly established who this decision applies to.

If a Level 1 agent cannot implement the decision made by the regional office, the agent documents the facts and refers the reason for separation (RFS) to Level 2 for adjudication.

If the client applies for special benefits, the agent must reassign the WI to Level 2 for adjudication of the otherwise entitled to benefits issue. 

### Note

Source topic: `en_EN/common_notes/note_c_4784.dita`

Note:

When in doubt of the validity of the other employment, the agent must contact the client and complete the Subsequent employment — Labour dispute questionnaire (INS3619) form. Once the form has been completed, the agent must attach it to an email and send it to the appropriate Regional office for a decision.
       [Subsequent employment — Labour dispute questionnaire (INS3619)](http://forms-formulaires.prv/eform99/index.cfm?APP=FormsGrp&GroupNum=151&LANG=E) 
       [Regional office](https://esdc.prv/en/service-canada/ei/contacts/index.shtml)

     [Subsequent employment — Labour dispute questionnaire (INS3619)](http://forms-formulaires.prv/eform99/index.cfm?APP=FormsGrp&GroupNum=151&LANG=E) 
     [Regional office](https://esdc.prv/en/service-canada/ei/contacts/index.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4785.dita`

Note:

The regional office is responsible for completing, coordinating and assigning various tasks to avoid unnecessary contacts and enquiries. Regional officers can conduct the fact-finding themselves or assign the initial fact-finding to an agent; this fact-finding is not part of this task. 

## Regional considerations

Source topic: `en_EN/task/terminating_d5dld_rcc/regional_considerations.dita`

A regional officer in the region of the employer makes all decisions regarding labour disputes (e.g. start and end dates, dates of disentitlement and any exemptions from disentitlement). Once the fact-finding is complete and a decision concerning entitlement has been made, the regional officer posts the decision in the Major Employer Events .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

Atlantic and Western Canada and Territories regions — For events before May 14, 2018, the decisions concerning labour disputes can be found in the following databases:

- Atlantic region: Documents are stored in the regional common document share under EI Document Library / Employer Info / Labour Disputes

- Western Canada and Territories region: WT regional site
         [WT regional site](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/labour-memos.shtml) 

## What you need to look for

Source topic: `en_EN/task/terminating_d5dld_rcc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/terminating_d5dld_rcc/in_nws.dita`

- Are there any SROCs or WIs containing documents relating to the labour dispute?

- Are there any SROCs or WIs containing documents relating to other insurable employment? 

### In FTS:

Source topic: `en_EN/task/terminating_d5dld_rcc/in_fts.dita`

- Is there a D5 disentitlement on file?

- Is the claim type (CT) initial, renewal or continuing?

- Is there a 74 - Labour dispute manual action (MA74) imposed on the file? 

### In Imaging:

Source topic: `en_EN/task/terminating_d5dld_rcc/in_imaging.dita`

- Are there any imaged documents relating to the labour dispute?

- Are there any imaged documents relating to other insurable employment? 

### Major Employer Events:

Source topic: `en_EN/task/terminating_d5dld_rcc/major_employer_events.dita`

- Is there any information relating to the labour dispute? 

## Step by step

Source topic: `en_EN/task/terminating_d5dld_rcc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/terminating_d5dld_rcc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/terminating_d5dld_rcc/reviewing_the_file_level_1.dita`

- In FTS and RCM, determine if during the labour dispute, the client was regularly engaged elsewhere in insurable employment:

- If no, go to step 2.

- If yes, go to step 3.

- In NWS, determine if the labour dispute period has ended:

- If yes, go to step 4.

- If no, go to Labour dispute has not ended .
               [Labour dispute has not ended](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#denotterm)

- In FTS, determine the claim type:

- If it is a continuing claim, go to Reassigning the issue to Level 2 — Continuing claim
               [Reassigning the issue to Level 2 — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#reassign)

- If it is a renewal claim, go to Reassigning the issue to Level 2 — Renewal claim .
               [Reassigning the issue to Level 2 — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#level2) 

#### Reviewing the decision

Source topic: `en_EN/task/terminating_d5dld_rcc/reviewing_the_decision_level_1.dita`

- In the Major Employer Events , determine if the decision has been made with respect to the end date of the labour dispute:

- If no, go to step 5.

- If yes, go to step 7.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting a decision to be made and posted in the Major Employer Events regarding entitlement to EI benefits as a result of the labour dispute period expiring.”
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

- Bring forward date: Enter the current date + 10 working days.

- When the WI moves to the current workload, determine if a decision has been posted in the Major Employer Events :

- If no, repeat step 5.

- If yes, go to step 7. 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/terminating_d5dld_rcc/record_of_decision_rod__creation_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “labour dispute period ended — D5 terminated as of [date].”

- Details: Document the decision according to the information noted in the Major Employer Events .
               [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

- Select Save . 

#### Inputs and communication

Source topic: `en_EN/task/terminating_d5dld_rcc/inputs_and_communication_level_1.dita`

- In NWS, determine if the client is a part-time employee:

- If no, go to step 9.

- If yes, go to step 10.

- Follow the applicable procedure based on the claim type:

- Labour dispute has ended — Renewal claim
               [Labour dispute has ended — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#determ_renl1)

- Labour dispute has ended — Continuing claim
               [Labour dispute has ended — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#determ_contl1)

- Follow the applicable procedure based on the claim type:

- Labour dispute has ended — Part-time employment on a renewal claim
               [Labour dispute has ended — Part-time employment on a renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#determ_ptl1)

- Labour dispute has ended — Part-time employment on a continuing claim
               [Labour dispute has ended — Part-time employment on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#determ_ptcontl1) 

#### Labour dispute has not ended

Source topic: `en_EN/task/terminating_d5dld_rcc/labour_dispute_has_not_ended_level_1.dita`

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Decision maintained (2576): Select Decision maintained - still cannot pay benefits.

- Why decision maintained (2587) : Select but we still cannot pay you benefits because .

- Text: Specify reason(s) maintained (1626): Type “the period of the labour dispute with [employer] has not ended.”

- In NWS, complete the WI for the labour dispute issue. 

#### Labour dispute has ended — Renewal claim

Source topic: `en_EN/task/terminating_d5dld_rcc/labour_dispute_has_ended__renewal_claim_level_1.dita`

- In FTS, click the Disqualifications/Disentitlements link and terminate the disentitlement as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End date: Select the disentitlement end date.

- Detection: Select 31 - Other .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlement terminated and/or removed (2591): Select Disentitlement terminated-benefits payable .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding Correspondence (COR) Manual Decision WI:

- If no, go to step 14.

- If yes, go to step 16.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 15.

- If yes, go to step 16.

- Create a COR Manual Decision WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the Service Canada centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-01 letter required — labour dispute issue.”

- Select Save .

- In NWS, complete the ADJ WI for the labour dispute issue. 

#### Labour dispute has ended — Continuing claim

Source topic: `en_EN/task/terminating_d5dld_rcc/labour_dispute_has_ended__continuing_claim_level_1.dita`

- In FTS, determine if there is a registration number for the labour dispute issue:

- If yes, go to step11.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, click the Disqualifications/Disentitlements link and terminate the D5 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End date: Select the disentitlement end date.

- Detection: Select 31 - Other .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlement terminated and/or removed (2591): Select Disentitlement terminated-benefits payable .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, complete the WI for the labour dispute issue. 

#### Labour dispute has ended — Part-time employment on a renewal claim

Source topic: `en_EN/task/terminating_d5dld_rcc/labour_dispute_has_ended__part-time_emp_a3f4e78f_level_1.dita`

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the applicable registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 94 - Manual Action .

- Work Type: Select 15 - Manual Action code 11, 12 or 14 .

- Remarks line 1: Type “labour dispute period ended.”

- Remarks line 2: Type “D5 to be terminated as of [date].”

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlement terminated and/or removed (2591): Select Disentitlement terminated-benefits payable .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 18.

- If yes, go to step 20.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 19.

- If yes, go to step 20.

- Create a COR Manual Decision WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-01 letter required — labour dispute issue.”

- Select Save .

- In NWS, complete the ADJ WI for the labour dispute issue. 

#### Labour dispute has ended — Part-time employment on a continuing claim

Source topic: `en_EN/task/terminating_d5dld_rcc/labour_dispute_has_ended__part-time_emp_d6d9bc8f_level_1.dita`

- In FTS, determine if there is a registration number for the labour dispute issue:

- If yes, go to step 12.

- If no, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the applicable registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 94 - Manual Action .

- Work Type: Select 15 - Manual Action code 11, 12 or 14 .

- Remarks line 1: Type “labour dispute ended.”

- Remarks line 2: Type “D5 to be terminated as of [date].”

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlement terminated and/or removed (2591): Select Disentitlement terminated-benefits payable .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, complete the WI for the labour dispute issue. 

#### Reassigning the issue to Level 2 — Continuing claim

Source topic: `en_EN/task/terminating_d5dld_rcc/reassigning_the_issue_to_level_2__conti_8c8ed21c_level_1.dita`

- In NWS, reassign the WI as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type “labour dispute — not within Level 1 authority.” 

#### Reassigning the issue to Level 2 — Renewal claim

Source topic: `en_EN/task/terminating_d5dld_rcc/reassigning_the_issue_to_level_2__renewal_claim_level_1.dita`

- In NWS, create an ADJ WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option based on the client’s preferred language.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Next Available User .

- Issue(s): Select Other .

- Details: Type “labour dispute — not within Level 1 authority.” 

### Level 2

Source topic: `en_EN/task/terminating_d5dld_rcc/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/terminating_d5dld_rcc/reviewing_the_file_level_2.dita`

- Determine if there is enough information on file to adjudicate the other employment issue:

- If additional information is needed, go to step 2.

- If no additional information is needed, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/terminating_d5dld_rcc/fact-finding_level_2.dita`

- Fact-find with the client or employer. Refer to Digest 8 — Labour dispute .

- In NWS, determine if the client or employer was contacted during fact-finding:

- If yes, go to step 4.

- If no, go to step 5.

- Add to the draft SROC created during fact-finding or create a new SROC as follows:

- New SROC: Main Issue: Select Other .

- New SROC: Comments: Type “labour dispute — other employment.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save . 

#### Adjudication

Source topic: `en_EN/task/terminating_d5dld_rcc/adjudication_level_2.dita`

- Determine if the case raises any doubts as to the client’s entitlement:

- If yes, go to step 6.

- If no, go to step 9.

- In Outlook, create and send an email to the appropriate Regional office with a request to review the case and determine the validity of the information as well as the client’s entitlement to benefits. (If applicable, attach the INS3169 form.)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Request sent to the regional officer to review case and determine validity of the information as well as client’s entitlement to EI benefits during the labour dispute.”

- Bring forward date: Enter today’s date + 10 working days.

- When the WI moves to the current workload, determine if a decision has been made for this particular case:

- If no, return to step 7.

- If yes, go to step 9.

- Adjudicate the client’s other employment based on the entitlement principles set out in Digest 8 — Labour disputes . 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/terminating_d5dld_rcc/record_of_decision_rod__creation_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Select the appropriate option:

- Type “Other employment/disentitlement not terminated.”

- Type “Other employment/disentitlement terminated.”

- Details: Document the decision according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save . 

#### Inputs and Communication

Source topic: `en_EN/task/terminating_d5dld_rcc/inputs_and_communication_level_2.dita`

- Follow the applicable procedure based on your decision and the status of the claim:

- Disentitlement not terminated — Renewal claim
               [Disentitlement not terminated — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#denotterm_ren)

- Disentitlement not terminated — Continuing claim
               [Disentitlement not terminated — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#denotterm_cont)

- Disentitlement terminated — Renewal claim
               [Disentitlement terminated — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#determ_ren)

- Disentitlement terminated — Part-time employment on a renewal claim
               [Disentitlement terminated — Part-time employment on a renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#determ_pt)

- Disentitlement terminated — Continuing claim
               [Disentitlement terminated — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#determ_cont)

- Disentitlement terminated — Part-time employment on a continuing claim
               [Disentitlement terminated — Part-time employment on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d5dld_rcc#determ_contpt) 

#### Disentitlement not terminated — Renewal claim

Source topic: `en_EN/task/terminating_d5dld_rcc/disentitlement_not_terminated__renewal_claim_level_2.dita`

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Decision Maintained (2576): Select Decision maintained-still cannot pay benefits .

- Why decision  maintained (2587): Select but we still cannot pay you benefits because .

- Text: Specify reason(s) maintained (1626) .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 15.

- If yes, go to step 17.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 16.

- If yes, go to step 17.

- Create a COR Manual Decision WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-01 letter required — labour dispute issue.”

- Select Save .

- In NWS, complete the ADJ WI for the labour dispute issue. 

#### Disentitlement not terminated — Continuing claim

Source topic: `en_EN/task/terminating_d5dld_rcc/disentitlement_not_terminated__continuing_claim_level_2.dita`

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Decision Maintained (2576): Select Decision maintained-still cannot pay benefits .

- Why decision maintained (2587): Select but we still cannot pay you benefits because .

- Text: Specify reason(s) maintained (1626) .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, complete the WI for the labour dispute issue. 

#### Disentitlement terminated — Renewal claim

Source topic: `en_EN/task/terminating_d5dld_rcc/disentitlement_terminated__renewal_claim_level_2.dita`

- In FTS, click the Disqualifications/Disentitlements link and terminate the disentitlement as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End date: Select the disentitlement end date.

- Detection: Select 31 - Other .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: D - No .

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlement terminated and/or removed (2591): Select Disentitlement terminated-benefits payable .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 16.

- If yes, go to step 18.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 17.

- If yes, go to step 18.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-01 letter required — labour dispute issue.”

- Select Save .

- In NWS, complete the ADJ WI for the labour dispute issue. 

#### Disentitlement terminated — Part-time employment on a renewal claim

Source topic: `en_EN/task/terminating_d5dld_rcc/disentitlement_terminated__part-time_em_db45154d_level_2.dita`

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the applicable registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 94 - Manual Action .

- Work Type: Select 15 - Manual Action code 11, 12 or 14 .

- Remarks line 1: Type “labour dispute — entitled to benefits.”

- Remarks line 2: Type “D5 to be terminated as of [date].”

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlement terminated and/or removed (2591): Select Disentitlement terminated-benefits payable .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 19.

- If yes, go to step 21.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 20.

- If yes, go to step 21.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-01 letter required — labour dispute issue.”

- Select Save .

- In NWS, complete the ADJ WI for the labour dispute issue. 

#### Disentitlement terminated — Continuing claim

Source topic: `en_EN/task/terminating_d5dld_rcc/disentitlement_terminated__continuing_claim_level_2.dita`

- In FTS, determine if there is a registration number for the labour dispute issue:

- If yes, go to step 13.

- If no, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, click the Disqualifications/Disentitlements link and terminate the disentitlement as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End date: Select the disentitlement end date.

- Detection: Select 31 - Other .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlement terminated and/or removed (2591): Select Disentitlement terminated-benefits payable .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, complete the WI for the labour dispute issue. 

#### Disentitlement terminated — Part-time employment on a continuing claim

Source topic: `en_EN/task/terminating_d5dld_rcc/disentitlement_terminated__part-time_em_5b1a1c1b_level_2.dita`

- In FTS, determine if there is a registration number for the labour dispute issue:

- If yes, go to step 13.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the applicable registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 94 - Manual Action .

- Work Type: Select 15 - Manual Action code 11, 12 or 14 .

- Remarks line 1: Type “labour dispute ended.”

- Remarks line 2: Type “D5 to be terminated as of [date].”

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlement terminated and/or removed (2591): Select Disentitlement terminated-benefits payable .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, complete the WI for the labour dispute issue. 

## Policy reference

Source topic: `en_EN/task/terminating_d5dld_rcc/policy_reference.dita`

- Digest Chapter 8 — Labour disputes
         [Digest Chapter 8 — Labour disputes](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-8/table-of-contents.html)

- EIA 36
         [EIA 36](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-36.html) 
