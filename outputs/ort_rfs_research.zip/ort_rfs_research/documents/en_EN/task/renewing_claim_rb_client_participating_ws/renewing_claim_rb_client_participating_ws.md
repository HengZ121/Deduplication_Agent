# Renewing a claim for regular benefits when a client is participating in Work-Sharing

Source map: `en_EN/task/renewing_claim_rb_client_participating_ws/renewing_claim_rb_client_participating_ws.ditamap`

## Summary

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/summary.dita`

Summary: When a client participating in Work-Sharing (WS) submits a claim for regular benefits within the benefit period (BP), including any extensions that apply, the BP can be renewed. 

## What you need to know

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/untitled_section.dita`

In NWS:

- Did the client apply with a reference code for WS?

- Does the client have a 900-series SIN?

- Does the client work for anyone other than the WS employer?

- Is there an ROE on file?

- Are there earnings,  separation monies, motor vehicle accident compensation, workers’ compensation benefits (WCB) or wage loss insurance (WLI) payments to consider or allocate?

- Was an RFS previously deferred?

- Is there an ADJ WI?

- Are there any uploaded documents that may impact the renewal claim?

In FTS:

- Is there a renewable BP?

- What is the LRW showing?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Is there a registration number?

- Is the project data on file for the WS?

- Is an MA2 imposed on the claim?

In RCM:

- Has an ROE been submitted?

- Are there earnings, separation monies, motor vehicle accident compensation, WCB or WLI payments to consider or allocate?

In Imaging:

- Is there any other documentation that may impact the renewal claim? 

### Inputting the WS agreement project data

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/inputting_the_ws_agreement_project_data.dita`

The officer uses the reference code and the normal weekly hours (NWH) to complete the Project Data - Work-sharing (M171) transaction. The 16-digit alphanumeric reference code contains the following information:

- Service Canada processing centre (digits 1–4)

- specialized application form type ( 03 is used for WS) (digits 5–6)

- unique identifier (digits 7–10)

- WS agreement start date (w/c) (digits 11–14)

- weeks of WS agreement duration (digits 15–16)

The officer enters digits 1–10 in the Project number field. The system updates the project number with the agreement number when the first utilization report (UR) is processed. When the officer has the agreement number, the officer enters it in the Project number field.

The officer enters digits 11–14 as the w/c in the Start date field. The officer calculates the w/c to enter in the End date field using the Start date + the number of weeks represented in digits 15 and 16 – 1. 

### Conditions required for a renewal

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/conditions_required_for_a_renewal.dita`

The officer can renew a claim to pay WS benefits for a WS client when all the following conditions are met:

- The client requests WS benefits.

- The client is part of a WS agreement.

- The client qualifies for regular benefits.

- The client’s claim can be renewed for at least one week during the WS period.

- The client is requesting benefits within BPC + 51 + weeks of BP extension + weeks of WS processed.

- The client has remaining entitlement to any benefit type (BT). Remaining entitlement to regular benefits is not required.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4468.dita) 

### Renewal advantages

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/renewal_advantages.dita`

When assessing a WS renewal, it is generally to the client’s advantage to renew the existing BP because regular entitlement is not used to pay WS benefits, and the BP is extended by one week for each week that is processed as WS. However, WS may reduce the insurable earnings in the rate calculation period (RCP) for any subsequent BPC.

If a deferred adjudication results in a disqualification on a renewal claim, a new BPC is required to pay WS benefits.

For more information, the officer refers to Cancelling, voiding, terminating or withdrawing a claim .
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml) 

### Effective date of a renewal

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/effective_date_of_a_renewal.dita`

The program officer determines when employees begin their participation in a WS agreement. This information is sent to the regional WS GD mailbox. Upon receipt of the email, a reference code is issued. It is then distributed to the WS employees by the employer or employee representative.

When a WS client submits an EI application with a reference code, the renewal week is the WS agreement start date (digits 11–14 of the reference code). The officer antedates the renewal to the WS agreement start week, if necessary.

At the start of an agreement, all WS employees receive the same reference code. When WS employees are added to the agreement in subsequent weeks, a new reference code is issued to them. This is because the reference code contains the w/c that will be entered as the start date of their participation in the WS agreement. The client’s first UR will match the agreement start date. If necessary, the officer contacts the WS unit or regional WS coordinator to obtain or confirm the agreement details.

When a client submits an EI application without a reference code, the officer determines if they are part of a WS agreement. Clients apply without reference codes for a variety of reasons. In some cases, the client applies within the period of a valid reference code but does not use it when completing the application. In these situations, it is possible that the claim can start in the week specified by the unused reference code. In other cases, the client waits too long to apply and the reference code is no longer valid. In these situations, the officer determines the effective date of renewal in the same way as a claim for regular benefits by referring to Determining the effective date of a renewal or a conversion . In all cases, to determine the renewal week, the officer reviews the date of application and the WS agreement information.
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4469.dita) 

### Exemption from reporting

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/exemption_from_reporting.dita`

WS clients can be exempted from completing claimant’s reports. If the client agrees to the conditions for the exemption from reporting, the officer ensures the exemption is input. For additional information, the officer refers to Exemption from reporting .
       [Exemption from reporting](/en/procedure/activity/exemption_reporting.shtml) 

### Allocation of monies

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/allocation_of_monies.dita`

Earnings that arise from WS employment are not deducted in a WS week. This includes, but is not restricted to the following monies:

- vacation pay;

- statutory holiday pay;

- bonuses;

- shift premiums;

- a pay-out of overtime or compensatory leave that was not taken;

- any other monies the WS employer owes the employee outside of normal wages for work performed.

Only earnings received from outside the WS employment are deducted from a WS week. When a week is considered a non-WS week, earnings from the WS employment are considered and subject to the normal allocation rules.

Whenever clients report receiving other monies, the officer determines if these monies are considered earnings for EI purposes. If the officer determines that the monies are earnings, they must be allocated. To determine how the earnings are allocated, the officer refers to Earnings .
       [Earnings](/en/procedure/activity/earnings.shtml) 

### Waiting period (WP)

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/waiting_period_wp.dita`

When a client receives WS benefits, the WP or any outstanding WP earnings (i.e. monies from outside the WS employment) are automatically deferred until a week is processed as a week of regular or special benefits. This could happen either during the period of the WS agreement or once the agreement has ended. The client does not need to request that the WP be deferred. 

### Duration of the benefit period (BP)

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/duration_of_the_benefit_period_bp.dita`

The duration of the BP is the length of time in which the client can claim benefits to which they are entitled. While WS benefits are paid on a regular CT, regular benefits entitlement is not reduced when a week of WS is paid. It is not required to have regular benefits entitlement weeks left on the claim to receive WS benefits. WS benefits can be paid within BPC + 51 + weeks of BP extension + weeks of WS processed (i.e. when one WS week is processed during the BP, the BP is extended by one week).

When a BP is extended to pay special benefits, WS benefits cannot be paid during the extended portion of the BP. 

### Work-Sharing (WS) agreement continues beyond BPC + 103

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/work-sharing_ws_agreement_continues_bey_2550a6a5.dita`

There is no limit to the number of weeks that a BP can be extended due to WS.

The BP is extended by one week for each week of WS benefits processed. Benefits can be paid beyond BPC + 103, but they must be paid in MPS once BPC + 103 is reached.

If the WS agreement’s end date is greater than BPC + 103, the officer enters the client’s BPC + 103 week in the End date field of the M171.

If a claim reaches BPC + 103, clients must submit a new EI application for regular benefits to receive benefits for the remainder of the WS agreement. The officer advises the client by letter. The officer also documents this information, along with the agreement details, on a record of decision (ROD).

When the new claim is assessed, the client can establish a new BP in CPS or renew the existing BP in MPS to receive benefits during the remainder of the WS agreement. 

### Weeks of entitlement

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/weeks_of_entitlement.dita`

WS weeks are only paid during the period of the WS agreement. There is no limit to the number of weeks of WS benefits clients can receive during their BP. The payment of WS benefits does not use regular or other entitlement to benefits.

When work is not shared during a WS agreement week (e.g. plant shut down), the week is processed as regular benefits. If weeks of regular entitlement remain available, provided the WP has been served, the client may be paid regular benefits for this week after considering any deductions from benefits from allocations or disentitlements.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4470.dita) 

When the client reports 5 sick days, the client may be paid sickness benefits for this week, provided that available sickness entitlement weeks remain. 

### Deferred reason for separation (RFS)

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/deferred_reason_for_separation_rfs.dita`

After converting a claim to WS benefits, any deferred or new RFS must be adjudicated.

If adjudication of the RFS is deferred, the officer enters a disqualification in FTS when special benefits are allowed. Officers always verify if any contentious RFS was adjudicated by checking for a ROD in NWS. If the RFS was adjudicated and a 10 - Dismissal - misconduct proven (D10) or 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no WS benefits are payable on this claim.

If there is a ROD on file indicating that adjudication of an RFS was deferred or if there is an RFS that has not yet been adjudicated, the RFS must be adjudicated. A Level 1 officer can adjudicate the RFS according to the National Policy on Levels of Decision . If it is not within Level 1 authority, the RFS is reassigned to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 

### Disqualifications

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/disqualifications.dita`

The serving of a disqualification can be carried forward or suspended while the client receives WS benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2890.dita) 

If there is an outstanding disqualification on the claim for a reason other than voluntary leaving or misconduct, the disqualification must be referred to Level 2 for adjudication. The level 2 officer determines if the outstanding disqualification must be carried forward or suspended for the duration of the WS benefits. 

### Disentitlements

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/disentitlements.dita`

The serving of a disentitlement is automatically deferred while the client receives WS benefits unless it is one of the following disentitlements:

- 5 - Labour dispute (D5)

- 12 - Inmate of penal institution (D12)

- 13 - Outside Canada (D13)

- 14 - Void benefit period (D14)

- 15 - Claim procedure (D15)

- 21 - Claimant refuses payment (D21)

- 38 - On vacation in Canada (D38)

- 39 - Prevent payment of part II benefits and/or incorrect Part I benefits (D39)

- 42 - Suspension from employment (D42)

- 43 - Leave of absence (D43)

- 48 - Moved-address unknown (D48)

If there is an outstanding disentitlement on the claim that will not be automatically deferred, the officer reviews the disentitlement to determine if it still applies on the renewal. A Level 1 officer can terminate the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . When the information on file allows for the disentitlement to be terminated, the disentitlement ends on the Friday of the week before the renewal week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer refers the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer can refer to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Contentious issues

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/contentious_issues.dita`

When renewing a claim, a client can report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If the issue is reported on the application, the system creates an Adjudication Issue (ADJ) WI. If there is a ROD on file indicating that adjudication of an RFS was deferred or if there is an RFS that has not yet been adjudicated, the RFS must be adjudicated. If a contentious issue is detected while reviewing the claim and the Level 1 officer cannot allow the issue according to the National Policy on Levels of Decision , the Level 1 officer reassigns the issue to Level 2. The Level 1 officer verifies that there is an ADJ WI for each contentious issue or creates an ADJ WI for each contentious issue and reassigns the issue to Level 2 for adjudication.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

When an ADJ WI is created on a renewal claim, either manually or by the system, the system automatically imposes a 2 - Contentious Renewal in Automation manual action (MA2) to prevent payment of benefits until the contentious issue is adjudicated and the renewal is completed. When the renewal or a decision must be input manually, the transactions must be input before the Claim Assessment (CA) or ADJ WI is completed, because ACP rescinds the MA2 when the CA and ADJ WIs are completed and there are no outstanding ADJ WIs. An officer cannot rescind an MA2. 

### Temporary foreign workers (900-series SIN)

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/temporary_foreign_workers_900-series_sin.dita`

Temporary foreign workers can participate in WS and receive WS benefits. When a client with a 900-series SIN applies for WS benefits, the officer determines the client’s entitlement. For more information, the officer refers to Determining entitlement for a client with a valid 900-series SIN or Actioning an expired 900-series SIN — Regular or sickness benefits .
       [Determining entitlement for a client with a valid 900-series SIN](/en/procedure/task/deter_entitlement_900series_sin.shtml) 
       [Actioning an expired 900-series SIN — Regular or sickness benefits](/en/procedure/task/actioning_expired_900series_rsb.shtml) 

### Claim action status and processing of the claim

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/claim_action_status_and_processing_of_the_claim.dita`

The Claim action status Renewal is created when a renewal decision is registered. There are 3 Claim action statuses that can be displayed:

- In Progress (Automation) is displayed on the Client information tree when there is one or more outstanding adjudication issues.

- In Progress (Manual) is displayed on the Client information tree when there is no outstanding adjudication issue and there is an outstanding CA or Specialized Application (SA) WI.

- Finalized is displayed on the Client information tree when all ADJ WIs are completed and the renewal week has been successfully input.

An ADJ WI is created for every new contentious issue. When opening an ADJ WI, the officer always checks to see if there is a Resolve Issue tab. If there is a Resolve Issue tab, the officer documents the decision directly in the ADJ WI by completing all mandatory screens. When the ADJ WI is completed, NWS creates a ROD based on the Resolve Issue screens. When the renewal is finalized, the system also generates the required transactions (e.g. signature code, disentitlement) based on the Resolve Issue screens. If a disentitlement or indefinite disqualification is imposed, the system creates a Correspondence (COR) WI for the D-01-00-00 letter. This means that the officer with the CA or SA WI has no action to perform for these ADJ WIs.

When there is no Resolve Issue tab for the ADJ WI, the officer creates a ROD, generates the required transactions and sends the appropriate letter. If there is an outstanding CA or SA WI when the officer completes the ADJ WI, a client Note is created and the officer with the CA or SA WI follows the instructions to input the transactions or send the letter. 

### ACS letters

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/acs_letters.dita`

Communication of the renewal decision is not necessary when the only transaction input is the renewal transaction. When another decision is input at the time of the renewal (disentitlement, disqualification or allocation of earnings), communication of the decision is necessary.

Written communication of the decision is usually done by officers who are responsible for sending the appropriate ACS letter. Under particular situations, the R-01-00-00 letter is sent automatically. Officers ensure that the letter was sent and, if the letter was not sent, they create and send the letter of decision in ACS.

If a renewal and an allocation are input by the same officer and are processed on the same day, the R-01-00-00 letter is, in most cases, created automatically.

There are some exceptions. The letter does not automate if one of the following conditions is met:

- One of the transactions (M106 or M175) rejects.

- The allocation code on the M175 is A .

- An E or W allocation is input for more than one week.

- One of the following manual actions (MAs) to stop payment is imposed:

- A disqualification or disentitlement is being input.

- A disqualification or disentitlement is already on file and is not being rescinded or terminated.

In some cases, the letter can be automated but additional decisions must be communicated. To prevent duplication of letters, the officer prevents the automated letter from being sent by using the Automated Letter Bypass function in FTS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4471.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4468.dita`

Note:

When a WS claim is renewed on a claim for which regular entitlement is exhausted, the claim must be processed in MPS. 

### Note

Source topic: `en_EN/common_notes/note_c_4469.dita`

Note:

When the client indicates a last day worked (LDW) in the first week of WS with reported earnings exceeding 125% of the benefit rate, ACP postdates the renewal to the following week. As earnings from WS employment are not deducted in a WS week, the claim must not be postdated. Only earnings received from outside the WS employment are considered earnings and deducted from a WS week. The officer corrects the postdate in these cases. 

### Note

Source topic: `en_EN/common_notes/note_c_4470.dita`

Note:

If regular entitlement is exhausted during a WS claim, the remaining WS period must be processed in MPS. 

### Note

Source topic: `en_EN/common_notes/note_c_2890.dita`

Note:

A disqualification for voluntary leaving or misconduct is not suspended in order to pay WS benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_4471.dita`

Note:

An F-00-00-00 letter is required if the client’s WS agreement ends after BPC + 103. 

## Regional considerations

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/regional_considerations.dita`

```text
| Regional WS coordinators |

| Region | Coordinator | Email |

| Atlantic | Business Expertise Consultants | esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca [esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca](mailto:esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca) |

| Quebec — specialized region | Business Expertise Consultants | Work-Sharing Reference Tool |

| Quebec — outside specialized region | Business Expertise Consultants | esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca [esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca](mailto:esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca) |

| Ontario | Team leader | on-eibp_tpae-worksha@servicecanada.gc.ca [on-eibp_tpae-worksha@servicecanada.gc.ca](mailto:on-eibp_tpae-worksha@servicecanada.gc.ca) |

| Western Canada and Territories | IPOC | bc-ipoc_copa-ws_tp-gd@servicecanada.gc.ca [bc-ipoc_copa-ws_tp-gd@servicecanada.gc.ca](mailto:bc-ipoc_copa-ws_tp-gd@servicecanada.gc.ca) |
``` 

## What you need to look for

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/untitled_section.dita`

In NWS:

- Did the client apply with a reference code for WS?

- Does the client have a 900-series SIN?

- Does the client work for anyone other than the WS employer?

- Is there an ROE on file?

- Are there earnings,  separation monies, motor vehicle accident compensation, workers’ compensation benefits (WCB) or wage loss insurance (WLI) payments to consider or allocate?

- Was an RFS previously deferred?

- Is there an ADJ WI?

- Are there any uploaded documents that may impact the renewal claim?

In FTS:

- Is there a renewable BP?

- What is the LRW showing?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Is there a registration number?

- Is the project data on file for the WS?

- Is an MA2 imposed on the claim?

In RCM:

- Has an ROE been submitted?

- Are there earnings, separation monies, motor vehicle accident compensation, WCB or WLI payments to consider or allocate?

In Imaging:

- Is there any other documentation that may impact the renewal claim? 

## Step by step

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/reviewing_the_file_level_1.dita`

- In NWS, determine if there is a SIR Validation (SIR) WI:

- If yes, go to step 2.

- If no, go to step 4.

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for the SIR WI to be completed.”

- Bring forward date: Enter today’s date + 10 days.

- When the CA WI moves to the current workload, determine if the SIR WI has been completed:

- If no, repeat step 2.

- If yes, go to step 4.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4472.dita)

- In FTS, determine if a registration number related to the renewal is on file:

- If yes, go to step 5.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- Go to step 5.

- In NWS, determine the type of application:

- If the client applied with a standard application, go to step 6.

- If the client applied with a specialized application, go to step 8.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4473.dita)

- Determine if this is a WS claim from the Quebec or Ontario region:

- If yes, go to step 7.

- If no, go to step 8.

- Determine if the CA WI is assigned to the regional WS unit or if you work for the regional WS unit:

- If yes, go to step 8.

- If no, go to Reassign the WI to the WS unit .
               [Reassign the WI to the WS unit](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renewing_claim_rb_client_participating_ws#reassign)

- Determine if the client reports having received monies that do not arise from WS employment and whether the monies have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings . Go to step 9.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 9.

- If no monies were reported, go to step 9.

- In NWS and in FTS, determine if one of the following conditions exists to extend the BP:

- The client was incarcerated and has since been tried and not found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If none of the conditions exist, go to step 10.

- If one of the conditions exists, refer to Extension of the benefit period . Go to step 10.
                   [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

- In FTS, determine if a D10 or D11 disqualification is imposed as a result of adjudication:

- If yes and the client has worked since the BPC, go to step 11.

- If yes and the client has not worked since the BPC, go to No benefits payable due to a 10 - Dismissal - misconduct proven or 11 - Voluntary leaving - just cause not proven disqualification .
               [No benefits payable due to a 10 - Dismissal - misconduct proven or 11 - Voluntary leaving - just cause not proven disqualification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renewing_claim_rb_client_participating_ws#level1_item_2)

- If no, go to step 12.

- Determine if the client qualifies for a new claim:

- If no, go to No benefits payable due to a 10 - Dismissal - misconduct proven or 11 - Voluntary leaving - just cause not proven disqualification .
               [No benefits payable due to a 10 - Dismissal - misconduct proven or 11 - Voluntary leaving - just cause not proven disqualification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renewing_claim_rb_client_participating_ws#level1_item_2)

- If yes, refer to Calculating or recalculating a claim for regular benefits .
               [Calculating or recalculating a claim for regular benefits](/en/procedure/activity/calculation.shtml)

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 13.

- If no, go to step 15.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, go to step 14.

- If no, the D15 issue must be sent to Integrity. Refer to Creating or reassigning a WI — Integrity . Go to step 15.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- In NWS, create an ADJ as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Next Available User .

- Issue(s): Select Availability .

- Details: Type “Outstanding D15 for a missed client information session requires Level 2 review.”

- Go to step 15.

- Determine if any of the following issues are present for which there is no ADJ WI:

- A disqualification is imposed other than a D10 or D11.

- An outstanding disentitlement is on file other than a D5, D12, D13, D14, D15, D21, D38, D39, D42, D43 or a D48.

- There is an outstanding issue that requires adjudication.

- If any of the conditions are met, go to step 16.

- If none of the conditions are met, go to step 18.

- In NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate issue (e.g. Availability ).

- Complete the mandatory fields required for the issue.

- Details: Indicate the reason the WI is being created.

- Determine if the conditions are met to render a decision at Level 1:

- If yes, refer to appropriate task for adjudication. Go to step 18.

- If no, reassign the WI for Level 2 as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type “Outstanding issue on file [indicate the issue requiring adjudication] requires review by Level 2.”

- Go to step 18.

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4474.dita)

- In NWS, determine if there are weeks of entitlement to regular benefits remaining:

- If yes, go to step 19.

- If no, go to Maximum regular benefits already paid .
               [Maximum regular benefits already paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renewing_claim_rb_client_participating_ws#NotRenewal)

- In FTS, select the Renewal/Revised (M106) transaction and complete the following fields:

- Registration number: Select the renewal registration number.

- Renewal: Select the appropriate option:

- If the client applied during the validity period of the reference code, select the WS agreement start date (digits 11–14 of the reference code).

- If the client applied after the validity period of the reference code, select the renewal week determined by referring to Determining the effective date of a renewal or conversion .
                   [Determining the effective date of a renewal or conversion](/en/procedure/task/deter_date_ren_conv.shtml)

- Claim type: Select 2 - Regular .

- Manual action: Select the appropriate option:

- If the client applied with a standard application, select 76 - Automated work-sharing .

- If the client applied with a specialized application, leave this field blank.

- Claim action: Select the appropriate option:

- If the client has requested and is entitled to be exempt from completing claimant’s reports, select W - Worksharing - No claimant’s reports .

- If the client has not requested or is not entitled to be exempt from completing claimant’s reports, select H - Worksharing with claimant’s reports .

- Contentious: Select the appropriate option:

- If the renewal did not require Level 2 adjudication, select 1 - No .

- If the renewal required Level 2 adjudication, select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, or if there is an MA2 on file, select D - No .

- Select Update .

- In FTS, determine if the project data is on the Project tab:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4475.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4476.dita)

- Determine if the WS agreement end date is beyond the BPC + 103:

- If yes, go to step 22.

- If no, go to step 24.

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type:
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2895.dita)

- In NWS, create a new ROD as follows:

- Main Issue: Select Other .

- Comments: Type “Work-Sharing beyond client’s last renewable week (BPC + 103).”

- Details: Type “The client’s Work-Sharing agreement ends after the client’s last renewable week. The client has been advised by letter to reapply for benefits at the conclusion of this claim. At that time, the client will apply for regular benefits without a reference code. The following details can be used to complete the project data for the subsequent claim:

- Employer name: Enter the employer’s name.

- Original project start week: Enter the project start week.

- Project end week: Enter the project end week.

- Service Canada Centre: Enter the project SCC.

- Agreement number: Enter the agreement number.

- Weekly hours: Enter the weekly hours.”

- Select Save .

- Determine if there is an allocation of earnings that must be communicated to the client:

- If yes, go to step 25.

- If no, go to step 30.

- Determine if one of the following situations applies:

- A disentitlement or definite disqualification is being input manually.

- There is an indefinite disqualification preventing payment on the renewal claim.

- If yes, go to step 26.

- If no, go to step 30.

- Select the File Control Data (M101) transaction and do the following:

- Select Claim Action .

- Select Automated Letter Bypass .

- In ACS, create the D-01-00-00 letter or add details to the draft D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- To advise the client that the indefinite disqualification cannot be rescinded, select Disqualifications - Definite / Indefinite - Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542) .

- Select Disqualification message (2543) .

- To advise the client of the D15: Select Disentitlements (2976) .

- To advise the client of the allocation: Select Allocation of Earnings (2516) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, determine if there is an outstanding decision:

- If no, send the D-01-00-00 letter.

- If yes, save the D-01-00-00 letter.

- In ACS, determine if there are any saved letters for the renewal claim:

- If yes, go to step 30.

- If no, go to step 31.

- Determine if all decisions that must be communicated to the client were included in the D-01-00-00 letter:

- If yes, delete the saved letters. Go to step 31.

- If no, send the letters with only the decisions that are left to be communicated. Go to step 31.

- Complete the SA or CA Renewal WI. 

#### No benefits payable due to a 10 - Dismissal - misconduct proven or 11 - Voluntary leaving - just cause not proven disqualification

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/no_benefits_payable_due_to_a_10_-_dismi_fe743176_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Work-Sharing benefits requested — benefits not payable.”

- Details: Type “No renewal for Work-Sharing benefits is possible as [reason WS benefits not payable].” Choose the appropriate option:

- If the client has not worked since the BPC , type “The client does not qualify for a new claim as no hours were accumulated after the BPC.”

- If the client has worked since the BPC , type “The client does not qualify for a new claim as [number of hours] were accumulated after the BPC. The client needed [number of hours] to qualify.”

- In FTS, select the Renewal/Revised (M106) transaction and complete the following fields:

- Claim denied: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246).

- Disqualifications - Definite / Indefinite - Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542).

- Disqualification message (2543) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the SA or CA Renewal WI. 

#### Maximum regular benefits already paid

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/maximum_regular_benefits_already_paid_level_1.dita`

- Determine if there is an outstanding ADJ WI:

- If yes, go to step 2.

- If no, go to step 4.

- Move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting Level 2 decision”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if all ADJ WIs are completed:

- If no, return to step 2.

- If yes, go to step 4.

- Determine if an ADJ WI resulted in a disqualification:

- If yes, go to step 5.

- If no, go to step 11.

- Determine if the client worked for another employer after the disqualification start week:

- If yes, go to step 6.

- If no, go to step 7.

- Determine if the client qualifies for a new claim:

- If no, go to step 7.

- If yes, go to step 11.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4477.dita)

- In NWS, create a ROD as follows:

- Comments: Type “No renewal - Work-Sharing benefits not payable.”

- Details: Choose the appropriate option:

- If the client has not worked since the BPC , type “No renewal for Work-Sharing benefits is possible as [reason WS benefits not payable]. The client does not qualify for a new claim as no hours were accumulated after the week for which a disqualification applies.”

- If the client has worked since the BPC , type “No renewal for Work-Sharing benefits is possible as [reason WS benefits not payable]. The client does not qualify for a new claim as [number of hours] was accumulated after the week for which a disqualification applies. The client needed [number of hours] to qualify.”

- In FTS, select the Renewal/Revised (M106) transaction and do the following:

- Claim denied: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, add details to the draft of the D-01-00-00 letter and send it. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246) .

- Allocation of Earnings (2516) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the SA or CA Renewal WI. No further action is required.

- Determine the renewal week.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4474.dita)

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 36 - Special benefits on fishing claims or other complex claim conditions .

- Remarks line 1: Type “WS renewal — regular exhausted (C460).”

- Remarks line 2: Type “CT 2, MA76, REN w/c [XXXX], NO-CR-CODE (if necessary).”

- Remarks line 3: Type “Project start date [XXXX] end date [XXXX] SCC [XXXX].”

- Remarks line 4: Type “Project Number [XXXXXXXXX] NWH [XXX].”

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag.

- Registration flag: Select 04 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, complete the SA or CA Renewal WI. 

#### Reassign the WI to the WS unit

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/reassign_the_wi_to_the_ws_unit_level_1.dita`

- In NWS, reassign the WI as follows:

- Destination — Level: Select the appropriate option based on the region of the employer’s head office:

- Ontario: 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - ON / Work-Sharing - ON .

- Quebec: 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC / Work-Sharing - QC .

- Reason: Select Unable to complete .

- Details: Type “BT is processed by specialized unit.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_4472.dita`

Note:

When the client applies with a reference code, an SA WI is generated. When the client applies without a reference code, a CA WI is generated. When the task refers to a CA WI, it also applies to an SA WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4473.dita`

Note:

When a WS application is submitted without a reference code, it may be necessary to fact-find with the client or the regional WS unit to confirm that the client is participating in a WS agreement and to obtain the WS project information required for the project data.
       [fact-find](/en/procedure/task/fact_find.shtml)

     [fact-find](/en/procedure/task/fact_find.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_4474.dita`

Note:

Postdate or antedate the renewal for a WS claim to the project start week, even if the postdate or antedate is more than one week, provided the reference code was valid when the client applied. 

#### Note

Source topic: `en_EN/common_notes/note_c_4475.dita`

Note:

If the agreement details are on file (e.g. a ROD), the reference code is not necessary. Complete the M171 from the agreement details. 

#### Note

Source topic: `en_EN/common_notes/note_c_4476.dita`

Note:

Only hours or half hours can be entered in the Weekly Hours field. Hours must be rounded up to the closer of the next hour or half hour. For example, 27.25 hours becomes 27.5 hours (entered as 275) and 38.75 hours becomes 39 hours (entered as 390).

If the number of hours normally worked in a week exceeds 60 hours, the claim must be processed in MPS . Contact EI Operational Processes and Procedures at NC-BM-GDP-GD to review the file to determine if an averaging formula can be used to simplify the work and prevent MPS processing.
       [MPS](/en/procedure/activity/mps.shtml) 
       [NC-BM-GDP-GD](/mailto:NC-BM-GDP-GD)

     [MPS](/en/procedure/activity/mps.shtml) 
     [NC-BM-GDP-GD](/mailto:NC-BM-GDP-GD) 

#### Callout

Source topic: `en_EN/common_notes/note_c_2895.dita`

“Your current Work-Sharing agreement is valid until [Saturday of the last agreement week]. Under the Employment Insurance Act, the maximum duration for a benefit period is 104 weeks. Therefore, your Employment Insurance claim will end on or before [day 6 of BPC + 103].

If you are still participating in a Work-Sharing agreement at the end of your claim, take the following steps to avoid delays in benefit payments:

1. Apply for benefits

Submit an application for regular benefits after your claim ends (no reference code is needed for this new application). Enter [day 6 of BPC + 103] as your last day of work and choose I have a Work-Sharing agreement as the reason for separation.

2. Request a record of employment

Request your Work-Sharing employer issue a record of employment (ROE) for work up to [day 6 of BPC + 103], using code H-Work-Sharing . If you have had any other work since [day 1 of BPC], request each employer issue an ROE for all work up to, but not past, [day 6 of BPC + 103].

If you have any questions, contact us as indicated below.” 

#### Note

Source topic: `en_EN/common_notes/note_c_4477.dita`

Note:

If there is a ROD on file indicating that the client qualifies for a new claim and that no disqualification should be imposed because the client has enough hours since the disqualifying event, renew the claim instead of establishing a new one. 

## Policy reference

Source topic: `en_EN/task/renewing_claim_rb_client_participating_ws/policy_reference.dita`

- EIA 10 (10)
         [EIA 10 (10)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-10.html#215961)

- EIA 10 (13)
         [EIA 10 (13)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-4.html#h-216010)

- EIA 12
         [EIA 12](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIR 26(1)
         [EIR 26(1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-26.1.html)

- EIR 44
         [EIR 44](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-44.html)

- Digest 25 — Work-Sharing
         [Digest 25 — Work-Sharing](https://www.canada.ca/fr/emploi-developpement-social/programmes/assurance-emploi/ae-liste/rapports/guide/ch-25/table-des-matieres.html) 
