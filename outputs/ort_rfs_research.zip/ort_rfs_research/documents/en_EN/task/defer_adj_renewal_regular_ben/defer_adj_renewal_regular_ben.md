# Deferring adjudication: Claim other than initial — Regular benefits

Source map: `en_EN/task/defer_adj_renewal_regular_ben/defer_adj_renewal_regular_ben.ditamap`

## Summary

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/summary.dita`

Summary: In certain situations, adjudication of a contentious reason for separation (RFS) can be deferred on renewal, conversion, or continuing claims for regular benefits. 

## What you need to know

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/what_you_need_to_know.dita`

### Conditions

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/conditions.dita`

When the client requests regular benefits but an indefinite disqualification has been imposed because of the adjudication of a contentious RFS, and the client does not have enough insurable hours to establish a new initial claim, the officer can defer fact-finding and adjudication of each subsequent RFS. The indefinite disqualification may have been imposed before or at the time of the renewal or conversion request.

When determining if the client has enough hours to establish a new initial claim, the officer includes the insurable hours accumulated after the start date of the indefinite disqualification. If it is apparent that the client does not have enough hours (i.e. the client accumulated less than 420 hours), the adjudication is deferred.

The officer refers to Calculation: Entrance requirements for regular and fishing benefits — Table to determine the number of insurable hours required to establish a new initial claim.
       [Calculation: Entrance requirements for regular and fishing benefits — Table](/en/procedure/generic/additionalresources/ver_reg_ben.shtml)

When there are several contentious RFSs before the date of renewal or conversion, the officer reviews the contentious RFSs in chronological order (starting at the BPC) to determine if the deferral of any RFS is possible. The officer assesses each RFS separately.

**Example**

The chart below shows 3 examples with a VER of 700:

```text
| Indefinite disqualification | Benefits period (BP) | Renewal |

| Example 1 | The client has worked enough hours to qualify. RFS 1 Dismissal 200 hours RFS 2 Dismissal 350 hours RFS 3 Voluntary leaving 700 hours | Cannot be deferred |

| Example 2 | The client has not worked enough hours to qualify. RFS 1 Dismissal 100 hours RFS 2 Dismissal 100 hours RFS 3 Voluntary leaving 100 hours | The decisions on the RFSs are deferred |

| Example 3 | The client has worked enough hours to qualify but RFS 1 is excluded. RFS 1 Dismissal 450 hours RFS 2 Dismissal 250 hours RFS 3 Voluntary leaving 100 hours | The decisions on RFSs 2 and 3 are deferred |
```

In Example 1 , the client worked after the start date of the indefinite disqualification and has worked enough hours to qualify for a new initial claim. The officer begins by adjudicating the RFS 1 of the BP. This RFS is excluded because the misconduct is proven. Deferral of adjudications for RFSs 2 and 3 is impossible as the client meets the VER with these employers. The officer adjudicates the RFS 2 and misconduct is not proven. The officer adjudicates the RFS 3.

In Example 2 , the client worked after the start date of the indefinite disqualification, but has not worked enough hours to qualify for a new initial claim. The officer can defer fact-finding and adjudication of any subsequent RFS.

In Example 3 , the client worked after the start date of the indefinite disqualification, and has worked enough hours to qualify for a new initial claim. The officer begins by adjudicating the RFS 1 of the BP and misconduct is proven. The officer can defer the adjudication for RFSs 2 and 3 because the client does not meet the VER with these employers. 

### Deferring adjudication on a labour dispute

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/deferring_adjudication_on_a_labour_dispute.dita`

The officer cannot defer a decision on a labour dispute on renewal, conversion and continuing claims. When the claim is established, deferral is impossible. 

### Claim action status and processing the claim

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/claim_action_status_and_processing_the_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . All Adjudication Issue (ADJ) WIs must be completed before the system finalizes the renewal. There is a Resolve Issue tab for ADJ WIs which includes screens where the officer documents the decision on voluntary leaving, dismissal and suspension issues. There is no Resolve Issue tab for ADJ WIs when the issue is a voluntary leave of absence. When the ADJ WI is completed, NWS creates a record of decision (ROD) based on the Resolve Issue screens.

For conversion claims to regular benefits and continuing claims, the officer deferring the adjudication creates the ROD in NWS, inputs the transactions in FTS, and sends a notification to the client.

For conversion claims to regular benefits and continuing claims, the officer deferring the adjudication creates the ROD in NWS and inputs the transactions in FTS. 

### Special condition field in RCM

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/special_condition_field_in_rcm.dita`

If the ROE with the contentious RFS is on file, the officer updates the Special condition field based on the Resolve Issue screens. Updating the Special condition field on the ROE does not interfere with the automation of potential subsequent claims. If the client reapplies for benefits and the ROE with Adjudication deferred falls within the new QP, the system creates a new ADJ WI. 

### Conditions for claims with a BPC between w/c 2310 and w/c 2361

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/conditions_for_claims_with_a_bpc_betwee_7b0401eb.dita`

For claims with a BPC between w/c 2310 and w/c 2361, the officer only adjudicates a contentious RFS if it is from the most recent period of employment. The officer cannot defer adjudication on a renewal claim if there is an outstanding indefinite disqualification due to a contentious RFS that was not allowed. The officer must adjudicate any new contentious RFS in the BP. Regardless of how many hours of insurable employment the client has accumulated since the disqualifying event, the client may be able to establish a new claim. If the officer allows the RFS on the new period of employment in the BP, the officer can establish a new initial claim. This is because the indefinite disqualification imposed due to the original period of employment no longer applies because the new ROE from the latest period of employment establishes a new BPC without a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 
     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3053.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3054.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Example 1

Source topic: `en_EN/common_notes/note_c_3053.dita`

Example 1:

The client applied for benefits with an ROE from Joe’s Grocer. Since the RFS was contentious, the officer denied it and imposed an indefinite disqualification. The client subsequently worked during the BP for Local Grill for 45 hours and then submitted a renewal application. The RFS from Local Grill is also contentious, so the officer cannot defer adjudication. The officer adjudicates the RFS from Local Grill and allows it. The officer can establish a new claim using hours from both ROEs.

On the new claim, the ROE from Local Grill is the last period of employment in the qualifying period (QP). The officer allows the RFS from Local Grill and does not adjudicate any other contentious RFS on the new claim, including the one from Joe’s Grocer. All of the ROEs are used to calculate the claim. The existing indefinite disqualification no longer applies to the ROE from Joe’s Grocer because it is not the last period of employment on the new claim and adjudication is not required. 

### Example 2

Source topic: `en_EN/common_notes/note_c_3054.dita`

Example 2:

The client worked during the BP after the start date of the indefinite disqualification and then quit the job. Since the RFS is contentious, the officer cannot defer adjudication. The officer adjudicates the RFS and denies it. The officer cannot establish a new claim for the client because the client does not have any hours of insurable employment after the most recent disqualifying event. 

## Regional considerations

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/in_nws.dita`

- Are there any RODs indicating the adjudication of a 10 - Dismissal - misconduct proven disqualification (D10) or a 11 - Voluntarily leaving - just cause not proven disqualification (D11)?

- Is there a Resolve Issue tab for the ADJ WI?

- Is there a Claim Assessment (CA) WI or a Specialized Application (SA) WI? 

### In FTS:

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/in_fts.dita`

- Has a D10 or D11 been imposed because of adjudication of the file? 

### In RCM:

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/in_rcm.dita`

- Are the ROEs on file?

- How many insurable hours has the client accumulated since the start date of the most recent indefinite disqualification? 

## Step by step

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/level_1.dita`

#### Determining if the conditions are met

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/determining_if_the_conditions_are_met_level_1.dita`

- Determine if the RFS is B - Strike or lockout :

- If no, go to step 2.

- If yes, adjudication cannot be deferred. Return to the previous task.

- Determine if the contentious RFS impacts a period in which regular benefits have already been paid:

- If no, go to step 3.

- If yes, adjudication cannot be deferred. Return to the previous task.

- In FTS, determine if a D10 or D11 has been imposed because of a previously denied adjudication:

- If yes and the BPC is w/c 2309 or before, or w/c 2362 or later, go to step 4.

- If yes and the BPC is between w/c 2310 and w/c 2361, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious RFS.

- If no, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious RFS.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3055.dita)

- Review the Rate/Duration tab to determine the client’s regional rate of unemployment and if the client has a violation.

- Determine the number of hours worked needed to establish a new claim:

- If the client does not have a violation, refer to VER — Regular and fishing benefits .
               [VER — Regular and fishing benefits](/en/procedure/generic/additionalresources/ver_reg_ben.shtml)

- If the client has a violation, refer to Increased entrance requirements — Regular and fishing benefits .
               [Increased entrance requirements — Regular and fishing benefits](/en/procedure/generic/additionalresources/increased_entrance_requirements.shtml)

- Refer to Calculating a claim — Regular benefits to determine if the client qualifies for a new claim:

- If no, go to step 7.

- If yes, deferral is impossible. Return to the previous task to adjudicate the contentious RFS. 

#### Inputting the decision

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/inputting_the_decision_level_1.dita`

- In NWS, determine if there is an ADJ WI with a Resolve Issue tab for the issue under review:

- If yes, go to Inputting the decision — Resolve Issue tab present .
               [Inputting the decision — Resolve Issue tab present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_regular_ben#input_decision_present)

- If no, go to Inputting the decision — Resolve Issue tab not present .
               [Inputting the decision — Resolve Issue tab not present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_regular_ben#input_decision_not_present) 

#### Inputting the decision — Resolve Issue tab present

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/inputting_the_decision__resolve_issue_t_b961b717_level_1.dita`

- On the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving or the Level 1 Dismissal as follows:

- Select The adjudication has been deferred because the client does not have relief from a previous disqualification .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In RCM, determine if the ROE for which adjudication is being deferred is on file:

- If yes, go to step 11.

- If no, go to step 12.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- In NWS, complete the WI for the issue being deferred. 

#### Inputting the decision — Resolve Issue tab not present

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/inputting_the_decision__resolve_issue_t_c247a126_level_1.dita`

- In NWS, create a ROD for each contentious RFS as follows:

- Comments: Enter the following information:

- contentious RFS

- name of the employer

- last day worked for the employer

- deferred adjudication — subsequent RFS

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of the ROE] is deferred. Previous adjudication resulted in an indefinite disqualification. The client has not accumulated sufficient insurable hours since that disqualifying event to establish a new claim.”

- Select Save .

- In RCM, determine if the ROE for which adjudication is being deferred is on file:

- If yes, go to step 10.

- If no, go to step 11.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3056.dita)

- In FTS, select the Disqualifications/Disentitlements (M161) transaction to impose a disqualification as follows:

- Action: Select Add .

- Disqualification: Select the appropriate disqualification:

- If the disqualification is for a dismissal or suspension, select 10 - Dismissal - misconduct proven .

- If the disqualification is for a voluntary leaving or a voluntary leave of absence, select 11 - Voluntary leaving - just cause not proven .

- Effective: Select the w/c of the dismissal or voluntary leaving.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision type: Select the appropriate option.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In NWS, complete the WI if one is on file for the issue being deferred. 

#### Note

Source topic: `en_EN/common_notes/note_c_3055.dita`

Note:

When there are several contentious RFSs before the renewal or conversion date, determine if it is possible to defer the adjudication of each RFS separately, starting with the one immediately following the BPC. When this RFS is included, adjudicate the next RFS. 

#### Note

Source topic: `en_EN/common_notes/note_c_3056.dita`

Note:

If selecting Submit causes the ROE to be flagged with an error, do not fix the error. The ROE is corrected when the client applies for a subsequent claim. 

### Level 2

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/level_2.dita`

#### Determining if the conditions are met

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/determining_if_the_conditions_are_met_level_2.dita`

- Determine if the RFS is B - Strike or lockout :

- If no, go to step 2.

- If yes, adjudication cannot be deferred. Return to the previous task.

- Determine if the contentious RFS impacts a period in which regular benefits have already been paid:

- If no, go to step 3.

- If yes, adjudication cannot be deferred. Return to the previous task.

- In FTS, determine if a D10 or D11 has been imposed because of a previously denied adjudication:

- If yes and the BPC is w/c 2309 or before, or w/c 2362 or later, go to step 4.

- If yes and the BPC is between w/c 2310 and w/c 2361, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious RFS.

- If no, deferral is impossible. Return to the previous task to adjudicate the contentious RFS.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3057.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita)

- Review the Rate/Duration tab to determine the client’s regional rate of unemployment and if the client has a violation.

- Determine the number of hours worked needed to establish a new claim:

- If the client does not have a violation, refer to VER — Regular and fishing benefits .
               [VER — Regular and fishing benefits](/en/procedure/generic/additionalresources/ver_reg_ben.shtml)

- If the client has a violation, refer to Increased entrance requirements — Regular and fishing benefits .
               [Increased entrance requirements — Regular and fishing benefits](/en/procedure/generic/additionalresources/increased_entrance_requirements.shtml)

- Determine if the client has worked enough hours since the disqualification to qualify for a new claim:

- If no, go to step 7.

- If yes, deferral is impossible. Return to the previous task to adjudicate the contentious RFS. 

#### Inputting the decision

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/inputting_the_decision_level_2.dita`

- In NWS, determine if there is an ADJ WI with a Resolve Issue tab for the issue under review:

- If yes, go to Inputting the decision — Resolve Issue tab present .
               [Inputting the decision — Resolve Issue tab present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_regular_ben#input_decision_present_level2)

- If no, go to Inputting the decision — Resolve Issue tab not present .
               [Inputting the decision — Resolve Issue tab not present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_regular_ben#input_decision_not_present_level2) 

#### Inputting the decision — Resolve Issue tab present

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/inputting_the_decision__resolve_issue_t_b961b717_level_2.dita`

- On the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving or the Level 2 Dismissal screen as follows:

- Select The adjudication has been deferred because the client does not have relief from a previous disqualification .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Determine if the ROE for which adjudication is being deferred is on file:

- If yes, go to step 11.

- If no, go to step 12.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- In NWS, complete the WI for the issue being deferred. 

#### Inputting the decision — Resolve Issue tab not present

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/inputting_the_decision__resolve_issue_t_c247a126_level_2.dita`

- In NWS, create a ROD for each contentious leave of absence as follows:

- Comments: Enter the following information:

- contentious RFS

- name of the employer

- last day worked for the employer

- deferred adjudication — subsequent RFS

- Details: Type “Adjudication of [RFS, full name of the employer, last day worked for the employer or serial number of the ROE] is deferred. Previous adjudication resulted in an indefinite disqualification. The client has not accumulated sufficient insurable hours since that disqualifying event to establish a new claim.”

- Determine if the ROE for which adjudication is being deferred is on file:

- If yes, go to step 10.

- If no, go to step 11.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3058.dita)

- In FTS, select the Disqualifications/Disentitlements (M161) transaction to impose a disqualification as follows:

- Action: Select Add .

- Disqualification: Select the appropriate disqualification:

- If the disqualification is for a dismissal or suspension, select 10 - Dismissal - misconduct proven .

- If the disqualification is for a voluntary leaving or a voluntary leave of absence, select 11 - Voluntary leaving - just cause not proven .

- Effective: Select the w/c of the dismissal or voluntary leaving.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision type: Select the appropriate option.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In NWS, complete the WI if one is on file for the issue being deferred. 

#### Note

Source topic: `en_EN/common_notes/note_c_3057.dita`

Note:

When there are several contentious RFSs before the renewal or conversion date, determine if it is possible to defer the adjudication of each RFS, separately, starting with the one immediately following the BPC. When this RFS is included, adjudicate the next RFS. 

#### Note

Source topic: `en_EN/common_notes/note_c_3058.dita`

Note:

If selecting Submit causes the ROE to be flagged with an error, you are not required to fix the error. The ROE is corrected if when the client applies for a subsequent claim. 

## Policy reference

Source topic: `en_EN/task/defer_adj_renewal_regular_ben/policy_reference.dita`

 
