# Completing a Claim Set-Up Registration WI — Non-complex

Source map: `en_EN/task/cs_reg/cs_reg.ditamap`

## Summary

Source topic: `en_EN/task/cs_reg/summary.dita`

Summary: A Claim Set-Up (CS) Registration WI is created when ACP is unable to register a claim. 

## What you need to know

Source topic: `en_EN/task/cs_reg/what_you_need_to_know.dita`

### Actioning a Claim Set-Up (CS) WI

Source topic: `en_EN/task/cs_reg/actioning_a_claim_set-up_cs_wi.dita`

When ACP is unable to register a claim, the officer obtains an initial registration number in SSO, or a renewal registration number is obtained in FTS.

ACP cannot register a new application when there is an outstanding initial or renewal registration. There can be no more than one outstanding initial or renewal registration number on a claim and no more than 2 outstanding registration numbers. If there are already 2 outstanding registration numbers, the officer must contact a team leader to determine the next steps.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3003.dita) 

### Duplicate applications

Source topic: `en_EN/task/cs_reg/duplicate_applications.dita`

Duplicate applications occur for a variety of reasons, such as when:

- a client tries to complete a claimant’s report through IRS and instead completes another application;

- a client makes an error on the first application and submits a second application with the correction. The client could also be trying to renew the claim or convert the benefit type (BT);

- the system automatically registered a subsequent renewal claim and the client filed a subsequent application.

When the client completes a duplicate application, the officer always verifies if there is an outstanding registration number. If there is an outstanding registration number, an initial or renewal claim event with an In Progress processing status is displayed in the NWS Client information tree . In these cases, the Non-complex officer compares the 2 applications to determine if there are differences. If an initial registration number is outstanding and the difference is a new period of employment in the qualifying period (QP) or the benefit period (BP) with a contentious reason for separation (RFS), or a newly declared training, teaching, farming, or self-employment (SE) issue, the officer creates an ADJ WI, completes the CS WI and no further action is required. If a renewal registration number is outstanding, the Non-complex officer reassigns the WI to Level 1.

If there are other differences, or if the initial claim has already been established, the Non-complex officer reassigns the WI to Level 1 to determine if the differences could impact the calculation. The Level 1 officer determines if a new registration number is required once the outstanding initial or renewal registration number has been completed. 

### Initial claim event is Finalized LREM

Source topic: `en_EN/task/cs_reg/initial_claim_event_is_finalized_lrem.dita`

ACP cannot register a new application when the initial claim event is Finalized LREM and the BPNE N2 claim is on the Summary tab in FTS. In this situation, the Unresolved claim on EN05 Manual Action not acceptable for automation message is displayed on the Processing Activities tab, and ACP creates a CS Registration WI. The Non-complex officer reassigns the CS WI to Level 1. 

### Continuing claim on EN05

Source topic: `en_EN/task/cs_reg/continuing_claim_on_en05.dita`

ACP cannot register a new application when the message Continuing claim on EN05 is displayed on the Processing Activities tab in NWS. When the client is on a continuing claim and a new application has been completed, ACP creates a CS Registration WI. In NWS, the Non-complex officer verifies on the most recent application if the client is requesting the same BT as the one displayed in the Type field of the Summary tab in FTS. If so, the Non-complex officer reassigns the CS WI to Level 1. If not, the Non-complex officer determines if there is an outstanding Claim Review (CR) Revised - Medical proof WI, a CR Revised-Conversion WI or an Action Item (AI) WI related to the conversion request. If so, the Non-complex officer reassigns the CS WI to Level 1. If not, the Non-complex officer obtains a renewal registration number in FTS. 

### Dormant Manual Pay Claim present

Source topic: `en_EN/task/cs_reg/dormant_manual_pay_claim_present.dita`

When the client completes an application and the message Unresolved Claim Type-Dormant Manual Pay Claim present is displayed on the Processing Activities tab in NWS, ACP creates a CS Registration WI. In FTS, the Manual Pay tab shows payments processed on a previous terminated claim. The Non-complex officer verifies on the most recent terminated claim if the last renewable week (LRW) has been reached or if the maximum entitlement weeks for the same BT requested has been paid before the LRW. If so, the Non-complex officer registers the initial claim and completes the CS WI. If not, the Non-complex officer reassigns the CS WI to Level 1. 

### Subsequent claim polling limit reached

Source topic: `en_EN/task/cs_reg/subsequent_claim_polling_limit_reached.dita`

When a claim is renewed with 4 or fewer weeks of benefits remaining and the client has worked enough hours to establish a new claim, the renewal application can be used to establish a subsequent claim.

ACP can register the subsequent claim if the CA WI for a renewal or subsequent initial claim is finalized within 28 days of the renewal application.

ACP waits for the last week to be processed before attempting to register the new claim. If the claim cannot be registered, ACP creates a CS WI.

If one of the following messages is displayed on the Processing Activities tab in NWS, different actions are required depending on which conditions exist:

- Polling for Subsequent Only

- 2nd Subsequent polling limit is reached. Claim is still active

- ACP Type of Claim changed to a Subsequent Initial

- Subsequent Only - Sickness Benefits Exhausted

- Claim still on EN05 and Subsequent Only polling limit is reached

Depending on the situation, the officer does the following:

- When the claim is active, the Failure to report box is unchecked and the claim status (CS) is 2 - Found work on Sunday or Monday of week 2 , the officer reassigns the CS WI to Level 1.

- When the Summary tab in FTS is greyed out, the claim is in the Dormant tab and the claimant’s reports have not been processed up to the LRW, the officer reassigns the CS WI to Level 1.

- When the client is requesting sickness benefits and the Processing Activities tab indicates in the second line Subsequent Only-Sickness Benefits Exhausted , the officer reassigns the CS WI to Level 1.

- When there is an outstanding AI WI with Pay affected - Antedate , the officer reassigns the CS WI to Level 1.

If none of the above conditions applies and the client has not completed claimant’s reports for the renewal claim up to the LRW, the officer does not register the subsequent claim. In this situation, the officer moves the CS WI to Pending until the Failure to report box is checked on the Summary tab in FTS. The officer then completes the CS WI. The Failure to report box is checked when 5 weeks have passed since the last claimant’s report was issued. If the client submits claimant’s reports for the renewal claim up to the LRW or up to the last entitlement week (if the maximum entitlement weeks are reached before the LRW) before the Failure to report box is checked, the officer registers the subsequent initial claim after the last report is processed. Once the Failure to report box is checked, the client needs an antedate or a new application to receive benefits for the renewal or subsequent initial claim. 

### Fraud indicators

Source topic: `en_EN/task/cs_reg/fraud_indicators.dita`

Before a claim is registered, officers determine if the client’s file is already under investigation for potential fraud. Officers can determine that there is an ongoing Integrity investigation for this file if:

- a 71 - Integrity Services case manual action (MA71) or 71 - Integrity Services case disentitlement (D71) is imposed;

- an SROC created by Integrity is on file;

- an AI WI is assigned to Integrity;

- a Call Back (CB) WI is assigned to Integrity.

If none of these are on the file, officers review the client’s file to determine if fraud indicators are present by consulting Fraud indicators: Identifying potentially fraudulent claims — Knowledge . If yes, officers:
       [Fraud indicators: Identifying potentially fraudulent claims — Knowledge](/en/procedure/generic/additionalresources/fraud_indicator.shtml)

- determine if the banking information has been changed in FTS and if so, terminate the direct deposit;

- impose a D71 on skeleton and BPNE 1, 2 or 7 claims or an MA71 on established claims, when required;

- complete the registration number to suspend the application process to prevent the claim from establishing or to prevent payments on the renewal claim until an investigation is completed;

- refer the issue to Integrity for investigation;

- complete the CS WI.

For more information, officers refer to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### New application without fraud indicators — 71 - Integrity Services case manual action (MA71) on file

Source topic: `en_EN/task/cs_reg/new_application_without_fraud_indicator_82f0e5e9.dita`

If an application with no fraud indicators is received and an MA71 is on file for a previous application identified as potentially fraudulent, the officer continues to follow the procedure to register the new application. 

### Fraudulent application received on a continuing claim

Source topic: `en_EN/task/cs_reg/fraudulent_application_received_on_a_co_7ee5f16f.dita`

If a fraudulent application is received on a continuing claim, the officer determines if the initial claim in FTS is legitimate. The officer then verifies in FTS if the client’s address and direct deposit information have been changed on the legitimate continuing claim:

- If yes, the officer considers the claim as compromised and imposes an MA71.

- If no, the officer considers the claim as not compromised. No MA71 is required and the officer sends an AI WI to Integrity for investigation. This ensures that the MA71 does not penalize the true SIN holder on the legitimate claim, since the claim has not been compromised. 

### Change of address

Source topic: `en_EN/task/cs_reg/change_of_address.dita`

A client who files an application to renew a claim may indicate a new address. When the new address is located in a different region, the message Claim history in another ITC is displayed on the Processing Activities tab in NWS. ACP is unable to register the claim. There are 4 mainframes located in Canada , one in each of the 4 regions:

- Atlantic

- Quebec

- Ontario

- Western Canada and Territories

The officer may need to submit a transfer request if the claim information is located in a different mainframe than the region where the client resides. The Non-complex officer refers to Change of address — Different region .
       [Change of address — Different region](/en/procedure/task/change_address_dr.shtml) 

### Outstanding SIR Validation (SIR) WI

Source topic: `en_EN/task/cs_reg/outstanding_sir_validation_sir_wi.dita`

If there is an outstanding SIR 900-series SIN WI, the Non-complex officer reassigns the CS WI to Level 1.

If there is an outstanding SIR SIN Restriction WI or SIR Non-match WI, the Non-complex officer moves the CS WI to Pending until the SIR WI is completed.

When an outstanding SIR SIN Restriction WI is completed and the client’s identity is not validated on an initial claim other than a 900-series SIN, the Non-complex officer completes the CS WI and requests that an authorized user delete the application in NWS. When an outstanding SIR SIN Restriction WI is completed and the client’s identity is validated, the Non-complex officer proceeds with the claim registration process.

When an outstanding SIR SIN Restriction WI is completed and the client’s identity is not validated on a renewal claim, the Non-complex officer reassigns the CS WI to Level 1.

When an outstanding SIR Non-match WI other than a 900-series SIN is completed and the client’s identity is not validated, the Non-complex officer completes the CS WI. The officer assigned to the SIR Non-match WI is responsible for requesting the deletion of the application in NWS by an authorized user. When an outstanding SIR Non-match WI is completed and the client’s identity is validated, the Non-complex officer proceeds with the claim registration process. 

### Determining if a claim is renewable

Source topic: `en_EN/task/cs_reg/determining_if_a_claim_is_renewable.dita`

- There is an active benefit period (BP).

- The LRW of the BP has not been reached.

- The client did not receive all the benefits to which he is entitled to on that BP.

The claim may be renewable for special benefits if all regular entitlement has been paid out, and the claim is in the Dormant tab, with the message Special benefits potentially payable . 

### Registering the application

Source topic: `en_EN/task/cs_reg/registering_the_application.dita`

When registering a claim, the Initial Intake (M149) transaction must always be transmitted from SSO. An officer should never use an FTS transaction for the M149 while the same SIN is open in SSO as this will cause data conflict in the system and the claim will be unable to be calculated. 

### SSO errors

Source topic: `en_EN/task/cs_reg/sso_errors.dita`

In some cases, when inputting the M149 or Name and Address Change / Transfer (M159) transaction in SSO, a 3-digit error code is displayed at the top of the screen. If the 3-digit error code indicates that the M149 or M159 cannot be input, the Non-complex officer reassigns the WI to Level 1 and a Level 1 officer must input the M149 or M159. 

### Commuters

Source topic: `en_EN/task/cs_reg/commuters.dita`

Commuters are Canadian and American workers who regularly cross the Canada and United States border between their residence and workplace.

Commuters can be entitled to Canadian or American benefits depending on where the work is performed.

Canadian workers who regularly commute to the United States for work are entitled to receive unemployment benefits from the state in which they worked. For more information, the officer refers the client to How Do I File for Unemployment Insurance? .
       [How Do I File for Unemployment Insurance?](https://www.dol.gov/general/topic/unemployment-insurance)

American workers who regularly commute to work in Canada from a border state are entitled to receive Canadian EI benefits, which they can apply for online.

There are 11 American states that share a border with Canada:

- Maine

- New Hampshire

- Vermont

- New York

- Michigan

- Minnesota

- North Dakota

- Idaho

- Montana

- Washington

- Alaska

When completing the application for Canadian EI benefits, an American client with an address in one of these states must answer the question “Do you regularly cross the border between your residence and workplace?”. If yes, the client is asked to provide the workplace address, and the claim is registered to the Service Canada Centre (SCC) that is nearest to the port of entry. For example, the claim of a client living in Detroit, Michigan is registered to SCC 3513 - Windsor.

Commuter claims are identified by the economic region code 99 . After the initial commuter claim is calculated, the economic region is automatically updated to 99 .

In order to qualify for benefits, commuter clients must meet the same qualifying and entitlement conditions as clients who live in Canada. The officer does not create any additional WIs for availability because the commuter lives out of Canada. When commuter clients who live out of Canada leave their area of residence, the same principles of adjudication apply.

Direct deposit payments can only be made to financial institutions located in Canada. Commuter clients who file a claim in Canada are also eligible for direct deposit payments, as long as the financial institution is located in Canada.

Claims for commuter benefits are processed by the local SCC. The officer does not refer commuter claims to the Interstate unit in Sudbury, Ontario (SCC 3503).

**Entitlement to EI benefits**

To qualify for regular or special benefits, a commuter must meet the same qualifying and entitlement conditions as a client residing in Canada.
       [qualifying and entitlement conditions](/en/procedure/generic/knowledge.shtml)

A maximum of 36 weeks of regular benefits can be paid to commuter clients. The number of weeks payable for regular benefits is based on the number of insurable hours the client accumulated in Canada during the last 52 weeks or since the client’s last claim.
       [maximum of 36 weeks of regular benefits](/en/procedure/generic/additionalresources/res_us_eu_chart.shtml)

The maximum number of weeks of benefits payable when regular and special benefits are combined is 50 weeks paid or deemed paid at the basic rate.

If the client established a claim while living in the United States and later moves to Canada, the maximum number of weeks of regular benefits to which the client is entitled does not increase. The client remains entitled to a maximum of 36 weeks of regular benefits. In these cases, the officer inputs an M159 transaction in FTS and unchecks the Commuter box.

If the client established a claim while living in Canada and later moves to the United States, the maximum number of weeks of regular benefits to which the client is entitled to the greater of the following:

- the number of weeks for which the client has already received benefits in Canada;

- the number of weeks the client would have been entitled to if the client had resided in the United States when the BP was established.

**Registering a commuter claim**

When obtaining a registration number for a commuter claim, the economic region code of a commuter claim is determined based on the postal code of the client’s workplace. On the SSO Name and Address screen, the Ordinary place of residence different field must indicate Yes . The officer enters the workplace postal code in the Residence postal code field and selects Commuters in the Tax province field. Once the postal code of the workplace is entered, the economic region is automatically updated.

The officer also ensures the mailing address format on the SSO Name and Address screen complies with Canada Post guidelines for an address in the United States as follows:

- First address line: The delivery address. If necessary, the officer indicates the apartment number on the second line after the delivery address.

- Second address line: The city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, a hyphen must be used to separate the fifth and sixth digits.

- Third address line: The country name.

     [Example of how the name and address will be displayed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3004.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3005.dita) 

To prevent a postal code from being displayed as part of the client’s address in FTS, the officer enters “XXXXXX” in the Postal code field on the SSO Name and Address screen.

To identify the claim as a commuter claim, the officer select C - Commuter in the Claim action field when inputting the M149 or checks the Commuter box when inputting the M159.

When registering a commuter claim for recalculation, the officer modifies the Economic region - new and Economic region - old fields of the SSO Name and Address screen from 99 to the appropriate economic region code, depending on the situation:

- If the economic region code used to calculate the initial claim was correct, the officer uses this economic region code.

- If the economic region code used to calculate the initial claim was incorrect, the officer uses the economic region associated with workplace postal code.

When obtaining a recalculation registration number, the officer only inputs the M159 transaction if incorrect information was input when the initial claim was calculated or if the information has changed since the initial claim was calculated.

- If the economic region code used to calculate the initial commuter claim was correct, the officer does not input the M159 transaction. However, if the M159 is necessary due to a change in other information, the officer leaves the Economic region field blank when inputting the M159.

- If the economic region code used to calculate the initial commuter claim was incorrect, the officer enters the correct economic region code associated with the postal code of the client’s workplace in the Economic Region field and transmits the M159. 

### SSO is unable to create the WI

Source topic: `en_EN/task/cs_reg/sso_is_unable_to_create_the_wi.dita`

In some exceptional circumstances, SSO does not create the Claim Assessment (CA) WI in NWS when the initial claim is registered. In SSO, a warning message displaying Unable to create work item appears and the officer must manually create the CA WI in NWS. 

### Note

Source topic: `en_EN/common_notes/note_c_3003.dita`

Note:

If the officer does not check if there is an outstanding initial or renewal registration number and instead attempts to obtain a second registration number, the officer receives a 745 error that cannot be overridden. The outstanding initial or renewal decision must be completed before a new initial or renewal registration number is obtained. 

### Example of how the name and address will be displayed

Source topic: `en_EN/common_notes/note_c_3004.dita`

Example of how the name and address will be displayed: 

### Note

Source topic: `en_EN/common_notes/note_c_3005.dita`

Note:

Mail using a non-standard address format is returned to the sender. With the exception of the hyphen in a 9-digit ZIP code, the officer omits all other punctuation marks in the mailing address. 

## Regional considerations

Source topic: `en_EN/task/cs_reg/regional_considerations.dita`

**Quebec region**

The business expertise advisor, and not the team leader, deletes the application in NWS. As indicated in the Step by step section, the officer creates and moves the REM WI to Pending until the date of application + 44 days. Instead of reassigning the REM WI to the authorized user, the officer completes the WI when the pending period has elapsed and advises the business expertise advisor to delete the application using the consultative tool. 

## What you need to look for

Source topic: `en_EN/task/cs_reg/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/cs_reg/in_nws.dita`

- What is the last day worked (LDW) on the application?

- Is a recent application on file?

- When was the application received?

- Is there an outstanding SIR WI?

- Has the client’s identity been validated?

- Does the client have a 900-series SIN?

- In the Processing Activities tab, is one of the following messages displayed?

- Claim history in another ITC

- Unresolved claim without last week processed on active claim

- Polling for Subsequent Only

- 2 nd Subsequent polling limit is reached. Claim is still active

- ACP Type of Claim changed to a Subsequent Initial

- Subsequent Only - Sickness Benefits Exhausted

- Claim still on EN05 and Subsequent Only polling limit is reached

- Is it a subsequent initial application?

- Has it been 5 weeks since the last claimant’s report was issued?

- Continuing claim on EN05

- Unresolved claim on EN05 Manual Action code is not acceptable for automation

- A025 not done, outstanding registration

- Unresolved Claim Type-Dormant Manual Pay Claim present

- Special benefits potentially payable

- Is there an initial or renewal claim in progress?

- Is there a duplicate application?

- Is the client requesting to be exempt from reporting?

- Is the claim a Work-Sharing (WS) claim? 

### In FTS:

Source topic: `en_EN/task/cs_reg/in_fts.dita`

- Is there an outstanding initial or renewal registration number?

- Is there a previous claim on the Dormant tab that is still renewable?

- What is the LRW on the Summary tab?

- Is there a Failure to report box checked?

- Has the client submitted claimant’s reports up to the LRW of the claim? 

## Step by step

Source topic: `en_EN/task/cs_reg/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/cs_reg/non-complex.dita`

#### Reviewing the file for fraud indicators

Source topic: `en_EN/task/cs_reg/reviewing_the_file_for_fraud_indicators_non-complex.dita`

- In NWS, determine if there is documentation indicating that the application for which the CS WI was created is under investigation for potential fraud:

- If no, go to step 2.

- If yes, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_8)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3006.dita)

- Determine if known fraud indicators are present and if fraud is suspected by referring to Fraud indicators: Identifying potentially fraudulent claims — Knowledge and reviewing the file:

- If yes, go to step 3.

- If no, go to step 4.

- In FTS, determine if the banking information has been changed to the banking information on the potentially fraudulent application:

- If no, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_8)

- If yes, terminate the banking information by referring to Ending a direct deposit and go to Fraud indicators are present .
               [Ending a direct deposit](/en/procedure/task/ending_dd.shtml) 
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_8) 

#### Determining if there is a SIR Validation (SIR) WI

Source topic: `en_EN/task/cs_reg/determining_if_there_is_a_sir_validation_sir_wi_non-complex.dita`

- Determine if there is a SIR WI related to the current application:

- If yes and the SIR WI is outstanding, go to step 5.

- If yes and the SIR WI has been completed, go to step 8.

- If no, go to step 13.

- Determine if the SIR WI is for a 900-series SIN:

- If no, go to step 6.

- If yes, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- In NWS, move the CS WI to Pending as follows:

- Pending reason: Select SIR Validation .

- Bring forward date: Select the appropriate option:

- If the SIR WI is Pending, enter the bring forward date of the SIR WI.

- If the SIR WI is not Pending and the application was filed within the last 28 days, enter the date of application + 28 days.

- If the SIR WI is not Pending and the application was filed more than 28 days ago, enter the date of application + 44 days.

- When the CS WI moves to the current workload, determine if the SIR WI is completed:

- If no, return to step 6.

- If yes, go to step 8.

- Determine if the SIR WI indicates that the client’s identity has been validated:

- If no, go to step 9.

- If yes, go to step 13.

- Determine the type of SIR WI:

- For a SIR SIN Restriction WI not related to a 900-series SIN, go to step 10.

- For a SIR SIN Restriction WI or a SIR Non-match WI related to a 900-series SIN, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- For a SIR Non-match WI, go to step 49.

- Determine if the claim is an initial or renewal claim:

- For an initial claim, go to step 11.

- For a renewal claim, go to Reassigning the issue to Level .
               [Reassigning the issue to Level](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- In ACS, create and send the S-01-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Second Notice to client Re SIR Non-match (2731): Select the appropriate option:

- Client did not provide copies of identification documents in MSCA or by mail.

- Client did not visit local office as instructed to do.

- Date of EI application filed (1264): Select the date of application.

- Date written or verbal direction given (1528): Select the appropriate.

- In NWS, create a Reminder (REM) WI to delete the Web application as follows:

- Complexity: Select Non-complex .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the date of application + 44 days.

- Language: Select the appropriate option.

- Details: Type “SIR not validated.”

- Destination: Enter the SCC as shown in FTS.

- End user: Select Myself and complete the following fields:

- Send to my pending workload: Check the box.

- Pending reason: Select Other .

- Comments: Type “As of due date, review the file to determine if the application still requires deletion.”

- Bring forward date: Enter the date of application + 44 days.

- Select Save .

- Go to step 49.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3007.dita) 

#### Determining if a transfer is required

Source topic: `en_EN/task/cs_reg/determining_if_a_transfer_is_required_non-complex.dita`

- In NWS, on the Processing Activities tab of the application for which the CS WI has been created, determine if the Claim history in another ITC message is displayed:

- If yes, go to step 14.

- If no, go to step 17.

- Determine if a transfer from another region is required (refer to Changing an address — Different region for guidance, if necessary):

- If yes and the AI Transfer WI is within your authority, go to step 15.

- If yes and the AI Transfer WI has been reassigned to Level 1, go to Reassigning the issue to Level 1 to reassign the CS WI to Level 1.
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- If no, go to step 27.

- In NWS, move the CS WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Transfer has been requested.”

- Bring forward date: Enter today’s date + 14 days.

- When the WI moves to the current workload, determine if the transfer is complete:

- If no, return to step 15.

- If yes, go to step 27. 

#### Reviewing the file

Source topic: `en_EN/task/cs_reg/reviewing_the_file_non-complex.dita`

- Determine if there is an outstanding initial or renewal claim (Claim action status will show In progress and there will be an outstanding initial or renewal registration number):

- If no, go to step 18.

- If there is an outstanding initial claim, go to step 24.

- If there is an outstanding renewal claim, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- In NWS, select the Processing Activities tab in the application for which the CS WI has been created to determine which message is displayed. When more than one message is displayed, select the one above the Work item created-Registration required line to determine the next steps:

- If the message is Unresolved claim without last week processed on active claim , go to step 19.

- If the message is Polling for Subsequent Only , go to step 20.

- If the message is 2 nd Subsequent polling limit is reached. Claim is still active , go to step 20.

- If the message is ACP Type of Claim changed to a Subsequent Initial , go to step 20.

- If the message is Claim still on EN05 and Subsequent Only polling limit is reached , go to step 20.

- If the message is Subsequent Only - Sickness Benefits Exhausted, go to step 20.

- If the message is Continuing claim on EN05 , go to step 28.

- If the message is Unresolved Claim on EN05 Manual Action code is not acceptable for automation , go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- If the message is A025 not done, outstanding registration exists , go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- If the message is Special benefits potentially payable, go to step 29.

- If the message is Unresolved Claim Type-Dormant Manual Pay Claim present , go to step 30.

- If none of the above messages is displayed, go to step 23.

- In FTS, determine if the Failure to report box is checked:

- If no, go to step 24.

- If yes, go to step 31.

- Determine which of the following situations applies to the client:

- If claimant’s reports have been processed up to the LRW or up to the last entitlement week for the BT requested by the client, go to step 33.

- If the claim is active and the Failure to report box is checked, go to step 49.

- If the claim is active, the Failure to report box is unchecked and the CS is 2 - Found work on Sunday or Monday of week 2 , go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- If the Summary tab is greyed out, the claim is in the Dormant tab and the claimant’s reports have not been processed up to the LRW, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- If the client is requesting sickness benefits and the Processing Activities tab indicates in the second line Subsequent Only-Sickness Benefits Exhausted , go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- If there is an outstanding AI WI Pay affected-Antedate , go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- If none of these conditions applies, go to step 21.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3008.dita)

- In NWS, move the CS WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for claimant’s reports up to the [LRW or last entitlement week] or Failure to report indicator.”

- Bring forward date: Enter the following Monday.

- When the CS WI moves to the current workload, determine if the Failure to report box is checked or if claimant’s reports have been processed up to the LRW:

- If neither condition applies, return to step 21.

- If claimant’s reports have been processed up to the LRW, go to step 33.

- If the Failure to report box is checked, go to step 49.

- In FTS, determine if there is a renewable claim:

- If yes, go to step 24.

- If no, go to step 27.

- Determine if all the information provided by the client is the same on both applications:

- If no, go to step 25.

- If yes, go to step 49.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3009.dita)

- Determine if the only difference is a new period of employment in the QP or the BP with a contentious RFS or a newly declared training, teaching, farming, or SE issue:

- If yes and there is an outstanding initial registration number, go to step 26.

- If yes and the initial registration number has already been completed, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- If no or if there are other differences, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- In NWS, for each issue requiring adjudication for which there is no WI, create an ADJ WI on the initial claim event as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- End User: Select Next available user .

- Issue: Check the appropriate box based on the issue.

- Complete any mandatory fields required for the issue type.

- Go to step 49.

- Select the appropriate option:

- If there is a continuing claim, go to step 28.

- If a renewal registration number is required, go to step 31.

- If an initial registration is required, go to step 33.

- If a recalculation registration is required, go to step 36.

- IN NWS, in the most recent application, determine if the client is requesting the same BT as the one displayed in the Type field of the Summary tab in FTS:

- If no, go to step 29.

- If yes, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- Determine if there is an outstanding CR Revised - Medical proof WI, CR Revised-Conversion WI or an AI WI related to the conversion request:

- If no, go to step 31.

- If yes, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- In FTS, on the most recent terminated claim, determine if the LRW has been reached or if the maximum entitlement weeks for the same BT requested has been paid before the LRW:

- If yes, go to step 33.

- If no, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3010.dita) 

#### Registering the application

Source topic: `en_EN/task/cs_reg/registering_the_application_non-complex.dita`

- In FTS, verify if the ITC is correct and select the Registration Number (M025, M030, M035) transaction. Assign a registration number as follows:

- Action: Select Assign .

- Claim source: Select 8 - Appli-Web External .

- Service unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3011.dita)

- Determine if the address or the phone number displayed in FTS is the same as the one on the renewal application:

- If no, refer to Change of address for guidance, if necessary, to input the Name and Address Change/Transfer (M159) transaction and go to step 47.
               [Change of address](/en/procedure/activity/change_address.shtml)

- If yes, go to step 48.

- In SSO, verify that the correct mainframe is selected and register the claim as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Initial .

- Select Search .

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3012.dita)

- Review the Name and Address screen.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2168.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2647.dita) 

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: Both fields are prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: Do the following:

- If the field is blank, enter the SCC shown on the WI History tab of the CS WI.

- For a commuter claim, enter the SCC associated with the workplace postal code.

- Tax credit: This field is prefilled based on the client’s information.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: If the field is blank, enter the SCC shown on the WI History tab of the CS WI (the same one input in the Responsible SCC field).

- Service unit: Type “01.”

- Tentative BPC: If the field is blank, determine the BPC based on the client’s LDW and application date. If the registration number being obtained is for a subsequent claim, select the week after the previous claim’s LRW.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select Yes to generate the Initial Intake (M149) transaction.

- Select Generate registration .
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2648.dita)

- Select Next .

- Determine if the following error message appears:

- WARNING! WARNING! WARNING! Unable to create work item for: SIN = 999999999 REG = 999999 Error Code = 1004 (Unexpected Error)

- If yes, go to step 35.

- If no, go to step 40.

- In NWS, select the applicable application in the Client information tree and create a CA WI as follows:

- Registration Number: Enter the registration number as shown in SSO.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select Initial or Renewal as appropriate.

- Benefit type: Select the appropriate BT.

- Destination: Enter the SCC as shown in the WI History tab of the CS WI.

- Date of application: Enter the appropriate date.

- Error number: Type “04.”

- Go to step 40.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3013.dita)

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 38.

- If no, go to step 39.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank , enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: This field is prefilled.

- Select Generate registration .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1570.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1571.dita)

- In SSO, determine whether the Intake Data (M149) or the Name and Address Change/ Transfer (M159) transaction is generated:

- If the Intake Data (M149) transaction is generated, go to step 41.

- If the Name and Address Change/ Transfer (M159) transaction is generated, go to step 42.

- Verify the information on the Initial Intake (M149) transaction and do the following, if required:

- If the First name field on the Name and Address screen in SSO was modified to “NA” because the client has only one name and selected X as the gender marker, enter a period “.” in the First name field.

- If the client requests to be exempt from reporting, select S - Suppress claimant’s reports in the Claim action field.

- If the claim is a WS claim and the client requests to be exempt from reporting, select W - Work-sharing - no claimant’s reports in the Claim action field.

- If the claim is a WS claim and the client requests to complete claimant’s reports, select H - Work - sharing with claimant’s reports in the Claim action field.

- For a commuter claim, select C - Commuter in the Claim action field and confirm the following:

- The mailing address complies with Canada Post guidelines for an address in the United States.

- The SCC and economic region correspond to the client’s workplace postal code.

- The Tax province field displays Commuters .

- Select Update to input the information.

- Go to step 47.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3014.dita)

- Determine if the recalculation is for a commuter claim:

- If no, go to step 43.

- If yes, go to step 44.

- Verify the information on the Name and Address Change /Transfer (M159) transaction and do the following, if required:

- If the First name field on the Name and Address screen in SSO was modified to “NA” because the client has only one name and selected X as the gender marker, enter a “.” in the First name field.

- Select Update to input the information.

- Go to step 47.

- Review the information on the Name and Address Change/Transfer (M159) transaction and confirm the following:

- The address complies with Canada Post guidelines for an address in the United States.

- The economic region code corresponds to the client’s workplace postal code.

- The Tax province field displays Commuters .

- The Commuter box is checked.

- Determine if the economic region used to calculate the initial claim was incorrect:

- If no, go to step 46.

- If yes, select Update to input the Name and Address Change / Transfer (M159) transaction with the corrected economic region code and go to step 47.

- Determine if any other information on the Name and Address Change / Transfer (M159) transaction was completed incorrectly when the initial claim was calculated or has changed since the initial claim was calculated:

- If no, do not input the Name and Address Change / Transfer (M159)

- If yes, leave the economic region field blank and select Update to input the Name and Address Change / Transfer (M159) transaction with the corrected information.

- Determine if a 3-digit error code is displayed for the Initial Intake (M149) transaction or the Name and Address Change / Transfer (M159) transaction:

- If no, go to step 48.

- If yes, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cs_reg#nc_item_6)

- In FTS, select Direct Deposit and compare the information on the system to the direct deposit information on the application:

- If the direct deposit information in the system is correct, go to step 49.

- If the direct deposit information in the system is incorrect, refer to Direct Deposit for guidance if necessary and go to step 49.
               [Direct Deposit](/en/procedure/activity/direct_deposit.shtml)

- In NWS, complete the CS WI. 

#### Reassigning the issue to Level 1

Source topic: `en_EN/task/cs_reg/reassigning_the_issue_to_level_1_non-complex.dita`

- In NWS, reassign the CS WI as follows:

- Destination: Select Next available user .

- Complexity: Select Level 1 .

- Reason: Select Unable to complete .

- Details: Type "Not within Non-complex authority."

- Select OK. 

#### Reason for deletion is no longer valid

Source topic: `en_EN/task/cs_reg/reason_for_deletion_is_no_longer_valid_non-complex.dita`

- In NWS, reassign the REM WI to Level 1 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 1 .

- Reason: Select Unable to complete .

- Details: Type "Reason for deletion is no longer valid — reactivate cancelled claim."

- Select OK. 

#### Fraud indicators are present

Source topic: `en_EN/task/cs_reg/fraud_indicators_are_present_non-complex.dita`

- In NWS, determine if any of the following WIs are on file and directly related to the potentially fraudulent application for which a CS WI has been created:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3015.dita) 

- If no, go to step 2.

- If yes, go to step 12.

- Determine if any of the following are on file and directly related to the potentially fraudulent application for which a CS WI has been created:

- an Integrity AI WI;

- an Integrity SROC;

- a D71 or an MA71;

- in RMDS, on the Employer profile screen, the Under investigation box is checked.

- If no, go to step 3.

- If yes, go to step 10.

- Determine if the fraudulent application for which a CS WI has been created was received after the client’s legitimate continuing claim:

- If yes, go to step 4.

- If no, go to step 7.

- Determine if the client’s continuing claim has been compromised:

- If yes, go to step 5.

- If no, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2651.dita)

- Determine if an MA71 is already imposed:

- If no, go to step 6.

- If yes, go to step 10.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave the field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 7.

- In NWS, determine if a suspected fraud has previously been referred to Integrity in an AI WI that has not been completed:

- If yes, go to step 8.

- If no, go to step 9.

- Add the information related to the potentially fraudulent application to the existing Integrity AI WI as follows:

- Right-click and select Add details/Further inquiry .

- Action: Select Additional Information .

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save.

- If it is a renewal application, go to step 10.

- If it is an initial application, go to step 12.

- In NWS, refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the processing unit in the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue: Select SIR validation .

- Comments: Type “Fraud suspected — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- If it is a renewal application, go to step 10.

- If it is an initial application, go to step 12.

- Determine if there is an outstanding registration number related to the fraudulent renewal application:

- If yes, go to step 11.

- If no, go to step 12.

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the registration number related to the fraudulent renewal application as follows:

- Action: Select Cancel .

- Select Update .

- No further action is required.

- In NWS, complete the CS WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_3006.dita`

Note:

If the fraud warning is present in FTS so that the SIN field on the tombstone data is highlighted in red and a red warning symbol is shown or if an MA71 is on file for a previous application on which fraud indicators are present, go to step 2. 

#### Note

Source topic: `en_EN/common_notes/note_c_3007.dita`

Note:

When the REM WI moves to the current workload, determine if the reason for deletion is still valid:

- If yes, reassign the REM WI to the authorized user.

- If no, go to Reason for deletion is no longer valid.

Officers in the Quebec region must refer to the Regional considerations. 

#### Note

Source topic: `en_EN/common_notes/note_c_3008.dita`

Note:

On the Summary tab in FTS, compare the Latest renewable week and the Last week processed fields with the application date in NWS to determine if claimant’s reports have been processed up to the LRW. 

#### Note

Source topic: `en_EN/common_notes/note_c_3009.dita`

Note:

Both applications must be thoroughly reviewed question-by-question to verify that all the answers in both applications are the same. 

#### Note

Source topic: `en_EN/common_notes/note_c_3010.dita`

Note:

When the client is requesting another BT and received the maximum entitlement weeks for a BT before the LRW, the Latest Renewable Week tab in FTS may display the last week paid instead of the correct LRW. To ensure that the LRW has not been reached, in FTS, on the most recent terminated claim, select the Rate/Duration tab. On the Claim duration section, the End of Initial benefit period box indicates the correct LRW. 

#### Note

Source topic: `en_EN/common_notes/note_c_3011.dita`

Note:

ACP cannot register a new application when there is an outstanding initial or renewal registration. There can be no more than one outstanding initial or renewal registration number on a claim, and no more than 2 outstanding registration numbers. If there are already 2 outstanding registration numbers, advise the team leader that multiple registration numbers are preventing a new one from being created. 

#### Note

Source topic: `en_EN/common_notes/note_c_3012.dita`

Note:

ACP cannot register a new application when there is an outstanding initial or renewal registration. There cannot be more than one outstanding initial or renewal registration number on a claim and not more than 2 outstanding registration numbers. If there are already 2 outstanding registration numbers, advise the team leader that multiple registration numbers are preventing a new one from being created. 

#### Note

Source topic: `en_EN/common_notes/note_c_2168.dita`

Note:

The information from the application in NWS is automatically downloaded in SSO. In rare cases, the information is not downloaded and must be manually input. Verify (and correct, if necessary) any prefilled fields with the information provided on the application. 

#### Note

Source topic: `en_EN/common_notes/note_c_2647.dita`

Note:

When the client has only one name, one of the name fields on the Name and Address screen may be empty or contain a non-alphabetical character. However, SSO does not allow the field to be completed in this way.

When a name field is empty or contains a non-alphabetical character, do the following:

- First Name: Enter the appropriate option:

- For a client who selects the Male gender marker, type “Mr.”

- For a client who selects the Female gender marker, type “Ms.”

- For a client who selects X as the gender marker, type “N.A.”

- Last Name: Enter the client’s name.

When the First Name field on the Name and Address screen is modified to “N.A.”, modify the Initial Intake (M149) or Name and Address Change / Transfer (M159) transaction generated by the calculation and type “.” in the First Name field before transmitting it. 

#### Note

Source topic: `en_EN/common_notes/note_c_2648.dita`

Note:

At this step, a registration number is assigned to the claim. If Yes is selected, the Initial Intake (M149) transaction is automatically generated.

If No is selected, the Initial Intake (M149) transaction is not generated. 

#### Note

Source topic: `en_EN/common_notes/note_c_3013.dita`

Note:

When manually creating a CA WI, do not input “1004” in the Error number field because only 2 digits can be input in that field. 

#### Note

Source topic: `en_EN/common_notes/note_c_1570.dita`

Note:

There cannot be more than 2 outstanding registration numbers. If there are already 2 outstanding registration numbers, advise the team leader that multiple registration numbers are preventing a new one from being created. 

#### Note

Source topic: `en_EN/common_notes/note_c_1571.dita`

Note:

When the message Success — Registration number created is displayed in SSO, a recalculation registration number is assigned to the claim. NWS creates a CR WI and assigns it to the unassigned (UNA) workload or to the next available user. 

#### Note

Source topic: `en_EN/common_notes/note_c_3014.dita`

Note:

Never input the Initial Intake (M149) transaction in FTS. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3015.dita`

- a CR Integrity ERB-EI Transition WI;

- an AI WI from Integrity indicating that the claim can be established;

- a CB WI;

- an SROC with the following indicated in the Comments field: “Decision made by the specialized team.”

- a record of decision (ROD) confirming that a third party submitted the EI application. 

#### Note

Source topic: `en_EN/common_notes/note_c_2651.dita`

Note:

A claim is considered to be compromised when the client’s information (address or direct deposit information) has been changed. If the claim is compromised, impose an MA71. 

## Policy reference

Source topic: `en_EN/task/cs_reg/policy_reference.dita`

 
