# Adjudicating a dismissal or suspension — Initial claim

Source map: `en_EN/task/dismissal_ds_ic/dismissal_ds_ic.ditamap`

## Summary

Source topic: `en_EN/task/dismissal_ds_ic/summary.dita`

Summary: Dismissal or suspension from employment may affect a client’s entitlement to regular benefits on an initial claim. The officer must determine whether the client was dismissed or suspended because of misconduct. 

## What you need to know

Source topic: `en_EN/task/dismissal_ds_ic/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/dismissal_ds_ic/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3236.dita) 

### Defining misconduct

Source topic: `en_EN/task/dismissal_ds_ic/defining_misconduct.dita`

If there is an indication of misconduct, Level 2 officers must follow the Fact-finding procedure and render a decision. An ROE is not required to adjudicate a dismissal or suspension.
       [Fact-finding](/en/procedure/task/fact_find.shtml)

Misconduct can be defined as:

- a wrongful act or breach of an obligation in the employment contract, committed voluntarily, deliberately, knowingly or of such a careless or negligent nature that it appears to have been committed deliberately;

- which has a negative effect on the continuation of the employer-employee relationship.

In this respect, Service Canada must:

- offer the client and employer the possibility of providing information on the reason for separation (RFS);

- take this information into account in its decision.

When there are contradictory statements, allow both parties to provide an explanation or clarification. 

### Client does not want employer to be contacted

Source topic: `en_EN/task/dismissal_ds_ic/client_does_not_want_employer_to_be_contacted.dita`

If the client does not want the employer to be contacted, officers must explain that they are legally required to fact-find with the employer. If the client insists that the employer not be contacted, officers advise the client that the only alternative is to withdraw the claim for benefits. Officers must then document the client’s request to withdraw the claim. Refer to Withdrawing an application .
       [Withdrawing an application](/en/procedure/task/withdraw_an_app.shtml) 

### Railway misconduct

Source topic: `en_EN/task/dismissal_ds_ic/railway_misconduct.dita`

In the interest of public safety, the rules governing railway employees in the course of their duties, particularly those in the operating groups, are very strict. Railway employees are subject to suspension or dismissal for causes which, in other industries, would not carry such severe penalties. When an employee from the railway sector (railway employee) is dismissed or suspended, the officer must request a copy of the hearing transcript issued by the disciplinary committee, as well as all of the other files containing evidence regarding the separation. 

### Mandatory retirement

Source topic: `en_EN/task/dismissal_ds_ic/mandatory_retirement.dita`

Human rights legislation in Canada prohibits mandatory retirement. Very few occupations are exempt from this legislation. Some employers may be able to demonstrate a genuine reason for mandatory retirement, but these cases are rare.

In cases of mandatory retirement, clients do not voluntarily leave their employment. The separation is initiated by the employer. Consequently, a Level 2 officer must adjudicate the RFS as a dismissal and determine whether clients lost their employment due to misconduct. Normally, in the case of mandatory retirement, the facts on file support a decision of misconduct not proven. Written notice to the employer that EI benefits have been allowed is not required as there is no allegation of misconduct. 

### Imposing a disqualification or disentitlement

Source topic: `en_EN/task/dismissal_ds_ic/imposing_a_disqualification_or_disentitlement.dita`

Once it is determined that the client was dismissed for misconduct, the officer must determine whether an indefinite disqualification or disentitlement applies.

If it is determined the client lost their employment due to misconduct, an indefinite disqualification is imposed on the claim for regular benefits, unless the client has worked enough insurable hours since the misconduct to establish a new claim. In that case, on an initial claim, the ROE with the misconduct is excluded from the calculation of the claim.

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is only required on the most recent ROE in the QP if the RFS is contentious. In addition, the common entrance requirement of 420 hours of insurable employment is not used to determine if the client requalifies after a disqualifying event. Instead, the client needs to have worked at least one hour in insurable employment since the disqualifying event and to have filed an EI application.

If the RFS since the disqualifying event on claims with a BPC between w/c 2310 and w/c 2361 is either non-contentious or is adjudicated and allowed, the officer can establish a new claim, with a new BPC between w/c 2310 and 2361, without a disqualification using the hours from all the ROEs in the QP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3237.dita) 

**Disentitled due to a suspension**

There may be situations where the employee is suspended from his duties for having acted in a way that resembles misconduct. The employer generally uses that suspension to review the evidence and determine if a disciplinary measure is sufficient or if a definitive dismissal is appropriate.

A client suspended because of misconduct is not entitled to benefits for each day of the suspension. The 42 - Suspension from employment disentitlement (D42) is imposed to indicate a suspension from work for proven misconduct.

**Dismissed or suspended within 3 weeks of anticipated layoff**

If the client is dismissed within 3 weeks of an anticipated layoff or the end of term employment, the 44 - Loss of employment in anticipation of layoff disentitlement (D44) is imposed. The D44 is imposed for a definite period only (maximum 3 weeks).

The 10 - Dismissal - misconduct proven indefinite disqualification (D10) is imposed in the following situations:

- If the client has been dismissed more than 3 weeks before the anticipated layoff.

- In all other cases of misconduct, except for suspension.

**Effect of disqualification or disentitlement on special benefits**

The D10 disqualification and the D42 and D44 disentitlements are suspended when special benefits are claimed and otherwise payable.

**Relief after suspension**

A client can gain relief from a D42 if one of the following conditions is met:

- The period of suspension expires.

- The client loses or voluntarily leaves the employment. In this case, the officer adjudicates the RFS before terminating the D42.

- The client accumulates with another employer the number of insurable hours required to qualify to receive benefits.

If the suspension is only in the QP, and the client has gained relief and is not requesting benefits during the suspension, the officer does not need to adjudicate the suspension. This applies for any suspension in the QP other than a suspension from the last employer before the BPC. The officer selects Misconduct not proven in the Decision field of the Resolve Issue tab and explains the decision in the ROD. 

### ROE

Source topic: `en_EN/task/dismissal_ds_ic/roe.dita`

An ROE is not required to adjudicate dismissal.

In NWS, there may be a New ROE message displayed on the ADJ WI for the dismissal issue. The message indicates that a new ROE has been received with an RFS that must be reviewed. The ROE may match the period of employment for that or another outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3238.dita) 

### Automated adjudication

Source topic: `en_EN/task/dismissal_ds_ic/automated_adjudication.dita`

ACP does not automate a Level 2 decision for dismissal.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3239.dita) 

### Notifying the employer

Source topic: `en_EN/task/dismissal_ds_ic/notifying_the_employer.dita`

In cases where misconduct was not proven, the employer must be notified in writing of the decision and of the right to request a reconsideration. However, in cases where the employer advises that the client was dismissed for unsuitability, no misconduct is alleged and therefore no notification is required. 

### Claim action status and processing the claim

Source topic: `en_EN/task/dismissal_ds_ic/claim_action_status_and_processing_the_claim.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can process the claim. There is a Resolve Issue tab for ADJ Dismissal WIs which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a ROD based on the Resolve Issue screens. Before the claim is calculated, the system updates the ROE based on the Resolve Issue screens. Before the claim is established, the system also generates the disqualification or disentitlement transaction, if required for the decision. If the dismissal or suspension is allowed and the employer must be notified, the system automates the Z-01-00-00 letter, or creates a Correspondence (COR) WI. If the dismissal or suspension is not allowed, the system creates a COR WI for the D-01-00-00 or N-00-00-00 letter. 

### Reason for separation (RFS) in the benefit period (BP) and In Progress claim action status

Source topic: `en_EN/task/dismissal_ds_ic/reason_for_separation_rfs_in_the_benefi_eaeeaa7b.dita`

A client may find employment at the beginning of the BP and subsequently leave or lose that employment before the initial claim is established. An Adjudication Issue (ADJ) WI is created for officers to adjudicate the contentious RFS. When the decision is that the client was dismissed due to misconduct and that a D10 indefinite disqualification applies in the BP, the system does not automatically impose a disqualification in the BP when the officer completes the screens on the Resolve Issue tab.

When adjudicating an RFS issue in the BP of a claim for which the Claim action status is In Progress , the Level 2 officer documents the decision on the Resolve Issue tab of the ADJ WI, verbally communicates the negative decision to the client and creates a draft of the D-01-00-00 letter as normal. However, the Level 2 officer also manually inputs a D15 and creates a Reminder (REM) WI for Level 1 before completing the ADJ WI.

The Level 2 officer manually imposes a D15 effective from the Monday of the week of the disqualifying event. Imposing the D15 allows the claim to continue in automation and prevents the payment of benefits from the date the client is dismissed due to misconduct in the BP.

When creating the REM WI for Level 1, the Level 2 officer includes instructions to impose the indefinite D10, rescind the D15 and send the D-01-00-00 letter. The Level 1 officer waits until the claim is established before actioning the REM WI. 

### Previously adjudicated dismissal

Source topic: `en_EN/task/dismissal_ds_ic/previously_adjudicated_dismissal.dita`

In some cases, the ADJ WI may be for a dismissal issue that was previously adjudicated. The officer indicates on the Resolve Issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the appropriate special condition based on the previous decision. The system updates the ROE when the ADJ WI is completed. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/dismissal_ds_ic/determining_if_the_file_must_be_referre_f4ff817e.dita`

When the RFS was undisclosed on a previous claim and a potential overpayment situation exists, refer to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/dismissal_ds_ic/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the dismissal or suspension is not required if the employment is not insurable either because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, the ADJ WI must not be completed. The officer follows the procedures and conditions for removal of claims from ACP process . The officer moves the ADJ WI to Pending until the Claim Assessment (CA) or Specialized Application (SA) WI is created. An authorized user must then delete the ADJ WI.
       [procedures and conditions for removal of claims from ACP process](https://esdc.prv/en/service-canada/ei/technologies/acp/index.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3240.dita) 

### Reason for separation (RFS) — Temporary Budget measures

Source topic: `en_EN/task/dismissal_ds_ic/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**Adjudicating the last employment in the qualifying period (QP) — BPCs between w/c 2310 and w/c 2361**

Budget 2021 has introduced a temporary simplification measure starting September 26, 2021. For claims with a BPC between w/c 2310 and w/c 2361, the officer will only adjudicate the last period of employment in the QP if it is contentious. If the officer allows the last RFS, all other ROEs in the QP, even if they are contentious, are used to calculate the claim. If, however, the officer does not allow the RFS on the last ROE in the QP, the claim is calculated with a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 

This new measure does not apply to fishing claims and claims from self-employed people. Instead, if clients have insurable employment in the QP with a contentious RFS and a BPC between w/c 2310 and w/c 2361 when they apply for self-employed (SE) or fishing benefits, the officer must adjudicate the contentious RFS following normal adjudication procedures.

When the client declares other employers with a contentious RFS on the same application, if ACP does not allow the issue under auto-adjudication rules, the issue is automatically resolved and ACP creates a record of decision (ROD) that shows Adjudication not Required . The Special condition field on the ROE is not updated, and the ROE is included in the calculation. An Adjudication Issue (ADJ) WI is not created for the RFS.

ACP does not always automatically create an ADJ WI when the application is received. However, if an ROE with a contentious RFS is received during the automation process, ACP may create an ADJ WI or ROE Issue (ROE) RFS Action WI.

When there is more than one ROE with the same last day paid (LDP), and one of the ROEs is contentious while the other ROE is not, adjudication is not required and both ROEs are included in the calculation.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3241.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3242.dita) 

**Adjudication not required: Reason for separation (RFS) beyond 12 weeks — BPCs between w/c 2258 and w/c 2309**

Adjudication principles on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309 only apply to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the I of E used to establish the claim.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3243.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1737.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_3236.dita`

Note:

If the adjudication of the dismissal is part of a recalculation or if it is a Claim Review (CR) WI, the officer must refer to Adjudicating a dismissal or suspension — Continuing claim .
       [Adjudicating a dismissal or suspension — Continuing claim](/en/procedure/task/dismissal_ds.shtml)

     [Adjudicating a dismissal or suspension — Continuing claim](/en/procedure/task/dismissal_ds.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3237.dita`

Note:

For claims with BPCs between w/c 2310 and w/c 2361, excluded ROEs only apply to SE benefits and Fishing claims. 

### Note

Source topic: `en_EN/common_notes/note_c_3238.dita`

Note:

The client may report dismissal on the application for benefits, but the ROE indicates a non-contentious RFS. In this situation, fact-finding is required. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the WI is completed indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_3239.dita`

Note:

If a claim is between w/c 2310 and w/c 2361 and all ROEs are on file, ACP may automatically resolve ADJ RFS WIs for periods of employment other than the last. 

### Note

Source topic: `en_EN/common_notes/note_c_3240.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the dismissal or suspension is required when the employment is not insurable due to a non-arm’s length issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Example 1

Source topic: `en_EN/common_notes/note_c_3241.dita`

Example 1:

Peter’s LDP was September 28, 2021 (w/c 2310) with 2 employers. Three periods of employment are provided on his EI application. Peter declared Employer 1 as his last employer and the RFS is shortage of work. In the Other Employers section of the application, Peter declared Employer 2 and the RFS is dismissal. He also declared Employer 3 and the RFS is voluntary leaving. The interruption of earnings (I of E) is in w/c 2310, and he applied for benefits on September 29, 2021. His BPC is September 26, 2021 (w/c 2310).

There are 2 contentious ROEs on Peter’s file:

- Employer 1: The LDP is September 28, 2021 (w/c 2309). The RFS is A .

- Employer 2: The LDP is September 28, 2021 (w/c 2309). The RFS is M .

- Employer 3: The LDP is May 19, 2021 (w/c 2291). The RFS is E .

Employer 1 and Employer 2 have the same LDP. The RFS with Employer 1 is non-contentious, so adjudication is not required for Employer 2. ACP automatically resolves the RFS for Employer 2 and creates a ROD that shows Adjudication not required .

The RFS with Employer 3 is contentious and is in the QP. However, because it is not the last employer in the QP, adjudication is not required. ACP creates a ROD that shows Adjudication not required .

All ROEs are included in the calculation of the claim. 

### Example 2

Source topic: `en_EN/common_notes/note_c_3242.dita`

Example 2:

Abdul’s LDP was September 24, 2021 (w/c 2309) with both of his employers. He declared Employer 1 as his last employer and the RFS is dismissal. In the Other Employers section of the application, Abdul declared Employer 2 and the RFS is voluntary leaving. The I of E is in w/c 2309, and he applied for benefits on September 26, 2021. His BPC is September 26, 2021 (w/c 2310).

- There are 2 contentious ROEs on Abdul’s file:

- Employer 1: The LDP is September 24, 2021 (w/c 2309). The RFS is M .

- Employer 2: The LDP is September 24, 2021 (w/c 2309). The RFS is E .

Employers 1 and 2 have the same LDP and the RFS with both employers are contentious. ACP creates an ADJ WI for Employer 1, automatically resolves the RFS issue for Employer 2 and creates a ROD that shows Adjudication not required. If the dismissal with Employer 1 is not allowed, the RFS with Employer 2 must be adjudicated. 

### Example

Source topic: `en_EN/common_notes/note_c_3243.dita`

Example:

Mary’s LDP was September 25, 2020 (w/c 2257). Her I of E is in w/c 2257, she submitted her application for benefits on September 26, 2020, and her BPC will be September 27, 2020 (w/c 2258).

There are 3 contentious ROEs on Mary’s file:

ROE 1: LDP September 25, 2020 (w/c 2257).

ROE 2: LDP July 17, 2020 (w/c 2247).

ROE 3: LDP May 31, 2020 (w/c 2241).

To determine which RFS to adjudicate, the officer subtracts 12 weeks from w/c 2257 (week of the I of E). For the example above, the formula is as follows: w/c 2257 (I of E) – 12 = w/c 2245. This determines a 12-week period falling before the Sunday of the I of E that encompasses the weeks from w/c 2245 to w/c 2256. The officer follows normal procedures and adjudicates ROE 1, which is the most recent ROE in the QP, and ROE 2, as it falls between w/c 2245 and w/c 2256, the 12-week period.

The officer allows any contentious RFS that occurs before the 12-week period. ROE 3 is before the 12-week period, so the officer allows the RFS by following the steps of Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
       [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#beyond_12_wks)

     [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#beyond_12_wks) 

### Note

Source topic: `en_EN/common_notes/note_c_1737.dita`

Note:

For information regarding reason for separation (RFS) issues resulting from a client not complying with the employer’s COVID-19 vaccination policy, the officer refers to the EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo) .
       [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml)

     [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml) 

## Regional considerations

Source topic: `en_EN/task/dismissal_ds_ic/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/dismissal_ds_ic/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/dismissal_ds_ic/in_nws.dita`

- Is there a ROD for dismissal on this or a prior application?

- What is the client’s statement in the Dismissal section of this or a prior application?

- Are there any SROCs, Action Item WIs or documentation containing additional information on the dismissal or suspension?

- What benefit type (BT) is the client applying for?

- Is the appropriate ROE linked to the period of employment for the dismissal issue? 

### In Imaging:

Source topic: `en_EN/task/dismissal_ds_ic/in_imaging.dita`

- Are there any imaged documents that may provide additional information on the dismissal or suspension? 

### In RCM:

Source topic: `en_EN/task/dismissal_ds_ic/in_rcm.dita`

- Is there an ROE for the dismissal?

- If yes, what is the RFS?

- Are there any comments related to the dismissal or suspension?

- Are there other ROEs since the loss of employment? If so, does the client have enough hours after the dismissal to qualify for benefits? 

## Step by step

Source topic: `en_EN/task/dismissal_ds_ic/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/dismissal_ds_ic/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/dismissal_ds_ic/reviewing_the_file_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, determine if the appropriate ROE is linked to the period of employment:

- If yes, go to step 2.

- If no , select the appropriate ROE in the list and select Save to create a link.

- If the ROE is not on file, go to step 2.

- Determine if there is a ROD for the dismissal or suspension issue on file:

- If there is no ROD for the dismissal or suspension issue, go to step 3.

- If there is a ROD for the dismissal or suspension issue, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#DecOnFile)

- If the client is correcting previously provided information or providing previously omitted information, determine if the information may impact the client’s entitlement to benefits previously paid:

- If yes, determine if the issue should be referred to Integrity by consulting Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- If no, go to step 4.

- Determine if the facts on file clearly indicate that the RFS occurred before the QP:

- If no, go to step 5.

- If yes, go to Reason for separation (RFS) occurred before the qualifying period (QP) .
               [Reason for separation (RFS) occurred before the qualifying period (QP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#RFSOutsideQP)

- In FTS, determine if the BPC falls in a period where special measures apply:

- If the BPC is between w/c 2258 and w/c 2309, go to step 6.

- If the BPC is between w/c 2310 and w/c 2360, go to step 8.

- If the BPC is not in either of the periods, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita)

- Determine if the dismissal occurred on the most recent ROE:

- If no, go to step 7.

- If yes, go to step 10.

- Determine if the dismissal occurred within the 12-week period before the I of E:

- If yes, go to step 10.

- If no, go to Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
               [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#beyond_12_wks)

- Determine if the claim is for SE benefits or Fishing:

- If no, go to step 9.

- If yes, go to step 10.

- Determine if the dismissal occurred on the most recent ROE:

- If yes, go to step 10.

- If no, go to Adjudication not required – Budget 2021 simplification measures .
               [Adjudication not required – Budget 2021 simplification measures](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#adj_not_required_budget_2021)

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if the employment is not insurable either because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 12.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if the RFS is a suspension or a dismissal:

- If the RFS is suspension, go to step 13.

- If the RFS is dismissal, go to step 14.

- Determine if all the following conditions are met:

- The suspension is in the QP.

- The period of employment is not the last ROE.

- The client is not requesting benefits during the suspension.

- The client has gained relief from the suspension.

- If no, go to step 14.

- If yes, go to Suspension in the qualifying period (QP) .
                   [Suspension in the qualifying period (QP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#suspension_qp)

- Determine if there is enough information on file to make a decision:

- If no, go to step 15.

- If yes, go to step 18. 

#### Fact-finding

Source topic: `en_EN/task/dismissal_ds_ic/fact-finding_level_2.dita`

- Fact-find with the client and the employer by referring to the Fact Finding Guide or Digest 7 — Misconduct to determine the questions to ask.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3231.dita)

- Determine if the client or employer was reached during fact-finding:

- If the client or employer was reached, go to step 17.

- If the client or employer was not reached or did not reply to the E-02-00-00 email, the N-10-00-00 letter or the Z-00-00-00 letter, go to step 18.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments : Type “[Dismissal or Suspension] — [employer’s name] — [LDW or start date of suspension] — [client or employer].”

- Details : Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1746.dita) 

#### Adjudicating a dismissal or suspension

Source topic: `en_EN/task/dismissal_ds_ic/adjudicating_a_dismissal_or_suspension_level_2.dita`

- Determine if the RFS is contentious:

- If the RFS is dismissal or suspension, go to step 19.

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS).
               [Non-contentious reason for separation (RFS).](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#NotCont)

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if misconduct is proven by considering all evidence provided by both the client and the employer, and the principles outlined in the EIA, EIR and case law (refer to Digest 7 — Misconduct as needed):

- If the decision is that misconduct is proven, go to step 20.

- If the decision is that misconduct is not proven, go to Misconduct not proven .
               [Misconduct not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#NoMisc)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1747.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3233.dita)

- Determine if the client was dismissed within 3 weeks of an anticipated layoff or end of term of employment:

- If no, go to step 21.

- If yes, go to Dismissal before anticipated layoff or end of term of employment — Misconduct proven .
               [Dismissal before anticipated layoff or end of term of employment — Misconduct proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#D44)

- Determine if the client was suspended:

- If the client was suspended, go to Suspension — Misconduct proven .
               [Suspension — Misconduct proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#SuspensionMisconduct)

- If the client was not suspended, go to Dismissal — Misconduct proven .
               [Dismissal — Misconduct proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#DismMisc) 

#### Dismissal — Misconduct proven

Source topic: `en_EN/task/dismissal_ds_ic/dismissal__misconduct_proven_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The client was dismissed or suspended .

- Enter the employer’s name.

- Enter the date of the dismissal.

- Select Continue .

- Complete the Dismissed or Suspended screen as follows:

- Relevant Facts: Select Dismissed .

- Enter the relevant facts.

- Indicate if the client agrees with the employer’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if necessary.

- Rationale: Select the appropriate options and enter any additional information.

- References: Select EIA 30 and enter any additional references.

- Decision: Select Misconduct proven .

- Do you wish to enter a disentitlement for a suspension or anticipated loss of employment?: Select No .

- Select Continue .

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 4.

- If the client was not reached by telephone during fact-finding, go to step 5.

- Verbally communicate the decision to the client.

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- In ACS, create and save a D-01-00-00 letter for regular benefits, or a N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits and does not have enough hours since the dismissal to qualify, select the following attributes:

- Disqualifications - Definite/Indefinite - Previous/current/revision (2970): Select D11 / D10 / Both / Previous disqualification / Revision (Initial/Renewal or Revision) .

- D11 / D10 / Both / Previous disqualification / Revision (Initial/Renewal or Revision) (2542): Select Disqualification message .

- Disqualification message (2543): Select D10 - Misconduct .

- D10 - No benefits payable (Date of event: before, on, or after the BPC date) (2546): Select D10 - Date of event on or before BPC and the appropriate options.

- D10 - Min hrs req for reg ben/Insuf. hrs accum. since event reg/Insufficient hrs reg+fishing (2547):

- If the client has not worked since the disqualifying event, select Minimum hours required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious the client does not have enough hours since the disqualifying event to qualify, select Insufficient hours accumulated since event for regular benefits or Insufficient hours accumulated since event for regular benefits and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but you do not have the information or knowledge to complete this block, select Minimum hours required to qualify for regular benefits .

- If the client is requesting regular benefits and has enough hours since the dismissal to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE Excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message / D10 Message (1503): Select D10 message .

- If the client is requesting special benefits and does not have enough hours since the dismissal to qualify for regular benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- Not entitled to regular after special: - D10/D11 or claim is BPNE – Initial or renewal claim or D42 – D43 (2540): Select (D11/D10) imposed – Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491): Select D10 imposed – Special benefits allowed .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D10 Min hours required to qualify for regular benefits/Not enough hours worked since event for regular/Not enough hours worked since event for regular and not enough fishing earnings for fishing benefits (2547):

- If the client has not worked since the disqualifying event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious there are insufficient hours since the disqualifying event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but you do not have the information or knowledge to complete this block, select Min hrs required to qualify for regular benefits .

- If the client is requesting special benefits and has enough hours since the disqualifying event to qualify for regular benefits, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE Excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (1503): Select D10 message .

- Special benefits approved (3046): Select BT and the appropriate options.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In FTS, determine if the dismissal occurred after the tentative BPC:

- If no, go to step 8.

- If yes, go to Misconduct proven — Reason for separation (RFS) in the benefit period (BP) .
               [Misconduct proven — Reason for separation (RFS) in the benefit period (BP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_ic#_Misconduct_Proven_Reason)

- In NWS, create a client Note instructing the responsible officer to add the appropriate attributes before sending the saved D-01-00-00 or N-00-00-00 letter when completing the COR WI.

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/dismissal_ds_ic/decision_already_on_file_level_2.dita`

- Determine if the appropriate decision is listed:

- If yes, select the appropriate ROD in the list and select Save . Go to step 4.

- If no , select Decision not in the list .

- Select the appropriate special condition option based on the decision on file and select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reason for separation (RFS) occurred before the qualifying period (QP)

Source topic: `en_EN/task/dismissal_ds_ic/reason_for_separation_rfs_occurred_befo_370bd688_level_2.dita`

- In NWS, on the General Details tab of the ADJ WI, change the complexity of the WI as follows:

- Complexity: Select Level 1 .

- Select Save .

- When the Warning window is displayed, select OK .

- On the Resolve Issue tab of the ADJ WI, complete the Level 1 dismissal screen as follows:

- Select The period of employment falls prior to the qualifying period .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Adjudication not required – Budget 2021 simplification measures

Source topic: `en_EN/task/dismissal_ds_ic/adjudication_not_required__budget_2021__620824ac_level_2.dita`

- In NWS, on the General Details tab of the ADJ WI, change the complexity as follows:

- Complexity : Select Level 1

- Save

- Select Continue

- On the Resolve Issue tab of the ADJ WI, complete the Level 1 Dismissal screen as follows:

- Resolve issue: Select Adjudication not required – Budget 2021 simplification measures .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Adjudication not required — Reason for separation (RFS) beyond 12 weeks

Source topic: `en_EN/task/dismissal_ds_ic/adjudication_not_required__reason_for_s_d81cc200_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The client was dismissed or suspended .

- Enter the employer’s name.

- Enter the date of the dismissal or suspension.

- Select Continue .

- Complete the Dismissed or Suspended screen as follows:

- Relevant Facts: Select Dismissed or Suspended .

- Type “Reason for separation is beyond the 12-week period and adjudication is not required.”

- Does the client agree with the employer’s version of the events?: Select Not applicable .

- Credibility: Select Credibility was not a factor in the decision-making process .

- Rationale: Select No for each option.

- Additional information: Type “Post-Employment Insurance Emergency Response Benefit transitional measure.

- References — Any additional references: Type “EIA 153.194.”

- Decision: Select Misconduct not proven .

- Written Notification: Select No .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/dismissal_ds_ic/employment_is_not_insurable_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Dismissal or Suspension] — [employer’s name] — [LDW or start date of suspension] — adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed people). Adjudication of the dismissal or suspension is therefore not required.”

- The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the dismissal or suspension is therefore not required.”

- Determine the Claim action status:

- If the status is Initial — In Progress (Automation) , go to step 3.

- If the status is Initial — In Progress (Manual) , go to step 6.

- In NWS, create a Reminder WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “ACP.”

- Due date: Enter today’s date.

- Language: Select the appropriate option.

- Details: Type “2” and “Processing — [unallocated or user name to whom the CA or SA WI is to be assigned].”

- Destination: Select Level and Canada .

- End User: Select Specific user . Type “SV-ADMIN, ACP-TAD” and select Find User .

- Select Save .

- Move the ADJ WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting removal of claim from automation process. Employment not insurable. This WI must be deleted once CA or SA WI is created.”

- Bring forward date: Enter today’s date + 2 business days.

- Select OK .

- When the ADJ WI moves to the current workload, confirm that the Claim action status is Initial — In Progress (Manual) and a CA or SA WI was created.

- Contact an authorized user (team leader or business expertise advisor) to delete the ADJ WI. 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/dismissal_ds_ic/non-contentious_reason_for_separation_rfs_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The reason for separation is not dismissal or suspension .

- Select Continue .

- Complete the Not dismissal or suspension screen as follows:

- Select the appropriate RFS.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Misconduct proven — Reason for separation (RFS) in the benefit period (BP)

Source topic: `en_EN/task/dismissal_ds_ic/misconduct_proven__reason_for_separatio_64987016_level_2.dita`

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose the D15 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select - Add .

- Disentitlement: Select 15 - Claim procedure .

- Start date: Enter the disentitlement start date (i.e. the Monday of the week of the disqualifying event).

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Impose D10 and rescind D15 starting on w/c XXXX-X.”

- Due Date: Enter today’s date + 2 business days.

- Language: Select the appropriate option.

- Benefit type: Select the appropriate option.

- Details: Type

- “If the claim is finalized as BPNE or if a D10 was imposed from BPC, no further action is required. Complete the REM WI.”

- “If the claim is established (not BPNE), do the following:

- In FTS, obtain a revised registration number.

- Input the indefinite D10 from w/c XXXX (week of the disqualifying event).

- Rescind D15 from w/c XXXX-X.

- Add the appropriate attributes and send the saved D-01-00-00 or N-0-00-00 ACS letter, if not already sent.”

- Destination — Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Revised BPNE .

- End User: Select Next available user .

- Select Save .

- Complete the ADJ WI. 

#### Misconduct not proven

Source topic: `en_EN/task/dismissal_ds_ic/misconduct_not_proven_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The client was dismissed or suspended .

- Enter the employer’s name.

- Enter the date of the dismissal or suspension.

- Select Continue .

- Complete the Dismissed or Suspended screen as follows:

- Relevant Facts: Select Dismissed or Suspended .

- Enter the relevant facts.

- Indicate if the client agrees with the employer’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if necessary.

- Rationale: Select the appropriate options and enter any additional information.

- References: Enter any additional references.

- Decision: Select Misconduct not proven .

- Written Notification: Select the appropriate option and, if necessary, provide the employer’s information for the letter.

- Indicate if the client was suspended from employment.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Dismissal before anticipated layoff or end of term of employment — Misconduct proven

Source topic: `en_EN/task/dismissal_ds_ic/dismissal_before_anticipated_layoff_or__f67a228e_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The client was dismissed or suspended .

- Enter the employer’s name.

- Enter the date of the dismissal.

- Select Continue .

- Complete the Dismissed or Suspended screen as follows:

- Relevant Facts: Select Dismissed or Suspended .

- Enter the relevant facts.

- Indicate if the employer agrees with the client’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if necessary.

- Rationale: Select the appropriate options and enter any additional information.

- References: Select EIA 33 and enter any additional references.

- Decision: Select Misconduct proven .

- Do you wish to enter a disentitlement for a suspension or anticipated loss of employment?: Select Yes .

- Input Disentitlement: Select Anticipated loss of employment (D44) and enter the disentitlement end date (must be a weekday).

- Verify the information on the Record of Decision screen:

- Check I agree .

- In ACS, create and save a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the appropriate options:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 ( 3021): Select D44: Loses employment due to misconduct within 3 weeks of layoff or end of term .

- We/In addition, we (2687) .

- Definite disentitlement start date (1272): Enter the appropriate date.

- Definite disentitlement end date (1274): Enter the appropriate date.

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the date of the dismissal.

- being laid off/the end of your term (3023): Select being laid off or the end of your term .

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text – Footnote (1066): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [X] to [X] because you were dismissed from your job with [Text - Name of Employer(s)] due to misconduct on [Date of Event] within 3 weeks of [being laid off/the end of term].”

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to send the saved letter when completing the COR WI.

- Complete the ADJ WI. 

#### Suspension — Misconduct proven

Source topic: `en_EN/task/dismissal_ds_ic/suspension__misconduct_proven_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The client was dismissed or suspended .

- Enter the employer’s name.

- Enter the date of the suspension.

- Select Continue .

- Complete the Dismissed or Suspended screen as follows:

- Relevant Facts: Select Suspended .

- Enter the relevant facts.

- Indicate if the client agrees with the employer’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if necessary.

- Rationale: Select the appropriate options and enter any additional information.

- References: Select EIA 31 and enter any additional references.

- Decision: Select Misconduct proven .

- Do you wish to enter a disentitlement for a suspension or anticipated loss of employment?: Select Yes .

- Input Disentitlement: Select Suspension from employment (D42) .

- Disentitlement start: Select the appropriate option.

- Disentitlement end: Select Indefinite .

- Select Continue .

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 4.

- If the client was not reached by telephone during fact-finding, go to step 5.

- Verbally communicate the decision to the client.

- Verify the information on the Record of Decision screen:

- Check I agree .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3244.dita)

- Determine if the facts reveal that the client quit or was dismissed after the suspension:

- If yes, go to step 7.

- If no , go to step 9.

- In FTS, select the Registration Number (M025, M030, M035) transaction, assign a registration number and create a CR WI as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Create Work Item: Check the box.

- Select Update .

- In NWS, reassign the CR WI as follows:

- Destination: Select Myself .

- Issue: Select Dismissed or suspended or Quit .

- Complexity: Select Level 2 .

- Send to my pending workload: Check the box.

- Reason: Select Other .

- Details: Type “The Claim action status of the initial claim is In progress. The client [quit/was dismissed] while on suspension. Requires termination of D42 and adjudication of RFS after the claim is finalized.”

- Bring forward date: Enter the next business day.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3245.dita)

- In ACS, create and save a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the appropriate options:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 (3021): Select D42 - Suspension due to misconduct .

- We/In addition, we (2687)

- Indefinite/Definite/Multiple Disentitlement dates (2485): Enter the appropriate dates.

- are/were (2979) .

- since/on (3022) .

- Date of suspension from employment (1470): Enter the appropriate date.

- Text - Name of employer(s) (1502): Enter the employer’s name.

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [X] to [X] because you were suspended from your job with [Text - Name of Employer(s)] due to misconduct.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to send the saved letter when completing the COR WI.

- Complete the ADJ WI. 

#### Suspension in the qualifying period (QP)

Source topic: `en_EN/task/dismissal_ds_ic/suspension_in_the_qualifying_period_qp_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The client was dismissed or suspended .

- Enter the employer’s name.

- Enter the date of the suspension.

- Select Continue .

- Complete the Dismissed or Suspended screen as follows:

- Relevant Facts: Select Suspended .

- Type “Fact-finding and adjudication not required — suspension is in the QP and client has gained relief.”

- Does the client agree with the employer’s version of events?: Check the Not applicable box.

- Credibility: Check the Credibility was not a factor box.

- Rationale: Select no in all the boxes and then type “Suspension in the QP.”

- Decision: Select Misconduct not proven .

- Written Notification: Is a letter to the employer required?: Select No .

- Was the client suspended from employment?: Select Yes .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_3231.dita`

Note:

If the employee’s disciplinary record contains documentary evidence related directly to the dismissal or suspension, we should request a copy of the client’s file from the employer. In cases of railway misconduct, we must also request a copy of the hearing transcript. 

#### Note

Source topic: `en_EN/common_notes/note_c_1746.dita`

Note:

Create a new SROC for each conversation with the employer or the client (e.g. if you contacted the employer twice, create 2 SROCs). 

#### Note

Source topic: `en_EN/common_notes/note_c_1747.dita`

Note:

If you are unable to contact the client or the employer, render a decision based on the information on file. 

#### Note

Source topic: `en_EN/common_notes/note_c_3233.dita`

Note:

Railway misconduct is only proven when the officer is able to obtain the transcript of the disciplinary committee hearing or when the client has provided sufficient facts regarding the railway rule or regulation violation to prove misconduct without the transcript. 

#### Note

Source topic: `en_EN/common_notes/note_c_3244.dita`

Note:

Even if the facts reveal that the client quit or was dismissed after the suspension, the system still imposes the D42 indefinitely. 

#### Note

Source topic: `en_EN/common_notes/note_c_3245.dita`

Note:

When the initial claim is finalized, refer to the appropriate procedure for guidance on completing the CR WI. 

## Policy reference

Source topic: `en_EN/task/dismissal_ds_ic/policy_reference.dita`

- Digest 7 — Misconduct
         [Digest 7 — Misconduct](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-7/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- EIA 31
         [EIA 31](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-31.html)

- EIA 33
         [EIA 33](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-33.html) 
