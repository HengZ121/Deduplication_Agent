# Determining if a claim is ready to be renewed or converted

Source map: `en_EN/task/determ_claim_demande_ren_conv/determ_claim_demande_ren_conv.ditamap`

## Summary

Source topic: `en_EN/task/determ_claim_demande_ren_conv/summary.dita`

Summary: Before a claim can be renewed or be converted to another benefit type (BT), an officer must resolve all outstanding issues. 

## What you need to know

Source topic: `en_EN/task/determ_claim_demande_ren_conv/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/determ_claim_demande_ren_conv/untitled_section.dita`

When a client applies for a conversion or a renewal, the officer reviews the claim completely. The officer must consider the following factors:

- outstanding disentitlement or disqualification;

- new contentious issues;

- reason for separation (RFS);

- temporary foreign workers;

- allocation of earnings. 

### Benefit type (BT) requested

Source topic: `en_EN/task/determ_claim_demande_ren_conv/benefit_type_bt_requested.dita`

When a client submits a renewal application for the same BT, the officer refers to the appropriate renewal task. If the renewal application is for a different BT, the officer refers to the appropriate conversion task. 

### Outstanding disentitlement

Source topic: `en_EN/task/determ_claim_demande_ren_conv/outstanding_disentitlement.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies to the renewal or conversion. A Level 1 officer can terminate or rescind the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

For a renewal claim, if the information on file allows for the disentitlement to be terminated, the disentitlement is terminated on the Friday of the week before the renewal week.

For a conversion on a continuing claim, if the information on file allows for the disentitlement to be terminated, the disentitlement is terminated as directed in the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3110.dita) 

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer reassigns the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Return to work (RTW)

Source topic: `en_EN/task/determ_claim_demande_ren_conv/return_to_work_rtw.dita`

If there is an RTW on the claim that falls on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer reassigns the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### New contentious issues

Source topic: `en_EN/task/determ_claim_demande_ren_conv/new_contentious_issues.dita`

**Renewal claim**

When renewing a claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that needs adjudication. If the issue is reported on the application, ACP creates an Adjudication Issue (ADJ) WI. If a contentious issue is detected while reviewing the claim, the Level 1 officer creates an ADJ WI for each contentious issue and attempts to defer adjudication or adjudicate the issue according to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3111.dita) 

If the Level 1 officer cannot adjudicate the issue, the Level 1 officer reassigns the ADJ WI to Level 2 for adjudication. If the Level 1 officer reassigns the file to Level 2 for adjudication, the Level 1 officer:

- initiates fact-finding;

- inputs the renewal;

- imposes a manual action to stop payment, if necessary;

- reassigns the ADJ WI.

When an ADJ WI is created on a renewal claim, either manually or by ACP, FTS automatically imposes a 2 - Contentious Renewal in Automation manual action (MA2) to prevent payment of benefits until the contentious issue is adjudicated and the renewal is complete. If the renewal inputs or a decision must be input manually, the transactions must be input before the ADJ WI is completed. When the ADJ WI is completed, FTS removes the MA2. An officer cannot rescind an MA2.

**Continuing claim**

When converting a continuing claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If there is no existing WI for the issue, the Level 1 officer creates a CR WI for each contentious issue and attempts to defer adjudication or adjudicates the issue according to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA 1) to prevent payment of benefits until the contentious issue is adjudicated.

The Level 1 officer:

- initiates fact-finding;

- creates a CR WI for the contentious issue (e.g. RFS, farming or availability);

- reassigns the CR WI related to the contentious issue to Level 2, if necessary;

- inputs the conversion;

- imposes an MA1.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3112.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3113.dita) 

### Previously deferred decision

Source topic: `en_EN/task/determ_claim_demande_ren_conv/previously_deferred_decision.dita`

When converting or renewing a claim, any RFS for which a decision had previously been deferred must be adjudicated.

When the claim is calculated, if the RFS adjudication is deferred, a disqualification is automatically imposed and appears in FTS on the Disqualification/Disentitlement screen.

The officer must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 10 - Dismissal - misconduct proven (D10) or a 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If a ROD on file indicates that adjudication of an RFS was deferred, the RFS must be adjudicated. A Level 1 officer can adjudicate the RFS according to the National Policy on Levels of Decision . If it is not within Level 1 authority, the officer reassigns the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

If the RFS is now allowed, the officer rescinds the disqualification on file and updates the Special Condition field in RCM.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2728.dita) 

### Temporary foreign workers (900-series SINs)

Source topic: `en_EN/task/determ_claim_demande_ren_conv/temporary_foreign_workers_900-series_sins.dita`

All foreign workers are given temporary resident status for a limited period when they enter Canada. Generally, foreign workers can demonstrate availability to accept work only if they possess a valid work permit which allows them to work in Canada. Therefore, when a foreign worker wants to convert or renew a claim for benefits, the validity of the work permit must be reviewed. For more information, the officer refers to 900-series SIN .
       [900-series SIN](/en/procedure/activity/expired_900.shtml) 

### Allocation of earnings

Source topic: `en_EN/task/determ_claim_demande_ren_conv/allocation_of_earnings.dita`

Whenever clients report receiving monies, the officer determines if these monies are considered earnings for EI purposes. Once it is determined that the monies are earnings, they must be allocated. To determine how the earnings are allocated, the officer refers to Earnings .
       [Earnings](/en/procedure/activity/earnings.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3114.dita) 

### Budget 2021

Source topic: `en_EN/task/determ_claim_demande_ren_conv/budget_2021.dita`

A Budget 2021 measure applies to separation monies that are reviewed between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361) and are paid due to a temporary layoff or a permanent separation from employment. When separation monies are reviewed during that period, they are not considered earnings and are not allocated, regardless of the BPC. Separation monies that are not allocated are not considered when determining the renewal week and cannot extend a benefit period (BP). This measure applies to all BTs for initial, renewal and continuing claims. 

### End of temporary measure

Source topic: `en_EN/task/determ_claim_demande_ren_conv/end_of_temporary_measure.dita`

The Budget 2021 temporary measure under which separation monies were no longer considered earnings expires on September 24, 2022 (w/c 2361). As of September 25, 2022 (w/c 2362), separation monies are again considered earnings and a transitional provision applies to ensure that clients are not penalized by a late review.

New allocations with an allocation start date on or after September 25, 2022 (w/c 2362) apply to initial, renewal and continuing claims and could extend the BP, if necessary. These earnings are considered when determining the renewal week. 

### Modifying an existing allocation

Source topic: `en_EN/task/determ_claim_demande_ren_conv/modifying_an_existing_allocation.dita`

When modifying an existing allocation, the rules that applied to that claim when the allocation was initially input still apply. 

### Transitional provision

Source topic: `en_EN/task/determ_claim_demande_ren_conv/transitional_provision.dita`

As of September 25, 2022 (w/c 2362), when reviewing separation monies, if the allocation start date is between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361), monies paid or payable due to a temporary layoff or a permanent separation from employment are not considered earnings and are not allocated. The allocation start date is the date the allocation would start, even if no BP was established for that period.

For more information, the officer refers to the BE Memo 2022-04 .
       [BE Memo 2022-04](/en/policy/bememo/be2022_04.shtml) 

### Processing claimant’s reports

Source topic: `en_EN/task/determ_claim_demande_ren_conv/processing_claimants_reports.dita`

The last week of benefits must be paid before the officer can input the conversion or renewal transactions. If claimant’s reports have not yet been processed, they must be processed before inputting the transactions. This requires a 2-day input. 

### Adjudication not previously required — Specialized ACP process

Source topic: `en_EN/task/determ_claim_demande_ren_conv/adjudication_not_previously_required__s_a89cd8c4.dita`

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the qualifying period (QP). The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE, but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3115.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a Claim Assessment (CA) Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0126.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_3110.dita`

Note:

A client is not required to demonstrate good cause for delay when submitting a medical certificate. The Level 1 officer can modify or rescind a disentitlement related to a missing medical certificate for special benefits, regardless of the length of the delay, provided all other conditions are met for the requested BT. 

### Note

Source topic: `en_EN/common_notes/note_c_3111.dita`

Note:

If it is not possible to create an ADJ WI, the officer creates a Claim Review (CR) WI. 

### Note

Source topic: `en_EN/common_notes/note_c_3112.dita`

Note:

When the Level 1 officer cannot adjudicate the contentious issue or rescind or terminate an existing disentitlement, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2. The officer does not reassign the CR Conversion WI. The Level 1 officer completes the conversion inputs, imposes an MA1 and completes the CR Conversion WI. 

### Note

Source topic: `en_EN/common_notes/note_c_3113.dita`

Note:

In both cases of a renewal or a conversion on a continuing claim, if the issue is an antedate, the Level 1 officer creates an Action Item (AI) WI. 

### Note

Source topic: `en_EN/common_notes/note_c_2728.dita`

Note:

For all initial claims and recalculations with a BPC between w/c 2310 and w/c 2361, only the last period of employment requires adjudication if it was previously deferred. 

### Note

Source topic: `en_EN/common_notes/note_c_3114.dita`

Note:

Pilot project no. 24 – Separation monies – w/c 2493 to w/c 2572

A temporary measure under Pilot Project No. 24 applies to separation monies paid due to a separation from employment on claims with a BPC or allocation start date between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). When separation monies are paid for that period, they are not allocated. Separation monies that are not allocated cannot extend a benefit period (BP). This measure applies to all benefit types (BTs) for initial, renewal and continuing claims.

To be considered under the temporary measures, one of the following conditions must be met:

- the BPC is between March 30, 2025 (w/c 2493), and October 10 , 2026 (w/c 2572 );

- the separation monies would otherwise be allocated under EIR 36(9) to 36(11) and the first week of allocation falls within the period beginning March 30, 2025 (w/c 2493) to October 10 , 2026 (w/c 2572 ).
         [EIR 36(9)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285) 
         [36(11)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285)

     [EIR 36(9)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285) 
     [36(11)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285) 

### Note

Source topic: `en_EN/common_notes/note_c_3115.dita`

Note:

The specialized ACP process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0126.dita`

Note:

Any contentious RFS issues in the BP must be adjudicated. 

## Regional considerations

Source topic: `en_EN/task/determ_claim_demande_ren_conv/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/determ_claim_demande_ren_conv/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/determ_claim_demande_ren_conv/in_nws.dita`

- Does the client have a 900-series SIN?

- Are there earnings to consider or allocate?

- Was an RFS previously deferred?

- Are there documents related to the issue? 

### In FTS:

Source topic: `en_EN/task/determ_claim_demande_ren_conv/in_fts.dita`

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Is an MA02 imposed on the claim? 

### In RCM:

Source topic: `en_EN/task/determ_claim_demande_ren_conv/in_rcm.dita`

- Has an ROE been submitted?

- If yes, are there earnings to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/determ_claim_demande_ren_conv/in_imaging.dita`

- Is there any other documentation which may impact the renewal or the conversion of the claim? 

## Step by step

Source topic: `en_EN/task/determ_claim_demande_ren_conv/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/determ_claim_demande_ren_conv/level_1.dita`

#### Outstanding SIR Validation (SIR) WI

Source topic: `en_EN/task/determ_claim_demande_ren_conv/outstanding_sir_validation_sir_wi_level_1.dita`

- In NWS, determine if there is a SIR WI:

- If yes, go to step 2.

- If no, go to step 4.

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for the SIR WI to be completed.”

- Bring forward date: Enter today’s date + 10 business days.

- When the CA WI moves to the current workload, determine if the SIR WI has been completed:

- If no, return to step 2.

- If yes, go to step 4.

- Determine if the client is requesting regular benefits:

- If yes, go to step 5.

- If the client is requesting special benefits, go to step 7. 

#### Outstanding disqualification

Source topic: `en_EN/task/determ_claim_demande_ren_conv/outstanding_disqualification_level_1.dita`

- In FTS, determine if a D10 or D11 has been imposed from the BPC because of adjudication:

- If yes and the client has worked since the BPC, go to step 6.

- If yes and the client has not worked since the BPC, go to step 9.

- If no, go to step 7.

- Determine if the client qualifies for a new claim (refer to Calculation of a claim - Index , if necessary):

- If no, go to step 9.

- If yes, refer to Cancelling a benefit period .
               [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3116.dita) 

#### Previously deferred decision

Source topic: `en_EN/task/determ_claim_demande_ren_conv/previously_deferred_decision_level_1.dita`

- Determine if a D10 or D11 has been imposed as a result of a deferred decision:

- If yes, go to step 8.

- If no, go to step 9.

- Determine if adjudication is now required by referring to Deferral of adjudication :

- If adjudication is required and the claim is a continuing claim, note that a CR WI must be created. Go to step 9.

- If adjudication is required and the claim is a renewal claim, note that an ADJ WI must be created. Go to step 9.

- If adjudication can remain deferred, go to step 9. 

#### Outstanding disentitlement

Source topic: `en_EN/task/determ_claim_demande_ren_conv/outstanding_disentitlement_level_1.dita`

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 10.

- If no, go to step 11.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, and the issue is on a renewal claim, create an ADJ WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Availability .

- Details: Type “Outstanding D15 for a missed client information session, Level 2 review required.”

- Go to step 11.

- If yes, and the issue is on a continuing claim, refer the issue to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 11.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If Integrity imposed the D15 for any other reason, refer the issue to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 11.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine if there are any other outstanding disentitlements on file:

- If yes and the claim is a continuing claim, create a CR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- Destination: Select Myself .

- Issue(s): Select the appropriate option.

- Reason: Select Related work item .

- Details: Type “Outstanding [type of disentitlement].”

- Select Save .

- Refer to the appropriate procedure and go to step 12.

- If yes and the claim is a renewal claim, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option (e.g. Availability ).

- Complete the mandatory fields required for the issue.

- Details: Type “Outstanding [type of disentitlement] disentitlement.”

- Refer to the appropriate procedure and go to step 12.

- If no, go to step 13.

- Determine if the conditions are met to terminate or rescind the disentitlement at Level 1 according to the National Policy on Levels of Decision

- If yes, terminate or rescind the disentitlement and go to step 13.

- If no, reassign the ADJ WI or CR WI for the disentitlement to Level 2. Go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita) 

#### Allocation of earnings

Source topic: `en_EN/task/determ_claim_demande_ren_conv/allocation_of_earnings_level_1.dita`

- Determine if the client reports having received monies and whether they have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings and then go to step 14.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 14.

- If no monies were received, go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0094.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3117.dita) 

#### Outstanding claimant’s reports

Source topic: `en_EN/task/determ_claim_demande_ren_conv/outstanding_claimants_reports_level_1.dita`

- In FTS, determine if there is a pending electronic claimant’s report on the E-Report tab for the period before the renewal or the conversion:

- If there is no pending electronic claimant’s report, go to step 15.

- If there is a pending electronic claimant’s report, refer to Actioning a pending claimant’s report and then go to step 15.
               [Actioning a pending claimant’s report](/en/procedure/task/pending_cr.shtml)

- Determine if there are any rejected electronic claimant’s reports on the Pending/Reject tab for the period before the renewal or the conversion:

- If no, go to step 16.

- If yes, re-input the claimant’s reports. Refer to Actioning a rejected claimant’s report and then go to step 16.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml) 

#### Other outstanding issues

Source topic: `en_EN/task/determ_claim_demande_ren_conv/other_outstanding_issues_level_1.dita`

- Determine if there are any other outstanding issues on the file that require adjudication for which there is no WI:

- If no, go to step 18.

- If yes and the claim is a continuing claim, in NWS, create a CR WI for each issue requiring adjudication as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Reason: Select Related work item .

- Details: Indicate the reason the WI is being created.

- Select Save .

- Go to step 17.

- If yes and the claim is a renewal claim, create an ADJ WI for each issue requiring adjudication as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Complete the mandatory fields for the issue type.

- Details: Type the relevant information.

- Go to step 17.

- In FTS, determine if there is an MA02 imposed on the claim:

- If yes, go to step 18.

- If no, select the R enewal/Revised (M106) transaction and impose a MA1 as follows:

- Registration number: If a registration number is displayed, remove it.

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Select Update .

- Return to the previous task. 

#### Note

Source topic: `en_EN/common_notes/note_c_3116.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361 and in which a disqualification has been imposed from the BPC, the client does not need to requalify since the disqualifying event.

When assessing whether it is advantageous to cancel a claim with a BPC between w/c 2310 and w/c 2361, the officer considers that the Budget 2021 temporary measures will not apply to new initial claims with a BPC in w/c 2362 or later. Therefore, the officer compares the current renewable claim and the potential new claim by considering the common entrance requirement (CER), the allocation of separation monies, the weeks of entitlement, the benefit rate, and the adjudication of contentious RFS issues. 

#### Note

Source topic: `en_EN/common_notes/note_c_2721.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose an MA1 to stop payment. 

#### Note

Source topic: `en_EN/common_notes/note_c_0094.dita`

Note:

A temporary measure under Pilot Project No. 24 applies to separation monies paid due to a separation from employment on claims with a BPC or allocation start date between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). When separation monies are paid for that period, they are not allocated. Separation monies that are not allocated cannot extend a BP. This measure applies to all BTs for initial, renewal and continuing claims. 

#### Note

Source topic: `en_EN/common_notes/note_c_3117.dita`

Note:

A Budget 2021 measure applies to separation monies that are reviewed between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361) and are paid due to a temporary layoff or a permanent separation from employment. When separation monies are reviewed during that period, they are not considered earnings and are not allocated, regardless of the BPC. Do not consider separation monies that are not allocated when determining the renewal week.

A transitional provision to the Budget 2021 applies to separation monies that are reviewed on or after September 25, 2022 (w/c 2362). When the allocation start date is between September 26, 2021 (w/c 2310), and September 24, 2022 (w/c 2361), monies paid or payable due to a temporary layoff or a permanent separation from employment are not considered earnings and are not allocated. 

## Policy reference

Source topic: `en_EN/task/determ_claim_demande_ren_conv/policy_reference.dita`

 
