# Adjudicating voluntary leaving (Level 1): Workforce reduction — Initial claim

Source map: `en_EN/task/vl_wr_ic/vl_wr_ic.ditamap`

## Summary

Source topic: `en_EN/task/vl_wr_ic/summary.dita`

Summary: When clients voluntarily leave employment due to workforce reduction, the client’s entitlement to regular benefits on an initial claim may be affected. Adjudication is required to determine if there is just cause for leaving the employment. 

## What you need to know

Source topic: `en_EN/task/vl_wr_ic/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/vl_wr_ic/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4931.dita) 

### Adjudicating voluntary leaving for a workforce reduction

Source topic: `en_EN/task/vl_wr_ic/adjudicating_voluntary_leaving_for_a_wo_b21e16ff.dita`

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave the employment. If it is determined that the client left the employment without just cause, a disqualification is imposed on the claim for regular benefits, unless the client has enough insurable hours since the voluntary leaving to establish a new claim. In this case, the ROE with the voluntary leaving is excluded from the calculation of the claim.

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is only required on the most recent ROE in the QP, if the RFS is contentious. In addition, the common entrance requirement of 420 hours of insurable employment is not used to determine if the client requalifies after a disqualifying event. Instead, the client needs to have worked at least one hour in insurable employment since the disqualifying event and to have filed an EI application.

If the RFS since the disqualifying event on claims with a BPC between w/c 2310 and w/c 2361 is either non-contentious or is adjudicated and allowed, the officer can establish a new claim without a disqualification using the hours from all the ROEs in the QP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0164.dita) 

The objective of a workforce reduction program is to ensure the economic viability of a company, an organization, a firm or a plant. To remain competitive, employers may have to restructure their workforce, which could include permanently reducing the number of employees. The group covered under a workforce reduction program may be all the employees (including seasonal, temporary or on call employees) or it could be limited to a sector, a particular group of workers or a particular work site. Workforce reduction could also include as little as one employee. Employees who leave under an approved workforce reduction program have a complete severance from their employment. The details of the workforce reduction program must be documented.

The appropriate regional workforce reduction coordinator renders all decisions on a workforce reduction program. The regional coordinator ensures that the initial fact-finding is completed and that decisions on workforce reduction programs are made and posted in Major Employer Events .
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

If a decision has not yet been posted in Major Employer Events , the officer completes the email template and sends it to the regional workforce reduction coordinator for the region where the employer’s head office is located.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596) 
       [regional workforce reduction coordinator](https://esdc.prv/en/service-canada/ei/contacts/workforce_reduction_coor.shtml)

Workers who agree to leaving their jobs under an approved workforce reduction program to preserve the job of a co-worker are not subject to disqualification for leaving according to EIR 51 , and may receive benefits if they meet the other entitlement conditions of the EIA (e.g. they are available for and actively seeking employment).
       [EIR 51](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html)

A workforce reduction program is defined in EIR 51(2) as a program:
       [EIR 51(2)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html)

- that is initiated by the employer;

- that has as its objective a permanent reduction in the number of employees;

- that offers employees the option to leaving employment voluntarily;

- whose elements are documented by the employer.

Employers planning a workforce reduction program may submit a request to Service Canada for confirmation that their plan meets the requirements of the EI Regulations.

The request should contain information confirming:

- the plan was initiated by the employer;

- the objective is to permanently reduce the workforce;

- the employees covered by the program.

Service Canada cannot provide a blanket decision that applies to all employees, but provides an employer with prior confirmation that an employer’s workforce reduction program meets the conditions of EIR 51 .
       [EIR 51](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html)

Regions usually have procedures in place for documenting approved workforce reduction programs. For information about approved workforce reduction programs, the officer refers to Major Employer Events . Employers are often advised to confirm the existence of a valid workforce reduction program in the Comments block of the ROE. If there is no documentation confirming the workforce reduction program as valid, or if the employer has not documented the ROE to that effect, the officer must fact-find with the employer.
       [Major Employer Events](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68?tenantId=9ed55846-8a81-4246-acd8-b1a01abfc0d1&hint=c930eca9-0fba-4aa4-9f84-c2395387ccd3&sourcetime=1744045362596)

**ROE**

An ROE is not required to adjudicate voluntary leaving.

In NWS, there may be a New ROE message displayed on the ADJ WI for the voluntary leaving issue. The message indicates that a new ROE has been received with a RFS that must be reviewed. The ROE may match the period of employment for that or another outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4924.dita) 

### Automated adjudication

Source topic: `en_EN/task/vl_wr_ic/automated_adjudication.dita`

ACP does not automate a decision for voluntary leaving due to workforce reduction.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3239.dita) 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/vl_wr_ic/determining_if_the_file_must_be_referre_f4ff817e.dita`

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Levels of decision

Source topic: `en_EN/task/vl_wr_ic/levels_of_decision.dita`

When the reason for the voluntary leaving is according to an approved workforce reduction program under EIR 51 ( National Policy on Levels of Decision ), Level 1 officers may adjudicate and allow benefits.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

When the Level 1 cannot adjudicate the issue, the facts are documented and the voluntary leaving is referred to Level 2 for adjudication. 

### Claim action status and processing the claim

Source topic: `en_EN/task/vl_wr_ic/claim_action_status_and_processing_the_claim.dita`

During processing, an initial claim will display one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can process the claim. There is a Resolve Issue tab for ADJ Voluntary leaving WIs which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a ROD based on the Resolve Issue screens. Before the claim is calculated, the system updates the ROE based on the Resolve Issue screens. No letter is sent when the client is allowed to voluntarily leave an employment due to an approved workforce reduction program.

**Previously adjudicated voluntary leaving**

In some cases, the ADJ WI may be for a voluntary leaving issue that was previously adjudicated. The officer indicates on the Resolve Issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the appropriate special condition based on the previous decision. The system updates the ROE when the ADJ WI is completed. 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/vl_wr_ic/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the voluntary leaving is not required if the employment is not insurable either because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, the ADJ WI must not be completed. The officer follows the procedures and conditions for removal of claims from ACP process . The officer moves the ADJ WI to Pending until the Claim Assessment (CA) or Specialized Application (SA) WI is created. An authorized user must then delete the ADJ WI.
       [procedures and conditions for removal of claims from ACP process](https://esdc.prv/en/service-canada/ei/technologies/acp/index.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4925.dita) 

### Reason for separation (RFS) — Temporary Budget measures

Source topic: `en_EN/task/vl_wr_ic/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**Adjudicating the last employment in the qualifying period (QP) — BPCs between w/c 2310 and w/c 2361**

Budget 2021 has introduced a temporary simplification measure starting September 26, 2021. For claims with a BPC between w/c 2310 and w/c 2361, the officer will only adjudicate the last period of employment in the QP if it is contentious. If the officer allows the last RFS, all other ROEs in the QP, even if they are contentious, are used to calculate the claim. If, however, the officer does not allow the RFS on the last ROE in the QP, the claim is calculated with a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 

This new measure does not apply to fishing claims and claims for self-employed people. Instead, if clients have insurable employment in the QP with a contentious RFS and a BPC between w/c 2310 and w/c 2361 when they apply for self-employment (SE) or fishing benefits, the officer must adjudicate the contentious RFS following normal adjudication.

When the client declares other employers with a contentious RFS on the same application, if ACP does not allow the issue under auto-adjudication rules, the issue is automatically resolved and ACP creates a record of decision (ROD) that shows Adjudication not Required . The Special condition field on the ROE is not updated, and the ROE is included in the calculation. An Adjudication Issue (ADJ) WI is not created for the RFS.

ACP does not always automatically create an ADJ WI when the application is received. However, if an ROE with a contentious RFS is received during the automation process, ACP may create an ADJ WI or ROE Issue (ROE) RFS Action WI.

When there is more than one ROE with the same last day paid (LDP), and one of the ROEs is contentious while the other ROE is not, adjudication is not required and both ROEs are included in the calculation.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4932.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4933.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4934.dita) 

### Adjudication not required: Reason for separation (RFS) beyond 12 weeks — BPCs between w/c 2258 and w/c 2309

Source topic: `en_EN/task/vl_wr_ic/adjudication_not_required_reason_for_se_2ca905dc.dita`

Adjudication principles on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309 only apply to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the I of E used to establish the claim.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3263.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4931.dita`

Note:

If the voluntary leaving adjudication is part of a recalculation, the officer must refer to Adjudicating voluntary leaving (Level 1): Workforce reduction — Continuing claim .
       [Adjudicating voluntary leaving (Level 1): Workforce reduction — Continuing claim](/en/procedure/task/vl_wr_rc.shtml)

     [Adjudicating voluntary leaving (Level 1): Workforce reduction — Continuing claim](/en/procedure/task/vl_wr_rc.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0164.dita`

Note:

For claims with BPCs between w/c 2310 and w/c 2361 excluded ROEs only apply to SE benefits and fishing claims. 

### Note

Source topic: `en_EN/common_notes/note_c_4924.dita`

Note:

The client may report voluntary leaving on the EI application but the ROE indicates a non-contentious RFS. In this situation, fact-finding is required. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the WI is completed indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_3239.dita`

Note:

If a claim is between w/c 2310 and w/c 2361 and all ROEs are on file, ACP may automatically resolve ADJ RFS WIs for periods of employment other than the last. 

### Note

Source topic: `en_EN/common_notes/note_c_4925.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Example 1

Source topic: `en_EN/common_notes/note_c_4932.dita`

Example 1:

Peter’s LDP was September 28, 2021 (w/c 2310) with 2 employers. Three periods of employment are provided on his EI application. Peter declared Employer 1 as his last employer and the RFS is shortage of work. In the Other Employers section of the application, Peter declared Employer 2 and the RFS is voluntary leaving. He also declared Employer 3 and the RFS is dismissal. The interruption of earnings (I of E) is in w/c 2310, and he applied for benefits on September 29, 2021. His BPC is September 26, 2021 (w/c 2310).

There are 2 contentious ROEs on Peter’s file:

Employer 1: The LDP is September 28, 2021 (w/c 2309). The RFS is A .

Employer 2: The LDP is September 28, 2021 (w/c 2309). The RFS is E .

Employer 3: The LDP is May 19, 2021 (w/c 2291). The RFS is M .

Employer 1 and Employer 2 have the same LDP. The RFS with Employer 1 is non-contentious, so adjudication is not required for Employer 2. ACP automatically resolves the RFS for Employer 2 and creates a ROD that shows Adjudication not required .

The RFS with Employer 3 is contentious and is in the QP. However, because it is not the last employer in the QP, adjudication is not required. ACP creates a ROD that shows Adjudication not required .

All ROEs are included in the calculation of the claim. 

### Info

Source topic: `en_EN/common_notes/note_c_4933.dita`

Example 2:

Abdul’s LDP was September 24, 2021 (w/c 2309) with both of his employers. He declared Employer 1 as his last employer and the RFS is voluntary leaving. In the Other Employers section of the application, Abdul declared Employer 2 and the RFS is dismissal. The I of E is in w/c 2309, and he applied for benefits on September 26, 2021. His BPC is September 26, 2021 (w/c 2310).

There are 2 contentious ROEs on Abdul’s file:

- Employer 1: The LDP is September 24, 2021 (w/c 2309). The RFS is E .

- Employer 2: The LDP is September 24, 2021 (w/c 2309). The RFS is M .

Employer 1 and 2 have the same LDP and RFS with both employers are contentious. ACP creates an ADJ WI for Employer 1, automatically resolves the RFS issue for Employer 2 and creates a ROD that shows Adjudication not required . If the voluntary leaving of Employer 1 is not allowed, the RFS for Employer 2 must be adjudicated. 

### Note

Source topic: `en_EN/common_notes/note_c_4934.dita`

Note:

ACP does not always automatically create an ADJ WI when the application is received. However, if an ROE with a contentious RFS is received during the automation process, ACP may create an ADJ WI or ROE RFS Action WI. 

### Example

Source topic: `en_EN/common_notes/note_c_3263.dita`

Example:

Mary’s LDP was September 25, 2020 (w/c 2257). Her I of E is in w/c 2257, she submitted her EI application on September 26, 2020, and her BPC will be September 27, 2020 (w/c 2258).

There are 3 contentious ROEs on Mary’s file:

ROE 1: LDP September 25, 2020 (w/c 2257).

ROE 2: LDP July 17, 2020 (w/c 2247).

ROE 3: LDP May 31, 2020 (w/c 2241).

To determine which RFS to adjudicate, the officer subtracts 12 weeks from w/c 2257 (week of the I of E). For the example above, the formula is as follows: w/c 2257 (I of E) – 12 = w/c 2245. This determines a 12-week period falling before the Sunday of the I of E that encompasses the weeks from w/c 2245 to w/c 2256. The officer follows normal procedures and adjudicates ROE 1, which is the most recent ROE in the QP, and ROE 2, as it falls between w/c 2245 and w/c 2256, the 12-week period.

The officer allows any contentious RFS that occurs before the 12-week period. ROE 3 is before the 12-week period, so the officer allows the RFS by following the steps of Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
       [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#beyond_12_wks)

     [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#beyond_12_wks) 

## Regional considerations

Source topic: `en_EN/task/vl_wr_ic/regional_considerations.dita`

Atlantic and Western Canada and Territories regions — For events before May 14, 2018, information on approved workforce reduction programs can be found in the following databases:

- Atlantic region: Documents are stored in the regional common document share under EI Document Library / Employer Info / WorkForceReduction

- Western Canada and Territories region: WT regional site
         [WT regional site](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/wfr.shtml)

Business Expertise Advisors can access the list of regional coordinators by referring to Regional Workforce Reduction Coordinators .
       [Regional Workforce Reduction Coordinators](https://esdc.prv/en/service-canada/ei/contacts/index.shtml) 

## What you need to look for

Source topic: `en_EN/task/vl_wr_ic/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/vl_wr_ic/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a prior application?

- What is the client’s statement in the Voluntary Leave section of this or a prior application?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the voluntary leaving on this or a prior application?

- Is the appropriate ROE linked to the period of employment for the voluntary leaving issue? 

### Major Employer Events:

Source topic: `en_EN/task/vl_wr_ic/major_employer_events.dita`

- Is there any information relating to the workforce reduction program? 

### In Imaging:

Source topic: `en_EN/task/vl_wr_ic/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving on this or a prior application? (Documents may have been received before the date of the most recent application.) 

### In RCM:

Source topic: `en_EN/task/vl_wr_ic/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving? 

## Step by step

Source topic: `en_EN/task/vl_wr_ic/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/vl_wr_ic/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/vl_wr_ic/reviewing_the_file_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI determine if the appropriate ROE is linked to the period of employment:

- If yes, go to step 2.

- If no, select the appropriate ROE in the list and select Save to create a link. Go to step 2.

- If the ROE is not on file, go to step 2.

- Determine if there is a ROD for the voluntary leaving issue on file:

- If there is no ROD for the voluntary leaving issue, go to step 3.

- If there is a ROD for the voluntary leaving issue, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#ALR)

- Determine if the facts on file clearly indicate the RFS occurred before the QP:

- If no, go to step 4.

- If yes, go to Reason for separation (RFS) occurred before the qualifying period (QP) .
               [Reason for separation (RFS) occurred before the qualifying period (QP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#RFSB4QP)

- In FTS, determine if the BPC falls in a period where special measures apply:

- If the BPC is between w/c 2258 and w/c 2309, go to step 5.

- If the BPC is between w/c 2310 and w/c 2360, go to step 7.

- If the BPC is not in either of the periods, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita)

- Determine if the voluntary leaving occurred on the most recent ROE:

- If no, go to step 6.

- If yes, go to step 9.

- Determine if the voluntary leaving occurred within the 12-week period before the I of E:

- If yes, go to step 9.

- If no, go to Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
               [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#beyond_12_wks)

- Determine if the claim is for SE benefits or Fishing:

- If no, go to step 8.

- If yes, go to step 9.

- Determine if the voluntary leaving occurred on the most recent ROE:

- If yes, go to step 9.

- If no, go to Adjudication not required – Budget 2021 EI Simplification Measures .
               [Adjudication not required – Budget 2021 EI Simplification Measures](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#adj_not_required)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 10.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred, by consulting Deferring adjudication .

- Determine if the employment is not insurable either because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 12.

- If the facts on file clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Review Major Employer Events to determine if the employer has an approved workforce reduction program:

- If no, go to step 13.

- If yes, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#RFSallowed) 

#### Fact-finding

Source topic: `en_EN/task/vl_wr_ic/fact-finding_level_1.dita`

- Fact-find with the employer to determine the client’s RFS.

- Determine if the employer was reached during fact-finding:

- If the employer was reached , go to step 15.

- If the employer was not reached or did not reply to the Z-00-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#reassignl2)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Voluntary leaving — [employer’s name] — [LDW] — employer.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/vl_wr_ic/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the RFS is contentious:

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS) .
               [Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#RFSVL)

- If the RFS is voluntary leaving, go to step 17.

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if the employer indicates that the client left under an approved workforce reduction program:

- If yes, go to step 18.

- If no and the RFS indicated by the employer can be resolved at Level 1, go to the appropriate procedure to adjudicate the voluntary leaving .
               [voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml)

- If no and the RFS indicated by the employer cannot be resolved at Level 1, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#reassignl2)

- Contact a Business Expertise Advisor to determine if the workforce reduction program has been approved and not yet entered in Major Employer Events .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4935.dita)

- In NWS move the WI for the voluntary leaving to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting Business Expertise Advisor’s answer.”

- Bring forward date: Enter the date the request is sent + 10 business days.

- When an answer is received from the Business Expertise Advisor or when the WI moves to the current workload, determine if there is an approved workforce reduction program in Major Employer Events :

- If there is an approved workforce reduction program in the MEE — Information Bulletin, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#RFSallowed)

- If there is no approved workforce reduction program in the MEE — Information Bulletin, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_wr_ic#reassignl2) 

#### Adjudication not required – Budget 2021 Simplification measures

Source topic: `en_EN/task/vl_wr_ic/adjudication_not_required__budget_2021__620824ac_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Resolve issue: Select Adjudication not required – Budget 2021 EI Simplification Measures .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/vl_wr_ic/decision_already_on_file_level_1.dita`

- Determine if the appropriate decision is listed:

- If yes, on the list, select the appropriate ROD and select Save . Go to step 4.

- If no, select Decision not in the list .

- Select Continue .

- Select the appropriate Special condition option based on the decision on file and select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/vl_wr_ic/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [LDW] —adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed people). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Determine the Claim action status:

- If the status is Initial — In Progress (Automation) , go to step 3.

- If the status is Initial — In Progress (Manual) , go to step 6.

- In NWS, create a Reminder WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “ACP.”

- Due date: Enter today’s date.

- Language: Select the appropriate option.

- Details: Type “2” and “Processing — [unallocated or user name to whom the CA or SA WI is to be assigned].”

- Destination: Select Level and Canada .

- End User: Select Specific user . Type “SV-ADMIN, ACP-TAD” and select Find User .

- Select Save .

- Move the ADJ WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting removal of the claim from automation process. Employment not insurable. This WI must be deleted once CA or SA WI is created.”

- Bring forward date: Enter today’s date + 2 working days.

- Select OK .

- When the ADJ WI moves to the current workload, confirm that the Claim action status is Initial — In Progress (Manual) and a CA or SA WI was created.

- Contact an authorized user (team leader or Business Expertise Advisor) to delete the ADJ WI. 

#### Adjudication not required — Reason for separation (RFS) beyond 12 weeks

Source topic: `en_EN/task/vl_wr_ic/adjudication_not_required__reason_for_s_d81cc200_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [LDW] — adjudication not required.”

- Details: Type “Post-Employment Insurance Emergency Response Benefit transitional measure — reason for separation beyond 12 weeks. EIA 153.194.”

- Select Save .

- On the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Is the decision for this issue already on file?: Select Yes .

- Select Decision not in the list .

- Special Condition: Select Voluntary Leaving - Just cause shown .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/vl_wr_ic/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Client quit [his/her] job and [provide a brief reason for the referral (e.g.no approved workforce reduction information is available)] — unable to complete at Level 1.”

- Select OK .

- When the Warning window is displayed, select Ok . 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/vl_wr_ic/non-contentious_reason_for_separation_rfs_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The reason for separation is not voluntary leaving .

- Select Continue .

- Complete the Not voluntary leaving screen as follows:

- Select the appropriate RFS.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reason for separation (RFS) occurred before the qualifying period (QP)

Source topic: `en_EN/task/vl_wr_ic/reason_for_separation_rfs_occurred_befo_370bd688_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The period of employment falls prior to the qualifying period .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/vl_wr_ic/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Select Due to an approved workforce reduction program .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_4935.dita`

Note:

If the employer is from the West and Territories region, contact the Liaison Enquiry Team instead of the Business Expertise Advisor. Refer to W-T Region Workforce Reduction Procedures .
       [W-T Region Workforce Reduction Procedures](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/wfr.shtml)

     [W-T Region Workforce Reduction Procedures](https://esdc.prv/en/service-canada/western-territories/bds/ins-proc/wfr.shtml) 

## Policy reference

Source topic: `en_EN/task/vl_wr_ic/policy_reference.dita`

- Digest 6.7.0 — Workforce Reduction
         [Digest 6.7.0 — Workforce Reduction](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/workforce-reduction.html#a6_7_0)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- EIR 51
         [EIR 51](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html) 
