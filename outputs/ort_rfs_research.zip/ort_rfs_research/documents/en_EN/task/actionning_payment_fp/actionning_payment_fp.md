# Reviewing the file for benefits paid or payable from another source — Renewal and continuing claims

Source map: `en_EN/task/actionning_payment_fp/actionning_payment_fp.ditamap`

## Summary

Source topic: `en_EN/task/actionning_payment_fp/summary.dita`

Summary: When a client applies for EI benefits, the officer determines if the client is receiving or is entitled to receive benefits from another source. 

## What you need to know

Source topic: `en_EN/task/actionning_payment_fp/what_you_need_to_know.dita`

### Benefits from another source

Source topic: `en_EN/task/actionning_payment_fp/benefits_from_another_source.dita`

Clients must apply for benefits from other sources that might otherwise be paid by EI. These sources, which are often referred to as the first payer, include the following:

- paid sick leave (PSL)

- group wage loss insurance (WLI)

- preventive withdrawal payments

- motor vehicle accident insurance

Clients may also apply for benefits from other sources that are not considered to be a first payer. These include the following:

- workers’ compensation benefits (WCB)

- Wage Earner Protection Program (WEPP)

When the client receives payments from another source, the officer refers to Earnings: Determination, allocation and references — Table to determine if the monies are earnings. If the payments are considered earnings, the officer allocates the monies to the period for which they are paid.
       [Earnings: Determination, allocation and references — Table](/en/procedure/generic/additionalresources/eiortjobaid_earn_chart.shtml)

When clients report they are capable of working, but information on file indicates benefits from another source to compensate for loss of income due to an illness or injury are or may be payable, the officer may have to review the clients’ availability to be looking for work. 

### Obligations of employers enrolled in the Premium Reduction Program (PRP)

Source topic: `en_EN/task/actionning_payment_fp/obligations_of_employers_enrolled_in_th_5dffdb3d.dita`

When a client stops working for an employer due to illness, injury or quarantine, the officer must verify FTS and determine if the employer is enrolled in the EI PRP. Employers enrolled in the PRP have been granted a reduction of their EI premiums payable because they have demonstrated that they provide their employees a specific amount of PSL or WLI benefits that meets the standards of the PRP. The details of the specific benefits provided by the employer are available in FTS. Many employers have multiple business numbers. Whenever possible, it is important to search for the employer using the business number indicated on the ROE, as not all business numbers have the same entitlement to employee benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1615.dita) 

If the client is not entitled to the benefits as shown in the details of the plan, the officer fact-finds with the employer to determine why the client is not entitled to the benefits. 

### Client obligations

Source topic: `en_EN/task/actionning_payment_fp/client_obligations.dita`

The officer ensures that clients are aware of their obligation to apply for benefits from a first payer, and to notify Service Canada once a decision is rendered.

When a client who is entitled to benefits from a first payer chooses not to apply for those benefits, the benefits to which the client could have been entitled are considered to have been paid for the period for which the monies could have been paid or payable had the client applied to receive them. In this situation, the officer allocates the monies at an amount that is equal to the no benefits payable amount. The same principle applies when the client has applied for benefits but the amount is not yet known and the client does not want to receive EI benefits while waiting for a decision. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/actionning_payment_fp/determining_if_the_file_must_be_referre_f4ff817e.dita`

If an employer does not meet the obligation as the first payer, the officer refers the case to Integrity before making a decision.
       [Integrity](/en/procedure/activity/referal_integrity.shtml) 

### Paid sick leave (PSL)

Source topic: `en_EN/task/actionning_payment_fp/paid_sick_leave_psl.dita`

An employer may provide a period of PSL to an employee who is unable to work due to illness, injury or quarantine. An employee’s entitlement to PSL may be based on a predetermined amount of paid sick time allowed by the employer each year, or it may be based on a formula related to an employee’s years of service. The employer can even advance future sick leave entitlements to an employee who does not have enough entitlement to cover the entire period of leave. PSL is considered benefits that might otherwise be paid by EI.

Clients who are entitled to PSL and who stop working due to illness or injury must exhaust their sick leave credits before they are eligible to receive EI sickness benefits. If a client is entitled to PSL and does not apply to use it, the sick leave entitlement is still deemed earnings and is allocated to the period for which the entitlement would have been paid or payable if the client had requested the paid leave from the employer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1616.dita) 

### Group wage loss insurance (WLI) plans

Source topic: `en_EN/task/actionning_payment_fp/group_wage_loss_insurance_wli_plans.dita`

Group WLI plans provide benefits to individuals for loss of income due to an illness or injury.

Group WLI plans are designed to cover a group of workers who work for the same employer. Group WLI provided for loss of income is considered a benefit that might otherwise be paid by EI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1617.dita) 

### Preventive withdrawal payments

Source topic: `en_EN/task/actionning_payment_fp/preventive_withdrawal_payments.dita`

Preventive withdrawal payments may be paid to an employee who stops working because the working conditions present physical danger to the employee’s health, danger to an unborn child or to a child the employee is breast-feeding. Preventive withdrawal payments are paid under provincial legislation and are currently only available in the province of Quebec.

Preventive withdrawal payments provided for loss of income are considered a benefit that might otherwise be paid by EI. If the client is entitled to these benefits under provincial law, the benefits are still considered earnings, even if the client chooses not to apply for them.

Preventive withdrawal payments are allocated to the weeks for which those payments are paid or payable, or for which they would have been paid or payable for if the client had applied. 

### Motor vehicle accident insurance

Source topic: `en_EN/task/actionning_payment_fp/motor_vehicle_accident_insurance.dita`

Motor vehicle accident insurance provides benefits to insured individuals due to a vehicle accident. Motor vehicle accident insurance provided for the loss of income is considered a benefit that might otherwise be paid by EI. 

### Workers’ compensation benefits (WCB)

Source topic: `en_EN/task/actionning_payment_fp/workers_compensation_benefits_wcb.dita`

WCB are provided to workers as a result of a workplace-related illness or injury. Clients wishing to receive WCB must apply for that benefit. Although WCB that are provided for loss of income are considered earnings, it is not mandatory for clients to apply for these benefits as they are not considered benefits that might otherwise be paid by EI. 

### Wage Earner Protection Program (WEPP)

Source topic: `en_EN/task/actionning_payment_fp/wage_earner_protection_program_wepp.dita`

WEPP provides workers with guaranteed payment of wages owed when their employer declares bankruptcy or becomes subject to a receivership. It is not mandatory for clients to apply for WEPP and WEPP is not considered a benefit that might otherwise be paid by EI. Clients who want to receive compensation from WEPP must apply for WEPP. Monies paid by WEPP to compensate for unpaid wages, earned unpaid vacation pay, severance and termination pay are earnings.

WEPP monies paid for unpaid earned vacation pay, severance and termination pay are paid as a result of the separation from employment and are allocated from the date of bankruptcy, based on the client’s normal weekly earnings (NWE). Monies paid to compensate expenses for travelling salespeople are not earnings and are not allocated.

None of the monies paid by WEPP are insurable. However, unpaid wages due to bankruptcy are insurable and should already be included on the ROE. When a client reports receiving a WEPP payment that includes unpaid wages, the officer determines if the unpaid wages are included on the original ROE. 

### Waiting for a decision on benefits from another source

Source topic: `en_EN/task/actionning_payment_fp/waiting_for_a_decision_on_benefits_from_006f49ce.dita`

When an application for benefits from another source is pending or there is a dispute regarding the entitlement, the client can be paid EI benefits while waiting for a decision.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1618.dita) 

### Communicating the decision

Source topic: `en_EN/task/actionning_payment_fp/communicating_the_decision.dita`

When clients declare they applied for benefits from other sources that might otherwise be payable by EI, the N-00-00-00 letter is sent to clients. 

### Note

Source topic: `en_EN/common_notes/note_c_1615.dita`

Note:

When an employer has PRP information on file, there may be a date indicated in the Last update filed field. This date can be for any change made in the employer record and must not be used as an effective date of the PRP. 

### Note

Source topic: `en_EN/common_notes/note_c_1616.dita`

Note:

Clients who have received PSL from their employer after their last day worked (LDW) may be entitled to have their waiting period (WP) waived. 

### Note

Source topic: `en_EN/common_notes/note_c_1617.dita`

Note:

A WLI plan that is not a group plan has the following characteristics:

- It is not considered a benefit that might otherwise be paid by EI.

- It is not earnings.

- It cannot be related to a group of persons who are all employed by the same employer.

- It is not financed in whole or in part by the employer.

- It is voluntarily purchased by the insured person.

- It is completely portable, in that the rate of premium and the protection provided remain the equivalent, should the client become employed by any other employer within the same occupation.

- It provides constant benefits, that is, there is no provision calling for automatic benefits increments in accordance with a pre-arranged benefit schedule based on current earnings.

- Its premium rates are not dependent on the experience of the employer’s group of workers. 

### Note

Source topic: `en_EN/common_notes/note_c_1618.dita`

Note:

It is not necessary to obtain a signed statement from clients specifying that they will reimburse the EI benefits received if the benefits from the other source are approved and determined to be earnings. 

## Regional considerations

Source topic: `en_EN/task/actionning_payment_fp/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actionning_payment_fp/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/actionning_payment_fp/in_nws.dita`

- Does information on file indicate that PSL is not exhausted?

- Is there any documentation on file indicating that the client has applied for, or is entitled to benefits from another source?

- If yes, is the type of benefits indicated and is the weekly amount available? 

### In RCM:

Source topic: `en_EN/task/actionning_payment_fp/in_rcm.dita`

- If the last ROE is on file, does it indicate PSL or WLI is paid or payable?

- If the last ROE is on file, is possible WLI entitlement indicated in the Comments field?

- If the last ROE is on file, what is the business number of the last employer? 

### In Imaging:

Source topic: `en_EN/task/actionning_payment_fp/in_imaging.dita`

- Is there information regarding monies from another source? 

### In FTS:

Source topic: `en_EN/task/actionning_payment_fp/in_fts.dita`

- Does the Employer Details — Premium Reduction Program screen show registered WLI information?

- If yes, is there possible PSL? Are there weeks of WLI? Does the status indicate that the employer has a reduction of EI premiums? 

## Step by step

Source topic: `en_EN/task/actionning_payment_fp/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/actionning_payment_fp/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/actionning_payment_fp/reviewing_the_file_level_1.dita`

- Determine what type of WI there is for the benefits from another source issue:

- If there is a Reminder (REM) WI, go to Follow up on the REM WI .
               [Follow up on the REM WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actionning_payment_fp#follow_up_on)

- If there is another type of WI, go to step 2.

- Determine if one of the following conditions is met:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1619.dita) 

- If one of the conditions is met, go to step 3.

- If none of the conditions are met, return to the previous task.

- Determine if additional information is required to clarify entitlement or receipt of benefits from another source:

- If yes, go to step 4.

- If no, go to step 8.

- Fact-find with the client or the employer to obtain the following information and advise the client of any necessary information:

- Is there entitlement to benefits from another source?

- Have benefits from another source been received?

- What are the details of any benefits from another source that the client could be entitled to receive?

- Is there a pending application?

- Have the benefits been exhausted?

- If benefits from a first payer could be payable and an application to benefits from another source has not been submitted, ensure that the client is aware of the obligation to apply for those benefits and to inform Service Canada of any decision that is received.

- If the client has applied or will apply for benefits from another source, does the client want to receive EI benefits while waiting for a decision?

- If the RFS is illness, the employer’s status indicates a reduction in premiums, and PSL or WLI information on the ROE does not correspond to the information on the Employer Details — Premium Reduction Program screen, why did the client not receive PSL or WLI as indicated on the Employer Details screen in FTS and what are the details of the benefits that could be received?

- If the client received PSL or WLI after the LDW, what are the details of the benefits received and were the benefits paid included in the calculation of the insurable hours and earnings on the ROE?

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 6.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Missing information .
               [Missing information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actionning_payment_fp#missing_information)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Earnings .

- Comments: Type “[type of benefits from another source].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if all of the required information was obtained during fact-finding:

- If yes, go to step 8.

- If no, go to Missing information .
               [Missing information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actionning_payment_fp#missing_information)

- Determine if the client received benefits from another source:

- If no, go to step 9.

- If yes, determine if the client received the full entitlement to the benefits from another source:

- If no, go to step 9.

- If yes, refer to Determining if monies are earnings for next steps.
                   [Determining if monies are earnings](/en/procedure/task/deter_monies_earnings.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1620.dita)

- Determine if the client could be entitled to receive benefits from another source:

- If yes, go to step 10.

- If no, return to the previous task.

- Determine if the client has applied or will apply for benefits from another source:

- If no, go to step 11.

- If yes, go to step 12.

- Determine if the information on file indicates one of the following situations applies:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1621.dita) 

- If yes, refer to Referral to Integrity and go to step 12.
               [Referral to Integrity](/en/procedure/activity/referal_integrity.shtml)

- If no, go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1622.dita)

- Determine if the information on file indicates that the client has not applied and will not be applying for preventative withdrawal or motor vehicle accident insurance benefits that the client could be entitled to receive:

- If no, go to step 13 .

- If yes, go to step 14.

- Determine if the client is requesting EI benefits while waiting for a decision on the benefits from another source:

- If no, go to step 14.

- If yes, go to step 15.

- To prevent payment of benefits, allocate the benefits from another source. Consider the amount of the potential benefits from another source to be equal to the no benefits payable amount. This is the amount to allocate. Refer to the appropriate allocation task in the Earnings activity and return to the previous task.

- In NWS, create a REM WI to follow up on the decision of the benefits from another source as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “[type of benefits from another source].”

- Due date: Select the current date + 90 business days.

- Language: Select the appropriate option.

- Details: Type “Decision pending on [type of benefits] from [source], follow up is required. Review the file for benefits paid or payable from another source and allocate if necessary.”

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Select Save .

- Determine if the claim is a renewal or a continuing claim:

- If it is a continuing claim, go to Client requesting EI benefits — Continuing claim .
               [Client requesting EI benefits — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actionning_payment_fp#continuingclaim)

- If it is a renewal claim, go to Client requesting EI benefits — Renewal claim .
               [Client requesting EI benefits — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actionning_payment_fp#renewalclaim) 

#### Client requesting EI benefits — Continuing claim

Source topic: `en_EN/task/actionning_payment_fp/client_requesting_ei_benefits__continuing_claim_level_1.dita`

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Also applied for other disability benefits - Client must repay EI (3062)

- In FTS, determine if a 1 - General suspension of benefits (stop payment) manual action (MA1) is imposed and if there is a registration number for the benefits from another source issue:

- If an MA1 is imposed but there is no registration number, go to step 3.

- If an MA1 is imposed and there is a registration number, go to step 4.

- If an MA1 is not imposed but there is a registration number, go to step 5.

- If none of the above applies, go to step 6.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and rescind the MA01 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 6.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Registration number: Select the appropriate registration number.

- Claim allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, determine if there is a WI for the benefits from another source issue:

- If yes, complete the WI.

- If no, no further action is required. Return to the previous task. 

#### Client requesting EI benefits — Renewal claim

Source topic: `en_EN/task/actionning_payment_fp/client_requesting_ei_benefits__renewal_claim_level_1.dita`

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Also applied for other disability benefits - Client must repay EI (3062)

- In NWS, create a client Note and type “Send the saved N-00-00-00 letter.”

- In NWS, determine if there is a WI for the benefits from another source issue:

- If yes, complete the WI.

- If no, no further action is required. Return to the previous task. 

#### File returned from Integrity

Source topic: `en_EN/task/actionning_payment_fp/file_returned_from_integrity_level_1.dita`

- Determine if Integrity established that benefits from another source are payable to the client:

- If benefits from another source are not payable to the client, go to step 6.

- If benefits from another source are payable to the client, go to step 2.

- Determine if the information on file indicates that the employer has deliberately prevented the client from receiving all of the PSL entitlement or applying for WLI:

- If the information on file indicates the employer prevented the client from receiving all of the PSL entitlement or applying for WLI, go to step 3.

- If the information on file does not indicate the employer prevented the client from receiving all of the PSL entitlement or applying for WLI, go to step 4.

- Advise the PRP of the information as follows:

- Complete the ADM2050 form.
               [ADM2050](https://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-ADM2050A.pdf)

- Obtain a copy of the following documents:

- the ROE, if applicable

- the Integrity investigation report

- the notice of decision sent to the client

- Mail the ADM2050 and documents to the following address: Premium Reduction Program 120 Harbourview Boulevard PO Box 11,000 Bathurst, NB  E2A 4T5

- Determine if Integrity obtained the amount of benefits payable from another source:

- If yes, go to step 5.

- If no, allocate the benefits from another source that the client is entitled to receive. If benefits from another source have not been paid, use an amount of earnings that equals the no benefits payable amount. This prevent the payment of benefits. Refer to the appropriate allocation task in the Earnings activity for next steps.
               [Earnings](/en/procedure/activity/earnings.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1623.dita)

- Refer to the appropriate allocation task in the Earnings activity for next steps.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1624.dita)

- Determine if earnings for the benefits payable from another source that the client is not entitled to receive were included on an ROE used to calculate a claim:

- If yes, go to step 7.

- If no, go to step 11.

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 9.

- If no, go to step 10.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC : Enter the SCC as shown in FTS. If the field is blank, enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC : This field is prefilled.

- Select Generate registration .

- Go to step 14.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1570.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1625.dita)

- Determine if an estimated allocation amount has been input:

- If yes, go to step 12.

- If no, go to step 14.

- In FTS, determine if there is an outstanding registration number for the benefits from another source issue:

- If yes, go to step 13.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Select Update .

- Select the Allocations link on the Summary tab and remove the allocation as follows:

- Select the appropriate allocation and select Modify .

- Registration number: Select the appropriate registration number.

- Action: Select Rescind .

- Detection: Select the code used on the initial input.

- Infraction: Select the code used on the initial input.

- Message: Select the code used on the initial input.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the CR Integrity WI. 

#### Missing information

Source topic: `en_EN/task/actionning_payment_fp/missing_information_level_1.dita`

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “Unable to obtain information about benefits from another source.”

- Details: Type “The client [employer] has not provided sufficient information regarding the [type of monies from another source] to determine entitlement to benefits. A 15 - Claim Procedure disentitlement is imposed to prevent payment of benefits.

- Select Save .

- In FTS, determine if there is an outstanding registration number for the monies from another source issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if an MA1 is imposed for the monies from another source issue:

- If yes, go to step 4.

- If no, go to step 5.

- Select the Renewal/Revised (M106) transaction, remove the MA01 and input a D15 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 15 - Claim Procedure .

- Start: Enter the Monday of the next week to be processed.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 6.

- Select the Disqualifications/Disentitlements (M161) transaction and input a D15 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 15 - Claim Procedure .

- Start date: Enter the Monday of the next week to be processed.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- D48 and D15 — Moved — Address unknown and claim procedure (3006)

- D15 - Claim procedure: Select the appropriate option:

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- Type of Weekly Indemnity Earnings (2532)

- In NWS, determine if there is a WI for the monies from another source issue:

- If yes, complete the WI.

- If no, no further action is required. Return to the previous task. 

#### Follow up on the Reminder (REM) WI

Source topic: `en_EN/task/actionning_payment_fp/follow_up_on_the_reminder_rem_wi_level_1.dita`

- Determine if information on file indicates that a decision has been made on the client’s entitlement to the benefits from another source:

- If no, go to step 2.

- If yes, go to step 6.

- Fact-find with the client or employer.

- Determine if client or employer was contacted during fact-finding:

- If yes, go to step 4.

- If no, go to step 15.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Earnings .

- Comments: Type “[type of type of benefits from another source].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if a decision has been made on the entitlement to benefits from another source:

- If yes, go to step 6.

- If no, move the REM WI to Pending as follows:

- Pending reason : Select Other .

- Comments : Type “Waiting for a decision on entitlement to benefits from another source.”

- Bring forward date : Today’s date + 90 business days.

- Determine if the client is entitled to receive the benefits from another source:

- If no, go to step 7.

- If yes, refer to Determining if monies are earnings for next steps.
               [Determining if monies are earnings](/en/procedure/task/deter_monies_earnings.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1626.dita)

- Determine if earnings for the benefits payable from another source, that the client is not entitled to receive, were included on an ROE used to calculate a claim:

- If yes, go to step 8.

- If no, go to step 12.

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type : Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 10.

- If no, go to step 11.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank , enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC : This field is prefilled.

- Select Generate registration .

- Go to step 19.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1570.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1625.dita)

- Determine if an estimated allocation amount has been input.

- If yes, go to step 13.

- If no, go to step 19.

- In FTS, determine if there is an outstanding registration number for the benefits from another source issue:

- If yes, go to step 14.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Select Update .

- Select the Allocations link on the Summary tab and remove the allocation as follows:

- Select the appropriate allocation and select Modify .

- Registration number: Select the appropriate registration number.

- Action: Select Rescind .

- Detection: Select the code used on the initial input.

- Infraction: Select the code used on the initial input.

- Message: Select the code used on the initial input.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 19.

- In NWS, create a ROD as follows:

- Comment: Type the appropriate option:

- “The client did not provide information about benefits from another source.”

- “Unable to obtain information about benefits from another source.”

- Details: Type the appropriate option:

- “The letter was sent on [date]. The client did not reply. A 15 - Claim procedure disentitlement is imposed from the Monday of the next week to be processed because the client did not provide information about benefits from another source. The allocation for earnings from the other source cannot be input.”

- “The [client or employer] did not provide enough information regarding the [type of monies from another source] to determine entitlement to benefits. A 15 - Claim procedure disentitlement is imposed to prevent payment of benefits.”

- Select Save .

- In FTS, determine if there is a registration number on file:

- If yes, go to step 17.

- If no, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Select Update .

- Select the Disqualifications/Disentitlement (M161) transaction to impose the D15 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select - Add .

- Disentitlement: Select 15 - Claim procedure .

- Start date: Enter the Monday of the next week to be processed.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: : Select F - Non-fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS , create and send the D-01-00-01 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976)

- D48 and D15 — Moved — Address unknown and claim procedure (3006)

- D15 - Claim procedure (3009)

- D15 - Text: Insert appropriate reason for D15

- We / In addition, we (2687)

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select Indefinite disentitlement start date (1270)

- Text- Insert appropriate reason(s) (1618): Type “you did not return our call after we left you a message on [Month DD, YYYY]”, “you did not respond to the letter we sent you on [Month DD, YYYY].” or “you did not provide information about other benefits you may be receiving.” as required.

- In NWS, complete the REM WI for the incapacity monies issue. 

#### Callout

Source topic: `en_EN/common_notes/note_c_1619.dita`

- The information on file indicates that there are benefits paid or potentially payable from another source.

- The client reports having applied for benefits from a first payer, but claims not to be entitled to those benefits.

- The last employer has a reduction in premiums, and the reason for separation (RFS) on the ROE is illness, injury or quarantine. 

#### Note

Source topic: `en_EN/common_notes/note_c_1620.dita`

Note:

If the benefits from another source are determined to be earnings, the next steps advise the officer to allocate the earnings or modify an existing earnings allocation. 

#### Callout

Source topic: `en_EN/common_notes/note_c_1621.dita`

- The employer has deliberately prevented the client from receiving all of the PSL entitlement.

- The employer is preventing the client from applying for WLI.

- The client has not applied and will not be applying for preventative withdrawal or motor vehicle accident insurance benefits that the client could be entitled to receive. 

#### Note

Source topic: `en_EN/common_notes/note_c_1622.dita`

Note:

When Integrity completes a review of entitlement to benefits from another source, return to this task and go to File returned from Integrity .
       [File returned from Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#file_returned_from)

     [File returned from Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#file_returned_from) 

#### Note

Source topic: `en_EN/common_notes/note_c_1623.dita`

Note:

If the benefits from another source are determined to be earnings, the next steps advise to allocate the earnings or modify an existing earnings allocation. 

#### Note

Source topic: `en_EN/common_notes/note_c_1624.dita`

Note:

When it is determined that a client is entitled to benefits from another source, the benefits from another source are allocated as earnings to prevent payment of benefits. Consider the amount of the potential monies to be equal to the no benefits payable amount. This is the amount to allocate. 

#### Note

Source topic: `en_EN/common_notes/note_c_1570.dita`

Note:

There cannot be more than 2 outstanding registration numbers. If there are already 2 outstanding registration numbers, advise the team leader that multiple registration numbers are preventing a new one from being created. 

#### Note

Source topic: `en_EN/common_notes/note_c_1625.dita`

Note:

When the message Success — Registration number created is displayed in SSO, a recalculation registration number is assigned to the claim. NWS creates a Claim Review (CR) WI and assigns it to the unassigned (UNA) workload or to the next available user. 

#### Note

Source topic: `en_EN/common_notes/note_c_1626.dita`

Note:

If the benefits from another source are determined to be earnings, the next steps advise the officer to allocate the earnings or modify an existing earnings allocation. If benefits from another source have not been paid, use an amount of earnings that equals the no benefits payable amount. This prevents the payment of benefits. 

## Policy reference

Source topic: `en_EN/task/actionning_payment_fp/policy_reference.dita`

 
