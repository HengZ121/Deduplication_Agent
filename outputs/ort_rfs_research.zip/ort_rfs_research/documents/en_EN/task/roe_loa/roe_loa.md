# Completing an ROE Issue RFS Action WI: N - Leave of absence

Source map: `en_EN/task/roe_loa/roe_loa.ditamap`

## Summary

Source topic: `en_EN/task/roe_loa/summary.dita`

Summary: When an ROE is received with a reason for separation (RFS) N - Leave of absence on an initial Web application, if the system is unable to create a link between the ROE and a matching period of employment or determine if the issue requires adjudication, an ROE Issue (ROE) RFS Action WI is created. 

## What you need to know

Source topic: `en_EN/task/roe_loa/what_you_need_to_know.dita`

### Linking the ROE and the matching period of employment

Source topic: `en_EN/task/roe_loa/linking_the_roe_and_the_matching_period_f71580ff.dita`

When an ROE RFS Action WI is received and a link has not yet been created between the ROE and a period of employment, the Non-complex agent must review the applicable ROE in RCM and the periods of employment listed in NWS. The Non-complex agent determines if one of the periods of employment listed in NWS matches the employer’s name on the ROE.

**Variations in the employer’s name**

Minor spelling differences between the employer’s name on the ROE and the period of employment are accepted. The agent must also consider that the employer may do business under more than one name. For example, the ROE indicates that the employer’s name is 123456 ONT Inc., but the client reported working for ABC Company. If the documentation on file or the Employer search (by business number) in FTS indicates that 123456 ONT Inc. operates as ABC Company, the names are equivalent and considered to be a match.

**Reviewing the dates on the ROE**

Only one ROE can be matched to each period of employment listed in NWS. The agent must review the Search / Correct - Results screen in RCM to determine if the ROE in the ROE RFS Action WI is the one with the last day for which paid (LDP) closest to the last day worked (LDW) for one of the periods of employment. The agent creates a link between the ROE and the period of employment with the matching employer’s name and best match for LDP and LDW. If either the employer’s name does not match or the LDP and LDW are not a good match, the agent does not create a link between the ROE and the period of employment.

**More than one ROE for one period of employment**

There may be more than one ROE but only one period of employment for the same employer.

**Example 1**

- Period of employment information declared on application:
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4686.dita)

- Search / Correct - Results in RCM:

```text
| SN | Employer | FDW / TSD | LDP / TED | Modified | Input | RFS | Audit | EHF |

| W12345678 | ABC Company | 01/07/2015 | 04/12/2015 | 22/12/2015 | 22/12/2015 | N | | |

| W12341234 | ABC Company | 01/01/2015 | 30/04/2015 | 22/12/2015 | 22/12/2015 | D | | |
```

- ROE RFS Action WI #1 for W12345678

- The agent completes the period of employment information section as follows:

- Matching POE: Select ABC Company .

- ROE RFS Action WI #2 for W12341234

- The agent completes the period of employment information section as follows:

- Matching POE: Select POE not in the list .

There may also be more than one period of employment for the same employer.

**Example 2**

- Period of employment information declared on application:
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4687.dita) 
         [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4688.dita)

- Search / Correct - Results in RCM:

```text
| SN | Employer | FDW / TSD | LDP / TED | Modified | Input | RFS | Audit | EHF |

| W12345678 | ABC Company | 01/07/2015 | 04/12/2015 | 22/12/2015 | 22/12/2015 | N | | |

| W12341234 | ABC Company | 01/01/2015 | 30/04/2015 | 22/12/2015 | 22/12/2015 | D | | |
```

- ROE RFS Action WI #1 for W12345678

- The agent completes the period of employment information section as follows:

- Matching POE: Select ABC Company (LDW 30/11/2015).

- ROE RFS Action WI #2 for W12341234

- The agent completes the period of employment information section as follows:

- Matching POE: Select ABC Company (LDW 01/06/2015).

**ROE already linked**

If the ROE is linked to a period of employment with a corresponding electronic record of decision (ROD) or an outstanding Adjudication Issue (ADJ) WI, the ROE RFS Action WI is completed without further action by the Non-complex agent. 

### Completing the Resolve Issue section

Source topic: `en_EN/task/roe_loa/completing_the_resolve_issue_section.dita`

If the ROE is not linked to a period of employment or if the ROE is linked to a period of employment without a corresponding electronic ROD or ADJ WI, the agent must complete the Resolve Issue section of the ROE RFS Action WI before completing the WI. When resolving the issue, the agent must review the ROE and the existing RODs.

**Comments in block 18**

If the ROE was issued with comments in block 18 , the agent must determine if the correct RFS is indicated on the ROE. Any required changes to the RFS details must be made in the Resolve Issue section of the ROE RFS Action WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4683.dita) 

**Reviewing existing records of decision (RODs) on file**

If the RFS is contentious and there is an existing ROD, the agent must determine if the information on the ROE contradicts the decision on file. When a ROD is not found or when the information on the ROE contradicts the ROD, the agent indicates that no decision matches the ROE when completing the Resolve Issue section of the ROE RFS Action WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2675.dita) 

### Callout

Source topic: `en_EN/common_notes/note_c_4686.dita`

- Employer: ABC Company

- First day worked: 01/01/2015

- Last day worked: 04/12/2015

- Reason for separation: Leave of absence 

### Callout

Source topic: `en_EN/common_notes/note_c_4687.dita`

- Employer: ABC Company

- First day worked: 01/08/2015

- Last day worked: 30/11/2015

- Reason for separation: Leave of absence 

### Callout

Source topic: `en_EN/common_notes/note_c_4688.dita`

- Employer: ABC Company

- First day worked: 01/01/2015

- Last day worked: 01/06/2015

- Reason for separation: Leave of absence 

### Note

Source topic: `en_EN/common_notes/note_c_4683.dita`

Note:

If there are comments in block 18 of the last ROE , the system creates an ROE Comments WI. The agent actioning the ROE Comments WI evaluates the comments in block 18 and may move the comments into the Additional information field in RCM. 

### Note

Source topic: `en_EN/common_notes/note_c_2675.dita`

Note:

When an option is selected in the POE Information section of the Resolve Issue tab, the system displays the actions that will be taken once the ROE RFS Action WI is completed. If adjudication of the RFS issue is required, an ADJ WI is automatically reactivated or created. 

## Regional considerations

Source topic: `en_EN/task/roe_loa/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/roe_loa/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/roe_loa/in_nws.dita`

- What is the serial number and the RFS indicated in the Specific Details tab of the ROE RFS Action WI?

- What periods of employment are indicated in the Matching POE list of the ROE RFS Action WI?

- Is there a ROD indicating that the RFS has been adjudicated?

- If yes, what are the details of the decision?

- Is there an SROC clarifying the employer’s name? 

### In RCM:

Source topic: `en_EN/task/roe_loa/in_rcm.dita`

- What ROEs are displayed on the Search / Correct - Results screen?

- What is the employer’s name in block 4 of the ROE?

- What is the last day for which paid in block 11 of the ROE?

- Is there an audit trail for the ROE?

- Does the audit trail contain a new value for the RFS in block 16 ?

- Are there comments in block 18 or the Additional information field of the ROE? 

### In FTS:

Source topic: `en_EN/task/roe_loa/in_fts.dita`

- Does the Employer search indicate that the employer operates under another name? 

## Step by step

Source topic: `en_EN/task/roe_loa/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/roe_loa/non-complex.dita`

#### Linking the ROE and the matching period of employment

Source topic: `en_EN/task/roe_loa/linking_the_roe_and_the_matching_period_f71580ff_non-complex.dita`

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, determine if there is a matching period of employment already selected in the Matching POE list:

- If no , go to step 2.

- If yes, go to step 6.

- Determine if the Matching POE list includes one or more periods of employment with the same employer’s name as the ROE:

- If there are one or more periods of employment with the same employer’s name as the ROE, go to step 3.

- If there is no period of employment with the same employer’s name as the ROE, select POE not in the list . Click Save and go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2685.dita)

- In RCM, review the Search / Correct - Results screen to determine if the ROE in the ROE RFS Action WI is the one with the same employer’s name and the LDP closest to the LDW for one of the periods of employment on the Matching POE list in the ROE RFS Action WI in NWS:

- If the ROE is for the same employer and the LDP on the ROE is the best match to the LDW for one of the periods of employment, go to step 4.

- If the ROE is for the same employer but the LDP on the ROE is not the best match to the LDW for one of the periods of employment, go to step 5.

- If the ROE is not for the same employer or the LDP on the ROE is clearly not a good match to the LDW for one of the periods of employment, go to step 5.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the POE information section as follows:

- Matching POE: Select the period of employment with the same employer’s name and best match for LDP and LDW.

- Click Save .

- Go to step 6.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the POE information section as follows:

- Matching POE: Select POE not in the list .

- Click Save .

- Go to step 6.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, determine if the Resolve Issue section is displayed:

- If the Resolve Issue section is displayed, go step 7.

- If the Resolve Issue section is not displayed, go to step 19. 

#### Ensuring the reason for separation (RFS) details are correct

Source topic: `en_EN/task/roe_loa/ensuring_the_reason_for_separation_rfs__9dc9245b_non-complex.dita`

- In RCM, review block 18 and the Additional information field of the ROE and determine if there are comments related to the RFS:

- If yes, go to step 8.

- If no , go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4684.dita)

- Determine if the ROE requires any of the following changes:

```text
| If the comments on the ROE indicate: | The RFS options in the ROE RFS Action WI must be changed as follows: |

| RFS | RFS sub-option |

| medical leave of absence | D - Illness or injury | not applicable |

| unpaid medical leave | D - Illness or injury | not applicable |

| illness or surgery related comment | D - Illness or injury | not applicable |
```

- If the ROE requires changes, note the changes required and go to step 9.

- If the ROE does not require changes, go to step 11.

           [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4685.dita)

- In NWS, determine if there is a ROD on file for the period of employment indicating that the RFS is  other than illness or injury (e.g. dismissal or suspension, leave of absence, voluntary leaving):

- If no , go to step 10.

- If yes, go to step 11.

- In NWS, on the Resolve Issue tab of theROE RFS Action WI, complete the Resolve Issue section as follows:

- Do the Reason for Separation details need to be modified?: Select Yes and the applicable RFS changes required (as indicated in step 8).

- Go to step 12.

- In NWS, on the Resolve Issue tab of the ROERFS Action WI, complete the Resolve Issue section as follows:

- Do the Reason for Separation details need to be modified?: Select No .

- Go to step 12. 

#### Selecting a special condition for the decision on file

Source topic: `en_EN/task/roe_loa/selecting_a_special_condition_for_the_d_d5caef0c_non-complex.dita`

- Determine which special condition options are displayed:

- If multiple options are displayed, go to step 13.

- If No Decision Matches the ROE is the only option displayed, go to step 17.

- If no special condition options are displayed, go to step 19.

- In NWS, determine if there is a ROD on file for the period of employment:

- If yes, go to step 14.

- If no , go to step 17.

- Review the decision indicated in the ROD:

- If the ROD indicates that adjudication was deferred, go to step 15.

- If the ROD does not indicate that adjudication was deferred, go to step 16.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Select the Special Condition for the decision on file: Select Adjudication Deferred .

- Go to step 19.

- In RCM, review the ROE and determine if there is information which contradicts the decision on file (e.g. the decision on file has a different RFS than the ROE; the comments on the ROE indicate illness or injury but the decision on file indicates something else):

- If there is contradictory information regarding the RFS on the ROE, go to step 17.

- If there is no contradictory information regarding the RFS on the ROE, go to step 18.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Select the Special Condition for the decision on file: Select No Decision Matches the ROE .

- Go to step 19.

- In NWS, on the Resolve Issue tab of the ROE RFS Action WI, complete the Resolve Issue section as follows:

- Select the Special Condition for the decision on file: Select the option that matches the decision in the ROD.

- If the decision indicates Suspension from employment (D-42) , select Suspension .

- If the decision indicates Anticipated Loss of Employment (D-44) , select Anticipated Loss of Employment and enter the disentitlement dates from the decision.

- Go to step 19. 

#### Completing the WI

Source topic: `en_EN/task/roe_loa/completing_the_wi_non-complex.dita`

- Complete the ROE RFS Action WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2685.dita`

Note:

When comparing the employer’s name on the period of employment and the ROE, you may accept minor spelling differences to the employer’s name. You must also consider that the employer may do business under more than one name (e.g. 123456 ONT INC does business as ABC Company). In this case, you must review the documentation on file or use the Employer search (by business number) in FTS to determine if the employer’s name on the ROE is equivalent to the employer’s name on the period of employment. 

#### Note

Source topic: `en_EN/common_notes/note_c_4684.dita`

Note:

When actioning an ROE Comments WI, the agent may have moved the comments in block 18 of the ROE to the Additional information field in RCM. 

#### Warning

Source topic: `en_EN/common_notes/note_c_4685.dita`

Warning:

Do not modify the ROE in RCM. The next step explains how to modify the RFS details in the ROE RFS Action WI. 

## Policy reference

Source topic: `en_EN/task/roe_loa/policy_reference.dita`

 
