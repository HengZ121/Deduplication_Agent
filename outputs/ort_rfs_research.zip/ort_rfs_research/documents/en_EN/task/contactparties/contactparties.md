# Contacting party for a reconsideration under EIA 112

Source map: `en_EN/task/contactparties/contactparties.ditamap`

## Summary

Source topic: `en_EN/task/contactparties/summary.dita`

Summary: When fact-finding for a reconsideration under EIA 112 is required, the client or the employer is initially contacted by telephone as it is the most efficient way to obtain or clarify information. If the client or the employer cannot be reached by telephone, an email or letter is sent requesting the client or employer to call.
       [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

The reconsideration under EIA 112 process is one of the last opportunities to obtain information and documents. Therefore, fact-finding must be as thorough as possible.
       [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 

## What you need to know

Source topic: `en_EN/task/contactparties/what_you_need_to_know.dita`

### Making developmental calls

Source topic: `en_EN/task/contactparties/making_developmental_calls.dita`

Fact-finding by telephone with a client or the employer is known as a developmental call.

If the initial decision was as a result of an Integrity investigation and further fact-finding is required, the officer performing the reconsideration under EIA 112 fact-finds, unless methods outside of the norm are required, such as travelling to a place of business or interviewing employees. In such exceptional cases, the file is returned to Integrity to finalize their investigation as soon as possible with an explanation justifying its return. Monitoring the progress of the investigation is required to avoid unnecessary delays.
       [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2702.dita) 

**Communication by telephone with the requester**

The officer must contact the requester except when the initial decision affecting the requester can be completely rescinded in favour of the requester without having to perform any additional fact-finding and no other interested party has appeal rights.

The objectives of this developmental call are to:

- acknowledge receipt of the request for reconsideration;

- initiate fact-finding and gather information;

- explain the legislative requirements to receive benefits;

- explain the reconsideration under EIA 112 process.
         [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2703.dita) 

Several calls may be required to meet the objectives above and to ensure a well-supported decision.

**Exceptions to developmental calls**

Developmental calls must be made to all relevant parties in all cases. However, there are some exceptions. In certain instances, there is a need for discretion when the party:

- is in hospital or another institution;

- is not able to speak or understand either official language, or understand for other reasons, and there is no approved third party;

- has asked not to be called; the officer does not offer this option to the requester, but, if the requester asks not to be called, the request is honoured;

- has been verbally abusive or threatening during a previous call;

- is terminally ill and the call would be inappropriate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2704.dita) 

**Preparing the developmental call**

Before making the call, the officer reviews the file and notes the questions to ask. Depending on the issue being reviewed, some adjudication procedures provide information to determine these questions. If necessary, the officer refers to the appropriate adjudication procedure.
       [adjudication](/en/procedure/index/adjudicationissue.shtml)

The officer must also request copies of any documents referred to in the initial decision or through the reconsideration process that are not yet on file as they cannot be requested once an appeal has been filed with the Employment Insurance Board of Appeal (EI BOA) or Social Security Tribunal (SST). This is the last chance to obtain all the relevant information, so fact-finding must be as thorough as possible.

**Validating the identity of the party reached**

When making the call, before providing any details of the reason for the call, officers must ensure they are speaking to the client, employer, or a third party authorized to receive personal information on the person’s behalf. Officers must always validate clients’ identity when communicating by telephone. It does not matter if clients or officers initiate the call, officers must always validate clients’ identity. If clients have their access code, their identity is validated by completing a primary security check. If the Access code field in FTS is blank, or if clients do not pass the primary security check, a detailed security check must be completed to validate their identity. If clients still do not pass the required security check, officers must communicate with them by mail.
       [third party](/en/procedure/task/thirdparty.shtml) 
       [validate clients’ identity](/en/procedure/generic/additionalresources/validating_cict.shtml)

**Fact-finding with the best source**

During fact-finding with the employer, officers must also ensure they are speaking to someone who can provide the required information. For example, payroll information must be obtained from someone who works in payroll. Likewise, information about a reason for separation (RFS) must be obtained from the person or from someone from the department familiar with the details of the RFS. Officers must know who they need to speak with before making the call or enquire at the beginning of the conversation.

**Leaving a voicemail or a message with a third party**

Personal or protected information must never be provided to third parties without authorization from the client. No personal or protected information can be shared in voicemails or when leaving messages with third parties, and no voicemail can be left if it is uncertain whether it is the right telephone number.

**Fact-finding with an approved third party**

Personal information used to determine initial or ongoing entitlement to EI benefits must be collected directly from the best source of information, and any required fact-finding must be conducted directly with all the relevant sources, including the client and the employer, if necessary. If the Commission has obtained appropriate authorization for a third party to receive personal information on the client’s or employer’s behalf, the officer organizes a 3-way telephone call with the client or the employer and the third party. If the third party refuses the 3-way telephone call, the officer must explain the advantages and indicate that any evidence provided without the person the third party represents being involved will be considered hearsay and therefore without the same evidentiary weight as a statement made directly by the interested party. In these cases, the officer must attempt to obtain the information directly from the interested party.
       [third party](/en/procedure/task/thirdparty.shtml)

Sharing facts relating to the issue under reconsideration with an approved third party does not replace direct fact-finding with the requester. If the approved third party communicates additional or new information concerning the issue during a conversation with the approved third party in the requester’s absence, it must be explained that they will be validated with the requester as well as all other relevant sources.

**Attempts to communicate by telephone**

Reasonable efforts must always be made to contact a party for each required call. However, a balance must be found between delaying a file and ensuring a timely decision is made. When attempting to call a client, no less than 2 attempts to contact a party must be made for each call and these attempts must be made on different days and at different times . The time zone of the party being contacted must be considered. If the officer is calling an employer, the type of business, its operating hours and peak times must be considered to ensure that it is an appropriate time and obtain maximum cooperation. 

### Message templates

Source topic: `en_EN/task/contactparties/message_templates.dita`

The officer can use the following scripts when calling a client:

**Asking for the client**

Hi, this is [officer’s first name] calling from Service Canada — Employment Insurance. May I speak with [client’s first and last name]?

**Leaving a message with a third party**

Can you please ask [client’s first name] to return my call within the next 24 hours? My name is [officer’s first name] and my phone number is [officer’s phone number]. My hours of work are [hours of work and time zone]. Thank you.

**Leaving a message on voicemail**

Hi, this is [officer’s first name] calling from Service Canada — Employment Insurance. Today is [date] and the time is [time]. This message is for [client’s first and last name]. Please call me back at [officer’s phone number] within 24 hours. My hours of work are [hours of work and time zone]. Thank you. 

### Documenting the communication attempts

Source topic: `en_EN/task/contactparties/documenting_the_communication_attempts.dita`

All attempts to verbally communicate with the interested party, as well as the actual conversation when the party is contacted, must be documented in NWS. According to the National Fact-Finding and Documentation Policy , abbreviations and acronyms must not be used (except for commonly known ones). This is especially important in a request for reconsideration as the documents may be reviewed by other parties such as EI BOA or SST members, lawyers, advocates, etc.
       [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 

### Written communication after unsuccessful attempts at communication by telephone

Source topic: `en_EN/task/contactparties/written_communication_after_unsuccessfu_a91c1b44.dita`

There are situations where written communication requesting communication by telephone is not required after unsuccessful attempts to contact the party by telephone, because the reconsideration under EIA 112 process can proceed. These include:
       [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- Confirming the intent of a request for reconsideration.

- Advising that a request will be held in abeyance.

- Explaining an error in the content of the decision letter.

- Obtaining proof of authorization for a third party.

- Indicating that an initial decision was made, but for which no notice of decision was sent.

In these cases, the officer returns to the previous task which indicates how to proceed in the absence of communication by telephone with the party.

In all other cases, when there is no telephone number at which the client or the employer can be reached, calls have not been returned after leaving voicemails or when the client’s identity cannot be validated, a letter or an email must be sent informing the party to contact the officer as soon as possible. 

### Contacting requesters by email

Source topic: `en_EN/task/contactparties/contacting_requesters_by_email.dita`

If the requester has provided an email address, it can be used to establish contact with the requester for the sole purpose of asking the requester to call to discuss the file. The officer must select the NC-RA-AE-NEPASREPONDRE-DONOTREPLY-EI-RFR-GD@hrsdc-rhdcc.gc.ca general delivery mailbox to send the email. No personal information may be included and under no circumstances may the officer mention details of the claim. It must not contain any confidential or privileged information. Under no circumstance can the officer discuss the specifics of the case, transmit or obtain information by email . An email can be sent instead of the ACS letter after the officer has made attempts to contact the requester by telephone as indicated in the task.
       [NC-RA-AE-NEPASREPONDRE-DONOTREPLY-EI-RFR-GD@hrsdc-rhdcc.gc.ca](/resources/ort/documents/EI_R4R_email_template_EN.msg) 

### Receiving electronic information or documentation

Source topic: `en_EN/task/contactparties/receiving_electronic_information_or_doc_f6cb9ae8.dita`

Officers can offer clients the option of uploading medical certificates and other medical forms in MSCA.

Clients can select from the following list of documents to upload:

```text
| Form number | Description |

| N/A | Hand-written medical certificate |

| INS5217 | CCB: INS5217 Annex 5 — Form [CCB: INS5217 Annex 5 — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ESDC-INS5217.pdf) |

| INS5257 | CCB/Family Caregiver: INS5257 Authorization to release medical information – Form [CCB/Family Caregiver: INS5257 Authorization to release medical information – Form](http://forms-formulaires.prv/lc/content/EForms/en/Detail.html?Form=INS5257) |

| INS5216B | CCB: INS5216B Medical certificate — Form [CCB: INS5216B Medical certificate — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5216B.pdf) |

| INS5223 | CCB: INS5223 Attestation that the client is considered like a family member — Form [CCB: INS5223 Attestation that the client is considered like a family member — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5223.pdf) |

| INS5242B | Family caregiver: INS5242B Medical certificate — Form [Family caregiver: INS5242B Medical certificate — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242B.pdf) |

| INS5140 | Sickness: INS5140 Medical certificate — Form [Sickness: INS5140 Medical certificate — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5140.pdf) |

| N/A | ROEs |

| INS3166 | ROEs: INS3166 Request for ROE — Form [ROEs: INS3166 Request for ROE — Form](https://forms-formulaires.prv/lc/apps/EForms/pdf/en/SC-INS3166.pdf) |

| N/A | Proof of employment (T4, pay stubs) |

| N/A | Proof of authorization to work in Canada (work permits, receipts from application, etc.) |
```

Clients can view any documents they upload in MSCA.

Once uploaded, the officer can view the documents in NWS by selecting View Documents . A list of the uploaded documents then appears and the officer can select a document to view. If the WI type is Medical, the WI moves from Pending to the current workload when the client uploads a document. For other WI types including Claim Assessment (CA), Specialized Application (SA), Claim Review (CR), or Action Item (AI), a banner is added to the WI when the client adds a new document. The Documents icon is red when a new document is available and has not been reviewed. Once an officer reviews the document, the icon changes to green. 

### No additional facts required

Source topic: `en_EN/task/contactparties/no_additional_facts_required.dita`

If there is no additional or missing information that must be obtained from a different source and the officer is able to reach a decision regarding the issue for which a reconsideration is requested, the officer may conclude the last development call to a client with a verbal notice of decision (i.e. combine the development and decision in the same call). A written ACS notice will confirm the decision.
       [verbal notice of decision](/en/procedure/task/arverbalcom.shtml)

However, the officer must keep in mind that clients must always be given the opportunity for rebuttal and that if the facts are equally balanced, they must be given the benefit of the doubt. 

### Note

Source topic: `en_EN/common_notes/note_c_2702.dita`

Note:

References to employers also imply interested parties, if necessary. 

### Note

Source topic: `en_EN/common_notes/note_c_2703.dita`

Note:

If, during the first call the client reports a permanent move to another region, the officer refers to Transferring a request for reconsideration to another region .
       [Transferring a request for reconsideration to another region](/en/procedure/task/transregion.shtml)

     [Transferring a request for reconsideration to another region](/en/procedure/task/transregion.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2704.dita`

Note:

The above must be documented in the file to be considered an exception. 

## Regional considerations

Source topic: `en_EN/task/contactparties/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/contactparties/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/contactparties/in_nws.dita`

- Are there documents referred to in the documentation or the decision that are not currently in Imaging or Common Document Share?

- Has additional information been submitted, uploaded or received since your last interaction with the party? 

## Step by step

Source topic: `en_EN/task/contactparties/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/contactparties/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/contactparties/reviewing_the_file_level_1.dita`

- Determine if there are any exceptions to a mandatory telephone call:

- If no, go to step 2.

- If yes, go to step 51.

- Determine if there is a valid telephone number on file:

- If no, go to step 3.

- If yes, go to step 5.

- In NWS, create a draft SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and last day worked (LDW), if necessary] — [party being called].”

- Details: Type “Unable to reach the client by telephone — no telephone number on file.”

- Select Draft .

- Determine if the party to contact is the client or the requester and if an email address was provided:

- If it is the client or the requester and an email address was provided, go to step 19.

- If it is the client or the requester, but no email address was provided, go to step 50.

- If it is an employer or a third party, but not the requester, an email cannot be sent. Go to step 50. 

#### First communication attempt by telephone

Source topic: `en_EN/task/contactparties/first_communication_attempt_by_telephone_level_1.dita`

- Determine if the requester has designated a third party on file:

- If no, go to step 6.

- If yes, contact the third party by telephone to organize a 3-way telephone call. Go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2705.dita)

- Attempt to contact the requester by telephone.

- Determine if the party was reached:

- If yes, go to step 8.

- If no, go to step 9.

- Determine if you are contacting a client:

- If yes, refer to Validating a client’s identity when communicating by telephone and then go to step 15.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- Determine if a voicemail or message with a third party can be left:

- If no, go to step 10.

- If yes, leave only the following information:

- name of the person you wish to speak with

- your name and organization (Service Canada — Employment Insurance)

- date and time that you called

- instruction to call back within the next 24 hours

- your number and the hours you can be reached (and your time zone if necessary)

- In NWS, create a draft SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Document the following information:

- telephone number dialled

- date and time of the call

- whether a voicemail or message with a third party has been left, or if unable to leave a message

- name of the third party, if necessary

- position of the third party, if contacting an employer

- your telephone number (in case the client contacts the call centre)

- Select Draft .

- Determine if the party to contact is the client or the requester and if an email address was provided:

- If it is the client or the requester, but no email address was provided, go to step 12.

- If it is an employer or third party, but not the requester, an email cannot be sent. Go to step 12.

- If it is the client or the requester and an email address was provided, go to step 19.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “First contact, RFR [ADMS record number].”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, determine if the party returned the call:

- If yes, go to step 14.

- If no, go to step 32.

- Determine if it is a client returning the call:

- If yes, refer to Validating a client’s identity when communicating by telephone and go to step 15.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- Determine if you were able to validate the client’s identity:

- If yes, go to step 16.

- If no, go to step 18.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 17.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 17.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “The client’s identity and address have been validated.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “Unable to validate client identity over telephone.” Document any additional details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to step 50. 

#### Communication attempt by email

Source topic: `en_EN/task/contactparties/communication_attempt_by_email_level_1.dita`

- Create and send an email to the client or the requester using the email template .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2706.dita)

- In Outlook, review the GD box:

- If no message is received stating that the delivery has failed, go to step 21.

- If a message is received stating that the delivery has failed, consider that there is no email address for the client and delete the failed email message from the GD mailbox. Go to step 31.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Details: Type the appropriate option:

- “Unable to validate client’s identity by telephone. An email has been sent. Response due [today’s date + 5 business days].”

- “No communication by telephone with the client [and why, if no attempts were made]. An email has been sent. Response due [today’s date + 5 business days].”

- Select Draft .

- In the Common Document Share, save a copy of the email in the Record folder.

- In NWS, create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — email contact with the requester.”

- Details: Copy and paste a copy of the email sent.

- Select Save .

- Move the WI to Pending as follows:

- Pending reason: Select Fact finding client or Fact finding employer .

- Comments: Type the appropriate option:

- “Awaiting response to email sent on [DD-MM-YYYY].”

- “Awaiting response from the client.”

- “Awaiting response from the employer.”

- Bring forward date: Enter today’s date + 5 business days.

- When the WI moves to the current workload, determine if the party responded:

- If the party responded, go to step 26.

- If the party did not respond and there is a valid telephone number on file, go to step 32.

- If the party did not respond and there is no valid telephone number on file, go to Unable to complete the call .
               [Unable to complete the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#_Unable_to_complete)

- Determine if it is a client returning the call:

- If yes, refer to Validating a client’s identity when communicating by telephone and go to step 27.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- Determine if the client’s identity could be validated:

- If yes, go to step 28.

- If no, go to step 30.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 29.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 29.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “The client’s identity and address have been validated.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “Unable to validate client identity over telephone.” Document any additional details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to step 47.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Details: Type “No communication by telephone with the client. An attempt was made to send an email, but delivery to [email address] failed.”

- Select Draft .

- Go to step 51. 

#### Second communication attempt by telephone

Source topic: `en_EN/task/contactparties/second_communication_attempt_by_telephone_level_1.dita`

- Attempt to contact the party again by telephone.

- Determine if the party was reached:

- If yes, go to step 34.

- If no, go to step 39.

- Determine if you are contacting a client:

- If yes, refer to Validating a client’s identity when communicating by telephone and then go to step 35.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- Determine if the client’s identity could be validated:

- If yes, go to step 36.

- If no, go to step 38.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 37.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 37.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “The client’s identity and address have been validated.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “Unable to validate the client’s identity by telephone.” Document any additional details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to step 50.

- Determine if a voicemail or message with a third party can be left:

- If no, go to step 40.

- If yes, leave only the following information:

- name of the person you wish to speak with

- your name and organization (Service Canada — Employment Insurance)

- date and time that you called, and that this is a second call

- instruction to call back within the next 24 hours

- your telephone number and the hours you can be reached (and your time zone if necessary)

- In NWS, open the draft SROC and add the following information:

- Details:

- telephone number dialed

- date and time of the call

- whether a message has been left on a voicemail or with a third party or if unable to leave a message

- name of the third party, if necessary

- position of the third party, if contacting an employer

- your telephone number (in case the client contacts the call centre)

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “2nd contact — request for reconsideration [ADMS record number].”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, determine if the party returned the call:

- If yes, go to step 43.

- If no, go to step 48.

- Determine if it is a client returning the call:

- If yes, refer to Validating a client’s identity when communicating by telephone and go to step 44.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- Determine if the client’s identity could be validated:

- If yes, go to step 45.

- If no, go to step 47.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 46.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 46.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “The client’s identity and address have been validated.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary — [party being called].”

- Details: Type “Unable to validate the client’s identity by telephone.” Document any additional details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to step 50.

- Determine if an attempt was made to reach the party by email:

- If no and the client or the requester provided an email address, return to step 19.

- If yes, go to step 49.

- If no and the party to contact is an employer or a third party, but not the requester, go to step 50.

- If no and the client or the requester did not provide an email address, go to step 51.

- Save the SROC and return to the previous task. 

#### Determining if written communication is required

Source topic: `en_EN/task/contactparties/determining_if_written_communication_is_required_level_1.dita`

- Determine if the purpose of the call is a developmental call required for the purpose of gathering specific information about the issue for which a reconsideration is sought:

- If yes, go to step 51.

- If no, go to Unable to complete the call .
               [Unable to complete the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#_Unable_to_complete) 

#### Communication attempt in writing

Source topic: `en_EN/task/contactparties/communication_attempt_in_writing_level_1.dita`

- Determine who you are trying to reach:

- If it is the employer, go to step 52.

- If it is the client, go to step 57.

- Determine if the employer is an interested party in the request for reconsideration:

- If yes, go to step 53.

- If no, go to step 54.

- In ACS, create and send the X-04-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Acknowledgment and Request call back from Employer (11830)

- This letter replaces or Footnote Employer (2365)

- Text - Footnote (11745): Type “You may call any weekday up to and including [today’s date + 10 business days] between the hours of [list hours of work, including the time zone]. The sooner you contact us, the sooner we can process this request.”

- Go to step 55.

- In ACS, create and send the Z-00-00-00. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334) .

- Employer or Third Party Address 1 (1336) .

- Employer or Third Party Address 2 (2440) .

- Employer or Third Party Address 3 (2441) .

- Text - Free Text (1612): Enter the issue you are enquiring about and type “You may call any weekday up to and including [today’s date + 10 business days] between the hours of [hours of work, including the time zone] at the following telephone number: [your telephone number].”

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “No communication by telephone with the employer [and why, if no attempts were made]. [X-04-00-00 or Z-00-00-00] letter has been sent. Response due [today’s date + 10 business days].” If not already documented, enter your telephone number in case the employer contacts the call centre.

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact finding employer .

- Comments: Type “Awaiting response to letter [X-04-00-00 or Z-00-00-00] sent on [DD-MM-YYYY].”

- Bring forward date: Enter today’s date + 10 business days.

- Go to step 60.

- In ACS, create and send X-03-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Acknowledge and Request call back from claimant (11913)

- This letter replaces or Footnote Employer (2365)

- Text - Footnote (11745): Type “You may call any weekday up to and including [today’s date + 10 business days] between the hours of [list hours of work, including the time zone]. The sooner you contact us, the sooner we can process this request.”

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type the appropriate option:

- “Unable to validate the client’s identity by telephone. X-03-00-00 letter has been sent. Response due [today’s date + 10 business days].” If not already documented, enter your telephone number in case the client contacts the call centre.

- “No communication by telephone with the client [and why, if no attempts were made]. X-03-00-00 letter has been sent. Response due [today’s date + 10 business days].” If not already documented, enter your telephone number in case the client contacts the call centre.

- “Unable to reach the client by telephone — no telephone number on file.”

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact finding client .

- Comments: Type “Awaiting response to letter X-03-00-00 sent on [DD-MM-YYYY].”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if the party responded:

- If yes, go to step 61.

- If no, go to Unable to complete the call .
               [Unable to complete the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#_Unable_to_complete)

- Determine if it is a client returning the call:

- If yes, refer to Validating a client’s identity when communicating by telephone and go to step 62.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- Determine if the client’s identity could be validated:

- If yes, go to step 63.

- If no, go to step 65.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 64.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 64.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “The client’s identity and address have been validated.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy.
               [National Fact-Finding and Documentation Policy.](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted)

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary — [party being called].”

- Details: Type “Unable to validate the client’s identity by telephone.” Document any additional details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Unable to complete the call .
               [Unable to complete the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#_Unable_to_complete) 

#### Unable to complete the call

Source topic: `en_EN/task/contactparties/unable_to_complete_the_call_level_1.dita`

- Save the draft SROC and return to the previous task. 

#### Completing the call

Source topic: `en_EN/task/contactparties/completing_the_call_level_1.dita`

- Once on the telephone with the party, do the following:

- Identify yourself.

- Explain the reason for the call (as indicated in the task; any or all of the following reasons may apply, but this is not an exhaustive list):

- Confirm that the request for reconsideration has been received.

- Confirm the intent of the request, if necessary.

- Explain the purpose and process of the reconsideration under EIA 112 process, including the fact that you are a different person from the one who made the initial decision.
                   [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- Explain the legislated requirements for the issue for which the request for reconsideration was made.

- Obtain the explanation for the delay in the request, if necessary.

- Indicate that the request is being held in abeyance, if necessary.

- Summarize the facts on file.

- Indicate that verbal notification of an initial decision was made, but a notice of decision was not sent, if required.

- Indicate that there are errors in the notice of decision, if necessary.

- Identify additional or missing information that is required (including documentation) and obtain it.

- Explain the need to contact all interested parties and that further contact may be required, if necessary.

- Explain the next steps.

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Return to the previous task. 

#### Note

Source topic: `en_EN/common_notes/note_c_2705.dita`

Note:

The third party might refuse the 3-way telephone call. In these cases, explain that any evidence provided without the person the third party represents being involved will be considered hearsay and therefore without the same evidentiary weight as a statement made directly by the interested party. Then contact only the requester. 

#### Note

Source topic: `en_EN/common_notes/note_c_2706.dita`

Note:

To make sure that the email is sent from the GD box and not from a personal email, check if the NC-RA-AE-NEPASREPONDRE-DONOTREPLY-EI-RFR-GD@hrsdc-rhdcc.gc.ca email address is entered in the From field. 

### Level 2

Source topic: `en_EN/task/contactparties/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/contactparties/reviewing_the_file_level_2.dita`

- Determine if there are any exceptions to a mandatory telephone call:

- If no, go to step 2.

- If yes, go to step 51.

- Determine if there is a valid telephone number on file:

- If no, go to step 3.

- If yes, go to step 5.

- In NWS, create a draft SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “Unable to reach the client by telephone — no telephone number on file.”

- Determine if the party to contact is the client or the requester and if an email address was provided:

- If it is the client or the requester and an email address was provided, go to step 19.

- If it is the client or the requester, but no email address was provided, go to step 50.

- If it is an employer or a third party, but not the requester, an email cannot be sent. Go to step 50. 

#### First communication attempt by telephone

Source topic: `en_EN/task/contactparties/first_communication_attempt_by_telephone_level_2.dita`

- Determine if the requestor has designated a third party on file:

- If no, go to step 6.

- If yes, contact the third party by telephone to organize a 3-way telephone call. Go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2705.dita)

- Attempt to contact the requester by telephone.

- Determine if the party was reached:

- If yes, go to step 8.

- If no, go to step 9.

- Determine if you are contacting a client:

- If yes, refer to Validating a client’s identity when communicating by telephone and then go to step 15.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- Determine if a voicemail or message with a third party can be left:

- If no, go to step 10.

- If yes, leave only the following information:

- name of the person you wish to speak with

- your name and organization (Service Canada — Employment Insurance)

- date and time that you called

- instruction to call back within the next 24 hours

- your number and the hours you can be reached (and your time zone if necessary)

- In NWS, create a draft SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Document the following information:

- telephone number dialled

- date and time of the call

- whether a voicemail or message with a third party has been left, or if unable to leave a message

- name of the third party, if necessary

- position of the third party, if contacting an employer

- your telephone number (in case the client contacts the call centre)

- Select Draft .

- Determine if the party to contact is the client or the requester and if an email address was provided:

- If it is the client or the requester, but no email address was provided, go to step 12.

- If it is an employer or a third party, but not the requester, an email cannot be sent. Go to step 12.

- If it is the client or the requester and an email address was provided, go to step 19.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “1st contact — request for reconsideration [ADMS record number].”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, determine if the party returned your call:

- If yes, go to step 14.

- If no, go to step 32.

- Determine if it is a client returning the call:

- If yes, refer to Validating a client’s identity when communicating by telephone and go to step 15.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- Determine if the client’s identity could be validated:

- If yes, go to step 16.

- If no, go to step 18.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 17.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 17.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “The client’s identity and address have been validated.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Completing the call.
               [Completing the call.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary — [party being called].”

- Details: Type “Unable to validate the client’s identity by telephone.” Document any additional details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to step 50. 

#### Communication attempt by email

Source topic: `en_EN/task/contactparties/communication_attempt_by_email_level_2.dita`

- Create and send an email to the client or the requester using the email template .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2706.dita)

- In Outlook, review the GD box:

- If no message is received stating that the delivery has failed, go to step 21.

- If a message is received stating that the delivery has failed, consider that there is no email address for the client and delete the failed email message from the GD mailbox. Go to step 31.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Details: Type the appropriate option:

- “Unable to validate the client’s identity by telephone. An email has been sent. Response due [today’s date + 5 business days].”

- “No communication by telephone with the client [and why, if no attempts were made]. An email has been sent. Response due [today’s date + 5 business days].”

- Select Draft .

- In the Common Document Share, save a copy of the email in the Record folder.

- NWS, create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — email contact with the requester.”

- Details: Copy and paste a copy of the email sent.

- Select Save .

- Move the WI to Pending as follows:

- Pending reason: Select Fact finding client or Fact finding employer .

- Comments: Type the appropriate option:

- “Awaiting response to email sent on [DD-MM-YYYY].”

- “Awaiting response from the client.”

- “Awaiting response from the employer.”

- Bring forward date: Enter today’s date + 5 business days.

- When the WI moves to the current workload, determine if the party responded to the email:

- If the party responded, go to step 26.

- If the party did not respond and there is a valid telephone number on file, go to step 32.

- If the party did not respond and there is no valid telephone number on file, go to Unable to complete the call .
               [Unable to complete the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#_Unable_to_complete_l2)

- Determine if it is a client returning the call:

- If yes, refer to Validating a client’s identity when communicating by telephone and go to step 27.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- Determine if you were able to validate the client’s identity:

- If yes, go to step 28.

- If no, go to step 30.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 29.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 29.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “The client’s identity and address have been validated.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Completing the call.
               [Completing the call.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary— [party being called].”

- Details: Type “Unable to validate client identity over telephone.” Document any additional details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to step 47.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Details: Type “No communication by telephone with the client. An attempt was made to send an email, but delivery to [email address] failed.”

- Select Draft .

- Go to step 51. 

#### Second communication attempt by telephone

Source topic: `en_EN/task/contactparties/second_communication_attempt_by_telephone_level_2.dita`

- Attempt to contact the party again by telephone.

- Determine if the party was reached:

- If yes, go to step 34.

- If no, go to step 39.

- Determine if you are contacting a client:

- If yes, refer to Validating a client’s identity when communicating by telephone and then go to step 35.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- Determine if the client’s identity could be validated:

- If yes, go to step 36.

- If no, go to step 38.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 37.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 37.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “The client’s identity and address have been validated.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft.

- Go to Completing the call.
               [Completing the call.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary— [party being called].”

- Details: Type “Unable to validate the client’s identity by telephone.” Document any additional details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to step 50.

- Determine if a voicemail or message with a third party can be left:

- If no, go to step 40.

- If yes, leave only the following information:

- name of the person you wish to speak with

- your name and organization (Service Canada — Employment Insurance)

- date and time that you called, and that this is a second call

- instruction to call back within the next 24 hours

- your telephone number and the hours you can be reached (and your time zone if necessary)

- In NWS, open the draft SROC and add the following information:

- Details:

- telephone number dialed

- date and time of the call

- whether a message has been left on a voicemail or with a third party or if unable to leave a message

- name of the third party, if applicable

- position of the third party, if contacting an employer

- your telephone number (in case the client contacts the call centre)

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “2nd contact — request for reconsideration [ADMS record number].”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, determine if the party returned the call:

- If yes, go to step 43.

- If no, go to step 48.

- Determine if it is a client returning the call:

- If yes, refer to Validating a client’s identity when communicating by telephone and go to step 44.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- Determine if the client’s identity could be validated:

- If yes, go to step 45.

- If no, go to step 47.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 46.

- If the client’s address is different from the one on file, refer to Change of address , then go to step 46.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “The client’s identity and address have been validated.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary — [party being called].”

- Details: Type “Unable to validate the client’s identity by telephone.” Document any additional details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to step 50.

- Determine if an attempt was made to reach the party by email:

- If no and the client or the requester provided an email address, return to step 19.

- If yes, go to step 49.

- If no and the party to contact is an employer or a third party, but not the requester, go to step 50.

- If no and the client or the requester did not provide an email address, go to step 51.

- Save the SROC and return to the previous task. 

#### Determining if written communication is required

Source topic: `en_EN/task/contactparties/determining_if_written_communication_is_required_level_2.dita`

- Determine if the purpose of the call is a developmental call required for the purpose of gathering specific information about the issue for which a reconsideration is sought:

- If yes, go to step 51.

- If no, go to Unable to complete the call .
               [Unable to complete the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#_Unable_to_complete_l2) 

#### Communication attempt in writing

Source topic: `en_EN/task/contactparties/communication_attempt_in_writing_level_2.dita`

- Determine who you are trying to reach:

- If it is the employer, go to step 52.

- If it is the client, go to step 57.

- Determine if the employer is an interested party in the request for reconsideration:

- If yes, go to step 53.

- If no, go to step 54.

- In ACS, create and send the X-04-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Acknowledgement and Request call back from Employer (11830)

- This letter replaces or Footnote Employer (2365)

- Text - Footnote (11745): Type “You may call any weekday up to and including [today’s date + 10 working days] between the hours of [list hours of work, including the time zone]. The sooner you contact us, the sooner we can process this request.”

- Go to step 55.

- In ACS, create and send the Z-00-00-00. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334) .

- Employer or Third Party Address 1 (1336) .

- Employer or Third Party Address 2 (2440) .

- Employer or Third Party Address 3 (2441) .

- Text - Free Text (1612): Enter the issue you are enquiring about and type “You may call any weekday up to and including [today’s date + 10 business days] between the hours of [hours of work, including the time zone] at the following telephone number: [your telephone number].”

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “No communication by telephone with the client [and why, if no attempts were made]. [X-04-00-00 or Z-00-00-00] letter has been sent. Response due [today’s date + 10 business days].” If not already documented, enter your telephone number in case the employer contacts the call centre.

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact finding (employer).

- Comments: Type “Awaiting response to letter [X-04-00-00 or Z-00-00-00] sent on [DD-MM-YYYY].”

- Bring forward date: Enter today’s date + 10 business days.

- Go to step 60.

- In ACS, create and send X-03-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Acknowledgment and Request call back from claimant (11913)

- This letter replaces or Footnote Employer (2365)

- Text - Footnote (11745): Type “You may call any weekday up to and including [today’s date + 10 business days] between the hours of [list hours of work, including the time zone]. The sooner you contact us, the sooner we can process this request.”

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type the appropriate option:

- “Unable to validate the client’s identity by telephone. X-03-00-00 letter has been sent. Response due [today’s date + 10 business days].” If not already documented, enter your telephone number in case the client contacts the call centre.

- “No communication by telephone with the client [and why, if no attempts were made]. X-03-00-00 letter has been sent. Response due [today’s date + 10 business days].” If not already documented, enter your telephone number in case the client contacts the call centre.

- “Unable to reach the client by telephone — no telephone number on file.”

- Select Draft .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact finding client .

- Comments: Type “Awaiting response to letter X-03-00-00 sent on [DD-MM-YYYY].”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves the current workload, determine if the party responded:

- If yes, go to step 61.

- If no, go to Unable to complete the call .
               [Unable to complete the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#_Unable_to_complete_l2)

- Determine if it is a client returning the call:

- If yes, refer to Validating a client’s identity when communicating by telephone and go to step 62.
               [Validating a client’s identity when communicating by telephone](/en/procedure/generic/additionalresources/validating_cict.shtml)

- If no, go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- Determine if the client’s identity could be validated:

- If yes, go to step 63.

- If no, go to step 65.

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 64.

- If the client’s address is different than the one on file, refer to Change of address , then go to step 64.
               [Change of address](/en/procedure/activity/change_address.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Type “The client’s identity and address have been validated.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Completing the call .
               [Completing the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#PartyContacted2)

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary — [party being called].”

- Details: Type “Unable to validate the client’s identity by telephone.” Document any additional details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Draft .

- Go to Unable to complete the call .
               [Unable to complete the call](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/contactparties#_Unable_to_complete_l2) 

#### Unable to complete the call

Source topic: `en_EN/task/contactparties/unable_to_complete_the_call_level_2.dita`

- Save the draft SROC and return to the previous task. 

#### Completing the call

Source topic: `en_EN/task/contactparties/completing_the_call_level_2.dita`

- Once on the telephone with the party, do the following:

- Identify yourself.

- Explain the reason for the call (as indicated in the task; any or all of the following reasons may apply, but this is not an exhaustive list):

- Confirm that the request for reconsideration has been received.

- Confirm the intent of the request, if necessary.

- Explain the purpose and process of the reconsideration under EIA 112 process, including the fact that you are a different person from the one who made the initial decision.
                   [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- Explain the legislated requirements for the issue for which the request for reconsideration was made.

- Obtain the explanation for the delay in the request, if necessary.

- Indicate that the request is being held in abeyance, if necessary.

- Summarize the facts on file.

- Indicate that verbal notification of an initial decision was made, but a notice of decision was not sent, if necessary.

- Indicate that there are errors in the notice of decision, if necessary.

- Identify additional or missing information that is required (including documentation) and obtain it.

- Explain the need to contact all interested parties and that further contact may be required, if necessary.

- Explain the next steps.

- In NWS, add details to the draft SROC created when attempting to contact the party or create a new SROC as follows:

- Main Issue: Select Request for Reconsideration .

- Comments: Type “RFR [ADMS record number] — [issue] — [employer name and LDW, if necessary] — [party being called].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Return to the previous task. 

## Policy reference

Source topic: `en_EN/task/contactparties/policy_reference.dita`

- National Fact-Finding and Documentation Policy
         [National Fact-Finding and Documentation Policy](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/national_policy_factfinding.shtml) 
