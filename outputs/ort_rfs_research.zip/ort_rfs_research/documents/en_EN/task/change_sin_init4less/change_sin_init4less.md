# Changing a SIN: Initial claim — Within 4 weeks of the interruption of earnings

Source map: `en_EN/task/change_sin_init4less/change_sin_init4less.ditamap`

## Summary

Source topic: `en_EN/task/change_sin_init4less/summary.dita`

Summary: When a client reports having obtained a new SIN and the initial application date and claim assessment are within 4 weeks of the interruption of earnings (I of E), the officer asks the client to reapply for benefits using the new SIN. 

## What you need to know

Source topic: `en_EN/task/change_sin_init4less/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/change_sin_init4less/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2500.dita) 

### Receiving notification of a new SIN

Source topic: `en_EN/task/change_sin_init4less/receiving_notification_of_a_new_sin.dita`

A client may receive a new SIN at any time during the claim. The client can report the change in person, by telephone or by mail. When notification of a new SIN is received, the officer confirms the new SIN in the Social Insurance Registry (SIR) database before making any changes to the records.

When permanent residents or Canadian citizens apply for EI benefits with a 900-series SIN, they receive a message informing them that they must apply for a new permanent SIN and report the new SIN when they receive it. 

### Updating the EI application

Source topic: `en_EN/task/change_sin_init4less/updating_the_ei_application.dita`

On an initial claim, when 4 or less weeks have passed since the most recent I of E occurred and the claim assessment is performed within this period , the officer follows this procedure to ask the client to reapply for benefits using the new SIN. Since the I of E is within 4 weeks, ACP registers the claim or, if ACP cannot determine the tentative BPC, it creates a Claim Set-Up (CS) Tentative BPC WI . The officer deletes the application with the old SIN, as it is considered an error.

However, when 4 or less weeks have passed since the most recent I of E occurred on an initial claim and the claim assessment is not performed within this period , the client cannot reapply with the new SIN because ACP would not calculate the BPC correctly. In this situation, the officer refers to Changing a SIN: Initial claim — More than 4 weeks after the interruption of earnings and manually establishes the claim with the new SIN using the information on the EI application that was submitted under the old SIN. Then, the officer deletes the application with the old SIN, as it is considered an error.
       [Changing a SIN: Initial claim — More than 4 weeks after the interruption of earnings](/en/procedure/task/change_sin_init4more.shtml)

On an initial claim, when the client applies more than 4 weeks from the most recent I of E, the officer refers to Changing a SIN: Initial claim — More than 4 weeks after the interruption of earnings .
       [Changing a SIN: Initial claim — More than 4 weeks after the interruption of earnings](/en/procedure/task/change_sin_init4more.shtml)

All SROCs, records of decision (RODs), Action Item (AI) or Call Back (CB) WIs created under the 900-series SIN remain accessible under the 900-series SIN and are not transferred to the new permanent SIN. To access this information, the officer refers to the client’s old SIN. 

### Updating the ROEs

Source topic: `en_EN/task/change_sin_init4less/updating_the_roes.dita`

All paper and electronic ROEs in RCM that were issued with the old SIN and used to calculate the claim must be re-entered as interim ROEs with the new SIN. This applies to both paper and electronic ROEs. In addition, the processing officer documents the SIN change under both the new and old SIN and submits the information to IPOC using an Operational Centre Memo (MM06) transaction. An IPOC officer then takes all the required actions related to the SIN change on any continuing, renewal or dormant claims.
       [interim ROEs](/en/procedure/activity/interim_roe.shtml)

The processing officer ensures that all ROEs issued since the new SIN became valid have been correctly issued with the new SIN. If an employer issues an ROE with the old SIN and the new SIN is already valid, the officer deletes the ROE and asks the employer to reissue the ROE with the new SIN. In addition to creating an interim ROE, the officer creates a Reminder (REM) WI while awaiting the ROE. 

### Updating the electronic file

Source topic: `en_EN/task/change_sin_init4less/updating_the_electronic_file.dita`

The client must not submit claimant’s reports with the old SIN because that claimwill not be established. When the claim is registered with the new SIN, the system issues an access code and instructions on when to submit the claimant’s report.

Earlier claims established with the old SIN that are now dormant must also be updated. The officer sends an MM06 to IPOC to have the updates made to dormant claims. 

### Obtaining the missing information

Source topic: `en_EN/task/change_sin_init4less/obtaining_the_missing_information.dita`

The officer imposes an indefinite 15 - Claim Procedure disentitlement (D15) from the BPC under the 900-series SIN when the client is not reached and fact-finding is required to confirm the client’s full name or parent’s last name at birth (EI application only).

The officer sends an ACS letter to notify the client of the disentitlement and instructs the client to provide the missing information as soon as possible. 

### Levels of decision — Rescinding a Claim Procedure disentitlement (D15)

Source topic: `en_EN/task/change_sin_init4less/levels_of_decision__rescinding_a_claim__193609eb.dita`

If the client does not respond to the requests to provide missing information, it is considered as a failure to report for an interview. The National Policy on Levels of Decision specifies that a Level 1 officer rescinds a D15 when the requested information is provided within 6 weeks of the date the D-01-00-00 letter was sent. For more information, the Level 1 officer refers to Reviewing a D15 disentitlement — Failure to report for a telephone interview .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
       [Reviewing a D15 disentitlement — Failure to report for a telephone interview](/en/procedure/task/claim_procedure_ftr_telehone_review_d15.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2500.dita`

Note:

When the claim assessment is not performed within 4 weeks of the I of E, or when a client reports having obtained a new SIN and the initial application was submitted after 4 weeks from the I of E, the officer refers to Changing a SIN: Initial claim — More than 4 weeks after the interruption of earnings .
       [Changing a SIN: Initial claim — More than 4 weeks after the interruption of earnings](/en/procedure/task/change_sin_init4more.shtml)

     [Changing a SIN: Initial claim — More than 4 weeks after the interruption of earnings](/en/procedure/task/change_sin_init4more.shtml) 

## Regional considerations

Source topic: `en_EN/task/change_sin_init4less/regional_considerations.dita`

**Quebec:**

The Business Expertise Advisor, rather than the Team Leader, deletes the application in NWS. Using the consultative tool, the officer advises the Business Expertise Advisor. No WI is created. 

## What you need to look for

Source topic: `en_EN/task/change_sin_init4less/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/change_sin_init4less/in_fts.dita`

- What personal information is on the application with the old SIN?

- Is there a skeleton claim?

- Are there any BPCs established with the old SIN? 

### In NWS:

Source topic: `en_EN/task/change_sin_init4less/in_nws.dita`

- Is there an SROC or AI WI related to the SIN change?

- Are there any other WIs outstanding on the claim under the old SIN?

- If yes, are they unassigned or assigned to other users? 

### In Imaging:

Source topic: `en_EN/task/change_sin_init4less/in_imaging.dita`

- Is there documentation related to the SIN change? 

### In SIR:

Source topic: `en_EN/task/change_sin_init4less/in_sir.dita`

- Does the information in the SIR database with the client’s new SIN match the personal information found on the original application (old SIN)?

- On which date was the new SIN issued? 

### In RCM:

Source topic: `en_EN/task/change_sin_init4less/in_rcm.dita`

- Have ROEs been submitted?

- What types of ROEs have been submitted (what letter does the serial number start with?)

- Have ROEs been issued before or after the SIN change? 

## Step by step

Source topic: `en_EN/task/change_sin_init4less/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/change_sin_init4less/level_1.dita`

#### Determining if the SIN change can be input

Source topic: `en_EN/task/change_sin_init4less/determining_if_the_sin_change_can_be_input_level_1.dita`

- In the SIR, compare the following SIR database information with the client’s new SIN to the initial application submitted under the old SIN:

- the client’s full name

- the parent’s last name at birth (EI application only)

- Fact-find with the client and do the following:

- Verify the correct information for any differences found in step 1.

- Inform the client of the following:

- The client must reapply with the new SIN.

- The client must ask the employer to complete all ROEs with the new SIN.

- The client must not submit claimant’s reports using the old SIN.

- The application completed with the old SIN will be deleted.

- The client can start submitting claimant reports when the new access code is issued.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 4.

- If the client was not reached or did not reply to the N10-00-00 letter, go to SIN change cannot be input — Unable to reach the client for missing information .
               [SIN change cannot be input — Unable to reach the client for missing information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/change_sin_init4less#d15)

- Determine if the client provided proof of the authorization to work in Canada for each period of employment in the qualifying period (QP) during which the client had a 900-series SIN:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2501.dita)

- In NWS and Imaging, determine if a proof of authorization to work in Canada was provided:

- If no, complete the WI related to the SIN change.

- If yes, go to SIN change can be input. 

#### SIN change can be input

Source topic: `en_EN/task/change_sin_init4less/sin_change_can_be_input_level_1.dita`

- In NWS, on the claim under the old SIN, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “SIN change — new SIN obtained.”

- Details: Type “New SIN — [new SIN]. This application must be deleted.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- With the new SIN, create an external SROC as follows:

- Main Issue: Select Other .

- Comments: Type “SIN change — new SIN obtained.”

- Details: Type “Old SIN — [old SIN].”

- Select Save . 

#### Deleting the EI application under the old SIN

Source topic: `en_EN/task/change_sin_init4less/deleting_the_ei_application_under_the_old_sin_level_1.dita`

- In NWS, create a REM WI with the old SIN to have the application with the old SIN deleted as follows:

- Select the appropriate application.

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due Date: Enter today’s date.

- Language: Select the language used on the application.

- Details: Type “The wrong SIN was provided on the application.”

- Destination: Enter the Service Canada Centre (SCC) code as shown in FTS.

- End User: Select Specific User and assign it to your team leader or the staff member who has deletion rights.

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2502.dita) 

#### Updating the ROEs

Source topic: `en_EN/task/change_sin_init4less/updating_the_roes_level_1.dita`

- In RCM, create an interim ROE using the new SIN for each ROE that affects the current claim and was input with the old SIN as follows:

- On the Input screen, complete the fields as follows:

- Social Insurance No.: Enter the new SIN.

- Serial Number: Leave this field blank.

- Serial Number of amended ROE or replaced: Leave this field blank.

- Interim ROE Type: Select Regular Interim or Fishing Interim .

- Printing Language: Select the language used on the original ROE.

- Select Submit .

- On the Input Regular ROE or Input Fishing ROE screen, enter the same information as shown on the original ROE with the old SIN.

- Additional information: Type “SIN change — old SIN [old SIN and serial number of original ROE].”

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2503.dita)

- Determine if there are ROEs on file with an issue date following the effective date of the new SIN:

- If yes, go to step 11.

- If no, go to step Updating the electronic file .
               [Updating the electronic file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/change_sin_init4less#updating)

- In RCM, delete each ROE that was incorrectly issued with the old SIN as follows:

- Select Search/Correct .

- Social Insurance No.: Enter the old SIN.

- Serial Number: Leave this field blank.

- Select Submit .

- Select a serial number to open an ROE.

- Status: Check the Delete box.

- Additional information: Type “SIN change — [new SIN].”

- Select Submit .

- Fact-find with the employer and do the following:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2499.dita)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC using the new SIN as follows:

- Main issue: Select ROE .

- Comments: Type “SIN change — [new SIN].”

- Details: Type “[Employer’s name] incorrectly issued the record of employment with the old SIN.” If required, type “Unable to contact the employer by telephone — a second letter was sent.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the employer was reached during fact-finding:

- If the employer was reached, go to step 15.

- If the employer was not reached or did not reply to the Z-02-00 letter, go to step 21.

- Determine if the employer states the ROE will be provided:

- If yes and the employer is faxing the ROE to Service Canada, go to step 16.

- If yes and the employer will issue the electronic ROE in a timely manner, go to step 16.

- If yes and the employer will provide the client with a paper ROE or true copy of the original paper ROE, go to 16.

- If no, go to step 20.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select ROE .

- Comments: Type “ROE request.”

- Bring forward date: Do one of the following:

- If the employer is faxing the ROE, enter today’s date + 2 business days.

- If the employer indicated that the electronic ROE will be issued in a timely manner, enter today’s date + 5 business days.

- If the employer is sending a paper ROE, enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if the ROE is displayed in RMDS or RCM:

- If the ROE is not displayed in RMDS or RCM, go to step 18.

- If the ROE is displayed in RCM, go to step 23.

- Determine if the paper copy, or an uploaded or faxed copy of the ROE has been received:

- If the ROE was not received and the bring-forward date is not reached, return to step 16.

- If an uploaded or faxed copy of a paper ROE was received, go to step 19.

- If a copy of the ROE has not been received and the bring-forward date is reached, go to step 20.

- In RCM, enter the ROE by referring to Data entry — Paper document . If the ROE that was entered has validation errors, correct the errors by referring to Correct an ROE and go to step 23.

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Opening Sentence to ER to Request or Clarify ROE/RFS (2794): Select Request ROE Opening Sentence - claimant .

- Request for a Record of Employment (2797) .

- Select Initial Request for ROE .

- Select Start-end date of employment / End date of employment (2798) .

- Go to step 22.

- In ACS, send a registered copy of the Z-02-00-00 letter with the following attributes:

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794): Select Request ROE Opening Sentence — claimant .

- Request for a Record of Employment (2797): Select Follow up request for ROE .

- Previously requested by mail (2799):

- Date ROE requested: Enter the date the original letter was sent.

- End date of period of employment: Enter the employment end date.

- Date of BF: Enter 10 business days from the date the letter is sent.

- Attachment List for Z-02-00-00 (3133): Select Attached: Copy of original letter .

- Indicate on letter how letter mailed (2804): Select Sent by registered mail .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1564.dita)

- In NWS, create a REM WI using the new SIN as follows:

- Complexity: Select Level 1.

- Reason: Select Missing ROE .

- Comments: Type “The employer must issue a new ROE.”

- Due date: Enter 10 working days from the date on which a valid ROE was requested.

- Details: Type “SIN change. The employer issued an ROE with the old SIN although the new SIN is now valid. An interim ROE was created. The employer must issue a new ROE. If the employer does not comply, refer the file to Integrity.”

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Next Available User .

- Select Save . 

#### Updating the electronic file

Source topic: `en_EN/task/change_sin_init4less/updating_the_electronic_file_level_1.dita`

- In FTS, determine if there is a skeleton claim set up with the old SIN:

- If yes, go to step 24.

- If no, go to step 26.

- Select the File Control Data (M101) transaction to terminate the benefit period for the old SIN as follows:

- Claim Action: Select Terminate benefit period (M101-7) .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and cancel the registration assigned to the old SIN as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Cancel .

- Select Update .

- Determine if there are earlier BPCs established with the old SIN:

- If there are no earlier claims established with the old SIN, go to No earlier claims established .
               [No earlier claims established](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/change_sin_init4less#Noearlier)

- If there are earlier claims established with the old SIN, go to Earlier claims established .
               [Earlier claims established](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/change_sin_init4less#Earlier) 

#### No earlier claims established

Source topic: `en_EN/task/change_sin_init4less/no_earlier_claims_established_level_1.dita`

- In NWS, with the old SIN, determine if there is a WI related to the SIN change that was not deleted:

- If yes, complete the WI.

- If no, no further action is required. 

#### Earlier claims established

Source topic: `en_EN/task/change_sin_init4less/earlier_claims_established_level_1.dita`

- In FTS, using the old SIN, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the registration number assigned to the initial application with the old SIN.

- Memo (MPS): Check the box.

- Detection: Select 31 - Other new facts .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the request for a SIN change.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 34 - Social insurance number change .

- Remarks line 1: Type “SIN change to new SIN [new SIN].”

- Remarks line 2 to 4: Enter the appropriate options:

- The list of all BPCs with the old SIN.

- If a D15 is imposed from the BPC under the 900-series SIN for the same BPC that will be established with the permanent SIN and the D15 is not required for the permanent SIN, type “Do not transfer BPC [XXXX] from old SIN. BPC [XXXX] is on new SIN.”

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction to transfer the registration number to IPOC as follows:

- Registration number: Select the registration number assigned to the initial application with the old SIN.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- Determine if there is a WI related to the SIN change that was not deleted:

- If yes, complete the WI.

- If no, no further action is required. 

#### SIN change cannot be input — Unable to reach the client for missing information

Source topic: `en_EN/task/change_sin_init4less/sin_change_cannot_be_input__unable_to_r_79064342_level_1.dita`

- In NWS, using the old SIN create a record of decision (ROD) as follows:

- Comments: Type “Unable to reach the client.”

- Details: Type “15 - Claim Procedure disentitlement imposed — SIN change. New SIN not validated.”

- Select Save .

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose a D15 as follows:

- Registration number: Select the registration number assigned to the initial application with the old SIN.

- Action: Select Add .

- Disentitlement: Select 15 - Claim Procedure .

- BPC date: Check the box (the Start date is prefilled with 55/55/5555 ).

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976)

- D48 and D15 – Moved – Address unknown and claim procedure (3006)

- D15 - Claim procedure (3009)

- D15 - TEXT: insert appropriate reason for D15

- We / In addition, we (2687)

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- Indefinite disentitlement start date (1270)

- Text — Insert appropriate reason(s) (1618): Type the appropriate option:

- “you have not returned our call[s] following the message[s] left on [date[s]].”

- “you have not contacted us following the letter sent to you on [date].”

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Complete the WI related to the SIN change.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2504.dita) 

#### Note

Source topic: `en_EN/common_notes/note_c_2501.dita`

Note:

When an ROE issued under the permanent SIN contains a period of employment during which the client had a 900-series SIN, proof of the authorization to work in Canada is required for this period. 

#### Note

Source topic: `en_EN/common_notes/note_c_2502.dita`

Note:

In the Quebec region, do not create a WI. Using the consultative tool, inform the Business Expertise Advisor that the application must be deleted. 

#### Note

Source topic: `en_EN/common_notes/note_c_2503.dita`

Note:

All ROEs used to calculate the claim are entered as interim ROEs with the new SIN. An ROE under the 900-series SIN with the status Void - Not Insurable following a Canada Revenue Agency (CRA) insurability ruling must also be entered as an interim ROE under the new SIN with the status Void - Not Insurable . 

#### Note

Source topic: `en_EN/common_notes/note_c_2499.dita`

Note:

It is the client’s responsibility to provide the new SIN to the employer. Do not provide the new SIN to the employer. 

#### Note

Source topic: `en_EN/common_notes/note_c_1564.dita`

Note:

When sending a copy of an original letter, print the letter locally. For instructions on printing locally while teleworking, refer to Telework: Printing documents locally — Instructions .
       [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml)

     [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2504.dita`

Note:

A claim can be established with an expired SIN, but a D15 must be imposed to prevent payment of benefits until a valid SIN is provided. 

## Policy reference

Source topic: `en_EN/task/change_sin_init4less/policy_reference.dita`

 
