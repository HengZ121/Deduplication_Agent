# Converting a claim to family caregiver benefits

Source map: `en_EN/task/converting_ctfcb_convetir_depppa/converting_ctfcb_convetir_depppa.ditamap`

## Summary

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/summary.dita`

Summary: Clients receiving benefits who need to take time away from work to care for or support a critically ill or injured patient can request a conversion to family caregiver benefits. 

## What you need to know

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/untitled_section.dita`

The purpose of this task is to help processing officer s finalize conversion requests to family caregiver benefits.

Family caregiver benefits provide temporary income to eligible clients who take leave from work to care for a critically ill or injured patient. For more information on this benefit type (BT), the officer can refer to Family caregiver benefits — Knowledge .
       [Family caregiver benefits — Knowledge](/en/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml)

For a claim to be converted to family caregiver benefits, the client must meet the entitlement conditions. There are 2 types of family caregiver benefits: family caregiver benefits for adults and family caregiver benefits for children.

Conversions to family caregiver benefits for children or adults are assigned or reassigned to the Centre of Specialization. These conversions are processed in CPS, as long as there is no maternity, parental, family caregiver (opposite type) or CCB window on the claim. If there is an existing window for one of these BTs, the officer sends an Operational Centre Memo (MM06) to IPOC to convert the claim. When completing the MM06 , the officer must ensure that all information required for the conversion is included. This includes the BT being requested, the period for which the benefits are to be paid, the number of weeks being requested (if applicable), any required allocations, benefit period (BP) extensions, disentitlements, etc. 

### Family caregiver for children

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/family_caregiver_for_children.dita`

Family caregiver benefits for children provide temporary income to eligible clients who take leave from work to care for a critically ill or injured patient who is under the age of 18 at the time the family caregiver window (FCW) is established. A total of 35 weeks can be claimed during any given BP. If a critically ill or injured child turns 18 during the FCW, the client may continue to receive family caregiver benefits for children.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2897.dita) 

### Family caregiver benefits for adults

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/family_caregiver_benefits_for_adults.dita`

Family caregiver benefits for adults provide temporary income to eligible clients who take leave from work to care for a critically ill or injured patient who is 18 or older at the time the FCW is established. A total of 15 weeks can be claimed during any given BP. 

### Adjudicating new contentious issue(s)

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/adjudicating_new_contentious_issues.dita`

When converting a continuing claim, a client may report a new contentious issue (e.g. reason for separation [RFS], farming or availability) that must be adjudicated. If there is no existing WI for this issue, the Level 1 officer creates a Claim Review (CR) WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an Action Item (AI), Call Back (CB), Assessment Issue (ASMT) or Reminder (REM WI), the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### Effective date of a conversion

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/effective_date_of_a_conversion.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer can refer to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Return to work (RTW)

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/return_to_work_rtw.dita`

If there is an RTW on the claim that falls on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer refers the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### Subsequent claim

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/subsequent_claim.dita`

The renewal application can be used to establish a subsequent claim when the following conditions are met:

- The claim is renewed and there are 4 or fewer weeks of benefits remaining in the BP.

- The client has worked enough hours to establish a new claim.

ACP can register the subsequent claim if the Claim Assessment (CA) WI for a renewal or subsequent initial claim is finalized within 28 days of the renewal application.

When ACP cannot register the subsequent claim because the renewal is not processed within 28 days of the renewal application (i.e. REN WK not found or no match and polling limit exceeded is displayed on the Processing Activities tab in NWS) or when the claim was converted to MPS, the officer processing the CA Renewal WI creates a Reminder (REM) WI. This ensures that an officer will manually register the subsequent claim. 

### Qualifying for family caregiver benefits

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/qualifying_for_family_caregiver_benefits.dita`

In order to qualify for family caregiver benefits for adults or children, the client must meet all of the following conditions:

- The client has had an interruption of earnings .

- The client is major attached (has accumulated at least 600 hours of insurable employment in the qualifying period [QP]), or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment. If the client has a violation, the agent refers to Increased entrance requirements to determine how many hours are required.
         [Increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

**Qualifying for benefits with the common entrance requirement(CER)(from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits regardless of the conversion date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to family caregiver benefits

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/entitlement_to_family_caregiver_benefits.dita`

To be entitled to family caregiver benefits, a client must meet the following conditions:

- The client is an eligible family member or close relative . The officer refers to Family member: Definition — Table for a list of all eligible family members and close relatives.
         [Family member: Definition — Table](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

- The client submits an acceptable medical certificate . The medical doctor or nurse practitioner signing the medical certificate must attest that the patient’s life is at risk as a result of illness or injury, that there has been a significant change in the patient’s baseline state of health and that the patient requires the care or support of one or more family members. The officer refers to Determining if a medical certificate is acceptable — Family caregiver benefits .
         [Determining if a medical certificate is acceptable — Family caregiver benefits](/en/procedure/task/determining_pcic_med_cert.shtml) 

### Family caregiver window (FCW)

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/family_caregiver_window_fcw.dita`

The FCW is defined as the 52-week period during which family caregiver benefits for adults or children are payable. For more information, the officer refers to Establishing the family caregiver window .
       [Establishing the family caregiver window](/en/procedure/task/establishing_fbw_etablir_fpppa.shtml) 

### Sharing benefits

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/sharing_benefits.dita`

Family caregiver benefits can be shared between eligible family members within individual limits for each BT. Family caregiver benefits can be shared either at the same time or separately during the 52-week window. The officer can refer to Family member: Definition for information on acceptable family members.
       [Family member: Definition](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

The clients sharing the benefits must agree on the number of weeks each family member claims. Only weeks that have not yet been paid can be shared. When clients disagree on how to share the benefits, a Level 2 officer adjudicates the division of the remaining weeks.

For more information, the officer can refer to Adjudicating the sharing of family caregiver benefits — Disagreement on how to share weeks .
       [Adjudicating the sharing of family caregiver benefits — Disagreement on how to share weeks](/en/procedure/task/adjudicating_na_pcic_bw.shtml) 

### Otherwise available

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/otherwise_available.dita`

Clients do not need to prove that they would be otherwise available or otherwise working to access family caregiver benefits.

Clients who request sickness benefits during their FCW are not required to prove they would be otherwise available for work. When the sickness period extends beyond the FCW, clients must prove that they are otherwise available to work during this extension period and must submit a medical certificate indicating the start date of their incapacity and the expected recovery date. 

### Deferred reason for separation (RFS)

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/deferred_reason_for_separation_rfs.dita`

In some situations, when clients qualify for and request special benefits, fact-finding and adjudication of the contentious RFS can be deferred. For more information, the officer can refer to Deferral of adjudication .
       [Deferral of adjudication](/en/procedure/activity/deferral_adj.shtml) 

### Extending the benefit period (BP)

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/extending_the_benefit_period_bp.dita`

When the client did not receive the maximum entitlement during the initial BP, the BP can be extended to a maximum of 104 weeks to pay additional weeks of sickness, maternity, parental, CCB and family caregiver benefits. For more information on BP extensions for combined special benefits, the officer can refer to Benefit period extension for special benefits .
       [Benefit period extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Disentitlements

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/disentitlements.dita`

The following disentitlements related to family caregiver benefits are imposed when the client does not meet the entitlement conditions:

- 61 - Family caregiver benefits for children or adults - Does not meet entitlement conditions

- 62 - Family caregiver benefits for children or adults - Benefits exhausted

- 63 - Family caregiver benefits for children or adults - No medical proof

For more information, the officer can refer to Family caregiver: Information on benefits — Knowledge .
       [Family caregiver: Information on benefits — Knowledge](/en/procedure/generic/additionalresources/family_caregiver_benefits_knowledge.shtml) 

### Outstanding disentitlements

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/outstanding_disentitlements.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies to the conversion. A Level 1 officer can terminate or rescind the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision. If the information on file allows for the disentitlement to be terminated, the disentitlement is terminated on the Friday of the week before the conversion week.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2752.dita) 

### CCB and family caregiver benefits

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/ccb_and_family_caregiver_benefits.dita`

While family caregiver benefits and CCB may be combined, CCB cannot be paid for the same patient at the same time as family caregiver benefits. CCB can be paid either before the FCW opens or after it ends, but cannot be paid during an existing FCW for the same patient. The FCW does not end until the maximum entitlement weeks of family caregiver benefits have been paid or the 52-week window has ended. 

### Family caregiver benefits unit consultation

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/family_caregiver_benefits_unit_consultation.dita`

While performing reconsideration under EIA 112, the reconsideration officer may need to consult a family caregiver benefits unit officer to render a decision. The processing officer can refer to this table found under Additional resources to ensure the appropriate steps are taken.
       [table](/en/procedure/generic/additionalresources/reconsideration_referral_specialized_unit_instruction.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2897.dita`

Note:

Before December 3, 2017 these benefits were referred to as PCIC and were only payable to parents of the critically ill child, whereas now they are payable to a family member of the child.
       [family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

     [family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_2752.dita`

Note:

A client is not required to demonstrate good cause for delay when submitting a medical certificate. The Level 1 officer can modify or rescind a disentitlement related to a missing medical certificate for special benefits, regardless of the length of delay, provided all other conditions are met for the requested BT. 

## Regional considerations

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/in_nws.dita`

- Are there earnings, separation monies, motor vehicle accident compensation, workers’ compensation benefits (WCB) or wage loss insurance (WLI) payments to consider or allocate?

- Is there an Adjudication Issue (ADJ) WI?

- If yes, for what issue?

- Did the client indicate on the application that he or she is providing care or support for a critically ill family member?

- Are there any SROCs or WIs containing the CCB/Family Caregiver: INS5257 Authorization to release medical information – Form ?
         [CCB/Family Caregiver: INS5257 Authorization to release medical information – Form](http://forms-formulaires.prv/lc/content/EForms/en/Detail.html?Form=INS5257)

- Are there any SROCs or WIs containing the Family caregiver: INS5242B Medical certificate — Form ?
         [Family caregiver: INS5242B Medical certificate — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5242B.pdf)

- Have any INS5257 or INS5242B forms been uploaded? 

### In FTS:

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the last renewable week (LRW) been reached?

- Has the waiting period (WP) been served, waived or deferred?

- Is there an RTW on the claim?

- Are there any pending claimant’s reports or claimant’s reports to be processed before the conversion?

- Is there a registration number? 

### In RCM:

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/in_rcm.dita`

- Has an ROE been submitted?

- If yes, are there earnings, separation monies, motor vehicle accident compensation, WCB or WLI payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/in_imaging.dita`

- Is there any other documentation which may impact the conversion claim?

- Are there any documents containing the INS5257 or INS5242B forms? 

## Step by step

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/reviewing_the_file_level_1.dita`

- In FTS, determine if there is a registration number:

- If yes, go to step 2.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- Determine if the WP must be served:

- If yes, refer to Cancelling a benefit period . Go to step 3.
               [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml)

- If no , go to step 3.

- Determine if there are any weeks of family caregiver benefits remaining to be paid:

- If yes, go to step 4.

- If no, go to Maximum family caregiver benefits already paid.
               [Maximum family caregiver benefits already paid.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#maximum)

- In NWS and in FTS, determine if one of the following conditions exists to extend the BP:

- The client was incarcerated and has since been tried and has not been found guilty.

- The client received WCB payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If one of the conditions exists, refer to Extension of the benefit period and then go to step 5.
               [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions exist, go to step 5.

- Determine if the LRW has been reached:

- If no, go to step 6.

- If yes, go to Last renewable week (LRW) reached.
               [Last renewable week (LRW) reached.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#LRW)

- Determine the following:

- Did the client submit an acceptable medical certificate ?
               [acceptable medical certificate](/en/procedure/task/determining_pcic_med_cert.shtml)

- Is the client an eligible family member ?
               [eligible family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

- Does the client attest to providing care and support for a critically ill or injured patient ?
               [providing care and support for a critically ill or injured patient](/en/procedure/task/determining_pcic_benefit_child.shtml)

- If the answer was yes to all of the above criteria, go to step 7.

- If the answer was no to any of the above criteria, go to Not entitled to family caregiver benefits .
               [Not entitled to family caregiver benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#NotEntitledFCB)

- Determine if the client is entitled to all of the requested weeks of family caregiver benefits. Refer to Determining if the client is entitled to the family caregiver benefits weeks requested :

- If yes, go to step 8.

- If no, make a note to include the 62 - Family caregiver for children or adults - Benefits exhausted disentitlement ( D62 ) information in the letter and impose the disentitlement. Go to step 8.

- Determine if there are any other outstanding disentitlements on file:

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 9.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Details: Type “Outstanding [type of disentitlement] disentitlement.”

- Select Save .

- Refer to the appropriate procedure and go to step 9.

- If no, go to step 10.

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If no, reassign the WI to Level 2 and go to step 10.

- If yes, complete the steps from the appropriate procedure and go to step 10.

- Determine if there are any outstanding issues that require adjudication that do not have a related WI:

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 11.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Details: Indicate the reason the WI is being created.

- Select Save .

- Refer to the appropriate procedure and go to step 11.

- If no, go to step 12.

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If no, reassign the WI to Level 2 and go to step 12.

- If yes, complete the steps from the appropriate procedure and go to step 12.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine the FCW. If necessary, refer to Establishing the family caregiver window .

- In FTS, determine if the claim status (CS) is 8 - Converted to manual pay:

- If no, go to step 15.

- If yes, go to step 18.

- Determine if there is an existing window for the following BTs: maternity, parental, family caregiver or CCB:

- If yes, go to step 16.

- If no, go to Inputs .
               [Inputs](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#level1_item_4)

- Determine the BT of the existing window:

- If it is an FCW, go to step 17.

- If it is a maternity, parental or CCB window, go to step 18.

- Determine if the FCW is for the same BT and the same patient:

- If no, go to step 18.

- If yes, go to Inputs
               [Inputs](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#level1_item_4)

- Determine if, before submitting the Operational Centre Memo (MM06) to IPOC, a Level 2 officer must adjudicate any outstanding issues:

- If yes, go to step 19.

- If no, go to step 21.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “awaiting Level 2 decision.”

- Bring forward date: Enter today’s date + 10 business working days.

- When the WI moves to the current workload, determine if a decision has been rendered:

- If no, return to step 19.

- If yes, go to step 21. 

#### Inputs – Operational Centre Memo (MM06) transaction required

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/inputs__operational_centre_memo_mm06_tr_f7aac1cb_level_1.dita`

- In FTS, from the Caregiver/Compassionate care data entry (MCB1) screen, update the claimant record as follows:

- Action: Select Modify .

- Entitlement weeks: Enter the number of weeks the client is entitled to.

- BPC: Enter the appropriate date.

- Waiting period served: Select Yes or No .

- Application date: Enter the date the client requested family caregiver benefits.

- Status: Select 12 - Caregiver/Compassionate benefits approved .

- Select Update .

- Determine if the client is exempt from reporting:

- If yes, go to step 23.

- If no, go to step 24.

- In FTS, select the Renewal/Revised (M106) transaction and cancel the exemption by completing the following fields:

- Claimant’s Report:

- Rescind: Check the box.

- Select Update .

- On the Summary tab, determine if an MA01 is imposed:

- If yes, go to step 25.

- If no, select the Renewal/Revised (M106) transaction and impose the MA01 as follows:

- Registration Number: Leave the field blank. If a number is showing, remove it.

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the applicable registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select the appropriate option:

- If the claim has already been converted to MPS (CS 8): Select 30 - New information on manual pay claim .

- When the claim is not yet in MPS, select 51 - Family caregiver for children or 52 - Family caregiver for adults .

- Remarks line 1: Type “Conversion to claim type [20 or 21] as of w/c [XXXX]. Window from w/c [XXXX] to w/c [XXXX]. [number of weeks] weeks to be paid. Rescind the MA01.”

- Remarks line 2: If a disentitlement is required, type “D[XX] [XXXX-X] to [XXXX-X] OP CODE [XX] [X] [XX].” (e.g. D14 w/c 1800-2010 OP CODE 24C09)

- Remarks line 3: If an extension of the BP is required, type “Extend [type] [w/c start date] — [number of weeks]. If necessary, provide the NO-CR-CODE and the information from the WP [deferred or waived] and other [WP w/c served].”

- Remarks line 4: Enter your first name and last name.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, determine if there is a client Note to send a saved ACS letter:

- If yes, go to step 29.

- If no, go to step 30.

- In ACS, review and send the saved letter.

- In NWS, determine if the conversion application was submitted using AW:

- If no go to step 31.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#subsequent_claims)

- Complete the WI. 

#### Maximum family caregiver benefits already paid

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/maximum_family_caregiver_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for family caregiver benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “No renewal — maximum family caregiver benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No renewal or conversion is possible as the client cannot receive the requested family caregiver benefits. The client does not qualify for a new claim as zero hours were accumulated after the BPC. D62 imposed.”

- If the client has worked since the BPC , type “No renewal or conversion is possible as the client cannot receive the requested family caregiver benefits. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. D62 imposed.”

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine if the claim was converted from regular or sickness benefits:

- If yes, go to step 6.

- If no, go to step 10.

- In FTS, select the Renewal/Revised (M106) transaction and impose the D62 as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Claim type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Add .

- Disentitlement: Select 62 - Family caregiver for children or adults - Benefits exhausted .

- Start date: Select the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- On the Search tab, select Caregiver/Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, find the patient record as follows:

- Claimant’s SIN: Enter the client's SIN.

- Select Search .

- Select the patient record to access the Caregiver/Compassionate care data entry (MCB1) screen.

- Select Entitlement (M112) to access the Caregiver/Compassionate care entitlement (M112) screen:

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select A - Add .

- Start date: Leave the field blank.

- End date: Leave the field blank.

- Entitlement weeks: Leave the field blank.

- Status: Select 10 - Maximum number of caregiver/compassionate care benefit weeks paid for patient .

- Select Update .

- Go to step 12.

- In FTS, on the Caregiver/Compassionate care data entry (MCB1) screen, update the claimant record as follows:

- Action: Select Modify .

- Status: Select 10 - D52/D62 - Maximum number of caregiver/compassionate care benefit weeks paid for patient .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and impose the D62 as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Claim Type: Select 2- Regular .

- Action: Select Add .

- Disentitlement: Select 62 - Family caregiver benefits for children or adults - Benefits exhausted .

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): “We cannot reactivate your claim for Employment Insurance benefits starting [renewal week - Sunday’s date] as you have received the maximum number of benefit weeks payable to you during this benefit period. To receive family caregiver benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you will have to file a new claim.”

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Last renewable week (LRW) reached

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/last_renewable_week_lrw_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for family caregiver benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “LRW reached — family caregiver benefits requested.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No renewal or conversion is possible as LRW has been reached and no BP extension is possible. Client does not qualify for a new claim as zero hours were accumulated after the BPC.”

- If the client has worked since the BPC , type “No renewal or conversion is possible as LRW has been reached and no BP extension possible. Client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): “We cannot reactivate your claim for Employment Insurance benefits starting [Renewal week - Sunday’s date] . Please note that we are required to advise you of all decisions made on your claim. No family caregiver benefits are payable to you on this claim because the last renewal week has been reached on this benefit period. To receive family caregiver benefits, you must work the required minimum number of insurable employment hours. If you want to receive family caregiver benefits in the future, you will have to file a new claim.”

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No.

- Complete: Select C - Yes.

- Select Update .

- In NWS, complete the WI. 

#### Not entitled to family caregiver benefits

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/not_entitled_to_family_caregiver_benefits_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “D61 or D63 imposed (choose the appropriate disentitlement). Entitlement not proven — family caregiver benefits.”

- Details: Type the appropriate options:

- “D61 imposed effective [date]. The client is not entitled to benefits. The client is not providing care or support to the critically ill or injured patient.”

- “D61 imposed effective [date]. The client is not entitled to benefits. The client is not recognized as a family member of the critically ill or injured patient.”

- “D63 imposed effective [date]. The client is not entitled to benefits. The client did not submit an acceptable medical certificate.”

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine if the claim was converted from regular or sickness benefits:

- If yes and there is not currently a window for maternity, parental, compassionate care or family caregiver (adults or children), go to step 4.

- If yes and there is currently a window for maternity, parental, compassionate care or family caregiver (adults or children), go to step 8.

- If no, go to step 8.

- In FTS, select the Renewal/Revised (M106) transaction to input the conversion and impose the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if applicable).

- Claim type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Add .

- Disentitlement: Select the appropriate disentitlement:

- 61 - Family caregiver for children or adult - Does not meet caregiver entitlement

- 63 - Family caregiver for children or adult - No medical proof

- Start date: Select the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- On the Search tab, select Caregiver/Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, find the patient record as follows:

- Claimant’s SIN: Enter the client's SIN.

- Select Search .

- Select the patient record to access the Caregiver/Compassionate care data entry (MCB1) screen.

- Select Entitlement (M112) to access the Caregiver/Compassionate care entitlement (M112) screen:

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Add .

- Start date: Leave the field blank.

- End date: Leave the field blank.

- Entitlement weeks: Leave the field blank.

- Status: Select the appropriate option:

- 11 - Missing certificate

- 13 - Not a family member

- 14 - Inadequate medical certificate

- 16 - Medical certificate not issued by a medical practitioner

- Select Update .

- Go to step 10.

- In FTS, on the Caregiver/Compassionate care data entry (MCB1) screen, update the claimant record as follows:

- Action: Select Modify .

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Status: Select the appropriate option:

- 11 - Missing certificate

- 13 - Not a family member

- 14 - Inadequate medical certificate

- 16 - Medical certificate not issued by a medical practitioner

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and impose the D61 or D63 as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select the appropriate option:

- 61 - Family caregiver for children or adult - Does not meet caregiver entitlement

- 63 - Family caregiver for children or adult - No medical proof

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send or add to the saved N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246) .

- Antedate denied or postdate message - Initial/Renewal/Continuing claim (2481) .

- Special benefits denied (3065): Select Compassionate care benefits denied - D61/D62/D63/Free text (3084) .

- Allocation of Earnings (2516)

- Waiting period messages (2445 ) (if the client has not served the WP): Select the appropriate option.

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Inputs

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/inputs_level_1.dita`

- Determine if the conversion is on a renewal claim:

- If the conversion is on a renewal claim, go to step 2.

- If the conversion is on a continuing claim, go to Conversion on a continuing claim .
               [Conversion on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#ConversionContinuingClaim)

- In NWS, determine if there is an outstanding ADJ WI :

- If no, go to Conversion on a renewal — No outstanding adjudication .
               [Conversion on a renewal — No outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#ConversionRenewalNoADJ)

- If yes, go to Conversion on a renewal — Outstanding adjudication .
               [Conversion on a renewal — Outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#ConversionRenewalADJ) 

#### Conversion on a continuing claim

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/conversion_on_a_continuing_claim_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival week: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if applicable).

- Claim type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Manual action: Select the appropriate option only if Level 2 adjudication is required.

- No claimant’s report: If requested by client, check the box.

- Contentious: Select the appropriate option:

- If the conversion did not require Level 2 adjudication, select 1 - No .

- If the conversion required Level 2 adjudication, select 2 - Yes .

- Complete: Select the appropriate option:

- If the Level 2 adjudication is required, select D - No to leave the registration number open for subsequent transactions.

- If the Level 2 adjudication is not required, select C - Yes to complete the registration number.

- Select Update .

- On the Search tab, select Caregiver/Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, find the patient record as follows:

- Claimant’s SIN: Enter the client's SIN.

- Select Search .

- Select the patient record to access the Caregiver/Compassionate care data entry (MCB1) screen.

- Determine if there is an existing FCW for the same BT and the same patient:

- If no, go to step 5.

- If yes, go to step 6.

- Select Entitlement (M112) to access the Caregiver/Compassionate care entitlement (M112) screen:

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Add .

- Start date: Enter the start date of the FCW.

- End date: Leave this field blank.

- Entitlement weeks: Enter the number of entitlement weeks.

- Status: Select 12 - Caregiver/Compassionate benefits approved .

- Select Update .

- Go to step 7.

- Select Entitlement (M112) to access the Caregiver/Compassionate care entitlement (M112) screen:

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Modify .

- Start date: Leave this field blank.

- End date: Leave this field blank.

- Entitlement weeks: Enter the number of entitlement weeks.

- Status: Select 12 - Caregiver/Compassionate benefits approved .

- Select Update .

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement is being imposed.

- There is an indefinite disqualification on file.

- If yes, go to step 8.

- If no, go to step 9.

- In ACS, create and save or add to the saved N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246) .

- Antedate denied or postdate message - Initial/Renewal/Continuing claim (2481) .

- Special benefits denied (3065): Select Compassionate care benefits denied - D61/D62/D63/Free text (3084) .

- Allocation of Earnings (2516) .

- Waiting period messages (2445) (If the client has not served the WP): Select the appropriate option.

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- Determine if Level 2 adjudication required:

- If yes, in NWS, create a client Note and type “Send the N-00-00-00 letter.” Go to step 10.

- If no, send the N-00-00-00 letter and go to step 11.

- In NWS, reassign any CR WI for the contentious issue to Level 2 as follows:

- Destination — SCC: Enter the SCC as shown in FTS.

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Not within Level 1 authority.”

- Go to step 11.

           [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2751.dita)

- In NWS, complete the CR Conversion WI. 

#### Conversion on a renewal claim — No outstanding adjudication

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/conversion_on_a_renewal_claim__no_outst_8874a6e6_level_1.dita`

- In FTS, select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if applicable).

- Claim type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- No claimant’s report: If requested by client, check the box.

- Contentious: Select the appropriate option:

- If the renewal did not require Level 2 adjudication, select 1 - No .

- If the renewal required Level 2 adjudication, select 2 - Yes .

- Complete: To complete the registration number, select C - Yes .

- Select Update .

- On the Search tab, select Caregiver/Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, find the patient record as follows:

- Claimant’s SIN: Enter the client's SIN.

- Select Search .

- Select the patient record to access the Caregiver/Compassionate care data entry (MCB1) screen.

- Determine if there is an existing FCW for the same BT and the same patient:

- If no, go to step 5.

- If yes, go to step 6.

- Select Entitlement (M112) to access the Caregiver/Compassionate care-Claimant entitlement (M112) screen.

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Add .

- Start date: Enter the start date of the FCW.

- End date: Enter the end date of the FCW.

- Entitlement weeks: Enter the number of entitlement weeks

- Waiting period served: Select Yes or No .

- Status: Select 12 - Caregiver/Compassionate benefits approved .

- Select Update .

- Go to step 7.

- Select Entitlement (M112) to access the Caregiver/Compassionate care entitlement (M112) screen:

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Modify .

- Start date: Leave this field blank.

- End date: Leave this field blank.

- Entitlement weeks: Enter the number of entitlement weeks.

- Status: Select 12 - Caregiver/Compassionate benefits approved .

- Select Update .

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement or definite disqualification is imposed.

- If yes, go to step 8.

- If no, go to step 9.

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246)

- Antedate denied or postdate message - Initial/Renewal/Continuing claim (2481) .

- Special benefits denied (3065): Select Compassionate care benefits denied - D61/D62/D63/Free text (3084) .

- Allocation of Earnings (2516) .

- Waiting period messages (2445) (If the client has not served the WP): Select the appropriate option.

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In NWS, determine if the conversion application was submitted using AW:

- If no go to step 10.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#subsequent_claims)

- Complete the WI. 

#### Conversion on a renewal claim — Outstanding adjudication

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/conversion_on_a_renewal_claim__outstand_c972fb4d_level_1.dita`

- Determine if the Level 2 officer has rendered a decision for the outstanding issues:

- If no, go to step 2.

- If yes, go to step 4.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting Level 2 decision.”

- Bring forward date: Enter today's date + 10 business days

- When the WI moves to the current workload, determine if a decision has been rendered:

- If no, return to step 2.

- If yes, go to step 4.

- In FTS, select the Renewal/Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if applicable).

- Claim type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Manual action: Select the appropriate option only if Level 2 adjudication is required.

- No claimant’s report: If requested by client, check the box.

- Contentious: Select the appropriate option:

- If the renewal did not require Level 2 adjudication, select 1 - No .

- If the renewal required Level 2 adjudication, select 2 - Yes .

- Complete: To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- On the Search tab, select Caregiver/Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, find the patient record as follows:

- Claimant’s SIN: Enter the client's SIN.

- Select Search .

- Select the patient record to access the Caregiver/Compassionate care data entry (MCB1) screen.

- Determine if there is an existing FCW for the same BT and the same patient:

- If no, go to step 8.

- If yes, go to step 9.

- Select Entitlement (M112) to access the Caregiver/Compassionate care-Claimant entitlement (M112) screen.

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Add .

- Start date: Enter the start date of the FCW.

- End date: Enter the end date of the FCW.

- Entitlement weeks: Enter the number of entitlement weeks.

- Waiting period served: Select Yes or No .

- Status: Select 12 - Caregiver/Compassionate benefits approved .

- Select Update .

- Go to step 10.

- Select Entitlement (M112) to access the Caregiver/Compassionate care entitlement (M112) screen:

- Type: Select the appropriate option:

- 20 - Family caregiver for children

- 21 - Family caregiver for adults

- Action: Select Modify .

- Start date: Leave this field blank.

- End date: Leave this field blank.

- Entitlement weeks: Enter the number of entitlement weeks.

- Status: Select 12 - Caregiver/Compassionate benefits approved .

- Select Update .

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- There is an indefinite disqualification on file.

- A disentitlement or definite disqualification is being imposed manually.

- If yes, go to step 11.

- If no, go to step 13.

- In ACS, create and save the N-00-00-00. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246)

- Antedate denied or postdate message - Initial/Renewal/Continuing claim (2481) .

- Special benefits denied (3065): Select Compassionate care benefits denied - D61/D62/D63/Free text (3084) .

- Allocation of Earnings (2516) .

- Waiting period messages (2445) (If the client has not served the WP): Select the appropriate option.

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In NWS, create a client Note and type “Send the N-00-00-00 letter.”

- Determine if the conversion application was submitted using AW:

- If no go to step 14.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/converting_ctfcb_convetir_depppa#subsequent_claims)

- Complete the WI. 

#### Subsequent claims

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/subsequent_claims_level_1.dita`

- Determine if there are 4 weeks or fewer of benefits payable remaining in the BP:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the renewal was finalized 28 calendar days after the renewal application was submitted (i.e. application date + 27 days) or if the Status field on the Summary tab in FTS is 8 - Converted to Manual Pay:

- If yes, go to step 3.

- If no, go to step 4.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Subsequent claim not automated.”

- Due date: Select the [LRW + 3 weeks].

- Language: Select the appropriate option.

- Details: Type “Subsequent claim to be established.”

- Destination — SCC : Select the SCC as shown in FTS.

- End User: Select Next available user .

- Complete the CA WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2721.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose an MA1 to stop payment. 

#### Info

Source topic: `en_EN/common_notes/note_c_2751.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose an MA1 to stop payment. 

## Policy reference

Source topic: `en_EN/task/converting_ctfcb_convetir_depppa/policy_reference.dita`

 
