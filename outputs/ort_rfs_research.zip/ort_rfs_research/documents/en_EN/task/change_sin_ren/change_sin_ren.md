# Changing a SIN — Renewal claim

Source map: `en_EN/task/change_sin_ren/change_sin_ren.ditamap`

## Summary

Source topic: `en_EN/task/change_sin_ren/summary.dita`

Summary: When clients on a renewal claim report that their SIN has changed, the officer replace s the old SIN on the clients’ EI records with the new SIN. 

## What you need to know

Source topic: `en_EN/task/change_sin_ren/what_you_need_to_know.dita`

### Receiving notification of a new SIN

Source topic: `en_EN/task/change_sin_ren/receiving_notification_of_a_new_sin.dita`

A client may receive a new SIN at any time during the claim. The client can report the change in person, by telephone or by mail. Therefore, the WI to action the SIN change can be a SIR Validation (SIR), an Action Item (AI), a Claim Review (CR) or a Claim Assessment (CA) WI. When notification of a new SIN is received, the officer confirms the new SIN in the Social Insurance Registry (SIR) database before making any changes to the records. 

### Updating the ROEs

Source topic: `en_EN/task/change_sin_ren/updating_the_roes.dita`

All paper and electronic ROEs in RCM that were issued with the old SIN and used to calculate the claim must be re-entered as interim ROEs with the new SIN. This applies to both paper and electronic ROEs. In addition, the processing officer documents the SIN change under both the new and old SIN and submits the information to IPOC using an Operational Centre Memo (MM06) transaction . An IPOC officer then takes all the required actions related to the SIN change on any continuing, renewal, or dormant claims.
       [interim ROEs](/en/procedure/activity/interim_roe.shtml)

The processing officer ensures that all ROEs issued since the new SIN became active have been correctly issued with the new SIN. If an employer issues an ROE with the old SIN and the new SIN is already valid, the officer deletes the ROE and asks the employer to reissue the ROE with the new SIN. In addition to creating an interim ROE, the officer creates a Reminder (REM) WI while awaiting the ROE. 

### Updating the electronic file

Source topic: `en_EN/task/change_sin_ren/updating_the_electronic_file.dita`

An IPOC officer updates the electronic file of a renewal claim.

If the client applies for a renewal claim with the new SIN, a new initial claim is created. The officer instructs IPOC to cancel the new initial claim on the MM06.

The officer determines if there are dormant claims and includes these BPCs on the MM06.

The officer completes the renewal before changing the SIN to allow the renewal to be processed in a timely manner. The officer can then send the MM06 to IPOC.

Completing the renewal first ensures that the client receives a notice to submit claimant’s reports. IPOC transfers all processed claimant’s reports to the new SIN. IPOC also processes any additional claimant’s reports that are rejected while IPOC is completing the updates. 

### Issuing a temporary access code

Source topic: `en_EN/task/change_sin_ren/issuing_a_temporary_access_code.dita`

When clients receive a new SIN, they cannot use the access code linked to the old SIN, and the officer cannot re-issue it. Once an IPOC officer has updated the electronic file with the new SIN, the officer contacts the client to issue a temporary access code. For more information, the officer refers to Issuing an access code .
       [Issuing an access code](/en/procedure/task/replacing_ac.shtml) 

## Regional considerations

Source topic: `en_EN/task/change_sin_ren/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/change_sin_ren/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/change_sin_ren/in_fts.dita`

- What is the personal information on the application with the old SIN?

- Are there any BPCs that were established using the old SIN?

- Is there a registration number?

- Are there any disentitlements imposed (e.g. D15, D3)? 

### In NWS:

Source topic: `en_EN/task/change_sin_ren/in_nws.dita`

- Is there documentation related to the SIN change? 

### In Imaging:

Source topic: `en_EN/task/change_sin_ren/in_imaging.dita`

- Is there documentation related to the SIN change? 

### In SIR:

Source topic: `en_EN/task/change_sin_ren/in_sir.dita`

- Does the information in the SIR database with the client’s new SIN match the personal information found on the original application (old SIN)? 

### In RCM:

Source topic: `en_EN/task/change_sin_ren/in_rcm.dita`

- What types of ROEs have been submitted (what is the serial number series)? 

## Step by step

Source topic: `en_EN/task/change_sin_ren/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/change_sin_ren/level_1.dita`

#### Determining if the SIN change can be input

Source topic: `en_EN/task/change_sin_ren/determining_if_the_sin_change_can_be_input_level_1.dita`

- In SIR, compare the following SIR database information with the client’s new SIN to the original initial application with the old SIN:

- full name

- parent’s last name at birth (AW application only)

- If there are differences, go to step 2.

- If there are no differences, go to step 5.

- Fact-find with the client.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 4.

- If the client was not reached or did not reply to the N10-00-00 letter, go to SIN change cannot be input — Unable to reach the client to obtain missing information .
               [SIN change cannot be input — Unable to reach the client to obtain missing information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/change_sin_ren#D15)

- In NWS, on the claim with the old SIN, add details to the draft SROC created during fact-finding or create a new SROC on the claim with the old SIN as follows:

- Main Issue: Select Other .

- Comments: Type “SIN change — permanent SIN obtained.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 

#### SIN change can be input

Source topic: `en_EN/task/change_sin_ren/sin_change_can_be_input_level_1.dita`

- In NWS, on the claim with the old SIN, add details to the draft SROC created during fact-finding or create a new SROC on the claim with the old SIN as follows:

- Main Issue: Select Other .

- Comments: Type “SIN change — permanent SIN obtained.”

- Details: Type “New SIN — [new SIN].” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- In NWS, create an external SROC with the new SIN as follows:

- Main Issue: Select Other .

- Comments: Type “SIN change.”

- Details: Type “New SIN obtained — old SIN is [old SIN].”

- Select Save .

- In RCM, create an interim ROE with the new SIN for each ROE that affects the current claim and was input with the old SIN as follows:

- On the Input screen, complete the fields as follows:

- Social Insurance No.: Enter the new SIN.

- Serial Number: Leave this field blank.

- Serial Number of amended ROE or replaced: Leave this field blank.

- Interim ROE Type: Select Regular Interim or Fishing Interim .

- Printing Language: Select the language used on the original ROE.

- Select Submit .

- On the Input Regular ROE or Input Fishing ROE screen, enter the same information as shown on the original ROE with the old SIN.

- Additional information: Type “SIN change — old SIN [old SIN and serial number of original ROE].”

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2498.dita)

- For all the ROEs issued with the old SIN, determine the ROE issue date:

- If the issue date is after the effective date of the new SIN, go to step 9.

- If the issue date is before the effective date of the new SIN, go to step 21.

- In RCM, delete each ROE that was incorrectly issued with the old SIN as follows:

- Select Search/Correct .

- Social Insurance No.: Enter the old SIN.

- Serial Number: Leave this field blank.

- Select Submit .

- Select a serial number to open an ROE.

- Status: Check the Delete box.

- Additional information: Type “SIN change — [new SIN].”

- Select Submit .

- Fact-find with the employer and do the following:

- Advise the employer to reissue the ROE with the new SIN.

- Inform the employer that the ROE issued with the old SIN has been deleted.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2499.dita)

- Determine if the employer was reached during fact-finding:

- If the employer was reached, go to step 12.

- If the employer was not reached or did not reply to the Z-02-00-00 letter, go to step 19.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC with the new SIN as follows:

- Main issue: Select ROE .

- Comments: Type “SIN change — [new SIN].”

- Details: Type “[Employer’s name] incorrectly issued the record of employment with the old SIN.” If necessary, type “Unable to contact the employer by telephone — a second letter was sent.” Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- Select Save .

- Determine if the employer states the ROE will be provided:

- If yes and the employer is faxing the ROE to Service Canada, go to step 14.

- If yes and the employer will issue the electronic ROE in a timely manner, go to step 14.

- If yes and the employer will provide the client with a paper ROE or true copy of the original paper ROE, go to 14.

- If no, go to step 18.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select ROE .

- Comments: Type “ROE request.”

- Bring forward date: Do one of the following:

- If the employer is faxing the ROE, enter today’s date + 2 business days.

- If the employer indicated that the electronic ROE will be issued in a timely manner, enter today’s date + 5 business days.

- If the employer is sending a paper ROE, enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if the ROE is displayed in RMDS or RCM:

- If the ROE is not displayed in RMDS or RCM, go to step 16.

- If the ROE is displayed in RCM, go to step 21.

- Determine if the paper copy, or an uploaded or faxed copy of the ROE has been received:

- If the ROE was not received and the bring-forward date is not reached, return to step 14.

- If an uploaded or faxed copy of a paper ROE was received, go to step 17.

- If a copy of the ROE has not been received and the bring-forward date is reached, go to step 18.

- In RCM, enter the ROE by referring to Data entry — Paper document . If the ROE that was entered has validation errors, correct the errors by referring to Correct an ROE and go to step 21.

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Opening Sentence to ER to Request or Clarify ROE/RFS (2794): Select Request ROE Opening Sentence - claimant .

- Request for a Record of Employment (2797) .

- Select Initial Request for ROE .

- Select Start-end date of employment / End date of employment (2798) .

- Go to step 20.

- In ACS, send a registered copy of the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794): Select Request ROE Opening Sentence — claimant .

- Request for a Record of Employment (2797): Select Follow up request for ROE .

- Previously requested by mail (2799):

- Date ROE requested: Type the date the original letter was sent.

- End date of period of employment: Type the employment end date.

- Date of BF: Enter 10 business days from the date the letter is sent.

- Attachment List for Z-02-00-00 (3133): Copy of original letter .

- Indicate on letter how letter mailed (2804): Sent by registered mail .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1564.dita)

- In NWS, create a REM WI with the new SIN as follows:

- Complexity: Select Level 1.

- Reason: Select Missing ROE .

- Comments: Type “The employer must issue a new ROE.”

- Due date: Enter 10 working days from the date on which a valid ROE was requested.

- Details: Type “SIN change. The employer issued an ROE with the old SIN although the new SIN was already valid. An interim ROE was created. The employer must issue a new ROE. If the employer does not comply, refer the file to Integrity.”

- Destination — SCC: Select the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next Available User .

- In FTS, with the old SIN, determine if there is a registration number for the SIN issue:

- If yes, go to step 22.

- If no, select the Registration Number(M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Refer to Conversion and Renewal to complete the renewal, and then return to step 23.

- After calculating the renewal, move the SIN-related WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “SIN change on renewal.”

- Bring forward date: Enter today’s date + 1 business day.

- When the SIN-related WI moves to your current workload, in FTS, with the old SIN select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the request for a SIN change.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 34 - Social insurance number change .

- Remarks Line 1: Type “SIN change to [new SIN].”

- Remarks Line 2: Enter the list of all BPCs (dormant and current) with old SIN.

- Remarks Line 3: Enter “New initial claim created with new SIN needs to be cancelled”.

- Remarks Line 4: Leave this field blank unless needed for BPCs.

- Remarks Line 5: Enter your name and telephone number.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction to transfer the registration number to IPOC as follows:

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, create a REM WI using the new SIN as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Review access code after SIN change.”

- Due date: Enter 7 working days from the date on which the Operational Centre Memo (MM06) transaction was sent to IPOC.

- Details: Type “SIN change. Once the electronic file has been updated with the new SIN, determine if an access code appears in FTS. If no, contact the client, conduct a detailed security check and issue a temporary access code. If yes, complete the REM WI.”

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Send to my pending workload: Check the box.

- Complete the WI related to the SIN change. 

#### SIN change cannot be input — Unable to reach the client for missing information

Source topic: `en_EN/task/change_sin_ren/sin_change_cannot_be_input__unable_to_r_79064342_level_1.dita`

- In NWS, with the old SIN create a record of decision as follows:

- Comments: Type “Unable to reach the client.”

- Details: Type “15 - Claim Procedure disentitlement imposed — SIN change. New SIN not validated.”

- Select Save .

- In FTS, determine if there is a registration number for the SIN issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose a D15 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 15 - Claim Procedure .

- Start date: Enter the disentitlement start date (the Monday of the next claimant’s report period).

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitle m ent review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976)

- D48 and D15 – Moved – Address unknown and claim procedure (3006)

- D15 - Claim procedure (3009): Select D15 — TEXT: insert appropriate reason for D15 and type the reason for the D15.

- We / In addition, we (2687)

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select Indefinite disentitlement start date .

- Text — Insert appropriate reason(s) (1618): Type either “Although the telephone messages were left on [insert dates], you have not returned our calls” or “Following the letter we sent you on [insert date], you have not contacted us.”

- In NWS create a client Note and type “Send the saved D-01-00-00 letter.”

- Complete the WI related to the SIN change. 

#### Note

Source topic: `en_EN/common_notes/note_c_2498.dita`

Note:

All ROEs used to calculate the claim are entered as interim ROEs with the new SIN. 

#### Note

Source topic: `en_EN/common_notes/note_c_2499.dita`

Note:

It is the client’s responsibility to provide the new SIN to the employer. Do not provide the new SIN to the employer. 

#### Note

Source topic: `en_EN/common_notes/note_c_1564.dita`

Note:

When sending a copy of an original letter, print the letter locally. For instructions on printing locally while teleworking, refer to Telework: Printing documents locally — Instructions .
       [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml)

     [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml) 

## Policy reference

Source topic: `en_EN/task/change_sin_ren/policy_reference.dita`

 
