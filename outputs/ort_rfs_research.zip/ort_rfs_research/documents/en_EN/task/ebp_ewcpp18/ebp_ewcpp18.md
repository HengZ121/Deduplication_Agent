# Extending the benefit period: Earnings

Source map: `en_EN/task/ebp_ewcpp18/ebp_ewcpp18.ditamap`

## Summary

Source topic: `en_EN/task/ebp_ewcpp18/summary.dita`

Summary: On a renewal or continuing claim, it may be possible to extend the benefit period (BP) when a client receives workers’ compensation benefits, preventive withdrawal payments or monies on separation and the allocation of these monies prevents the payment of EI benefits. 

## What you need to know

Source topic: `en_EN/task/ebp_ewcpp18/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/ebp_ewcpp18/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3291.dita) 

### Extending the benefit period (BP)

Source topic: `en_EN/task/ebp_ewcpp18/extending_the_benefit_period_bp.dita`

A BP extension can be granted when payment of EI benefits is prevented due to an allocation of earnings from workers’ compensation benefits, preventive withdrawal payments or monies following a complete and final severance.

**Maximum benefit period (BP) extension**

The maximum BP extension is 52 weeks. Therefore, the BP cannot be more than 104 weeks. A BP extension does not change the maximum entitlement to benefits .
       [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml) 

### Extending the benefit period (BP) due to earnings

Source topic: `en_EN/task/ebp_ewcpp18/extending_the_benefit_period_bp_due_to_earnings.dita`

A BP extension can be granted when the payment of EI benefits is prevented due to an allocation of earnings from workers’ compensation benefits, preventive withdrawal payments or monies following a complete and final separation from employment.

When the allocation prevents the client from serving the WP, this is the same as preventing the payment of benefits. Therefore, a BP extension can be granted for each week that the WP cannot be served due to the allocation.

**Workers’ compensation benefits**

Workers’ compensation benefits are administered by the provinces and territories. It provides financial assistance to employees who have suffered a workplace injury or an occupational disease. Only payments meant as a replacement for “loss of income” are considered earnings for EI benefit purposes.

**Preventive withdrawal**

Preventive withdrawal is paid by the Commission des normes, de l'équité, de la santé et de la sécurité du travail when a job causes risk to the unborn child or to the mother.

**Monies on separation**

Monies on separation are monies that an employer pays to an employee when they have terminated the employer/employee relationship. 

### Pilot Project No. 24: Separation monies — w/c 2493 to w/c2572

Source topic: `en_EN/task/ebp_ewcpp18/pilot_project_no_24_separation_monies___97f46b0b.dita`

A temporary measure under Pilot Project No. 24 applies to separation monies paid due to a separation from employment on claims with a BPC or allocation start date between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). When separation monies are paid for that period, they are not allocated. Separation monies that are not allocated cannot extend a benefit period (BP). This measure applies to all benefit types (BTs) for initial, renewal and continuing claims.

To be considered under the temporary measures, one of the following conditions must be met:

- the BPC is between March 30, 2025 (w/c 2493), and October 10 , 2026 (w/c 2572 ).

- the separation monies would otherwise be allocated under EIR 36(9) to 36(11) and the first week of allocation falls within the period beginning March 30, 2025 (w/c 2493) to October 10 , 2026 (w/c 2572 ).
         [EIR 36(9)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285) 
         [36(11)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285) 

### Budget 2021

Source topic: `en_EN/task/ebp_ewcpp18/budget_2021.dita`

A Budget 2021 measure applies to separation monies that are reviewed between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361) and are paid due to a temporary layoff or a permanent separation from employment. When separation monies are reviewed during that period, they are not considered earnings and are not allocated regardless of the BPC. Separation monies that are not allocated cannot extend a BP. This measure applies to all benefit types (BTs) for initial, renewal and continuing claims. 

### End of temporary measure

Source topic: `en_EN/task/ebp_ewcpp18/end_of_temporary_measure.dita`

The Budget 2021 temporary measure under which separation monies were no longer considered earnings expires on September 24, 2022 (w/c 2361). As of September 25, 2022 (w/c 2362), separation monies are again considered earnings and a transitional provision applies to ensure that clients are not penalized by a late review.

New allocations with an allocation start date on or after September 25, 2022 (w/c 2362) apply to initial, renewal and continuing claims and could extend the BP, if necessary. 

### Modifying an existing allocation

Source topic: `en_EN/task/ebp_ewcpp18/modifying_an_existing_allocation.dita`

When modifying an existing allocation, the rules that applied to that claim when the allocation was initially inputted still apply. 

### Transitional provision

Source topic: `en_EN/task/ebp_ewcpp18/transitional_provision.dita`

As of September 25, 2022 (w/c 2362), when reviewing separation monies, if the allocation start date is between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361), monies paid or payable due to a temporary layoff or a permanent separation from employment are not considered earnings and are not allocated. The allocation start date is the date the allocation would start, even if no BP was established for that period.

For more information, officers consult the BE Memo 2022-04 .
       [BE Memo 2022-04](/en/policy/bememo/be2022_04.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3292.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3293.dita) 

### Exceptions

Source topic: `en_EN/task/ebp_ewcpp18/exceptions.dita`

Weeks that were paid or considered payable cannot be used for a BP extension.

For additional information on the deduction of earnings beyond the waiting period (WP), refer to Earnings: Earnings deduction calculation — Table .
       [Earnings: Earnings deduction calculation — Table](/en/procedure/generic/additionalresources/bp_erw_table.shtml) 

### Acceptable proof

Source topic: `en_EN/task/ebp_ewcpp18/acceptable_proof.dita`

A client’s statement can be accepted as sufficient proof to allow the extension and no further supporting documentation is required. 

### Permanent separation from employment

Source topic: `en_EN/task/ebp_ewcpp18/permanent_separation_from_employment.dita`

A permanent separation from employment refers to the full and final severance in the employer-employee relationship. This occurs when the client retires, quits, is dismissed by his employer or is laid off with no expectation of recall (i.e. block 14 indicates Not returning ).

Additionally, a complete severance from employment is presumed to occur when all 3 of the following conditions are met:

- severance pay or pay in lieu of notice is paid;

- the reason for separation on the ROE is A, E, K or M ;

- block 14 on the ROE indicates Unknown , Not Returning or is left blank.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3294.dita) 

### Earnings for a partial week

Source topic: `en_EN/task/ebp_ewcpp18/earnings_for_a_partial_week.dita`

If an allocation prevents payment of a partial week of benefits, it is possible to extend the BP.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3295.dita) 

### Definition of a paid week

Source topic: `en_EN/task/ebp_ewcpp18/definition_of_a_paid_week.dita`

A paid week is any of the following:

- At least $1.00 of benefits has been paid.

- The client serves one week of a definite disqualification.

- The benefits were used to reimburse an overpayment or a penalty under Section 38 .
         [Section 38](http://lois.justice.gc.ca/eng/acts/E-5.6/section-38.html)

- Benefits were withheld for assignment of benefits.

- Benefits were withheld pursuant to a family order agreement.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3296.dita) 

### Last week worked

Source topic: `en_EN/task/ebp_ewcpp18/last_week_worked.dita`

When considering a BP extension, the officer must determine if the earnings for the last week worked are sufficient to prevent payment of benefits. If the earnings last week worked prevent payment, no BP extension applies. If the earnings last week worked do not prevent payment, the officer must consider the sum of the earnings last week worked and the other monies (workers’ compensation, monies on separation monies or preventative withdrawal). If no benefits are payable after both types of earnings are considered, a BP extension applies. For additional information on conditions that prevent the client from serving the WP, the officer can refer to Waiting period: Conditions that prevent the waiting period from being served — Table .
       [Waiting period: Conditions that prevent the waiting period from being served — Table](/en/procedure/generic/additionalresources/bp_extension_bpc_table.shtml) 

### Determining the number of weeks for the extension

Source topic: `en_EN/task/ebp_ewcpp18/determining_the_number_of_weeks_for_the_e9666979.dita`

When the weekly allocation amount is less than the No benefits payable amount in FTS, the BP cannot be extended.

When the weekly allocation amount is greater than the No benefits payable amount in FTS, the BP can be extended. 

### Note

Source topic: `en_EN/common_notes/note_c_3291.dita`

Note:

For information on extension of the BP on an initial claim, the officer can refer to the applicable calculation procedure. 

### Note

Source topic: `en_EN/common_notes/note_c_3292.dita`

Note:

Due to a post-EI Emergency Response Benefit (EI ERB) temporary processing measure, separation monies are not allocated on certain claims with a BPC between September 27, 2020 (w/c 2258) and September 19, 2021 (w/c 2309). Therefore, no BP extension is granted. For more information, the officer refers to the appropriate task under Earnings .
       [Earnings](/en/procedure/activity/earnings.shtml)

     [Earnings](/en/procedure/activity/earnings.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3293.dita`

Note:

Unless an Operational Centre Memo (MM06) is required to allocate the earnings, the earnings allocation must be completed before the BP extension. If necessary, the officer can refer to Earnings .
       [Earnings](/en/procedure/activity/earnings.shtml)

     [Earnings](/en/procedure/activity/earnings.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3294.dita`

Note:

Vacation pay alone on the ROE does not constitute sufficient proof of a permanent separation from employment. 

### Example

Source topic: `en_EN/common_notes/note_c_3295.dita`

Example:

A client is disentitled for out of Canada for 2 days and would be payable EI benefits if the allocation did not exist. A BP extension can be granted because the allocation of monies — not the disentitlement — prevents the payment of benefits. 

### Example

Source topic: `en_EN/common_notes/note_c_3296.dita`

Example:

If the allocation of a client’s workers’ compensation benefits does not fully prevent the payment of benefits, we cannot use that week for extension purposes because benefits were paid. 

## Regional considerations

Source topic: `en_EN/task/ebp_ewcpp18/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/ebp_ewcpp18/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/ebp_ewcpp18/in_fts.dita`

- What is the status of the WP?

- Is there a registration number? 

### In NWS:

Source topic: `en_EN/task/ebp_ewcpp18/in_nws.dita`

- Is there an SROC or a record of decision (ROD) with details of the allocation? 

### In Imaging:

Source topic: `en_EN/task/ebp_ewcpp18/in_imaging.dita`

- Are there any documents relating to the allocation? 

## Step by step

Source topic: `en_EN/task/ebp_ewcpp18/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/ebp_ewcpp18/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/ebp_ewcpp18/reviewing_the_file_level_1.dita`

- Determine if the client received any of the following earnings during the BP:

- workers’ compensation benefits

- preventive withdrawal

- monies paid following a complete and final separation from employment (refer to Digest 5.12.1 — Definition of lay-off or separation if necessary to determine if the severance is temporary or final)

- If the client received any of the earnings, go to step 2.

- If the client did not receive any of the earnings, go to Extension not allowed
                   [Extension not allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ebp_ewcpp18#Extension_not_allowed)

               [Digest 5.12.1 — Definition of lay-off or separation](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/moneys-paid-layoff-separation.html#a5_12_1)

- Determine if the monies received were separation monies and if the claim meets one of the following conditions:

- the BPC is between March 30, 2025 (w/c 2493), and October 10 , 2026 (w/c 2572 ).

- the separation monies would otherwise be allocated under EIR 36(9) to 36(11) and the first week of allocation falls within the period beginning March 30, 2025 (w/c 2493) to October 10 , 2026 (w/c 2572 ).
               [EIR 36(9)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285) 
               [36(11)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285)

- The separation monies are reviewed on or after September 25, 2022 (w/c 2362) and the allocation start date is between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361).

- The separation monies are reviewed between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361).

- For an initial claim, the BPC is between September 27, 2020 (w/c 2258) and September 19, 2021 (w/c 2309).

- For a renewal claim, the renewal week is between September 27, 2020 (w/c 2258) and September 19, 2021 (w/c 2309).

- For a continuing claim, the allocation start date is between September 27, 2020 (w/c 2258) and September 24, 2021 (w/c 2309).

- If no, go to step 3.

- If yes, go to Extension not allowed .
                   [Extension not allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ebp_ewcpp18#Extension_not_allowed)

- Determine if the earnings allocation has been completed:

- If yes, go to step 4.

- If no , determine if an Operational Centre Memo (MM06) is required to allocate the earnings (refer to Earnings if required):

- If an Operational Centre Memo (MM06) is required, go to step 4.

- If an Operational Centre Memo (MM06) is not required, refer to Earnings to allocate the earnings.
                   [Earnings](/en/procedure/activity/earnings.shtml)

               [Earnings](/en/procedure/activity/earnings.shtml) 

#### Calculating the number of weeks to extend

Source topic: `en_EN/task/ebp_ewcpp18/calculating_the_number_of_weeks_to_extend_level_1.dita`

- For each amount of workers’ compensation benefits, preventive withdrawal and monies paid following a complete and final separation, gather the following information:

- Start and end dates of the allocation or monies to be allocated.

- Weekly amount of allocation or monies to be allocated.

- Type of allocation.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3297.dita)

- Calculate the number of weeks for the BP extension by adding the following:

- The number of weeks during the BP for which workers’ compensation benefits, preventive withdrawal, and monies paid following a complete and final separation prevents the payment of benefits. For additional information on the deduction of earnings beyond the WP, refer to Earnings: Earnings deduction calculation — Table.
               [Earnings: Earnings deduction calculation — Table.](/en/procedure/generic/additionalresources/bp_erw_table.shtml)

- If the workers’ compensation benefits, preventive withdrawal, and monies paid following a complete and final separation prevent the client from serving the WP, the number of weeks those earnings prevent the client from serving the WP. For additional information on conditions that prevent serving the WP, refer to Waiting period: Conditions that prevent the waiting period from being served — Table .

- If the number of weeks for the extension is less than 52 weeks, go to step 6.

- If the number of weeks for the extension is 52 weeks or more, go to step 8.

               [Waiting period: Conditions that prevent the waiting period from being served — Table](/en/procedure/generic/additionalresources/bp_extension_bpc_table.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3298.dita)

- Based on the number of weeks for the extension of the BP, calculate the new last renewable week and determine if conditions to further extend the BP exist in the extended portion of the BP:

- If conditions to further extend the BP exist, go to step 7.

- If conditions to further extend the BP do not exist, go to step 8.

- Calculate the number of weeks for the BP extension by adding the following:

- The number previously calculated as the number of weeks for the BP extension.

- The number of weeks during the extended portion of the BP for which workers’ compensation benefits, preventive withdrawal, and monies paid following a complete and final separation prevents the payment of benefits.

- If the number of weeks for the extension is less than 52 weeks, return to step 6.

- If the number of weeks for the extension is 52 weeks or more, go to step 8. 

#### Inputting the benefit period (BP) extension

Source topic: `en_EN/task/ebp_ewcpp18/inputting_the_benefit_period_bp_extension_level_1.dita`

- In FTS, determine if the claim for benefits is active, blocked or archived:

- If the claim is blocked or archived, go to step 9.

- If the claim is active, go to Allocation input on a non-blocked claim .
               [Allocation input on a non-blocked claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ebp_ewcpp18#Allocation_input_on_non_blocked)

- Determine if the allocation was input on a blocked claim or if the allocation will be input on an Operational Centre Memo (MM06) :

- If the allocation was input on a blocked claim, go to Allocation input on a blocked claim .
               [Allocation input on a blocked claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ebp_ewcpp18#allocation_input_on_blocked)

- If the allocation will be input on an Operational Centre Memo (MM06) , return to the originating Earnings procedure to create an Operational Centre Memo (MM06) with the BP extension information, including the number of weeks calculated for the extension of the BP. Go to Allocation input on a non-blocked claim .
               [Earnings](/en/procedure/activity/earnings.shtml) 
               [Allocation input on a non-blocked claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ebp_ewcpp18#Allocation_input_on_non_blocked) 

#### Extension not allowed

Source topic: `en_EN/task/ebp_ewcpp18/extension_not_allowed_level_1.dita`

- In NWS, complete the WI or return to the originating task. 

#### Allocation input on a non-blocked claim

Source topic: `en_EN/task/ebp_ewcpp18/allocation_input_on_a_non-blocked_claim_level_1.dita`

- In FTS, determine if there is a registration number:

- If yes , go to step 2.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Additional Data (M107) transaction and input the BP extension as follows:

- Registration number: Select the appropriate registration number.

- Benefit Period Extensions — Action: Select Add .

- Start Week: Enter the w/c of the first week of the earnings that prevented the payment of benefits.

- Number of Weeks: Enter the total number of weeks for the extension of the BP.

- Type: Select the appropriate code:

- P - Preventative Withdrawal

- S - Separation pay benefits

- W - Worker’s compensation benefits

- Decision Type: Select the appropriate decision type:

- 2 - Renewal

- 3 - Revised

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number

- D - No to leave the registration number open.

- Select Update .

- In NWS, complete the WI or return to the originating task. 

#### Allocation input on a blocked claim

Source topic: `en_EN/task/ebp_ewcpp18/allocation_input_on_a_blocked_claim_level_1.dita`

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 8 - Your earnings were not deducted .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select the appropriate option:

- If no additional weeks need to be processed or paid, select 91 - Overpayment .

- If additional weeks need to be processed or paid, select 93 - Manual Pay System .

- Work type: Select the appropriate option:

- If the Work item is 91 , select 2 - Non-misrepresentation .

- If the Work item is 93 , select 33 - Blocked claim requiring payment .

- Remarks Line 1: Type “Input M107 [action type] [w/c - start date] - [w/c - end date] [number of weeks] [type of monies (e.g. P - Preventative Withdrawal, S - Separation pay benefits, W - Workers’ compensation benefits)] [apply UP to OP, if necessary].”

- Remarks Line 5: Enter your first name and last name.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- Determine if a subsequent claim needs to be postdated due to the BP extension:

- If no, go to step 5.

- If yes and the claim is active, input the Renewal/Revised (M106) transaction with the required information for the recalculation to postdate the subsequent BPC. If it is not possible to postdate the BPC using the Renewal/Revised (M106) transaction, select the Renewal/Revised (M106) transaction to create a second Operational Centre Memo (MM06) . Refer to MM06 Benefit period: BPC change (antedate and postdate) — Transaction to send the information to IPOC, indicating to process both MM06 transactions.
               [MM06 Benefit period: BPC change (antedate and postdate) — Transaction](/en/procedure/generic/additionalresources/mm06_bpc_change_antedate_transaction.shtml)

- If yes and the claim is blocked, select the Renewal/Revised (M106) transaction to create a second Operational Centre Memo (MM06) . Refer to MM06 Benefit period: BPC change (antedate and postdate) — Transaction to send the information to IPOC, indicating to process both MM06 transactions.
               [MM06 Benefit period: BPC change (antedate and postdate) — Transaction](/en/procedure/generic/additionalresources/mm06_bpc_change_antedate_transaction.shtml)

- In NWS, complete the WI or return to the previous task. 

#### Note

Source topic: `en_EN/common_notes/note_c_3297.dita`

Note:

This information can be found either in the SROC or ROD created during the Earnings procedure, or on the ROE.
       [Earnings](/en/procedure/activity/earnings.shtml)

     [Earnings](/en/procedure/activity/earnings.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_3298.dita`

Note:

It is also possible to plot and take notes on a calculation worksheet .
       [calculation worksheet](/resources/ort/documents/calc_worksheet.xls)

     [calculation worksheet](/resources/ort/documents/calc_worksheet.xls) 

## Policy reference

Source topic: `en_EN/task/ebp_ewcpp18/policy_reference.dita`

- Digest 1.5.1 - Grounds for extension of the benefit period
         [Digest 1.5.1 - Grounds for extension of the benefit period](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-1/extend-benefit-period.html#a1_5_0)

- EIA 10
         [EIA 10](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-10.html)

- EIA 152.11
         [EIA 152.11](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-152.11.html)

- EIR 77
         [EIR 77](http://laws-lois.justice.gc.ca/fra/reglements/DORS-96-332/section-77.html)

- EIR 77.997
         [EIR 77.997](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-14.html#docCont) 
