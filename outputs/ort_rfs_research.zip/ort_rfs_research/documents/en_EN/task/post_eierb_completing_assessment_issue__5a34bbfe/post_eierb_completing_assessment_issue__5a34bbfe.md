# Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE

Source map: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/post_eierb_completing_assessment_issue__5a34bbfe.ditamap`

## Summary

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/summary.dita`

Summary : ACP creates an Assessment Issue (ASMT) ROE Correction WI in the specialized ACP process when an ROE has an error that prevents automation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2628.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_2628.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP no longer creates WIs based on specialized processing. However, the agent continues to complete outstanding WIs that were created by the specialized process before August 16, 2021 using specialized procedures. 

## What you need to know

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4056.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4057.dita) 

### Data entry errors on an ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/data_entry_errors_on_an_roe.dita`

Procedures related to the data entry of an ROE or the review of ROE comments sometimes create an error on the ROE (e.g. a change was made to the original ROE but was not initialled by the employer). When this occurs, the discrepancy is indicated in the Additional information field of the ROE. 

### Identifying ROE errors

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/identifying_roe_errors.dita`

In RCM, an ROE error message is displayed in red beside the blocks in error. When an ROE is corrected, the agent validates the changes to determine if errors are still present or if new ones have occurred. The ROE is considered successfully corrected and available for use in the claim assessment only when no error messages remain.

**Duplicate ROEs**

If the ROE displays an error message stating that a serial number has already been entered for another SIN, the Level 1 agent refers to Post-EI ERB: Correcting an ROE flagged as a duplicate ROE with a different SIN .
       [Post-EI ERB: Correcting an ROE flagged as a duplicate ROE with a different SIN](/en/procedure/task/post_eierb_correcting_roe_flagged_duplicate_roe_different_sin.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4058.dita) 

**ROEs with a serial number status problem**

If the ROE displays an error message stating that a problem with the status of the serial number was detected, the Level 1 agent refers to Post-EI ERB: Correcting an ROE flagged with a serial number problem .
       [Post-EI ERB: Correcting an ROE flagged with a serial number problem](/en/procedure/task/post_eierb_correcting_roe_flagged_with_a_serial_number_problem.shtml) 

### Correcting ROE errors

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/correcting_roe_errors.dita`

Guides are available to help employers correctly complete an ROE. When errors are present and the agent must contact the employer, the agent can also use these guides to teach the employer how to correctly complete the ROE.

The agent must consider that changing one field may affect other information. The types of questions to ask include the following:

- If the first day worked changes, are the total insured hours still correct?

- If the other separation monies are changed, are the total insured earnings still correct?

- If the pay period type changes, is the pay period end date still correct?

The agent processing the ASMT ROE Correction WI reviews all the information on file (the application, previous claims, Easy Access, Major Employer Events database, etc.) before contacting the employer or client to obtain the necessary information.

If the agent is unable to obtain the information required to correct the ROE from the employer or client, the agent does the following:

- estimates the corrections using the available information on file;

- sends a letter to notify the employer of the changes made;

- sends a letter to notify the client that the ROE is unverified and may be reviewed at a later date if additional information is received. 

### Note

Source topic: `en_EN/common_notes/note_c_4056.dita`

Note:

This task applies only to ASMT WIs that were created to address comments on an ROE in the specialized ACP process before its end date of August 16, 2021. To correct an ROE error in the normal ACP process, refer to Completing an ROE Correction WI — Regular ROE (Non-complex) or Correcting an error during calculation or recalculation — Regular ROE (Level 1).
       [Completing an ROE Correction WI — Regular ROE](/en/procedure/task/completing_roe_correction_regular.shtml) 
       [Correcting an error during calculation or recalculation — Regular ROE](/en/procedure/task/correcting_roe_error_calculation_regular.shtml)

     [Completing an ROE Correction WI — Regular ROE](/en/procedure/task/completing_roe_correction_regular.shtml) 
     [Correcting an error during calculation or recalculation — Regular ROE](/en/procedure/task/correcting_roe_error_calculation_regular.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4057.dita`

Note:

For an ASMT ROE Correction WI for a Government of Canada ROE, the agent refers to Updated: ROE issued by the Government of Canada — Procedures (Non-complex, Level 1 and Level 2) .
       [Updated: ROE issued by the Government of Canada — Procedures (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_roe_goc_procedures_ncl1l2.shtml)

     [Updated: ROE issued by the Government of Canada — Procedures (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_roe_goc_procedures_ncl1l2.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4058.dita`

Note:

Although there is a function to override this error in RCM, it must only be used after an Integrity investigation determines the ROE is valid and is required to calculate a claim. 

## Regional considerations

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/in_nws.dita`

- What is the name of the employer declared on the application?

- Are there documents (e.g. SROC, other WIs) containing the information necessary to correct the ROE? 

### In RCM:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/in_rcm.dita`

- Which error messages are displayed when attempting to validate the ROE?

- Is there information in the Comments or Additional information field of the ROE?

- If this ROE is the last ROE, what is the last day paid (LDP)? 

### In Imaging:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/in_imaging.dita`

- Are there any documents that can provide the information required to correct the ROE? 

### In the employer database:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/in_the_employer_database.dita`

- Is there any information about this employer?

- Is there any information about the ROE error in question? 

## Step by step

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/non-complex.dita`

#### Reviewing the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/reviewing_the_roe_non-complex.dita`

- In RCM, determine if an error states that the serial number has already been entered for another SIN:

- If no, go to step 2.

- If yes, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe#nc_item_5)

- Determine if an error states that a problem with the status of the serial number was detected:

- If no, go to step 3.

- If yes, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe#nc_item_5) 

#### Correcting the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/correcting_the_roe_non-complex.dita`

- Determine which blocks of the ROE are in error and consult the table in ROE: RCM validation error correction for a regular ROE — Instructions to determine how to correct the ROE:

- If the table indicates that corrections can be made with the information on file, go to step 4.

- If the table indicates that employer contact is required, go to step 5.

- If the table does not indicate that corrections can be made at your level and does not indicate that employer contact is required, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe#nc_item_5)

- In RCM, correct the errors and do the following:

- Additional information : Type “Changes made to blocks [X] in accordance with the EI ORT.”

- Select Validate and do the following:

- If error messages are displayed for any block, repeat step 3.

- If no error message is displayed, select Submit and go to step 9. 

#### Fact-finding

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/fact-finding_non-complex.dita`

- Fact-find with the person who issued the ROE to obtain the missing information by phone.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4053.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4059.dita)

- Determine if the information has been obtained:

- If yes, go to step 7.

- If no, save the draft SROC and go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe#nc_item_5) 

#### Updating the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/updating_the_roe_non-complex.dita`

- In RCM, correct the ROE and do the following:

- Additional information : Type “Changes to block [X] confirmed with [employer, including the name of the person contacted].”

- Select Validate and do the following :

- If an error message is displayed and the table in ROE: RCM validation error correction for a regular ROE — Instructions does not indicate to check the Override-able errors box next to the error message, go to step 8.
                   [ROE: RCM validation error correction for a regular ROE — Instructions](/en/procedure/generic/correction_reg_1.shtml)

- If error messages are displayed and the table in ROE: RCM validation error correction for a regular ROE — Instructions indicates to check the Override-able errors box next to each error message, check the appropriate boxes and select Submit . Go to step 9.
                   [ROE: RCM validation error correction for a regular ROE — Instructions](/en/procedure/generic/correction_reg_1.shtml)

- If no error message is displayed, select Submit and go to step 9.

- Determine which blocks of the ROE are in error and consult the table in ROE: RCM validation error correction for a regular ROE — Instructions to determine how to correct the ROE:

- If the table indicates that corrections can be made at your level, repeat step 7.

- If the table does not indicate that corrections can be made at your level, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe#nc_item_5)

- In NWS, complete the ASMT ROE Correction WI. 

#### Reassigning the issue to Level 1

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/reassigning_the_issue_to_level_1_non-complex.dita`

- In NWS, reassign the WI to Level 1 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 1 .

- Reason: Select Unable to complete .

- Details: Type the appropriate option:

- “Unable to make ROE corrections to ROE block [number].”

- “The serial number is already in use for another SIN.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_4053.dita`

Note:

If the employer cannot be reached on the first attempt, leave a message. If unable to leave a message on the first attempt or if the employer does not call back within 24 hours, make one more attempt by phone but do not leave a message on the second attempt. Document the attempts in a draft SROC per usual procedures. 

#### Note

Source topic: `en_EN/common_notes/note_c_4059.dita`

Note:

To correct an ROE issued by the Government of Canada, refer to Updated: ROE issued by the Government of Canada — Procedures (Non-complex, Level 1 and Level 2) .
       [Updated: ROE issued by the Government of Canada — Procedures (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_roe_goc_procedures_ncl1l2.shtml)

     [Updated: ROE issued by the Government of Canada — Procedures (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_roe_goc_procedures_ncl1l2.shtml) 

### Level 1

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/level_1.dita`

#### Reviewing the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/reviewing_the_roe_level_1.dita`

- In RCM, determine if an error states the serial number has already been entered for another SIN:

- If no, go to step 2.

- If yes, go to Post-EI ERB: Correcting an ROE flagged as a duplicate ROE with a different SIN .
               [Post-EI ERB: Correcting an ROE flagged as a duplicate ROE with a different SIN](/en/procedure/task/post_eierb_correcting_roe_flagged_duplicate_roe_different_sin.shtml)

- In RCM, determine if an error states a problem with the status of the serial number was detected:

- If no, go to step 3.

- If yes, go to Post-EI ERB: Correcting an ROE flagged with a serial number problem .
               [Post-EI ERB: Correcting an ROE flagged with a serial number problem](/en/procedure/task/post_eierb_correcting_roe_flagged_with_a_serial_number_problem.shtml) 

#### Correcting the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/correcting_the_roe_level_1.dita`

- Determine which blocks of the ROE are in error and consult the tables in ROE: RCM validation error correction for a regular ROE — Instructions and ROE: RCM validation error correction for a regular ROE (employer not reached) — Instructions to determine how to correct the ROE:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4060.dita)

- In RCM, correct the errors and do the following:

- Additional information : Type “Changes made to blocks [X] in accordance with the EI ORT procedures.”

- Select Validate and do the following:

- If an error message is displayed and the tables do not indicate to check the Override-able errors box next to the error message, repeat step 3 to determine how to correct the error.

- If error messages are displayed and the tables indicate to check the Override-able errors box next to each error message, check the appropriate boxes and select Submit . Go to step 14.

- If no error message is displayed, select Submit and go to step 14. 

#### Fact-finding

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/fact-finding_level_1.dita`

- Fact-find with the person who issued the ROE to obtain the missing information by phone.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4053.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4059.dita)

- Determine if the information has been obtained:

- If no, save the draft SROC and go to step 7.

- If yes, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4054.dita)

- If indicated in the table in ROE: RCM validation error correction for a regular ROE (employer not reached) — Instructions , fact-find with the client to obtain the missing information.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4055.dita)

- Determine if the information has been obtained:

- If yes, go to step 9.

- If no, save the draft SROC and go to Actioning the ROE without verification .
               [Actioning the ROE without verification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe#level1_item_5) 

#### Updating the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/updating_the_roe_level_1.dita`

- In RCM, correct the ROE and do the following:

- Additional information : Type “Changes to block [X] confirmed with [client or employer, including the name of the person contacted].”

- Select Validate and do the following:

- If an error message is displayed and the tables used in step 3 do not indicate to check the Override-able errors box next to the error message, go to step 10.

- If error messages are displayed and the tables used in step 3 indicate to check the Override-able errors box next to each error message, check the appropriate boxes and select Submit . Go to step 11.

- If no error message is displayed, select Submit and go to step 11.

- Determine which blocks of the ROE are in error and consult the tables in ROE: RCM validation error correction for a regular ROE — Instructions and ROE: RCM validation error correction for a regular ROE (employer not reached) — Instructions to determine how to correct the ROE:

- If the corrections can be made with the information on file, repeat step 9.

- If the corrections cannot be made with the information on file, save the draft SROC and go to Actioning the ROE error without verification .
               [Actioning the ROE error without verification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe#level1_item_5)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4060.dita)

- Determine if the ROE has been corrected based on information provided by the employer or the client:

- If the client provided the information, go to step 12.

- If the employer provided the information, go to step 14.

- In ACS, create and send the Z-02-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805): Select one of the following:

- Multiple Changes to ROE

- A Single Change to ROE

- List of the change

- Attached INS 3413

- Create and send the N-06-0-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Various reasons - No ROE - Clm Approved / Clm Not Est'd (2699)

- Claim approved-Unverified / Interim ROE(s)

- Unverified ROE / unverified ROEs / Interim ROE / Interim ROEs (2502)

- Unverified ROE or unverified ROE(s)

- Receive ROE(s)/Receive additional info about ROE(s) (2503)

- Receive additional info about ROE(s)

- In NWS, complete the ASMT ROE Correction WI. 

#### Actioning the ROE error without verification

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/actioning_the_roe_error_without_verification_level_1.dita`

- In RCM, estimate the information required to correct the ROE using all available information on file, correct the ROE and do the following:

- Additional information : Type “Unable to verify changes to block [X] with employer or client.”

- In ACS, create and send the Z-02-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805): Select one of the following:

- Multiple Changes to ROE

- A Single Change to ROE

- List of the change

- Attached INS 3413

- Create and send the N-06-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Various reasons - No ROE - Clm Approved / Clm Not Est'd (2699)

- Claim approved-Unverified / Interim ROE(s)

- Unverified ROE / unverified ROEs / Interim ROE / Interim ROEs (2502)

- Unverified ROE or unverified ROE(s)

- Receive ROE(s)/Receive additional info about ROE(s) (2503)

- Receive additional info about ROE(s)

- In NWS, complete the ASMT ROE Correction WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4060.dita`

Note:

Refer to the ROE: RCM validation error correction for a regular ROE — Instructions table first. If the solution is not found, refer to the ROE: RCM validation error correction for a regular ROE (employer not reached) — Instructions table before moving on.
       [ROE: RCM validation error correction for a regular ROE — Instructions](/en/procedure/generic/correction_reg_1.shtml) 
       [ROE: RCM validation error correction for a regular ROE (employer not reached) — Instructions](/en/procedure/generic/correction_reg_2.shtml)

     [ROE: RCM validation error correction for a regular ROE — Instructions](/en/procedure/generic/correction_reg_1.shtml) 
     [ROE: RCM validation error correction for a regular ROE (employer not reached) — Instructions](/en/procedure/generic/correction_reg_2.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_4054.dita`

Note:

If the employer provides information related to the reason for separation (RFS) during fact-finding, document the information on an SROC. Document all other changes in RCM. 

#### Note

Source topic: `en_EN/common_notes/note_c_4055.dita`

Note:

If unable to reach the client on the first attempt, leave a message and send an email (if the client provided an email address). If the client does not call back within 24 hours and did not provide an email address, make one more attempt by phone but do not leave a message. Document the attempts in a draft SROC per usual procedures. Refer to fact-finding for email instructions.
       [fact-finding](/en/procedure/task/fact_find.shtml)

     [fact-finding](/en/procedure/task/fact_find.shtml) 

## Policy reference

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__5a34bbfe/policy_reference.dita`

 
