# Verifying and entering the supplemental unemployment benefits code

Source map: `en_EN/task/ver_ent_subc/ver_ent_subc.ditamap`

## Summary

Source topic: `en_EN/task/ver_ent_subc/summary.dita`

Summary: When the information on file shows that the client is receiving supplemental unemployment benefits (SUB) payments in the benefit period (BP), the officer must verify and enter the appropriate SUB code. 

## What you need to know

Source topic: `en_EN/task/ver_ent_subc/what_you_need_to_know.dita`

### Supplemental unemployment benefits (SUB) payments

Source topic: `en_EN/task/ver_ent_subc/supplemental_unemployment_benefits_sub_payments.dita`

Employers may provide a SUB plan to supplement EI benefits paid during periods of unemployment. When an employer pays a SUB plan, the payments are reported on the ROE in block 17C - Other monies . To be eligible for the SUB payment, a client must be receiving EI benefits for the weeks concerned (except for the waiting period [WP] if this is part of the plan).

**Approved plans**

Payments issued under an approved SUB plan are not considered earnings for benefit purposes if the plan type matches the requested benefit type (BT). For a SUB plan to be approved, it must meet certain conditions. Once approved, the appropriate SUB code must be input for the payment to be excluded from earnings if reported on the claimant’s report.

**Employer details screen**

When a registered SUB plan shows on the Employer Details screen in FTS, the officer determines if the following entitlement conditions are met:

- The ROE indicates that the employee receives SUB or the client reports receiving SUB

- The client is requesting the BT that is listed under the SUB plan.

- The employer-employee relationship is continuing.

- The client is part of the beneficiary group covered by the SUB plan.

The officer inputs the appropriate SUB code on the Renewal/Revised (M106) transaction.

**Types of plans**

An employer may supplement an employee’s EI benefits through 2 different types of plans:

- Supplement to regular, sickness or training benefits (SUB) :

- paid for temporary stoppage of work, training, or illness

- weekly amount of the SUB payment plus the EI benefit rate from that employment cannot be greater than 95% of the client’s normal weekly earnings (NWE) from the employer paying the SUB ( EIR 37 ).
             [EIR 37](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-37.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4898.dita) 

The National Services — SUB Program registers SUB plans for regular, sickness, or training benefits and adds them to the database, which is updated weekly. Once the database is updated, the details, including the appropriate SUB code, are available in the Employer Details screen in FTS.

When no registered plan for regular, sickness, or training benefits is listed, the officer must email National Services to verify if the plan has recently been registered.

- Supplement to maternity, parental, CCB and family caregiver benefits (top-up):

- paid to top up maternity, parental, CCB, or family caregiver benefits

- the employer attests, usually by completing block 17C on the ROE, that the following EIR 38 conditions are met:

- The weekly amount of the SUB payment plus the EI benefit rate from that employment is not greater than 100% of the client’s NWE from the employer paying the SUB.

- The SUB payment does not reduce the client’s other accumulated employment benefits such as sick leave, vacation leave or severance pay.

             [EIR 38](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-38.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2229.dita) 

SUB plans for maternity, parental, CCB and family caregiver benefits are not registered. When the employer attests that the SUB plan meets the conditions of EIR 38, the plan is considered to be approved. Indicating the SUB top-up in block 17C of the ROE is a sufficient attestation. No further confirmation is required. The SUB code for an approved plan for maternity, parental, CCB or family caregiver benefits is always 16 - Approved maternity, parental, compassionate care, or family caregiver for children or adults only . If this SUB information is not on the ROE, the officer fact-finds with the employer to obtain the attestation. 

### Calculation warnings

Source topic: `en_EN/task/ver_ent_subc/calculation_warnings.dita`

The C790 warning is displayed when the officer attempts to input the initial transaction or the subsequent decision transaction without a SUB code when the employer number is on the Employer Details screen in FTS and the claim is not BPNE. The officer reviews the SUB plan and determines if the client is entitled to it.

The C791 warning is displayed when the officer attempts to input the initial or subsequent decision transaction with a SUB code when the employer number is not in the Employer Details screen in FTS.

For more information, the officer refers to WECS .
       [WECS](http://wecs-siew.prv/wecs-siew/lookup_e.aspx) 

### Information for employers

Source topic: `en_EN/task/ver_ent_subc/information_for_employers.dita`

Information for employers regarding these plans can be found on the Service Canada website at:

- Supplement to Regular, Sickness or Training Benefits
         [Supplement to Regular, Sickness or Training Benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/ei-employers-supplemental-unemployment-benefit.html)

- Supplement to maternity, parental, compassionate care and family caregiver benefits
         [Supplement to maternity, parental, compassionate care and family caregiver benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/ei-employers-maternity-parental-benefits.html)

Employers seeking more information or wishing to register a SUB plan must contact the Employer Contact Centre .
       [Employer Contact Centre](https://www.canada.ca/en/employment-social-development/corporate/contact/employer-contact-center.html)

The employer (or the administrator of an approved plan) is responsible for verifying that the client is receiving EI benefits before issuing a SUB payment. The employer verifies this, either from a SUB report or from the client’s benefit statements as follows:

- A SUB report showing EI payments made to the client is issued to the employer when the following 2 conditions are met:

- the SUB plan is for regular, sickness and training benefits;

- an approved SUB code other than 8 - Approved and no listing issued to employer is entered.

- The client must submit EI benefit statements to the employer (no SUB report is available) when one of the following conditions is met:

- the SUB plan is to top up maternity, parental, CCB or family caregiver benefits;

- SUB code 8 is entered.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4899.dita) 

If there is no registered SUB plan for regular, sickness, or training benefits; or the plan does not meet EIR 38 for payment of maternity, parental, CCB or family caregiver benefits, the SUB payments are considered earnings for benefit purposes ( EIR 36 ). The officer must enter SUB code 9 - Not approved and no listing issued to employer and notify the client that the SUB earnings must be declared. If the client is exempt from completing claimant’s reports, the exemption must be cancelled. When the total of the EI benefits and the SUB plan for maternity, parental, compassionate care or family caregiver benefits exceeds the client’s NWE from the employer paying the SUB, only the part that exceeds that total is considered earnings.
       [EIR 36](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html) 

### Note

Source topic: `en_EN/common_notes/note_c_4898.dita`

Note:

The temporary transitional measure included under EIR 37(3) has been repealed and no longer applies effective January 3, 2021. For BPCs from w/c 2063 to w/c 2271 in the first week following the WP, the combined SUB and EI benefits may exceed the 95% threshold in order to accommodate SUB plans that existed before the change. Effective January 3, 2021 (w/c 2272), monies exceeding the maximum threshold will be considered earnings and deducted from benefits payable. 

### Note

Source topic: `en_EN/common_notes/note_c_2229.dita`

Note:

The temporary transitional measure included under EIR 38(3) has been repealed and no longer applies effective January 3, 2021. For BPCs from w/c 2063 to w/c 2271, in the first week following the WP, the combined SUB and EI benefits may exceed the 100% threshold in order to accommodate SUB plans that existed before the change. Effective January 3, 2021 (w/c 2272), monies exceeding the maximum threshold will be considered earnings and deducted from benefits payable. 

### Note

Source topic: `en_EN/common_notes/note_c_4899.dita`

Note:

When there is more than one employment, the employer paying the SUB is notified of the portion of the benefit rate that is based on that employment. Only that portion of the benefit rate and the NWE from the employer paying the SUB are considered when determining the maximum amount of the SUB payment from that employer. Refer to Determining the portion of the benefit rate that is based on the earnings from each employer .
       [Determining the portion of the benefit rate that is based on the earnings from each employer](/en/procedure/task/calc_communicating/det_pot_benrate_earnings.shtml)

     [Determining the portion of the benefit rate that is based on the earnings from each employer](/en/procedure/task/calc_communicating/det_pot_benrate_earnings.shtml) 

## Regional considerations

Source topic: `en_EN/task/ver_ent_subc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/ver_ent_subc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/ver_ent_subc/in_nws.dita`

- What BT has the client requested?

- Is there information indicating that the client may be entitled to SUB payments?

- Are there documents related to the issue? 

### In RCM:

Source topic: `en_EN/task/ver_ent_subc/in_rcm.dita`

- What is the reason for separation?

- Has the employer indicated that the client is receiving SUB payments while on EI?

- If so, has the employer indicated the SUB plan meets EIR 38? 

### In FTS:

Source topic: `en_EN/task/ver_ent_subc/in_fts.dita`

- Does this employer have a registered SUB plan?

- Is the SUB plan for regular, sickness, or training benefits?

- What is the SUB plan type?

- Who is covered in the beneficiaries group? 

## Step by step

Source topic: `en_EN/task/ver_ent_subc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/ver_ent_subc/level_1.dita`

#### Determining the type of supplemental unemployment benefits (SUB) payments

Source topic: `en_EN/task/ver_ent_subc/determining_the_type_of_supplemental_un_272a799e_level_1.dita`

- Based on the information on file, determine how the SUB plan was identified:

- If FTS generated a C790 or C791 warning , go to step 2.

- If the client or employer indicated that SUB is being received, go to step 4.

- Review the file to determine if there is any information indicating that the client could be receiving SUB:

- If yes, go to step 3.

- If no, override then warning. Complete the WI or return to the previous task.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4900.dita)

- Determine if the requested BT matches the plan type listed in the Employer Details screen in FTS:

- If yes, go to step 4.

- If no, go to step 19.

- Determine the reason that the client may be receiving the SUB payments:

- If the reason is due to temporary stoppage of work; illness, injury, quarantine; or training, go to Supplemental unemployment benefits (SUB) paid for temporary stoppage of work, sickness or training .
               [Supplemental unemployment benefits (SUB) paid for temporary stoppage of work, sickness or training](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ver_ent_subc#sub)

- If the reason is to top up maternity, parental, CCB or family caregiver benefits, go to Supplemental unemployment benefits (SUB) paid to top up maternity, parental, CCB or family caregiver benefits .
               [Supplemental unemployment benefits (SUB) paid to top up maternity, parental, CCB or family caregiver benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ver_ent_subc#topup) 

#### Supplemental unemployment benefits (SUB) paid for temporary stoppage of work, sickness or training

Source topic: `en_EN/task/ver_ent_subc/supplemental_unemployment_benefits_sub__ba217d56_level_1.dita`

- In FTS, select the Employer search and enter all 15 characters of the employer’s business number to determine if the employer has a registered SUB plan for the BT requested:

- If no, go to step 6.

- If yes, go to step 10.

- Email the National Services — SUB Program and verify if the SUB plan has recently been registered:

- In the subject line, type “URGENT — SUB plan confirmation.”

- In the body of the email, include the following information:

- employer’s name and address;

- employer’s business number;

- SUB type (sickness, temporary shortage of work, or training) based on the information on file;

- client’s name;

- ask if the employer has a registered SUB plan and, if yes, ask for the details of the plan, including the start date, plan type, SUB code and group of beneficiaries covered by the plan;

- your name and telephone number.

- In NWS, determine if there is a WI for the task:

- If no, hold the task for 48 hours.

- If yes, move it to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “SUB plan verification.”

- Bring forward date: Enter today’s date + 2 business days.

- When National Services replies or the WI moves to the current workload, create an SROC as follows:

- Main Issue: Select Other .

- Comments: Type “SUB plan for [employer name].”

- Details: Document that National Services was contacted to verify if the SUB plan was registered and the response (including the SUB plan details, if necessary), according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if a SUB plan has been registered:

- If the SUB plan has been registered, go to step 10.

- If no SUB plan has been registered or if no response from National Services has been received, go to step 17.

- Determine if there is enough information on file to determine if the client meets all of the following criteria:

- The client is part of the beneficiary group listed in the Employer Details screen in FTS.

- The client has a work stoppage attributed to the employer with the SUB plan.

- The client continues to have a relationship with the employer (i.e. was not dismissed or did not voluntarily leave).

- If yes, go to step 13.

- If no, go to Fact-finding .
                   [Fact-finding](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ver_ent_subc#_Fact-finding_1) 

#### Fact-finding

Source topic: `en_EN/task/ver_ent_subc/fact-finding_level_1.dita`

- Fact-find with the client (or employer, if necessary) to clarify SUB information, such as:

- Which beneficiary group the client is part of?

- What is the payment type?

- What information the client has to determine that SUB is paid?

- Any other relevant facts.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Earnings .

- Comments: Type “Supplementary unemployment benefit information received from the client.”

- Details: Document the fact-finding details according the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client meets all criteria to be entitled to the SUB plan:

- If yes, go to step 14.

- In no, go to step 17.

- In NWS, create a ROD as follows:

- Comments: Type “The [type of SUB payments] are not considered earnings.”

- Details: Type “The [type of SUB payments] received by the client are not earnings as defined in EIR 37(1). No allocation is required.”

- Select Save .

- In FTS, determine if there is a 1 - General suspension of benefits (stop payment) manual action (MA01) imposed for the SUB issue:

- If yes, go to step 16.

- If no, select the Renewal/Revised (M106) transaction and complete it as follows:

- SUB: Enter the SUB code.

- Select Update .

- Go to step 19.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4901.dita)

- Select the Renewal/Revised (M106) transaction and complete it as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- SUB: Enter the SUB code.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Go to step 19.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4902.dita)

- In FTS, determine if there is an MA01imposed for the SUB issue:

- If yes, go to step 18.

- If no, select the Renewal/Revised (M106) transaction and complete it as follows to indicate that the SUB plan is not registered or does not meet the conditions of EIR 37:

- SUB: Select 09 .

- Select Update .

- If the SUB plan is payable due to incapacity, refer to step 8 of Allocating incapacity monies .
                   [Allocating incapacity monies](/en/procedure/task/all_inc_monies.shtml)

- If the SUB plan is payable due to shortage of work or due to training, refer to step 8 of Allocating other monies .
                   [Allocating other monies](/en/procedure/task/all_others_monies.shtml)

- Go to step 19.

- In FTS, select the Renewal/Revised (M106) transaction and complete it as follows to indicate that the SUB is not registered or does not meet the conditions of EIR 37:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- SUB: Select 09 .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- If the SUB plan is payable due to incapacity, refer to step 8 of Allocating incapacity monies .
               [Allocating incapacity monies](/en/procedure/task/all_inc_monies.shtml)

- If the SUB plan is payable due to shortage of work or training, refer to step 8 of Allocating other monies .
               [Allocating other monies](/en/procedure/task/all_others_monies.shtml)

- Complete the WI or return to the initial task. 

#### Supplemental unemployment benefits (SUB) paid to top up maternity, parental, CCB or family caregiver benefits

Source topic: `en_EN/task/ver_ent_subc/supplemental_unemployment_benefits_sub__6a451c06_level_1.dita`

- Determine if additional fact-finding is required:

- If yes, go to step 6.

- If no, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4903.dita)

- Fact-find with the employer to determine if the employer can attest that the SUB plan meets the conditions of EIR 38 .

- Determine if the employer was reached:

- If yes, go to step 8.

- If no, go to step 10.

- In NWS, create an SROC as follows:

- Main Issue: Select Other .

- Comments: Type “SUB plan for [employer name].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if the information on file indicates that the SUB top-up meets the conditions of EIR 38 :

- If the information on file does not indicate that the conditions are met, go to step 10.

- If information on file indicates that the conditions are met, go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2232.dita)

- In FTS, select the Renewal / Revised (M106) transaction and enter the code to indicate that the SUB does not meet the conditions of EIR 38:

- SUB: Select 09 .

- Select Update .

- Determine if the client is currently exempt from completing claimant’s reports:

- If yes, go to step 12.

- If no, refer to step 8 of Allocating other monies .
               [Allocating other monies](/en/procedure/task/all_others_monies.shtml)

- In FTS, select the Renewal / Revised (M106) transaction and cancel the exemption from reporting to allow the client to declare the SUB earnings as follows:

- Claimant’s Report:

- Rescind: Check the box.

- Select Update .

- Refer to step 8 of Allocating other monies .
               [Allocating other monies](/en/procedure/task/all_others_monies.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4904.dita)

- In FTS, select the Renewal/Revised (M106) transaction and enter the code as follows to indicate that the SUB plan meets the conditions of EIR 38:

- SUB: Select 16 .

- Select Update .

- In NWS, create a ROD as follows:

- Comments: Type “The [type of SUB payments] are not considered earnings.”

- Details: Type “The [type of SUB payments] received by the client are not earnings as defined in EIR 35(1). No allocation is required.”

- Select Save .

- In FTS, determine if there is a MA01 imposed for the SUB issue:

- If no, go to step 16.

- If yes, select the Renewal/Revised (M106) transaction and remove the MA01 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 1 - General Suspension of Benefits (stop payment) .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Complete the WI or return to the initial task. 

#### Note

Source topic: `en_EN/common_notes/note_c_4900.dita`

Note:

SUB may be indicated in:

- block 17C of the ROE;

- the comments in the ROE;

- the information provided by the client. 

#### Note

Source topic: `en_EN/common_notes/note_c_4901.dita`

Note:

Inputting the SUB code of a recently registered plan (i.e. a plan registered before the weekly database update) results in a C791 warning. The officer overrides this warning when National Services has confirmed the SUB plan details. 

#### Note

Source topic: `en_EN/common_notes/note_c_4902.dita`

Note:

Inputting the SUB code of a recently registered plan (i.e. a plan registered before the weekly database update) results in a C791 warning. Override this warning when National Services has confirmed the SUB plan details. 

#### Note

Source topic: `en_EN/common_notes/note_c_4903.dita`

Note:

By indicating the SUB top-up in block 17C of the ROE, the employer is attesting that the SUB plan meets the conditions of EIR 38. No further confirmation is required.

If the information on file indicates that the client is receiving a SUB top up but it is not indicated on the ROE, fact-find with the employer. 

#### Note

Source topic: `en_EN/common_notes/note_c_2232.dita`

Note:

For BPCs from w/c 2063 to w/c 2271, in the first week following the WP, the combined SUB and EI benefits may exceed the 100% threshold. 

#### Note

Source topic: `en_EN/common_notes/note_c_4904.dita`

Note:

When the total of the EI benefits and the SUB plan for maternity, parental, CCB or family caregiver benefits exceed the client’s NWE from the employer paying the SUB, only the part that exceeds that total is considered earnings. 

### Level 2

Source topic: `en_EN/task/ver_ent_subc/level_2.dita`

#### Determining the type of supplemental unemployment benefits (SUB) plan

Source topic: `en_EN/task/ver_ent_subc/determining_the_type_of_supplemental_un_c324cc1f_level_2.dita`

- Based on the information on file determine how the SUB plan was identified:

- If FTS generated a C790 warning, go to step 2.

- If FTS generated a C791 warning, go to step 3.

- If the client or employer indicated that SUB is being received, go to step 3.

- Review the file to determine if there is any information indicating that the client is receiving SUB:

- If yes, go to step 3.

- If no, override the warning. Complete the WI or return to the previous task.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4900.dita)

- Determine if the requested BT matches the plan type listed in the Employer Details screen in FTS:

- If yes, go to step 4.

- If no, go to step 17.

- Determine the reason that the client may be receiving the SUB payments:

- If the reason is due to temporary stoppage of work; illness, injury, quarantine; or training, go to Supplemental unemployment benefits (SUB) paid for temporary stoppage of work, sickness or training .
               [Supplemental unemployment benefits (SUB) paid for temporary stoppage of work, sickness or training](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ver_ent_subc#sub_2)

- If the reason is to top up maternity, parental, CCB or family caregiver benefits, go to Supplemental unemployment benefits (SUB) paid to top up maternity, parental, CCB or family caregiver benefits .
               [Supplemental unemployment benefits (SUB) paid to top up maternity, parental, CCB or family caregiver benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ver_ent_subc#topup_2) 

#### Supplemental unemployment benefits (SUB) paid for temporary stoppage of work, sickness or training

Source topic: `en_EN/task/ver_ent_subc/supplemental_unemployment_benefits_sub__ba217d56_level_2.dita`

- In FTS, select the Employer search and enter all 15 characters of the employer’s business number to determine if the employer has a registered SUB plan for the BT requested:

- If no, go to step 6.

- If yes, go to step 10.

- Email the National Services — SUB Program and verify if the SUB plan has recently been registered:

- In the subject line, type “URGENT — SUB plan confirmation.”

- In the body of the email, include the following information:

- employer’s name and address;

- employer’s business number;

- SUB type (sickness, temporary shortage of work, or training) based on the information on file;

- client’s name;

- ask if the employer has a registered SUB plan and, if yes, ask for the details of the plan, including the start date, plan type, SUB code and group of beneficiaries covered by the plan;

- your name and telephone number.

- In NWS, determine if there is a WI for the task:

- If no, hold the task for 48 hours.

- If yes, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “SUB plan verification.”

- Bring forward date: Enter today’s date + 2 business days.

- When National Services replies or the WI moves to the current workload, create an SROC as follows:

- Main Issue: Select Other .

- Comments: Type “SUB plan for [employer name].”

- Details: Document that National Services was contacted to verify if the SUB plan was registered and the response (including the SUB plan details, if necessary) according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if a SUB plan has been registered:

- If the SUB plan has been registered, go to step 10.

- If no SUB plan has been registered or no response from National Services has been received, go to step 17.

- Determine if there is enough information on file to determine if the client meets all of the following criteria:

- The client is part of the beneficiary group listed in the Employer Details screen in FTS.

- The client has a work stoppage attributed to the employer with the SUB plan.

- The client continues to have a relationship with the employer (i.e. was not dismissed or did not voluntarily leave).

- If yes, go to step 14.

- If no, go to Fact-finding .
                   [Fact-finding](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ver_ent_subc#_Fact-finding_2) 

#### Fact-finding

Source topic: `en_EN/task/ver_ent_subc/fact-finding_level_2.dita`

- Fact-find with the client (or employer, if necessary) to clarify SUB information such as:

- Is which beneficiary group the client is part of?

- What is the payment type?

- What information the client has to say that SUB is paid?

- Any other relevant facts.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Earnings .

- Comments: Type “Supplementary unemployment benefit information received from the client.”

- Details: Document the fact-finding details according to the National Fact-finding and Documentation Policy .
               [National Fact-finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client meets all criteria to be eligible to SUB plan:

- If yes, go to step 14.

- In no, go to step 17.

- In NWS, create a ROD as follows:

- Comments: Type “The [type of SUB payments] are not considered earnings.”

- Details: Type “The [type of SUB payments] received by the client are not earnings as defined in EIR 37(1). No allocation is required.”

- Select Save .

- In FTS, determine if there is a MA01 imposed for the SUB issue:

- If yes, go to step 16.

- If no, select the Renewal/Revised (M106) transaction and complete it as follows:

- SUB: Enter the SUB code.

- Select Update .

- Go to step 19.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4901.dita)

- Select the Renewal/Revised (M106) transaction and complete it as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 1 - General Suspension of Benefits (stop payment) .

- Rescind: Check the box.

- SUB: Enter the SUB code.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Go to step 19.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4902.dita)

- In FTS, determine if there is an MA01 imposed for the SUB issue:

- If yes, go to step 18.

- If no, select the Renewal/Revised (M106) transaction and complete it as follows to indicate that the SUB is not registered or does not meet the conditions of EIR 37:

- SUB: Select 09 .

- Select Update .

- If the SUB plan is payable due to incapacity, refer to step 8 of Allocating incapacity monies .
                   [Allocating incapacity monies](/en/procedure/task/all_inc_monies.shtml)

- If the SUB plan is payable due to shortage of work or due to training, refer to step 8 of Allocating other monies .
                   [Allocating other monies](/en/procedure/task/all_others_monies.shtml)

- In FTS, select the Renewal / Revised (M106) transaction and enter the code as follows to indicate that the SUB plan is not registered or does not meet the conditions of EIR 37:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- SUB: Select 09 .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, C - Yes .

- To leave the registration number open for subsequent transactions, D - No .

- Select Update .

- If the SUB plan is payable due to incapacity, refer to step 8 of Allocating incapacity monies .
               [Allocating incapacity monies](/en/procedure/task/all_inc_monies.shtml)

- If the SUB plan is payable due to shortage of work or training, refer to step 8 of Allocating other monies .
               [Allocating other monies](/en/procedure/task/all_others_monies.shtml)

- Complete the WI or return to the initial task. 

#### Supplemental unemployment benefits (SUB) paid to top up maternity, parental, CCB or family caregiver benefits

Source topic: `en_EN/task/ver_ent_subc/supplemental_unemployment_benefits_sub__6a451c06_level_2.dita`

- Determine if additional fact-finding is required:

- If yes, go to step 6.

- If no, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4903.dita)

- Fact-find with the employer to determine if the employer can attest that the SUB plan meets the conditions of EIR 38 .

- Determine if the employer was reached:

- If yes, go to step 8.

- If no, go to step 10.

- In NWS, create an SROC as follows:

- Main Issue: Select Other .

- Comments: Type “SUB plan for [employer name].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if the information on file indicates that the SUB top-up meets the conditions of EIR 38 :

- If the information on file does not indicate that the conditions are met, go to step 10.

- If information on file indicates that the conditions are met, go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2232.dita)

- In FTS, select the Renewal / Revised (M106) transaction and enter the code to indicate that the SUB does not meet the conditions of EIR 38

- SUB: Select 09 .

- Select Update .

- Determine if the client is currently exempt from completing claimant’s reports:

- If yes, go to step 12.

- If no, refer to step 8 of Allocating other monies .
               [Allocating other monies](/en/procedure/task/all_others_monies.shtml)

- Select the Renewal / Revised (M106) transaction and cancel the exemption from reporting to allow the client to declare the SUB earnings as follows:

- Claimant’s Report:

- Rescind: Check the box.

- Select Update .

- Refer to step 8 of Allocating other monies .
               [Allocating other monies](/en/procedure/task/all_others_monies.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4905.dita)

- In NWS, create a ROD as follows:

- Comments: Type “The [type of SUB payments] are not considered earnings.”

- Details: Type “The [type of SUB payments] received by the client are not earnings as defined in EIR 35(1). No allocation is required.”

- Select Save .

- In FTS, determine if there is a MA01 imposed for the SUB issue:

- If yes, go to step 15.

- If no, select the Renewal/Revised (M106) transaction and enter the SUB code as follows:

- SUB: Select 16 .

- Select Update .

- Select the Renewal/Revised (M106) transaction to remove the MA01 and enter the SUB code as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 1 - General Suspension of Benefits (stop payment) .

- Rescind: Check the box.

- SUB: Select 16 .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Complete the WI or return to the initial task. 

#### Note

Source topic: `en_EN/common_notes/note_c_4905.dita`

Note:

When the total of EI benefits and the SUB plan for maternity, parental, CCB or family caregiver benefits exceed the client’s NWE from the employer paying the SUB, only the part that exceeds that total is considered earnings. 

## Policy reference

Source topic: `en_EN/task/ver_ent_subc/policy_reference.dita`

- EIR 36(12)
         [EIR 36(12)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-36.html)

- EIR 37
         [EIR 37](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-37.html)

- EIR 38
         [EIR 38](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-38.html)

- Digest 5.5.2 — Payments supplemental to unemployment insurance benefits
         [Digest 5.5.2 — Payments supplemental to unemployment insurance benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/excluded-earnings-regulation35.html#a5_5_2)

- Digest 5.5.2.1 — Approved supplemental unemployment benefit plans
         [Digest 5.5.2.1 — Approved supplemental unemployment benefit plans](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/excluded-earnings-regulation35.html#a5_5_2_1)

- Digest 5.5.2.2 — Payments by Reason of Pregnancy or for the Care of a Child or for the Care or Support of a Family Member
         [Digest 5.5.2.2 — Payments by Reason of Pregnancy or for the Care of a Child or for the Care or Support of a Family Member](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/excluded-earnings-regulation35.html#a5_5_2_2) 
