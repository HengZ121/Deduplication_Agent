# Receiving and referring an informant lead

Source map: `en_EN/task/referral_integrity_informant_lead/referral_integrity_informant_lead.ditamap`

## Summary

Source topic: `en_EN/task/referral_integrity_informant_lead/summary.dita`

Summary: When an individual provides information about potential abuse of the EI program, the information must be referred to Integrity. 

## What you need to know

Source topic: `en_EN/task/referral_integrity_informant_lead/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/referral_integrity_informant_lead/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4369.dita) 

### Informant lead

Source topic: `en_EN/task/referral_integrity_informant_lead/informant_lead.dita`

The term “informant” refers to an individual who provides information about potential abuse of the EI program. An “informant lead” is any information received from this individual. An informant lead may also be referred to as a Third Party Report or a Third Party Complaint, but for consistency, the term “informant lead” is used in this document.

An informant may wish to report possible abuse that is unrelated to the EI program (e.g. taxes not being deducted from earnings, which is the responsibility of the Canada Revenue Agency). Regardless of the nature of the report, the agent refers the report to Integrity, where it is transferred to the appropriate authority.

All informant leads must be verified by Integrity. 

### Referring informant leads to Integrity

Source topic: `en_EN/task/referral_integrity_informant_lead/referring_informant_leads_to_integrity.dita`

Informant leads received by telephone are documented on an Informant lead: INS5204 Third party information — Form and forwarded to Integrity. To protect the identity of the informant, the agent must avoid using WIs to refer the information. When the INS5204 form is received by Integrity, it is put into a sealed envelope and kept separate from the client’s file to protect the informant’s identity.
       [Informant lead: INS5204 Third party information — Form](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=ESDC-INS5204EFM.pdf)

The 3-page INS5204 form includes many subjects, including reason for separation, availability and possible abuse of the EI program by the employer. 

### Informant’s right to anonymity

Source topic: `en_EN/task/referral_integrity_informant_lead/informants_right_to_anonymity.dita`

A disclaimer must be read to advise informants that Service Canada is legally bound to ensure that their identity is not disclosed. Therefore, the identity of the informant is protected when anonymity is requested. However, the informant must be aware the client may guess the person’s identity from the information given.

If the informant insists on speaking directly with an investigator, the INS5204 form is completed with as much information as possible before it is submitted to Integrity. When possible, the agent obtains a first name and a telephone number where the informant can be reached. If anonymity is requested, the informant may be identified as John Doe. Explain to the informant that all the information provided is put into a sealed envelope that the client cannot access.

Informant lead referral forms must never be attached to an electronic claim file in NWS (e.g. SROC, AI, CB). 

### Note

Source topic: `en_EN/common_notes/note_c_4369.dita`

Note:

If the issue is potentially fraudulent activity on an EI Emergency Response Benefit (EI ERB) claim, the agent refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

     [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

## Regional considerations

Source topic: `en_EN/task/referral_integrity_informant_lead/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/referral_integrity_informant_lead/what_you_need_to_look_for.dita`

## Step by step

Source topic: `en_EN/task/referral_integrity_informant_lead/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/referral_integrity_informant_lead/level_1.dita`

#### Receiving the informant lead

Source topic: `en_EN/task/referral_integrity_informant_lead/receiving_the_informant_lead_level_1.dita`

- In E-forms, open the Informant lead: INS5204 Third party information — Form .

- Read the statement at the top of the form to the informant to notify of the right to anonymity:

- If the informant wishes to remain anonymous, assure the person that Service Canada will make every effort to protect his or her anonymity.

- Ensure you obtain a first name and a telephone number for the investigator to contact the informant if necessary.

- Complete the form with as much detail as possible.

- Do not use abbreviations or acronyms.

- Document only the informant's statement (e.g. do not indicate the informant's SIN unless it is provided by the informant).

- The Comments: Other details field at the end of the form should be used when the informant is unwilling or unable to provide some information.

- If the informant wishes to speak directly to an investigator, type the following in the Comments: Other details field:

- “The informant does not want to provide information to us and wishes to speak directly to an investigator.”

           [Danger](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4370.dita)

- When completed, read back the informant’s statement to verify the information (including the spelling of any names). 

#### Referring the informant lead to Integrity

Source topic: `en_EN/task/referral_integrity_informant_lead/referring_the_informant_lead_to_integrity_level_1.dita`

- Forward the completed form by selecting Send from the File menu or clicking the envelope icon in the toolbar.

- On the Compose tab, complete the following fields. Do not use the term “fraud” in the email .

- Subject : Type of one following:

- “Informant lead — [last 3 digits of the client's SIN if known]”

- “Informant lead — potential abuse by the employer [name of employer if known]”

- To : Select the appropriate Integrity unit below based on where the informant resides:

- Atlantic: Send to atl-integrity_general_delivery-poste_restante_integrite-atl@servicecanada.gc.ca .
                   [atl-integrity_general_delivery-poste_restante_integrite-atl@servicecanada.gc.ca](mailto:atl-integrity_general_delivery-poste_restante_integrite-atl@servicecanada.gc.ca)

- Quebec: Send to qc-ip-pi-enq-inv-gd@servicecanada.gc.ca .
                   [qc-ip-pi-enq-inv-gd@servicecanada.gc.ca](mailto:qc-ip-pi-enq-inv-gd@servicecanada.gc.ca)

- Ontario: Send to on-integ-ref-dem-gd@servicecanada.gc.ca .
                   [on-integ-ref-dem-gd@servicecanada.gc.ca](mailto:on-integ-ref-dem-gd@servicecanada.gc.ca)

- Western Canada and Territories: Send to w-t-eis-sie-gd@hrdc-drhc.net .
                   [w-t-eis-sie-gd@hrdc-drhc.net](mailto:w-t-eis-sie-gd@hrdc-drhc.net)

- On the Options tab, do the following:

- Verify that the box beside Save a copy in “Sent Items” folder is not checked.

- Click OK .

- Complete the WI or return to the initial task. 

#### Danger

Source topic: `en_EN/common_notes/note_c_4370.dita`

**Warning:**

Do not save the form. 

## Policy reference

Source topic: `en_EN/task/referral_integrity_informant_lead/policy_reference.dita`

 
