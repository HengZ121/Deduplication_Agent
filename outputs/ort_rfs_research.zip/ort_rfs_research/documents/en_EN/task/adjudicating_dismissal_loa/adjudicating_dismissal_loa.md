# Adjudicating dismissal after a leave of absence

Source map: `en_EN/task/adjudicating_dismissal_loa/adjudicating_dismissal_loa.ditamap`

## Summary

Source topic: `en_EN/task/adjudicating_dismissal_loa/summary.dita`

Summary: When clients at the end of a leave of absence are dismissed, their entitlement to regular benefits may be affected. Adjudication is required to determine if the client was dismissed due to misconduct. 

## What you need to know

Source topic: `en_EN/task/adjudicating_dismissal_loa/what_you_need_to_know.dita`

### Adjudicating a dismissal after a leave of absence

Source topic: `en_EN/task/adjudicating_dismissal_loa/adjudicating_a_dismissal_after_a_leave__43e81e6a.dita`

When clients at the end of a leave of absence are dismissed, the officer must determine if the dismissal was due to misconduct.

If the 43 - Leave from employment without just cause disentitlement (D43) was imposed with an unknown end date, the officer must adjudicate the reason for separation (RFS) issue before terminating the disentitlement.

The D43 is terminated on the date the leave of absence ended. 

### Levels of decision

Source topic: `en_EN/task/adjudicating_dismissal_loa/levels_of_decision.dita`

Level 1 officers can terminate a disentitlement for a leave of absence on a renewal claim when:

- the client is renewing the claim; and

- the client resumed employment with the same employer after the period of leave of absence and was then laid off or stopped working for a reason that can be allowed at Level 1; or

- the client did not resume the employment for a reason that can be allowed at Level 1; or

- the client accumulated enough insured hours with another employer after the beginning of the period of leave to qualify for benefits.

Continuing claims must be reassigned to Level 2. 

### Processing a renewal claim

Source topic: `en_EN/task/adjudicating_dismissal_loa/processing_a_renewal_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . When the claim action status shows In Progress , all Adjudication Issue (ADJ) WIs must be completed before the system can calculate the initial claim or finalize the renewal claim. The MA02 stop payment is removed by the system. 

### Communicating the decision

Source topic: `en_EN/task/adjudicating_dismissal_loa/communicating_the_decision.dita`

If a letter of decision is required on an initial or renewal claim, before completing the ADJ WI, the officer creates a Correspondence (COR) Manual decision WI indicating the details of the required letter. If a letter of decision is required on a continuing claim, the officer sends the letter before completing the ADJ WI. 

## Regional considerations

Source topic: `en_EN/task/adjudicating_dismissal_loa/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/adjudicating_dismissal_loa/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/adjudicating_dismissal_loa/in_nws.dita`

- Is there a ROD for the RFS?

- Are there any SROC’s containing information on the dismissal? 

### In FTS:

Source topic: `en_EN/task/adjudicating_dismissal_loa/in_fts.dita`

- Is there a manual action 75 - Verification of reason for termination of Employment (MA75) imposed?

- Is there an outstanding registration number? 

### In Imaging

Source topic: `en_EN/task/adjudicating_dismissal_loa/in_imaging.dita`

- Are there any imaged documents relating to the dismissal? (Documents may have been received before the date of the most recent application). 

## Step by step

Source topic: `en_EN/task/adjudicating_dismissal_loa/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/adjudicating_dismissal_loa/level_1.dita`

#### Determining if the conditions to allow at Level 1 are met

Source topic: `en_EN/task/adjudicating_dismissal_loa/determining_if_the_conditions_to_allow__2ac9dc0f_level_1.dita`

- Determine if the claim type is (CT) renewal:

- If yes, go to step 2.

- If no, go to Reassigning the WI to Level 2 .
               [Reassigning the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_dismissal_loa#reassignL2)

- Based on the National Policy on Levels of Decision , determine if the following conditions are met to allow the dismissal at Level 1:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1718.dita) 

- If yes, go to step 3.

- If no, go to Reassigning the WI to Level 2 .
               [Reassigning the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_dismissal_loa#reassignL2) 

#### Adjudicating the dismissal

Source topic: `en_EN/task/adjudicating_dismissal_loa/adjudicating_the_dismissal_level_1.dita`

- Refer to Dismissal and return to step 4.

- In FTS, determine if a D43 is imposed with an unknown end date:

- If yes, go to Disentitlement imposed with an unknown end date .
               [Disentitlement imposed with an unknown end date](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_dismissal_loa#diwaued)

- If no, go to Disentitlement not imposed with an unknown end date .
               [Disentitlement not imposed with an unknown end date](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_dismissal_loa#dniwaued) 

#### Disentitlement imposed with an unknown end date

Source topic: `en_EN/task/adjudicating_dismissal_loa/disentitlement_imposed_with_an_unknown_end_date_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “leave of absence ended/disentitlement terminated.”

- Details: Type the appropriate option:

- “The client resumed employment with the same employer after the leave of absence period, and was then laid off or stopped working for a reason that can be allowed at Level 1. Disentitlement terminated as of w/c [XXXX-X].”

- “The client did not resume the employment for a reason that can be allowed at Level 1. Disentitlement terminated as of w/c [XXXX-X].”

- “The client accumulated enough hours of insurable employment with another employer after the start of the leave of absence period to qualify for benefits. Disentitlement terminated as of w/c [XXXX-X].”

- References: Type “EI Act 32, Digest 6.6.2 — Authorized period of leave - Section 32.”

- Select the Disqualifications/Disentitlements link and terminate the D43 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualification/Disentitlements (M161) transaction opens, complete the following fields:

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End Date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C- Yes to clear the registration number .

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements terminated and/or removed (2591) :

- Definite disentitlement end date (1274) .

- Text - Specify reason(s) disentitled (1482) .

- Overpayment messages (2452) .

- Right to Request a Reconsideration (with blank option) (4169) .

- In NWS, create a client Note and type “Send the A-01-00-00 letter.”

- Determine if there is an outstanding COR Manual decision WI:

- If no, go to step 6.

- If yes, go to step 8.

- Determine if the system generated a ROD with a negative decision:

- If no, go to step 7.

- If yes, go to step 8.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the Service Canada centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-00 letter required — leave of absence issue.”

- In NWS, complete the WI for the leave of absence issue. 

#### Disentitlement not imposed with an unknown end date

Source topic: `en_EN/task/adjudicating_dismissal_loa/disentitlement_not_imposed_with_an_unkn_a292ac56_level_1.dita`

- In NWS, complete the WI for the leave of absence issue. 

#### Reassigning the WI to Level 2

Source topic: `en_EN/task/adjudicating_dismissal_loa/reassigning_the_wi_to_level_2_level_1.dita`

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type “not within Level 1 authority.” 

#### Callout

Source topic: `en_EN/common_notes/note_c_1718.dita`

- the client is renewing the claim; and

- the client resumed employment with the same employer after the period of leave of absence and was then laid off or stopped working for a reason that can be allowed at Level 1; or

- the client did not resume the employment for reasons that can be allowed at Level 1; or

- the client accumulated enough insured hours with another employer after the beginning of the period of leave to qualify for benefits. 

### Level 2

Source topic: `en_EN/task/adjudicating_dismissal_loa/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/adjudicating_dismissal_loa/reviewing_the_file_level_2.dita`

- Determine if there is a ROD on file for the RFS issue:

- If there is no ROD, go to step 2.

- If there is a ROD, go to step 3. 

#### Adjudicating the dismissal

Source topic: `en_EN/task/adjudicating_dismissal_loa/adjudicating_the_dismissal_level_2.dita`

- Refer to Dismissal and return to step 3. 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/adjudicating_dismissal_loa/record_of_decision_rod__creation_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “leave of absence ended/disentitlement terminated.”

- Details: Type “The client was dismissed at the end of a leave of absence. Disentitlement terminated as of XXXX-X.”

- References: EIA 32, Digest 6.6.2 — Authorized period of leave-Section 32. 

#### Inputs and communication

Source topic: `en_EN/task/adjudicating_dismissal_loa/inputs_and_communication_level_2.dita`

- Follow the applicable procedure based on your decision and the status of the claim:

- Disentitlement terminated — Renewal claim
               [Disentitlement terminated — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_dismissal_loa#DEterm)

- Disentitlement terminated — Continuing claim
               [Disentitlement terminated — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_dismissal_loa#DEtermCont) 

#### Disentitlement terminated — Renewal claim

Source topic: `en_EN/task/adjudicating_dismissal_loa/disentitlement_terminated__renewal_claim_level_2.dita`

- In FTS, determine if a D43 is imposed:

- If yes, go to step 6.

- If no, go to step 12.

- Select the Disqualifications/Disentitlements link and terminate the D43 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualification/Disentitlements (M161) transaction opens, complete the following fields:

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End Date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C – Yes to clear the registration number.

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements terminated and/or removed (2591):

- Definite disentitlement end date (1274) .

- Text - Specify reason(s) disentitled (1482) .

- Overpayment messages (2452) .

- Right to Request a Reconsideration (with blank option) (4169) .

- In NWS, create a client Note and type “Send the A-01-00-00 letter.”

- Determine if there is an outstanding COR Manual decision WI:

- If no, go to step 10.

- If yes, go to step 12.

- Determine if the system generated a ROD with a negative decision:

- If no, go to step 11.

- If yes, go to step 12.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the Service Canada centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-00 letter required — leave of absence issue.”

- Complete the WI for the leave of absence issue. 

#### Disentitlement terminated — Continuing claim

Source topic: `en_EN/task/adjudicating_dismissal_loa/disentitlement_terminated__continuing_claim_level_2.dita`

- Determine if there is an outstanding registration number for the leave of absence issue:

- If there is an outstanding registration number, go to step 6.

- If there is no outstanding registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine which of the following is applicable:

- If there is an MA75 and no D43 imposed, go to step 7.

- If there is a D43 with an unknown end date and no MA75 imposed, go to step 8.

- If there is a D43 with an unknown end date and an MA75 imposed go to step 9.

- If none of the above apply, go to step12.

- Select the Renewal/Revised (M106) transaction and remove the MA75 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 75 - Verification of reason for termination of Employment .

- Rescind: Check the box.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- Go to step 12.

- Select the Disqualifications/Disentitlements link and terminate the D43 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualification/Disentitlements (M161) transaction opens, complete the following fields:

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End Date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number .

- Select Update .

- Go to step 11.

- Select the Renewal/Revised (M106) transaction and remove the MA75 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 75 - Verification of reason for termination of Employment .

- Rescind: Check the box.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration open for subsequent transactions.

- Select Update .

- Select the Disqualifications/Disentitlements link and terminate the D43 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualification/Disentitlements (M161) transaction opens, complete the following fields:

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End Date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number .

- Select Update .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements terminated and/or removed (2591):

- Definite disentitlement end date (1274) .

- Text - Specify reason(s) disentitled (1482) .

- Overpayment messages (2452) .

- Right to Request a Reconsideration (with blank option) (4169) .

- In NWS, complete the WI for the leave of absence issue. 

## Policy reference

Source topic: `en_EN/task/adjudicating_dismissal_loa/policy_reference.dita`

- EIA 32
         [EIA 32](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-32.html)

- Digest 6.6.2 — Authorized period of leave - Section 32
         [Digest 6.6.2 — Authorized period of leave - Section 32](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/periods-of-leave.html#a6_6_2) 
