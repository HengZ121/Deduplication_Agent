# Creating or reassigning a WI — Integrity

Source map: `en_EN/task/referral_integrity_create_reassign_wi/referral_integrity_create_reassign_wi.ditamap`

## Summary

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/summary.dita`

Summary: When processing a claim, the officer may suspect a client, an employer or a third party of committing abuse. Clients may also report that their personal information has been compromised and used to establish a claim for EI or the EI Emergency Response Benefit (EI ERB) or to interfere with the payment of benefits. When it is determined that there is potential abuse, the officer refers the issue to Integrity for investigation. 

## What you need to know

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4361.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0146.dita) 

### Determining if an issue must be referred to Integrity

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/determining_if_an_issue_must_be_referre_dba254fc.dita`

This task is only for actioning a referral to Integrity once the officer determines a referral is required. To determine if an issue must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### ROE issued by the Government of Canada

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/roe_issued_by_the_government_of_canada.dita`

When fact finding about an ROE that is missing or requires correction and the employer is a Government of Canada department or agency served by the Public Service Pay Centre , the officer refers to ROE issued by the Government of Canada — Instructions .
       [department or agency served by the Public Service Pay Centre](https://www.canada.ca/en/public-services-procurement/services/pay-pension/pay-administration/pay-centre-resources/departments-agencies-served-by-pay-centre.html) 
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

These Government of Canada ROEs are referred to Integrity only if an interim ROE cannot be created. In this situation only , the officer creates and assigns an Action Item (AI) WI to the National Integrity level in NWS. 

### Fraudulent EI or EI Emergency Response Benefit (EI ERB) claims

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/fraudulent_ei_or_ei_emergency_response__cf78ae9b.dita`

An officer may suspect, or a client may report that personal information has been compromised and used to establish an EI or EI ERB claim. Fraudulent activity on the claim can also prevent the client from receiving payments.

When the legitimacy of the application is in doubt, the officer reviews the application to determine if any fraud indicators are present and decides if it should be referred to Integrity. The officer refers to Fraud indicators: Identifying potentially fraudulent claims — Knowledge for a detailed list of known fraud indicators, such as addresses and bank accounts.
       [Fraud indicators: Identifying potentially fraudulent claims — Knowledge](/en/procedure/generic/additionalresources/fraud_indicator.shtml)

The most common issues related to fraudulent activity are as follows:

- The client is prevented from receiving another benefit type (BT) administered by the Canada Revenue Agency (CRA) due to the establishment of a benefit period (BP) after an application was fraudulently submitted by a third party.

- The client is receiving EI benefits or the EI ERB. A third party fraudulently submits a new application using the client’s information, but with different direct deposit or address information that does not belong to the client.

- The client is receiving EI benefits or the EI ERB. A third party fraudulently accesses the client’s MSCA and changes the direct deposit or address information.

When the investigation starts, the investigator creates an SROC in NWS and sends a letter to the client. Once the investigation is complete, the investigator sends instructions on any required actions to processing in a Claim Review (CR) Integrity WI.

If the client is trying to establish an EI claim after an EI ERB claim when a 71 - Integrity Services case manual action (MA71) is already imposed for an EI ERB investigation, the officer thoroughly reviews the file before deciding if fraud is also suspected on the new EI application. If the officer suspects fraud, the officer creates a new referral for Integrity.

**Fraud indicators**

Before referring the file to Integrity, officers determine if the application is already under investigation for potential fraud. Officers can determine that there is an ongoing Integrity investigation for this application if:

- an MA71 or 71 - Integrity services case disentitlement (D71) is imposed;

- an SROC created by Integrity is on file;

- an AI WI is assigned to Integrity;

- a Call Back (CB) WI is assigned to Integrity.

- the Under investigation box is checked on the Employer profile screen in RMDS.

If none of these is on file, officers review the file to determine if fraud indicators are present. If yes, officers:

- impose a D71 on skeleton and BPNE 1, 2 or 7 claims, or an MA71 on established claims, if necessary;

- cancel the registration number to suspend the application process to prevent the claim from being established or to prevent payments on the renewal claim until the investigation is complete;

- refer the issue to Integrity for investigation.

If the issue is a CS WI for a potentially fraudulent application, the officer refers to the Claim Set-Up (CS) WI procedures for the required steps.
       [Claim Set-Up (CS) WI](/en/procedure/activity/claim_setup.shtml)

If the issue is a SIR Non-match WI for a potentially fraudulent application, the officer refers to the SIR Non-match procedures for the required steps.
       [SIR Non-match](/en/procedure/activity/sir_nm.shtml)

If the issue is a Claim Assessment (CA) WI for a potentially fraudulent application or an AI WI indicating that the application process must be suspended, the officer continues in this procedure.

If the only fraud indicator is the fraud warning highlighted in red in FTS, the officers do not refer the issue to Integrity.

For more information, the officer refers to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims —Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims —Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml)

**Fraudulent application received on a continuing claim**

If a fraudulent application is received on a continuing claim, the officer determines if the initial claim in FTS is legitimate. The officer then verifies in FTS if the client’s address and direct deposit information have been changed on the legitimate continuing claim:

- If yes, the officer considers the claim as compromised and imposes an MA71.

- If no, the officer considers the claim as not compromised. No MA71 is required and the officer sends an AI WI to Integrity for investigation. This ensures that the MA71 does not penalize the true SIN holder on the legitimate claim, since the claim has not been compromised.

**Client’s application is blocked by a potentially fraudulent application**

When an application with no fraud indicators is received and a previous application is under investigation for potential fraud, officers do not refer the new application to Integrity. Instead, officers process the client’s new application using the previous task for the WI they have been assigned.

**GCKey — Canada Revenue Agency (CRA) privacy breach**

In response to the GCKey security incident, affected MSCA accounts have been disabled and access codes have been cancelled.

These accounts should contain an SROC indicating that for security reasons, the client has been assigned a temporary access code. In some cases, an MA71 was input and an investigation is ongoing.

The officer refers any case in which the client’s personal information has been compromised to Integrity for investigation.

For more information, the officer refers to COVID-19 and external communication strategy .
       [COVID-19 and external communication strategy](/en/site/dossier/information_covid19_external_communicatioin_strategy.shtml#_Letter_to_clients)

**Error code C850**

If an error code C850 is received when the officer attempts to add or modify the client’s direct deposit information, the direct deposit information is listed on a restricted dataset and cannot be added. The officer must not share this information with the client.

If the officer receives the error code C850 when attempting to add or modify a client’s direct deposit information, the officer refers the claim to Integrity by creating an Action Item (AI) WI.

A detailed description of the error code is in WECS .
       [WECS](http://wecs-siew.prv/wecs-siew/lookup_e.aspx)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0089.dita) 

### Referring an issue to Integrity

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/referring_an_issue_to_integrity.dita`

The officer refers issues to Integrity in a new AI WI. The officer does not reassign an existing AI WI to Integrity. If there is a CB WI directly related to the issue under investigation, the officer reassigns it to Integrity.

If there is already an ongoing investigation and the officer discovers a new potentially fraudulent activity (e.g. a second fraudulent application in NWS), the officer refers it to Integrity in a new AI WI. However, if the AI WI for the previous fraud is not complete, the officer adds the information about the new fraud to the existing AI WI.

When referring an issue related to unreported contentious RFS to Integrity, the officer determines if there is an outstanding AI WI assigned to Integrity for that RFS and takes the appropriate action:

- If there is no outstanding AI WI assigned to Integrity for the RFS, the officer creates an urgent AI WI and moves the ADJ WI to Pending until the investigation is complete. In the Details field of the WI, the officer indicates that the payment of benefits is impacted so that the case is prioritized.

- If there is an outstanding AI WI assigned to Integrity for the RFS, the officer adds information to the AI WI, checks the Urgent box and moves the ADJ WI to Pending until the investigation is complete. When adding information in the details field of the WI, the officer indicates that the payment of benefits is impacted so that the case is prioritized.

The term “fraud” is not used in the referral. Since the WI is an official document for access-to-information purposes, it must contain only the relevant facts of the issue in question. 

### Preventing the payment of benefits

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/preventing_the_payment_of_benefits.dita`

When referring an issue to Integrity, the officer determines if the potential abuse impacts the payment of future benefits on an active claim. If not already on the claim, the officer imposes an MA71 to prevent the payment of further benefits until Integrity completes the investigation. If the officer suspects that a skeleton or BPNE (N1, N2 or N7) claim is fraudulent, the officer imposes a D71 to prevent the claim from being finalized during the investigation.

Unless otherwise instructed, when an issue is referred to Integrity on an initial, renewal or continuing claim, the officer moves any WIs related to this issue to Pending until Integrity completes the investigation and a decision is made. The officer then completes the WI according to the record of decision (ROD) related to investigation. 

### Fact-finding

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/fact-finding.dita`

Once Integrity has started an investigation, all fact-finding is completed by the investigator. Therefore, if the client has provided information related to the investigation, the information is sent to Integrity. 

### Ongoing investigation

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/ongoing_investigation.dita`

An ongoing investigation means that Integrity is investigating the case and has not yet sent it for adjudication (no CR Integrity WI has been created). The existence of an ongoing investigation does not mean that the officer must refer issues to Integrity or move the WI to Pending until the investigation is complete. If the issue does not indicate possible abuse, the officer does not refer the issue to Integrity unless it is related to the ongoing investigation .

An officer can determine if there is an ongoing Integrity investigation from any of the following indicators:

- An MA71 is imposed.

- A D71 is imposed.

- An outstanding registration number containing a registration flag 1 - Integrity Services exists.

- A 15 - Claim Procedure disentitlement (D15) is imposed by Integrity (in many cases, the case is completed in NIIS when the D15 is imposed, but the investigation may still be ongoing).

- An N-04-00-00 letter has been sent to request that a medical certificate be provided.

- A letter beginning with C-00, C-72, C-73 or C-88 has been sent by Integrity.

- For potentially fraudulent claims, an SROC created by Integrity might be on file indicating that the claim is under review.

If any of these indicators are present, the officer determines if the issue is related to the ongoing investigation before deciding to refer the issue to Integrity.

**Communicating information during an ongoing investigation**

When a client provides new information or requests information regarding an ongoing investigation , the officer forwards the information or request to Integrity with a CB WI. If there is already a CB WI related to the issue under investigation , the officer reassigns the CB WI to Integrity. The officer does not assign it directly to the investigator.

**Communicating information when the investigation is complete**

When a client provides new information or requests information regarding an investigation that is complete , the officer forwards the information or request on a CB WI to the ISB Post Audit Processing level in NWS if the CR Integrity WI is unassigned. The CB WI can be assigned directly to the officer if the CR Integrity WI is assigned. 

### Note

Source topic: `en_EN/common_notes/note_c_4361.dita`

Note:

For an initial calculation or recalculation using a Government of Canada ROE that is missing or requires correction, the officer refers to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0146.dita`

Note:

The restriction on referring issues to Integrity has been lifted for all issues except self-employment (SE). The officer refers the file to Integrity only when the SE issue impacts the payment of future benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_0089.dita`

Note:

If the client subsequently provides a different direct deposit account that is not rejected with the error code C850, the officer still refers the rejected direct deposit account information to Integrity. The officer also includes the rejected direct deposit information in the AI WI sent to Integrity. 

## Regional considerations

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/in_fts.dita`

- In which region does the client reside?

- Has an MA71 been imposed?

- Has a D71 been imposed?

- Does the potential abuse impact an active claim? 

### In NWS:

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/in_nws.dita`

- Are there any SROCs relating to an ongoing investigation?

- What WI types are pending in the client’s claim? 

## Step by step

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/reviewing_the_file_level_1.dita`

- Determine if the reason for referral is an ROE issue (e.g. missing ROE, ROE clarification, suspicious ROE, etc.):

- If no, go to step 2.

- If yes, go to Referring the issue to Integrity — ROE .
               [Referring the issue to Integrity — ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#referring_the_issue_gov_roe)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4362.dita)

- Determine if the reason for referral is a failure to attend a client information session:

- If no, go to step 3.

- If yes, go to step 9.

- Determine if the reason for referral is to forward information to Integrity about an ongoing investigation :

- If no, go to step 4.

- If yes, go to step 9.

- Determine if the SIN is available for the issue being referred:

- If yes, go to step 5.

- If no, go to Referring the issue to Integrity — No SIN on file .
               [Referring the issue to Integrity — No SIN on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#nosin)

- Determine if the reason for referral is the presence of error code C850:

- If no, go to step 6.

- If yes, go to Referring the issue to Integrity – Error code C850 .
               [Referring the issue to Integrity – Error code C850](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#level1_item_3) 

#### Imposing a stop payment

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/imposing_a_stop_payment_level_1.dita`

- Determine if the issue for referral impacts the payment of future benefits on an initial, renewal or continuing claim or if a fraudulent claim is suspected:

- If it is a renewal or continuing claim and the payment of future benefits may be impacted, go to step 7.

- If it is an initial claim and the payment of future benefits may be impacted, go to step 9.

- If it is an initial, renewal or continuing claim and the payment of future benefits is not impacted, go to step 9.

- If a potentially fraudulent claim is suspected, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#fip)

- Determine if a manual action (MA) has already been imposed:

- If no, go to step 8.

- If yes, go to step 9 .
               [#sin](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#sin)

- Select the Renewal/Revised (M106) transaction and impose an MA71 to stop payment as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update . 

#### Referring the issue to Integrity — SIN on file

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/referring_the_issue_to_integrity__sin_on_file_level_1.dita`

- In NWS, determine if there is a CB WI directly related to the reason for referral :

- If yes, go to step 10.

- If no, go to step 11.

- Reassign the CB WI to Integrity as follows:

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- Complexity: Select Level 1 .

- Reason: Select Other .

- Details: Type “Ongoing investigation.” Explain why the issue is being referred to Integrity. If doubt arose while speaking with the client, provide all relevant details.

- Determine if there is an existing AI WI assigned to Integrity that is not completed:

- If no, go to step 12.

- If yes, add the information to the existing AI WI. If it is an unreported RFS that impacts the payment of benefits on a current claim, type “Payment of benefits is pending the outcome of the investigation.” Go to Reviewing the impacts of the referral .
               [Reviewing the impacts of the referral](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#_Reviewing_the_impacts)

- In NWS, create an AI WI as follows:

- Urgent: Do one of the following:

- If the issue for referral prevents the payment of benefits, check the box.

- If the issue for referral does not prevent the payment of benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Category: Do one of the following:

- If this is an initial claim or if an MA71 is imposed, select Pay affected .

- If the investigation involves a terminated claim or if no MA is imposed, select Not pay affected .

- Issue: Select Integrity .

- Comments: Type one of the following:

- If there is no ongoing investigation, type “There is doubt about [subject of doubt].”

- If there is an ongoing investigation, type “There is doubt about [subject of doubt] — ongoing investigation.”

- Details: Explain why the issue is being referred to Integrity. If it is an unreported RFS that impacts the payment of benefits on a current claim, type “Payment of benefits is pending the outcome of the investigation.” 

#### Reviewing the impacts of the referral

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/reviewing_the_impacts_of_the_referral_level_1.dita`

- In FTS, determine if the issue being referred to Integrity only impacts a terminated, blocked or archived claim:

- If no, go to step 14.

- If yes, go to step 16.

- In NWS, determine if there is a WI related to the reason for referral:

- If yes, move it to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Referral to Integrity.”

- Bring forward date: Enter today’s date + 21 working days.

- Go to step 15.

- If no or the WI is not related to the issue, return to the previous task.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4363.dita)

- When the WI moves to the current workload, determine if there is a CR Integrity WI for the investigation and if it is completed or if there is a decision related to the investigation on file:

- If no, repeat step 14.

- If yes, go to step 20.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4364.dita)

- Determine if there is an outstanding WI:

- If yes, go to step 17.

- If no, return to the previous task.

- Determine if the outstanding WI is related to the reason for referral:

- If yes, go to step 18.

- If no, return to the previous task.

- In FTS, determine if there is an outstanding registration number related to the reason for referral:

- If yes, go to step 19.

- If no, go to step 20.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Referring the issue to Integrity — ROE

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/referring_the_issue_to_integrity__roe_level_1.dita`

- Determine the reason for the referral of the ROE issue:

- If there is a missing ROE, go to step 2.

- If ROE clarification is required, go to step 3.

- If the ROE or any information it contains is potentially false, go to step 4.

- In NWS, create an AI WI as follows:

- Urgent: Do one of the following:

- If the issue for referral prevents the payment of benefits, check the box.

- If the issue for referral does not prevent the payment of benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Category: Select the appropriate option:

- Pay affected.

- Not pay affected.

- Issue: Select Integrity .

- Comments: Type: “Missing ROE — [name of employer].”

- Details: Provide as much detail as possible including any of the following information that applies:

- The employer’s contact information and CRA business number.

- The first and last day of work.

- The attempts to contact the employer and the results .

- An interim ROE was created.

- The reason no interim ROE was created.

- Go to step 5.

- In NWS, create an AI WI as follows:

- Urgent: Do one of the following:

- If the issue for referral prevents the payment of benefits, check the box.

- If the issue for referral does not prevent the payment of benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Category: Select the appropriate option:

- Pay affected.

- Not pay affected.

- Issue: Select Integrity .

- Comments: Type: “ROE clarification— [ ROE serial number ].”

- Details: Provide as much detail as possible including any of the following information that applies:

- the employer’s name , contact information and CRA business number;

- the first and last day of work;

- the attempts to contact the employer and the results;

- the information on the ROE that is missing or requires clarification.

- Go to step 5.

- In NWS, create an AI WI as follows:

- Urgent: Do one of the following:

- If the issue for referral prevents the payment of benefits, check the box.

- If the issue for referral does not prevent the payment of benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Category: Select the appropriate option:

- Pay affected.

- Not pay affected.

- Issue: Select Integrity .

- Comments: Type: “Potentially false ROE or information — [ ROE serial number ].”

- Details: Provide as much detail as possible including any of the following information that applies:

- the employer’s name , contact information and CRA business number;

- the first and last day of work;

- the attempts to contact the employer and the results;

- the potentially false information including:

- RFS misrepresented or amended to a non-contentious RFS;

- inflated insurable hours or earnings;

- employer issued an additional or amended ROE with just enough hours allowing the client to qualify for EI benefits;

- suspicion that the client never worked for the employer and that the employer issued a false ROE;

- client used a SIN belonging to someone else and there is suspicion that the ROE is fraudulent;

- employer is not the same one to whom the blank ROE was issued and the serial number is not printed, is wrong or is a duplicate.

- Return to the previous task. 

#### Referring the issue to Integrity — No SIN on file

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/referring_the_issue_to_integrity__no_sin_on_file_level_1.dita`

- In NWS, create a General Inquiry (GEN) WI as follows:

- Select Create General Inquiry .

- First name: Enter the client’s first name.

- Last name: Enter the client’s last name.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Issue: Select ROE .

- Comments: Type “Referral to Integrity.”

- Details: Type “ROE [ROE serial number] has been issued with the wrong SIN. ROE issued to [name and SIN of the client who received the ROE in error] but belongs to [name of the client to whom the ROE belongs]. Unable to obtain the SIN of the client to whom the ROE belongs.”

- Return to the previous task. 

#### Fraud indicators are present

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/fraud_indicators_are_present_level_1.dita`

- In NWS, determine if there is a CR Integrity ERB-EI Transition WI on file that is directly related to the potentially fraudulent application:

- If no, go to step 2.

- If yes, move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Referral to Integrity.”

- Bring forward date: Enter date of application + 27 calendar days.

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4365.dita)

- Determine if there is a CB WI or AI WI from Integrity on file that is directly related to the potentially fraudulent application:

- If there is only a CB WI on file, move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Referral to Integrity.”

- Bring forward date: Enter date of application + 27 days.

- If there is an AI WI from Integrity indicating that the claim can be established, return to step 1 of the previous task.

- If neither WI is on file, go to step 3.

- Determine if the CA WI is related to a fraudulent renewal application:

- If yes, go to step 4.

- If it is related to a fraudulent initial application, go to step 7.

- Determine if the client’s continuing claim has been compromised:

- If yes, go to step 5.

- If no, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2651.dita)

- Determine if an MA71 is already imposed:

- If no, go to step 6.

- If yes, go to step 13.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 9.

- Determine if a D71 is already imposed:

- If no, go to step 8.

- If yes, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4366.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4367.dita)

- Determine if there is documentation on file indicating that Integrity is already aware of the potential fraud for this issue:

- If no, go to step 10.

- If yes, go to step 11.

- In NWS, refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue: Select SIR validation .

- Comments: Type “Fraud suspected — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file]. The application process has been suspended until the investigation ends.”

- Select Save .

- If it is an initial application, go to step 11.

- If it is a renewal application, go to step 13.

- In NWS, determine if the claim status is Finalized – Pending LREM :

- If yes, go to step 12.

- If no, go to step 13.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- No further action is required.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2696.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the registration number related to the fraudulent application as follows:

- Action: Select Cancel .

- Select Update .

- No further action is required. 

#### Referring the issue to Integrity — Error code C850

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/referring_the_issue_to_integrity__error_5d1a5eb8_level_1.dita`

- Determine if there is an existing AI WI assigned to Integrity that is not completed:

- If no, go to step 2.

- If yes, add the information to the existing AI WI and go to step 3.

- In NWS, create an AI WI as follows:

- Complexity: Select Level 1 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation, select the region where the client resides:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue(s): Select Integrity .

- Comments: Type “Direct deposit — error code C850.”

- Details: Type “Added or modified information related to the direct deposit account [XXXXX XXXX XXXXXXX] was rejected with an error code C850.”

- In NWS, create a new SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Referral to Integrity — banking information.”

- Details: Type “Banking information rejected with an error code C850.” Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- No further action is required. Return to the previous task, if necessary. 

#### Note

Source topic: `en_EN/common_notes/note_c_4362.dita`

Note:

A missing ROE from a Government of Canada department served by the Public Service pay centre is referred to Integrity only if an interim ROE cannot be created. 

#### Note

Source topic: `en_EN/common_notes/note_c_4363.dita`

Note:

If the claim is a renewal claim and there is no pending WI, impose an MA71 to prevent payments in case the claim is automated before the investigation is complete. 

#### Note

Source topic: `en_EN/common_notes/note_c_4364.dita`

Note:

The WI must stay in Pending as long as the CR Integrity WI related to the investigation has not been completed or there is no decision related to the investigation on file. 

#### Note

Source topic: `en_EN/common_notes/note_c_4365.dita`

Note:

The CA WI must stay in Pending until the CR Integrity WI related to the potentially fraudulent application has been completed . The CA WI will be deleted when the CR Integrity WI Is completed. No further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2651.dita`

Note:

A claim is considered to be compromised when the client’s information (address or direct deposit information) has been changed. If the claim is compromised, impose an MA71. 

#### Note

Source topic: `en_EN/common_notes/note_c_4366.dita`

Note:

Before imposing a D71, confirm that one has not already been imposed. If a transaction to impose a D71 is input when one already exists, the D71 is cancelled. 

#### Note

Source topic: `en_EN/common_notes/note_c_4367.dita`

Note:

If error code C072: Invalid Claim action or Action field (C072) is displayed when inputting the Renewal/Revised (M106) transaction, the D71 cannot be imposed. 

#### Note

Source topic: `en_EN/common_notes/note_c_2696.dita`

Note:

If error code 836: WARNING - Flag 33 claim (Last Record of Employment Missing), claim is still polling for the last record of employment is displayed when attempting to clear the registration number, check the box next to Override so that the transaction can be processed. 

### Level 2

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/reviewing_the_file_level_2.dita`

- Determine if the reason for referral is an ROE issue (e.g. missing ROE, ROE clarification, suspicious ROE, etc.):

- If no, go to step 2.

- If yes, go to Referring the issue to Integrity — ROE .
               [Referring the issue to Integrity — ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#referring_the_issue_gov_roe_l2)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4362.dita)

- Determine if the reason for referral is a failure to attend a client information session:

- If no, go to step 3.

- If yes, go to step 9.

- Determine if the reason for referral is to forward information to Integrity about an ongoing investigation :

- If no, go to step 4.

- If yes, go to step 9.

- Determine if the SIN is available for the issue being referred:

- If yes, go to step 5.

- If no, go to Referring the issue to Integrity — No SIN on file .
               [Referring the issue to Integrity — No SIN on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#nosin2)

- Determine if the reason for referral is the presence of error code C850:

- If no, go to step 6.

- If yes, go to Referring the issue to Integrity — Error code C850 .
               [Referring the issue to Integrity — Error code C850](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#level2_item_3) 

#### Imposing a stop payment

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/imposing_a_stop_payment_level_2.dita`

- Determine if the issue for referral impacts the payment of future benefits on an initial, renewal or continuing claim or if a fraudulent claim is suspected:

- If it is a renewal or continuing claim and the payment of future benefits may be impacted, go to step 7.

- If it is an initial claim and the payment of future benefits may be impacted, go to Referring the issue to Integrity — SIN on file .
               [Referring the issue to Integrity — SIN on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#sin2)

- If it is an initial, renewal or continuing claim and the payment of future benefits is not impacted, go to Referring the issue to Integrity — SIN on file .
               [Referring the issue to Integrity — SIN on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#sin2)

- If a potentially fraudulent claim is suspected, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#initial-task)

- Determine if an MA has already been imposed:

- If no, go to step 8.

- If yes, go to Referring the issue to Integrity — SIN on file .
               [Referring the issue to Integrity — SIN on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#sin2)

- Select the Renewal/Revised (M106) transaction and impose an MA71 to stop payment as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- If yes, go to Referring the issue to Integrity — SIN on file .
               [Referring the issue to Integrity — SIN on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#sin2) 

#### Referring the issue to Integrity — SIN on file

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/referring_the_issue_to_integrity__sin_on_file_level_2.dita`

- In NWS, determine if there is a CB WI directly related to the reason for referral :

- If yes, go to step 10.

- If no, go to step 11.

- Reassign the CB WI to Integrity as follows:

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- Complexity: Select Level 1 .

- Reason: Select Other .

- Details: Type “Ongoing investigation.” Explain why the issue is being sent to Integrity. If doubt arose while speaking with the client, provide all relevant details.

- Determine if there is an existing AI WI assigned to Integrity that is not completed:

- If no, go to step 12.

- If yes, add the information to the existing AI WI. If it is an unreported RFS that impacts the payment of benefits on a current claim, type “Payment of benefits is pending the outcome of the investigation.” Go to Reviewing the impacts of the referral .
               [Reviewing the impacts of the referral](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/referral_integrity_create_reassign_wi#_Reviewing_the_impacts_1)

- In NWS, create an AI WI as follows:

- Urgent: Select the appropriate option:

- If the issue for referral prevents the payment of benefits, check the box.

- If the issue for referral does not prevent the payment of benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Category: Do one of the following:

- If this is an initial claim or if an MA71 is imposed, select Pay affected .

- If the investigation involves a terminated claim or if no MA is imposed, select Not pay affected .

- Issue: Select Integrity .

- Comments: Type one of the following:

- If there is no ongoing investigation, type “There is doubt about [subject of doubt].”

- If there is an ongoing investigation, type “There is doubt about [subject of doubt] — ongoing investigation.”

- Details: Explain why the issue is being referred to Integrity. If it is an unreported RFS that impacts the payment of benefits on a current claim, type “Payment of benefits is pending the outcome of the investigation.” 

#### Reviewing the impacts of the referral

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/reviewing_the_impacts_of_the_referral_level_2.dita`

- In FTS, determine if the issue being referred to Integrity only impacts a terminated, blocked or archived claim:

- If no, go to step 14.

- If yes, go to step 16.

- In NWS, determine if there is a WI related to the reason for referral:

- If yes, move it to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Referral to Integrity.”

- Bring forward date: Enter today’s date + 21 working days.

- Go to step 15.

- If no or the WI is not related to the issue, return to the previous task.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4363.dita)

- When the WI moves to the current workload, determine if there is a CR Integrity WI for the investigation and if it is completed or if there is a decision related to the investigation on file:

- If no, repeat step 14.

- If yes, go to step 20.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4368.dita)

- Determine if there is an outstanding WI:

- If yes, go to step 17.

- If no, return to the previous task.

- Determine if the outstanding WI is related to the reason for referral:

- If yes, go to step 18.

- If no, return to the previous task.

- In FTS, determine if there is an outstanding registration number related to the reason for referral:

- If yes, go to step 19.

- If no, go to step 20.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Referring the issue to Integrity — ROE

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/referring_the_issue_to_integrity__roe_level_2.dita`

- Determine the reason for the referral of the ROE issue:

- If there is a missing ROE, go to step 2.

- If ROE clarification is required, go to step 3.

- If the ROE is potentially false or contains false information, go to step 4.

- In NWS, create an AI WI as follows:

- Urgent: Do one of the following:

- If the issue for referral prevents the payment of benefits, check the box.

- If the issue for referral does not prevent the payment of benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Category: Select the appropriate option:

- Pay affected.

- Not pay affected.

- Issue: Select Integrity .

- Comments: Type “Missing ROE — [name of employer].”

- Details: Provide as much detail as possible including any of the following information that applies:

- the employer’s name, contact information and CRA business number;

- the first and last day of work;

- the attempts to contact the employer and the results ;

- an interim ROE was created;

- the reason no interim ROE was created.

- Go to step 5.

- In NWS, create an AI WI as follows:

- Urgent: Do one of the following:

- If the issue for referral prevents the payment of benefits, check the box.

- If the issue for referral does not prevent the payment of benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Category: Select the appropriate option:

- Pay affected.

- Not pay affected.

- Issue: Select Integrity .

- Comments: Type: “ROE clarification— [ROE serial number].”

- Details: Provide as much detail as possible including any of the following information that applies:

- the employer’s name, contact information and CRA business number;

- the first and last day of work;

- the attempts to contact the employer and the results;

- the information on the ROE that is missing or requires clarification.

- Go to step 5.

- In NWS, create an AI WI as follows:

- Urgent: Do one of the following:

- If the issue for referral prevents the payment of benefits, check the box.

- If the issue for referral does not prevent the payment of benefits, do not check the box.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Category: Select the appropriate option:

- Pay affected.

- Not pay affected.

- Issue: Select Integrity .

- Comments: Type: “Potentially false ROE — [ROE serial number].”

- Details: Provide as much detail as possible including any of the following information that applies:

- the employer’s name , contact information and CRA business number;

- the first and last day of work;

- the attempts to contact the employer and the results;

- the potentially false information such as:

- RFS misrepresented or amended to a non-contentious RFS;

- inflated insurable hours or earnings;

- employer issued an additional or amended ROE with just enough hours allowing the client to qualify for EI benefits;

- suspicion that the client never worked for the employer and that the employer issued a false ROE;

- client used a SIN belonging to someone else and there is suspicion that the ROE is fraudulent;

- employer is not the same one to whom the blank ROE was issued and the serial number is not printed, is wrong or is a duplicate.

- Return to the previous task. 

#### Referring the issue to Integrity — No SIN on file

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/referring_the_issue_to_integrity__no_sin_on_file_level_2.dita`

- In NWS, create a GEN WI as follows:

- Select Create General Inquiry .

- First name: Enter the client’s first name.

- Last name: Enter the client’s last name.

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western Canada and Territories: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Issue: Select ROE .

- Comments: Type “Referral to Integrity.”

- Details: Type “ROE [ROE serial number] has been issued with the wrong SIN. ROE issued to [name and SIN of the client who received the ROE in error] but belongs to [name of the client to whom the ROE belongs]. Unable to obtain the SIN of the client to whom the ROE belongs.”

- Return to the previous task. 

#### Fraud indicators are present

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/fraud_indicators_are_present_level_2.dita`

- In NWS, determine if there is a CR Integrity ERB-EI Transition WI on file that is directly related to the potentially fraudulent application:

- If no, go to step 2.

- If yes, move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Referral to Integrity.”

- Bring forward date: Enter date of application + 27 calendar days.

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4365.dita)

- Determine if there is a CB WI or AI WI from Integrity on file that is directly related to the potentially fraudulent application:

- If there is only a CB WI on file, move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Referral to Integrity.”

- Bring forward date: Enter date of application + 27 days.

- If there is an AI WI from Integrity indicating that the claim can be established, return to step 1 of the previous task.

- If neither WI is on file, go to step 3.

- Determine if the CA WI is related to a fraudulent renewal application:

- If yes, go to step 4.

- If it is related to a fraudulent initial application, go to step 7.

- Determine if the client’s continuing claim has been compromised:

- If yes, go to step 5.

- If no, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2651.dita)

- Determine if an MA71 is already imposed:

- If no, go to step 6.

- If yes, go to step 12.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 9.

- Determine if a D71 is already imposed:

- If no, go to step 8.

- If yes, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4366.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4367.dita)

- In NWS, refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue: Select SIR validation .

- Comments: Type “Fraud suspected — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file]. The application process has been suspended until the investigation ends.”

- Select Save .

- If it is an initial application, go to step 10.

- If it is a renewal application, go to step 12.

- In NWS, determine if the claim status is Finalized – Pending LREM :

- If yes, go to step 11.

- If no, go to step 12.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- No further action is required.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2696.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the registration number related to the fraudulent application as follows:

- Action: Select Cancel .

- Select Update .

- No further action is required. 

#### Referring the issue to Integrity — Error code C850

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/referring_the_issue_to_integrity__error_5d1a5eb8_level_2.dita`

- Determine if there is an existing AI WI assigned to Integrity that is not completed:

- If no, go to step 2.

- If yes, add the information to the existing AI WI and go to step 3.

- In NWS, create an AI WI as follows:

- Complexity: Select Level 1 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation, select the region where the client resides:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue(s): Select Integrity .

- Comments: Type “Direct deposit — error code C850.”

- Details: Type “Added or modified information related to the direct deposit account [XXXXX XXXX XXXXXXX] was rejected with an error code C850.”

- In NWS, create a new SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Referral to Integrity — banking information.”

- Details: Type “Banking information rejected with an error code C850.” Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- No further action is required. Return to the previous task, if necessary. 

#### Note

Source topic: `en_EN/common_notes/note_c_4368.dita`

Note:

The WI must stay Pending as long as the CR Integrity WI related to the investigation has not been completed or there is no decision related to the investigation on file. 

## Policy reference

Source topic: `en_EN/task/referral_integrity_create_reassign_wi/policy_reference.dita`

 
