# Adjudicating voluntary leaving: Renewal claim — Level 2

Source map: `en_EN/task/vllevel2_rc/vllevel2_rc.ditamap`

## Summary

Source topic: `en_EN/task/vllevel2_rc/summary.dita`

Summary: When clients voluntarily leave employment, their entitlement to regular benefits on a renewal claim may be affected. If the reason for separation (RFS) cannot be allowed at Level 1 according to the National policy on Levels of Decision , the voluntary leaving must be adjudicated at Level 2 to determine if the client had just cause for leaving the employment.
       [National policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

## What you need to know

Source topic: `en_EN/task/vllevel2_rc/what_you_need_to_know.dita`

### Adjudicating voluntary leaving

Source topic: `en_EN/task/vllevel2_rc/adjudicating_voluntary_leaving.dita`

The adjudication process is the same (though the inputs are different) for the following types of voluntary leaving:

- permanently leaving employment

- taking a temporary leaving of absence from employment (Refer to Adjudicating a leave of absence — Level 2 )
         [Adjudicating a leave of absence — Level 2](/en/procedure/task/adjudicating_loa_l2.shtml)

- leaving employment early in anticipation of a layoff or the end of the term of employment

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3246.dita) 

### Imposing a disqualification or disentitlement

Source topic: `en_EN/task/vllevel2_rc/imposing_a_disqualification_or_disentitlement.dita`

Once it is determined that the client did not have just cause for voluntarily leaving the employment, the officer must determine whether an indefinite disqualification or disentitlement applies.

**Imposing a disentitlement**

If the client voluntarily left the employment within 3 weeks of an anticipated layoff or the end-of-term employment, the 44 - Loss of employment in anticipation of layoff disentitlement (D44) is imposed. The D44 is imposed for a definite period only (maximum 3 weeks).

**Imposing a disqualification**

If the client voluntarily left the employment more than 3 weeks before an anticipated layoff and in all other cases , the indefinite D11 is imposed.

**Suspending a disqualification or disentitlement**

The D11 disqualification and the D44 disentitlement are suspended when special benefits are claimed and otherwise payable.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4936.dita) 

### Imposing a disqualification or disentitlement — BPCs between w/c 2310 and w/c 2361

Source topic: `en_EN/task/vllevel2_rc/imposing_a_disqualification_or_disentit_0170a30a.dita`

Once it is determined that the client left the employment without just cause, the officer determines whether an indefinite disqualification or disentitlement applies.

On a renewal claim, if the client left the employment without just cause, the officer imposes an indefinite disqualification on the claim for regular benefits. However, if the client has worked since this voluntary leaving and the RFS from that employment is not contentious or was adjudicated and allowed, the officer determines if the client has worked enough hours in insurable employment since the BPC to establish a new claim. If so, the claim may be terminated to establish a new initial claim using the hours of insurable employment that the client accumulated since the BPC.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3249.dita) 

**Example #1**

In this chart, a renewal application was filed in w/c 2327 and aD11 was imposed at that time. The client applies for a second renewal for w/c 2341 after being laid off in w/c 2340. It is not possible to terminate the D11. Since the client has worked enough hours since BPC 2310 was established and the last RFS is not contentious (layoff), the officer can terminate the claim and establish a new initial claim, effective w/c 2341. The officer uses all hours from ROE 1 and ROE 2 to calculate BPC 2341.

**Example #2**

In this chart, a renewal application was filed in w/c 2341.The voluntary leaving on ROE 2 has to be adjudicated because it falls in the benefit period (BP). If the voluntary leaving is allowed, the officer can renew the claim effective w/c 2341 and the client can receive any remaining entitlement on this claim. However, if adjudication results in a just cause not shown decision on ROE 2, the officer renews the claim with a disqualification. Since the client has accumulated 500 hours since BPC 2310 was established and the last RFS is not contentious, the client can request to terminate BPC 2310 and establish a new initial claim effective w/c 2341.

**Example #3**

In this chart, a renewal application was filed in w/c 2341. The voluntary leaving on ROE 2 has to be adjudicated because it falls in the BP. The client has accumulated only 390 hours since BPC 2310 was established. If the voluntary leaving is allowed, the officer renews the claim without a disqualification. If just cause is not shown, the officer renews the claim with a D11. 

### Fact-finding

Source topic: `en_EN/task/vllevel2_rc/fact-finding.dita`

The adjudicating officer gathers all relevant information and completes all fact-finding before adjudicating the issue. The Level 2 officer must:

- offer the client and the employer the opportunity to provide information concerning the RFS;

- allow both parties to provide an explanation or clarification when there are contradictory statements;

- give the client the opportunity to provide a final rebuttal;

- take this information into account when adjudicating the issue; and

- give the client the benefit of the doubt when the facts provided by the client and those provided by the employer are equally credible.

**Fact-finding — Voluntary leaving for personal reasons**

When clients voluntarily leave their employment strictly for personal reasons (e.g. returning to school, changing careers, providing care for an ill child), the officer does not contact the employer again after the initial fact-finding if:

- the facts are credible;

- considering all factors, it is unlikely that the employer has any information about the existence or absence of other reasonable alternatives for the client.

**Client wishes that employer not be contacted**

In cases where the voluntary leaving is not strictly for personal reasons and the client does not want the employer to be contacted, officers must explain that they are legally required to fact-find with the employer.

**Refusing employment**

Voluntarily leaving an employment can also include:

- refusing employment that is offered as an alternative to an anticipated loss of employment (the voluntary leaving occurs when the loss of employment occurs);

- refusing to resume an employment (the voluntary leaving occurs when the employment is meant to resume;

- refusing to continue an employment after the work, undertaking or business of the employer is transferred to another employer.

**Mandatory retirement**

Human rights legislation in Canada prohibits mandatory retirement. Very few occupations are exempt from this legislation. Some employers may be able to demonstrate a genuine reason for mandatory retirement, however these cases are rare.

In cases of mandatory retirement, clients do not voluntarily leave their employment. The separation is initiated by the employer. Consequently, a Level 2 officer must adjudicate the RFS as a dismissal and determine whether the client lost the employment due to misconduct.
       [dismissal](/en/procedure/task/dismissal_ds_rc.shtml)

An ROE is not required to adjudicate a voluntary leaving. 

### Imposing a disqualification or disentitlement

Source topic: `en_EN/task/vllevel2_rc/imposing_a_disqualification_or_disentitlement.dita`

Once it is determined that the client did not have just cause for voluntarily leaving the employment, the officer must determine whether an indefinite disqualification or disentitlement applies.

**Imposing a disentitlement**

If the client voluntarily left the employment within 3 weeks of an anticipated layoff or the end-of-term employment, the 44 - Loss of employment in anticipation of layoff disentitlement (D44) is imposed. The D44 is imposed for a definite period only (maximum 3 weeks).

**Imposing a disqualification**

If the client voluntarily left the employment more than 3 weeks before an anticipated layoff and in all other cases , the indefinite D11 is imposed.

**Suspending a disqualification or disentitlement**

The D11 disqualification and the D44 disentitlement are suspended when special benefits are claimed and otherwise payable.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4936.dita) 

### Previously deferred decision

Source topic: `en_EN/task/vllevel2_rc/previously_deferred_decision.dita`

When converting or renewing a claim, any RFS for which adjudication had previously been deferred must be adjudicated.

When the claim is calculated, if the RFS adjudication is deferred, a disqualification is automatically imposed and appears in FTS on the Disqualification/Disentitlement screen.

The officer always verifies if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a D11 was imposed, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer rescinds the D11 that is on file and updates the Special Condition field on the ROE in RCM to Voluntary Leaving - Just cause shown .

If the RFS is now not allowed, the officer updates the Special Condition field on the ROE in RCM to Voluntary Leaving - No just cause . 

### Adjudication not previously required — Specialized ACP process

Source topic: `en_EN/task/vllevel2_rc/adjudication_not_previously_required__s_a89cd8c4.dita`

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the qualifying period (QP). The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0126.dita) 

### Automated adjudication

Source topic: `en_EN/task/vllevel2_rc/automated_adjudication.dita`

ACP does not automate a Level 2 decision for voluntary leaving. 

### Notifying the employer

Source topic: `en_EN/task/vllevel2_rc/notifying_the_employer.dita`

The employer must be notified in writing of the decision and provided with the right to request a reconsideration in the case of voluntary leaving when the reasons for leaving are work-related, but just cause for leaving was shown. 

### Claim action status and processing the claim

Source topic: `en_EN/task/vllevel2_rc/claim_action_status_and_processing_the_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . All Adjudication Issue (ADJ) WIs must be completed before the system finalizes the renewal. There is a Resolve Issue tab for ADJ Voluntary leaving WIs which includes screens where the officer documents the decision.

When the ADJ WI is completed, the system creates a ROD. When the renewal is finalized, the system generates the required transactions based on the Resolve Issue screens and removes the stop payment (MA02). If the voluntary leaving is allowed and the employer must be notified, the system automates the Z-01-00-00 letter, or creates a Correspondence (COR) WI. If the voluntary leaving is not allowed, the system creates a COR WI for the D-01-00-00 or N-00-00-00 letter.

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is required only if the RFS on the most recent ROE in the QP is contentious. In addition, the officer does not use the common entrance requirement (CER) of 420 hours of insurable employment to determine if the client requalifies after a disqualifying event. Instead, the client needs to have worked at least one hour in insurable employment since the disqualifying event and to have filed an EI application.

If the RFS since the disqualifying event on claims with a BPC between w/c 2310 and w/c 2361 is either non-contentious or is adjudicated and allowed, the officer can establish a new claim without a disqualification using the hours from all the ROEs in the QP.

If the client does not show just cause, the officer notifies the client of the decision verbally and in writing. When preparing the ACS letter, the officer chooses the attribute informing the client that the minimum number of hours is required to qualify for benefits, even when a new claim can be established. 

### Previously adjudicated voluntary leaving

Source topic: `en_EN/task/vllevel2_rc/previously_adjudicated_voluntary_leaving.dita`

In some cases, the ADJ WI may be for a voluntary leaving issue that was adjudicated previously. The officer indicates on the Resolve Issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the appropriate special condition based on the previous decision. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/vllevel2_rc/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/fr/procedure/task/determining_issue_referred_integrity.shtml)

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/determining_issue_referred_integrity.shtml)

**Pending the Adjudication Issue (ADJ) WI when the reason for separation (RFS) is referred to Integrity**

When the RFS is referred to Integrity, the officer moves the ADJ WI to Pending until the investigation is complete and the case is adjudicated. When the ROD for the Integrity case is created, the ADJ WI for the RFS moves to the officer’s current workload. The officer then completes the ADJ WI by selecting the Decision already on file option. 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/vllevel2_rc/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the voluntary leaving is not required if the employment is not insurable either because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, an authorized user must delete the ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4925.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_3246.dita`

Note:

For information regarding RFS issues resulting from a client not complying with the employer’s COVID-19 vaccination policy, the officer refers to the EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo) .
       [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml)

     [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4966.dita`

Note:

ROEs for employment after the event must be on file in order to determine if the client has enough hours since the voluntary leaving to establish a new claim in order to gain relief from the disqualification. If the ROEs are not on file, the claim is renewed with a disqualification and the onus is on the client to provide evidence of sufficient hours since the event to either rescind the disqualification or establish a new claim. 

### Note

Source topic: `en_EN/common_notes/note_c_3249.dita`

Note:

When assessing whether to establish a new claim, officers keep in mind that the Budget 2021 temporary measures do not apply to new claims with a BPC of w/c 2362 or later. 

### Note

Source topic: `en_EN/common_notes/note_c_4936.dita`

Note:

The client may report voluntary leaving on the application for benefits but the ROE indicates a non-contentious RFS. In this situation, fact-finding is required. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the WI is completed indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0126.dita`

Note:

Any contentious RFS issues in the BP must be adjudicated. 

### Note

Source topic: `en_EN/common_notes/note_c_4925.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. 

## Regional considerations

Source topic: `en_EN/task/vllevel2_rc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/vllevel2_rc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/vllevel2_rc/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a previous EI application?

- What is the client’s statement in the Voluntary Leave section of this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the voluntary leaving on this or a previous EI application?

- What benefit type (BT) is the client applying for? 

### In FTS:

Source topic: `en_EN/task/vllevel2_rc/in_fts.dita`

- Have claimant’s reports been processed for the period in question?

- If yes, when was the original statement made? 

### In Imaging:

Source topic: `en_EN/task/vllevel2_rc/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving? 

### In RCM:

Source topic: `en_EN/task/vllevel2_rc/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving?

- Are there other ROEs since the voluntary leaving?

- If so, does the client have enough hours after the voluntary leaving to qualify for benefits? 

## Step by step

Source topic: `en_EN/task/vllevel2_rc/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/vllevel2_rc/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/vllevel2_rc/reviewing_the_file_level_2.dita`

- In NWS, determine if there is a ROD for the voluntary leaving issue on file:

- If there is a ROD for the voluntary leaving, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_rc#DecOnFile)

- If there is no ROD for the voluntary leaving, go to step 2.

- Determine if adjudication can be deferred by consulting the Deferring adjudication procedure.

- Determine if the client is correcting previously provided information or providing previously omitted information and determine if the information may impact the client’s entitlement to previously paid benefits:

- If no, go to step 4.

- If yes, determine if the issue should be referred to Integrity by consulting Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if the employment is not insurable either because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 5.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_rc#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if there is enough information on file to adjudicate the RFS:

- If no, go to step 6.

- If yes, go to step 9. 

#### Fact-finding

Source topic: `en_EN/task/vllevel2_rc/fact-finding_level_2.dita`

- Fact-find with the client and the employer. Refer to the Fact-Finding Guide and Digest 6 — Voluntary leaving employment to determine the questions to ask.

- Determine if the client or employer was reached during fact-finding:

- If the client or employer was reached, go to step 8.

- If the client or employer was not reached or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to step 9.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Voluntary leaving — [employer’s name] — LDW — [client].”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1746.dita) 

#### Adjudicating voluntary leaving

Source topic: `en_EN/task/vllevel2_rc/adjudicating_voluntary_leaving_level_2.dita`

- Determine if the RFS is contentious:

- If the RFS is voluntary leaving, go to step 10.

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS) .
               [Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_rc#NotCont)

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if just cause is shown, considering all evidence provided by both the client and the employer, and in accordance with the principles outlined in the EI, EIR and case law (refer to Digest 6 — Voluntary leaving employment as needed):

- If the client has not shown just cause, go to step 11.

- If the client has shown just cause, go to Just cause shown .
               [Just cause shown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_rc#RFSallowed)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1747.dita)

- Determine if the client left within 3 weeks of an anticipated layoff or end-of-term employment:

- If the client did not leave within 3 weeks of an anticipated layoff or end-of-term employment, go to step 12.

- If the client left within 3 weeks of an anticipated layoff or end-of-term of employment, go to Voluntary leaving before anticipated end of employment — Just cause not shown .
               [Voluntary leaving before anticipated end of employment — Just cause not shown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_rc#D44) 

#### Just cause not shown

Source topic: `en_EN/task/vllevel2_rc/just_cause_not_shown_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Enter the employer’s name.

- Enter the date of the voluntary leaving.

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Relevant Facts: Enter the relevant facts.

- Indicate if the employer agrees with the client’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if required.

- Rationale: Select No and enter any additional information.

- References: Select EIA 30 and enter any additional references.

- Decision: Select Voluntary Leaving - Just cause not shown .

- Do you wish to enter a disentitlement (D-44, anticipated loss of employment)?: Select No .

- Do you wish to terminate an existing disentitlement (D-42, suspension from employment)?: Select the appropriate option and, if required, complete any additional fields.

- Overpayment: Review and, if required, modify the prefilled codes Detection , Infraction and Message fields.

- Select Continue .

- Determine if this employment is the last employment before the renewal:

- If it is not the last employment and the BPC is between w/cs 2310 and 2361 , go to step 15.

- If it is not the last employment and the BPC is w/c 2309 or before , go to step 16.

- If it is not the last employment and the BPC is w/c 2362 or later , go to step 16.

- If it is the last employment, go to step 18.

- Based on the renewal application, determine the renewal week:

- If the renewal week is w/c 2362 or later, go to step 16.

- If the renewal week is between w/cs 2311 and 2361, go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4967.dita)

- Based on the ROEs on file, determine if the client has enough hours since the disqualifying event to qualify for a new claim:

- If the client has enough hours to qualify for a new claim, go to Rescinding a disqualification — Client has enough hours .
               [Rescinding a disqualification — Client has enough hours](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_rc#ClientHasGainedRelief)

- If the client does not have enough hours to qualify for a new claim, go to step 18.

- Based on the ROEs on file, determine if the client has worked enough hours since establishing this BPC to qualify for a new claim:

- If no, go to step 18.

- If yes, go to Budget 2021 — Reason for separation (RFS) measure .
               [Budget 2021 — Reason for separation (RFS) measure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel2_rc#Budegt2021_reason_for_separation)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4968.dita)

- Verbally communicate the decision to the client.

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- In RCM, determine if the ROE is on file:

- If no, go to step 21.

- If yes, update the Special condition field and go to step 21.

- In ACS, create and save a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246): Enter the appropriate date.

- If the client is requesting regular benefits select the following attributes:

- Disqualifications - Definite / Indefinite - Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) .

- D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) (2542): Select Disqualification message .

- Disqualification message (2543): Select D11 - Voluntary leaving .

- D11 - No benefits payable (Date of event: before, on, or after the BPC date) (2544): Select D11 - Date of event after BPC and the appropriate sub-options.

- D11 - Min hrs req for reg ben/Insuf. hrs accum. since event reg/Insuf. hrs/reg+earnings/fishing (2545):

- If the BPC is between w/c 2310 and w/c 2361, select Minimum hours required to qualify for regular benefits .

- If the client has not worked since the disqualifying event, select Minimum hours required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious there are insufficient hours since the disqualifying event to qualify, select Insufficient hours accumulated since event for regular or Insufficient hours accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but you do not have the information or knowledge to complete this block, select Minimum hours required to qualify for regular benefits .

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- Not Entitled to Regular AFTER Special: D10/D11 or Claim is BPNE - Initial or Renewal claim or D42 - D43 (2540): Select D11/D10 imposed - Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491): Select D11 imposed - Special benefits allowed .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D11 - Min hrs for reg ben/Insuf. hrs accum. Since event reg/Insuf. hrs/reg+earnings/fishing):

- If the BPC is between w/c 2310 and w/c 2361, select Minimum hours required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious there are insufficient hours since the disqualifying event to qualify, select Insufficient hours accumulated since event for regular or Insufficient hours accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but you do not have the information or knowledge to complete this block, select Minimum hours required to qualify for regular benefits .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to add the appropriate attributes before sending the draft D-01-00-00 or N-00-00-00 letter in ACS when completing the COR WI.

- Complete the ADJ WI. 

#### Budget 2021 — Reason for separation (RFS) measure

Source topic: `en_EN/task/vllevel2_rc/budget_2021__reason_for_separation_rfs_measure_level_2.dita`

- In NWS, create a Call Back (CB) WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select Initial .

- Benefit type: Select the appropriate option.

- Destination — SCC: Select the Service Canada Centre (SCC) as shown in FTS.

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- Comments: Type “An indefinite disqualification has been imposed on the renewal claim for [employer name — LDP]. The client may have worked sufficient hours since this BPC to establish a new claim under Budget 2021 measures. If additional information is required, contact the client to discuss termination in favour of a new claim.”

- Obtained by: Select Telephone .

- Obtained from: Select Client .

- Select Save .

- Go to step 2.

- Verbally communicate the decision to the client.

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- In ACS, create and save a D-01-00-00 letter for regular benefits, or an N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the following attributes:

- Disqualifications - Definite / Indefinite - Previous / Current / Revision (2970): Select D11 / D10 / Both / Previous disqualification/ Revision (Initial/Renewal or Revision) .

- D11 / D10 / Both / Previous disqualification/Revision (Initial/Renewal or Revision) (2542): Select Disqualification message .

- Disqualification message (2543): Select D11 - Voluntary leaving .

- D11 - No benefits payable (Date of event: before, on, or after the BPC date) (2544): Select D11 - Date of event after BPC and the appropriate sub-options.

- D11 - Min hrs req for reg ben/Insuf. hrs accum. since event reg/Insuf. hrs/reg+earnings/fishing (2545):

- Select Minimum hours required to qualify for regular benefits .

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- Not Entitled to Regular AFTER Special: D10/D11 or Claim is BPNE - Initial or Renewal claim or D42 - D43 (2540): Select (D11/D10) imposed - Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491): Select D11 imposed - Special benefits allowed .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D11 - Min hrs for reg ben/Insuf. hrs accum. Since event reg/Insuf. hrs/reg+earnings/fishing (2547): Select Minimum hours required to qualify for regular benefits .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to add the appropriate attributes before sending the draft D-01-00-00 or N-00-00-00 letter when completing the COR WI.

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/vllevel2_rc/decision_already_on_file_level_2.dita`

- Determine if the appropriate decision is listed:

- If yes, on the list, select the appropriate ROD and select Save . Go to step 4.

- If no, select Decision not in the list .

- Select the appropriate special condition option based on the decision on file and select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/vllevel2_rc/employment_is_not_insurable_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “voluntary leaving — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed people). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Contact an authorized user (team leader or business expertise advisor) to delete the ADJ WI. 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/vllevel2_rc/non-contentious_reason_for_separation_rfs_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving screen as follows:

- Select The reason for separation is not voluntary leaving .

- Select Continue .

- Complete the Not voluntary leaving screen as follows:

- Select the appropriate RFS.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In RCM, determine if the ROE is on file:

- If yes, go to step 5.

- If no, go to step 7.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select the appropriate RFS option and sub-option, if necessary.

- Select Validate .

- Select Submit .

- Determine if the ROE was flagged in error after validation:

- If yes, fix the validation error and go to step 7.

- If no, go to step 7.

- Complete the ADJ WI. 

#### Just cause shown

Source topic: `en_EN/task/vllevel2_rc/just_cause_shown_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Enter the employer’s name.

- Enter the date of the voluntary leaving.

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Relevant Facts: Enter the relevant facts.

- Indicate if the employer agrees with the client’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if required.

- Rationale: Select Yes and enter any additional information.

- References: Enter any additional references.

- Decision: Select Voluntary Leaving - Just cause shown .

- Written Notification: Select the appropriate option and, if required, provide the employer details for the letter.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In FTS, determine if there is a D11 on file because this RFS adjudication was previously deferred:

- If yes, go to step 5.

- If no, go to step 7.

- Determine if the D11 is solely due to this previously deferred RFS issue and if other issues must be adjudicated:

- If no other issues must be adjudicated, go to step 6.

- If other issues must be adjudicated refer to the appropriate tasks for guidance. Then go to step 6.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In RCM, determine if the ROE is on file:

- If no, go to step 8.

- If yes, update the Special condition field and go to step 8.

- Complete the ADJ WI. 

#### Voluntary leaving before anticipated end of employment — Just cause not shown

Source topic: `en_EN/task/vllevel2_rc/voluntary_leaving_before_anticipated_en_d591facb_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Enter the employer’s name.

- Enter the date of the voluntary leaving.

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Relevant Facts: Enter the relevant facts.

- Indicate if the employer agrees with the client’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if required.

- Rationale: Select No and enter any additional information.

- References: Select EIA 33 and enter any additional references.

- Decision: Select Voluntary Leaving - Just cause not shown .

- Do you wish to enter a disentitlement (D-44, anticipated loss of employment)?: Select Yes .

- Input Disentitlement: Enter the disentitlement end date (must be a weekday).

- Overpayment: Review and, if required, modify the prefilled Detection , Infraction and Message codes.

- Do you wish to terminate an existing disentitlement (D42, suspension from employment)? Select No .

- Select Continue .

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- In ACS, create and save a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the following attributes:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 (3021): Select D44 - Leaves employment without just cause within 3 weeks of layoff or end of term .

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text - Footnote (11745): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [X] to [X] because you quit your job with [Text - Name of Employer(s)] on [Date of Event] without just cause within 3 weeks of [being laid off/the end of term].”

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to add the appropriate attributes before sending the draft D-01-00-00 or N-00-00-00 letter in ACS when completing the COR WI.

- Complete the ADJ WI. 

#### Rescinding a disqualification — Client has enough hours

Source topic: `en_EN/task/vllevel2_rc/rescinding_a_disqualification__client_h_d63939aa_level_2.dita`

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI.

- Create a Reminder (REM) WI as follows:

- Complexity: Select Level 2 .

- Reason: Select Other .

- Comments: Type “Rescind this disqualification.”

- Due date: Enter the next working day.

- Language: Select the appropriate option.

- Details: Type “Once the renewal is finalized, if the client has enough hours to gain relief, rescind the D11 and create a ROD to justify the cancellation”.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4969.dita)

- Move the REM WI to Pending as follows:

- Send to my pending workload: Check the box.

- Reason: Select Other .

- Comments: Type “The Claim action status of the renewal claim is In progress.”

- Bring forward date: Enter the next working day.

- Select Save .

- When the REM WI moves to the current workload, determine if the claim has been finalized:

- If no, repeat step 4.

- If yes, go to step 6.

- In NWS, create a ROD and complete the following fields:

- Comments: voluntary leaving — [employer’s name] — [last day worked] — gained relief.

- Details: No disqualification to be imposed as client has sufficient hours since this disqualifying event to establish a new claim. No notification required.

- In FTS determine if a D11 has been imposed:

- If yes, go to step 8.

- If no, go to step 11.

- Determine the claim status (CS):

- If the CS is 6 - Terminated , go to step 9.

- If the CS is 0 - Active , go to step 10.

- Select the File Control Data (M101)/Claim Action transaction:

- Select Reactivate non-blocked claim (M101-12) .

- Select Update .

- Select the Disqualifications/Disentitlements (M161) link and rescind this event’s D11 as follows:

- Select the original disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Disqualification: 11 - Voluntary leaving — just cause not proven .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3257.dita)

- In NWS, create a client Note and type “No D-01-00-00 letter is required.”

- Complete the REM WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_1746.dita`

Note:

Create a new SROC for each conversation with the employer or the client (e.g. if you contacted the employer twice, create 2 SROCs). 

#### Note

Source topic: `en_EN/common_notes/note_c_1747.dita`

Note:

If you are unable to contact the client or the employer, render a decision based on the information on file. 

#### Note

Source topic: `en_EN/common_notes/note_c_4967.dita`

Note:

If the claim’s BPC is w/c 2309 or before, or w/c 2362 or later, the only disqualification that can be rescinded is the D11 that the system imposed on the renewal. 

#### Note

Source topic: `en_EN/common_notes/note_c_4968.dita`

Note:

For claims with BPCs between w/c 2310 and w/c 2361, a national common entrance requirement of 420 hours of insurable employment is required to establish a claim for regular or special benefits. If the client has a violation on file, increased entrance requirements may apply.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

#### Note

Source topic: `en_EN/common_notes/note_c_4969.dita`

Note:

The only disqualification to be rescinded is this decision, which is related to the D11. If there are any other disqualifications on file, they must not be rescinded. 

#### Note

Source topic: `en_EN/common_notes/note_c_3257.dita`

Note:

Use the renewal registration number to rescind the disqualification. Override the 740 error. 

## Policy reference

Source topic: `en_EN/task/vllevel2_rc/policy_reference.dita`

- Digest 6 — Voluntary leaving employment
         [Digest 6 — Voluntary leaving employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- BE 2010-12 — Voluntary Leaving to Attend Approved Training
         [BE 2010-12 — Voluntary Leaving to Attend Approved Training](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2010-12.shtml)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- EIA 32
         [EIA 32](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-32.html)

- EIA 33
         [EIA 33](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-33.html) 
