# Deferring adjudication: Claim other than initial — Special benefits (other than sickness)

Source map: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/defer_adj_renewal_special_ben_other_sickness.ditamap`

## Summary

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/summary.dita`

Summary: In certain situations, adjudication of a contentious reason for separation (RFS) can be deferred on renewal, conversion, or continuing claims for maternity, parental, CCB and family caregiver benefits. 

## What you need to know

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/what_you_need_to_know.dita`

### Conditions

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/conditions.dita`

When a client requests maternity, parental, CCB, or family caregiver benefits, the officer can defer fact-finding and adjudication of a contentious reason for separation (RFS) if the client qualifies for the requested benefit type (BT) and one of the following conditions is met:

- There is an existing indefinite disqualification imposed because a previous adjudication was denied.

- The client qualifies for maternity, parental, CCB or family caregiver benefits and a 46 - Variable entrance requirement not met - special benefits payable disentitlement (D46) is already imposed.

- The client qualifies for maternity, parental, CCB or family caregiver benefits and is not requesting regular benefits for any period after the contentious RFS.

Normally, an indefinite 10 - Dismissal - misconduct proven (D10) or 11 - Voluntary leaving - just cause not proven (D11) disqualification is imposed when the RFS fact-finding and adjudication are deferred, to prevent payments to which the client is not entitled. However, for all initial calculations and recalculations when the BPC is between September 27, 2020 (w/c 2258) and September 25, 2021 (w/c 2309), Unemployment Insurance Calculation (UIC) considers the RFS as non-contentious when the special condition on the ROE is blank or deferred. Consequently, no disqualification is imposed when the adjudication of the RFS is deferred on these claims.

If there is already an indefinite disqualification from a previous RFS adjudication or previous deferral, imposing a second indefinite disqualification prevents the payment of benefits if the first indefinite disqualification is removed.

If more than one contentious RFS is being deferred, use the date of the most recent contentious RFS deferral as the start date of the disqualification. 

### Deferring adjudication on a labour dispute

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/deferring_adjudication_on_a_labour_dispute.dita`

The officer cannot defer a decision on a labour dispute on renewal, conversion and continuing claims. When the claim is established, deferral is impossible. 

### Deferring adjudication on a leave of absence

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/deferring_adjudication_on_a_leave_of_absence.dita`

The decision on a leave of absence can be deferred on an initial or renewal claim for special benefits when all of the following conditions are met:

- the leave of absence is not the RFS on the last ROE; and

- the client started new employment while on a leave of absence from the previous employment; and

- the client has stopped working for the new employer for reasons related to the requested benefit type (BT); and

- the RFS on the last ROE is P , F , or Z .

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3063.dita) 

### Claim action status and processing of the claim

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/claim_action_status_and_processing_of_the_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . All Adjudication Issue (ADJ) WIs must be completed before the system finalizes the renewal. There is a Resolve Issue tab for ADJ WIs which includes screens where the officer documents the decision on voluntary leaving, dismissal and suspension issues. There is no Resolve Issue tab for ADJ WIs when the issue is a voluntary leave of absence. When the ADJ WI is completed, NWS creates a record of decision (ROD) based on the Resolve Issue screens. When the renewal is finalized, the system generates the required transactions (e.g. signature code, disentitlement) based on the Resolve Issue screens. If a disentitlement is imposed, the system creates a Correspondence (COR) WI for the D-01-00-00 letter.

For conversion claims and continuing claims, the officer deferring the adjudication creates the ROD in NWS and inputs the transactions in FTS. 

### Special condition field in RCM

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/special_condition_field_in_rcm.dita`

If the ROE with the contentious RFS is on file, the officer updates the Special condition field based on the Resolve Issue screens. Updating the Special condition field on the ROE does not interfere with the automation of potential subsequent claims. If the client reapplies for benefits and the ROE with Adjudication deferred falls within the new qualifying period (QP), the system creates a new ADJ WI. 

### Example

Source topic: `en_EN/common_notes/note_c_3063.dita`

Example:

ROE 1

Costco — first day of worked: December 5, 2021. Last day worked (LDW): June 12, 2022 — RFS: N - Leave of absence .

ROE 2

General Motors — first day worked: August 1, 2022. LDW: September 15, 2022 — RFS: P - Parental .

- The client takes a leave of absence from his employment with Costco on June 12, 2022. While on leave, the client begins work for a new employer, General Motors on August 1, 2022.

- The client stops working for General Motors to take parental leave. The ROE indicates the RFS is P - Parental and the LDW is September 15, 2022.

- The client requests a renewal for special benefits from the date that he stopped working for General Motors (September 15, 2022). The client meets the entitlement requirements for special benefits so the client’s leave of absence from Costco can be deferred.

The officer manually imposes an indefinite 43 - Leave from employment without just cause disentitlement (D43) from the date the leave began (June 12, 2022). This prevents the payment of regular benefits from the BPC or date of renewal. 

## Regional considerations

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/in_nws.dita`

- Are there any RODs indicating that a D10 or D11 has been adjudicated?

- Is there a Resolve Issue tab for the ADJ WI? 

### In FTS:

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/in_fts.dita`

- Has a D10 or D11 disqualification been imposed as a result of a previous adjudication or a deferral on the claim?

- Has the renewal been finalized? 

### In RCM:

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/in_rcm.dita`

- Is the ROE on file?

- 

## Step by step

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/level_1.dita`

#### Determining if the conditions are met

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/determining_if_the_conditions_are_met_level_1.dita`

- Determine if the RFS is B - Strike or lockout :

- If no, go to step 2.

- If yes, adjudication cannot be deferred. Return to the previous task.

- Determine if the contentious RFS impacts a period in which regular benefits have already been paid:

- If no, go to step 3.

- If yes, adjudication cannot be deferred. Return to the previous task.

- Determine if the RFS is N – leave of absence:

- If no, go to step 4.

- If yes, go to Deferring adjudication on a leave of absence .
               [Deferring adjudication on a leave of absence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_special_ben_other_sickness#level1_item_3)

- In FTS, determine if a D10 or D11 has been imposed because of a previous adjudication or a deferral on the claim:

- If no, go to step 5.

- If yes, go to Inputting the decision .
               [Inputting the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_special_ben_other_sickness#level1_item_2)

- Determine if the client is requesting regular benefits after the date of the contentious RFS:

- If no, go to Inputting the decision .
               [Inputting the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_special_ben_other_sickness#level1_item_2)

- If yes, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious RFS. 

#### Inputting the decision

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/inputting_the_decision_level_1.dita`

- In NWS, determine if there is an ADJ WI with a Resolve Issue tab for the issue under review:

- If yes, go to Inputting the decision — Resolve Issue tab present .
               [Inputting the decision — Resolve Issue tab present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_special_ben_other_sickness#resolve_issue_present)

- If no, go to Inputting the decision — Resolve Issue tab not present .
               [Inputting the decision — Resolve Issue tab not present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_special_ben_other_sickness#resolve_issue_not_present) 

#### Inputting the decision — Resolve Issue tab present

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/inputting_the_decision__resolve_issue_t_b961b717_level_1.dita`

- On the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving or the Level 1 Dismissal screen as follows:

- Select The adjudication has been deferred because the client meets the qualifying conditions for special benefits and the conditions to defer have been met .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In RCM, determine if the ROE for which adjudication is being deferred is on file:

- If yes, go to step 10.

- If no, go to step 11.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3061.dita)

- In NWS, complete the WI for the issue being deferred. 

#### Inputting the decision — Resolve Issue tab not present

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/inputting_the_decision__resolve_issue_t_c247a126_level_1.dita`

- In NWS, create a ROD for the contentious issue being deferred as follows:

- Comments: Enter the following information:

- contentious RFS

- name of the employer

- last day worked for the employer

- deferred adjudication — subsequent RFS

- Details: Type “The adjudication has been deferred because the client meets the qualifying conditions for special benefits and has not requested regular benefits at this time. The adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of the ROE] is deferred for [maternity benefits, parental benefits, CCB or family caregiver benefits].”

- Select Save .

- In RCM, determine if the ROE for which adjudication is being deferred is on file:

- If yes, go to step 9.

- If no, go to step 10.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3056.dita)

- In FTS, select the Disqualifications/Disentitlements (M161) transaction to impose a disqualification as follows:

- Action: Select Add .

- Disqualification: Select the appropriate disqualification:

- If the disqualification is for a dismissal or suspension, select 10 - Dismissal - misconduct proven .

- If the disqualification is for a voluntary leaving or a voluntary leave of absence, select 11 - Voluntary leaving - just cause not proven .

- Effective: Select the w/c of the dismissal or voluntary leaving.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision type: Select the appropriate option.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In NWS, complete the WI for the issue being deferred. 

#### Deferring adjudication on a leave of absence

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/deferring_adjudication_on_a_leave_of_absence_level_1.dita`

- Determine if all conditions are met to defer adjudication on the leave of absence at Level 1:

- leave of absence is not the RFS on the last ROE; and

- the client started new employment while on a leave of absence from the previous employment; and

- the client has stopped working for the new employer for reasons related to the requested BT; and

- the RFS on the client’s last ROE is F , P or Z .

- If all conditions are met, go to step 5.

- If all conditions are not met, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious issue.

- In NWS, create a ROD as follows:

- Comments: Type “ Leave of absence deferred — Employer - LDW [DD-MM-YYYY]. ”

- Details: Type “Adjudication of leave of absence from [full name of the employer, LDW for the employer and ROE serial number] is deferred because the client has worked since the leave of absence and has stopped working for reasons related to special benefits. The RFS on the ROE is F, P or Z.

- Select Save .

- In FTS, select the Disqualification/Disentitlements (M161) transaction to impose the disqualification as follows:

- Action: Select Add .

- Disqualification: Select 11 - Voluntary leaving - just cause not proven.

- Effective: Enter the w/c for the effective start date of the leave of absence.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message : Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Decision Type: Select the appropriate option.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- In RCM, determine if the ROE for which adjudication is being deferred is on file:

- If yes, go to step 8.

- If no, go to step 9.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3056.dita)

- In NWS, complete the WI for the issue being deferred. 

#### Note

Source topic: `en_EN/common_notes/note_c_3061.dita`

Note:

If selecting Submit causes the ROE to be flagged with an error, do not fix the error. The ROE is corrected if and when the client applies for a subsequent claim. 

#### Note

Source topic: `en_EN/common_notes/note_c_3056.dita`

Note:

If selecting Submit causes the ROE to be flagged with an error, do not fix the error. The ROE is corrected when the client applies for a subsequent claim. 

### Level 2

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/level_2.dita`

#### Determining if the conditions are met

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/determining_if_the_conditions_are_met_level_2.dita`

- Determine if the RFS is B - Strike or lockout :

- If no, go to step 2.

- If yes, adjudication cannot be deferred. Return to previous task.

- Determine if the contentious RFS impacts a period in which regular benefits have already been paid:

- If no, go to step 3.

- If yes, adjudication cannot be deferred. Return to the previous task.

- Determine if the RFS is N – Leave of absence :

- If no, go to step 4.

- If yes, go to Deferring adjudication on a leave of absence .
               [Deferring adjudication on a leave of absence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_special_ben_other_sickness#level2_item_3)

- In FTS, determine if a D10 or D11 has been imposed because of a previous adjudication or a deferral on the claim:

- If no, go to step 5.

- If yes, go to Inputting the decision .
               [Inputting the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_special_ben_other_sickness#level2_item_2)

- Determine if the client is requesting regular benefits after the date of the contentious RFS:

- If no, go to Inputting the decision .
               [Inputting the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_special_ben_other_sickness#level2_item_2)

- If yes, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious RFS. 

#### Inputting the decision

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/inputting_the_decision_level_2.dita`

- In NWS, determine if there is an ADJ WI with a Resolve Issue tab for the issue under review:

- If yes, go to Inputting the decision — Resolve Issue tab present .
               [Inputting the decision — Resolve Issue tab present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_special_ben_other_sickness#resolve_issue_present_lv2)

- If no, go to Inputting the decision — Resolve Issue tab not present .
               [Inputting the decision — Resolve Issue tab not present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_renewal_special_ben_other_sickness#resolve_issue_not_present_lv2) 

#### Inputting the decision — Resolve Issue tab present

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/inputting_the_decision__resolve_issue_t_b961b717_level_2.dita`

- On the Resolve Issue tab of the ADJ WI, complete the Level 2 Voluntary leaving or the Level 2 Dismissal screen as follows:

- Select The adjudication has been deferred because the client meets the qualifying conditions for special benefits and the conditions to defer have been met .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In RCM, determine if the ROE for which adjudication is being deferred is on file:

- If yes, go to step 10.

- If no, go to step 11.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3056.dita)

- In NWS, complete the WI for the issue being deferred. 

#### Inputting the decision — Resolve Issue tab not present

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/inputting_the_decision__resolve_issue_t_c247a126_level_2.dita`

- In NWS, for the contentious issue being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious RFS

- name of the employer

- last day worked for the employer

- deferred adjudication — subsequent RFS

- Details: Type “The adjudication has been deferred because the client meets the qualifying conditions for special benefits and has not requested regular benefits at this time. The adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of the ROE] is deferred for [maternity benefits, parental benefits, CCB or family caregiver benefits].”

- Select Save .

- In RCM, determine if the ROE for which adjudication is being deferred is on file:

- If yes, go to step 9.

- If no, go to step 10.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3056.dita)

- In FTS, select the Disqualifications/Disentitlements (M161) transaction to impose a disqualification as follows:

- Action: Select Add .

- Disqualification: Select the appropriate disqualification:

- If the disqualification is for a dismissal or suspension, select 10 - Dismissal - misconduct proven .

- If the disqualification is for a voluntary leaving or a voluntary leave of absence, select 11 - Voluntary leaving - just cause not proven .

- Effective: Select the w/c of the dismissal or voluntary leaving.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision type: Select the appropriate option.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In NWS, complete the WI for the issue being deferred. 

#### Deferring adjudication on a leave of absence

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/deferring_adjudication_on_a_leave_of_absence_level_2.dita`

- Determine if all conditions are met to defer the leave of absence:

- leave of absence is not the RFS on the last ROE; and

- the client started new employment while on a leave of absence from the previous employment; and

- the client has stopped working for the new employer for reasons related to the requested BT; and

- the RFS on the client’s last ROE is F , P or Z .

- If all conditions are met, go to step 5.

- If all conditions are not met, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious issue.

- In NWS, create a ROD as follows:

- Comments: Type “Leave of Absence deferred — Employer-LDW [DD-MM-YYYY].”

- Details: Type “Adjudication of leave of absence from (full name of the employer, last day worked for the employer and ROE serial number) is deferred because the client has worked since the leave of absence and has stopped working due to reasons related to the requested benefit type. The RFS on the ROE is F, P or Z.”

- Select Save .

- In FTS, select the Disqualification/Disentitlements (M161) transaction to impose the disqualification as follows:

- Action: Select Add .

- Disqualification: Select 11 - Voluntary leaving - just cause not proven .

- Effective: Enter the w/c of the effective start date of the leave of absence.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision Type: Select the appropriate option.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration open for subsequent transactions, select D - No .

- Select Update .

- In RCM, determine if the ROE for which adjudication is being deferred is on file:

- If yes, go to step 8.

- If no, go to step 9.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3056.dita)

- In NWS, complete the WI for the issue being deferred. 

## Policy reference

Source topic: `en_EN/task/defer_adj_renewal_special_ben_other_sickness/policy_reference.dita`

 
