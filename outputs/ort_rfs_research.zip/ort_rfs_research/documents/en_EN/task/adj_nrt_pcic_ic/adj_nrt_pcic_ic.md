# Adjudicating non-referred training: Family caregiver benefits — Initial Claim

Source map: `en_EN/task/adj_nrt_pcic_ic/adj_nrt_pcic_ic.ditamap`

## Summary

Source topic: `en_EN/task/adj_nrt_pcic_ic/summary.dita`

Summary: When a client declares non-referred training on the EI application or while an initial claim is in progress, adjudication is required to determine entitlement to benefits during the training period. 

## What you need to know

Source topic: `en_EN/task/adj_nrt_pcic_ic/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/task/adj_nrt_pcic_ic/training_reported_between_september_27__5ecd71c7.dita`

A transitional measure which ACP automatically adjudicated and allowed all training effective September 27, 2020 has ended on September 11, 2021. The intent of this measure was to prevent any delay in payment to clients who reported training.

The client must still meet the entitlement conditions for family caregiver benefits while attending non-referred training. A client attending non-referred training may provide information on a claimant’s report or during a conversation with an agent that brings into question the entitlement to family caregiver benefits. In this case, the agent creates a WI for the training issue and follows normal adjudication procedures, even if ACP initially allowed the training. 

### Adjudication required on manually registered claims

Source topic: `en_EN/task/adj_nrt_pcic_ic/adjudication_required_on_manually_regis_d5cd9e4c.dita`

Training was automatically adjudicated and electronic records of decision (RODs) were created only on claims that were automated in ACP.

The agent manually registers claims that are not automated in ACP. Training is not automatically adjudicated on manually registered claims. Instead, ACP assigns an Adjudication Issue (ADJ) WI to an agent because it could not automate the decision. Adjudication of these training ADJ WIs is required , and the agent follows the appropriate procedures to resolve them. Even if ACP initially allowed training, when a training ADJ WI is assigned (e.g. upon renewal), the agent must adjudicate. Additionally, if it is determined that a disentitlement applies from the start date of the training course, the Level 2 agent imposes a retroactive D3. 

### Impact of training on family caregiver benefits

Source topic: `en_EN/task/adj_nrt_pcic_ic/impact_of_training_on_family_caregiver_benefits.dita`

When adjudicating non-referred training for a client receiving family caregiver benefits, the issue is not availability, but whether the client continues to care for the patient for whom the benefits are payable. This includes clients who are attending short-term training courses and targeted initiatives. Refer to the job aid for a complete list of non-referred short-term courses and targeted initiatives.
       [job aid](/en/procedure/generic/additionalresources/shortterm_courses_ti.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1676.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1677.dita) 

### Targeted initiatives and short-term courses

Source topic: `en_EN/task/adj_nrt_pcic_ic/targeted_initiatives_and_short-term_courses.dita`

When clients receiving family caregiver benefits report that they are attending a targeted initiative or short-term course, the total daily or weekly attendance hours is not considered.

If the client is attending a short-term course referred under EIA 25, refer to Confirming referred training: Special benefits — Initial claim .
       [Confirming referred training: Special benefits — Initial claim](/en/procedure/task/confirmreftrng_sb_in.shtml) 

### Levels of decision

Source topic: `en_EN/task/adj_nrt_pcic_ic/levels_of_decision.dita`

Level 1 is authorized to allow benefits when both of the following conditions are met:

- The training is under 25 hours per week.

- The training location is in an area that allows the client to continue to provide care and support to the patient.

There must be no doubt that the client is still providing care. If the client makes any statement that creates doubt that the client is providing care, the issue must be referred to Level 2. 

### Care or support

Source topic: `en_EN/task/adj_nrt_pcic_ic/care_or_support.dita`

Care is defined as:

- all care that is required because of a critically ill or injured patient’s state of health, other than the care provided by a health care professional.

Support is defined as:

- all psychological or emotional support that is required because of a critically ill patient’s state of health.

The definition of care or support can also include situations where the client spends time each day with the critically ill patient in the home, a hospice or a medical facility.

An individual claiming this benefit type may require a short break from providing care or support for the critically ill patient. That is why benefits are not automatically denied when the client stops providing care for only a few days. The agent determines whether the client continues to be entitled to benefits based on the merits of each individual case.

If it becomes apparent that the client is not providing care or support based on the definitions above, the client is disentitled from benefits.

For more information, the agent can refer to Digest 22.2.4 — Care or support of critically ill or injured child or adult .
       [Digest 22.2.4 — Care or support of critically ill or injured child or adult](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-22/family-caregiver-benefits.html#a22_2_4) 

### Imposing a disentitlement

Source topic: `en_EN/task/adj_nrt_pcic_ic/imposing_a_disentitlement.dita`

If the client requests family caregiver benefits but does not meet the entitlement conditions, the agent imposes a 61 - Family caregiver benefits for children or adults - Does not meet the entitlement Conditions (D61) on the claim. 

### Processing the claim

Source topic: `en_EN/task/adj_nrt_pcic_ic/processing_the_claim.dita`

During processing, an initial claim displays the following status:

- In Progress (Manual)

- Recalculation — In Progress (Manual)

The processing of family caregiver benefits claims is not automated. A trip-down Claim Assessment WI occurs immediately after the registration and the setup of the claim.

There is a Resolve Issue tab for Adjudication (ADJ) Training WIs which includes screens where the agent documents the decision. When the ADJ WI is completed, the system creates a record of decision based on the Resolve Issue screens. When the claim is established, the system also generates the required transactions (e.g. training information, disentitlement) based on the Resolve Issue screens. 

### Communicating the decision

Source topic: `en_EN/task/adj_nrt_pcic_ic/communicating_the_decision.dita`

If the training is not allowed and a disentitlement is imposed, the system creates a Correspondence WI for the N-00-00-00 letter. No letter is sent when the training is allowed. 

### Note

Source topic: `en_EN/common_notes/note_c_1676.dita`

Note:

If a client quits employment or refuses an offer of employment to attend a non-referred training course, a non-referred short-term training course or a targeted initiative, agents adjudicates the reason for separation or refusal of employment on a separate WI. 

### Note

Source topic: `en_EN/common_notes/note_c_1677.dita`

Note:

If adjudication is part of a recalculation, the agent refers to Adjudicating non-referred training: Family caregiver benefits — Continuing claim .
       [Adjudicating non-referred training: Family caregiver benefits — Continuing claim](/en/procedure/task/adj_nrt_pcic_cc.shtml)

     [Adjudicating non-referred training: Family caregiver benefits — Continuing claim](/en/procedure/task/adj_nrt_pcic_cc.shtml) 

## Regional considerations

Source topic: `en_EN/task/adj_nrt_pcic_ic/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/adj_nrt_pcic_ic/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/adj_nrt_pcic_ic/untitled_section.dita`

In FTS:

- Is there training information in the Project tab?

In NWS:

- Was the training questionnaire completed in AW?

- Is there an SROC or an Action Item WI with the training information, from either the Part-time Training checklist or the Training Course Information (INS3141) form?

In Imaging:

- Is there non-referred training information or the INS3141 form? 

## Step by step

Source topic: `en_EN/task/adj_nrt_pcic_ic/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/adj_nrt_pcic_ic/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/adj_nrt_pcic_ic/reviewing_the_file_level_1.dita`

- Determine if the following non-referred training details are on file:

- Number of hours of training per week (if the client is attending regular non-referred training)

- Location of the training

- Start date of training

- If not all of the training details are on file, go to step 2.

- If all of the training details are on file, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/adj_nrt_pcic_ic/fact-finding_level_1.dita`

- Fact-find with the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_ic#reassign)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue : Select Training .

- Comments : Type “Non-referred training — family caregiver.”

- Details : Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/adj_nrt_pcic_ic/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the client reported training in error, was engaged in the training before the benefit period or is not attending training:

- If any of these conditions are met, go to Training not an issue .
               [Training not an issue](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_ic#TrainingNotIssue)

- If the client did not report training in error, go to step 6.

- Determine the type of training the client is attending:

- If the client is attending a short-term training course or a targeted initiative, go to step 7.

- If the client is attending regular non-referred training, go to step 8.

- Determine if the short-term course or targeted initiative is at a location that allows the client to provide care or support to the patient while attending:

- If the course or initiative is at a location that allows the client to provide care or support to the patient while attending, go to step 8.

- If the course or initiative is at a location that may prevent the client from providing care or support to the patient while attending, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_ic#reassign)

- Determine if both of the following conditions are met:

- The non-referred training is less than 25 hours per week.

- The non-referred training is not at a location that prevents the client from providing care or support to the patient while attending the course.

- If both conditions are met, go to step 9.

- If either condition is not met, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_ic#reassign)

- Determine if the client has made any statement that creates doubt that the client is providing care for the patient for whom the benefits are payable while on the non-referred training:

- If there is no doubt that the client is providing care for the patient, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_ic#Entitlement)

- If there is doubt that the client is providing care for the patient, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_ic#reassign) 

#### Training not an issue

Source topic: `en_EN/task/adj_nrt_pcic_ic/training_not_an_issue_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Training screen as follows:

- Select The facts on file show training was declared in error by the client .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI for the training issue. 

#### Entitlement conditions met

Source topic: `en_EN/task/adj_nrt_pcic_ic/entitlement_conditions_met_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Training screen as follows:

- Select Based on the information on file, the criteria to allow the decision to be made at Level 1 have been met (National Policy on Levels of Decision) .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Verify the information on the Record of Decision screen presented:

- Check I agree .

- Complete the ADJ WI for the training issue. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/adj_nrt_pcic_ic/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the WI as follows:

- Destination : Select Next Available User .

- Complexity : Select Level 2 .

- Reason : Select Unable to Complete .

- Details : Type the applicable reason:

- “Unable to contact client for fact-finding.”

- “Not within Level 1 authority — The non-referred training is more than 25 hours per week.”

- “The non-referred training is at a location that prevents the client from providing care or support to the patient.”

- “There is doubt as to whether the client is providing care for the patient on non-referred training.”

- Select OK .

- When the Warning window is displayed, select Ok . 

### Level 2

Source topic: `en_EN/task/adj_nrt_pcic_ic/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/adj_nrt_pcic_ic/reviewing_the_file_level_2.dita`

- Determine if the following non-referred training details are on file:

- Number of hours of training per week (if the client is attending regular non-referred training)

- Location of the training

- Start date of training

- If not all of the training details are on file, go to step 2.

- If all of the training details are on file, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/adj_nrt_pcic_ic/fact-finding_level_2.dita`

- Fact-find with the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 5.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue : Select Training .

- Comments : Type “Non-referred training — family caregiver.”

- Details : Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating non-referred training

Source topic: `en_EN/task/adj_nrt_pcic_ic/adjudicating_non-referred_training_level_2.dita`

- Determine if the client reported training in error, completed the training course before the benefit period or is not attending training:

- If any of these conditions are met, go to Training not an issue .
               [Training not an issue](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_ic#TrainingNotAnIssuel2)

- If none of these conditions are met, go to step 6.

- Adjudicate the non-referred training according to the entitlement principles found in Digest 22.5.0 Attending a course of instruction :

- If the client has met the entitlement conditions, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_ic#nft_ecm)

- If the client has not met the entitlement conditions, go to Entitlement conditions not met .
               [Entitlement conditions not met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_ic#nft_ecnm) 

#### Training not an issue

Source topic: `en_EN/task/adj_nrt_pcic_ic/training_not_an_issue_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Training is not an issue .

- Select Continue .

- Complete the Training is not an issue screen as follows:

- Relevant Facts: Indicate why the training is not an issue.

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale: Select the reason why training is not an issue.

- References: Enter any additional references.

- Verify the information on the Record of Decision screen

- Check I agree .

- Complete the ADJ WI for the training issue. 

#### Entitlement conditions met

Source topic: `en_EN/task/adj_nrt_pcic_ic/entitlement_conditions_met_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Engaged in non-referred training.

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select the appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Complete the Engaged in non-referred training screen as follows:

- Relevant Facts:

- Indicate whether the client has completed the training course.

- Indicate whether the client voluntarily left employment to take the course and provide additional information if applicable.

- Summarize the evidence.

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale:

- Based on the evidence, is it determined that the client’s involvement in training prevents him or her from providing care or support for a critically ill family member? Select No .

- Enter any additional rationale information.

- References: Enter any additional references.

- Decision: Select Allowed - care entitlement condition is met .

- Select Continue .

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI for the training issue. 

#### Entitlement conditions not met

Source topic: `en_EN/task/adj_nrt_pcic_ic/entitlement_conditions_not_met_level_2.dita`

- Verbally communicate the decision to the client.

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select Engaged in non-referred training .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start: Select the appropriate option:

- If the training starts at or before the BPC, select BPC .

- If the training starts after the BPC, select Specific date and enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Complete the Engaged in non-referred training screen as follows:

- Relevant Facts:

- Indicate whether the client has completed the training course.

- Indicate whether the client voluntarily left employment to take the course and provide additional information if applicable.

- Summarize the evidence.

- Credibility: Indicate whether credibility was a factor in the decision and, if required, complete any additional fields.

- Rationale:

- Based on the evidence, is it determined that the client’s involvement in training prevents him or her from providing care or support for a critically ill patient? Select Yes .

- Enter any additional rationale information.

- References: Enter any additional references.

- Decision: Select Not allowed - Disentitlement, family caregiver benefits, entitlement conditions not met (D-61) .

- Disentitlement start: Select the appropriate option:

- Select BPC .

- Select Specific date and enter the start date (Monday to Friday).

- Disentitlement end: Select the appropriate option:

- If the training has ended, select the corresponding end date of the disentitlement.

- If the training has not ended, select Indefinite .

- Overpayment: Review and, if required, modify the prefilled Detection , Infraction and Message fields.

- Select Continue .

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065)

- If the BT was family caregiver for children, select Family caregiver benefits for children denied - D61/D62/D63/Free text (11282) .

- Select D61 - Not entitled to family caregiver benefits for children - Various reasons (11283) .

- Select D61 - Client does not provide care or support to the critically Ill or injured child .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Select the appropriate dates from the drop down calendar.

- If the BT was family caregiver for adults, select Family caregiver benefits for adults denied - D61/D62/D63 / Free Text (11281) .

- Select D61 - Not entitled to family caregiver benefits for adults - Various reasons (11276) .

- Select D61 - Client does not provide care or support to the critically ill or injured adult .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Select the appropriate dates from the drop down calendar.

- Overpayment messages (2452) .

- Right to Request a Reconsideration (no Blank Option) (4169): Select Right to Request a Reconsideration .

- This letter replaces or Footnote (2365): Type “You have not proven that you are caring for your family member while attending a course of instruction on your own initiative.”

- Overpayment messages (2452) .

- Right to Request a Reconsideration (no Blank Option) (4169): Select Right to Request a Reconsideration .

- This letter replaces or Footnote (2365): Type “You have not proven that you are caring for the critically ill or injured family member while attending a course of instruction on your own initiative.”

- In NWS, create a client Note and type “Send the saved N-00-00-00 letter.”

- Complete the ADJ WI for the training issue. 

## Policy reference

Source topic: `en_EN/task/adj_nrt_pcic_ic/policy_reference.dita`

- Digest 10.12.2 — Persons attending courses on their own initiative
         [Digest 10.12.2 — Persons attending courses on their own initiative](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2)

- Digest 22.2.4 — Care or Support of critically ill or injured family member
         [Digest 22.2.4 — Care or Support of critically ill or injured family member](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-22/benefits-parents-critically-ill-children.html#a22_2_4)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
