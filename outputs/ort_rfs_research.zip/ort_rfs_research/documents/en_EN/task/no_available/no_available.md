# Adjudicating otherwise available issues — Initial claim

Source map: `en_EN/task/no_available/no_available.ditamap`

## Summary

Source topic: `en_EN/task/no_available/summary.dita`

Summary: Clients who are entitled to sickness benefits must prove that if not for the illness or injury, they would be available for work. 

## What you need to know

Source topic: `en_EN/task/no_available/what_you_need_to_know.dita`

### Temporary process is no longer in effect — Relaxed requirements

Source topic: `en_EN/task/no_available/temporary_process_is_no_longer_in_effec_dc8cd340.dita`

The simplification measure for relaxed requirements ends September 25, 2021. Effective September 26, 2021, the officer follows normal procedures to adjudicate all availability issues. 

### Defining otherwise available

Source topic: `en_EN/task/no_available/defining_otherwise_available.dita`

Clients’ availability is reviewed as if they are claiming regular benefits. To establish their entitlement, it is necessary to determine if clients would have been available for work if they had been capable of working.

Clients must prove that they would be otherwise available for work for each day in the period of incapacity. They cannot provide proof of capability weeks or months in advance. The information provided must be reviewed to determine if clients have proven their availability. The decision is made on the credibility of the information given. If the facts prove that clients would otherwise be available for work, the officer accepts the information. 

### Not otherwise available — Indicators

Source topic: `en_EN/task/no_available/not_otherwise_available__indicators.dita`

If the issue is related to a contentious reason for separation (RFS), the officer does not review the client’s availability, unless the information on file suggests not otherwise available indicators. If there are indicators on file that suggest the client could not be otherwise available, the officer fact-finds with the client.

There are not otherwise available indicators in the following cases:

- voluntary leaving due to retirement

- voluntary leaving to care for a child or immediate family member

- voluntary leaving due to loss of transportation

- voluntary leaving to go back to school

- leave of absence

- dismissal for unavailability

- vacation pay during a closure period due to vacation

When clients must prove that they are otherwise available for work, the officer cannot defer adjudication if the RFS implies that the client is not otherwise available. 

### 33 - Incapacity proven but not otherwise available disentitlement (D33)

Source topic: `en_EN/task/no_available/33_-_incapacity_proven_but_not_otherwis_d285f3a4.dita`

When clients do not prove that they are otherwise available for work for part or the entire period of incapacity, a D33 must be imposed for the period of time clients are not otherwise available for work.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3874.dita) 

### Incapacity in the maternity window

Source topic: `en_EN/task/no_available/incapacity_in_the_maternity_window.dita`

If a pregnant client has stopped working because of incapacity, she is considered otherwise available for work until the earlier of the following dates:

- the week before the expected date of birth (DOB);

- the week before the actual DOB (if it is on file).

However, if any part of the client’s incapacity falls in the period of prearranged maternity leave, she is not considered otherwise available for work during the entire period of the prearranged maternity leave , and is therefore not entitled to sickness benefits during that period. She is still entitled to maternity benefits during the period of prearranged maternity leave.

When a client is considered otherwise available during the maternity window, an external maternity start week is required to prevent the payment of maternity benefits while the client is entitled to benefits other than maternity.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3875.dita) 

If the client specifically requests sickness benefits for the week of birth, the Level 1 officer can allow the payment of sickness benefits in that week if the actual DOB was the Saturday of that week. If the DOB is any other day of the week, or if the client is requesting sickness benefits beyond the week of birth, the Level 1 officer refers the question to Level 2.

**Minor attached client**

Sickness benefits can be paid for the 14-day period following the DOB when a minor-attached client is receiving regular benefits in the maternity window. A medical certificate is not required to allow this 14-day period, but the client is still required to prove that she is otherwise available for work on each day she requests sickness benefits. Only Level 2 officers can make these decisions.

**Defining minor attached clients — Common entrance requirement (from w/c 2310 to w/c 2361)**

A temporary Budget 2021 measure applies to claims for regular and special benefits, with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure.

**Actual date of birth (DOB) reported**

When the client provides an actual DOB, it is used to determine the length of the maternity window and the start of the parental window (PW). Inputs may be required to ensure that the maternity window and PW are accurate. If a client was receiving sickness benefits before her maternity benefits and she reports an actual DOB, the officer reviews the client’s availability.

If the client provides an actual DOB on an established claim, the officer refers to Actual date of birth provided on an established claim .
       [Actual date of birth provided on an established claim](/en/procedure/task/actual_dob_ec.shtml) 

### Incapacity in the parental window (PW), compassionate care window (CCW) or family caregiver window (FCW)

Source topic: `en_EN/task/no_available/incapacity_in_the_parental_window_pw_co_e46186a2.dita`

Clients who request sickness benefits during the PW, CCW or FCW are not required to prove they would be otherwise available for work, as long as they remain entitled to those benefits. When the sickness period extends beyond the window established for those benefits, or they have exhausted entitlement to those benefits, clients must prove that they are otherwise available to work during that period. They must also provide a medical certificate indicating the start date of their incapacity.

Clients who are not entitled to parental benefits, CCB, or family caregiver benefits must prove that they are available for work to receive regular benefits. If a client is disentitled from regular benefits due to availability and then requests sickness benefits, the client is considered not otherwise available for work and the officer imposes a disentitlement during the period of sickness unless the client proves that the situation has changed since the original decision.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3876.dita) 

### Claim action status and processing an initial claim

Source topic: `en_EN/task/no_available/claim_action_status_and_processing_an_i_8f68a0b8.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When the Claim action status is In Progress , all Adjudication Issue (ADJ) WIs must be completed before the system can calculate the initial claim.

If a letter of decision is required on an initial claim, before completing the ADJ WI, the officer creates a Correspondence (COR) Manual Decision WI indicating the details of the required letter. 

### Note

Source topic: `en_EN/common_notes/note_c_3874.dita`

Note:

If a client is entitled to other special benefits but is considered not otherwise available, the client’s entitlement to those other benefits should be considered. The officer does not impose a D33 for those weeks if the client is entitled to and agrees to receive the other benefit type (BT). 

### Example

Source topic: `en_EN/common_notes/note_c_3875.dita`

Example:

The client planned and made arrangements with her employer to start her maternity leave June 3, 2019. The client becomes ill in March 2019, and her doctor recommends that she take sick leave until the delivery date. The client is not due until July 1, 2019. She is not otherwise available as of June 3 because she already made arrangements to be on maternity leave. Therefore, she cannot receive sickness benefits between June 2 and June 30, even though her doctor recommended that she take sick leave during this period. She could, however, receive maternity benefits. 

### Example

Source topic: `en_EN/common_notes/note_c_3876.dita`

Example:

The client applied for parental benefits and was not entitled. The client subsequently applied for regular benefits. The client has to prove that he is available for work while receiving regular benefits. If the client is deemed not available due to caring for the child and the client becomes sick, the client is not considered otherwise available during the period of sickness. The client would still be caring for the child regardless of the benefits requested and therefore, not available for work. 

## Regional considerations

Source topic: `en_EN/task/no_available/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/no_available/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/no_available/in_nws.dita`

- Are there documents related to the issue? 

### In FTS:

Source topic: `en_EN/task/no_available/in_fts.dita`

- Is the client requesting sickness benefits in the maternity window?

- Is the client requesting sickness benefits during the PW, CCW or FCW? 

### In Imaging:

Source topic: `en_EN/task/no_available/in_imaging.dita`

- Are there documents related to the issue? 

## Step by step

Source topic: `en_EN/task/no_available/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/no_available/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/no_available/reviewing_the_file_level_1.dita`

- Determine if adjudication can be deferred by referring to Deferral of adjudication .

- Determine if the file contains the information required to adjudicate:

- If additional details are needed, go to step 3.

- If additional details are not needed, go to step 6. 

#### Fact-finding

Source topic: `en_EN/task/no_available/fact-finding_level_1.dita`

- Fact-find with the client or the employer. Refer to the National Fact-Finding and Documentation Policy if necessary.

- Determine if the client or the employer was reached during fact-finding or responded to the N-10-00-00 ACS letter:

- If yes, go to step 5.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#reassignL2)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Otherwise available — spoke with [client or employer].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/no_available/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Based on the BT, go to the appropriate step:

- If the client is requesting sickness benefits before or during the maternity window, go to step 7.

- If the client is requesting sickness benefits during the PW, CCW or FCW, go to step 11.

- For all other requests for sickness benefits, go to step 12.

- Determine if all of the conditions are met to allow the otherwise available issue at Level 1:

- The client is requesting sickness benefits before the week of the actual DOB.

- The client stopped working due to illness, or was receiving regular or sickness benefits before the start of the maternity window.

- The client’s maternity leave at her place of employment was not scheduled for the period of time she is requesting sickness benefits for.

- The client would have been available for work if not for the illness, injury or quarantine.

- If any of the conditions are not met, go to step 8.

- If all of the conditions are met, go to Otherwise available .
                   [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#OWAL1)

- Determine if the only condition that is not met is the following:

- The client is requesting sickness benefits before the week of the actual DOB.

- If yes, go to step 9.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#reassignL2)

- Determine if the request is only for the week of the actual DOB.

- If yes, go to step 10.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#OWAL1)

- Determine if the DOB is on a Saturday:

- If yes, go to Otherwise available .
               [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#OWAL1)

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#reassignL2)

- Determine if all of the conditions are met to allow the otherwise available issue at Level 1:

- The client received or was eligible for parental benefits, CCB or family caregiver benefits before becoming incapacitated, injured or quarantined.

- The client is eligible for parental benefits, CCB or family caregiver benefits up to or beyond the recovery date.

- The client submits a medical certificate for the period of incapacity that indicates the incapacity start date and the expected recovery date.

- If all of the conditions are met, go to Otherwise available .
                   [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#OWAL1)

- If any of the conditions are not met, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#reassignL2)

- Determine if the client would have been employed or entitled to regular benefits if not for the sickness or injury:

- If the client would have been employed or entitled to regular benefits if not for the sickness or injury, go to Otherwise available .
               [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#OWAL1)

- If the client would not have been employed or entitled to regular benefits if not for the sickness or injury, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#reassignL2) 

#### Otherwise available

Source topic: `en_EN/task/no_available/otherwise_available_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Otherwise available.”

- Details: Type “The criteria to allow sickness benefits at Level 1 have been met ( National Policy on Levels of Decision ).” Include the end date, if necessary.
               [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita)

- Determine the BT requested for the calculation:

- If the BT is regular, refer to Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, note that an external maternity start week may be required and refer to Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is compassionate care, refer to Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver, refer to Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/no_available/reassigning_the_issue_to_level_2_level_1.dita`

- Reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Otherwise available — not within Level 1 authority.” 

#### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Level 2

Source topic: `en_EN/task/no_available/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/no_available/reviewing_the_file_level_2.dita`

- Determine if adjudication can be deferred by referring to Deferral of adjudication .

- Determine if there is enough information to make a decision:

- If additional details are needed, go to step 3.

- If additional details are not needed, go to step 6. 

#### Fact-finding

Source topic: `en_EN/task/no_available/fact-finding_level_2.dita`

- Complete fact-finding . Refer to Digest 11 — Sickness Benefits to determine the questions to ask clients and employers, if necessary.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 5.

- If the client was not reached or did not reply to the N-10-00-00 letter, go to Client not contacted .
               [Client not contacted](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#client_non_contacted)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Otherwise available — spoke with [client or employer].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating otherwise available issues

Source topic: `en_EN/task/no_available/adjudicating_otherwise_available_issues_level_2.dita`

- Determine if there is adequate proof that the client would be otherwise available for work if not for the incapacity based on a review of all the information provided on file and in accordance with the EIA, EIR, jurisprudence and Digest 11.3.0 — Second entitlement condition: to be otherwise available for work .

- Determine if the client is otherwise available:

- If yes, go to Otherwise available .
               [Otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#Otherwise_available)

- If no, go to Not otherwise available .
               [Not otherwise available](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/no_available#not_otherwise_available) 

#### Otherwise available

Source topic: `en_EN/task/no_available/otherwise_available_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Otherwise available.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy . Include the end date, if applicable.
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Complete the WI for the otherwise available issue. 

#### Not otherwise available

Source topic: `en_EN/task/no_available/not_otherwise_available_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Not otherwise available from [XXXX-X] to [XXXX-X].”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If fact-finding by telephone was not attempted, select Draft and go to step 2.

- If the client was reached by telephone during fact-finding, select Draft and go to step 2.

- If the client was not reached by telephone during fact-finding, select Save and go to step 3.

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Verbally communicate the decision to the client .

- Based on the BT, determine if the client is requesting sickness benefits before or during the maternity window:

- If no, go to step 4.

- If yes, go to step 6.

- In FTS, select the Disqualifications/Disentitlement (M161) transaction and impose the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 33 - Incapacity proven but not otherwise available .

- Start date: Select the appropriate option :

- BPC date: Check the box if the disentitlement begins at the BPC.

- Enter the disentitlement start date if the disentitlement begins after the BPC.

- End Date: Enter the appropriate disentitlement end date as follows:

- If the date at which the client will become otherwise available is known, impose the appropriate disentitlement end date.

- If the date at which the client will become otherwise available is not known, select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065) .

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D-33 - Not otherwise available .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) and select the appropriate option.

- Text - Reasons why not otherwise available (1630): Type the details.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Go to step 7.

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- If the client is entitled to receive other special benefits on the claim, select Special benefits approved (3046) and select the appropriate options.

- Special benefits denied (3065)

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066): Select D-33 - Not otherwise available .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) and select the appropriate option.

- Text - Reasons why not otherwise available (1630): Type the details.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note and type “Send saved N-00-00-00 letter.” Indicate any additional information that the Level 1 officer must add.

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 9.

- If yes, go to step 11.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 10.

- If yes, go to step 11.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination — SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “N-00-00-00 letter required — not otherwise available.”

- Select Save .

- Complete the ADJ WI for the not otherwise available issue. 

#### Client not reached

Source topic: `en_EN/task/no_available/client_not_reached_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Not otherwise available from w/c [XXXX] to [XXXX].”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save.

- Based on the BT, determine if the client is requesting sickness benefits before or during maternity window:

- If no, go to step 3.

- If yes, go to step 5.

- In FTS, select the Disqualifications/Disentitlement (M161) transaction and impose the D33 disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 33 - Incapacity proven but not otherwise available .

- Start date: Select the appropriate option:

- BPC date: Check the box if the disentitlement begins at the BPC.

- Enter the disentitlement start date if the disentitlement begins after the BPC.

- End Date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065) .

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D-33 - Not otherwise available .

- Select Indefinite disentitlement start date (1270) .

- Text - Reasons why not otherwise available (1630): Type the details.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Go to step 6.

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- If the client is entitled to receive other special benefits on the claim, select Special benefits approved (3046) and select the appropriate options .

- Special benefits denied (3065)

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066): Select D-33 - Not otherwise available .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) and select the appropriate option.

- Text - Reasons why not otherwise available (1630): Type the details.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note and type “Send saved N-00-00-00 letter.” Indicate any additional information that the Level 1 officer must add.

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 8.

- If yes, go to step 10.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 9.

- If yes, go to step 10.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “N-00-00-00 letter required — not otherwise available.”

- Select Save .

- In NWS, complete the WI for the otherwise available issue or return to the previous task. 

## Policy reference

Source topic: `en_EN/task/no_available/policy_reference.dita`

- Digest 10 — Availability
         [Digest 10 — Availability](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/table-of-contents.html)

- Digest 11 — Sickness Benefits
         [Digest 11 — Sickness Benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-11/table-of-contents.html)

- Digest 12 — Maternity Benefits
         [Digest 12 — Maternity Benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-12/table-of-contents.html)

- Digest 13 — Parental Benefits
         [Digest 13 — Parental Benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-13/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
