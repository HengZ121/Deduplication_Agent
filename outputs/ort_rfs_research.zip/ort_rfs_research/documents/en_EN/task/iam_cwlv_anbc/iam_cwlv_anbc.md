# Implementing client misrepresentation on an active claim — Warning letter and unclassified violation

Source map: `en_EN/task/iam_cwlv_anbc/iam_cwlv_anbc.ditamap`

## Summary

Source topic: `en_EN/task/iam_cwlv_anbc/summary.dita`

Summary: When a warning letter and notice of unclassified violation are being issued to the client for making a misrepresentation on an active or terminated (non-blocked) claim, all decisions related to the misrepresentation must be input and the client must be notified. 

## What you need to know

Source topic: `en_EN/task/iam_cwlv_anbc/what_you_need_to_know.dita`

### Adjudicating misrepresentation — Implementing the decision

Source topic: `en_EN/task/iam_cwlv_anbc/adjudicating_misrepresentation__impleme_a73ca3b8.dita`

The final step in adjudicating misrepresentation is to implement the decision by completing the appropriate inputs and notifying the client.

This implementation task applies to active and terminated (non-blocked) claims. It includes the following:

- inputting the reconsidered decision(s) in FTS and RCM (if applicable) to establish the overpayment (OP) or underpayment (UP)

- inputting the unclassified violation in FTS

- sending the decision letter in ACS

- clearing the case in NIIS

- completing the WI in NWS

When a third party makes a misrepresentation with the both the client’s knowledge and consent, it is considered collusion between the client and third party. In this situation, the client must repay the net OP and any applicable sanction can be imposed on both the client and the third party. 

### Determining the order of FTS inputs

Source topic: `en_EN/task/iam_cwlv_anbc/determining_the_order_of_fts_inputs.dita`

Controlled, multiple-day inputs in FTS are required to establish separate OPs for each decision (i.e. unreported earnings and reason for separation [RFS]). When there is more than one reconsideration decision that results in an OP, the decisions must be input in the following order:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3457.dita) 

Controlled inputs in FTS are also required for UP and OP situations. The officer processes the inputs resulting in the OP first. Once the OP is established, the officer inputs an agreed deduction equal to the benefit rate amount. For more information, the officer refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

### Coding a full work week (FWW)

Source topic: `en_EN/task/iam_cwlv_anbc/coding_a_full_work_week_fww.dita`

When clients report earnings on their claimant’s report, the earnings are coded along with a FWW code, if applicable. An FWW is coded  if the client declared working 35 hours or more (28 hours or more in a week containing one of these 4 federal statutory holidays: New Year’s Day, Canada Day, Labour Day, Christmas Day). An investigation could reveal that FWWs have been coded when the client did not work or worked less than an FWW. When an FWW must be removed, document the decision on a record of decision (ROD). 

### Updating the special condition in RCM

Source topic: `en_EN/task/iam_cwlv_anbc/updating_the_special_condition_in_rcm.dita`

If the reconsideration decision is related to the RFS and the ROE is on file, the Special condition field must be updated in RCM to show the decision. The RCM input can be done at any time. 

### Sending the file for recalculation

Source topic: `en_EN/task/iam_cwlv_anbc/sending_the_file_for_recalculation.dita`

Certain situations of misrepresentation (e.g. the submission of a false ROE or an ROE containing false information) require the claim to be recalculated. A recalculation is also required when the misrepresentation involves an undisclosed contentious RFS in the qualifying period (QP) and impacts the calculation of the claim. If a recalculation is required, an Action Item (AI) WI is created for Level 1. Once the recalculation is completed, a Level 2 officer inputs the unclassified violation and notifies the client of the decisions. 

### Completing the case in NIIS

Source topic: `en_EN/task/iam_cwlv_anbc/completing_the_case_in_niis.dita`

Level 2 officers have access to NIIS to view selected information and to complete cases they have adjudicated. Although the Level 2 decisions are documented in NWS, the Decision tab on the Report of Investigation ( IC50 or IC70 ) screen must be completed to close the case. This ensures that NIIS has a complete record of the investigation.

It is important to note that the FTS inputs, not the amounts entered on the Decision tab, update the OP values on the Subject Enquiry (IC07) screen in NIIS. If the OP values are not automatically updated, they can be manually updated by an NIIS regional coordinator so that Integrity staff receive proper credit for their work.
       [NIIS regional coordinator](https://esdc.prv/en/service-canada/isb/io/bso/iccm_coordinators.shtml) 

### Callout

Source topic: `en_EN/common_notes/note_c_3457.dita`

**Input order for multiple transactions**

- full disentitlement

- partial disentitlement

- unreported earnings / unreported allocation of earnings

- indefinite disqualification

- definite disqualification 

## Regional considerations

Source topic: `en_EN/task/iam_cwlv_anbc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/iam_cwlv_anbc/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/iam_cwlv_anbc/in_fts.dita`

- Is the misrepresentation on an active or dormant claim?

- Is there an FWW code 1, 2 or 3 in any of the reports under investigation? 

### In NWS:

Source topic: `en_EN/task/iam_cwlv_anbc/in_nws.dita`

- On the reconsideration ROD:

- What transactions (allocation, disentitlement, disqualification, recalculation, etc.) are required?

- On the misrepresentation or penalty ROD:

- Does the misrepresentation involve the RFS?

- What is the level of misrepresentation?

- What is the number of misrepresentations (false or misleading statements knowingly made)?

- Are there documents related to the issue? 

### In NIIS:

Source topic: `en_EN/task/iam_cwlv_anbc/in_niis.dita`

- On the Report of Investigation (IC50 or IC70) screen:

- What is the investigation type?

- On the Observation (IC04) screen:

- If applicable, what are the client’s actual earnings to be allocated? 

### In Imaging:

Source topic: `en_EN/task/iam_cwlv_anbc/in_imaging.dita`

- Is there a Request for Payroll Information (INS5097) or Request for Clarification of Employment Information (INS5098) showing the client’s actual earnings to be allocated? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/iam_cwlv_anbc/in_integrity_investigations_document_up_6a8da64b.dita`

- Is there any document containing mitigating circumstances 

### In RCM:

Source topic: `en_EN/task/iam_cwlv_anbc/in_rcm.dita`

- If the misrepresentation involved the client’s RFS, is the ROE on file? 

## Step by step

Source topic: `en_EN/task/iam_cwlv_anbc/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/iam_cwlv_anbc/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/iam_cwlv_anbc/reviewing_the_file_level_2.dita`

- Determine the status of the claim on which the misrepresentation was made:

- If the claim is active, go to step 2.

- If the claim is dormant, reactivate it as follows:

- On the Dormant tab, select the appropriate BPC.

- Select Reactivate .

- Select Update .

- Go to step 2.

- Determine if any of the following apply:

- The misrepresentation involved the submission of a false ROE or the submission of an ROE with false information in the QP.

- The misrepresentation involved an undisclosed contentious RFS in the QP and impacts the calculation of the claim (i.e. a disqualification is applicable and the client has not worked enough hours since the disqualifying event to establish the claim).

- If no, go to step 3.

- If yes, go to Sending a claim for recalculation .
                   [Sending a claim for recalculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/iam_cwlv_anbc#recalc)

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3467.dita) 

#### Implementing the decision

Source topic: `en_EN/task/iam_cwlv_anbc/implementing_the_decision_level_2.dita`

- Determine if the reconsideration decision requires the input of multiple transactions. If yes, the following order must be respected:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3457.dita) 
           [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3481.dita)

- Determine the result of the reconsideration decision.

- If the decision results in a disentitlement, go to step 5.

- If the decision results in unreported earnings or an allocation, go to step 6.

- If the decision results in an indefinite disqualification, go to 10.

- If the decision results in a definite disqualification, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3458.dita)

- In FTS, select the Disqualifications/Disentitlement (M161) transaction to input the disentitlement as follows:

- Registration number: Select the revised registration corresponding to the investigation.

- Action: Select the appropriate option:

- Add: To add a new disentitlement.

- Terminate/Modify: To modify an existing disentitlement.

- Disentitlement: Select the appropriate disentitlement code.

- Start date: Enter the disentitlement start date.

- End date: Enter the disentitlement end date.

- Infraction: Select the misrepresentative option corresponding to the input:

- For a 1 - Not unemployed (D1) disentitlement, select U - Fraud - Earnings and employment .

- For a 14 - Void benefit period (D14) disentitlement, select W - Fraud - Insurability - new information .

- For any other type of disentitlement, select V - Fraud - Availability, Capability .

- Message: Select the appropriate message:

- For a definite disentitlement, select 3 - An overpayment resulted due to a definite disentitlement .

- For an indefinite disentitlement, select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 12.

- Determine if the FWW code needs to be changed in any of the reports under investigation.

- If yes, go to step 7.

- If no, go to step 9.

- In FTS, on the Payment Tab, select the appropriate Report week and modify the claimant’s report as follows: * Change only the information that requires modification .

- Select Modify .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1822.dita) 
               [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3459.dita)

- Earnings: For each week, enter the client’s earnings if applicable.

- Full work week: Select the appropriate option:

- 1 - Full work week - week 1

- 2 - Full work week - week 2

- 3 - Full work week both weeks

- Infraction: Select U - Fraud - Earnings and employment .

- Message: Select 7 - You misrepresented your earnings .

- Select Save .

- Select Update .

- Determine if earnings need to be modified on weeks where the FWW code does not need to be changed.

- If yes, go to step 9.

- If no, go to step 12.

- In FTS, select the Allocations (M175) transaction to input the allocation (s) as follows:

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3459.dita) 

- Registration number: Select the revised registration corresponding to the investigation.

- On the first line, select the appropriate attribute:

- Type: Select the appropriate option:

- For a correction in declared earnings or for any unreported earnings, select A - Amended earnings .

- For modification of an existing allocation, select the same allocation code.

- Amount: Enter in the amount.

- Start date: Enter the first week of the allocation.

- End date: Enter the last week of the allocation.

- Last week amount: Enter in the amount (if necessary):

- Infraction: Select U - Fraud - Earnings and employment .

- Message: Select 7 - You misrepresented your earnings .

- Contentious: Select 2C - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 12.

- In FTS, select the Disqualifications/Disentitlement (M161) transaction to input the disqualification as follows:

- Registration number: Select the revised registration corresponding to the investigation.

- Action: Select the appropriate option.

- Disqualification: Select the appropriate disqualification code.

- Start date: Enter the disqualification start date.

- End date: Enter the disqualification end date.

- Infraction: Select Z - Fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Determine if the ROE is on file:

- If no, go to step 12.

- If yes, in RCM, update the Special condition field to reflect the reconsideration decision on the RFS. Go to step 12.

- Determine if a stop payment is imposed for the investigation issue:

- If no, go to step 13.

- If yes, in FTS, select the Renewal/Revised (M106) transaction and remove the stop payment as follows:

- Registration number: Select the revised registration number corresponding to the investigation.

- Manual action: Select the appropriate manual action (MA) code.

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Go to step 13.

- In FTS, on the Violation (ML01) transaction, input the unclassified violation as follows:

- Action: Select Add .

- Notification week: Select the current w/c.

- BPC: Select the BPC on which the misrepresentation was made.

- Imposed by: Select 1 - Agent .

- Warning Letter: Select 1 - Violation - warning letter issued .

- Select Update .

- Determine if the case involves more than 52 weeks of unreported earnings:

- If yes, go to step 15.

- If no, go to step 16.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3485.dita)

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Definite Disqualification Messages - D06/D07/D09 (2918)

- D13 or D38 - Outside Canada (Interstate option)/on vacation within or outside Canada (2924)

- Various reasons for penalty and violation: Found work / Self Employment / Capability / Training / Availability / Full work week / Text (2935): Select Blank .

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared/omitted (2953)

- No reply from client/reply received with an explanation/reply received with no explanation (2938)

- False representation message/Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452)

- This letter Replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “This letter includes only the information for the benefit period starting [date of BPC]. The information for the benefit period starting [date of BPC] is included in a separate letter.”

- In ACS, create and send the D-91-00-00 letter to inform the client of the reconsideration, warning letter and unclassified violation decisions. Based on the claim information, select all of the required attributes, including the following:

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Definite Disqualification Messages - D06/D07/D09 (2918)

- D13 or D38 - Outside Canada (Interstate option)/on vacation within or outside Canada (2924)

- Various reasons for penalty and violation: Found work / Self Employment / Capability / Training / Availability / Full work week / Text (2935): Select the applicable option, or if the period of disentitlement and an explanation are required, select Failed to provide information: Text: Specify what we have learned .

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared/omitted (2953)

- No reply from client/reply received with an explanation/reply received with no explanation (2938)

- False representation message/Number of omissions or false representations (2941)

- Levels of misrepresentation (12292)

- Penalty message / Warning message (2950): Select Warning message .

- Overpayment Messages (2452)

- Notice of violation (3095)

- Determine if a sanction also applies to a third party:

- If yes, go to Implementing third party misrepresentation to impose the sanctions for the third party and to complete the case.
               [Implementing third party misrepresentation](/en/procedure/task/implementing_tp_misrepresentation.shtml)

- If no, go to step 18.

- In NIIS, on the Decision tab of the Report of Investigation (IC50 or IC70) screen, clear the case as follows:

- Overpayment: Indicate whether an OP resulted from the misrepresentation.

- Reason: Select the appropriate option based on the decision that resulted in the OP.

- Amount: Enter the estimated total net OP that resulted from the misrepresentation.

- Penalty: Select No .

- Warning: Select Yes .

- Reason: Select the appropriate option.

- Violation: Select Yes .

- Seriousness: Select Warning .

- In NWS, complete the Claim Review (CR) WI. 

#### Sending a claim for recalculation

Source topic: `en_EN/task/iam_cwlv_anbc/sending_a_claim_for_recalculation_level_2.dita`

- Determine the issue:

- If it is a contentious RFS, go to step 4.

- If it is a false ROE or an ROE containing false information, go to step 6.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction to input the disqualification as follows:

- Registration number: Select the revised registration number corresponding to the investigation.

- Action: Select the appropriate option.

- Disqualification: Select the appropriate disqualification code.

- Start date: Enter the disqualification start date.

- End date: Enter the disqualification end date.

- Infraction: Select Z - Fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- Determine if the ROE is on file:

- If no, go to step 6.

- If yes, in RCM, update the Special condition field to reflect the reconsideration decision on the RFS. Go to step 6.

- Create an AI WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Claim type: Select Revised .

- Destination — Level: Select EI Processing .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- Comments: Type “Level 1 recalculation required — Integrity case [Integrity case number].”

- Details: Do the following:

- Type “A recalculation of BPC [DD-MM-YYYY] is required due to the adjudication of ROE [serial number]. A Level 2 ROD is on file and the reconsideration timeframe ends on [DD-MM-YYYY]. Recalculation inputs and notification to the client must be completed no later than this date. The infraction code for the recalculation is W - Insurability. ” If the ROE contains false information, clearly indicate what is incorrect and provide the correct information. If there is a CR Recalculation WI for the ROE under reconsideration, also type “Complete the Claim Review Recalculation work item related to this benefits period.”

- Create a client Note and do the following:

- Type “The [D-91-00-00 or D-17-03-00] letter will be sent once the claim has been recalculated. Please save any other required letters.”

- Move the CR Integrity WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Unclassified violation to be input once recalculation completed.”

- Bring forward date: Select the next business day.

- When the CR Integrity WI moves to the current workload, verify that all of the recalculation transactions have processed in FTS and the OP (if applicable) is showing in PSCD:

- If all transactions have not yet processed and the total OP (if applicable) has not been established, return to step 8.

- If the transactions have processed and the OP (if applicable) is established, go to step 10.

- In FTS, on the Violation (ML01) transaction, input the unclassified violation as follows:

- Action: Select Add .

- Notification week: Select the current w/c.

- BPC: Select the BPC on which the misrepresentation was made.

- Imposed by: Select 1 - Agent .

- Warning Letter: Select 1 - Violation - warning letter issued .

- Select Update .

- Determine if a stop payment is imposed for the investigation issue:

- If no, go to step 12.

- If yes, in FTS, select the Renewal/Revised (M106) transaction and remove the stop payment as follows:

- Registration number: Select the revised registration number corresponding to the investigation.

- Manual action: Select the appropriate MA code.

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Determine the issue:

- If it is a contentious RFS, go to step 13.

- If it is a false ROE or an ROE containing false information, go to step 14.

- In ACS, create and send the D-91-00-00 letter to inform the client of the reconsideration and penalty decisions. Based on the claim information, select all of the required attributes, including the following:

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- No reply from client/reply received with an explanation/reply received with no explanation (2938)

- False representation message/Number of omissions or false representations (2941)

- Levels of misrepresentation (12292)

- Penalty message / Warning message (2950): Select Warning message .

- Overpayment Messages (2452)

- Notice of violation (3095): Select the appropriate option.

- Go to step 15.

- In ACS, create and send the D-17-03-00 letter to inform the client of the reconsideration and unclassified violation decisions. Based on the claim information, select all of the required attributes, including the following:

- False ROE(s) / False Information (2618): Select the appropriate option.

- Number of invalid or false ROE(s) submitted (1668)

- Specify serial number of invalid or false ROE(s) (1672)

- Levels of Misrepresentation (12292): Select the level of misrepresentation and number of false representations.

- Penalty message / Warning message (2950): Select Warning message .

- Overpayment Messages (2452)

- Notice of violation (3095): Select the appropriate option.

- Determine if a sanction also applies to a third party:

- If yes, go to Implementing third party misrepresentation to impose the sanctions on the third party and to complete the case.
               [Implementing third party misrepresentation](/en/procedure/task/implementing_tp_misrepresentation.shtml)

- If no, go to step 16.

- In NIIS, on the Decision tab of the Report of Investigation (IC50 or IC70) screen, clear the case as follows:

- Overpayment: Indicate whether an OP resulted from the misrepresentation.

- Reason: Select the appropriate option based on the decision that resulted in the OP.

- Amount: Enter the estimated total net OP that resulted from the misrepresentation.

- Penalty: Select No .

- Warning: Select Yes .

- Reason: Select the appropriate option.

- Violation: Select Yes .

- Seriousness: Select Warning .

- In NWS, complete the CR WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_3467.dita`

Note:

If the decision is to impose a D14, a recalculation is not required and the officer goes to Implementing the decision. 

#### Warning

Source topic: `en_EN/common_notes/note_c_3481.dita`

Warning:

In situations where inputs will create both an UP and an OP, the inputs resulting in the OP are done first. Once the OP is established, the officer inputs an agreed deduction equal to the benefit rate amount. For more information, the officer refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml)

     [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_3458.dita`

Note:

When there are multiple reconsideration decisions, complete each applicable step. 

#### Note

Source topic: `en_EN/common_notes/note_c_1822.dita`

Note:

When the Detailed Claimant’s Report screen opens, the information displayed the information declared by the client on the original claimant’s report. The Manual Action field is automatically prefilled with 19 - Amended report . 

#### Warning

Source topic: `en_EN/common_notes/note_c_3459.dita`

Warning:

If the client declared earnings from another employment for a week that is being amended, combine the earnings for both employments for that week. Allocate the total earnings. 

#### Note

Source topic: `en_EN/common_notes/note_c_3485.dita`

Note:

If the case involves more than 52 weeks of unreported earnings, a D-91-00-00 letter is required for each benefit period (BP). The warning letter and unclassified violation information for the entire case is only included in the letter for the most recent BP. 

## Policy reference

Source topic: `en_EN/task/iam_cwlv_anbc/policy_reference.dita`

- EIA 7.1
         [EIA 7.1](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-7.1.html)

- EIA 40
         [EIA 40](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-40.html)

- EIA 41.1
         [EIA 41.1](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-41.1.html) 
