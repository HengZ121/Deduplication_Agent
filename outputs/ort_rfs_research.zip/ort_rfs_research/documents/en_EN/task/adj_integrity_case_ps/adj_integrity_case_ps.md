# Adjudicating an Integrity case — Parental sharing

Source map: `en_EN/task/adj_integrity_case_ps/adj_integrity_case_ps.ditamap`

## Summary

Source topic: `en_EN/task/adj_integrity_case_ps/summary.dita`

Summary: Investigators are reviewing EI claims of clients who shared parental benefits before September 2019. The investigators inform agents when they discover a discrepancy in the waiting period (WP) deferral, the type of parental benefits received or the total number of parental benefits weeks shared between parents. The agent reviews each parent’s claim and makes corrections as required. 

## What you need to know

Source topic: `en_EN/task/adj_integrity_case_ps/what_you_need_to_know.dita`

### Processing an Integrity claim review

Source topic: `en_EN/task/adj_integrity_case_ps/processing_an_integrity_claim_review.dita`

Below are the main processing steps for this activity. If the agent determines that the client knowingly made a false or misleading statement, the agent must adjudicate the parental sharing issue, complete the record of decision (ROD), and refer to Misrepresentation to determine the type of sanction to impose. The agent must input the complete decision after determining the sanctions.
       [Misrepresentation](/en/procedure/activity/misrepresentation.shtml) 

### Reconsidering a decision

Source topic: `en_EN/task/adj_integrity_case_ps/reconsidering_a_decision.dita`

EIA 52 states that a claim for benefits may be reconsidered as long as it results in an overpayment (OP) or an underpayment (UP). The time limit for reconsidering a claim is 36 months from the week benefits were paid or payable. This period is extended to 72 months if there is a false or misleading statement.
       [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html) 

### Determining if a false statement was made

Source topic: `en_EN/task/adj_integrity_case_ps/determining_if_a_false_statement_was_made.dita`

A false statement is a statement that is incorrect or untrue. It can be the result of an intentional or negligent action, or it can be the result of an honest mistake.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1671.dita) 

At this point, the agent only knows that the information provided by the client is incorrect. Without an explanation from the client, it cannot be determined if the client intentionally or knowingly failed to provide the right information. Regardless of whether it was intentional or an honest mistake, the client did not apply using correct information and therefore the reconsideration timeframe can be extended to 72 months. 

### Determining if a false statement was knowingly made

Source topic: `en_EN/task/adj_integrity_case_ps/determining_if_a_false_statement_was_kn_d9caede1.dita`

Knowingly means the agent can reasonably conclude that clients knew the information provided was untrue when they provided or did not report that information. There is no element of intent in this consideration. It is not necessary to determine a degree of fault. The agent must only establish that it is more likely the client understood the information provided and did not accurately portray the facts.

If the client received payments by paper cheque, each cheque cashed can be considered a misrepresentation under EIA 38(1)(e). If the client received payments by direct deposit, each direct deposit payment or any excess amount the client received and did not return can be considered a misrepresentation under EIA 38(1)(f).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1672.dita) 

### Exemption from reporting

Source topic: `en_EN/task/adj_integrity_case_ps/exemption_from_reporting.dita`

The client may make false statements on an application for benefits, an ROE, a record of interview or a claimant’s report. If the client is exempt from reporting, the agent must review the payments that have been issued to determine if there are false statements. The agent can also consider any of the other documents such as those listed above as a false statement.

If the client received payments by direct deposit, the payments cannot be considered as false statements. However, if the client received payments by warrant, each warrant can be considered a false statement. 

### Voluntary disclosure

Source topic: `en_EN/task/adj_integrity_case_ps/voluntary_disclosure.dita`

The National Policy on Voluntary Disclosure encourages clients, employers and third parties to come forward and voluntarily disclose misrepresentations. According to this policy, voluntary disclosure occurs when a person admits to having knowingly made a false statement.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

An investigator may recommend that the file be reconsidered in light of the National Policy on Voluntary Disclosure .
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

There are 2 essential conditions for allowing the voluntary disclosure:

- There is no investigation under way in relation to the voluntary disclosure when a client admits to making a false statement.

- The false statement would have resulted in punitive measures such as a penalty, a warning or prosecution had there been no voluntary disclosure.

According to the National Policy on Voluntary Disclosure , there is no limit to the number of times that a client can voluntarily disclose misrepresentations.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 

### Incorrect type of parental benefits

Source topic: `en_EN/task/adj_integrity_case_ps/incorrect_type_of_parental_benefits.dita`

When reviewing the shared parental benefits, the investigator may determine that the parents did not share the same type of parental benefits.

Once at least one week of parental benefits has been paid to any parent, all parents requesting parental benefits for the same birth, adoption or placement are only entitled to receive the type of parental benefits selected by the first parent who applied for benefits. 

### Number of weeks paid exceeds the maximum shareable entitlement

Source topic: `en_EN/task/adj_integrity_case_ps/number_of_weeks_paid_exceeds_the_maximu_1b3fb7c0.dita`

When reviewing the shared parental benefits, the investigator may determine that the parents received more than the maximum shareable entitlement.

The maximum shareable entitlement is 40 weeks of standard parental benefits or 69 weeks of extended parental benefits for children born or placed for adoption on or after March 17, 2019. For children born before this date, the maximum shareable entitlement is 35 weeks of standard parental benefits or 61 weeks of extended parental benefits. The maximum entitlement for one client remains at 35 weeks of standard or 61 weeks of extended benefits.

The maximum parental entitlement is also the maximum number of parental entitlement weeks that can be paid in a BP. The parental entitlement can be paid over 2 BPs, but cannot be paid outside of the parental window (PW). The number of weeks of parental benefits a client is entitled to receive is not affected by the number of children born at the same time (twins, triplets, etc.) or by the number of children adopted at the same time. 

### Waiting period (WP)

Source topic: `en_EN/task/adj_integrity_case_ps/waiting_period_wp.dita`

When reviewing the shared parental benefits, the investigator may determine that the WP was incorrectly deferred.

Only one WP must be served when benefits are claimed for the same birth, adoption or placement. The WP can be deferred on a claim for parental benefits if the client has already served a WP during a benefit period (BP) for the same birth, adoption or placement. Parents do not have to share parental benefits in order to have the WP deferred. When both parents file a claim for benefits simultaneously, they must indicate which one of them will have their WP deferred.

The following are examples of a WP that was already served for the same birth, adoption or placement:

- The mother has served a WP on a BP established for maternity benefits or on a claim that she later converted to maternity benefits for the same birth.

- Another parent has served a WP on a BP established for regular benefits and later renewed the BP for parental benefits for the same birth, adoption or placement.

- A client establishes a subsequent claim for the balance of parental benefits and served a WP while on a previous claim during which parental benefits were claimed for the same birth, adoption or placement.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1487.dita) 

### Unlinking SINs that were linked in error

Source topic: `en_EN/task/adj_integrity_case_ps/unlinking_sins_that_were_linked_in_error.dita`

A Parental Client Record is created for every client who requests parental benefits. The Parental Client Record consists of the client’s SIN, the arrival or placement week (APW) and the other parents’ SIN, if it has been provided. Once a claim is finalized, the system links Parental Client Records for all clients who are sharing parental benefits for the same child. However, it is possible that an incorrect client SIN could be linked to a Parental Client Record in error. In this case, the Parental Client Records must be unlinked and subsequently linked with the correct parent, if necessary. 

### Imposing a Parental benefits, qualifying conditions not met disentitlement (D35)

Source topic: `en_EN/task/adj_integrity_case_ps/imposing_a_parental_benefits_qualifying_5787ebc1.dita`

The agent imposes a 35 - Parental benefits, qualifying conditions not met disentitlement (D35) when the client is not payable parental benefits under the following conditions:

- Parental benefits are claimed outside of the PW.

- The parental benefits are exhausted.

- The client is excluded from sharing the parental benefit weeks.

Once adjudication is complete, the agent must determine whether to change the entitlement to parental benefits indicated in FTS or to impose a D35. 

### Returning a file to Integrity

Source topic: `en_EN/task/adj_integrity_case_ps/returning_a_file_to_integrity.dita`

After conducting a full review of the investigation, if the Level 2 agent determines that facts are missing, the agent must return the file to the investigator for further fact-finding and indicate the information that is missing but necessary to adjudicate the file. The Level 2 agent must not adjudicate the issue if facts are missing or incomplete.

Facts are not considered missing or incomplete if the investigator has followed up with the client when the client fails to report for an interview or fails to reply to a request for information. The investigator is not required to send a follow-up letter but must make 2 attempts on 2 different days to contact the client by telephone. If the investigator leaves a message on a voicemail, only one attempt is required and they must allow 48 hours for the client to respond.

If the investigator recommends that the Integrity case be considered as voluntary disclosure, but the investigation type is not 70 in NIIS, the officer returns the file to Integrity. 

### Definition of claim status (CS)

Source topic: `en_EN/task/adj_integrity_case_ps/definition_of_claim_status_cs.dita`

A claim can be active, terminated, blocked or archived. The claim status impacts which transactions can be input and when the letter of decision is sent:

    Active: 
      The active claim is established and is currently displayed automatically in FTS. It is a claim for which benefits are still payable and that has not been terminated. 
      Terminated: 
      A terminated claim appears on the

Dormant

tab in FTS. It has ended but can be reactivated. Once the transaction to reactivate the claim has been processed, all inputs for the claim must be done the same as for an active claim. 
      Blocked: 
      In some cases, the claim that the agent must reconsider is on the

Dormant

tab in FTS, but there is a new active claim established and displayed on the

Summary

screen. The agent makes adjustments to this type of claim using BCS if the blocked status shows

1 - Updateable

. Otherwise, IPOC intervention is required. 
      Archived: 
      Claims that are more than 7 years old are moved from the

Dormant

tab to the

Archived

tab. The officer can view an archived claim by changing the status of the archived claim from

1 - Non-Viewable

to

2 - Viewable

in FTS. Once the officer requests to make the claim viewable, the status field immediately displays

2 - Viewable

and the claim becomes viewable the next business day for 2 weeks. Adjustments to this type of claim are processed with IPOC intervention. 

### FTS inputs order

Source topic: `en_EN/task/adj_integrity_case_ps/fts_inputs_order.dita`

Controlled, multiple-day inputs in FTS are required to establish separate OPs for each decision, such as unreported earnings and reason for separation (RFS). When there is more than one reconsideration decision that results in an OP, the decisions must be input in the following order:

- full disentitlement

- partial disentitlement

- unreported earnings or unreported allocation of earnings

- indefinite disqualification

- definite disqualification

Controlled inputs in FTS are also required for UP and OP situations. The agent processes the inputs resulting in the OP first. Once the OP is established, the agent inputs an agreed deduction equal to the benefit rate amount. For more information, the agent refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

### Record of decision (ROD)

Source topic: `en_EN/task/adj_integrity_case_ps/record_of_decision_rod.dita`

The Level 2 agent must record and document each decision in a separate ROD. 

### Creating an Operational Centre Memo (MM06) transaction for multiple issues

Source topic: `en_EN/task/adj_integrity_case_ps/creating_an_operational_centre_memo_mm0_12498087.dita`

When the MM06 includes multiple issues, if at least one issue is deemed to be a misrepresentation whereas at least another one is not, the agent ensures to include the appropriate OP message code for each issue in the Remarks section. 

### Example

Source topic: `en_EN/common_notes/note_c_1671.dita`

Example:

The client applies for 40 weeks of standard parental benefits and the spouse applies for 40 weeks of standard parental benefits. An investigation reveals that both parents were receiving benefits for the same child and the number of weeks paid exceeds the maximum entitlement of 40 weeks. 

### Note

Source topic: `en_EN/common_notes/note_c_1672.dita`

Note:

A false statement knowingly made does not always result in an OP of benefits. Since a monetary penalty is calculated based on the OP resulting from the misrepresentation, the agent can consider sending a warning letter if the client knowingly made a false statement but the misrepresentation did not result in an OP. 

### Note

Source topic: `en_EN/common_notes/note_c_1487.dita`

Note:

If the WP has been waived for the first parent requesting benefits for a birth, adoption or placement, the WP cannot be deferred by the second parent requesting benefits for this same birth, adoption or placement. However, the second parent requesting benefits for this same birth, adoption or placement may meet the conditions to waive the WP. 

## Regional considerations

Source topic: `en_EN/task/adj_integrity_case_ps/regional_considerations.dita`

**Quebec — Returning the file to Integrity**

In addition to the information already indicated in this procedure, refer the file to Integrity as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a Cc.

- In NWS, create a client Note and type “measure - returned to Integrity” and include the date (YYYY-MM-DD). 

## What you need to look for

Source topic: `en_EN/task/adj_integrity_case_ps/what_you_need_to_look_for.dita`

### In NIIS:

Source topic: `en_EN/task/adj_integrity_case_ps/in_niis.dita`

- Review the IC07 Subject Enquiry screen for all active and prior cases.

- Review the IC08 Case Summary screen to see the actions taken on the case.

- Review the IC56 Case Notes screen to ensure you have the complete case.

- Review the IC50 Report of Clerical Investigation or IC70 Report of Investigation screen.

- Is there an Integrity Investigation Sheet?

- Is there a Report of Interview? 

### In Imaging:

Source topic: `en_EN/task/adj_integrity_case_ps/in_imaging.dita`

- Are there any documents that are relevant to the case?

- Is there information on file about the other parents’ SIN? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/adj_integrity_case_ps/in_integrity_investigations_document_up_6a8da64b.dita`

- Are there any documents that are relevant to the case? 

### In NWS:

Source topic: `en_EN/task/adj_integrity_case_ps/in_nws.dita`

- Review the application for benefits.

- Review SROCs, RODs, Action Item (AI) and Call Back (CB) WIs for information relevant to the case.

- Is there an application, an SROC, or an electronic questionnaire with the other parents’ SIN?

- Is there a ROD for the benefits sharing issue?

- When did the client and the child’s other parents apply for benefits for this birth, adoption or placement? 

### In FTS:

Source topic: `en_EN/task/adj_integrity_case_ps/in_fts.dita`

- What type of parental benefits did the client receive?

- What type of parental benefits did the child’s other parents receive?

- Is there an exemption from reporting?

- If yes, did the client receive payments by direct deposit?

- What SINs are linked to the client’s file on the Parental Benefits Validation screen? 

## Step by step

Source topic: `en_EN/task/adj_integrity_case_ps/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/adj_integrity_case_ps/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/adj_integrity_case_ps/reviewing_the_file_level_2.dita`

- Determine if there is a false statement:

- If no, go to step 2.

- If yes, go to step 3.

- Determine if the request for reconsideration was made within the 36-month time limit:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_integrity_case_ps#not_within_timeframe)

- Determine if the request for reconsideration is within the maximum reconsideration period of 72 months:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_integrity_case_ps#not_within_timeframe)

- Determine if the information gathered by Integrity is complete:

- If yes, go to step 5.

- If no, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_integrity_case_ps#return_file_integrity) 

#### Adjudicating the issue

Source topic: `en_EN/task/adj_integrity_case_ps/adjudicating_the_issue_level_2.dita`

- Adjudicate the parental entitlement issue:

- If the client is not entitled to the parental benefits that were received, go to step 6.

- If the client is entitled to the parental benefits that were received, go to Entitlement in order .
               [Entitlement in order](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_integrity_case_ps#Entitlement_in_order)

- Determine if the client knowingly made a false or misleading statement, as described in Digest 18.3.1.5 - Knowingly and Digest 18.3.1.4 - Misleading :

- If the client knowingly made a false or misleading statement, go to step 7.

- If the client did not knowingly make a false or misleading statement, go to step 8.

- If the client did not make a false or misleading statement, go to False statement not knowingly made or no false statement — Reconsideration within 36 months .
               [False statement not knowingly made or no false statement — Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_integrity_case_ps#Reconsideration_within_36)

- Determine if the investigator recommends that the file be reconsidered in light of a voluntary disclosure, as described in National Policy on Voluntary Disclosure :

- If the voluntary disclosure criteria are not met, go to step 9.

- If the voluntary disclosure criteria are met and the investigation type in NIIS is 70, go to Voluntary disclosure allowed .
               [Voluntary disclosure allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_integrity_case_ps#Voluntary_disclosure_approved)

- If the voluntary disclosure criteria are met but the investigation type in NIIS is not 70, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_integrity_case_ps#return_file_integrity)

- Determine the reconsideration timeframe for the false or misleading statement not knowingly made:

- If the false statement was made within the prescribed period of 36 months , go to False statement not knowingly made or no false statement — Reconsideration within 36 months .
               [False statement not knowingly made or no false statement — Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_integrity_case_ps#Reconsideration_within_36)

- If the false statement was made within the prescribed period of 72 months , go to False statement not knowingly made — Reconsideration after 36 months .
               [False statement not knowingly made — Reconsideration after 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_integrity_case_ps#Reconsideration_beyond_36) 

#### False statement knowingly made

Source topic: `en_EN/task/adj_integrity_case_ps/false_statement_knowingly_made_level_2.dita`

- In NWS, create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction ):

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine the issue:

- If the number of weeks paid exceeds the maximum shareable entitlement, go to step 11.

- If the type of parental benefits is incorrect, go to step 12.

- If the WP was served incorrectly, go to step 13.

- In NWS, create a ROD for the parental sharing issue as follows:

- Comments: Type “[Integrity case number] — parental sharing.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If the client was initially approved for more parental benefits weeks than the parent was entitled to and was overpaid because the maximum entitlement was reached, type “The client is entitled to receive [number of weeks] weeks.”

- If the client is entitled to 0 weeks, type “Parental benefits are exhausted. A 35 - Parental - minor attached or outside range or maximum parental/special benefits paid disentitlement is imposed effective [date]. The parent is not entitled to parental benefits because the maximum parental entitlement weeks has already been paid for the parental window.”

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 14.

- In NWS, create a ROD for the type of parental benefits as follows:

- Comments: Type “[Integrity case number] — changing the type of parental benefits”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy . If the client was paid the wrong type of parental benefits or was initially approved for more parental benefits weeks than the client was entitled to, type [“Parental benefits are payable up to a maximum combined total of 40 standard or 69 extended weeks per birth, adoption or placement for children born or placed for adoption on or after March 17, 2019.” or “Parental benefits are payable up to a maximum combined total of 35 standard or 61 extended weeks for children born or placed for adoption before March 17, 2019.”] The maximum number of weeks that can be paid to one parent is 35 weeks of standard benefits or 61 weeks of extended benefits. When clients share the parental benefits, the parents must share the same type of benefits. The first parent to apply for benefits for this birth, adoption or placement chooses a type of parental benefits. This is the type of benefits the other parents are entitled to. [The client or another parent ] applied for parental benefits first and is entitled to [ standard or extended ] parental benefits. The other parents are entitled to receive [number of weeks].”
                   [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 14.

- In NWS, create a ROD for the WP as follows:

- Comments: Type “[Integrity case number] — waiting period change.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If the client has had the WP deferred in error, type “Conditions to defer the waiting period are not met as a waiting period for this birth, adoption or placement has not yet been served.”

- If the WP should be deferred, type “Originally the waiting period was not deferred but should have been. Changes were made and the waiting period was deferred.”

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Continue with Adjudicating client or third party misrepresentation - Monetary penalty or warning letter to determine the appropriate sanctions and input all the decisions. 

#### False statement not knowingly made or no false statement — Reconsideration within 36 months

Source topic: `en_EN/task/adj_integrity_case_ps/false_statement_not_knowingly_made_or_n_c5db9ff1_level_2.dita`

- Determine the issue:

- If the number of weeks paid exceeds the maximum shareable entitlement, go to step 2.

- If the type of parental benefits is incorrect, go to step 3.

- If the WP was served incorrectly, go to step 4.

- In NWS, create a ROD for the parental sharing issue as follows:

- Comments: Type “[Integrity case number] — parental sharing.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If the client was initially approved for more parental benefits weeks than the parent was entitled to and was overpaid because the maximum entitlement was reached, type “The client is entitled to receive [number of weeks] weeks.”

- If the client is entitled to 0 weeks, type “Parental benefits are exhausted. A 35 - Parental - minor attached or outside range or maximum parental/special benefits paid disentitlement is imposed effective [date]. The parent is not entitled to parental benefits because the maximum parental entitlement weeks has already been paid for the parental window.”

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 5.

- In NWS, create a ROD for the type of parental benefits as follows:

- Comments: Type “[Integrity case number] — changing the type of parental benefits”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy . If the client was paid the wrong type of parental benefits or was initially approved for more parental benefits weeks than the client was entitled to, type [“Parental benefits are payable up to a maximum combined total of 40 standard or 69 extended weeks per birth, adoption or placement for children born or placed for adoption on or after March 17, 2019.” or “Parental benefits are payable up to a maximum combined total of 35 standard or 61 extended weeks for children born or placed for adoption before March 17, 2019.”] The maximum number of weeks that can be paid to one parent is 35 weeks of standard benefits or 61 weeks of extended benefits. When clients share the parental benefits, the parents must share the same type of benefits. The first parent to apply for benefits for this birth, adoption or placement chooses a type of parental benefits. This is the type of benefits the other parents are entitled to. [The client or another parent ] applied for parental benefits first and is entitled to [ standard or extended ] parental benefits. The other parents are entitled to receive [number of weeks] weeks.”
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 5.

- In NWS, create a ROD for the WP as follows:

- Comments: Type “[Integrity case number] — waiting period change.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If the client has had the WP deferred in error, type “Conditions to defer the waiting period are not met as a waiting period for this birth, adoption or placement has not yet been served.”

- If the WP should be deferred, type “Originally the waiting period was not deferred but should have been. Changes were made and the waiting period was deferred.”

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 5.

- In NWS, create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction )

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain why no false statements were knowingly made or no false statements were made.

- Determine if the number of weeks paid is equal to the number of weeks of entitlement shown in FTS:

- If yes, go to step 7.

- If no, go to step 14.

- In FTS, determine if the WP status is 5 - Waiting period deferred (parental standard or extended):

- If no, go to step 8.

- If yes, error code 312 is generated and an IPOC agent must make the change. Go to step 11.

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 9.

- If the claim is terminated, but can be reactivated:

- On the Terminated tab, select the appropriate BPC.

- Click Reactivate .

- Go to step 9.

- If the claim is blocked or archived, go to step 11.

- On day 1, in FTS, select the Renewal/Revised (M106) transaction and impose a D35 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 35 - Parental benefits, qualifying conditions not met .

- Start date: Select the first week the parent was overpaid parental benefit weeks.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Click Update .

- On day 2, select the Renewal/Revised (M106) transaction and complete the following fields:

- Registration number: Select the appropriate registration number.

- Click the Special Benefits (M106) link and in the Parental section, do the following:

- Entitlement weeks: Enter the number of weeks of entitlement (the total number of weeks the client is entitled to).

- Click Save .

- Waiting period: If the WP should be deferred, select 5 - Waiting period deferred (parental standard or extended) .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Click Update .

- Go to step 15.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Click Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- Remarks line 1: Type “312 error code. Parental entitlement paid in full and WP deferred.”

- Remarks line 2: Type “Change entitlement parental weeks to [XX], DE35, start [XXXX], end 9999 OP Code 31F04.”

- Remarks line 3: Type “WP deferral rescind” if it was deferred in error.

- Remarks line 4: Type “Remove stop pay” if necessary.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Click Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Click Update .

- Go to step 17.

- In FTS, select the Renewal/Revised (M106) transaction, impose a D35 and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Click the Special Benefits (M106) link and in the Parental section, do the following:

- Entitlement weeks: Enter the number of weeks of entitlement (the total number of weeks the client is entitled to).

- Click Save .

- Action: Select Add .

- Disentitlement: Select 35 - Parental benefits, qualifying conditions not met .

- Start date: Select the first week the parent was overpaid parental benefit weeks.

- End date: Select Indefinite .

- Waiting period: Take the appropriate action:

- If the WP was deferred in error, select X - Rescind .

- If the WP was not deferred but should be, select 5 - Waiting period deferred (parental standard or extended) .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Click Update .

- Determine if a 1 - General suspension of benefits (stop payment) manual action (MA01) is imposed to stop payments for the sharing of parental benefits issue:

- If yes, go to step 16.

- If no, go to step 17.

- In FTS, select the Renewal/Revised (M106) transaction to remove the MA01:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits (stop payment) (if necessary).

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Various reasons for penalty and violation (2935): Select the appropriate option.

- According to our records / In addition, according to our records (2936)

- Failed to provide information: Text Specify what we have learned (1628 )

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292)

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment.

- Overpayment – No misrepresentation and active claim .

- Overpayment – No misrepresentation and inactive claim .

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other .

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Click OK .

- In NWS, complete the Claim Review (CR) Integrity WI. 

#### False statement not knowingly made — Reconsideration after 36 months

Source topic: `en_EN/task/adj_integrity_case_ps/false_statement_not_knowingly_made__rec_05f214bd_level_2.dita`

- Determine the issue:

- If the number of weeks paid exceeds the maximum shareable entitlement, go to step 2.

- If the type of parental benefits is incorrect, go to step 3.

- If the WP was served incorrectly, go to step 4.

- In NWS, create a ROD for the parental sharing issue as follows:

- Comments: Type “[Integrity case number] — parental sharing.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If the client was initially approved for more parental benefits weeks than the client was entitled to and was overpaid because the maximum entitlement was reached, type “The client is entitled to receive [number of weeks] weeks.”

- If the client is entitled to 0 weeks, type “Parental benefits are exhausted. A 35 - Parental - minor attached or outside range or maximum parental/special benefits paid disentitlement is imposed effective [date]. The parent is not entitled to parental benefits because the maximum parental entitlement weeks has already been paid for the parental window.”

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 5.

- In NWS, create a ROD for the type of parental benefits as follows:

- Comments: Type “[Integrity case number] — changing the type of parental benefits”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy . If the client was paid the wrong type of parental benefits or was initially approved for more parental benefits weeks than the client was entitled to, type [“Parental benefits are payable up to a maximum combined total of 40 standard or 69 extended weeks per birth, adoption or placement for children born or placed for adoption on or after March 17, 2019.” or “Parental benefits are payable up to a maximum combined total of 35 standard or 61 extended weeks for children born or placed for adoption before March 17, 2019.”] The maximum number of weeks that can be paid to one parent is 35 weeks of standard benefits or 61 weeks of extended benefits. When clients share the parental benefits, the parents must share the same type of benefits. The first parent to apply for benefits for this birth, adoption or placement chooses a type of parental benefits. This is the type of benefits the other parents are entitled to. [The client or another parent ] applied for parental benefits first and is entitled to [ standard or extended ] parental benefits. The other parents are entitled to receive [number of weeks] weeks.
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 5.

- In NWS, create a ROD for the WP as follows:

- Comments: Type “[Integrity case number] — waiting period change.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If the client has had the WP deferred in error, type “Conditions to defer the waiting period are not met as a waiting period for this birth, adoption or placement has not yet been served.”

- If the WP should be deferred, type “Originally the waiting period was not deferred but should have been. Changes were made and the waiting period was deferred.”

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 5.

- Create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction )

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain why no false statements were made knowingly.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Click Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- Remarks line 1: Type “312 error code. Parental entitlement paid in full and WP deferred.”

- Remarks line 2: Type “Change entitlement parental weeks to [XX], DE35, start [XXXX], end 9999 OP Code 31F04.”

- Remarks line 3: Type “WP deferral rescind” if it was deferred in error.

- Remarks line 4: Type “Remove stop pay” if necessary.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Click Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Click Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Decision reconsidered beyond 36 months (2595): Select Decision reconsidered beyond 36 months due to false representations

- Various reasons for penalty and violation (2935): Select the appropriate option.

- According to our records / In addition, according to our records (2936)

- Failed to provide information: Text Specify what we have learned (1628)

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292)

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment.

- Overpayment – No misrepresentation and active claim .

- Overpayment – No misrepresentation and inactive claim .

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other .

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Click OK .

- In NWS, complete the CR Integrity WI. 

#### Voluntary disclosure allowed

Source topic: `en_EN/task/adj_integrity_case_ps/voluntary_disclosure_allowed_level_2.dita`

- Determine the issue:

- If the number of weeks paid exceeds the maximum shareable entitlement, go to step 2.

- If the type of parental benefits is incorrect, go to step 3.

- If the WP was served incorrectly, go to step 4.

- In NWS, create a ROD for the parental sharing issue as follows:

- Comments: Type “[Integrity case number] — parental sharing.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If the client was initially approved for more parental benefits weeks than the client was entitled to and was overpaid because the maximum entitlement was reached, type “The parent is entitled to receive [number of weeks] weeks.”

- If the client is entitled to 0 weeks, type “Parental benefits are exhausted. A 35 - Parental - minor attached or outside range or maximum parental/special benefits paid disentitlement is imposed effective [date]. The parent is not entitled to parental benefits because the maximum parental entitlement weeks has already been paid for the parental window.”

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 5.

- In NWS, create a ROD for the type of parental benefits as follows:

- Comments: Type “[Integrity case number] — changing the type of parental benefits”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy . If the client was paid the wrong type of parental benefits or was initially approved for more parental benefits weeks than the client was entitled to, type [“Parental benefits are payable up to a maximum combined total of 40 standard or 69 extended weeks per birth, adoption or placement for children born or placed for adoption on or after March 17, 2019.” or “Parental benefits are payable up to a maximum combined total of 35 standard or 61 extended weeks for children born or placed for adoption before March 17, 2019.”] The maximum number of weeks that can be paid to one parent is 35 weeks of standard benefits or 61 weeks of extended benefits. When clients share the parental benefits, the parents must share the same type of benefits. The first parent to apply for benefits for this birth, adoption or placement chooses a type of parental benefits. This is the type of benefits the other parents are entitled to. [The client or another parent ] applied for parental benefits first and is entitled to [ standard or extended ] parental benefits. The other parents are entitled to receive [number of weeks] weeks.
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 5.

- In NWS, create a ROD for the WP as follows:

- Comments: Type “[Integrity case number] — waiting period change.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .

- If the client has had the WP deferred in error, type “Conditions to defer the waiting period are not met as a waiting period for this birth, adoption or placement has not yet been served.”

- If the WP should be deferred, type “Originally the waiting period was not deferred but should have been. Changes were made and the waiting period was deferred.”

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save .

- Go to step 5.

- Create a ROD for the voluntary disclosure issue as follows:

- Comments: Type “[Integrity case number] — voluntary disclosure allowed.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain that the client meets the 2 conditions for the use of the National Policy on Voluntary Disclosure .
               [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- Go to step 6.

- In NWS, create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction ):

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if the number of weeks paid is equal to the number of weeks of entitlement shown in FTS:

- If yes, go to step 8.

- If no, go to step 15.

- In FTS, determine if the WP status is 5 - Waiting period deferred (parental standard or extended) :

- If no, go to step 9.

- If yes, error code 312 is generated and an IPOC agent must make the change. Go to step 12.

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 10.

- If the claim is terminated, but can be reactivated:

- On the Terminated tab, select the appropriate BPC.

- Click Reactivate .

- Go to step 10.

- If the claim is blocked or archived, go to step 12.

- On day 1, in FTS, select the Renewal/Revised (M106) transaction and impose a D35 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 35 - Parental benefits, qualifying conditions not met .

- Start date: Select the first week the parent was overpaid parental benefit weeks.

- End date: Select Indefinite .

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Click Update .

- On day 2, select the Renewal/Revised (M106) transaction and complete the following fields:

- Registration number: Select the appropriate registration number.

- Click the Special Benefits (M106) link and in the Parental section, do the following:

- Entitlement weeks: Enter the number of weeks of entitlement (the total number of weeks the client is entitled to).

- Click Save .

- Waiting period: If the WP should be deferred, select 5 - Waiting period deferred (parental standard or extended) .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Click Update .

- Go to step 16.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Detection: Select the investigation type as displayed in NIIS.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Click Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- Remarks line 1: Type “312 error code. Parental entitlement paid in full and WP deferred.”

- Remarks line 2: Type “Change entitlement parental weeks to [XX], DE35, start [XXXX], end 9999 OP Code 31F04.”

- Remarks line 3: Type “WP deferral rescind” if it was deferred in error.

- Remarks line 4: Type “Remove stop pay” if necessary.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Click Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Click Update .

- Go to step 18.

- In FTS, select the Renewal/Revised (M106) transaction, impose a D35 and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Click the Special Benefits (M106) link and in the Parental section, do the following:

- Entitlement weeks: Enter the number of weeks of entitlement (the total number of weeks the client is entitled to).

- Click Save .

- Action: Select Add .

- Disentitlement: Select 35 - Parental benefits, qualifying conditions not met .

- Start date: Select the first week the parent was overpaid parental benefit weeks.

- End date: Select Indefinite .

- Waiting period: Take the appropriate action:

- If the WP was deferred in error, select X - Rescind.

- If the WP was not deferred but should be, select 5 - Waiting period deferred (parental standard or extended) .

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Click Update .

- Determine if an MA01 is imposed to stop payments for the parental sharing issue:

- If yes, go to step 17.

- If no, go to step 18.

- In FTS, select the Renewal/Revised (M106) transaction to remove the MA01 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Various reasons for penalty and violation (2935)

- Failed to provide information

- According to our records / In addition, according to our records (2936)

- one occasion / Text: number of occasions (2937)

- Text - Specify what we have learned (1628):

- No reply from claimant / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment.

- Overpayment – No misrepresentation and active claim .

- Overpayment – No misrepresentation and inactive claim .

- In ACS, create and send the D-70-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Voluntary disclosure / Administrative Rule - Undeclared Earnings(2664):

- Voluntary disclosure of information(2694) .

- Subjects of Voluntary Disclosure (2665) .

- Option # 7: Text-Insert appropriate reason(s) (1618)

- Blank/Reminder: Provide information on report (2667) .

- Provide full and accurate information on each report and correct any incorrect reports as soon as possible.

- Overpayment messages (2452): Select the appropriate option.

- Right to request a reconsideration (4169) .

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other .

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Click OK .

- In NWS, complete the CR Integrity WI. 

#### Not within reconsideration timeframe

Source topic: `en_EN/task/adj_integrity_case_ps/not_within_reconsideration_timeframe_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — EIA 52 — not within reconsideration period.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, select the Renewal/Revised (M106) transaction and clear the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Click Update .

- In NIIS, from the Report for Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “not within reconsideration period — no decision on the parental sharing issue.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Click OK .

- In NWS, complete the CR Integrity WI. 

#### Returning the file to Integrity

Source topic: `en_EN/task/adj_integrity_case_ps/returning_the_file_to_integrity_level_2.dita`

- In NIIS, from the Document tab, select IC70 Report of Investigation or IC50 Report of Clerical Investigation , depending on the case, and complete the following fields:

- Select Recommendation .

- Refer the file to Integrity as follows:

- Click Yes (IC70) .

- Check the box (IC50) .

- Enter the missing or additional information required in the text area.

- Click OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1673.dita)

- In FTS, click the Outstanding Registrations link to cancel the registration number as follows:

- Click Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Click Update .

- Return the paper documents (if applicable) relating to the investigation to the investigator who signed the Report of Investigation.

- In NWS, complete the CR Integrity WI. 

#### Entitlement in order

Source topic: `en_EN/task/adj_integrity_case_ps/entitlement_in_order_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — parental benefits compliance — entitlement in order.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain why entitlement is considered in order.

- Create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction ):

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if an MA01 is imposed to stop payments for the parental sharing issue:

- If yes, go to step 4.

- If no, go to step 5.

- Select the Renewal/Revised (M106) transaction to remove the MA as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Infraction: Select F - Non fraud - Other .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number.

- Click Update .

- Go to step 6.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Click Update .

- In NIIS, from the Report for Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Entitlement in order.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Click OK .

- In NWS, complete the CR Integrity WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1673.dita`

Note:

The regional consideration for agents in the Quebec region is as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a Cc.

- In NWS, create a client Note and type “measure - returned to Integrity” and include the date (YYYY-MM-DD). 

## Policy reference

Source topic: `en_EN/task/adj_integrity_case_ps/policy_reference.dita`

- Digest 13 — Parental benefits
         [Digest 13 — Parental benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-13/table-of-contents.html)

- Digest 17 — Reconsideration, Amendment of a Decision, and Error Correction
         [Digest 17 — Reconsideration, Amendment of a Decision, and Error Correction](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/table-of-contents.html)

- Digest 18 — Policy on Penalties
         [Digest 18 — Policy on Penalties](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/table-of-contents.html)

- EIA 23
         [EIA 23](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-23.html)

- EIA 52
         [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 
