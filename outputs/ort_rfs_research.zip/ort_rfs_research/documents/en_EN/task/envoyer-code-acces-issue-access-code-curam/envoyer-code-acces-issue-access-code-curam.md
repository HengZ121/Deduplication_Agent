# Issuing an access code — Cúram

Source map: `en_EN/task/envoyer-code-acces-issue-access-code-curam/envoyer-code-acces-issue-access-code-curam.ditamap`

## Summary

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/summary.dita`

Summary: When a client reports having lost or forgotten an access code, it is possible to reissue the original access code by mail or to issue a temporary access code. 

## What you need to know

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/untitled_section.dita`

An access code is a 4-digit number that is issued to the client by letter when the client submits an application for benefits. The system generates and mails the access code to the client automatically. Only 2 of the 4 numbers are displayed in Cúram. It can take up to a week for clients to receive their access code depending on mail delivery.

The SIN and access code allow clients to:

- obtain personal information about their claim for benefits through any of the following channels:

- MSCA-EI

- the Telephone Information Service (TIS)

- a Service Canada Centre (SCC)

- call centres

- complete electronic claimant’s reports through TRS or IRS.

The access code does not expire as long as the client record exists. After 7 years of inactivity, client records are removed from the database and the access code expires.

     [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3368.dita) 

### Replacing an access code

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/replacing_an_access_code.dita`

Clients can replace their own access code using TIS. When clients lose or forget their access code, they are unable to access TIS or complete electronic claimant’s reports. However, it is possible for a Service Canada officer to reissue the original access code or issue a temporary one. Replacing the access code with either the original code or a temporary code automatically restores the client’s access to these services. 

### Detailed security check

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/detailed_security_check.dita`

A detailed security check must be conducted with the client before providing information or issuing an access code. The officer does not accept requests to reissue an access code from a third party, unless it is from the designated representative. In the case of a representative, ensure that there is no electronic document indicating that the client has recovered and no longer requires the services of the representative. Representatives are identified in Cúram with the indicator “REP”. For additional information, refer to Appointment of representative — Limited physical or mental capacity .
       [Appointment of representative — Limited physical or mental capacity](/en/procedure/activity/app_rep.shtml) 

### Validating the client’s address

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/validating_the_clients_address.dita`

When a client is successfully identified, the officer validates the address on file to ensure that Service Canada has the most recent information. If the address is incorrect, the officer changes it. 

### Rescinding a security code 6 imposed by Integrity

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/rescinding_a_security_code_6_imposed_by_a517edff.dita`

Due to attempts by unknown sources to identify EI access codes associated with some client’s files, a Security Status code 6 – Claimant does not want to use the service may have been imposed by Integrity. This code prevents the client from completing claimant’s reports. When this code is input, Integrity adds an SROC in NWS that states:

For security reasons, the client cannot submit a report electronically. Please verify the claimant’s identity by using the detailed security check and proceed with the completion of the client’s report.

If claimant’s identity cannot be confirmed, do not input any transactions. Accept the client information related to the request or enquiry and forward the information to Regional Integrity Operations using a Call Back Work Item in NWS.”

When speaking to a client impacted by this situation, the officer conducts a detailed security check to authenticate the client. If the authentication is successful, the officer rescinds the security code, assigns a temporary access code and explains to the client how to change it. If the client fails the detailed security check, the officer sends a CB WI to Integrity.

For more information, the officer refers to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Reissuing the access code

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/reissuing_the_access_code.dita`

There are 2 options for issuing access codes.

**Reissuing the original access code**

The original code is sent to the client by mail the same day or the next business day, if the request for the code is received on a Friday. Therefore, it can take up to a week for clients to receive their access code, depending on mail delivery.

Exceptions:

The access code cannot be reissued in the following circumstances:

- claim is contentious or BPNE

- claim is dormant

- client is deceased

- claim is in purge and recreate

- temporary access code is already assigned (TIS security code 50, 51, 60 or 61)

- claim is transferred

- claim is in MPS

- a new SIN

In the above cases, a temporary access code must be issued.

**Issuing a temporary access code**

When clients have an electronic claimant’s report that is past due or imminent (within the next 5 business days), or when they receive a new SIN, the officer issues a temporary code.

Clients must change the temporary code they have received to a 4-digit number of their choice using TIS. The officer confirms with clients that they have access to a touch-tone telephone, since they need it to access TIS. To make the change, they are instructed to enter the temporary code and then to input their new code. TIS then confirms that the change is successful.

If the client does not have access to a touch-tone telephone, the officer obtains and inputs the claimant’s reports.

If clients receive a new SIN, they cannot use the access code linked to the old SIN and the officer cannot reissue it. When an IPOC officer has updated the client’s electronic file with the new SIN, the officer contacts the client to issue a temporary access code. 

### Warning

Source topic: `en_EN/common_notes/note_c_3368.dita`

Warning:

If fraudulent activity is suspected on an EI claim, the officer does not issue an access code. For more information, the officer refers to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml)

     [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

## Regional considerations

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/in_nws.dita`

- What personal information did the client indicate in the Personal Information section of the application?

- Is there an SROC stating that for security reasons, the client cannot submit a report electronically? 

### In Cúram:

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/in_curam.dita`

- Is the client’s personal information available?

- Is there a claimant’s report due within the next 5 business days?

- Is there a security code 6 – Claimant does not want to use the service on the Electronic Security screen? 

## Step by step

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/reviewing_the_file_level_1.dita`

- In Cúram, from the Person Evidence Case home screen in the Access Code section, review the Security Status field to determine if code 6 – Claimant does not want to use the service has been imposed by Integrity:

- If yes, go to Rescinding a Security Status code 6 imposed by Integrity .
               [Rescinding a Security Status code 6 imposed by Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/envoyer-code-acces-issue-access-code-curam#level1_item_3)

- If no, go to step 2.

- Determine if the client must be contacted by telephone or if the call is already in progress with the client:

- If the client must be contacted by telephone, go to step 3.

- If the call is already in progress with the client, go to step 4.

- Contact the client by referring to the appropriate fact-finding task. Determine if the client was reached during fact-finding:

- If the client was reached, go to step 4.

- If the client was not reached or did not reply to the N-10-00-00 letter, complete the WI. No further action is required. 

#### Conducting a detailed security check

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/conducting_a_detailed_security_check_level_1.dita`

- Conduct a detailed security check with the client:

- If the client fails the detailed security check, go to Detailed security check — Failed .
               [Detailed security check — Failed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/envoyer-code-acces-issue-access-code-curam#dscf)

- If the client passes the detailed security check, go to step 5.

           [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3369.dita) 

#### Detailed security check — Passed

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/detailed_security_check__passed_level_1.dita`

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 6.

- If the client’s address is different than the one on file, refer to Change of address and then go to step 6.
               [Change of address](/en/procedure/task/ajou_mod_sup_adresse_client-add_mod_end_client_address_curam.shtml)

- Determine if the next claimant’s report is due within the next 5 business days:

- If no, reissue the original access code. Go to step 7.

- If yes, issue a temporary access code. Go to step 8.

- In Cúram, reissue the original access code as follows:

- From the Person Evidence Case home screen in the Access Code section, select the ellipses (…) on the right-hand side of the screen.

- Select Re-Issue .

- Select Save .

- Inform the client that a letter containing the access code will be issued.

- Go to step 11.

- Determine if the client has access to a touch-tone telephone:

- If no, obtain claimant’s reports from the client using the Claimant Report without Paycoding or Claimant Report with Paycoding checklist (to input the claimant’s reports, the officer refers to Inputting a Claimant’s Report – Cúram ).Go to step 9.
               [Claimant Report without Paycoding](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Original_without_pay_coding-Checklist.doc) 
               [Claimant Report with Paycoding](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Original_with_pay_coding-Checklist.doc) 
               [Inputting a Claimant’s Report – Cúram](/en/procedure/task/saisir-decl-assur-emp-input-client-report.shtml)

- If yes, go to step 10.

- Provide the client with the date their next claimant’s report is due and advise the client to call the Employment Insurance Call Centre (1-800-206-7218) every two weeks to complete their next claimant’s report. Go to step 11.

- In Cúram, issue a temporary access code as follows:

- From the Person Evidence Case home screen in the Access Code section, select the ellipses (…) on the right-hand side of the screen.

- Select Issue Temporary .

- When the Create and Save Temporary Access Code window opens, advise the client of the warnings indicated.

- Select Next .

- Provide the client with the temporary access code (it is displayed until you save it).

- Select Save .

- Advise the client to contact TIS to select a new access code.

- Go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3370.dita)

- Determine if there is a WI for this task:

- If yes, complete the WI.

- If no, return to originating task. 

#### Detailed security check — Failed

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/detailed_security_check__failed_level_1.dita`

- Do not provide any claim information. Determine if the client can go to a SCC in person:

- If yes, provide clients with the address of the closest SCC and tell them to present their identification. Go to step 2.

- If no, tell clients to telephone 1-800-206-7218 for service in English and 1‑800‑808‑6352 for service in French when they have the information. Go to step 2.

- In NWS, create an external SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Access code request — security check failed.”

- Details: Type the appropriate option:

- “Client requested access code to be replaced, but failed detailed security check — client is unable to attend a SCC and has been told to contact us with information.”

- “Client requested access code to be replaced, but failed detailed security check — client directed to present identification at SCC (insert SCC address).”

- Determine if there is a WI for this task:

- If yes, complete the WI.

- If no, return to originating task. 

#### Rescinding a Security Status code 6 imposed by Integrity

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/rescinding_a_security_status_code_6_imp_7df2eaf2_level_1.dita`

- While on the telephone with the client, conduct a detailed security check .

- After conducting the detailed security check, do one of the following:

- If the client failed the detailed security check, go to step 3.

- If the client passed the detailed security check, go to step 5.

- Do not provide any claim information. Advise client that another officer will contact them to verify their identity.

- In NWS, create a CB WI for Integrity as follows:

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Integrity .

- Comments: Type “Security Status code 6 on file. Identity not validated.”

- Details: Explain why the issue is being referred to Integrity.

- No further action is required.

- Rescind the Security Status code 6 as follows:

- From the Person Evidence Case home screen under Access Code , select the ellipses (…) on the right hand side of the screen.

- Select Rescind .

- Select Save .

- Issue a temporary access code as follows:

- From the Person Evidence Case home screen in the Access Code section, select the ellipses (…) on the right-hand side of the screen.

- Select Issue Temporary .

- When the Create and Save Temporary Access Code window opens, advise the client of the warnings indicated.

- Select Next .

- Provide the client with the temporary access code (it is displayed until you save it).

- Select Save .

- Advise the client to contact TIS to select a new access code. 

#### Warning

Source topic: `en_EN/common_notes/note_c_3369.dita`

Warning:

If fraudulent activity is suspected on a claim, the officer does not issue an access code. For more information, refer to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml)

     [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_3370.dita`

Note:

The client must change the temporary access code by calling the TIS at 1-800-206-7218 for service in English or 1‑800‑808‑6352 for service in French and taking the following steps:

- Select option 1.

- Enter their SIN, followed by the access code as asked by the system.

- Select option 3

- Enter a new access code that is easy to remember.

- Enter the new access code a 2nd time to confirm it. 

### Level 2

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/reviewing_the_file_level_2.dita`

- In Cúram, from the Person Evidence Case home screen in the Access Code section, review the Security Status field to determine if code 6 – Claimant does not want to use the service has been imposed by Integrity:

- If yes, go to Rescinding a security code 6 imposed by Integrity .
               [Rescinding a security code 6 imposed by Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/envoyer-code-acces-issue-access-code-curam#level2_item_3)

- If no, go to step 2.

- Determine if the client must be contacted by telephone or if the call is already in progress with the client:

- If the client must be contacted by telephone, go to step 3.

- If the call is already in progress with the client, go to step 4.

- Contact the client by referring to the appropriate fact-finding task. Determine if the client was reached during fact-finding:

- If the client was reached, go to step 4.

- If the client was not reached or did not reply to the N-10-00-00 letter, complete the WI. No further action is required. 

#### Conducting a detailed security check

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/conducting_a_detailed_security_check_level_2.dita`

- Conduct a detailed security check with the client:

- If the client fails the detailed security check, go to Detailed security check — Failed .
               [Detailed security check — Failed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/envoyer-code-acces-issue-access-code-curam#dscf_l2)

- If the client passes the detailed security check, go to step 5.

           [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3371.dita) 

#### Detailed security check — Passed

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/detailed_security_check__passed_level_2.dita`

- Validate the client’s address:

- If the client’s address is the same as the one on file, go to step 6.

- If the client’s address is different than the one on file, refer to Change of address and then go to step 6.
               [Change of address](/en/procedure/task/ajou_mod_sup_adresse_client-add_mod_end_client_address_curam.shtml)

- Determine if the next claimant’s report is due within the next 5 business days:

- If no, reissue the original access code. Go to step 7.

- If yes, issue a temporary access code. Go to step 8.

- In Cúram, reissue the original access code as follows:

- From the Person Evidence Case home screen in the Access Code section, select the ellipses (…) on the right-hand side of the screen.

- Select Re-Issue .

- Select Save .

- Inform the client that a letter containing the access code will be issued.

- Go to step 11.

- Determine if the client has access to a touch-tone telephone:

- If no, obtain claimant’s reports from the client using the Claimant Report without Paycoding or Claimant Report with Paycoding checklist (to input the claimant’s reports, the officer refers to Inputting a Claimant’s Report – Cúram).Go to step 9.
               [Claimant Report without Paycoding](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Original_without_pay_coding-Checklist.doc) 
               [Claimant Report with Paycoding](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Original_with_pay_coding-Checklist.doc)

- If yes, go to step 10.

- Provide the client with the date their next claimant’s report is due and advise the client to call the Employment Insurance Call Centre (1-800-206-7218) every two weeks to complete their next claimant’s report. Go to step 11.

- In Cúram, issue a temporary access code as follows:

- From the Person Evidence Case home screen in the Access Code section, select the ellipses (…) on the right-hand side of the screen.

- Select Issue Temporary .

- When the Create and Save Temporary Access Code window opens, advise the client of the warnings indicated.

- Select Next .

- Provide the client with the temporary access code (it is displayed until you save it).

- Select Save .

- Advise the client to contact TIS to select a new access code.

- Go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3370.dita)

- Determine if there is a WI for this task:

- If yes, complete the WI.

- If no, return to originating task. 

#### Detailed security check — Failed

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/detailed_security_check__failed_level_2.dita`

- Do not provide any claim information. Determine if the client can go to a SCC in person:

- If yes, provide clients with the address of the closest SCC and tell them to present their identification. Go to step 2.

- If no, tell clients to telephone 1-800-206-7218 for service in English and 1‑800‑808‑6352 for service in French when they have the information. Go to step 2.

- In NWS, create an external SROC as follows:

- Determine if there is a WI for this task:

- If yes, complete the WI.

- If no, return to originating task. 

#### Rescinding a Security Status code 6 imposed by Integrity

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/rescinding_a_security_status_code_6_imp_7df2eaf2_level_2.dita`

- While on the telephone with the client, conduct a detailed security check .

- After conducting the detailed security check, do one of the following:

- If the client failed the detailed security check, go to step 3.

- If the client passed the detailed security check, go to step 5.

- Do not provide any claim information. Advise client that another officer will contact them to verify their identity.

- In NWS, create a CB WI for Integrity as follows:

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select National Compliance – Special Projects.

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Integrity .

- Comments: Type “Security code 6 on file. Identity not validated.”

- Details: Explain why the issue is being referred to Integrity.

- No further action is required.

- Rescind the Security Status code 6 as follows:

- From the Person Evidence Case home screen under Access Code , select the ellipses (…) on the right hand side of the screen.

- Select Rescind .

- Select Save .

- Issue a temporary access code as follows:

- From the Person Evidence Case home screen, in the Access Code section, select the ellipses (…) on the right-hand side of the screen.

- Select Issue Temporary .

- When the Create and Save Temporary Access Code window opens, advise the client of the warnings indicated.

- Select Next .

- Provide the client with the temporary access code (it is displayed until you save it).

- Select Save .

- Advise the client to contact TIS to select a new access code. 

#### Warning

Source topic: `en_EN/common_notes/note_c_3371.dita`

Warning:

If fraudulent activity is suspected on a claim, the officer does not issue an access code. For more information, refer to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml)

     [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

## Policy reference

Source topic: `en_EN/task/envoyer-code-acces-issue-access-code-curam/policy_reference.dita`

 
