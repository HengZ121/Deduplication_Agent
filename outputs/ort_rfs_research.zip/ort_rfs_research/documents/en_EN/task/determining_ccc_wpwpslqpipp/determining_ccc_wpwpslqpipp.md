# Determining during calculation of a claim if the client is entitled to have the waiting period waived due to paid sick leave or QPIP payments

Source map: `en_EN/task/determining_ccc_wpwpslqpipp/determining_ccc_wpwpslqpipp.ditamap`

## Summary

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/summary.dita`

Summary: Clients who have received paid sick leave (PSL) from their employer or QPIP payments after their last day worked may be entitled to have their waiting period (WP) waived. 

## What you need to know

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Waiting period (WP)

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/waiting_period_wp.dita`

Generally, before receiving the first week of benefits, clients must serve a WP for which no benefits are payable. The WP begins on the first week of unemployment for which benefits would otherwise be payable. Under certain conditions, the WP can be waived.
       [WP](/en/procedure/generic/knowledge.shtml#Waiting_period)

**Pilot project no. 24: Waiving the waiting period (WP) for BPCs between March 30 andOctober 10, 2026 (w/c 2493 to w/c2572)**

A temporary measure to waive the one-week WP has been implemented to support clients impacted by major changes in economic conditions due to the imposition of tariffs by the United States. The WP is waived for all initial claims with a BPC between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ), regardless of the requested benefit type (BT). If it is advantageous to the client, the client can decide to serve the WP (e.g. the client must serve the WP to receive supplemental unemployment benefits [SUB]).

For more information, the officer refers to Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions .
       [Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions](/en/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml) 

### Determining if the waiting period (WP) can be waived

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/determining_if_the_waiting_period_wp_ca_77ecbdb6.dita`

When PSL or QPIP payments are received after the last day of work, the WP can be waived when both of the following conditions are met:

- A benefit period (BP) is being established based on an interruption of earnings (I of E) due to illness, injury, quarantine, pregnancy, the need to care for a newly born or adopted child, or the need to provide care or support to a gravely ill family member;

- After the last day worked, the client received QPIP payments or PSL from the same employer related to the I of E that occurred.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3125.dita) 

PSL and QPIP payments are the only earnings that allow the WP to be waived. Payments made for any other reason (e.g. wage loss insurance, paid vacation, liquidation of accumulated sick leave credits when the reason for separation (RFS) is not sickness, maternity leave payments or payments made for the care of a child) do not allow the WP to be waived.

It may not be to the client’s advantage to waive the WP if the employer pays supplements to EI for maternity or parental benefits (top-up) and the client is requesting maternity or parental benefits. In those cases, the details of the SUB plan are required to determine if it is to the client’s advantage to waive the WP.

Examples of situations in which it is not to the client’s advantage to waive the WP:

- The employer is providing a supplement to top up EI benefits to 100% of the client’s normal salary for the entire BP, including the WP.

- The other parent sharing parental benefits does not want to serve the WP (for example, because that parent can only take a few weeks off).

- The employer’s SUB plan requires the client to serve the WP to be entitled to the SUB payments. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_3125.dita`

Note:

The PSL does not have to be paid by the most recent employer if there is more than one employment, as long as both conditions are met for one employer. The client does not have to apply for special benefits for the WP to be waived. 

## Regional considerations

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/in_nws.dita`

- Is there information on file indicating that the client is receiving SUB payments?

- If yes, what are the details of the SUB plan?

- Did the client stop working due to illness, injury, quarantine, pregnancy, the need to care for a newly born or adopted child, or the need to provide care or support to a gravely ill family member? 

### In RCM:

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/in_rcm.dita`

- Is the RFS on the ROE due to illness, injury, quarantine, pregnancy, the need to care for a newly born or adopted child, or the need to provide care or support to a gravely ill family member?

- Has the employer stated that the client was paid sick leave after the last day worked?

- Has the employer stated that the client is receiving SUB payments?

- If yes, are the details of the SUB plan available? 

### In FTS:

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/in_fts.dita`

- Does this employer provide a SUB plan?

- If yes, what are the plan details?

- Did the client receive payments from QPIP? 

## Step by step

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/level_1.dita`

#### Determining if the waiting period (WP) must be waived

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/determining_if_the_waiting_period_wp_mu_99bcfd7b_level_1.dita`

- Determine if additional fact-finding is required:

- If no, go to step 2.

- If yes, go to Fact-finding .
               [Fact-finding](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_ccc_wpwpslqpipp#_Fact-finding_is_required)

- Determine if the following conditions apply:

- A BP is being established based on an I of E due to illness, injury, quarantine, pregnancy, the need to care for a newly born or adopted child, or the need to provide care or support to a gravely ill family member.

- After the last day worked, the client received sick leave payments from the same employer where the I of E occurred, or the client received benefits from the QPIP.

- If both conditions are met, go to step 3.

- If either condition is not met, go to Waiting period (WP) must not be waived .
                   [Waiting period (WP) must not be waived](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_ccc_wpwpslqpipp#_Waiting_period_not)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3126.dita)

- Determine if the client is receiving SUB from the employer while receiving EI benefits:

- If the client is receiving SUB, go to step 4.

- If the client is not receiving SUB, go to Waiting period (WP) must be waived .
               [Waiting period (WP) must be waived](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_ccc_wpwpslqpipp#_Waiting_period_to)

- Based on the SUB plan details, determine if it is to the client’s advantage to serve a WP:

- If serving a WP is to the client’s advantage, the WP will not be waived. Go to Waiting period (WP) must not be waived .
               [Waiting period (WP) must not be waived](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_ccc_wpwpslqpipp#_Waiting_period_not)

- If serving a WP is not to the client’s advantage, go to Waiting period (WP) must be waived .
               [Waiting period (WP) must be waived](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_ccc_wpwpslqpipp#_Waiting_period_to) 

#### Waiting period (WP) must not be waived

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/waiting_period_wp_must_not_be_waived_level_1.dita`

- On the calculation worksheet, note that if a decision letter is sent when the claim is finalized, the Waiting Period Message (2444) message must be inserted.

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 11 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 11 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 10 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is CCB, refer to step 11 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is family caregiver benefits (FCB), refer to step 11 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Waiting period (WP) must be waived

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/waiting_period_wp_must_be_waived_level_1.dita`

- On the calculation worksheet, note that when the claim is input in SSO, the officer must waive the WP.

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 11 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 11 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 10 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is CCB, refer to step 11 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is FCB, refer to step 11 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Fact-finding

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/fact-finding_level_1.dita`

- On the calculation worksheet, note that you must fact-find with the employer or the client to determine if there is entitlement to PSL or QPIP payments.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2237.dita)

- Determine the BT requested for the calculation:

- If the BT is regular, refer to step 11 of Determining if a claim is ready to be calculated — Regular benefits .
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If the BT is sickness, refer to step 11 of Determining if a claim is ready to be calculated — Sickness benefits .
               [Determining if a claim is ready to be calculated — Sickness benefits](/en/procedure/subactivity/det_crc_sb.shtml)

- If the BT is sickness, maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Sickness, maternity and parental benefits](/en/procedure/subactivity/detcalc_smp.shtml)

- If the BT is maternity and parental, refer to step 11 of Determining if a claim is ready to be calculated — Maternity and parental benefits .
               [Determining if a claim is ready to be calculated — Maternity and parental benefits](/en/procedure/subactivity/detcalc_mpb.shtml)

- If the BT is parental, refer to step 10 of Determining if a claim is ready to be calculated — Parental benefits .
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If the BT is CCB, refer to step 11 of Determining if a claim is ready to be calculated — CCB .
               [Determining if a claim is ready to be calculated — CCB](/en/procedure/subactivity/detcalc_ccb.shtml)

- If the BT is FCB, refer to step 11 of Determining if a claim is ready to be calculated — Family caregiver benefits .
               [Determining if a claim is ready to be calculated — Family caregiver benefits](/en/procedure/subactivity/detcalc_pcic.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_3126.dita`

Note:

As a temporary measure under Pilot Project No. 24, the WP is waived on all BPCs between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). Clients can request to serve to WP if it is to their advantage (e.g. clients must serve the WP to receive SUB).

For more information, the officer refers to Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions .
       [Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions](/fr/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml)

     [Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions](/fr/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2237.dita`

Note:

Once fact-finding is complete, return to this task. 

## Policy reference

Source topic: `en_EN/task/determining_ccc_wpwpslqpipp/policy_reference.dita`

- EIA 13
         [EIA 13](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-10.html)

- Digest 1.8.1- Application
         [Digest 1.8.1- Application](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-1/waiting-period.html#a1_8_1)

- EIR 40(6)
         [EIR 40(6)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-23.html)

- EIR 76.22
         [EIR 76.22](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-44.html) 
