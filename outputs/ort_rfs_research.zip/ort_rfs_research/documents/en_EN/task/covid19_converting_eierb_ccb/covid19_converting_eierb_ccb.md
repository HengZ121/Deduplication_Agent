# COVID-19 — Converting EI ERB claims to CCB

Source map: `en_EN/task/covid19_converting_eierb_ccb/covid19_converting_eierb_ccb.ditamap`

## Summary

Source topic: `en_EN/task/covid19_converting_eierb_ccb/summary.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0826.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_converting_eierb_ccb#archived)

Summary: After receiving the EI Emergency Response Benefit (EI ERB), a client can request that their claim be converted to CCB. 

### Warning

Source topic: `en_EN/common_notes/note_c_0826.dita`

**This page has been archived on the Web**

UPDATED: 2022-04-12 — The Headlines and Updates page has been archived because the information is outdated.

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available. 

## What you need to know

Source topic: `en_EN/task/covid19_converting_eierb_ccb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/covid19_converting_eierb_ccb/untitled_section.dita`

CCB are paid to clients who temporarily stop working to provide care or support to a family member who is gravely ill and who has a significant risk of death within 26 weeks. A maximum of 26 weeks of CCB is paid to eligible clients. 

### Payment of benefits

Source topic: `en_EN/task/covid19_converting_eierb_ccb/payment_of_benefits.dita`

The maximum number of weeks of CCB payable in a BP is 26 for one or more patients. Up to 26 clients may share in CCB for any one patient. A maximum of 26 weeks is payable per gravely ill family member. CCB can be paid only during a CCW. 

### Determining if the EI ERB claim can be terminated

Source topic: `en_EN/task/covid19_converting_eierb_ccb/determining_if_the_ei_erb_claim_can_be__3b93ca30.dita`

In order to terminate the EI ERB claim, the client must be able to qualify for a new benefit period (BP) for CCB (600 hours of insurable employment). On top of the hours accumulated after the start of the EI ERB claim, the agent uses the hours before the BPC of the EI ERB claim to determine if the client qualifies for a new claim.

**Credit of insurable hours of employment for BPNE claims**

If a client requesting CCB after receiving EI ERB or CERB has fewer than 600 hours of insurable employment in their qualifying period, a credit of 480 hours is awarded to the client.

The agent must create an interim ROE as follows:

- Block 4: EI ERB initiative – Credit hours

- Block 6: Weekly

- Block 8: Social Insurance Number

- Block 10: the Sunday of the EI ERB BPC

- Block 11: the Saturday of the last week of EI ERB

- Block 12: the Saturday of the last week prior of EI ERB

- Block 15A: 480

- Block 15B: 1

- Block 16: A-Shortage of work

If the client still does not qualify for a new claim for CCB after the credit is awarded, the client continues to receive EI ERB or CERB for the remainder of the entitlement weeks (a maximum of 28 weeks or until October 3, 2020). 

### Required documents

Source topic: `en_EN/task/covid19_converting_eierb_ccb/required_documents.dita`

To receive CCB, the client must provide all ROEs in the QP and a medical certificate to attest to the family member being gravely ill.

If information is missing and the agent cannot establish the claim based on the information on file, the agent does not terminate the EI ERB claim. The agent imposes a 39 - Prevent payment of part II benefits and/or incorrect Part 1 benefits disentitlement (D39) until the client provides the information required to establish the claim.

**Medical certificate**

Refer to COVID-19 and reviewing medical certificates for CCB and family caregiver to determine if a medical certificate is required.
       [COVID-19 and reviewing medical certificates for CCB and family caregiver](/en/site/dossier/covid19_review_mc_ccb_fc.shtml)

**Missing ROE**

As a result of QP extensions, or the fact that the EI ERB was calculated without the ROE, there may be incidences of missing ROEs that are required for calculation.

During calculation, if the error code Due to extension of qualifying period, additional insurable hours could be required (1093) is displayed, the agent refers to Reviewing the calculation result — Messages for more details. The agent can also refer to Updated: COVID-19 and missing ROEs — Procedures (Level 1) .
       [Reviewing the calculation result — Messages](/en/procedure/generic/rcr_screen_messages.shtml) 
       [Updated: COVID-19 and missing ROEs — Procedures (Level 1)](/en/site/dossier/updated_missing_roe_procedure_level1.shtml)

**Terminating the EI ERB claim**

For clients to receive CCB, the agent has to terminate the EI ERB claim and register a new initial claim for CCB.

For more information on how to terminate a claim, the agent refers to Terminating a benefit period .
       [Terminating a benefit period](/en/procedure/task/benefit_period_term.shtml) 

### Establishing the subsequent claim for CCB

Source topic: `en_EN/task/covid19_converting_eierb_ccb/establishing_the_subsequent_claim_for_ccb.dita`

The agent can use the initial application to set up the subsequent claim. If the client worked between the application date and the date on which the subsequent claim for CCB begins, the client can provide the specific details of that employment between the renewal date and the start date of the subsequent claim. The agent can use an interim ROE, but also advises the client to provide the ROE.

The normal calculation procedures apply to these claims except for the requirement to amend the previously paid BPC date in SSA and the requirement to waive the waiting period (WP).

**Re-inputting information from an application**

The agent ensures that all information from the initial application has been actioned on the subsequent claim, including supplemental unemployment benefits (SUB) coding and exemptions from completing claimant’s reports.

**Documentation for the subsequent CCB claim**

The agent saves all documentation and decisions related to the subsequent CCB claim in the appropriate application and not in external SROCs and records of decision (RODs). 

### BPC of the CCB claim

Source topic: `en_EN/task/covid19_converting_eierb_ccb/bpc_of_the_ccb_claim.dita`

When the client meets all the requirements for CCB, the claim for CCB starts:

- At the next payable week (if the client is on a continuing claim);

- At the renewal week (if the client had returned to work);

- After the last week of the period for which a payment of CERB was received (the client will have to provide the date of the last payment of CERB).

The CERB periods are as follows:

- March 15, 2020 to April 11, 2020

- April 12, 2020 to May 9, 2020

- May 10, 2020 to June 6, 2020

- June 7, 2020 to July 4, 2020

- July 5, 2020 to August 1, 2020

- August 2, 2020 to August 29, 2020

- August 30, 2020 to September 26, 2020

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2960.dita) 

### Extending the qualifying period (QP)

Source topic: `en_EN/task/covid19_converting_eierb_ccb/extending_the_qualifying_period_qp.dita`

In some cases, the QP can be extended by a maximum of 52 weeks (for a maximum QP length of 104 weeks).The QP can never be extended beyond the BPC week of a previous claim. The agent does not take into account the EI ERB claim in the calculation of the QP extension.

To account for the EI ERB or CERB period, the QP is extended:

- by 16 weeks if the BPC for the new initial claim is between March 15, 2020 and June 28, 2020.

- by 24 weeks if the BPC for the new initial claim between July 5, 2020 and August 23, 2020.

- by 28 weeks if the BPC for the new initial claim is on or after August 30, 2020.

All clients are entitled to a QP extension, even if they did not receive the full 28 weeks of the EI ERB or CERB.

The agent refers to Reviewing for a possible qualifying period extension to determine if the client is entitled to other QP extensions.
       [Reviewing for a possible qualifying period extension](/en/procedure/task/calc_determining/review_qpe.shtml)

**Determining the cut-off date (COD)**

The agent needs to determine what the actual COD is. The COD is the most recent of the following dates:

- the date of a previous non-ERB claim;

- if the BPC is March 15, 2020 and June 28, 2020: the BPC of the new claim  – 68 weeks – any other QP extensions;

- if the BPC is between July 5, 2020 and August 23, 2020: the BPC of the new claim  – 76 weeks – any other QP extensions;

- if the BPC is on or after August 30, 2020: the BPC of the new claim – 80 weeks – any other QP extensions.

This calculation takes into account the extension due to ERB as well as the normal 52-week the QP. Any additional QP extensions on file also need to be included.

In SSA, the agent manually inputs the COD on the Coding Requirements screen in the Previously paid BPC field. This allows the new claim to bypass the EI ERB claim and be calculated accordingly.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2961.dita) 

**Inputting the QP extension**

The QP extension is input in SSA on the Extension of the Qualifying/ Benefit period annex. The agent selects t he dates to use in the extension as follows:

- From [BPC - 16] to [BPC – 1]

- From [BPC - 24] to [BPC – 1]

- From [BPC - 28] to [BPC – 1]

The agent refers to Extending the qualifying period in SSA to input the QP extension and uses the Employment measures reason.
       [Extending the qualifying period in SSA](/en/procedure/task/calc_calculating/extending_qp.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2962.dita) 

### Waiving the waiting period (WP)

Source topic: `en_EN/task/covid19_converting_eierb_ccb/waiving_the_waiting_period_wp.dita`

The agent can waive the WP on all subsequent initial CCB claims after an EI ERB or CERB claim.  The codes to use are:

- Wage Loss Insurance: Select 3 - Paid sick leave prior to benefit period commencement - WP must be waived .

- Waiting period: Select 2 - Waived . 

### IPOC intervention required

Source topic: `en_EN/task/covid19_converting_eierb_ccb/ipoc_intervention_required.dita`

In some cases, the EI ERB claim may have already been converted to CCB and some weeks of EI ERB or CCB may have been processed. In these cases, IPOC intervention is required to properly establish the subsequent claim.

If any weeks of CCB appear in the Payments tab in FTS, but no payments were issued, the agent creates an IPOC Review (IPOC REV) WI to remove CCB weeks from the EI ERB claim before establishing the subsequent CCB claim. Once the weeks are removed from the pay history summary (PHS), the agent establishes the subsequent claim.

If the client has received the wrong type of benefits, the agent sends an Operational Centre Memo (MM06) transaction to IPOC to terminate the old claim and establish the subsequent claim in purge and recreate (P/R).

The overpayments (OP) created when clients receive the EI ERB instead of CCB are written off. The OP is still displayed in FTS but the balance is not recoverable.

If the claim displays 5 - COVID-19 Automation Utility , the agent cannot register a recalculation in SSA because there is no claim to recalculate. The workaround is to register an initial claim, input the data to obtain a calculation result for the desired BPC, and send the file to IPOC on an Operational Centre Memo (MM06) transaction. 

### Note

Source topic: `en_EN/common_notes/note_c_2960.dita`

Note:

The new claim starts after the last paid week of EI ERB or CERB, however, the client may want to start the claim at an earlier date.  In these cases, the agent should explain to the client the advantages and disadvantages of starting the claim at an earlier date.

The agent must refer to Calculating or recalculating a claim for CCB in order to set-up the initial claim.  The client is entitled to the QP extension, WP waiver and credit of hours as mentioned in this procedure.
       [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml)

     [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2961.dita`

Note:

If the COD is less than the new BPC - 52 then no QP extension is required for the calculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2962.dita`

Note:

Adding only the QP extension on the Special Benefits - Annex screen is not sufficient because the QP cannot be extended beyond the previously paid BPC (which is the BPC of the EI ERB claim). That is why the QP extension has to be factored in and the agent must manually enter the COD in the Previously Paid BPC field in SSA. 

## Regional considerations

Source topic: `en_EN/task/covid19_converting_eierb_ccb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/covid19_converting_eierb_ccb/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/covid19_converting_eierb_ccb/in_nws.dita`

- Is there an ROE on file? If no, is there employment information on file?

- Is the number of requested CCB weeks specified? 

### In FTS:

Source topic: `en_EN/task/covid19_converting_eierb_ccb/in_fts.dita`

- Are there any pended claimant’s reports or claimant’s reports to be processed before the conversion?

- Is there a registration number? 

### In RCM:

Source topic: `en_EN/task/covid19_converting_eierb_ccb/in_rcm.dita`

- Has an ROE been submitted? 

### In Imaging:

Source topic: `en_EN/task/covid19_converting_eierb_ccb/in_imaging.dita`

- Is there medical proof on file? 

## Step by step

Source topic: `en_EN/task/covid19_converting_eierb_ccb/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/covid19_converting_eierb_ccb/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/covid19_converting_eierb_ccb/reviewing_the_file_level_1.dita`

- In FTS, review the Payments tab and the Special Coding screen to determine if the client received EI ERB or CERB:

- If yes, go to step 2.

- If no, the CCB claim must be established as per normal process. Refer to Calculating or recalculating a claim for CCB .
               [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml)

- Determine the tentative BPC of the new CCB claim.

- Determine if the are pending, rejected or cycling CRs prior to the tentative BPC of the subsequent claim:

- If no, go to step 5.

- If yes, move the file to Pending as follows. Go to step 4.

- Pending reason: Select Other .

- Comments: Type “Verify that all EI ERB weeks have been paid.”

- Bring forward date: Enter the date on which the last payment is due + 5 business days.

- When the WI moves to the current workload, determine if the last requested week of EI ERB prior to the tentative BPC of the subsequent claim was paid:

- If no, return to step 3.

- If yes, go to step 5.

- Determine if all of the information required to establish whether the client qualifies for CCB on a new claim (e.g. an application, all ROEs, medical proof and the number of CCB weeks the client is entitled to) is on file:

- If no , go to step 6.

- If yes, go to step 12. 

#### Fact-Finding

Source topic: `en_EN/task/covid19_converting_eierb_ccb/fact-finding_level_1.dita`

- Fact-find with the client to obtain the missing information required to determine if the client qualifies for benefits on a new claim. If there is a missing ROE, refer to Updated: COVID-19 and missing ROEs — Procedures .

- Determine if the required information was obtained and if the client agreed to submit the required information:

- If the information was not obtained but the client agreed to provide it, go to step 9.

- If the information was obtained, go to step 12.

- If the information was not obtained and the client did not agree to provide it, go to Imposing a 39 - Prevent payment of part II benefits and/or incorrect Part I benefits disentitlement (D39) .
               [Imposing a 39 - Prevent payment of part II benefits and/or incorrect Part I benefits disentitlement (D39)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_converting_eierb_ccb#Imposing_d39)

- In NWS, determine if there is a WI related to the conversion from the EI ERB to CCB benefits:

- If no, go to step 9.

- If yes, go to step 10.

- Create a Reminder (REM) WI as follows:

- Complexity: Select Level 1 .

- Comments: Type “The client agreed to submit information for CCB.”

- Due date: Enter today’s date + 10 business days.

- Language: Select the appropriate option.

- Details: Type “The client must provide [missing information] to establish the subsequent CCB claim.”

- Destination — SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End user: Select Myself .

- Send to my pending workload: Check the box.

- Reason: Select Fact finding client .

- Bring forward date: Enter same date as the WI due date.

- Click Save .

- Go to step 11.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for the client to submit information.”

- Bring forward date: Enter the today’s date + 10 business days.

- When the WI moves to the current workload, determine if the required information has been received:

- If yes, go to step 12.

- If no, go to Imposing a 39 - Prevent payment of part II benefits and/or incorrect Part I benefits disentitlement (D39) .
               [Imposing a 39 - Prevent payment of part II benefits and/or incorrect Part I benefits disentitlement (D39)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_converting_eierb_ccb#Imposing_d39) 

#### Inputs

Source topic: `en_EN/task/covid19_converting_eierb_ccb/inputs_level_1.dita`

- Determine if the client qualifies for a new BP (refer to Calculating or recalculating a claim for CCB ). If the calculation results in a BPNE claim, the agent creates an interim ROE to allow 480 hours to the client and determines if the client now qualifies for a CCB claim.

- If yes, go to step 13.

- If no, the client continues to receive EI ERB or CERB and no action to establish a subsequent claim is required.

- In FTS, on the Payments tab, determine if the BPC of the new CCB claim overlaps with weeks that were already processed or paid:

- If no, go to step 14.

- If yes and weeks were processed but not paid, go to IPOC intervention required — Weeks of CCB were processed but not paid .
               [IPOC intervention required — Weeks of CCB were processed but not paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_converting_eierb_ccb#IPOC_intervention_required)

- If yes and weeks have been paid, go to IPOC intervention required — Weeks of CCB were processed and paid .
               [IPOC intervention required — Weeks of CCB were processed and paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/covid19_converting_eierb_ccb#IPOC_intervention_required_1)

- In SSA, register a new initial claim as follows:

- Select Claims Preparation .

- Under the Functions menu, select Registration—Normal .

- Press Enter .

- Social Insurance Number: Enter the client’s SIN.

- Claim selection: If this screen is displayed, ensure previous claims are in the Filing system stage.

- Select No and press Enter .

- Name and address: If the information is not prefilled, complete the following fields:
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2963.dita)

- Last job: Enter the correct National Occupation Classification code for the client’s last job title.
               [National Occupation Classification](https://noc.esdc.gc.ca/Home/Welcome/0f896f6aad7d48abb26c2ab4c33775d5?GoCTemplateCulture=en-CA)

- Enter the client’s personal information:

- DOB

- gender

- language

- name

- mailing address

- Economic region: The information is prefilled based on the client’s mailing address information. If the economic region is highlighted in red, enter the client’s city to manually choose the economic region from the list of options.

- Tax Province: The information is prefilled based on the client’s mailing address information.

- Tax Credit: Select the option provided by the client.

- Responsible HRCC: If the field is blank, enter the appropriate SCC based on the client’s address on the application.

- Application Form: Enter the client’s employment information:

- reason for separation (RFS)

- first day worked

- last day worked (LDW)

- variable best weeks (VBW)

- If provided, enter the postmark application date and the date the application was received. If not available, enter the date the client signed the application.

- When the Annexes menu opens, press ESC .

- Close the RCM screen that opens.

- When the Renewability/Registration screen opens, press Enter .

- Pay HRCC: Ensure that the SCC number is the same as shown in FTS. If the field is blank, enter the responsible HRCC code.

- Service Unit: Type “01.”

- Claim Source: Select AppliWeb (AW) .

- Decision Type: Select Initial .

- Flag: Select Regular .

- Tentative Benefit Period Commence: If this field is not prefilled, use the week after the last week of the EI ERB was paid.

- Do you want an Intake data screen?: Select Yes .

- Press Enter .

- When the M149 screen appears press 4.

- Determine if error code 230 appears:

- If yes, input a D in the TERM field on the M149 transaction screen in SSA. Go to step 16.

- If no, but a different error code appears, refer to WECS .
               [WECS](http://wecs-siew.prv/wecs-siew/lookup_e.aspx)

- If no error code appears, go to step 16.

- In NWS, reassign the CA WI to yourself.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2964.dita)

- Refer to Calculating or recalculating a claim for CCB to complete the calculation. Consider the information in steps 17 and 18 when calculating the claim.

- the date of a prior non-EI ERB claim;

- if the BPC is March 15, 2020 and June 28, 2020: the BPC of the new claim  – 68 weeks – any other QP extensions;

- if the BPC is between July 5, 2020 and August 23, 2020: the BPC of the new claim  – 76 weeks – any other QP extensions;

- if the BPC is on or after August 30, 2020: the BPC of the new claim – 80 weeks – any other QP extensions.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2965.dita)

- In SSA, calculate the claim as usual, except for the following input requirements:

- On the Coding Requirements screen, complete these fields as follows:

- Previously paid BPC: Enter the COD.

- On the Extension of the qualifying/benefit period screen input the extension under reason Employment measures .

- For the From date use the BPC – [# weeks of the QP extension].

- For the To date use the date BPC – 1.

- On the Determination of Earnings screen, input the WP waiver as follows:

- Waiting Period Waiver: Select Yes .

- On the Initial decision screen, amend the transaction to input the WLI code as follows:

- WLI: Enter 3 .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2966.dita)

- In NWS, complete the WI related to the new initial claim. 

#### IPOC intervention required — Weeks of CCB were processed but not paid

Source topic: `en_EN/task/covid19_converting_eierb_ccb/ipoc_intervention_required__weeks_of_cc_7e995f8d_level_1.dita`

- In FTS, on the File Control Data (M101) — Claim Action screen, do the following:

- Select Terminate benefit period (M101-7) .

- Click Update .

- In NWS, create an IPOC REV WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate language.

- Destination — SCC: Select the IPOC based on the region in which the claim is located in FTS:

- Atlantic: Select 1826 Moncton IPOC .

- Ontario: Select 3056 Belleville IPOC .

- Quebec: Select 2642 Montreal IPOC (3) .

- Western Canada and Territories: Select 5903 Vancouver IPOC .

- End User: Select Next available user .

- Issue: Select Payment history summary adjustment .

- BPC: Enter the BPC of claim to be cancelled.

- Comments: Type “Retroactive cancellation of a BP.”

- Details: Type “Benefits processed on BPC [BPC of the BP to terminate] should be processed on a new BP. Remove from the PHS w/c [w/c of the start date of CCB] to w/c [w/c of last week processed]. Advise the agent with a REM WI when complete.”

- Obtained by: Select Other .

- Obtained from: Select Other .

- Source details: Type “Processing agent.”

- Click Save .

- In NWS, determine if there is a WI:

- If yes, go to step 17.

- If no, go to step 19 when IPOC has sent the REM WI after the work is complete on the claim.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Request to remove CCB weeks from PHS. Claim sent to IPOC.”

- Bring forward date: Enter today's date + 2 business days.

- When the WI moves to the current workload, determine if IPOC has completed the requested action:

- If no, repeat step 17.

- If yes, go to step 19.

- In SSA, register a new initial claim as follows:

- Select Claims Preparation .

- Under the Functions menu, select Registration—Normal .

- Press the Enter key .

- Social Insurance Number: Enter the client’s SIN.

- Claim selection: If this screen is displayed, ensure previous claims are in the Filing system stage.

- Select No and press Enter .

- Name and address: If the information is not prefilled, complete the following fields:
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2967.dita)

- Last job: Enter the correct National Occupation Classification code for the client’s last job title.
               [National Occupation Classification](https://noc.esdc.gc.ca/Home/Welcome/0f896f6aad7d48abb26c2ab4c33775d5?GoCTemplateCulture=en-CA)

- Enter the client’s personal information:

- DOB

- gender

- language

- name

- mailing address

- Economic region: The information is prefilled based on the client’s mailing address information. If the economic region is highlighted in red, enter the client’s city to manually choose the economic region from the list of options.

- Tax Province: The information is prefilled based on the client’s mailing address information.

- Tax Credit: Select the option provided by the client.

- Responsible HRCC: If the field is blank, enter the appropriate HRCC based on the client’s address on the application.

- Application Form: Enter the client’s employment information:

- RFS

- first day worked

- LDW

- VBW

- If provided, enter the postmark application date and the date the application was received. If not available, enter the date the client signed the application.

- When the Annexes menu appears, press ESC .

- Close the RCM screen that opens.

- When the Renewability/Registration screen opens, press Enter .

- Pay HRCC: Ensure that the SCC number is the same as shown in FTS. If the field is blank, enter the responsible HRCC code.

- Service Unit: Type “01.”

- Claim Source: Select AppliWeb (AW) .

- Decision Type: Select Initial .

- Flag: Select Regular .

- Tentative Benefit Period Commence: If this field is not prefilled, use the week after the last week of the EI ERB was paid.

- Do you want an Intake data screen?: Select Yes .

- Press Enter .

- In NWS, reassign the newly created CA WI to yourself.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2968.dita)

- Determine the COD to enter manually in SSA for the calculation as the most recent of the following dates:

- the date of a prior non-EI ERB claim;

- if the BPC is March 15, 2020 and June 28, 2020: the BPC of the new claim  – 68 weeks – any other QP extensions;

- if the BPC is between July 5, 2020 and August 23, 2020: the BPC of the new claim  – 76 weeks – any other QP extensions;

- if the BPC is on or after August 30, 2020: the BPC of the new claim – 80 weeks – any other QP extensions.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2965.dita)

- In SSA, calculate the claim as usual, except for the following input requirements:

- On the Coding Requirements screen, complete these fields as follows:

- Previously paid BPC: Enter the COD.

- On the Extension of the qualifying/benefit period screen input the extension under reason Employment measures .

- For the From date use the BPC – [# weeks of the QP extension].

- For the To date use the date BPC – 1.

- On the Determination of Earnings screen, input the WP waiver as follows:

- Waiting Period Waiver: Select Yes .

- On the Initial decision screen, amend the transaction to input the WLI code as follows:

- WLI: Enter 3 .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2969.dita)

- In NWS, complete the WI related to the new initial claim. 

#### IPOC intervention required — Weeks of CCB were processed and paid

Source topic: `en_EN/task/covid19_converting_eierb_ccb/ipoc_intervention_required__weeks_of_cc_26dc95ac_level_1.dita`

- In FTS, determine if there is an outstanding recalculation registration number:

- If no, go to step 15.

- If yes, go to step 17.

- In SSA, starting from the main screen, assign a recalculation registration number as follows:

- Select Claims Preparation .

- Select Registration — Recalculation - Initial .

- Social Insurance Number: Type the SIN (do not press the Enter key).

- Press the ESC key when the Annexes menu appears.

- Close the RCM screen that appears.

- Press the Enter key when the Renewability/Registration screen appears.

- Pay HRCC: Type the Service Canada Centre (SCC) number as shown in the claim file in FTS. If the field is blank, enter the HRCC using one of the following codes:

- Atlantic: 1121

- Quebec: 2371

- Ontario: 3515

- Western: 4812

- Service Unit: Type “01.”

- Decision Type: Select Recalculation — Initial (should default to this choice).

- Flag: Select Recalculation (should default to this choice).

- Tentative Benefit Period Commence: The BPC is prefilled by SSA.

- Do you want an Intake data screen?: Select No .

- Press the Enter key.

- In NWS, reassign the newly created CR WI to yourself.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2970.dita)

- Determine the COD to enter manually in SSA for the calculation as the most recent of the following dates:

- the date of a prior non-EI ERB claim;

- if the BPC is March 15, 2020 and June 28, 2020: the BPC of the new claim  – 68 weeks – any other QP extensions;

- if the BPC is between July 5, 2020 and August 23, 2020: the BPC of the new claim  – 76 weeks – any other QP extensions;

- if the BPC is on or after August 30, 2020: the BPC of the new claim – 80 weeks – any other QP extensions.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2965.dita)

- In SSA, calculate the claim as usual, except for the following input requirements:

- On the Coding Requirements screen, complete these fields as follows:

- Subsequent or Manual BPC: Enter the date of the BPC for the CCB claim.

- Previously paid BPC: Enter the COD.

- On the Extension of the qualifying/benefit period screen input the extension under reason Employment measures .

- For the From date use the BPC – [# weeks of the QP extension].

- For the To date use the date BPC – 1.

- On the Determination of Earnings screen, input the WP waiver as follows:

- Waiting Period Waiver: Select Yes .

- Use the information obtained on the Subsequent decision screens to help complete the MM06 below.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2971.dita)

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Click Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 92 - Purge and Recreate .

- Work type: Select 20 - Benefit period commencement change .

- Remarks line 1: Type “Convert to CCB at BPC [XXXX].”

- Remarks line 2 to 4: Type “M106 BPC [XXXX], CT 12, INS HRS [XXXX], INS EARN [XXXXX], DIV WK [XX], COD [XXXX], ERN WK 1 [XXXX], LFA [XX], WP waived, WLI 3 NO-CR-CODE (if necessary). M112 Certificate number [XXXX], ADD, Start date [XXXX], ENT WEEK [XXXX].”

- Remarks line 5: Enter your name and telephone number.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select E - Non-fraud - Paid beyond termination .

- Message: Select 67 - O/P established / write-off - Change in insurable employment .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Click Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2972.dita)

- In FTS, select the Registration Number (M025, M030, M035) transaction and change the registration flag as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Click Update .

- In NWS, complete the WI. 

#### Imposing a 39 - Prevent payment of part II benefits and/or incorrect Part I benefits disentitlement (D39)

Source topic: `en_EN/task/covid19_converting_eierb_ccb/imposing_a_39_-_prevent_payment_of_part_baa26b4c_level_1.dita`

- In FTS, determine if a D39 is already imposed:

- If no, go to step 2.

- If yes, no further action is required.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 39 - Prevent payment of part II benefits and/or incorrect Part I benefits .

- Start date: Enter the Monday of the next claimant’s report to be received.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No if the claim is not contentious.

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In ACS, create and send the D-01-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Opening Sentence for Initial, Renewal or Continuing claims (2466) .

- Disentitlements (2976):

- Select D48 – D15 – Prescribed Manner (3006):

- Select D15 – Did not answer request for information . 

#### Note

Source topic: `en_EN/common_notes/note_c_2963.dita`

Note:

The information from the application in NWS is downloaded to SSA. In some rare cases, the information does not download and the agent must manually input it. The agent verifies (and corrects, if necessary) any prefilled fields with the information from the application. 

#### Note

Source topic: `en_EN/common_notes/note_c_2964.dita`

Note:

Refer to Calculating or recalculating a claim for CCB to complete the calculation. Consider the information in steps 17 and 18 when calculating the claim.
       [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml)

     [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2965.dita`

Note:

The above takes into account the extension given to these claims along with the normal 52-week QP. Refer to Reviewing for a possible qualifying period extension to determine if the client is entitled to other QP extensions.
       [Reviewing for a possible qualifying period extension](/en/procedure/task/calc_determining/review_qpe.shtml)

     [Reviewing for a possible qualifying period extension](/en/procedure/task/calc_determining/review_qpe.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2966.dita`

Note:

If the COD calculated in step 17 is less than the new BPC – 52 then no QP extension is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2967.dita`

Note:

The information from the application in NWS is downloaded to SSA. In some rare cases, the information does not download and the agent must manually input the information. The agent verifies (and corrects, if necessary) any prefilled fields with the information from the application. 

#### Note

Source topic: `en_EN/common_notes/note_c_2968.dita`

Note:

Refer to Calculating or recalculating a claim for CCB to complete the calculation. Consider the information in steps 21 and 22 when calculating the claim.
       [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml)

     [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2969.dita`

Note:

If the COD calculated in step 21 is less than the new BPC – 52 then no QP extension is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2970.dita`

Note:

To obtain the proper calculation information for the MM06 the agent will need to run a preliminary calculation in SSA. Refer to

     [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml) 

to complete the preliminary calculation. Consider the information in steps 17 and 18 when calculating the claim.

     [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2971.dita`

Note:

If the COD calculated in step 17 is less than the new BPC – 52 then no QP extension is required to obtain the preliminary calculation. 

#### Note

Source topic: `en_EN/common_notes/note_c_2972.dita`

Note:

If the client received the $2000 and the BPC is prior to the end date of the second D65, type “initial 2000$ payment requires amending” in the MM06. 

## Policy reference

Source topic: `en_EN/task/covid19_converting_eierb_ccb/policy_reference.dita`

 
