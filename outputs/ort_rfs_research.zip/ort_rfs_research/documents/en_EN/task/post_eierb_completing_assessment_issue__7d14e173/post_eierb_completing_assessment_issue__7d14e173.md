# Post-EI ERB: Completing an Assessment Issue ROE Comments WI — Regular ROE

Source map: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/post_eierb_completing_assessment_issue__7d14e173.ditamap`

## Summary

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/summary.dita`

Summary: ACP creates an Assessment Issue (ASMT) ROE Comments WI in the specialized ACP process when the comments on a regular ROE require review to determine if they impact claim calculation or entitlement.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4046.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4046.dita`

Note:

The ACP specialized process ends August 16, 2021. As of the end date, ACP will no longer create WIs based on specialized processing. Existing incomplete WIs created by the specialized process prior to August 16, 2021 will be completed using specialized procedures. 

## What you need to know

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4047.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4048.dita) 

ROE comments appear in block 18 for regular ROEs. The intended use of the Comments field is for the employer to clarify or provide additional information. 

### Comment types

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/comment_types.dita`

Comments generally fall into one of 3 categories:

- No impact: information that is not relevant to claim calculation or entitlement (e.g. a personal note to the employee such as “Best of luck in the future”)

- Repetitive information: information already indicated elsewhere (e.g. comments indicate “shortage of work” and block 16 displays A - Shortage of Work )

- Possible impact: information that is relevant to claim calculation or entitlement (e.g. additional details about moneys paid on separation or the reason for separation [RFS]) 

### Creating a WI

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/creating_a_wi.dita`

An artificial intelligence model attempts to address comments before the ROE enters the ACP wait process. During the ACP wait process, the system creates an ROE Comments WI for the last ROE only if the artificial intelligence model was unable to address the comments on the ROE. The system assigns ROE Comments WIs to Non-Complex agents.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2628.dita) 

### Impact on calculation

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/impact_on_calculation.dita`

Comments which could impact claim calculation or entitlement must be reviewed and changes must be made on the ROE in RCM. These comments are copied to the Additional information field in RCM before being removed from block 18 .

Comments which have no impact or contain repetitive information are removed from block 18 at the Non-Complex level. If the comments cannot be removed based on the procedure, the agent reassigns the ROE Comments WI to Level 1.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4044.dita) 

### ROE errors found during validation

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/roe_errors_found_during_validation.dita`

ROEs are automatically validated by the system. In some situations, this validation can be performed only when a change is made in RCM, such as deleting a comment. If an error is detected during validation, the agent corrects the ROE to allow automation. If the error cannot be corrected at the Non-complex level, the agent reassigns the ASMT ROE Comments WI to Level 1. 

### Note

Source topic: `en_EN/common_notes/note_c_4047.dita`

Note:

This task applies only to ASMT WIs that were created to address comments on an ROE in the specialized ACP process before its end date of August 16, 2021. For comments on an ROE in the normal ACP process, the agent refers to Completing an ROE Comments WI — Regular ROE .
       [Completing an ROE Comments WI — Regular ROE](/en/procedure/task/roe_comments_reg.shtml)

     [Completing an ROE Comments WI — Regular ROE](/en/procedure/task/roe_comments_reg.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4048.dita`

Note:

For an ASMT ROE Comments WI for a Government of Canada ROE that requires fact-finding, the agent refers to Updated: ROE issued by the Government of Canada — Procedures (Non-complex, Level 1 and Level 2) .
       [Updated: ROE issued by the Government of Canada — Procedures (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_roe_goc_procedures_ncl1l2.shtml)

     [Updated: ROE issued by the Government of Canada — Procedures (Non-complex, Level 1 and Level 2)](/en/site/dossier/updated_roe_goc_procedures_ncl1l2.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2628.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP no longer creates WIs based on specialized processing. However, the agent continues to complete outstanding WIs that were created by the specialized process before August 16, 2021 using specialized procedures. 

### Note

Source topic: `en_EN/common_notes/note_c_4044.dita`

Note:

Comments about the Coronavirus, COVID-19 or the client being in quarantine do not have an impact on calculation and should be actioned at the Non-complex level. 

## Regional considerations

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/in_nws.dita`

- Why was the WI reassigned to Level 1?

- Is there an ASMT ROE Correction WI for the same ROE? 

### In RCM:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/in_rcm.dita`

- Are there comments displayed in block 18 of the ROE?

- Which error messages are displayed when validating the ROE? 

## Step by step

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/non-complex.dita`

#### Reviewing the conditions to allow at Non-complex level

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/reviewing_the_conditions_to_allow_at_no_73969f75_non-complex.dita`

- Determine if the comments can be actioned or removed from block 18 according to ROE: Actions required for comments found in block 18 of a regular ROE — Instructions :

- If yes, take the required action and go to step 2.

- If no , go to Reassigning the WI to Level 1 .
               [Reassigning the WI to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__7d14e173#nc_item_4) 

#### Inputs

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/inputs_non-complex.dita`

- In RCM, select Validate and do the following:

- If errors are displayed for any block, go to step 3.

- If no error is found, select Submit and go to step 5.

- In NWS, determine if an outstanding ASMT ROE Correction WI exists for this ROE:

- If no , go to step 4.

- If yes, go to step 5. 

#### Correcting ROE errors

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/correcting_roe_errors_non-complex.dita`

- Determine if you can correct the ROE according to Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE :

- If yes, correct the ROE and go to step 5.

- If no , go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__7d14e173#nce_item_4)

- Complete the ASMT ROE Comments WI. 

#### Reassigning the issue to Level 1

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/reassigning_the_issue_to_level_1_non-complex.dita`

- In NWS, reassign the ASMT ROE Comments WI to Level 1 as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 1 .

- Reason: Select Unable to Complete .

- Details: Type the appropriate option:

- “According to the procedure, comments cannot be removed — Level 1 to review.”

- “Unable to correct ROE at Non-complex level.” 

### Level 1

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/reviewing_the_file_level_1.dita`

- In NWS, determine why the WI was reassigned to Level 1:

- If there are comments in block 18 to be reviewed, go to step 2.

- If another agent removed the comments but an ROE error requires correction, go to Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE.
               [Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE.](/en/procedure/task/post_eierb_completing_assessment_issue_roe_correction_wi_regular_roe.shtml) 

#### Reviewing the conditions to allow at Level 1

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/reviewing_the_conditions_to_allow_at_level_1_level_1.dita`

- Determine if the comments in block 18 can be actioned without clarification from the employer (e.g. pension information):

- If no , go to step 3.

- If yes, go to step 7. 

#### Fact-finding

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/fact-finding_level_1.dita`

- Fact-find with the employer by phone.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4049.dita)

- Determine if clarification has been obtained:

- If no , go to step 5.

- If yes, go to step 7. 

#### Required information has not been obtained

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/required_information_has_not_been_obtained_level_1.dita`

- In RCM, change the ROE as follows:

- Correct the ROE as necessary based on the comments in block 18 .

- Comments: Remove the text.

- Additional information: Copy the comments from block 18 and type “Changes made with information available on file, as unable to confirm with the employer.”

- In ACS, create and send the Z-02-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805): Select one of the following:

- Multiple Changes to ROE

- A Single Change to ROE

- List of the change

- Attached INS 3413

- Go to step 8. 

#### Required information has been obtained

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/required_information_has_been_obtained_level_1.dita`

- In RCM, change the ROE as follows:

- Correct the ROE based on the information obtained from either the fact-finding or the Comments field.

- Comments: Remove the text.

- Additional information: Copy the comments from block 18 and do the following:

- If the comments were removed from block 18 after clarification from the employer, type “Changes confirmed with [full name and position title]” and include details for any unchanged blocks confirmed by the employer.

- If the comments were removed from block 18 with no clarification from the employer, type “Changes made to blocks [X] in accordance with the EI ORT.”

- In RCM, select Validate and do the following:

- If errors are displayed for any block, go to step 9.

- If no errors are displayed, select Submit and go to step 10.

- Correct the ROE to fix the validation error, and go to step 10. For information on how to correct an ROE, refer to Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE .

- In NWS, complete the ASMT ROE Comments WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4049.dita`

Note:

If the employer cannot be reached on the first attempt, leave a message. If unable to leave a message on the first attempt or if the employer does not call back within 24 hours, make one more attempt by phone but do not leave a message on the second attempt. Document the attempts in a draft SROC per usual procedures.

If the employer provides details specific to the RFS, create an SROC to document the information . Document all other changes in RCM. 

## Policy reference

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__7d14e173/policy_reference.dita`

 
