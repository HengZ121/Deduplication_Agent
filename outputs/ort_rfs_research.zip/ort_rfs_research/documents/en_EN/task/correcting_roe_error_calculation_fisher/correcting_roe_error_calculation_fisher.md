# Correcting an error during calculation or recalculation — Fishing ROE

Source map: `en_EN/task/correcting_roe_error_calculation_fisher/correcting_roe_error_calculation_fisher.ditamap`

## Summary

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/summary.dita`

Summary: ROE errors prevent calculation of a claim until they are corrected. When fraud indicators are present and the file is not already under investigation, the officer refers the file to Integrity. 

## What you need to know

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2917.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Impact of ROE errors

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/impact_of_roe_errors.dita`

An ROE that is in error and that is required for calculation prevents assessment of the claim in SSO. When there is an ROE error, the calculating officer must search for related ROE WIs and review the work that has been completed. If an ROE Correction WI has been created for the error, and assigned to a Non-complex officer, the calculating officer may have to move the WI to Pending while the Non-complex officer completes the ROE Correction WI. 

### Data entry errors on an ROE

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/data_entry_errors_on_an_roe.dita`

Procedures related to the data entry of an ROE or the review of ROE comments sometimes create an error on the ROE (e.g. a change was made to the original ROE but was not initialled by the employer). When this occurs, the discrepancy is indicated in the Additional information field of the ROE. These procedures prevent automatic calculation of the claim until the information can be reviewed. 

### Identifying ROE errors

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/identifying_roe_errors.dita`

In RCM, ROE error messages are displayed in red by the blocks in error. When an ROE is corrected, the changes require validation to determine if errors are still present or if new ones have occurred. Only when no error messages remain is the ROE considered successfully corrected and available for use in the claim assessment.

**Duplicate ROEs**

If the ROE displays an error message that states a serial number has already been entered for another SIN, the officer refers to Correcting an ROE flagged as a duplicate ROE with a different SIN .
       [Correcting an ROE flagged as a duplicate ROE with a different SIN](/en/procedure/task/duplicate_correcting_roe.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0077.dita) 

**ROEs with a serial number status problem**

If the ROE displays an error message that states a problem with the status of the serial number was detected, the officer refers to Correcting an ROE flagged with a serial number problem .
       [Correcting an ROE flagged with a serial number problem](/en/procedure/task/lms_correcting_roe.shtml) 

### Fraudulent web ROEs

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/fraudulent_web_roes.dita`

Fraudulent ROEs have been issued through ROE Web, or the potential exists for future fraudulent ROEs to be issued. There are also reasons to suspect that some of the business numbers (BNs) associated with these suspicious ROEs may be fraudulent.

When Integrity identifies a fraudulent BN, an Integrity officer deletes the associated Web ROEs in RCM if they were not used to calculate a claim. The Integrity officer enters the following note in the Additional information section of the ROE:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1569.dita) 

When correcting an ROE deleted by Integrity, the officer suspends the application process, if necessary, and completes the ROE Correction WI if the WI status has not been changed to Deleted in NWS. 

### Fraudulent paper ROEs

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/fraudulent_paper_roes.dita`

Fraudulent paper ROEs were created without the knowledge of the true SIN-holder and the employer associated with the Canada Revenue Agency (CRA) BN indicated in block 5 of the ROE. There are also instances where there are reasons to suspect that the business identified on the ROE is illegitimate or suspicious and was created to issue fraudulent ROEs. These fraudulent ROEs were sent to Service Canada and scanned as documents in support of fraudulent EI applications, or uploaded in AW or MSCA.

A close examination may reveal a difference in the font and size of the characters in the serial number of these ROEs when compared to the normal format. In some cases, RCM validates the serial number and does not signal the ROE as a duplicate, because that serial number was used to establish an EI claim more than 11 years ago. In other situations, the serial number has been issued within the last 11 years to a different BN than the one used on the fraudulent ROE, however, RCM validates the serial number but does not flag it as a duplicate because the ROE was never used to establish a claim.

When correcting an ROE, officers may suspect that an ROE is fraudulent even if no error message is displayed about the status of the serial number. Officers actioning ROE Correction WIs do not fact-find with the employer. Officers delete the ROE in RCM, suspend the application process and refer the file to Integrity, if the file is not already under investigation.

For more information, officers refer to Fraud indicators: Identifying potentially fraudulent claims — Knowledge.
       [Fraud indicators: Identifying potentially fraudulent claims — Knowledge.](/en/procedure/generic/additionalresources/fraud_indicator.shtml) 

### Fraud indicators

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/fraud_indicators.dita`

Before taking any actions, officers determine if the application is already under investigation for potential fraud. Officers can determine that there is an ongoing Integrity investigation for this application if:

- a 71 - Integrity Services case manual action (MA71) or 71 - Integrity Services case disentitlement (D71) is imposed;

- an SROC created by Integrity is on file;

- an Action Item (AI) WI is assigned to Integrity;

- a Call Back (CB) WI is assigned to Integrity.

If none of these are on the file, officers review the file to determine if fraud indicators are present. If yes, officers:

- determine if the banking information has been changed in FTS and, if so, terminate the direct deposit;

- impose a D71 on skeleton and BPNE 1, 2 or 7 claims or an MA71 on established claims, if necessary;

- complete the registration number to suspend the initial application process to prevent the claim from establishing until an investigation is completed;

- refer the issue to Integrity for investigation;

- complete the Claim Set-Up (CS) WI.

If the only fraud indicator is the fraud warning highlighted in red in FTS, the officers do not refer the issue to Integrity.

For more information, officers refer to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Correcting ROE errors

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/correcting_roe_errors.dita`

Guides are available to help employers correctly complete an ROE. When errors are present and the officer must contact the employer, the officer may also use these guides to teach the employer how to correctly complete an ROE.

If the officer is unable to obtain the required information from the employer to correct the ROE, the following steps are taken:

- The corrections are estimated and the missing information is obtained from other sources (e.g. the client) in order to correct the ROE.

- A letter is sent to the client stating that the ROE is unverified and will be reviewed later.

- The file is referred to Integrity for employer non-compliance. 

### Note

Source topic: `en_EN/common_notes/note_c_2917.dita`

Note:

This task only applies to the correction of an ROE error when calculating a claim in the normal ACP process. To correct an ROE error in the specialized ACP process, refer to Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Fishing ROE .
       [Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Fishing ROE](/en/procedure/task/Post_eierb_completing_assessment_issue_roe_correction_wi_fishing_roe.shtml)

     [Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Fishing ROE](/en/procedure/task/Post_eierb_completing_assessment_issue_roe_correction_wi_fishing_roe.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_0077.dita`

Note:

Although there is a function to override this error in RCM, this function must only be used following an Integrity investigation when it is determined that the ROE is valid and is required to calculate a claim. 

### Callout

Source topic: `en_EN/common_notes/note_c_1569.dita`

“Suspicious ROE. ROE has been deleted to prevent it from being used in benefits calculation until an investigation is completed. It can be restored if its legitimacy is confirmed.” 

## Regional considerations

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/in_nws.dita`

- What is the last day worked declared on the application?

- Are there any documents (e.g. SROC, other WIs) containing the information necessary to correct the ROE? 

### In RCM:

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/in_rcm.dita`

- Which error messages are displayed when attempting to validate the ROE?

- Is there information in the Comments or Additional information field of the ROE? 

### In Imaging:

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/in_imaging.dita`

- Are there any documents that may provide the information necessary to correct the ROE? 

### In the Employer database:

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/in_the_employer_database.dita`

- Is there any information about this employer?

- Is there any information about the ROE error in question? 

## Step by step

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/level_1.dita`

#### Reviewing the file for fraud indicators

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/reviewing_the_file_for_fraud_indicators_level_1.dita`

- In NWS, determine if there is documentation indicating that the file is under investigation for potential fraud:

- If no, go to step 2.

- If yes, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/correcting_roe_error_calculation_fisher#level1_item_5)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1527.dita)

- Review the application and ROEs to determine if known fraud indicators are present and if fraud is suspected. Refer to Fraud indicators: Identifying potentially fraudulent claims — Knowledge :

- If yes, go to step 3.

- If no, go to step 4.

- In FTS, determine if the banking information has been changed to the banking information on the potentially fraudulent application:

- If no, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/correcting_roe_error_calculation_fisher#level1_item_5)

- If yes, terminate the banking information by referring to Ending a direct deposit and go to Fraud indicators are present .
               [Ending a direct deposit](/en/procedure/task/ending_dd.shtml) 
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/correcting_roe_error_calculation_fisher#level1_item_5) 

#### Reviewing the file

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/reviewing_the_file_level_1.dita`

- In NWS, review the related WIs and determine if there is an ROE Correction WI for the ROE in error:

- If yes, go to step 5.

- If no , go to step 7.

- Determine if the ROE Correction WI is assigned:

- If the ROE Correction WI is not assigned, assign it to yourself and go to step 7.

- If the ROE Correction WI is assigned, determine if the application is older than 26 days:

- If yes, go to step 6.

- If no , move the Claim Assessment (CA) or the Specialized Application (SA) WI to Pending as follows:

- Pending reason: Select ROE .

- Comments: Type “awaiting ROE correction.”

- Bring forward date: Enter the date of application + 26 days.

- Determine if the ROE Correction WI is completed:

- If the ROE Correction WI is completed, in RCM, determine if the related ROE is still in error:

- If yes, go to step 7.

- If no , return to Calculating or recalculating a claim for fishing benefits .
                   [Calculating or recalculating a claim for fishing benefits](/en/procedure/activity/calc_fish.shtml)

- If the ROE Correction WI is not completed, determine if the WI is in the assigned agent’s pending workload:

- If yes, reassign the WI to yourself and go to step 7.

- If no , contact your team leader to request the WI be reassigned to you before proceeding. 

#### Reviewing the ROE

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/reviewing_the_roe_level_1.dita`

- In RCM, determine if an error states the serial number has already been entered for another SIN:

- If yes, go to Correcting an ROE flagged as a duplicate ROE with a different SIN .
               [Correcting an ROE flagged as a duplicate ROE with a different SIN](/en/procedure/task/duplicate_correcting_roe.shtml)

- If no, go to step 8.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0077.dita)

- In RCM, determine if an error states a problem with the status of the serial number was detected:

- If yes, go to Correcting an ROE flagged with a serial number problem .
               [Correcting an ROE flagged with a serial number problem](/en/procedure/task/lms_correcting_roe.shtml)

- If no, go to step 9. 

#### Correcting the ROE

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/correcting_the_roe_level_1.dita`

- Determine which blocks of the ROE are in error and consult ROE: RCM validation error correction for a fishing ROE — Instructions and ROE: RCM validation error correction for a fishing ROE (employer not reached) — Instructions to determine how to correct the ROE:

- If the corrections can be made with the information on file, go to step 10.

- If the corrections cannot be made with the information on file, go to step 11.

- In RCM, correct the errors and do the following:

- Additional information: Type “Changes made to blocks [#s] in accordance with the EI Online Reference Tool (ORT).”

- Select Validate:

- If an error message is displayed and the tables do not indicate to check the Override-able errors box next to the error, repeat step 9 to determine how to correct the error.

- If error messages are displayed and the tables indicate to check the Override-able errors box next to each error message, check the applicable boxes and select Submit . Go to step 22.

- If no error message is displayed, select Submit and go to step 21. 

#### Fact-finding

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/fact-finding_level_1.dita`

- In NWS and ACS, determine if any attempts have been made to contact the employer:

- If no , go to step 12.

- If yes, go to step 13.

- Fact-find with the person who issued the ROE to obtain the missing information:

- If the employer was not reached, go to step 13.

- If the employer was reached, go to step 21.

- In ACS, determine if letters were already sent to this employer for the current ROE:

- If no letters were sent to this employer, go to step 14.

- If a first Z-02-00-00 letter has been sent, determine if 10 working days have passed since the letter was sent:

- If no , go to step 15.

- If yes, go to step 16.

- If a second Z-02-00-00 letter has been sent, determine if 10 working days have passed since it was sent:

- If no , go to step 18.

- If yes, go to step 20.

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Request for a Record of Employment (2797)

- Request for Additional ROE Information:

- Text - Free Text (1612): Enter the following information: issue you are inquiring about, your telephone number and work hours (in the employer’s time zone, if necessary) and the date which the information is required.

- Blank / Contact agent / Contact by phone or mail (11326): Select the appropriate option.

- In NWS, move the ROE Correction WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Z-02-00-00 letter sent.”

- Bring forward date: Enter the day the letter is sent + 10 working days.

- When the bring-forward date is reached, determine if the information was obtained:

- If no , go to step 17.

- If yes, go to 22.

- In ACS, send a registered copy of the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Request for a Record of Employment (2797)

- Follow-up Request for ROE Additional Information

- Date contacted employer ( 1556)

- Enclosing a copy of letter (2800)

- Date of BF (5140): Enter the date the letter is sent + 10 working days.

- Blank / Contact agent / Contact by phone or mail (11326)

- Attachment List for Z-02-00-00 letter (3133):

- Copy of original letter.

- Indicate on letter how letter mailed (2804) .

- Select Sent by Registered mail.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1564.dita)

- In NWS, move the ROE Correction WI Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Z-02-00-00 letter sent.”

- Bring forward date: 10 working days from the day the letter is sent.

- When the bring-forward date is reached, determine if the information has been obtained:

- If no , go to step 20.

- If yes, go to step 21.

- In RCM, determine which blocks of the ROE are in error and consult ROE: RCM validation error correction for a fishing ROE — Instructions and ROE: RCM validation error correction for a fishing ROE (employer not reached) — Instructions to determine how to correct the ROE:

- If the corrections can be made with the information on file, go to step 21.

- If the corrections cannot be made with the information on file, go to Actioning the ROE error when there is employer non-compliance .
               [Actioning the ROE error when there is employer non-compliance](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/correcting_roe_error_calculation_fisher#_Actioning_the_ROE) 

#### Updating the ROE after fact-finding

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/updating_the_roe_after_fact-finding_level_1.dita`

- In RCM, correct the ROE and do the following:

- Additional information: Type “changes to Block # confirmed with [client or employer (include the name of the person contacted)]”.

- Select Validate:

- If an error message is displayed and the tables do not indicate to check the Override-able errors box next to the error, repeat step 20 to determine how to correct the error.

- If error messages are displayed and the tables indicate to check the Override-able errors box next to each error message, check the applicable boxes select Submit . Go to step 22.

- If no error message is displayed, select Submit and go to step 22.

- If there is a related ROE Correction WI, complete it.

- Return to Calculating or recalculating a claim for fishing benefits . 

#### Actioning the ROE error when there is employer non-compliance

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/actioning_the_roe_error_when_there_is_e_81c81f75_level_1.dita`

- In NWS, create an SROC and complete the following:

- Issue: Select ROE .

- Comments: Type “potential employer non-compliance [employer’s name].”

- Details: Type “Employer did not respond to Z-02-00-00 letter by response required date of [DD-MM-YYYY]. Second letter sent by registered mail on [DD-MM-YYYY] with a response required date of [DD-MM-YYYY].”

- Fact-find with the client to obtain the missing information:

- If the information was obtained, go to step 3.

- If the information was not obtained, go to step 5.

- In RCM, correct the ROE and do the following:

- Determine if corrections were made by contacting the client:

- If no , in the Additional information field, type “changes made to block [#s] with information available on file, as unable to confirm with the employer.”

- If yes, in the Additional information field, type “changes to block [#s] confirmed with client as unable to confirm with the employer.”

- Select Validate:

- If an error message is displayed and the tables do not indicate to check the Override-able errors box next to the error, repeat step 2 to determine how to correct the error.

- If error messages are displayed and the tables indicate to check the Override-able errors box next to each error displayed, check the applicable boxes and select Submit . Go to step 4.

- If no error message is displayed, select Submit and go to step 4.

- In ACS, send a copy of the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805)

- Multiple Changes to ROE

- A Single Change to ROE

- List of the change

- Attached INS 3413
                       [INS 3413](http://forms-formulaires.prv/lc/apps/EForms/pdf/en/ESDC-INS3413.pdf)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1564.dita)

- In NWS, refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 1 .

- Destination — Level: At level 4 - National Integrity (ISB) , select the Integrity unit in the region where the client lives:

- Atlantic: Integrity - ATL

- Quebec: Integrity - QC / I - A - Regional Operations - QC / I - Distribution Centre - QC

- Ontario: Integrity - ON

- Western: Integrity - WT / I - A - Regional Operations - WT / I - Distribution Centre - WT

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Integrity .

- Comments: Type “Employer non-compliance”.

- Details: Type the employer’s name, address, telephone number, CRA business number, ROE number, the information required and the attempts already made to obtain it.

- If there is a related ROE Correction WI, complete the WI.

- Return to Calculating or recalculating a claim for fishing benefits . 

#### Fraud indicators are present

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/fraud_indicators_are_present_level_1.dita`

- In NWS, determine if any of the following WIs are on file:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2661.dita) 

- If no, go to step 2.

- If yes, go to step 19.

- Determine if any of the following are on file and directly related to the potentially fraudulent application:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1573.dita) 

- If no, go to step 3.

- If yes, go to step 6.

- In NWS, determine if a suspected fraud has previously been referred to Integrity in an AI WI that has not been completed:

- If yes, go to step 4.

- If no, go to step 5.

- Add the information related to the potentially fraudulent application to the existing Integrity AI WI as follows:

- Right-click and select Add details/Further inquiry .

- Action: Select Additional Information .

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the processing unit in the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue(s): Select ROE .

- Comments: Type “Fraud suspected — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- In FTS, determine if the initial claim has already been calculated:

- If yes, go to step 7.

- If no, go to step 10.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If yes, go to step 8.

- If no, go to step 16.

- Determine if an MA71 has already been imposed:

- If no, go to step 9.

- If yes, go to step 16.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 16.

- Determine if there is an outstanding initial registration number related to the fraudulent application:

- If yes, go to step 11.

- If no, go to step 16.

- Determine if a D71 has already been imposed:

- If no, go to step 12.

- If yes, go to step 13.

           [Important](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2918.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

- Go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2664.dita)

- In NWS, determine if the Claim Status action is Finalized - Pending LREM :

- If yes, go to step 14.

- If no, go to step 15.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- Go to step 16.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1576.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the initial registration number as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 16.

- Determine if the ROE to be corrected is potentially fraudulent:

- If yes, go to step 17.

- If no, go to step 19.

- In RCM, determine if the ROE has been deleted:

- If no, go to step 18.

- If yes, go to step 19.

- In RCM, open the ROE and delete it as follows:

- Delete: Check the box.

- Additional information : Type “Suspicious ROE. ROE has been deleted to prevent it from being used in benefits calculation until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- Go to step 19.

- In NWS, determine if there is a related ROE Correction WI:

- If yes, go to step 20.

- If no, no further action is required.

- Determine if the status of the ROE Correction WI is Assigned-Active :

- If yes, complete the WI.

- If no, no further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_1527.dita`

Note:

If the only fraud indicator is the fraud warning highlighted in red in FTS, go to step 2. 

#### Note

Source topic: `en_EN/common_notes/note_c_1564.dita`

Note:

When sending a copy of an original letter, print the letter locally. For instructions on printing locally while teleworking, refer to Telework: Printing documents locally — Instructions .
       [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml)

     [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml) 

#### Callout

Source topic: `en_EN/common_notes/note_c_2661.dita`

- a Claim Review (CR) Integrity ERB-EI Transition WI related to the potentially fraudulent application;

- an AI WI from Integrity indicating that the claim can be established;

- a CB WI about the potentially fraudulent application. 

#### Callout

Source topic: `en_EN/common_notes/note_c_1573.dita`

- an Integrity AI WI;

- an Integrity SROC;

- a D71 or an MA71;

- in RMDS, on the Employer profile screen, the Under investigation box is checked. 

#### Important

Source topic: `en_EN/common_notes/note_c_2918.dita`

Important:

Before imposing a D71, confirm that the file does not already include one. In such cases, if a transaction is input to impose a D71, the existing D71 is cancelled. 

#### Note

Source topic: `en_EN/common_notes/note_c_2664.dita`

Note:

If error code C072: Invalid Claim action or Action field (C072) is displayed when inputting the Renewal/Revised (M106) transaction, the D71 cannot be imposed. Go to step 13. 

#### Note

Source topic: `en_EN/common_notes/note_c_1576.dita`

Note:

If error code 836: WARNING - Flag 33 claim (Last Record of Employment Missing), claim is still polling for the last record of employment is displayed when attempting to clear the registration number, check the Override box to process the transaction. 

## Policy reference

Source topic: `en_EN/task/correcting_roe_error_calculation_fisher/policy_reference.dita`

- How to complete a self-employed Fishers ROE (employer’s guide)
         [How to complete a self-employed Fishers ROE (employer’s guide)](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/roe-guide.html) 
