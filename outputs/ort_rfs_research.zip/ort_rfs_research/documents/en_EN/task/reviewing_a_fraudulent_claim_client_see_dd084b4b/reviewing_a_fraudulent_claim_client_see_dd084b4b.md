# Reviewing a fraudulent renewal when no payment has been issued

Source map: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/reviewing_a_fraudulent_claim_client_see_dd084b4b.ditamap`

## Summary

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/summary.dita`

Summary: Integrity investigators create a Claim Review (CR) Integrity - ERB-EI Transition WI to inform the officer of the result of an investigation when a client’s personal information has been used to fraudulently renew a claim for EI benefits. When a call centre officer validates the client’s identity but cannot action the fraudulent claim, the call centre officer creates an Action Item (AI) WI for Level 1 or Integrity, depending on the situation. 

## What you need to know

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4581.dita) 

### Fraudulent renewals

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/fraudulent_renewals.dita`

On March 15, 2020, the Government of Canada introduced the EI Emergency Response Benefit (EI ERB) to provide temporary income support to workers impacted by the COVID-19 pandemic. In the weeks that followed, it was discovered that the personal information of many Canadians was used to fraudulently establish EI ERB claims or EI claims.

Fraudulent activity in EI applications is discovered in several different ways, including the following:

- The client receives a T4E without having applied for benefits and contacts the call centre.

- A returned payment raises suspicion about a bank account.

- A client’s claim is transferred to another information technology centre (ITC) and the client can no longer complete claimant’s reports.

- A client files a new application and an officer discovers fraud indicators on a previous application while processing the claim.
         [fraud indicators](/en/procedure/generic/additionalresources/fraud_indicator.shtml)

- A client files a new application and a renewal is completed instead of a new claim because there is an existing fraudulent BPC.

- A client has an existing claim and a third party renews the client’s claim. The renewal results in the client’s banking information being changed to a bank account not owned by the client.

- A third party modifies the client’s banking information. The client or third party completes claimant’s reports, which results in misdirected payments.

- A fraudulent ROE was issued in a fraudulent EI application submitted by a third party. 

### Levels of decision

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/levels_of_decision.dita`

The Level 1 officer can review a fraudulent renewal claim in the following situations :

- The Level 1 officer receives an AI WI and all of the following conditions are met:

- no payment has been issued to the client or third party on the fraudulent claim (this includes any payment that was issued and later updated to Cancelled or Returned in SPS) ;

- the third party is unknown;

- no potentially fraudulent ROE were used to calculate the client’s claim for the same BPC.

- The Level 1 officer receives a CR Integrity ERB-EI Transition WI and all of the following conditions are met:

- no payment was issued to the third party on the fraudulent claim (this includes any payment that was issued and later updated to Cancelled or Returned in SPS) ;

- the third party is unknown

- no other contentious issues requiring a Level 2 decision were reported in the investigation or in another investigation for the same BPC.

- The Level 1 officer receives an AI WI and a CR Integrity ERB-EI Transition WI and all of the following conditions are met:

- no payment was issued to the third party on the fraudulent claim(this includes any payment that was issued and later updated to Cancelled or Returned in SPS) ;

- the third party is unknown;

- no other contentious issues requiring a Level 2 decision were reported in the investigation or in another investigation for the same BPC.

When the conditions above are not met, the Level 1 officer does the following:

- If there is only an AI WI, the Level 1 officer reassigns it to Integrity.

- If there is only a CR Integrity - ERB-EI Transition WI, the Level 1 officer reassigns it to Level 2.

- If there is an AI WI and a CR Integrity - ERB-EI Transition WI, the Level 1 officer completes the AI WI and reassigns the CR WI to Level 2. 

### Responsibilities of the call centre officer

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/responsibilities_of_the_call_centre_officer.dita`

When a client contacts the call centre and the file is under review by Integrity (i.e. contains an MA71), the call centre officer validates the client’s identity and verifies the fraud indicators to determine if the MA71 can be rescinded.

An SROC is added to the file to confirm that the client’s identity could be validated.

When the client’s identity cannot be validated, the call centre officer refers the file to Integrity.

When the client’s identity can be validated, but measures cannot be taken by the call centre officer based on the procedure, the call centre officer creates a Level 1 AI WI for processing. 

### Responsibilities of the Level 1 processing officer

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/responsibilities_of_the_level_1_process_048e8bde.dita`

When a third party has used a client’s personal information to renew a claim after a client either returned to work or stopped completing claimant’s reports, the processing officer inputs the required transactions to correct the file.

The Level 1 officer may receive an AI WI created by the call centre  after validating the client’s identity, or a CR Integrity - ERB-EI Transition WI, which was created after the Integrity investigation was completed . The officer assigned the AI WI reviews the claim to determine if payments were issued on the fraudulent renewal application or if potentially fraudulent ROEs were used to calculate the client’s claim that was established for the same BPC. If yes, the officer reassigns the AI WI to Integrity. If there is a CR Integrity ERB-EI Transition at Level 2, the officer marks the Level 2 CR Integrity - ERB-EI Transition WI as urgent and completes the AI WI without taking any action.

The officer assigned a Level 1 CR Integrity - ERB-EI Transition WI reviews the claim to determine if payments were issued on the fraudulent renewal application or if a contentious issue requires a Level 2 decision. If yes, the officer reassigns the CR Integrity - ERB-EI Transition WI to Level 2.

If the officer is assigned to the AI WI and there is a related Level 1 CR Integrity - ERB-EI Transition WI in the current workload, the officer reassigns the WI to their own workload. If the officer cannot complete the Level 1 CR Integrity - ERB-EI Transition WI because it was incorrectly identified that the case contains no overpayment (OP), or if a contentious issue requires a Level 2 decision, the Level 1 officer marks the CR Integrity - ERB-EI Transition WI as urgent , reassigns the CR Integrity - ERB-EI Transition WI to Level 2 and completes the AI WI without taking any action.

In NIIS, Integrity identifies the serial number of the ROEs that do not belong to the client. The Level 1 officer processing the CR Integrity ERB-EI Transition WI deletes the fraudulent ROEs in RCM, if necessary, and determines if the fraudulent ROEs were used to calculate the client’s initial claim. If yes, the Level 1 officer processing the CR Integrity ERB-EI Transition WI recalculates the claim by following the instructions in the Step by Step section.

The address and banking information provided by the third party must be updated to the client’s information, even if the client is not requesting benefits. In FTS, ensure that the address and banking information are updated and that the client’s name, language and gender are correct. If there is a fraudulent claim in another ITC, update the client’s information in both ITCs.

When processing a Level 1 CR Integrity - ERB-EI Transition WI, it is possible that some transactions related to the fraudulent application may have already been enteredinput into the file. The officer should still continue with the procedure to ensure that all required actions have been taken.

The officer takes the necessary action to ensure that the information saved in our systems is the client’s and that accurate payments are issued.

The officer completing a CR Integrity - ERB-EI Transition WI must ensure all the required information related to the case is in NIIS. If information is missing, the case must be returned to Integrity in NIIS. Once the officer has completed all the required claim updates, the officer closes the NIIS case and completes the CR Integrity - ERB-EI Transition WI. 

### Responsibilities of the Level 2 processing officer

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/responsibilities_of_the_level_2_process_255e3410.dita`

The Level 2 officer could receive CR Integrity - ERB-EI Transition WIs from Integrity for a previous referral when no payments have been issued to the third party on the fraudulent renewal application and if there are no contentious issues requiring a Level 2 decision. When this occurs, the Level 2 officer reassigns the CR Integrity - ERB-EI Transition WI to Level 1.

When no payments have been issued to the third party on the fraudulent renewal application and there are contentious issues requiring a Level 2 decision, the Level 2 officer processes the CR Integrity - ERB-EI Transition WI, since Level 1 officers do not adjudicate contentious issues requiring a Level 2 decision. In NIIS, Integrity identifies the serial number of the ROEs that do not belong to the client. The Level 2 officer processing the CR Integrity ERB-EI Transition WI deletes the fraudulent ROEs in RCM, if necessary, and determines if the fraudulent ROEs were used to calculate the client’s initial claim. If yes, the Level 2 officer processing the CR Integrity ERB-EI Transition WI creates an AI WI for Level 1 to request a recalculation of the claim.

The address and banking information provided by the third party must be updated to the client’s information, even if the client is not requesting benefits. In FTS, ensure that the address and banking information are updated and that the client’s name, language and gender are correct. If there is a fraudulent claim in another ITC, update the client’s information in both ITCs.

When processing a Level 2 CR Integrity - ERB-EI Transition WI, it is possible that some transactions related to the fraudulent application may have already been enteredinput into the file. The officer should still continue with the procedure to ensure that all required actions have been taken.

When a disqualification has been imposed, the level 2 officer creates and sends the D01-00-00 letter in ACS. 

### Responsibilities of the IPOC officer

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/responsibilities_of_the_ipoc_officer.dita`

The IPOC officer usually inputs all adjustments related to fraudulent claims, such as:

- voiding the established fraudulent claim;

- removing all weeks paid to the third party from the client’s file;

- removing fraudulent cycling claimant’s reports on blocked or archived claims if the client is not eligible for some or all of these weeks and the client is requesting benefits;

- issuing payments to the client on a blocked or archived claim;

- adjusting the client’s tax file for payments issued in the current tax or amending the T4E for payments issued in a previous tax year;

- deleting the pay history, if necessary.

For the current task, since no payments were issued, IPOC intervention is only required when:

- the client is requesting benefits on a claim that is blocked, archived or converted to MPS.

- the client is requesting benefits on a claim that is active or terminated that can be reactivated for a renewal week that is before the one on file and there are cycling claimant’s reports that the third party completed after the renewal week.

If the client is not requesting benefits after the renewal week on a claim that is blocked, archived or converted to MPS, regardless of whether there are cycling claimant’s reports that the third party completed after the renewal week, the processing officer does not send an MM06 to IPOC. The officer creates a record of decision (ROD) and requests that an authorized user delete the fraudulent EI application in NWS. No further action is required. 

### Responsibilities of the third party

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/responsibilities_of_the_third_party.dita`

When a third party fraudulently receives EI payments, the third party is responsible for the resulting OP. Integrity follows up to establish the OP on the third party’s file and refers the case to the Royal Canadian Mounted Police, if necessary.

For the current task, since no payments were issued, the officer takes no further action related to the third party’s OP. 

### Cycling claimant’s reports

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/cycling_claimants_reports.dita`

In many cases, there are cycling claimant’s reports that were completed by the third party. Different actions are required depending on the claim status (CS) and the period for which the client is requesting benefits.

If the claim is blocked, archived or converted to MPS and the client is requesting benefits, IPOC intervention is required.

If the claim is active or terminated but can be reactivated, claimant’s reports are cycling and the client is requesting benefits for a period before the renewal week showing in FTS, IPOC intervention is required.

If the claim is active or is terminated but can be reactivated, claimant’s reports are cycling and the client is requesting benefits for a period after the renewal week showing in FTS, the officer does the following:

- On day one, the officer inputs a return to work (RTW) the Monday of the first week of the cycling claimant’s report on the claim and rescinds the MA71.

- On day 2, the system has rejected claimant’s reports after the renewal week. The officer inputs the correct renewal week and any other required transaction, including claimant’s reports, if necessary.

If the claim is active or is terminated but can be reactivated, claimant’s reports are cycling and the client is requesting benefits for the renewal week in FTS, but is not entitled to some or all of those weeks , the officer does the following:

- On day one, the officer inputs an RTW the Monday on the first cycling claimant’s report in which the client is not entitled to the full amount to be issued and rescinds the MA71.

- On day 2, the system has rejected claimant’s reports after the RTW week. The officer rescinds the RTW, amends the claimant’s report for the RTW week to include any pay coding and inputs any other required transaction, including claimant’s reports, if necessary.

The officer inputs an RTW the Monday of the renewal week and rescinds the MA71 if all the following conditions are met:

- The claim is active or terminated but can be reactivated.

- There are cycling claimant’s reports completed by the third party after the renewal week.

- The client is not requesting benefits after the renewal week. 

### Defining claim status (CS)

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/defining_claim_status_cs.dita`

A claim can be active, terminated, blocked or archived. The CS impacts which transactions can be input:

Active:

The active claim is established and is currently displayed automatically in FTS. It is a claim for which benefits are still payable and that has not been terminated.

Terminated:

A terminated claim appears on the Dormant tab in FTS. It has ended but can be reactivated. Once the transaction to reactivate the claim has been processed, all inputs for the claim must be done the same as for an active claim.

Blocked:

In some cases, the claim that the officer must reconsider is on the Dormant tab in FTS, but there is a new active claim established and displayed on the Summary tab. For this task, adjustments to blocked claims require IPOC intervention.

Archived:

A claim that is no longer on the Summary tab or the Dormant tab in FTS is an archived claim. The claim is displayed on the Pay History (under Enquiry ). The summary displays previous BPCs. When the BPC is selected, weeks paid and benefit types (BTs) paid are displayed. Adjustments to archived claims require IPOC intervention. 

### Returning the file to Integrity

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/returning_the_file_to_integrity.dita`

The Level 1 or Level 2 officer processing a CR Integrity - ERB-EI Transition WI consults NIIS for each case to find all the relevant information to review the issue. After conducting a full review of the investigation, if the officer determines that facts are missing, the officer returns the file to Integrity for further fact-finding. The officer indicates the information that is missing but necessary to adjudicate the issue. The officer does not adjudicate the issue if facts are missing or incomplete.

Missing or incomplete information could include:

- the client’s current address information;

- the client’s current banking information;

- whether the client is requesting benefits or not;

- the renewal week, if the client is requesting benefits;

- the claimant’s report information, if the client is requesting benefits;

- whether payments have been issued to the client or the third party.

- fraudulent ROEs to be deleted or that have been deleted from the client’s file.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1707.dita) 

The officer ensures that the investigator has also included information about any related contentious issues, if necessary.

For more information on navigating NIIS, the officer refers to the National Integrity Investigation System (NIIS) User Reference Guide .
       [National Integrity Investigation System (NIIS) User Reference Guide](https://014gc.sharepoint.com/sites/NIIS-SNEI/NIIS%20Documentation/NIIS%20EI%20Reference%20Guide%2020210406-V01-English.pdf) 

### Note

Source topic: `en_EN/common_notes/note_c_4581.dita`

Note:

This task is only for officers trained to process AI WI or CR Integrity - ERB-EI Transition WI when a renewal claim has been compromised. The claim is considered compromised when the client’s information (i.e. address or direct deposit information( has been changed of when the third party has completed claimant’s reports. 

### Note

Source topic: `en_EN/common_notes/note_c_1707.dita`

Note:

If an investigator has updated the client’s address and banking information in FTS, the officer does not return the file to Integrity for this information. 

## Regional considerations

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/regional_considerations.dita`

**Quebec — Returning the file to Integrity**

In addition to the information already indicated in this procedure, Level 1 and Level 2 officers return the file to Integrity as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address qc-dgsi-isb-retour@servicecanada.gc.ca as a carbon copy.
             [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca)

- In NWS, create a client Note and type “Measure — returned to Integrity — [DD-MM-YYYY].”

**Quebec — Removing an application in NWS**

The Business Expertise Advisor, and not the team leader, deletes the application in NWS. As indicated in the Step by step section, officers in the Quebec region use the National Business Expertise Tool (NEXO) to send the request and have the application deleted. A WI is not created in NWS. 

## What you need to look for

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/what_you_need_to_look_for.dita`

### In NIIS:

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/in_niis.dita`

- On the IC08 Case Summary screen, what actions have been taken on the case?

- On the IC50 Report of Clerical Investigation or IC70 Report of Investigation screen, is there:

- an Integrity Investigation Sheet?

- a Report of Interview?

- Has all the information required to make a decision been provided? 

### In Imaging:

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/in_imaging.dita`

- Are there any documents that are relevant to the case? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/in_integrity_investigations_document_up_6a8da64b.dita`

- Are there any documents that are relevant to the case? 

### In SPS:

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/in_sps.dita`

- Have any payments been returned or cancelled?

- Have any payments been made to a third party?

- Have any payments been made to the client by mistake?

- What is the status of the payments made on the claim? 

### In NWS:

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/in_nws.dita`

- Is there any information relevant to the case on SROCs, RODs, AI, IPOC Review (IPOC REV) and Call Back (CB) WIs?

- Are there any related WIs on file?

- What is the CS in the Client information tree ?

- Is there an SROC or WI indicating that undeliverable mail has been received? 

### In FTS:

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/in_fts.dita`

- Is the client’s banking information correct?

- Is the client’s name and address correct?

- Is the language indicated correct?

- Is the gender indicated correct?

- Does the phone number need to be modified or added?

- Is an MA71 imposed?

- Are there claimant’s reports that need to be input?

- Are there cycling claimant’s reports?

- Has a renewal week been input?

- What is the CS (active, terminated, blocked, archived or converted to MPS)? 

### In RCM:

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/in_rcm.dita`

- Are there fraudulent ROEs to delete or that have been deleted from the client’s file? 

### In ACS:

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/in_acs.dita`

- Did Integrity send a request for information to the client? 

## Step by step

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/reviewing_the_file_level_1.dita`

- In NWS, determine if there is a Level 2 CR Integrity - ERB-EI Transition WI that has not been completed:

- If no, go to step 2.

- If yes, do the following, depending on the situation:

- If processing a Level 1 AI WI is required, complete it as follows:

- Details: Type “No action taken as Level 2 CR Integrity - ERB-EI Transition WI is not complete.”

- In the Level 2 CR Integrity - ERB-EI Transition WI, check the Urgent box.

- No further action is required.

- If processing a Level 1 CR Integrity - ERB-EI Transition WI is required and the Level 2 CR Integrity - ERB-EI Transition WI is already assigned to another officer, reassign the Level 1 CR Integrity - ERB-EI Transition WI to that officer as follows:

- Destination: Select Specific user:

- Enter the officer’s last name and first name.

- Find User: Select the appropriate name.

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type: “Reassigned to be actioned with the other WI.”

- No further action is required.

- If processing a Level 1 CR Integrity - ERB-EI Transition WI is required and the Level 2 CR Integrity - ERB-EI Transition WI is not assigned, go to Reassigning the WI to level 2 .
                   [Reassigning the WI to level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_8)

- In NWS, determine the type of WI:

- If it is a Level 1 CR Integrity - ERB-EI Transition WI, go to step 3.

- If it is a Level 1 AI WI, go to step 4.

- In NIIS, determine if the information gathered by Integrity is complete:

- If yes, go to step 4.

- If no, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_9)

- In FTS, determine if payments were issued to a third party on the fraudulent renewal claim:

- If no, go to step 5.

- If yes and processing the Level 1 CR Integrity - ERB-EI Transition WI is required, go to Reassigning the WI to level 2 .
               [Reassigning the WI to level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_8)

- If yes and processing the Level 1 CR Integrity - ERB-EI Transition WI and the AI WI is required, complete the AI WI indicating that the CR WI has been sent to Level 2, mark the CR Integrity - ERB-EI Transition WI as urgent and go to Reassigning the WI to level 2 .
               [Reassigning the WI to level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_8)

- If yes and processing a Level 1 AI WI is required, go to Reassigning the AI WI to Integrity .
               [Reassigning the AI WI to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_9)

- Determine if a decision on a contentious issue is required at Level 2:

- If yes and processing the Level 1 CR Integrity - ERB-EI Transition WI is required, go to Reassigning the WI to level 2 .
               [Reassigning the WI to level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_8)

- If yes and processing the Level 1 CR Integrity - ERB-EI Transition WI and the AI WI is required, complete the AI WI indicating that the CR has been sent to Level 2, mark the CR Integrity - ERB-EI Transition WI as urgent and go to Reassigning the WI to level 2 .
               [Reassigning the WI to level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_8)

- If yes and processing the Level 1 AI WI is required, go to Reassigning the AI WI to Integrity .
               [Reassigning the AI WI to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_9)

- If no, go to step 6.

- Determine if any potentially fraudulent ROEs were used to calculate one of the client’s established claims:

- If yes and:

- processing the Level 1 AI WI is required and the calculated BPC is the same as the AI WI, go to Reassigning the AI WI to Integrity .
                   [Reassigning the AI WI to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_9)

- processing the Level 1 AI WI is required and the calculated BPC is not the same as the AI WI, go to step 7.

- processing the Level 1 CR Integrity - ERB-EI Transition WI is required, go to step 7.

- processing the Level 1 CR Integrity - ERB-EI Transition WI and the AI WI is required, go to step 7.

- If no, go to step 7.

- Determine if the address is the client’s address:

- If yes, go to step 8.

- If no, update the address and go to step 8.
               [update the address](/en/procedure/activity/change_address.shtml)

- Determine if there is an SROC or an AI WI on file indicating that undeliverable mail has been received:

- If yes, re-send any letters that should have been sent to the client and whose information still applies. For more information, refer to Re-sending undeliverable mail . Go to step 9.
               [Re-sending undeliverable mail](/en/procedure/task/rescending_un_mail.shtml)

- If no, go to step 9.

- Determine if the banking information is correct:

- If yes, go to step 10.

- If no, update the banking information and go to step 10.
               [update the banking information](/en/procedure/activity/direct_deposit.shtml)

- Determine if the client is requesting benefits:

- If yes, go to step 11.

- If no and the claim is active or terminated but can be reactivated, go to Actioning the fraudulent renewal on an active claim — Client is not requesting benefits .
               [Actioning the fraudulent renewal on an active claim — Client is not requesting benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_5)

- If no and the claim is blocked, archived or converted to MPS, go to Actioning a fraudulent renewal on a claim that is blocked, archived or converted to MPS — Client is not requesting benefits .
               [Actioning a fraudulent renewal on a claim that is blocked, archived or converted to MPS — Client is not requesting benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_4)

- In FTS, determine if the claim is active, terminated, blocked, archived or converted to MPS:

- If the claim is terminated but can be reactivated, select the appropriate BPC on the Dormant tab and select Reactivate . Go to step 12.

- If the claim is active, go to step 13.

- If the claim is blocked, archived or converted to MPS, go to Actioning a fraudulent renewal on a claim that is blocked, archived or converted to MPS — Client is requesting benefits .
               [Actioning a fraudulent renewal on a claim that is blocked, archived or converted to MPS — Client is requesting benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_3)

- In NWS, move the AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Reactivation of BPC [XXXX].”

- Bring forward date: Enter today’s date + one business day.

- When the WI moves to the current workload, go to step 13.

- Determine the renewal week. Refer to Determining the effective date of a renewal or a conversion and Conversion and renewal , if necessary. Go to step 14.

- In FTS, determine if a renewal week related to the fraudulent application has been input:

- If yes, go to step 15.

- If no, go to step 22.

- Determine if the renewal week that is on file is the renewal week requested by the client:

- If yes, go to step 16.

- If no, go to step 20.

- Determine if there are cycling claimant’s reports completed by a third party:

- If no, go to step 17.

- If yes, go to step 19.

- Determine if there are cycling claimant’s reports completed by the client:

- If no, go to step 18.

- If yes, go to step 28

- Determine if a completed Claimant’s report: Original without pay coding — Checklist or Claimant’s report: Original with pay coding — Checklist is included for the renewal period:

- If yes, complete the claimant’s reports and go to step 28.

- If no and processing a Level 1 AI WI is required, fact-find with the client to obtain claimant’s reports, input the claimant’s reports and go to step 28.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If no and processing the Level 1 CR Integrity - ERB-EI Transition WI is required, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_9)

- Review the cycling claimant’s reports to determine the period for which the client is requesting benefits:

- If the client is requesting the same weeks as the cycling claimant’s reports and:

- has declarations (earnings, not available days, FWW, etc.) that will affect entitlement for the requested weeks, go to step 22.

- is entitled to those weeks, go to step 29.

- there are additional weeks, input the additional claimant’s reports and go to step 29.

- If the client is requesting and is entitled to only some of the same weeks as the cycling claimant’s reports (i.e. w/cs 2300–2305 are cycling and client is only requesting and entitled to w/cs 2304–2305), go to step 22.

- If the client is requesting completely different weeks from the cycling claimant’s reports, go to step 22.

- Determine if cycling claimant’s reports were completed after the renewal week:

- If yes, go to step 21.

- If no, go to step 23.

- Determine which of the following situations applies to the client:

- If the client’s renewal week is after the renewal week displayed in FTS, go to step 22.

- If the client’s renewal week is before the renewal week displayed in FTS and cycling claimant’s reports must be amended, go to step 22.

- If the client’s renewal week is before the renewal week displayed in FTS and cycling claimant’s reports must not be amended, go to step 27.

- Select the Additional Data (M107) transaction and input the RTW week as follows:

- Return to work: Select the Monday of the first cycling claimant’s report the client is not entitled to the full amount to be issued.

- Select Update .

- Review the client’s application and ROEs in RCM to determine if any allocation is required:

- If no, go to step 24.

- If yes, refer to Earnings (Activity) and complete the required inputs. Go to step 24.
               [Earnings (Activity)](/en/procedure/activity/earnings.shtml)

- Determine if there is an MA71 to stop payments:

- If yes, go to step 25.

- If no, go to step 26.

- In NWS, determine which of the following situations applies to the client:

- If an MA71 must be rescinded and a renewal week must be entered, go to step 26.

- If an RTW has been input, an MA71 must be rescinded and a renewal week must be entered, go to step 28.

- If an RTW has been input, an MA71 must be rescinded and claimant’s reports must be updated, go to step 29.

- If only an MA71 must be rescinded, go to step 29.

- If only a renewal week must be entered, go to step 34.

- In FTS, if there is no renewal registration number related to the client’s application, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- Select the Renewal/Revised (M106) transaction to rescind the MA71, if there is one on file, and input the renewal week as follows:

- Registration number: Select the renewal registration number.

- Renewal: Select the Sunday of the effective renewal week.

- Earnings week 1: Enter the amount, if necessary.

- Manual action: Select 71 - Integrity Services case .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, or if there is a 2 - Contentious renewal in automation manual action (MA02) on file, select D - No .

- Select Update .

- Go to step 39.

- Select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- Go to step 31.

- Do the following:

- If there is no outstanding registration number and there is a Level 1 AI WI related to the fraudulent renewal, go to step 30.

- If there is an outstanding registration number and there is a Level 1 AI WI related to the fraudulent renewal, go to step 31.

- If there is an Integrity registration number related to a CR Integrity - ERB-EI Transition WI, go to step 31.

- Select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and rescind the MA71 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select 71 - Integrity Services case .

- Rescind: Check the box

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, or if there is an MA02 on file (on a renewal registration number), select D - No .

- Detection: Select the appropriate option:

- If there is an Integrity registration number, this field is prefilled according to the type of investigation in NIIS.

- If there is a revised registration number, leave the field blank.

- Infraction: Select the appropriate option:

- If there is an Integrity registration number, select F - Non-fraud - Other .

- If there is a revised registration number, leave the field blank.

- Message: Select the appropriate option:

- If there is an Integrity registration number, select 27 - An overpayment resulted due to an incorrect calculation .

- If there is a revised registration number, leave the field blank.

- Select Update .

- If an RTW has been input and a new renewal week must be entered, go to step 32.

- If an RTW has been input and claimant’s reports must be updated, go to step 32.

- If there are cycling claimant’s reports and the client is entitled to those weeks, go to step 39.

- If claimant’s reports have been updated, go to step 40.

- If there are cycling claimant’s reports, the client is entitled to those weeks and a new renewal week must be entered before the current renewal week, go to Inputting a renewal week with an Operational Centre Memo (MM06) transaction .
               [Inputting a renewal week with an Operational Centre Memo (MM06) transaction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_2)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type: “Waiting for RTW to be processed.”

- Bring forward date: Enter today’s date + one business day.

- Select Save .

- When the WI moves to the current workload, determine which of the following situations applies to the client:

- If an RTW has been input and a new renewal week must be entered after the current renewal week, go to step 35.

- If an RTW has been input and a new renewal week must be entered before the current renewal week, go to step 36.

- If an RTW must be rescinded and claimant’s reports must be updated, go to step 36.

- Select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and input the renewal week as follows:

- Registration number: Select the renewal registration number.

- Renewal: Select the Sunday of the effective renewal week.

- Earnings week 1: Enter the amount, if necessary.

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, or if there is an MA02 on file, select D - No .

- Select Update .

- Go to step 39.

- Select the Additional Data (M107) transaction and rescind the RTW week as follows:

- Return to work: Select the RTW week present on the claim.

- Rescind: Check the box.

- Select Update .

- Amend the last claimant’s report processed by referring to Modifying a claimant’s report . Go to step 38.

- Input the outstanding claimant’s reports by referring to Inputting a claimant’s report .

- If a new renewal week must be entered before the current renewal week, go to Inputting a renewal week with an Operational Centre Memo (MM06) transaction .
               [Inputting a renewal week with an Operational Centre Memo (MM06) transaction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_2)

- If the renewal week is the renewal week requested by the client, go to step 40.

- Input the claimant’s reports, if necessary, and go to step 41.

- Review the file (RCM, SROC in NWS, RMDS Employer profile screen , NIIS) and determine if it contains fraudulent ROEs:

- If no, go to step 41.

- If yes, go to Reviewing fraudulent ROEs .
               [Reviewing fraudulent ROEs](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_6)

- In NWS, determine the type of WI assigned:

- If it is a Level 1 AI WI, go to step 42.

- If it is a Level 1 CR Integrity - ERB-EI Transition WI, go to step 46.

- If it is a Level 1 CR Integrity - ERB-EI Transition WI and a Level 1 AI WI, go to step 46.

- In NWS, create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “Client’s identity validated — fraudulent renewal.”

- Details: Type “The client’s identity, address and banking information were validated on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “Fraudulent claim — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a Reminder (REM) WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NWS, complete the AI WI and all other related WIs. No further action is required.

- Create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information ].” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen, close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Client’s information has been corrected as required.”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In FTS, determine if the Integrity registration number has been completed:

- If no, go to step 51.

- If yes, go to step 52.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the Level 1 CR Integrity - ERB-EI Transition WI and all other related WIs. 

#### Inputting a renewal week with an Operational Centre Memo (MM06) transaction

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/inputting_a_renewal_week_with_an_operat_7005f8f0_level_1.dita`

- Review the file (RCM, SROC in NWS, RMDS Employer profile screen , NIIS) and determine if it contains fraudulent ROEs:

- If yes, go to step 2.

- If no, go to step 23.

- In RCM, determine if the fraudulent ROEs have been deleted:

- If no, go to step 3.

- If yes, go to step 4.

- In RCM, open each ROE identified as fraudulent by Integrity and delete them as follows:

- Delete: Check the box.

- Additional information: Select the appropriate option:

- If it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 5.

- If it is a Level 1 AI WI that is being processed, type “Suspicious ROE. ROE has been deleted until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- Go to step 5.

- Determine if the following text appears in the Additional information section of the deleted ROE: “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- If yes, go to step 5.

- If no and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, do the following:

- Additional information : Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 5.

- If no and it is a Level 1 AI WI that is being processed, go to step 5.

- Determine if there are any fraudulent ROEs in the QP of one of the client’s established claim:

- If yes, go to step 6.

- If no, go to step 23.

- Determine if any fraudulent ROEs were used to calculate one of the client’s established claim:

- If no, go to step 7.

- If yes, go to step 8.

- Determine if there is an outstanding CR Recalculation WI for the fraudulent ROE:

- If yes, go to step 13.

- If no, go to step 23.

- Determine if there is an outstanding CR Recalculation WI for the same BPC as the claim calculated with a fraudulent ROE:

- If no and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, go to step 9.

- If yes and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, go to step 13.

- If it is a Level 1 AI WI that is being processed, go to step 23.

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 11.

- If no, go to step 12.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank , enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: This field is prefilled.

- Select Generate registration .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1570.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1571.dita)

- In NWS, determine the status of the outstanding CR Recalculation WI:

- If it is assigned to another officer, go to step 14.

- If it is unassigned, go to step 15.

- If it is assigned to you, go to step 16.

- Determine in which workload the outstanding CR Recalculation WI is:

- If it is in the pending workload, go to step 15.

- If it is in the current workload, contact the officer and ask to reassign the WI to yourself. Go to step 16.

- In NWS, open the CR Recalculation WI and reassign it to yourself as follows:

- Destination: Select Myself .

- Reason: Select Other .

- Details: Type “Related WI.”

- Select OK .

- In FTS, determine the BPC:

- If the BPC is w/c 2258 or after, go to step 17.

- If the BPC is between w/c 2230 and w/c 2257 and it is a claim for special benefits other than sickness benefits, go to step 17.

- If the BPC is between w/c 2230 and w/c 2257 and it is an EI ERB claim, the EI ERB claim must not be recalculated to change the rate or number of weeks of entitlement. Select the Renewal/Revised (M106) transaction and complete the recalculation registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 23.

- Refer to Recalculation and follow the appropriate task to recalculate the claim. Go to step 18.

- Determine if the recalculation has changed the BPC, hours or insurable earnings, which will result in an OP to the client due to a deleted fraudulent ROE:

- If yes, go to step 19.

- If no, go to step 23.

- Determine if, as a result of the recalculation, an established claim became BPNE due to a deleted fraudulent ROE:

- If no, go to step 20.

- If yes, go to step 21.

- In ACS, create and send the N-03-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Various Reasons - Claim was recalculated (2683): Select Reviewed calculation of claim .

- Various results due to recalculation or revision (2684)

- Allocation of Earnings (2516)

- Allocation of Bankruptcy payments (2573)

- Change to family supplement rate - No longer entitled (2685)

- Change in BPC or LRW – Reports need to be completed (2686)

- Teachers: Benefit rate during non-teaching period (2689)

- Insurability Ruling - Benefits are being suspended (2690): Select Blank .

- Underpayment / overpayment message (2691): Select Overpayment Message .

- Do not report monies already declared (2456)

- Waiting Period Message (2444)

- Right to Request a Reconsideration (with Blank option) (4169)

- This Letter Replaces or Footnote (2365): Do the following:

- Select Footnote .

- Text - Footnote (11745): Type: “Your claim was initially calculated using a record of employment (ROE) that does not belong to you.”

- Go to step 23.

- Determine if the claim became BPNE due to a deleted fraudulent ROE and if there is a violation for that BPC on the Violation History (ML02) screen in FTS:

- If no, go to step 22.

- If yes, include that information in the MM06 to remove that BPC from the list of BPCs that are affected by the violation. Go to step 22.

- In ACS, create and send the B-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Types of BPNE Decisions (3197)

- BPNE - Regular / Special Benefits (2615)

- Number of insurable employment hours accumulated (1366)

- Start date of Regular qualifying period - Sunday’s date (1418)

- End date of Regular qualifying period - Saturday’s date (1420)

- Number of insurable employment hours required (1362)

- Start date of Regular qualifying period - Sunday’s date (1418)

- End date of Regular qualifying period - Saturday’s date (1420)

- End date of Regular qualifying period - Saturday’s date (1420)

- Overpayment Messages (2452): Select the appropriate option:

- If the client has an active claim, select Overpayment – No misrepresentation and active claim .

- If the client does not have an active claim, select Overpayment – No misrepresentation and inactive claim .

- This letter Replaces or Footnote (2365): Do the following:

- Select Footnote .

- Text - Footnote (11745): Type: “We have reviewed the calculation of your claim. Your claim was initially calculated using a record of employment that does not belong to you.”

- Go to step 23.

- In NWS, determine if a completed Claimant’s report: Original without pay coding — Checklist or Claimant’s report: Original with pay coding — Checklist is included for the antedate period:

- If no and processing a Level 1 AI WI is required, fact-find with the client to obtain claimant’s reports. Go to step 24.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If no and processing a Level 1 CR Integrity - ERB-EI Transition WI is required, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_9)

- If yes, go to step 27.

- Determine if claimant’s report information was obtained:

- If no, go to step 25.

- If yes, go to step 27.

- Create a ROD as follows:

- BPC: Enter the BPC.

- Comments: Type “Unable to obtain claimant’s reports — antedate renewal not input.”

- Details: Type “Claimant’s reports are required to input the antedated renewal week. Unable to contact the client for claimant’s reports, so the antedate cannot be input at this time.”

- If there is an outstanding WI for the antedate request, complete it. Go to step 31.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select the appropriate option.

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 92 - Purge and Recreate .

- Work type: Select 26 - Processing of a report blocked by a renewal week .

- Remarks line 1: Type “Antedate renewal from w/c [XXXX] to [XXXX].”

- Remarks lines 2 – 4: Enter the claimant’s report details and any allocation information.

- Remarks line 5: Enter your first name and last name.

- Detection: Select 23 - Recalculation - postdating or antedating .

- Infraction: Select C - Non-fraud - Insurability - new information .

- Message: Select 38 - An overpayment resulted due to a change in the start of your claim .

- Contentious: Select the appropriate option.

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 04 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, determine the type of WI:

- If it is a Level 1 AI WI, go to step 31.

- If it is a Level 1 CR Integrity - ERB-EI Transition WI, go to step 35.

- Create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “Client’s identity validated — fraudulent renewal.”

- Details: Type “The client’s identity, address and banking information were validated on: [DD-MM-YYYY]. The client’s address is: [client’s address] and the client’s banking information is: [client’s banking information].” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “Fraudulent claim — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details : Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NWS, complete the AI WI and all other related WIs. No further action is required.

- In NWS, create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, also type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen, close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “ Client’s information has been corrected as required .”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In FTS, determine if a renewal registration number should be completed:

- If yes, go to step 40.

- If no, go to step 41.

- Select the Renewal/Revised (M106) transaction and complete the renewal registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1- No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the Level 1 CR Integrity - ERB-EI Transition WI and all other related WIs. 

#### Actioning a fraudulent renewal on a claim that is blocked, archived or converted to MPS — Client is requesting benefits

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/actioning_a_fraudulent_renewal_on_a_cla_fb0c57cf_level_1.dita`

- Review the file (RCM, SROC in NWS, RMDS Employer profile screen , NIIS) and determine if it contains fraudulent ROEs:

- If yes, go to step 2.

- If no, go to step 26.

- In RCM, determine if the fraudulent ROEs have been deleted:

- If no, go to step 3.

- If yes, go to step 4.

- In RCM, open each ROE identified as fraudulent by Integrity and delete them as follows:

- Delete: Check the box.

- Additional information: Select the appropriate option:

- If it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 5.

- If it is a Level 1 AI WI that is being processed, type “Suspicious ROE. ROE has been deleted until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- Go to step 5.

- Determine if the following text appears in the Additional information section of the deleted ROE: “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- If yes, go to step 5.

- If no and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, do the following:

- Additional information: Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 5.

- If no and it is a Level 1 AI WI that is being processed, go to step 5.

- Determine if there are any fraudulent ROEs in the QP of one of the client’s established claim:

- If yes, go to step 6.

- If no, go to step 26.

- Determine if any fraudulent ROEs were used to calculate one of the client’s established claim:

- If no, go to step 7.

- If yes, go to step 8.

- Determine if there is an outstanding CR Recalculation WI for the fraudulent ROE:

- If yes, go to step 10.

- If no, go to step 26.

- Determine if there is an outstanding CR Recalculation WI for the same BPC as the claim calculated with a fraudulent ROE:

- If no and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, go to step 9.

- If yes and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, go to step 13.

- If it is a Level 1 AI WI that is being processed, go to step 31.

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 11.

- If no, go to step 12.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank , enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: This field is prefilled.

- Select Generate registration .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1570.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1571.dita)

- In NWS, determine the status of the outstanding CR Recalculation WI:

- If it is assigned to another officer, go to step 14.

- If it is unassigned, go to step 15.

- If it is assigned to you, go to step 16.

- Determine in which workload the outstanding CR Recalculation WI is:

- If it is in the pending workload, go to step 15.

- If it is in the current workload, contact the officer and ask to reassign the WI to yourself. Go to step 16.

- In NWS, open the CR Recalculation WI and reassign it to yourself as follows:

- Destination: Select Myself .

- Reason: Select Other .

- Details: Type “Related WI.”

- Select OK .

- In FTS, determine the BPC:

- If the BPC is w/c 2258 or after, go to step 17.

- If the BPC is between w/c 2230 and w/c 2257 and it is a claim for special benefits other than sickness benefits, go to step 17.

- If the BPC is between w/c 2230 and w/c 2257 and it is an EI ERB claim, the EI ERB claim must not be recalculated to change the rate or number of weeks of entitlement. Select the Renewal/Revised (M106) transaction and complete the recalculation registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 26.

- Refer to Recalculation and follow the appropriate task to recalculate the claim. Go to step 18.

- Determine if the claim became BPNE due to a deleted fraudulent ROE and if there is a violation for that BPC on the Violation History (ML02) screen in FTS:

- If no, go to step 19.

- If yes, include that information in the MM06 to remove that BPC from the list of BPCs that are affected by the violation. Go to step 19.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the recalculation registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4466.dita)

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 54 - Third party fraud .

- Remarks line 1: Type “Recalculation — fraudulent ROE used in claim calculation.”

- Remarks lines 2–4: Type “INS HRS [insurable hours], INS EARNINGS [insurable earnings], DIV WK [divisor], COD [cut-off date]. OP belongs to the client.” If necessary, enter the information regarding the claimant’s report and any other relevant information.

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 04 - Insurance Payment Operational Centre .

- Select Update .

- Determine if the recalculation has changed the BPC, hours or insurable earnings, which will result in an OP to the client due to a deleted fraudulent ROE:

- If yes, go to step 23.

- If no, go to step 26.

- Determine if, as a result of the recalculation, an established claim became BPNE due to a deleted fraudulent ROE:

- If no, go to step 24.

- If yes, go to step 25.

- In ACS, create and send the N-03-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Various Reasons - Claim was recalculated (2683): Select Reviewed calculation of claim .

- Various results due to recalculation or revision (2684)

- Allocation of Earnings (2516)

- Allocation of Bankruptcy payments (2573)

- Change to family supplement rate - No longer entitled (2685)

- Change in BPC or LRW – Reports need to be completed (2686)

- Teachers: Benefit rate during non-teaching period (2689)

- Insurability Ruling - Benefits are being suspended (2690): Select Blank .

- Underpayment / overpayment message (2691): Select Overpayment Message .

- Do not report monies already declared (2456)

- Waiting Period Message (2444)

- Right to Request a Reconsideration (with Blank option) (4169)

- This Letter Replaces or Footnote (2365): Do the following:

- Select Footnote .

- Text - Footnote (11745): Type: “Your claim was initially calculated using a record of employment that does not belong to you.”

- Go to step 26.

- In ACS, create and send the B-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Types of BPNE Decisions (3197)

- BPNE – Regular / Special Benefits (2615)

- Number of insurable employment hours accumulated (1366)

- Start date of Regular qualifying period - Sunday’s date (1418)

- End date of Regular qualifying period - Saturday’s date (1420)

- Number of insurable employment hours required (1362)

- Start date of Regular qualifying period - Sunday’s date (1418)

- End date of Regular qualifying period - Saturday’s date (1420)

- End date of Regular qualifying period - Saturday’s date (1420)

- Overpayment Messages (2452): Select the appropriate option:

- If the client has an active claim, select Overpayment – No misrepresentation and active claim .

- If the client does not have an active claim, select Overpayment – No misrepresentation and inactive claim .

- This letter Replaces or Footnote (2365): Do the following:

- Select Footnote .

- Text - Footnote (11745): Type: “We have reviewed the calculation of your claim. Your claim was initially calculated using a record of employment that does not belong to you.”

- Go to step 26.

- Determine if a registration number related to the same issue is outstanding:

- If no, go to step 27.

- If yes, go to step 28.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Detection: Select the appropriate option:

- If there is an Integrity registration number, this field is prefilled according to the type of investigation in NIIS.

- If there is a revised registration number, select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4466.dita)

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 54 - Third party fraud .

- Remarks: Select the appropriate option:

- If the renewal week that is on file is the renewal week requested by the client and no cycling claimant’s reports were completed by a third party:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “Issue w/c [w/cs to which the client is entitled], CT [XX].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].” If an MA was imposed to stop payments, type “Rescind MA[XX].

- If the renewal week that is on file is the renewal week requested by the client, there are cycling claimant’s reports that were completed by a third party and the client is entitled to those weeks, do the following:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “Issue w/c [w/cs to which the client is entitled], CT [XX].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If an MA was imposed to stop payments, type “Rescind MA[XX].”

- If the renewal week that is on file is the renewal week requested by the client, there are cycling claimant’s reports that were completed by a third party and the client is entitled to some of those weeks:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “Remove cycling claimant’s reports w/c [XXXX] to [XXXX]. Issue w/c [w/cs to which the client is entitled], CT [XX].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].” If an MA was imposed to stop payments, type “Rescind MA[XX].

- If the renewal week on file is different from the renewal week requested by the client and there are cycling claimant’s reports that were completed by a third party:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “Remove cycling claimant’s reports w/c [XXXX] to [XXXX]. Input renewal w/c [XXXX], CT [XX]. Issue w/c [w/cs to which the client is entitled].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].” If an MA was imposed to stop payments, type “Rescind MA[XX].”

- If the renewal week on file is different from the renewal week requested by the client and no cycling claimant’s reports were completed by a third party:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “Input renewal w/c [XXXX], CT [XX]. Issue w/c [w/cs to which the client is entitled].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].” If an MA was imposed to stop payments, type “Rescind MA[XX].”

- If the renewal week has not been input:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “Input renewal w/c [XXXX], CT [XX]. Issue w/c [w/cs to which the client is entitled].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].” If an MA was imposed to stop payments, type “Rescind MA[XX].”

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 04 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, determine the type of WI:

- If it is a Level 1 AI WI, go to step 32.

- If it is a Level 1 CR Integrity - ERB-EI Transition WI, go to step 36.

- In NWS, create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “Client’s identity validated — fraudulent renewal.”

- Details: Type “The client’s identity, address and banking information were validated on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “Fraudulent claim — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NWS, complete the AI WI and all other related WIs. No further action is required.

- Create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, also type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen, close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Client’s information has been corrected as required.”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In FTS, determine if the Integrity registration number has been completed:

- If no, go to step 41.

- If yes, go to step 42.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the Level 1 CR Integrity - ERB-EI Transition WI and all other related WIs. 

#### Actioning a fraudulent renewal on a claim that is blocked, archived or converted to MPS — Client is not requesting benefits

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/actioning_a_fraudulent_renewal_on_a_cla_918eab2a_level_1.dita`

- Review the file (RCM, SROC in NWS, RMDS Employer profile screen, NIIS) and determine if it contains fraudulent ROEs:

- If yes, go to step 2.

- If no, go to step 26.

- In RCM, determine if the fraudulent ROEs have been deleted:

- If no, go to step 3.

- If yes, go to step 4.

- In RCM, open each ROE Integrity identified as fraudulent and delete them as follows:

- Delete: Check the box.

- Additional information: Select the appropriate option:

- If it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 5.

- If it is a Level 1 AI WI that is being processed, type “Suspicious ROE. ROE has been deleted until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- Go to step 5.

- Determine if the following text appears in the Additional information section of the deleted ROE: “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- If yes, go to step 5.

- If no and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, do the following:

- Additional information : Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 5.

- If no and it is a Level 1 AI WI that is being processed, go to step 5.

- Determine if there are any fraudulent ROEs in the QP of one of the client’s established claim:

- If yes, go to step 6.

- If no, go to step 26.

- Determine if any fraudulent ROEs were already used to calculate one of the client’s established claim:

- If no, go to step 7.

- If yes, go to step 8.

- Determine if there is an outstanding CR Recalculation WI for the fraudulent ROE:

- If yes, go to step 10.

- If no, go to step 26.

- Determine if there is an outstanding CR Recalculation WI for the same BPC as the claim calculated with a fraudulent ROE:

- If no and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, go to step 9.

- If yes and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, go to step 13.

- If it is a Level 1 AI WI that is being processed, go to step 26.

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 11.

- If no, go to step 12.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank , enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: This field is prefilled.

- Select Generate registration .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1570.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1571.dita)

- In NWS, determine the status of the outstanding CR Recalculation WI:

- If it is assigned to another officer, go to step 14.

- If it is unassigned, go to step 15.

- If it is assigned to you, go to step 16.

- Determine in which workload the outstanding WI is:

- If it is in the pending workload, go to step 15.

- If it is in the current workload, contact the officer and ask to reassign the WI to yourself. Go to step 16.

- In NWS, open the CR Recalculation WI and reassign it to yourself as follows:

- Destination: Select Myself .

- Reason: Select Other .

- Details: Type “Related WI.”

- Select OK .

- In FTS, determine the BPC:

- If the BPC is w/c 2258 or after, go to step 17.

- If the BPC is between w/c 2230 and w/c 2257 and it is a claim for special benefits other than sickness benefits, go to step 17.

- If the BPC is between w/c 2230 and w/c 2257 and it is an EI ERB claim, the EI ERB claim must not be recalculated to change the rate or number of weeks of entitlement. Select the Renewal/Revised (M106) transaction and complete the recalculation registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 26.

- Refer to Recalculation and follow the appropriate task to recalculate the claim. Go to step 18.

- Determine if the claim became BPNE due to a deleted fraudulent ROE and if there is a violation for that BPC on the Violation History (ML02) screen in FTS:

- If no, go to step 19.

- If yes, include that information in the MM06 to be sent to IPOC to remove that BPC from the list of BPCs that are affected by the violation. Go to step 19.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the recalculation registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4466.dita)

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 54 - Third party fraud .

- Remarks line 1: Type “Recalculation — fraudulent ROE used in claim calculation.”

- Remarks lines 2–4: Type “INS HRS [insurable hours], INS EARNINGS [insurable earnings], DIV WK [divisor], COD [cut off date]. OP belongs to the client.” If necessary, enter the information regarding the claimant’s report and any other relevant information.

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 04 - Insurance Payment Operational Centre .

- Select Update .

- Determine if the recalculation has changed the BPC, hours or insurable earnings, which will result in an OP to the client due to a deleted fraudulent ROE:

- If yes, go to step 23.

- If no, go to step 26.

- Determine whether, as a result of the recalculation, an established claim became BPNE due to a deleted fraudulent ROE:

- If no, go to step 24.

- If yes, go to step 25.

- In ACS, create and send the N-03-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Various Reasons - Claim was recalculated (2683): Select Reviewed calculation of claim

- Various results due to recalculation or revision (2684)

- Allocation of Earnings (2516)

- Allocation of Bankruptcy payments (2573)

- Change to family supplement rate - No longer entitled (2685)

- Teachers: Benefit rate during non-teaching period (2689)

- Insurability Ruling - Benefits are being suspended (2690): Select Blank .

- Underpayment / overpayment message (2691): Select Overpayment Message .

- Do not report monies already declared (2456)

- Waiting Period Message (2444)

- Right to Request a Reconsideration (with Blank option) (4169)

- This Letter Replaces or Footnote (2365): Do the following:

- Select Footnote .

- Text - Footnote (11745): Type: “Your claim was initially calculated using a record of employment that does not belong to you.”

- Go to step 26.

- In ACS, create and send the B-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Types of BPNE Decisions (3197)

- BPNE – Regular / Special Benefits (2615)

- Number of insurable employment hours accumulated (1366)

- Start date of Regular qualifying period - Sunday’s date (1418)

- End date of Regular qualifying period - Saturday’s date (1420)

- Number of insurable employment hours required (1362)

- Start date of Regular qualifying period - Sunday’s date (1418)

- End date of Regular qualifying period - Saturday’s date (1420)

- End date of Regular qualifying period - Saturday’s date (1420)

- Overpayment Messages (2452): Select the appropriate option:

- If the client has an active claim, select Overpayment – No misrepresentation and active claim .

- If the client does not have an active claim, select Overpayment – No misrepresentation and inactive claim .

- This letter Replaces or Footnote (2365): Do the following:

- Select Footnote .

- Text - Footnote (11745): Type: “We have reviewed the calculation of your claim. Your claim was initially calculated using a record of employment that does not belong to you.”

- Go to step 26.

- In NWS, determine the type of WI:

- If it is a Level 1 CR Integrity - ERB-EI Transition WI, go to step 27.

- If it is a Level 1 AI WI, go to step 34.

- In NWS, create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, also type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen, close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Client’s information has been corrected as required.”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In FTS, determine if the Integrity registration number has been completed:

- If no, go to step 32.

- If yes, go to step 33.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the Level 1 CR Integrity - ERB-EI Transition WI and all other related WIs. No further action is required.

- Create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “Client’s identity validated — fraudulent renewal.”

- Details: Type “The client’s identity, address and banking information were validated on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “Fraudulent claim — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4582.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NWS, complete the AI WI and all other related WIs. No further action is required. 

#### Actioning a fraudulent renewal on an active claim — Client is not requesting benefits

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/actioning_a_fraudulent_renewal_on_an_ac_ea0bd270_level_1.dita`

- In FTS, determine if the claim is active or terminated:

- If the claim is terminated, but can be reactivated, select the appropriate BPC on the Dormant tab and select Reactivate . Go to step 2.

- If the claim is active, go to step 3.

- In NWS, move the AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Reactivation of BPC [XXXX].”

- Bring forward date: Enter today’s date + one business day.

- When the WI moves to the current workload, go to step 3.

- In FTS, determine if a renewal week related to the fraudulent application has been input:

- If yes, go to step 4.

- If no, go to step 6.

- Determine if the client filed an application after the fraudulent renewal application and if claimant’s reports were processed:

- If no, go to step 5.

- If yes, go to step 6.

- Select the Additional Data (M107) transaction and input the RTW week as follows:

- Return to work: Select the Monday of the renewal week related to the fraudulent application.

- Select Update .

- Determine if there is an MA71 to stop payments:

- If yes, go to step 7.

- If no, go to step 10.

- In NWS, determine the type of WI:

- If it is a Level 1 AI WI, go to step 8.

- If it is a Level 1 CR Integrity - ERB-EI Transition WI, go to step 9.

- Select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and rescind the MA71 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 71 - Integrity Services case .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Detection: Select the appropriate option:

- If there is an Integrity registration number, this field is pre-filled according to the type of investigation in NIIS.

- If there is a revised registration number, leave the field blank.

- Infraction: Select the appropriate option:

- If there is an Integrity registration number, select F - Non-fraud - Other .

- If there is a revised registration number, leave the field blank.

- Message: Select the appropriate option:

- If there is an Integrity registration number, select 27 - An overpayment resulted due to an incorrect calculation .

- If there is a revised registration number, leave the field blank.

- Select Update .

- Review the file (RCM, SROC in NWS, RMDS Employer profile screen , NIIS) and determine if it contains fraudulent ROEs:

- If yes, go to step 11.

- If no, go to step 32.

- In RCM, determine if the fraudulent ROEs have been deleted:

- If no, go to step 12.

- If yes, go to step 13.

- In RCM, open each ROE identified as fraudulent by Integrity and delete them as follows:

- Delete: Check the box.

- Additional information: Select the appropriate option:

- If it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 14.

- If it is a Level 1 AI WI that is being processed, type “Suspicious ROE. ROE has been deleted until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- Go to step 14.

- Determine if the following text appears in the Additional information section of the deleted ROE: “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- If yes, go to step 14.

- If no and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, do the following:

- Additional information: Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 14.

- If no and it is a Level 1 AI WI that is being processed, go to step 14.

- Determine if there are any fraudulent ROEs in the QP of one of the client’s established claim:

- If yes, go to step 15.

- If no, go to step 32.

- Determine if any fraudulent ROEs were used to calculate of one of the client’s established claim:

- If no, go to step 16.

- If yes, go to step 17.

- Determine if there is an outstanding CR Recalculation WI for the fraudulent ROE:

- If yes, go to step 22.

- If no, go to step 32.

- Determine if there is an outstanding CR Recalculation WI for the same BPC as the claim calculated with a fraudulent ROE:

- If no and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, go to step 18.

- If yes and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, go to step 22.

- If it is a Level 1 AI WI that is being processed, go to step 32.

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 20.

- If no, go to step 21.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank , enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: This field is prefilled.

- Select Generate registration .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1570.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1571.dita)

- In NWS, determine the status of the outstanding CR Recalculation WI:

- If it is assigned to another officer, go to step 23.

- If it is unassigned, go to step 24.

- If it is assigned to you, go to step 25.

- Determine in which workload the outstanding WI is:

- If it is in the pending workload, go to step 24.

- If it is in the current workload, contact the officer to ask to reassign the WI to yourself. Go to step 25.

- In NWS, open the CR Recalculation WI and reassign it to yourself as follows:

- Destination: Select Myself .

- Reason: Select Other .

- Details: Type “Related WI.”

- Select OK .

- In FTS, determine the BPC:

- If the BPC is w/c 2258 or after, go to step 26.

- If the BPC is between w/c 2230 and w/c 2257 and it is a claim for special benefits other than sickness benefits, go to step 26.

- If the BPC is between w/c 2230 and w/c 2257 and it is an EI ERB claim, the EI ERB claim must not be recalculated to change the rate or number of weeks of entitlement. Select the Renewal/Revised (M106) transaction and complete the recalculation registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 32.

- Refer to Recalculation and follow the appropriate task to recalculate the claim. Go to step 27.

- Determine if the recalculation has changed the BPC, hours or insurable earnings, which will result in an OP to the client due to a deleted fraudulent ROE:

- If yes, go to step 28.

- If no, go to step 32.

- Determine if, as a result of the recalculation, an established claim became BPNE due to a deleted fraudulent ROE:

- If yes, go to step 29.

- If no, go to step 30.

- Determine if an established claim became BPNE due to a deleted fraudulent ROE and if there is a violation for that BPC on the Violation History (ML02) screen:

- If no, go to step 31.

- If yes, send an MM06 to IPOC to remove that BPC from the list of BPCs that are affected by the violation. When creating the Operational Centre Memo (MM06) for IPOC, select 93 - Manual Pay System in the Work . Go to step 31.

- In ACS, create and send the N-03-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Various Reasons - Claim was recalculated (2683): Select Reviewed calculation of claim .

- Various results due to recalculation or revision (2684)

- Allocation of Earnings (2516)

- Allocation of Bankruptcy payments (2573)

- Change to family supplement rate - No longer entitled (2685)

- Change in BPC or LRW – Reports need to be completed (2686)

- Teachers: Benefit rate during non-teaching period (2689)

- Insurability Ruling - Benefits are being suspended (2690): Select Blank .

- Underpayment / overpayment message (2691): Select Overpayment Message .

- Do not report monies already declared (2456)

- Waiting Period Message (2444)

- Right to Request a Reconsideration (with Blank option) (4169)

- This Letter Replaces or Footnote (2365): Do the following:

- Select Footnote .

- Text - Footnote (11745): Type: “Your claim was initially calculated using a record of employment that does not belong to you.”

- Go to step 26.

- In ACS, create and send the B-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Types of BPNE Decisions (3197)

- BPNE – Regular / Special Benefits (2615)

- Number of insurable employment hours accumulated (1366)

- Start date of Regular qualifying period - Sunday’s date (1418)

- End date of Regular qualifying period - Saturday’s date (1420)

- Number of insurable employment hours required (1362)

- Start date of Regular qualifying period - Sunday’s date (1418)

- End date of Regular qualifying period - Saturday’s date (1420)

- End date of Regular qualifying period - Saturday’s date (1420)

- Overpayment Messages (2452): Select the appropriate option:

- If the client has an active claim, select Overpayment – No misrepresentation and active claim .

- If the client does not have an active claim, select Overpayment – No misrepresentation and inactive claim .

- This letter Replaces or Footnote (2365): Do the following:

- Select Footnote .

- Text - Footnote (11745): Type: “We have reviewed the calculation of your claim. Your claim was initially calculated using a record of employment that does not belong to you.”

- Go to step 32.

- In NWS, determine the type of WI:

- If it is a Level 1 AI WI, go to step 33.

- If it is a Level 1 CR Integrity - ERB-EI Transition WI, go to step 37.

- In NWS, create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “Client’s identity validated — fraudulent renewal.”

- Details: Type “The client’s identity, address and banking information were validated on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “Fraudulent claim — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NWS, complete the AI WI and all other related WIs. No further action is required.

- Create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, also type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen , close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Client’s information has been corrected as required.”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In FTS, determine if the Integrity registration number has been completed:

- If no, go to step 42.

- If yes, go to step 43.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the Level 1 CR Integrity - ERB-EI Transition WI and all other related WIs. 

#### Reviewing fraudulent ROEs

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/reviewing_fraudulent_roes_level_1.dita`

- In RCM, determine if the fraudulent ROEs have been deleted:

- If no, go to step 2.

- If yes, go to step 3.

- In RCM, open each ROE identified as fraudulent by Integrity and delete them as follows:

- Delete: Check the box.

- Additional information: Select the appropriate option:

- If it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 4.

- If it is a Level 1 AI WI that is being processed, type

- “Suspicious ROE. ROE has been deleted until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- Go to step 4.

- Determine if the following text appears in the Additional information section of the deleted ROE: “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- If yes, go to step 4.

- If no and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, do the following:

- Additional information: Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 4.

- If no and it is a Level 1 AI WI that is being processed, go to step 4.

- Determine if there are any fraudulent ROEs in the QP of one of the client’s established claim:

- If yes, go to step 5.

- If no, go to step 22.

- Determine if any fraudulent ROEs were used to calculate one of the client’s established claim:

- If no, go to step 6.

- If yes, go to step 7.

- Determine if there is an outstanding CR Recalculation WI for the fraudulent ROE:

- If yes, go to step 12.

- If no, go to step 22.

- Determine if there is an outstanding CR Recalculation WI for the same BPC as the claim calculated with a fraudulent ROE:

- If no and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, go to step 8.

- If yes and it is a Level 1 CR Integrity - ERB-EI Transition WI that is being processed, go to step 12.

- If it is a Level 1 AI WI that is being processed, go to step 22.

- In SSO, verify that the correct mainframe is selected and assign a recalculation registration number as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Recalculation .

- Select Search .

- In FTS, determine if the claim to be recalculated is a commuter claim:

- If yes, go to step 10.

- If no, go to step 11.

- In SSO, modify the following fields on the Name and address screen as follows, if necessary:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Refer to Changing an address — Outside of Canada for more information on the required United States of America address format.
               [Changing an address — Outside of Canada](/en/procedure/task/change_address_ooc.shtml)

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: In both fields, remove economic region code 99 . Enter the economic region code as follows:

- If the economic region code used to calculate the initial claim is correct, enter this economic region code.

- If the economic region code used to calculate the initial claim is incorrect, enter the economic region associated with the workplace postal code.

- Tax province: Select Commuters .

- Responsible SCC: Enter the SCC associated with the workplace postal code.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Enter the SCC as shown in FTS. If the field is blank , enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: This field is prefilled.

- Select Generate registration .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1570.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1571.dita)

- In NWS, determine the status of the outstanding CR Recalculation WI:

- If it is assigned to another officer, go to step 13.

- If it is unassigned, go to step 14.

- If it is assigned to you, go to step 15.

- Determine in which workload the outstanding WI is:

- If it is in the pending workload, go to step 14.

- If it is in the current workload, contact the officer to ask to reassign the WI to yourself. Go to step 15.

- In NWS, open the CR Recalculation WI and reassign it to yourself as follows:

- Destination: Select Myself .

- Reason: Select Other .

- Details: Type “Related WI.”

- Select OK .

- In FTS, determine the BPC:

- If the BPC is w/c 2258 or after, go to step 16.

- If the BPC is between w/c 2230 and w/c 2257 and it is a claim for special benefits other than sickness benefits, go to step 16.

- If the BPC is between w/c 2230 and w/c 2257 and it is an EI ERB claim, the EI ERB claim must not be recalculated to change the rate or number of weeks of entitlement. Select the Renewal/Revised (M106) transaction and complete the recalculation registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 22.

- Refer to Recalculation and follow the appropriate task to recalculate the claim. Go to step 17.

- Determine if the recalculation has changed the BPC, hours or insurable earnings, which will result in an OP to the client due to a deleted fraudulent ROE:

- If yes, go to step 18.

- If no, go to step 22.

- Determine if, as a result of the recalculation, an established claim became BPNE due to a deleted fraudulent ROE:

- If yes, go to step 19.

- If no, go to step 20.

- When an established claim became BPNE due to a deleted fraudulent ROE, in FTS, determine if there is a violation for that BPC on the Violation History (ML02) screen:

- If no, go to step 21.

- If yes, send an MM06 to IPOC to remove that BPC from the list of BPCs that are affected by the violation. When creating the Operational Centre Memo (MM06) for IPOC, select 93 - Manual Pay System in the Work item field and 54 - Third party fraud in the Work type field . Go to step 21.

- In ACS, create and send the N-03-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Various Reasons - Claim was recalculated (2683): Select Reviewed calculation of claim

- Various results due to recalculation or revision (2684)

- Allocation of Earnings (2516)

- Allocation of Bankruptcy payments (2573)

- Change to family supplement rate - No longer entitled (2685)

- Change in BPC or LRW – Reports need to be completed (2686)

- Teachers: Benefit rate during non-teaching period (2689)

- Insurability Ruling - Benefits are being suspended (2690): Select Blank .

- Underpayment / overpayment message (2691): Select Overpayment Message .

- Do not report monies already declared (2456)

- Waiting Period Message (2444)

- Right to Request a Reconsideration (with Blank option) (4169)

- This Letter Replaces or Footnote (2365): Do the following:

- Select Footnote .

- Text - Footnote (11745): Type: “Your claim was initially calculated using a record of employment that does not belong to you.”

- Go to step 26.

- In ACS, create and send the B-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Types of BPNE Decisions (3197)

- BPNE – Regular / Special Benefits (2615)

- Number of insurable employment hours accumulated (1366)

- Start date of Regular qualifying period - Sunday’s date (1418)

- End date of Regular qualifying period - Saturday’s date (1420)

- Number of insurable employment hours required (1362)

- Start date of Regular qualifying period - Sunday’s date (1418)

- End date of Regular qualifying period - Saturday’s date (1420)

- End date of Regular qualifying period - Saturday’s date (1420)

- Overpayment Messages (2452): Select the appropriate option:

- If the client has an active claim, select Overpayment – No misrepresentation and active claim .

- If the client does not have an active claim, select Overpayment – No misrepresentation and inactive claim .

- This letter Replaces or Footnote (2365): Do the following:

- Select Footnote .

- Text - Footnote (11745): Type: “We have reviewed the calculation of your claim. Your claim was initially calculated using a record of employment that does not belong to you.”

- Go to step 22.

- In NWS, determine the type of WI:

- If it is a Level 1 AI WI, go to step 23.

- If it is a Level 1 CR Integrity - ERB-EI Transition WI, go to step 27.

- In NWS, create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “Client’s identity validated — fraudulent renewal.”

- Details: Type “The client’s identity, address and banking information were validated on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4583.dita) 

- Comments: Type “Fraudulent claim — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NWS, complete the AI WI and all other related WIs.

- Create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, also type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

Note:

Before requesting that an authorized user delete the fraudulent Web application in NWS, ensure that all WIs related to the fraudulent claim are completed.

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen, close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Client’s information has been corrected as required.”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In FTS, determine if the Integrity registration number has been completed:

- If no, go to step 32.

- If yes, go to step 33.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the Level 1 CR Integrity - ERB-EI Transition WI and all other related WIs. 

#### Returning the file to Integrity

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/returning_the_file_to_integrity_level_1.dita`

- In NIIS, on the Document tab, select one of the following, depending on the case:

- IC70 Report of Investigation

- Return the case to Integrity Operations: Select Yes .

- IC50 Report of Clerical Investigation

- Return the case to Integrity Operations: Check the box .

- Select the Recommendation tab .

- Enter the missing or additional information required in the text area.

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4584.dita)

- In FTS, select the Outstanding Registrations link to cancel the Integrity registration number as follows:

- Select Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Select Update .

- Determine if there is an outstanding renewal registration number related to the investigation:

- If yes, go to step 4.

- If no, go to step 5.

- Select the Outstanding Registrations link to cancel the renewal registration number as follows:

- Select Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Select Update .

- If there is an outstanding WI for the antedate request, complete it.

- If necessary, return the paper documents relating to the investigation to the investigator who signed the Report of Investigation.

- In NWS, complete the Level 1 CR Integrity - ERB-EI Transition WI.

- Determine if there is an AI WI related to the CR Integrity ERB-EI Transition WI:

- If yes, return to step 8 of Reviewing the file .
               [Reviewing the file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level1_item_1)

- If no, no further action is required. 

#### Reassigning the WI to level 2

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/reassigning_the_wi_to_level_2_level_1.dita`

- In NWS, reassign the CR Integrity - ERB-EI Transition WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Do the following:

- If payments were issued to a third party on the fraudulent renewal claim, type “The claim does not meet Level 1 processing criteria because payments were issued to a third party on the fraudulent renewal claim.”

- If a decision on a contentious issue is required at Level 2, type “The claim does not meet Level 1 processing criteria because a decision on a contentious issue is required at Level 2.”

- No further action is required. 

#### Reassigning the AI WI to Integrity

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/reassigning_the_ai_wi_to_integrity_level_1.dita`

- In NWS, reassign the AI WI to Integrity as follows:

- In the AI WI, ensure that the Urgent box is checked.

- Destination — Level: At level 4 - National Integrity (ISB) and sub-level 2 - ID Validation , select the processing unit in the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- Complexity: Select Level 1

- Reason: Select Other .

- Details: Do the following:

- If payments were issued to a third party on the fraudulent renewal claim, type “The claim does not meet Level 1 processing criteria because payments were issued to a third party on the fraudulent renewal claim.”

- If a decision on a contentious issue is required at Level 2, type “A decision on a contentious issue is required at Level 2.”

- If the investigation has been returned to Integrity, type “The investigation has been returned to Integrity.”

- If potentially fraudulent ROEs were used to calculate the client’s established claim for the same BPC, type “Potentially fraudulent ROEs were used to calculate the client’s established claim for BPC [w/c]: ROE [serial number] with the business number [Canada Revenue Agency (CRA) business number].”

- No further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_4559.dita`

Note:

Before requesting that an authorized user delete the fraudulent Web application in NWS, ensure that all WIs related to the fraudulent claim are completed. 

#### Note

Source topic: `en_EN/common_notes/note_c_1713.dita`

Note:

In the Quebec region, instead of creating a REM WI, use the National Business Expertise Tool (NEXO) to advise the business expertise advisor that an application must be deleted. 

#### Note

Source topic: `en_EN/common_notes/note_c_1570.dita`

Note:

There cannot be more than 2 outstanding registration numbers. If there are already 2 outstanding registration numbers, advise the team leader that multiple registration numbers are preventing a new one from being created. 

#### Note

Source topic: `en_EN/common_notes/note_c_1571.dita`

Note:

When the message Success — Registration number created is displayed in SSO, a recalculation registration number is assigned to the claim. NWS creates a CR WI and assigns it to the unassigned (UNA) workload or to the next available user. 

#### Note

Source topic: `en_EN/common_notes/note_c_4466.dita`

Note:

If a second Operational Centre Memo (MM06) transaction is required for the same BPC, type “Page 1 of 2.” at the end of the Remarks section of the first Operational Centre Memo (MM06) transaction and type “Page 2 of 2.” at the beginning of the Remarks section of the second transaction. 

#### Info

Source topic: `en_EN/common_notes/note_c_4582.dita`

Note :

Before requesting that an authorized user delete the fraudulent Web application in NWS, ensure that all WIs related to the fraudulent claim are completed. 

#### Note

Source topic: `en_EN/common_notes/note_c_4583.dita`

Note:

This ROD must be created in the fraudulent renewal application. In NWS, select the fraudulent application and create the ROD using the appropriate information. If the application is not finalized, create the ROD before deleting the fraudulent renewal application and ensure that all other documents (not related to the fraudulent application) are transferred to the client’s renewal application. 

#### Note

Source topic: `en_EN/common_notes/note_c_4584.dita`

Note:

The regional consideration for officers in the Quebec region is as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address qc-dgsi-isb-retour@servicecanada.gc.ca as a carbon copy.
             [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca)

- In NWS, create a client Note and type “Measure — returned to Integrity —[DD-MM-YYYY].”

     [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca) 

### Level 2

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/reviewing_the_file_level_2.dita`

- In NIIS, determine if the information gathered by Integrity is complete:

- If yes, go to step 2.

- If no, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level2_item_5)

- In FTS, determine if payments were issued to a third party on the fraudulent renewal claim:

- If no, go to step 3.

- If yes and the claim is blocked, archived or converted to MPS, refer to Reviewing a fraudulent renewal when payments have been issued — Blocked claim .
               [Reviewing a fraudulent renewal when payments have been issued — Blocked claim](/en/procedure/task/renewal_payments_issued.shtml)

- If yes and the claim is active or terminated but can be reactivated, refer to Reviewing a fraudulent renewal when payments have been issued — Active or terminated claim .
               [Reviewing a fraudulent renewal when payments have been issued — Active or terminated claim](/en/procedure/task/reviewing_a_fraudulent_claim_renewal_client_not_seeking_benefits.shtml)

- Determine if a decision on a contentious issue is required at Level 2:

- If yes, go to step 4.

- If no, reassign the CR Integrity - ERB-EI Transition WI to Level 1 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 1 .

- Reason: Select Unable to complete .

- Details: Type “The claim meets Level 1 processing criteria.”

- No further action is required.

- Determine if the address is the client’s address:

- If yes, go to step 5.

- If no, update the address and go to step 5.
               [update the address](/en/procedure/activity/change_address.shtml)

- Determine if there is an SROC or an AI WI on file indicating that undeliverable mail has been received:

- If yes, re-send any letters that should have been sent to the client and whose information still applies. For more information, refer to Re-sending undeliverable mail . Go to step 6.
               [Re-sending undeliverable mail](/en/procedure/task/rescending_un_mail.shtml)

- If no, go to step 6.

- Determine if the banking information is correct:

- If yes, go to step 7.

- If no, update the banking information and go to step 7.
               [update the banking information](/en/procedure/activity/direct_deposit.shtml)

- Determine if the client is requesting benefits:

- If yes, go to step 8.

- If no and the claim is blocked, archived or converted to MPS, go to step 33.

- If no and the claim is active or terminated but can be reactivated, go to Actioning the fraudulent renewal on an active claim — Client is not requesting benefits .
               [Actioning the fraudulent renewal on an active claim — Client is not requesting benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level2_item_3)

- In FTS, determine if the claim is active, terminated, blocked or archived:

- If the claim is terminated but can be reactivated, select the appropriate BPC on the Dormant tab and select Reactivate . Go to step 9.

- If the claim is active, go to step 10.

- If the claim is blocked, archived or converted to MPS, go to Actioning a fraudulent renewal on a claim that is blocked, archived or converted to MPS — Client is requesting benefits.
               [Actioning a fraudulent renewal on a claim that is blocked, archived or converted to MPS — Client is requesting benefits.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level2_item_4)

- In NWS, move the AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Reactivation of BPC [XXXX].”

- Bring forward date: Enter today’s date + one business day.

- When the WI moves to the current workload, go to step 10.

- Determine the renewal week. Refer to Determining the effective date of a renewal or a conversion and Conversion and renewal .

- In FTS, determine if a renewal week related to the fraudulent application has been input:

- If yes, go to step 12.

- If no, go to step 21.

- Determine if the renewal week that is on file is the renewal week requested by the client:

- If yes, go to step 13.

- If no, go to step 17.

- In FTS, determine if there are cycling claimant’s reports completed by a third party:

- If no, go to step 14.

- If yes, go to step 16.

- Determine if there are cycling claimant’s reports completed by the client:

- If no, go to step 15.

- If yes, go to step 20.

- In NIIS and NWS, determine if a completed Claimant’s report: Original without pay coding — Checklist or Claimant’s report: Original with pay coding — Checklist is included for the renewal period:

- If no, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level2_item_5)

- If yes, go to step 20.

- Review the cycling claimant’s reports to determine the period for which the client is requesting benefits:

- If the client is requesting the same weeks as the cycling claimant’s reports and:

- has declarations (earnings, not available days, FWW, etc.) that will affect entitlement for the weeks requested, go to step 19.

- is entitled to those weeks, go to step 24.

- there are additional weeks, process the additional claimant’s reports if a completed Claimant’s report: Original without pay coding — Checklist or Claimant’s report: Original with pay coding — Checklist is on file and go to step 24. If not, go to step 24.
                   [Claimant’s report: Original without pay coding — Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Original_without_pay_coding-Checklist.doc) 
                   [Claimant’s report: Original with pay coding — Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Original_with_pay_coding-Checklist.doc)

- If the client is requesting and is entitled to some of the same weeks as the cycling claimant’s reports (e.g. w/cs 2300–2305 are cycling and client is only requesting and entitled to w/cs 2304–2305), go to step 19.

- If the client is requesting completely different weeks from the cycling claimant’s reports, go to step 19.

- Determine if claimant’s reports were completed after the renewal week:

- If yes, go to step 18.

- If no, go to step 20.

- Determine which of the following situations applies to the client:

- If the client’s renewal week is after the renewal week displayed in FTS, go to step 19.

- If the client’s renewal week is before the renewal week displayed in FTS and cycling claimant’s reports must be amended, go to step 19.

- If the client’s renewal week is before the renewal week displayed in FTS and cycling claimant’s reports must not be amended, go to step 24.

- Select the Additional Data (M107) transaction and input the RTW week as follows:

- Return to work: Select the Monday of the first cycling claimant’s report the client is not entitled to the full amount to be issued.

- Select Update .

- Review the client’s application and ROEs in RCM to determine if an allocation of earnings is required:

- If no, go to step 21.

- If yes, refer to Earnings (Activity) and complete the required inputs. Go to step 21.
               [Earnings (Activity)](/en/procedure/activity/earnings.shtml)

- In FTS, determine if there is an MA71 imposed to stop payments:

- If yes, go to step 22.

- If no, go to step 27.

- Determine which of the following situations applies to the client:

- If an MA71 must be rescinded and a renewal week must be entered, go to step 23.

- If an RTW has been input, go to step 24.

- If an MA71 must be rescinded, go to step 24.

- If a renewal week must be entered, go to step 27.

- Select the Renewal/Revised (M106) transaction to rescind the MA71, if there is one on file, and input the renewal week as follows:

- Registration number: Select the Integrity registration number.

- Renewal: Select the Sunday of the effective renewal week.

- Earnings week 1: Enter the amount, if necessary.

- Manual action: Select 71 - Integrity Services case .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Detection: This field is prefilled according to the type of investigation in NIIS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Select Update .

- Go to step 32.

- Select the Renewal/Revised (M106) transaction and rescind the MA71 as follows:

- Registration number: Select the Integrity registration number.

- Manual action: Select 71 - Integrity Services case .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Detection: This field is prefilled according to the type of investigation in NIIS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Select Update .

- If an RTW has been input and a new renewal week must be entered, go to step 25.

- If an RTW has been input and claimant’s reports must be updated, go to step 25.

- If there are cycling claimant’s reports and the client is entitled to those weeks, go to step 32.

- If the renewal week that is on file is the renewal week requested by the client and there are no cycling claimant’s reports that were completed by a third party, go to step 32.

- If there are cycling claimant’s reports, the client is entitled to those weeks and a new renewal week must be entered before the current renewal week, go to Inputting a renewal week with an Operational Centre Memo (MM06) transaction .
               [Inputting a renewal week with an Operational Centre Memo (MM06) transaction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level2_item_2)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type: “Waiting for RTW to be processed.”

- Bring Forward Date: Enter today’s date + one business day.

- Select Save .

- When the WI moves to the current workload, determine which of the following situations applies to the client:

- If an RTW has been input and a new renewal week must be entered after the current renewal week, go to step 27.

- If an RTW has been input and a new renewal week must be entered before the current renewal week, go to step 28.

- If an RTW must be rescinded and claimant’s reports must be updated, go to step 28.

- Select the Renewal/Revised (M106) transaction and input the renewal week as follows:

- Registration number: Select the Integrity registration number.

- Renewal: Select the Sunday of the renewal week.

- Earnings week 1: Enter the amount, if necessary.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Detection: This field is prefilled according to the type of investigation in NIIS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Select Update .

- Go to step 32.

- In FTS, select the Additional Data (M107) transaction and rescind the RTW week as follows:

- Return to work: Select the RTW week on the claim.

- Rescind: Check the box.

- Select Update .

- In NIIS and NWS, determine if a completed Claimant’s report: Original without pay coding — Checklist or Claimant’s report: Original with pay coding — Checklist is included for the renewal period:

- If yes, go to step 30.

- If no, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level2_item_5)

- Amend the last claimant’s report processed by referring to Modifying a claimant’s report . Go to step 31.

- Update the outstanding claimant’s reports by referring to Inputting a claimant’s report :

- If a new renewal week must be entered before the current renewal week, go to Inputting a renewal week with an Operational Centre Memo (MM06) transaction .
               [Inputting a renewal week with an Operational Centre Memo (MM06) transaction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level2_item_2)

- If the renewal week is the renewal week requested by the client, go to step 32.

- Complete the claimant’s reports, if necessary, and go to step 33.

- In NIIS, determine if Integrity identified fraudulent ROEs:

- If yes, go to step 34.

- If no, go to step 40.

- In RCM, determine if the fraudulent ROEs have been deleted:

- If no, go to step 35.

- If yes, go to step 36.

- In RCM, open each ROE identified as fraudulent in NIIS by Integrity and delete them as follows:

- Delete: Check the box.

- Additional information : Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 36.

- Determine if the following text appears in the Additional information section of the deleted ROE: “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- If yes, go to step 37.

- If no, do the following:

- Additional information : Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Determine if there are any fraudulent ROEs in the QP of one of the client’s established claim:

- If yes, go to step 38.

- If no, go to step 40.

- Determine if any fraudulent ROEs were used to calculate one of the client’s established claim:

- If yes, go to step 39.

- If no, go to step 40.

- In NWS, create an AI WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Claim type: Select Initial .

- Destination — Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / ISB Post Audit Processing .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- BPC: Enter the BPC requiring a recalculation.

- Comments: Type “Integrity confirmed that ROEs [serial numbers] are fraudulent. The ROEs have been deleted. Recalculate the client’s claim. Ensure the banking information and address are correct.”

- Source Details: Enter the Integrity case number.

- Determine if there is a contentious reason for separation (RFS) that requires adjudication in the QP:

- If yes, go to step 41.

- If no, go to step 45.

- In FTS, determine the BPC:

- If the BPC is between w/c 2310 and w/c 2361, go to step 42.

- If the BPC is between w/c 2258 and w/c 2309, go to step 43.

- If the BPC is between w/c 2230 and w/c 2257 and it is a claim for special benefits other than sickness benefits, adjudicate each contentious FRS issue, unless the decision can be deferred. Go to step 43.

- If the BPC is w/c 2362 or after, adjudicate each contentious RFS issue, unless the decision can be deferred. Go to step 43.

- If the BPC is between w/c 2230 and w/c 2257 and it is an EI ERB claim, go to step 46.

- Determine if there is a contentious RFS in the QP on the most recent ROE that belongs to the client:

- If yes, do the following:

- Open the corresponding RFS issue (i.e. the automatically resolved ROD with Adjudication not required ).

- Decision Options: Select Decision no longer valid .

- Select OK .

- Adjudicate the contentious RFS from the most recent ROE belonging to the client.

- Go to step 43.

- If no, go to step 46.

- Determine if the client is requesting regular or sickness benefits:

- If no, adjudicate each RFS issue requiring adjudication on a contentious RFS, unless the decision can be deferred. Go to step 44.

- If yes, go to step 46.

- Determine if a negative decision must be communicated in writing to the client due to a deleted fraudulent ROE:

- If yes, go to step 44.

- If no, go to step 46.

- In ACS, create and send the D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If a disqualification has been imposed, the client is requesting regular benefits and does not have enough hours since the contentious RFS to qualify, select the following attributes:

- Disqualifications - Definite/Indefinite - Previous/Current/Revision (2970): Select D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revised) .

- D11 / D10 / Both / Previous Disq / Revision - Initial or Renewal or Revision (2542): Select Disqualification message for Initial Claim .

- Disqualification message for Initial Claim (2543) .

- D11 / D10-Date of event = BPC/Date of event prior to BPC/ Date of event after BPC (2544): Select Date of event = BPC or Date of event prior to BPC and the appropriate sub-options.

- D11 / D10-Min hrs for reg/ Insufficient hrs reg/ Insufficient hrs reg fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting regular benefits and has enough hours since the contentious RFS to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of Employer(s) (1502): Enter the employer’s name.

- D11 message/D10 message (2463)

- If the client is requesting special benefits and does not have enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Special benefits approved (3046): Select the appropriate BT and options.

- Not entitled to regular after special: - (D10/D11) or claim is BPNE - Initial or renewal claim D42 - D43 (2540): Select (D11/D10) imposed - Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491)

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D11 / D10 / Both- Min hrs for reg / Insufficient hrs reg / Insufficient hrs reg fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting special benefits and has enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (1503) .

- Special benefits approved (3046): Select the appropriate BT and options.

- If a disentitlement has been imposed, select Disentitlements (2976) .

- If an allocation of earnings has been input, select Allocation of Earnings (2516) .

- Overpayment Messages (2452): Select the appropriate option:

- If there is no resulting OP, select Blank .

- If the client has an active claim, select Overpayment = No misrepresentation and active claim .

- If the client does not have an active claim, select Overpayment – No misrepresentation and inactive claim .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create the ROD on the client’s application and not on the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, also type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen, close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Fraudulent renewal. No OP to a third party.”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In FTS, determine if the Integrity registration number has been completed:

- If no, go to step 51.

- If yes, go to step 52.

- Select the Renewal/Revised (M106) transaction and complete the Integrity registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the CR Integrity - ERB-EI Transition WI and all other related WIs. 

#### Inputting a renewal week with an Operational Centre Memo (MM06) transaction

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/inputting_a_renewal_week_with_an_operat_7005f8f0_level_2.dita`

- Determine if a completed Claimant’s report: Original without pay coding — Checklist or Claimant’s report: Original with pay coding — Checklist is included for the antedate period:

- If yes, go to step 2.

- If no and fact-finding is required, go to Returning the file to Integrity .
               [fact-finding](/en/procedure/task/fact_find.shtml) 
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b#level2_item_5)

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the Integrity registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 92 - Purge and Recreate .

- Work type: Select 26 - Processing of a report blocked by a renewal week .

- Remarks line 1: Type “Antedate renewal from w/c [XXXX] to [XXXX].”

- Remarks line 2–4: Enter the claimant’s report details and any allocation information.

- Remarks line 5: Enter your first name and last name.

- Detection: Select 23 - Recalculation - postdating/antedating .

- Infraction: Select C - Non-fraud - Insurability - new information .

- Message: Select 38 - An overpayment resulted due to a change in the start of your claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, determine if Integrity identified fraudulent ROEs:

- If yes, go to step 5.

- If no, go to step 11.

- In RCM, determine if the fraudulent ROEs have been deleted:

- If no, go to step 6.

- If yes, go to step 7.

- In RCM, open each ROE identified as fraudulent in NIIS by Integrity and delete them as follows:

- Delete: Check the box.

- Additional information: Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 8.

- Determine if the following text appears in the Additional information section of the deleted ROE: “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- If yes, go to step 8.

- If no, add the text as follows:

- Additional information: Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Determine if there are any fraudulent ROEs in the QP of one of the client’s established claim:

- If yes, go to step 9.

- If no, go to step 11.

- Determine if any fraudulent ROEs were used to calculate one of the client’s established claim:

- If yes, go to step 10.

- If no, go to step 11.

- In NWS, create an AI WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Claim type: Select Initial .

- Destination — Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / ISB Post Audit Processing .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- BPC: Enter the BPC requiring a recalculation.

- Comments: Type “Integrity confirmed that ROEs [serial numbers] are fraudulent. The ROEs have been deleted. Recalculate the client’s claim. Ensure the banking information and address are correct.”

- Source Details: Enter the Integrity case number.

- Determine if there is a contentious reason for separation (RFS) that requires adjudication in the QP:

- If yes, go to step 12.

- If no, go to step 17.

- In FTS, determine the BPC:

- If the BPC is between w/c 2310 and w/c 2361, go to step 13.

- If the BPC is between w/c 2258 and w/c 2309, go to step 14.

- If the BPC is between w/c 2230 and w/c 2257 and it is a claim for special benefits other than sickness benefits, adjudicate each contentious FRS issue, unless the decision can be deferred. Go to step 15.

- If the BPC is w/c 2362 or after, adjudicate each contentious FRS issue, unless the decision can be deferred. Go to step 15.

- If the BPC is between w/c 2230 and w/c 2257 and it is an EI ERB claim, go to step 17.

- Determine is there is a contentious RFS in the QP on the most recent ROE that belongs to the client:

- If yes, do the following:

- Open the corresponding RFS issue (i.e. the automatically resolved ROD with Adjudication not required ).

- Decision Options: Select Decision no longer valid .

- Select OK .

- Adjudicate the contentious RFS from the most recent ROE belonging to the client.

- Go to step 15.

- If no, go to step 17.

- Determine if the client is requesting regular or sickness benefits:

- If no, adjudicate each RFS issue requiring adjudication on a contentious RFS, unless the decision can be deferred. Go to step 15.

- If yes, go to step 17.

- Determine if a negative decision must be communicated in writing to the client due to a deleted fraudulent ROE:

- If yes, go to step 16.

- If no, go to step 17.

- In ACS, create and send the D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If a disqualification has been imposed, the client is requesting regular benefits and does not have enough hours since the contentious RFS to qualify, select the following attributes:

- Disqualifications - Definite/Indefinite - Previous/Current/Revision (2970): Select D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revised) .

- D11 / D10 / Both / Previous Disq / Revision - Initial or Renewal or Revision (2542): Select Disqualification message for Initial Claim .

- Disqualification message for Initial Claim (2543)

- D11 / D10 - Date of event = BPC/Date of event prior to BPC/ Date of event after BPC (2544): Select Date of event = BPC or Date of event prior to BPC and the appropriate sub-options.

- D11 / D10 - Min hrs for reg/ Insufficient hrs reg/ Insufficient hrs reg fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting regular benefits and has enough hours since the contentious RFS to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 message - D10 message (2463)

- If the client is requesting special benefits and does not have enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Special Benefits Approved (3046): Select the appropriate BT and options.

- Not entitled to regular after special: - (D10/D11) or claim is BPNE) - Initial or Renewal claim or D42 -D43 (2540): Select (D11/D10) imposed - Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491)

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D11 min hours for regular/not enough hours regular/not enough hours regular and not enough earnings fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting special benefits and has enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (1503) .

- Special Benefits Approved (3046): Select the appropriate BT and options.

- If a disentitlement has been imposed, select Disentitlements (2976) .

- If an allocation of earnings has been input, select Allocation of Earnings (2516) .

- Overpayment Messages (2452): Select the appropriate option:

- If there is no resulting OP, select Blank .

- If the client has an active claim, select Overpayment – No misrepresentation and active claim .

- If the client does not have an active claim Overpayment – No misrepresentation and inactive claim .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- Create the ROD on the client’s application and not on the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, also type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen, close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Fraudulent renewal. No OP to a third party.”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In NWS, complete the CR Integrity - ERB-EI Transition WI and all other related WIs. 

#### Actioning a fraudulent renewal on an active claim — Client is not requesting benefits

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/actioning_a_fraudulent_renewal_on_an_ac_ea0bd270_level_2.dita`

- In FTS, determine if the claim is active or terminated:

- If the claim is terminated but can be reactivated, select the appropriate BPC on the Dormant tab and select Reactivate . Go to step 2.

- If the claim is active, go to step 3.

- In NWS, move the AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Reactivation of BPC [XXXX].”

- Bring forward date: Enter today’s date + one business day.

- When the WI moves to the current workload, go to step 3.

- In FTS, determine if a renewal week related to the fraudulent application has been input:

- If yes, go to step 4.

- If no, go to step 6.

- Determine if the client filed an application after the fraudulent renewal application and if claimant’s reports were processed:

- If no, go to step 5.

- If yes, go to step 6.

- Select the Additional Data (M107) transaction and input the RTW week as follows:

- Return to work: Select the Monday of the renewal week related to the fraudulent application.

- Select Update .

- In FTS, determine if there is an MA71 to stop payments:

- If yes, go to step 7.

- If no, go to step 8.

- Select the Renewal/Revised (M106) transaction and rescind the MA71 as follows:

- Registration number: Select the Integrity registration number.

- Manual Action: Select 71 - Integrity Services case .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Detection: This field is prefilled according to the type of investigation in NIIS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Select Update .

- In NIIS, determine if Integrity identified fraudulent ROEs:

- If yes, go to step 9.

- If no, go to step 15.

- In RCM, determine if the fraudulent ROEs have been deleted:

- If no, go to step 10.

- If yes, go to step 11.

- In RCM, open each ROE identified as fraudulent in NIIS by Integrity and delete them as follows:

- Delete: Check the box.

- Additional information : Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 12.

- In RCM, determine if the following text appears in the Additional information section of the deleted ROE: “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- If yes, go to step 12.

- If no, do the following:

- Additional information : Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- In RCM, determine if there are any fraudulent ROEs in the QP of one of the client’s established claim:

- If yes, go to step 13.

- If no, go to step 15.

- Determine if any fraudulent ROEs were used to calculate one of the client’s established claim:

- If yes, go to step 14.

- If no, go to step 15.

- In NWS, create an AI WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Claim type: Select Initial .

- Destination — Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / ISB Post Audit Processing .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- BPC: Enter the BPC requiring a recalculation.

- Comments: Type “Integrity confirmed that ROEs [serial numbers] are fraudulent. The ROEs have been deleted. Recalculate the client’s claim. Ensure the banking information and address are correct.”

- Source Details: Enter the Integrity case number.

- Determine if there is a contentious reason for separation (RFS) that requires adjudication in the QP:

- If yes, go to step 16.

- If no, go to step 21.

- In FTS, determine the BPC:

- If the BPC is between w/c 2310 and w/c 2361, go to step 17.

- If the BPC is between w/c 2258 and w/c 2309, go to step 18.

- If the BPC is between w/c 2230 and w/c 2257 and it is a claim for special benefits other than sickness benefits, adjudicate each contentious FRS issue, unless the decision can be deferred. Go to step 19.

- If the BPC is w/c 2362 or after, adjudicate each contentious FRS issue, unless the decision can be deferred. Go to step 19.

- If the BPC is between w/c 2230 and w/c 2257 and it is an EI ERB claim, go to step 21.

- Determine is there is a contentious RFS in the QP on the most recent ROE that belongs to the client:

- If yes, do the following:

- Open the corresponding RFS issue (i.e. the automatically resolved ROD with Adjudication not required ).

- Decision Options: Select Decision no longer valid .

- Select OK .

- Adjudicate the contentious RFS from the most recent ROE belonging to the client.

- Go to step 19.

- If no, go to step 21.

- Determine if the client is requesting regular or sickness benefits:

- If no, adjudicate each RFS issue requiring adjudication on a contentious RFS. Go to step 19.

- If yes, go to step 21.

- Determine if a negative decision must be communicated in writing to the client due to a deleted fraudulent ROE:

- If yes, go to step 20.

- If no, go to step 21.

- In ACS, create and send the D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If a disqualification has been imposed, the client is requesting regular benefits and does not have enough hours since the contentious RFS to qualify, select the following attributes:

- Disqualifications - Definite/Indefinite - Previous/Current/Revision (2970): Select D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revised) .

- D11 / D10 / Both / Previous Disq / Revision - Initial or Renewal or Revision (2542): Select Disqualification message for Initial Claim .

- Disqualification message for Initial Claim (2543)

- D11 / D10 - Date of event = BPC/Date of event prior to BPC/ Date of event after BPC (2544): Select Date of event = BPC or Date of event prior to BPC and the appropriate sub-options.

- D11 / D10 - Min hrs for reg/ Insufficient hrs reg/ Insufficient hrs reg fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting regular benefits and has enough hours since the contentious RFS to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 message/D10 message (2463)

- If the client is requesting special benefits and does not have enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Special Benefits Approved (3046): Select the appropriate BT and options.

- Not entitled to regular after special: - (D10/D11) or claim is BPNE) - Initial or renewal claim D42 – D43 (2540): Select (D11/D10) imposed - Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491)

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D11 min hours for regular/not enough hours regular/ not enough hours regular and not enough earnings fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting special benefits and has enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE Excluded due to D11 or D10 disqualification .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (1503) .

- Special Benefits Approved (3046): Select the appropriate BT and options.

- If a disentitlement has been imposed, select Disentitlements (2976) .

- If an allocation of earnings has been input, select Allocation of Earnings (2516) .

- Overpayment Messages (2452: Select the appropriate option:

- If there is no resulting OP, select Blank .

- If the client has an active claim, select Overpayment – No misrepresentation and active claim. .

- If the client does not have an active claim, select Overpayment – No misrepresentation and inactive claim. .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, also type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen, close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Fraudulent renewal. No OP to a third party.”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In NWS, complete the CR Integrity - ERB-EI Transition WI and all other related WIs. 

#### Actioning a fraudulent renewal on a claim that is blocked, archived or converted to MPS — Client is requesting benefits

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/actioning_a_fraudulent_renewal_on_a_cla_fb0c57cf_level_2.dita`

- In NIIS, determine if Integrity identified fraudulent ROEs:

- If yes, go to step 2.

- If no, go to step 8.

- In RCM, determine if fraudulent the ROEs have been deleted:

- If no, go to step 3.

- If yes, go to step 4.

- In RCM, open each ROE identified as fraudulent in NIIS by Integrity and delete them as follows:

- Delete: Check the box.

- Additional information : Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Go to step 5.

- Determine if the following text appears in the Additional information section of the deleted ROE: “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- If yes, go to step 5.

- If no, do the following:

- Additional information : Type “Investigation has been completed. This fraudulent ROE must remain in deleted status. (NIIS case [XXXXXX]).”

- Select Validate .

- Select Submit .

- Determine if there are any fraudulent ROEs in the QP of one of the client’s established claim:

- If yes, go to step 6.

- If no, go to step 8.

- Determine if any fraudulent ROEs were used to calculate one of the client’s established claim:

- If yes, go to step 7.

- If no, go to step 8.

- In NWS, create an AI WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Claim type: Select Initial .

- Destination — Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / ISB Post Audit Processing .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- BPC: Enter the BPC requiring a recalculation.

- Comments: Type “Integrity confirmed that ROEs [serial numbers] are fraudulent. The ROEs have been deleted. Recalculate the client’s claim. Ensure the banking information and address are correct.”

- Source Details: Enter the Integrity case number.

- Determine if there is a contentious reason for separation (RFS) in the QP:

- If yes, go to step 9.

- If no, go to step 14.

- In FTS, determine the BPC:

- If the BPC is between w/c 2310 and w/c 2361, go to step 10.

- If the BPC is between w/c 2258 and w/c 2309, go to step 11.

- If the BPC is between w/c 2230 and w/c 2257 and it is a claim for special benefits other than sickness benefits, adjudicate each contentious FRS issue, unless the decision can be deferred. Go to step 12.

- If the BPC is w/c 2362 or after, adjudicate each contentious FRS issue, unless the decision can be deferred. Go to step 12.

- Determine is there is a contentious RFS in the QP on the most recent ROE that belongs to the client:

- If yes, do the following:

- Open the corresponding RFS issue (i.e. the automatically resolved ROD with Adjudication not required ).

- Decision Options: Select Decision no longer valid .

- Select OK .

- Adjudicate the contentious RFS from the most recent ROE belonging to the client.

- Go to step 12.

- If no, go to step 14.

- Determine if the client is requesting regular or sickness benefits:

- If no, adjudicate each RFS issue requiring adjudication on a contentious RFS. Go to step 12.

- If yes, go to step 14.

- Determine if a negative decision must be communicated in writing to the client due to a deleted fraudulent ROE:

- If yes, go to step 13.

- If no, go to step 14.

- In ACS, create and send the D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If a disqualification has been imposed, the client is requesting regular benefits and does not have enough hours since the contentious RFS to qualify, select the following attributes:

- Disqualifications - Definite/Indefinite - Previous/Current/Revision (2970): Select D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revised) .

- D11 / D10 / Both / Previous Disq / Revision - Initial or Renewal or Revision (2542): Select Disqualification message for Initial Claim .

- Disqualification message for Initial Claim (2543)

- D11 / D10 - Date of event = BPC/Date of event prior to BPC/ Date of event after BPC (2544): Select Date of event = BPC or Date of event prior to BPC and the appropriate sub-options.

- D11 / D10 - Min hrs for reg/ Insufficient hrs reg/ Insufficient hrs reg fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting regular benefits and has enough hours since the contentious RFS to qualify, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- D11 message/D10 message (2463)

- If the client is requesting special benefits and does not have enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Special benefits approved (3046): Select the appropriate BT and options.

- Not entitled to regular after special: - (D10/D11) or claim is BPNE) - Initial or renewal claim or D42 - D43 (2540): Select (D11/D10) imposed - Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491)

- Text: Name of Employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D11 / D10 / Both-Min hrs for reg/ Insufficient hrs reg/ Insufficient hrs reg fishing (2545):

- If the client has not worked since the event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the event and it is obvious there are insufficient hours since the event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the event, but the information or knowledge to complete this block is missing, select Min hrs required to qualify for regular benefits .

- If the client is requesting special benefits and has enough hours since the contentious RFS to qualify for regular benefits, select the following attributes:

- Various issues affecting claim establishment and benefit rate (2500): Select ROE excluded due to voluntary leave not just cause or misconduct .

- Text: Name of Employer(s) (1502): Enter the employer’s name.

- D11 Message - D10 Message (1503) .

- Special benefits approved (3046): Select the appropriate BT and options.

- Special Benefits Approved (3046): Select the appropriate BT and options.

- If a disentitlement has been imposed, select Disentitlements (2976) .

- If an allocation of earnings has been input, select Allocation of Earnings (2516) .

- Overpayment Messages (2452): Select the appropriate option:

- If there is no resulting OP, select Blank .

- If the client has an active claim, select Overpayment – No misrepresentation and active claim .

- If the client does not have an active claim, select Overpayment – No misrepresentation and inactive claim .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, move the CR Integrity - ERB-EI Transition WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type: “Waiting for CR Recalculation WI to be processed at Level 1.”

- Bring forward date: Enter today’s date + 10 business days.

- Select Save .

- When the WI moves to the current workload, determine if the Level 1 AI WI and the CR Recalculation WI are completed:

- If no, repeat step 14.

- If yes, go to step 16.

- In FTS, in the Enquiry tab, select Transaction History to determine which of the following situations applies:

- If the Renewal/Revised (M106) and the Operational Centre Memo (MM06) transactions related to the recalculation registration number have been transmitted, go to step 17.

- If the Renewal/Revised (M106) transaction related to the recalculation registration number with the Claim Allowed field indicating NCA - No changes to the claim has been transmitted, go to step 18.

- Determine whether, as a result of the recalculation, the established claim related to the same BPC as the fraudulent renewal application became BPNE due to a deleted fraudulent ROE:

- If no, go to step 18.

- If yes, go to step 20.

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the Integrity registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Detection: This field is prefilled according to the type of investigation in NIIS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4585.dita)

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the Integrity registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 54 - Third party fraud .

- Remarks: Select the appropriate option:

- If the renewal week that is on file is the renewal week requested by the client and there are no cycling claimant’s reports that were completed by a third party, do the following:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type: “Issue w/c [w/cs to which the client is entitled], CT [XX].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].” If an MA was imposed to stop payments, type “Rescind MA[XX].”

- If the renewal week that is on file is the renewal week requested by the client, there are cycling claimant’s reports that were completed by a third party and the client is entitled to those weeks, do the following:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “ Issue w/c [w/cs to which the client is entitled], CT [XX].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If an MA was imposed to stop payments, type “Rescind MA[XX].”

- If the renewal week that is on file is the renewal week requested by the client, there are cycling claimant’s reports that were completed by a third party and the client is entitled to some of those weeks, do the following:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “Remove cycling claimant’s reports w/c [XXXX] to [XXXX]. Issue w/c [w/cs to which the client is entitled], CT [XX].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].” If an MA was imposed to stop payments, type “Rescind MA[XX].”

- If the renewal week on file is different from the renewal week requested by the client and there are cycling claimant’s reports that were completed by a third party, do the following:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “Remove cycling claimant’s reports w/c [XXXX] to [XXXX]. Input renewal w/c [XXXX], CT [XX]. Issue w/c [w/cs to which the client is entitled].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].” If an MA was imposed to stop payments, type “Rescind MA[XX].”

- If the renewal week on file is different from the renewal week requested by the client and there are no cycling claimant’s reports that were completed by a third party, do the following:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “Input renewal w/c [XXXX], CT [XX].” Issue w/c [w/cs to which the client is entitled].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].” If an MA was imposed to stop payments, type “Rescind MA[XX].”

- If the renewal week has not been input, do the following:

- Remarks line 1: Type “Fraudulent renewal. Unknown third party.”

- Remarks lines 2–4: Type “Input renewal w/c [XXXX], CT [XX]. Issue w/c [w/cs to which the client is entitled].” If paycoding is required, type “[Appropriate paycoding, e.g. FWW, non-available days, sick days].” If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].” If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].” If a disqualification must be imposed, type “D[XX] from w/c [XXXX].” If an MA was imposed to stop payments, type “Rescind MA[XX].”

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Create a ROD in the client’s application and not in the fraudulent application as follows:

- Comments: Type “[Integrity file number] — fraudulent renewal.”

- Details: Type “The investigator confirmed the client’s address and banking information on: [DD-MM-YYYY]. The client’s address is: [client’s address]. The client’s banking information is: [client’s banking information].” If Integrity identified fraudulent ROEs, also type “Integrity confirmed that ROE [serial number] is fraudulent.” Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD on the fraudulent renewal application as follows:

- Comments: Type “[Integrity file number] — renewal submitted by a third party.”

- Details: Enter the following information:

- Relevant facts: Type “An EI renewal application was filed by a third party on [DD-MM-YYYY] using the client’s identity.”

- Decision/Justification: Type “This renewal application was not filed by the client and must not be included in an access to information request.”

- To delete the fraudulent application, create a REM WI as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4559.dita) 

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Delete the application.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Fraudulent renewal application dated [DD-MM-YYYY].”

- Destination — SCC: Enter the SCC as shown in FTS.

- End user: Select Specific user:

- Enter the name of the team leader or the designated person and select Find user .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1713.dita)

- In NIIS, on the Decision tab of the IC70 Report of Investigation screen , close the case as follows:

- Disentitlement: Select No .

- Reason: Select Other and type “Fraudulent renewal. No OP to a third party.”

- Overpayment: Do not check either box.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Prosecution: Select No .

- Select OK .

- In FTS, determine if the Integrity registration number has been completed:

- If no, go to step 25.

- If yes, go to step 26.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the CR Integrity - ERB-EI Transition WI and all other related WIs. 

#### Returning the file to Integrity

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/returning_the_file_to_integrity_level_2.dita`

- In NIIS, on the Document tab, select one of the following, depending on the case:

- IC70 Report of Investigation

- Return the case to Integrity Operations: Select Yes .

- IC50 Report of Clerical Investigation

- Return the case to Integrity Operations: Check the box .

- Select the Recommendation tab .

- Enter the missing or additional information required in the text area.

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4560.dita)

- In FTS, select the Outstanding Registrations link to cancel the Integrity registration number as follows:

- Select Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Select Update .

- If there is an outstanding WI for the antedate request, complete it.

- If necessary, return the paper documents relating to the investigation to the investigator who signed the Report of Investigation.

- In NWS, complete the CR Integrity - ERB-EI Transition WI and other related WIs. 

#### Note

Source topic: `en_EN/common_notes/note_c_4585.dita`

Note:

If a second Operation Centre Memo (MM06) transaction is required for the same BPC, type “Page 1 of 2” at the end of the Remarks section of the first Operational Centre Memo (MM06) transaction and type “Page 2 of 2” at the beginning of the Remarks section of the second transaction. 

#### Note

Source topic: `en_EN/common_notes/note_c_4560.dita`

Note:

The regional consideration for officers in the Quebec region is as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address qc-dgsi-isb-retour@servicecanada.gc.ca as a carbon copy.
             [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca)

- In NWS, create a client Note and type “Measure — returned to Integrity — [DD-MM-YYYY].”

     [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca) 

## Policy reference

Source topic: `en_EN/task/reviewing_a_fraudulent_claim_client_see_dd084b4b/policy_reference.dita`

 
