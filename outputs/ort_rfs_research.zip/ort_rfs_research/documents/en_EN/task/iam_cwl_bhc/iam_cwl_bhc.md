# Implementing client misrepresentation on an archived claim — Warning letter

Source map: `en_EN/task/iam_cwl_bhc/iam_cwl_bhc.ditamap`

## Summary

Source topic: `en_EN/task/iam_cwl_bhc/summary.dita`

Summary: When a warning letter is being issued to the client for making a misrepresentation on an archived claim or a blocked claim that is not updateable, all decisions related to the misrepresentation must be input by sending an Operational Centre Memo (MM06) transaction to IPOC. Once the decisions have been input, the client must be notified. 

## What you need to know

Source topic: `en_EN/task/iam_cwl_bhc/what_you_need_to_know.dita`

### Adjudicating misrepresentation — Issuing a warning letter

Source topic: `en_EN/task/iam_cwl_bhc/adjudicating_misrepresentation__issuing_a98124f6.dita`

The final step in adjudicating misrepresentation is to implement the decision by completing the appropriate inputs and notifying the client. 

### Implementing a decision on an archived or blocked claim

Source topic: `en_EN/task/iam_cwl_bhc/implementing_a_decision_on_an_archived__303671ca.dita`

This implementation task applies to archived claims and blocked claims that are not updateable in BCS. It includes the following:

- creating an MM06 for IPOC to input the reconsideration decision(s)

- inputting the reconsidered decision(s) in RCM (if necessary)

- sending the decision letter in ACS

- clearing the case in NIIS

- completing the WI in NWS

**Determining if there is collusion with a third party**

A third party making a misrepresentation with the client’s knowledge and consent is considered collusion between the client and third party. In this situation, the client must repay the net overpayment (OP) and any appropriate sanction can be imposed on both the client and the third party.

**Updating the special condition in RCM**

If the reconsideration decision is related to the reason for separation (RFS) and the ROE is on file, the Special condition field must be updated in RCM to show the decision. The RCM input can be done at any time.

**Sending the file for recalculation**

Certain situations of misrepresentation (e.g. the submission of a false ROE or an ROE containing false information) require the claim to be recalculated. A recalculation is also required when the misrepresentation involves an undisclosed contentious RFS in the qualifying period (QP) and impacts the calculation of the claim. If a recalculation is required, an Action Item (AI) WI is created for Level 1. Once the recalculation transaction inputs have been determined by Level 1 and indicated in the client Note , a Level 2 officer creates the MM06 for IPOC to input the reconsideration decisions (including the recalculation).

**Communicating the decision**

On a blocked or archived claim, the officer is responsible for creating and saving the ACS letter(s) to notify the client of the reconsideration decisions and warning. The MM06 must clearly indicate whether IPOC should:

- send the saved ACS letter(s),

- add missing fields to the ACS letter(s), or

- amend and send the ACS letter(s).

IPOC only sends the saved letter(s) if advised to do so in the MM06. IPOC does not create the ACS letter(s).

**Completing the case in NIIS**

Level 2 officers have access to NIIS to view selected information and to complete cases they have adjudicated. Although the Level 2 decisions are documented in NWS, the Decision tab on the Report of Investigation ( IC50 or IC70 ) screen must be completed to close the case. This ensures that NIIS has a complete record of the investigation. 

## Regional considerations

Source topic: `en_EN/task/iam_cwl_bhc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/iam_cwl_bhc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/iam_cwl_bhc/in_nws.dita`

- On the reconsideration record of decision (ROD):

- What transactions (allocation, disentitlement, disqualification, recalculation, etc.) are required?

- On the misrepresentation ROD:

- Does the misrepresentation involve the RFS?

- What is the level of misrepresentation?

- What is the number of misrepresentations (false or misleading statements knowingly made)?

- Were the false statements made within the last 36 months?

- Are there documents related to the issue? 

### In NIIS:

Source topic: `en_EN/task/iam_cwl_bhc/in_niis.dita`

- On the Report of Investigation (IC50 or IC70) screen:

- What is the investigation type?

- What is the investigation case number?

- If necessary, what is the name of the employer?

- On the Observation (IC04) screen

- If necessary, what are the client’s actual earnings to be allocated? 

### In Imaging:

Source topic: `en_EN/task/iam_cwl_bhc/in_imaging.dita`

- Is there a Request for Payroll Information (INS5097) or Request for Clarification of Employment Information (INS5098) showing the client’s actual earnings to be allocated? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/iam_cwl_bhc/in_integrity_investigations_document_up_6a8da64b.dita`

- Is there any document containing mitigating circumstances? 

### In RCM:

Source topic: `en_EN/task/iam_cwl_bhc/in_rcm.dita`

- If the misrepresentation involved the client’s RFS, is the ROE on file? 

## Step by step

Source topic: `en_EN/task/iam_cwl_bhc/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/iam_cwl_bhc/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/iam_cwl_bhc/reviewing_the_file_level_2.dita`

- Determine if any of the following applies:

- The misrepresentation involved the submission of a false ROE or the submission of an ROE with false information in the QP.

- The misrepresentation involved an undisclosed contentious RFS in the QP and impacts the calculation of the claim (i.e. a disqualification is applies and the client has not worked enough hours since the disqualifying event to establish the claim).

- If yes, go to Recalculation required .
                   [Recalculation required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/iam_cwl_bhc#Recalc)

- If no, go to step 2.

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3467.dita)

- If the decision involves an RFS, determine if the ROE is on file:

- If no, go to step 3.

- If yes, in RCM, update the Special condition field to reflect the reconsideration decision on the RFS.

- Determine the result of the reconsideration decision:

- If the decision results in a disentitlement, go to step 4.

- If the decision results in unreported earnings or an allocation, go to step 6.

- If the decision results in a disqualification, go to step 8.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3482.dita) 

#### Decision results in a disentitlement

Source topic: `en_EN/task/iam_cwl_bhc/decision_results_in_a_disentitlement_level_2.dita`

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the revised registration corresponding to the investigation.

- Memo (MPS): Check the box.

- Infraction: Select the misrepresentative option corresponding to the input:

- For a 1 - Not unemployed (D1) disentitlement, select U - Fraud - Earnings and employment .

- For a 14 - Void benefit period (D14) disentitlement, select W - Fraud - Insurability - new information .

- For any other type of disentitlement, select V - Fraud - Availability, Capability

- Message: Select the appropriate message:

- For a definite disentitlement, select 3 - An overpayment resulted due to a definite disentitlement .

- For an indefinite disentitlement, select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the revised registration corresponding to the investigation.

- BPC: Select the BPC of the claim on which the misrepresentation was made.

- Work item: Select the appropriate option:

- If the transaction impacts cycling claimant’s reports on a blocked claim, select 93 - Manual Pay System .

- If there are no cycling claimant’s reports, select 91 - Overpayment .

- Work type: Select the appropriate option:

- If the Work item is 91 , select 1 - Misrepresentation .

- If the Work item is 93 , select 33 - Blocked claim requiring payment .

- Remarks line 1: Indicate all of the following that apply:

- Whether additional information is being provided on another Operational Centre Memo (MM06) transaction. For example, Page 1 of 3, Page 2 of 3.

- URGENT: If urgent, provide reason. (e.g. URGENT approaching time limitation for penalty)

- DE: Disentitlement information. (e.g. DE 78V03-13-1720-1-1722-5)

- Remarks line 2: Indicate all of the following:

- WRN: warning letter

- Integrity case number.

               [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3483.dita)

- Remarks line 3: Type one of the following instructions for the ACS letter:

- Send stored D-91-00-00 letter.

- Add [missing fields] to D-91-00-00 letter and send.

- Amend D-91-00-00 letter, if necessary, (re: reconsideration limitation) and send.

- Remarks line 5: Indicate your name and telephone number.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 10. 

#### Decision results in unreported earnings or an allocation

Source topic: `en_EN/task/iam_cwl_bhc/decision_results_in_unreported_earnings_72484300_level_2.dita`

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the revised registration corresponding to the investigation.

- Memo (MPS): Check the box.

- Infraction: Select U - Fraud - Earnings and employment .

- Message: Select 7 - You misrepresented your earnings .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the revised registration corresponding to the investigation.

- BPC: Select the BPC of the claim on which the misrepresentation was made.

- Work item: Select the appropriate option:

- If the transaction impacts cycling claimant’s reports on a blocked claim, select 93 - Manual Pay System .

- If there are no cycling claimant’s reports, select 91 - Overpayment .

- Work type: Select the appropriate option:

- If the Work item is 91 , select 1 - Misrepresentation .

- If the Work item is 93 , select 33 - Blocked claim requiring payment .

- Earnings to be allocated: Do one of the following:
               [Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3459.dita) 

- If wages from employment are to be allocated, select the w/c and enter the amount of the earnings to be allocated to that week. The earnings amount is rounded to the nearest dollar. The amount field must contain 4 digits with no decimal places. For example, if the client’s actual earnings were $250.49 for the week, type “0250” in the amount field. Repeat for subsequent allocation weeks. This section is completed from left to right. If more than 16 weeks of earnings are to be allocated, another Operational Centre Memo (MM06) is required.

- If there are no wages from employment to be allocated, leave this section blank.

- Remarks line 1: Indicate all of the following that apply:

- Whether additional information is being provided on another Operational Centre Memo (MM06) transaction. For example, Page 1 of 3, Page 2 of 3.

- URGENT: If urgent, provide reason. (e.g. URGENT approaching time limitation for penalty)

- ALLOC: Other allocation information. (e.g. ALLOC 74U07-V-0550-1700-1703-0200)

- FWW: If changes are required.

- Remarks line 2: Indicate all of the following:

- WRN: warning letter

- Integrity case number.

               [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3483.dita)

- Remarks line 3: Type one of the following instructions for the ACS letter:

- Send stored D-91-00-00 letter.

- Add [missing fields] to D-91-00-00 letter and send.

- Amend D-91-00-00, if necessary, (re: penalty limitation) and send.

- Remarks line 5: Indicate your name and telephone number.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 10. 

#### Decision results in a disqualification

Source topic: `en_EN/task/iam_cwl_bhc/decision_results_in_a_disqualification_level_2.dita`

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the revised registration corresponding to the investigation.

- Memo (MPS): Check the box.

- Infraction: Select Z - Fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the revised registration corresponding to the investigation.

- BPC: Select the BPC of the claim on which the misrepresentation was made.

- Work item: Select the appropriate option:

- If the transaction impacts cycling claimant’s reports on a blocked claim, select 93 –- Manual Pay System .

- If there are no cycling claimant’s reports, select 91 - Overpayment .

- Work type: Select the appropriate option:

- If the Work item is 91 , select 1 - Misrepresentation .

- If the Work item is 93 , select 33 - Blocked claim requiring payment .

- Remarks line 1: Indicate all of the following that apply:

- Whether additional information is being provided on another Operational Centre Memo (MM06) transaction. For example, Page 1 of 3, Page 2 of 3.

- URGENT: If urgent, provide reason. (e.g. URGENT approaching time limitation for penalty)

- DQ: Disqualification information. (e.g. DQ 75Z01-10-9999-1725)

- Remarks line 2: Indicate all of the following:

- WRN: warning letter

- Integrity case number.

               [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3483.dita)

- Remarks line 3: Type one of the following instructions for the ACS letter:

- Send stored D-91-00-00 letter.

- Add [missing fields] to D-91-00-00 letter and send.

- Amend D-91-00-00 letter, if necessary, (re: reconsideration limitation) and send.

- Remarks line 5: Indicate your name and telephone number.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3484.dita) 

#### Sending an ACS letter

Source topic: `en_EN/task/iam_cwl_bhc/sending_an_acs_letter_level_2.dita`

- Determine if the case involves more than 52 weeks of unreported earnings:

- If yes, go to step 11.

- If no, go to step 12.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3465.dita)

- In ACS, create and save the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Decision reconsidered beyond 36 months (2595): Select the appropriate option.

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Definite Disqualification Messages - D06/D07/D09 (2918)

- D13 or D38 - Outside Canada (Interstate option)/on vacation within or outside Canada (2924)

- Various reasons for penalty and violation: Found work / Self Employment / Capability / Training / Availability / Full work week / Text (2935): Select Blank .

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared/omitted (2953)

- No reply from client/reply received with an explanation/reply received with no explanation (2938)

- False representation message/Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452)

- This Letter Replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “This letter includes only the information for the calendar year [20XX]. The information for calendar year [20XX] is included in a separate letter.”

- In ACS, create and save the D-91-00-00 letter to inform the client of the reconsideration and warning letter decisions. Based on the claim information, select all of the required attributes, including the following:

- Decision reconsidered beyond 36 months (2595): Select the appropriate option.

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Definite Disqualification Messages - D06/D07/D09 (2918)

- D13 or D38 - Outside Canada (Interstate option)/on vacation within or outside Canada (2924)

- Various reasons for penalty and violation: Found work / Self Employment / Capability / Training / Availability / Full work week / Text (2935): Select the appropriate option, or if the period of disentitlement and an explanation are required, select Failed to provide information: Text: Specify what we have learned .

- Some or All Earnings, Self-Employment Earnings or Fishing Earnings not declared/omitted (2953)

- No reply from client/reply received with an explanation/reply received with no explanation (2938)

- False representation message/Number of omissions or false representations (2941)

- Levels of misrepresentation (12292)

- Penalty message / Warning message (2950) : Select Warning message .

- Overpayment Messages (2452)

- Determine if a sanction also applies to a third party:

- If no, go to step 14.

- If yes, go to Implementing third party misrepresentation to impose the sanctions on the third party and to complete the case.
               [Implementing third party misrepresentation](/en/procedure/task/implementing_tp_misrepresentation.shtml) 

#### Completing the case in NIIS

Source topic: `en_EN/task/iam_cwl_bhc/completing_the_case_in_niis_level_2.dita`

- In NIIS, on the Decision tab of the Report of Investigation (IC50 or IC70) screen, clear the case as follows:

- Overpayment: Indicate whether an OP resulted from the misrepresentation.

- Reason: Select the appropriate option based on the decision that resulted in the OP.

- Amount: Enter the estimated total net OP that resulted from the misrepresentation.

- Penalty: Select No .

- Warning: Select Yes .

- Reason: Select the appropriate option.

- Violation: Select No .

- In NWS, complete the Claim Review (CR) WI. 

#### Recalculation required

Source topic: `en_EN/task/iam_cwl_bhc/recalculation_required_level_2.dita`

- If the decision involves an RFS, determine if the ROE is on file:

- If no, go to step 2.

- If yes, in RCM, update the Special condition field to reflect the reconsideration decision on the RFS.

- Create an AI WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Claim type: Select Revised .

- Destination — Level: Select EI Processing .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- Comments: Type “Level 1 recalculation required — Integrity case [Integrity case number].”

- Details: Do the following:

- Type “A recalculation of BPC [DD-MM-YYYY] is required due to the adjudication of ROE [serial number]. A Level 2 ROD is on file and the reconsideration timeframe ends on [DD-MM-YYYY]. Recalculation inputs and notification to the client must be completed no later than this date. The infraction code for the recalculation is W - Insurability. ” If the ROE contains false information, clearly indicate what is incorrect and provide the correct information. If there is a CR Recalculation WI for the ROE under reconsideration, also type “Complete the Claim Review Recalculation work item related to this benefits period.”

- Create a client Note and do the following:

- Type “Please indicate in the client Note the transaction fields and data to be entered for the recalculation of the [blocked or archived] claim so that this information can be included on the Operational Centre Memo (MM06). The [D-91-00-00 or D-17-03-00] letter will be sent once the claim has been recalculated. Please save any other required letters.”

- Move the CR Integrity WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “MM06 to be sent once recalculation transaction inputs indicated in client Note.”

- Bring forward date: Select the next business day.

- When the CR Integrity WI moves to the current workload, verify that recalculation transactions are indicated in the client Note:

- If the recalculation transactions are not indicated in the client Note , return to step 4.

- If the transactions fields and data to be entered for the recalculation are indicated in the client Note , go to step 6.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the revised registration corresponding to the investigation.

- Select Memo (MPS) .

- Infraction: Select the appropriate option:

- For a false ROE, select W - Fraud - Insurability - new information .

- For a contentious RFS, select Z - Fraud - Other .

- Message: Select the appropriate option:

- For a contentious RFS, select 1 - An overpayment resulted due to a disqualification .

- For a false ROE, select 9 - An overpayment resulted due to a change in insurable employment .

- Contentious: Select D - No .

- Complete: Select C - Yes .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the revised registration number corresponding to the investigation.

- BPC: Select the BPC of the claim on which the misrepresentation was made.

- Work item: Select the appropriate option:

- If the transaction impacts cycling claimant’s reports on a blocked claim, select 93 - Manual Pay System .

- If there are no cycling claimant’s reports, select 91 - Overpayment .

- Work type: Select the appropriate option:

- If the Work item is 91 , select 1 - Misrepresentation .

- If the Work item is 93 , select 33 - Blocked claim requiring payment .

- Remarks line 1: Indicate all of the following that apply:

- Whether additional information is being provided on another Operational Centre Memo (MM06) transaction. (e.g. Page 1 of 3, Page 2 of 3)

- URGENT: If urgent, provide reason. (e.g. URGENT approaching time limitation for penalty)

- Indicate the exact transaction fields and data to be entered for the recalculation (from the client Note ). (e.g. M106 BPC___ HOURS___ EARNINGS____)

- Remarks line 2: Indicate all of the following:

- WRN: warning letter

- Integrity case number.

               [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3483.dita)

- Remarks line 3: Type one of the following instructions for the ACS letter:

- Send stored [D-17-03-00 or D-91-00-00] letter.

- Add [missing fields] to [D-17-03-00 or D-91-00-00] letter and send.

- Amend [D-17-03-00 or D-91-00-00] letter, if necessary, (re: reconsideration limitation) and send.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Determine the issue:

- If it is a contentious RFS, go to step 9.

- If it is a false ROE or an ROE containing false information, go to step 10.

- In ACS, create and save the D-91-00-00 letter to inform the client of the reconsideration and penalty decisions. Based on the claim information, select all of the relevant attributes, including the following:

- Decision reconsidered beyond 36 months (2595): Select the appropriate option.

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- No reply from client/reply received with an explanation/reply received with no explanation (2938)

- False representation message/Number of omissions or false representations (2941)

- Levels of misrepresentation (12292)

- Penalty message / Warning message (2950): Select Warning message .

- Overpayment Messages (2452)

- Go to step 11.

- In ACS, create and save the D-17-03-00 letter to inform the client of the reconsideration and warning letter decisions. Based on the claim information, select all of the relevant attributes, including the following:

- False ROE(s) / False Information (2618)

- Number of invalid or false ROE(s) submitted (1668)

- Specify serial number of invalid or false ROE(s) (1672)

- Levels of Misrepresentation (12292)

- Penalty message / Warning message (2950): Select Warning message .

- Overpayment Messages (2452)

- In NWS, clear the client Note .

- Determine if a sanction also applies to a third party:

- If no, go to step 13.

- If yes, go to Implementing third party misrepresentation to impose the sanctions on the third party and to complete the case.
               [Implementing third party misrepresentation](/en/procedure/task/implementing_tp_misrepresentation.shtml)

- In NIIS, on the Decision tab of the Report of Investigation (IC50 or IC70) screen, clear the case as follows:

- Overpayment: Indicate whether an OP resulted from the misrepresentation.

- Reason: Select the appropriate option based on the decision that resulted in the OP.

- Amount: Enter the estimated total net OP that resulted from the misrepresentation.

- Penalty: Select No .

- Warning: Select Yes .

- Reason: Select the appropriate option.

- Violation: Select No .

- Complete the CR Integrity WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_3467.dita`

Note:

If the decision is to impose a D14, a recalculation is not required and the officer goes to Implementing the decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_3482.dita`

Note:

Multiple reconsideration decisions can be combined on one Operational Centre Memo (MM06) transaction, but a separate Operational Centre Memo (MM06) transaction is required for each BPC. 

#### Example

Source topic: `en_EN/common_notes/note_c_3483.dita`

Example:

WRN 12345678A9 

#### Warning

Source topic: `en_EN/common_notes/note_c_3459.dita`

Warning:

If the client declared earnings from another employment for a week that is being amended, combine the earnings for both employments for that week. Allocate the total earnings. 

#### Note

Source topic: `en_EN/common_notes/note_c_3484.dita`

Note:

For more transaction input help on allocations, disentitlements or disqualifications, refer to the specific issue that was reconsidered. 

#### Note

Source topic: `en_EN/common_notes/note_c_3465.dita`

Note:

If the case involves more than 52 weeks of unreported earnings, a D-91-00-00 letter is required for each calendar year. The warning letter information for the entire case is only included in the letter for the most recent calendar year. 

## Policy reference

Source topic: `en_EN/task/iam_cwl_bhc/policy_reference.dita`

- EIA 40
         [EIA 40](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-40.html)

- EIA 41.1
         [EIA 41.1](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-41.1.html) 
