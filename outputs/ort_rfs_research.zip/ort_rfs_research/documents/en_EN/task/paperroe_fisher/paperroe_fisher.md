# Entering data from a paper ROE — Fishing

Source map: `en_EN/task/paperroe_fisher/paperroe_fisher.ditamap`

## Summary

Source topic: `en_EN/task/paperroe_fisher/summary.dita`

Summary: An ROE is necessary to establish a claim for benefits to determine a client’s entitlement and eligibility. When a paper ROE is received, the data must be entered in RCM. When fraud indicators are present and the file is not already under investigation, the officer refers the file to Integrity. 

## What you need to know

Source topic: `en_EN/task/paperroe_fisher/what_you_need_to_know.dita`

### Paper ROEs

Source topic: `en_EN/task/paperroe_fisher/paper_roes.dita`

All paper ROEs submitted by mail or in person are scanned and sent to a GD mailbox to be uploaded to RMDS. ROEs that are uploaded to RMDS and are waiting to be input have a Pending status. Paper ROEs that cannot be scanned because they are damaged or illegible are sent to the processing centre to be input directly into RCM.

Paper ROEs that have the optional pay period worksheet attached cannot be scanned for input. They are sent to the processing centre to be input directly into RCM.

ROEs in the pending workload that Service Canada Centre (SCC) officers cannot input because they are complex or missing information have their status changed to Incomplete in RMDS. Duplicate, employer copy, and illegible ROEs also have their status changed to Incomplete . When the officer confirms the ROE is a duplicate, employer copy, or illegible the officer deletes the PDF file in RMDS.

Before entering a potentially fraudulent ROE in RCM, the SCC officer adds the following comment to the client Note in NWS “ROE [serial number] has been moved to the Incomplete workload in RMDS. ROE is potentially fraudulent.” When the ROE has already been flagged by Integrity as fraudulent, the SCC officer adds the following comment to the client Note in NWS: “ROE [serial number] has been moved to the Incomplete workload in RMDS. The BN for this ROE is under investigation for potential fraud.” The SCC officer does not enter the ROE in RCM, but does change the status to Incomplete in RMDS.

Before entering an ROE that has an Incomplete status in RMDS, in NWS, the Non-complex officer verifies if there is a client Note about a fraudulent ROE. If yes, the officer suspends the application process and refers the file to Integrity, if necessary, before inputting the ROE in RCM. Once the ROE is input in RCM, the officer deletes the ROE.

Non-complex officers input all ROEs with the Incomplete status. On request, Non-complex officers may be required to input ROEs with the Pending status.

Officers use RMDS to retrieve ROEs for input. When an ROE is opened in RMDS, RCM automatically opens in a split screen with the ROE for input.

Officers can refer to the RMDS User Guide .
       [RMDS User Guide](https://esdc.prv/en/service-canada/ei/frontline/roe-web/rmds/user-guide.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3340.dita) 

Errors made while entering data from a paper ROE into RCM could:

- prevent or delay claim automation;

- cause errors in claim calculation;

- increase the workload for users trying to identify and correct the errors.

Any corrections or notations to the ROE must be made in RCM and never directly on the paper version.

The serial number on a paper ROE for self-employed fishers begins with a Z .

Even if there is no application for benefits, all paper ROEs received must be entered. 

### ROEs uploaded by the client

Source topic: `en_EN/task/paperroe_fisher/roes_uploaded_by_the_client.dita`

Clients can submit ROEs using the document upload feature in AW and MSCA. The system accepts only ROEs beginning with A, E, K, L, and Z. The serial number is also mandatory. The system does not check whether the serial number already exists in RCM. The officer can view uploaded ROEs on the Uploaded Documents tab in NWS.

When clients upload ROEs in MSCA or in AW, an Action Item (AI) ROE Input WI is created in NWS. The officer completing the AI ROE Input WI views the ROE in NWS and inputs the ROE directly in RCM.

If the ROE requires corrections or notes, the officer performs the action in RCM.

This process does not involve RMDS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3341.dita) 

When clients upload their own paper ROE in AW or MSCA but the ROE was issued with the wrong SIN, officers fact-find with employers to confirm that they issued the ROE with the wrong SIN. Officers advise employers that a new or amended ROE is not required and they add an SROC in NWS confirming that the uploaded paper ROE with the wrong SIN belongs to the client.

When clients upload another client’s ROE in AW or MSCA, it cannot be moved under the correct SIN. Officers contact the team leader to remove the document from view. For more information, officers refer to Document upload: Updating documents — Instructions .
       [Document upload: Updating documents — Instructions](/en/procedure/generic/document_upload_updating_document_instruction.shtml) 

### Interim ROE

Source topic: `en_EN/task/paperroe_fisher/interim_roe.dita`

Under certain circumstances, interim ROEs can be entered to establish a claim when the ROE is not available or cannot be entered (e.g. serial number is partially legible and the ROE is not in Easy Access). RCM generates a serial number beginning with X9 for self-employed fishers interim ROEs. 

### Fraudulent paper ROEs

Source topic: `en_EN/task/paperroe_fisher/fraudulent_paper_roes.dita`

Even if the information on the ROE matches the information on the application, this does not mean that the application is authentic. Fraudulent ROEs can be paper, ROE Web or ROE SAT.

Fraudulent paper ROEs were created without the knowledge of the true SIN-holder and the employer associated with the Canada Revenue Agency (CRA) business number (BN) indicated in block 5 of the ROE. There are also instances where there are reasons to suspect that the business identified on the ROE is illegitimate or suspicious and was created to issue fraudulent ROEs. These fraudulent ROEs were sent to Service Canada and scanned as documents in support of fraudulent applications for benefits, or uploaded in AW or MSCA. A close examination may reveal a difference in the font and size of the characters in the serial number of these ROEs when compared to the normal format. In some cases, RCM validates the serial number and does not signal the ROE as a duplicate, because that serial number was used to establish an EI claim more than 11 years ago. In other situations, the serial number has been issued within the last 11 years to a different business number than the one used on the fraudulent ROE, however, RCM validates the serial number but does not flag it as a duplicate because the ROE was never used to establish an EI claim.

When a suspicious business is identified, an Integrity officer changes the status of suspicious employers to Under investigation in RMDS, and changes the status of any associated ROEs to Stolen . Then, a SROC is automatically created in NWS for the associated application, indicating that the claim is under investigation.

When entering an ROE that has been marked as stolen, a message is displayed indicating that there is a problem with the status of the serial number. The Non-complex officer follows normal procedures and submits the ROE with the error, which creates an ROE Correction WI.

When entering an ROE (paper, scanned or uploaded), the officer may suspect that an ROE is fraudulent even if no error message is displayed about the status of the serial number. Before entering the ROE in RCM, the officer suspends the application process, if necessary, and refers the file to Integrity, if the file is not already under investigation. If no fact-finding is required, the officer follows normal procedures and enters the ROE. Once the ROE is entered in RCM, the officer deletes the ROE.

For more information, officers refer to Fraud indicators: Identifying potentially fraudulent claims — Knowledge .
       [Fraud indicators: Identifying potentially fraudulent claims — Knowledge](/en/procedure/generic/additionalresources/fraud_indicator.shtml) 

### Amended ROE

Source topic: `en_EN/task/paperroe_fisher/amended_roe.dita`

Amended ROEs replace existing ROEs. Type the serial number of the ROE that has been amended or replaced exactly as shown in block 2 . 

### Fax or photocopy of a paper ROE

Source topic: `en_EN/task/paperroe_fisher/fax_or_photocopy_of_a_paper_roe.dita`

When it is clear that a fax or photocopy of a paper or scanned ROE is from the employer (e.g. on letterhead, with fax cover sheet from the employer or countersigned by the employer), the ROE is entered as an authentic ROE.

If the ROE’s origin cannot be confirmed, when entering the ROE, Fax or Photocopy is selected as appropriate. RCM is automatically defaulted to show Authentic ROE in the Fax or Photocopy field.

Never ask an employer to fax an ROE. The completed ROE is considered partially sensitive and is designated Protected B. 

### Altered ROE

Source topic: `en_EN/task/paperroe_fisher/altered_roe.dita`

An ROE that has been altered (i.e. information has been crossed out and replaced) and not initialled may not be valid. The changes must be verified to determine if the ROE is valid. Mandatory fields are verified before entering the ROE and non-mandatory fields are verified after data entry by a Non-Complex officer. 

### Invalid ROE

Source topic: `en_EN/task/paperroe_fisher/invalid_roe.dita`

A client or employer may submit a document that looks like a valid ROE but does not contain a valid serial number. Any document that is not a valid ROE is never entered in RCM, even as an interim ROE. The employer is contacted and asked to issue a valid ROE (paper or electronic). 

### Parts of a paper ROE

Source topic: `en_EN/task/paperroe_fisher/parts_of_a_paper_roe.dita`

There are 3 sections, or copies, of a paper ROE:

- Part 1 is the employee’s copy that is normally submitted to Service Canada for data entry.

- Part 2 is Service Canada’s copy that the employer sends to National Services in Bathurst, NB. Once input, these copies can be viewed in Easy Access.

- Part 3 is the employer’s copy that is retained in the employer’s files.

If part 2 or 3 of the ROE is submitted rather than part 1, it must still be entered. 

### Easy Access

Source topic: `en_EN/task/paperroe_fisher/easy_access.dita`

Easy Access stores copies of ROEs submitted by employers to Bathurst. If an ROE is missing or unreadable, some of the information from the ROE can be viewed and a copy can be obtained from Easy Access. 

### CRA business no. field

Source topic: `en_EN/task/paperroe_fisher/cra_business_no_field.dita`

This mandatory field must contain all 15 characters of the employer's business number (e.g. 123456789 RP 0001).

- The first 9 digits represent the employer's GST number and cannot match the client's SIN.

- The 2 letters must be “RP” on ROEs to indicate the employer's payroll program.

- The last 4 digits specify the employer's payroll account or department. 

### Entering an ROE

Source topic: `en_EN/task/paperroe_fisher/entering_an_roe.dita`

To illustrate the logical sequence for entering an ROE, and the procedures for correcting any corresponding issues, this task is divided into the following 6 sections:

**Section 1: Determine the ROE type (paper, scanned or uploaded)**

Officers who receive a faxed ROE from an employer or client, an uploaded ROE in NWS, or an ROE that cannot be scanned (illegible or damaged) can go to Section 3 to directly input the ROE into RCM without scanning it.

In NWS, the officer with an AI ROE Input WI views the ROE on the Uploaded Documents tab by selecting the correct ROE from available documents. The system identifies the serial number of the uploaded ROE in the Details field of the AI WI. The officer opens RCM to enter the ROE.

**Section 2: Retrieve an ROE from RMDS**

In RMDS, officers retrieve ROEs from one of the following workloads:

Incomplete: when retrieving the next oldest ROE to input that officers at the SCC cannot action.

In Progress: when retrieving an ROE that required fact-finding before input.

Pending: when retrieving the next oldest ROE to be input (only if the team leader informs officers to use this workload).

When a scanned ROE is selected in RMDS, the ROE and RCM open in a split screen for data entry.

**Section 3: Validate the ROE before data entry**

The following blocks are mandatory and must be complete or the ROE cannot be entered in RCM:

- block 1: Serial no.

- block 6B: Trip(s) end date (fresh) OR Date of purchase (cured) : Line 1 must be complete. ( Note : block 6A: Trip(s) start date does not have to be complete).

- block 7: CRA business no.

- block 9: Social insurance no.

Identify all errors or omissions in these blocks before fact-finding, to avoid multiple calls to the employer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3342.dita) 

Fact-finding is not in every officer’s work profile. If an officer receives an ROE that requires fact-finding to determine the mandatory fields, and fact-finding is not in the officer’s work profile, the officer changes the WI issue type to AI Communication WI. Then, the officer refers to Reassigning the WI — Fact-finding required .
       [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Reassigning)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3343.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3922.dita) 

### Section 4: Enter the SIN and serial number (Input short screen)

Source topic: `en_EN/task/paperroe_fisher/section_4_enter_the_sin_and_serial_numb_0b24b47b.dita`

After verifying that all mandatory blocks are complete, the officer can enter the ROE in RCM. The Input short screen displays the following fields:

- Social insurance no.

- Interim ROE type

- Serial no. (not mandatory for interim ROEs)

- Serial no. of the ROE amended or replaced

- Printing language: The default selection is the RCM display language.

Fax or photocopy ROE received from the employer: When it is clear that a fax or photocopy of an ROE is from the employer (e.g. on letterhead, with fax coversheet from the employer or countersigned by the employer), the ROE is entered as an authentic ROE. Do not select Fax or Photocopy . No follow-up with the employer is required.

Original ROE or serial number received after interim ROE has been input:

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3923.dita) 

Original ROE received after an amended ROE has been input:

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3924.dita) 

**Section 5: Enter the ROE (Input Fishing ROE screen)**

Blocks 1 , 2 (if completed) and 9 will be prefilled on this screen from the Input short screen.

Blocks 6B , 7 and 9 have already been verified in section 3. If further information is required during data entry, return to the blocks as outlined in section 3.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3345.dita) 

**Section 6: Finalize and submit the ROE**

This step allows the officer to quickly review the data entered to ensure it corresponds to the data from the paper ROE, and to correct any errors before submitting. After the ROE is submitted, RCM validates the ROE. If the ROE contains an error, it is highlighted in red on the Search/Correct - Results screen .

For initial claims, ACP generates an ROE Correction WI for the next available user when ROE errors are identified by RCM or by Automated Readiness Trigger for electronic ROEs (W, M or S series).

ACP does not use any ROEs (paper or electronic) that contain errors or issues that may impact the calculation of an initial claim. The claim remains in the ROE wait process until the related ROE WI is completed or until the wait limit is reached. 

### Note

Source topic: `en_EN/common_notes/note_c_3340.dita`

Note:

A faxed ROE from the client or the employer can be input directly in RCM without scanning. 

### Note

Source topic: `en_EN/common_notes/note_c_3341.dita`

Note:

Officers can work in both RMDS and NWS separately to enter ROEs in RCM, as required. 

### Note

Source topic: `en_EN/common_notes/note_c_3342.dita`

Note:

If a close examination reveals that a paper ROE may be fraudulent, the officer does not fact-find with the employer. The officer suspends the application process, if necessary, and refers the file to Integrity, if the file is not already under investigation. 

### Note

Source topic: `en_EN/common_notes/note_c_3343.dita`

Note:

Temporary workload measure: When fact-finding is required for the ROE, non-complex officers who are able to fact-find change the WI issue type to AI Communications WI before completing the WI. 

### Note

Source topic: `en_EN/common_notes/note_c_3922.dita`

Note:

If block 13 is completed, respect the language preference when contacting the employer. 

### Note

Source topic: `en_EN/common_notes/note_c_3923.dita`

Note:

If an employer provides the correct serial number or ROE after an interim ROE has been entered, enter the correct serial number or original ROE and complete the following fields:

- Serial no.: Type the serial number (provided by the employer) of the original ROE.

- Serial no. of ROE amended or replaced: Type the serial number of the interim ROE.

- Additional information: Type “Serial number of original ROE confirmed with employer after interim ROE input.” 

### Note

Source topic: `en_EN/common_notes/note_c_3924.dita`

Note:

If the original ROE is received after an amended ROE has been entered, complete the following field of the amended ROE:

- Additional information: Type “Original ROE serial XXXXXXXXX was received after amended ROE input. Cannot be data entered.”

- File the ROE .
         [File the ROE](/en/procedure/task/file_roe.shtml)

     [File the ROE](/en/procedure/task/file_roe.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3345.dita`

Note:

If ROE fields have been changed and not initialled by the employer, leave the corresponding fields in RCM blank. In the Additional Information field, type the details of the original and altered information for these fields. 

## Regional considerations

Source topic: `en_EN/task/paperroe_fisher/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/paperroe_fisher/what_you_need_to_look_for.dita`

## Step by step

Source topic: `en_EN/task/paperroe_fisher/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/paperroe_fisher/non-complex.dita`

#### Procedure

Source topic: `en_EN/task/paperroe_fisher/procedure.dita`

- Section 1: Determine the ROE type (paper or scanned or uploaded)
         [Section 1: Determine the ROE type (paper or scanned or uploaded)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#deter_ROE_type)

- Section 2: Retrieve an ROE from RMDS
         [Section 2: Retrieve an ROE from RMDS](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#retriveve_roe)

- Section 3: Validate the ROE prior to data entry
         [Section 3: Validate the ROE prior to data entry](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#validateROE)

- Section 4: Enter the SIN and serial number (Input short screen)
         [Section 4: Enter the SIN and serial number (Input short screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#EnterSIN)

- Section 5: Enter the ROE (Input Regular ROE screen)
         [Section 5: Enter the ROE (Input Regular ROE screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#EnterROE)

- Section 6: Finalize and submit the ROE
         [Section 6: Finalize and submit the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Finalize)

- Section 7: Reassigning the WI — Fact-finding required
         [Section 7: Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Reassigning)

- Section 8: Fraud indicators are present
         [Section 8: Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Fraud_indicators_are_present) 

#### Section 1: Determine the ROE type (paper or scanned or uploaded)

Source topic: `en_EN/task/paperroe_fisher/section_1_determine_the_roe_type_paper__39bbd105_non-complex.dita`

- Determine if the ROE was scanned or uploaded:

- If it is a scanned ROE, go to Section 2 .
               [Section 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#retriveve_roe)

- If it is a paper ROE that cannot be scanned, go to Section 3 .
               [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#validateROE)

- If it is an AI ROE Input WI for an uploaded ROE, go to Section 3 .
               [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#validateROE)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3925.dita) 

#### Section 2: Retrieve an ROE from RMDS

Source topic: `en_EN/task/paperroe_fisher/section_2_retrieve_an_roe_from_rmds_non-complex.dita`

- In RMDS, select the Scanned ROEs tab and do one of the following:

- To input ROEs that have an Incomplete status, go to step 2.

- To input ROEs that have a Pending status, go to step 3.

- To input ROEs that have an In Progress status, go to step 4.

- Select Search Scanned ROEs and do the following:

- PDF status: Select Incomplete.

- Language: Select the appropriate option.

- Select Search .

- Select View ROE . The ROE opens in a split screen with RCM. Go to Section 3 .
               [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#validateROE)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3926.dita)

- Select Process Scanned ROE and do the following:

- Select Next English PDF or Next French PDF . The ROE opens in a split screen with RCM.

- Go to Section 3 .
               [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#validateROE)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3348.dita)

- Select Search Scanned ROEs and do the following:

- SIN: Enter the client’s SIN.

- PDF status: Select In Progress .

- Language: Select the appropriate option.

- Select Search .

- Select View ROE . The ROE opens in a split screen with RCM.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3349.dita) 

#### Section 3: Validate the ROE before data entry

Source topic: `en_EN/task/paperroe_fisher/section_3_validate_the_roe_before_data_entry_non-complex.dita`

- Determine if block 1 is complete (i.e. serial number starts with a Z and is followed by 8 numbers):

- If block 1 is complete, go to Review block 6B: Trip end date or Date of purchase — line 1 .
               [Review block 6B: Trip end date or Date of purchase — line 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b6)

- If block 1 is not complete, go to one of the following:

- The serial number is incomplete .
                   [The serial number is incomplete](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#SNinc)

- The serial number is not valid (Invalid ROE) .
                   [The serial number is not valid (Invalid ROE)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#SNnv)

- Determine if the ROE is displayed in Easy Access:

- If the ROE is displayed, use the serial number shown when entering the ROE. As there may be multiple ROEs, ensure that the correct one is selected. Go to Review block 6B: Trip end date or Date of purchase — line 1 .
               [Review block 6B: Trip end date or Date of purchase — line 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b6)

- If the ROE is not displayed, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to obtain the complete serial number:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita) 

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Reassigning)

- If the serial number is obtained, use that serial number when entering the ROE. Go to Review block 6B: Trip end date or Date of purchase — line 1 .
               [Review block 6B: Trip end date or Date of purchase — line 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b6)

- If the serial number is not obtained, go to step 3.

- Enter the ROE as an interim ROE (after verifying that blocks 6B, 7 and 9 are complete) by completing the following fields:

- Interim ROE type: Select Fishing Interim .

- Additional information: Type “The serial number is illegible so the original ROE could not be input.”

- Go to Review block 6B: Trip end date or Date of purchase — line 1 .
               [Review block 6B: Trip end date or Date of purchase — line 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b6)

- Determine if block 6B is complete:

- If block 6B is complete, go to Review block 7: CRA business no .
               [Review block 7: CRA business no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#block7)

- If block 6B is not complete, or has been altered but not initialled, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to determine the trip end date (or date of purchase).

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Reassigning)

- If the trip end date is obtained, use that date and complete the following field when entering the ROE:

- Additional information: Type “The correct trip end date was obtained from the employer [employer’s name].”

- Go to Review block 7: CRA business no .
                   [Review block 7: CRA business no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#block7)

- If the trip end date is not obtained, go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita)

- In ACS, send a Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334)

- Employer or Third Party Address (1336)

- Employer or Third Party Address (2440)

- Employer or Third Party Address (2441)

- To whom it may concern – Madam or Sir – Madam – Sir – Text ( 2418)

- Opening Sentence to ER re: Request or Clarify ROE/RFS ( 2794)

- Request ROE Opening Sentence – claimant

- Claimant First Name (1044)

- Claimant Last Name (1046)

- Request for Record of Employment (2797)

- Request for Additional ROE Information

- Text – Free Text (2797): Type, “Please provide us with the trip end date for the following ROE: ZXXXXXXXX.”

- This Letter Replaces or Footnote (2365):

- Footnote: Type in bold text “ Instead of replying by mail, if you prefer, you can provide the information to [your name] by telephone at [your telephone number]. ”

- Attachment List for Z-02-00-00: select

- Employer’s Response for Additional ROE Information .

- In NWS, create a Reminder (REM) WI to follow up on the letter sent to the employer and complete the following fields:

- Complexity: Select Non-complex .

- Reason: Select Fact-Finding Employer .

- Comments: Type “last day paid information.”

- Due Date: Enter today’s date + 10 working days.

- Language: Select the appropriate option based on the preferred language of employer.

- Destination: Select the SCC as shown in FTS.

- End User: Select Myself .

- When the REM WI comes out of pending, or if the employer returns contact, determine if the employer has provided the trip end date:

- If the employer has provided the date, use that date and complete the following field when entering the ROE:

- Additional information: Type “The correct trip end date was obtained from employer [employer’s name].”

- Go to step 8.

- If the employer has not provided the date, go to step 6.

- Contact the client to obtain the trip end date:

- If the client provides the date, use that date and complete the following field when entering the ROE:

- Additional information: Type “The correct trip end date was obtained from the client.”

- Go to step 7.

- If the date is not obtained or if the client is not reached:

- Complete the REM WI.

- Refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
                   [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- In ACS, send a Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334)

- Employer or Third Party Address (1336)

- Employer or Third Party Address (2440)

- Employer or Third Party Address (2441)

- To whom it may concern – Madam or Sir – Madam – Sir – Text (2418)

- Notification of Changes to a ROE (2805): select one of the following

- Multiple Changes to ROE

- A Single Change to ROE

- We (2687)

- List of corrections / attached INS 3413 (2806): select List of corrections and type “The trip end date has been changed to [dd/mm/yyyy].” (Provide the date given by client).

- In NWS, complete the REM WI.

- Determine if block 7 is complete (i.e. the business number is 9 digits, followed by the payroll account number):

- If block 7 is complete but the first 9 digits of block 7 match the client’s SIN, verify the employer’s business number. Go to First 9 digits of block 7 match the SIN .
               [First 9 digits of block 7 match the SIN](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#first9match)

- If block 7 is not complete, go to one of the following:

- Block 7 is incomplete or has been altered without being initialled .
                   [Block 7 is incomplete or has been altered without being initialled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b7)

- All or part of the payroll program account number (e.g. RP0001) is missing .
                   [All or part of the payroll program account number (e.g. RP0001) is missing](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#RP0001)

- In FTS, select the Employer (MN22) search and type the employer’s name:

- If the search by employer name displays the business number and it is different than the SIN, use that business number when entering the ROE. Go to Review block 9: Social insurance no .
               [Review block 9: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b9)

- If the search by employer name displays the business number and is the same as the SIN, go to step 3.

- If the search by employer does not display the business number, go to step 2.

- In RCM, determine if the client has worked for the same employer previously. The business number may be on the prior ROE.

- If the business number is displayed on a previous ROE for the same employer and is different than the SIN indicated on the ROE, use that business number when entering the ROE. Go to Review block 9: Social insurance no .
               [Review block 9: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b9)

- If there are no other ROEs for that employer or if the business number displayed in the results is the same as the SIN, go to step 3.

- In FTS, select the Claimant (MN04) search and enter the client’s last and first name:

- If the SIN is displayed in the results and is different than the SIN indicated on the ROE, use that SIN and complete the following field when entering the ROE:

- Additional information: Type “Correct SIN obtained from FTS.”

- Go to Review block 9: Social insurance no .
                   [Review block 9: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b9)

- If the SIN is not displayed in the results, go to step 4.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to obtain the correct business number or SIN.

- If the correct business number or SIN is obtained, go to Review block 9: Social insurance no .
               [Review block 9: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b9)

- If the correct business number or SIN is not obtained, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita)

- In FTS, select the Employer (MN22) search and type the employer’s name:

- If the search by employer name displays the business number, use that business number when entering the ROE and go to Review block 9: Social insurance no .
               [Review block 9: Social insurance no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b9)

- If the search by employer name does not display the business number, go to step 2.

- In RCM, determine if the business number is displayed on a previous ROE from this employer:

- If the business number is displayed on a previous ROE, use that business number when entering the ROE. Go to Review block 9: Social insurance no.
               [Review block 9: Social insurance no.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b9)

- If there are no other ROEs from this employer, go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to obtain the business number:

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Reassigning)

- If the business number is obtained, use that business number when entering the ROE and go to Review block 9: Social insurance no.
               [Review block 9: Social insurance no.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b9)

- If the business number is not obtained, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3927.dita)

- In FTS, select the Employer (MN22) search and type the first 9 digits of the business number:

- If the search by business number displays only one business number, use that business number when entering the ROE and go to Review block 9: Social insurance no.
               [Review block 9: Social insurance no.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b9)

- If the search by business number displays more than one business number, go to step 2.

- In RCM, determine if the business number is displayed on a previous ROE from this same employer:

- If the business number is displayed on a previous ROE, use that business number when entering the ROE. Go to Review block 9: Social insurance no.
               [Review block 9: Social insurance no.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b9)

- If there are no other ROEs for that employer, go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to obtain the correct business number:

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Reassigning)

- If the business number is obtained, use that business number when entering the ROE and go to Review block 9: Social insurance no.
               [Review block 9: Social insurance no.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b9)

- If the business number is not obtained, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita)

- Determine if block 9 is complete:

- If block 9 is in complete or has been altered and not initialled, go to step 2.

- If block 9 is complete, do the following based on the situation:

- If the SIN starts with a 0 or an 8, go to step 2.

- If the SIN does not start with a 0 or an 8, go to Section 4: Enter the SIN and serial number (Input short screen) .
                   [Section 4: Enter the SIN and serial number (Input short screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#EnterSIN)

- If the client uploaded a paper ROE in AW or MSCA and the ROE has been issued with the wrong SIN, go to step 4.

- In FTS, select the Claimant (MN04) search and enter the client’s last and first name:

- If the SIN is displayed in the results, use that SIN when entering the ROE and complete the following field when entering the ROE:

- Additional information: Type “Correct SIN obtained from FTS.”

- Go to Section 4: Enter the SIN and serial number (Input short screen) .
                   [Section 4: Enter the SIN and serial number (Input short screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#EnterSIN)

- If the SIN is not displayed in the results, go to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3352.dita)

- Fact-find with the employer to obtain the SIN:

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Reassigning)

- If the SIN is obtained from the employer, use that SIN when entering the ROE and go to Section 4: Enter the SIN and serial number (Input short screen) .
               [Section 4: Enter the SIN and serial number (Input short screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#EnterSIN)

- If the SIN is not obtained from the employer, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Fact-find with the employer to confirm the client’s uploaded ROE was issued with the wrong SIN:

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Reassigning)

- If the SIN is confirmed with the employer, go to step 5.

- If the SIN is not confirmed with the employer, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “SIN confirmed for uploaded ROE — employer contact [employer’s name] — [last day worked (LDW)].

- Details: Type “Employer confirmed the uploaded ROE [serial number] was issued with the wrong SIN. The ROE belongs to the client.” Document the fact-finding details according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](http://servicecanada.prv/eng/ei/reference-material/policy-legislation/national_policy_factfinding.shtml#5.4)

- Select Save .

- Go to Section 4: Enter the SIN and serial number (Input short screen) .
                   [Section 4: Enter the SIN and serial number (Input short screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#EnterSIN)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita) 

#### Section 4: Enter the SIN and serial number (Input short screen)

Source topic: `en_EN/task/paperroe_fisher/section_4_enter_the_sin_and_serial_numb_0b24b47b_non-complex.dita`

- On the Input short screen, complete the fields as follows:

- Social insurance no .: Type the SIN verified in section 3.

- Interim ROE type: If the serial number is incomplete, select Fishing Interim . If this choice is selected, leave the Serial No . field and the Serial number of ROE amended or replaced field blank.

- Serial no .: Type the serial number verified in section 3.

- Serial no. of the ROE amended or replaced: If block 2 is complete, enter the serial number of the ROE amended or replaced.

- Select Submit .

- Determine if an error message is displayed:

- If no error message is displayed, go to Section 5: Enter the ROE (Input Fishing ROE screen) .
               [Section 5: Enter the ROE (Input Fishing ROE screen)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#EnterROE)

- If an error message is displayed, go to the appropriate section below:

- Error message: Invalid Social Insurance Number or Social insurance number must be 9 numeric characters and not all zeros
                   [Invalid Social Insurance Number or Social insurance number must be 9 numeric characters and not all zeros](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#EM1)

- Error message: Invalid Serial Number
                   [Invalid Serial Number](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#EM2)

- Error message: Serial Number already exists for that SIN in the ROE database
                   [Serial Number already exists for that SIN in the ROE database](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#EM3)

- Error message: This Serial Number (SN) has already been entered for another Social Insurance Number (SIN) or A problem was detected with the status of this Serial Number (SN)
                   [This Serial Number (SN) has already been entered for another Social Insurance Number (SIN) or A problem was detected with the status of this Serial Number (SN)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#serial)

- Verify if the ROE received is the original ROE, and if it is replacing a faxed or photocopied ROE that has been entered in RCM:

- If the ROE is the original and it is replacing a fax or photocopy that has been entered, go to step 2.

- If the ROE is not the original or is not replacing a fax or photocopy that has been entered, return to Review block 1: Serial no .
               [Review block 1: Serial no](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#b1)

- Open the ROE in RCM to verify if the information on the ROE received is the same as the information on the fax or photocopy that was entered:

- If the information is the same, complete the following field:

- Fax or photocopy: Select Authentic ROE .

- Additional information: Type “Original ROE received, compared to fax or photocopy and is in order.”

- Select Submit .

- Go to section 6, step 5: Determine how to file the ROE .
                   [Determine how to file the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#fileROE)

- If the information is not the same, go to step 3.

- Determine if the changes from the initial ROE have been noted in the audit trail:

- If the changes have been noted in the audit trail, complete the following fields:

- Fax or photocopy: Select Authentic ROE .

- Additional information: Type “Original ROE received, compared to fax or photocopy, changes noted in audit trail.”

- Select Submit .

- Go to section 6, step 5: Determine how to file the ROE .
                   [Determine how to file the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#fileROE)

- If the changes have not been noted, continue to step 4.

- Fact-find with the employer to confirm the changes:

- If fact-finding is not in your work profile, go to Reassigning the WI — Fact-finding required .
               [Reassigning the WI — Fact-finding required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Reassigning)

- If the employer confirms the changes, complete the following fields:

- Fax or photocopy: Select Authentic ROE .

- Additional information: Type “Original ROE received, confirmed changes in fax or photocopy with employer (include the name of the person contacted).”

- Go to section 6, step 5: Determine how to file the ROE .
                   [Determine how to file the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#fileROE)

- If the employer does not confirm the changes, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita) 

#### Section 5: Enter the ROE (Input Fishing ROE screen)

Source topic: `en_EN/task/paperroe_fisher/section_5_enter_the_roe_input_fishing_roe_screen.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3928.dita) 

Enter the blocks of the ROE as follows:

Block 3: Employer’s payroll reference no.: This optional block is for the employer’s referencing purposes.

- If completed, type the reference number as provided.

- If not completed, leave blank.

Block 4: Employer’s name and address:

- If completed, type the employer’s name and address as provided.

- If the employer’s name is absent or illegible, do the following:

- In FTS, select the Employer (MN22) search and type the employer’s business number:

- If the employer’s name is found, type it in the Employer’s name field.

- If the search by business number displays does not display the employer’s name, fact-find with the employer to obtain it.

- If the employer’s name is obtained, in the Additional information field, type “Employer’s name obtained from employer (include the name of the person contacted).”

- If the employer’s name is not obtained, leave blank.

                 [fact-find](/en/procedure/task/fact_find.shtml)

- If the employer’s address is absent or illegible, leave blank.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3351.dita) 

Block 5: Employer’s postal code:

- If completed, type the postal code as provided.

- If not completed, leave blank.

Block 6:

- 6A: Trip(s) start date (dd/mm/yyyy):

- If completed, type the dates as provided.

- If not completed, leave blank.

- 6B: Trip(s) end date (fresh) or Date of purchase (cured):

- Type the date verified in section 3.

- 6C: $. Share of insurable earnings:

- If completed, type the amount provided.

- If not completed, leave blank.

Block 7: CRA business no .

- Enter the business number.

Block 8: Employee’s name and address:

- If completed, type the employee’s name and address as provided.

- If the employee’s name is missing, do the following:

- Type the SIN into the appropriate field in FTS to obtain the client’s name. If the employee’s identity is not verified, refer the ROE to Integrity. Go to Creating or reassigning a WI — Integrity .
             [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If the address is illegible or partially incorrect, type the address provided in the application for benefits (if one exists) or leave blank.

Block 9: Employee’s SIN:

- The SIN is prefilled from the Input short screen.

Block 10: Commercial fishing vessel number (CFVN):

- If completed, type the number as provided.

- If not completed, leave blank.

Block 11: Reason for issuing this ROE:

- If the reason for issuing the ROE is B - Other , review block 12 for comments explaining the reason for separation (RFS).

Block 12: Comments:

- If the comments indicate “requested by fisher,” complete the fields as follows:

- Reason for separation: Select A - Requested by Fisher (change from B - Other ).

- Comments: Leave the field blank.

- Additional information: Enter the comments from block 12.

- If the comments indicate a non-contentious RFS (e.g. end of season or issued on request by Service Canada), complete the fields as follows:

- Reason for separation: Select A - End of fishing (change from B - Other ).

- Comments: Leave blank.

- Additional information: Type the comments from block 12 .

- Type all other comments in block 12 as provided.

Block 13:

Communication preferred In English or French:

- If completed, select English or French as provided.

- If not completed, leave blank.

Signature / Name of Issuer (please print): A computer generated ROE requires the printed name only. A signature is required only if the issuer makes changes on the hard copy of the ROE. In this case, the changes must also be initialled. No follow-up is needed when the issuer signs the ROE but does not complete the Name of issuer (please print) field.

- Enter the name of the issuer as shown.

- If the ROE has been computer-generated and does not have a signature, leave blank.

- If the ROE has been completed by hand with no signature, complete the following field:

- Status: Check the Unsigned box.

- If the ROE is signed by the client, complete the following fields:

- Comments: Type “signed by client.”

- Status: Check the Unsigned box.

Telephone number:

- If completed, enter the telephone number as provided.

- If not completed, Type “000 0000000.”

Block 13A: Date issued:

- If completed, enter the date as shown.

- If the issue date is incomplete or blank, do the following:

- If the date of receipt is known, complete the following fields:

- Enter the date that the ROE is received.

- Additional information: Type “Issue date is blank or incomplete and the date of receipt was entered.”

- If the date of receipt is unknown, complete the following fields:

- Date issued: Leave blank. The ROE will be saved to RCM with the current date as the issue date.

- Additional information: Type “Issue date is blank or incomplete and the date of receipt is unknown.”

Status:

- For data entry purposes, this field is used only in the following situations:

- The serial number has been entered incorrectly under the correct SIN (check Delete ).

- The ROE has been entered under the wrong SIN (check Delete ).

- The ROE has been completed by hand and is not signed by the issuer.

- The ROE has been signed by the client.

Fax or Photocopy:

- If the authenticity of a fax or photocopy ROE is confirmed (i.e. it is clearly from the employer), leave the default selection of Authentic ROE .

- If the authenticity of a fax or photocopy ROE is not confirmed, select Fax or Photocopy as appropriate. 

#### Section 6: Finalize and submit the ROE

Source topic: `en_EN/task/paperroe_fisher/section_6_finalize_and_submit_the_roe_non-complex.dita`

- Select Submit .

- Determine if the following error message is displayed: Please review the errors on the page. Are you sure you want to submit the ROE as shown?

- If the error message is not displayed, go to step 3.

- If the error message is displayed, verify that the data entered accurately reflects the information on the paper ROE:

- If the information is accurately reflected, select Yes to submit the ROE. Go to step 3.

- If the information is not accurately reflected, select No to return to the input screen and correct the errors.

- Return to step 1.

- Determine if the ROE is potentially fraudulent:

- If yes, go to step 4.

- If no, go to step 5.

- In RCM, open the ROE and delete it as follows:

- Delete: Check the box.

- Additional information : Type “Suspicious ROE. ROE has been deleted to prevent it from being used in benefits calculation until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit.

- Go to step 5.

- Determine how to file the ROE:

- If the ROE was scanned and uploaded to RMDS and it is a duplicate, employer copy or illegible delete the PDF file in RMDS as follows:

- Select Scanned ROE .

- Select Search Scanned ROE .

- SIN: Enter the client’s SIN.

- PDF Status: Select Incomplete .

- Select Search .

- Open the ROE by selecting View ROE .

- Select Delete Backpage .

- No further action is required.

- If the ROE was viewed and input in RCM from the Uploaded Documents tab in NWS:

- If fact-finding was conducted, ensure that the WI issue type has been updated to AI Communications WI and complete the WI.

- If no fact-finding was necessary, complete the AI ROE Input WI.

- If the paper ROE is a fax, photocopy or part 1, refer to Preparing documents for imaging to send the ROE to Imaging to be put in the PA pile.
               [Preparing documents for imaging](/en/procedure/task/prep_docs_imaging.shtml)

- If the paper ROE is part 2 and the authenticity of the ROE is not in doubt, mail the original to Bathurst at the following address: NICOLAS DENYS BUILDING 120 HARBOURVIEW BOULEVARD BATHURST NB E2A 7R2

- If the paper ROE may be fraudulent, refer to Preparing documents for imaging to send the ROE to Imaging to be put in the PA pile.
                   [Preparing documents for imaging](/en/procedure/task/prep_docs_imaging.shtml)

- If the paper ROE is part 3 and the authenticity of the ROE is not in doubt, return it to the employer address provided in block 4 .

- If the paper ROE may be fraudulent, refer to Preparing documents for imaging to send the ROE to Imaging to be put in the PA pile.
                   [Preparing documents for imaging](/en/procedure/task/prep_docs_imaging.shtml) 

#### Section 7: Reassigning the WI — Fact-finding required

Source topic: `en_EN/task/paperroe_fisher/section_7_reassigning_the_wi__fact-find_3d99d956_non-complex.dita`

- In NWS, reassign the AI ROE Input WI as follows:

- On the Specific Details tab, do the following:

- Issue: Select Communications .

- Select Save .

- Reassign the WI as follows:

- Destination: Select Next available user .

- Reason: Select Unable to complete .

- Details: Type “Requires fact-finding, not within officer’s work profile.”

- Select OK . 

#### Section 8: Fraud indicators are present

Source topic: `en_EN/task/paperroe_fisher/section_8_fraud_indicators_are_present_non-complex.dita`

- In NWS, determine if any of the following WIs are on file:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2922.dita) 

- If no, go to step 2.

- If yes, go to step 20.

- Determine if any of the following are on file and directly related to the potentially fraudulent application:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2923.dita) 

- If no, go to step 3.

- If yes, go to step 6.

- In NWS, determine if a suspected fraud has previously been referred to Integrity in an AI WI that has not been completed:

- If yes, go to step 4.

- If no, go to step 5.

- Add the information related to the potentially fraudulent application to the existing Integrity AI WI as follows:

- Right-click and select Add details/Further Inquiry .

- Action: Select Additional Information

- Details: If a fraudulent application has been completed, type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” Type “ROE [serial number] with business number [CRA business number] contains inconsistencies .” If the ROE could not be entered, type “ROE cannot be entered.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 – ID Validation , select the region where the client lives:

- Processing - ATL

- Processing - QC

- Processing - ON

- Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue(s): Select ROE .

- Comments: Type “Fraud suspected — indicators present.”

- Select Save .

- Details: If a fraudulent application has been completed, type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” Type “ROE [serial number] with business number [CRA business number] contains inconsistencies .” If the ROE could not be entered, type “ROE cannot be entered”. If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- In FTS, determine if the initial claim has already been calculated:

- If yes, go to step 7.

- If no, go to step 13.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If no, go to step 8.

- If yes, go to step 11.

- In FTS, determine if there is an outstanding renewal registration number:

- If yes, go to step 9.

- If no, go to step 10.

- In NWS, determine if the outstanding renewal registration number is related to the fraudulent application:

- If yes, go to step 10.

- If no, go to step 20.

- Determine if the client’s claim has been compromised:

- If yes, go to step 11.

- If no and there is an outstanding renewal registration number related to the fraudulent application, go to step 19.

- If no and there is no outstanding renewal registration number related to the fraudulent application, go to step 20.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2651.dita)

- Determine if an MA71 has already been imposed:

- If no, go to step 12.

- If yes and there is an outstanding renewal registration number  related to the fraudulent application, go to step 19.

- If yes and there is no outstanding renewal registration number related to the fraudulent application, go to step 20.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Do the following:

- If there is an outstanding registration number related to the fraudulent application, go to step 19.

- If there is no outstanding registration number related to the fraudulent application, go to step 20.

- Determine if there is an outstanding initial registration number:

- If yes, go to step 14.

- If no, go to step 20.

- In NWS, determine if the outstanding initial registration number is related to the fraudulent application:

- If yes, go to step 15.

- If no, go to step 20.

- Determine if a D71 has already been imposed:

- If no, go to step 16.

- If yes, go to step 17.

           [Important](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3223.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

- Go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3929.dita)

- In NWS, determine if the Claim action status is Finalized - Pending LREM :

- If yes, go to step 18.

- If no, go to step 19.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- Go to step 20.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1576.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the registration number related to the fraudulent application as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 20.

- In RCM, determine it the ROE can be entered:

- If yes, return to step 1 of Section 6: Finalize and submit the ROE.
               [Section 6: Finalize and submit the ROE.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Finalize)

- If no, take the following action based on the situation:

- If it is an uploaded ROE, go to step 21.

- If it is a scanned ROE, change the status in RMDS to In Progress . No further action is required.

- If it is a fax, photocopy or paper ROE (part 1, 2 or 3), return to step 5 of Section 6: Finalize and submit the ROE .
                   [Section 6: Finalize and submit the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/paperroe_fisher#Finalize)

- In NWS, complete the AI ROE Input WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_3925.dita`

Note:

If an ROE was scanned and is illegible, send an email to the GD mailbox the scan came from and request a copy of the ROE. If the copy that is then received is also illegible, refer to Section 6, step 5 to delete the PDF file.
       [Section 6, step 5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fileROE)

If an ROE was uploaded and is illegible, validate the ROE with the client or employer. Refer to Section 3 .
       [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#validateROE)

If the uploaded ROE is illegible and fact-finding to validate the ROE is not in your work profile, change the WI issue type to AI Communications WI and reassign the WI to the next available user in NWS.

     [Section 6, step 5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fileROE) 
     [Section 3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#validateROE) 

#### Note

Source topic: `en_EN/common_notes/note_c_3926.dita`

Note:

If the scanned document is a blank page or a page other than an ROE, delete it by selecting Delete Backpage . Refer to Section 6, step 5 .
       [Section 6, step 5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fileROE)

If fact-finding is required at any time during the input of a scanned ROE, change the status of the ROE to In Progress . This status signals to officers that the ROE input is currently being actioned by another officer.

     [Section 6, step 5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fileROE) 

#### Note

Source topic: `en_EN/common_notes/note_c_3348.dita`

Note:

If fact-finding is required at any time during the input of a scanned ROE, change the status of the ROE to In Progress . This status signals to officers that the ROE input is currently being actioned by another officer. 

#### Note

Source topic: `en_EN/common_notes/note_c_3349.dita`

Note:

If the client’s SIN is not known, search by PDF status and locate the ROE by the client’s name. 

#### Note

Source topic: `en_EN/common_notes/note_c_3352.dita`

Note:

If a paper ROE may be fraudulent, do not fact-find with the employer or enter the ROE. Refer to Section 8: Fraud indicators are present .
       [Section 8: Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fraud_indicators_are_present)

     [Section 8: Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#fraud_indicators_are_present) 

#### Note

Source topic: `en_EN/common_notes/note_c_3351.dita`

Note:

If it is a scanned ROE and a callback is required or the ROE is sent to Integrity, change the status in RMDS to In Progress .

If it is an uploaded ROE and a callback is required or the ROE is sent to Integrity, move the AI ROE Input WI to Pending following normal procedures. Refer to Fact-Finding or Creating or reassigning a WI — Integrity , if necessary.
       [Fact-Finding](/en/procedure/task/fact_find.shtml) 
       [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

     [Fact-Finding](/en/procedure/task/fact_find.shtml) 
     [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_3927.dita`

Note:

If it is a scanned ROE and a callback is required or the ROE is sent to Integrity, change the status in RMDS to In Progress . 

#### Note

Source topic: `en_EN/common_notes/note_c_3928.dita`

Note:

If, after selecting Submit , it is clear that the serial number was entered incorrectly but under the correct SIN, complete the following fields:

- Status: Check the Delete box.

- Additional information: Type “ROE deleted — originally entered under incorrect serial number.”

- Select Submit .

Return to the Input short screen and enter the ROE using the correct serial number. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2922.dita`

- a Claim Review (CR) Integrity ERB-EI Transition WI related to the potentially fraudulent application;

- an AI WI from Integrity indicating that the claim can be established;

- a Call Back (CB) WI about the potentially fraudulent application. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2923.dita`

- an Integrity AI WI;

- an Integrity SROC;

- a 71 - Integrity Services case disentitlement (D71) or a 71 - Integrity Services case manual action (MA71);

- in RMDS, on the Employer profile screen, the Under investigation box is checked. 

#### Note

Source topic: `en_EN/common_notes/note_c_2651.dita`

Note:

A claim is considered to be compromised when the client’s information (address or direct deposit information) has been changed. If the claim is compromised, impose an MA71. 

#### Important

Source topic: `en_EN/common_notes/note_c_3223.dita`

Important:

Before imposing a D71, confirm that the file does not already include one. In such cases, if a transaction is input to impose a D71, the existing D71 is cancelled. 

#### Note

Source topic: `en_EN/common_notes/note_c_3929.dita`

Note:

If error code C072: Invalid Claim action or Action field (C072) is displayed when inputting the Renewal/Revised (M106) transaction, the D71 cannot be imposed. Go to step 17. 

#### Note

Source topic: `en_EN/common_notes/note_c_1576.dita`

Note:

If error code 836: WARNING - Flag 33 claim (Last Record of Employment Missing), claim is still polling for the last record of employment is displayed when attempting to clear the registration number, check the Override box to process the transaction. 

## Policy reference

Source topic: `en_EN/task/paperroe_fisher/policy_reference.dita`

 
