# Implementing a decision — Income review on EI ERB claims

Source map: `en_EN/task/imp-dec-inc-rev-eierb/imp-dec-inc-rev-eierb.ditamap`

## Summary

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/summary.dita`

Summary: When it has been determined that income exceeds $1 000 over a 4-week period on an EI ERB claim or a full work week (FWW) or found work code must be removed , the officer inputs the decision for the 2-week period under review and notifies the client. 

## What you need to know

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/what_you_need_to_know.dita`

### Implementing a decision

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/implementing_a_decision.dita`

To implement a decision when income exceeds $1 000 over a 4-week period, the officer does the following:

- inputs the disentitlements for the 2-week periods under review to establish the overpayment (OP);

- removes the FWW or found work code, if necessary;

- sends the decision letter;

- clears the case in NIIS;

- completes the WI in NWS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3505.dita) 

### Imposing a disentitlement

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/imposing_a_disentitlement.dita`

If the client’s income exceeds $1 000 in a 4-week period, the officer imposes a 47 - EI ERB - Earnings limit exceeded for the four week period disentitlement (D47) in BCS. The officer imposes a D47 only for the 2-week period under review . 

### Error code B112

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/error_code_b112.dita`

If the client received the $2 000 advance payment, the officer reviews the Emergency Response Benefits screen in FTS to determine which code is displayed. Some of the lump sum payment modification codes are:

- A - Removed - SIN change

- B - Added - SIN change

- C - Cancelled

- D - Established as overpayment

- E - Received twice

- F - Received three or more times

- G - Removed - Victim of a third party fraud

- I - Removed - Exceptional or multiple condition(s) / Non-fraud third party overpayment

- N - $1500 established as overpayment

- P - $1000 established as overpayment

- Q - $500 established as overpayment

The OP created by the disentitlement does not include the $2 000 advance payment,if it was paid. If the $2 000 advance payment was issued and the lump sum payment modification code is C , D , G , or I , the officer imposes the disentitlement in BCS. If the lump sum payment modification code is blank, B , N , P or Q , the officer may have to send the information to IPOC on an Operational Centre Memo (MM06) transaction.

The processing officer inputs transactions in BCS but may receive error code B112 . This code prevents amendments to the file before the 65 - Lump Sum Payment ($2000) - Canadian Emergency Response code (D65) logic is removed from the claim. If the officer receives error code B112 after attempting to input transactions in BCS, the officer sends an MM06 to request IPOC intervention. The IPOC officer updates the lump sum payment modification code to D and inputs the remaining transactions.

For more information on the lump sum payment modification code, the officer refers to COVID-19: Emergency Response Advance Payment Modification — Knowledge .
       [COVID-19: Emergency Response Advance Payment Modification — Knowledge](/en/procedure/generic/covid19_emergency_response_lump_sump_payment_modification_knowledge.shtml)

If a W - Earnings week 1 allocation is on file, the officer inputs an A - Amended earnings allocation in BCS with 0000 in the Earnings field. 

### Error code C237

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/error_code_c237.dita`

Error code C237 is displayed when the officer attempts to reactivate an EI ERB claim in FTS because the BPC is equal to or greater than the current week – 155 . This means that EI ERB claim updates can only be done using BCS when the blocked status shows 1 - Updateable . IPOC intervention is required for any other blocked status. 

### Inputs on a blocked claim — BCS

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/inputs_on_a_blocked_claim__bcs.dita`

Certain types of transactions can be processed on blocked dormant claims in BCS. There are 2 options available: Estimate and Claim update . 

### Claim update function

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/claim_update_function.dita`

When transactions must be input on a blocked claim, the officer reviews the Blocked Claims System tab in FTS to determine the BCS status. If the CS is 1 - Updateable , the officer requests an update using BCS and the transactions can be processed.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3506.dita) 

In BCS, only one BPC can be updated at a time. When transactions are input but not processed, Yes appears in the Block Action Pending column and access is denied for input on all other BPCs until the requested transactions are processed. Access to a BPC with a pending action is limited to the officer who initiated that action.

If the officer requests an update that cannot be completed by BCS, on the next processing day, the message Blocked claim not updated or not calculated is displayed along with the exception, error or warning on the Rejected Transactions Retrieval (MR05) screen.

The officer reviews the exception, error or warning on the Results tab in BCS for further action. If the update cannot be completed using BCS, the system presents an estimate result. If the officer receives error code B112 , the officer creates an MM06 using a Renewal/Revised (M106) transaction. For other errors, the officer reviews WECS and re-inputs the transactions in BCS, or if necessary, sends the decision to IPOC using the Forward via MM06 link, which creates the prefilled M106 and MM06 transactions.
       [WECS](http://wecs-siew.prv/wecs-siew/lookup_e.aspx) 

### Estimate function

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/estimate_function.dita`

The Estimate function in BCS allows the officer to view and evaluate the end results without processing the transactions. Estimates are possible for blocked claims with a CS 1 - Updateable as well as unblocked dormant claims, if the CS is 5 (inactive) or 6 (terminated) .

BCS Estimate transactions are processed overnight and the results are available on the Results vtab the next day. Officers who have requested an estimate can view the end result and forward the request for IPOC intervention using the prefilled MM06 available on the Results tab. 

### Creating an Operational Centre Memo (MM06) transaction

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/creating_an_operational_centre_memo_mm0_3297a7ef.dita`

The officer creates an MM06 when it is not possible to impose the disentitlement in BCS. 

### Completing the case in NIIS

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/completing_the_case_in_niis.dita`

The officer accesses NIIS to review selected information and to complete cases when a decision is required on income. Although the decision is documented in NWS, the officer must complete the Decision tab on the Report of Clerical Investigation (IC50) or Report of Investigation (IC70) screen to close the case. This ensures that NIIS has a complete record of the investigation. 

### Note

Source topic: `en_EN/common_notes/note_c_3505.dita`

Note:

The officer removes the FWW or found work code only if the week can be applied against an OP. 

### Note

Source topic: `en_EN/common_notes/note_c_3506.dita`

Note:

At this time, BCS cannot process a benefit period (BP) extension, the recalculation of a claim or the removal of a manual action (MA). The officer sends an MM06 asking IPOC to process these transactions. 

## Regional considerations

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/what_you_need_to_look_for.dita`

### In FTS

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/in_fts.dita`

- What is the CS in BCS?

- Is there a W - Earnings week 1 allocation on file?

- What is the lump sum payment modification code on the Emergency Response Benefits screen?

- Has a D47 or D65 been imposed on the claim?

- Are there any weeks with an FWW or found work code? 

## Step by step

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/reviewing_the_file_level_2.dita`

- In FTS, determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed and there is no found work code to be removed , go to step 2.

- If any other CS is displayed or there is a found work code to be removed and applie dto the OP , go to Creating an Operational Centre Memo (MM06) transaction .
               [Creating an Operational Centre Memo (MM06) transaction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/imp-dec-inc-rev-eierb#level2_item_3) 

#### Inputting the decision on a blocked claim

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/inputting_the_decision_on_a_blocked_claim_level_2.dita`

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 3.

- If all rows are blank, go to step 5.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1399.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, repeat step 3.

- If all rows are blank, go to step 5.

- Review the Summary tab, then select the Allocations link and determine if there is a W allocation on file:

- If yes, go to step 6.

- If no, go to step 10.

- Select the BPC to update from the Blocked Status column. When the Blocked Claim screen opens, do the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- On the Allocations tab, in the Allocations section, input the allocation as follows:

- Action: Select A - Add .

- Type: Select A - Amended earnings .

- Amount: Type “0000.”

- Start date: Enter the start date of the W allocation.

- End date: Enter the end date of the W allocation.

- Last week amount: Leave this field blank.

- Detection: Select 97 - EI ERB – Compliance .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Select Update .

- On the Pending Transactions tab, review the transaction and determine if it is correct:

- If no, go to step 9.

- If yes, select Close and go to step 10.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Select Close .

- Return to step 6.

- Determine if an FWW code must be removed for any of the claimant’s reports under review and applied to an OP that will be created:

- If yes, go to step 11.

- If no, go to step 15.

- In FTS, select the BPC to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- On the Allocation “A” tab, in the Amended Earnings and FWW columns, modify the week of the FWW as follows:

- Select the week that requires a change. Repeat for every week that requires a change.

- Amended earnings: remove the earnings.

- FWW: Select the new FWW code.

- Detection: Select 97 - EI ERB – Compliance .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3507.dita)

- On the Pending Transactions tab, review the transaction and determine if it is correct:

- If no, go to step 14.

- If yes, select Close and go to step 15.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Select Close .

- Return to step 11.

- In NWS, determine which of the following situations applies:

- If a D47 that is already imposed must be modified, go to step 16.

- If a D47 that is already imposed must be rescinded and a new disentitlement must be input, go to step 17.

- If a D47 that is already imposed must be rescinded and no new disentitlement must be input, go to step 23.

- If a new D47 must be input, go to step 31.

- Determine if the start and end dates of the disentitlements must be modified:

- If yes, go to step 17.

- If only the end dates must be modified, go to step 27.

- In FTS, select the BPC to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following fields:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To clear the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- On day one, on the Disentitlements tab, in the Disentitlements section, input up to 4 disentitlements as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3508.dita) 

- Action: Select A - Add .

- Type: Select 47 - EI ERB - Earnings limit exceeded for the four week period .

- Start date: Enter the disentitlement start date, if necessary.

- End date: Enter the disentitlement end date.

- Detection: Select 97 - EI ERB – Compliance .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Select Update .

- On the Pending Transactions tab, review the transaction and determine if it is correct:

- If no, go to step 20.

- If yes, select Close and go to step 21.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Select Close .

- Return to step 17.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Correct disentitlement input — original disentitlement will be rescinded on day 2.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in BCS, determine if the Results tab shows error code B112 :

- If no, go to step 23.

- If yes, go to step 37.

- In FTS, select the BPC to update from the Blocked Status column. When the Blocked Claim screen opens, do the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To clear the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- On the Disentitlements tab, in the Disentitlements section, rescind up to 4 disentitlements as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3509.dita) 

- Action: Select X - Rescind .

- Type: Select 47 - EI ERB - Earnings limit exceeded for the four week period

- Start date: Enter the disentitlement start date.

- End date: Enter the disentitlement end date.

- Detection: Select 97 - EI ERB – Compliance .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Select Update .

- On the Pending Transactions tab, review the transaction and determine if it is correct:

- If no, go to step 26.

- If yes, select Close and go to step 35.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Select Close .

- Return to step 25.

- Select the BPC to update from the Blocked Status column. When the Blocked Claim screen opens, do the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To clear the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- On the Disentitlements tab, in the Disentitlements section, modify up to 4 disentitlements as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3509.dita) 

- Action: Select T - Terminate .

- Type: Select 31 - EI ERB entitlement conditions not met .

- Start date: Enter the disentitlement start date.

- End date: Enter the disentitlement end date.

- Detection: Select 97 - EI ERB – Compliance .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Select Update .

- On the Pending Transactions tab, review the transaction and determine if it is correct:

- If no, go to step 30.

- If yes, select Close and go to step 35.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Select Close .

- Return to step 29.

- Select the BPC to update from the Blocked Status column. When the Blocked Claim screen opens, do the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To clear the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- On the Disentitlements tab, in the Disentitlements section, add up to 4 disentitlements as follows

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3509.dita) 

- Action: Select A - Add .

- Type: Select 47 - EI ERB - Earnings limit exceeded for the four week period

- Start date: Enter the disentitlement start date.

- End date: Enter the disentitlement end date.

- Detection: Select 97 - EI ERB – Compliance .

- Infraction: Select F - Non-Fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Select Update .

- On the Pending Transactions tab, review the transaction and determine if it is correct:

- If no, go to step 34.

- If yes, select Close and go to step 35.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Select Close .

- Return to step 33.

- In NWS, move the CR WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Transactions input in BCS.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, determine if the Results tab shows error code B112 :

- If yes, go to step 37.

- If no, go to step 40.

- In BCS, on the Results tab, select the estimated result that must be sent to IPOC and select the Forward via MM06 link.

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Detection: Select 97 - EI ERB – Compliance .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentative .

- Earnings to be allocated: Leave this field blank.

- Remarks lines 2–4: Enter the appropriate details:

- Add any missing information, if necessary.

- Type “Error code B112. Apply UP to OP.”

- Remarks line 5: Enter your first and last name.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1717.dita)

- Determine if the client must be notified of a disentitlement:

- If no, go to step 41.

- If yes, go to step 42.

- In ACS, create and send the C-71-05-01 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Earnings / insurable hours of work / income while on claim (12577)

- Blank / free form (3311): Select Blank .

- Go to step 42.

- In ACS, create and send the C-74-01-13 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Choice of phrases decision letter to claimant (12610): Select the appropriate option.

- Since we have not received a response from you / After reviewing your response (12612)

- Choice of Period 1-14 (12583) .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3510.dita)

- In NIIS, on the Report for Investigation (IC70) screen, select the Decision tab and complete the following fields:

- Disentitlement: Select the appropriate option.

- Overpayment: Select OP .

- Reason: Select Other .

- Amount: Enter the OP.

- Reason: Select Other and type the appropriate option:

- “EI ERB eligibility not proven — D47 imposed from w/c [XXXX] to w/c [XXXX].”

- “EI ERB eligibility proven — D47 not imposed.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity - ERB Reason for separation WI. 

#### Creating an Operational Centre Memo (MM06) transaction

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/creating_an_operational_centre_memo_mm0_3297a7ef_level_2.dita`

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Detection: Select 97 - EI ERB – Compliance .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Complete: Select D - No .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3511.dita)

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work Item: Select 91 - Overpayment .

- Work Type: Select 2 - Non-Misrepresentation .

- Earnings to be allocated: Leave this field blank.

- Remarks line 1: Type “Adjustment to EI ERB claim required.”

- Remarks line 2–4: Type the appropriate details:

- If there is a W allocation on file, type “Rescind W allocation $[XXXX], w/c [XXXX].”

- If necessary, type “[Add, modify, or rescind] D47 from w/c [XXXX-X] to [XXXX-X].”

- If necessary, type “Remove the FWW or found work code in w/c [XXXX].”

- Type “Apply UP to OP,” if necessary.

- Remarks line 5: Enter your name and telephone number.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1717.dita)

- Determine if the client must be notified of a disentitlement:

- If no, go to step 4.

- If yes, go to step 5.

- In ACS, create and send the C-71-05-01 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Earnings / insurable hours of work / income while on claim (12577)

- Blank / free form (3311): Select Blank .

- Go to step 6.

- In ACS, create and send the C-74-01-13 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Choice of phrases decision letter to claimant (12610): Select the appropriate option.

- Since we have not received a response from you / After reviewing your response (12612)

- Choice of Period 1-14 (12583) .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3512.dita)

- In NIIS, on the Report for Investigation (IC70) screen, select the Decision tab and complete the following fields:

- Disentitlement: Select the appropriate option.

- Overpayment: Select OP .

- Reason: Select Other .

- Amount: Enter the OP.

- Reason: Select Other and type the appropriate option:

- “EI ERB eligibility not proven — D47 imposed from w/c [XXXX] to w/c [XXXX].” .

- “EI ERB eligibility proven — D47 not imposed.”.

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity - ERB Reason for separation WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1399.dita`

Note:

In BCS, only one BPC can be updated at a time. 

#### Note

Source topic: `en_EN/common_notes/note_c_3507.dita`

Note:

When the FWW code is removed in BCS, also rescind earnings to ensure the UP is correctly applied. 

#### Note

Source topic: `en_EN/common_notes/note_c_3508.dita`

Note:

The officer can input multiple disentitlements. However, when a seventh disentitlement is added, the system generates a 36 - Seven or more disentitlements in effect manual action (MA36). The officer receives an estimate to send the inputs to IPOC. 

#### Note

Source topic: `en_EN/common_notes/note_c_3509.dita`

Note:

The officer can input multiple disentitlements. However, when a seventh disentitlement is added, the system generates an MA36. The officer receives an estimate to send the inputs to IPOC. 

#### Note

Source topic: `en_EN/common_notes/note_c_1717.dita`

Note:

If a second Operational Centre Memo (MM06) transaction is required for the same BPC, type “Page 1 of 2” at the end of the Remarks section of the first Operational Centre Memo (MM06) transaction and type “Page 2 of 2” at the beginning of the Remarks section of the second transaction. 

#### Note

Source topic: `en_EN/common_notes/note_c_3510.dita`

Note:

If a previously unpaid week with a FWW code was used to reduce the OP, add a footnote at the end of the letter and type, “An underpayment for the week of [DD-MM-YYYY] to [DD-MM-YYYY] was applied to the overpayment, reducing your debt to $[XXXX].” 

#### Note

Source topic: `en_EN/common_notes/note_c_3511.dita`

Note:

Remove the FWW or found work code only if the week can be applied against an OP. 

#### Note

Source topic: `en_EN/common_notes/note_c_3512.dita`

Note:

If a previously unpaid week with a FWW or found work code was used to reduce the OP, add a footnote at the end of the letter and type, “An underpayment for the week of [DD-MM-YYYY] to [DD-MM-YYYY] was applied to the overpayment, reducing your debt to $[XXXX].” 

## Policy reference

Source topic: `en_EN/task/imp-dec-inc-rev-eierb/policy_reference.dita`

- EIA 153.9 (4)
         [EIA 153.9 (4)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242461)

- EI Emergency Response Benefit — BE 2020-04
         [EI Emergency Response Benefit — BE 2020-04](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2020-04.html)

- EI Emergency Response Benefit Digest
         [EI Emergency Response Benefit Digest](https://ort-orl.esdc-edsc.canada.ca/en/policy/generic/ei_erb_digest.html) 
