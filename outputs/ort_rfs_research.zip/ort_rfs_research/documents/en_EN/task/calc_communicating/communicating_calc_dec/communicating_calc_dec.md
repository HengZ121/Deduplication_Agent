# Communicating decisions in writing after calculation

Source map: `en_EN/task/calc_communicating/communicating_calc_dec/communicating_calc_dec.ditamap`

## Summary

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/summary.dita`

Summary: When a client qualifies for benefits, a letter can be sent when the client or the employer must be notified of a decision. 

## What you need to know

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Communicating decisions

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/communicating_decisions.dita`

When a client must be notified of a decision, a letter may be sent automatically by the system, a Correspondence (COR) WI may be created or the agent calculating the claim may need to send a letter. 

### Manual letters

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/manual_letters.dita`

The agent completing the calculation of a claim must review the information that must be communicated, review ACS for sent and draft letters, and send all required letters that are not indicated in an outstanding COR WI. If possible, when an agent is responsible for sending multiple decisions, the decisions are combined in one letter. Separate letters are created only when the details of a required notification cannot be combined with other decisions the agent must communicate. The agent communicating the decision must ensure the details and address of draft letters are correct.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2240.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2241.dita) 

### ACS letters

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/acs_letters.dita`

In some cases, an automated letter is created when the initial claim is input but additional decisions must be communicated (e.g. the client has an allocation of earnings during the benefit period and an antedate was denied). When this occurs, to prevent multiple letters being sent, the Automated letter Bypass function is selected and the agent must create a manual letter the next day. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Example

Source topic: `en_EN/common_notes/note_c_2240.dita`

Example:

A Level 2 agent creates and saves a letter advising the client of a disqualification due to a contentious reason for separation. When the calculation is finalized, the ROE is excluded and no disqualification is imposed. The agent who finalizes the calculation must edit the draft letter by removing the reference to a disqualification and inserting the text in the excluded ROE. The agent must also ensure the client’s address is correct. 

### Note

Source topic: `en_EN/common_notes/note_c_2241.dita`

Note:

When clients update their address after a letter is created, the address on the draft letter is not automatically updated. 

## Regional considerations

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/what_you_need_to_look_for.dita`

### In ACS:

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/in_acs.dita`

- Have any letters been drafted? 

### In FTS:

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/in_fts.dita`

- Does the client’s address in FTS match the address on the saved letters In ACS? 

### In NWS:

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/in_nws.dita`

- Is there an outstanding COR WI?

- If yes, what are the details indicated? 

## Step by step

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/level_1.dita`

#### Determining if a manual letter is required

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/determining_if_a_manual_letter_is_required_level_1.dita`

- In NWS, move the calculation WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting confirmation that applicable automated letters were sent.”

- Bring forward date: Enter today’s date + 1 day.

- When the WI moves to the current workload, determine if an automated letter was sent, or if a COR WI was created for the notification required:

- If an automated letter was sent or if a COR WI was created, go to step 3.

- If an automated letter was not sent, and a COR WI was not created, go to Manual letter required .
               [Manual letter required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_communicating/communicating_calc_dec#Manual)

- Review the automated letters sent and the COR WI, and determine if they contain all the details of the decisions that must be communicated to the client or the employer:

- If yes, go to Manual letter not required .
               [Manual letter not required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_communicating/communicating_calc_dec#Manual_not)

- If no, go to Manual letter required .
               [Manual letter required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_communicating/communicating_calc_dec#Manual) 

#### Manual letter not required

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/manual_letter_not_required_level_1.dita`

- In ACS, determine if there are draft letters:

- If yes, delete any draft letter which is no longer required and go to step 5.

- If no, go to step 5.

- In NWS, clear any client Note that you have processed and complete the calculation WI. 

#### Manual letter required

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/manual_letter_required_level_1.dita`

- In ACS, search for draft letters:

- If there are draft letters, go to step 2.

- If there are no draft letters, go to step 6.

- Review each draft letter and delete the letters which are no longer required:

- If any draft letters remain, go to step 3.

- If no draft letters remain, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2242.dita)

- Determine if the details of the draft letters are correct:

- If yes, correct the letter and go to step 4.

- If no, determine if the letter can be corrected:

- If yes, correct the letter and go to step 4.

- If no, delete it and create a new one. Go to step 4.

- Determine if the additional required details can be added to the existing letter:

- If yes, go to step 5.

- If no, go to step 6.

- Add the additional details to the existing letter and go to step 7.

- In ACS, create the letter with the details of the decision following the instructions previously noted.

- In FTS, verify if the client’s address is the same as the address on the letter:

- If the address is the same, go to step 8.

- If the address is not the same, update the address on each letter to be sent to match the address in FTS. Go to step 8.

- In ACS, send the necessary letters for the decisions that must be communicated.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2243.dita)

- In NWS, clear any client Note that you have processed and complete the calculation WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2242.dita`

Note:

If the draft letter can be viewed in ACS but not altered, it is a letter created using a template that has since been retired. These letters are no longer considered to be using approved language. When a decision must be communicated and the letter was created using a retired template, the agent must create a new letter using the new format and delete the letter that was created using the retired template. 

#### Note

Source topic: `en_EN/common_notes/note_c_2243.dita`

Note:

If a COR WI exists, do not send the draft letters for the decision that must be communicated, as indicated in the COR WI. 

## Policy reference

Source topic: `en_EN/task/calc_communicating/communicating_calc_dec/policy_reference.dita`

- EIA 53
         [EIA 53](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-53.html) 
