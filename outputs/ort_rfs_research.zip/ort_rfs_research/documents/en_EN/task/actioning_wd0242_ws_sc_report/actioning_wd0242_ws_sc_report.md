# Actioning a special condition code — IPOC

Source map: `en_EN/task/actioning_wd0242_ws_sc_report/actioning_wd0242_ws_sc_report.ditamap`

## Summary

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/summary.dita`

Summary: When a special condition code prevents a claimant's report from being processed, the IPOC officer reviews the claim information and the special condition code to determine the action required on the claim file. A Manual Action - Claimant’s Reports (T045) transaction is required in order to process the declaration. 

## What you need to know

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/what_you_need_to_know.dita`

### Function of special condition codes

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/function_of_special_condition_codes.dita`

The design of the Work-Sharing (WS) process allows an IPOC officer to process a utilization report (UR) as a whole. The IPOC officer does not need to review each individual claim listed to determine how to process the UR. In order to facilitate this process, special condition codes were put in place to assist with complex conditions or to identify claims that require individual review. 

### Inputting a special condition code

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/inputting_a_special_condition_code.dita`

When a special condition code is required, the IPOC officer inputs the code in the Reason for not working column of the UR. To determine when a special condition code is required and to ensure that the special condition codes are input appropriately, the IPOC officer refers to Work-Sharing: Utilization report coding — Input guide . These codes help AWSS determine the action to be taken, or prevent the creation of the automated Manual Action - Claimant’s Reports (T045) that AWSS normally creates.
       [Work-Sharing: Utilization report coding — Input guide](/en/procedure/generic/additionalresources/ws_coding_utilization_report.shtml)

The client’s record is matched with the employer’s record using a special condition code, and is then removed from AWSS. NWS generates an IPOC System Notification (IPOC SN) Work-sharing - Special condition WI. The IPOC officer reviews the claim and the details of this WI to determine the next steps required to process the declaration. If the week requires manual processing, the IPOC officer inputs a Manual Action - Claimant’s Reports (T045) transaction. 

### Triage process

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/triage_process.dita`

A triage process was developed to convert URs received through the Data Gateway and upload them to FTS.

Since the triage process cannot action UR declarations with comments, a workaround was created to notify an IPOC officer to review all UR declarations with comments.

The triage process converts the UR and inputs special condition code 11 - Non-available and sick days are greater than 5 in all declarations that contain a comment. IPOC officers need to familiarize themselves with this workaround because there are 2 scenarios where declarations can be coded with special condition code 11. The 2 scenarios are:

- An IPOC officer inputs special condition code 11 to reject a UR declaration if not available days and sick days were greater than 5. NWS generates an IPOC SN Work-sharing - Special condition WI.

- The triage process inputs special condition code 11 to reject a UR declaration with comments. The SIN is added to an .XML file in the Rejected_Declarations subfolder.

The IPOC officer reviews all other information on the UR and the claimant’s report to determine the correct action to take to address the special condition code. 

### Work-Sharing - Special conditions WI

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/work-sharing_-_special_conditions_wi.dita`

An IPOC SN Work-sharing - Special condition WI is generated for each claimant’s report for which the internally generated Manual Action - Claimant’s Reports (T045) transaction was prevented due to a special condition code. This WI contains the following information:

- client’s declaration:

- SIN

- Service Canada Center (SCC)

- w/c

- number of weeks on the report

- earnings week 1 and week 2

- not-available days week 1 and week 2

- sick days week 1 and week 2

- full work week (FWW) code

- found work code

- disentitlement days week 1 and week 2

- WS end week

- employer’s declaration:

- w/c (if a second week is applicable, it is on the line below the first week)

- the Sunday date that corresponds with the w/c

- not-available days declared by the employer

- sick days declared by the employer

- paid sick leave (PSL) amount

- other paid amounts

- hours missed due to WS

- the special condition code input with the UR

- the WS agreement number

The action the officer must take to process the declaration depends on the special condition code. The special condition codes indicated in the Specific details tab of the IPOC SN Work-sharing - Special condition WI can include:

- 1 - Paid sick leave

- 6 - Voluntary termination (quit)

- 7 - Termination (fired)

- 8 - Laid off

- 10 - Non-available and sick days are greater than 1 but less than 5

- 11 - Non-available and sick days are greater than 5

The special condition codes are also available on the WD0242 EDS report.

**Code 1 - Paid sick leave**

If the client has hours worked for the WS employer, the IPOC officer ignores earnings (including PSL, wage loss insurance [WLI] and workers’ compensation benefits [WCB]). The IPOC officer uses this code only when 0 hours have been worked. The claimant’s report is rejected, unless both the client’s record and the employer’s record indicate 5 sick days and the waiting period (WP) has already been served. If the claimant’s report is rejected, an IPOC SN Work-sharing - Special condition WI is generated. The required action depends on whether the WP has been served or waived, and whether the client or employer has reported PSL, WLI or WCB.

If the WP has been served, the IPOC officer processes the week with the PSL considered as earnings. If the WP has not been served, the IPOC officer processes the week without the PSL amount and creates an SROC to document the file.

When an employer reports WLI or WCB payments and the exact amount is unknown, the IPOC officer processes the week with $9 999 and creates an Action Item (AI) WI for a Level 1 review. If there is an outstanding AI WI for the issue, the IPOC officer documents the file in an SROC.

When the Level 1 officer obtains the information, the officer inputs a manual action 19 - Amended report (MA19) with the allocation amount. If the allocation is ongoing and it affects future weeks, the Level 1 officer also creates an IPOC Review (IPOC REV) WI with the allocation information. The IPOC officer adds the allocation to the lump-sum payment worksheet.

```text
| Condition | Action required |

| The WP is not served and is not waived. | PSL, WLI or WCB are not considered earnings. Combine the client and employer declaration and input a Manual Action - Claimant’s Reports (T045) transaction without adding the amount declared as PSL, WLI or WCB into the Earnings field. Create an SROC to document the file. |

| The WP is served or waived and the PSL, WLI or WCB amounts are known. | PSL, WLI or WCB are considered earnings. Input a Manual Action - Claimant’s Reports (T045) transaction with the amount declared as PSL, WLI or WCB in the Earnings field. |

| The WP is served or waived and the PSL, WLI or WCB amounts are unknown. | PSL, WLI or WCB are considered earnings. Input a Manual Action - Claimant’s Reports (T045) transaction with $9 999 in the Earnings field. Create an AI WI for Level 1. |

| The WP is served or waived and the PSL, WLI or WCB amount are unknown. An AI WI has already been sent to Level 1. | PSL, WLI or WCB are considered earnings. Input a Manual Action - Claimant’s Reports (T045) transaction with $9 999 in the Earnings field. Create an SROC to document the file. |
```

**Codes 6 - Voluntary termination (quit) and 7 – Termination (fired)**

AWSS prevents the IPOC officer from inputting either of these codes when hours worked have been input on the UR. In order to ensure the required code is on the declaration, the IPOC officer removes the hours worked and hours missed from the UR declaration. Additionally, the AWSS record does not contain the comments from the Comments column of the UR.

These comments include the date of and reason for separation (RFS). For this reason, the IPOC officer actioning the IPOC SN Work-sharing - Special condition WI cannot use the AWSS declaration to determine the required action. Instead, the IPOC officer retrieves the employer’s UR declaration from the employer folder on the WS Common Document Share.

The IPOC officer ensures that the WS agreement is ended in the correct week, the weeks up to and including the new agreement end week have been processed, and the RFS is documented in an SROC or an AI WI in NWS. The IPOC officer refers to Processing a separation from Work-Sharing employment - IPOC , if necessary.
       [Processing a separation from Work-Sharing employment - IPOC](/en/procedure/task/actioning_pse_wsc.shtml)

**Code 8 - Laid off**

AWSS prevents the IPOC officer from inputting this code when hours worked have been input. When there are hours worked in the week in which the separation occurred, the UR is input without the special condition code. The officer that inputs the UR documents the separation and ends the WS agreement.

The IPOC officer ensures that the WS agreement is ended in the correct week, the weeks up to and including the new agreement end week have been processed, and the RFS is documented in an SROC or an AI WI in NWS. The IPOC officer refers to Processing a separation from Work-Sharing employment - IPOC , if necessary.
       [Processing a separation from Work-Sharing employment - IPOC](/en/procedure/task/actioning_pse_wsc.shtml)

**Codes 10 - Non-available days and sick days are greater than 1 but less than 5 and 11- Non-available and sick days are greater than 5**

AWSS is programmed to combine the client and employer declarations and create the necessary Manual Action - Claimant’s Reports (T045) transaction. However, the combined declaration must meet the prescribed system logic for a week to be processed successfully. When not-available days and sick days add up to a total of less than 5 or greater than 5, the system recognizes that there is not enough information to correctly process the week.

In these cases, the IPOC officer fact-finds with the client to determine which circumstances apply to the week in question. Once the IPOC officer has obtained and documented the necessary information, the IPOC officer inputs a Manual Action - Claimant’s Reports (T045) transaction to process the week.

If the declaration contains a comment , but no sick or not available days, the triage process inputs special condition code 11 on that declaration so that it will be rejected from the AWSS upload.

The IPOC officer refers to the declarations in the Rejected_Declarations subfolder and reviews the comment to determine the required action. 

## Regional considerations

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/what_you_need_to_look_for.dita`

### In the UR:

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/in_the_ur.dita`

- Did the employer indicate the RFS and the last day worked (LDW) in the Comments column of the UR?

- Did the employer report any PSL, WLI or WCB amounts? 

### In FTS:

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/in_fts.dita`

- On the Worksharing Records screen, does the employer declaration contain all of the information necessary to determine the required action?

- Are there PSL, WLI or WCB allocations on file? 

### In NWS:

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/in_nws.dita`

- Is there an SROC or AI WI containing separation or availability information for the week in question?

- Are there any SROCs, AI WI or IPOC REV WI containing information on the incapacity monies? 

### In the Lump Sum Payment worksheet:

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/in_the_lump_sum_payment_worksheet.dita`

- Are there any PSL, WLI or WCB allocations added to the worksheet? 

## Step by step

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/step_by_step.dita`

### IPOC

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/ipoc.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/reviewing_the_file_ipoc.dita`

- Review the employer’s UR declaration in the employer’s folder in the WS Common Document Share.

- In NWS, review the Specific details tab of the IPOC SN Work-sharing - Special condition WI and determine the special condition code:

- If it is 1 , go to Code 1 - Paid Sick Leave .
               [Code 1 - Paid Sick Leave](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_wd0242_ws_sc_report#ipocc_item_2)

- If it is 6 , 7 or 8 , go to Separation from Work-Sharing (WS) employment .
               [Separation from Work-Sharing (WS) employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_wd0242_ws_sc_report#ipocc_item_3)

- If it is 10 or 11 , go to Non-available days and sick days are not equal to 5 .
               [Non-available days and sick days are not equal to 5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_wd0242_ws_sc_report#ipocc_item_4) 

#### Code 1 - Paid Sick Leave

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/code_1_-_paid_sick_leave_ipoc.dita`

- In FTS, determine if the WP has been served or waived:

- If no, go to step 2.

- If yes, go to step 3.

- In NWS, create an SROC as follows:

- Main Issue: Select Earnings .

- Comments: Type “[Paid sick leave, wage loss insurance or workers’ compensation benefits] amount is not considered earnings during the waiting period.”

- Details: Type “[Paid sick leave, wage loss insurance or workers’ compensation benefits] reported on the utilization report for w/c [XXXX]. The waiting period is served during this week. IPOC has processed the week without the monies because they are not considered earnings during the waiting period.” Provide the WS employer name and agreement number.

- Select Save.

- Go to step 7.

- In NWS, determine if the client or employer provided a PSL, WLI or WCB amount:

- If no, go to step 4.

- If yes, go to step 7.

- Determine if there is an outstanding AI WI for the issue on file:

- If no, go to step 5.

- If yes, go to step 6.

- Create an AI WI for Level 1 as follows:

- Complexity: Select Level 1.

- Destination: Select the appropriate option:

- Atlantic: SCC: Select the Service Canada Centre (SCC) as shown in FTS.

- Ontario: Level: Select 1- Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - ON / Work-Sharing - ON .

- Quebec: Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC / Work-Sharing - QC .

- Western Canada and Territories: Level: Select 1- Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - WT / Work-Sharing - WT .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Earnings .

- Comments: Type “[Paid sick leave, wage loss insurance or workers’ compensation benefits] indicated on utilization report for w/c [XXXX] — Amount unknown.”

- Details: Type “[Paid sick leave, wage loss insurance or workers’ compensation benefits] indicated on utilisation report for w/c [XXXX] — employer does not know the amount that is or will be paid. An amount of $9 999 was entered to prevent any potential overpayment. Once fact-finding is completed, input amended claimant’s reports with the correct amount. If the allocation is ongoing and affects weeks that are still unprocessed, send the allocation information to IPOC via IPOC REV WI.” Provide the WS employer name and WS agreement number.

- Go to step 7.

- Create an SROC as follows:

- Main Issue: Select Earnings .

- Comments: Type “[Paid sick leave, wage loss insurance or workers’ compensation benefits] indicated on the utilization report for w/c [XXXX] — Amount unknown.”

- Details: Type “[Paid sick leave, wage loss insurance or workers’ compensation benefits] indicated on the utilization report for w/c [XXXX] — employer does not know the amount that is or will be paid. An amount of $9999 was entered to prevent any potential overpayment. Once the pending action item work item is completed, the Level 1 officer inputs the correct amount.” Provide the WS employer name and agreement number.

- Go to step 7.

- In FTS, input a Manual Action - Claimant’s Reports (T045) transaction. For guidance, refer to T045: Work-Sharing conditions and required actions — Transaction .

- Go to Completing the WI . 

#### Separation from Work-Sharing (WS) employment

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/separation_from_work-sharing_ws_employment_ipoc.dita`

- Determine if the WS agreement was ended in the appropriate week and if the RFS was documented:

- If yes, go to step 2.

- If no, go to Processing a separation from Work-Sharing employment - IPOC. .
               [Processing a separation from Work-Sharing employment - IPOC.](/en/procedure/task/actioning_pse_wsc.shtml)

- In FTS, determine if the claimant’s reports have been processed up to and including the last week of the WS agreement:

- If no, go to step 3.

- If yes, go to Completing the WI .
               [Completing the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_wd0242_ws_sc_report#ipocc_item_5)

- Input a Manual Action - Claimant’s Reports (T045) transaction. For guidance, refer to T045: Work-Sharing conditions and required actions — Transaction . Go to Completing the WI . 

#### Non-available days and sick days are not equal to 5

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/non-available_days_and_sick_days_are_no_d1ffc2cb_ipoc.dita`

- Fact-find with the client to obtain the non-available and sick days, as required. Once the required information is obtained, go to step 2.

- In FTS, input a Manual Action - Claimant’s Reports (T045) transaction. Refer to T045: Work-Sharing conditions and required actions — Transaction for guidance. Go to Completing the WI 

#### Completing the WI

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/completing_the_wi_ipoc.dita`

- In NWS, complete the IPOC SN Work-sharing - Special condition WI and document the action taken. 

## Policy reference

Source topic: `en_EN/task/actioning_wd0242_ws_sc_report/policy_reference.dita`

 
