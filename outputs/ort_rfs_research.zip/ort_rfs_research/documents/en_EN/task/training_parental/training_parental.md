# Adjudicating non-referred training: Parental benefits — Continuing claim

Source map: `en_EN/task/training_parental/training_parental.ditamap`

## Summary

Source topic: `en_EN/task/training_parental/summary.dita`

Summary: When clients receiving parental benefits decide to take a non-referred training course, adjudication is required to determine if they are entitled to benefits during the training period. 

## What you need to know

Source topic: `en_EN/task/training_parental/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/task/training_parental/training_reported_between_september_27__5ecd71c7.dita`

A transitional measure under which ACP automatically adjudicated and allowed all training effective September 27, 2020, has ended effective September 11, 2021. The intent of this measure was to prevent any delay in payment to clients who report training.

The client must still meet the entitlement conditions for parental benefits while attending non-referred training. A client attending non-referred training may provide information on a claimant’s report or during a conversation with an agent that brings into question the entitlement to parental benefits. In this case, the agent creates a WI for the training issue and follows normal adjudication procedures, even if ACP initially allowed the training. 

### Impact of training on parental benefits

Source topic: `en_EN/task/training_parental/impact_of_training_on_parental_benefits.dita`

When adjudicating non-referred training for a client receiving parental benefits, the issue is whether the client continues to care for the child for whom the benefits are payable. This includes clients who are attending short-term training courses and targeted initiatives. Refer to the job aid for a complete list of non-referred short-term courses and targeted initiatives.
       [job aid](/en/procedure/generic/additionalresources/shortterm_courses_ti.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4814.dita) 

### Targeted initiatives and short-term courses

Source topic: `en_EN/task/training_parental/targeted_initiatives_and_short-term_courses.dita`

When clients report that they are attending a targeted initiative or short-term course, the total daily or weekly attendance hours is not considered.

If the client is attending a short-term course referred under EIA 25, refer to Confirming referred training: Special benefits — Continuing claim .
       [Confirming referred training: Special benefits — Continuing claim](/en/procedure/task/confirmreftrng_sb_con.shtml) 

### Levels of decision

Source topic: `en_EN/task/training_parental/levels_of_decision.dita`

Level 1 is authorized to allow benefits when the following conditions are met:

- The training is under 25 hours per week.

- The training location is in the area where the client resides with the child.

There must be no doubt that the client is still providing care. If the client makes any statement that creates doubt that the client is providing care, the issue must be referred to Level 2. 

### Inputting the training information

Source topic: `en_EN/task/training_parental/inputting_the_training_information.dita`

A client collecting parental benefits is usually exempt from completing claimant’s reports and therefore, the non-referred training information is not input in FTS. However, if the client is completing claimant’s reports, the non-referred training information must be input. 

### Note

Source topic: `en_EN/common_notes/note_c_4814.dita`

Note:

If a client quits employment or refuses an offer of employment to attend a non-referred training course, a non-referred short-term training course or a targeted initiative, agents must adjudicate the reason for separation on a separate WI. 

## Regional considerations

Source topic: `en_EN/task/training_parental/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/training_parental/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/training_parental/in_fts.dita`

- Is there a registration number for the non-referred training issue?

- Is there a stop payment (MA72) for the non-referred training issue?

- Is the client exempt from completing claimant’s reports?

- Is there a pending claimant’s report?

- Is there training information in the Project tab? 

### In NWS:

Source topic: `en_EN/task/training_parental/in_nws.dita`

- Is there a record of decision (ROD) for the non-referred training issue?

- Is there an SROC or an Action Item (AI) WI with the training information, from either the Part-time Training checklist or the Training Course Information (INS3141) form? 

### In Imaging:

Source topic: `en_EN/task/training_parental/in_imaging.dita`

- Is there non-referred training information or the INS3141 form? 

## Step by step

Source topic: `en_EN/task/training_parental/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/training_parental/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_parental/reviewing_the_file_level_1.dita`

- Determine if the non-referred training issue has been adjudicated and if there is an existing ROD in NWS:

- If no, go to step 2.

- If yes and ACP allowed training reported between September 27, 2020 and September 11, 2021, but new information indicates doubt that the client is providing care for the child, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_parental#reassign)

- If yes and it is any other situation, go to Training previously adjudicated .
               [Training previously adjudicated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_parental#_Issue_already_adjudicated)

- Determine if the following non-referred training details are on file:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4822.dita) 

- If all of the training details are not on file, fact-find with the client and go to step 3.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If all of the training details are on file, go to step 6. 

#### Fact-finding

Source topic: `en_EN/task/training_parental/fact-finding_level_1.dita`

- Fact-find with the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 5.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Reassign the issue to Level 2 .
               [Reassign the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_parental#reassign)

- In NWS, add to the draft SROC created during fact-fin ding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — parental benefits.”

- Details : Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/training_parental/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine the type of training the client is attending:

- If the client is attending a short-term training course or a targeted initiative, go to step 7.

- If the client is attending regular non-referred training, go to step 8.

- Determine if the short-term course or targeted initiative is at a location that requires the client to reside away from the child while attending:

- If the course or initiative is not at a location that requires the client to reside away from the child while attending, go to step 9.

- If the course or initiative is at a location that requires the client to reside away from the child while attending, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_parental#reassign)

- Determine if both of the following conditions are met:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4823.dita) 

- If both conditions are met, go to step 9.

- If either condition is not met, go to Reassign the issue to Level 2 .
               [Reassign the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_parental#reassign)

- Determine if the client has made any statement that creates doubt that the client is providing care for the child for whom the benefits are payable while on the non-referred training:

- If there is no doubt that the client is providing care for the child, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_parental#_Entitlement_in_order)

- If there is doubt that the client is providing care for the child, go to Reassign the issue to Level 2 .
               [Reassign the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_parental#reassign) 

#### Training previously adjudicated

Source topic: `en_EN/task/training_parental/training_previously_adjudicated_level_1.dita`

- In FTS, select the Renewal/Revised (M106) transaction and remove the 72 - Additional training information required manual action (MA72) as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: C - Yes .

- Select Update .

- Complete the WI. 

#### Entitlement conditions met

Source topic: `en_EN/task/training_parental/entitlement_conditions_met_level_1.dita`

- In NWS, create a ROD with the following information:

- Comments: Type “Non-referred training — entitlement in order.”

- Details: Type “The client is providing care for the child while on non-referred training.” Document any other details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the client is completing claimant’s reports:

- If the client is completing claimant’s reports, go to step 3.

- If the client is exempt from completing claimant’s reports, go to step 5.

- Determine if there is a pending claimant’s report:

- If there is a pending claimant’s report, clear the outstanding claimant’s report and go to step 4.
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 4.

- In FTS, determine if the non-referred training information has been input in the Project tab:

- If the non-referred training information has been input, go to step 5.

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Determine if an MA72 is imposed and if there is an outstanding registration number for the non-referred training issue:

- If an MA72 is imposed but there is no registration number, go to step 6.

- If an MA72 is imposed and there is a revised registration number, go to step 7.

- If no MA72 is imposed but there is a revised registration number, go to step 8.

- If none of the above applies, go to step 9.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: C - Yes .

- Select Update .

- Go to step 9.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Complete the WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/training_parental/reassigning_the_issue_to_level_2_level_1.dita`

- In FTS, determine if the client is completing claimant’s reports:

- If the client is completing claimant’s reports, go to step 2.

- If the client is exempt from completing claimant’s reports, go to step 4.

- Determine if there is a pending claimant’s report:

- If there is a pending claimant’s report, clear the outstanding claimant’s report and go to step 3.
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 3.

- In FTS, determine if the non-referred training information has been input in the Project tab:

- If the non-referred training information has been input, go to step 4 .

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input the non-referred training information as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and input an MA72 as follows:

- Manual action : Select 72 - Additional Training information required .

- Select Update .

- In NWS, reassign the WI as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type the appropriate reason for the reassignment:

- “Unable to contact client for fact-finding.”

- “Not within Level 1 authority — The non-referred training is more than 25 hours per week.”

- “The non-referred training is at a location that requires the client to reside away from the child.”

- “There is doubt as to whether the client is providing care for the child while on non-referred training.” 

#### Callout

Source topic: `en_EN/common_notes/note_c_4822.dita`

Required details

- number of hours of training per week (if the client is attending regular non-referred training)

- location of the training

- start date of training 

#### Callout

Source topic: `en_EN/common_notes/note_c_4823.dita`

- Condition #1: The non-referred training is less than 25 hours per week.

- Condition #2: The non-referred training is not at a location that requires the client to reside away from the child while attending the course. 

### Level 2

Source topic: `en_EN/task/training_parental/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_parental/reviewing_the_file_level_2.dita`

- Determine if the non-referred training issue has been adjudicated and if there is an existing ROD in NWS:

- If no, go to step 2.

- If yes and ACP allowed training reported between September 27, 2020 and September 11, 2021, but new information indicates doubt that the client is providing care for the child, go to step 3

- If yes and it is any other situation, go to Training previously adjudicated .
               [Training previously adjudicated](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_parental#_Already_adjudicated)

- Determine if the non-referred training details are on file (e.g. number of hours of training per week and location of school):

- If additional details are needed, go to step 3. For help determining the questions to ask the client, refer to Digest Chapter 13.1.4 .
               [Digest Chapter 13.1.4](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-13/parental-benefits-payments.html#a13_1_4)

- If additional details are not needed, go to step 6. 

#### Fact-finding

Source topic: `en_EN/task/training_parental/fact-finding_level_2.dita`

- Fact-find with the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 5.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 6.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — parental benefits.”

- Details: Document the fact-finding details according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating non-referred training

Source topic: `en_EN/task/training_parental/adjudicating_non-referred_training_level_2.dita`

- Adjudicate the non-referred training according to the entitlement principles of Digest Chapter 13.1.4 .

- Based on the decision, select the appropriate procedure:

- Entitlement conditions met
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_parental#inorder)

- Entitlement conditions not met
               [Entitlement conditions not met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_parental#est2) 

#### Entitlement conditions met

Source topic: `en_EN/task/training_parental/entitlement_conditions_met_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — entitlement in order.”

- Details: Document the decision and rationale according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if the client is completing claimant’s reports:

- If the client is completing claimant’s reports, go to step 3.

- If the client is exempt from completing claimant’s reports, go to step 5.

- In FTS, determine if the non-referred training information has been input:

- If the non-referred training information has been input, go to step 4.

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Determine if there is a pending claimant’s report:

- If there is a pending claimant’s report, clear the outstanding claimant’s report and go to step 5.
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 5.

- Determine if an MA72 is imposed and if there is an outstanding registration number for the non-referred training issue:

- If an MA72 is imposed but there is no registration number, go to step 6.

- If an MA72 is imposed and there is a registration number, go to step 7.

- If no MA72 is imposed and there is a revised registration number, go to step 8.

- If none of the above applies, go to step 9.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: C - Yes .

- Select Update .

- Go to step 9.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Entitlement conditions not met

Source topic: `en_EN/task/training_parental/entitlement_conditions_not_met_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — D-34 from w/c XXXX-X to XXXX-X.”

- Details: Document the decision and rationale according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the client is completing claimant’s reports:

- If the client is completing claimant’s reports, go to step 3.

- If the client is exempt from completing claimant’s reports, go to step 5.

- Determine if the non-referred training information has been input:

- If the non-referred training information has been input, go to step 4.

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input the non-referred training information as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Determine if there is a pending claimant’s report:

- If there is a pending claimant’s report, clear the outstanding claimant’s report and go to step 5.
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 5.

- In FTS, determine if there is an outstanding registration number for the non-referred training issue:

- If there is an outstanding registration number, go to step 6.

- If there is no outstanding registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if an MA72 is imposed for the non-training issue:

- If an MA72 is imposed, go to step 7.

- If an MA72 is not imposed, go to step 8.

- Select the Renewal/Revised (M106) transaction to remove the MA72 and input the disentitlement as follows:

- Registration number: Select the related registration number.

- Manual action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 34 - Parental benefits entitlement conditions not met .

- Start date: Select the disentitlement start date.

- End date: Select the appropriate end date as follows:

- If the training has ended, select the corresponding end date of the disentitlement.

- If the training has not ended, select Indefinite .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Update .

- Go to step 9.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the disentitlement as follows:

- Registration Number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 34 - Parental benefits entitlement conditions not met .

- Start date: Select the disentitlement start date.

- End date: Select the appropriate end date as follows:

- If the training has ended, select the corresponding end date of the disentitlement.

- If the training has not ended, select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Parental benefits denied or suspended.

- Parental benefits denied or suspended - D34/D35/D56/D57/Free text (3074): Select Text: Explain why parental benefits not payable .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select the appropriate option and select the disentitlement dates.

- Text - Insert appropriate reason(s) (1618): Type “You have not proven that you are caring for your child while attending a course of instruction on your own initiative.”

- Overpayment Messages (2452)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI. 

#### Training previously adjudicated

Source topic: `en_EN/task/training_parental/training_previously_adjudicated_level_2.dita`

- In NWS, complete the non-referred training WI. 

## Policy reference

Source topic: `en_EN/task/training_parental/policy_reference.dita`

- Digest 10.12.2 — Persons attending courses on their own initiative
         [Digest 10.12.2 — Persons attending courses on their own initiative](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2)

- Digest 13.1.4 — To care for a child
         [Digest 13.1.4 — To care for a child](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-13/parental-benefits-payments.html#a13_1_4)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
