# Performing a reconsideration under EIA 112 - Previous process

Source map: `en_EN/task/performingar_prev_ver/performingar_prev_ver.ditamap`

## Summary

Source topic: `en_EN/task/performingar_prev_ver/summary.dita`

Summary: Clients and employers can request a reconsideration under EIA 112 of a decision made on a claim by submitting a request for reconsideration. The agent processes the request for reconsideration to ensure that the decisions made on the file follow the applicable legislation and policies.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4018.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4018.dita`

Note:

Agents follow this task if they are assigned an AI WI to process a request for reconsideration received prior to March 6, 2021. 

## What you need to know

Source topic: `en_EN/task/performingar_prev_ver/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/performingar_prev_ver/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4019.dita) 

### Receiving a request for reconsideration

Source topic: `en_EN/task/performingar_prev_ver/receiving_a_request_for_reconsideration.dita`

According to EIA 112 , clients, employers or any other person subject to a decision of the Commission have the right to ask for a reconsideration under EIA 112 of a claim decision. In the reconsideration under EIA 112 , the “requester” is the person making the request for reconsideration. When a request for reconsideration is received, an agent, different from the one who made the initial decision, performs a reconsideration under EIA 112 of the initial decision to ensure it follows the applicable legislation and policies.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

The request for reconsideration must be submitted in writing. However, use of the Request for Reconsideration of an Employment Insurance (EI) Decision (INS5210) form is not mandatory. If this form is not used, the request must be submitted in a letter that clearly states that it is a request for reconsideration and that includes the following information:
       [Request for Reconsideration of an Employment Insurance (EI) Decision (INS5210)](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5210.pdf)

- name of the requester (and the third party, if applicable)

- requester’s SIN or business number, address and telephone number

- date on which the decision was communicated to the requester

The letter submitted must also include the reasons why the client is requesting a reconsideration under EIA 112 of the decision.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

If the Request for Reconsideration of an Employment Insurance (EI) Decision (INS5210) form was not used, and the intent of the letter is unclear, the issue is referred to processing for action.
       [Request for Reconsideration of an Employment Insurance (EI) Decision (INS5210)](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5210.pdf)

An unsigned request for reconsideration is not automatically invalid, as there is no legislated requirement for a signature. Identity can be confirmed by cross checking information already on file. If there is any question on the intent or authenticity of the letter, the agent contacts the requester for confirmation.

A request for reconsideration faxed or submitted in any other electronic format is accepted and processed as long as there is no question as to its authenticity.

Once a request for reconsideration is received, it cannot be withdrawn unless it was submitted in error. A request for reconsideration is considered to have been submitted in error only if the client indicates at the start of the conversation that the letter was never meant to be a request for reconsideration. If it was the clients’ intent to request a reconsideration, but they state at the start of the conversation with the agent that they no longer wish to pursue the request, the Commission is nevertheless legally required to process the request.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3984.dita) 

There are times when the processing centre may take action on a file without realizing that a reconsideration under EIA 112 has been requested. If this occurs, the agent processing the request for reconsideration must refer to Assessing whether a reconsideration under EIA 112 is required when an initial decision has been modified to determine if the reconsideration under 112 will proceed. If the reconsideration proceeds, the agent is referred back to the Performing a reconsideration under EIA 112 .
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [to Assessing whether a reconsideration under EIA 112 is required when an initial decision has been modified](/en/procedure/task/assessing_ar_id.shtml) 
       [Performing a reconsideration under EIA 112](/en/procedure/task/performingar.shtml) 

### Request for reconsideration made by a third party

Source topic: `en_EN/task/performingar_prev_ver/request_for_reconsideration_made_by_a_t_2e43a1fb.dita`

A third party may submit a request for reconsideration on behalf of a requester (client or employer). The request is accepted if the Request for Reconsideration of an Employment Insurance (EI) Decision (INS5210) form is fully completed and signed by the requester , and it is accompanied by an authorization document signed by the requester.
       [Request for Reconsideration of an Employment Insurance (EI) Decision (INS5210)](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5210.pdf)

An authorization is made in writing and must:

- be voluntary;

- specify the purpose for which consent is being given;

- identify the information to be released; and

- be signed and dated by the requester. 

### Request for reconsideration involving an employer

Source topic: `en_EN/task/performingar_prev_ver/request_for_reconsideration_involving_a_4e7091b1.dita`

The definition of “employer” is limited to a person or organization for whom the client works or has worked.

An employer is considered an interested party in the following cases and must be added as a participant in ADMS regardless of the outcome of the reconsideration under EIA 112 :
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- dismissal

- voluntary leaving when the reasons for leaving are work-related

- refusal to accept employment or failure to take advantage of a job opportunity if the reasons for doing so are work-related

- labour disputes

Employers are only notified if the decision is favorable to the client. However, the reconsideration under EIA 112 can still proceed in cases where the employer was not notified of the original decision but has requested a reconsideration of that decision.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

A potential or prospective employer for whom the client has not worked is not notified of the decision or of any further recourse action. Although the information gathered in the fact-finding process and taken into account in the decision is included in the reconsideration file, the employer is not considered to be an interested party. 

### Creating a distinct file for an insurability ruling — More than one benefit period (BP)

Source topic: `en_EN/task/performingar_prev_ver/creating_a_distinct_file_for_an_insurab_932be244.dita`

When an insurability ruling is required and the request for reconsideration impacts more than one BP, the agent creates a separate file in ADMS for each BP when starting to process the request for reconsideration. This allows the suspension of the reconsideration timeframe countdown that is displayed on the counter in ADMS for each file until the insurability ruling is received. 

### Creating a distinct file for an overpayment (OP) or a penalty — More than one benefit period (BP)

Source topic: `en_EN/task/performingar_prev_ver/creating_a_distinct_file_for_an_overpay_fdca1609.dita`

If the request for reconsideration is for a decision that resulted in an overpayment (OP) for more than one BP, the agent evaluates the possibility of creating a separate file for each BP in ADMS. 

### Creating a distinct file for multiple issues — Employer considered an interested party

Source topic: `en_EN/task/performingar_prev_ver/creating_a_distinct_file_for_multiple_i_b6e04444.dita`

In cases where more than one issue is under review, it is important to determine who is considered an interested party to each issue. In cases where the employer is not considered an interested party to all issues, separate record folders are created in Common Document Share and separate ADMS files are created in order to preserve the privacy of the client should the case proceed to the Social Security Tribunal (SST). 

### Determining the level of authority by issue

Source topic: `en_EN/task/performingar_prev_ver/determining_the_level_of_authority_by_issue.dita`

A Level 1 reconsideration agent can perform a request for reconsideration on any issue that was initially decided at Level 1, provided it is within Level 1 authority according to the National Policy on Levels of Decision . Level 1 authority covers, but is not limited to, the following:
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml#1)

- benefit rate

- earnings

- qualifying period (QP) extension

- insufficient hours

- special benefits

- BP duration

- BP extension

- BPNE

- denied antedate

- medical certificate

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4020.dita) 

A Level 1 reconsideration agent can perform a request for reconsideration when the initial decision on an earnings allocation was made by an Integrity agent:

- If a Level 1 Integrity agent completes an investigation with an earnings allocation that does not result in a warning letter, notice of violation or penalty, a Level 1 reconsideration agent can perform the request for reconsideration and correct the earnings or maintain the decision on file. If the issue is related to undeclared earnings reported after 6 weeks where the initial decision was made at Level 2, a Level 2 reconsideration agent performs the request for reconsideration. To determine whether a Level 1 or Level 2 Integrity agent rendered the initial decision, the agent reviews the transaction history in FTS. In the Additional Data (M107) or Allocations (M175) transaction relating to the earnings allocation, the Contentious field shows the following:

- No , if a Level 1 Integrity agent rendered the initial decision.

- Yes , if a Level 2 Integrity agent rendered the initial decision.

If the request for reconsideration does not fall within Level 1 authority according to the National Policy on Levels of Decision and is not one of the 2 exceptions noted above, a Level 2 reconsideration agent performs the request for reconsideration.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml#1) 

### Processing a request for reconsideration according to the Official Languages Act

Source topic: `en_EN/task/performingar_prev_ver/processing_a_request_for_reconsideratio_767ecbad.dita`

The Request for Reconsideration of an Employment Insurance (EI) Decision (INS5210) form does not ask in which language to process the request. However, the principles of section 5.5 of the Fact-Finding and Documentation Policy apply to reconsideration under EIA 112 .
       [Request for Reconsideration of an Employment Insurance (EI) Decision (INS5210)](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5210.pdf) 
       [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#s5_5) 
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.shtml) 

### Contacting the requester

Source topic: `en_EN/task/performingar_prev_ver/contacting_the_requester.dita`

The agent must contact the requester by telephone, except when the initial decision affecting the client can be completely rescinded to the client’s advantage without having to complete any additional fact-finding and there is no interested party involved.

The objectives of this mandatory telephone call to the requester are to:

- acknowledge receipt of the request for reconsideration;

- initiate fact-finding and gather information;

- explain the legislative requirements to obtain benefits; and

- explain the reconsideration under EIA 112 process (e.g. that the agent is not the same agent who made the initial decision; who might be contacted for information; the legislative requirements of the issue; and the recourse available if the decision is maintained).
         [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3987.dita) 

### Circumstances where a reconsideration under EIA 112 cannot be performed

Source topic: `en_EN/task/performingar_prev_ver/circumstances_where_a_reconsideration_u_0480ccc4.dita`

**Request from an unauthorized third party**

If a request for reconsideration is received from a third party without the appropriate requester’s signature and authorization of the interested party it is considered to be an invalid request and the reconsideration under EIA 112 is not performed.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

**No initial decision**

At times the Commission may receive a request to reconsider a decision before an initial decision has been made. In these cases, the reconsideration under EIA 112 cannot be performed because there is no initial decision to reconsider. This also applies to requests received when a reconsideration under EIA 112 has already been performed on the same issue (even if by another requester), but the request is related to a different time period (e.g. after the date of the reconsideration under EIA 112 decision).
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

If the notice of the initial decision was not sent, but the record shows that the Commission made a decision on the issue being challenged, the request for reconsideration is accepted and processed. The notice of the initial decision is not sent at this point. The notice of decision on the reconsideration sets the record straight.

**Issues outside the Commission’s authority**

At times a request may be received to review a decision that is related to an EI claim, but that is outside the Commission’s authority to review. These include the following:

- insurability of employment, hours and earnings

- benefit repayment (clawback)

- EI benefits for the self-employed (relating to date of registration, cancellation or termination of an agreement)

- responsibility of repayment and interest charged on an OP

During the course of the reconsideration under EIA 112 , the agent may have to determine if an issue is outside the Commission’s authority, and whether the request for reconsideration can be held in abeyance while waiting for a decision on another matter.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

**Decisions not subject to reconsideration under EIA 112**

A request may be received to review a decision that is not subject to a reconsideration under EIA 112 . The following decisions are not subject to a reconsideration under EIA 112 :
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

Work-sharing (WS) agreement: A decision about the approval or refusal of a WS agreement is not subject to a reconsideration under EIA 112 .
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

EIA 25 referral: A decision about the referral of a client to a course, program or other employment activity under EIA 25 is not subject to a reconsideration under EIA 112 . These issues must be resolved with the referring authority.
       [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html) 
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

Pilot Project: Working While on Claim: A decision about a reversion under Pilot Project: Working While on Claim is not subject to a reconsideration under EIA 112 This includes the denial of a request for reversion, the denial of a late request for reversion, and a request to undo a reversion.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

Write-off: A decision about writing off a penalty owed, amount payable or interest accrued on any penalty owed or amount payable is not subject to a reconsideration under EIA 112 . The client’s recourse regarding these issues is to seek judicial review with the Federal Court of Canada.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

Payment refusal requests: The decision to impose a D21 is discretionary. Denial of a payment refusal request is a decision that is not subject to a reconsideration under EIA 112 . The client’s recourse regarding this issue is to seek judicial review with the Federal Court of Canada.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

Voluntary disclosure: A decision to accept or refuse information under the voluntary disclosure policy is not subject to a reconsideration under EIA 112 . The client’s recourse regarding this issue is to seek judicial review with the Federal Court of Canada.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

The decision on the request for reconsideration reflects the Commission’s position and informs the client of the proper recourse. The client does not have the right to appeal in the above situations, and the SST is not mentioned in the letter of decision. Nevertheless, the client may still choose to file an appeal with the SST. It is the SST’s responsibility to decide whether the appeal will proceed or be dismissed.

**Canadian Charter of Rights and Freedoms**

The Commission does not address any issues regarding the application of the Canadian Charter of Rights and Freedoms. The reconsideration under EIA 112 proceeds only on the substantive issues.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 

### Processing an issue unrelated to issues under review

Source topic: `en_EN/task/performingar_prev_ver/processing_an_issue_unrelated_to_issues_cfc0f72d.dita`

During the reconsideration process under EIA 112 , the agent may come across one or more of the following 3 situations:
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- an issue not previously identified or adjudicated;

- a new issue that requires adjudication before benefits can be paid, in cases where the initial decision is being changed;

- an error unrelated to the decision being reviewed.

The agent can address an outstanding issue at the time of the reconsideration under EIA 112 only if it is essential in order to resolve the issue under review, or if the same facts and circumstances taken into consideration for the initial decision lead the reconsideration agent to another outcome, because the issues are inherently linked or there is an interconnected issue.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

In all other cases, the issue must be referred to Processing for review . When referring an issue to processing, the agent must exercise judgement and consider imposing a manual action in order to avoid paying benefits if there is a decision that remains to be adjudicated.
       [referred to Processing for review](/en/procedure/task/refissues.shtml)

**Processing issues considered to be inherently linked**

The following are examples of issues considered to be inherently linked that must be addressed at the time of the reconsideration under EIA 112 .
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

Example 1: BPNE and implied antedate

A reconsideration under EIA 112 is being performed on a decision about BPNE. During fact-finding, the client is implicitly asking for an antedate, and it may be possible to establish a claim if the antedate is granted. The agent must therefore address both issues because they are inherently linked. The agent completes all necessary fact-finding, makes a decision and informs the client of both decisions. If the decisions are negative, the agent provides appeal rights to the client on both issues. If the antedate is allowed, the agent completes the record of decision (ROD) as per adjudication procedures but only notifies the client that the BPNE decision has been rescinded in the decision letter.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

Example 2: Misconduct and voluntary leaving

A reconsideration under EIA 112 is being performed on a decision about a dismissal, but during fact-finding, the agent finds the issue is really voluntary leaving. As both issues are subject to EIA 30(1) , the agent makes a decision on the voluntary leaving.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [EIA 30(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

Example 3: Out of Canada and availability

A reconsideration under EIA 112 is being performed on a decision about an out of Canada issue, but the client declares that he or she was available and looking for work while out of Canada. The agent addresses the availability under EIA 18(1) and the exception outlined in EIR 55(1) .
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [EIA 18(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html) 
       [EIR 55(1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

Example 4: Not unemployed and availability

A reconsideration under EIA 112 is being performed on a decision about not unemployed and availability, but during fact-finding, the agent finds the unemployed issue is unsupported, and the time spent for the business makes the client’s availability questionable. The agent completes all necessary fact-finding, makes a decision, and informs the client of the decision. If the decision is negative, the agent provides appeal rights to the client.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

**Processing interconnected issues**

Indefinite disqualifications and violations affect future eligibility to benefits. When a request for reconsideration involves a BPNE decision, the client must clarify which decision is being contested as the actions required differ:

- If the client is contesting the decision not to establish a benefit period due to the insufficient number of insurable hours of employment, proceed with the reconsideration under EIA 112 of this issue.
         [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- If the client is contesting the initial decision (voluntary leaving, misconduct or violation) and this is the cause of the BPNE, address the client’s request for reconsideration of the earlier decision and ask the client to explain the delay in doing so, if necessary. While the earlier decision is being addressed, the reconsideration under EIA 112 of the BPNE decision can be held in abeyance until the decision has been made since that decision is required in order to review the BPNE decision. However, the request to hold the BPNE decision in abeyance in this situation is usually only requested if the reconsideration under EIA 112 of the initial decision is expected to take some time and could impact the speed of service on the BPNE decision.
         [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
         [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 

### Consulting a specialized unit

Source topic: `en_EN/task/performingar_prev_ver/consulting_a_specialized_unit.dita`

While performing a reconsideration under EIA 112, the reconsideration agent may need to consult a specialized unit agent to render a decision on a CCB claim. The processing agent can refer to this table found under Additional resources to ensure the appropriate steps are taken. Any claims for family caregiver benefits are processed by a hybrid team in the Ontario region.
       [table](/en/procedure/generic/additionalresources/reconsideration_referral_specialized_unit_instruction.shtml) 

### Processing a delayed request for reconsideration

Source topic: `en_EN/task/performingar_prev_ver/processing_a_delayed_request_for_reconsideration.dita`

According to the legislation, a requester must request a review within 30 calendar days of the communication of the initial decision. The Commission considers delays between 31 and 120 days to be short delays and approves the delay without further fact-finding. This period may be extended if the requester provides a reasonable explanation.

The request period starts on the earliest date the client, the employer or other person subject to the initial decision becomes aware of it:

- the date of the verbal communication, whether it is followed by a letter or not

- the date the notice of decision is received

- the date the Notice of Debt is received, if the notice of decision was not received and the request for reconsideration is linked to the OP or penalty amount 

### Suspending the recoupment of an overpayment (OP) or penalty

Source topic: `en_EN/task/performingar_prev_ver/suspending_the_recoupment_of_an_overpay_748870bb.dita`

Once a request for reconsideration is received, collection action is suspended for all outstanding OPs or penalties related to the issue to be reviewed. This is also true in cases where the decision is not being reviewed until it is determined if the delayed request is accepted, or if the issue under appeal is the refusal of a delayed reconsideration. Once the reconsideration under EIA 112 is complete, the collection action resumes on any OP that may remain.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4021.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4019.dita`

Note:

Any WIs related to an EI Emergency Response Benefit (EI ERB) claim are processed by a specialized team. For instructions on how to reassign these WIs, the agent refers to the workload management page in the ORT.
       [workload management](/en/procedure/generic/wl_mgmt_rfr.shtml)

     [workload management](/en/procedure/generic/wl_mgmt_rfr.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3984.dita`

Note:

In cases where, once contacted, clients refuse to proceed with the review because they do not want the employer contacted, the decision is maintained and notice is sent to the client only. 

### Note

Source topic: `en_EN/common_notes/note_c_4020.dita`

Note:

A Level 1 reconsideration agent can only perform a request for reconsideration on a denied antedate in the 2 following cases:

- The decision was initially made at Level 1 and it will be maintained.

- The decision can be reversed and good cause for the delay can be allowed at Level 1 according to the National Policy on Levels of Decision .
         [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml#1)

     [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml#1) 

### Note

Source topic: `en_EN/common_notes/note_c_3987.dita`

Note:

The initial telephone call may also end up being your fact-finding and decision call depending on the circumstances of the review. 

### Note

Source topic: `en_EN/common_notes/note_c_4021.dita`

Note:

The agent is ultimately responsible for ensuring the accuracy and completeness of all the information on the file including documentation, inputs in ADMS and notices of decision. 

## Regional considerations

Source topic: `en_EN/task/performingar_prev_ver/regional_considerations.dita`

When an agent has a request for reconsideration from another region, the file needs to be reassigned to the RFRA level of the client’s current address if the file involves the following:

- fishing benefits

- Bill C-56 self-employment benefits

- grievance settlements

- case groupings

- warrant replacements

- workers’ compensation benefits

- motor vehicle accident insurance

- training

- teacher claims

A Level 1 agent in the Quebec region may receive a claim from another region for maternity or parental benefits. In that case, the agent reassigns the WI in NWS to the RFRA level of the client’s current address.

A Level 1 agent in the Atlantic, Ontario or Western Canada and Territories region may receive a claim for QPIP benefits. In that case, the agent reassigns the WI in NWS to the RFRA-QC level. 

## What you need to look for

Source topic: `en_EN/task/performingar_prev_ver/what_you_need_to_look_for.dita`

### In Common Document Share:

Source topic: `en_EN/task/performingar_prev_ver/in_common_document_share.dita`

- What is the issue under review?

- Who is the requester? 

### In FTS:

Source topic: `en_EN/task/performingar_prev_ver/in_fts.dita`

- Is there an OP? 

### In Imaging:

Source topic: `en_EN/task/performingar_prev_ver/in_imaging.dita`

- Is there documentation on file relating to the issue under review? 

### In NWS:

Source topic: `en_EN/task/performingar_prev_ver/in_nws.dita`

- What is the issue under review?

- Is there documentation on file (SROC, ROD, etc.) for the initial decision under review?

- Is there documentation on file regarding verbal notification of the decision?

- If yes, what is the date of the notification?

- Is there a previous request for reconsideration of the same issue? 

### In ACS:

Source topic: `en_EN/task/performingar_prev_ver/in_acs.dita`

- Was a notice of decision sent?

- If yes, when? 

### In DARS:

Source topic: `en_EN/task/performingar_prev_ver/in_dars.dita`

- Was a Notice of Debt sent?

- If yes, when? 

### In ADMS:

Source topic: `en_EN/task/performingar_prev_ver/in_adms.dita`

- What is the issue under review?

- How many days have passed since the requester was notified of the decision?

- Is there a previous request for reconsideration of the same issue? 

## Step by step

Source topic: `en_EN/task/performingar_prev_ver/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/performingar_prev_ver/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/performingar_prev_ver/reviewing_the_file_level_1.dita`

- In ADMS, assign the file as follows:

- Select Search/Relate .

- Enter the client’s SIN or the employer’s number.

- Click Search .

- Matching records: Select the appropriate file.

- Start completing the Process Appeal screen as follows:

- Date received by SCBO: Enter the date the file was assigned to you.

- Determine if the request involves a third party:

- If no, go to step 4.

- If yes, refer to Determining if a third party has the authority to participate in a reconsideration under EIA 112 .
               [Determining if a third party has the authority to participate in a reconsideration under EIA 112](/en/procedure/task/thirdparty.shtml)

- Determine if the request was submitted on the Request for Reconsideration of an Employment Insurance (EI) Decision (INS5210) form:

- If it was not submitted on the form, go to step 5.

- If it was submitted on the form, go to step 6.

- Determine if the following information is present in the document:

- The name of the person making the request (and the client’s representative, if applicable)

- The client’s SIN or business number, address and telephone number

- The date on which the decision was communicated to the client

- A clear request to review or reconsider a decision

- If the information is not present, refer to Referring issues to Processing .
                   [Referring issues to Processing](/en/procedure/task/refissues.shtml)

- If the information is present, go to step 6.

- Determine the issue the requester would like to have reconsidered.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3991.dita)

- In ADMS, on the Issues tab ( Issue summary ), determine if all issues, sub-issues and sub-sub-issues requiring review are listed and complete:

- If all issues are not listed:

- Click Add/Modify Issue .

- Click Add Issue .

- Go to step 8.

- If all issues are not accurate or are incomplete:

- Click Add/Modify Issue .

- Go to step 8.

- If all issues are listed and complete, go to step 10.

- Add the new issue or modify incomplete or incorrect fields as follows:

- If adding a new issue: Click Add Issue .

- Issue: Select the appropriate issue.

- Sub-Issue: Select appropriate sub-issue if required.

- Sub-Sub-Issue: Select appropriate sub-sub-issue if required.

- Calling on Decision: If applicable, select the appropriate option:

- If there is indication the client was verbally advised of the initial decision and the right to request reconsideration, select Yes .

- If there is indication the client could not be contacted for verbal communication of the initial decision, select No .

- If verbal communication was not required for this issue, select N/A .

- Overpayment / Penalty: Select the appropriate option:

- If there is an OP or penalty, select Yes .

- If there is no OP or penalty, select No .

- Integrity: Select the appropriate option:

- If there is an Integrity case number on file, select Yes .

- If there is no Integrity case number on file, select No .

- Select Save.

- Repeat step 8.

- In NWS, add details to the AI WI as follows:

- Action: Select Additional information .

- Details: Enter all the issues that must be reconsidered completely and precisely.

- Determine if at least one of the following conditions that require creating separate files is met:

- An insurability ruling is required for more than one BP.

- The reconsideration is for more than one BP and the agent determined that separate files are required.

- The employer is not considered an interested party for each issue.

- If yes, in ADMS, create the necessary separate files. Refer to Registering a request for reconsideration if necessary. Repeat steps 6 to 9 to add issues in the new files.
                   [Registering a request for reconsideration](/en/procedure/task/registering_request_re.shtml)

- If no, no action is required.

- In Common Document Share, locate or create a record folder as follows:

- Select the appropriate folder based on the client’s SIN or the employer’s business number.

- Create a folder called “Record-[ADMS ID number]” (e.g. Record-12345).

- Move the request for reconsideration document into the newly created folder.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3999.dita)

- Determine if the file is from outside the region and involves the following:

- fishing benefits

- Bill C-56 self-employment benefits

- grievance settlement

- case grouping

- warrant replacement

- workers’ compensation benefits

- motor vehicle accident insurance

- training

- teacher claims

- If no, go to step 13.

- If yes, go to Reassigning the WI to another region .
                   [Reassigning the WI to another region](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/performingar_prev_ver#reassign_WI_to_another_region)

- Determine if all issues are for Level 1:

- If no, go to step 14.

- If yes, go to step 19.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4022.dita)

- Determine if one of the following situations exist:

- There is a potential antedate issue on a BPNE claim, the client qualifies at the earlier date and Level 2 support is required to determine if the reasons for the antedate can be allowed. Go to step 15.

- There is a potential OP write-off situation that needs Level 2 support to continue. Go to step 16.

- If none exist, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/performingar_prev_ver#reassign)

- In NWS, create an Action Item (AI) WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 2 support required — antedate.”

- Details: Enter the following information:

- ADMS record number.

- That the client qualifies at the earlier date if the antedate is allowed.

- Whether or not the client will still qualify if the antedate is denied and the reasons the BPNE can now be allowed.

- Obtained on: Select today’s date.

- Source Details: Type “Request for reconsideration.”

- Urgent: Check the box.

- Go to step 17.

- In NWS, create an AI WI for Level 2 as follows:

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 2 support required — OP write-off.”

- Details: Enter the following information:

- ADMS record number.

- The criteria that was met to have the OP written off.

- Obtained on: Select today’s date.

- Source Details: Type “Request for reconsideration.”

- Urgent: Check the box.

- In NWS, move the initial AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting adjudication from the Level 2 agent.”

- Bring forward date: Enter the appropriate date.

- When the AI WI moves to the current workload, verify if the decision was made:

- If no, return to step 17.

- If yes, go to step 19.

- Determine if the issue under review is subject to a reconsideration under EIA 112 :

- If the issue is subject to a reconsideration under EIA 112 , go to step 20.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- If the issue is not subject to a reconsideration under EIA 112 , refer to Reviewing a decision that is not subject to a reconsideration under EIA 112 .
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
               [Reviewing a decision that is not subject to a reconsideration under EIA 112](/en/procedure/task/notsubjecttour.shtml)

- Determine if suspension of collection of an OP or penalty is required by referring to Suspending collection of a debt .

- Determine if an initial decision has been made concerning the issue to be reviewed:

- If an initial decision has been made, go to step 22.

- If an initial decision has not been made, refer to Referring issues to Processing.
               [Referring issues to Processing.](/en/procedure/task/refissues.shtml)

- Determine if the issue is within the Commission’s authority by consulting Determining if the issue is within the Commission’s authority .

- Determine if a notice of decision was sent:

- If a notice of decision was sent, go to step 24.

- If a notice of decision was not sent, go to step 25.

- Determine if there are any errors in the notice of decision:

- If there are errors, contact the client to explain the correct decision.
               [contact](/en/procedure/task/contactparties.shtml)

- If there are no errors, go to step 25.

- Determine if the decision created an OP or penalty:

- If no OP or penalty was created as a result of the decision, go to step 26.

- If an OP or penalty was created as a result of the decision, note that if the time limit according to EIA 52 of 36 or 72 months has not expired, the client can be notified of the decision in the course of the reconsideration under EIA 112 . This serves as notification of the decision. Go to step 26.
               [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html) 
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4000.dita)

- In ADMS, complete the Process Appeal screen as follows:

- Initial Decision Communicated: Enter the date the requester was notified of the decision and advised of the right to request reconsideration.

- Click Save .

- Determine if the request was received within 30 days of the date the requester was notified of the decision:

- If the request was received within the time frame, go to step 28.

- If the request was not received within the time frame, refer to Adjudicating a delayed request for reconsideration .
               [Adjudicating a delayed request for reconsideration](/en/procedure/task/delayeddr.shtml)

- Determine if the requester is requesting a review of a decision for a period already reviewed as part of a reconsideration under EIA 112 , a new period, or both:

- If the request is to review the decision for a period already reviewed, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/performingar_prev_ver#reassign)

- If the request is to review a new period, refer the issue to Processing .
               [refer the issue to Processing](/en/procedure/task/refissues.shtml)

- If the request is for both, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/performingar_prev_ver#reassign)

- Determine if the reconsideration under EIA 112 needs to be held in abeyance by referring to Holding a reconsideration under EIA 112 in abeyance. 

#### Reconsidering the initial decision

Source topic: `en_EN/task/performingar_prev_ver/reconsidering_the_initial_decision_level_1.dita`

- Review the initial decision and determine the following:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4023.dita) 

- If yes to all, go to step 31.

- If no to some, note where the initial decision was not sound, and go to step 31.

- Taking into account any new information provided on the request for reconsideration or in any systems (NWS, Imaging, RCM, Common Document Share folder, etc.), determine if there is sufficient information on file to make a correct final decision:

- If no, to conduct additional fact-finding, go to step 32.

- If yes, to make the final decision, go to step 38.

- Fact-find with the interested parties, as required. If necessary, refer to the Digest of Benefit Entitlement Principles , Jurisprudence Guidance Memos and the Fact-Finding Guide to determine the questions to ask.

- Determine if one of the following situations exist:

- There is a potential antedate issue on a BPNE claim, the client qualifies at the earlier date and Level 2 support is required to determine if the reasons for the antedate can be allowed. Go to step 34.

- There is a potential OP write-off situation that needs Level 2 support to continue. Go to step 35.

- If none exist, go to step 38.

- In NWS, create an AI WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 2 support required — Antedate.”

- Details: Enter the following information:

- ADMS record number.

- That the client qualifies at the earlier date if the antedate is allowed.

- Whether or not the client will still qualify if the antedate is denied and the reasons the BPNE can now be allowed.

- Obtained on: Select today’s date.

- Source Details: Type “Request for reconsideration.”

- Urgent: Check the box.

- Go to step 36.

- In NWS, create an AI WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 2 support required — OP write-off.”

- Details: Enter the following information:

- ADMS record number.

- The criteria that was met to have the OP written off.

- Obtained on: Select today’s date.

- Source Details: Type “Request for reconsideration.”

- Urgent: Check the box.

- In NWS, move the initial AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting adjudication from the Level 2 agent.”

- Bring forward date: Enter the appropriate date.

- When the AI WI moves to the current workload, verify if the decision was made:

- If no, return to step 36.

- If yes, go to step 38.

- Taking into consideration all the facts on file, including any additional information, fact-finding or evidence for the period of the initial decision, decide whether or not the initial decision is maintained, maintained with modifications, or rescinded by doing the following:

- Weigh the credibility, relevance and reliability of each type of evidence.

- If the decision is related to the loss of employment and the evidence gathered from the parties is equally balanced, the benefit of the doubt must be given to the client.

- Place the burden of proof on the correct party (client or Commission).

- Apply the correct standard of proof.

- Apply the correct EI legislation, jurisprudence and Commission policies and directives to support the decision.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4024.dita)

- In NWS, create a ROD (or add to a previously drafted ROD) as follows:

- New ROD: Comments: Type “RFR [ADMS record number] — [issue] — [employer name and last day worked (if necessary)] — decision [maintained, modified or rescinded].”

- Details: Document the decision and rationale using the applicable Reconsideration ROD template .
               [Reconsideration ROD template](/en/procedure/generic/ar_index_cft_afg.shtml)

- Click Draft .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4025.dita)

- Determine if verbally communicating the decision under EIA 112 is required.

- Determine if an OP or penalty was suspended while the reconsideration under EIA 112 was being performed:

- If no, go to step 42.

- If yes, go to Reinstating the collection of a debt and return to step 42.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4026.dita)

- If the decision is changed, make the necessary changes in the applicable systems (FTS, RCM, DARS, etc.).

[Important](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4027.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4028.dita)

- Communicate the reconsideration under EIA 112 decision in writing .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4006.dita) 

#### Completing the inputs after the reconsideration

Source topic: `en_EN/task/performingar_prev_ver/completing_the_inputs_after_the_reconsideration_level_1.dita`

- Determine if the initial decision was rescinded, modified or maintained:

- If the decision was rescinded, go to step 45.

- If the decision was modified, go to step 46.

- If the decision was maintained, go to step 47.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision result: Select Decision rescinded .

- Reason: Select the applicable reason why the decision was rescinded.

- Date RFR Decision Implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Click Save.

- Go to step 48.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained with Modifications .

- Date RFR Decision implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Click Save.

- Go to step 48.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained .

- Date RFR Decision implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Click Save .

- Determine if ADMS inputs are complete for all decisions:

- If yes, go to step 49.

- If no, complete the missing fields, then go to step 49.

- In NWS, complete the WI.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4029.dita) 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/performingar_prev_ver/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Request for reconsideration about an issue for Level 2.”

- Click OK .

- In ADMS, from the main workload screen, do the following:

- Select the related file.

- Click Assign to .

- Last name: Type “Unassigned” and click Find .

- Select the level 2 bin according to the region in which the client resides.

- Click Assign to . 

#### Reassigning the WI to another region

Source topic: `en_EN/task/performingar_prev_ver/reassigning_the_wi_to_another_region_level_1.dita`

- In ADMS, from the main workload screen, do the following:

- Select the related file.

- Click Assign to .

- Last name: Type “Unassigned” and click Find .

- Select the bin according to the region in which the client resides and the appropriate level (1 or 2).

- Click Assign to .

- In NWS, reassign the WI as follows:

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- Complexity: Select Level 1 .

- Reason: Select Unable to complete .

- Details: Type “Request for reconsideration has an issue that needs to be processed regionally.”

- Click OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_3991.dita`

Note:

A guide is available to help locate the clues and identify the issue.
       [guide](/en/procedure/generic/administrative_review.shtml)

     [guide](/en/procedure/generic/administrative_review.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_3999.dita`

Note:

If moving from a different location in the Common Document Share, delete the previous folder after moving. 

#### Note

Source topic: `en_EN/common_notes/note_c_4022.dita`

Note:

In order to identify Level 1 issues that are related to a post audit and that must therefore be reviewed at Level 2, review the information available in ACS, FTS, or in RODs shown in NWS. Determine if a warning letter, penalty or notice of violation relating to the issue under reconsideration was sent to the client. 

#### Note

Source topic: `en_EN/common_notes/note_c_4000.dita`

Note:

A reconsideration under EIA 112 addresses only the portion of the OP created within the 36- or 72-month period between the time benefits were paid and the time the client is notified of the decision that created the OP. Any portion of an OP or penalty created outside of that time limit can be cancelled. If the client declares not having received the notice of the decision, refer to Actioning a Notice of Debt declared by the client as not received .
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [Actioning a Notice of Debt declared by the client as not received](/en/procedure/task/actioning_nddcnr.shtml)

     [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
     [Actioning a Notice of Debt declared by the client as not received](/en/procedure/task/actioning_nddcnr.shtml) 

#### Callout

Source topic: `en_EN/common_notes/note_c_4023.dita`

Was credibility an issue and if so, was it properly assessed?

Were all contradictions clarified?

Is all the necessary evidence on the file, including relevant documents, and was the file properly considered?

Was the correct legal test applied to the issue?

Was the onus of proof placed on the correct party?

Was the benefit of the doubt policy, if applicable, applied correctly?

If it was a discretionary decision, did the Commission exercise its authority judiciously?

If the issue was a post audit, was the decision made within the applicable time frames?

Was the decision made in accordance with the relevant legislation including EIA, EIR, the Digest of Benefit Entitlement Principles and relevant jurisprudence? 

#### Note

Source topic: `en_EN/common_notes/note_c_4024.dita`

Note:

If the initial decision was sound, but entitlement is proven currently, the initial decision is terminated from that date and is considered as maintained with modifications. Inform the requester that:

- there is a new definite period of the disentitlement;

- the claim is currently allowed;

- the requester has the right to appeal to the SST if the requester disagrees with the decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_4025.dita`

Note:

Add jurisprudence in the ROD only if necessary to support your decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_4026.dita`

Note:

Even if you are rescinding the decision, if there was an OP suspended in relation to the issue on an active or non-blocked claim, you must reinstate collection of the debt in DARS before you can make changes to the file in FTS. If it is an archived claim or a blocked claim that is not updateable using BCS, complete only the ADMS input for the collection action. Include a request to reinstate collection in DARS on the Operational Centre Memo (MM06) to IPOC. 

#### Important

Source topic: `en_EN/common_notes/note_c_4027.dita`

Important:

When a decision that resulted in an OP is completely rescinded on an archived claim or a blocked claim that is not updateable using BCS, send the inputs to IPOC on an Operational Centre Memo (MM06) . 

#### Note

Source topic: `en_EN/common_notes/note_c_4028.dita`

Note:

Be sure to review whether any action needs to be taken on previous claims due to the new decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_4006.dita`

Note:

In cases where clients have refused to proceed with the process because they do not want the employer contacted, no written notice is sent to the employer. 

#### Note

Source topic: `en_EN/common_notes/note_c_4029.dita`

Note:

Once the reconsideration under EIA 112 is complete, immediately determine whether there are documents which are not on file in an electronic format or that are not readily accessible (same-day access) if an appeal was filed. Examples include, but are not limited to: archived claimant’s reports, Customs Match documents (e.g. the E-311 Customs Declaration Card), recently received documentation or paper ROEs. These documents must be obtained immediately and stored in Common Document Share. Also, if the documentation on file is extensive, the information must be gathered and saved in the Common Document Share reconsideration file. This ensures that the Commission meets the 5-day requirement if an appeal to the SST is filed.
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [Customs Match](https://edsc.prv/en/service-canada/ei/technologies/control-detection/rcrp_description.shtml)

     [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
     [Customs Match](https://edsc.prv/en/service-canada/ei/technologies/control-detection/rcrp_description.shtml) 

### Level 2

Source topic: `en_EN/task/performingar_prev_ver/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/performingar_prev_ver/reviewing_the_file_level_2.dita`

- Determine if you have an AI WI titled “Level 2 support”:

- If no, go to step 2.

- If yes, go to Processing a WI for Level 2 support .
               [Processing a WI for Level 2 support](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/performingar_prev_ver#WIs_for_Level2)

- In ADMS, assign the file as follows:

- Select Search/Relate .

- Enter the client’s SIN or the employer’s number.

- Click Search .

- Matching records: Select the appropriate file.

- Start completing the Process Appeal screen as follows:

- Date received by SCBO: Enter the date the file was assigned to you.

- Initial Decision Communicated: Enter the date the requester was notified of the decision and advised of the right to request reconsideration.

- Click Save .

- Determine if the request involves a third party:

- If no, go to step 5.

- If yes, refer to Determining if a third party has the authority to participate in a reconsideration under EIA 112 .
               [Determining if a third party has the authority to participate in a reconsideration under EIA 112](/en/procedure/task/thirdparty.shtml)

- Determine if the request was submitted on the Request for Reconsideration of an Employment Insurance (EI) Decision (INS5210) form:

- If it was not submitted on the form, go to step 6.

- If it was submitted on the form, go to step 7.

- Determine if the following information is present in the document:

- The name of the person making the request (and the client’s representative, if applicable)

- The client’s SIN or business number, address and telephone number

- The date on which the decision was communicated to the client

- A clear request to review or reconsider a decision

- If the information is not present, refer to Referring issues to Processing .
                   [Referring issues to Processing](/en/procedure/task/refissues.shtml)

- If the information is present, go to step 7.

- Determine the issue the requester would like to have reconsidered.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3991.dita)

- In ADMS, on the Issues tab ( Issue summary ), determine if all issues, sub-issues and sub-sub-issues requiring review are listed and complete:

- If all issues are not listed:

- Click Add/Modify Issue .

- Click Add Issue .

- Go to step 9.

- If all issues are not accurate or are incomplete:

- Click Add/Modify Issue .

- Go to step 9.

- If all issues are listed and complete, go to step 11.

- Add the new issue or modify incomplete or incorrect fields as follows:

- If adding a new issue: Click Add Issue .

- Issue: Select the appropriate issue.

- Sub-Issue: Select appropriate sub-issue if required.

- Sub-Sub-Issue: Select appropriate sub-sub-issue if required.

- Calling on Decision: If applicable, select the appropriate option:

- If there is indication the client was verbally advised of the initial decision and the right to request a reconsideration, select Yes .

- If there is indication the client could not be contacted for verbal communication of the initial decision, select No .

- If verbal communication was not required for this issue, select N/A .

- Overpayment / Penalty: Select the appropriate option:

- If there is an OP or penalty, select Yes .

- If there is no OP or penalty, select No .

- Integrity: Select the appropriate option:

- If there is an Integrity case number on file, select Yes .

- If there is no Integrity case number on file, select No .

- Select Save .

- Repeat step 9.

- In NWS, add details to the AI WI as follows:

- Action: Select Additional information .

- Details: Enter all the issues that must be reconsidered completely and correctly.

- Determine if at least one of the following conditions that require creating separate files is met:

- An insurability ruling is required for more than one BP.

- The reconsideration is for more than one BP and the agent determined that separate files are required.

- The employer is not considered an interested party for each issue.

- If yes, in ADMS, create the necessary separate files. Refer to Registering a request for reconsideration if necessary. Repeat steps 7 to 10 to add issues in the new files.
                   [Registering a request for reconsideration](/en/procedure/task/registering_request_re.shtml)

- If no, no action is required.

- In Common Document Share, locate or create a record folder as follows:

- Select the appropriate folder based on the client’s SIN or the employer’s business number.

- Create a folder called “Record-[ADMS ID number]” (e.g. Record-12345).

- Move the request for reconsideration document into the newly created folder.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3999.dita)

- If there is more than one issue under review, verify if the employer is a party to only one of the issues:

- If the employer is a party to only one of the issues, go to step 14.

- If the employer is a party to none of the issues, go to step 15.

- If the employer is a party to all issues, go to step 15.

- In Common Document Share, create a separate record folder for each issue. Refer to Registering a request for reconsideration and return to step 15.

- Determine if the issue under review is subject to a reconsideration under EIA 112 :

- If the issue is subject to a reconsideration under EIA 112 , go to step 16.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- If the issue is not subject to a reconsideration under EIA 112 , refer to Reviewing a decision that is not subject to a reconsideration under EIA 112 .
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
               [Reviewing a decision that is not subject to a reconsideration under EIA 112](/en/procedure/task/notsubjecttour.shtml)

- Click Save .

- Determine if suspension of collection of an OP or penalty is required by referring to Suspending collection of a debt .

- Determine if an initial decision has been made concerning the issue to be reviewed:

- If an initial decision has been made, go to step 18.

- If an initial decision has not been made, refer to Referring issues to Processing.
               [Referring issues to Processing.](/en/procedure/task/refissues.shtml)

- Determine if the issue is within the Commission’s authority by consulting Determining if the issue is within the Commission’s authority .

- Determine if a notice of decision was sent:

- If a notice of decision was sent, go to step 20.

- If a notice of decision was not sent, go to step 21.

- Determine if there are any errors in the notice of decision:

- If there are errors, contact the client to explain the correct decision.
               [contact](/en/procedure/task/contactparties.shtml)

- If there are no errors, go to step 21.

- Determine if the decision created an OP or penalty:

- If no OP or penalty was created as a result of the decision, go to step 22.

- If an OP or penalty was created as a result of the decision, note that if the time limit according to EIA 52 of 36 or 72 months has not expired, the client can be notified of the decision in the course of the reconsideration under EIA 112 . This serves as notification of the decision. Go to step 22.
               [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html) 
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4010.dita)

- In ADMS, complete the Process Appeal screen as follows:

- Initial Decision Communicated: Enter the date the requester was notified of the decision and advised of the right to request reconsideration.

- Click Save .

- Determine if the request was received within 30 days of the date the requester was notified of the decision:

- If the request was received within the time frame, go to step 24.

- If the request was not received within the time frame, refer to Adjudicating a delayed request for reconsideration .
               [Adjudicating a delayed request for reconsideration](/en/procedure/task/delayeddr.shtml)

- Determine if the requester is requesting a review of a decision for a period already reviewed as part of a reconsideration under EIA 112 , a new period, or both:

- If the request is to review the decision for a period already reviewed, refer to Determining if EIA 111 is applicable following a reconsideration under EIA 112 .
               [Determining if EIA 111 is applicable following a reconsideration under EIA 112](/en/procedure/task/eiapplicable.shtml)

- If the request is to review a new period, refer the issue to Processing .
               [refer the issue to Processing](/en/procedure/task/refissues.shtml)

- If the request is for both, process both requests.

- Determine if the reconsideration under EIA 112 needs to be held in abeyance by referring to Holding a reconsideration under EIA 112 in abeyance.

- Determine if there is more than one interested party to the decision:

- If there is more than one interested party, go to step 27.

- If there only one interested party, go to step 30.

- Determine if the party to be added is an employer or a client:

- If the party to be added is an employer, go to step 28.

- If the party to be added is the client, go to step 29.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4012.dita)

- In ADMS, on the Participants tab, unless specified, select the most appropriate option for each of the following attributes:

- Click Add participant .

- What kind of participant do you want to add?: Select Organization .

- Type: Select Employer .

- Business number: Enter the employer’s business number.

- Organization name: Enter the employer’s name.

- Language: Select the appropriate option.

- Address: Enter the employer’s address.

- City: Enter the employer’s city.

- Province: Enter the employer’s province.

- Postal code: Enter the employer’s postal code.

- Telephone (Work): Enter the employer’s phone number.

- Email: Enter the employer’s email.

- Click Save .

- Go to step 30.

- In ADMS, on the Participants tab, unless specified, select the most appropriate option for each of the following attributes:

- Click Add participant .

- What kind of participant do you want to add?: Select Individual .

- Enter the Social Insurance Number (SIN) if applicable: Enter the client’s SIN and click Proceed .

- Type: Select Claimant .

- SIN: Enter the client’s SIN.

- First name: Enter the client’s first name.

- Last name: Enter the client’s last name.

- Language : Select the appropriate option.

- Address: Enter the client’s address.

- City: Enter the client’s city.

- Province: Enter the client’s province.

- Postal code: Enter the client’s postal code.

- Telephone (Home): Enter the client’s phone number.

- Email: Enter the client’s email.

- Click Save . 

#### Reconsidering the initial decision

Source topic: `en_EN/task/performingar_prev_ver/reconsidering_the_initial_decision_level_2.dita`

- Review the initial decision and determine the following:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4023.dita) 

- If yes to all, go to step 31.

- If no to some, note where the initial decision was not sound, and go to step 31.

- Taking into account any new information provided on the request for reconsideration or in any systems (NWS, Imaging, RCM, Common Document Share folder, etc.), determine if there is sufficient information on file to make a correct final decision:

- If no, to conduct additional fact-finding, go to step 32.

- If yes, to make the final decision, go to step 33.

- Fact-find with the interested parties, as required. If necessary, refer to the Digest of Benefit Entitlement Principles , Jurisprudence Guidance Memos and the Fact-Finding Guide to determine the questions to ask.

- Determine if Level 1 support is necessary to adjudicate:

- If yes, go to step 34.

- If no, go to step 37.

- In NWS, create an AI WI as follows:

- Complexity: Select Level 1 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 1 support required.”

- Details: Enter the ADMS record number and the details on actions required.

- Obtained on: Select today’s date.

- Source Details: Type “Request for reconsideration.”

- Urgent: Check the box.

- In NWS, move the initial AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting actions from the Level 1 agent.”

- Bring forward date: Enter the appropriate date.

- When the AI WI moves to the current workload, verify if the actions were taken:

- If no, return to step 35.

- If yes, go to step 37.

- Taking into consideration all the facts on file, including any additional information, fact-finding or evidence for the period of the initial decision, decide whether or not the initial decision is maintained, maintained with modifications, or rescinded by doing the following:

- Weigh the credibility, relevance and reliability of each type of evidence.

- If the decision is related to the loss of employment and the evidence gathered from the parties is equally balanced, the benefit of the doubt must be given to the client.

- Place the burden of proof on the correct party (client or Commission).

- Apply the correct standard of proof.

- Apply the correct EI legislation, jurisprudence and Commission policies and directives to support the decision.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4030.dita)

- In NWS, create a ROD (or add to a previously drafted ROD) as follows:

- New ROD: Comments: Type “RFR [ADMS record number] — [issue] — [employer name and last day worked (if necessary)] — decision [maintained, modified or rescinded].”

- Details: Document the decision and rationale using the applicable Reconsideration ROD template .
               [Reconsideration ROD template](/en/procedure/generic/ar_index_cft_afg.shtml)

- Click Draft .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4025.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4031.dita)

- Determine if verbally communicating the decision under EIA 112 is required.

- Determine if an OP or penalty was suspended while the reconsideration under EIA 112 was being performed:

- If no, go to step 41.

- If yes, go to Reinstating the collection of a debt and go to step 41.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4026.dita)

- If the decision is changed, determine if a recalculation is required to implement the decision:

- If a recalculation is required and you do not have the training to process it, go to step 42.

- If recalculation is not required or if you have the training to process it, go to step 45.

- In NWS, create an AI WI as follows:

- Complexity: Select Level 1 .

- Destination: Select the appropriate option based on the client’s current address

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “RFR — recalculation.”

- Details: Enter the ADMS record number and the details on actions required.

- Obtained on: Select today’s date.

- Source Details: Type “Request for reconsideration.”

- In NWS, move the initial AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting actions from the Level 1 agent.”

- Bring forward date: Enter the next working day.

- When the AI WI moves to the current workload, verify if the actions were taken:

- If no, return to step 43.

- If yes, go to step 45.

- If the decision is changed, make the necessary changes in the applicable systems (e.g. FTS, RCM, DARS).

[Important](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4032.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4028.dita)

- Communicate the reconsideration under EIA 112 decision in writing .

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4006.dita) 

#### Completing the inputs after the reconsideration

Source topic: `en_EN/task/performingar_prev_ver/completing_the_inputs_after_the_reconsideration_level_2.dita`

- Determine if the initial decision was rescinded, modified or maintained:

- If the decision was rescinded, go to step 48.

- If the decision was modified, go to step 49.

- If the decision was maintained, go to step 50.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision result: Select Decision rescinded .

- Reason: Select the applicable reason why the decision was rescinded.

- Date RFR Decision Implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Click Save .

- Go to step 52.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained with Modifications .

- Date RFR Decision implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Click Save .

- Go to step 52.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained .

- Date RFR Decision implemented: Enter the date the decision was implemented.

- Date RFR Decision sent to Requestor: Enter the date the letter was sent.

- Click Save .

- In NWS, complete the WI.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4029.dita) 

#### Processing a WI for Level 2 support

Source topic: `en_EN/task/performingar_prev_ver/processing_a_wi_for_level_2_support_level_2.dita`

- Taking into account any information provided on the request for reconsideration or in any systems (NWS, Imaging, RCM, Common Document Share folder, etc.), determine if there is sufficient information on file to make a correct decision:

- If no, to conduct additional fact-finding, go to step 2.

- If yes, to make the decision, go to step 3.

- Fact-find with the interested parties, as required. If necessary, refer to the Digest of Benefit Entitlement Principles , Jurisprudence Guidance Memos and the Fact-Finding Guide to determine the questions to ask.

- Determine the issue and do the following:

- If the decision is related to an antedate, go to step 4.

- If the decision is related to an OP write-off, refer to Adjudicating a write-off for ROD and letter requirements, then go to step 14.
               [Adjudicating a write-off](/en/procedure/task/adjudicating_write_off.shtml)

- In NWS, create a ROD (or add to a previously drafted ROD) as follows:

- New ROD: Comments: Type “RFR [ADMS record number] — [issue] — [employer name and last day worked (if necessary)] — decision [maintained, modified or rescinded].”

- Details: Document the decision and rationale using the applicable Reconsideration ROD template .
               [Reconsideration ROD template](/en/procedure/generic/ar_index_cft_afg.shtml)

- Click Draft .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4025.dita)

- Determine if verbally communicating the decision under EIA 112 is required.

- Determine if the initial decision was rescinded, modified or maintained:

- If the decision was rescinded, go to step 7.

- If the decision was modified, go to step 9.

- If the decision was maintained, go to step 11.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision result: Select Decision rescinded .

- Reason: Select the applicable reason why the decision was rescinded.

- Click Save .

- In ACS, create and save the X-01-00-00 letter. Based on the claim information, select all of the required, including the following:

- Insert ADMS Record ID (4059)

- Notice of Administrative Review Decision addressed to client - Client Requested Reconsideration (11980)

- Date Request for Reconsideration received (4063)

- Date of Commission’s decision (4065): Select the date on the initial decision letter.

- List of issues (11981)

- Decision completely rescinded or removed /maintained / modified or replaced by a new decision (11982): Select Decision completely rescinded or removed .

- Date of Commission’s decision (4065): Select the earliest date the client was notified of the decision (verbally or in writing).

- Blank / Text: Describe impact of this reversal (4041): Select Text: Describe impact of this reversal .

- Go to step 13.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained with Modifications .

- Click Save .

- In ACS, create and save the X-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Insert ADMS Record ID (4059)

- Notice of Administrative Review Decision addressed to client - Client Requested Reconsideration  (11980)

- Date Request for Reconsideration received (4063)

- Date of Commission’s decision (4065): Select the date on the initial decision letter.

- List of issues (11981)

- Decision completely rescinded or removed /maintained / modified or replaced by a new decision (11982): Select Decision modified or replaced by a new decision .

- Date of Commission’s decision (4065): Select the earliest date the client was notified of the decision (verbally or in writing).

- Blank/Additional information (4039): Select Additional Information

- Text - Free Text (1612): Explain the new decision.

- Go to step 13.

- In ADMS, complete the Review Decision screen as follows:

- Date RFR Decision issued: Enter the date the reconsideration under EIA 112 was finalized.
               [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- RFR Decision Result: Select Decision Maintained .

- Click Save .

- In ACS, create and save the X-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Insert ADMS Record ID (4059)

- Notice of Administrative Review Decision addressed to claimant- Claimant Requested Reconsideration (11980)

- Date Request for Reconsideration received (4063)

- Date of Commission’s decision (4065): Select the date on the initial decision letter.

- List of issues (11981)

- Decision completely rescinded or removed /maintained/ modified or replaced by a new decision (11982): Select Decision maintained

- Date of Commission’s decision (4065): Select the earliest date the client was notified of the decision (verbally or in writing).

- Blank/Specify reasons maintained (4042): Select Specify reasons maintained .

- Text - Free Text (1612): Explain why the decision was maintained.

- In NWS, create a client Note instructing the Level 1 reconsideration agent responsible for implementation to add the appropriate attributes before sending the saved X-01-00-00 letter in ACS.

- Complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4010.dita`

Note:

A reconsideration under EIA 112 addresses only the portion of the OP created within the 36- or 72-month period between the time benefits were paid and the time the client is notified of the decision that created the OP. Any portion of an OP or penalty created outside of that time limit can be cancelled. If the client declares not having received the notice of decision refer to Actioning a Notice of Debt declared by the client as not received .
       [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
       [Actioning a Notice of Debt declared by the client as not received](/en/procedure/task/actioning_nddcnr.shtml)

     [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html) 
     [Actioning a Notice of Debt declared by the client as not received](/en/procedure/task/actioning_nddcnr.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_4012.dita`

Note:

If either has a representative, refer to Determining if a third party has the authority to participate in a reconsideration under EIA 112 .
       [Determining if a third party has the authority to participate in a reconsideration under EIA 112](/en/procedure/task/thirdparty.shtml)

     [Determining if a third party has the authority to participate in a reconsideration under EIA 112](/en/procedure/task/thirdparty.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_4030.dita`

Note:

If the initial decision was sound, but entitlement is proven currently, the initial decision is terminated from that date and is considered as maintained with modifications. Inform the requester of the new definite period of the disentitlement, and also that the claim is allowed currently. Explain the appeal rights to the SST to the client, if the client is unsatisfied with the modified decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_4031.dita`

Note:

An employer may file a request for reconsideration of a decision regarding the claim for benefits of a current or former employee, and the agent determines that the initial decision must be rescinded and replaced by a new one. The new decision is retroactive and may result in an OP of benefits, as in the case of disqualifications. 

#### Important

Source topic: `en_EN/common_notes/note_c_4032.dita`

Important:

When a decision about a reason for separation is changed, the Special Condition field on the ROE in RCM must be changed to reflect the correct decision and the original ROD must be invalidated in NWS as the ROE and the automatically resolved or automatically adjudicated ROD may be used in the recalculation of a claim, or in the establishment of a new BPC in the future. Failure to make the change could result in the incorrect payment of benefits in the case of automation.

When a decision that resulted in an OP is completely rescinded on an archived claim or a blocked claim that is not updateable using BCS, send the inputs to IPOC on an Operational Centre Memo (MM06) . 

## Policy reference

Source topic: `en_EN/task/performingar_prev_ver/policy_reference.dita`

- EIA 52
         [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- EIA 53
         [EIA 53](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-53.html)

- EIA 112
         [EIA 112](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- EIA 112.1
         [EIA 112.1](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.1.html)

- EIR 77.96(8)
         [EIR 77.96(8)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-77.96.html)

- EIR 78(1)
         [EIR 78(1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-78.html)

- EIR 78(2)
         [EIR 78(2)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-78.html#984410) 
