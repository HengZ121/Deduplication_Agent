# Cancelling a benefit period

Source map: `en_EN/task/benefit_period_cancel/benefit_period_cancel.ditamap`

## Summary

Source topic: `en_EN/task/benefit_period_cancel/summary.dita`

Summary: When a client requests the cancellation of a benefit period (BP) or when a renewal claim may not be as beneficial to a client as a new BP, the officer determines if the existing BP can be cancelled. 

## What you need to know

Source topic: `en_EN/task/benefit_period_cancel/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/benefit_period_cancel/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2152.dita) 

### Reviewing a benefit period (BP) when a client submits an application and there is an established claim

Source topic: `en_EN/task/benefit_period_cancel/reviewing_a_benefit_period_bp_when_a_cl_bdbbe54d.dita`

When a Claim Assessment (CA) or Specialized Application (SA) WI is created for a client with a renewable BP, the officer reviews the BP to determine if a renewal, termination or cancellation would be more beneficial for the client.

Generally, when a client who still has entitlement weeks on an established BP submits an application, the BP is renewed. Clients are advised on the renewal application that their BP is automatically renewed and that if they want to have a new BP instead of a renewal, they must telephone the call centre. A call centre officer who cannot complete the cancellation for the client creates a Call Back (CB) WI and refers it for processing.

A client can also request to retroactively cancel a BP, even when benefits were paid or payable. This can occur when a client requests that a new BP be established after a BP is renewed or a disentitlement is terminated.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2153.dita) 

### Reviewing the advantages and disadvantages with the client

Source topic: `en_EN/task/benefit_period_cancel/reviewing_the_advantages_and_disadvanta_7d0e43f1.dita`

When considering a cancellation, the officer reviews the advantages and disadvantages of cancelling the BP with the client. The BP can only be cancelled without contacting the client if it is clearly to the client’s advantage. When a client decides to cancel the BP, the decision is final, and cannot be reversed.

When a BP is cancelled, it is treated as if it never existed. The hours and earnings used to establish the cancelled BP can be used to establish a new BP. 

### Conditions to cancel a benefit period (BP)

Source topic: `en_EN/task/benefit_period_cancel/conditions_to_cancel_a_benefit_period_bp.dita`

A BP can be cancelled when a new BP can be established and one of the following conditions is met:

- The BP has terminated and no benefits were paid or payable during that period.
         [payable](/en/procedure/generic/knowledge.shtml#Entitlement_Weeks_Paid_or_Payable)

- No benefits were paid or payable during the BP, whether ended or not, and the client is requesting a claim cancellation.

- Benefits are considered paid and all of the following conditions are met:

- The only weeks paid were weeks of definite disqualification served;

- The client is applying for and is entitled to special benefits;

- The client meets one of the following conditions related to the hours of insurable employment in the qualifying period (QP):

- The client is minor attached (has fewer than 600 hours of insurable employment) and, after cancelling the old claim, the client becomes major attached (has accumulated at least 600 hours of insurable employment) on the new BP.
                 [minor attached](/en/procedure/generic/knowledge.shtml#minor_attached) 
                 [major attached](/en/procedure/generic/knowledge.shtml#major_attached)

- The new BPC is between w/c 2310 to w/c 2361 and, after cancelling the old claim, the client has 420 hours or more of insurable employment to establish the new BP. During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure.

- The client submits a request to cancel a BP after benefits were paid or payable in order to establish a new BP for the first week benefits were paid or payable. 

### Claims with a BPC between w/c 2310 and w/c 2361

Source topic: `en_EN/task/benefit_period_cancel/claims_with_a_bpc_between_wc_2310_and_wc_2361.dita`

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is required only on contentious reasons for separation (RFSs) on the most recent ROE in the QP.

The officer can cancel the claim to establish a new initial claim with a BPC between w/c 2310 and w/c 2361 if the following conditions are met:

- The client has a BPC in the above range.

- The client has an indefinite disqualification, but has worked at least one hour in insurable employment in the BP.

- The RFS since the disqualification is either non-contentious or was adjudicated and allowed.

If all these conditions are met, the officer may be able to establish a new claim using all of the ROEs. This is because the indefinite disqualification imposed on the original period of employment no longer applies. The new ROE from the latest period of employment establishes a new BPC without a disqualification.

In this situation, it is advantageous for the client to cancel the BP and establish a new claim. 

### Cancelling a claim retroactively

Source topic: `en_EN/task/benefit_period_cancel/cancelling_a_claim_retroactively.dita`

When a client submits a request to cancel a BP after benefits were paid or payable in order to establish a new BP for the first week benefits were paid or payable, the cancellation request is referred to as a retroactive cancellation request.

**Timeframes to request a benefit period (BP) cancellation**

A retroactive request submitted in a timely manner is considered as having been made before benefits were paid or payable (e.g. before the BP was renewed, before the first week after a disentitlement was terminated). A request is considered to be made in a timely manner if it is submitted within the 30-day period following the first week benefits were paid or payable. A request filed after the 30-day period is referred to Level 2 to determine if there is good cause for the delay. If there is good cause for the delay, the request is considered as having been made in a timely manner. When the conditions for the retroactive request are met and a new BP is established, any weeks of benefits paid on or after the new BPC are considered as paid on the new BP.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2154.dita) 

### Refusing to cancel a claim

Source topic: `en_EN/task/benefit_period_cancel/refusing_to_cancel_a_claim.dita`

If the client requests cancellation but cannot or does not want to establish a new BP, the officer does not cancel the BP.

Unless there is an indication that the client cannot establish a new BP, terminating the BP is considered when the conditions to cancel a BP are not met. The officer refers to Terminating a benefit period .
       [Terminating a benefit period](/en/procedure/task/benefit_period_term.shtml) 

### Qualifying for the new benefit period (BP)

Source topic: `en_EN/task/benefit_period_cancel/qualifying_for_the_new_benefit_period_bp.dita`

Before cancelling a BP, the officer ensures that the client qualifies for the new BP. A variety of calculators are available to help make this determination (e.g. the Benefit Rate Calculation Tool or the SSA Tutorial Calculator). If necessary, a calculation worksheet can be used.
       [Benefit Rate Calculation Tool](http://wecs-siew.prv/wecs-siew/benefitcalc_e.aspx) 
       [calculation worksheet](/resources/ort/documents/calc_worksheet.xls)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2155.dita) 

### Advantages and disadvantages of cancelling a benefit period (BP)

Source topic: `en_EN/task/benefit_period_cancel/advantages_and_disadvantages_of_cancell_ee6373ee.dita`

The cancellation of a BP can be advantageous to a client because the cancelled BP is considered to have never existed. When a BP is cancelled, the hours and earnings used to calculate the cancelled BP that fall within the new QP are used to establish the new BP.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2156.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1305.dita) 

**Assessing the client’s situation**

The following is a non-exhaustive list of elements to assess before determining if cancelling the BP is advantageous for the client:

- The end of the BP has not been reached.

- The client remains major attached and may be entitled to special benefits.

- The client becomes entitled to benefits again.

- The client still qualifies.

- The new BP duration will be longer.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2157.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2158.dita) 

**Advantageous situations**

The following are situations that are considered to be clearly in the client’s best interest if the client is applying for a new claim:

- An indefinite disqualification has been imposed on the BP, the client is applying for regular benefits, and the client has worked enough hours to requalify.

- The BPC is between w/c 2310 and w/c 2361, an indefinite disqualification has been imposed on the BP, the client is applying for regular benefits, the RFS after the disqualifying event is either non-contentious or was adjudicated and allowed, the new BPC to be established is between w/c 2310 and w/c 2361 and the client has worked in insurable employment since the disqualification.

- A client is minor attached, but has worked enough hours to qualify for special benefits.

- A client is subject to a pension allocation that prevents payment of benefits on an existing BP and has worked enough hours in insurable employment to requalify for a new BP in which the pension is no longer allocated as earnings.

- The claim is currently BPNE and the client has worked enough hours to qualify for benefits.

- The last renewable week (LRW) has been reached, no weeks of benefits were paid and the client qualifies for benefits.

- There is only 1 week remaining before the LRW, the WP has not yet been served and the client qualifies for benefits.

**Disadvantages of cancelling a benefit period (BP)**

A BP cancellation can cause certain disadvantages. By cancelling the BP and establishing a new BP, the QP may contain fewer earnings or fewer insurable hours. As a result, the client could receive a lower benefit rate or fewer entitlement weeks compared to a renewal of the BP followed by the establishment of a new BP. The officer assesses these possibilities.

**Discussing with the client**

When it is not clearly to the client’s advantage, the officer discusses the following advantages and disadvantages with the client:

- If a pension allocation prevents payment of benefits on an existing BP and the client has worked enough hours in insurable employment to requalify for a new BP, the pension is no longer allocated as earnings.

- The benefit rate can be increased or decreased.

- Weeks of entitlement can be increased or decreased.

- Duration may be increased on the new BP.

- A new WP must be served on the new BP, unless it can be waived or deferred.

- If a definite disqualification has been imposed, it may be carried forward to the new BP.

- If the BP is for special benefits, the new BP may affect the windows and entitlement to these benefits.

- The client is major attached on an existing BP and may become minor attached on the new BP, or vice versa.

- The client may be subject to an increased entrance requirement on the new BP.

- The decision to cancel the BP is final, and cannot be reversed. 

### Notifying the client

Source topic: `en_EN/task/benefit_period_cancel/notifying_the_client.dita`

When the officer cancels the BP without speaking to the client, the officer must notify the client of the cancellation by letter. 

### Inputting a benefit period (BP) cancellation

Source topic: `en_EN/task/benefit_period_cancel/inputting_a_benefit_period_bp_cancellation.dita`

The inputs to cancel a BP depend on whether the cancellation is retroactive.

- If the cancellation is not retroactive, the BP is cancelled with:

- an M149 - Initial Intake Data (M149) transaction if a renewal week has not been input;

- a File Control Data (M101) transaction type 7 (M101-7) transaction if a renewal week has been input.

- If the cancellation is retroactive, the officer cancels the BP with a M101-7 transaction. If weeks have been processed, the officer also does the following:

- If weeks have not been paid on the existing BP after the renewal week or after the disentitlement was terminated, the officer creates an IPOC Review (IPOC REV) WI.

- If weeks have been paid on the existing BP after the renewal week or after the disentitlement was terminated, the officer creates an Operational Centre Memo (MM06) transaction.

When the officer retroactively cancels a BP on which weeks have been processed after the renewal week or after the disentitlement was terminated, an OP is created for the weeks that will be payable during the new BP. Once the OP has been established, the officer inputs an agreed deduction in PSCD equal to the benefit rate amount so that the benefits payable in the new BP are applied to the OP. For more information, the officer refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

### Violations

Source topic: `en_EN/task/benefit_period_cancel/violations.dita`

The Violation History (ML02) screen displays a list of a client’s violations. By selecting a BPC displayed on the ML02 screen, the officer can view the violation details, including any BPC that was established with increased entrance requirement s. A BPC established with increased entrance requirements is a BP that was affected by a violation and appears in FTS as First BPC affected or Second BPC affected. When such a BPC is cancelled, the officer sends an MM06 to IPOC to request that the cancelled BP be removed from the list of BPCs that were affected by the violation.
       [increased entrance requirement](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2159.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_2152.dita`

Note:

While the inputs to terminate or cancel a BP are the same, it is important to understand the distinction between terminating and cancelling a BP. The result of the input and the effect on the client are different. If the appropriate action to take is unclear, the officer refers to Cancelling, voiding, terminating or withdrawing a claim before proceeding.
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml)

     [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml) 

### Example

Source topic: `en_EN/common_notes/note_c_2153.dita`

Example:

Marcy established a BP before returning to work. She worked for 5 months, was laid off and then applied for benefits. The BP was renewed and Marcy received a notice of the renewal. Shortly after receiving the notice of renewal, she requested that a new BP be established instead of renewing the existing BP. This is a retroactive request. 

### Example

Source topic: `en_EN/common_notes/note_c_2154.dita`

Example:

- BPC 2207 (October 7, 2019)

- A 3 - Not available disentitlement (D3) is imposed from the BPC up to w/c 9999.

- Following a review of availability, the D3 is terminated in w/c 2220-5 (January 10, 2020).

- The client receives notification by letter on January 13, 2020.

- The client has until February 13, 2020 to file the cancellation request within the prescribed 30-day period.

The client wants the BP established in October 2019 to be cancelled so that it can start in January 2020.

The client submits the cancellation request on February 19, 2020.

The client submitted the cancellation request after the 30-day period had expired. The officer reassigns the file to Level 2 to determine if the client had good cause for the delay. 

### Note

Source topic: `en_EN/common_notes/note_c_2155.dita`

Note:

To qualify for fishing benefits, the client must not qualify for regular (non-fishing) benefits. A client who qualifies for regular (non-fishing) benefits does not qualify for fishing benefits. 

### Example

Source topic: `en_EN/common_notes/note_c_2156.dita`

Example:

Francis has established a BP for regular benefits with 525 hours. He serves the waiting period (WP) and 3 weeks of definite disqualification before returning to work. He works 400 hours and then stops working due to illness. Francis is not entitled to sickness benefits on the established BP since he is minor attached. If he requests a cancellation of the established BP, the hours used to establish the minor-attached BP can be combined with the 400 hours worked after the BP was established. This would allow Francis to establish a new, major-attached BP, as long as at least 200 of the 525 hours worked fall within the QP. If so, Francis would now be major attached and qualify for sickness benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_1305.dita`

Note:

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure. 

### Note

Source topic: `en_EN/common_notes/note_c_2157.dita`

Note:

When assessing whether it is advantageous to cancel a claim with a BPC between w/c 2310 and w/c 2361, the officer considers that the Budget 2021 temporary measures will not apply to new initial claims with a BPC in w/c 2362 or later. Therefore, the officer compares the current renewable claim and the potential new claim by considering the common entrance requirement (CER), the allocation of separation monies, the weeks of entitlement, the benefit rate, and the adjudication of contentious RFS issues. 

### Note

Source topic: `en_EN/common_notes/note_c_2158.dita`

Note:

The variable best weeks (VBW) questions are not presented on an initial or renewal application. When the BP is being cancelled, if it is not evident that the benefit rate will reach its maximum and if the client has not submitted the VBW information, the officer gives the client the opportunity to provide it. 

### Example

Source topic: `en_EN/common_notes/note_c_2159.dita`

Example:

Violation history:

- BPC 2057 (November 20, 2016)

- Violation imposed

- Notification w/c 2119 (January 29, 2018)

BPCs affected by an increased entrance requirement caused by violation in BPC 2057:

- First BPC affected: BPC 2157 (October 21, 2018)

- Second BPC affected: BPC 2214 (November 24, 2019)

Gladys has gained relief from increased entrance requirements because 2 initial claims have been established since the date the notice of violation was issued. If BPC 2214 is cancelled, she no longer has 2 initial claims established since the date the notice of violation was issued. If a new BP is established within 260 weeks of the notification being sent, Gladys would not meet either condition to gain relief from increased entrance requirements and she would be subject to increased entrance requirements for the new BP. 

## Regional considerations

Source topic: `en_EN/task/benefit_period_cancel/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/benefit_period_cancel/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/benefit_period_cancel/in_nws.dita`

- Is there documentation on file regarding the request for cancellation?

- Has the client submitted a renewal claim?

- Is this a retroactive request?

- If yes, what is the date of the retroactive request?

- Is there documentation of verbal notice regarding the end of the disentitlement (e.g. an SROC or ROD)?

- Has a Claimant Attestation — Highest Weeks of Insurance Earnings (Variable Best Weeks) (INS5241) form been received?
         [Claimant Attestation — Highest Weeks of Insurance Earnings (Variable Best Weeks) (INS5241)](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=sc-ins5241.pdf) 

### In FTS:

Source topic: `en_EN/task/benefit_period_cancel/in_fts.dita`

- Have weeks of benefits been paid?

- Has a renewal week been input?

- What is the benefit type (BT)?

- If the BP is for special benefits, what are the special benefit windows?

- What is the benefit rate?

- What is the LRW in the BP?

- What is the remaining entitlement in the BP?

- Are there any ongoing allocations?

- Are there any disqualifications or disentitlements in the BP?

- Has the WP been served, waived or deferred?

- Is the client major or minor attached?

- What is the client’s violation history?

- Is there a definite disentitlement imposed as of the BPC?

- If this is a retroactive request, were payments made between the BPC and :

- the renewal week?

- the end of the disentitlement?

- What is the issue date of the benefits statement? 

## Step by step

Source topic: `en_EN/task/benefit_period_cancel/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/benefit_period_cancel/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/benefit_period_cancel/reviewing_the_file_level_1.dita`

- Determine if IPOC created a Reminder (REM) WI indicating a new BP can now be established:

- If no, go to step 2.

- If yes, determine what IPOC adjusted:

- If IPOC adjusted only the violation history, go to Amending the violation history .
                   [Amending the violation history](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#violation)

- If IPOC adjusted the pay history summary (PHS) either with or without an adjustment of the violation history, go to Cancelling a claim retroactively .
                   [Cancelling a claim retroactively](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#Retroactive_request)

- Determine if the client wants to cancel a regular BP in favour of a fishing BP:

- If no, go to step 3.

- If yes, determine if there is an indefinite disqualification on the regular BP:

- If yes, go to step 3.

- If no, go to Benefit period (BP) not cancelled .
                   [Benefit period (BP) not cancelled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#BPnotcancelled)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2160.dita)

- Determine if one of the following conditions is met:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2161.dita) 

- If one of the conditions is met, go to step 4.

- If none of the conditions is met, refer to Terminating a benefit period .
               [Terminating a benefit period](/en/procedure/task/benefit_period_term.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2162.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2163.dita)

- Determine if this is a retroactive request that was filed within the 30-day period:

- If the request is retroactive and was not filed within the 30-day period, go to step 5.

- If the request is retroactive and was filed within the 30-day period, go to step 10.

- If the request is not retroactive, go to step 10.

- In NWS, determine if there is a Level 2 ROD for the adjudication of good cause for the delay in submitting the retroactive request:

- If yes, go to step 9.

- If no, create a CR Revised WI as follows:

- Type: Select Revised .

- Issue: Select Entitlement .

- Registration number: Enter the revised registration number.

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Select the Service Canada Centre as shown in FTS.

- BPC: Enter the BPC.

- Date of registration: Enter the date of the revised registration.

- Create a client Note and type “CR Revised WI created today. The issue requiring adjudication is claim procedure — delay in requesting claim cancellation.”

- Move the Level 1 WI related to the claim cancellation to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for adjudication of good cause.”

- Bring forward date: Enter the today’s date + 10 business days.

- When the Level 1 WI related to the claim cancellation moves to the current workload, determine if there is a Level 2 ROD for the adjudication of good cause for the delay in submitting the retroactive request:

- If no, return to step 7.

- If yes, go to step 9.

- Determine if good cause for the delay has been allowed:

- If yes, go to step 10.

- If no, go to Benefit period (BP) not cancelled .
               [Benefit period (BP) not cancelled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#BPnotcancelled)

- Determine if all of the information is on file to establish whether the client qualifies for benefits on a new claim (e.g. an application, all ROEs):

- If not all of the information is on file, go to step 11.

- If all the information is on file, go to step 18.

- Fact-find with the client:

- Ask if the client intends to apply for a new claim.

- Obtain from the client the missing information required to determine if the client qualifies for benefits on a new claim.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2164.dita)

- Determine if the client was contacted during fact-finding:

- If client was contacted, go to step 13.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Benefit period (BP) not cancelled .
               [Benefit period (BP) not cancelled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#BPnotcancelled)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- BPC: Type the BPC.

- Main Issue: Select Other .

- Comments: Type “Cancellation request.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the required information was obtained:

- If no, go to step 15.

- If yes, go to step 18.

- Determine if the client agreed to submit the required information:

- If yes, go to step 16.

- If no, go to Benefit period (BP) not cancelled .
               [Benefit period (BP) not cancelled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#BPnotcancelled)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for the client to submit information.”

- Bring forward date: Enter the today’s date + 10 business days.

- When the WI moves to the current workload, determine if the required information has been received:

- If yes, go to step 18.

- If no, go to Benefit period (BP) not cancelled .
               [Benefit period (BP) not cancelled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#BPnotcancelled)

- Determine if the client qualifies for a new BP (refer to the appropriate Calculating or recalculating a claim activity):

- If yes, go to step 19.

- If no, go to Benefit period (BP) not cancelled .
               [Benefit period (BP) not cancelled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#BPnotcancelled)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2160.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2165.dita)

- Determine if it is clearly to the client’s advantage to cancel the BP:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2166.dita) 

- If any of the conditions apply, go to step 20.

- If none of the conditions applies, go to step 21.

- In NWS, create a ROD as follows:

- BPC: Enter the BPC.

- Comments: Type “Cancellation of BPC [BPC].”

- Details: Type “BPC [BPC] cancelled. The client was not contacted to review advantages and disadvantages of cancelling the BP because the cancellation is clearly to the client’s advantage.”

- Go to step 25.

- Contact the client and review the advantages and disadvantages of cancelling the claim, including the following. Refer to Fact-finding .

- The decision to cancel is final and cannot be reversed.

- A new WP must be served on the new BP unless it is waived or deferred.

- The decision to cancel the BP cannot be appealed once it has been input.

- If the client chooses to cancel the BP, a letter will be sent only if benefits have been paid.

- If the client chooses not to cancel the BP, no letter will be sent.

- Remind the client to submit all of their ROEs as soon as possible, if they have not yet been submitted.

- If the client did not provide the VBW information and it is not evident that the benefit rate will reach its maximum, use the INS5241 form and obtain the VBW information. If the client cannot be contacted by telephone at this point, in ACS, create and send the Q-01-00-00 letter, which allows the client to complete and return the form.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 23.

- If the client was not contacted, go to Benefit period (BP) not cancelled .
               [Benefit period (BP) not cancelled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#BPnotcancelled)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- BPC: Type the BPC.

- Main Issue: Select Other .

- Comments: Type “BP cancellation.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy . Also type “The client was advised of the advantages and disadvantages of cancellation. The client was also told that the decision is final and cannot be reversed, and that a letter will be sent only if the client chooses to cancel the BP and benefits have been paid.”
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client still wants to cancel the BP in favor of a new one:

- If yes, go to step 25.

- If no, go to Benefit period (BP) not cancelled .
               [Benefit period (BP) not cancelled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#BPnotcancelled)

- Determine if the BP cancellation is for weeks of benefits that were processed after a renewal week or after a disentitlement was terminated:

- If no, go to Cancelling the benefit period (BP).
               [Cancelling the benefit period (BP).](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#Cancelling_BP)

- If yes, go to Cancelling a claim retroactively .
               [Cancelling a claim retroactively](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#Retroactive_request) 

#### Cancelling the benefit period (BP)

Source topic: `en_EN/task/benefit_period_cancel/cancelling_the_benefit_period_bp_level_1.dita`

- In FTS, determine if the renewal week has been input:

- If no, go to step 2.

- If yes, go to step 4.

- In SSO, on the Registration screen, update the claim type as follows:

- Decision Type: Select Initial .

- Select Next .

- On the M149 - Initial Intake Data screen, update the tentative BPC as follows:

- Terminate previous claim: Yes (should be prefilled correctly).

- Tentative BPC: Enter the BPC of the initial claim to be established.

- Select Update to transmit the information.

- Go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2167.dita)

- In FTS, select the File Control Data (M101) - Claim Action transaction, do the following:

- Select Cancel benefit period (M101-7) .

- Select Update .

- In SSO, verify if the correct mainframe is selected and register a new initial claim as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Initial .

- Select Search .

- Review the Name and Address screen:
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2168.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2169.dita) 

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region-new and Economic region-old : The information is prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: Select the appropriate option:

- If the field is blank, enter the SCC based on the client’s address on the application.

- For a commuter claim, enter the SCC associated with the workplace postal code.

- Tax credit: This field is prefilled based on the client’s information.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Ensure that the SCC number is the same as shown in FTS. If the field is blank, enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: If not prefilled, determine the BPC based on the client’s last day worked (LDW) and application date.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select No .

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2170.dita)

- Determine if the Violation History (ML02) screen displays the cancelled BP as a BPC that was affected by a violation:

- If no, go to step 7.

- If yes, go to Amending the violation history .
               [Amending the violation history](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#violation)

- Determine if the client was contacted during fact-finding:

- If the client was not contacted, go to step 8.

- If the client was contacted, go to step 9.

- In ACS, create and send the N-06-00-00 letter, completing the appropriate fields.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2171.dita)

- In NWS, determine if there is an AI WI or Call Back (CB) WI for the cancellation request:

- If yes, complete the WI and go to step 10.

- If no, go to step 10.

- Determine the BT requested for the calculation:

- If the BT is regular, refer to Calculating or recalculating a claim for regular benefits .
               [Calculating or recalculating a claim for regular benefits](/en/procedure/activity/calculation.shtml)

- If the BT is sickness, refer to Calculating or recalculating a claim for sickness benefits .
               [Calculating or recalculating a claim for sickness benefits](/en/procedure/activity/calc_sick.shtml)

- If the BT is sickness, maternity and parental, refer to Calculating or recalculating a claim for sickness, maternity and parental benefits .
               [Calculating or recalculating a claim for sickness, maternity and parental benefits](/en/procedure/activity/calc_sick_mat_par.shtml)

- If the BT is maternity and parental, refer to Calculating or recalculating a claim for maternity and parental benefits .
               [Calculating or recalculating a claim for maternity and parental benefits](/en/procedure/activity/calc_mat_par.shtml)

- If the BT is parental, refer to Calculating or recalculating a claim for parental benefits .
               [Calculating or recalculating a claim for parental benefits](/en/procedure/activity/calc_par.shtml)

- If the BT is compassionate care, refer to Calculating or recalculating a claim for CCB .
               [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml)

- If the BT is family caregiver, refer to Calculating or recalculating a claim for family caregiver benefits .
               [Calculating or recalculating a claim for family caregiver benefits](/en/procedure/activity/calc_pcic_benefit.shtml) 

#### Cancelling a claim retroactively

Source topic: `en_EN/task/benefit_period_cancel/cancelling_a_claim_retroactively_level_1.dita`

- Determine if IPOC created a REM WI indicating a new BP can now be established:

- If no, go to step 2.

- If yes, go to step 12.

- In FTS, select the File Control Data (M101) - Claim Action transaction and do the following:

- Select Cancel benefit period (M101-7) .

- Select Update .

- Determine if weeks of benefits have been paid after the renewal week or after the disentitlement was terminated:

- If no, go to step 4.

- If yes, go to step 6.

- Determine if the Violation History (ML02) screen displays the BP to be cancelled as a BPC that was affected by a violation:

- If no, go to step 5.

- If yes, go to step 6.

- In NWS, create an IPOC REV WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate language.

- Destination — SCC: Select the IPOC based on the region in which the claim is located in FTS:

- Atlantic: 1826

- Quebec: 2642

- Ontario: 3056

- Western Canada and Territories: 5903

- User: Select Next available user .

- Issue: Select Pay history summary adjustment .

- BPC: Type the BPC of claim to be cancelled.

- Comments: Type “Retroactive cancellation of a BP.”

- Details: Type “Benefits processed on BPC [BPC of the BP to cancel] to be processed on a new BP. Remove processed weeks from the PHS. Advise adjudicator with REM WI when complete.”

- Obtained by: Select the appropriate method.

- Obtained from: Select the appropriate source.

- Source details: Enter the source details.

- Select Save .

- Go to step 10.

- In FTS, determine if a revised registration number exists:

- If yes, go to step 7.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction to automatically generate an Operational Centre Memo (MM06) transaction and complete the following fields:

- Registration number: Select the appropriate registration number.

- Select Memo (MPS) .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim to be cancelled.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 35 - Claim Cancellation .

- I f the Violation History (ML02) screen does not display the cancelled BP as a BPC that was affected by a violation:

- Remarks lines 1–4: Type “Benefits processed on BPC [BPC of the BP to cancel] to be processed on a new BP. Remove processed weeks from the PHS. Create OP for paid weeks. Advise adjudicator with REM WI when complete.”

- If the Violation History (ML02) screen displays the cancelled BP as a BPC that was affected by a violation:

- Remarks lines 1–4: Type “Benefits processed on BPC [BPC of the BP to cancel] to be processed on a new BP. Remove processed weeks from PHS. Create OP for paid weeks. Update ML02 for BPC [BPC with violation that affected the cancelled BP] and remove BPC [BPC of the BP to cancel] as a BPC affected by a violation. Advise adjudicator with REM WI when complete.”

- Remarks line 5: Enter your first name and last name.

- Detection: Select 31 - Other new facts- entitlement review .

- Infraction: Select F - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In FTS, select the Registration Number (M025, M030, M035) transaction and change the registration flag as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for IPOC to cancel the BP.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI related to the cancellation request moves to the current workload, determine if IPOC created a REM WI:

- If no, return to step 10.

- If yes, go to step 12.

- Determine if IPOC established an OP for the weeks that were removed:

- If yes, go to step 13.

- If no, go to step 14.

- Input an agreed deduction equal to the benefit rate amount. For more information, refer to Applying an agreed deduction in PSCD .

- In SSO, verify if the correct mainframe is selected and register a new initial claim as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Initial .

- Select Search .

- Review the Name and Address screen:
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2168.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2169.dita) 

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region-new and Economic region-old : The information is prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: Select the appropriate option:

- If the field is blank, enter the SCC based on the client’s address on the application.

- For a commuter claim, enter the SCC associated with the workplace postal code.

- Tax credit: This field is prefilled based on the client’s information.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: Ensure that the SCC number is the same as shown in FTS. If the field is blank, enter the appropriate SCC:

- Atlantic: Type “1121.”

- Quebec: Type “2371.”

- Ontario: Type “3515.”

- Western Canada and Territories: Type “4812.”

- Service unit: Type “01.”

- Tentative BPC: If not prefilled, determine the BPC based on the client’s last day worked (LDW) and application date.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select No .
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2170.dita)

- In ACS, create and send the N-06-00-00 letter, completing the appropriate fields.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2171.dita)

- In NWS, determine if there is an AI or CB WI for the cancellation request:

- If yes, complete the WI and go to step 17.

- If no, go to step 17.

- Determine the BT requested for the calculation:

- If the BT is regular, refer to Calculating or recalculating a claim for regular benefits .
               [Calculating or recalculating a claim for regular benefits](/en/procedure/activity/calculation.shtml)

- If the BT is sickness, refer to Calculating or recalculating a claim for sickness benefits .
               [Calculating or recalculating a claim for sickness benefits](/en/procedure/activity/calc_sick.shtml)

- If the BT is sickness, maternity and parental, refer to Calculating or recalculating a claim for sickness, maternity and parental benefits .
               [Calculating or recalculating a claim for sickness, maternity and parental benefits](/en/procedure/activity/calc_sick_mat_par.shtml)

- If the BT is maternity and parental, refer to Calculating or recalculating a claim for maternity and parental benefits .
               [Calculating or recalculating a claim for maternity and parental benefits](/en/procedure/activity/calc_mat_par.shtml)

- If the BT is parental, refer to Calculating or recalculating a claim for parental benefits .
               [Calculating or recalculating a claim for parental benefits](/en/procedure/activity/calc_par.shtml)

- If the BT is compassionate care, refer to Calculating or recalculating a claim for CCB .
               [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml)

- If the BT is family caregiver benefits, refer to Calculating or recalculating a claim for family caregiver benefits .
               [Calculating or recalculating a claim for family caregiver benefits](/en/procedure/activity/calc_pcic_benefit.shtml) 

#### Amending the violation history

Source topic: `en_EN/task/benefit_period_cancel/amending_the_violation_history_level_1.dita`

- Determine if IPOC created a REM WI indicating a new initial claim can now be established:

- If no, go to step 2.

- If yes, go to step 8.

- In FTS, determine if a revised registration number exists:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction to automatically generate an Operational Centre Memo (MM06) transaction and complete the following fields:

- Registration number: Select the appropriate registration number.

- Select Memo (MPS) .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim to be cancelled.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 35 - Claim Cancellation .

- Remarks line 1: Type “Cancelled BPC [cancelled BPC] affects violation history. Update ML02 for BPC [BPC with the violation that affected the cancelled BP] and remove BPC [cancelled BPC] as a BPC affected by a violation Advise adjudicator with REM WI when complete.”

- Remarks line 5: Enter your first name and last name.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In FTS, select the Registration Number (M025, M030, M035) transaction and change the registration flag as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for IPOC to update the Violation history screen due to the cancellation of an affected BP.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI related to the cancellation request moves to the current workload, determine if IPOC has created a REM WI:

- If no, return to step 6.

- If yes, go to step 8.

- Determine if the client was contacted during fact-finding:

- If the client was not contacted, go to step 9.

- If the client was contacted, go to step 10.

- In ACS, create and send the N-06-00-00 letter, completing the appropriate fields.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2171.dita)

- In NWS, determine if there is an AI or CB WI for the cancellation request:

- If yes, complete the WI and go to step 11.

- If no, go to step 11.

- Determine the BT requested for the calculation:

- If the BT is regular, refer to Calculating or recalculating a claim for regular benefits .
               [Calculating or recalculating a claim for regular benefits](/en/procedure/activity/calculation.shtml)

- If the BT is sickness, refer to Calculating or recalculating a claim for sickness benefits .
               [Calculating or recalculating a claim for sickness benefits](/en/procedure/activity/calc_sick.shtml)

- If the BT is sickness, maternity and parental, refer to Calculating or recalculating a claim for sickness, maternity and parental benefits.
               [Calculating or recalculating a claim for sickness, maternity and parental benefits.](/en/procedure/activity/calc_sick_mat_par.shtml)

- If the BT is maternity and parental, refer to Calculating or recalculating a claim for maternity and parental benefits .
               [Calculating or recalculating a claim for maternity and parental benefits](/en/procedure/activity/calc_mat_par.shtml)

- If the BT is parental, refer to Calculating or recalculating a claim for parental benefits .
               [Calculating or recalculating a claim for parental benefits](/en/procedure/activity/calc_par.shtml)

- If the BT is compassionate care, refer to Calculating or recalculating a claim for CCB .
               [Calculating or recalculating a claim for CCB](/en/procedure/activity/calc_ccb.shtml)

- If the BT is family caregiver benefits, refer to Calculating or recalculating a claim for family caregiver benefits .
               [Calculating or recalculating a claim for family caregiver benefits](/en/procedure/activity/calc_pcic_benefit.shtml) 

#### Benefit period (BP) not cancelled

Source topic: `en_EN/task/benefit_period_cancel/benefit_period_bp_not_cancelled_level_1.dita`

- In FTS, determine if there is an outstanding revised registration number on file for the cancellation request:

- If yes, go to step 2.

- If no, go to step 3.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claims Allowed: Select NCA - No changes to the claim .

- Contentious: Select the appropriate option:

- If the decision did not require Level 2 adjudication, select 1 - No .

- If the decision required Level 2 adjudication, select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NWS, determine if there is a Level 2 ROD for the denial of a cancellation request:

- If no, go to step 4.

- If yes, go to step 7.

- In NWS, create a ROD as follows:

- BPC: Enter the BPC.

- Comments: Type “Cancellation of the BPC [BPC].”

- Details: Type “BPC [BPC] cannot be cancelled.” Include the reason the BP was not cancelled (e.g. the client does not qualify on new BP, an officer is unable to contact and advise the client of advantages and disadvantages).

- Determine if the client requested cancellation of the BP:

- If no, go to step 7.

- If yes, determine if the client was verbally advised that the BP is not being cancelled:

- If no, go to step 6.

- If yes, go to step 7.

- In ACS, create and send an F-00-00-00 letter advising the client of the decision:

- In the Free Text (1612) field, type the appropriate option:

- If the client does not qualify to establish a new BP and the new requested BT was fishing benefits, type “We are writing to inform you that we cannot cancel your claim for Employment Insurance benefits that began on [BPC of existing BPC] as you are unable to establish a new one. As stated in Section 8 of the EI Fishing Regulations, in order to establish a claim for fishing benefits a client must not qualify for regular non-fishing EI benefits. As a result, we cannot cancel a benefit period for regular benefits in favour of a benefit period for fishing benefits.”

- If the client does not qualify to establish a new BP and the new requested BT is not fishing benefits, type “We are writing to inform you that we cannot cancel your claim for Employment Insurance benefits that began on [BPC of existing BPC] as you are unable to establish a new one.”

- If the client was not reached to discuss the advantages and disadvantages, type “We are writing to inform you that we cannot cancel your claim for Employment Insurance benefits that began on [BPC of existing BPC] as we were unable to reach you to review the advantages and disadvantages of cancelling the benefit period.”

- In NWS, determine the type of WI:

- If the WI is an AI or CB WI, complete the WI.

- If the WI is a CA, SA or Claim Review (CR) WI, return to the appropriate Conversion and renewal procedure.
               [Conversion and renewal](/en/procedure/activity/conversions.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2160.dita`

Note:

A client who qualifies for regular (non-fishing) benefits does not qualify for fishing benefits. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2161.dita`

**Condition 1 for cancellation**

- The BP is terminated, no benefits were paid or payable during the BP and the client is requesting benefits.

**Condition 2 for cancellation**

- No benefits were paid or payable during the BP, whether terminated, ended or not, the client is requesting a claim cancellation, and the client is requesting benefits.

**Condition 3 for cancellation**

- No benefits were actually paid, and the only weeks deemed paid were weeks of a definite disqualification served.

- The client is applying for and is entitled to special benefits.

- The client is minor attached (has fewer than 600 hours of insurable employment) (Claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361) that are established with 420 hours of insurable employment or more qualify for special benefits. During this period, the definitions of major and minor attached do not apply.)

**Condition 4 for cancellation (retroactive request)**

- Benefits were paid or payable.

- The client requests the cancellation of a BP in order to establish a new BP for the first week benefits were paid or payable.

- The new BP can be established the same week that benefits were paid or payable.

- No benefits were paid or payable before the week in which the client wants to establish the new BP. 

#### Note

Source topic: `en_EN/common_notes/note_c_2162.dita`

Note:

Benefits are considered paid when a client serves a week of a definite disqualification. A week of benefits is not considered paid if, following a reconsideration, the client was not entitled to benefits for that week and an OP is established. 

#### Note

Source topic: `en_EN/common_notes/note_c_2163.dita`

Note:

A BP being considered for cancellation may be the first or second BP affected by a violation. If so, cancelling the BP will cause the client to be subject to increased entrance requirements unless the new BP is more than 260 weeks after the violation notice was issued. Refer to Violation: Impact on calculation for regular and fishing claims (increased entrance requirements) — Table .
       [Violation: Impact on calculation for regular and fishing claims (increased entrance requirements) — Table](/en/procedure/generic/additionalresources/increased_entrance_requirements.shtml)

     [Violation: Impact on calculation for regular and fishing claims (increased entrance requirements) — Table](/en/procedure/generic/additionalresources/increased_entrance_requirements.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_2164.dita`

Note:

If necessary, review the advantages and the disadvantages with the client and notify the client that an officer may call again if the client qualifies for benefits on the new claim. 

#### Note

Source topic: `en_EN/common_notes/note_c_2165.dita`

Note:

When a BP being considered for cancellation has a BPC that was affected by a violation, the client is subject to increased entrance requirement s for a new BP unless relief is obtained. Refer to Violation: Impact on calculation for regular and fishing claims (increased entrance requirements) — Table .
       [increased entrance requirement](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 
       [Violation: Impact on calculation for regular and fishing claims (increased entrance requirements) — Table](/en/procedure/generic/additionalresources/increased_entrance_requirements.shtml)

     [increased entrance requirement](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 
     [Violation: Impact on calculation for regular and fishing claims (increased entrance requirements) — Table](/en/procedure/generic/additionalresources/increased_entrance_requirements.shtml) 

#### Callout

Source topic: `en_EN/common_notes/note_c_2166.dita`

Conditions under which it is clearly to the client’s advantage to cancel the BP:

- An indefinite disqualification has been imposed on the BP, the client is applying for regular benefits, and the client has worked enough hours to requalify.

- The BPC is between w/c 2310 and w/c 2361, an indefinite disqualification has been imposed on the BP, the client is applying for regular benefits, the RFS after the disqualifying event is non-contentious or was adjudicated and allowed, the new BPC to be established is between w/c 2310 and w/c 2361 and the client has worked in insurable employment since the disqualification.

- The client is minor attached but has worked enough hours to qualify for special benefits.

- The client is subject to a pension allocation that fully prevents payment of benefits and has worked enough hours for the pension allocation to become requalified.

- The claim is currently BPNE and the client has worked enough hours to qualify for benefits.

- The LRW has been reached, no weeks of benefits were paid and the client qualifies for a new claim.

- There is only 1 week remaining before the LRW, the WP has not yet been served and the client qualifies for a new claim. 

#### Note

Source topic: `en_EN/common_notes/note_c_2167.dita`

Note:

If the M149 - Initial Intake Data screen cannot be transmitted, do the following:

- In SSO, select Store to save the information.

- Exit from the SIN file in SSO before proceeding.

- In FTS, select the transaction Initial Intake (M149) and do the following:

- Terminate previous claim: Check the box.

- Tentative BPC: Enter the BPC of the initial claim to be established.

- Select Update to transmit the information.

- Go to step 6. 

#### Note

Source topic: `en_EN/common_notes/note_c_2168.dita`

Note:

The information from the application in NWS is automatically downloaded in SSO. In rare cases, the information is not downloaded and must be manually input. Verify (and correct, if necessary) any prefilled fields with the information provided on the application. 

#### Note

Source topic: `en_EN/common_notes/note_c_2169.dita`

Note:

When the client has only one name, one of the name fields on the Name and Address screen may be empty or contain a non-alphabetical character. However, SSO does not allow the field to be completed in this way.

When a name field is empty or contains a non-alphabetical character, do the following:

- First Name: Enter the appropriate option:

- For a client who selects the Male gender marker, type “Mr.”

- For a client who selects the Female gender marker, type “Ms.”

- For a client who selects the X gender marker, type “N.A.”

- Last Name: Enter the client’s name.

When the First Name field on the Name and Address screen is modified to “N.A.” , modify the M149 - Initial Intake Data (M149) or M159 - Name and Address Change / Transfer (M159) transaction generated by the calculation and type a “.” in the First Name field before inputting it. 

#### Note

Source topic: `en_EN/common_notes/note_c_2170.dita`

Note:

The M149 - Initial Intake Data (M149) transaction cannot be input on the same day as the File Control Data (M101) transaction type 7 (M101-7). 

#### Note

Source topic: `en_EN/common_notes/note_c_2171.dita`

Note:

Do not select the Right to Request a Reconsideration option as the decision to cancel the BP is final, and cannot be reversed. 

### Level 2

Source topic: `en_EN/task/benefit_period_cancel/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/benefit_period_cancel/reviewing_the_file_level_2.dita`

- Determine if additional information is required to determine if there was good cause for the delay in filing the retroactive cancellation request:

- If yes, go to step 2.

- If no, go to step 5.

- Fact-find with the client to obtain the reason for the delay in requesting the retroactive cancellation of a portion of the BP. Refer to Digest 3 — Antedate for questions to ask the client.

- Determine if the client was contacted during fact-finding:

- If yes, go to step 4.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Denying a retroactive cancellation .
               [Denying a retroactive cancellation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#notcontacted2)

- In NWS, add details to the draft SROC created during fact-finding, or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Reason for delay in retroactive cancellation.”

- Details: Document the fact-finding details according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Based on a review of all information on file and in accordance with the Act, Regulations and jurisprudence, determine if the client showed good cause for the delay. Refer to Digest 3 — Antedate .

- If yes, go to step 6.

- If no, go to Denying a retroactive cancellation .
               [Denying a retroactive cancellation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/benefit_period_cancel#notcontacted2)

- In NWS, create a ROD as follows:

- Comments: Type “Retroactive cancellation — Good cause for the delay in applying for claim cancellation.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2172.dita)

- In NWS, determine if there is a Level 1 WI associated with the cancellation request:

- If yes, go to step 9.

- If no, create a CR Revised WI as follows:

- Type: Select Revised .

- Issue: Select Calculation .

- Registration number: Enter the revised registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the Service Canada Centre as shown in FTS.

- BPC: Enter the BPC.

- Date of registration: Enter the date of the revised registration.

- Create a client Note and type “CR Revised WI created today. Good cause was shown for the delay in requesting the claim cancellation. The Level 1 officer can proceed with determining if the client meets the conditions to allow the claim cancelation.”

- In NWS, complete the Level 2 WI.

- In NWS, create a ROD as follows:

- Comments : Type “Retroactive cancellation denied.”

- Details : Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2172.dita)

- In ACS, send the N-06-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes fields as follows:

- Denial of the claimant’s request to terminate a claim : Select No good cause for being late (2701) .

- BPC date - Sunday’s date (1060)

- Date of claimant’s request to cancel or terminate claim (1462)

- Right to Request a Reconsideration (with Blank option) (4169)

- In NWS, complete the Level 2 WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2172.dita`

Note:

In the Quebec region, use the Decision-Making Process forms on the Quebec intranet site when creating a ROD.
       [Decision-Making Process](https://esdc.prv/en/service-canada/quebec/resources/bdsb/doc-evidence.shtml)

     [Decision-Making Process](https://esdc.prv/en/service-canada/quebec/resources/bdsb/doc-evidence.shtml) 

## Policy reference

Source topic: `en_EN/task/benefit_period_cancel/policy_reference.dita`

- Digest 1.4.5 — Cancellation
         [Digest 1.4.5 — Cancellation](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-1/benefit-period-structure.html#a1_4_5)

- Digest 3 — Antedate
         [Digest 3 — Antedate](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-3/table-of-contents.html)

- EIA 10
         [EIA 10](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-10.html)

- BE 2010-03 — Automatic Renewal of Existing Claim
         [BE 2010-03 — Automatic Renewal of Existing Claim](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2010-03.shtml) 
