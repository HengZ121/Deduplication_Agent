# Entering a paper application

Source map: `en_EN/task/entering_pa/entering_pa.ditamap`

## Summary

Source topic: `en_EN/task/entering_pa/summary.dita`

Summary: The Application for Employment Insurance Benefits form (INS5114) or the Application for Employment Insurance Benefits for Self-Employed Persons form (INS5236) is completed when the client wants to manually fill out an application. 

## What you need to know

Source topic: `en_EN/task/entering_pa/what_you_need_to_know.dita`

### Paper applications

Source topic: `en_EN/task/entering_pa/paper_applications.dita`

The client can mail a paper application to the SCC or drop it off in person at the SCC.

A paper application for benefits must include a signature. The signature must be hand-written and cannot be typed. Although it is desirable that the signature be in ink, accept it even if the client uses a pencil.

Accept any marking made by the client as a signature. For example, Chinese handwritten characters constitute a valid signature as it indicates the client confirms that he has completed the document. 

### Determining the date of application and postmark date

Source topic: `en_EN/task/entering_pa/determining_the_date_of_application_and_66de30e6.dita`

The date of application and the postmark dates are both required to enter the application.

When determining the date of application, use the earlier of:

- the postmark date on the envelope in which the application for benefit form was mailed;

- the date stamp showing receipt of the application form at the SCC.

When determining the postmark date, if both the postmark date and the date stamp, are illegible or missing, use the date from the signature of application field. 

### Determining when a claim is renewable

Source topic: `en_EN/task/entering_pa/determining_when_a_claim_is_renewable.dita`

- There is an active benefit period (BP).

- The last renewable week (LRW) of the BP has not been reached.

- The client did not receive all the benefits to which he is entitled to on that BP.

The claim may be renewable for special benefits if all regular entitlement has been paid out, and the claim is on the Dormant tab, with the message “special benefits potentially payable.” 

### Verifying mainframes

Source topic: `en_EN/task/entering_pa/verifying_mainframes.dita`

There are 4 mainframes, one in each of the regions: Atlantic, Quebec, Ontario and Western region.

The client’s claim information is located in the mainframe in the region where he or she resides. In FTS, from the Mainframe menu, verify all 4 mainframes to ensure the client does not have an active claim in another region. 

### Warning message: Error code 1004

Source topic: `en_EN/task/entering_pa/warning_message_error_code_1004.dita`

In some exceptional circumstances, SSO creates the registration number in FTS but does not create the Claim Assessment (CA) WI in NWS. A warning message displaying error code 1004 appears in SSO and the officer must manually create the CA WI in NWS. 

## Regional considerations

Source topic: `en_EN/task/entering_pa/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/entering_pa/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/entering_pa/untitled_section.dita`

- Does the application have the client’s signature? 

### In FTS:

Source topic: `en_EN/task/entering_pa/in_fts.dita`

- Is there an undeliverable mail indicator ($) in the tombstone data? 

### In SSO:

Source topic: `en_EN/task/entering_pa/in_sso.dita`

- Before entering the INS5114 or INS5236 form information, is the correct mainframe selected? 

## Step by step

Source topic: `en_EN/task/entering_pa/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/entering_pa/non-complex.dita`

#### Reviewing the file

Source topic: `en_EN/task/entering_pa/reviewing_the_file_non-complex.dita`

- Verify the client has signed the application and do the following:

- If the client has not signed the application, do not register in SSO, and go to step 2.

- If the client has signed the application, go to step 3.

- In ACS, send the Q-01-00-00-letter, completing the following attributes:

- Re: Missing Application / Address Info (2875): Select Sign Application .

- Message: BF Date - If not received, may delay claim (2897): Select 2 weeks from today’s date.

- Attachment List for Q-01-00-00 (3120): Select Text: Specify the attachment(s) .

- Text: Specify the attachment(s) (1546): Type “Application for Employment Insurance Benefits (INS5114)” or “Application for Employment Insurance Benefits for Self-Employed Persons (INS5236)”.

- Select Local Printing . Return the application with the relevant documents along with the letter.

- No further action is required.

- In FTS, verify in each of the 4 mainframes if there is an undeliverable mail indicator ($) in the tombstone data, and do one of the following:

- If there is an undeliverable mail indicator ($), go to step 4.

- If there is no undeliverable mail indicator ($), go to step 5.

- In NWS, create a Reminder WI, and complete the following fields:

- Complexity: Select Level 2 .

- Reason: Select Other .

- Comments: Type “undeliverable mail indicator ($).”

- Due date: From the drop-down calendar, select the current date.

- Language: Select the appropriate option depending on the language in which the client completed the application.

- Details: Type “initial claim filed — decision requires review”.

- Destination: Enter the SCC as shown in FTS.

- End user: Select Next available user .

- Select Save .

- In FTS, verify in each of the 4 mainframes if there is an active claim on the Summary or Dormant tab:

- If yes, go to step 6.

- If no, go to Registering an initial claim .
               [Registering an initial claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/entering_pa#nc_item_3)

- Determine if the request is for a continuing claim or a renewable claim:

- For a renewable claim, go to Registering a renewal claim in FTS .
               [Registering a renewal claim in FTS](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/entering_pa#nc_item_2)

- For a continuing claim, go to Creating an Action Item (AI) WI for Level 1 .
               [Creating an Action Item (AI) WI for Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/entering_pa#_Creating_an_Action) 

#### Registering a renewal claim in FTS

Source topic: `en_EN/task/entering_pa/registering_a_renewal_claim_in_fts_non-complex.dita`

- In FTS, verify if the information technology centre (ITC) is correct and select the Registration Number (M025, M030, M035) transaction. Assign a renewal registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- Determine if the address or the phone number displayed in FTS are different from those on the paper application:

- If no, go to step 3.

- If yes, refer to Change of address to input the Name and Address Change/Transfer (M159) transaction and go to step 3.
               [Change of address](/en/procedure/activity/change_address.shtml)

- Select the Direct Deposit (M163) transaction and compare the information in FTS with the direct deposit information on the paper application:

- If the direct deposit information in FTS is correct, go to step 4.

- If the direct deposit information in FTS is incorrect or no information is displayed, refer to Direct deposit and go to step 4.
               [Direct deposit](/en/procedure/activity/direct_deposit.shtml)

- In NWS, create an SROC as follows:

- BPC: Enter the BPC as shown in FTS.

- Main Issue: Select Other .

- Comments: Type “Paper application for renewal” and the date the application was received.

- Details: Type “Paper renewal application received. Renewal registered in FTS and application sent to imaging.” Document any comments or information the client provided on the paper application. Indicate any other documents received with the application.

- Obtained by: Select Other .

- Obtained from: Select Client .

- Source details: Type “Paper application.”

- Obtained on: Select the date the application was received.

- Select Save .

- Write “PA” on the bottom right-hand corner of the first page of the paper application and send for imaging. If other documents are attached to the application, refer to the appropriate task (e.g.: Entering data from a paper ROE , Adding a direct deposit , Preparing documents for imaging ).

- If yes, refer to Change of address to input the Name and Address Change/Transfer (M159) transaction and go to step 3.
               [Change of address](/en/procedure/activity/change_address.shtml)

- If no, go to step 3. 

#### Registering an initial claim

Source topic: `en_EN/task/entering_pa/registering_an_initial_claim_non-complex.dita`

- In SSO, verify that the correct mainframe is selected and register the claim as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Initial .

- Select Search .

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3362.dita)

- Review the Name and Address screen.
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3363.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2647.dita) 

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: Both fields are prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Enter the client’s personal information in the following fields:

- First name

- Last name

- Gender

- Language - speaking

- Language - writing

- Date of birth

- Ordinary place of residence different (for a claim other than a commuter claim)

- Mailing address

- Postal code

- Telephone

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: For a commuter claim, enter the SCC associated with the workplace postal code. If the field is blank, enter the SCC of the region where the client resides:

- Atlantic: Type “1121 or 1953 (SE benefits).”

- Quebec: Type “2371 or 2930 (SE benefits).”

- Ontario: Type “3515 or 3978 (SE benefits).”

- Western Canada and Territories: Type “4812 or 4758 (SE benefits).”

- Last job: Enter the correct National Occupation Classification (NOC) code for the client’s last job title.
                       [National Occupation Classification](https://noc.esdc.gc.ca/Home/?GoCTemplateCulture=en-CA)

- Tax credit: Select the appropriate option.

- Select Next .

- On the Application Form screen, do the following:

- Application received: Enter the date the application was received. If this information is not available, enter the date the client signed the application.

- Reason for separation: Select the appropriate option.

- First day worked: Enter the first day worked.

- Last day worked: Enter the last day worked (LDW).

- Postmark application: Enter the postmark application date. If the postmark application date is not provided, enter the date the client signed the application.

- Select Next .

- On the Registration screen, do the following:

- Pay SCC: Verify that the SCC is the same as shown in FTS. If the field is blank, enter the SCC of the region where the client resides:

- Atlantic: Type “1121 or 1953 (SE benefits).”

- Quebec: Type “2371 or 2930 (SE benefits).”

- Ontario: Type “3515 or 3978 (SE benefits).”

- Western Canada and Territories: Type “4812 or 4758 (SE benefits).”

- Service unit: Type “01.”

- Tentative BPC: If the field is blank, determine the BPC based on the client’s LDW and application date. If the registration number being obtained is for a subsequent claim, select the week after the previous claim’s LRW.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select Yes to generate the Initial Intake (M149) transaction.

- Select Generate registration .
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2648.dita)

- Select Next .

- On the M149 - Initial Intake Data screen, select Update .

- Determine if the following error message appears:

- WARNING! WARNING! WARNING! Unable to create work item for: SIN = 999999999 REG = 999999 Error Code = 1004 (Unexpected Error)

- If yes, go to step 3.

- If no, go to step 4.

- In NWS, create a CA WI as follows:

- Select Paper Application - [date of the application] .

- Select Claim Assessment / Specialized application .

- Registration Number: Enter the registration number as shown in SSO.

- Complexity: Select Level 1 .

- Language: Select the appropriate option depending on the language of the client’s application.

- Claim type: Select Initial .

- Benefit type: Select the appropriate type.

- Destination: Enter the SCC as shown in FTS, or if blank, enter the SCC based on which region the client lives in, using one of the following codes:

- Atlantic: 1121 or 1953 (SE benefits)

- Quebec: 2371 or 2930 (SE benefits)

- Ontario: 3515 or 3978 (SE benefits)

- Western: 4812 or 4758 (SE benefits)

- Date of application: Enter the correct date.

- Error number: Type “1004.”

- If the Intake Data (M149) screen is displayed, do the following:

- Review the information.

- If the First Name field on the Name and Address screen in SSO was modified to “NA” because the client has only one name and selected X as the gender marker, enter a “.” in the First Name field.

- Select Update to transmit the information.

- Go to step 5.

- Determine if an error message is displayed, and do the following:

- If the Intake Data (M149) or Name and Address Change / Transfer (M159) screen displays an error code, go to correcting an Intake Data (M149)/ Name and Address Change/ Transfer (M159) error .
               [correcting an Intake Data (M149)/ Name and Address Change/ Transfer (M159) error](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/entering_pa#M149)

- If an error message is not displayed, go to step 6.

- In NWS, in the Client information tree , select the Paper Application tab, and complete the following field:

- SCC: select the same SCC as the one displayed in FTS or if blank enter the SCC, determined by the client’s region of residence, by using one of the following codes:

- Atlantic: 1121 or 1953 (SE benefits)

- Quebec: 2371 or 2930 (SE benefits)

- Ontario: 3515 or 3978 (SE benefits)

- Western: 4812 or 4758 (SE benefits)

- In NWS, create an SROC and complete the following fields:

- BPC: Enter the BPC as shown on the Intake Data (M149) screen in SSO or FTS.

- Issue: Select Other .

- Comments: Type “paper application” and the date it was received.

- Details: Type “paper application registered” and any comments the client provided on the paper application. Indicate any other documents received with the application.

- Obtained by: Select Other .

- Obtained from: Select Client .

- Source Detail: Type “paper application.”

- Obtained on: In the drop-down calendar, select the date the application was received.

- Select Save .

- Write “PA” on the bottom right-hand corner of the first page of the paper application and send for imaging. If other documents are attached to the application, refer to the appropriate task (e.g.: Entering data from a paper ROE , Adding a direct deposit , Preparing documents for imaging ). 

#### Correcting an error on the Initial Intake (M149) or Name and Address Change / Transfer (M159) screen

Source topic: `en_EN/task/entering_pa/correcting_an_error_on_the_initial_inta_09209fcd_non-complex.dita`

- In FTS, select either the Initial Intake (M149) or Name and Address Change/Transfer (M159) transaction:

- If it is an initial application, complete the Initial Intake (M149) by entering the correct BPC in the Tentative BPC field.

- Select Update .

- If it is a renewal application, complete the Name and Address Change/Transfer (M159) transaction by ensuring that the address in the system is the same as the address on the application. If the address on the Name and Address Change/Transfer (M159) is different from the address on the application, refer to Change of address .

- Select Update .

               [Change of address](/en/procedure/activity/change_address.shtml)

- Determine if the Intake Data (M149) screen or Name and Address Change / Transfer (M159) screen displays an error code:

- If there is an error code, go to step 3.

- If there is no error code, go to step 4.

- In NWS, create an AI WI and complete the following fields:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Rejected transactions .

- BPC: Enter the BPC as shown in FTS.

- Comments: Type “rejected initial intake” and the error code.

- Details: Type “Review the claim and take the required action.”

- Obtained by: Select Other .

- Obtained from: Select Other .

- Obtained on: Select today’s date in the drop-down calendar.

- Select Save .

- In NWS, in the Client information tree , select the Paper Application tab, and complete the following field:

- SCC: Select the SCC as shown in FTS, or if blank, enter the SCC , based on the client’s region of residence, using one of the following codes:

- Atlantic: 1121 or 1953 (SE benefits)

- Quebec: 2371 or 2930 (SE benefits)

- Ontario: 3515 or 3978 (SE benefits)

- Western: 4812 or 4758 (SE benefits)

- In NWS, create an SROC and complete the following fields:

- BPC: Enter the BPC as shown on the Intake Data ( M149) screen in SSO or FTS.

- Issue: Select Other .

- Comments: Type “paper application” and the date it was received.

- Details: Type “paper application registered” and any comments the client provided on the paper application. Indicate any other documents received with the application.

- Obtained by: Select Other .

- Obtained from: Select Client .

- Source Detail: Type “paper application.”

- Obtained on: In the drop-down calendar, select the date the application was received.

- Select Save .

- Write “PA” on the bottom right-hand corner of the first page of the paper application and send for imaging. If other documents are attached to the application, refer to the appropriate task (e.g.: Entering data from a paper ROE , Adding a direct deposit , Preparing documents for imaging) . 

#### Creating an Action Item (AI) WI for Level 1

Source topic: `en_EN/task/entering_pa/creating_an_action_item_ai_wi_for_level_1_non-complex.dita`

- In NWS, create an AI WI and complete the following fields:

- Complexity: Select Level 1 .

- Language: Select the appropriate option depending in what language the client completed his application in.

- Destination: Enter the SCC as shown in FTS.

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- BPC: Enter the appropriate BPC.

- Comments: Type “The claim is already in the system.”

- Details: Type “Review the claim and take the required action.”

- Obtained by: Select Other .

- Obtained from: Select Other .

- Obtained on: Select today’s date in the drop-down calendar.

- Select Save .

- Write “PA” on the bottom right-hand corner of the first page of the paper application and send for imaging. If other documents are attached to the application, refer to the appropriate task (e.g.: Enter a paper ROE , Adding a direct deposit , Prepare documents for imaging). 

#### Note

Source topic: `en_EN/common_notes/note_c_3362.dita`

Note:

ACP cannot register a new application when there is an outstanding initial or renewal registration. There cannot be more than one outstanding initial or renewal registration number on a claim, and not more than 2 outstanding registration numbers. If there are already 2 outstanding registration numbers, advise the team leader that multiple registration numbers are preventing a new one from being created. 

#### Note

Source topic: `en_EN/common_notes/note_c_3363.dita`

Note:

In some cases, if the client has a previous application, some fields may be prefilled with information. In such cases, verify the information provided on the paper application, and correct the information, if necessary. 

#### Note

Source topic: `en_EN/common_notes/note_c_2647.dita`

Note:

When the client has only one name, one of the name fields on the Name and Address screen may be empty or contain a non-alphabetical character. However, SSO does not allow the field to be completed in this way.

When a name field is empty or contains a non-alphabetical character, do the following:

- First Name: Enter the appropriate option:

- For a client who selects the Male gender marker, type “Mr.”

- For a client who selects the Female gender marker, type “Ms.”

- For a client who selects X as the gender marker, type “N.A.”

- Last Name: Enter the client’s name.

When the First Name field on the Name and Address screen is modified to “N.A.”, modify the Initial Intake (M149) or Name and Address Change / Transfer (M159) transaction generated by the calculation and type “.” in the First Name field before transmitting it. 

#### Note

Source topic: `en_EN/common_notes/note_c_2648.dita`

Note:

At this step, a registration number is assigned to the claim. If Yes is selected, the Initial Intake (M149) transaction is automatically generated.

If No is selected, the Initial Intake (M149) transaction is not generated. 

## Policy reference

Source topic: `en_EN/task/entering_pa/policy_reference.dita`

- EIA 48(1)
         [EIA 48(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-48.html)

- EIA 50(3)
         [EIA 50(3)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-50.html) 
