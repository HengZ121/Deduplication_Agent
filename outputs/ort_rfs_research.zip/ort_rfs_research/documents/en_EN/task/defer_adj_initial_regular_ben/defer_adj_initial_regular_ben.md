# Deferring adjudication: Initial claim — Regular benefits

Source map: `en_EN/task/defer_adj_initial_regular_ben/defer_adj_initial_regular_ben.ditamap`

## Summary

Source topic: `en_EN/task/defer_adj_initial_regular_ben/summary.dita`

Summary: In certain situations, adjudication of contentious issues can be deferred on initial claims for regular benefits. 

## What you need to know

Source topic: `en_EN/task/defer_adj_initial_regular_ben/what_you_need_to_know.dita`

### Conditions

Source topic: `en_EN/task/defer_adj_initial_regular_ben/conditions.dita`

To determine entitlement to benefits when an Adjudication Issue (ADJ) WI is assigned, officers must fact-find and adjudicate the issue, regardless of whether the ROEs have been received.

On initial claims for regular benefits, the officer can defer adjudication in the following situations:

- any adjudication issue when the claim is automated BPNE 2;

- any adjudication issue when the claim is a manual BPNE 2 at day 27;

- any adjudication issue when the claim is automated BPNE 1 or 5;

- any adjudication issue when the claim is a manual BPNE 1 or 5;

- any adjudication issue when the client has less than 420 insurable hours in the qualifying period (QP);

- the reason for separation (RFS) is B - Strike or lockout (labour dispute) and the claim is BPNE;

- a contentious reason for separation (RFS) before a disqualifying event that results in an indefinite disqualification. 

### Conditions for claims with a BPC between w/c 2310 and w/c 2361

Source topic: `en_EN/task/defer_adj_initial_regular_ben/conditions_for_claims_with_a_bpc_betwee_7b0401eb.dita`

For claims with a BPC between w/c 2310 and w/c 2361, the officer only reviews a contentious RFS if it is for the most recent period of employment. The officer does not take into consideration any contentious RFS on other ROEs in the QP and they are included in the calculation of the claim. Therefore, the officer does not consider deferring adjudication for any other ROEs in the QP, even if they occur before a disqualifying event that results in an indefinite disqualification. The officer continues to follow all other deferral conditions noted above for claims in this range. This measure does not apply to claims for self-employment (SE) or fishing benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3037.dita) 

### Claim action status and processing of the claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/claim_action_status_and_processing_of_the_claim.dita`

During processing, an initial claim displays one of the following claim action statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

- Finalized - Pending LREM

When the claim action status shows In Progress, all ADJ WIs must be completed before the system can calculate the initial claim. However, in some cases, when the system automates a claim, the adjudication is automatically deferred as well. 

### Deferring adjudication on an automated BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_an_automated__817fd17b.dita`

Claims are automated BPNE 2 and the Claim action status changes to Finalized - Pending LREM when the last ROE is not received at the end of the initial wait process (day 27). The officer moves all ADJ WIs to Pending when the status shows Finalized - Pending LREM . If the last ROE is still missing at the end of the extended initial wait process (day 46), adjudication of any issue is deferred by the system when it sets the claim status to Finalized . A record of decision (ROD) is created automatically. The Last record of employment missing option on the Resolve Issue screen must never be used while the claim is still in automation. 

### Deferring adjudication on a manual BPNE 2 claims

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_a_manual_bpne_2_claims.dita`

When the Claim action status is In Progress (Manual) and the last ROE is missing at day 27, the officer with the Claim Assessment (CA) WI can only finalize the claim BPNE 2 after all ADJ WIs are completed. The officer with the ADJ WI can defer adjudication of any issue so the officer with the CA WI can complete it. 

### Deferring adjudication on an automated BPNE 1 or 5 claims

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_an_automated__5752812e.dita`

Claims are automated BPNE 1 or 5 when clients did not accumulate enough insurable hours to establish a claim. The system defers adjudication on any issue when a claim has been automated BPNE 1 or 5. A ROD is created automatically. 

### Deferring adjudication on a manual BPNE 1 or 5 claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_a_manual_bpne_fbae7619.dita`

Any adjudication is deferred when a claim will be manually finalized as BPNE 1 or 5. The officer manually finalizes the claim when all of the required information is on file, or when the CA WI has reached the due date. 

### Deferring adjudication on an obvious BPNE claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_an_obvious_bpne_claim.dita`

When reviewing a claim, it may be obvious that the claim calculation will result in BPNE 1. This occurs when clients have accumulated less than 420 insurable hours in the QP and all ROEs included in the QP are on file. As there is no potential for recalculation, adjudication of any issue is deferred. 

### Deferring adjudication before a disqualifying event

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_before_a_disqual_7216ebc7.dita`

When there is one or more voluntary leaving or dismissal in the QP, any one of these events can prevent payment of regular benefits in the benefit period (BP). Adjudication is deferred on any contentious RFS before a disqualifying event that results in an indefinite disqualification 10 - Dismissal - misconduct proven (D10) or 11 - Voluntary leaving - Just cause not proven (D11).

To determine a disqualifying event, the officer must first consider the most recent event of voluntary leaving or dismissal in the QP. The most recent event is not always equal to the last employment and can fall anywhere in the QP. If the officer determines that there is no disqualification for that event, fact-finding and adjudication are completed for the preceding voluntary leaving or dismissal in the QP. The officer continues to work in reverse chronological order until:

- an indefinite disqualification is imposed;

- the beginning of the QP is reached; or

- no event results in an indefinite disqualification.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3038.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3039.dita) 

### Deferring adjudication on a labour dispute

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_a_labour_dispute.dita`

When the RFS is B, the officer can defer a decision on an initial claim for regular benefits if the claim is or will be finalized BPNE and no benefits will be paid. When the claim can be established, deferral is impossible. 

### Record of decision (ROD) — Creation

Source topic: `en_EN/task/defer_adj_initial_regular_ben/record_of_decision_rod__creation.dita`

When adjudication is being deferred on issues that do not display a Resolve Issue tab on the ADJ WI, the officer is responsible for creating a ROD for the issue that is being deferred. If a Resolve Issue tab is displayed on the ADJ WI, the officer is responsible for completing all screens. Once the screens are completed, the system automatically creates a ROD. 

### Special condition field in RCM

Source topic: `en_EN/task/defer_adj_initial_regular_ben/special_condition_field_in_rcm.dita`

There is no Resolve Issue tab on the ADJ WI for leave of absence and strike or lockout (labour dispute) issues. Therefore, when adjudication is deferred, the officer must select Adjudication deferred in the Special condition field of the appropriate ROE in RCM. For all other RFS issues with a Resolve Issue tab on the ADJ WI, the system updates the Special condition field. 

### Deferring adjudication when the ROE is not on file

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_when_the_roe_is__0f07e548.dita`

When all conditions to defer are met, adjudication on a contentious RFS can be deferred even if the ROE is not on file. When the ROE is received, the system attempts to locate an electronic decision to update the Special condition field. If it cannot locate one, an ROE RFS WI is created. 

### Communicating the decision

Source topic: `en_EN/task/defer_adj_initial_regular_ben/communicating_the_decision.dita`

There is no requirement to notify the client of a deferral. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Note

Source topic: `en_EN/common_notes/note_c_3037.dita`

Note:

The adjudication of an antedate request can never be deferred. Antedate requests must be adjudicated even if the claim results in a BPNE 1 or 5. 

### Info

Source topic: `en_EN/common_notes/note_c_3038.dita`

**Example 1**

```text
| Cut-off date | 700 hours | 500 hours | 300 hours | BPC |

| | ROE 3 - RFS | ROE 2 - RFS | ROE 1 - RFS | |

| | Layoff | Voluntary leaving | Misconduct proven | |
```

- The last employment or most recent disqualifying event is ROE 1. Since misconduct was proven, a disqualification will result. Because a D10 disqualification is being imposed for ROE 1, the adjudication of the RFS on ROE 2 can be deferred. All the hours in the QP are used to calculate the claim. 

### Info

Source topic: `en_EN/common_notes/note_c_3039.dita`

**Example 2**

```text
| Cut-off date | 700 hours | 300 hours | 600 hours | BPC |

| | ROE 3 - RFS | ROE - 2 RFS | ROE 1 - RFS | |

| | Dismissal | Voluntary Leaving — No just cause | Lay-off | |

| | VER = 595 | | | |
```

- The last employment or most recent disqualifying event is ROE 2. The client has worked enough insurable hours after the voluntary leaving for a claim to be established solely based on the hours of ROE 1. Because the client has sufficient insurable hours since the disqualifying event, a D11 disqualification is not imposed. The 300 hours from ROE 2 are excluded from calculation. The RFS on ROE 3 cannot be deferred. The RFS on ROE 3 must be adjudicated to determine whether that ROE is used in the calculation. 

## Regional considerations

Source topic: `en_EN/task/defer_adj_initial_regular_ben/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/defer_adj_initial_regular_ben/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/defer_adj_initial_regular_ben/in_fts.dita`

- Has the claim been automated BPNE 2? 

### In NWS:

Source topic: `en_EN/task/defer_adj_initial_regular_ben/in_nws.dita`

- What is the Claim action status?

- Is there more than one employer in the QP?

- Is there a Resolve Issue tab for the ADJ WI?

- Are there RODs for other RFS issues on the claim?

- If so, what was the decision? 

### In RCM:

Source topic: `en_EN/task/defer_adj_initial_regular_ben/in_rcm.dita`

- Are all ROEs for the QP on file?

- What is the total number of insurable hours in the QP? 

## Step by step

Source topic: `en_EN/task/defer_adj_initial_regular_ben/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/defer_adj_initial_regular_ben/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/defer_adj_initial_regular_ben/reviewing_the_file_level_1.dita`

- In RCM, determine if the last ROE is missing:

- If yes, go to step 2.

- If no, go to step 5.

- In NWS, determine if the claim action status is Finalized - Pending LREM :

- If yes, go to Deferring adjudication on an automated BPNE 2 claim .
               [Deferring adjudication on an automated BPNE 2 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#L1AutomatedN2)

- If no , go to step 3.

- Determine if the claim action status is In Progress (Manual) :

- If yes, go to step 4.

- If no, go to step 6.

- Determine if more than 26 days have passed since the date the application was filed:

- If yes, go to Deferring adjudication on a manual BPNE 2 claim .
               [Deferring adjudication on a manual BPNE 2 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#L1ManualN2)

- If no, go to step 5.

- Determine if the claim will be manually finalized as BPNE 1 or 5.

- If no, go to step 6.

- If yes, go to Deferring adjudication on a manual BPNE 1 or 5 claim .
               [Deferring adjudication on a manual BPNE 1 or 5 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#DefADJManualBPNE5)

- In RCM, determine the total number of insurable hours for all ROEs in the QP, including any interim ROEs and ROE: INS3166 Request for missing ROE — Form (INS3166) forms on file:

- If the total number of hours is 419 or less, go to step 7.

- If the total number of hours is 420 or more, go to Deferring adjudication in any other situation .
               [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#OtherLevel1)

- Determine if the ROEs, interim ROE or any INS3166 forms are on file for all insurable employment listed on the application for benefits:

- If all ROEs, interim ROE and INS3166 forms are on file, go to Deferring adjudication on an obvious BPNE claim .
               [Deferring adjudication on an obvious BPNE claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#ObviousBPNELevel1)

- If all ROEs, interim ROE and INS3166 forms are not on file, and the issue is not a contentious RFS, deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

- If all ROEs, interim ROE and INS3166 forms are not on file and the issue is a contentious RFS, go to Deferring adjudication in any other situation .
               [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#OtherLevel1) 

#### Deferring adjudication on an automated BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_an_automated__817fd17b_level_1.dita`

- Determine if the client clearly indicates that the missing ROE will not be provided and no interim ROE can be created.

- If the client did not clearly indicate that the missing ROE will not be provided or if an interim ROE can be created, go to step 4.

- If the client clearly indicates that the missing ROE will not be provided and no interim ROE can be created, go to step 6.

- In NWS, move the WI for the issue being deferred to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “awaiting last ROE.”

- Bring forward date: Enter the date of application + 45 days.

- When the WI moves to the current workload, determine if the last ROE, including any interim ROE or INS3166 form for the last ROE is on file:

- If no and the bring forward date has not been reached, repeat step 4.

- If no and the bring forward date has been reached, go to step 6.

- If yes, deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI.

- If yes, go to step 7.

- If no, go to step 9.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 10.

- For the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is leave of absence)

- last day worked for the employer (if the issue is leave of absence)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on a manual BPNE 1 or 5 claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_a_manual_bpne_fbae7619_level_1.dita`

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI:

- If yes, go to step 7.

- If no, go to step 9.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Obviously BPNE .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 12.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — manual BPNE

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of the ROE (if the issue is a contentious RFS)] is deferred because the claim will be manually finalized as BPNE.”

- Select Save .

- Determine if adjudication is being deferred for a leave of absence or a strike or lockout issue:

- If yes, go to step 11.

- If no , go to step 12.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- In NWS, complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on a manual BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_a_manual_bpne_2_claim_level_1.dita`

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI of the RFS.

- If yes, go to step 6.

- If no, go to step 8.

- On the Resolve Issue tab of the ADJ WI of the RFS, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 9.

- For the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on an obvious BPNE claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_an_obvious_bpne_claim_level_1.dita`

- In NWS, determine if you have a Resolve Issue tab for the ADJ WI:

- If yes, go to step 8.

- If no, go to step 10.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Obviously BPNE .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 15.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — obvious BPNE

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is obviously BPNE. Less than 420 insurable hours on file.”

- Select Save .

- Determine if adjudication is being deferred for a leave of absence or a strike or lockout issue:

- If yes, go to step 12.

- If no , go to step 15.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If the validation causes an ROE error, go to step 14.

- If the validation does not cause an ROE error, go to step 15.

- In NWS, determine if there is an ROE Issue (ROE) Correction WI or CA WI for this ROE:

- If there is an ROE Correction or CA WI, go to step 15.

- If there is no ROE Correction or CA WI, create an ROE Correction WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the Service Canada centre (SCC) as shown in FTS.

- End User: Select Myself .

- Serial Number: Enter the serial number of the ROE.

- Issue: Select Correction .

- In NWS, complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication in any other situation

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_in_any_other_situation_level_1.dita`

- Determine if the RFS is B - Strike or lockout :

- If no, go to step 2.

- If yes, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious issue.

- Determine if there is more than one contentious RFS on file:

- If yes, go to step 3.

- If no , deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3040.dita)

- Determine if the last contentious RFS has been adjudicated:

- If yes, go to step 4.

- If no, deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

- Determine if the adjudication of any contentious RFS in the QP resulted in an indefinite disqualification (D10 or D11):

- If yes, go to step 5.

- If no , deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

- Determine if the RFS that must be adjudicated occurred before the event that resulted in a D10 or D11:

- If yes, go to step 6.

- If no , deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab for the ADJ WI of the RFS:

- If yes, go to step 7.

- If no, go to step 9.

- On the Resolve Issue tab of the ADJ WI of the RFS, complete the screen as follows:

- Select The client has been disqualified from receiving benefits due to a reason for separation from a more recent period of employment .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 14.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer

- last day worked for the employer

- deferred adjudication — before disqualifying event

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of ROE] is deferred because it occurred before a disqualifying event.”

- Select Save .

- In RCM, determine if the ROE is on file:

- If the ROE is on file, go to step 11.

- If the ROE is not on file, go to step 14.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If the validation causes an ROE error, go to step 13.

- If the validation does not cause an ROE error, go to step 14.

- In NWS, determine if there is an ROE Correction WI or CA WI for this ROE:

- If there is an ROE Correction or CA WI, go to step 14.

- If there is no ROE Correction or CA WI, create an ROE Correction WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Serial Number: Enter the serial number of the ROE.

- Issue: Select Correction .

- In NWS, complete the ADJ WI of the RFS for the adjudication issue being deferred. 

#### Note

Source topic: `en_EN/common_notes/note_c_3040.dita`

Note:

On claims with a BPC between w/c 2310 and w/c 2361, adjudication is only required on the last RFS. Therefore, adjudication deferral before a disqualifying event no longer applies. This measure does not apply on claims for SE or fishing benefits.

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Level 2

Source topic: `en_EN/task/defer_adj_initial_regular_ben/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/defer_adj_initial_regular_ben/reviewing_the_file_level_2.dita`

- In RCM, determine if the last ROE is missing:

- If yes, go to step 2.

- If no, go to step 5.

- In NWS, determine if the claim status is Finalized - Pending LREM :

- If yes, go to Deferring adjudication on an automated BPNE 2 claim .
               [Deferring adjudication on an automated BPNE 2 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#L2AutomatedN2)

- If no , go to step 3.

- Determine if the claim action status is In Progress (Manual) :

- If yes, go to step 4.

- If no, go to step 6.

- Determine if more than 26 days have passed since the date the application was filed:

- If no, go to step 5.

- If yes, go to Deferring adjudication on a manual BPNE 2 claim .
               [Deferring adjudication on a manual BPNE 2 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#L2ManualN2)

- Determine if the claim will be manually finalized as BPNE 1 or 5.

- If no, go to step 6.

- If yes, go to Deferring adjudication on a manual BPNE 1 or 5 claim .
               [Deferring adjudication on a manual BPNE 1 or 5 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#DefADJManualBPNE5L2)

- In RCM, determine the total number of insurable hours for all ROEs in the QP, including any interim ROE or ROE: INS3166 Request for missing ROE — Form (INS3166) forms on file:

- If the total number of hours is 419 or less, go to step 7.

- If the total number of hours is 420 or more, go to Deferring adjudication in any other situation .
               [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#OtherLevel2)

- Determine if the ROE, interim ROE or any INS3166 forms are on file for all insurable employment listed on the application for benefits:

- If all ROEs, interim ROE and INS3166 forms are on file, go to Deferring adjudication on an obvious BPNE claim .
               [Deferring adjudication on an obvious BPNE claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#ObviousLevel2)

- If all ROEs, interim ROEs and INS3166 forms are not on file, and the issue is not a contentious RFS, deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

- If all ROEs, interim ROEs and INS3166 forms are not on file and the issue is a contentious RFS, go to Deferring adjudication in any other situation .
               [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_regular_ben#OtherLevel2) 

#### Deferring adjudication on an automated BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_an_automated__817fd17b_level_2.dita`

- Determine if the client clearly indicated that the missing ROE will not be provided and no interim ROE can be created.

- If the client did not clearly indicate that the missing ROE will not be provided or if an interim ROE can be created, go to step 4.

- If the client clearly indicates that the missing ROE will not be provided and no interim ROE can be created, go to step 6.

- In NWS, move the WI for the issue being deferred to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “awaiting last ROE.”

- Bring forward date: Enter the date of application + 45 days.

- When the WI moves to the current workload, determine if the last ROE, including any interim ROE or any INS3166 form for the last ROE is on file:

- If no and the bring forward date has not been reached, repeat step 4.

- If no and the bring forward date has been reached, go to step 6.

- If yes, deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI:

- If yes, go to step 7.

- If no, go to step 9.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 10.

- For the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is leave of absence)

- last day worked for the employer (if the issue is leave of absence)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on a manual BPNE 1 or 5 claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_a_manual_bpne_fbae7619_level_2.dita`

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI:

- If yes, go to step 7.

- If no, go to step 9.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Obviously BPNE .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 12.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — manual BPNE

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim will be manually finalized as BPNE.”

- Select Save .

- Determine if adjudication is being deferred for a leave of absence or a strike or lockout issue:

- If yes, go to step 11.

- If no , go to step 12.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- In NWS, complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on a manual BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_a_manual_bpne_2_claim_level_2.dita`

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI of the RFS.

- If yes, go to step 6.

- If no, go to step 8.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 9.

- For the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on an obvious BPNE claim

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_on_an_obvious_bpne_claim_level_2.dita`

- In NWS, determine if you have a Resolve Issue tab for the ADJ WI:

- If yes, go to step 8.

- If no, go to step 10.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Obviously BPNE .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 15.

- In NWS, for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — obvious BPNE

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is obviously BPNE. Less than 420 insurable hours on file.”

- Select Save .

- Determine if adjudication is being deferred for a leave of absence or a strike or lockout issue:

- If yes, go to step 12.

- If no, go to step 15.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If the validation causes an ROE error, go to step 14.

- If the validation does not cause an ROE error, go to step 15.

- In NWS, determine if there is an ROE Correction WI or CA WI for this ROE:

- If there is an ROE Correction or CA WI, go to step 15.

- If there is no ROE Correction or CA WI, create an ROE Correction WI as follows:

- Complexity: Select Non-Complex .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Serial Number: Enter the serial number of the ROE.

- Issue: Select Correction .

- In NWS, complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication in any other situation

Source topic: `en_EN/task/defer_adj_initial_regular_ben/deferring_adjudication_in_any_other_situation_level_2.dita`

- Determine if the RFS is B - Strike or lockout:

- If no, go to step 2.

- If yes, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious issue.

- Determine if there are more than one contentious RFS on file:

- If yes, go to step 3.

- If no , deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3040.dita)

- Determine if the last contentious RFS has been adjudicated:

- If yes, go to step 4.

- If no , return to the originating procedure to adjudicate the contentious issue.

- Determine if the adjudication of the last contentious RFS resulted in an indefinite disqualification (D10 or D11):

- If no or if you are unable to determine if the decision will result in a disqualification, go to step 5.

- If yes, go to step 7.

- Working in reverse chronological order from the last contentious RFS, adjudicate any contentious RFS until one of the following conditions is met:

- If adjudication resulted in an indefinite disqualification (D10 or D11), go to step 6.

- If the start of the tentative QP has been reached and no adjudication resulted in an indefinite disqualification (D10 or D11), deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

- Determine if the RFS that must be adjudicated occurred before the event that resulted in a D10 or D11:

- If yes, go to step 7.

- If no , deferral is not possible. Return to the originating procedure to adjudicate the contentious issue.

- In NWS, determine if you have a Resolve Issue tab for the ADJ WI of the RFS:

- If yes, go to step 8.

- If no, go to step 10.

- On the Resolve Issue tab of the ADJ WI of the RFS, complete the screen as follows:

- Select The client has been disqualified from receiving benefits due to a reason for separation from a more recent period of employment .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 15.

- In NWS, for the contentious RFS that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer

- last day worked for the employer

- deferred adjudication — before disqualifying event

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of ROE] is deferred because it occurred before a disqualifying event.”

- Select Save .

- In RCM, determine if the ROE is on file:

- If the ROE is on file, go to step 12.

- If the ROE is not on file, go to step 15.

- Update each of the ROEs for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If the validation causes an ROE error, go to step 14.

- If the validation does not cause an ROE error, go to step 15.

- In NWS, determine if there is an ROE Correction WI or CA WI for this ROE:

- If there is an ROE Correction or CA WI, go to step 15.

- If there is no ROE Correction or CA WI, create an ROE Correction WI as follows:

- Complexity: Select Non-Complex .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Serial Number: Enter the serial number of the ROE.

- Issue: Select Correction .

- Go to step 15.

- In NWS, complete the ADJ WI of the RFS for the adjudication issue being deferred. 

## Policy reference

Source topic: `en_EN/task/defer_adj_initial_regular_ben/policy_reference.dita`

 
