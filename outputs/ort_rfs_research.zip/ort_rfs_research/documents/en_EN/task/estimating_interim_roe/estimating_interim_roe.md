# Estimating interim ROE information

Source map: `en_EN/task/estimating_interim_roe/estimating_interim_roe.ditamap`

## Summary

Source topic: `en_EN/task/estimating_interim_roe/summary.dita`

Summary: When an interim ROE is required to finalize the calculation of a claim and actual hours and earnings information is not available, an interim ROE is created by estimating the information. 

## What you need to know

Source topic: `en_EN/task/estimating_interim_roe/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/estimating_interim_roe/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Interim ROEs

Source topic: `en_EN/task/estimating_interim_roe/interim_roes.dita`

Before estimating an interim ROE, the officer determines if it is required by referring to Determining if an interim ROE is required .
       [Determining if an interim ROE is required](/en/procedure/task/determining_interim_roe.shtml)

When an interim ROE is required, the officer verifies the legitimacy of the employment and estimates the interim ROE information based on the information available.

If the legitimacy of the employment cannot be confirmed or there are insufficient employment details to estimate the interim ROE, the officer denies the interim ROE. The client does not have the right to file a request for reconsideration regarding the decision to deny an interim ROE. An interim ROE is an administrative measure used to provide a service to the client. 

### Verifying the legitimacy of the employment

Source topic: `en_EN/task/estimating_interim_roe/verifying_the_legitimacy_of_the_employment.dita`

Fraudulent requests for interim ROEs are among the actions people take to receive EI benefits fraudulently. For more information, the officer refers to Fraud indicators: Identifying potentially fraudulent claims — Knowledge . Before creating an interim ROE, the officer verifies the legitimacy of the employment. The officer does not use FTS and SSO to verify registered businesses because suspicious businesses cannot be determined in these systems. To verify the legitimacy of employment, the officer must consult both RMDS and Employers under Review .
       [Fraud indicators: Identifying potentially fraudulent claims — Knowledge](/en/procedure/generic/additionalresources/fraud_indicator.shtml) 
       [Employers under Review](https://014gc.sharepoint.com/sites/NEIDEnforcement/Ressources%20collaboratives%20%20Collaborative%20Resources/Forms/AllItems.aspx?id=%2fsites%2fNEIDEnforcement%2fRessources+collaboratives++Collaborative+Resources%2fEmployeurs+sous+examen+-+Employers+under+Review&viewid=0582f4ae-33aa-4fca-905b-07b1a3c96c54&xsdata=MDV8MDJ8ZGVuaXNlLmxlZ3Jvd0BzZXJ2aWNlY2FuYWRhLmdjLmNhfDMxYzBmYzc3YjY1ZjQwZmZlMTM5MDhkZTNlM2M2ODcyfDllZDU1ODQ2OGE4MTQyNDZhY2Q4YjFhMDFhYmZjMGQxfDB8MHw2MzkwMTY2MjYzMjY5NzA1MTN8VW5rbm93bnxUV0ZwYkdac2IzZDhleUpGYlhCMGVVMWhjR2tpT25SeWRXVXNJbFlpT2lJd0xqQXVNREF3TUNJc0lsQWlPaUpYYVc0ek1pSXNJa0ZPSWpvaVRXRnBiQ0lzSWxkVUlqb3lmUT09fDB8fHw%3d&sdata=c0VNNDUrS1BmNEpaejc0TkxrbGFmSUtZME54NWhzRm1LaEZSTzB4bmM3cz0%3d)

When a registered business is suspected of being made up or non-existent, an Integrity officer flags the employer profile in RMDS as Under investigation . At this time, a legitimate business that is used by an unauthorized third party cannot be flagged in RMDS. Because of this, Integrity Services Branch created Employers under Review , a resource in SharePoint listing registered businesses suspected of being used fraudulently.
       [Employers under Review](https://014gc.sharepoint.com/sites/NEIDEnforcement/Ressources%20collaboratives%20%20Collaborative%20Resources/Forms/AllItems.aspx?id=%2fsites%2fNEIDEnforcement%2fRessources+collaboratives++Collaborative+Resources%2fEmployeurs+sous+examen+-+Employers+under+Review&viewid=0582f4ae-33aa-4fca-905b-07b1a3c96c54&xsdata=MDV8MDJ8ZGVuaXNlLmxlZ3Jvd0BzZXJ2aWNlY2FuYWRhLmdjLmNhfDMxYzBmYzc3YjY1ZjQwZmZlMTM5MDhkZTNlM2M2ODcyfDllZDU1ODQ2OGE4MTQyNDZhY2Q4YjFhMDFhYmZjMGQxfDB8MHw2MzkwMTY2MjYzMjY5NzA1MTN8VW5rbm93bnxUV0ZwYkdac2IzZDhleUpGYlhCMGVVMWhjR2tpT25SeWRXVXNJbFlpT2lJd0xqQXVNREF3TUNJc0lsQWlPaUpYYVc0ek1pSXNJa0ZPSWpvaVRXRnBiQ0lzSWxkVUlqb3lmUT09fDB8fHw%3d&sdata=c0VNNDUrS1BmNEpaejc0TkxrbGFmSUtZME54NWhzRm1LaEZSTzB4bmM3cz0%3d)

The officer verifies employers not registered in our systems through external sources and, if necessary, by documentation.

**RMDS**

The officer searches for employers in RMDS to find businesses registered in our systems. If the Under investigation box is checked on the Employer Profile screen, the officer does not create an interim ROE and refers the issue to Integrity.

**Employers under Review**

This resource is maintained by Integrity Services Branch. The officer consults this list of suspicious registered businesses. If the employer is listed on Employers under Review , the officer does not create an interim ROE and refers the issue to Integrity.
       [Employers under Review](https://014gc.sharepoint.com/sites/NEIDEnforcement/Ressources%20collaboratives%20%20Collaborative%20Resources/Forms/AllItems.aspx?id=%2fsites%2fNEIDEnforcement%2fRessources+collaboratives++Collaborative+Resources%2fEmployeurs+sous+examen+-+Employers+under+Review&viewid=0582f4ae-33aa-4fca-905b-07b1a3c96c54&xsdata=MDV8MDJ8ZGVuaXNlLmxlZ3Jvd0BzZXJ2aWNlY2FuYWRhLmdjLmNhfDMxYzBmYzc3YjY1ZjQwZmZlMTM5MDhkZTNlM2M2ODcyfDllZDU1ODQ2OGE4MTQyNDZhY2Q4YjFhMDFhYmZjMGQxfDB8MHw2MzkwMTY2MjYzMjY5NzA1MTN8VW5rbm93bnxUV0ZwYkdac2IzZDhleUpGYlhCMGVVMWhjR2tpT25SeWRXVXNJbFlpT2lJd0xqQXVNREF3TUNJc0lsQWlPaUpYYVc0ek1pSXNJa0ZPSWpvaVRXRnBiQ0lzSWxkVUlqb3lmUT09fDB8fHw%3d&sdata=c0VNNDUrS1BmNEpaejc0TkxrbGFmSUtZME54NWhzRm1LaEZSTzB4bmM3cz0%3d)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3384.dita) 

**External sources**

When the employer is not registered in our systems, the officer verifies legitimacy of employment through other sources. The officer uses only reputable external sources, including the following:

- Canada's Business Registries ;
         [Canada's Business Registries](https://canadasbusinessregistries.ca/search)

- Better Business Bureau ;
         [Better Business Bureau](https://www.bbb.org/)

- canada411 ;
         [canada411](https://www.canada411.ca/)

- newspaper publications.

The officer exercises caution when using Internet sources. Social media accounts, company websites and domain names are sometimes used by made up businesses to appear legitimate. Therefore, the officer does not use these sources alone to verify legitimacy.

**Proof of legitimate employment**

If the officer is unable to confirm the employment’s legitimacy using the above, the officer asks if the client is able to provide documentation proving insurable employment such as:

- pay stub

- cancelled cheque

- T4

- work schedule

- written confirmation of insured hours and earnings by the employer

- termination notice

- badge or pass

- time card

- contract of service

- notice of garnishment

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3385.dita) 

The proof provided by the client may cover only part of the employment. Unless there is reason to doubt the credibility of the client’s statement, the officer accepts the proof for the whole period of employment.

If the officer determines the employment is legitimate following the verification methods above, the officer approves the interim ROE. When the officer cannot determine that the employment is legitimate following the verification methods or referring to other sources, and the client cannot prove the employment’s legitimacy, the officer denies the interim ROE. 

### Estimating the interim ROE

Source topic: `en_EN/task/estimating_interim_roe/estimating_the_interim_roe.dita`

When an interim ROE must be estimated, the officer uses the client’s statement about the details of the employment to calculate the interim ROE. The officer does not need the proof of employment to create the interim ROE.

If an interim ROE is required because the employer has failed to provide the ROE, the officer reviews the file to determine what employment details were obtained when Determining if an interim ROE is required .
       [Determining if an interim ROE is required](/en/procedure/task/determining_interim_roe.shtml)

When estimating the ROE, the officer uses all accurate employment details that are available. If there is evidence that part of the period was not insurable, or was insured for less than reported by the client, the officer reduces the interim estimated amounts accordingly.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3386.dita) 

**Required employment details**

The following employment details are required to estimate the regular interim ROE:

- employer’s name

- first day worked

- last day worked (LDW)

- total insurable hours worked or hours worked in a standard work week

- total insurable earnings or salary

- reason for separation (RFS)

- any monies paid or payable on separation

The following employment details are required to estimate the fishing interim ROE:

- employer’s name

- catch type (fresh or cured)

- trip start date (fresh catch only)

- trip end date (fresh catch) or date of purchase (cured catch)

- trip share of insurable earnings

- RFS

For additional information on completing an ROE, the officer refers to How to complete the Record of Employment .
       [How to complete the Record of Employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/roe-guide.html) 

### Easy Access

Source topic: `en_EN/task/estimating_interim_roe/easy_access.dita`

When an interim ROE is required, the officer determines if an ROE covering that same period of employment is in Easy Access.

If the ROE is on file in Easy Access, the officer determines if the ROE information appears to be accurate when compared to other information on the client’s file. If the ROE information appears accurate, the officer uses it to create an interim ROE. If the ROE information does not appear to be accurate or is incomplete, the officer uses a combination of the ROE information that appears to be accurate and the information on the client’s file to estimate the interim ROE.

If the required details of employment are insufficient to estimate an interim ROE and the only ROE on file in Easy Access from the employer is for another period of employment, the officer determines if the information on the ROE in Easy Access and the information on the file can be used to estimate the required details of the employment. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_3384.dita`

Note:

In Employers under Review , the search box located in the column header drop-down allows the officer to search and filter the list based on specific criteria.
       [Employers under Review](https://014gc.sharepoint.com/sites/NEIDEnforcement/Ressources%20collaboratives%20%20Collaborative%20Resources/Forms/AllItems.aspx?id=%2fsites%2fNEIDEnforcement%2fRessources+collaboratives++Collaborative+Resources%2fEmployeurs+sous+examen+-+Employers+under+Review&viewid=0582f4ae-33aa-4fca-905b-07b1a3c96c54&xsdata=MDV8MDJ8ZGVuaXNlLmxlZ3Jvd0BzZXJ2aWNlY2FuYWRhLmdjLmNhfDMxYzBmYzc3YjY1ZjQwZmZlMTM5MDhkZTNlM2M2ODcyfDllZDU1ODQ2OGE4MTQyNDZhY2Q4YjFhMDFhYmZjMGQxfDB8MHw2MzkwMTY2MjYzMjY5NzA1MTN8VW5rbm93bnxUV0ZwYkdac2IzZDhleUpGYlhCMGVVMWhjR2tpT25SeWRXVXNJbFlpT2lJd0xqQXVNREF3TUNJc0lsQWlPaUpYYVc0ek1pSXNJa0ZPSWpvaVRXRnBiQ0lzSWxkVUlqb3lmUT09fDB8fHw%3d&sdata=c0VNNDUrS1BmNEpaejc0TkxrbGFmSUtZME54NWhzRm1LaEZSTzB4bmM3cz0%3d)

     [Employers under Review](https://014gc.sharepoint.com/sites/NEIDEnforcement/Ressources%20collaboratives%20%20Collaborative%20Resources/Forms/AllItems.aspx?id=%2fsites%2fNEIDEnforcement%2fRessources+collaboratives++Collaborative+Resources%2fEmployeurs+sous+examen+-+Employers+under+Review&viewid=0582f4ae-33aa-4fca-905b-07b1a3c96c54&xsdata=MDV8MDJ8ZGVuaXNlLmxlZ3Jvd0BzZXJ2aWNlY2FuYWRhLmdjLmNhfDMxYzBmYzc3YjY1ZjQwZmZlMTM5MDhkZTNlM2M2ODcyfDllZDU1ODQ2OGE4MTQyNDZhY2Q4YjFhMDFhYmZjMGQxfDB8MHw2MzkwMTY2MjYzMjY5NzA1MTN8VW5rbm93bnxUV0ZwYkdac2IzZDhleUpGYlhCMGVVMWhjR2tpT25SeWRXVXNJbFlpT2lJd0xqQXVNREF3TUNJc0lsQWlPaUpYYVc0ek1pSXNJa0ZPSWpvaVRXRnBiQ0lzSWxkVUlqb3lmUT09fDB8fHw%3d&sdata=c0VNNDUrS1BmNEpaejc0TkxrbGFmSUtZME54NWhzRm1LaEZSTzB4bmM3cz0%3d) 

### Note

Source topic: `en_EN/common_notes/note_c_3385.dita`

Note:

Clients can upload proof of employment documents in MSCA.

The officer does not ask the client to submit proof of employment unless there is doubt about the legitimacy of the employment or the officer doubts the existence of documentation. 

### Note

Source topic: `en_EN/common_notes/note_c_3386.dita`

Note:

When a client cannot provide exact details of the employment, the officer must try to narrow down the information. For example, if the client states the first day worked was at the end of January, the officer asks if it was the last week. If it was, the officer asks if it was the Monday of that week. If the client cannot provide exact dates, the officer must estimate carefully to ensure that a future overpayment (OP) does not occur. 

## Regional considerations

Source topic: `en_EN/task/estimating_interim_roe/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/estimating_interim_roe/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/estimating_interim_roe/in_nws.dita`

- Is there an uploaded document, SROC or WI containing the employment information (letter or ROE: INS3166 Request for missing ROE — Form )?
         [ROE: INS3166 Request for missing ROE — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS3166.pdf)

- Is the required information on the application? 

### In Imaging:

Source topic: `en_EN/task/estimating_interim_roe/in_imaging.dita`

- Is there a document (letter or INS3166 form) containing the employment information? 

### In Easy Access:

Source topic: `en_EN/task/estimating_interim_roe/in_easy_access.dita`

- Is there an ROE from this employer for the period of employment? 

### In RMDS:

Source topic: `en_EN/task/estimating_interim_roe/in_rmds.dita`

- Is the employer found in the employer profile search?

- Is the Under investigation box checked? 

### In Employers under Review :

Source topic: `en_EN/task/estimating_interim_roe/in_employers_under_review.dita`

- Is the employer listed? 

## Step by step

Source topic: `en_EN/task/estimating_interim_roe/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/estimating_interim_roe/level_1.dita`

#### Reviewing Easy Access for the ROE

Source topic: `en_EN/task/estimating_interim_roe/reviewing_easy_access_for_the_roe_level_1.dita`

- In Easy Access, determine if there is an ROE from the employer for this period of employment:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the information of the ROE in Easy Access appears to be accurate.

- If no, go to step 3.

- If yes, go to Information of the ROE in Easy Access appears to be accurate .
               [Information of the ROE in Easy Access appears to be accurate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#information_roe_accurate) 

#### Reviewing the file

Source topic: `en_EN/task/estimating_interim_roe/reviewing_the_file_level_1.dita`

- Determine if the following information is available:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3387.dita) 

- If all the information is not on file, go to step 4.

- If all the information is on file, go to step 6.

- In Easy Access, determine if there is an ROE from the employer covering this or another period of employment:

- If yes, go to step 5.

- If no, go to Interim ROE denied .
               [Interim ROE denied](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Interim_ROE_denied)

- Determine if the information from the ROE in Easy Access and the information on the file can be used to estimate the interim ROE:

- If yes, go to Estimating the interim ROE using the information on file .
               [Estimating the interim ROE using the information on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Estimating_the_interim)

- If no, go to Interim ROE denied .
               [Interim ROE denied](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Interim_ROE_denied) 

#### Confirming the legitimacy of the employment

Source topic: `en_EN/task/estimating_interim_roe/confirming_the_legitimacy_of_the_employment_level_1.dita`

- In Easy Access, determine if there is an ROE from the employer covering this or another period of employment:

- If no, go to step 7.

- If yes, go to Estimating the interim ROE using the information on file .
               [Estimating the interim ROE using the information on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Estimating_the_interim)

- In RMDS, select Paper and select Search Employer. When the Employer Profile - Search screen opens, enter the search information in the appropriate fields:

- Review RMDS and Employers under Review to determine if the employer is flagged for an Integrity investigation:

- If yes, refer the issue to Integrity by referring to Creating or reassigning a WI — Integrity (Task) , then go to Interim ROE denied .
               [Creating or reassigning a WI — Integrity (Task)](/en/procedure/task/referral_integrity_create_reassign_wi.shtml) 
               [Interim ROE denied](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Interim_ROE_denied)

- If no, go to Estimating the interim ROE using the information on file .
               [Estimating the interim ROE using the information on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Estimating_the_interim)

           [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3388.dita)

- Determine if the employer is found in external sources:

- If the employer is not found or the legitimacy is in doubt, go to step 10.

- If the employer is found in reputable sources, go to Estimating the interim ROE using the information on file .
               [Estimating the interim ROE using the information on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Estimating_the_interim)

- Fact-find with the client to request documentation proving insurable employment. Refer to Proof of legitimate employment , if necessary.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 12.

- If the client was not reached or did not reply to the N-10-00-00 letter, go to Interim ROE denied .
               [Interim ROE denied](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Interim_ROE_denied)

- In NWS, create a new SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “Missing ROE information.”

- Details: Document the fact-finding details according to the

- National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save.

- Determine if the client can provide proof of legitimate employment:

- If yes, go to step 14.

- If no, go to Interim ROE denied .
               [Interim ROE denied](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Interim_ROE_denied)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select ROE .

- Comments: Type “Proof of legitimate employment.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if acceptable proof of legitimate employment is on file:

- If no, go to Interim ROE denied .
               [Interim ROE denied](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Interim_ROE_denied)

- If yes, go to Estimating the interim ROE using the information on file .
               [Estimating the interim ROE using the information on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/estimating_interim_roe#Estimating_the_interim)

           [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3389.dita) 

#### Interim ROE denied

Source topic: `en_EN/task/estimating_interim_roe/interim_roe_denied_level_1.dita`

- In ACS, create and send the F-00-00-01 letter with the following:

- Text - Free Text (1612): Type “To process your employment information from the employer [employer name], we require the following additional employment information: [required employment information]. When you provide this information, we will reconsider your claim. Please provide either the ROE or the information requested. For more information, please contact us at 1-800-206-7218.”

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “Interim ROE denied.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In NWS, determine if the WI is an Action item (AI) WI:

- If it is an AI WI, complete the WI.

- If it is a Claim Assessment (CA) WI, Specialized Application (SA) WI or Claim Review (CR) Recalculation WI, return to Reviewing information for a missing ROE .
               [Reviewing information for a missing ROE](/en/procedure/task/calc_determining/missing_roe.shtml)

- If it is any other WI, return to the previous task. 

#### Information from the ROE in Easy Access appears to be accurate

Source topic: `en_EN/task/estimating_interim_roe/information_from_the_roe_in_easy_access_0705c281_level_1.dita`

- Use the information from the ROE in Easy Access, as well as the information on file to create an interim ROE. In the Additional Information field, type “Interim ROE created based on ROE [serial number of the ROE in Easy Access] in Easy Access.” Refer to Entering an interim ROE . 

#### Estimating the interim ROE using information on file

Source topic: `en_EN/task/estimating_interim_roe/estimating_the_interim_roe_using_inform_1cbcf77c_level_1.dita`

- Determine if the missing ROE is a fishing ROE:

- If no, go to step 2.

- If yes, go to step 6.

- Determine if the details for the total insurable hours are on file:

- If no, go to step 3.

- If yes, go to step 4.

- From the information provided, estimate the total hours worked in 53 full weeks of work or the period of employment, whichever is shorter (if necessary, refer to How to complete the Record of Employment ). Make a note of your findings.

[Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3390.dita)

- Determine if the details for the total insurable earnings are on file:

- If no, go to step 5.

- If yes, refer to Entering an interim ROE .
               [Entering an interim ROE](/en/procedure/task/entering_interim_roe.shtml)

- From the information provided, estimate the total earnings for 27 full weeks of work or the period of employment since the last ROE, whichever is shorter. Add any insurable separation monies to the total earnings (if necessary, refer to How to complete the Record of Employment ). Make a note of your findings and refer to Entering an interim ROE .

[Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3391.dita)

- Determine if the details for the fisher’s share of the insurable earnings are on file:

- If no, go to step 7.

- If yes, refer to Entering an interim ROE .
               [Entering an interim ROE](/en/procedure/task/entering_interim_roe.shtml)

- From the information provided, estimate the total of the fisher’s share of insurable earnings for a maximum of 31 consecutive weeks of work or the period of employment since the last ROE, whichever is shorter (if necessary, refer to How to complete the Record of Employment ). Make a note of your findings and refer to Entering an interim ROE . 

#### Callout

Source topic: `en_EN/common_notes/note_c_3387.dita`

- employer’s name, telephone number and address

- type of work performed

- wages earned

- first and last day worked, if regular earnings

- catch type, if fishing earnings

- trip dates, if fishing earnings

- monies on separation, if applicable

- RFS 

#### Info

Source topic: `en_EN/common_notes/note_c_3388.dita`

Note: Do not disclose the status Under investigation to a client, employer or third party. 

#### Info

Source topic: `en_EN/common_notes/note_c_3389.dita`

Note: Review documentation for inconsistencies (e.g. ROE with no serial number or wrong name, or document does not match the information provided in the INS3166 form). 

#### Example

Source topic: `en_EN/common_notes/note_c_3390.dita`

Example:

A client worked from August 8, 2016 to September 22, 2017 with no breaks in work. The client worked 37.5 hours from Monday to Friday each week. As the period of employment represented 59 calendar weeks, use 53 weeks for the hours. Total hours = 1987.5 (53 full weeks × 37.5 hours per week.) 

#### Example

Source topic: `en_EN/common_notes/note_c_3391.dita`

Example:

A client worked from August 8, 2016 to September 22, 2017 with no breaks in work. The client worked 37.5 hours from Monday to Friday each week. The rate of pay was $900 per week and $450 in vacation pay was received on separation.

As the period of employment represented 59 calendar weeks, use 27 weeks for the earnings. Total earnings for work performed = $24 300 (27 full weeks X $900 per week.) Total earnings for the ROE = $24 750 (Total earnings for work performed + insurable separation monies.) 

## Policy reference

Source topic: `en_EN/task/estimating_interim_roe/policy_reference.dita`

 
