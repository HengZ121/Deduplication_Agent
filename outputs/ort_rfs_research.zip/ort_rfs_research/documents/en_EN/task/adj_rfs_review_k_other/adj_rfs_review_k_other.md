# Actioning an Adjudication Issue RFS Review WI: K - Other

Source map: `en_EN/task/adj_rfs_review_k_other/adj_rfs_review_k_other.ditamap`

## Summary

Source topic: `en_EN/task/adj_rfs_review_k_other/summary.dita`

Summary: When an ROE is received with a reason for separation (RFS) K - Other and there are no comments on the ROE, an Adjudication Issue (ADJ) RFS Review WI is created. The system cannot create a link between the ROE and the matching period of employment reported on the initial EI application. 

## What you need to know

Source topic: `en_EN/task/adj_rfs_review_k_other/what_you_need_to_know.dita`

### Conditions for creating the WI

Source topic: `en_EN/task/adj_rfs_review_k_other/conditions_for_creating_the_wi.dita`

When none of the periods of employment reported on the application have a contentious RFS, or when all the periods of employment with a contentious RFS are already linked to an ROE, an ADJ RFS Review WI is created. The RFS sub-option on the ROE is one of the following:

- Blank

- At employee’s request

- Canadian Forces - Queen’s Regulations and Orders 

### Reviewing the reason for separation (RFS)

Source topic: `en_EN/task/adj_rfs_review_k_other/reviewing_the_reason_for_separation_rfs.dita`

When an ADJ RFS Review WI is received, the Level 1 officer reviews the information on file and, if necessary, fact-finds with the interested parties to determine if the RFS is contentious and requires adjudication.

**No interruption of earnings (I of E)**

Fact-finding may reveal that the employer issued the ROE at the employee’s request. If the officer determines that there was no I of E in the qualifying period (QP), the ADJ RFS Review WI must not be completed. The officer refers to Procedures/conditions for removal of claims from the ACP process . The officer moves the ADJ RFS Review WI to Pending until the Claim Assessment (CA) or Specialized Application (SA) WI is created. An authorized user must then delete the ADJ RFS Review WI.
       [Procedures/conditions for removal of claims from the ACP process](https://esdc.prv/en/service-canada/ei/technologies/acp/index.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1681.dita) 

**Client is working part-time**

Fact-finding can reveal that the client continues to work on a part-time basis. In this case, the officer creates an ADJ Availability WI before updating the RFS in RCM and completing the ADJ Issue RFS Review WI in NWS. This step prevents the claim from automating before the adjudication of the client’s availability is complete.

**Canadian Forces — Queen’s Regulations and Orders**

Members of the Canadian Forces are released under Queen’s Regulations and Orders 15.01. When a member of the Canadian Forces is released, the person issuing the ROE must indicate on the ROE the appropriate item in the Queen’s Regulations and Orders to show the reason for release. In most cases, the item in the Queen’s Regulations and Orders clarifies the RFS. When the RFS is unclear or differs from the client’s statement, the officer must fact-find with the contact named on the ROE.
       [Queen’s Regulations and Orders](https://www.canada.ca/en/department-national-defence/corporate/policies-standards/queens-regulations-orders/vol-1-administration/ch-15-release.html)

The following items in the Queen’s Regulations and Orders indicate a contentious RFS and may lead to disqualification:

- Misconduct — Sentenced to dismissal

- Misconduct — Service misconduct

- Misconduct — Illegally absent

- Unsatisfactory service — Unsatisfactory conduct

- Unsatisfactory service — Unsatisfactory performance

- Voluntary — On request - When entitled to an immediate annuity

- Voluntary — On request - Other causes

- Service completed — Unsuitable for further service 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/adj_rfs_review_k_other/determining_if_the_file_must_be_referre_f4ff817e.dita`

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1681.dita`

Note:

If the client was issued an ROE for a vacation period paid under an agreement (collective agreement or other) between the employer and employee (or the union representing the employees), there may not be an I of E. For more information, the officer refers to the BE Memo 2026-01 .
       [BE Memo 2026-01](/en/policy/bememo/be2026-01.shtml)

     [BE Memo 2026-01](/en/policy/bememo/be2026-01.shtml) 

## Regional considerations

Source topic: `en_EN/task/adj_rfs_review_k_other/regional_considerations.dita`

**Quebec region**

The Business Expertise Advisor, not the team leader, deletes the ADJ WI when required by the procedure. The officer uses the National Business Expertise Tool (NEXO) to request the deletion of the ADJ WI. 

## What you need to look for

Source topic: `en_EN/task/adj_rfs_review_k_other/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/adj_rfs_review_k_other/in_nws.dita`

- Are there are any SROCs, WIs or other documentation containing details related to the RFS?

- What is the Claim action status? 

### In Imaging:

Source topic: `en_EN/task/adj_rfs_review_k_other/in_imaging.dita`

- Are there any documents related to the RFS? 

### In RCM:

Source topic: `en_EN/task/adj_rfs_review_k_other/in_rcm.dita`

- What is the RFS sub-option on the ROE?

- Is there a Queen’s Regulations and Orders item on the ROE? 

## Step by step

Source topic: `en_EN/task/adj_rfs_review_k_other/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/adj_rfs_review_k_other/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/adj_rfs_review_k_other/reviewing_the_file_level_1.dita`

- Determine if there is information on file that allows to determine the RFS:

- If no, go to step 2.

- If yes, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/adj_rfs_review_k_other/fact-finding_level_1.dita`

- To determine the RFS, fact-find with the employer and, if necessary, the client.

- Determine if the employer or client was contacted during fact-finding:

- If yes, go to step 4.

- If no, go to Unable to determine if adjudication is required .
               [Unable to determine if adjudication is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_rfs_review_k_other#NotContacted)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Clarification — [employer’s name] — [last day worked] — [employer or client].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if adjudication is required

Source topic: `en_EN/task/adj_rfs_review_k_other/determining_if_adjudication_is_required_level_1.dita`

- Determine if there is an I of E for any employment in the QP:

- If yes, go to step 6.

- If no, go to Adjudication not required — No interruption of earnings (I of E) .
               [Adjudication not required — No interruption of earnings (I of E)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_rfs_review_k_other#NoIOE)

- Determine if the RFS is contentious:

- If yes, go to step 7.

- If no, go to Adjudication not required — Non-contentious reason for separation (RFS) .
               [Adjudication not required — Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_rfs_review_k_other#NotContentious) 

#### Adjudication required — Contentious reason for separation (RFS)

Source topic: `en_EN/task/adj_rfs_review_k_other/adjudication_required__contentious_reas_3e96d163_level_1.dita`

- In NWS, on the Specific Details tab, update the ADJ RFS Review WI as follows:

- Issue: Select the appropriate RFS.

- Select Save .

- Determine if the conditions to adjudicate the RFS issue at Level 1 according to the National Policy on Levels of Decision are met by referring to the appropriate activity ( Dismissal , Labour dispute , Leave of absence , Voluntary leaving ):

- If no, go to step 9.

- If yes, follow the steps from the appropriate activity.

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 10.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Not within Level 1 authority.” 

#### Unable to determine if adjudication is required

Source topic: `en_EN/task/adj_rfs_review_k_other/unable_to_determine_if_adjudication_is_required_level_1.dita`

- In NWS, on the Specific Details tab, update the ADJ RFS Review WI as follows:

- Issue: Select Quit .

- Select Save .

- Reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Unable to reach employer or client in order to clarify RFS.”

- Select OK .

- When the Warning window is displayed, select OK . 

#### Adjudication not required — No interruption of earnings (I of E)

Source topic: `en_EN/task/adj_rfs_review_k_other/adjudication_not_required__no_interrupt_4cdc091c_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “No interruption of earnings.”

- Details: Type “An interruption of earnings has not occurred.”

- Determine the Claim action status:

- If it is Initial — In Progress (Automation) , go to step 8.

- If it is Initial — In Progress (Manual) , go to step 11.

- Create a Reminder (REM) WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “ACP”.

- Due date: Enter today’s date.

- Language: Select the appropriate option.

- Details: Type “5” and “Processing — [unassigned or user name to whom the CA or SA WI is to be assigned].”

- Destination — Level: Select Canada .

- End User: Select Specific user and type “SV-ADMIN, ACP-TAD” and select Find User .

- Select Save .

- Move the ADJ RFS Review WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting removal of claim from automation process. No I of E. This WI must be deleted once a CA or SA WI is created.”

- Bring forward date: Enter today’s date + 2 business days.

- Select OK .

- When the ADJ RFS Review WI moves to the current workload, confirm that the Claim action status is Initial — In Progress (Manual) and a CA or SA WI was created.

- Contact an authorized user (team leader or Business Expertise Advisor) to delete the ADJ RFS Review WI. 

#### Adjudication not required — Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/adj_rfs_review_k_other/adjudication_not_required__non-contenti_e8b0f7ad_level_1.dita`

- Determine if the ROE was issued due to a period of leave that is being paid under an agreement (e.g. construction workers in Quebec):

- If yes, go to step 8.

- If no, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1682.dita)

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Not within Level 1 authority.”

- Determine if the ROE was issued because the client continues to work part-time.

- If yes, go to step 10.

- If no, go to step 12.

- Determine if the client is requesting regular benefits:

- If yes, go to step 11.

- If no, go to step 12.

- In NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Destination — SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Myself .

- Issue(s): Select Availability .

- Details: Type “Client continues to work part-time and is requesting regular benefits.”

- Go to step 12.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1683.dita)

- In RCM, update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select the appropriate RFS option and sub-option, if necessary.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1684.dita)

- Determine if the ROE was flagged in error after validation:

- If yes, fix the validation error, and go to step 12. For procedures on correcting an ROE, refer to Completing an ROE Correction WI — Regular ROE .
               [Completing an ROE Correction WI — Regular ROE](/en/procedure/task/completing_roe_correction_regular.shtml)

- If no, go to step 14.

- In NWS, complete the ADJ RFS Review WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1682.dita`

Note:

If the client was issued an ROE for a vacation period paid under an agreement (collective agreement or other) between the employer and employee (or the union representing the employees), a Level 2 officer must review the not unemployment issue. For more information, refer to BE Memo 2026-01 .
       [BE Memo 2026-01](//en/policy/bememo/be2026-01.shtml)

     [BE Memo 2026-01](//en/policy/bememo/be2026-01.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_1683.dita`

Note:

Refer to Adjudicating availability — Client is working part-time to complete the ADJ Availability WI.
       [Adjudicating availability — Client is working part-time](/en/procedure/task/availability_pt.shtml)

     [Adjudicating availability — Client is working part-time](/en/procedure/task/availability_pt.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_1684.dita`

Note:

If there is no appropriate RFS option (e.g. the client continues to work part-time for the employer), select A - Shortage of work . 

## Policy reference

Source topic: `en_EN/task/adj_rfs_review_k_other/policy_reference.dita`

- Queen’s Regulations and Orders 15.01
         [Queen’s Regulations and Orders 15.01](http://www.forces.gc.ca/en/about-policies-standards-queens-regulations-orders-vol-01/ch-15.page) 
