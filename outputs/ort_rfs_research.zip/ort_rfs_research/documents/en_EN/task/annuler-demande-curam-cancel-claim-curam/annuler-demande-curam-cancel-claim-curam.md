# Cancelling a claim — Cúram

Source map: `en_EN/task/annuler-demande-curam-cancel-claim-curam/annuler-demande-curam-cancel-claim-curam.ditamap`

## Summary

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/summary.dita`

Summary : During the assessment of a claim or while actioning a client request, the officer may need to determine if it is appropriate to cancel a claim. 

## What you need to know

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/untitled_section.dita`

In Cúram, the benefit period (BP) is referred to as a Product Delivery Case (PDC). The PDC is the period in which clients can claim the weeks of benefits they are entitled to. The PDC contains all the evidence that the officer needs to determine if the client is eligible and entitled for that claim.

When a client requests the cancellation of a claim or when a renewal claim may not be as beneficial to the client as a new claim, the officer determines if the existing claim can be cancelled. In Cúram, cancelling the claim is referred to as overriding the BP.

A cancelled claim is considered to have never existed. The self-employment (SE) earnings can be used to establish a new claim, as long as the SE earnings fall within the new qualifying period (QP). 

### Reviewing a benefit period when the client requests the cancellation of an established claim

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/reviewing_a_benefit_period_when_the_cli_863f679f.dita`

When a client contacts the call center to request the cancellation of an established claim, an AI WI is created in NWS. In these cases, the officer contacts the client to obtain all required information and documentation to determine if the client qualifies for a new claim and meets the conditions for cancellation of the existing claim. 

### Reviewing a benefit period when a client submits an application and there is an established claim

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/reviewing_a_benefit_period_when_a_clien_0ad4a7c1.dita`

In Cúram, a Call-Back task is created when a client submits an application for benefits but has an established claim with entitlement weeks remaining. The client is asked on the application if they would like to renew their existing claim. If yes, the Renewal – Requested by client – Call Back Required task is created. If no, the Renewal – Not requested by client – Call Back Required task is created.
       [Renewal – Requested by client – Call Back Required](/en/procedure/task/ren-dem-client-rr-curam-ren-request-client-cbr-curam.shtml) 
       [Renewal – Not requested by client – Call Back Required](/en/procedure/task/renouve-non-client_renewal-not-client.shtml)

If the client requests to renew their existing claim, the officer contacts the client to complete the renewal checklist Renewal: Special benefits for Self-employed People (Part VII.1 Claims) and obtains all required information and documentation. To renew the claim, the officer submits the Renewal evidence transaction in Cúram.
       [Renewal: Special benefits for Self-employed People (Part VII.1 Claims)](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Renewal-Special_benefits_for_Self-Employed_People_(Part%20VII.1%20Claims)-Checklist.doc)

If the client requests to start a new claim, the officer determines if the existing claim can be cancelled or terminated and whether the client qualifies for a new claim. If the client does not qualify for a new claim or it is disadvantageous to start a new claim, the officer contacts the client to complete the renewal checklist Renewal: Special benefits for Self-employed People (Part VII.1 Claims) , obtains all required information and documentation and renews the claim.  If the client qualifies for a new claim and it is advantageous to start a new claim (e.g. the client qualifies for a higher benefit rate), the officer submits the Override Benefit Period transaction. Once the existing claim is cancelled or terminated, the officer advises the client to complete a new paper application.
       [Renewal: Special benefits for Self-employed People (Part VII.1 Claims)](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Renewal-Special_benefits_for_Self-Employed_People_(Part%20VII.1%20Claims)-Checklist.doc) 

### Conditions to cancel a claim

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/conditions_to_cancel_a_claim.dita`

To establish a new claim, there must be an interruption of earnings (I of E). A claim can be cancelled when a new claim can be established and one of the following conditions is met:

- The claim has ended and no benefits were paid or payable during the claim.

- No benefits were paid or payable during the claim, whether the claim has ended or not, and the client is requesting a claim cancellation.

To cancel the existing claim, the officer to determines if the client qualifies to establish a new claim. If the client cannot be reached during fact-finding, the existing claim cannot be cancelled and is renewed instead. 

### Refusing to cancel a claim when there is no new claim

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/refusing_to_cancel_a_claim_when_there_i_82918080.dita`

If the client requests cancellation but cannot or does not want to establish a new claim, the officer does not cancel the claim.

Unless there is an indication that the client cannot establish a new claim, terminating the claim is considered when the conditions to cancel a claim are not met. The officer refers to Terminating a claim - Cúram .
       [Terminating a claim - Cúram](/en/procedure/task/terminer_demande_curam-terminate_claim_curam.shtml) 

### Advantages and disadvantages of cancelling a claim

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/advantages_and_disadvantages_of_cancell_6ee72367.dita`

The cancellation of a claim can be advantageous to a client because the cancelled claim is considered to have never existed. When a claim is cancelled, the SE earnings used to calculate the cancelled claim that fall within the new QP are used to establish the new claim.

Claim cancellation can also cause certain disadvantages. By cancelling the existing claim and establishing a new claim, the QP may contain fewer SE earnings. As a result, the client could receive a lower benefit rate compared to a renewal of the claim followed by the establishment of a new claim. The client could also lose access to weeks of benefits that were potentially payable on the cancelled claim. The officer assesses these possibilities. 

### Inputting the claim cancellation

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/inputting_the_claim_cancellation.dita`

The claim is cancelled by submitting the Override Benefit Period evidence in Cúram. 

### Violations

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/violations.dita`

The Violation History (ML02) screen in FTS displays a list of a client’s violations. By selecting a BPC displayed on the ML02 screen, the officer can view the violation details, including any BPC that was established with increased entrance requirements . To view a client’s violations in Cúram, the officer checks the Application Case on the Evidence tab. If the violation is in blue, the officer clicks on it to see the client’s violations. A BPC established with increased entrance requirements is a claim that was affected by a violation and appears in FTS as First BPC affected or Second BPC affected. When such a BPC is cancelled, the officer sends an MM06 to IPOC to request that the cancelled claim be removed from the list of BPCs that were affected by the violation.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

## Regional considerations

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/in_nws.dita`

- Is the client requesting cancellation or termination of a claim?

- Is there documentation of verbal notice regarding the end of the disentitlement (e.g. an SROC or ROD)? 

### In Cúram:

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/in_curam.dita`

- Is there an established claim?

- If yes, have benefits been paid or are benefits payable?

- Is the claim BPNE?

- Is there a disentitlement on the claim from BPC?

- If yes, has it recently ended, and have benefits been paid since?

- Has a renewal week been input?

- What are the special benefit windows?

- What is the benefit rate?

- What is the LRW in the claim?

- What is the remaining entitlement for the claim?

- Are there any ongoing allocations?

- Are there any disentitlements on the claim?

- Has the WP been served, waived or deferred? 

### In FTS:

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/in_fts.dita`

- Has a suspension been imposed to prevent payment?

- Are any fraud indicators present?

- Is there a renewal – call back required task?

- What is the client’s violation history? 

## Step by step

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/reviewing_the_file_level_1.dita`

- Determine if one of the following conditions is met:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2030.dita) 

- If one of the conditions is met, go to step 2.

- If none of the conditions is met, refer to Terminating a claim - Cúram .
               [Terminating a claim - Cúram](/en/procedure/task/terminer_demande_curam-terminate_claim_curam.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2031.dita)

- Fact-find with the client:

- Ask if the client intends to apply for a new claim.

- If no, advise the client that the existing claim cannot be cancelled and will be renewed (refer to Renewal requested by client – Call back required – Task in Cúram to complete the renewal ). Go to step 10.
                   [Renewal requested by client – Call back required – Task in Cúram to complete the renewal](/en/procedure/task/ren-dem-client-rr-curam-ren-request-client-cbr-curam.shtml)

- Obtain either the estimated or actual SE earnings in the QP and refer to Earnings: Minimum and maximum self-employed earnings and maximum benefit rate — Table and Self-employed: Information on calculation and entitlement to special benefits — Knowledge to determine if the client would qualify for a new claim.

- If the client meets the minimum SE earnings requirement, keep the client on the telephone and go to step 3.

- If the client is unable to provide the requested information at this time, keep the client on the telephone and go to step 3.

- If the client does not meet the minimum SE earnings requirement, go to step 10.
                   [#level1_item_3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/annuler-demande-curam-cancel-claim-curam#level1_item_3)

               [Earnings: Minimum and maximum self-employed earnings and maximum benefit rate — Table](/en/procedure/generic/additionalresources/min_max_se_ti.shtml) 
               [Self-employed: Information on calculation and entitlement to special benefits — Knowledge](/en/procedure/generic/benefits_se_knowledge.shtml)

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Claim not cancelled .
               [Claim not cancelled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/annuler-demande-curam-cancel-claim-curam#level1_item_3)

- Determine if the client has reduced the time normally devoted to SE activities by more than 40% (I of E):

- If yes, keep the client on the telephone and go to step 4.

- If the client is unable to confirm an I of E at this time, keep the client on the telephone and go to step 4.

- If no, go to step 10.

- Determine if the client had a valid agreement that has been in place for at least 12 months at the time of the BPC and that the agreement is not terminated or deemed to be terminated (confirm with client and review the Evidence Dashboard in the Application Case ):

- If yes, keep the client on the telephone and go to step 5.

- If no, go to step 10.
               [#level1_item_3](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/annuler-demande-curam-cancel-claim-curam#level1_item_3)

- Determine if the client would qualify for a new claim based on the SE earnings in the QP, the I of E and the agreement information provided:

- If the client is unable to provide some or all of the requested information at this time, do the following:

- Advise the client this information is required to determine if the existing claim can be cancelled and a new claim can be established.

- Provide the officer’s contact information and the date the client must provide the requested information by (today’s date + 10 business days).

- Go to step 6.

- If yes, do the following:

- Refer the client to visit an SCC to complete a paper application for self-employed persons (fastest option). If the client is unable to visit in person, advise the client to complete and return the paper application that will be mailed to the address on file.

- Advise the client:

- The decision to cancel a claim is final and cannot be reversed.

- A new WP must be served on the new claim unless it is waived or deferred.

- The decision to cancel the claim cannot be appealed once it has been input.

- No letter will be sent to advise the client of the cancellation.

- Go to step 6.

- If no, advise the client that the existing claim cannot be cancelled and will be renewed (refer to Renewal requested by client – Call back required – Task in Cúram to complete the renewal ). Go to step 10.
               [Renewal requested by client – Call back required – Task in Cúram to complete the renewal](/en/procedure/task/ren-dem-client-rr-curam-ren-request-client-cbr-curam.shtml)

           [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2032.dita) 
           [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2033.dita)

- In NWS, add details to the draft external SROC created during fact-finding or create a new external SROC as follows:

- BPC: Type the BPC.

- Main Issue: Select Other .

- Comments: Type “Claim cancellation.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client provided the requested information:

- If no, go to step 8.

- If yes, go to step 11.

- In Cúram, defer the task as follows:

- From the Task Homepage , select … at the top right-hand corner of the screen.

- From the drop-down menu, select Defer .

- Restart date: Enter today’s date + 10 business days.

- Comments: Type “Waiting for the client to provide information required to determine if a new claim can be established.”

- Select Save .

- When the task moves to the current workload, determine if the client obtained the requested information:

- If yes, return to step 5.

- If no, go to step 10.

- In NWS, add details to the draft external SROC created during fact-finding or create a new external SROC as follows:

- BPC: Type the BPC.

- Main Issue: Select Other .

- Comments: Type “Claim cancellation.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Go to Claim not cancelled .
               [Claim not cancelled](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/annuler-demande-curam-cancel-claim-curam#level1_item_3)

- Determine if the client will visit an SCC to complete the paper application:

- If no, go to step 12.

- If yes, go to step 15.

- Locally print the INS5236: Application for Employment Insurance Benefits for Self-Employed Persons .

- In ACS , create and send the Q-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Info Requested Re: ROE / RFS / Conflicting statements / Undeliverable Mail / More Info required (2876) .

- Select: Request for Additional Information Re: Entitlement .

- Text – Specify instructions to claimant (1548) .

- Type “Complete and return the INS5236 form.”

- Message re BF Date-if not received may delay claim (2897) .

- Date of BF (Date letter sent + 10 business days) (1540).

- Attachment List for Q-01/00/00 (3120).

- Text - Specify the attachment(s) (1546): Type “Application for Employment Insurance Benefits for Self-Employed Persons INS5236.”

- Select Local printing .

- Attach the paper application to the printed Q-01-00-00 letter and send them to the client.

- In Cúram, create a record of decision (ROD) as follows:

- From the client’s home screen, select Cases and Applications from the navigation bar.

- Select the appropriate reference number and select Contacts from the navigation bar.

- Select Notes from the menu on the left-hand side and select New Note from the right-hand side.

- From the New Note window, complete the following fields:

- Subject: Type “Cancellation of claim BPC [BPC].”

- Priority: Select Medium .

- Sensitivity: Select 1 .

- Text: Type “Claim with BPC [BPC] cancelled. Client qualifies to establish a new claim.”

- Select Save .

- In Cúram, cancel the claim as follows:

- Search for the client with their Social Insurance Number (SIN) in the search bar at the top of the screen.

- Select the client’s name to display the Person Evidence Case.

- Select the Reference Number for the Case Name: Employment Insurance Program Benefits to open the Product Delivery Case.

- Select the Evidence tab of the Product Delivery Case from the navigation bar.

- Select Override Benefit Period.

- When the New Override Benefit Period window opens, select Cancel .

- Select Save .

- Select the ellipses (…) in the top right corner of the Evidence tab.

- From the drop-down menu, select Apply Changes .

- In FTS, determine if the Violation History (ML02) screen displays the cancelled claim as a BPC that was affected by a violation:

- If no, go to step 18.

- If yes, go to Amending the violation history .
               [Amending the violation history](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/annuler-demande-curam-cancel-claim-curam#level1_item_2)

- In Cúram, complete the task or return to your previous task. 

#### Amending the violation history

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/amending_the_violation_history_level_1.dita`

- In FTS, determine if a revised registration number exists:

- If yes, go to step 2.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction to automatically generate an Operational Centre Memo (MM06) transaction and complete the following fields:

- Registration number: Select the appropriate registration number.

- Select Memo (MPS) .

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim to be cancelled.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 35 - Claim Cancellation .

- Remarks line 1: Type “Cancelled BPC [cancelled BPC] affects violation history. Update ML02 for BPC [BPC with the violation that affected the cancelled claim] and remove BPC [cancelled BPC] as a BPC affected by a violation . Advise adjudicator with REM WI when complete.”

- Remarks line 5: Enter your first name and last name.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Other .

- Message: Select 27 - An overpayment resulted due to an incorrect calculation .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In FTS, select the Registration Number (M025, M030, M035) transaction and change the registration flag as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In Cúram, defer the task as follows:

- From the Task Homepage , select … at the top right-hand corner of the screen.

- From the drop-down menu, select Defer .

- Restart date : Enter today’s date + 10 business days.

- Comments: Type “Waiting for IPOC to update the Violation history screen due do the cancellation of an affected claim.”

- Select Save .

- When the task related to the cancellation request moves to the current workload, determine if IPOC has created a REM WI in NWS:

- If no, return to step 5.

- If yes, go to step 7.

- In Cúram, complete the task or return to your previous task. 

#### Claim not cancelled

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/claim_not_cancelled_level_1.dita`

- In Cúram, create a record of decision (ROD) as follows:

- From the client’s home screen, select Cases and Applications from the navigation bar.

- Select the appropriate reference number and select Contacts from the navigation bar.

- Select Notes from the menu on the left-hand side and select New Note from the right-hand side.

- From the New Note window, complete the following fields:

- Subject: Type “Cancellation of the BPC [BPC].”

- Priority: Select Medium .

- Sensitivity: Select 1 .

- Text: Type “BPC [BPC] cannot be cancelled.” Include the reason the claim was not cancelled (e.g. the client does not qualify on a new claim, unable to contact to obtain a paper application etc.).

- Select Save .

- Determine if the client was verbally advised that the claim is not being cancelled:

- If no, go to step 3.

- If yes, go to step 4.

- In ACS, create and send an F-00-00-00 letter advising the client of the decision:

- In the Free Text (1612) field, type the appropriate option:

- If the client does not qualify to establish a new claim, type “We are writing to inform you that we cannot cancel your claim for Employment Insurance benefits that began on [BPC of existing claim] as you are unable to establish a new one.”

- If the client was not reached, type “We are writing to inform you that we cannot cancel your claim for Employment Insurance benefits that began on [BPC of existing claim] as we were unable to reach you to obtain required information.”

- Refer to Renewal requested by client – Call back required – Task in Cúram to complete the claim renewal.Cúram. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2030.dita`

Condition 1 for cancellation

- The claim has ended, no benefits were paid or payable during the claim and the client is requesting benefits.

Condition 2 for cancellation

- No benefits were paid or payable during the claim, whether ended or not, the client is requesting a claim cancellation, and the client is requesting benefits. 

#### Note

Source topic: `en_EN/common_notes/note_c_2031.dita`

Note:

A claim being considered for cancellation may be the first or second claim affected by a violation. If so, cancelling the claim will cause the client to be subject to increased entrance requirements unless the new claim is more than 260 weeks after the violation notice was issued. 

#### Info

Source topic: `en_EN/common_notes/note_c_2032.dita`

Note: If the client intends to visit an SCC, the officer advises the client that an appointment may be required. 

#### Info

Source topic: `en_EN/common_notes/note_c_2033.dita`

Note: When a claim being considered for cancellation has a BPC that was affected by a violation, the client is subject to increased entrance requirements for a new claim unless relief is obtained. 

## Policy reference

Source topic: `en_EN/task/annuler-demande-curam-cancel-claim-curam/policy_reference.dita`

 
