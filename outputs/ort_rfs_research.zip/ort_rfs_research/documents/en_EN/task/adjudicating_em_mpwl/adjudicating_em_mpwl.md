# Adjudicating employer misrepresentation — Monetary penalty or warning letter

Source map: `en_EN/task/adjudicating_em_mpwl/adjudicating_em_mpwl.ditamap`

## Summary

Source topic: `en_EN/task/adjudicating_em_mpwl/summary.dita`

Summary: An administrative penalty (monetary or warning letter) must be imposed if an employer makes a misrepresentation for which neither the voluntary disclosure policy nor prosecution is applicable. 

## What you need to know

Source topic: `en_EN/task/adjudicating_em_mpwl/what_you_need_to_know.dita`

### Employer misrepresentation — Determining the penalty

Source topic: `en_EN/task/adjudicating_em_mpwl/employer_misrepresentation__determining_1422a8d5.dita`

The first step in a case of misrepresentation is determining if a penalty must be imposed.

**Adjudicating an employer misrepresentation**

For the purpose of adjudicating misrepresentation, the definition of an employer is an individual employer, a corporation or an individual director, officer or agent of a corporation. It is possible to impose more than one sanction for the same investigation. For example, a penalty of $4 000 can be imposed on the corporation, on an officer of the corporation and on an employee acting on behalf of the corporation.

The following are examples of employer misrepresentation that can result in a penalty or warning letter:

- issuing a false ROE;

- issuing an ROE containing false information;

- making a written or verbal representation that the employer knows is false or misleading;

- failing to disclose facts that the employer knows are false or misleading;

- participating in or consenting to any of the above.

When the misrepresentation is made by a person acting on behalf of the employer and the employer was not aware of the person’s actions and it is the employer’s first offence, a penalty is only imposed on the person acting on behalf of the employer. In this situation, the agent refers to Adjudicating employer misrepresentation — Caution letter .
       [Adjudicating employer misrepresentation — Caution letter](/en/procedure/task/adjudicating_em_cl.shtml) 

### Imposing a monetary penalty

Source topic: `en_EN/task/adjudicating_em_mpwl/imposing_a_monetary_penalty.dita`

A monetary penalty is an administrative fine imposed on employers under EIA 39 if they have made a misrepresentation. Repetitive misrepresentation is subject to more severe consequences, including higher penalties. The purpose of a penalty is to discourage further abuse of the EI program.

A monetary penalty can be imposed up to 36 months after the misrepresentation. Processing and postal delays must be taken into consideration when determining whether the misrepresentation falls with the 36-month limitation period. 

### Level of misrepresentation

Source topic: `en_EN/task/adjudicating_em_mpwl/level_of_misrepresentation.dita`

The level of misrepresentation sets a maximum penalty amount that can be imposed. The level of misrepresentation is determined by the highest level of penalty imposed before the reconsidered period and not by the number of decision notices sent to the employer.

The notification date of a previous penalty, warning letter, or prosecution judgment is used to determine the level of the current misrepresentation. The notification date is deemed to be the Saturday of the week following the date on the penalty notice, warning letter, or the prosecution judgment date.

If the employer was not notified of a sanction within the last 260 weeks, the current investigation is assessed as a first level misrepresentation.

If the current misrepresentation occurred after the employer was notified of a sanction for a first level misrepresentation within the last 260 weeks, it is considered a second level misrepresentation.

Similarly, if the current misrepresentation occurred after the employer was notified of a sanction for a second level misrepresentation within the last 260 weeks, it is considered a third level misrepresentation.

There may be cases where the employer is in the process of appealing an earlier decision. If, in the meantime, a second investigation is launched for misrepresentation covering a period after the notification date of the decisions being appealed, this misrepresentation is nevertheless deemed repetitive. This does not change until all the steps of the appeal process have been completed and the decision being appealed is no longer considered as misrepresentation. When the final appeal decision is implemented, all subsequent decisions must be amended accordingly. 

### Mitigating circumstances

Source topic: `en_EN/task/adjudicating_em_mpwl/mitigating_circumstances.dita`

The Level 2 agent must review all documents, facts and information on file to determine whether there are mitigating circumstances that could reduce the sanction for the misrepresentation. The existence of mitigating circumstances must never be assumed. There must be a clear indication that such circumstances exist. Mitigating circumstances usually relate to the time when the misrepresentation occurred, but there are some that may exist up to and including the time the case is being reviewed by an adjudicator or even after the decision has been reached.

A percentage value is assigned to the mitigating circumstances. When calculating the penalty amount, the maximum penalty amount based on the level of misrepresentation is reduced by the percentage value of the mitigating circumstances. 

### Calculating the penalty amount — EIA 39(2)

Source topic: `en_EN/task/adjudicating_em_mpwl/calculating_the_penalty_amount__eia_392.dita`

An employer is penalized under EIA 39(2) when the misrepresentation impacts a client’s benefit rate or weeks of entitlement on an EI claim. For example, the employer records more insurable earnings on the ROE than the client actually earned and, as a result, the client receives a higher benefit rate.
       [EIA 39(2)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-39.html)

Penalties imposed under EIA 39(2) are based on the maximum weekly benefit rate in effect at the time the penalty is imposed and must take into account mitigating circumstances.

```text
| Level of misrepresentation | Penalty amount (for each misrepresentation) |

| First | (3 X maximum benefit rate) – % assigned to mitigating circumstances |

| Second | (6 X maximum benefit rate) – % assigned to mitigating circumstances |

| Third or more | (9 X maximum benefit rate) – % assigned to mitigating circumstances |
``` 

### Calculating the penalty amount — EIA 39(4)

Source topic: `en_EN/task/adjudicating_em_mpwl/calculating_the_penalty_amount__eia_394.dita`

An employer is penalized under EIA 39(4) when the misrepresentation enables a client to become entitled to benefits. For example, the employer records more insurable hours on the ROE than the client actually worked and, as a result, the client is able to establish a claim. If the employer recorded the actual hours worked on the ROE, the client would not be able to establish a claim. Another example would be if the employer records a false reason for separation on the ROE and, as a result, the client is able to receive benefits without a disqualification. This section also applies if an employer issues or sells ROEs when the client never worked for that employer.
       [EIA 39(4)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-39.html)

Penalties imposed under EIA 39(4) are based on the greater of 2 calculations:

The first calculation is based on the level of misrepresentation and takes into account mitigating circumstances.

```text
| Level of misrepresentation | Penalty amount (for each misrepresentation) |

| First | $ 4 000 – % assigned to mitigating circumstances |

| Second | $ 8 000 – % assigned to mitigating circumstances |

| Third or more | $12 000 – % assigned to mitigating circumstances |
```

The second calculation is to determine the total value of all penalties imposed against any person who made a claim for benefits based on the misrepresentation.

An employer penalty imposed under EIA 39(4) is never less than the total of all related client penalties. 

### Issuing a warning letter

Source topic: `en_EN/task/adjudicating_em_mpwl/issuing_a_warning_letter.dita`

According to EIA 41.1 , a warning letter can be issued instead of imposing a monetary penalty. Warning letters are considered a penalty within the meaning of the EI legislation, but do not carry the greater consequence of a monetary sanction.
       [EIA 41.1](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-41.1.html)

For employer misrepresentations that occurred within the last 36 months, a warning letter can be imposed only when the misrepresentation is adjudicated under EIA 39(2). According to EIA 41.1, a warning letter is not allowed when the misrepresentation is adjudicated under EIA 39(4). However, if the misrepresentation occurred more than 36 months ago, only a warning letter can be imposed under EIA 39(2) or 39(4).

Warning letters can be issued up to 72 months after the misrepresentation. Processing and postal delays must be taken into consideration when determining whether the misrepresentation falls within the 72-month limitation period.

A warning letter is issued when:

- Mitigating circumstances make a monetary penalty punitive under EIA 39(2).

- The misrepresentation occurred more than 36 months ago and the time limit to impose a penalty has passed. 

### Discretionary decision

Source topic: `en_EN/task/adjudicating_em_mpwl/discretionary_decision.dita`

A determination of misrepresentation and the resulting sanction is a discretionary decision. This means the agent must consider any information provided and show how it concludes that the misleading statement was made knowingly. The agent must be able to explain why facts are relevant or irrelevant. In the case of a monetary penalty, written rationale must clearly show how the penalty amount was calculated. 

### Documentation and transactions

Source topic: `en_EN/task/adjudicating_em_mpwl/documentation_and_transactions.dita`

Employer misrepresentation cases are sent for adjudication under the employer’s SIN or business number. When the case is recorded under the employer’s SIN, the agent documents the decision and rationale on an external SROC in NWS. When the case is recorded under the employer’s business number only, the agent documents the decision and rationale in the investigation file which is maintained according to regional procedures. 

### DARS and PSCD

Source topic: `en_EN/task/adjudicating_em_mpwl/dars_and_pscd.dita`

The agent must review DARS and PSCD as not all accounts are converted to PSCD. 

## Regional considerations

Source topic: `en_EN/task/adjudicating_em_mpwl/regional_considerations.dita`

**Atlantic region — Paper-based employer investigation file**

If the agent receives the paper file for adjudication, the agent adds to the file the ROD, a copy of the ACS letter and a copy of the completed Report of Investigation from NIIS. When the decision has been implemented, the agent returns the file to Integrity Services Branch for storage. The business expertise consultant updates the regional penalty log.

If the agent does not receive the paper file for adjudication, the agent emails the ROD, a copy of the ACS letter and a copy of the completed Report of Investigation from NIIS to atl-integrity_general_delivery-poste_restante_integrite-atl@hrdc-drhc.net . The business expertise consultant updates the investigation file and the regional penalty log.
       [atl-integrity_general_delivery-poste_restante_integrite-atl@hrdc-drhc.net](mailto:atl-integrity_general_delivery-poste_restante_integrite-atl@hrdc-drhc.net)

**Ontario region — Paper-based employer investigation file**

When the decision has been implemented, the agent emails a copy of the ROD to the Integrity Services Branch’s business expertise consultant responsible for employer investigations. The business expertise consultant updates the regional penalty log.

**Quebec region — Paper-based employer investigation file**

The agent receives a General Inquiry WI in NWS to adjudicate the case. The documents needed to adjudicate the case are saved in an employer penalty folder in the Common Document Share.

The agent saves the ROD and a copy of the ACS letter in the employer folder in the Common Document Share. When the decision has been implemented, the agent informs the Integrity officer and sends an email to esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca and qc-stp-pps-ae-ei-gestion-charge-de-travail-workload-management@hrsdc-rhdcc.gc.ca .
       [esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca](mailto:esdc.ien.agfq.ei.ag.bec.gd-gd.cteo.co.ae.corq.rei.edsc@servicecanada.gc.ca) 
       [qc-stp-pps-ae-ei-gestion-charge-de-travail-workload-management@hrsdc-rhdcc.gc.ca](mailto:qc-stp-pps-ae-ei-gestion-charge-de-travail-workload-management@hrsdc-rhdcc.gc.ca)

**Western Canada and Territories region — Paper-based employer investigation file**

The agent receives the paper file for adjudication and adds the ROD and a copy of the ACS letter to the file. When the decision has been implemented, the agent informs the Integrity officer by email and returns the file to the Integrity officer for storage. The business expertise consultant updates the regional penalty log when notified of the decision by the Integrity officer. 

## What you need to look for

Source topic: `en_EN/task/adjudicating_em_mpwl/what_you_need_to_look_for.dita`

### In PSCD:

Source topic: `en_EN/task/adjudicating_em_mpwl/in_pscd.dita`

- On the Debtor Overview screen, in the Debt Information - Account Balance section:

- Are there any penalties for the employer imposed in the last 260 weeks?

- If yes, what is the document date for the previous penalty?

- What are the initial amounts of all penalties imposed on all clients who made a claim for benefits based on the employer misrepresentation? 

### In NIIS:

Source topic: `en_EN/task/adjudicating_em_mpwl/in_niis.dita`

- On the Case Summary (IC08) screen, are there any prior cases for which a penalty was imposed?

- Is there an Integrity Investigation Sheet? If so, does it contain mitigating circumstances?

- Is there a Report of Interview? If so, does it contain a misrepresentation or mitigating circumstances?

- Was the misrepresentation made by a person acting on behalf of the employer but without the employer’s knowledge?

- If yes, is a caution letter being recommended for the employer? 

### In NWS:

Source topic: `en_EN/task/adjudicating_em_mpwl/in_nws.dita`

- Are there any SROCs for previous cases of misrepresentation? If yes, what was the result? 

### In ACS:

Source topic: `en_EN/task/adjudicating_em_mpwl/in_acs.dita`

- On what date was a previous notice of misrepresentation sent to the employer? 

### In the paper-based investigation file:

Source topic: `en_EN/task/adjudicating_em_mpwl/in_the_paper-based_investigation_file.dita`

- On what date was a previous notice of misrepresentation sent to the employer?

- Is there documentation showing mitigating circumstances?

- Are there any RODs for previous cases of misrepresentation? If yes, what was the result? 

## Step by step

Source topic: `en_EN/task/adjudicating_em_mpwl/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/adjudicating_em_mpwl/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/adjudicating_em_mpwl/reviewing_the_file_level_2.dita`

- Determine if you are within the 36-month time limit defined by EIA 40(b) to impose a monetary penalty for the misrepresentation:

- If within the 36-month time limit, go to step 2.

- If not within the 36-month time limit, go to Issuing a warning letter .
               [Issuing a warning letter](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_em_mpwl#wl)

- Determine the section of the EIA under which the penalty is being imposed:

- If the penalty is being imposed under EIA 39(2), go to Penalty or warning letter — EIA 39(2) .
               [Penalty or warning letter — EIA 39(2)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_em_mpwl#wleia)

- If the penalty is being imposed under EIA 39(4), go to Penalty — EIA 39(4) .
               [Penalty — EIA 39(4)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjudicating_em_mpwl#peneia) 

#### Issuing a warning letter

Source topic: `en_EN/task/adjudicating_em_mpwl/issuing_a_warning_letter_level_2.dita`

- Determine if the employer’s SIN is applicable:

- If no, go to step 4.

- If yes, go to step 7.

- In Microsoft Word, create a ROD for the investigation file and type the following information:

- “[employer’s name].”

- “[employer’s business number].”

- “[Integrity case number].”

- “Issue: Employer misrepresentation.”

- “Decision: Warning letter.”

- “Rationale: [refer to the Fact-Finding and Documentation Policy and include the following details:

- a summary of the false statements or omissions;

- the employer’s explanation;

- the rationale for determining that false statements were made knowingly;

- any mitigating circumstances considered;

- the level of misrepresentation;

- the rationale for imposing a warning instead of a monetary penalty.]”

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#7.1)

- Attach a copy of the ROD to the investigation file according to regional procedures.

- A violation is not applicable in this case because the employer is not considered an insured person. Go to Implementing employer misrepresentation for next steps.

- In NWS, create an external SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “[Integrity case number] — employer misrepresentation — warning letter.”

- Details: Refer to the Fact-Finding and Documentation Policy . Include the following details:

- a summary of the false statements or omissions;

- the employer’s explanation;

- the rationale for determining that false statements were made knowingly;

- any mitigating circumstances considered;

- the level of misrepresentation;

- the rationale for imposing a warning instead of a monetary penalty.

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#7.1)

- Before the misrepresentation decision is implemented, consider a notice of violation. Go to Adjudicating employer misrepresentation — Violation for next steps. 

#### Penalty or warning letter — EIA 39(2)

Source topic: `en_EN/task/adjudicating_em_mpwl/penalty_or_warning_letter__eia_392_level_2.dita`

- Determine the current level of misrepresentation.

- Determine the number of misrepresentations.

- Determine the current maximum weekly benefit rate.

- Identify any mitigating circumstances that warrant a reduction to the penalty amount and determine the percentage by which the penalty will be reduced.

- Determine the penalty amount based on the level of misrepresentation as follows:

```text
| Level of misrepresentation | Penalty calculation (for each misrepresentation) |

| First | (3 X maximum benefit rate) – % assigned to mitigating circumstances |

| Second | (6 X maximum benefit rate) – % assigned to mitigating circumstances |

| Third or more | (9 X maximum benefit rate) – % assigned to mitigating circumstances |
```

- Determine if the circumstances are so mitigating that any monetary penalty is punitive:

- If yes, go to step 9.

- If no, go to step 14.

- Determine if the employer’s SIN is applicable:

- If no, go to step 10.

- If yes, go to step 13.

- In Microsoft Word, create a ROD for the investigation file and type the following information:

- “[employer’s name].”

- “[employer’s business number].”

- “[Integrity case number].”

- “Issue: Employer misrepresentation.”

- “Decision: Warning letter.”

- “Rationale: [refer to the Fact-Finding and Documentation Policy and include the following details:

- a summary of the false statements or omissions;

- the employer’s explanation;

- the rationale for determining that false statements were made knowingly;

- any mitigating circumstances considered;

- the level of misrepresentation;

- the rationale for imposing a warning instead of a monetary penalty.]”

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#7.1)

- Attach a copy of the ROD to the investigation file according to regional procedures.

- A violation is not applicable in this case because the employer is not considered an insured person. Go to Implementing employer misrepresentation for next steps.

- In NWS, create an external SROC as follows:

- Main Issue: Select Integrity.

- Comments: Type “[Integrity case number] — employer misrepresentation — warning letter.”

- Details: Refer to the Fact-Finding and Documentation Policy . Include the following details:

- a summary of the false statements or omissions;

- the employer’s explanation;

- the rationale for determining that false statements were made knowingly;

- any mitigating circumstances considered;

- the level of misrepresentation;

- the rationale for imposing a warning instead of a monetary penalty.

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#7.1)

- Go to step 19.

- Determine if the employer’s SIN is applicable:

- If no, go to step 15.

- If yes, go to step 18.

- In Microsoft Word, create a ROD for the investigation file and type the following information:

- “[employer’s name].”

- “[employer’s business number].”

- “[Integrity case number].”

- “Issue: Employer misrepresentation.”

- “Decision: Penalty.”

- “Rationale: [refer to the National Fact-finding, Documentation and Retention Policy and include the following details:

- the misrepresentation was assessed under EIA 39(2);

- a summary of the false statements or omissions;

- the employer’s explanation;

- the rationale for determining that false statements were made knowingly;

- any mitigating circumstances considered;

- the level of misrepresentation;

- an explanation of the penalty calculation (refer to steps 3 to 7).]”

               [National Fact-finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#7.1)

- Attach a copy of the ROD to the investigation file according to regional procedures.

- A violation is not applicable in this case because the employer is not considered an insured person. Go to Implementing employer misrepresentation for next steps.

- In NWS, create an external SROC as follows:

- Main Issue: Select Integrity.

- Comments: Type “[Integrity case number] — employer misrepresentation — penalty.”

- Details: Refer to the Fact-Finding and Documentation Policy . Include the following details:

- the misrepresentation was assessed under EIA 39(2);

- a summary of the false statements or omissions;

- the employer’s explanation;

- the rationale for determining that false statements were made knowingly;

- any mitigating circumstances considered;

- the level of misrepresentation;

- an explanation of the penalty calculation (refer to steps 3 to 7).

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#7.1)

- Before the misrepresentation decision is implemented, consider a notice of violation. Go to Adjudicating employer misrepresentation — Violation for next steps. 

#### Penalty — EIA 39(4)

Source topic: `en_EN/task/adjudicating_em_mpwl/penalty__eia_394_level_2.dita`

- Determine the current level of misrepresentation.

- Identify any mitigating circumstances that warrant a reduction to the penalty amount and determine the percentage by which the penalty will be reduced.

- Determine the penalty amount based on the level of misrepresentation as follows:

```text
| Level of misrepresentation | Penalty calculation (for each misrepresentation) |

| First | $ 4 000 – % assigned to mitigating circumstances |

| Second | $ 8 000 – % assigned to mitigating circumstances |

| Third or more | $12 000 – % assigned to mitigating circumstances |
```

- Determine the total of all penalty amounts assessed against any person who made a claim for benefits based on the employer’s misrepresentation.

- Determine the penalty amount to impose. The penalty amount is the greater of:

- the calculated penalty amount (step 5); or

- the total of all penalty amounts imposed on the client (step 6).

- Determine if the employer’s SIN is applicable:

- If no, go to step 9.

- If yes, go to step 12.

- In Microsoft Word, create a ROD for the investigation file and type the following information:

- “[employer’s name].”

- “[employer’s business number].”

- “[Integrity case number].”

- “Issue: Employer misrepresentation.”

- “Decision: Penalty.”

- “Rationale: [refer to the Fact-Finding and Documentation Policy and include the following details:

- the misrepresentation was assessed under EIA 39(4);

- a summary of the false statements or omissions;

- the employer’s explanation;

- the rationale for determining that false statements were made knowingly;

- any mitigating circumstances considered;

- the level of misrepresentation;

- an explanation of the penalty calculation (refer to steps 3 to 7).]”

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#7.1)

- Attach a copy of the ROD to the investigation file according to regional procedures.

- A violation is not applicable in this case because the employer is not considered an insured person. Go to Implementing employer misrepresentation for next steps.

- In NWS, create an external SROC as follows:

- Main Issue: Select Integrity.

- Comments: Type “[Integrity case number] — employer misrepresentation — penalty.”

- Details: Refer to the Fact-Finding and Documentation Policy . Include the following details:

- the misrepresentation was assessed under EIA 39(4);

- a summary of the false statements or omissions;

- the employer’s explanation;

- the rationale for determining that false statements were made knowingly;

- any mitigating circumstances considered;

- the level of misrepresentation;

- an explanation of the penalty calculation (refer to steps 3 to 7).

               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#7.1)

- Before the misrepresentation decision is implemented, consider a notice of violation. Go to Adjudicating employer misrepresentation — Violation for next steps. 

## Policy reference

Source topic: `en_EN/task/adjudicating_em_mpwl/policy_reference.dita`

- Digest 18—Policy on penalties
         [Digest 18—Policy on penalties](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/table-of-contents.html)

- EIA 39
         [EIA 39](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-39.html)

- EIA 40
         [EIA 40](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-40.html)

- EIA 41.1
         [EIA 41.1](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-41.1.html)

- Integrity Operations Manual—Chapter 15
         [Integrity Operations Manual—Chapter 15](http://servicecanada.prv/eng/ei/reference-material/ic-manual/chapter15.shtml)

- National Fact-finding, Documentation and Retention Policy
         [National Fact-finding, Documentation and Retention Policy](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/national_policy_factfinding.shtml#7.1) 
