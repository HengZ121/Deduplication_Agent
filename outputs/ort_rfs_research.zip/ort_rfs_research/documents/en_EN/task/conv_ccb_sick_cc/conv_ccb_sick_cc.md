# Converting a claim from CCB to sickness benefits — Continuing claim

Source map: `en_EN/task/conv_ccb_sick_cc/conv_ccb_sick_cc.ditamap`

## Summary

Source topic: `en_EN/task/conv_ccb_sick_cc/summary.dita`

Summary: Clients receiving CCB who become unable to work because they are ill, injured or quarantined can interrupt their CCB and request a conversion to sickness benefits. 

## What you need to know

Source topic: `en_EN/task/conv_ccb_sick_cc/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/conv_ccb_sick_cc/untitled_section.dita`

As of October 12, 2014, clients in current receipt of CCB (including fishers) do not need to prove that they are otherwise available for work in order to convert to sickness benefits if they are ill or injured. They can resume collecting the balance of their CCB once sickness benefits have been paid. These provisions do not apply if the client has received all their CCB entitlement weeks, the client is deceased, the CCB window has ended or if there is information on file indicating the client will not resume collecting the balance of their CCB entitlement weeks after they have recovered from the illness or injury. In those cases, clients must prove they are otherwise available for work.

Clients requesting that their claim be converted to sickness benefits, and who are on approved compassionate care leave from their employer, are not required to exhaust their sick leave credits from their employer before receiving sickness benefits.

A conversion request may be received on an Action Item (AI) WI, a Claim Review (CR) WI, or a renewal application.

For a claim to be converted to sickness benefits, the entitlement conditions for sickness benefits must be met.

The officer reviews all documentation in the electronic claim to ensure all issues and information have been addressed as appropriate. The system does not generate a new WI or send a notification for outstanding Claim Assessment (CA) or Specialized Application (SA) WIs when documents are uploaded in all situations. 

### Client’s address

Source topic: `en_EN/task/conv_ccb_sick_cc/clients_address.dita`

As a client requesting CCB may temporarily move to another address to provide care or to support a gravely ill family member, the client’s address on the application form is compared to the address in FTS to determine if there has been a change. When a client moves to a province or territory served by a different region, a change in region in FTS is required. 

### Effective date of a conversion

Source topic: `en_EN/task/conv_ccb_sick_cc/effective_date_of_a_conversion.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer refers to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Return to work (RTW)

Source topic: `en_EN/task/conv_ccb_sick_cc/return_to_work_rtw.dita`

If there is an RTW on the claim that falls on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer refers the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### Retroactive conversion request

Source topic: `en_EN/task/conv_ccb_sick_cc/retroactive_conversion_request.dita`

A request to convert to sickness benefits a period of CCB that has already been paid is considered only if the following conditions are met:

- The weeks for which sickness benefits are being claimed fall after October 12, 2014.

- The conversion request is made within 4 weeks of the last week for which CCB were paid.

- The medical certificate includes the date the client’s illness began (onset date).

Where a conversion request is made more than 4 weeks after the periods stated above, the client must show good cause for the delay in making the request. 

### Reassigning a WI to Specialized EI Processing/CCB

Source topic: `en_EN/task/conv_ccb_sick_cc/reassigning_a_wi_to_specialized_ei_processingccb.dita`

CCB claims are processed in selected CCB offices. For more information, the officer refers to Compassionate Care . When a client requests a retroactive conversion from CCB to another benefit type (BT), the officer reassigns the WI related to the conversion to Specialized EI Processing/CCB. A conversion request is retroactive when the client requests a conversion to another BT for which CCB weeks have already processed, whether they were paid or not.
       [Compassionate Care](https://esdc.prv/en/service-canada/ei/contacts/compassionate_care.shtml)

The regular processing officer processes all other conversions from CCB to another BT, and does not reassign them to the specialized processing team. The officer reviews FTS and ensures that the SCC is transferred from the CCB unit to the regional Hosting Production Services site responsible for the client’s current address. There are 4 regions that serve the provinces and territories:

- Atlantic: 1121

- Quebec: 2371

- Ontario: 3515

- Western and Territories: 4812

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2707.dita) 

### Determining when an Operational Centre Memo transaction (MM06) is required

Source topic: `en_EN/task/conv_ccb_sick_cc/determining_when_an_operational_centre__bcc2051c.dita`

If the claim is in MPS, the officer sends an MM06 to IPOC to convert the claim. When completing the MM06, the officer includes all the information required for the conversion. If the claim is in MPS, it stays in MPS for the remainder of the BP and the client must complete paper claimant’s reports. 

### Qualifying for sickness benefits

Source topic: `en_EN/task/conv_ccb_sick_cc/qualifying_for_sickness_benefits.dita`

Sickness benefits can be paid if one of the following conditions is met:

- The client is major attached (has accumulated at least 600 hours of insurable employment).
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

- the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2708.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0021.dita) 

**Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits regardless of the conversion date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

During this period, the officer does not use the claim type (CT) 9 - Sickness - minor attached . 

### Entitlement to sickness benefits

Source topic: `en_EN/task/conv_ccb_sick_cc/entitlement_to_sickness_benefits.dita`

Clients are entitled to sickness benefits if they submit proof of their own illness, injury or quarantine.

The client can receive up to 26 weeks of sickness benefits per benefit period (BP) for a BPC in w/c 2374 or later, and up to 15 weeks of sickness benefits per BP for a BPC in w/c 2373 or earlier. Once a claim has been established, a client can receive a combination of regular and special benefits within the BP. The maximum entitlement to benefits varies based on the BT received. The maximum number of weeks payable for each BT cannot be exceeded.
       [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2653.dita) 

The officer imposes a 22 - Illness (maximum sickness/special benefits paid) disentitlement (D22) when a client requests sickness benefits but the maximum weeks of sickness benefits have already been paid.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2709.dita) 

### Determining if a medical certificate must be submitted

Source topic: `en_EN/task/conv_ccb_sick_cc/determining_if_a_medical_certificate_mu_d4cdaa5c.dita`

Clients requesting a conversion to sickness benefits from CCB must submit an acceptable medical certificate that attests to their own incapacity, and states the incapacity start date and the probable duration of the incapacity.
       [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2710.dita) 

When a medical certificate has been requested but has not been submitted yet, the officer imposes a 16 - No medical certificate submitted disentitlement (D16).

When the client submits a medical certificate but it is considered unacceptable, the officer contacts and asks the client to submit a new medical certificate. If the client does not submit a new medical certificate, the officer imposes a D16.

If the authenticity of a medical certificate or the doctor’s signature raises doubts, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Incapacity period

Source topic: `en_EN/task/conv_ccb_sick_cc/incapacity_period.dita`

To allow the payment of sickness benefits, the officer must determine the period for which the client is incapable of working. This is done by determining the following information:

- the incapacity start date

- the end date of the incapacity

- the expected recovery date

- the recovery week to be input

**Incapacity start date**

For a conversion from CCB to sickness benefits on a continuing claim, the incapacity start date indicated on the medical certificate is the accepted date.

If the medical certificate does not specify a start date, the officer accepts the earliest of the following as the incapacity start date:

- the Sunday of the week the doctor signed the medical certificate;

- the Sunday of the week of the medical consultation.

If the medical certificate does not specify a start date, the officer accepts the doctor’s signature date or the date the doctor saw the client as the incapacity start date. If the certificate does not contain any of these dates, the officer contacts and asks the client to submit a new medical certificate with the incapacity start date. If the client does not submit a new medical certificate, the officer imposes a D16.

**Incapacity end date**

The incapacity end date is the last day the client is incapable of working. The period of incapacity ends the day before the recovery date.

**Recovery date**

The recovery date is the first day the client is capable of working. The medical certificate is used to determine the recovery date.

**Recovery week**

The recovery week is the week up to which sickness benefits are payable.

To determine the recovery week, the officer refers to Determining the recovery week — Instructions .
       [Determining the recovery week — Instructions](/en/procedure/generic/determing_the_recovery_week_instruction.shtml) 

### Deferring the adjudication of a contentious reason for separation (RFS)

Source topic: `en_EN/task/conv_ccb_sick_cc/deferring_the_adjudication_of_a_content_9206571e.dita`

If the client was working while receiving CCB, and reports a contentious RFS when converting to sickness benefits, the officer must fact-find, adjudicate and notify the client of the decision. In some situations, when clients qualify for and request special benefits, fact-finding and adjudication of the contentious RFS can be deferred.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2711.dita) 

### Processing claimant’s reports

Source topic: `en_EN/task/conv_ccb_sick_cc/processing_claimants_reports.dita`

Before the officer can input the conversion transactions, the last week of requested CCB must be paid. Any claimant’s reports that have not yet been processed for the period for which the client requests CCB must be processed before the officer can input the conversion. This requires a 2-day input. 

### Extending the benefit period (BP)

Source topic: `en_EN/task/conv_ccb_sick_cc/extending_the_benefit_period_bp.dita`

The BP can be extended to a maximum of 104 weeks to pay additional weeks of sickness benefits when all the conditions are met during the initial BP. For more information, the officer refers to Benefit period extension .
       [Benefit period extension](/en/procedure/activity/extension_benefit_period.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Extending the compassionate care window CCW window

Source topic: `en_EN/task/conv_ccb_sick_cc/extending_the_compassionate_care_window_b046c3c0.dita`

When clients receive sickness benefits, the CCW is not extended. The CCW remains the period of 26 weeks from the date of receipt of the first valid medical certificate related to the CCB. 

### Outside Canada

Source topic: `en_EN/task/conv_ccb_sick_cc/outside_canada.dita`

A client may need to leave Canada to provide care or support to a gravely ill family member, and still be entitled to CCB. During that time out of Canada, the client may fall ill or be injured. To collect sickness benefits, clients must prove that they are undergoing medical treatment in an accredited hospital that is not readily or immediately available in their area of residence. The urgency to receive medical treatment does not invalidate this provision. To determine the entitlement to sickness benefits of a client who falls ill outside Canada while providing care to a gravely ill family member, the officer refers to Outside Canada .
       [Outside Canada](/en/procedure/activity/out_canada.shtml) 

### Benefit top-ups and supplemental unemployment benefits (SUB)

Source topic: `en_EN/task/conv_ccb_sick_cc/benefit_top-ups_and_supplemental_unempl_e9a623b1.dita`

A client may report benefit top-ups or SUB payments while in receipt of CCB. If the employer does not have an approved SUB plan covering sick leave, benefit top-ups or SUB payments made to a client who is in receipt of sickness benefits are considered as earnings, and are deducted dollar for dollar from sickness benefits.

If the employer does not have an approved SUB plan covering sick leave, it is the clients’ responsibility to ask their employer to stop CCB top-up payments while they are in receipt of sickness benefits. 

### Sickness and training or support measures

Source topic: `en_EN/task/conv_ccb_sick_cc/sickness_and_training_or_support_measures.dita`

If a client becomes ill or incapable of working while participating in an employment benefit or training measure and is unable to continue the training, the training or employment benefit project information must be rescinded. 

### Outstanding disentitlements

Source topic: `en_EN/task/conv_ccb_sick_cc/outstanding_disentitlements.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies. A Level 1 officer can terminate or rescind the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . If the information on file allows for the disentitlement to be terminated, the disentitlement ends on the Friday of the week before the conversion week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

The Level 1 officer can render the decision to terminate a disentitlement on a CCB claim and allow sickness benefits to be paid on a continuing or renewal claim when all of the following conditions are met:

- The client is requesting a conversion from compassionate care benefits to sickness benefits.

- There is a 51 - Does not meet compassionate care entitlement conditions disentitlement (D51), a 52 - Compassionate care benefits exhausted disentitlement (D52), or a 53 - Compassionate care benefits - No medical proof disentitlement (D53) on file.

- The client is requesting the conversion to sickness benefits after the end of the period for which CCB was requested.

- The client meets the entitlement conditions for sickness benefits requested.

- There is no disentitlement on file related to not otherwise available, self-employment or a labour dispute.

- The reason for not returning to work can be allowed at Level 1 and is related to the BT requested.

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer refers the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Adjudicating new contentious issues

Source topic: `en_EN/task/conv_ccb_sick_cc/adjudicating_new_contentious_issues.dita`

When converting a continuing claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If there is no existing WI for this issue, the Level 1 officer creates a CR WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/task/conv_ccb_sick_cc/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an AI, Call Back (CB), Assessment Issue (ASMT) or Reminder (REM) WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### Note

Source topic: `en_EN/common_notes/note_c_2707.dita`

Note:

If the client has a residential address and a mailing address in 2 different regions, the claim is transferred to the region of the mailing address. 

### Note

Source topic: `en_EN/common_notes/note_c_2708.dita`

Note:

For claims beginning w/c 2362 or later and w/c 2309 or earlier, if fewer than 600 insurable hours were used to establish the claim, the client is considered minor attached. In this situation, sickness benefits can be paid only if the reason for separation (RFS) is not illness or injury. 

### Note

Source topic: `en_EN/common_notes/note_c_0021.dita`

Note:

If the client has a violation, there may be increased entrance requirements .
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Note

Source topic: `en_EN/common_notes/note_c_2653.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2709.dita`

Note:

When a client is not entitled to sickness benefits, the officer must determine if the client is able to establish a new claim. 

### Note

Source topic: `en_EN/common_notes/note_c_2710.dita`

Note:

A client is not required to demonstrate good cause for delay when submitting a medical certificate. The Level 1 officer can modify or rescind a disentitlement related to a missing medical certificate for special benefits, regardless of the length of delay, provided all other conditions are met for the BT. 

### Note

Source topic: `en_EN/common_notes/note_c_2711.dita`

Note:

Deferral of fact-finding and adjudication of a contentious RFS can be considered even if a D16 is imposed. 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

## Regional considerations

Source topic: `en_EN/task/conv_ccb_sick_cc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/conv_ccb_sick_cc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/conv_ccb_sick_cc/in_nws.dita`

- Did the client apply for a renewal requesting a conversion of benefits?

- If yes, review processing activities for the web application and take notes if necessary:

- What issues did ACP detect?

- Does it indicate why the claim tripped down?

- Is the client’s current address different from the address on file?

- Has the client worked since the last application for benefits?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies , motor vehicle accident compensation, workers’ compensation benefits (WCB) or wage loss insurance (WLI) payments to consider or allocate?

- Is there a new contentious RFS?

- Is there an Adjudication Issue (ADJ) WI?

- if yes, for what issue?

- Is there a medical certificate that attests to the client’s own illness or injury on file, or has one been uploaded? 

### In FTS:

Source topic: `en_EN/task/conv_ccb_sick_cc/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the last renewable week (LRW) been reached?

- Is there a stop payment?

- Is there an RTW on the claim?

- Are there any pending claimant’s reports or claimant’s reports to be processed before the conversion?

- What is the number of the Service Canada Centre (SCC) for the client’s address?

- Is there a registration number?

- Does this employer have an approved SUB plan?

- Is the SUB plan for regular, sickness or training benefits?

- What is the SUB plan type?

- Who is covered in the beneficiaries group? 

### In RCM:

Source topic: `en_EN/task/conv_ccb_sick_cc/in_rcm.dita`

- Has the ROE been submitted?

- Are there earnings, separation monies , motor vehicle accident compensation, WCB or WLI payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/conv_ccb_sick_cc/in_imaging.dita`

- Is there a medical certificate on file attesting to the client’s own illness or injury? 

## Step by step

Source topic: `en_EN/task/conv_ccb_sick_cc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/conv_ccb_sick_cc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/conv_ccb_sick_cc/reviewing_the_file_level_1.dita`

- In FTS, determine if the maximum combination of regular and special benefits have been paid:

- If yes, go to Maximum combination of regular and special benefits paid .
               [Maximum combination of regular and special benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_ccb_sick_cc#maxcomb)

- If no, determine if the maximum number of weeks of sickness benefits have been paid for this BPC:

- If no, go to step 2.

- If yes, go to Maximum sickness benefits paid .
                   [Maximum sickness benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_ccb_sick_cc#maxsick)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- Determine if a registration number related to the conversion is on file:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Go to step 3.

- Determine if the client is requesting a retroactive conversion to a period for which CCB has been processed:

- If no, go to step 4.

- If yes, go to Reassigning the WI to the Specialized EI Processing/CCB level .
               [Reassigning the WI to the Specialized EI Processing/CCB level](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_ccb_sick_cc#level1_item_6)

- Determine if there is an outstanding AI WI for a medical certificate for CCB or indicating that the patient has died:

- If yes, go to step 5.

- If no, go to step 7.

- In NWS, move the conversion WI to Pending as follows:

- Pending reason: Select Other .

- Comments: “Waiting for CCB unit to action [a medical certificate or a notification of death] on file.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if a decision has been rendered:

- If no, repeat step 5.

- If yes, go to step 7.

- Determine if one of the following scenarios applies:

- If there is a change of address to input, refer to Change of address . Go to step 8.
               [Change of address](/en/procedure/activity/change_address.shtml)

- If the client was receiving CCB top-ups and SUB payments, and the employer continues to pay them, refer to Verifying and entering the supplemental unemployment benefits code . Go to step 8.
               [Verifying and entering the supplemental unemployment benefits code](/en/procedure/task/ver_ent_subc.shtml)

- If the client requested a payment against the first payer, refer to Reviewing for benefits paid or payable from another source .
               [Reviewing for benefits paid or payable from another source](/en/procedure/task/calc_determining/rev_psl_wli.shtml)

- If neither scenario applies, go to step 8.

- Determine if there is a pending E-report on the E-Report tab for the period before the conversion:

- If there is no pending E-report, go to step 9.

- If there is a pending E-report, refer to Actioning a pending claimant’s report and then go to step 9.
               [Actioning a pending claimant’s report](/en/procedure/task/pending_cr.shtml)

- Determine if there are any rejected E-reports on the Pending/Reject tab for the period before the conversion:

- If no, go to step 10.

- If yes, re-input the reports. Refer to Actioning a rejected claimant’s report and then go to step 10.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml)

- Determine if the client reports having received monies and whether they have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings and then go to step 11.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 11.

- If no monies were received, go to step 11.

- In NWS and in FTS, determine if one of the following conditions applies:

- The client was incarcerated, and has since been tried and has not been found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If one of the conditions applies, refer to BP extension and then go to step 12.
               [BP extension](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions apply, go to step 12.

- Determine if the LRW has been reached:

- If no, go to step 13.

- If yes, go to Last renewable week (LRW) has been reached .
               [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_ccb_sick_cc#LWRreached)

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 14.

- If no, go to step 16.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, go to step 15.

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 16.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine the claim type:

- If it is a conversion on a continuing claim, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 16.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If it is a conversion on a renewal claim, in NWS create an ADJ WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Availability .

- Details: Type “Outstanding D15 for a missed client information session, Level 2 review required.”

- Select Save .

- Go to step 16.

- Determine if there are any other outstanding disentitlements on file:

- If no, go to step 18.

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 17.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option .

- Details: Type “Outstanding [type of disentitlement] disentitlement.”

- Select Save .

- Refer to the appropriate procedure and go to step 17.

- Determine if the conditions are met to terminate or rescind the disentitlement at Level 1 according to the National Policy on Levels of Decision :

- If yes, terminate or rescind the disentitlement and go to step 18.

- If no, reassign the WI to Level 2 and go to step 18.

- Determine if there are any outstanding issues that require adjudication that do not have a related WI:

- If no, go to step 20.

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 19.

- If yes and the conversion is on a renewal claim, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Next Available User .

- Issue(s): Select the appropriate option

- Details: Indicate the reason the WI is being created.

- Select Save .

- Refer to the appropriate procedure and go to step 19.

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If yes, complete the steps from the appropriate procedure and go to step 20.

- If no, reassign the WI to Level 2 and go to step 20.

           [Remarque](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2714.dita)

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine if a valid medical certificate is on file attesting to the client’s own illness or injury:

- If yes, go to step 22.

- If no, go to step 23.

- Determine if the incapacity start date, the doctor’s signature date or the date the doctor saw the client is on the medical certificate:

- If no, go to step 23.

- If yes, go to step 29. 

#### Fact-finding to obtain a medical certificate

Source topic: `en_EN/task/conv_ccb_sick_cc/fact-finding_to_obtain_a_medical_certificate_level_1.dita`

- Fact-find with the client and ask the client to submit a valid medical certificate with the required information. If necessary, refer to the Fact-Finding and Documentation Policy .

- Determine if the client was contacted during fact-finding or if the client responded to the N-10-00-00 letter:

- If the client was contacted, go to step 25.

- If the client was not contacted, go to step 26.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Conversion .

- Comments: Type “Conversation with the client — medical certificate requested.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client submitted a valid medical certificate:

- If a medical certificate was requested but is not on file, go to step 27.

- If a medical certificate is on file, go to step 29.

- If the client was not contacted and the medical certificate is not on file, go to step 30.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact finding with client .

- Comments: Type “Awaiting medical certificate.”

- Bring forward date: Enter [the day the client was contacted + 10].

- When the WI moves to the current workload, determine if a valid medical certificate has been submitted:

- If yes, go to step 29.

- If no, go to step 30.

- Determine if there is a gap between the effective conversion date and the incapacity start date:

- If yes, use the start date indicated on the medical certificate and go to step 30.

- If no, use the start date indicated on the medical certificate and go to step 33.

- In NWS, document the decision in a record of decision (ROD) as follows:

- Comments: Type “D16 imposed — incapacity start date not proven or no medical certificate submitted].”

- Details: Type the appropriate option:

- If the medical certificate was not submitted or is not acceptable, type “The client has not submitted a medical certificate. Indefinite D16 imposed from [the week of the conversion].”

- If the incapacity start date declared by the client does not match the incapacity start date, the date the doctor saw the client or the doctor’s signature date on the medical certificate, type “The incapacity start date declared by the client does not match the medical certificate. D16 imposed from [the period declared by the client] to [the Friday before the incapacity start date].”

- If there is no incapacity start date, date on which the doctor saw the client or doctor’s signature date on the medical certificate, type “The incapacity start date is not on the medical certificate. Indefinite D16 imposed from [the week of the conversion].”

- In FTS, select the Renewal / Revised (M161) transaction to input the D16 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 16 - No medical certificate submitted .

- Start date: Select the Monday of the conversion date.

- End date: Select the appropriate option.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- D16 - No medical certificate provided / incapacity ended / gradual return (3068): Select the appropriate option:

- D16 - No medical certificate provided .

- D16 - No medical evidence supporting your incapacity .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- Determine the recovery week by referring to Determining the recovery week — Instructions and then go to step 34. 

#### Inputs

Source topic: `en_EN/task/conv_ccb_sick_cc/inputs_level_1.dita`

- In FTS, determine if the claim status (CS) is 8 - Converted to manual pay :

- If no, go to step 35.

- If yes, go to Sending an Operational Centre Memo (MM06) transaction to IPOC .
               [Sending an Operational Centre Memo (MM06) transaction to IPOC](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_ccb_sick_cc#level1_item_4)

- In FTS, determine if the client is minor attached:

- If yes, use the claim type 9 - Sickness - minor attached .

- If no, use the claim type 3 - Sickness - major attached .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2715.dita)

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select the appropriate option:

- 3 - Sickness - major attached

- 9 - Sickness - minor attached

- Manual Action: Select the appropriate option (only if Level 2 adjudication is required).

- Select the Special benefits (M106) link and input the following on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option

- If Level 2 adjudication is required, select D - No to leave the registration number open for subsequent transactions.

- If Level 2 adjudication is not required, select C - Yes to complete the registration number.

- Select Update .

- Determine if the warning C790 was issued when the Renewal / Revised (M106) transaction was input:

- If no, go to step 38.

- If yes, do the following:

- Check the Override box.

- Select Update .

- Go to step 38.

- In FTS, change the SCC number as follows on the Name and Address Change / Transfer - M159 transaction:

- New SCC : Select the SCC number according to the Hosting Production Services for the client’s address.

- Atlantic: 1121

- Ontario: 3515

- Quebec: 2371

- Western Canada and Territories: 4812

- Select Update .

- In ACS, add to the saved N-00-00-00 letter or create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits approved (3046) .

- Sickness benefits approved (3047):

- Select Sickness approved - Client must provide medical certificate .

- Select Start date of Sickness benefits - Sunday’s date (1252) .

- Select End date of Sickness benefits - Saturday’s date (1254) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- Determine if Level 2 adjudication is required:

- If no, go to step 41.

- If yes, in NWS, reassign any CR WI for the contentious issue to Level 2 as follows:

- Destination — SCC: Select the SCC as shown in FTS.

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “ Not within Level 1 authority.”

- Go to step 41.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2716.dita)

- In NWS, complete the Conversion WI. 

#### Sending an Operational Centre Memo (MM06) transaction to IPOC

Source topic: `en_EN/task/conv_ccb_sick_cc/sending_an_operational_centre_memo_mm06_6137db03_level_1.dita`

- Before sending the Operational Centre Memo (MM06) to IPOC, determine if a Level 2 officer must adjudicate any outstanding issues:

- If yes, go to step 2.

- If no, go to step 4.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting Level 2 decision.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if a decision has been rendered:

- If no, repeat step 2.

- If yes, go to step 4.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 30 - New information on manual pay claim .

- Remarks line 1: Type “Convert from CT [12 or 77] to CT [XX].”

- Remarks line 2: Type “Start w/c [XXXX] to w/c [XXXX], RCV WK [XXXX]”. Include the waiting period (WP) details and any other relevant information.

- Remarks lines 3 and 4: If an extension of the BP is required, type “Extend [type], start w/c [XXXX], ENT WEEKS [XX]. If a new disentitlement is required or an existing disentitlement must be terminated, type “D[XX] Disentitlement start w/c [XXXX-X] to [XXXX-X].” If an allocation is required, type “M175 [type] [amount] [w/c start date] to [w/c end date], [amount, if the last week is different].

- Remarks line 5: Enter your first name and last name.

- Decision type: Select the appropriate option.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 04 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, determine if there is a client Note to send a saved ACS letter:

- If yes, go to step 8.

- If no, go to step 9.

- In ACS, review and send the saved letter.

- In NWS, complete the WI. 

#### Maximum combination of regular and special benefits already paid

Source topic: `en_EN/task/conv_ccb_sick_cc/maximum_combination_of_regular_and_spec_5cf2309f_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D22 imposed — maximum combination of benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC. D22 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as [number of hours] hours were accumulated after the BPC and the client needed [number of hours] hours to qualify. D22 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction and impose the D22 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 22 - Illness (maximum sickness / special benefits paid) .

- Start date: Select the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special Benefits Denied (3065): Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D22 - Max sickness paid / max sick paid but approved regular or maternity benefits /max combination of special benefits reached (3069) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Maximum sickness benefits already paid

Source topic: `en_EN/task/conv_ccb_sick_cc/maximum_sickness_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D22 imposed — sickness benefits exhausted.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as maximum sickness benefits have been paid. The client does not qualify for a new claim as no hours were accumulated after the BPC. D22 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as maximum sickness benefits have been paid. The client does not qualify for a new claim as [number of hours] hours were accumulated after the BPC and the client needed [number of hours] hours to qualify. D22 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction and impose the D22 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 22 - Illness (maximum sickness / special benefits paid) .

- Start date: Select the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D22 - Max sickness paid / max sickness paid but approved regular or maternity benefits /max combination of special benefits reached (3069) .

- Select D22 - Max weeks of sickness benefits already paid .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Sickness maximum of 15 or 26 weeks (12545) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Last renewable week (LRW) reached

Source topic: `en_EN/task/conv_ccb_sick_cc/last_renewable_week_lrw_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “LRW reached — sickness benefits requested.”

- Details: Select one of the following:

- If the client has not worked since the BPC , type “No conversion is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as no hours were accumulated after the BPC. CCB are still payable.”

- If the client has worked since the BPC , type “No conversion is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as [number of hours] hours were accumulated after the BPC. Client needed [number of hours] hours to qualify. CCB are still payable.”

- In ACS, send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type: “We cannot reactivate your claim for Employment Insurance benefits starting (Renewal week - Sunday’s date) . Please note that we are required to advise you of all decisions made on your claim. No sickness benefits are payable to you on this claim because the last renewal week has been reached on this benefit period. To receive regular benefits, you must work the required minimum number of insurable employment hours. If you want to receive regular benefits in the future, you must apply for a new claim.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction to complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Reassigning the WI to the Specialized EI Processing/CCB level

Source topic: `en_EN/task/conv_ccb_sick_cc/reassigning_the_wi_to_the_specialized_e_1950e2ef_level_1.dita`

- In NWS, reassign the WI as follows:

- Destination — Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / CCB .

- Reason: Select Unable to complete .

- Details: Type “The client is requesting a retroactive conversion to a period for which CCB has been processed.”

- Select OK. 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Remarque

Source topic: `en_EN/common_notes/note_c_2714.dita`

Remarque :

When converting a claim to regular or sickness benefits, always determine if the client is available or otherwise available 

#### Note

Source topic: `en_EN/common_notes/note_c_2715.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, 420 hours of insurable employment is required to establish a claim for regular or special benefits. During this period the definitions of major and minor attached clients do not apply. However if the client has 420 or more insurable hours, the officers chooses the major attached option.

During this period, the officer cannot use the claim type (CT) 9 - Sickness - minor attached . 

#### Note

Source topic: `en_EN/common_notes/note_c_2716.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose a 1 -General suspension of benefits (stop payment) manual action (MA1) to stop payment. 

## Policy reference

Source topic: `en_EN/task/conv_ccb_sick_cc/policy_reference.dita`

- BE 2014-04—Sickness Benefits for Claimants in Receipt of Parents of Critically Ill Children (PCIC) and Compassionate Care (CCB) Benefits
         [BE 2014-04—Sickness Benefits for Claimants in Receipt of Parents of Critically Ill Children (PCIC) and Compassionate Care (CCB) Benefits](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2014-04.shtml)

- EIA 12(6)
         [EIA 12(6)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 21(1)
         [EIA 21(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-21.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- National Policy on Proof of Incapacity
         [National Policy on Proof of Incapacity](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/proof_of_incapacity_policy.shtml) 
