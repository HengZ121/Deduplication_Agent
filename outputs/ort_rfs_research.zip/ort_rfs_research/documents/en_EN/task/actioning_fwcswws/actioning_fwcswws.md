# Actioning rejected transactions due to casual sickness benefits on a Work-Sharing claim — IPOC

Source map: `en_EN/task/actioning_fwcswws/actioning_fwcswws.ditamap`

## Summary

Source topic: `en_EN/task/actioning_fwcswws/summary.dita`

Summary: A client who is receiving regular or Work-Sharing (WS) benefits can receive weeks of casual sickness benefits. After either 4 consecutive weeks have been declared or 8 weeks in total have been paid, the claimant’s report is rejected overnight with either a C465 or a C484 error code. 

## What you need to know

Source topic: `en_EN/task/actioning_fwcswws/what_you_need_to_know.dita`

### Processing error codes C465 and C484

Source topic: `en_EN/task/actioning_fwcswws/processing_error_codes_c465_and_c484.dita`

There are 2 different casual sickness weeks counters for any individual claim:

- Consecutive casual sickness declared: If this counter is at 4 consecutive casual sickness weeks, whether these weeks are paid or not, and a fifth week of casual sickness is input, the claimant’s report is rejected with a C465 error.

- Total casual sickness weeks paid: When 8 weeks of casual sickness benefits have been paid on a claim, consecutive or not, and a ninth week of casual sickness is input, the claimant’s report is rejected with a C484 error.

When the claimant’s report is rejected overnight with a C465 or C484 error code, it generates an IPOC System Notification (IPOC SN) Work-sharing - CPS reject WI. In EDS, the officer can also view these errors each day on the LD11443 WS error listing report.

**Ending a Work-Sharing (WS) agreement**

The IPOC officer must review the rejected claimant’s reports to determine what action to take. The WS agreement end week must be changed to correspond to the week before the week of the rejected claimant’s report.

The IPOC officer notifies the program officer of the termination of the WS project due to an extended sick leave using the notification of separation from WS employment email template.

**Creating an Action Item (AI) WI**

If the client submits a claimant’s report that indicates 5 sick days, the IPOC officer sends an AI WI to advise the processing centre that the client must be contacted regarding claim conversion. 

### Retrieving rejected transactions

Source topic: `en_EN/task/actioning_fwcswws/retrieving_rejected_transactions.dita`

The IPOC officer must clear the rejection on the Rejected Transactions Retrieval (MR05) screen once the error has been actioned. 

## Regional considerations

Source topic: `en_EN/task/actioning_fwcswws/regional_considerations.dita`

**Ontario region:**

The WS Level 1 officer cannot action the Manual Action - Claimant’s Report (T045) transaction. The WS Level 1 officer sends a Work-Sharing IPOC Review (IPOC REV) WI to the Ontario IPOC (SCC 3056) with a request to process the T045 transaction. 

## What you need to look for

Source topic: `en_EN/task/actioning_fwcswws/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/actioning_fwcswws/in_fts.dita`

- Did the client declare sick days for the entire report period or for only a part of the report period?

- Which error codes are indicated on the Pending/Reject tab? 

### In NWS:

Source topic: `en_EN/task/actioning_fwcswws/in_nws.dita`

- Is there an outstanding AI WI requesting a claim conversion to sickness benefits? 

## Step by step

Source topic: `en_EN/task/actioning_fwcswws/step_by_step.dita`

### IPOC

Source topic: `en_EN/task/actioning_fwcswws/ipoc.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_fwcswws/reviewing_the_file_ipoc.dita`

- In NWS, review the rejected week and error code in the Specific details tab of the IPOC SN Work-Sharing - CPS reject WI.

- In FTS, on the Payments tab, determine if claimant’s reports are cycling:

- If yes, go to Claimant’s reports are cycling .
               [Claimant’s reports are cycling](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_fwcswws#crac)

- If no, go to Claimant’s reports are not cycling .
               [Claimant’s reports are not cycling](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_fwcswws#cranc) 

#### Claimant’s reports are cycling

Source topic: `en_EN/task/actioning_fwcswws/claimants_reports_are_cycling_ipoc.dita`

- Select the Renewal/Revised (M106) transaction and remove the cycling claimant’s reports as follows:

- Manual action: Select 76R - Automated work-sharing Rescind/Removal of Cycling Reports .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1425.dita)

- Select the Project Data — Worksharing (M171) transaction and change the end week of the WS agreement as follows:

- End date: Select the WS agreement end week that corresponds to the week before the week of the rejected claimant’s report.

- Select Update .

- Go to Referring the issue to the processing centre and notifying the regional program officer .
               [Referring the issue to the processing centre and notifying the regional program officer](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_fwcswws#ipocc_item_2)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1426.dita) 

#### Claimant’s reports are not cycling

Source topic: `en_EN/task/actioning_fwcswws/claimants_reports_are_not_cycling_ipoc.dita`

- In FTS, determine if the client is exempt from reporting:

- If yes, go to step 4.

- If no, go to step 5.

- Select the Renewal/Revised (M106) transaction and rescind the NO-CR-CODE as follows:

- Claimant’s Report — Rescind: Check the box.

- Select Update .

- Select the Project Data—Worksharing (M171) transaction and change the end week of the WS agreement as follows:

- End date: Enter the WS agreement end week that corresponds to the week before the week of the claimant’s report that was rejected.

- Select Update .
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1426.dita)

- Determine if the 76 - Automated Work-Sharing manual action (MA76) has been rescinded:

- If yes, go to Referring the issue to the processing centre and notifying the regional program officer .
               [Referring the issue to the processing centre and notifying the regional program officer](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_fwcswws#ipocc_item_2)

- If no, select the Manual Action - Claimant’s Report (T045) transaction and rescind the 76 - Automated Work-Sharing manual action (MA76) as follows:

- Week: Select Indefinite .

- Manual action: Select 76 - Automated work-sharing .

- Rescind: Check the box.

- Select Update .

- Go to Referring the issue to the processing centre and notifying the regional program officer .
               [Referring the issue to the processing centre and notifying the regional program officer](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_fwcswws#ipocc_item_2) 

#### Referring the issue to the processing centre and notifying the regional program officer

Source topic: `en_EN/task/actioning_fwcswws/referring_the_issue_to_the_processing_c_c1c487da_ipoc.dita`

- Complete the notification of separation from WS employment email template and send it to the regional program officer’s GD mailbox. Select the appropriate email template:

- Atlantic
               [Atlantic](https://014gc.sharepoint.com/:u:/r/sites/EI_IPOS-SOPA_AE/IPOC%20Guidance_Procedures%20COPA/Templates-Mod%C3%A8les/ATL-Template-WSSeparationNotice-EN.oft?csf=1&download=1)

- Quebec
               [Quebec](https://014gc.sharepoint.com/:u:/r/sites/EI_IPOS-SOPA_AE/IPOC%20Guidance_Procedures%20COPA/Templates-Mod%C3%A8les/QC-Template-WSSeparationNotice-EN.oft?csf=1&download=1)

- Ontario
               [Ontario](https://014gc.sharepoint.com/:u:/r/sites/EI_IPOS-SOPA_AE/IPOC%20Guidance_Procedures%20COPA/Templates-Mod%C3%A8les/ON-Template-WSSeparationNotice-EN.oft?csf=1&download=1)

- Western Canada and Territories
               [Western Canada and Territories](https://014gc.sharepoint.com/:u:/r/sites/EI_IPOS-SOPA_AE/IPOC%20Guidance_Procedures%20COPA/Templates-Mod%C3%A8les/WT-Template-WSSeparationNotice-EN.oft?csf=1&download=1)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1427.dita)

- In NWS, create an AI WI for Level 1 as follows:

- Complexity: Select Level 1 .

- Destination — Level: Select the appropriate option:

- Quebec: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing – QC / Work-Sharing – QC .

- Ontario: Select 1- Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - ON / Work-Sharing - ON .

- Western Canada and Territories: Select 1- Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - WT / Work-Sharing - WT .

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1428.dita)

- End User: Select Next available user .

- Category: Select the appropriate option:

- Pay affected .

- Not Pay affected .

- Issue: Select Work-Sharing .

- Comments: Do one of the following:

- For error code C465, type “Fifth consecutive week of sickness declared on WS claim.”

- For error code C484, type “Maximum 8 weeks of casual sickness benefits paid on WS claim.”

- Details: Do one of the following:

- For error code C465, type “Fourth consecutive week of sickness processed and WS terminated in w/c [XXXX]. Contact the client for claim conversion from w/c [XXXX].”

- For error code C484, type “Maximum 8 weeks of casual sickness benefits paid and WS terminated in w/c [XXXX]. Contact the client for claim conversion from w/c [XXXX].”

- Select Save .

- Create an SROC as follows:

- Main Issue: Select Other .

- Comments: Do one of the following:

- For error code C465, type “Fifth consecutive week of sickness declared on a Work-Sharing claim.”

- For error code C484, type “Maximum 8 weeks of casual sickness paid on Work-Sharing claim.”

- Details: Do one of the following:

- For error code C465, type “The client is on Work-Sharing. An error code C465 was generated — fifth consecutive week of sickness declared for w/c [XXXX]. The Work-Sharing end week is changed to w/c [XXXX]. An Action Item work item is sent to Level 1 to contact the client for claim conversion.”

- For error code C484, type “The client is on Work-Sharing. An error code C484 was generated — a week of sickness declared for w/c [XXXX] and maximum 8 weeks of casual sickness have already been paid. The Work-Sharing end week is changed to w/c [XXXX]. An Action Item work item is sent to Level 1 to contact the client for claim conversion.”

- Select Save .

- In FTS, select the Rejected Transactions Retrieval (MR05) screen and do the following:

- Completed by: Leave this field blank.

- Error Code: Do one of the following:

- For error code C465, type “465.”

- For error code C484, type “484.”

- Select Search .

- Delete the error code that was reviewed from the Rejected Transactions Retrieval (MR05) screen as follows:

- Delete: Check the box next to the appropriate SIN.

- Select Update .

- Review the rejected transactions on the Pending /Reject tab and determine if another error code must be reviewed:

- If no, go to Completing the WI .
               [Completing the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_fwcswws#ipocc_item_3)

- If yes, go to Actioning a Work-sharing rejected transaction or a warning notification — IPOC .
               [Actioning a Work-sharing rejected transaction or a warning notification — IPOC](/en/procedure/task/actioning_work_sharing_rejected_transaction_or_warning_notification_ipoc.shtml) 

#### Completing the WI

Source topic: `en_EN/task/actioning_fwcswws/completing_the_wi_ipoc.dita`

- In NWS, complete the IPOC SN Work-Sharing - CPS reject WI and document the actions taken. 

#### Note

Source topic: `en_EN/common_notes/note_c_1425.dita`

Note:

This action removes the 76 - Automated Work-Sharing manual action (MA76), the cycling claimant’s reports and, if necessary, the exemption from reporting. 

#### Note

Source topic: `en_EN/common_notes/note_c_1426.dita`

Note:

Ensure that WS weeks are processed up to the revised end week. 

#### Note

Source topic: `en_EN/common_notes/note_c_1427.dita`

Note:

Complete the email template as follows:

- Date of receipt of notice: Select the date of the rejected claimant’s report.

- Reason for separation: Type “Fifth week of consecutive casual sickness” or “Ninth week of casual sickness.”

- Last day worked: Select the Friday of the last week processed as WS or the specific date if known.

- Save a copy of the email in the employer’s Correspondence subfolder. 

#### Note

Source topic: `en_EN/common_notes/note_c_1428.dita`

Note:

For the Atlantic region, assign the WI to the SCC as shown in FTS. 

## Policy reference

Source topic: `en_EN/task/actioning_fwcswws/policy_reference.dita`

 
