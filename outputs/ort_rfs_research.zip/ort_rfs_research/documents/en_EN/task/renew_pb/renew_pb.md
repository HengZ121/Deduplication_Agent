# Renewing a claim for parental benefits

Source map: `en_EN/task/renew_pb/renew_pb.ditamap`

## Summary

Source topic: `en_EN/task/renew_pb/summary.dita`

Summary: When a client applies for parental benefits and there is a benefit period (BP) with entitlement weeks remaining, the BP can be renewed. 

## What you need to know

Source topic: `en_EN/task/renew_pb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/renew_pb/untitled_section.dita`

When assessing a renewal, it might be to the client’s advantage to establish a new BP instead of renewing the existing BP. For more information, the officer refers to Cancelling, voiding, terminating or withdrawing a claim .
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml)

Parental benefits allow parents to be away from their work to care for a newborn child or a child placed with the client for the purpose of adoption. Benefits may be requested and received from the date of birth, adoption or placement of the child. 

### Type of parental benefits

Source topic: `en_EN/task/renew_pb/type_of_parental_benefits.dita`

Parental benefits can be paid either at the basic rate or at a reduced rate over an extended period of time. The maximum number of parental entitlement weeks for a birth or adoption varies depending on the type of parental benefits the client receives and whether benefits are shared with other legally recognized parents. 

### Maximum entitlement

Source topic: `en_EN/task/renew_pb/maximum_entitlement.dita`

A client is entitled to a maximum of 35 weeks of standard parental benefits or 61 weeks of extended parental benefits per birth or placement for adoption. The maximum parental entitlement is also the maximum number of parental entitlement weeks that can be paid in a BP. The number of weeks of parental benefits a client is entitled to receive is not affected by the number of children born at the same time (twins, triplets, etc.) or by the number of children adopted at the same time. 

### Sharing parental benefits

Source topic: `en_EN/task/renew_pb/sharing_parental_benefits.dita`

Parents can share parental benefits. For more information and definitions, the officer refers to Parents: Definition — Table .
       [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

The type of parental benefits requested by the first parent to apply for EI benefits determines the type of parental benefits all parents are entitled to receive for the same birth, adoption or placement, regardless of which parent is paid first. When fact-finding with parents who applied for EI benefits after the first parent, the officer informs the other parents of this. Once at least one week of parental benefits has been paid to any parent, all parents requesting parental benefits for the same birth, adoption or placement are only entitled to receive the type of parental benefits selected by the first parent who applied for EI benefits.

The maximum shareable entitlement is 40 weeks of standard parental benefits or 69 weeks of extended parental benefits for children born or placed for adoption on or after March 17, 2019. For children born or placed for adoption before this date, the maximum shareable entitlement is 35 weeks of standard parental benefits or 61 weeks of extended parental benefits. The maximum entitlement for one client remains at 35 weeks of standard or 61 weeks of extended benefits. Clients can change the number of weeks that each parent receives at any time before all benefits are paid. When clients cannot agree on the number of weeks they will each receive, the officer reassigns the issue to a Level 2 officer who adjudicates the division of the remaining weeks.

Clients who apply for parental benefits must provide the name and SIN of the other parent for control purposes. If the client does not provide the name and SIN of the other parent, or in the case of a single parent or a parent whose family situation is such that information on the child’s other parent cannot be obtained, the officer can still allow the claim.

**Validating shared parental benefits**

A Parental Client Record is created for every client requesting parental benefits. The Parental Client Record consists of the client’s SIN, the arrival or placement week (APW) and the other parent’s SIN, if it has been provided. Once a claim is finalized, the system links Parental Client Records for all clients who are sharing parental benefits for the same child. The Parental sharing validation process creates a Claim Review (CR) Parental Benefits Validation WI when one of the following conditions is met:

- The parental benefit type on all linked Parental Client Records is not the same.

- The total number of parental weeks requested on all linked Parental Client Records exceeds the maximum number of shareable parental benefit weeks.

**FTS**

The officer inputs the other parent’s SIN using the Parental Benefits Validation transaction in the Enquiry menu in FTS. The Parental Benefits Validation screen displays linked parents’ SINs and the associated APW.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4433.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0139.dita) 

**Other parent’s SIN**

When the client has provided the other parent’s SIN, the officer manually enters it on the day following the parental input.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2717.dita) 

If the client’s SIN has already been linked to the other parent, no entry is necessary. 

### Duration of the benefit period (BP)

Source topic: `en_EN/task/renew_pb/duration_of_the_benefit_period_bp.dita`

The BP is the period of time in which clients can claim the weeks of benefits to which they are entitled. The duration of a BP is normally 52 weeks, including the week of the BPC.

A BP ends when one of the following occurs:

- All the weeks of regular benefits to which the client is entitled have been paid.

- The 52-week duration has been reached and no condition to extend the BP was met.

- The client requests and qualifies for termination of the BP.

- The maximum entitlement to benefits has been paid.
         [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

Under certain conditions, the BP can be extended to allow clients more time to receive the benefits to which they are entitled. For further information, the officer refers to Extension of the Benefit period .
       [Extension of the Benefit period](/en/procedure/activity/extension_benefit_period.shtml) 

### Qualifying for parental benefits

Source topic: `en_EN/task/renew_pb/qualifying_for_parental_benefits.dita`

To qualify for parental benefits, a client must meet the following conditions:

- The client must have an interruption of earnings (I of E).

- The client must be major attached (has accumulated at least 600 insurable hours) or the BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2774.dita) 

**Qualifying for benefits with the common entrance requirement (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national common entrance requirement (CER) of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits, regardless of the renewal date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to parental benefits

Source topic: `en_EN/task/renew_pb/entitlement_to_parental_benefits.dita`

Parental benefits are payable during the parental window (PW) to parents providing care for a child. To be entitled to parental benefits, the client must provide proof of birth, adoption or placement. A client does not have to collect all of the weeks of parental benefits successively. Payments of parental benefits can alternate with the payment of another type of benefits. Parental benefits can be paid in one BP or over 2 BPs, as long as the maximum number of parental entitlement weeks is not exceeded and the end of the PW has not been reached. 

### Proof of birth, adoption or placement

Source topic: `en_EN/task/renew_pb/proof_of_birth_adoption_or_placement.dita`

Parents must supply proof of birth, adoption or placement depending on their relationship to the child or children. For more information, the officer refers to Parents: Definition — Table .
       [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml) 

### Parental window (PW)

Source topic: `en_EN/task/renew_pb/parental_window_pw.dita`

The PW is defined as the period during which parental benefits can be paid. The PW starts and ends as follows:

- Start week:

- The APW is determined by the parent’s relationship to the child. For more information, the officer refers to Parents: Definition — Table ).
             [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

- End week:

- For standard parental benefits: the end week is 52 weeks after the APW (APW + 52)

- For extended parental benefits: the end week is 78 weeks after the APW (APW + 78)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0877.dita) 

### Extending the benefit period (BP) and parental window (PW)

Source topic: `en_EN/task/renew_pb/extending_the_benefit_period_bp_and_par_bc66fc4a.dita`

Hospitalization of the child for whom parental benefits are being claimed is grounds to extend the BP and PW. The BP and PW can also be extended for personnel of the Canadian military who are unable to collect their parental benefits because of an imperative military requirement. For more information, the officer refers to Extension of the benefit period.
       [Extension of the benefit period.](/en/procedure/activity/extension_benefit_period.shtml)

The PW is also extended when a client entitled to parental benefits is entitled to a BP extension for special benefits. When this occurs, the BP and PW are both extended. For more information, the officer refers to Benefit period: Extension for special benefits — Table .
       [Benefit period: Extension for special benefits — Table](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Terminating parental benefits during the Parental window (PW) — Entitlement conditions are no longer met

Source topic: `en_EN/task/renew_pb/terminating_parental_benefits_during_th_507d8ff1.dita`

A client must meet the entitlement conditions for each week of parental benefits requested. If the officer is informed that the client is no longer caring for the child during the PW, the officer imposes a definite or indefinite 34 - Parental benefits entitlement conditions not met disentitlement (D34) starting the Monday after the week in which the client is no longer entitled to benefits. For more information, the officer refers to Determining entitlement to parental benefits when the client is no longer caring for the child .
       [Determining entitlement to parental benefits when the client is no longer caring for the child](/en/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml) 

### Multiple parental windows (PW) in one benefit period (BP)

Source topic: `en_EN/task/renew_pb/multiple_parental_windows_pw_in_one_ben_3cfa5dd8.dita`

When a subsequent birth or placement occurs during a BP, a subsequent PW can be established. If the maximum entitlement to benefits has not yet been paid in the BP and a subsequent PW is required, parental benefits can be paid for the subsequent birth or placement. When a subsequent PW is required on an existing BP and parental entitlement weeks have already been paid during the BP, the claim must be converted to MPS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4434.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4435.dita) 

### QPIP

Source topic: `en_EN/task/renew_pb/qpip.dita`

Clients who live in Quebec and who request benefits due to a pregnancy, birth or adoption must apply to QPIP . The Quebec government pays these benefits to Quebec residents. In some cases, the Quebec government also pays QPIP benefits to a parent living outside of Quebec if both parents lived in Quebec when the initial claim for maternity or parental benefits for the birth or adoption of the same child was made. When a client applying for EI benefits lives in Quebec or indicates that the other parent is entitled to QPIP benefits, the officer on the specialized  team that is responsible for liaising with QPIP determines whether the client is entitled to the requested EI benefits.
       [QPIP](/en/procedure/generic/additionalresources/qpip_knowledge.shtml)

When a client living in Quebec is entitled to receive QPIP benefits, an officer from the specialized QPIP team imposes an indefinite 57 - E.I.Maternity and Parental denied, benefits payable by the province disentitlement (D57).

When a client is not entitled to receive QPIP benefits, the client can apply for EI benefits.

For more information, the officer refers to QPIP .
       [QPIP](/en/procedure/activity/qpip.shtml) 

### Disentitlements

Source topic: `en_EN/task/renew_pb/disentitlements.dita`

The following disentitlements related to parental benefits are imposed when the client does not meet the entitlement conditions:

A D34 is imposed when a client does not meet the entitlement conditions for one of the following reasons:

- The child’s date of birth or date (DOB) of placement is not indicated.

- There is no proof of placement for the purposes of adoption.

- There is no statement of the intent to care for the child.

- The client stops caring for the child during the PW.

A 35 - Parental benefits, qualifying conditions not met disentitlement (D35) is imposed for one of the following reasons:

- The client is minor attached (has fewer than 600 hours of insurable employment during the qualifying period [QP]).

- The parental benefits are exhausted.

- The maximum combination of special benefits has been paid.
         [maximum combination of special benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml#special)

- The maximum combination of regular and special benefits has been paid.
         [maximum combination of regular and special benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml#combine)

- The claim was not made during the PW.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2720.dita) 

### Contentious issues

Source topic: `en_EN/task/renew_pb/contentious_issues.dita`

When renewing a claim, a client may report a new contentious issue that must be adjudicated, such as reason for separation (RFS), farming or availability. If the contentious issue is reported on the application, the system creates an Adjudication Issue (ADJ) WI. If a contentious issue is detected while reviewing the claim, the Level 1 officer creates an ADJ WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If unable to create an ADJ WI, the officer creates a CR WI. For more information on the required type of WI, the officer refers to Creation of a WI for a contentious issue .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Creation of a WI for a contentious issue](/en/procedure/generic/additionalresources/creation_wi_ci.shtml)

For more information, the officer refers to Determining if a claim is ready to be renewed or converted .
       [Determining if a claim is ready to be renewed or converted](/en/procedure/task/determ_claim_demande_ren_conv.shtml) 

### Deferred reason for separation (RFS)

Source topic: `en_EN/task/renew_pb/deferred_reason_for_separation_rfs.dita`

Sometimes, when clients ask for a claim to be renewed, fact-finding and adjudication of the RFS can be deferred. For more information, the officer refers to Deferral of adjudication .
       [Deferral of adjudication](/en/procedure/activity/deferral_adj.shtml) 

### Effective date of a renewal

Source topic: `en_EN/task/renew_pb/effective_date_of_a_renewal.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer refers to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml)

**Renewal week required**

A renewal week is required when changing the claim type (CT) to 4 - Maternity or parental , 14 - Standard parental , 16 - Extended parental , 74 - Self-employed - Maternity , 75 - Self-employed - Standard parental or 79 - Self-employed - Extended parental . If no renewal week is input for these CTs on conversions, the transaction is rejected with error code 242 . 

### Claim in MPS

Source topic: `en_EN/task/renew_pb/claim_in_mps.dita`

When the claim is in MPS with claim status (CS) 8 - Converted to Manual Pay , the officer sends an Operational Centre Memo (MM06) transaction to IPOC to renew the claim. If the claim is in MPS, it stays in MPS for the remainder of the BP and the client must complete paper claimant’s reports, unless the client requests an exemption from reporting and is entitled to it. For more information, the officer refers to Exemption from reportin g.
       [Exemption from reportin](/en/procedure/activity/exemption_reporting.shtml)

When inputting the MM06, the officer ensures that all information required for the renewal is included. This includes the renewal week, the claim type (CT), claimant’s reports (if the information is available), the APW, the parental start week, the number of additional weeks being requested, the total entitlement weeks (already paid + additional weeks being requested), the Natural/Adoption code, the Waiting period code, the NO-CR-CODE, any required allocations, BP extensions, disentitlements, etc. If there is any outstanding ADJ or AI WIs and a decision on a contentious issue is required, the Level 1 officer waits for their completion before sending the MM06 to IPOC. 

### Maximum combination of regular and special benefits

Source topic: `en_EN/task/renew_pb/maximum_combination_of_regular_and_spec_7bee3d77.dita`

When regular and special benefits are combined, the maximum number of weeks payable is the equivalent of 50 weeks paid or deemed paid at the basic benefit rate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2653.dita) 

When the client has received both extended parental benefits and regular benefits, weeks in which no benefits are paid to the client are deemed to be weeks for which benefits were paid at the basic benefit rate. 

### Renewing a claim for extended parental benefits when regular benefits have been paid

Source topic: `en_EN/task/renew_pb/renewing_a_claim_for_extended_parental__88a9243a.dita`

When renewing a claim for parental benefits on which the client has also received regular benefits, the officer inputs the transactions directly in FTS. No action is required from IPOC as long as CPS has paid fewer than 50 weeks of benefits. When 50 weeks of combined regular and special benefits are paid through CPS, an error is generated. The officer actioning the error refers to Actioning a rejected transaction — Error codes C725 and C726 and manually calculates the number of weeks that may still be payable to the client along with any necessary extension of the BP. IPOC processes any remaining weeks of entitlement in MPS.
       [Actioning a rejected transaction — Error codes C725 and C726](/en/procedure/task/actioning_rt_c725_c726.shtml) 

### Subsequent claim

Source topic: `en_EN/task/renew_pb/subsequent_claim.dita`

The renewal application can be used to establish a subsequent claim when the following conditions are met:

- The claim is renewed with 4 or fewer weeks of benefits remaining in the BP.

- The client has worked enough hours to establish a new claim.

If the Claim Assessment (CA) WI for a renewal or subsequent initial claim is finalized within 28 calendar days of the renewal application, ACP can register the subsequent claim.

When ACP cannot register the subsequent claim because the renewal is not processed within 28 days of the renewal application (i.e. REN WK not found or no match and polling limit exceeded is displayed on the Processing Activities tab) or when the claim was converted to MPS, the officer processing the CA Renewal WI must create a Reminder (REM) WI for the subsequent claim to be registered. 

### Claim action status and processing of the claim

Source topic: `en_EN/task/renew_pb/claim_action_status_and_processing_of_the_claim.dita`

The Claim action status Renewal is created when a renewal decision is registered. There are 3 Claim action statuses that may be displayed:

- In Progress (Automation) is displayed on the Client information tree when there are one or more outstanding adjudication issues.

- In Progress (Manual) is displayed on the Client information tree when there are no outstanding ADJ WI and there is an outstanding CA or Specialized Application (SA) WI.

- Finalized is displayed on the Client information tree when all ADJ WIs are completed and the renewal week has been successfully input. 

### Completing the WI

Source topic: `en_EN/task/renew_pb/completing_the_wi.dita`

If the Level 1 officer cannot adjudicate the issue, the WI is referred to Level 2 for adjudication. When an ADJ WI is created on a renewal claim, either manually or by the system, the system automatically imposes a 2 - Contentious renewal in automation manual action (MA02) to prevent payment of benefits until the contentious issue is adjudicated and the renewal is complete. When the ADJ WI is completed, the system removes the MA02. An officer cannot remove an MA02.

The Level 1 officer who refers the file to Level 2 for adjudication must:

- initiate fact-finding;

- input the conversion;

- reassign the WI.

When opening an ADJ WI, the officer must always verify if there is a Resolve Issue tab. If there is a Resolve Issue tab, the officer documents the decision directly in the ADJ WI by completing all mandatory screens. When the ADJ WI is completed, NWS creates a record of decision (ROD) based on the Resolve Issue screens.

When the renewal is finalized, the system also generates the required transactions (e.g. signature code, disentitlement) based on the Resolve Issue screens. If a disentitlement or indefinite disqualification is imposed, the system creates a Correspondence (COR) WI for the D-01-00-00 letter. This means that the officer with the CA or SA WI has no action to perform for these ADJ WIs.

If there is no Resolve Issue tab for the ADJ WI, the officer with the ADJ WI creates a ROD, generates the required transactions and sends the appropriate letter. If there is an outstanding CA or SA WI when the officer completes the ADJ WI, a client Note is created and the officer with the CA or SA WI follows the instructions to input the transactions or send the letter. 

### Communicating the decision

Source topic: `en_EN/task/renew_pb/communicating_the_decision.dita`

When the only transaction input is the renewal of the BP, communication of the renewal decision is not necessary. When another decision (i.e. a disentitlement, a disqualification or an allocation of earnings) is input at the time of the renewal, communication of the renewal decision is necessary. When this occurs, the officer renewing the claim is responsible for communicating the decision. 

### Fraud indicators

Source topic: `en_EN/task/renew_pb/fraud_indicators.dita`

When the officer suspects that the application is fraudulent, the officer refers to Creating or reassigning a WI — Integrity before proceeding in this procedure.
       [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

For more information, the officer refers to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Suspicious ROEs

Source topic: `en_EN/task/renew_pb/suspicious_roes.dita`

Many fraudulent applications have been submitted with suspicious ROEs and could have been used to calculate a client’s claim. The following are some indicators that an ROE may be suspicious:

- The employer name or occupation on the ROE does not match other ROEs in RCM (e.g. the client’s employment history is with the School District 123, but an ROE is received from a plumbing company).

- The employer name on the ROE does not match the employment information provided by the client on previous applications.

- The employer name on the ROE does not match the last employer on the initial application.

- The employer name indicated as the last employer on the initial application is a large well-known corporation, but the name indicated on the ROE (block 4 - Employer’s name ) is a person’s name (e.g. the last employer on the application is Wal-Mart, but the employer on the ROE is John Doe).

- The ROE is a paper ROE issued by a large company that normally issues electronic ROEs (or vice versa). 

### No fraud indicators present on renewal application — 71 - Integrity Services case manual action (MA71) imposed

Source topic: `en_EN/task/renew_pb/no_fraud_indicators_present_on_renewal__82acd80b.dita`

When a previous initial application is potentially fraudulent, an MA71 was imposed, no benefits were paid, and a renewal application with no fraud indicators is received, the officer:

- creates an IPOC Review (IPOC REV) Claim removal WI for the IPOC officer to remove the claim from the client’s file.

- creates an SROC to document the action taken;

- refers to the calculation procedures to process the client’s application as a new initial claim.

When a previous renewal application is potentially fraudulent, an MA71 was imposed, no benefits were paid, and a subsequent renewal application with no fraud indicators is received, the officer:

- inputs the return to work (RTW) date equal to the first day of the appropriate week;

- rescinds the MA71;

- creates an SROC to document the action taken;

- processes the renewal for the client.

The officer verifies whether any suspicious ROEs are under investigation by entering the business number (BN) in RMDS. If a BN is under investigation and the ROE is still on file, the officer deletes the ROE.

If benefits were paid on the potentially fraudulent application, the officer notifies Integrity that the client’s claim is blocked due to an MA71 and moves the CA WI to Pending until the investigation is complete.

If a suspicious ROE was used to calculate the client’s claim, the officer notifies Integrity about this and indicates that the client has submitted a renewal application. The officer then moves the CA WI to Pending until the investigation is complete.

To notify Integrity that a client’s claim is blocked due to an MA71, or that a suspicious ROE was used in the initial calculation, the officer creates an urgent AI WI so that the investigation can be prioritized. 

### Note

Source topic: `en_EN/common_notes/note_c_4433.dita`

Note:

The Parental Benefits Validation screen only displays linked SINs. The other parent’s SIN provided on AW or MSCA or input in FTS is not displayed on the screen until it has been linked to the other parent’s SIN by the parental benefits validation process, which only occurs once the claims are finalized. 

### Note

Source topic: `en_EN/common_notes/note_c_0139.dita`

Note:

FTS does not display the Parental Benefits Validation screen for claims filed before September 28, 2019 as they do not have a Parental Client Record. The parental benefits validation process cannot validate these claims. If the officer inputs a Renewal/Revised (M106) transaction with parental information on these claims on or after September 30, 2019 a Parental Client Record is created. 

### Note

Source topic: `en_EN/common_notes/note_c_2717.dita`

Note:

This is necessary because the Parental Benefits Validation transaction is not accessible until the Parental Client Record is created (after the parental benefits inputs are processed). 

### Note

Source topic: `en_EN/common_notes/note_c_2774.dita`

Note:

If a client has been found responsible for a violation for an earlier claim, an increased number of hours may be needed to qualify for parental benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_0877.dita`

Note:

Under certain conditions, the PW can be extended to allow the client more time to collect weeks of entitlement. 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_4434.dita`

Note:

A client cannot receive 2 different types of parental benefits in the same BP for multiple APW. When a different type of parental benefit must be paid, a new BP must be established. 

### Note

Source topic: `en_EN/common_notes/note_c_4435.dita`

Note:

If the conditions are met (the officer refers to Exemption from reporting ), a client receiving parental benefits on a subsequent PW through MPS can be exempt from reporting.
       [Exemption from reporting](/en/procedure/activity/exemption_reporting.shtml)

     [Exemption from reporting](/en/procedure/activity/exemption_reporting.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2720.dita`

Note:

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure. As a result, the officer does not impose a D35 on claims with a BPC between w/c 2310 and w/c 2361 when the client has accumulated the required number of hours in the QP. However, the officer still determines if a D35 should be imposed for any other reason listed above. 

### Note

Source topic: `en_EN/common_notes/note_c_2653.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

## Regional considerations

Source topic: `en_EN/task/renew_pb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/renew_pb/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/renew_pb/in_nws.dita`

- What type of parental benefits is the client requesting and how many weeks of parental benefits is the client requesting?

- Has the client worked since the last week paid?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, monies on separation, motor vehicle accident compensation, workers’ compensation benefits (WCB) or wage loss insurance (WLI) payments to consider or allocate?

- Is there an ADJ WI?

- If yes, for what issues?

- Is the date of birth (DOB), arrival or placement provided?

- Is the SIN of the other parent provided?

- Are the parents sharing parental benefits?

- Is the number of requested parental weeks specified?

- Is there an electronic questionnaire or an SROC with the other parent’s SIN? 

### In FTS:

Source topic: `en_EN/task/renew_pb/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- Has the last renewable week (LRW) been reached?

- Has the waiting period (WP) been served, waived or deferred?

- Is there a registration number?

- Is there an MA71? 

### In RCM:

Source topic: `en_EN/task/renew_pb/in_rcm.dita`

- Is there an ROE on file?

- Are there earnings, monies on separation, motor vehicle accident compensation, WCB or WLI payments to consider or allocate?

- Are there any suspicious ROEs? 

### In Imaging:

Source topic: `en_EN/task/renew_pb/in_imaging.dita`

- Is there any other documentation which may impact the renewal claim?

- Is there documentation with the other parent’s SIN? 

## Step by step

Source topic: `en_EN/task/renew_pb/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/renew_pb/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/renew_pb/reviewing_the_file_level_1.dita`

- Determine if one of the following situations applies:

- In FTS, the client’s residential address is in Quebec and no EI maternity or parental benefits have been paid for the same BPC.

- In NWS, the client indicated on the EI application on the Maternity or parental: INS5168 Annex 3 — Form or in the details on file one of the following:

- The client received QPIP benefits in the last 2 years or will receive QPIP benefits.

- The other parent has received, is receiving or will receive QPIP benefits.

- If no, go to step 2.

- If yes, go to Reassigning the WI .
               [Reassigning the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_pb#level1_item_9)

- In FTS, determine if there is a registration number:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- Determine if the maximum combination of regular and special benefits has been paid:

- If yes, go to Maximum combination of regular and special benefits paid .
               [Maximum combination of regular and special benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_pb#maxcombinedpaid)

- If no, determine if the maximum number of weeks of parental benefits have been paid for the birth or placement:

- If no, go to step 4.

- If yes, go to Maximum parental benefits paid .
                   [Maximum parental benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_pb#maxpaid)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- Determine if the WP must be served:

- If no, go to step 7.

- If yes, refer to Cancelling a benefit period and go to step 5.
               [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml)

- Determine if the client requested the deferral of the WP:

- If yes, go to step 6.

- If no, go to step 7.

- Determine if the conditions to defer the WP have been met:

- If no, go to step 7.

- If yes, note that a WP deferral must be input with the transactions. Go to step 7.

- In NWS and FTS, determine if one of the following conditions is met to extend the BP:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4436.dita)

- Determine the renewal week. Refer to Determining the effective date of a renewal or a conversion .

- Based on the Claim duration section of the Rate/Duration tab in FTS, determine if one of the following conditions is met:

- The client is requesting benefits before the end of the week displayed in the Latest renewable week field.

- The client is requesting special benefits before the end of the week displayed in the End of the initial benefit period field.

- The client is requesting special benefits after the end of the week displayed in the End of the initial benefit period field, but is entitled to an automatic extension of the BP and is requesting special benefits before the end of the extended BP.

- If any condition is met, go to step 10.

- If none of the conditions is met, go to Last renewable week (LRW) has been reached. .
                   [Last renewable week (LRW) has been reached.](/en/procedure/task/renew_pb.shtml#LRW)

               [extension of the BP](/en/procedure/activity/extension_benefit_period.shtml)

- Based on the renewal week, determine if the first week for which parental benefits could be payable is within the PW:

- If yes, go to step 11.

- If no, go to Benefits requested outside of the parental window (PW) .
               [Benefits requested outside of the parental window (PW)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_pb#outsideparentalwindow)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4437.dita)

- Determine if adjudication of entitlement to parental benefits is required (e.g. the parents are disputing how they wish to share the parental benefits):

- If no, go to step 12.

- If yes, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Availability .

- Details: Type “Adjudication of entitlement to parental benefits required.”

- Determine if there are any other outstanding issues that require adjudication:

- If no, go to step 13.

- If yes or uncertain, refer to Determining if a claim is ready to be renewed or converted . Go to step 13.
               [Determining if a claim is ready to be renewed or converted](/en/procedure/task/determ_claim_demande_ren_conv.shtml)

- Determine if there is an outstanding ADJ WI for entitlement to parental benefits (e.g. the parents are disputing how they wish to share the parental benefits):

- If yes, go to step 14.

- If no, go to step 16.

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting adjudication of entitlement to parental benefits.”

- Bring forward date: Enter the date the ADJ WI was created for the entitlement issue + 10 business days.

- When the WI moves to the current workload, determine if the issue has been adjudicated:

- If no, return to step 14.

- If yes, go to step 16.

- Determine the parental start week, the type and the number of parental weeks the client is entitled to.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4438.dita)

- Determine if either condition requiring an Operational Centre Memo (MM06) is met:

- A subsequent PW is required in the BP and parental entitlement weeks have already been paid during the BP.

- Extended parental benefits have been paid and the CT is not currently extended parental benefits.

- If yes, go to step 18.

- If no, go to step 19.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select the appropriate option:

- If the renewal did not require a Level 2 adjudication, select 1 - No .

- If the renewal required a Level 2 adjudication, select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the renewal claim.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 32 - Multiple confinement/parental .

- Remarks line 1: Type “Multiple parental periods.”

- Remarks line 2: Type “REN WK w/c [XXXX], APW w/c [XXXX], PSW w/c [XXXX], ADDTL WKS REQ [XX] (additional weeks being requested), TOTAL ENT WKS [XX] (already paid + additional weeks being requested), Natural/Adoption code [X], SCI 99 (for extended parental benefits, if necessary).”

- Remarks line 3: Enter the additional information regarding the claimant’s reports, NO-CR, MA rescind, D3 termination, if necessary.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select the appropriate option:

- If the renewal did not require Level 2 adjudication, select 1 - No .

- If the renewal required Level 2 adjudication, select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- Go to step 49. 

#### Inputs

Source topic: `en_EN/task/renew_pb/inputs_level_1.dita`

- In RCM, determine if there are any suspicious ROEs that have not already been deleted:

- If yes, note the BNs and go to step 20.

- If no, go to step 22.

- In RMDS, determine if the BN is under investigation as follows:

- Select Paper and then select Employer .

- Business No.: Enter the BN.

- Select Search .

- Select the BN and select Open .

- When the Employer profile screen opens, determine if the Under investigation box in the lower left-hand corner is checked:

- If yes, go to step 21.

- If no, go to step 22.

- In RCM, delete the ROE with the BN that is under investigation as follows:

- Delete: Check the box.

- Additional information: Select the appropriate option:

- If the ROE was not used to calculate the client’s established claim or the fraudulent established claim, type “Suspicious ROE has been deleted to prevent it from being used in benefits calculation. If its legitimacy is confirmed, it can be restored.”

- Select Validate .

- Select Submit .

- Go to step 22.

- If the ROE was used to calculate the client’s established claim or the fraudulent established claim, type “Suspicious ROE has been deleted. If its legitimacy is confirmed, it can be restored.”

- Select Validate .

- Select Submit .

- Go to step 22.

- Depending on the situation, go to the appropriate step:

- If there are no fraudulent ROEs on file, go to step 23.

- If fraudulent ROEs were not used to calculate the client’s initial claim, go to step 23.

- If fraudulent ROEs were used to calculate the client’s initial claim, go to step 32.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If yes, go to step 24.

- If no, go to step 26.

- Determine if benefits were paid after the potentially fraudulent application was submitted:

- If yes, go to step 25.

- If no, go to step 26.

- Determine if there is an outstanding CR Integrity ERB-EI Transition WI:

- If no, go to step 26.

- If yes, check the Urgent box in the CR Integrity ERB-EI Transition WI and go to step 33.

- In FTS, determine if an MA71 was imposed: Note: Review Action Item (AI) WIs and SROCs on file to determine why the MA71 was imposed.

- If yes and it was imposed due to the fraudulent initial application and no benefits were paid, go to step 27.

- If yes and it was imposed due to the fraudulent initial application and benefits were paid, go to step 32.

- If yes and it was imposed due to a previous fraudulent renewal application and benefits were paid, go to step 32.

- If yes and it was imposed due to a previous fraudulent renewal application and no benefits were paid , go to step 35.

- If yes and it was imposed for any other reason, go to step 43.

- If no, go to step 43.

- In NWS, create an IPOC REV Claim removal WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the appropriate IPOC based on the region of the claim in FTS:

- Atlantic: 1826

- Quebec: 2642

- Ontario: 3056

- Western Canada and Territories: 5903

- End User: Select Next available user .

- Issue(s): Select Claim Removal .

- BPC: Enter the claim’s BPC.

- Comments: Type “Claim removal.”

- Details: Type “Void the BPC in w/c [XXXX]. Fraudulent application. No payments issued on the BPC.” If there is a violation on the Violation History (ML02) screen, type “Update the ML02 screen for the BPC in w/c [BPC with the violation that affects the voided BPC] and remove the BPC in w/c [voided BPC] from the affected BPCs.” Type “Advise Level 1 officer to establish the new BPC with a REM WI.”

- Obtained by: Select the appropriate option.

- Obtained from: Select the appropriate option.

- Source details: Enter the source details.

- Select Save .

- Move the CA WI to Pending as follows:

- Pending reason: Select the appropriate option.

- Comments: Type “The IPOC officer has to void the claim and create a REM WI so a new claim can be established”

- Bring forward date: Enter today’s date + 2 business days.

- When the CA WI moves to the current workload, determine if the IPOC officer has sent the REM WI to establish the claim:

- If no, repeat step 28.

- If yes, go to step 30.

- Create an SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Potentially fraudulent initial claim — claim voided.”

- Details: Type “Initial claim is potentially fraudulent. The claim has been voided and is pending an investigation.”

- In SSO, verify that the correct mainframe is selected and register the claim as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Initial .

- Select Search .

- Review the Name and Address screen:
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2168.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2647.dita) 

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: Both fields are prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: Do the following:

- If the field is blank, enter the SCC shown on the WI History tab of the CS WI.

- For a commuter claim, enter the SCC associated with the workplace postal code.

- Tax credit: This field is prefilled based on the client’s information.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: If the field is blank, enter the SCC shown on the WI History tab of the CS WI (the same one input in the Responsible SCC field).

- Service unit: Type “01.”

- Tentative BPC: If the field is blank, determine the BPC based on the client’s LDW and application date. If the registration being obtained is for a subsequent claim, select the week after the previous claim’s LRW.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select Yes to generate the Initial Intake (M149) transaction.

- Select Generate registration .
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2648.dita)

- Select Next .

- On the M149 - Initial Intake Data screen, select Update .

- Go to Determining if a claim is ready to be calculated — Parental benefits to process the client’s EI application as a new initial claim.
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- Create an AI WI for Integrity as follows:

- Urgent: Check the box.

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue(s): Select Other .

- Comments: Type the appropriate option:

- “Client blocked.”

- “Suspicious ROE used in calculation.”

- Details: Type the appropriate option:

- “The application dated [DD-MM-YYYY] was submitted by the client and is blocked by an MA71.”

- “A suspicious ROE was used in the calculation of the claim and a new application was submitted by the client.”

- Select Save .

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for investigation to end.”

- Bring forward date: Enter today’s date + 10 business days.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4439.dita)

- Once the CR Integrity ERB-EI Transition WI is complete, do the following:

- If a fraudulent initial claim has been voided and an initial claim must be established, refer to Determining if a claim is ready to be calculated — Parental benefits to process the client’s EI application as a new initial claim.
               [Determining if a claim is ready to be calculated — Parental benefits](/en/procedure/subactivity/detcalc_pb.shtml)

- If processing a renewal claim is required and the CS is 0 - Active , go to step 35.

- If processing a renewal claim is required and the CS is 8, go to step 55.

- In FTS, determine if the client’s address is correct:

- If yes, go to step 36.

- If no, update the address and go to step 36.
               [update the address](/en/procedure/activity/change_address.shtml)

- Determine if the client’s banking information is correct:

- If yes, go to step 37.

- If no, update the banking information and go to step 37.
               [update the banking information](/en/procedure/activity/direct_deposit.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4440.dita)

- To determine the RTW date, choose the appropriate option:

- If cycling claimant’s reports are on file, the RTW date is the first day of the first week of the cycling claimant’s reports.

- If there are no cycling claimant’s reports the RTW date is the first day of the next week to be processed.

- Select the Additional Data (M107) transaction and input the RTW date as follows:

- Registration number: Leave this field blank.

- Return to work: Input the RTW date as determined in step 37.

- Select Update .

- In NWS, create an SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Potentially fraudulent renewal — return to work input.”

- Details: Type “The renewal is potentially fraudulent. A return to work date has been input and the stop payment was rescinded pending an investigation.”

- In FTS, select the Renewal/Revised (M106) transaction to rescind the MA71 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 71 - Integrity Services case .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- Determine if there are cycling claimant’s reports:

- If yes, go to step 42.

- If no, go to step 43.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Renewal to be input.”

- Bring forward date: Enter the next business day.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4441.dita)

- In FTS, determine if the CS is 8:

- If no, go to step 44.

- If yes, go to step 55.

- Select the Renewal/Revised (M106) transaction and input the renewal according to the Maternity/Parental input guide as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week during which the payment of parental benefits starts.

- Earnings week 1: Type the amount (if necessary).

- Notify system to: Select E - Accept a renewal week effective after the last renewable week of the benefit period (if necessary).

- Claim type: If the CT is not currently parental benefits, select the appropriate option ( 14 - Parental standard or 16 - Parental extended ).

- Manual Action: Select [the appropriate MA, e.g. 1 - General suspension of benefits (stop payment) ] (if necessary).

- Waiting period: If the WP must be deferred, select 5 - Waiting period deferred (parental standard or extended) .

- Select the Special benefits (M106) link and input the following in the Parental section:

- If parental information is not yet input:

- Arrival/Placement Week: Enter the week of birth.

- Start week: Enter the parental start week.

- Entitlement Weeks: Enter the total number of weeks of entitlement (number of parental weeks already paid + number of additional weeks requested). This number cannot exceed the maximum parental entitlement.

- Natural/Adoption: Select the appropriate code (5, 6, 7 or 8).

                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2773.dita)

- If the last week paid is the end week of the PW in FTS:

- Start week: Enter [initial parental start week + 52 weeks].

- Entitlement Weeks: If this number requires a modification, enter the total number of entitlement weeks (number of parental weeks already paid + number of additional weeks requested). This number cannot exceed the maximum number of weeks of entitlement to parental benefits.

- Modification: Select E - Extend .

- Select Save .

- No claimant’s report: If the client is entitled to an exemption from completing claimant’s reports and the last week paid is not the end week of the PW, check the box.

- Supplementary claim information: If the client is entitled to extended parental benefits, select 99 - Parental extended .

- Contentious: Select the appropriate option:

- If the renewal did not require Level 2 adjudication, select 1 - No .

- If the renewal required Level 2 adjudication, select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions or multiple day transactions or if there is an MA02 on file, select D - No .

- Review the Maternity/Parental input guide and determine if the inputs require modifications:

- If no, select Update .

- If yes, modify the inputs based on the input guide and select Update .

               [Maternity/Parental input guide](https://esdc.prv/en/service-canada/ei/technologies/bps/maternity_parental_input_guide.shtml)

- Using the Maternity/Parental input guide , determine if multiple days are required for the parental inputs:

- If yes, go to step 45.

- If no, go to step 49.

               [Maternity/Parental input guide](https://esdc.prv/en/service-canada/ei/technologies/bps/maternity_parental_input_guide.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4442.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “2-day input required.”

- Bring forward date: Enter today’s date + 1 business day.

- When the WI moves to the current workload, determine the transaction to input on day 2:

- If the only transaction to input is the exemption from completing claimant’s reports, go to step 47.

- For multiple day transactions, go to step 48.

- In FTS, select the Renewal/Revised (M106) transaction and input the exemption from completing claimant’s reports as follows:

- Registration number: Leave the field blank.

- No claimant’s report: Check the box.

- Select Update .

- Go to step 49.

- In FTS, select the Renewal/Revised (M106) transaction and input the day 2 transaction as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- No claimant’s report: If the client is entitled to an exemption from completing claimant’s reports, check the box.

- Review the Maternity/Parental input guide and determine if the inputs require modifications:

- If no, select Update .

- If yes, modify the inputs based on the input guide and select Update .

               [Maternity/Parental input guide](https://esdc.prv/en/service-canada/ei/technologies/bps/maternity_parental_input_guide.shtml)

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions or multiple day transactions or if there is an MA02 on file, select D - No . 

#### Validating other parent’s SIN

Source topic: `en_EN/task/renew_pb/validating_other_parents_sin_level_1.dita`

- Determine if the client has provided the other parent’s SIN:

- If yes, go to step 50.

- If no, go to step 65.

- In FTS, on the Parental Benefits Validation screen, determine if the other parent’s SIN is linked to the client’s SIN:

- If no, go to step 51.

- If yes, go to step 65.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Parental validation pending processing of transactions.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, verify if all the transactions have been processed successfully:

- If no, return to step 51.

- If yes, go to step 53.

- In FTS, on the Parental Benefits Validation screen, determine if the other parent’s SIN is linked to the client’s SIN:

- If no, go to step 54.

- If yes, go to step 65.

- In FTS, in the Enquiry menu, select Parental Benefits Validation and enter the other parent’s SIN as follows:

- SIN: Enter the other parent’s SIN.

- Select Add .

- When the question Are you sure you want to add (link) this SIN? appears, select Yes .

- Select Close .

- Go to step 65. 

#### Claim in MPS

Source topic: `en_EN/task/renew_pb/claim_in_mps_level_1.dita`

- Before sending the Operational Centre Memo (MM06) transaction to IPOC, determine if a Level 2 officer must adjudicate any outstanding issues:

- If yes, go to step 56.

- If no, go to step 58.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting Level 2 decision.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if a decision has been rendered:

- If no, repeat step 56.

- If yes, go to step 58.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 30 - New information on a manual pay claim .

- Remarks line 1: Type “Input renewal w/c [XXXX], CT [XX].”

- Remarks lines 2–4: Type “APW [XXXX], PSW [XXXX], ADDTL WKS REQ [XX] (additional weeks being requested), TOTAL ENT WKS [XX] (already paid + additional weeks being requested), Natural/Adoption code [X], NO-CR-CODE (if requested by the client), WP code [X] (if necessary).” Also enter the appropriate information:

- If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].”

- If an extension of the BP is required, type “Extend BP Type [X], Start week [XXXX], Number of weeks [X].”

- If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].”

- If a disqualification must be imposed, type “D[XX] from w/c [XXXX].”

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 04 - Insurance Payment Operational Centre .

- Select Update . 

#### Communication on an MPS claim

Source topic: `en_EN/task/renew_pb/communication_on_an_mps_claim_level_1.dita`

- Determine if there is an allocation of earnings that must be communicated to the client:

- If yes, go to step 62.

- If no, go to step 63.

- In ACS, add details to the draft N-00-00-00 letter and send it, or create one and send it. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246) .

- If an antedate has been denied, select Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Special benefits approved (3046): Select Maternity and/or parental benefits (standard/extended) approved or denied with sickness options (3054) .

- Allocation of Earnings (2516) .

- Waiting period message (2445): If the client has not served the WP, select the appropriate option.

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- Go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_pb#level1_item_7)

- In NWS, determine if there is a client Note indicating to send a draft N-00-00-00 letter:

- If yes, go to step 64.

- If no, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_pb#level1_item_7)

- In ACS, review and send the draft N-00-00-00 letter. Go to Subsequent claims . 

#### Communication on an active claim

Source topic: `en_EN/task/renew_pb/communication_on_an_active_claim_level_1.dita`

- Determine if there was an allocation of earnings that must be communicated to the client:

- If yes, go to step 66.

- If no, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_pb#level1_item_7)

- In ACS, add details to the draft N-00-00-00 letter, or create one. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246)

- If an antedate has been denied, select Antedate denied or postdate Message – Initial/renewal/continuing claims (2481) .

- Special benefits approved (3046): Select Maternity and/or parental benefits (standard/extended) approved or denied with sickness options (3054) .

- Allocation of Earnings (2516)

- Waiting period message (2445): If the client has not served the WP, select the appropriate option.

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, determine if there is an outstanding ADJ WI for Level 2:

- If no, go to step 68.

- If yes, save the N-00-00-00 letter and go to step 69.

- In ACS, send the N-00-00-00 letter and go to Subsequent claims .

- In NWS, create a client Note and type “Send the draft N-00-00-00 letter.” 

#### Subsequent claims

Source topic: `en_EN/task/renew_pb/subsequent_claims_level_1.dita`

- In NWS , determine if there are 4 or less weeks remaining to be paid in the BP:

- If yes and the CS is 0, go to step 71.

- If yes and the CS is 8, go to step 72.

- If no, go to step 73.

- Determine if the renewal was finalized within 28 days of the renewal application being filed (i.e. application date + 27 calendar days):

- If no, go to step 72.

- If yes, go to step 73.

- Create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Subsequent claim not automated.”

- Due date: Select the LRW + 3 weeks.

- Details: Type “Subsequent claim to be established.”

- Destination: Select the SCC shown in FTS.

- End User: Select Next available user .

- Complete the CA WI. 

#### Maximum combination of regular and special benefits already paid

Source topic: `en_EN/task/renew_pb/maximum_combination_of_regular_and_spec_5cf2309f_level_1.dita`

- In NWS, determine if the client has worked since the BPC:

- If no, go to step 2.

- If yes, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D35 imposed — maximum combination of benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as no hours were accumulated after BPC. D35 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as [number of hours] were accumulated after BPC and the client needed [number of hours] to qualify. D35 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D35 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Action: Select Add .

- Disentitlement: Select 35 - Parental benefits, qualifying conditions not met .

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Parental benefits denied or suspended - D34/D35/D56/D57/Free text (3074) .

- Text: Explain why Parental benefits not payable .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Text - Insert appropriate reason(s) (1618): Type: “You have received the maximum number of benefits weeks payable to you during this benefit period. The maximum number of benefit weeks paid on this claim cannot exceed a total of [the maximum number of regular and special benefit weeks that can be paid] weeks. To receive benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you must apply for a new claim.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Maximum parental benefits already paid

Source topic: `en_EN/task/renew_pb/maximum_parental_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type: “No parental benefits paid — parental benefits exhausted.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type: “No renewal is possible as the maximum entitled parental benefits has been paid. The client does not qualify for a new claim as no hours were accumulated after BPC. No renewal.”

- If the client has worked since the BPC , type: “No renewal is possible as the maximum entitled parental benefits has been paid. The client does not qualify for a new claim as [number of hours] were accumulated after BPC and the client needed [number of hours] to qualify. No renewal.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D35 and the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the appropriate Sunday.

- Earnings week 1: Type the amount (if necessary).

- Action: Select Add .

- Disentitlement: Select 35 - Parental Benefits - Qualifying Conditions Not Met .

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Parental benefits denied or suspended - D34/D35/D56/D57/Free text (3074) .

- Select D35 - Not qualified or entitled (various reasons) (3077) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the CA WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/renew_pb/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “Last renewable week reached - parental benefits requested.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type: “No renewal is possible as the has been reached and no benefit period extension is possible. The client does not qualify for a new claim as no hours were accumulated after BPC.”

- If the client has worked since the BPC , type: “No renewal is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as [number of hours] were accumulated after BPC and the client needed [number of hours] to qualify.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type: “We cannot reactivate your claim EI benefits starting [renewal week - Sunday’s date] . Please note that we are required to advise you of all decisions made on your claim. No parental benefits are payable to you on this claim because the last renewable week has been reached on this benefit period. To receive parental benefits, you must work the required minimum number of insurable employment hours. If you want to receive parental benefits in the future, you must apply for a new claim.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the CA WI. 

#### Benefits requested outside of the parental window (PW)

Source topic: `en_EN/task/renew_pb/benefits_requested_outside_of_the_paren_72cc13a6_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “D35 imposed: Parental Benefits - qualifying conditions not met.”

- Details: Type “Client requests parental benefits outside of the parental window. D35 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D35 and the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week in which the client wants the parental benefits to start being paid.

- Earnings week 1: Type the amount (if necessary).

- Claim type: Select 2 – Regular .

- Action: Select Add .

- Disentitlement: Select 35 - Parental Benefits - Qualifying Conditions Not Met .

- Start: Select the Monday of the week in which the client wants the parental benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Parental benefits denied or suspended - D34/D35/D56/D57/Free text (3074)

- D35 - Not qualified or entitled (various reasons) (3077)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the CA WI. 

#### Reassigning the WI

Source topic: `en_EN/task/renew_pb/reassigning_the_wi_level_1.dita`

- In NWS, reassign the CA WI and the following related WIs, if necessary (Call Back [CB], AI and REM) as follows:

- Destination: Select Level 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC/QPIP .

- Reason: Select Unable to complete .

- Details: Type “Decision required to determine whether EI or QPIP applies.”

- Select OK .

- No further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4436.dita`

- The client was incarcerated and has since been tried and not found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- The child for whom parental benefits are claimed was hospitalized during the PW.

- If one of the conditions is met, refer to Extension of the benefit period and go to step 8.
             [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions are met, go to step 8. 

#### Note

Source topic: `en_EN/common_notes/note_c_4437.dita`

Note:

In order to determine if that week is within the PW, consider the PW, earnings that may prevent the payment of benefits, and, if necessary, when the WP will be served. 

#### Note

Source topic: `en_EN/common_notes/note_c_4438.dita`

Note:

In order to determine the number of parental weeks the client is entitled to, consider the following:

- number of weeks requested

- type of parental benefits the client is entitled to

- PW

- BP

- RTW (if available)

- WP (if one will be served)

- number of weeks the other parent is entitled to (if available) 

#### Note

Source topic: `en_EN/common_notes/note_c_2168.dita`

Note:

The information from the application in NWS is automatically downloaded in SSO. In rare cases, the information is not downloaded and must be manually input. Verify (and correct, if necessary) any prefilled fields with the information provided on the application. 

#### Note

Source topic: `en_EN/common_notes/note_c_2647.dita`

Note:

When the client has only one name, one of the name fields on the Name and Address screen may be empty or contain a non-alphabetical character. However, SSO does not allow the field to be completed in this way.

When a name field is empty or contains a non-alphabetical character, do the following:

- First Name: Enter the appropriate option:

- For a client who selects the Male gender marker, type “Mr.”

- For a client who selects the Female gender marker, type “Ms.”

- For a client who selects X as the gender marker, type “N.A.”

- Last Name: Enter the client’s name.

When the First Name field on the Name and Address screen is modified to “N.A.”, modify the Initial Intake (M149) or Name and Address Change / Transfer (M159) transaction generated by the calculation and type “.” in the First Name field before transmitting it. 

#### Note

Source topic: `en_EN/common_notes/note_c_2648.dita`

Note:

At this step, a registration number is assigned to the claim. If Yes is selected, the Initial Intake (M149) transaction is automatically generated.

If No is selected, the Initial Intake (M149) transaction is not generated. 

#### Note

Source topic: `en_EN/common_notes/note_c_4439.dita`

Note:

When the investigation is complete, a CR Integrity ERB-EI Transition WI is created. In the CR Integrity ERB-EI Transition WI, ensure that the Urgent box is checked. Do not process the CA WI until the CR Integrity ERB-EI Transition WI related to the potentially fraudulent application has been completed . If the following WIs are outstanding, do not process the CA WI until they are completed:

- IPOC Manual Pay (IPOC MPS) Third party fraud WI

- IPOC Overpayment (IPOC O/P) Third party fraud 

#### Note

Source topic: `en_EN/common_notes/note_c_4440.dita`

Note:

In FTS, ensure that the correct address and banking information are on file (update the information, if necessary). Ensure also that the client’s name, language and gender are correct. If there is a fraudulent claim in another information technology centre (ITC), update the information in both ITCs. 

#### Note

Source topic: `en_EN/common_notes/note_c_4441.dita`

Note:

The next business day, the cycling claimant’s reports will show error code C420: WARNING - Claim status changed to 02 (found work) on the Pending/reject tab. Delete the rejected transactions on the Rejected Transactions Retrieval (MR05) screen. 

#### Note

Source topic: `en_EN/common_notes/note_c_2773.dita`

Note:

If the client is a legally recognized parent on the child’s birth certificate, select the appropriate natural parent sex code options. 

#### Note

Source topic: `en_EN/common_notes/note_c_4442.dita`

Note:

If there is a previous renewal application from the client that was suspended, the information from that application is used to determine the renewal week and any allocations that apply. 

## Policy reference

Source topic: `en_EN/task/renew_pb/policy_reference.dita`

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- EIA 12(6)
         [EIA 12(6)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 23 (1)
         [EIA 23 (1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-23.html) 
