# Adjudicating periods of leave — Lay days and other work patterns

Source map: `en_EN/task/adjucating_leave_laydays/adjucating_leave_laydays.ditamap`

## Summary

Source topic: `en_EN/task/adjucating_leave_laydays/summary.dita`

Summary: Many employers provide various work patterns to employees to maximize production and to ensure continuity of the business. In some cases, employees are entitled to a period of leave to compensate for excessive time worked and the issue must be adjudicated at Level 2. 

## What you need to know

Source topic: `en_EN/task/adjucating_leave_laydays/what_you_need_to_know.dita`

### Defining a week of unemployment

Source topic: `en_EN/task/adjucating_leave_laydays/defining_a_week_of_unemployment.dita`

To be entitled to benefits, the week a client is requesting benefits must be considered a week of unemployment. A week of unemployment is a week in which the client does not work a full work week (FWW). 

### Defining full-time employment

Source topic: `en_EN/task/adjucating_leave_laydays/defining_full-time_employment.dita`

For the purpose of lay days, full-time employment is defined as the normal number of hours of work that is considered full-time employment in the client’s province or territory of work. This means full-time employment in general, not just for that specific category of work. The officer refers to Normal number of hours worked per week in full-time employment by province or territory to determine what is considered full-time employment in the province or territory of work.
       [Normal number of hours worked per week in full-time employment by province or territory](/en/procedure/generic/additionalresources/normal_hours_week.shtml) 

### Determining entitlement to lay days

Source topic: `en_EN/task/adjucating_leave_laydays/determining_entitlement_to_lay_days.dita`

Once it is determined what is considered as full-time employment in the client’s province or territory of work, the officer can identify if the client is entitled to lay days by answering the following questions:

- Is there an agreement between the employer and employee regarding the work pattern?

- Does the client work more hours in a week than what is considered as full-time employment in the province or territory in which the client works?

- If the client works more hours, is the client compensated for the extra time worked with a period of leave ? 

### Determining work patterns — Increased number of hours worked per week

Source topic: `en_EN/task/adjucating_leave_laydays/determining_work_patterns__increased_nu_b7ca88a6.dita`

Many employers have developed work patterns in which employees work excessive hours in a work week and are compensated for the excessive hours with a period of leave.

Common examples of these work patterns are:

- 2 and 1: 12 hours per day, 7 days per week for 2 weeks followed by one week off;

- 3 and 1: 10 hours per day, 7 days per week for 3 weeks followed by one week off.

In these situations, employers normally have employees on varying rotational patterns to ensure that work continues during periods of leave for employees.

Determining if a pattern of excessive hours followed by a period of leave exists does not depend on the formal contractual relationship between an employer and employee. The pattern does not have to be established on a regular and weekly basis but there should be an element of predictable repetition. The fact that the work pattern is in place is sufficient to proceed with determining if the client is not unemployed. 

### Defining period of leave (lay days)

Source topic: `en_EN/task/adjucating_leave_laydays/defining_period_of_leave_lay_days.dita`

A client is considered to be on a period of leave (lay days) when both of the following conditions are met:

- The client regularly works a greater number of hours in each week than individuals who have a full-time employment in the client’s province or territory of employment.

- The client is entitled to a period of leave under an employment agreement (contract of service) as a way to compensate for the extra time worked.

When both conditions are met and the period of leave (lay days) falls within the period of employment, clients are considered to have worked a FWW, are not unemployed and are not entitled to benefits for any weeks during which they are on leave (lay days).

The term used to describe the period of leave (i.e. lay days, shore days, period of leave) and whether the client is being paid during the period of leave do not have any impact on how the issue is adjudicated.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1688.dita) 

### Other work patterns with a period of leave — Normal weekly hours

Source topic: `en_EN/task/adjucating_leave_laydays/other_work_patterns_with_a_period_of_le_d518ec4b.dita`

In some work arrangements, clients work one week and are off the following week, even though they work the same number of hours as individuals who have a full-time employment.

In these situations, it is difficult to consider a client as not unemployed. The officer must adjudicate the availability issue for the week the client is not working.

     [Example of a regular work pattern without increased hours](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1689.dita) 

### Interruption of earnings (I of E)

Source topic: `en_EN/task/adjucating_leave_laydays/interruption_of_earnings_i_of_e.dita`

Whether the client is paid for the period of leave or not, an I of E only occurs after the end of the period of leave (lay days) if the client does not return to work for that employer.

When a client loses entitlement to lay days due to a layoff or separation, an I of E occurs at the time of the separation from employment. 

### Allocation of earnings

Source topic: `en_EN/task/adjucating_leave_laydays/allocation_of_earnings.dita`

If the client is not able to take the period of leave due to a layoff or separation, the officer must determine if the client is entitled to monies instead of the period of leave. If it is not the case, the client cannot be considered not unemployed as of the week of the layoff date. An imposed 1 - Not unemployed disentitlement (D1) would be terminated at the end of the last week worked.

If the client is entitled to monies instead of the period of leave, and the monies are paid or payable due to the layoff or separation, they are considered earnings and must be allocated. The monies are allocated as with any other monies paid due to layoff or separation. In this case, the normal weekly earnings are based on the client’s actual work week. The officer refers to Allocating monies on separation to allocate the monies in this situation.
       [Allocating monies on separation](/en/procedure/task/all_monies_sep.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0094.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1690.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1691.dita) 

### Imposing a disentitlement

Source topic: `en_EN/task/adjucating_leave_laydays/imposing_a_disentitlement.dita`

When the officer determines that the client is not unemployed due to lay days, a D1 disentitlement is imposed. When the start or end of a period of leave is a partial week, a D1 is imposed for the entire week. 

### Information reported after claimant’s reports have been processed

Source topic: `en_EN/task/adjucating_leave_laydays/information_reported_after_claimants_re_82afb561.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Processing of an initial or renewal claim

Source topic: `en_EN/task/adjucating_leave_laydays/processing_of_an_initial_or_renewal_claim.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) .

When the Claim action status is In Progress , all Adjudication Issue (ADJ) WIs must be completed before the system can calculate the initial claim or finalize the renewal claim. The 2 - Contentious Renewal in Automation manual action (MA02) is removed by the system. 

### Communicating the decision

Source topic: `en_EN/task/adjucating_leave_laydays/communicating_the_decision.dita`

If a letter of decision is required on an initial or renewal claim, before completing the ADJ WI, the officer creates a Correspondence (COR) Manual Decision WI indicating the details of the required letter. If a letter of decision is required on a continuing claim, the officer sends the letter before completing the WI. 

### Info

Source topic: `en_EN/common_notes/note_c_1688.dita`

**Example of a lay day work pattern**

- ABC Trucking has 2 trucks and employs 4 drivers.

- The employees have a verbal agreement with the employer to work one week out of every 2 on an alternating basis.

- The employees are not compensated by the employer for the week they do not work.

- This work arrangement ensures that the trucks are always moving, thereby maximizing the profit the employer generates.

- The employees work an average of 50 hours during the week they work.

- The employer issues ROEs to the employees at the end of each week because they are not scheduled to work the following week. The reason for separation is shortage of work, with an expected return to work of the following week.

- The Employment Standards Act for the province of work indicates that 40 hours per week is considered as full-time employment.

- Since the employees are not working every second week and are not paid for those weeks, they request EI benefits for the week they do not work.

In this case, EI benefits are not payable for the weeks the clients do not work because they meet all the following conditions:

- Every week, they regularly work more hours than a person employed in full-time employment.

- They are entitled to a period of leave under an employment agreement to compensate for the extra time worked.

- There is an agreement in place with the employer for this pattern of work. 

### Example of a regular work pattern without increased hours

Source topic: `en_EN/common_notes/note_c_1689.dita`

Example of a regular work pattern without increased hours

- There are 2 co-workers who are employed in companion home care, caring for an elderly client.

- The employees alternate working 35 hours one week, followed by a week off.

- The employees and employer have agreed to this type of work schedule.

- The Employment Standards Act for the province of work indicates that 40 hours per week is considered as full-time employment.

- Since the employees are not working every second week and are not paid for those weeks, they request EI benefits for the week they do not work.

In this case, there is an agreement between the employer and employees regarding the work pattern; however, the employees do not work excessive hours and are not paid for the week they do not work.

EI benefits may be payable for the weeks the clients do not work if they can prove they meet the availability requirements during their week off. 

### Note

Source topic: `en_EN/common_notes/note_c_0094.dita`

Note:

A temporary measure under Pilot Project No. 24 applies to separation monies paid due to a separation from employment on claims with a BPC or allocation start date between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ). When separation monies are paid for that period, they are not allocated. Separation monies that are not allocated cannot extend a BP. This measure applies to all BTs for initial, renewal and continuing claims. 

### Note

Source topic: `en_EN/common_notes/note_c_1690.dita`

Note:

A Budget 2021 measure applies to separation monies that are reviewed between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361), and are paid due to a temporary layoff or a permanent separation from employment. When separation monies are reviewed during that period, they are not considered earnings and are not allocated, regardless of the BPC.

A transitional provision applies to separation monies that are reviewed on or after September 25, 2022 (w/c 2362). When the allocation start date is between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361), earnings paid or payable due to a temporary layoff or a permanent separation from employment are not considered earnings and are not applied. 

### Note

Source topic: `en_EN/common_notes/note_c_1691.dita`

Note:

Separation monies are not allocated if claims meet one of the following conditions:

- the BPC is between March 30, 2025 (w/c 2493), and October 10 , 2026 (w/c 2572 ).

- the separation monies would otherwise be allocated under EIR 36(9) to 36(11) and the first week of allocation falls within the period beginning March 30, 2025 (w/c 2493) to October 10 , 2026 (w/c 2572 ).
         [EIR 36(9)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285) 
         [36(11)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285)

- On all initial claims, the BPC is between September 27, 2020 (w/c 2258) and September 19, 2021 (w/c 2309).

- On all renewal claims, the renewal week is between September 27, 2020 (w/c 2258) and September 19, 2021 (w/c 2309). Allocations that were already in place on the initial claim being renewed in w/c 2258 or after remain in place even if the allocation goes past w/c 2258.

- On all continuing claims, the allocation start date is between September 27, 2020 (w/c 2258) and September 24, 2021 (w/c 2309).

- The separation monies are reviewed between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361), regardless of the BPC.

- The separation monies are reviewed on or after September 25, 2022 (w/c 2362) and the allocation start date is between September 26, 2021 (w/c 2310) and September 24, 2022 (w/c 2361).

This measure applies to all EI claim types (CTs) and for EI Emergency Response Benefit (EI ERB) claims.

Separation monies that are not allocated cannot extend a benefit period (BP).

     [EIR 36(9)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285) 
     [36(11)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-6.html#h-983285) 

## Regional considerations

Source topic: `en_EN/task/adjucating_leave_laydays/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/adjucating_leave_laydays/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/adjucating_leave_laydays/in_fts.dita`

- What is the claim type: initial, renewal or continuing?

- Have claimant’s reports been processed for the period in question?

- If yes, when was the original statement made?

- Is there a registration number for the not unemployed issue?

- Is there a manual action 1 - General suspension of benefits (stop payment) (MA01) on the claim for the not unemployed issue? 

### In NWS:

Source topic: `en_EN/task/adjucating_leave_laydays/in_nws.dita`

- Are there any SROCs, WIs or RODs relating to not unemployed issue? 

### In Imaging:

Source topic: `en_EN/task/adjucating_leave_laydays/in_imaging.dita`

- Are there documents related to the issue? 

## Step by step

Source topic: `en_EN/task/adjucating_leave_laydays/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/adjucating_leave_laydays/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/adjucating_leave_laydays/reviewing_the_file_level_2.dita`

- Determine if the decision can be deferred by referring to Deferral of adjudication .

- If the client is correcting previously provided information or providing previously omitted information, determine if the information may impact the client’s entitlement to benefits previously paid:

- If yes, determine if the issue should be referred to Integrity by consulting Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- If no, go to step 3.

- Determine if the following questions can be answered based on the facts on file:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1692.dita) 
           [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1693.dita) 
           [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1694.dita) 
           [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1695.dita) 

- If there is no information on file, or if it is insufficient, go to step 4.

- If all of the information is on file, go to step 7. 

#### Fact-finding

Source topic: `en_EN/task/adjucating_leave_laydays/fact-finding_level_2.dita`

- Fact-find with the client or employer. Refer to Digest 4.3.5 — Lay days or periods of leave .

- Determine if the client or employer was contacted during fact-finding:

- If the client or employer was contacted, go to step 6.

- If the client or employer was not contacted or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to Failure to provide information .
               [Failure to provide information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjucating_leave_laydays#FailureToProvide)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Lay days — [employer’s name] — [client or employer].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating not unemployed issues

Source topic: `en_EN/task/adjucating_leave_laydays/adjudicating_not_unemployed_issues_level_2.dita`

- Determine if the days not worked during a period of employment are considered lay days. Refer to Digest 4.3.5 ― Lay days or periods of leave if needed:

- If no, go to Lay days not an issue .
               [Lay days not an issue](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjucating_leave_laydays#NotAnIssue)

- If yes, go to step 8.

- Determine if the client is on a rotation pattern or if there is a stoppage of work:

- If there is a stoppage of work, go to step 9.

- If the client is on a rotation pattern, go to step 10.

- Determine if the client is paid for and entitled to the period of leave as a result of the work stoppage:

- If the client is not entitled to the period of leave but is paid for the unused lay days, go to Allocating lay days due to work stoppage .
               [Allocating lay days due to work stoppage](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjucating_leave_laydays#Lay_days_allocation)

- If the client is entitled to the period of leave (paid or unpaid) and the work stoppage occurred before or during the period of leave, go to Step 10.

- If neither of the above applies, go to No lay day entitlement due to work stoppage .
               [No lay day entitlement due to work stoppage](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjucating_leave_laydays#WorkStoppage)

- Select the applicable procedure based on the claim type:

- Disentitlement applicable for lay days — Initial claim
               [Disentitlement applicable for lay days — Initial claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjucating_leave_laydays#DEInitial)

- Disentitlement applicable for lay days — Renewal claim
               [Disentitlement applicable for lay days — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjucating_leave_laydays#DERenewal)

- Disentitlement applicable for lay days — Continuing claim
               [Disentitlement applicable for lay days — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adjucating_leave_laydays#DEContinuing) 

#### Failure to provide information

Source topic: `en_EN/task/adjucating_leave_laydays/failure_to_provide_information_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Failure to provide entitlement information.”

- Details: Type the appropriate option:

- “Messages have been left for the client on [dates]. There has been no response from the client. D15 disentitlement imposed for failure to provide entitlement information.”

- “ ACS letter sent on [date]. The client did not reply to the letter. D15 disentitlement imposed for failure to provide entitlement information.”

- Determine the claim type:

- If it is a continuing claim, go to step 8.

- If it is an initial or renewal claim, go to step 13.

- In FTS, determine if there is a registration number for the lay day issue:

- If yes, go to step 9.

- If no , select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if an MA01 is imposed for the lay day issue:

- If yes, go to step 10.

- If no, go to step 11.

- In FTS, select the Renewal/Revised (M106) transaction, rescind the MA01 and impose a D15 disentitlement as follows:

- Registration number: Select the applicable registration number.

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 15 - Claim Procedure .

- Start: Select the Monday of the next week to process.

- End: Select Indefinite .

- Contentious: Select 2 - Yes.

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Update .

- Go to step 12.

- Select the Disqualifications/Disentitlement (M161) transaction and impose a D15 disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 15 - Claim Procedure .

- Start date: Select the Monday of the next week to process.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- Select D48 and D15 — Moved — Address unknow and claim procedure (3006) .

- Select D15 - Claim procedure (3009) .

- We / In addition, we (2687)

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) and enter the date.

- Go to step 19.

- In FTS, select the Disqualifications/Disentitlement (M161) transaction and impose a D15 disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 15 - Claim Procedure .

- Start date: Select the Monday of the next week to process.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- Select D48 and D15 — Moved — Address unknown and claim procedure (3006) .

- Select D15 - Claim procedure (3009) .

- We / In addition, we (2687)

- Select I ndefinite/Definite/Multiple Disentitlement dates (2485) and enter the date.

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 17.

- If yes, go to step 19.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 18.

- If yes, go to step 19.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the Service Canada centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — lay day issue.”

- Select Save .

- In NWS, complete the WI for the lay day issue. 

#### Lay days not an issue

Source topic: `en_EN/task/adjucating_leave_laydays/lay_days_not_an_issue_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Work pattern — in order.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Refer to Adjudicating availability — Preference or restriction and reasonable period to adjudicate the client’s availability for the weeks the client does not work, and to complete the transactions and WI. 

#### Allocating lay days due to work stoppage

Source topic: `en_EN/task/adjucating_leave_laydays/allocating_lay_days_due_to_work_stoppage_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Lay days — allocation due to work stoppage.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Refer to Allocating monies on separation to allocate the lay day monies and to complete the WI. 

#### No lay day entitlement due to work stoppage

Source topic: `en_EN/task/adjucating_leave_laydays/no_lay_day_entitlement_due_to_work_stoppage_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Work stoppage — no lay day entitlement.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine the claim type:

- If it is a continuing claim, go to step 12.

- If it is an initial or renewal claim, go to step 16.

- In FTS, determine if a MA01 is imposed and if there is a registration number for the lay day issue:

- If an MA01 is imposed but there is no registration number, go to step 13.

- If an MA01 is imposed and there is a registration number, go to step 14.

- If an MA01 is not imposed but there is a revised registration number, go to step 15.

- If none of the above applies, go to step 16.

- Select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and rescind the MA01 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 16.

- If an MA01 was not imposed but there is a registration number for the lay day issue, select the Renewal/Revised (M106) transaction and complete the following fields:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Complete the WI for the lay day issue. 

#### Disentitlement applies for lay days — Initial claim

Source topic: `en_EN/task/adjucating_leave_laydays/disentitlement_applies_for_lay_days__in_a5bcb501_level_2.dita`

- In NWS, create a draft ROD as follows:

- Comments: Type “Lay days — disentitlement from w/c [XXXX-X] to [XXXX-X].”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- If fact-finding by telephone was not attempted, select Draft and go to step 12.

- If the client was reached by telephone during fact-finding, select Draft and go to step 12.

- If the client was not reached by telephone during fact-finding, select Save and go to step 13.

- Verbally communicate the decision to the client.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1696.dita)

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose a D1 disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 1 - Not unemployed .

- Start date: Select the appropriate option:

- BPC date: If the disentitlement begins at the BPC, check the box.

- If the disentitlement begins after the BPC, select the Monday of the first week of disentitlement.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 4 - An overpayment resulted in an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976) :

- Select D1 - Not unemployed (FWW/working/on salary/self employed/operating a business/controls own hours/farming/leave/questionnaire not returned) (2977) .

- Select D1 - Working full work week(s):

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- In NWS, create a client Note and type “Send the saved D-01-00-00 letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 17.

- If yes, go to step 19.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 18.

- If yes, go to step 19.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — lay day issue.”

- Select Save .

- Complete the WI for the lay day issue. 

#### Disentitlement applies for lay days — Renewal claim

Source topic: `en_EN/task/adjucating_leave_laydays/disentitlement_applies_for_lay_days__re_cd4c1f0c_level_2.dita`

- In NWS, create a draft ROD as follows:

- Comments: Type “Lay days — disentitlement from w/c [XXXX-X] to [XXXX-X].”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- If fact-finding by telephone was not attempted, select Draft and go to step 12.

- If the client was reached by telephone during fact-finding, select Draft and go to step 12.

- If the client was not reached by telephone during fact-finding, select Save and go to step 13.

- Verbally communicate the decision to the client.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1696.dita)

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose a D1 disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 1 - Not unemployed .

- Start date: Select the appropriate option:

- BPC date: If the disentitlement begins at the BPC, check the box.

- If the disentitlement begins after the BPC, select the Monday of the first week of disentitlement.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 4 - An overpayment resulted in an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976) :

- Select D1 - Not unemployed (FWW/working/on salary/self employed/operating a business/controls own hours/farming/leave/questionnaire not returned)(2977) .

- Select D1 - Working full work week(s) :

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- In NWS, create a client Note and type “Send the saved D-01-00-00 letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 17.

- If yes, go to step 19.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 18.

- If yes, go to step 19.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — lay day issue.”

- Select Save .

- Complete the WI for the lay day issue. 

#### Disentitlement applies for lay days — Continuing claim

Source topic: `en_EN/task/adjucating_leave_laydays/disentitlement_applies_for_lay_days__co_c73fa14b_level_2.dita`

- In NWS, create a draft ROD as follows:

- Comments: Type “Lay days — disentitlement from w/c [XXXX-X] to [XXXX-X].”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- If fact-finding by telephone was not attempted, select Draft and go to step 12.

- If the client was reached by telephone during fact-finding, select Draft and go to step 12.

- If the client was not reached by telephone during fact-finding, select Save and go to step 13.

- Verbally communicate the decision to the client.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1696.dita)

- In FTS, determine if there is an outstanding registration number for the not unemployed issue:

- If yes, go to step 14.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if an MA01 is imposed for the lay day issue:

- If yes, go to step 15.

- If no, go to step 16.

- In FTS, select the Renewal/Revised (M106) transaction to rescind the MA01 and impose a D1 disentitlement as follows:

- Registration number: Select the applicable registration number.

- Manual action: Select 1 - General suspension of benefits (stop payment) .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 1 - Not unemployed .

- Start: Select the Monday of the first week of disentitlement.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 4 - An overpayment resulted in an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 17.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose a D1 disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 1 - Not unemployed .

- Start date: Select the Monday of the first week of disentitlement.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 4 - An overpayment resulted in an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976) :

- Select D1 - Not unemployed (FWW/working/on salary/self employed/operating a business/controls own hours/farming/leave/questionnaire not returned)) (2977) .

- Select D1 - Working full work week(s) :

- Indefinite/Definite/Multiple Disentitlement dates (2485)

- In NWS, complete the WI for the lay day issue. 

#### Callout

Source topic: `en_EN/common_notes/note_c_1692.dita`

Is the client entitled to a period of leave to compensate for the extra time worked?

- If yes, is there an agreement between the employer and employee for the work pattern? 

#### Callout

Source topic: `en_EN/common_notes/note_c_1693.dita`

Is the employee on a rotation pattern or is there a work stoppage (layoff, separation, etc.)? 

#### Callout

Source topic: `en_EN/common_notes/note_c_1694.dita`

If there is a work stoppage, is the employee entitled to the period of leave during the work stoppage?

- If the employee is not entitled to the period of leave, is the employee compensated for lay days? 

#### Callout

Source topic: `en_EN/common_notes/note_c_1695.dita`

If there is a work stoppage, did the work stoppage occur while the employee was on the period of leave? 

#### Note

Source topic: `en_EN/common_notes/note_c_1696.dita`

Note:

If the first week of the period of leave is a partial week, the D1 disentitlement is imposed from the Monday of that week. 

## Policy reference

Source topic: `en_EN/task/adjucating_leave_laydays/policy_reference.dita`

- BE 2016-08 — Not Unemployed: Lay Days and other Work Patterns
         [BE 2016-08 — Not Unemployed: Lay Days and other Work Patterns](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2016-08.shtml)

- Digest 4 — Week of unemployment
         [Digest 4 — Week of unemployment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-4/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- EIA 11
         [EIA 11](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-11.html)

- EIR 14(3)
         [EIR 14(3)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-14.html)

- EIR 31
         [EIR 31](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-31.html)

- EIR 77.997
         [EIR 77.997](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/page-14.html#docCont) 
