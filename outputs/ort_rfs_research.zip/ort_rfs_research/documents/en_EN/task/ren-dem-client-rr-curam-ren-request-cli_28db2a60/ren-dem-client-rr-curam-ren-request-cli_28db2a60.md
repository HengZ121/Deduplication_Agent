# Renewal requested by client — Call back required — Task in Cúram

Source map: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/ren-dem-client-rr-curam-ren-request-cli_28db2a60.ditamap`

## Summary

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/summary.dita`

Summary : The task Renewal – Requested by client – Call Back Required is triggered when the client wants to renew a claim for self-employed compassionate care benefits (SE CCB). There is an active benefit period (BP) in Cúram, and the client answered yes to the question “Do you want to reactivate your existing claim?” 

## What you need to know

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/untitled_section.dita`

SE CCB provides income support to eligible clients who are absent from their self-employed work to provide care or support to a family member (patient) with a serious medical condition that poses a significant risk of death within 26 weeks.

The maximum number of weeks of CCB payable in a BP is 26 for one or more patients. Up to 26 clients can share in CCB for any one patient. A maximum of 26 weeks is payable per gravely ill family member. 

### Renewal of a SE CCB claim in Cúram

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/renewal_of_a_se_ccb_claim_in_curam.dita`

At this time, a client cannot complete the renewal questionnaire online. If the client has an active BP in Cúram and answered “yes” to the question "Do you want to reactivate your existing claim?" a task will be created in Cúram. The officer must contact the client, complete the renewal checklist Renewal: Special benefits for Self-employed People (Part VII.1 Claims) and the Special benefits: Family caregiver benefits and CCB (information and attestation) - Checklist . The officer will input the renewal week as an Evidence in Cúram and the client will be able to submit the claimant’s report.
       [Renewal: Special benefits for Self-employed People (Part VII.1 Claims)](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Renewal-Special_benefits_for_Self-Employed_People_(Part%20VII.1%20Claims)-Checklist.doc) 
       [Special benefits: Family caregiver benefits and CCB (information and attestation) - Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Special_benefits-Family_caregiver_benefits_and_CCB_information_and_attestation-Checklist.doc)

**Entitlement to CCB**

To be entitled to CCB, a client must meet the following conditions:

- The client submits an acceptable medical certificate. The doctor or nurse practitioner signing the medical certificate must attest that the patient who is a family member (as outlined in the Family member: Definition — Table ) meets both of the following conditions:

- The patient has a serious medical condition with a significant risk of death within 26 weeks.

- The patient requires care or support from one or more family members.

         [Family member: Definition — Table](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

- The client is providing care or support to the patient identified on the medical certificate.

- The client requests the benefits during the compassionate care window (CCW) established for the patient.

- The 26 payable weeks of CCB have not already been paid during the CCW for the patient. 

### Effective date of a renewal

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/effective_date_of_a_renewal.dita`

Renewal claims for self-employment benefits are effective the week the client applies for the renewal.

**Return to work (RTW)**

When an RTW week shows in Cúram, the client is prevented from submitting any claimant’s reports once the RTW week is reached. If the client changes this previously scheduled RTW week, an officer must modify the claim so that the client can submit claimant’s reports to continue to receive benefits.

The client may request a change to the RTW week by contacting the call centre or in person at a Service Canada Centre (SCC).

To determine if the conditions are met to rescind or modify the RTW, the Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error . The Level 1 officer rescinds the RTW when renewing the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer reassigns the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml)

**Compassionate care window (CCW)**

The CCW is the 52-week period during which 26 weeks of CCB are payable. The start and end dates of the CCW are based on the patient’s medical certificate. For more information, the officer refers to Determining if the compassionate care window is correctly established .
       [Determining if the compassionate care window is correctly established](/en/procedure/task/calc_determining/establish_ccw.shtml)

The CCW cannot be extended. A subsequent medical certificate may establish a new 52-week window during which CCB can be paid. However, a subsequent CCW does not change the maximum entitlement of 26 weeks payable.

**Sharing of benefits**

CCB can be shared between entitled family members at the same time or separately during the 52-week window. For more information on entitled family members, the officer refers to Family member: Definition — Table .
       [Family member: Definition — Table](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

The clients sharing the benefits must agree on the number of weeks each family member receives. Only weeks that have not yet been paid can be shared. When clients disagree on how to share the benefits, a Level 2 officer adjudicates the division of the remaining weeks.

For more information, the officer refers to Adjudicating the sharing of CCB — Renewal or continuing claim .
       [Adjudicating the sharing of CCB — Renewal or continuing claim](/en/procedure/task/deter_weeks_ccb.shtml)

**CCB and family caregiver benefits**

While CCB and family caregiver benefits can be paid during one BP, CCB cannot be paid for the same patient at the same time as family caregiver benefits. CCB can be paid before the family caregiver window (FCW) starts or after it ends but cannot be paid during an existing FCW for the same patient. The FCW does not end until the maximum number of weeks of entitlement to family caregiver benefits has been paid or >the 52-week window has ended.

**Disentitlements**

When the conditions to receive CCB are not met, the officer imposes the following disentitlements, as required:

- 51 - Does not meet compassionate care entitlement conditions (D51)

- 52 - Compassionate care benefits exhausted (D52)

- 53 - Compassionate care benefits - No medical proof (D53) 

### Contentious issues

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/contentious_issues.dita`

When renewing a claim, a client may report a new contentious issue (e.g. reason for separation [RFS], farming or availability). If a contentious issue is detected while reviewing the checklist, the Level 1 officer creates an ADJ WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If the decision is not within Level 1 authority, the officer reassigns the ADJ WI to Level 2. The WI related to an active Cúram claim must be sent to the Cúram hierarchy in NWS.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Otherwise available

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/otherwise_available.dita`

Clients do not need to prove that they would be otherwise available or otherwise working to receive CCB.

Clients who request sickness benefits during the CCW are not required to prove they would be otherwise available for work. When the sickness period extends beyond the CCW, clients must prove that they are otherwise available to work during this extension period and must provide a medical certificate indicating the start date of their incapacity and the expected recovery date. 

### Deferred reason for separation (RFS)

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/deferred_reason_for_separation_rfs.dita`

In some situations, when clients qualify for and request special benefits, fact-finding and adjudication of the contentious RFS can be deferred. For more information, the officer refers to Deferral of adjudication .
       [Deferral of adjudication](/en/procedure/activity/deferral_adj.shtml) 

### Benefit period (BP) extension

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/benefit_period_bp_extension.dita`

The BP can be extended to a maximum of 104 weeks to pay additional weeks of sickness, maternity, parental, CCB and family caregiver benefits when the client did not receive the maximum entitlement during the initial BP. For more information on BP extensions for combined special benefits, the officer refers to Benefit period extension for special benefits .
       [Benefit period extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml)

**Subsequent claim**

When a claim is renewed with 4 or fewer weeks of benefits remaining and the client has worked enough hours to establish a new claim, the renewal application can be used to establish a subsequent claim. 

### Fraud indicators

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/fraud_indicators.dita`

When the officer suspects fraudulent activity, the officer refers to Creating or reassigning a WI — Integrity before proceeding in this procedure.
       [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml) 

## Regional considerations

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/in_fts.dita`

- Is there a renewal claim in FTS?

- Is there a Cúram claim indicator? 

### In NWS:

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/in_nws.dita`

- Is there SROC about an active claim in Cúram?

- Are there any SROCs or WIs containing the CCB/Family Caregiver: INS5257 Authorization to release medical information  — Form ?
         [CCB/Family Caregiver: INS5257 Authorization to release medical information  — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5216A.pdf)

- Are there any SROCs or WIs containing the CCB: INS5216B Medical certificate — Form ?
         [CCB: INS5216B Medical certificate — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5216B.pdf)

- Have any INS5257 or INS5216B forms been uploaded? 

### In Imaging:

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/in_imaging.dita`

- Is there any other documentation which may impact the renewal claim?

- Are there any documents containing the INS5257 or INS5216B forms? 

### In Cúram:

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/in_curam.dita`

- Is there a renewable claim in Cúram?

- Has any renewal evidence been entered?

- Do you have a Renewal – Requested by client – Call Back Required task? 

## Step by step

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/level_1.dita`

#### Review the file

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/review_the_file_level_1.dita`

- Determine if the WP must be served:

- If no, go to step 2.

- If yes, refer to Cancelling a benefit period - Cúram . If cancelling the BP is not advantageous to the client, go to step 2.
               [Cancelling a benefit period - Cúram](/en/procedure/task/annuler-demande-curam-cancel-claim-curam.shtml) 

#### Reviewing the patient record

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/reviewing_the_patient_record_level_1.dita`

- In FTS, on the Search tab, select Caregiver/Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, find the patient record as follows:

- Claimant’s SIN: Enter the client’s SIN.

- Select Search .

- Select the patient record to access the Caregiver/Compassionate care data entry (MCB1) screen.

- Determine if there are CCB entitlement weeks remaining:

- If weeks are still payable, go to step 4.

- If the maximum number of entitlement weeks has been received, go to CCB benefits exhausted .
               [CCB benefits exhausted](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60#ccb_exhausted)

- Determine if the LRW has been reached:

- If no, go to step 5.

- If yes, go to Last renewable week (LRW) has been reached .
               [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60#lrw)

- Determine the compassionate care window (CCW) was correctly established Determining if the compassionate care window is correctly established (Task) and go to step 6.

- Determine if all benefits requested by the client are outside the CCW, refer to Determining if the client is entitled to the CCB weeks requested during the compassionate care window (Task) .

- If no, go to step 7;

- If yes, go to CCB requested outside the compassionate care window (CCW) .
               [CCB requested outside the compassionate care window (CCW)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60#ccb_outside)

- Determine if other family members of the patient have requested CCB while providing care for the same person.

- If the benefits are shared with another family member, note the number of CCB weeks left to be paid and the number of unpaid weeks requested by another family member.

- Go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/fact-finding_level_1.dita`

- Fact-find with the client to obtain the information using the checklists: Renewal: Special benefits for Self-employed People (Part VII.1 Claims) and Special benefits Family caregiver benefits and CCB (information and attestation ).

- If the client was reached, go to step 9.

- If the client was not reached or did not reply to the N-10-00-00 letter for additional fact-finding, go to Unable to contact the client .
               [Unable to contact the client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60#Unable_to_contact)

- In NWS, create an SROC for each checklist as follows:

- Main Issue: Select Renewal or CCB Information and Attestation

- Comments: Type “Compassionate care benefits — Renewal — client.” and “Compassionate care benefits — Information and Attestation — Client”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client is sharing the CCB benefits with a family member and adjudication is required:

- If yes, refer to Adjudicating the sharing of CCB — Renewal or continuing claim (Task) and then go to step 11.
               [Adjudicating the sharing of CCB — Renewal or continuing claim (Task)](/en/procedure/task/deter_weeks_ccb.shtml)

- If no, go to step 11.

- In NWS and FTS, determine if one of the conditions to extend the BP is met:

- The client was incarcerated and has since been tried and not found guilty.

- The client received WCB and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If yes, refer to Extension of the benefit period and then go to step 12.
                   [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

- If no, go to step 12.

- Determine if the following conditions are met:

- The client provided an acceptable medical certificate .
               [acceptable medical certificate](/en/procedure/task/deter_ccb_mc.shtml)

- The client is a family member .
               [family member](/en/procedure/generic/additionalresources/definition_fam_mem.shtml)

- The client attests to providing care and support for a gravely ill family member .

- If yes, go to step 13.

- If no, go to Not entitled to CCB .
                   [Not entitled to CCB](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60#not_entitle_ccb)

               [providing care and support for a gravely ill family member](/en/procedure/task/deter_ccb_gifm.shtml)

- Determine if there is an issue that requires adjudication:

- If yes, determine the contentious issue and if necessary, refer to the appropriate task, then go to step 14.

- If no, go to step 14.

- Determine the renewal week. Refer to Determining the effective date of a renewal or a conversion .

- Go to Inputting the transactions .
               [Inputting the transactions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60#level1_item_4) 

#### Inputting the transactions

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/inputting_the_transactions_level_1.dita`

- In Cúram, on the PDC, in the Evidence dashboard, select Renewal and complete as follows:

- Obtained on : Enter todays date.

- Name of client : Confirm the correct client’s name is selected.

- Renewal start date: Select the appropriate start date of the renewal

- Select Save .

- Apply the Renewal evidence as follows:

- From the Evidence Dashboard , select In Edit Evidence from the left-hand side menu.

- Select the 3 dots ( … ) on the right-hand side of the In Edit Evidence navigation bar (beside Open in New Tab ). From the drop=down menu, select Apply Changes .

- From the Apply Changes window, select the Renewal evidence and select Save .

- Do not enter any Overpayment (OP) codes .

- From the Search menu, select Caregiver / Compassionate care - Patient and on the Search for Caregiver / Compassionate care patient (MCB2) screen, search for the patient record as follows:

- Claimant’s SIN: Enter the client's SIN.

- Select Search .

- Select the patient record to access the Caregiver / Compassionate care data entry (MCB1) screen, in the Claimant section do the following:

- Action: Select Modify .

- Entitlement weeks: Enter the number of entitlement weeks.

- Select Update .

- Complete the task in Cúram. 

#### CCB benefits exhausted

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/ccb_benefits_exhausted_level_1.dita`

- Using the Fact-finding task, contact the client :

- If the client is reached, explain that the CCB benefits are exhausted and go to step 2.

- If the client was not reached, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2926.dita)

- In Cúram, create a record of decision (ROD) as follows:

- Open the Product Delivery Case (PDC).

- Go to Notes under Contacts tab.

- Select New Note to open the dialog box and create the ROD:

- Subject: Type “No CCB entitlement”

- Priority:

- Sensitivity:

- Text: Document the decision and rationale according to the Fact-Finding and Documentation Policy and Type:

- “Compassionate care benefits exhausted. A D52 is imposed effective [date]. The client is not entitled to compassionate care benefits due to the maximum compassionate care benefit entitlement has already been paid for the compassionate care window.”

                   [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In the Evidence Dashboard, select Return to work and Disentitlements to open the New disentitlement modal and complete as follows:

- Date Received: Enter the appropriate date.

- Case Participant: Select the client’s name.

- Reason: Select from the drop-down menu:

- 52 - Compassionate care benefits exhausted

- Start date: Enter the appropriate date.

- End date: Leave blank for an indeterminate disentitlement.

- Select Save .

- The Evidence will now appear with the status “Evidence in Edit”

- Click on the three dots ( … ) in the top right corner and select “ Apply Changes ”.

- Review the evidence and update the overpayment codes to:

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special Benefits Denied (3065): Select Compassionate Care Benefits denied - D51/D52/D53/Free text (3084) .

- D52 - Max CCB wks already paid - Death of critically ill family member - Max CCB wks already shared (3087) .

- D52 - Max 26 CCB weeks already paid to client or other family members .

- Indefinite or Definite disentitlement dates (2485) .

- Right to Request Reconsideration (no Blank Option) (4169): Select Right to Request a Reconsideration .

- From the Search menu, select Caregiver / Compassionate care - Patient and on the Search for Caregiver/Compassionate care patient (MCB2) screen, search for the patient record as follows:

- Claimant’s SIN: Enter the client's SIN.

- Select Search .

- Select the patient record to access the Caregiver / Compassionate care data entry (MCB1) screen, in the Claimant section do the following:

- Action: Select Add .

- Status: Select 10 - D52/D62 - Maximum number of caregiver/compassionate care benefit weeks paid for patient .

- Select Update .

- Complete the task in Cúram. 

#### CCB requested outside the compassionate care window

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/ccb_requested_outside_the_compassionate_2f43bb3c_level_1.dita`

- Using the Fact-finding task, contact the client:

- If the client is reached, explain that the CCB benefits requested are outside the CCW and go to step 2.

- If the client was not reached, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2926.dita)

- In Cúram, create a record of decision (ROD) as follows:

- Open the Product Delivery Case (PDC)

- Go to Notes under Contacts tab.

- Select New Note to open the dialog box and create the ROD:

- Subject: Type “The client does not meet CCB entitlement conditions.”

- Priority:

- Sensitivity:

- Text: Document the decision and rationale according to the Fact-Finding and Documentation Policy and Type:

- “The client does not meet compassionate care benefit entitlement conditions. A D51 is imposed effective [date]. The client is not entitled to compassionate care benefits outside of the compassionate care window.”

                   [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In the Evidence Dashboard, select Other Disentitlements under Payment Related to open the New disentitlement modal and complete as follows:

- Date Received: Enter the appropriate date

- Case Participant: Select the client’s name

- Reason: Select from the drop-down menu:

- 51 - Does not meet compassionate care entitlement conditions

- Start date: Enter the appropriate date

- End date: Leave blank for an indeterminate disentitlement.

- Select Save .

- The Evidence will now appear with the status “ Evidence in Edit ”:

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special Benefits Denied (3065): Select Compassionate Care Benefits denied - D51/D52/D53/Free text (3084) .

- D51 - Not entitled to CCB - Various reasons (3085)

- D51 - Period requested falls before or after the established 52-week period established .

- Indefinite or Definite disentitlement dates (2485)

- Right to Request Reconsideration (no Blank Option) (4169): Select Right to Request a Reconsideration .

- Complete the task in Cúram. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/last_renewable_week_lrw_has_been_reached_level_1.dita`

- Determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim by referring to Self-employed: Information on calculation and entitlement to special benefits — Knowledge .

- If no, go to step 3.

- If yes, explain to the client that they must submit a new claim and complete the task.

- In Cúram, create a record of decision (ROD) as follows:

- Open the Product Delivery Case (PDC).

- Go to Notes under Contacts tab.

- Select New Note to open the dialog box and create the ROD:

- Subject: Type “Last renewable week reached - compassionate care benefits requested.”

- Priority:

- Sensitivity :

- Text: Select the appropriate option:

- If the client has not worked since the BPC , type “No renewal is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as no earnings were reported after the BPC.”

- If the client has worked since the BPC , type “No renewal is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as [earnings] was reported after the BPC and the client needed [earnings] to qualify.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Complete the task in Cúram. 

#### Not entitled to CCB

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/not_entitled_to_ccb_level_1.dita`

- In Cúram, create a record of decision (ROD) as follows:

- In the Evidence Dashboard, select Return to work and Disentitlements to open the New disentitlement modal and complete as follows:

- The Evidence will now appear with the status “ Evidence in Edit ”

- Click on the three dots ( … ) in the top right corner and select “ Apply Changes ”.

- Review the evidence and update the overpayment codes to:

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- In ACS, create and save the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special Benefits Denied (3065): Select Compassionate Care Benefits denied - D51/D52/D53/Free text (3084) .

- D51 - Not entitled to CCB - Various reasons (3085)

- D51 - Client does not provide care or support to the ill family member .

- D51 - Sick person is not a family member .

- D53 - No acceptable med cert/Period requested does not match med cert/No auth to release med info (3088)

- Indefinite or Definite disentitlement dates (2485)

- Right to Request Reconsideration (no Blank Option) (4169): Select Right to Request a Reconsideration .

- Complete the task in Cúram. 

#### Unable to contact the client

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/unable_to_contact_the_client_level_1.dita`

- In Cúram, create a record of decision (ROD) as follows:

- Open the Product Delivery Case (PDC).

- Go to Notes under Contacts tab.

- Select New Note to open the dialog box and create the ROD:

- Subject: Type “Unable to contact the client.”

- Priority:

- Sensitivity :

- Text: Type: “Unable to contact the client to obtain required information to renew the claim.”

- Complete the task in Cúram. 

#### Note

Source topic: `en_EN/common_notes/note_c_2926.dita`

Note:

At this time, SROCs must be created and saved in NWS for all actions completed in Cúram. 

## Policy reference

Source topic: `en_EN/task/ren-dem-client-rr-curam-ren-request-cli_28db2a60/policy_reference.dita`

 
