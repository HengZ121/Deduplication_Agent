# Processing a separation from Work-Sharing employment — IPOC

Source map: `en_EN/task/actioning_pse_wsc/actioning_pse_wsc.ditamap`

## Summary

Source topic: `en_EN/task/actioning_pse_wsc/summary.dita`

Summary: The Work-Sharing (WS) employer notifies IPOC of a client’s separation from employment on the utilization report (UR). When a client is laid off from WS employment, the client’s WS agreement is terminated effective the week of the layoff. When a client is dismissed from or voluntarily leaves WS employment, the WS agreement is terminated effective the week before the week in which the separation occurs. 

## What you need to know

Source topic: `en_EN/task/actioning_pse_wsc/what_you_need_to_know.dita`

### Processing a separation from employment in a utilization report (UR)

Source topic: `en_EN/task/actioning_pse_wsc/processing_a_separation_from_employment_d8bc2e75.dita`

When IPOC receives a UR with the details of a client’s separation from WS employment, the IPOC officer processes the UR according to the employer’s declaration. Whether or not the program officer has notified IPOC of the client’s separation from WS employment is irrelevant to the processing of the UR.

The WS employer indicates on the UR when a client has been laid off and removed from the agreement for any reason, including full-time apprenticeship training. The WS employer must provide the actual date of the layoff, not just the week in which the layoff occurred. When a client is laid off in the middle of the week, any hours after that date cannot be claimed as hours missed due to WS since the hours are missed due to the layoff.

The IPOC officer reviews the Correspondence subfolder in the employer’s folder to determine if the program officer has notified IPOC of a client’s separation from WS employment. If there is no communication related to the client’s separation from the WS agreement on file, the IPOC officer advises the program officer of the separation using the separation from WS employment template.

**Processing a layoff due to apprenticeship training and maternity, parental, compassionate care and family caregiver leave**

The WS employer also indicates on the UR when a client is on full-time apprenticeship training or maternity, parental, compassionate care or family caregiver leave. The WS employer must provide the start date of the apprenticeship training or leave.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1498.dita) 

When a WS employer indicates 0 hours worked and 0 hours missed due to full-time apprenticeship training on the UR, fact-finding is required to determine if it is a temporary layoff.

The IPOC officer uses special condition code 08 - Laid off since it is a short-term separation that ends when the apprenticeship training is over or when the employee returns from leave. The IPOC officer advises the employer to remove the employee from the UR until the employee returns from apprenticeship training or leave. Although it is not reported as a layoff on the ROE, separation for apprenticeship training and maternity, parental, compassionate care and family caregiver leave is considered a temporary layoff for WS purposes to pay apprenticeship or special benefits.

When a WS employer indicates on the UR that an employee is deceased, the IPOC officer considers the situation as a layoff for WS purposes. When documenting the file, the IPOC officer creates an Action Item (AI) WI for Level 1. 

### Inputting a special condition code

Source topic: `en_EN/task/actioning_pse_wsc/inputting_a_special_condition_code.dita`

If the UR covering the week of the layoff is a WS week, the IPOC officer codes the WS information but does not input the special condition code 8 - Laid off . The IPOC officer must process the UR without this special condition code in AWSS.

If the UR covering the week of the layoff is a non-WS week, the IPOC officer pay codes as normal, inputs the special condition code 8 - Laid off and processes the UR in AWSS. 

### Terminating the Work-Sharing (WS) agreement on the client’s claim

Source topic: `en_EN/task/actioning_pse_wsc/terminating_the_work-sharing_ws_agreeme_452f8a90.dita`

When terminating the WS agreement on the client’s WS claim, the IPOC officer changes the WS agreement end week to the week of the layoff and documents the details of the layoff on an SROC since the client may request other benefit types (BTs).

When fact-finding is done with the employer, the IPOC officer must document the details of that conversation on an SROC. 

### Processing a dismissal or voluntary leaving

Source topic: `en_EN/task/actioning_pse_wsc/processing_a_dismissal_or_voluntary_leaving.dita`

When a client is dismissed or voluntarily leaves the WS employment, the WS agreement end week must be changed to the week before the week in which the separation occurred.

In AWSS, the IPOC officer processes the UR containing the week of the event with special condition code 06 - Voluntary termination (quit) or 07 - Terminated (fired) but does not code the hours worked or hours missed.

When fact-finding is done with the employer, the IPOC officer must document the details of that conversation on an SROC.

Any hours not worked after the separation from WS employment are not considered missed due to WS during the week in which the contentious reason for separation (RFS) occurred. The client cannot receive the WS benefits for those hours. However, if the RFS is allowed, the client may be able to receive benefits for any hours missed due to WS before the separation.

The IPOC officer must follow special processes to ensure that the client is not paid for the week in which the separation occurs until the RFS is adjudicated. For this reason, it is necessary to document the UR declaration, including the separation information on an AI WI to Level 1. The officer adjudicates the RFS and determines if the client should be paid WS benefits or another type of benefits for the week in which the separation occurs. If further IPOC action is required, the officer sends an Operational Centre Memo (MM06) or an IPOC Review (REV) WI . 

### Receiving a late notification

Source topic: `en_EN/task/actioning_pse_wsc/receiving_a_late_notification.dita`

On occasion, the WS employer does not advise IPOC about a separation from the WS employment in a timely manner, specifically after the UR has been input for the week in which the separation occurred. In these cases, the action to take depends on whether the week in which the separation occurred has been matched and processed. If the week has not been matched with the client record in AWSS, the IPOC officer inputs an amended UR declaration for the week in which the separation occurred. If the week is matched but not processed, the IPOC officer ensures all weeks before the separation have been processed and actions the separation. If the week has been matched and processed, the IPOC officer actions the separation from WS employment for the last week processed and imposes a manual action 75 - Verification of reason for termination of employment (MA75) on the claim. 

### Processing a lump-sum payment

Source topic: `en_EN/task/actioning_pse_wsc/processing_a_lump-sum_payment.dita`

When ending a WS agreement, the IPOC officer reviews the master lump-sum payment spreadsheet and checks for any outstanding allocations for the client. The officer inputs any allocations extending beyond the new end week of the client’s WS agreement. 

### Note

Source topic: `en_EN/common_notes/note_c_1498.dita`

Note:

In the Quebec region, QPIP replaces EI maternity and parental benefits. When a WS employer indicates that the client is receiving QPIP benefits, the client is considered to be on maternity or parental leave. 

## Regional considerations

Source topic: `en_EN/task/actioning_pse_wsc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actioning_pse_wsc/what_you_need_to_look_for.dita`

### In the UR:

Source topic: `en_EN/task/actioning_pse_wsc/in_the_ur.dita`

- Did the employer indicate the RFS and the last day worked in the Comments column of the UR? 

### In NWS:

Source topic: `en_EN/task/actioning_pse_wsc/in_nws.dita`

- Is there an outstanding AI WI requesting a claim conversion to regular benefits?

- Is there an IPOC Purge & Recreate WI or an IPOC REV WI related to the contentious RFS? 

### In FTS:

Source topic: `en_EN/task/actioning_pse_wsc/in_fts.dita`

- Are there claimant’s reports cycling for weeks after the new end week?

- Have the claimant’s reports been received and processed up to the new end week? 

### In the lump sum payment spreadsheet:

Source topic: `en_EN/task/actioning_pse_wsc/in_the_lump_sum_payment_spreadsheet.dita`

- Are there any allocations extending beyond the new end week? 

### In the employer’s electronic file in the Active_Agreements folder:

Source topic: `en_EN/task/actioning_pse_wsc/in_the_employers_electronic_file_in_the_779fe214.dita`

- Is there any information related to a client’s separation from WS agreement in the Correspondence subfolder? 

## Step by step

Source topic: `en_EN/task/actioning_pse_wsc/step_by_step.dita`

### IPOC

Source topic: `en_EN/task/actioning_pse_wsc/ipoc.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_pse_wsc/reviewing_the_file_ipoc.dita`

- In NWS, determine if there is an outstanding IPOC REV WI for the contentious RFS issue:

- If yes, go to step 2.

- If no, go to step 6.

- Determine if the contentious RFS is adjudicated:

- If yes, go to step 3.

- If no, go to step 6.

- In FTS, determine if all the conditions are met:

- There is a Purge and Recreate (P/R) Operational Centre Memo (MM06) transaction requesting to extend the WS agreement.

- On the Worksharing Records screen, in the Matched column of the appropriate weeks, the box is checked.

- If both conditions are met, go to step 4.

- In all other situations, go to Processing a converted amended Work-Sharing utilization report – IPOC .
                   [Processing a converted amended Work-Sharing utilization report – IPOC](/en/procedure/task/processing_amended_wsur.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1499.dita)

- In NWS, add information to the existing IPOC REV WI regarding the RFS on the UR declaration:

- In the menu, select Add and select Add details / Further Inquiry . Then, do the following:

- Action: Select Additional information .

- Details: Add the details of the UR declarations.

- Select OK .

- Reassign the IPOC REV WI as follows:

- If the IPOC Purge & Recreate (IPOC P/R) WI is assigned:

- Destination: Select Specific user and select the IPOC officer.

- Issue: Select MM06 clarification .

- Reason: Select Related work item .

- Details: Type “UR matched in AWSS. Process UR.”

- Select OK .

- If the IPOC P/R WI is not assigned:

- Destination: Select Next available user .

- Issue: Select MM06 clarification .

- Reason: Select Related work item .

- Details: Type “UR matched in AWSS. Process UR.”

- Select OK .

- Review the Correspondence subfolder in the employer’s folder to determine if there is communication from the program officer advising of the client’s separation from the WS employment:

- If no, go to step 7.

- If yes, go to step 8.

- Complete the separation from WS employment template and send it to the regional program officer’s GD mailbox. Select the appropriate email template:

- - Atlantic
                   [Atlantic](https://014gc.sharepoint.com/:u:/r/sites/EI_IPOS-SOPA_AE/IPOC%20Guidance_Procedures%20COPA/Templates-Mod%C3%A8les/ATL-Template-WSSeparationNotice-EN.oft?csf=1&download=1)

- Quebec
                   [Quebec](https://014gc.sharepoint.com/:u:/r/sites/EI_IPOS-SOPA_AE/IPOC%20Guidance_Procedures%20COPA/Templates-Mod%C3%A8les/QC-Template-WSSeparationNotice-EN.oft?csf=1&download=1)

- Ontario
                   [Ontario](https://014gc.sharepoint.com/:u:/r/sites/EI_IPOS-SOPA_AE/IPOC%20Guidance_Procedures%20COPA/Templates-Mod%C3%A8les/ON-Template-WSSeparationNotice-EN.oft?csf=1&download=1)

- Western Canada and Territories
                   [Western Canada and Territories](https://014gc.sharepoint.com/:u:/r/sites/EI_IPOS-SOPA_AE/IPOC%20Guidance_Procedures%20COPA/Templates-Mod%C3%A8les/WT-Template-WSSeparationNotice-EN.oft?csf=1&download=1)

- Save a copy of the email in the employer’s Correspondence subfolder.

- Review the UR and determine if the employer reported the separation on the week in which the separation occurred or earlier:

- If yes, go to step 9.

- If no, go to Processing a late notification .
               [Processing a late notification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#sbs_process_late_notification)

- Review the UR and determine the client’s RFS:

- If the client is laid off due to shortage of work, apprenticeship training, or maternity, parental, compassionate care or family caregiver leave, or if the client is deceased, go to Processing a layoff .
               [Processing a layoff](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#sbs_process_layoff)

- If the client is dismissed or voluntarily left, go to Processing a dismissal or voluntary leaving .
               [Processing a dismissal or voluntary leaving](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#sbs_process_dismissal) 

#### Processing a late notification

Source topic: `en_EN/task/actioning_pse_wsc/processing_a_late_notification_ipoc.dita`

- In FTS, determine if the UR for the week in which the separation occurred has been input into AWSS:

- If yes, go to step 2.

- If no, go to step 9.

- Determine if the UR for the week in which the separation occurred has been matched in AWSS:

- If yes, go to step 3.

- If no, go to step 8.

- Determine if the UR for the week of the separation has been processed:

- If yes, go to step 4.

- If no, ensure weeks before the separation have been processed. Go to step 5.

- If the RFS is dismissal or voluntary leaving, select the Renewal/Revised (M106) transaction and impose an MA75 as follows:

- Registration number: Leave this field blank. If a number is displayed, remove it.

- Manual Action: Select 75 - Verification of reason for termination of Employment .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1500.dita)

- If processing a converted UR, remove the UR declaration from the current UR as there should be no UR declarations for weeks after the separation.

- In FTS, determine if the claim is in MPS:

- If no, go to step 7.

- If yes, go to Processing an MPS claim .
               [Processing an MPS claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_4)

- On the Payments tab, determine if claimant’s reports are cycling:

- If yes, go to Processing a cycling claimant’s report .
               [Processing a cycling claimant’s report](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_2)

- If no, go to No cycling claimant’s reports .
               [No cycling claimant’s reports](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_3)

- Delete the UR declaration from AWSS for the week of the separation and any subsequent weeks with a special condition code 44. For more information, refer to Work-Sharing: Utilization report coding — Input guide .

- Review the UR and determine the client’s RFS:

- If the client is laid off due to shortage of work, apprenticeship training or maternity, parental, compassionate care or family caregiver leave, or if the client is deceased, go to Processing a layoff .
               [Processing a layoff](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#sbs_process_layoff)

- If the client is dismissed or voluntarily left, go to Processing a dismissal or voluntary leaving .
               [Processing a dismissal or voluntary leaving](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#sbs_process_dismissal) 

#### Processing a layoff

Source topic: `en_EN/task/actioning_pse_wsc/processing_a_layoff_ipoc.dita`

- Determine if a UR is currently being processed:

- If yes, go to step 2.

- If no, go to step 4.

- Review the UR and determine if the employer reported hours worked for the client:

- If no, go to step 3.

- If yes, no special condition code is required for the UR. Continue to process the UR as declared and go to step 4.

- On the UR converted by macro, make the following adjustments and continue to process the UR:

- Remove the hours missed, if necessary.

- Keep any earnings reported.

- Enter special condition code 08 - Laid off in the Reason for not working column.

- In FTS, determine if the claim is in MPS:

- If no, go to step 5.

- If yes, go to Processing an MPS claim .
               [Processing an MPS claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_4)

- On the Payments tab, determine if claimant’s reports are cycling for weeks after the week in which the separation from employment occurred:

- If yes, go to Processing a cycling claimant’s report .
               [Processing a cycling claimant’s report](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_2)

- If no, go to No cycling claimant’s reports .
               [No cycling claimant’s reports](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_3) 

#### Processing a dismissal or voluntary leaving

Source topic: `en_EN/task/actioning_pse_wsc/processing_a_dismissal_or_voluntary_leaving_ipoc.dita`

- Determine if a UR is currently being processed:

- If yes, go to step 2.

- If no, go to step 5.

- Review the UR and determine if the employer reported hours worked for the client:

- If no, go to step 3.

- If yes, go to step 4.

- On the UR converted by macro, make the following adjustments and continue to process the UR:

- Remove the hours missed, if necessary.

- Keep any earnings reported.

- If the client voluntarily left the WS employment, enter special condition code 6 - Voluntary termination (quit) in the Reason for not working column. If the client was dismissed from the WS employment, enter special condition code 7 - Terminated (fired) in the Reason for not working column. Go to step 5.

- On the UR converted by macro, make the following adjustments and continue to process the UR:

- Remove the hours worked.

- Remove the hours missed, if necessary.

- Keep any earnings reported.

- If the client voluntarily left the WS employment, enter special condition code 6 - Voluntary termination (quit) in the Reason for not working column. If the client was dismissed from the WS employment, enter special condition code 7 - Terminated (fired) in the Reason for not working column.

- In FTS, determine if the claim is in MPS:

- If no, go to step 6.

- If yes, go to Processing an MPS claim .
               [Processing an MPS claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_4)

- On the Payments tab, determine if claimant’s reports are cycling for the week in which the separation from employment occurred or the weeks after it:

- If yes, go to Processing a cycling claimant’s report .
               [Processing a cycling claimant’s report](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_2)

- If no, go to No cycling claimant’s reports .
               [No cycling claimant’s reports](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_3) 

#### Processing a cycling claimant’s report

Source topic: `en_EN/task/actioning_pse_wsc/processing_a_cycling_claimants_report_ipoc.dita`

- In FTS, select the Renewal/Revised (M106) transaction and remove the cycling claimant’s reports as follows:

- Manual action: Select 76R - Automated work-sharing Rescind/Removal of Cycling Reports .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1501.dita)

- Select the Project Data — Worksharing (M171) transaction and change the end week of the WS agreement as follows:

- End date: Enter the new WS agreement end week.

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1502.dita)

- Determine if the claimant’s reports are processed up to the revised WS end week:

- If no, go to step 4.

- If yes, go to step 8.

- The next business day, select the Renewal/Revised (M106) transaction and re-input the MA76 as follows:

- Manual action: Select 76 - Automated work-sharing .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1503.dita)

- Determine if the client was exempt from reporting:

- If no, go to step 6.

- If yes, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1504.dita)

- If the client completes paper claimant’s reports, re-input the claimant’s reports that were previously cycling up to the new end week. Go to step 8.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1505.dita)

- The next business day, select Renewal/Revised (M106) transaction and re-input the NO-CR-CODE as follows:

- Claimant’s Report — No claimant’s report: Check the box.

- Select Update .

- In NWS, determine if an IPOC System Notification (IPOC SN) Work-Sharing - Special condition WI was generated due to a special condition code:

- If no, go to step 9.

- If yes, reassign the IPOC SN Work-Sharing - Special condition WI to yourself. For more information, refer to Actioning a special condition code — IPOC . Go to step 9.
               [Actioning a special condition code — IPOC](/en/procedure/task/actioning_wd0242_ws_sc_report.shtml)

- Review the master lump-sum payment spreadsheet and check for outstanding allocations for the client. Determine if there are allocations extending beyond the new WS end week:

- If yes, go to Inputting an allocation .
               [Inputting an allocation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_5)

- If no, go to Documenting the separation from employment .
               [Documenting the separation from employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_6)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1506.dita) 

#### No cycling claimant’s reports

Source topic: `en_EN/task/actioning_pse_wsc/no_cycling_claimants_reports_ipoc.dita`

- In FTS, determine if the client is exempt from reporting:

- If yes, go to step 2.

- If no, go to step 7.

- Select the Renewal/Revised (M106) transaction and rescind the NO-CR-CODE as follows:

- Claimant’s Report — Rescind: Check the box.

- Select Update .

- Select the Project Data — Worksharing (M171) transaction and change the end week of the WS agreement as follows:

- End date: Enter the new WS agreement end week

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1502.dita)

- Determine if the claimant’s reports have been processed up to the revised WS end week:

- If no, go to step 5.

- If yes, go to step 6.

- The next business day, select the Renewal/Revised (M106) transaction and re-input the NO-CR-CODE as follows:

- Claimant’s Report — No claimant’s report: Check the box.

- Select Update .

- Go to step 10.

- Select the Manual Action - Claimant’s Reports (T045) transaction and rescind the MA76 as follows:

- Week: Select Indefinite .

- Manual action: Select 76 - Automated work-sharing .

- Rescind: Check the box.

- Select Update .

- Go to step 10.

- Select the Project Data — Worksharing (M171) transaction and change the end week of the WS agreement as follows:

- End date: Enter the new WS agreement end week.

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1502.dita)

- Determine if the claimant’s reports have been processed up to the revised WS end week:

- If yes, go to step 9.

- If no, go to step 10.

- Select the Manual Action - Claimant’s Reports (T045) transaction and rescind the MA76 as follows:

- Week: Select Indefinite .

- Manual action: Select 76 - Automated work-sharing .

- Rescind: Check the box.

- Select Update .

- In NWS, determine if IPOC SN Work-Sharing - Special condition WI was generated due to a special condition code:

- If no, go to step 11.

- If yes, reassign the IPOC SN Work-Sharing - Special condition WI to yourself. Refer to Actioning a special condition code — IPOC for guidance. Go to step 11.
               [Actioning a special condition code — IPOC](/en/procedure/task/actioning_wd0242_ws_sc_report.shtml)

- Review the master lump-sum payment spreadsheet and check for outstanding allocations for the client. Determine if there are allocations extending beyond the new WS end week:

- If yes, go to Inputting an allocation .
               [Inputting an allocation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_5)

- If no, go to Documenting the separation from employment .
               [Documenting the separation from employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_6)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1506.dita) 

#### Processing an MPS claim

Source topic: `en_EN/task/actioning_pse_wsc/processing_an_mps_claim_ipoc.dita`

- In FTS, select the Operational Centre Memo (MM06) transaction and complete the following fields:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 30 - New information on a manual pay claim .

- Remarks line 1: Type “early termination of WS agreement — [laid off, voluntary departure, termination].”

- Remarks line 2: Type “Change WS end week from w/c [XXXX] to w/c [XXXX].”

- Remarks line 3: Type “WS agreement number [XXXXXXX].”

- Remarks line 4: If necessary, enter the information for URs that have not yet been processed up to the revised end week.

- Remarks line 5: Enter your first name and last name.

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1507.dita)

- Go to Documenting the separation from employment . 

#### Inputting an allocation

Source topic: `en_EN/task/actioning_pse_wsc/inputting_an_allocation_ipoc.dita`

- Obtain the client’s allocation information from the master lump-sum payment spreadsheet.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision Type: Select 3 - Revised .

- Select Update .

- Select the Allocations (M175) transaction and input the outstanding allocation as follows:

- Registration number: Select the appropriate registration number.

- On the first line, select the appropriate allocation type:

- Type: Select the appropriate allocation type.

- Amount: Enter the amount allocated per week.

- Start date: Enter the first week of the outstanding allocation.

- End date: Enter the last week of the outstanding allocation.

- Last week amount: Select the appropriate option:

- If the allocation amount in the last week is less than the amount allocated per week, enter that amount.

- If the allocation amount in the last week is equal to the amount allocated per week, leave the field blank.

- Detection: Selection 31 - Other new facts- entitlement review .

- Infraction: Select A - Non-fraud - Earnings and employment .

- Message: Select 8 - Your earnings were not deducted .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1508.dita) 

#### Documenting the separation from employment

Source topic: `en_EN/task/actioning_pse_wsc/documenting_the_separation_from_employment_ipoc.dita`

- Determine the RFS:

- If the client is laid off due to shortage of work, go to step 2.

- If the client is laid off due to apprenticeship training or maternity or parental leave, or if the client is deceased, go to step 3.

- If the client is laid off due to compassionate care leave, go to step 4.

- If the client is laid of due to family caregiver leave, go to step 5.

- If the client is dismissed or voluntarily left the WS employment, go to step 6.

- In NWS, create an SROC as follows:

- Main Issue: Select Reason for Separation .

- Comments: Type “Changes to Work-Sharing — layoff indicated on utilization report.”

- Details: Document the UR for the week of the layoff. Type “Utilization report for week code [XXXX] indicates normal weekly hours of [XX], [XX] hours worked and [XX] hours missed. Comment on utilization report indicated that client was laid off on [DD-MM-YYYY].” Provide the WS employer and WS agreement number.

- Select Save .

- Go to Completing the WI .
               [Completing the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_7)

- In NWS, create an AI WI for Level 1 as follows:

- Complexity: Select Level 1 .

- Destination — Level: Select 1 - Natl Processing & Payments Svcs (PPS) / Specialized EI Processing / Revised BPNE .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Reason for separation .

- Comments: Type “Changes to Work-Sharing — [apprenticeship training or maternity or parental leave or client deceased]”

- Details: Type “Comments on Work-Sharing utilization report indicate client [was laid off, began full-time apprenticeship training, is on maternity or parental leave or is deceased] effective [DD-MM-YYYY]. Work-Sharing terminated in w/c [XXXX].” For a leave of absence for any reason, type “Contact the client for claim conversion from w/c [XXXX].” For a deceased client, enter any other relevant details provided in the Comments field on the UR. Provide the WS employer and WS agreement number.

- Go to Completing the WI .
               [Completing the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_7)

- In NWS, create an AI WI for Level 1 as follows:

- Complexity: Select Level 1 .

- Benefit type: Select Compassionate care .

- Destination — Level: Select 1 - Natl Processing & Payments Svcs (PPS) / Specialized EI Processing / Revised BPNE .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Reason for separation .

- Comments: Type “Changes to Work-Sharing — compassionate care leave.”

- Details: Type “Comments on work-sharing utilization report indicate client is on compassionate care leave effective [DD-MM-YYYY]. Work-sharing terminated in w/c [XXXX]. Contact the client for claim conversion from w/c [XXXX].” Provide the WS employer and WS agreement number.

- Go to Completing the WI .
               [Completing the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_7)

- In NWS, create an AI WI for Level 1 as follows:

- Complexity: Select Level 1.

- Benefit type: Select Family caregiver .

- Destination — Level: Select 1 - Natl Processing & Payments Svcs (PPS) / Specialized EI Processing / Revised BPNE .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Reason for separation .

- Comments: Type “Changes to Work-Sharing — Family caregiver leave.”

- Details: Type “Comments on work-sharing utilization report indicate client is on family caregiver leave effective [DD-MM-YYYY]. Work-sharing terminated in w/c [XXXX]. Contact the client for claim conversion from w/c [XXXX].” Provide the WS employer and WS agreement number.

- Go to Completing the WI .
               [Completing the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_7)

- In NWS, create an AI WI for Level 1 as follows:

- Complexity: Select Level 1 .

- Destination: Select the appropriate option:

- Atlantic: SCC: Select the Service Canada Centre (SCC) as shown in FTS.

- Quebec: Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC / Work-Sharing - QC .

- Ontario: Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - ON / Work-Sharing - ON .

- Western Canada and Territories: Level: Select 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - WT / Work-Sharing - WT .

- End User: Select Next available user .

- Category: Select Pay affected (if WS hours were reported as missed) or Not Pay affected (if no WS hours were reported as missed).

- Issue: Select Work-Sharing .

- Comments: Type “Contentious RFS reported on Utilization Report.”

- Details: Document the UR for the week of the separation. Type “Utilization Report for w/c [XXXX] indicates normal weekly hours of [XX], hours worked of [XX] and hours missed of [XX].” Include the RFS information, exactly as it was provided on the UR. Provide the WS employer and WS agreement number. If the employer provided the separation information after the week with the separation or subsequent weeks processed, also type “Employer provided separation information on [date UR was submitted]. Weeks [XXXX – XXXX] had already been processed. MA75 imposed.”

- Go to Completing the WI .
               [Completing the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_pse_wsc#ipocc_item_7) 

#### Completing the WI

Source topic: `en_EN/task/actioning_pse_wsc/completing_the_wi_ipoc.dita`

- In NWS, complete the IPOC SN Work-Sharing - Special condition WI, if necessary, and document the action taken. 

#### Note

Source topic: `en_EN/common_notes/note_c_1499.dita`

Note:

The steps to reprocess the UR in AWSS or the claimant’s reports that are cycling or processed are the same as the steps for processing a converted amended UR. 

#### Note

Source topic: `en_EN/common_notes/note_c_1500.dita`

Note:

If there are 2 manual actions (MAs) on the claim, rescind the 76 - Automated work-sharing manual action (MA76) before inputting an MA75. Refer to the Processing a cycling claimant’s report or No cycling claimant’s reports sections for instructions.
       [Processing a cycling claimant’s report](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#ipocc_item_2) 
       [No cycling claimant’s reports](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#ipocc_item_3)

     [Processing a cycling claimant’s report](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#ipocc_item_2) 
     [No cycling claimant’s reports](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#ipocc_item_3) 

#### Note

Source topic: `en_EN/common_notes/note_c_1501.dita`

Note:

By selecting that option, the MA76 and the exemption from reporting are rescinded and the cycling claimant’s reports are removed from the claim. Note the information on cycling claimant’s reports up to the revised end week. The information is re-input in a future step.

Only one MA can be input per day. Hold the file until the next business day if an MA75 was input due to a late notification. The next business day, input the MA76R when the MA75 has been successfully input on the claim. 

#### Note

Source topic: `en_EN/common_notes/note_c_1502.dita`

Note:

When a client is laid off, the revised WS end week is the week of the layoff. When a client is dismissed or voluntarily leaves the WS employment, the revised WS end week is the week before the week in which the separation occurs.

When the week in which the separation occurred or the subsequent weeks have already been processed, the WS end week is the last week processed. 

#### Note

Source topic: `en_EN/common_notes/note_c_1503.dita`

Note:

The MA76 allows the claimant’s reports to be input up to the revised end week. 

#### Note

Source topic: `en_EN/common_notes/note_c_1504.dita`

Note:

The NO-CR-CODE generates the claimant’s reports if they are not already processed up to the revised end week. 

#### Note

Source topic: `en_EN/common_notes/note_c_1505.dita`

Note:

Re-input the previously cycling claimant’s reports on an Issue Payments (M151/152) transaction. Since this involves a client’s paper claimant’s reports, do not include STUAE coding or UR information. 

#### Note

Source topic: `en_EN/common_notes/note_c_1506.dita`

Note:

Remove the client’s old allocation information from the master lump-sum payment spreadsheet. 

#### Note

Source topic: `en_EN/common_notes/note_c_1507.dita`

Note:

In the Operational Centre Memo (MM06) transaction, do not include the UR information for the week the client was dismissed or voluntarily left the WS employment. This information is included when an AI WI is sent to Level 1 in the next step. 

#### Note

Source topic: `en_EN/common_notes/note_c_1508.dita`

Note:

An officer should already have sent an ACS allocation letter.

Remove the client’s old allocation information from the master lump-sum payment spreadsheet. 

## Policy reference

Source topic: `en_EN/task/actioning_pse_wsc/policy_reference.dita`

 
