# Converting a claim from parental to sickness benefits

Source map: `en_EN/task/conv_parsick/conv_parsick.ditamap`

## Summary

Source topic: `en_EN/task/conv_parsick/summary.dita`

Summary: Clients receiving parental benefits who become unable to work because of illness, injury or quarantine, can request a conversion to sickness benefits. 

## What you need to know

Source topic: `en_EN/task/conv_parsick/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/conv_parsick/untitled_section.dita`

For a claim to be converted to sickness benefits, the entitlement conditions for sickness benefits must be met. 

### Qualifying for sickness benefits

Source topic: `en_EN/task/conv_parsick/qualifying_for_sickness_benefits.dita`

A client qualifies for sickness benefits if one of the following conditions is met:

- The client is major attached (has accumulated at least 600 hours of insurable employment).
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

- The BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0021.dita) 

### Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)

Source topic: `en_EN/task/conv_parsick/qualifying_for_benefits_with_the_common_772f2c7f.dita`

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits regardless of the conversion date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

During this period, the officer does not use the claim type (CT) 9 - Sickness - minor attached . 

### Extending to sickness benefits

Source topic: `en_EN/task/conv_parsick/extending_to_sickness_benefits.dita`

A client is entitled to sickness benefits if the following conditions are met:

- The client submits proof of illness, injury or quarantine;

- The client is otherwise available for work. 

### Otherwise available and parental benefits

Source topic: `en_EN/task/conv_parsick/otherwise_available_and_parental_benefits.dita`

Clients who are receiving parental benefits (including fishing benefits) do not have to prove that they would be otherwise available for work to receive sickness benefits.

However, clients on parental leave who do not request EI or QPIP benefits must prove that they are otherwise available for work to be entitled to sickness benefits. 

### Weeks of entitlement

Source topic: `en_EN/task/conv_parsick/weeks_of_entitlement.dita`

The client can receive up to 26 weeks of sickness benefits per benefit period (BP) for a BPC in w/c 2374 or later and up to 15 weeks of sickness benefits per BP for a BPC in w/c 2373 or earlier. Once a claim has been established, a client may receive a combination of regular and special benefits within the BP. The maximum entitlement to benefits varies based on the benefit type (BT). The maximum number of weeks payable for each BT cannot be exceeded.
       [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2653.dita) 

The officer imposes a 22 - Illness (maximum sickness/special benefits paid) disentitlement (D22) when a client requests sickness benefits but the maximum weeks of sickness benefits have already been paid.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2737.dita) 

### Casual sickness

Source topic: `en_EN/task/conv_parsick/casual_sickness.dita`

Weeks of casual sickness cannot be paid on a claim for parental benefits. However, a client who is entitled to and receiving regular benefits during the parental window (PW) can report up to 4 weeks of casual sickness. For more information, the officer refers to Converting a claim from regular to sickness benefits .
       [Converting a claim from regular to sickness benefits](/en/procedure/task/conv_regsick.shtml) 

### Extension of the benefit period (BP)

Source topic: `en_EN/task/conv_parsick/extension_of_the_benefit_period_bp.dita`

The BP can be extended for a maximum of 104 weeks to pay additional weeks of sickness benefits when all of the conditions are met before the BP ends. The officer must refer to Benefit period extension for more information.
       [Benefit period extension](/en/procedure/activity/extension_benefit_period.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Determining if a medical certificate must be submitted

Source topic: `en_EN/task/conv_parsick/determining_if_a_medical_certificate_mu_d4cdaa5c.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2738.dita) 

A client requesting a conversion to sickness benefits from parental benefits must submit an acceptable medical certificate that attests to the incapacity and indicates the incapacity start date and the probable duration.
       [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

When a medical certificate has been requested but has not been submitted yet, the officer imposes a 16 - No medical certificate submitted disentitlement (D16).

When the client submits a medical certificate but it is considered unacceptable, the officer contacts and asks the client to submit a new medical certificate. If the client does not submit a new medical certificate, the officer imposes a D16.

If the authenticity of a medical certificate or the doctor’s signature raises doubts, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Incapacity period

Source topic: `en_EN/task/conv_parsick/incapacity_period.dita`

To allow the payment of sickness benefits, the officer must determine the period for which the client is incapable of working. This is done by determining the following information:

- the incapacity start date

- the end date of the incapacity

- the expected recovery date

- the recovery week to be input

**Incapacity start date**

For a conversion from parental to sickness benefits on a continuing claim, the incapacity start date indicated on the medical certificate is the accepted date.

If the medical certificate does not specify a start date, the officer accepts the earliest of the following as the incapacity start date:

- the Sunday of the week the doctor signed the medical certificate;

- the Sunday of the week of the medical consultation.

If the certificate does not contain any of these dates, the officer contacts and asks the client to submit a new medical certificate with the incapacity start date. If the client does not submit a new medical certificate, the officer imposes a D16.

**Incapacity end date**

The incapacity end date is the last day the client is incapable of working. The period of incapacity ends the day before the recovery date.

**Recovery date**

The recovery date is the first day the client is capable of working. The medical certificate is used to determine the recovery date.

**Recovery week**

The recovery week is the week up to which sickness benefits are payable.

To determine the recovery week, the officer refers to Determining the Recovery week — Instructions .
       [Determining the Recovery week — Instructions](/en/procedure/generic/determing_the_recovery_week_instruction.shtml) 

### Out of region or Out of Canada

Source topic: `en_EN/task/conv_parsick/out_of_region_or_out_of_canada.dita`

Clients who are not in Canada may be entitled to parental benefits. During their time out of Canada, clients may fall ill or be injured. To collect sickness benefits, clients must prove that they are undergoing medical treatment in an accredited hospital that is not readily or immediately available in their area of residence. The urgency to receive medical treatment does not invalidate this provision. To determine the entitlement to sickness benefits of clients who fall ill outside of Canada while on parental benefits, the officer must refer to Out of Canada .
       [Out of Canada](/en/procedure/activity/out_canada.shtml) 

### Outstanding disentitlement

Source topic: `en_EN/task/conv_parsick/outstanding_disentitlement.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies on the renewal (conversion). A Level 1 officer can terminate or rescind the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . If the information on file allows for the disentitlement to be terminated, the disentitlement is terminated on the Friday of the week before the conversion week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2752.dita) 

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer refers the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Temporary foreign workers (900-series SIN)

Source topic: `en_EN/task/conv_parsick/temporary_foreign_workers_900-series_sin.dita`

All foreign workers are given temporary resident status for a limited period of time when they enter Canada. Generally, foreign workers can demonstrate availability to accept work only if they possess a valid work permit which allows them to work in Canada. Therefore, when a foreign worker wishes to renew or convert a claim to sickness benefits, the validity of the work permit will need to be checked as the client could be deemed not otherwise available. 

### Effective date of a renewal or a conversion

Source topic: `en_EN/task/conv_parsick/effective_date_of_a_renewal_or_a_conversion.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer refers to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Return to Work (RTW)

Source topic: `en_EN/task/conv_parsick/return_to_work_rtw.dita`

If there is an RTW on the claim that falls on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer refers the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### Retroactive conversion request

Source topic: `en_EN/task/conv_parsick/retroactive_conversion_request.dita`

A request to convert a period of parental benefits that have already been paid to sickness benefits is considered only if the following conditions are met:

- The request is made within 4 weeks of either the week the BP expired or the onset of the illness (whichever is later).

- The medical certificate includes the date the illness began (onset date).

Where a request is made more than 4 weeks after the periods stated above, the client is required to show good cause for the delay in making the request. 

### Conversion from parental to sickness benefits on a continuing claim

Source topic: `en_EN/task/conv_parsick/conversion_from_parental_to_sickness_be_5c68f52a.dita`

**Processing claimant’s reports**

Before the officer can input the conversion transactions, the last week of parental benefits must be paid. If claimant’s reports have not yet been processed for the parental benefits period, they must be processed before inputting the conversion. This requires a 2-day input.

**Deferring the adjudication of a contentious reason for separation (RFS)**

When clients report a contentious RFS, the officer must fact-find, adjudicate and notify the client of the decision. In some situations, when clients qualify for and request special benefits, fact-finding and adjudication of the contentious RFS can be deferred.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2711.dita) 

**Adjudicating new contentious issues**

When converting a continuing claim, a client may report a new contentious issue (e.g. RFS, farming or availability) that must be adjudicated. If there is no existing WI for this issue, the Level 1 officer creates a Claim Review (CR) WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

The Level 1 officer does not reassign the CR Conversion WI to Level 2 for any reason. 

### Conversion from parental to sickness benefits on a renewal claim

Source topic: `en_EN/task/conv_parsick/conversion_from_parental_to_sickness_be_4afdad02.dita`

When actioning the renewal, the officer reviews all documentation in the electronic claim to ensure all issues and information have been addressed as appropriate. The system does not generate a new WI or send a notification for outstanding Claim Assessment (CA) or Specialized Application (SA) WIs when documents are uploaded in all situations.

**Renewal advantages**

When assessing a renewal, it might be to the client’s advantage to establish a new BP instead of renewing the existing BP. The officer refers to Cancelling, voiding, terminating or withdrawing a claim for more information.
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml)

**Subsequent claim**

The renewal application can be used to establish a subsequent claim when the following conditions are met:

- The claim is renewed and there are 4 or fewer weeks of benefits remaining in the BP.

- The client has worked enough hours to establish a new claim.

ACP can register the subsequent claim if the CA WI for a renewal or subsequent initial claim is finalized within 28 days of the renewal application.

When ACP cannot register the subsequent claim because the renewal is not processed within 28 days of the renewal application (i.e. REN WK not found or No match and polling limit exceeded is displayed on the Processing Activities tab in NWS) or when the claim was converted to MPS, the officer processing the CA Renewal WI creates a Reminder (REM) WI. This ensures that an officer will manually register the subsequent claim.

**Adjudicating new contentious issues**

When renewing a claim, a client may report a new contentious issue (e.g. RFS, farming, availability) that must be adjudicated. If the issue is reported on the application, the system creates an Adjudication Issue (ADJ) WI. If a contentious issue is detected while reviewing the claim, the Level 1 officer must create an ADJ WI for each contentious issue and must attempt to adjudicate the issue according to the National Policy on Levels of Decision . When an ADJ WI is created on a renewal claim, either manually or by the system, the system automatically imposes a 2 - Contentious Renewal in Automation manual action (MA2) to prevent payment of benefits until the contentious issue is adjudicated and the renewal is completed. When the renewal or a decision must be input manually, the inputs must be done before the Claim Assessment (CA) WI is completed, as the completion of the WI triggers the removal of the MA2 by the system. An officer cannot remove an MA2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 

### Claim action status and processing of the claim

Source topic: `en_EN/task/conv_parsick/claim_action_status_and_processing_of_the_claim.dita`

The Claim action status Renewal is created when a renewal decision is registered. There are 3 Claim action statuses that may be displayed:

- In Progress (Automation) is displayed on the Client information tree when there is one or more outstanding adjudication issues.

- In Progress (Manual) is displayed on the Client information tree when there is no outstanding ADJ WI and there is an outstanding CA or SA WI.

- Finalized is displayed on the Client information tree when all ADJ WIs are completed and the renewal week has been successfully input.

An ADJ WI is created for every new contentious issue. When opening an ADJ WI, the officer must always check to see if there is a Resolve Issue tab. If there is a Resolve Issue tab, the officer can document the decision directly in the ADJ WI by completing all mandatory screens. When the ADJ WI is completed, NWS creates a record of decision (ROD) based on the Resolve Issue screens. When the renewal is finalized, the system also generates the required transactions (e.g. signature code, disentitlement) based on the Resolve Issue screens. If a disentitlement is imposed, the system creates a Correspondence WI for the D-01-00-00 letter. This means that the officer with the CA or SA WI has no action to perform for these ADJ WIs.

If there is no Resolve Issue tab for the ADJ WI, the officer must create a ROD, generate the required transactions and send the appropriate letter. If there is an outstanding CA or SA WI when the officer completes the ADJ WI, a client Note is created and the officer with the CA or SA WI must follow the instructions to input the transactions or send the letter. 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/task/conv_parsick/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular. The officer manually updates this field to the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For conversion requests on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an Action Item (AI), Call Back (CB), Assessment Issue (ASMT) or REM WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### ACS letters

Source topic: `en_EN/task/conv_parsick/acs_letters.dita`

Communication of the renewal decision is not necessary when the only transaction input is the renewal transaction. When another decision is input at the time of the renewal (disentitlement, disqualification or allocation of earnings) communication of the decision is necessary.

Officers who are responsible for communicating the decision usually send the appropriate ACS letter. Under certain situations, the R-01-00-00 letter is sent automatically. Officers must ensure that the letter was sent and, if was not, they must create and send the letter of decision in ACS.

If a renewal and an allocation are input by the same officer and are processed on the same day, the R-01-00-00 letter is, in most cases, created automatically.

There are some exceptions. The letter does not automate if one of the following conditions is met;

- One of the transactions (M106 or M175) rejects.

- The allocation code on the M175 is A.

- An E or W allocation is input for more than one week.

- A stop payment is imposed (MA01, MA02, MA48, MA71, MA72, MA73, MA74, MA75).

- A disqualification or disentitlement is being input.

- A disqualification or disentitlement is already on file and is not being rescinded or terminated.

In some cases, the letter may automate but additional decisions must be communicated. To prevent duplication of letters, the officer must prevent the automated letter from being sent by using the Automated Letter Bypass function in FTS. 

### Note

Source topic: `en_EN/common_notes/note_c_0021.dita`

Note:

If the client has a violation, there may be increased entrance requirements .
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Note

Source topic: `en_EN/common_notes/note_c_2653.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2737.dita`

Note:

If a client is not entitled to sickness benefits, the officer must determine if the client can establish a new claim. If the client filed a renewal application, it is used to determine if the client qualifies for a new initial claim. 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_2738.dita`

Note:

The temporary measure for medical certificates ends September 25, 2021. For all BPs with a BPC or renewal week of September 26, 2021 (w/c 2310) or later, the officer follows normal procedures.

For BPs with a BPC or renewal week between March 15, 2020 (w/c 2230) and September 19, 2021 (w/c 2309), a client is not required to provide a medical certificate to receive sickness benefits. For more details, the officer refers to the previous version of this task by selecting the link at the bottom of the page. 

### Note

Source topic: `en_EN/common_notes/note_c_2752.dita`

Note:

A client is not required to demonstrate good cause for delay when submitting a medical certificate. The Level 1 officer can modify or rescind a disentitlement related to a missing medical certificate for special benefits, regardless of the length of delay, provided all other conditions are met for the requested BT. 

### Note

Source topic: `en_EN/common_notes/note_c_2711.dita`

Note:

Deferral of fact-finding and adjudication of a contentious RFS can be considered even if a D16 is imposed. 

## Regional considerations

Source topic: `en_EN/task/conv_parsick/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/conv_parsick/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/conv_parsick/in_nws.dita`

- Did the client apply for a renewal requesting a conversion of benefits?

- If yes, review processing activities for the web application and take notes if necessary:

- What issues did ACP detect?

- Does it indicate why the claim tripped down?

- Does the client have a 900-series SIN?

- Has the client worked since the last week paid?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies, workers’ compensation benefits (WCB), motor vehicle accident compensation or wage loss insurance (WLI) payments to consider or allocate?

- Is there a new contentious RFS?

- Is there an ADJ WI?

- If yes, for what issue?

- Is there a medical certificate on file or has one been uploaded?

- Are there any work or personal restrictions on file? 

### In FTS:

Source topic: `en_EN/task/conv_parsick/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the last renewable week (LRW) been reached?

- Has the waiting period (WP) been served, half served, waived or deferred?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Is there an RTW on the claim?

- Are there any pended claimant’s reports or claimant’s reports to be processed before the conversion?

- Is there a registration number? 

### In RCM:

Source topic: `en_EN/task/conv_parsick/in_rcm.dita`

- Has the ROE been submitted?

- Are there earnings, separation monies, WCB, motor vehicle accident compensation or WLI payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/conv_parsick/in_imaging.dita`

- Is there a medical certificate on file?

- What is the recovery date?

- What is the incapacity start date?

- Is there any other documentation which may impact the conversion claim? 

## Step by step

Source topic: `en_EN/task/conv_parsick/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/conv_parsick/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/conv_parsick/reviewing_the_file_level_1.dita`

- In NWS, determine if there is a SIR Validation (SIR) WI:

- If yes, go to step 2.

- If no, go to step 4.

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for the SIR WI to be completed.”

- Bring forward date: Enter today’s date + 10 days.

- When the CA WI moves to the current workload, determine if the SIR WI has been completed:

- If no, repeat step 2.

- If yes, go to step 4.

- In FTS, determine if a registration number related to the conversion is on file:

- If yes, go to step 5.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Go to step 5.

- In FTS, determine if the maximum combination of regular and special benefits has been paid:

- If yes, go to Maximum combination of regular and special benefits paid .
               [Maximum combination of regular and special benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_parsick#maxcom)

- If no, determine if the maximum number of weeks of sickness benefits has been paid:

- If no, go to step 6.

- If yes, go to Maximum sickness benefits paid .
                   [Maximum sickness benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_parsick#maxsick)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- Determine if there is a pending E-report on the E-Report tab for the period before the conversion:

- If there is no pending E-report, go to step 7.

- If there is a pending E-report, refer to Actioning a pending claimant’s report and then go to step 7.
               [Actioning a pending claimant’s report](/en/procedure/task/pending_cr.shtml)

- Determine if there are any rejected E-reports on the Pending/Reject tab for the period before the conversion:

- If no, go to step 8.

- If yes, re-input the reports. Refer to Actioning a rejected claimant’s report and then go to step 8.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml)

- Determine if the client reports having received monies and whether they have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings and then go to step 9.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 9.

- If no monies were received, go to step 9.

- In NWS and in FTS, determine if one of the following conditions applies:

- The client was incarcerated, and has since been tried and has not been found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received monies on separation for a definite job loss and allocation prevented benefits from being paid.

- If one of the conditions applies, refer to Benefit period extension and then go to step 10.
               [Benefit period extension](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions applies, go to step 10.

- Determine if the LRW has been reached:

- If no, go to step 11.

- If yes, go to Last renewable week (LRW) has been reached .
               [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_parsick#LRW)

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 12.

- If no, go to step 14.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, go to step 13.

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 14.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine the claim type:

- If it is a conversion on a continuing claim, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 14.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If it is a conversion on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next Available User .

- Issue(s): Select Availability .

- Details: Type “Outstanding D15 for a missed client information session, Level 2 review required.”

- Select Save .

- Go to step 14.

- Determine if there are any other outstanding disentitlements on file:

- If no, go to step 16.

- If yes and the conversion is on a continuing claim, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save.

- Refer to the appropriate procedure and go to step 15.

- If yes, and the conversion is done on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Details: Type “Outstanding [type of disentitlement] disentitlement.”

- Select Save .

- Refer to the appropriate procedure and then go to step 16.

- Determine if the conditions are met to terminate or rescind the disentitlement at Level 1 according to the National Policy on Levels of Decision :

- If yes, terminate or rescind the disentitlement and go to step 16.

- If no, reassign the WI to Level 2 and go to step 16.

- Determine if there are any outstanding issues that require adjudication that do not have a related WI:

- If no, go to step 18.

- If yes and the conversion is on a continuing claim, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 17.

- If yes, and the conversion is done on a renewal claim, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Details: Indicate the reason the WI is being created.

- Select Save .

- Refer to the appropriate procedure and then go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2732.dita)

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If yes, complete the steps from the appropriate procedure and go to step 18.

- If no, reassign the WI to Level 2 and go to step 18.

- Determine if an acceptable medical certificate is on file:

- If yes, go to step 19.

- If no, go to step 20.

- Determine if the incapacity start date, the doctor’s signature date or the date the doctor saw the client is on the medical certificate:

- If no, go to step 20.

- If yes, go to step 26. 

#### Fact-finding to obtain a medical certificate

Source topic: `en_EN/task/conv_parsick/fact-finding_to_obtain_a_medical_certificate_level_1.dita`

- Fact-find with the client and ask the client to submit a valid medical certificate with the required information. Refer to the National Fact-Finding and Documentation Policy if needed.

- Determine if the client was contacted during fact-finding or if the client responded to the N-10-00-00 ACS letter:

- If the client was contacted, go to step 22.

- If the client was not contacted, go to step 23.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Conversion .

- Comments: Type “Conversation with the client — medical certificate requested.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client submitted an acceptable medical certificate:

- If a medical certificate was requested but is not on file, go to step 24.

- If a medical certificate is on file, go to step 26.

- If the client was not contacted and the medical certificate is not on file, go to step 27.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Medical certificate .

- Comments: Type “Awaiting medical certificate.”

- Bring forward date: Enter [10 days from the day the client was contacted].

- When the WI moves to the current workload, determine if an acceptable medical certificate has been submitted:

- If yes, go to step 26.

- If no, go to step 27.

- Determine if there is a gap between the effective conversion date and the incapacity start date:

- If yes, use the start date indicated on the medical certificate and go to step 27.

- If no, use the start date indicated on the medical certificate and go to step 28.

- In NWS, create a ROD as follows:

- Comments: Type the appropriate option:

- “D16 imposed — Incapacity start date not proven.”

- “D16 imposed — No medical certificate submitted.”

- Details: Type the appropriate option:

- If the medical certificate was not submitted, type “The client has not submitted a medical certificate. Indefinite D16 imposed from [the week of the conversion].”

- If the incapacity start date declared by the client does not match the incapacity start date, the date the doctor saw the client or the doctor’s signature date on the medical certificate, type “Incapacity start date declared by client does not match the medical certificate. D16 imposed from [the period declared by the client] to [the Friday before the incapacity start date].”

- If there is no incapacity start date, no date the doctor saw the client or no doctor’s signature date on the medical certificate, type “The incapacity start date declared by the client is not supported by the medical certificate. Indefinite D16 imposed from the [week of the conversion].”

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2753.dita)

- Determine the recovery week by referring to Determining the Recovery week — Instructions and go to step 29.

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine if the conversion is on a renewal claim:

- If the conversion is on a renewal claim, go to step 31.

- If the conversion is on a continuing claim, go to Conversion on a continuing claim .
               [Conversion on a continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_parsick#Conversion)

- In NWS, determine if there is an outstanding ADJ WI:

- If there is no ADJ WI, go to Conversion on a renewal claim — No outstanding adjudication .
               [Conversion on a renewal claim — No outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_parsick#NoOutAdj)

- If there is an ADJ WI, go to Conversion on a renewal claim — Outstanding adjudication .
               [Conversion on a renewal claim — Outstanding adjudication](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_parsick#OutAdj) 

#### Maximum combination of regular and special benefits already paid

Source topic: `en_EN/task/conv_parsick/maximum_combination_of_regular_and_spec_5cf2309f_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D22 imposed — maximum combination of benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC. D22 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as [number of hours] hours were accumulated after the BPC and the client needed [number of hours] hours to qualify. D22 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction and impose the D22 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Leave this field blank.

- Action: Select Add .

- Disentitlement: Select 22 - Illness (maximum sickness / special benefits paid) .

- Start date: Select the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D22 - Max sickness paid/max sick paid but approved regular or maternity benefits /max combination of special benefits reached (3069) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Maximum sickness benefits already paid

Source topic: `en_EN/task/conv_parsick/maximum_sickness_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D22 imposed — sickness benefits exhausted.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as maximum sickness benefits have been paid. The client does not qualify for a new claim as no hours were accumulated after the BPC. D22 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as maximum sickness benefits have been paid. The client does not qualify for a new claim as [number of hours] hours were accumulated after the BPC and the client needed [number of hours] hours. D22 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction and impose the D22 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 22 - Illness (maximum sickness / special benefits paid) .

- Start date: Select the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special Benefits Denied (3065): Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066):

- Select D22 - Max sickness paid/max sickness paid but approved regular or maternity benefits /max combination of special benefits reached (3069) .

- Select D22 - Max weeks of sickness already paid .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Sickness maximum of 15 or 26 weeks (12545) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/conv_parsick/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for sickness benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “LRW reached — sickness benefits requested.”

- Details: Select one of the following:

- If the client has not worked since the BPC , type “No conversion is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as no hours were cumulated after the BPC. Parental benefits are still payable.”

- If the client has worked since the BPC , type “No conversion is possible as the LRW has been reached and no BP extension is possible. The client does not qualify for a new claim as [number of hours] hours were accumulated after the BPC. Client needed [number of hours] hours to qualify. Parental benefits still payable.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612):
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2754.dita)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction to complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Conversion on a continuing claim

Source topic: `en_EN/task/conv_parsick/conversion_on_a_continuing_claim_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select the appropriate option:

- 3 - Sickness - major attached .

- 9 - Sickness - minor attached .

- Manual Action: Select the appropriate option (only if Level 2 adjudication is required).

- Select the Special benefits (M106) link and input the following information on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

- If a D16 is also required, complete the following fields:

- Action: Select Add .

- Disentitlement: Select 16 - No medical certificate submitted .

- Start: Select the Monday of the renewal week.

- End: Select the Friday before the incapacity start date or Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select the appropriate option:

- If the renewal did not require Level 2 adjudication, select 1 - No .

- If the renewal required Level 2 adjudication, select 2 - Yes .

- Complete: Select the appropriate option

- If Level 2 adjudication is required, select D - No to leave the registration number open for subsequent transactions.

- If Level 2 adjudication is not required, select C - Yes to clear the registration number.

- Select Update

- Determine if sickness benefits have been allowed:

- If yes, go to step 3.

- If no, go to step 4.

- Determine what must be communicated to the client:

- If an allocation of earnings and any other decisions must be communicated:

- Advise the client of the renewal/revival week, the number of weeks payable, the allocation and any other decisions. Go to step 5.

- If an allocation of earnings must be communicated:

- Advise the client of the renewal/revival week, the number of weeks payable and the allocation. Go to step 5.

- If no other decision must be communicated:

- Advise the client of the renewal/revival week and the number of weeks payable. Go to step 5.

- Determine what must be communicated to the client:

- If an allocation of earnings and any other decisions must be communicated:

- Advise the client of the renewal/revival week, the allocation and any other decisions. Go to step 5.

- If an allocation of earnings must be communicated:

- Advise the client of the renewal/revival week and the allocation. Go to step 5.

- If no other decision must be communicated:

- No letter is required. Go to step 10.

- In ACS, select the appropriate option:

- If the file does not require Level 2 adjudication, create and send or add to the saved N-00-00-00 letter and send.

- If the file requires Level 2 adjudication, create and save or add to the saved N-00-00-00 letter and save.

- In the N-00-00-00 letter, based on the claim information, select all of the required attributes, including the following:

- To advise the client of the renewal week:

- Renewal week - Sunday’s date (1246) .

- To advise the client that the antedate has been denied:

- Antedate denied or postdate message - Initial/renewal/continuing claims (2481) .

- Select Antedate denied (2483) .

- Select Antedate denied - Renewal/continuing claims (2484) .

- Select Renewal application not filed on time and no good cause for delay .

- Date to which Antedate is requested (1144): Select the appropriate date.

- To advise the client that sickness benefits have been approved:

- Special benefits approved (3046) .

- Sickness benefits approved (3047) .

- Select Sickness approved - Client must provide medical certificate .

- Start date Sickness benefits - Sunday’s date (1252) .

- End date Sickness benefits - Saturday’s date (1254) .

- To advise the client of the D16 (definite or indefinite):

- Special Benefits denied (3065) .

- Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D16 - No medical certificate provided / incapacity ended / gradual return (3068) .

- Select D16 - No medical certificate provided .

- Indefinite/Definite/Multiple Disentitlement dates (2485) : Select the appropriate option.

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of earnings - Only from ROE #1 - Monies allocated beyond BPC (2523)

- Select Monies from last employer are allocated [with balance in wk 1 msg] .

- Pension Allocation (2525) (if the client is receiving a pension):

- Select the appropriate option.

- Weekly Indemnity Allocation (2529) (if the client is receiving an indemnity payment):

- Select the appropriate option.

- Allocated monies that prevent payment of sickness benefits (3090) (if necessary):

- Select the appropriate option.

- Waiting period message (2445) (if the client has not served the WP):

- Select the appropriate option.

- Message for sickness claim - Is client receiving any other payment? (WLI / PSL / WCB / MVA) (3092)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In ACS, determine if there is a saved D-01-00-00 letter:

- If yes, go to step 8.

- If no, go to step 9.

- Determine if all the decisions which must be communicated to the client are included in the N-00-00-00 letter:

- If yes, delete the letter.

- If no, send the letter with only the decisions that are left to be communicated.

- In NWS, if the file requires Level 2 adjudication, create a client Note and type “Send the N-00-00-00 letter.”

- Determine if Level 2 adjudication is required:

- If no, go to step 11.

- If yes, in NWS, reassign any CR WI for the contentious issue to Level 2 as follows:

- Destination — SCC: Select the SCC as shown in FTS.

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Not within Level 1 authority.”

- Go to step 11.

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2742.dita)

- In NWS, complete the Conversion WI. 

#### Conversion on a renewal claim — No outstanding adjudication

Source topic: `en_EN/task/conv_parsick/conversion_on_a_renewal_claim__no_outst_8874a6e6_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal : Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select the appropriate option:

- 3 - Sickness - major attached

- 9 - Sickness - minor attached

- Select the Special benefits (M106) link and input the following information on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

- If a D16 is also required, complete the following fields:

- Action: Select Add .

- Disentitlement: Select 16 - No medical certificate submitted .

- Start: Select the Monday of the renewal week.

- End: Select the Friday before the incapacity start date or Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select the appropriate option:

- If the renewal did not require Level 2 adjudication, select 1 - No .

- If the renewal required Level 2 adjudication, select 2 - Yes .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- Determine if there is an allocation that must be communicated to the client:

- If yes, go to step 3.

- If no, go to step 7.

- Determine if one of the following situations applies:

- There is a denied antedate.

- There is an MA2 on file.

- A disentitlement or a definite disqualification is being imposed manually.

- Sickness benefits have been approved to a specific date (for less than the maximum number of weeks payable for this BPC).

- If no, go to step 4.

- If yes, go to step 6.

- In NWS, move the CA Renewal WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting confirmation that automated R-01-00-00 letter was sent.”

- Bring forward date: Enter today’s date + 1 day.

- When the WI moves to the current workload, determine if the automated R-01-00-00 letter was sent:

- If no, go to step 7.

- If yes, go to step 13.

- In FTS, select the File Control Data (M101) transaction as follows:

- Select Claim Action .

- Select Automated Letter Bypass .

- Determine if sickness benefits have been allowed for 8 weeks or less:

- If yes, go to step 8.

- If no, go to step 9.

- Determine what must be communicated to the client:

- If an allocation of earnings and any other decisions must be communicated:

- Advise the client of the renewal/revival week, the number of weeks payable, the allocation and any other decisions. Go to step 10.

- If an allocation of earnings must be communicated:

- Advise the client of the renewal/revival week, the number of weeks payable and the allocation. Go to step 10.

- If no other decision must be communicated:

- Advise the client of the renewal/revival week and the number of weeks payable. Go to step 10.

- Determine what must be communicated to the client:

- If an allocation of earnings and any other decisions must be communicated:

- Advise the client of the renewal/revival week, the allocation and any other decisions. Go to step 10.

- If an allocation of earnings must be communicated:

- Advise the client of the renewal/revival week and the allocation. Go to step 10.

- If no other decision must be communicated:

- No letter is required. Go to step 13.

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following.

- To advise the client of the renewal week:

- Renewal week - Sunday’s date (1246) .

- To advise the client that the antedate has been denied:

- Antedate denied or postdate Message – Initial/renewal/continuing claim (2481) .

- Select Antedate denied (2483) .

- Select Antedate denied - Renewal/continuing claims (2484) .

- Select Renewal application not filed on time and no good cause for delay .

- Date to which Antedate is requested (1144): Select the appropriate date.

- To advise the client that sickness benefits have been approved:

- Special benefits approved (3046) .

- Sickness benefits approved (3047) .

- Select Sickness approved - Client must provide medical certificate .

- Start date Sickness benefits - Sunday’s date (1252) .

- End date Sickness benefits - Saturday’s date (1254) .

- To advise the client of the D16 (definite or indefinite):

- Special Benefits denied (3065) .

- Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D16 - No medical certificate provided / incapacity ended / gradual return (3068) .

- Select D16 - No medical certificate provided .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select the appropriate option.

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of earnings - Only from ROE #1 - Monies allocated beyond BPC (2523)

- Select Monies from last employer are allocated [with balance in wk 1 msg] .

- Pension Allocation (2525) (if the client is in receipt of a pension):

- Select the appropriate option.

- Weekly Indemnity Allocation (2529) (if the client is in receipt of an indemnity payment):

- Select the appropriate option.

- Allocated monies that prevent payment of sickness benefits (3090) (if necessary):

- Select the appropriate option.

- Waiting period message (2445) (If the client has not served the WP):

- Select the appropriate option.

- Message for sickness claim - Is client receiving any other payment? (WLI / PSL / WCB / MVA) (3092) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In ACS, determine if there is a saved D-01-00-00 letter:

- If yes, go to step 12.

- If no, go to step 13.

- Determine if all decisions which must be communicated to the client are included in the N-00-00-00 letter:

- If yes, delete the letter.

- If no, send the letter with only decisions that are left to be communicated.

- In NWS, determine if the conversion application was submitted using AW:

- If no go to step 14.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_parsick#subsequent_claims)

- Complete the CA WI. 

#### Conversion on a renewal claim — Outstanding adjudication

Source topic: `en_EN/task/conv_parsick/conversion_on_a_renewal_claim__outstand_c972fb4d_level_1.dita`

- Select the Renewal / Revised (M106) transaction and input the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal : Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if necessary).

- Claim type: Select the appropriate option:

- 3 - Sickness - major attached

- 9 - Sickness - minor attached

- Select the Special benefits (M106) link and input the following information on the Sickness tab:

- Last day worked: Select the appropriate date.

- Recovery week: Select the appropriate Saturday.

- Select Save .

- If a D16 is also required, complete the following fields:

- Action: Select Add .

- Disentitlement: Select 16 - No medical certificate submitted .

- Start: Select the Monday of the renewal week.

- End: Select the Friday before the incapacity start date or Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select the appropriate option:

- If the renewal did not require Level 2 adjudication, select 1 - No .

- If the renewal required Level 2 adjudication, select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if sickness benefits have been allowed for 8 weeks or less:

- If yes, go to step 3.

- If no, go to step 4.

- Determine what must be communicated to the client:

- If an allocation of earnings and the imposed D16 must be communicated:

- Advise the client of the renewal/revival week, the number of weeks payable, the D16 and the allocation. Go to step 5.

- If an allocation of earnings must be communicated:

- Advise the client of the renewal/revival week, the number of weeks payable and the allocation. Go to step 5.

- If no other decision must be communicated:

- Advise the client of the renewal/revival week and the number of weeks payable. Go to step 5.

- Determine what must be communicated to the client:

- If an allocation of earnings and the imposed D16 must be communicated:

- Advise the client of the renewal/revival week, the D16 and the allocation. Go to step 5.

- If an allocation of earnings must be communicated:

- Advise the client of the renewal/revival week and the allocation. Go to step 5.

- If no other decision must be communicated:

- No letter is required. Go to step 7.

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following.

- To advise the client of the renewal week:

- Renewal week - Sunday’s date (1246) .

- To advise the client that sickness benefits have been approved:

- Special benefits approved (3046) .

- Sickness benefits approved (3047) .

- Select Sickness approved - Client must provide medical certificate .

- Start date Sickness benefits - Sunday’s date (1252).

- End date Sickness benefits - Saturday’s date (1254).

- To advise the client of the D16 (definite or indefinite):

- Special benefits denied (3065) .

- Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- Select D16 - No medical certificate provided / incapacity ended / gradual return (3068) .

- Select D16 - No medical certificate provided .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select the appropriate option.

- To advise the client of the allocation:

- Allocation of Earnings (2516):

- Allocation of earnings - Only from ROE #1 - Monies allocated beyond BPC (2523)

- Select Monies from last employer are allocated [with balance in wk 1 msg] .

- Pension allocation (2525) (if the client is in receipt of a pension):

- Select the appropriate option.

- Weekly indemnity allocation (2529) (if the client is in receipt of an indemnity payment):

- Select the appropriate option.

- Allocated monies that prevent payment of sickness benefits (3090) (if necessary):

- Select the appropriate option.

- Waiting period messages (2445) (If the client has not served the WP):

- Select the appropriate option.

- Message for sickness claim - Is client receiving any other payment? (WLI / PSL / WCB / MVA) (3092) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, create a client Note and type “Send the N-00-00-00 letter.”

- In NWS, determine if the conversion application was submitted using AW:

- If no go to step 8.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_parsick#subsequent_claims)

- Complete the CA WI. 

#### Subsequent claims

Source topic: `en_EN/task/conv_parsick/subsequent_claims_level_1.dita`

- Determine if there are 4 weeks or fewer of benefits payable remaining in the BP:

- If yes, go to step 2.

- If no, go to step 4.

- Determine if the renewal was finalized 28 calendar days after the renewal application was submitted (i.e. application date + 27 days) or if the Status field on the Summary tab in FTS displays 8 - Converted to Manual Pay :

- If yes, go to step 3.

- If no, go to step 4.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Subsequent claim not automated.”

- Due date: Select the [LRW + 3 weeks].

- Language: Select the appropriate option.

- Details: Type “Subsequent claim to be established.”

- Destination — SCC : Select the SCC as shown in FTS.

- End User: Select Next available user .

- Complete the CA WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Note

Source topic: `en_EN/common_notes/note_c_2732.dita`

Note:

When converting a claim to regular or sickness benefits, always determine if the client is available or otherwise available. 

#### Note

Source topic: `en_EN/common_notes/note_c_2753.dita`

Note:

When finalizing the conversion, you must impose a D16 and send an N-00-00-00 letter to inform the client that sickness benefits have been denied. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2754.dita`

“We cannot reactivate your claim for Employment Insurance benefits starting (Renewal week - Sunday’s date) . Please note that we are required to advise you of all decisions made on your claim.

No sickness benefits are payable to you on this claim because the last renewal week has been reached on this benefit period.

To receive regular benefits, you must work the required minimum number of insurable employment hours. If you want to receive regular benefits in the future, you must apply for a new claim.” 

#### Note

Source topic: `en_EN/common_notes/note_c_2742.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose a 1 - General suspension of benefits (stop payment) manual action (MA1) to stop payment. 

## Policy reference

Source topic: `en_EN/task/conv_parsick/policy_reference.dita`

- EIA 12(6)
         [EIA 12(6)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 21(1)
         [EIA 21(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-21.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- National Policy on Proof of Incapacity
         [National Policy on Proof of Incapacity](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/proof_of_incapacity_policy.shtml) 
