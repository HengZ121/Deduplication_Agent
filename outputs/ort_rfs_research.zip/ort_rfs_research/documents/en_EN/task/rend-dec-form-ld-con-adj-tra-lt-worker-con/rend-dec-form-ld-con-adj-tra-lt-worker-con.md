# Adjudicating training for a long-tenured worker — Continuing claim

Source map: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/rend-dec-form-ld-con-adj-tra-lt-worker-con.ditamap`

## Summary

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/summary.dita`

Summary: When a client identified as a long-tenured worker reports attending full-time training, adjudication is required to determine entitlement to benefits during the training period. 

## What you need to know

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/training_reported_between_september_27__5ecd71c7.dita`

ACP allowed all training the client reported between September 27, 2020 and September 11, 2021 on an application for benefits, claimant’s report or in MSCA. If there is a WI in NWS to confirm referred training, the officer follows the steps to confirm that the client is participating in referred training. If after fact-finding the officer cannot confirm that the training was referred, the officer refers to the appropriate non-referred training task. 

### Referred training

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/referred_training.dita`

When the client is unemployed and able to establish a claim for regular or fishing benefits, Service Canada or an authority designated by Service Canada can refer the client to attend training under EIA 25. Referred training may include training and programs of instruction, or participation in any other employment activity designed to facilitate the client’s re-entry into the labour force. A client who is attending referred training under EIA 25 is considered unemployed and available for work. 

### Skills Boost (Lifelong Learning Initiative)

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/skills_boost_lifelong_learning_initiative.dita`

Skills Boost was a pilot project launched in 2018 which offered several measures to support adult learners, including the Lifelong Learning Initiative. While some of the Skills Boost piloted measures have ended, Service Canada’s authority to allow clients identified as long-tenured workers to attend full-time self-funded training without losing entitlement to regular or fishing benefits has become a permanent measure. Skills Boost can also be referred to as the Lifelong Learning Initiative, is meant to complement work and services already in place from existing designated authorities. Before approving a long-tenured worker’s training, the officer must ensure that the client has not already been referred to training by their province or territory.

For more information, the officer refers to Backgrounder: Skills Boost and Employment Insurance (EI) and courses or training programs .
       [Backgrounder: Skills Boost](https://www.canada.ca/en/employment-social-development/news/2018/06/backgrounder-skills-boost.html) 
       [Employment Insurance (EI) and courses or training programs](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/courses-training.html) 

### Levels of decision

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/levels_of_decision.dita`

The Level 1 officer can allow benefits to be paid to long-tenured workers while they are attending training or an employment activity only if they have been referred under EIA 25 by the Commission, or an authority designated by the Commission.
       [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-6.html#docCont)

As of August 5, 2018, a Level 2 officer has the authority to refer clients to self-funded full-time training under EIA 25, as long as the client is identified as a long-tenured worker and all entitlement conditions are met (including contentious issues related to a reason for separation [RFS]). If the entitlement conditions are not met, the officer refers to Adjudicating non-referred training: Regular or fishing benefits — Continuing claim .
       [Adjudicating non-referred training: Regular or fishing benefits — Continuing claim](/en/procedure/task/training_fishing.shtml)

The Level 2 officer can render a decision when the client:

- is entitled to regular or fishing benefits ;
         [is entitled to regular or fishing benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#reg)

- is a long-tenured worker ;
         [is a long-tenured worker](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#ltw)

- participates in full-time training ;
         [participates in full-time training](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#fulltime)

- attends a designated, certified or approved educational institution located in Canada ;
         [attends a designated, certified or approved educational institution located in Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#design)

- requests approval to attend full-time training .
         [requests approval to attend full-time training](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#request)

Service Canada has the authority to approve full-time training for a long-tenured worker. However, before adjudicating training, the officer adjudicates other contentious issues to determine if the client is entitled to benefits. This can help the client better understand the decision-making process, as the client may assume that for a referred training situation, contentious issues are automatically allowed.

The officer must adjudicate the RFS based on the National Policy on Levels of Decision and the appropriate procedures.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4415.dita) 

### Approval start date

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/approval_start_date.dita`

If a client has not been referred to the training under EIA 25 by a designated authority, the client must get approval from Service Canada before attending training.

When the client reports training on a continuing claim, the approval is granted from the Sunday of the week Service Canada receives the client’s request. This also applies when the client reports training after the training started. In these cases, a Level 2 officer renders the approval decision as of the Sunday of the week the client made the request. The Level 2 officer adjudicates the period between the real training start date and the approved start date if the conditions are not met to adjudicate the non-referred training at Level 1.

When the client reports training on a claimant’s report, approval is granted from the Sunday of the claimant’s report in which the course starts. 

### The client is entitled to regular or fishing benefits

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/the_client_is_entitled_to_regular_or_fi_2891f36b.dita`

The client must apply for regular or fishing benefits at the time the request is made.

Long-tenured workers who receive approval for training are considered unemployed, capable of and available for work.

Officers cannot grant approval to clients entitled to self-employment benefits because they are only entitled to special benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4416.dita) 

### The client is a long-tenured worker

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/the_client_is_a_long-tenured_worker.dita`

To be considered a long-tenured worker, a client must meet the following 2 conditions:

- have paid at least 30% of the maximum EI premiums for at least 7 of the last 10 years;

- not have received more than 35 weeks of regular benefits in the last 156 weeks (3 years) before the BPC of the current claim.

The system determines the client’s status when the Initial Intake (M149) transaction is input. When the system is unable to determine the client’s status or if the client disagrees with their status, the officer refers to Determining if a client is a long-tenured worker for more information.
       [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml)

If a client was initially categorized as a long-tenured worker before the claim was established (when the Initial Decision [M103] transaction was processed) and the status changes after the course is approved (e.g. the client has not paid sufficient premiums during the last 7 out of 10 years), Service Canada does not reverse the decision. The officer documents the information on a record of decision (ROD).

If there is a subsequent claim and the client is attending the same full-time training, the long-tenured worker criteria are not re-evaluated on the subsequent claim. The client is still considered a long-tenured worker. The officer creates a ROD confirming that the client was categorized as a long-tenured worker for a previous BPC.

If there is a subsequent claim and the client is attending a new full-time training, the long-tenured worker criteria must be evaluated on the subsequent claim. 

### The client participates in full-time training

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/the_client_participates_in_full-time_training.dita`

Long-tenured workers are considered as participating in full-time training if they meet the educational institution’s definition of a full-time student. The officer can accept the client’s statement to that effect as sufficient proof.

Combining multiple part-time courses does not make the client a full-time student. 

### The client attends a designated, certified or approved educational institution located in Canada

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/the_client_attends_a_designated_certifi_ddab2365.dita`

The Level 2 officer can approve training provided by a designated or certified educational institution located in Canada. If the officer cannot find the institution on the list of designated or certified educational institutions, the officer determines if the educational institution the client is attending can be approved by considering the following 3 conditions:
       [designated](https://www.canada.ca/en/employment-social-development/programs/post-secondary/designated-schools.html) 
       [certified](http://certification.esdc.gc.ca/lea-mcl/h.4m.2@-eng.jsp) 
       [designated](https://www.canada.ca/en/employment-social-development/programs/post-secondary/designated-schools.html) 
       [certified](http://certification.esdc.gc.ca/lea-mcl/h.4m.2@-eng.jsp)

- the educational institution is located in Canada;

- the training is at the high school level or higher;

- the client will obtain or improve skills for an occupation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4417.dita) 

### The client requests approval to attend full-time training

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/the_client_requests_approval_to_attend__3ca1983e.dita`

For approval to be granted, the client must formally request to attend training. When the client completes the electronic questionnaire, the client is not able to formally request to attend training. Therefore, the officer must contact the client to get a statement. The officer contacts the client only if the client requests regular or fishing benefits and all other criteria are met.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4418.dita) 

### 900-series SIN clients

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/900-series_sin_clients.dita`

In addition to all other criteria, a client with a 900-Series SIN must hold a valid study permit to attend school while in Canada. The client must submit a copy of a valid study permit to Service Canada. 

### Voluntarily leaving employment for approved training

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/voluntarily_leaving_employment_for_appr_4e4e5e94.dita`

Service Canada has the authority to approve full-time training for long-tenured workers, but approval of training does not result in approval of an RFS related to voluntary leaving or leave of absence.

Service Canada does not authorize clients to voluntarily leave their employment to pursue training.

Voluntary leaving and the adjudication of training for long-tenured workers are separate issues. 

### Outstanding disentitlements

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/outstanding_disentitlements.dita`

On a continuing claim, there may be outstanding disentitlements that were imposed before the request for approval. Before rendering a decision, the officer reviews the facts on file to determine if the disentitlement can be terminated. If the outstanding disentitlement is no longer applicable, the officer refers to the appropriate procedure. 

### Training break, failing, being expelled or quitting a course

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/training_break_failing_being_expelled_o_5768c4eb.dita`

Training breaks of 4 weeks or less (Christmas, Easter, etc.), are considered normal and acceptable.

Breaks of a longer duration should be adjudicated to determine if the client’s availability is in order or whether it is a break or a gap in training.

Clients are responsible for making their best efforts to succeed in the training, but failing a course will have no implication on their entitlement to benefits. Clients do not need to provide proof of success.

A client who is expelled from training could lose benefit entitlement. The officer must refer these situations to Level 2. If a client reports being expelled or quitting a course, the officer can refer to Adjudicating the end of referred training for more information.
       [Adjudicating the end of referred training](/en/procedure/task/training_ert.shtml)

Clients must inform Service Canada immediately if there is a change to their training situation. 

### Claimant’s reports

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/claimants_reports.dita`

Clients will be required to complete EI claimant’s reports while on training. 

### Extending the qualifying period (QP) or benefit period (BP)

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/extending_the_qualifying_period_qp_or_b_c122ec6a.dita`

Under this measure, no extension of the QP or BP is allowed for weeks of approved training. 

### Training questionnaire

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/training_questionnaire.dita`

Clients can provide training information when completing an application on AW, on MSCA or by contacting Service Canada. When clients contact Service Canada to provide training information, the officer must complete the Training: INS3141 Training course information transcript ― Form .
       [Training: INS3141 Training course information transcript ― Form](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Training-INS3141_Training_course_information_%20transcript-Form.doc)

When a client declares the training course has ended, the officer uses the Training: End of training for long-tenured workers — Checklist when adjudicating availability.
       [Training: End of training for long-tenured workers — Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Training-End_of_training_for_long-tenured_workers-Checklist.doc) 

### Communicating the decision

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/communicating_the_decision.dita`

When approval is granted, the officer will send the N-20-18-08 letter to the client.

A decision about long-tenured worker training is a discretionary power and is not subject to appeal.

When approval is not granted, a letter is not sent. The client is considered to be attending non-referred training. Communication of the decision will occur when the non-referred training is adjudicated. 

### Automated claim processing

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/automated_claim_processing.dita`

The system does not automate a decision to grant long-tenured worker training. When the system determines there is a potential for approval to be granted, the system creates a Level 1 Adjudication (ADJ) WI. 

### Note

Source topic: `en_EN/common_notes/note_c_4415.dita`

Note:

Sometimes, there is a delay between the date the client reported training (on the EI application, on the claimant’s report, verbally, etc.) and the date an officer adjudicates the non-referred training. In these situations, if the training is approved, the officer renders the approval decision as of the Sunday of the week the client made the request, not the week the adjudication was performed. 

### Note

Source topic: `en_EN/common_notes/note_c_4416.dita`

Note:

When reviewing entitlement to regular or fishing benefits for a client identified as a long-tenured worker, the officer must also adjudicate all contentious issues related to an RFS based on the National Policy on Levels of Decision and the appropriate procedures. A client who can be referred to training as a long-tenured worker may still be disqualified from receiving regular or fishing benefits due to a contentious RFS.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

When possible, before adjudicating training, the officer must adjudicate other contentious issues to determine if the client is entitled to benefits before adjudicating the training. This will avoid confusion for the client who may assume that other contentious issues are automatically allowed.

     [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4417.dita`

Note:

Training outside Canada (whether it is an educational institution or virtual attendance) cannot be allowed for long-tenured workers’ initial, renewal or continuing claims. 

### Note

Source topic: `en_EN/common_notes/note_c_4418.dita`

Note:

Sometimes there is a delay between the date the client reported training (on the EI application, on the claimant’s report, verbally, etc.) and the date an officer adjudicates the non-referred training. In these situations, if the training is approved, the officer renders the approval decision as of the Sunday of the week the client made the request, not the week the adjudication was performed. 

## Regional considerations

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/in_fts.dita`

- Has referred training information been input on the Project tab (codes 9, 35, 39, 53, 90, 95 and 98)?

- Is there a registration number for the training issue?

- Is there an outstanding disentitlement that requires review?

- Is there a 72 - Additional training information required manual action (MA72) for the training issue?

- Are there long-tenured worker details in the Claimant category field in the Special Coding tab? 

### In NWS:

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/in_nws.dita`

- Has the training questionnaire been completed in AW?

- Is there an SROC or Action Item (AI) WI with the training information.

- Is there a ROD for the training issue? 

### In Imaging:

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/in_imaging.dita`

- Is there training information or the INS3141 form? 

### In the LMDAAccess module of EIBIS:

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/in_the_lmdaaccess_module_of_eibis.dita`

- Is there a Notice of Intent to refer the client to training? 

## Step by step

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/reviewing_the_file_level_1.dita`

- Determine if there is an indefinite disqualification on file:

- If no, go to step 2.

- If yes, refer to the appropriate task for Adjudicating non-referred training .
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

- Determine if there is a disentitlement on file (including a 46 - Variable entrance requirement not met - special benefits payable [D46] disentitlement):

- If yes, go to step 3.

- If no, go to step 4.

- Refer to the appropriate task to determine if the disentitlement can be terminated before the referred course start date:

- If yes, go to step 4.

- If no, refer to the appropriate task for Adjudicating non-referred training .
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

- Determine if the client is entitled to regular or fishing benefits:

- If yes, go to step 5.

- If no, adjudicate the claim as non-referred training. Refer to the appropriate task for Adjudicating non-referred training .
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4419.dita)

- In FTS, in the Claimant category field in the Special Coding tab, determine if the client has been categorized:

- If the Claimant category field is blank, refer to Determining if a client is a long-tenured worker :

- If the client is identified as a long-tenured worker, go to step 6.

- If the client is not identified as a long-tenured worker, adjudicate the claim as non-referred training. Refer to the appropriate task for Adjudicating non-referred training .
                   [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

               [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml)

- In EIBIS , determine if there is a Notice of Intent as follows:

- Enter your user name and password (same as Windows, firstname.lastname).

- Select Submit .

- Select LMDAAccess and enter the client’s SIN.

- Select Submit .

- If no, go to step 7.

- If yes, refer to Confirming referred training: Regular or fishing benefits — Continuing claim .
                   [Confirming referred training: Regular or fishing benefits — Continuing claim](/en/procedure/task/training_ic.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4420.dita)

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type “Unable to complete — not within Level 1 authority.”

- Select OK .

- When the Warning window is displayed, select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_4419.dita`

Note:

When reviewing a client’s entitlement to regular or fishing benefits as a long-tenured worker, if possible, first adjudicate any other contentious issues based on the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

Actioning other contentious issues first can avoid causing confusion for the client, who may assume that other contentious issues are automatically allowed.

     [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_4420.dita`

Note:

If the referring authority entered a Notice of Intent to refer the client to training, it is displayed at the bottom of the screen, below Claimant Information, EI Claim Info and Allocation of Earnings (if necessary). 

### Level 2

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/reviewing_the_file_level_2.dita`

- Determine if there is an indefinite disqualification on file:

- If no, go to step 2.

- If yes, adjudicate the claim as non-referred training. Refer to the appropriate task for Adjudicating non-referred training .
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

- Determine if there is a disentitlement on file (including a 46 - Variable entrance requirement not met - special benefits payable [D46] disentitlement):

- If yes, go to step 3.

- If no, go to step 4.

- Refer to the appropriate task to determine if the disentitlement can be terminated before the referred course start date:

- If yes, go to step 4.

- If no, adjudicate the claim as non-referred training. Refer to the appropriate task for Adjudicating non-referred training .
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

- In EIBIS determine if there is a Notice of Intent as follows:

- Enter your user name and password (same as for Windows, firstname.lastname).

- Select Submit .

- Select LMDAAccess and enter the client’s SIN.

- Select Submit .

- If no, go to step 5.

- If yes, refer to Confirming referred training: Regular or fishing benefits — Continuing claim .
                   [Confirming referred training: Regular or fishing benefits — Continuing claim](/en/procedure/task/training_ic.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4421.dita)

- Determine if the client is entitled to regular or fishing benefits:

- If yes, go to step 6.

- If no, refer to the appropriate task for Adjudicating non-referred training .
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4419.dita)

- In FTS, in the Claimant category field in the Special Coding tab, determine if the client has been categorized:

- If the Claimant category field is blank, refer to Determining if a client is a long-tenured worker :

- If the client is identified as a long-tenured worker, go to step 7.

- If the client is not identified as a long-tenured worker, refer to the appropriate task for Adjudicating non-referred training .
                   [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

               [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml)

- In NWS, review the training questionnaire from the application or the training checklist on file and determine if the client states to attend full-time training:

- If yes, go to step 8.

- If no, refer to the appropriate task for Adjudicating non-referred training .
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

- Determine if the client is attending an educational institution located in Canada:

- If yes, go to step 9.

- If no, refer to the appropriate task for Adjudicating non-referred training .
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

- Determine if the institution is found on the list of designated or certified educational institutions:

- If no, go to Institution not found on the list of designated or certified educational institutions .
               [Institution not found on the list of designated or certified educational institutions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#level2_item_2)

- If yes, go to Confirming that the client requested training approval as a long-tenured worker .
               [Confirming that the client requested training approval as a long-tenured worker](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#level2_item_3) 

#### Institution not found on the list of designated or certified educational institutions

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/institution_not_found_on_the_list_of_de_301040d6_level_2.dita`

- Determine if there is enough information to adjudicate the educational institution the client is attending:

- If no, fact-find with the client and go to step 11.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If yes, go to step 13.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 12.

- If the client was not reached or did not reply to the N-10-00-00 letter, document the attempts to communicate with the client according to the National Fact-Finding and Documentation Policy . Refer to the appropriate task for Adjudicating non-referred training .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Educational institution.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if all of the following conditions are met to approve the educational institution the client is attending:

- The educational institution is located in Canada.

- The training is at the high school level or higher.

- The client will obtain or improve skills for an occupation.

- If all conditions are met, the educational institution is approved. Go to step 14.

- If all conditions are not met, the educational institution is not approved. Refer to the appropriate task for Adjudicating non-referred training .
                   [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

- In NWS, create a ROD as follows:

- Comments: Type “Training for long-tenured worker — Institution approved.”

- Details: Type “The client’s full-time courses or training program takes place at the [name of institution]. The institution is an approved institution: the educational institution is located in Canada, the training is at the high school level or higher, and the client will obtain or improve skills for an occupation.”

- Select Save .

- Go to Confirming that the client is requesting training approval as a long-tenured worker.
               [Confirming that the client is requesting training approval as a long-tenured worker.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#level2_item_3) 

#### Confirming that the client requested training approval as a long-tenured worker

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/confirming_that_the_client_requested_tr_8f500db9_level_2.dita`

- Conduct fact-finding to determine if the client wants to request an approval to attend self-funded, full-time training for long-tenured workers. Read the following statement and get the client’s agreement:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4422.dita) 

- If the client agrees with the statement and requests an approval, go to step 2.

- If the client does not agree with the statement or does not want to request an approval, document the details of the conversation according to the National Fact-Finding and Documentation Policy . Refer to the appropriate task for Adjudicating non-referred training .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

- If the client was not reached or did not reply to the N-10-00-00 letter, document the attempts to communicate with the client according to the National Fact-Finding and Documentation Policy . Refer to the appropriate task for Adjudicating non-referred training .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml) 
               [Adjudicating non-referred training](/en/procedure/activity/training.shtml)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Long-tenured worker — approved training — regular or fishing benefits.”

- Details: Type
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4423.dita)

- Select Save .

- Go to Adjudicating the training .
               [Adjudicating the training](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#_Adjudicating_the_training) 

#### Adjudicating the training

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/adjudicating_the_training_level_2.dita`

- Determine if the client started attending the training before the request for approval was made:

- If yes, go to step 4.

- If no, go to Referred training allowed .
               [Referred training allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#ReferredTrainingAllowed)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4424.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4425.dita)

- Determine if there is enough information to adjudicate the non-referred training issue:

- If no, fact-find with the client and go to step 5.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If yes, go to step 7.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 6.

- If the client was not reached or did not reply to the N-10-00-00 letter, go to step 7.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — regular benefits.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Adjudicate the non-referred training according to the entitlement principles of Digest 10.12.2 — Persons attending courses on their own initiative :

- If the client has proven availability, go to Non-referred training allowed.
               [Non-referred training allowed.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#NonReferredTrainingAllowed)

- If the client has not proven availability, go to Entitlement not proven for non-referred training.
               [Entitlement not proven for non-referred training.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#EntitlementNotProvenNonReferred) 

#### Non-referred training allowed

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/non-referred_training_allowed_level_2.dita`

- On day 1, in NWS, create a ROD with the following information:

- Comments: Type “Non-referred training — availability in order.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- In FTS, determine if the non-referred training information has been input on the Project tab:

- If yes, go to step 10.

- If no, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the non-referred training start date.

- End date: Select the day before Service Canada received the client’s request to be referred in the initiative.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Go to step 10.

- Determine if there is a pending claimant’s report for the non-referred training period:

- If no, go to step 11.

- If yes, clear the outstanding claimant’s report. If necessary, refer to Claimant’s report . Then, go to step 11.
               [Claimant’s report](/en/procedure/activity/claimant_report.shtml)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Multiple-day inputs required.”

- Bring forward date: Enter the next day.

- On day 2, once the WI moves to the current workload, in FTS, verify if the previous transactions were posted successfully:

- If no, refer to Rejected transactions records . Correct the transaction and return to step 11.
               [Rejected transactions records](/en/procedure/activity/rt_mr05.shtml)

- If yes, go to Referred training allowed to complete the inputs for the training period that has been approved.
               [Referred training allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#_Referred_training_allowed) 

#### Entitlement not proven for non-referred training

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/entitlement_not_proven_for_non-referred_training_level_2.dita`

- On day 1, in NWS, create a ROD as follows:

- Comments: Type “Non-referred training — not available — 3 - Not available disentitlement from w/c XXXX-X to XXXX-X.”

- Details: Document the decision and rationale according to Digest 10.12.2 — Persons attending courses on their own initiative and the National Fact-Finding and Documentation Policy .
               [Digest 10.12.2 — Persons attending courses on their own initiative](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html) 
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Verbally communicate the decision to the client. Then, save the ROD.

- In FTS, determine if there is an outstanding registration number for the non-referred training issue:

- If there is an outstanding registration number, go to step 4.

- If there is no outstanding registration number, assign one on the Registration Number (M025, M030, M035) transaction as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the disentitlement as follows:

- Registration Number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Select the disentitlement start date.

- End date: Select the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if the non-referred training information has been input in the Project tab:

- If yes, go to step 6.

- If no, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the non-referred training start date.

- End date: Select the day before Service Canada received the client’s request to be referred in the initiative.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Go to step 6.

- Determine if there is a pending claimant’s report for the non-referred training period:

- If no, go to step 7.

- If yes, clear the outstanding claimant’s report. If necessary, refer to Claimant’s report . Then, go to step 7.
               [Claimant’s report](/en/procedure/activity/claimant_report.shtml)

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D3 - Not available - Various reasons (2986) .

- Select D3 - On a non-approved training course - Availability not proven/Restrictions while on a training course / Not looking for work (2987) .

- Overpayment Messages (2452) .

- Right to Request a Reconsideration (with Blank option) (4169) .

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Multiple-day inputs required.”

- Bring forward date: Enter the next day.

- On day 2, once the WI moves to the current workload, in FTS, verify if the previous transactions posted successfully:

- If no, refer to Rejected transactions records . Correct the transaction and return to step 8.
               [Rejected transactions records](/en/procedure/activity/rt_mr05.shtml)

- If yes, go to Referred training allowed to complete the inputs for the training period that has been approved.
               [Referred training allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con#ReferredTrainingAllowed) 

#### Referred training allowed

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/referred_training_allowed_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Training for long-tenured worker — approval granted.”

- Details: Type “The client’s full-time courses or training program takes place at the [name of institution], which is an approved institution. The client will attend classes from [DD-MM-YYYY] to [DD-MM-YYYY]. At the start of the claim [BPC date], the client was considered as a long-tenured worker. The client confirmed wanting to request an approval to attend self-funded, full-time training for long-tenured worker. Approval is granted starting [DD-MM-YYYY].”

- In FTS, determine if the training information has been input on the Project tab:

- If yes, go to step 3.

- If no, select the Project Data — Training (M171) transaction and input it as follows:

- Start date: Select the referred training start date.

- End date: Select the referred training end date.

- Project SCC: Enter the appropriate code.

- Training identification: Select 39 - Lifelong Learning initiative .

- Institution code: Type “201808.”

- Select Update .

- Go to step 3.

- Determine if there is a pending claimant’s report:

- If no, go to step 4.

- If yes, clear the outstanding claimant’s report. If necessary, refer to Claimant’s report . Then, go to step 4.
               [Claimant’s report](/en/procedure/activity/claimant_report.shtml)

- In ACS, create and send the N-20-18-08 letter.

- Determine if an MA72 is imposed and if there is an outstanding registration number for the training issue:

- If an MA72 is imposed but there is no registration number, go to step 6.

- If an MA72 is imposed and there is a registration number, go to step 7.

- If no MA72 is imposed but there is a revised registration number, go to step 8.

- If none of the above applies, go to step 9.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: C - Yes .

- Select Update .

- Go to step 9.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI for the training issue. 

#### Note

Source topic: `en_EN/common_notes/note_c_4421.dita`

Note:

If the referring authority has entered a Notice of Intent to refer the client to training, it is displayed at the bottom of the screen, below Claimant Information, EI Claim Info and Allocation of Earnings (if necessary). 

#### Callout

Source topic: `en_EN/common_notes/note_c_4422.dita`

“Should you qualify for regular or fishing Employment Insurance benefits and meet the entitlement criteria for this initiative, attending the training course will not affect your entitlement and/or eligibility for Employment Insurance benefits.

This decision will not extend the duration of your benefit period or increase the number of benefit weeks that you are entitled to receive.

There are no requirements to conduct job searches or accept offers of suitable employment while attending this training.

Training must be declared on your claimant’s report.

You are required to notify Service Canada immediately if you stop attending training or if your schedule changes, as it may impact entitlement to your Employment Insurance benefits. You can contact us at either 1-800-206-7218 or at a Service Canada Centre.” 

#### Callout

Source topic: `en_EN/common_notes/note_c_4423.dita`

“The client confirmed wanting to request an approval to attend self-funded, full-time training for long-tenured workers. The client was read the following statement and agrees:

Should you qualify for regular or fishing Employment Insurance benefits and meet the entitlement criteria for this initiative, attending the training course will not affect your entitlement and/or eligibility for Employment Insurance benefits.

This decision will not extend the duration of your benefit period or increase the number of benefit weeks that you are entitled to receive.

There are no requirements to conduct job searches or accept offers of suitable employment while attending this training.

Training must be declared on your claimant’s report.

You are required to notify Service Canada immediately if you stop attending training or if your schedule changes, as it may impact entitlement to your Employment Insurance benefits.

You can contact us at either 1-800-206-7218 or at a Service Canada Centre.” 

#### Note

Source topic: `en_EN/common_notes/note_c_4424.dita`

Note:

Sometimes there is a delay between the date the client reported training (on the EI application, on the claimant’s report, verbally, etc.) and the date an officer adjudicates the non-referred training. In these situations, if the training is approved, render the approval decision as of the Sunday of the week the client made the request, not the week the adjudication was performed. 

#### Note

Source topic: `en_EN/common_notes/note_c_4425.dita`

Note:

If there are weeks of training that occurred before the approval date, adjudicate those weeks as if they were weeks of non-referred training. 

## Policy reference

Source topic: `en_EN/task/rend-dec-form-ld-con-adj-tra-lt-worker-con/policy_reference.dita`

- BE 2018-05 — Training Referral for Long Tenured Workers
         [BE 2018-05 — Training Referral for Long Tenured Workers](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2018-05.shtml) 
