# Confirming apprenticeship training — Continuing claims

Source map: `en_EN/task/training_rcc/training_rcc.ditamap`

## Summary

Source topic: `en_EN/task/training_rcc/summary.dita`

Summary: When clients start attending an apprenticeship course on a continuing claim, the officer determines if they were referred to the apprentice course by a designated authority. 

## What you need to know

Source topic: `en_EN/task/training_rcc/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/task/training_rcc/training_reported_between_september_27__5ecd71c7.dita`

A transitional measure, under which ACP adjudicated and allowed all training effective September 27, 2020 has ended on September 11, 2021.If there is a WI in NWS to confirm referred training, the officer follows the steps to confirm that the client is participating in referred training. If after fact-finding the officer cannot confirm that the training was referred, the officer consults the appropriate non-referred training task. 

### Adjudication required on manually registered claims

Source topic: `en_EN/task/training_rcc/adjudication_required_on_manually_regis_d5cd9e4c.dita`

Training was automatically adjudicated and electronic records of decision (RODs) were created only on claims that were automated in ACP.

The officer manually registers claims that are not automated in ACP. Training is not automatically adjudicated on manually registered claims. Instead, ACP assigns an Adjudication Issue (ADJ) WI to an officer because it could not automate the decision. Adjudication of these training ADJ WIs is required , and the officer follows the appropriate procedures to resolve them. Even if ACP initially allowed training, when a training ADJ WI is assigned (e.g. upon renewal), the officer must adjudicate. Additionally, if it is determined that a disentitlement applies from the start date of the training course, the Level 2 officer imposes a retroactive D3. 

### Apprenticeship training

Source topic: `en_EN/task/training_rcc/apprenticeship_training.dita`

An apprenticeship is a formal program of skills acquisition in a trade, consisting of alternating periods of on-the-job and classroom training, and leading to certification as a journeyperson.

Clients who register for apprenticeship training receive an information package from a Service Canada Centre (SCC) or the province or territory, depending on the region. The package arrives 3 to 6 weeks before the training begins and contains the following information:

- instructions on how to file an EI claim

- a reference code (in most cases) to use when applying online using AW

- details about exemption reporting and advance payment 

### Determining if the client was referred to the apprenticeship course

Source topic: `en_EN/task/training_rcc/determining_if_the_client_was_referred__0acbcd90.dita`

When a client provides a valid reference code on a continuing claim, no further confirmation of the training referral is required. The training is input on the Project tab in FTS and the 21 - Apprentice full transfer training identification code is applied.

The reference code is a 16-digit code that contains the following information:

- Service Canada Processing Centre (digits 1 to 4)

- Apprenticeship application form type (02) (digits 5 and 6)

- Year (digits 7 to 10)

- Identifier (digits 11 to 16)

When clients do not know the reference code, they are advised to obtain it from the appropriate provincial or territorial referring authority. The apprentice training cannot be input until a reference code is provided to validate the training period. If the client does not provide the reference code, the training is treated as non-referred training and must be adjudicated.
       [non-referred training](/en/procedure/activity/training.shtml) 

### Adjudicating voluntarily leaving

Source topic: `en_EN/task/training_rcc/adjudicating_voluntarily_leaving.dita`

If a designated authority refers a client to the apprenticeship before voluntarily leaving a job, the officer follows the Adjudicating voluntary leaving (Level 1) — Course of instruction procedure to determine if the voluntary leaving is authorized. The voluntary leaving and the confirmation of the referred apprenticeship are 2 separate issues.
       [Adjudicating voluntary leaving (Level 1) — Course of instruction](/en/procedure/activity/voluntary_leaving.shtml) 

### Exemption from completing claimant’s reports

Source topic: `en_EN/task/training_rcc/exemption_from_completing_claimants_reports.dita`

Unless there is a situation that may affect their EI payments, apprentice trainees are not required to complete claimant’s reports during the training period. If the client provides the reference code on a continuing claim, the Claimant’s report: Declaration for exemption from completing claimant’s report―Checklist can be completed. Refer to Exemption from reporting .
       [Claimant’s report: Declaration for exemption from completing claimant’s report―Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Declaration_for_the_exemption_from_completing_claimant_reports-Checklist.doc) 
       [Exemption from reporting](/en/procedure/activity/exemption_reporting.shtml) 

### Apprentice indicator

Source topic: `en_EN/task/training_rcc/apprentice_indicator.dita`

The RFS on the client’s last ROE are used to determine the Apprentice indicator code on the M171 .

The apprentice indicator code indicates if benefits can continue to be paid after the apprenticeship period and if the client requested advance pay.

All apprenticeship claims display a no advance pay indicator, except when advance pay requested by the client is documented on the claim.
       [no advance pay](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#no_advance_pay) 
       [advance pay requested by the client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#advance_pay)

**No advance pay**

If the client does not request advance pay, the Apprentice indicator code on the M171 is determined as follows:

- When the RFS is J - Apprenticeship Training :

- Benefits stop when all the weeks of benefits have been paid for the apprenticeship period.

- The Apprentice indicator code is 1 - No advance pay, stop claimant's report at course end week .

- When the RFS is not J - Apprenticeship Training :

- Benefits continue to be paid after the apprenticeship period. After the course end week, the client must complete claimant’s reports.

- The Apprentice indicator code is 2 - No advance pay, continue claimant's reports beyond course end week .

**Advance pay requested by the client**

Advance pay is an option available to a client enrolled in apprenticeship training. It is not promoted or presented as an option on the EI application, however, clients can request advance pay. Any request for advance pay is documented on the claim.

If the client requests advance pay, the Apprentice indicator code on the M171 is determined as follows:

- When the RFS is J - Apprenticeship Training :

- Benefits stop when all the weeks of benefits have been paid for the apprenticeship period.

- The Apprentice indicator code is 3 - Advance pay, stop claimant’s reports at course end week .

- When the RFS is not J - Apprenticeship Training :

- Benefits continue to be paid after the apprenticeship period. After the course end week, the client must complete claimant’s reports.

- The Apprentice indicator code is 4 - Advance pay, continue claimant’s reports beyond course end week .

Advance payment is normally made for the period of a claimant’s report. Payments are made at the beginning of that period instead of at the end of it. Even if the payment is issued in advance, the client is still required to complete claimant’s reports. If the client does not complete claimant’s reports, the officer imposes a 37 - Advance pay apprentice - entitlement conditions not met or claimant failed to return reports (D37) disentitlement is imposed. 

### Outstanding disentitlements

Source topic: `en_EN/task/training_rcc/outstanding_disentitlements.dita`

If there is an existing 3 - Not available disentitlement (D3) imposed and the client is referred to training under EIA25, the disentitlements are terminated on the day before the training starts. 

### Communicating the decision

Source topic: `en_EN/task/training_rcc/communicating_the_decision.dita`

No letter is sent when the training is allowed. 

## Regional considerations

Source topic: `en_EN/task/training_rcc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/training_rcc/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/training_rcc/in_fts.dita`

- Is there a D3 preventing payment during the apprenticeship period?

- Is there apprenticeship information on the Project tab for the training period?

- If the client is requesting advance payment:

- is the benefit rate greater than 0?

- is the advance payment request within the start and end weeks of the course?

- is the requested week of payment later than the last week processed? 

### In RCM:

Source topic: `en_EN/task/training_rcc/in_rcm.dita`

- Is the RFS on the last ROE J - Apprenticeship Training? 

### In NWS:

Source topic: `en_EN/task/training_rcc/in_nws.dita`

- Is there any documentation (SROC, Action Item [AI] WI or Call Back [CB] WI) indicating the client’s reference code for the apprenticeship program?

- Is the client requesting advance payment?

- Is there information (the application, SROCs or AI WIs) indicating that the client requests exemption from completing claimant’s reports during the apprenticeship training period? 

### In Imaging:

Source topic: `en_EN/task/training_rcc/in_imaging.dita`

- Is there a copy of the client’s apprenticeship training documentation? 

## Step by step

Source topic: `en_EN/task/training_rcc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/training_rcc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_rcc/reviewing_the_file_level_1.dita`

- Determine if the reference code or training documents for the client’s apprenticeship program are on file:

- If proof of the apprenticeship program is not on file, go to step 2.

- If proof of the apprenticeship program is on file, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/training_rcc/fact-finding_level_1.dita`

- Fact-find with the client and ask the client to provide the reference code or a copy of the training documents for the apprenticeship program.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4827.dita)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not respond to the N-10-00-00 letter, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#Unconfirmed_referral_to)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Apprenticeship training.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Moving the training information WI to Pending

Source topic: `en_EN/task/training_rcc/moving_the_training_information_wi_to_pending_level_1.dita`

- Determine if the client stated the reference code or training documents would be provided at a later time:

- If the client stated the reference code or training documents would be provided at a later time, go to step 6.

- If the client provided the reference code, go to step 8.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact-finding client .

- Comments: Type “Waiting for proof of apprenticeship program.”

- Bring forward date: Select the date proof was requested + 10 working days.

- Select OK .

- When the WI moves to the current workload, determine if proof was provided:

- If proof was provided, go to step 8.

- If no proof was provided, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#ref_app_course_not_confirmed) 

#### Determining if the client was referred to the apprenticeship course

Source topic: `en_EN/task/training_rcc/determining_if_the_client_was_referred__0acbcd90_level_1.dita`

- Determine if the client provided a reference code:

- If yes, go to step 9.

- If no, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#Unconfirmed_referral_to)

- Validate the reference code provided as follows:

- Select Search .

- Select Search Reference Code.

- In Search SCC , type in the first 4 numbers of the reference code.

- Compare the reference code provided to those in the list and confirm it is still valid.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4828.dita)

- Determine if the client provided a valid reference code:

- If the reference code is not valid, go back to step 2.

- If the reference code is valid, go to Referred apprenticeship course confirmed .
               [Referred apprenticeship course confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#Valid_reference_code)

- If the code is not valid and step 2 has already been repeated, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#Unconfirmed_referral_to) 

#### Referred apprenticeship course not confirmed

Source topic: `en_EN/task/training_rcc/referred_apprenticeship_course_not_confirmed_level_1.dita`

- Go to Training — Non-referred . 

#### Referred apprenticeship course confirmed

Source topic: `en_EN/task/training_rcc/referred_apprenticeship_course_confirmed_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Apprenticeship training in order.”

- Details: Type “Reference code is provided for apprenticeship training.” If a D3 must be terminated, type “Terminate the D3 for the apprenticeship training.”

- In FTS, determine if the apprenticeship training information is on the Project tab:

- If the information is not on the Project tab, go to step 3.

- If the information is on the Project tab, go to step 4.

- Select the Project Data - Training (M171) transaction and input the apprenticeship training information as follows:

- Start date: Enter the start date of the training.

- End date: Enter the end date of the training.

- Project SCC: Enter the first 4 digits of the reference code.

- Project number: Enter the first 10 digits of the reference code

- Training identification: Select 21 - Apprentice full-transfer labour market agreement .

- Apprentice indicator: Determine if there is an advance pay request:

- If there is no advance payment request and the RFS is J - Apprenticeship Training , select 1 - No advance pay, stop claimant's report at course end week .

- If there is no advance payment request and the RFS is not J - Apprenticeship Training , select 2 - No advance pay, continue claimant's report beyond course end week .

- If there is an advance payment request and the RFS is J - Apprenticeship Training , select 3 - Advance pay, stop claimant’s report at course end week .

- If there is an advance payment request and the RFS is not J - Apprenticeship Training , select 4 - Advance pay, continue claimant’s report beyond course end week .

- Claimant’s report: Determine if the client’s request for exemption from reporting is on file:

- If the client’s request is on file, select No .

- If the client’s request is not on file, leave blank.

- Institution code: Type the first 6 digits of the reference code.

- Select Update .

- Determine if there is a D3 imposed because the clients did not prove their availability while attending the course of instruction:

- If there is a D3 preventing payment, go to step 5.

- If there is no D3 preventing payment, go to step 7.

- In FTS, determine if there is a registration number for the apprenticeship training issue:

- If yes, go to step 6.

- If no , select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Disqualifications/Disentitlements link to terminate the D3 as follows:

- Select the appropriate disentitlement ( 3 - Not available ).

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following:

- Registration number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End date: Select the Friday of the week before the apprenticeship training start date.

- Detection: Select 31 - Other - new facts-entitlement review .

- Infraction: For a D3, select B - Non-fraud - Availability, capability.

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select one of the following:

- C - Yes to complete the registration number

- D - No to leave the registration number open for subsequent transactions

- Select Update .

- Go to step 11.

- Determine if an MA72 is imposed and if there is a registration number for the apprenticeship training issue:

- If an MA72 is not imposed but there is a revised registration number, go to step 10.

- If an MA72 is imposed but there is no registration number, go to step 8.

- If an MA72 is imposed and there is a registration number, go to step 9.

- If none of the above applies, go to step 11.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the applicable registration number.

- Manual action: Select 72 - Additional Training information required.

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 11.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4827.dita`

Note:

If the client requests exemption from completing claimant’s reports, complete the Claimant’s report: Declaration for exemption from completing claimant’s report ― Checklist . The form is copied into a separate SROC.
       [Claimant’s report: Declaration for exemption from completing claimant’s report ― Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Declaration_for_the_exemption_from_completing_claimant_reports-Checklist.doc)

     [Claimant’s report: Declaration for exemption from completing claimant’s report ― Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Declaration_for_the_exemption_from_completing_claimant_reports-Checklist.doc) 

#### Note

Source topic: `en_EN/common_notes/note_c_4828.dita`

Note:

If there is no SCC that matches those numbers, it is not a valid code. 

### Level 2

Source topic: `en_EN/task/training_rcc/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_rcc/reviewing_the_file_level_2.dita`

- Determine if the reference code or training documents for the client’s apprenticeship program are on file:

- If proof of the apprenticeship program is not on file, go to step 2.

- If proof of the apprenticeship program is on file, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/training_rcc/fact-finding_level_2.dita`

- Fact-find with the client and ask him or her to provide the reference code or a copy of the training documents for the apprenticeship program.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4829.dita)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not respond to the N-10-00-00 letter, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#ref_app_course_not_confirmed)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Apprenticeship training.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Moving the training information WI to Pending

Source topic: `en_EN/task/training_rcc/moving_the_training_information_wi_to_pending_level_2.dita`

- Determine if the client stated the reference code or training documents would be provided at a later time:

- If the client stated the reference code or training documents would be provided at a later time, go to step 6.

- If the client provided the reference code, go to step 8.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact finding client .

- Comments: Type “Waiting for proof of apprenticeship program.”

- Bring forward date: Select the date proof was requested + 10 working days.

- Select OK .

- When the WI moves to the current workload, determine if proof was provided:

- If proof was provided, go to step 8.

- If no proof was provided, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#ref_app_course_not_confirmed) 

#### Determining if the client was referred to the apprenticeship course

Source topic: `en_EN/task/training_rcc/determining_if_the_client_was_referred__0acbcd90_level_2.dita`

- Determine if the client provided a reference code:

- If yes, go to step 9.

- If no, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#ref_app_course_not_confirmed)

- Validate the reference code provided as follows:

- Select Search .

- Select Search Reference Code .

- In Search SCC , enter the first 4 numbers of the reference code.

- Compare the reference code provided to those in the list and confirm it is still valid.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4828.dita)

- Determine if the client provided a valid reference code:

- If the reference code is not valid, go back to step 2.

- If the code is not valid and step 2 has already been repeated, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#ref_app_course_not_confirmed)

- If the reference code is valid, go to Referred apprenticeship course confirmed .
               [Referred apprenticeship course confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_rcc#Valid_reference_code_2) 

#### Referred apprenticeship course not confirmed

Source topic: `en_EN/task/training_rcc/referred_apprenticeship_course_not_confirmed_level_2.dita`

- Go to Training — Non-referred . 

#### Referred apprenticeship course confirmed

Source topic: `en_EN/task/training_rcc/referred_apprenticeship_course_confirmed_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Apprenticeship training in order.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy . Type “Reference code is provided for apprenticeship training.” If a D3 must be terminated, type “Terminate the D3 for the apprenticeship training.”
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the apprenticeship information is on the Project tab:

- If the information is not on the Project tab, go to step 3.

- If the information is on the Project tab, go to step 4.

- Input the apprenticeship training information on the Project Data - Training (M171) transaction as follows:

- Start date: Enter the start date of the training.

- End date: Enter the end date of the training.

- Project SCC: Enter the first 4 digits of the reference code.

- Project number: Enter the first 10 digits of the reference code

- Training identification: Select 21 - Apprentice full-transfer labour market agreement .

- Apprenticeship indicator: Determine if there is an advance pay request:

- If there is no advance payment request and the RFS is J - Apprenticeship Training , select 1 - No advance pay, stop claimant's report at course end week .

- If there is no advance payment request and the RFS is not J - Apprenticeship Training , select 2 - No advance pay, continue claimant's report beyond course end week .

- If there is an advance payment request and the RFS is J - Apprenticeship Training , select 3 - Advance pay, stop claimant’s reports at course end week .

- If there is an advance payment request and the RFS is not J - Apprenticeship Training , select 4 - Advance pay, continue claimant’s reports beyond course end week .

- Claimant’s report: Determine if the client’s request for exemption from reporting is on file:

- If the request is on file, select No .

- If the request is not on file, leave blank.

- Institution code: Type the first 6 digits of the reference code.

- Select Update .

- Determine if there is a D3 imposed because the clients did not prove their availability while attending the course of instruction:

- If there is a D3 preventing payment, go to step 5.

- If there is no D3 preventing payment, go to step 7.

- In FTS, determine if there is a registration number for the apprenticeship training issue:

- If yes, go to step 6.

- If no , select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Disqualifications/Disentitlements link to terminate the D3 as follows:

- Select the appropriate disentitlement ( 3 - Not available ).

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following:

- Registration number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End date: Select the Friday of the week before the apprenticeship training start date.

- Detection: Select 31 - Other - new facts-entitlement review .

- Infraction: For a D3, select B - Non-fraud - Availability, capability.

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select one of the following:

- C - Yes to complete the registration number

- D - No to leave the registration number open for subsequent transactions

- Select Update .

- Go to step 11.

- Determine if an MA72 is imposed and if there is a registration number for the apprenticeship training issue:

- If an MA72 is imposed but there is no registration number, go to step 8.

- If an MA72 is imposed but there is a registration number, go to step 9.

- If an MA72 is not imposed but there is a revised registration number, go to step 10.

- If none of the above applies, go to step 11.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the applicable registration number.

- Manual action: Select 72 - Additional Training information required.

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 11.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4829.dita`

Note:

If the client requests exemption from completing claimant’s reports, complete the Claimant’s report: Declaration for exemption from completing claimant’s report ― Checklist form (INS5173). The form is copied into a separate SROC.
       [Claimant’s report: Declaration for exemption from completing claimant’s report ― Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Declaration_for_the_exemption_from_completing_claimant_reports-Checklist.doc)

     [Claimant’s report: Declaration for exemption from completing claimant’s report ― Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Declaration_for_the_exemption_from_completing_claimant_reports-Checklist.doc) 

## Policy reference

Source topic: `en_EN/task/training_rcc/policy_reference.dita`

- EIA 25
         [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- EIA 28
         [EIA 28](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-28.html)

- EIR 26
         [EIR 26](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-26.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
