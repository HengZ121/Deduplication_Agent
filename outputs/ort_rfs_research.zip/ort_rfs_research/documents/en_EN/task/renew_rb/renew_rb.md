# Renewing a claim for regular benefits

Source map: `en_EN/task/renew_rb/renew_rb.ditamap`

## Summary

Source topic: `en_EN/task/renew_rb/summary.dita`

Summary: When a client submits a claim for regular benefits and there is a benefit period (BP) with entitlement weeks remaining, the BP can be renewed. 

## What you need to know

Source topic: `en_EN/task/renew_rb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/renew_rb/untitled_section.dita`

If the benefit type (BT) before the renewal request is regular, the officer follows the steps in this task to renew a claim for regular benefits. If the previous BT is not regular, the officer refers to the appropriate conversion task.

When assessing a renewal, it might be to the client’s advantage to establish a new BP instead of renewing the existing BP. For more information, the officer refers to Cancelling, voiding, terminating or withdrawing a claim .
       [Cancelling, voiding, terminating or withdrawing a claim](/en/procedure/activity/cancel_term_void_withd_claim.shtml) 

### Duration of the benefit period (BP)

Source topic: `en_EN/task/renew_rb/duration_of_the_benefit_period_bp.dita`

The duration of the BP is the length of time in which clients can claim benefits to which they are entitled. The length of a BP is 52 weeks, including the week of the BPC and the waiting period (WP). A BP for regular benefits ends when one of the following occurs:

- All the weeks to which the client is entitled have been paid.

- The maximum regular benefits have been paid.
         [maximum regular benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml#regular)

- The maximum combined special and regular benefits have been paid.
         [maximum combined special and regular benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml#combine)

- The 52-week duration is reached.

- The client requests the termination of the BP.

Under certain circumstances, the BP can be extended to allow clients more time to receive the benefits to which they are entitled. For further information, the officer refers to Extension of the benefit period .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4443.dita) 

### Contentious issues

Source topic: `en_EN/task/renew_rb/contentious_issues.dita`

When renewing a claim, a client may report a new contentious issue that must be adjudicated, such as reason for separation (RFS), farming or availability. If the issue is reported on the application, the system creates an Adjudication Issue (ADJ) WI. If a contentious issue is detected while reviewing the claim, the Level 1 creates an ADJ WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision . If unable to create an ADJ WI, the officer creates a Claim Review (CR) WI. For more information on the required type of WI, the officer refers to Creation of a WI for a contentious issue .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
       [Creation of a WI for a contentious issue](/en/procedure/generic/additionalresources/creation_wi_ci.shtml)

For more information, the officer refers to Determining if a claim is ready to be renewed or converted .
       [Determining if a claim is ready to be renewed or converted](/en/procedure/task/determ_claim_demande_ren_conv.shtml) 

### Adjudication not previously required — Specialized ACP process

Source topic: `en_EN/task/renew_rb/adjudication_not_previously_required__s_a89cd8c4.dita`

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the qualifying period (QP). The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0126.dita) 

### Deferred reason for separation (RFS)

Source topic: `en_EN/task/renew_rb/deferred_reason_for_separation_rfs.dita`

Sometimes, when a client asks for a claim to be renewed, fact-finding and adjudication of the RFS can be deferred. For more information, the officer refers to Deferral of adjudication .
       [Deferral of adjudication](/en/procedure/activity/deferral_adj.shtml) 

### Effective date of a renewal

Source topic: `en_EN/task/renew_rb/effective_date_of_a_renewal.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer refers to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Claim in MPS

Source topic: `en_EN/task/renew_rb/claim_in_mps.dita`

When the claim is in MPS with claim status (CS) 8 - Converted to Manual Pay , the officer sends an Operational Centre Memo (MM06) transaction to IPOC to renew the claim. If the claim is in MPS, it stays in MPS for the remainder of the BP and the client must complete paper claimant’s reports.

When inputting the MM06, the officer ensures that all information required for the renewal is included. This includes the renewal week, the claim type (CT), claimant’s reports (if the information is available), any required allocations, BP extensions, disentitlements, etc. If there is any outstanding ADJ or AI WIs and a decision on a contentious issue is required, the Level 1 officer waits for their completion before sending the MM06 to IPOC.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Subsequent claim

Source topic: `en_EN/task/renew_rb/subsequent_claim.dita`

The renewal application can be used to establish a subsequent claim when the following conditions are met:

- The claim is renewed with 4 or fewer weeks of benefits remaining in the BP.

- The client has worked enough hours to establish a new claim.

If the Claim Assessment (CA) WI for a renewal or subsequent initial claim is finalized within 28 days of the renewal application, ACP can register the subsequent claim.

When ACP cannot register the subsequent claim because the renewal is not processed within 28 days of the renewal application (i.e. REN WK not found or no match and polling limit exceeded is displayed on the Processing Activities tab) or when the claim was converted to MPS, the officer processing the CA Renewal WI must create a Reminder (REM) WI for the subsequent claim to be registered. 

### Claim action status and processing of the claim

Source topic: `en_EN/task/renew_rb/claim_action_status_and_processing_of_the_claim.dita`

The Claim action status Renewal is created when a renewal decision is registered. There are 3 Claim action statuses that may be displayed:

- In Progress (Automation) is displayed on the Client information tree when there is one or more outstanding adjudication issues.

- In Progress (Manual) is displayed on the Client information tree when there is no outstanding adjudication issue and there is an outstanding CA or Specialized Application (SA) WI.

- Finalized is displayed on the Client information tree when all ADJ WIs are completed and the renewal week has been successfully input. 

### Completing the WI

Source topic: `en_EN/task/renew_rb/completing_the_wi.dita`

If the Level 1 officer cannot adjudicate the issue, the WI is referred to Level 2 for adjudication. When an ADJ WI is created on a renewal claim, either manually or by the system, the system automatically imposes a 2 - Contentious renewal in automation manual action (MA02) to prevent payment of benefits until the contentious issue is adjudicated and the renewal is complete. When the renewal inputs or a decision must be input manually, the inputs must be done before the ADJ WI is completed, as the system removes the MA02 when the WI is completed. An officer cannot rescind an MA02.

The Level 1 officer who is referring the file to Level 2 for adjudication must:

- initiate fact-finding;

- input the conversion;

- reassign the WI.

When opening an ADJ WI, the officer must always check to see if there is a Resolve Issue tab. If there is a Resolve Issue tab, the officer can document the decision directly in the ADJ WI by completing all mandatory screens. When the ADJ WI is completed, NWS creates a record of decision (ROD) based on the Resolve Issue screens.

When the renewal is finalized, the system also generates the required transactions (e.g. signature code, disentitlement) based on the Resolve Issue screens. If a disentitlement or indefinite disqualification is imposed, the system creates a Correspondence (COR) WI for the D-01-00-00 letter. This means that the officer with the CA or SA WI has no action to perform for these ADJ WIs.

When there is no Resolve Issue tab for the ADJ WI, the officer must create a ROD, generate the required transactions and send the appropriate letter. If there is an outstanding CA or SA WI when the officer completes the ADJ WI, a client Note is created and the officer with the CA or SA WI must follow the instructions to input the transactions or send the letter. 

### ACS letters

Source topic: `en_EN/task/renew_rb/acs_letters.dita`

Communication of the renewal decision is not necessary when the only transaction input is the renewal transaction. When another decision is input at the time of the renewal (disentitlement, disqualification or allocation of earnings), communication of the decision is necessary.

Written communication of the decision is usually done by officers who are responsible for sending the appropriate ACS letter. Officers must ensure that the letter was sent and, if the letter was not sent, they must create and send the letter of decision in ACS.

If a renewal and an allocation are input by the same officer and are processed on the same day, the R-01-00-00 letter is, in most cases, created automatically.

There are some exceptions. The letter does not automate if one of the following conditions is met:

- One of the transactions (M106 or M175) rejects.

- The allocation code on the M175 is A .

- An E or W allocation is input for more than one week.

- One of the following manual action (MA) to stop payments is imposed:

- 1 - General suspension of benefits (stop payment) (MA01)

- 2 - Contentious Renewal in Automation (MA02)

- 48 - Stop payment due to undeliverable mail (MA48)

- 71 - Integrity Services case (MA71)

- 72 - Additional training information required (MA72)

- 73 - Canada Revenue Agency case (MA73)

- 74 - Labour Dispute (MA74)

- 75 - Verification of reason for termination of Employment (MA75)

- A disqualification or disentitlement is being input.

- A disqualification or disentitlement is already on file and is not being rescinded or terminated.

In some cases, the letter may automate but additional decisions must be communicated. To prevent duplication of letters, the officer must prevent the automated letter from being sent by using the Automated Letter Bypass function in FTS. 

### Fraud indicators

Source topic: `en_EN/task/renew_rb/fraud_indicators.dita`

When the officer suspects that the application is fraudulent, the officer refers to Creating or reassigning a WI — Integrity before proceeding in this procedure.
       [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

For more information, the officer refers to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Suspicious ROEs

Source topic: `en_EN/task/renew_rb/suspicious_roes.dita`

Many fraudulent applications have been submitted with suspicious ROEs and could have been used to calculate a client’s claim. The following are some indicators that an ROE may be suspicious:

- The employer name or occupation on the ROE does not match other ROEs in RCM (e.g. the client’s employment history is with the School District 123, but an ROE is received from a plumbing company).

- The employer name on the ROE does not match the employment information provided by the client on previous applications.

- The employer name on the ROE does not match the last employer on the initial application.

- The employer name indicated as the last employer on the initial application is a large well-known corporation, but the name indicated on the ROE (block 4 - Employer’s name ) is a person’s name (e.g. the last employer on the application is Wal-Mart, but the employer on the ROE is John Doe).

- The ROE is a paper ROE issued by a large company that normally issues electronic ROEs (or vice versa). 

### No fraud indicators present on renewal application — 71 - Integrity Services case manual action (MA71) imposed

Source topic: `en_EN/task/renew_rb/no_fraud_indicators_present_on_renewal__82acd80b.dita`

When a previous initial application is potentially fraudulent, an MA71 was imposed, no benefits were paid, and a renewal application with no fraud indicators is received, the officer:

- creates an IPOC Review (IPOC REV) Claim removal WI for the IPOC officer to remove the claim from the client’s file;

- creates an SROC to document the action taken;

- refers to the calculation procedures to process the client’s application as a new initial claim.

When a previous renewal application is potentially fraudulent, an MA71 was imposed, no benefits were paid, and a subsequent renewal application with no fraud indicators is received, the officer:

- inputs the return to work (RTW) date equal to the first day of the appropriate week;

- rescinds the MA71;

- creates an SROC to document the action taken;

- processes the renewal for the client.

The officer verifies whether any suspicious ROEs are under investigation by entering the business number (BN) in RMDS. If a BN is under investigation and the ROE is still on file, the officer deletes the ROE.

If benefits were paid on the potentially fraudulent application, the officer notifies Integrity that the client’s claim is blocked due to an MA71 and moves the CA WI to Pending until the investigation is complete.

If a suspicious ROE was used to calculate the client’s claim, the officer notifies Integrity about this and indicates that the client has submitted a renewal application. The officer then moves the CA WI to Pending until the investigation is complete.

To notify Integrity that a client’s claim is blocked due to an MA71, or that a suspicious ROE was used in the initial calculation, the officer creates an urgent AI WI so that the investigation can be prioritized. 

### Note

Source topic: `en_EN/common_notes/note_c_4443.dita`

Note:

A temporary measure is introduced under Pilot Project No. 24 to increase the number of weeks of entitlement to regular benefits by 20 weeks, up to a maximum of 65 weeks, for long-tenured workers who meet the established criteria. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The BP will be extended by 20 weeks when one week of regular benefits has been paid.

The maximum combination of regular and special benefits also increases to 70 weeks for long-tenured workers. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0126.dita`

Note:

Any contentious RFS issues in the BP must be adjudicated. 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

## Regional considerations

Source topic: `en_EN/task/renew_rb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/renew_rb/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/renew_rb/in_nws.dita`

- When was the application for renewal filed?

- Has the client worked since the last week paid?

- Are there earnings, monies on separation, motor vehicle accident compensation, workers’ compensation benefits or wage loss insurance payments to consider or allocate?

- Is there an ADJ WI?

- If yes, for what issues? 

### In FTS:

Source topic: `en_EN/task/renew_rb/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- Has the last renewable week (LRW) been reached?

- Has the WP been served, half served, waived or deferred?

- Is there a registration number?

- Is there an MA71? 

### In RCM:

Source topic: `en_EN/task/renew_rb/in_rcm.dita`

- Has an ROE been submitted for the renewal?

- Are there earnings, monies on separation, motor vehicle accident compensation, wage loss insurance workers’ compensation benefits or wage loss insurance payments to consider or allocate?

- Are there any suspicious ROEs? 

### In Imaging:

Source topic: `en_EN/task/renew_rb/in_imaging.dita`

- Is there any other documentation which may impact the renewal claim? 

## Step by step

Source topic: `en_EN/task/renew_rb/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/renew_rb/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/renew_rb/reviewing_the_file_level_1.dita`

- In FTS, determine if there is a registration number:

- If yes, go to step 2.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 2 - Renewal .

- Select Update .

- Determine if there are weeks of regular benefits remaining to be paid:

- If yes, go to step 3.

- If no and special benefits have not been paid, go to Maximum regular benefits already paid .
               [Maximum regular benefits already paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#max_reg_benefits_already_paid)

- If no and special benefits have been paid, go to Maximum combination of regular and special benefits already paid .
               [Maximum combination of regular and special benefits already paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#max_comb_of_reg_and_spacial_ben_already_paid)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4444.dita)

- Determine if the WP must be served:

- If no, go to step 4.

- If yes and the client has not worked since the beginning of the BP, go to step 4.

- If yes and the client has worked since the beginning of the BP, the existing claim can be cancelled in favour of a new BP. Refer to Cancelling a benefit period . Go to step 4.
               [Cancelling a benefit period](/en/procedure/task/benefit_period_cancel.shtml)

- In NWS and in FTS, determine if one of the following conditions exists to extend the BP:

- The client was incarcerated and has since been tried and not found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If one of the conditions exists, refer to Extension of the benefit period and then go to step 5.
               [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions exist, go to step 5.

- Determine if the LRW has been reached:

- If no, go to step 6.

- If yes, go to Last renewable week (LRW) is reached .
               [Last renewable week (LRW) is reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#LRW_is_reached)

- Determine the renewal week. Refer to Determining the effective date of a renewal or a conversion .

- Determine if there are any outstanding issues that require adjudication:

- If no, go to step 8.

- If yes or uncertain, refer to Determining if a claim is ready to be renewed or converted . Go to step 8.
               [Determining if a claim is ready to be renewed or converted](/en/procedure/task/determ_claim_demande_ren_conv.shtml) 

#### Inputs

Source topic: `en_EN/task/renew_rb/inputs_level_1.dita`

- In RCM, determine if there are any suspicious ROEs that have not already been deleted:

- If yes, note the BNs and go to step 9.

- If no, go to step 11.

- In RMDS, determine if the BN is under investigation as follows:

- Select Paper and then select Employer .

- Business No.: Enter the BN.

- Select Search .

- Select the BN and select Open .

- When the Employer profile screen opens, determine if the Under investigation box in the lower left-hand corner is checked:

- If yes, go to step 10.

- If no, go to step 11.

- In RCM, delete the ROE with the BN that is under investigation as follows:

- Delete: Check the box.

- Additional information: Select the appropriate option:

- If the ROE was not used to calculate the client’s established claim or the fraudulent established claim, type “Suspicious ROE has been deleted to prevent it from being used in benefits calculation. If its legitimacy is confirmed, it can be restored.”

- Select Validate .

- Select Submit .

- Go to step 11.

- If the ROE was used to calculate the client’s established claim or the fraudulent established claim, type “Suspicious ROE has been deleted. If its legitimacy is confirmed, it can be restored.”

- Select Validate .

- Select Submit .

- Go to step 11.

- Determine which of the following situations applies, then go to the appropriate step:

- If there are no fraudulent ROEs on file, go to step 12.

- If fraudulent ROEs were not used to calculate the client’s initial claim, go to step 12.

- If fraudulent ROEs were used to calculate the client’s initial claim, go to step 21.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If yes, go to step 13.

- If no, go to step 15.

- Determine if benefits were paid after the potentially fraudulent application was submitted:

- If yes, go to step 14.

- If no, go to step 15.

- Determine if there is an outstanding CR Integrity ERB-EI Transition WI:

- If no, go to step 15.

- If yes, check the Urgent box in the CR Integrity ERB-EI Transition WI and go to step 22.

- In FTS, determine if an MA71 was imposed: Note: Review Action Item (AI) WIs and SROCs on file to determine why the MA71 was imposed.

- If yes and it was imposed due to the fraudulent initial application and no benefits were paid, go to step 16.

- If yes and it was imposed due to the fraudulent initial application and benefits were paid, go to step 21.

- If yes and it was imposed due to a previous fraudulent renewal application and benefits were paid, go to step 21.

- If yes and it was imposed due to a previous fraudulent renewal application and no benefits were paid, go to step 24.

- If yes and it was imposed for any other reason, go to step 32.

- If no, go to step 32.

- In NWS, create an IPOC REV Claim removal WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the appropriate IPOC based on the region of the claim in FTS:

- Atlantic: 1826

- Quebec: 2642

- Ontario: 3056

- Western and Territories: 5903

- End User: Select Next available user .

- Issue(s): Select Claim Removal .

- BPC: Enter the claim’s BPC.

- Comments: Type “Claim removal.”

- Details: Type “Void the BPC in w/c [XXXX]. Fraudulent application. No payments issued on the BPC.” If there is a violation on the Violation History (ML02) screen, type “Update the ML02 screen for the BPC in w/c [BPC with the violation that affects the voided BPC] and remove the BPC in w/c [voided BPC] from the affected BPCs. Type “Advise Level 1 officer to establish the new BPC with a REM WI.”

- Obtained by: Select the appropriate option.

- Obtained from: Select the appropriate option.

- Source details: Enter the source details.

- Select Save .

- Move the CA WI to Pending as follows:

- Pending reason: Select the appropriate option.

- Comments: Type “The IPOC officer has to void the claim and create a REM WI so a new claim can be established”

- Bring forward date: Enter today’s date + 2 business days.

- When the CA WI moves to the current workload, determine if the IPOC officer has sent the REM WI to establish the claim:

- If no, repeat step 17.

- If yes, go to step 19.

- Create an SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Potentially fraudulent initial claim — claim voided.”

- Details: Type “Initial claim is potentially fraudulent. The claim has been voided and is pending an investigation.”

- In SSO, verify that the correct mainframe is selected and register the claim as follows:

- On the Claim Selection screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Registration type: Select Initial .

- Select Search .

- Review the Name and Address screen:
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2168.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4445.dita) 

- For a commuter claim, complete the following fields as follows:

- Ordinary place of residence different: Select Yes .

- Residence postal code: Enter the workplace postal code.

- Mailing address: Do the following:

- First line of address: Enter the delivery address. If necessary, enter the apartment number on the first line after the delivery address.

- Second line of address: Enter the city name, 2-letter state abbreviation and ZIP code. Separate the state abbreviation from the ZIP code with 2 spaces. The ZIP code may be either 5 or 9 digits. If the 9-digit format is used, use a hyphen to separate the fifth and sixth digits.

- Last line of address: Type “United States.”

- Postal code: Type “XXXXXX.”

- Economic region - new and Economic region - old: Both fields are prefilled based on the client’s mailing address information. For a commuter claim, enter the economic region associated with the workplace postal code (if not prefilled when the residence postal code was entered).

- Tax province: This field is prefilled based on the client’s mailing address information. For a commuter claim, select Commuters .

- Responsible SCC: Do the following:

- If the field is blank, enter the SCC shown on the WI History tab of the CS WI.

- For a commuter claim, enter the SCC associated with the workplace postal code.

- Tax credit: This field is prefilled based on the client’s information.

- Select Next .

- On the Application Form screen, select Next .

- On the Registration screen, do the following:

- Pay SCC: If the field is blank, enter the SCC shown on the WI History tab of the CS WI (the same one input in the Responsible SCC field).

- Service unit: Type “01.”

- Tentative BPC: If the field is blank, determine the BPC based on the client’s LDW and application date. If the registration being obtained is for a subsequent claim, select the week after the previous claim’s LRW.

- Claim source: Select Appli-web (virtual) .

- Initial intake transaction (M149) required: Select Yes to generate the Initial Intake (M149) transaction.

- Select Generate registration .
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2648.dita)

- Select Next .

- On the M149 - Initial Intake Data screen, select Update .

- Go to Determining if a claim is ready to be calculated — Regular benefits to process the client’s EI application as a new initial claim.
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- Create an AI WI for Integrity as follows:

- Urgent: Check the box.

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue(s): Select Other .

- Comments: Type the appropriate option:

- “Client blocked.”

- “Suspicious ROE used in calculation.”

- Details: Type the appropriate option:

- “The application dated [DD-MM-YYYY] was submitted by the client and is blocked by an MA71.”

- “A suspicious ROE was used in the calculation of the claim and a new application was submitted by the client.”

- Select Save .

- Move the CA WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for investigation to end.”

- Bring forward date: Enter today’s date + 10 business days.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4446.dita)

- Once the CR Integrity ERB-EI Transition WI is complete, do the following:

- If a fraudulent initial claim has been voided and an initial claim must be established, refer to Determining if a claim is ready to be calculated — Regular benefits to process the client’s EI application as a new initial claim.
               [Determining if a claim is ready to be calculated — Regular benefits](/en/procedure/subactivity/determining_reg_claim_ready.shtml)

- If processing a renewal claim is required and the CS is 0 - Active , go to step 24.

- If processing a renewal claim is required and the CS is 8, go to step 42.

- In FTS, determine if the client’s address is correct:

- If yes, go to step 25.

- If no, update the address and go to step 25.
               [update the address](/en/procedure/activity/change_address.shtml)

- Determine if the client’s banking information is correct:

- If yes, go to step 26.

- If no, update the banking information and go to step 26.
               [update the banking information](/en/procedure/activity/direct_deposit.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4447.dita)

- To determine the RTW date, choose the appropriate option:

- If cycling claimant’s reports are on file, the RTW date is the first day of the first week of the cycling claimant’s reports.

- If there are no cycling claimant’s reports the RTW date is the first day of the next week to be processed.

- Select the Additional Data (M107) transaction and input the RTW date as follows:

- Registration number: Leave this field blank.

- Return to work: Input the RTW date as determined in step 26.

- Select Update .

- In NWS, create an SROC as follows:

- Main Issue: Select Integrity .

- Comments: Type “Potentially fraudulent renewal — return to work input.”

- Details: Type “The renewal is potentially fraudulent. A return to work date has been input and the stop payment was rescinded pending an investigation.”

- In FTS, select the Renewal/Revised (M106) transaction to rescind the MA71 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 71 - Integrity Services case .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- Determine if there are cycling claimant’s reports:

- If yes, go to step 31.

- If no, go to step 32.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Renewal to be input.”

- Bring forward date: Enter the next business day.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4448.dita)

- In FTS, determine if the CS is 8:

- If no, go to step 33.

- If yes, go to step 42.

- Select the Renewal / Revised (M106) transaction and input the renewal as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the effective renewal week.

- Earnings week 1: Enter the amount (if necessary).

- Contentious: Select the appropriate option:

- If the renewal did not require Level 2 adjudication, select 1 - No .

- If the renewal required Level 2 adjudication, select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, or if there is an MA02 on file, select D - No .

- Select Update . 

#### Communication on an active claim

Source topic: `en_EN/task/renew_rb/communication_on_an_active_claim_level_1.dita`

- Determine if there is an allocation of earnings that must be communicated to the client:

- If yes, go to step 35.

- If no, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#level1_item_6)

- In NWS, determine if there is an outstanding ADJ WI:

- If no, go to step 36.

- If yes, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#level1_item_6)

- Determine if one of the following situations applies:

- A denied antedate is on file.

- A disentitlement or a definite disqualification is being input manually.

- An indefinite disqualification is preventing payment on the renewal claim.

- If no, go to step 37.

- If yes, go to step 38.

- Determine if a MA02 is imposed on the claim:

- If yes, go to step 38.

- If no, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#level1_item_6)

- In FTS, select the File Control Data (M101) transaction as follows:

- Select Claim Action .

- Select Automated Letter Bypass .

- In ACS, add details to the draft D-01-00-00 letter and send it. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246) .

- Allocation of Earnings (2516) .

- Waiting Period Message (2444): If the client has not served the WP, select the appropriate option.

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In ACS, determine if there is a draft N-02-00-01 or D-20-16-03 letter:

- If yes, go to step 41.

- If no, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#level1_item_6)

- Determine if all decisions which must be communicated to the client are included in the D-01-00-00 letter:

- If yes, delete the other draft letters. Go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#level1_item_6)

- If no, send the letters with only the decisions that are left to be communicated. Go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#level1_item_6) 

#### Claim in MPS

Source topic: `en_EN/task/renew_rb/claim_in_mps_level_1.dita`

- Before sending the Operational Centre Memo (MM06) transaction to IPOC, determine if a Level 2 officer must adjudicate any outstanding issues:

- If yes, go to step 43.

- If no, go to step 45.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting Level 2 decision.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if a decision has been rendered:

- If no, repeat step 43.

- If yes, go to step 45.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 30 - New information on a manual pay claim .

- Remarks line 1: Type “Input renewal w/c [XXXX], CT [XX].”

- Remarks lines 2–4: Enter the appropriate information:

- If the claimant’s reports’ information is available and coding is not required, type “M151 CR from w/c [XXXX] to [XXXX].”

- If the claimant’s reports’ information is available and coding is required, type “M152 CR from w/c [XXXX] to [XXXX], earnings $[XXXX], NA [not available days], sickness [sick days], FWW [XX]” and other relevant information regarding the claimant’s reports input for each period (e.g. M152 CR from w/c 2000 to 2010, earnings $400, 2011, sickness 3).

- If there is an allocation, type “M175 [type] [amount] from w/c [XXXX] to [XXXX], [amount, if different from last week].”

- If an extension of the BP is required, type “Extend BP Type [X], Start week [XXXX], Number of weeks [X].”

- If a disentitlement must be imposed, type “D[XX] from w/c [XXXX-X] to [XXXX-X].”

- If a disqualification must be imposed, type “D[XX] from w/c [XXXX].”

- Remarks line 5: Enter your first name and last name .

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No or 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 04 - Insurance Payment Operational Centre .

- Select Update . 

#### Communication on an MPS claim

Source topic: `en_EN/task/renew_rb/communication_on_an_mps_claim_level_1.dita`

- Determine if one of the following situations applies:

- A denied antedate is on file.

- A disentitlement or a disqualification must be imposed.

- An indefinite disqualification is preventing benefits payment on the renewal claim.

- If yes, go to step 49.

- If no, go to step 52.

- In ACS, add details to the draft D-01-00-00 letter and send it. Based on the claim information, select all of the required attributes, including the following:

- Renewal week - Sunday’s date (1246) .

- Allocation of Earnings (2516) .

- Waiting Period Message (2444): If the client has not served the WP, select the appropriate option.

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In ACS, determine if there is a draft N-02-00-01 or D-20-16-03 letter:

- If yes, go to step 51.

- If no, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#level1_item_6)

- Determine if all decisions which must be communicated to the client are included in the D-01-00-00 letter:

- If yes, delete the other draft letters. Go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#level1_item_6)

- If no, send the letters with only the decisions that are left to be communicated. Go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#level1_item_6)

- Determine if there is an allocation of earnings that must be communicated to the client:

- If yes, go to step 53.

- If no, go to Subsequent claims .
               [Subsequent claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/renew_rb#level1_item_6)

- In ACS, create and send the D-20-16-03 letter. 

#### Subsequent claims

Source topic: `en_EN/task/renew_rb/subsequent_claims_level_1.dita`

- Determine if there are 4 or fewer weeks remaining to be paid in the BP:

- If yes and the CS is 0, go to step 55.

- If yes and the CS is 8, go to step 56.

- If no, go to step 57.

- Determine if the renewal was finalized within 28 days of the renewal application being filed (i.e. filing date + 27 days):

- If no, go to step 56.

- If yes, go to step 57.

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “Subsequent claim not automated.”

- Due date: Select the LRW + 3 weeks.

- Details: Type “Subsequent claim to be established.”

- Destination: Select the SCC shown in FTS.

- End User: Select Next available user .

- Complete the CA WI. 

#### Maximum combination of regular and special benefits already paid

Source topic: `en_EN/task/renew_rb/maximum_combination_of_regular_and_spec_5cf2309f_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for regular benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “No renewal — maximum combination of benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No renewal is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC. No conversion.”

- If the client has worked since the BPC , type “No renewal is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. No conversion.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type: “We cannot reactivate your claim for Employment Insurance benefits starting [renewal week - Sunday’s date] as you have received the maximum number of benefit weeks payable to you during this benefit period(BP). The maximum number of benefit weeks paid on this claim cannot exceed a total of [maximum number of regular and special benefit weeks that can be paid] weeks. To receive regular benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you will have to file a new claim.”

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction to complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the CA WI. 

#### Maximum regular benefits already paid

Source topic: `en_EN/task/renew_rb/maximum_regular_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for regular benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “No renewal, maximum regular benefits paid.”

- Details: Enter the appropriate details based on whether the client has worked since the BPC:

- If the client has not worked since the BPC, type “No renewal is possible as the client has received the maximum entitlement to regular benefits. The client does not qualify for a new claim as no hours were accumulated after BPC.”

- If the client has worked since the BPC, type “No renewal is possible as the client has received the maximum entitlement to regular benefits. The client does not qualify for a new claim as [number of hours] were accumulated after BPC. The client needed [number of hours] to qualify.”

- In ACS, send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type the following: “We cannot reactivate your claim for Employment Insurance benefits starting [Renewal week - Sunday’s date] . Please note that we are required to advise you of all decisions made on your claim. No regular benefits are payable to you on this claim because you have been paid all of the regular benefits to which you are entitled. To receive regular benefits, you must work the required minimum number of insurable employment hours. If you want to receive regular benefits in the future, you will have to file a new claim. You may be able to receive special benefits such as compassionate care, sickness, maternity, parental and family caregiver benefits. If any of these benefit types apply to your situation, please contact us to find out whether you are entitled.”

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the CA WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/renew_rb/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for regular benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “LRW reached — regular benefits requested.”

- Details: Enter the appropriate details based on whether the client has worked since the BPC:

- If the client has not worked since the BPC, type “No renewal is possible as LRW has been reached and no BP extension possible. Client does not qualify for a new claim as no hours were accumulated after BPC.”

- If the client has worked since the BPC, type “No renewal is possible as LRW has been reached and no BP extension possible. Client does not qualify for a new claim as [number of hours] were accumulated after BPC and the client needed [number of hours] to qualify.”

- In ACS, send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type the following: “We cannot reactivate your claim for Employment Insurance benefits starting [Renewal week - Sunday’s date] . Please note that we are required to advise you of all decisions made on your claim. No regular benefits are payable to you on this claim because the last renewable week has been reached on this benefit period. To receive regular benefits, you must work the required minimum number of insurable employment hours. If you want to receive regular benefits in the future, you will have to file a new claim.”

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the CA WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4444.dita`

Note:

A temporary measure is introduced under Pilot Project No. 24 to increase the number of weeks of entitlement to regular benefits by 20 weeks, up to a maximum of 65 weeks, for long-tenured workers who meet the established criteria. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The maximum combination of regular and special benefits also increases to 70 weeks for long-tenured workers. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Note

Source topic: `en_EN/common_notes/note_c_2168.dita`

Note:

The information from the application in NWS is automatically downloaded in SSO. In rare cases, the information is not downloaded and must be manually input. Verify (and correct, if necessary) any prefilled fields with the information provided on the application. 

#### Note

Source topic: `en_EN/common_notes/note_c_4445.dita`

Note:

When the client has only one name, one of the name fields on the Name and Address screen may be empty or contain a non-alphabetical character. However, SSO does not allow the field to be completed in this way.

When a name field is empty or contains a non-alphabetical character, do the following:

- First Name: Enter the appropriate option:

- For a client who selects the Male gender marker, type “Mr.”

- For a client who selects the Female gender marker, type “Ms.”

- For a client who selects X as the gender marker, type “N.A.”

- Last Name: Enter the client’s name.

When the First Name field on the Name and Address screen is modified to “N.A.,” modify the Initial Intake (M149) or Name and Address Change / Transfer (M159) transaction generated by the calculation and type “.” in the First Name field before transmitting it. 

#### Note

Source topic: `en_EN/common_notes/note_c_2648.dita`

Note:

At this step, a registration number is assigned to the claim. If Yes is selected, the Initial Intake (M149) transaction is automatically generated.

If No is selected, the Initial Intake (M149) transaction is not generated. 

#### Note

Source topic: `en_EN/common_notes/note_c_4446.dita`

Note:

When the investigation is complete, a CR Integrity ERB-EI Transition WI is created. In the CR Integrity ERB-EI Transition WI, ensure that the Urgent box is checked. Do not process the CA WI until the CR Integrity ERB-EI Transition WI related to the potentially fraudulent application has been completed . If the following WIs are outstanding, do not process the CA WI until they are completed:

- IPOC Manual Pay (IPOC MPS) Third party fraud WI.

- IPOC Overpayment (IPOC O/P) Third party fraud. 

#### Note

Source topic: `en_EN/common_notes/note_c_4447.dita`

Note:

In FTS, ensure that the correct address and banking information are on file (update the information, if necessary). Ensure also that the client’s name, language and gender are correct. If there is a fraudulent claim in another ITC, update the information in both ITCs. 

#### Note

Source topic: `en_EN/common_notes/note_c_4448.dita`

Note:

The next day, the cycling claimant’s reports will show error code C420: WARNING - Claim status changed to 02 (found work) on the Pending/reject tab. Delete the rejected transactions on the Rejected Transactions Retrieval (MR05) screen. 

## Policy reference

Source topic: `en_EN/task/renew_rb/policy_reference.dita`

- EIA 12(6)
         [EIA 12(6)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
