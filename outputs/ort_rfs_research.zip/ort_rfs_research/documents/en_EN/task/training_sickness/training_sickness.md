# Adjudicating non-referred training: Sickness benefits — Continuing claim

Source map: `en_EN/task/training_sickness/training_sickness.ditamap`

## Summary

Source topic: `en_EN/task/training_sickness/summary.dita`

Summary: When clients receiving sickness benefits report that they are taking non-referred training, adjudication is required to determine if they are entitled to benefits during the training period. 

## What you need to know

Source topic: `en_EN/task/training_sickness/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/task/training_sickness/training_reported_between_september_27__5ecd71c7.dita`

A transitional measure under which ACP automatically adjudicated and allowed all training effective September 27, 2020 has ended on September 11, 2021. The intent of this measure was to prevent any delay in payment to clients who reported training.

The client must still meet the entitlement conditions for sickness benefits while attending non-referred training. A client attending non-referred training may provide information on a claimant’s report or during a conversation with an agent that brings into question the entitlement to sickness benefits. In this case, the agent creates a WI for the contentious training issue and follows normal adjudication procedures, even if ACP initially allowed the training. 

### Impact of training on sickness benefits

Source topic: `en_EN/task/training_sickness/impact_of_training_on_sickness_benefits.dita`

Clients who apply for sickness benefits and prove their incapacity must also prove that they are otherwise available for work. This means that if not for the illness or injury, the client would be available for work. To help determine availability and entitlement during the training period, complete the Non-referred training checklist for sickness benefits . No distinction is made between part-time and full-time training .
       [Non-referred training checklist for sickness benefits](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Training-Non-referred_training_for_sickness_benefits-Checklist.doc)

This includes clients who are attending short-term training courses and targeted initiatives. Refer to the job aid for a complete list of non-referred short-term courses and targeted initiatives.
       [job aid](/en/procedure/generic/additionalresources/shortterm_courses_ti.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4814.dita) 

### Otherwise available during non-referred training

Source topic: `en_EN/task/training_sickness/otherwise_available_during_non-referred_training.dita`

Additional fact-finding or follow-up is not required when a client reports training of up to 9 hours per week.

When training is equal to or greater than 10 hours, but less than 15 hours per week, it must be determined that if not for the medical situation, the client would be available and capable of working, and that upon recovery, the intention is to look for full-time work. The client must also be willing to quit the course to accept full-time employment once recovered from the illness or injury.

When clients report that they are attending full-time training on their own initiative, the officer refers to BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training and the Digest of Benefit Entitlement Principles 10.12.2.8 — Hours of work . Both the BE Memo and the Digest explain that, under FCA A-29-22 , when adjudicating availability, the officer must consider the clients’ work history while attending training, in addition to other factors (i.e. the number of hours clients are attending training). Clients can rebut the presumption of non-availability if they can demonstrate having a regular work history outside of the training hours while taking full-time training. Using any previous ROEs, the officer reviews the number of hours the client worked while attending training to determine if the client can rebut the presumption of non-availability. Clients must also demonstrate a willingness and ability to remain available for a similar work schedule. Clients must not reduce or restrict their available hours of work beyond what is reasonable, given their work history, while attending training.
       [BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training](/en/policy/bememo/be2023-05.shtml) 
       [Digest of Benefit Entitlement Principles 10.12.2.8 — Hours of work](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2_8) 
       [FCA A-29-22](https://www.canlii.org/en/ca/fca/doc/2023/2023fca169/2023fca169.html)

When a client is devoting 15 or more hours per week to training, the agent must determine the total number of hours per week that is being spent on the training, including :

- class time

- study time

- time spent working on assignments

- time spent doing research

Correspondence courses are treated the same as any other training, with the following conditions applied:

- the course obligations must be outside the client’s normal working hours;

- upon recovery, the client must be willing to quit the course to accept full-time employment;

- upon recovery, the client must not limit the acceptance of full-time employment in favour of the training. 

### Targeted initiatives and short-term courses

Source topic: `en_EN/task/training_sickness/targeted_initiatives_and_short-term_courses.dita`

When clients receiving sickness benefits report that they are attending a targeted initiative or short-term course, the total daily or weekly attendance hours is not considered.

If the client is attending a short-term course referred under EIA 25, refer to Confirming referred training: Special benefits — Continuing claim .
       [Confirming referred training: Special benefits — Continuing claim](/en/procedure/task/training_cc.shtml) 

### Automated decisions

Source topic: `en_EN/task/training_sickness/automated_decisions.dita`

When a client reports non-referred training in a claimant’s report or on MSCA, an electronic questionnaire is created and can be viewed in NWS. If the electronic questionnaire meets the Levels of Decision criteria for Level 1 adjudication, ACP can automatically adjudicate the non-referred training. In this case, ACP creates a record of decision (ROD) and inputs the training Project data in FTS.

When ACP cannot adjudicate the non-referred training issue, a Level 2 agent must adjudicate the decision. When the claim is established, ACP creates a Claim Review (CR) WI, obtains a revised registration number and imposes a manual action 72 - Additional Training information required (MA72) to stop payment. 

### Information reported after claimant’s reports have been processed

Source topic: `en_EN/task/training_sickness/information_reported_after_claimants_re_82afb561.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the agent determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the agent refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4814.dita`

Note:

If a client quits employment or refuses an offer of employment to attend a non-referred training course, a non-referred short-term training course or a targeted initiative, agents must adjudicate the reason for separation on a separate WI. 

## Regional considerations

Source topic: `en_EN/task/training_sickness/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/training_sickness/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/training_sickness/in_fts.dita`

- Is there a registration number for the non-referred training issue?

- Is there a MA72 for the non-referred training issue?

- Have claimant’s reports been processed for the period in question?

- If yes, when was the original statement made?

- Is there a pending claimant’s report?

- Is there training information in the Project tab? 

### In NWS:

Source topic: `en_EN/task/training_sickness/in_nws.dita`

- Was the training questionnaire completed?

- Is there a ROD for the non-referred training issue?

- Is there an SROC or an Action Item (AI) WI with the training information, from either the Part-time Training checklist or the INS3141? 

### In Imaging:

Source topic: `en_EN/task/training_sickness/in_imaging.dita`

- Is there non-referred training information or the Training Questionnaire (INS3141)? 

## Step by step

Source topic: `en_EN/task/training_sickness/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/training_sickness/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_sickness/reviewing_the_file_level_1.dita`

- In NWS, determine if there is a ROD for the non-referred training issue:

- If no , go to step 2.

- If yes and ACP allowed training reported between September 27, 2020 and September 11, 2021, but new information indicates that the client is not otherwise available, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_sickness#reassign)

- If yes, and it is any other situation go to Automated decision .
               [Automated decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_sickness#auto_decision)

- If the client is correcting previously provided information or providing previously omitted information, determine if the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue should be referred to Integrity by consulting Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if there is enough information to adjudicate the non-referred training:

- If additional details are needed, go to step 4.

- If additional details are not needed, go to step 7. 

#### Fact-finding

Source topic: `en_EN/task/training_sickness/fact-finding_level_1.dita`

- Fact-find with the client. For help determining the questions to ask the client, refer to the Fact-Finding Guide .

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 6.

- If the client was not contacted or did not reply to the N-10-00-00 letter and the claim is an initial or continuing, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_sickness#reassign)

- If the client was not contacted or did not reply to the N-10-00-00 letter and the claim is a renewal, return to Conversion and renewal .
               [Conversion and renewal](/en/procedure/activity/conversions.shtml)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — sickness benefits.”

- Details: If completed during fact-finding, copy and paste the Non-referred training checklist for sickness benefits . Document any additional fact-finding details according to the Fact-Finding and Documentation Policy .
               [Non-referred training checklist for sickness benefits](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Training-Non-referred_training_for_sickness_benefits-Checklist.doc) 
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/training_sickness/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine the type of training the client is attending:

- If the client is attending regular non-referred training for 10 to 14 hours per week, go to step 8.

- If the client is attending a short-term training course or a targeted initiative, go to step 8.

- If the client is attending regular non-referred training for 15 hours or more per week, go to step 9.

- If the client is attending a regular non-referred training course for 9 hours or less per week, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_sickness#entitlement_conditions_met)

- Determine if the following conditions are met for the non-referred training:

- The client declares that if not for the medical situation, he would be available and capable of working.

- The client's intention upon recovery is one of the following:

- to return to employment, as the course or program will be completed prior to recovery.

- to leave the course or program and resume employment activities.

- to continue the course or program and resume employment activities to the same extent as prior to the illness or injury.

- If all of the conditions are met, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_sickness#entitlement_conditions_met)

- If any of the conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_sickness#reassign)

- Determine if the following conditions are met for the non-referred training:

- All of the course obligations occur outside the normal work hours of the client’s usual occupation.

- The client declares that if not for the medical situation, he would be available and capable of working.

- The client's intention upon recovery is one of the following:

- to return to employment, as the course or program will be completed prior to recovery

- to leave the course or program and resume employment activities

- to continue the course/ program and resume employment activities to the same extent as prior to the illness or injury

- If all of the conditions are met, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_sickness#entitlement_conditions_met)

- If any of the conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_sickness#reassign) 

#### Automated decision

Source topic: `en_EN/task/training_sickness/automated_decision_level_1.dita`

- Determine if there is a pending claimant’s report.

- If there is no pending claimant’s report, go to step 2.

- If there is a pending claimant’s report, clear the outstanding claimant’s report .
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- Determine if there is an MA72 imposed and an outstanding registration number for the non-referred training:

- If an MA72 is imposed but there is no registration number, go to step 3.

- If an MA72 is imposed and there is a registration number, go to step 4.

- If no MA72 is imposed, and there is a revised registration number, go to step 5.

- If none of the above applies, go to step 6.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: C - Yes .

- Select Update .

- Go to step 6.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Entitlement conditions met

Source topic: `en_EN/task/training_sickness/entitlement_conditions_met_level_1.dita`

- In NWS, create a ROD with the following information:

- Comments: Type “Non-referred training — entitlement in order.”

- Details: Type “meets Levels of Decision criteria to allow non-referred training at Level 1.” To document additional details, refer to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the non-referred training information has been input in the Project tab:

- If the non-referred training information has been input, go to step 3.

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Determine if there is a pending claimant’s report.

- If there is no pending claimant’s report, go to step 4.

- If there is a pending claimant’s report, clear the outstanding claimant’s report .
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- Determine if there is an MA72 imposed and an outstanding registration number for the non-referred training:

- If an MA72 is imposed but there is no registration number, go to step 5.

- If an MA72 is imposed and there is a registration number, go to step 6.

- If no MA72 is imposed, and there is a revised registration number, go to step 7.

- If none of the above applies, go to step 8.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: C - Yes .

- Select Update .

- Go to step 8.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/training_sickness/reassigning_the_issue_to_level_2_level_1.dita`

- In FTS, determine if the non-referred training information has been input on the Project tab:

- If the non-referred training information has been input, go to step 2.

- If the non-referred training has not been input, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Determine if there are full weeks of benefits payable before the non-referred training start date:

- If there are full weeks of benefits payable, go to step 3.

- If there are no full weeks of benefits, go to step 4.

- Determine if there is a pending claimant’s report:

- If there is a pending claimant’s report, clear the outstanding claimant’s report and go to step 4.
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 4.

- In FTS, select the Renewal/Revised (M106) transaction and input an MA72 as follows:

- Manual action: Select 72 - Additional Training information required .

- Select Update .

- In NWS, reassign the WI as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type the applicable reason for the reassignment:

- “Unable to contact client for fact-finding.”

- “Not within Level 1 authority.” 

### Level 2

Source topic: `en_EN/task/training_sickness/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_sickness/reviewing_the_file_level_2.dita`

- In NWS, determine if there is an existing ROD for the training issue:

- If no, go to step 2.

- If yes and ACP allowed training reported between September 27, 2020 and September 11, 2021, but new information indicates that the client is not otherwise available, go to step 4.

- If yes, and it is any other situation, in NWS, complete the non-referred training WI. No further action is required.

- If the client is correcting previously provided information or providing previously omitted information, determine if the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue should be referred to Integrity by consulting Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if there is enough information to adjudicate the non-referred training:

- If additional details are needed, go to step 4.

- If additional details are not needed, go to step 7. 

#### Fact-finding

Source topic: `en_EN/task/training_sickness/fact-finding_level_2.dita`

- Fact-find with the client. For help determining the questions to ask the client, refer to the Fact-Finding Guide .

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 6.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 7.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — sickness benefits.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating non-referred training

Source topic: `en_EN/task/training_sickness/adjudicating_non-referred_training_level_2.dita`

- Adjudicate the non-referred training according to Digest Chapter 11.3.0 and Digest 10.12.2 — Persons attending courses on their own initiative and BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training .

- Based on the decision, select the applicable procedure:

- Entitlement conditions met
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_sickness#inorder2)

- Entitlement conditions not met
               [Entitlement conditions not met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_sickness#est2) 

#### Entitlement conditions met

Source topic: `en_EN/task/training_sickness/entitlement_conditions_met_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — entitlement in order.”

- Details: Document the decision and rationale according to chapters 10.12.2 and 11.3.0 of the Digest. Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [10.12.2](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2) 
               [11.3.0](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-11/otherwise-available-for-work.html#a11_3_0) 
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the non-referred training information has been input in the Project tab:

- If the non-referred training information has been input, go to step 3.

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Determine if there is a pending claimant’s report:

- If there is a pending claimant’s report, clear the outstanding claimant’s report .
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 4.

- Determine if there is an MA72 imposed and an outstanding registration number for the non-referred training issue:

- If an MA72 is imposed but there is no registration number, go to step 5.

- If an MA72 is imposed and there is a registration number, go to step 6.

- If no MA72 is imposed, and there is a revised registration number, go to step 7.

- If none of the above applies, go to step 8.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 8.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Entitlement conditions not met

Source topic: `en_EN/task/training_sickness/entitlement_conditions_not_met_level_2.dita`

- In NWS, create ROD as follows:

- Comments: Type “Non-referred training — not otherwise available — D-33 from w/c XXXX-X to XXXX-X.”

- Details: Document the decision and rationale according to chapters 10.12.2 and 11.3.0 of the Digest. Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [10.12.2](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2) 
               [11.3.0](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-11/otherwise-available-for-work.html#a11_3_0) 
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- If fact-finding by telephone was not attempted, select Draft and go to step 2.

- If the client was reached by telephone during fact-finding, select Draft and go to step 2.

- If the client was not reached by telephone during fact-finding, select Save and go to step 3.

- Verbally communicate the decision to the client.

- In FTS, determine if there is an outstanding registration number for the non-referred training issue:

- If there is an outstanding registration number, go to step 4.

- If there is no outstanding registration number, select the Registration Number(M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if an MA72 is imposed for the non-referred training issue:

- If an MA72 is imposed, go to step 5.

- If an MA72 is not imposed, go to step 6.

- Select the Renewal/Revised (M106) transaction to remove the MA72 and input the disentitlement as follows:

- Registration number: Select the related registration number.

- Manual action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 33 - incapacity proven but not otherwise available .

- Start date: Select the disentitlement start date.

- End date: Select the appropriate disentitlement end date as follows:

- If the training has ended, select the corresponding end date of the disentitlement.

- If the training has not ended, select Indefinite .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate message:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Update .

- Go to step 7.

- Select the Disqualifications/Disentitlements (M161) transaction and input the disentitlement as follows:

- Registration Number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 33 - incapacity proven but not otherwise available .

- Start date: Select the disentitlement start date.

- End date: Select the appropriate disentitlement end date as follows:

- If the training has ended, select the corresponding end date of the disentitlement.

- If the training has not ended, select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate message:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes.

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In FTS, determine if the non-referred training information has been input on the Project tab:

- If the non-referred training information has been input, go to step 9.

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Determine if there is a pending claimant's report:

- If there is a pending claimant’s report, clear the outstanding claimant’s report .
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 9.

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- D33 - Not otherwise available (11034).

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select the appropriate option, and select the disentitlement dates.

- Text - Reasons why not otherwise available (1630): Type “You are on a non-approved training course.”

- Overpayment Messages (2452)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI. 

## Policy reference

Source topic: `en_EN/task/training_sickness/policy_reference.dita`

- Digest 11.3.0 — Second entitlement condition: to be otherwise available for work
         [Digest 11.3.0 — Second entitlement condition: to be otherwise available for work](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-11/otherwise-available-for-work.html#a11_3_0)

- Digest 10.12.2 — Persons attending courses on their own initiative
         [Digest 10.12.2 — Persons attending courses on their own initiative](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training
         [BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2023-05.shtml) 
