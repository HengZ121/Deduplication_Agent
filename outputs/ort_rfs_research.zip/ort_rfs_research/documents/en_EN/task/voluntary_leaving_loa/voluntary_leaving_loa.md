# Adjudicating a leave of absence — Level 1

Source map: `en_EN/task/voluntary_leaving_loa/voluntary_leaving_loa.ditamap`

## Summary

Source topic: `en_EN/task/voluntary_leaving_loa/summary.dita`

Summary: When a client takes a voluntary leave of absence, entitlement to regular benefits may be affected. When specific conditions are met, the Level 1 officer can allow the reason for separation (RFS). 

## What you need to know

Source topic: `en_EN/task/voluntary_leaving_loa/what_you_need_to_know.dita`

### Adjudicating a leave of absence

Source topic: `en_EN/task/voluntary_leaving_loa/adjudicating_a_leave_of_absence.dita`

A leave of absence is a prearranged unpaid period of absence from work, authorized by the employer, with an anticipated end or return to work (RTW) date.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1738.dita) 

### Availability during a leave of absence

Source topic: `en_EN/task/voluntary_leaving_loa/availability_during_a_leave_of_absence.dita`

If requesting regular benefits, the client must be capable of and available for work to be considered entitled. However, if requesting sickness benefits, the client must be otherwise available to be considered entitled. If the client is not otherwise available, the officer reviews the client’s availability. For more information, the officer refers to Availability .
       [Availability](/en/procedure/activity/availability.shtml) 

### ROE

Source topic: `en_EN/task/voluntary_leaving_loa/roe.dita`

An ROE is not required to adjudicate a leave of absence.

In NWS, there may be a New ROE message displayed on the Adjudication Issue (ADJ) WI for the leave of absence issue. The message indicates that a new ROE has been received with an RFS that must be reviewed. The ROE may match the period of employment for that or another outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4980.dita) 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/voluntary_leaving_loa/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Levels of decision

Source topic: `en_EN/task/voluntary_leaving_loa/levels_of_decision.dita`

A Level 1 officer can render the decision to allow a period of leave of absence on an initial or renewal claim for an ROE that is not the last when:

- the claim is an initial or renewal claim; and

- the leave of absence is not on the last ROE; and

- the client is not requesting benefits for the period of the leave of absence;

- the client resumed employment with the same employer after the period of leave of absence and was then laid off or stopped working for a reason that can be allowed at Level 1; or

- the client did not resume the employment and the RFS can be allowed at Level 1; or

- the client accumulated enough insurable hours with another employer after the beginning of the period of leave to qualify to receive benefits.

When the Level 1 officer cannot adjudicate the issue, the facts are documented and the RFS is referred to Level 2 for adjudication. 

### Claim action status and processing the claim

Source topic: `en_EN/task/voluntary_leaving_loa/claim_action_status_and_processing_the_claim.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) .

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can calculate the initial claim or finalize the renewal claim. Once all of the ADJ WIs are completed, the system rescinds the 2 - Contentious Renewal in Automation manual action (MA02). 

### Updating the ROE after adjudication

Source topic: `en_EN/task/voluntary_leaving_loa/updating_the_roe_after_adjudication.dita`

When the leave of absence is adjudicated and the ROE is received, the officer updates block Special condition of the ROE to either Authorized period of leave (without just cause) or Voluntary leaving - Just cause . An initial claim cannot be calculated until block Special condition is updated. When the officer selects Authorized period of leave , the system generates the D43 with the calculation result.

**ROE errors found during validation**

ROEs are automatically validated by the system. In some situations, a change must be made in RCM (such as updating block Special condition ) before this validation can occur. When an error is detected during the validation (e.g. a vacation pay type is not indicated on an ROE), ACP does not automatically create an ROE Issue (ROE) Correction WI, but the error prevents automatic calculation. If possible, the officer must correct the ROE immediately so ACP can calculate the claim. 

### Processing the Adjudication Issue (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_loa/processing_the_adjudication_issue_adj_w_43ed2c2a.dita`

Adjudication of the leave of absence is not required if the employment is not insurable, either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, the ADJ WI must not be completed. The officer follows the procedures and conditions for removal of claims from ACP process . The officer moves the ADJ WI to Pending until the Claim Assessment (CA) or Specialized Application (SA) WI is created. An authorized user must then delete the ADJ WI.
       [procedures and conditions for removal of claims from ACP process](https://esdc.prv/en/service-canada/ei/technologies/acp/index.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0125.dita) 

### Reason for separation (RFS) — Temporary Budget measures

Source topic: `en_EN/task/voluntary_leaving_loa/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**Adjudicating the last employment in the qualifying period (QP) — BPCs between w/c 2310 and w/c 2361**

Budget 2021 has introduced a temporary simplification measure starting September 26, 2021. For claims with a BPC between w/c 2310 and w/c 2361, the officer will only adjudicate the last period of employment in the QP if it is contentious. If the officer allows the last RFS, all other ROEs in the QP, even if they are contentious, are used to calculate the claim. If, however, the officer does not allow the RFS on the last ROE in the QP, the claim is calculated with a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 

This new measure does not apply to fishing claims and claims for self-employed people. Instead, if clients have insurable employment in the QP with a contentious RFS and a BPC between w/c 2310 and w/c 2361 when they apply for self-employment (SE) or fishing benefits, the officer must adjudicate the contentious RFS following normal adjudication procedures.

When the client declares other employers with a contentious RFS on the same application, if ACP does not allow the issue under auto-adjudication rules, the issue is automatically resolved and ACP creates a record of decision (ROD) that shows Adjudication not Required . Block Special condition on the ROE is not updated, and the ROE is included in the calculation. An ADJ WI is not created for the RFS.

ACP does not always automatically create an ADJ WI when the application is received. However, if an ROE with a contentious RFS is received during the automation process, ACP may create an ADJ WI or ROE RFS Action WI.

When there is more than one ROE with the same last day paid (LDP), and one of the ROEs is contentious while the other ROE is not, adjudication is not required and both ROEs are included in the calculation.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1741.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4981.dita) 

### Adjudication not required: Reason for separation (RFS) beyond 12 weeks — BPCs between w/c 2258 and w/c 2309

Source topic: `en_EN/task/voluntary_leaving_loa/adjudication_not_required_reason_for_se_2ca905dc.dita`

Adjudication principles on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309 only apply to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the I of E used to establish the claim.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4982.dita) 

### Adjudication not previously required — Specialized ACP process

Source topic: `en_EN/task/voluntary_leaving_loa/adjudication_not_previously_required__s_a89cd8c4.dita`

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the QP. The RFS issues that were not previously adjudicated can be identified because block Special condition was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0092.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_1738.dita`

Note:

When the period of leave is entirely in the qualifying period (QP) and is not the last ROE, the leave of absence has no impact on an initial claim. Any hours of insurable employment accumulated in the QP are included in the claim calculation, regardless of whether the client has just cause for the leave of absence. A leave of absence without just cause results in a disentitlement for the period of leave, but the disentitlement does not apply to the QP. Therefore, if the period of leave is entirely in the QP on an initial claim, the officer can conclude without further fact-finding that the client has just cause for the leave of absence. Communication with the employer is also not required. 

### Note

Source topic: `en_EN/common_notes/note_c_4980.dita`

Note:

The client may report leave of absence on the EI application but the ROE indicates a non-contentious RFS. In this situation, fact-finding is required. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the WI is completed indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_0125.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. In these situations, adjudication of the leave is required. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Example 1

Source topic: `en_EN/common_notes/note_c_1741.dita`

Example 1:

Peter’s LDP was September 28, 2021 (w/c 2310) with 2 employers. Three periods of employment are provided on his EI application. Peter declared Employer 1 as his last employer and the RFS is shortage of work. In the Other Employers section of the application, Peter declared Employer 2 and the RFS is leave of absence. He also declared Employer 3 and the RFS is voluntary leaving. The interruption of earnings (I of E) is in w/c 2310, and he applied for benefits on September 29, 2021. His BPC is September 26, 2021 (w/c 2310).

There are 2 contentious ROEs on Peter’s file:

- Employer 1: The LDP is September 28, 2021 (w/c 2309). The RFS is A .

- Employer 2: The LDP is September 28, 2021 (w/c 2309). The RFS is N .

- Employer 3: The LDP is May 19, 2021 (w/c 2291). The RFS is E .

Employer 1 and Employer 2 have the same LDP. The RFS with Employer 1 is non-contentious, so adjudication is not required for Employer 2. ACP automatically resolves the RFS for Employer 2 and creates a ROD that shows Adjudication not required .

The RFS with Employer 3 is contentious and is in the QP. However, because it is not the last employer in the QP, adjudication is not required. ACP creates a ROD that shows Adjudication not required .

All ROEs are included in the calculation of the claim. 

### Example 2

Source topic: `en_EN/common_notes/note_c_4981.dita`

Example 2:

Abdul’s LDP was September 24, 2021 (w/c 2309) with both of his employers. He declared Employer 1 as his last employer and the RFS is leave of absence. In the Other Employers section of the application, Abdul declared Employer 2 and the RFS is voluntary leaving. The I of E is in w/c 2309, and he applied for benefits on September 26, 2021. His BPC is September 26, 2021 (w/c 2310).

- Employer 1: The LDP is September 24, 2021 (w/c 2309). The RFS is N .

- Employer 2: The LDP is September 24, 2021 (w/c 2309). The RFS is E .

Employer 1 and 2 have the same LDP and the RFS with both employers are contentious. ACP creates an ADJ WI for Employer 1, automatically resolves the RFS issue for Employer 2 and creates a ROD that shows Adjudication not required . If the leave of absence with Employer 1 is not allowed, the RFS with Employer 2 must be adjudicated. 

### Example

Source topic: `en_EN/common_notes/note_c_4982.dita`

Example:

Mary’s LDP was September 25, 2020 (w/c 2257). Her I of E is in w/c 2257, she submitted her EI application on September 26, 2020, and her BPC will be September 27, 2020 (w/c 2258).

There are 3 contentious ROEs on Mary’s file:

ROE 1: LDP September 25, 2020 (w/c 2257).

ROE 2: LDP July 17, 2020 (w/c 2247).

ROE 3: LDP May 31, 2020 (w/c 2241).

To determine which RFS to adjudicate, the officer subtracts 12 weeks from w/c 2257 (week of the I of E). For the example above, the formula is as follows: w/c 2257 (I of E) – 12 = w/c 2245. This determines a 12-week period falling before the Sunday of the I of E that encompasses the weeks from w/c 2245 to w/c 2256. The officer follows normal procedures and adjudicates ROE 1, which is the most recent ROE in the QP, and ROE 2, as it falls between w/c 2245 and w/c 2256, the 12-week period.

The officer allows any contentious RFS that occurs before the 12-week period. ROE 3 is before the 12-week period, so the officer allows the RFS by following the steps of Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
       [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#adj_not_require_rfs_beyond_12_weeks)

     [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#adj_not_require_rfs_beyond_12_weeks) 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0092.dita`

Note:

Any contentious RFS issues in the benefit period (BP) must be adjudicated. 

## Regional considerations

Source topic: `en_EN/task/voluntary_leaving_loa/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/voluntary_leaving_loa/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/voluntary_leaving_loa/in_nws.dita`

- Is there a ROD for the RFS on this or a previous EI application?

- What is the client’s statement in the Voluntary leaving section of this or a previous EI application?

- Are there any SROCs, Action Item (AI) WIs, other WIs or documentation containing checklists or other details relating to the RFS on this or a previous EI application?

- Is there an ROE Correction WI for the ROE concerning the leave of absence?

- Is this the last period of employment?

- Did the client apply for EI benefits during the leave of absence? 

### In FTS:

Source topic: `en_EN/task/voluntary_leaving_loa/in_fts.dita`

- Was the client claiming benefits during the period of the leave of absence?

- What is the claim type (CT) (initial, continuing or renewal)?

- Is there a 75 - Verification of reason for termination of Employment manual action (MA75) imposed to stop payments?

- Is there a registration number? 

### In Imaging:

Source topic: `en_EN/task/voluntary_leaving_loa/in_imaging.dita`

- Are there are any imaged documents relating to the RFS (they could have been received before the most recent application)? 

### In RCM:

Source topic: `en_EN/task/voluntary_leaving_loa/in_rcm.dita`

- Is there an ROE for the RFS?

- If yes, what is the RFS indicated?

- Are there any comments related to the RFS?

- Is there an ROE for a period of employment occurring after the leave of absence? 

## Step by step

Source topic: `en_EN/task/voluntary_leaving_loa/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/voluntary_leaving_loa/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/voluntary_leaving_loa/reviewing_the_file_level_1.dita`

- In NWS, determine if there is a ROD for the leave of absence issue already on file:

- If no, go to step 2.

- If yes, go to Adjudication not required — Decision already on file .
               [Adjudication not required — Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_loa#DeconFile)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1744.dita)

- Determine the CT:

- If this is an initial or renewal claim, go to step 3.

- If this is a continuing claim, go to step 8.

- In FTS, determine if the BPC falls in a period where special measures apply:

- If the BPC is between w/c 2258 and w/c 2309, go to step 4

- If the BPC is between w/c 2310 and w/c 2360, go to step 6.

- If the BPC is not in either of the periods, go to step 8.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita)

- Determine if the leave of absence occurred on the most recent ROE:

- If no, go to step 5.

- If yes, go to step 8.

- Determine if the leave of absence occurred within the 12-week period before the I of E:

- If yes, go to step 8.

- If no, go to Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
               [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_loa#adj_not_require_rfs_beyond_12_weeks)

- Determine if the claim is for SE or fishing benefits:

- If no, go to step 7.

- If yes, go to step 8.

- Determine if the leave of absence occurred on the most recent ROE:

- If yes, go to step 8.

- If no, go to Adjudication not required — Budget 2021 simplification measures.
               [Adjudication not required — Budget 2021 simplification measures.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_loa#adj_not_required_budget_2021)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 9.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting the Deferring adjudication .

- If adjudication cannot be deferred and this is a continuing claim, go to Reassigning the WI to Level 2 .
               [Reassigning the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_loa#reassigntoL2)

- If adjudication cannot be deferred and the leave of absence is on the last period of employment on an initial or renewal claim, go to Reassigning the WI to Level 2 .
               [Reassigning the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_loa#reassigntoL2)

- If adjudication cannot be deferred and the leave of absence is not from the last period of employment on an initial or renewal claim, go to step 10.

- Determine if the employment is not insurable, either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 11.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_loa#Employment_not_insurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if the client is capable and available for work (regular benefits) or otherwise available for work (sickness benefits):

- If yes, go to step 12.

- If no, go to Reassigning the WI to Level 2 .
               [Reassigning the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_loa#reassigntoL2)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4983.dita)

- Determine if there is enough information to adjudicate the leave of absence based on the National Policy on Levels of Decision :

- If no, go to step 13.

- If yes, go to step 16. 

#### Fact-finding

Source topic: `en_EN/task/voluntary_leaving_loa/fact-finding_level_1.dita`

- Fact-find with the client or employer to obtain the required information.

- Determine if the client or employer was reached during fact-finding:

- If the client or employer was reached, go to step 15.

- If the client or employer was not reached or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to Reassigning the WI to Level 2 .
               [Reassigning the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_loa#reassigntoL2)

- In NWS, add to the draft SROC or create a new SROC as follows:

- Issue: Select Reason for separation .

- Comments: Type “Leave of absence — [employer’s name] — [LDW] — [client or employer].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- Select Save . 

#### Determining if the conditions to allow at Level 1 are met

Source topic: `en_EN/task/voluntary_leaving_loa/determining_if_the_conditions_to_allow__2ac9dc0f_level_1.dita`

- Determine if the conditions to allow the RFS are met:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4984.dita) 

- If the conditions are met, go to step 17.

- If the conditions are not met, go to Reassigning the WI to Level 2 .
               [Reassigning the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_loa#reassigntoL2) 

#### Leave of absence allowed

Source topic: `en_EN/task/voluntary_leaving_loa/leave_of_absence_allowed_level_1.dita`

- In NWS, create a ROD as follows:

- BPC: Enter the BPC.

- Comments: Type “Leave of absence — [employer’s name] — [LDW] — reason for separation allowed.”

- Details: Type “The circumstances related to the client’s leave of absence have been considered and based on the information on file, the criteria for a Level 1 decision have been met (National Policy on Levels of Decision).”

- In RCM, determine if the ROE with the RFS due to the leave of absence has been received:

- If yes, go to step 19.

- If no, go to step 21.

- Update the ROE as follows:

- Special condition: Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional information .

- Select Validate .

- Select Submit and determine if validation causes an ROE error:

- If yes, go to step 20.

- If no, go to step 21.

- In NWS, determine if there is a CA or ROE Correction WI for this ROE:

- If yes, go to step 21.

- If no, correct the ROE to fix the validation error and go to step 21. Refer to Correcting an ROE as required.
               [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- In NWS, complete the ADJ WI for the leave of absence. 

#### Employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_loa/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Leave of absence — [employer’s name] — [LDW] — adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the leave of absence is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the leave of absence is therefore not required.”

- Determine the Claim action status:

- If the status is In Progress (Automation) , go to step 3.

- If the status is In Progress (Manual) , go to step 6.

- In NWS, create a Reminder (REM) WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “ACP.”

- Due date: Enter today’s date.

- Language: Select the appropriate option.

- Details: Type “2” and “Processing — [unallocated or user name to whom the CA or SA WI is to be assigned].”

- Destination: Select Level and Canada .

- End User: Select Specific user . Type “SV-ADMIN, ACP-TAD” and select Find User .

- Select Save .

- Move the ADJ WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting removal of the claim from automation process. Employment not insurable. This WI must be deleted once CA or SA WI is created.”

- Bring forward date: Enter today’s date + 2 working days.

- Select OK .

- When the ADJ WI moves to the current workload, confirm that the Claim action status is In Progress (Manual) and a CA or SA WI was created.

- Contact an authorized user (team leader or Business Expertise Advisor) to delete the ADJ WI. 

#### Adjudication not required — Budget 2021 simplification measures

Source topic: `en_EN/task/voluntary_leaving_loa/adjudication_not_required__budget_2021__620824ac_level_1.dita`

- In NWS, create a ROD as follows:

- BPC: Enter the BPC.

- Comments: Type “Leave of absence — [employer’s name] — [LDW] — adjudication not required.”

- Details: Type “Budget 2021 simplification measure — period of employment is not the last employer in the qualifying period. Adjudication is not required. EI Act 29(a).”

- Select Save .

- Complete the ADJ WI for the leave of absence. 

#### Adjudication not required — Decision already on file

Source topic: `en_EN/task/voluntary_leaving_loa/adjudication_not_required__decision_alr_a281283e_level_1.dita`

- In RCM, determine if the ROE with the leave of absence has been received:

- If yes, go to step 2.

- If no, go to step 3.

- Update the ROE as follows:

- Reason for issuing this record of employment: Select N - Leave of absence .

- Special condition: Select the appropriate option:

- If just cause is not shown, select Authorized period of leave .

- If just cause is shown, select Voluntary leaving - Just cause .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional information .

- Select Validate .

- Select Submit .

- Complete the WI. 

#### Adjudication not required — Reason for separation (RFS) beyond 12 weeks

Source topic: `en_EN/task/voluntary_leaving_loa/adjudication_not_required__reason_for_s_d81cc200_level_1.dita`

- In NWS, create a ROD as follows:

- BPC: Enter the BPC.

- Comments: Type “Leave of absence — [employer’s name] — [LDW] — adjudication not required.”

- Details: Type “Post-Employment Insurance Emergency Response Benefit transitional measure — reason for separation beyond 12 weeks. EIA 153.194.”

- In RCM, determine if the ROE with the RFS due to the leave of absence has been received:

- If the ROE has been received, go to step 3.

- If the ROE has not been received, go to step 5.

- Update the ROE as follows:

- Special condition: Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the leave of absence from block 18 - Comments to block Additional information .

- Select Validate .

- Select Submit and determine if validation causes an ROE error:

- If yes, go to step 4.

- If no, go to step 5.

- In NWS, determine if there is a CA or ROE Correction WI for this ROE:

- If yes, go to step 5.

- If no, correct the ROE to fix the validation error and go to step 5. Refer to Correcting an ROE as required.
               [Correcting an ROE](/en/procedure/activity/correct_roe.shtml)

- In NWS, complete the ADJ WI for the leave of absence. 

#### Reassigning the WI to Level 2

Source topic: `en_EN/task/voluntary_leaving_loa/reassigning_the_wi_to_level_2_level_1.dita`

- Determine the CT:

- If this is a continuing claim, go to step 2.

- If this is an initial or renewal claim, go to step 3.

- In FTS, verify from the Summary tab if an MA75 has been input:

- If yes, go to step 3.

- If no, select the Renewal/Revised (M106) transaction and input the MA75 as follows:

- Registration number: Leave this field blank. If a number is displayed, remove it.

- Manual Action: Select 75 - Verification of reason for termination of Employment .

- Select Update .

- Go to step 3.

- In NWS, reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “The client quit [his/her] job and [provide a brief reason for the reassignment, e.g. not a referred course] — not within Level 1 authority.” 

#### Note

Source topic: `en_EN/common_notes/note_c_1744.dita`

Note:

If the BPC is between w/c 2310 and w/c 2361 and there is a ROD on file that indicates Adjudication not required — Budget 2021 simplification measures , complete the ADJ WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_4983.dita`

Note:

When determining whether the client is otherwise available for work (sickness benefits), consider the last period of employment and not the employment from which the client took the leave of absence. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4984.dita`

- the request is for an initial or renewal claim; and

- the leave of absence is not on the last ROE; and

- the client is not requesting benefits for the period of the leave of absence; and

- the client resumed employment with the same employer after the period of leave of absence and was then laid off or stopped working for a reason that can be allowed at Level 1; or

- the client did not resume the employment and the RFS can be allowed at Level 1; or

- the client accumulated enough insured hours with another employer after the beginning of the period of leave to qualify for benefits. 

## Policy reference

Source topic: `en_EN/task/voluntary_leaving_loa/policy_reference.dita`

- Digest 6.6.0 — Periods of Leave
         [Digest 6.6.0 — Periods of Leave](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/periods-of-leave.html#a6_6_10)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 32
         [EIA 32](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-32.html)

- National Policy on Levels of Decision — Period of leave of absence
         [National Policy on Levels of Decision — Period of leave of absence](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml#s10_2) 
