# Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Fishing ROE

Source map: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/post_eierb_completing_assessment_issue__d0072767.ditamap`

## Summary

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/summary.dita`

Summary: ACP creates an Assessment Issue (ASMT) ROE Correction WI in the specialized ACP process when an ROE has an error that prevents automation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2628.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_2628.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP no longer creates WIs based on specialized processing. However, the agent continues to complete outstanding WIs that were created by the specialized process before August 16, 2021 using specialized procedures. 

## What you need to know

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4050.dita) 

### Data entry errors on an ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/data_entry_errors_on_an_roe.dita`

Procedures related to the data entry of an ROE or the review of ROE comments sometimes create an error on the ROE (e.g. a change was made to the original ROE but was not initialled by the employer). When this occurs, the discrepancy is indicated in the Additional information field of the ROE. 

### Identifying ROE errors

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/identifying_roe_errors.dita`

In RCM, an ROE error message is displayed in red beside the blocks in error. When an ROE is corrected, the agent validates the changes to determine if errors are still present or if new ones have occurred. The ROE is considered successfully corrected and available for use in the claim assessment only when no error messages remain.

**Duplicate ROEs**

If the ROE displays an error message stating that a serial number has already been entered for another SIN, the agent refers to Post-EI ERB: Correcting an ROE flagged as a duplicate ROE with a different SIN .
       [Post-EI ERB: Correcting an ROE flagged as a duplicate ROE with a different SIN](/en/procedure/task/post_eierb_correcting_roe_flagged_duplicate_roe_different_sin.shtml)

**ROEs with a serial number status problem**

If the ROE displays an error message stating that a problem with the status of the serial number was detected, the agent refers to Post-EI ERB: Correcting an ROE flagged with a serial number problem .
       [Post-EI ERB: Correcting an ROE flagged with a serial number problem](/en/procedure/task/post_eierb_correcting_roe_flagged_with_a_serial_number_problem.shtml) 

### Correcting ROE errors

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/correcting_roe_errors.dita`

Guides are available to help employers correctly complete an ROE. When errors are present and the agent must contact the employer, the agent can also use these guides to teach the employer how to correctly complete the ROE.

The agent makes every effort to correct the ROE as soon as possible since the client is waiting for payment. The agent reviews all the information on file (the application, previous claims, Easy Access, Employer database, etc.) before contacting the client or the employer. The agent completing the ASMT ROE Correction WI must contact the client before contacting the employer if the required information is the trip start date or the trip end date for fresh catch. The client is contacted because most buyers do not know this information. For cured catch, the agent obtains the trip end date from the employer.

If the agent is unable to obtain the information required to correct the ROE from the employer or client, the agent takes the following steps:

- estimates the corrections using the available information on file;

- sends a letter to notify the employer of the changes made;

- sends a letter to notify the client that the ROE is unverified and may be reviewed at a later date if additional information is received. 

### Note

Source topic: `en_EN/common_notes/note_c_4050.dita`

Note:

This task applies only to ASMT WIs that were created to correct an ROE error in the specialized ACP process before its end date of August 16, 2021. To correct an ROE error in the normal ACP process, the agent refers to Completing an ROE Correction WI — Fishing ROE (Non-complex) or Correcting an error during calculation or recalculation — Fishing ROE (Level 1).
       [Completing an ROE Correction WI — Fishing ROE](/en/procedure/task/completing_roe_correction_fisher.shtml) 
       [Correcting an error during calculation or recalculation — Fishing ROE](/en/procedure/task/correcting_roe_error_calculation_fisher.shtml)

     [Completing an ROE Correction WI — Fishing ROE](/en/procedure/task/completing_roe_correction_fisher.shtml) 
     [Correcting an error during calculation or recalculation — Fishing ROE](/en/procedure/task/correcting_roe_error_calculation_fisher.shtml) 

## Regional considerations

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/in_nws.dita`

- What is the name of the employer declared on the application?

- What is the last day worked (LDW) declared on the application?

- Are there documents (e.g. SROC, other WIs) containing the information necessary to correct the ROE? 

### In RCM:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/in_rcm.dita`

- Which error messages are displayed when attempting to validate the ROE?

- Is there information in the Comments or Additional information field of the ROE? 

### In Imaging:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/in_imaging.dita`

- Are there any documents that provide the information required to correct the ROE? 

### In the Employer database:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/in_the_employer_database.dita`

- Is there any information about this employer?

- Is there any information about the ROE error in question? 

## Step by step

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/non-complex.dita`

#### Reviewing the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/reviewing_the_roe_non-complex.dita`

- In RCM, determine if an error states that the serial number has already been entered for another SIN:

- If no, go to step 2.

- If yes, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__d0072767#nc_item_5)

- Determine if an error states that a problem with the status of the serial number was detected:

- If no, go to step 3.

- If yes, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__d0072767#nc_item_5) 

#### Correcting the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/correcting_the_roe_non-complex.dita`

- Determine which blocks of the ROE are in error and consult the table in ROE: RCM validation error correction for a fishing ROE — Instructions to determine how to correct the ROE:

- If the table indicates that corrections can be made with the information on file, go to step 4.

- If the table indicates that employer (or client) contact is required, go to step 5.

- If the table does not indicate that corrections can be made at your level and does not indicate that employer contact is required, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__d0072767#nc_item_5)

- In RCM, correct the errors and do the following:

- Additional information : Type “Changes made to blocks [X] in accordance with the EI ORT.”

- Select Validate and do the following:

- If error messages are displayed for any block, repeat step 3.

- If no error message is displayed, select Submit and go to step 9. 

#### Fact-finding

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/fact-finding_non-complex.dita`

- Fact-find with the person who issued the ROE (or the client) to obtain the missing information by phone.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4051.dita)

- Determine if the information has been obtained:

- If yes, go to step 7.

- If no, save the draft SROC and go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__d0072767#nc_item_5) 

#### Updating the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/updating_the_roe_non-complex.dita`

- In RCM, correct the ROE and do the following:

- Additional information : Type “Changes to block [X] confirmed with [client or employer, including the name of the person contacted].”

- Select Validate and do the following:

- If an error message is displayed and the table in ROE: RCM validation error correction for a fishing ROE — Instructions does not indicate to check the Override-able errors box next to the error message, go to step 8.
                   [ROE: RCM validation error correction for a fishing ROE — Instructions](/en/procedure/generic/correction_fishing_1.shtml)

- If error messages are displayed and the table in ROE: RCM validation error correction for a fishing ROE — Instructions indicates to check the Override-able errors box next to each error message, check the appropriate boxes and select Submit . Go to step 9.
                   [ROE: RCM validation error correction for a fishing ROE — Instructions](/en/procedure/generic/correction_fishing_1.shtml)

- If no error message is displayed, select Submit and go to step 9.

- Determine which blocks of the ROE are in error and consult the table in ROE: RCM validation error correction for a fishing ROE — Instructions to determine how to correct the ROE:

- If the table indicates that corrections can be made at your level, repeat step 7.

- If the table does not indicate that corrections can be made at your level, go to Reassigning the WI to Level 1 .
               [Reassigning the WI to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__d0072767#nc_item_5)

- In NWS, complete the ASMT ROE Correction WI. 

#### Reassigning the WI to Level 1

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/reassigning_the_wi_to_level_1_non-complex.dita`

- In NWS, reassign the WI to Level 1 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 1 .

- Reason: Select Unable to complete .

- Details: Type the appropriate option:

- “Unable to make ROE corrections to ROE block [number].”

- “The serial number is already in use for another SIN.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_4051.dita`

Note:

If the person cannot be reached on the first attempt, leave a message. If unable to leave a message on the first attempt or if the person does not call back within 24 hours, make one more attempt by phone but do not leave a message on the second attempt. Document the attempts in a draft SROC per usual procedures. 

### Level 1

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/level_1.dita`

#### Reviewing the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/reviewing_the_roe_level_1.dita`

- In RCM, determine if an error states the serial number has already been entered for another SIN:

- If no, go to step 2.

- If yes, go to Post-EI ERB: Correcting an ROE flagged as a duplicate ROE with a different SIN .
               [Post-EI ERB: Correcting an ROE flagged as a duplicate ROE with a different SIN](/en/procedure/task/post_eierb_correcting_roe_flagged_duplicate_roe_different_sin.shtml)

- In RCM, determine if an error states a problem with the status of the serial number was detected:

- If no, go to step 3.

- If yes, go to Post-EI ERB: Correcting an ROE flagged with a serial number problem .
               [Post-EI ERB: Correcting an ROE flagged with a serial number problem](/en/procedure/task/post_eierb_correcting_roe_flagged_with_a_serial_number_problem.shtml) 

#### Correcting the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/correcting_the_roe_level_1.dita`

- Determine which blocks of the ROE are in error and consult the tables in ROE: RCM validation error correction for a fishing ROE — Instructions and ROE: RCM validation error correction for a fishing ROE (employer not reached) — Instructions to determine how to correct the ROE:

- If the corrections can be made with the information on file, go to step 4.

- If the corrections cannot be made with the information on file, go to step 5.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4052.dita)

- In RCM, correct the errors and do the following:

- Additional information : Type “Changes made to blocks [X] in accordance with the EI ORT.”

- Select Validate and do the following:

- If an error message is displayed and the tables do not indicate to check the Override-able errors box next to the error message, repeat step 3 to determine how to correct the error.

- If error messages are displayed and the tables indicate to check the Override-able errors box next to each error message, check the appropriate boxes and select Submit . Go to step 15.

- If no error message is displayed, select Submit and go to step 15. 

#### Fact-finding

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/fact-finding_level_1.dita`

- Determine if the trip start date (block 6A ) or trip end date (block 6B ) for fresh catch requires correction:

- If no, go to step 6.

- If yes, go to step 8.

- Fact-find with the person who issued the ROE to obtain the missing information by phone.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4053.dita)

- Determine if the information has been obtained:

- If no , save the draft SROC and go to step 8.

- If yes, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4054.dita)

- If indicated in the table in ROE: RCM validation error correction for a fishing ROE — Instructions , fact-find with the client to obtain the missing information.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4055.dita)

- Determine if the information has been obtained:

- If yes, go to step 10.

- If no, save the draft SROC and go to Actioning the ROE error without verification .
               [Actioning the ROE error without verification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__d0072767#level1_item_5) 

#### Updating the ROE

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/updating_the_roe_level_1.dita`

- In RCM, correct the ROE and do the following:

- Additional information : Type “Changes to block [X] confirmed with [client or employer, including the name of the person contacted].”

- Select Validate and do the following:

- If an error message is displayed and the tables do not indicate to check the Override-able errors box next to the error, go to step 11.

- If error messages are displayed and the tables indicate to check the Override-able errors box next to each error message, check the appropriate boxes and select Submit . Go to step 12.

- If no error message is displayed, select Submit and go to step 12.

- Determine which blocks of the ROE are in error and consult the tables in ROE: RCM validation error correction for a fishing ROE — Instructions and ROE: RCM validation error correction for a fishing ROE (employer not reached) — Instructions to determine how to correct the ROE:

- If the corrections can be made with the information on file, repeat step 10.

- If the corrections cannot be made with the information on file, save the draft SROC and go to Actioning the ROE error without verification .
               [Actioning the ROE error without verification](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__d0072767#level1_item_5)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4052.dita)

- Determine if the ROE has been corrected based on information provided by the employer or the client:

- If the client provided the information, go to step 13.

- If the employer provided the information, go to step 15.

- In ACS, send a copy of the Z-02-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805)

- Multiple Changes to ROE

- A Single Change to ROE

- List of the change

- Attached INS 3413

- Create and send the N-06-0-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Various reasons - No ROE - Clm Approved / Clm Not Est'd (2699)

- Claim approved-Unverified / Interim ROE(s)

- Unverified ROE / unverified ROEs / Interim ROE / Interim ROEs (2502)

- Unverified ROE or unverified ROE(s)

- Receive ROE(s)/Receive additional info about ROE(s) (2503)

- Receive additional info about ROE(s)

- In NWS, complete the ASMT ROE Correction WI. 

#### Actioning the ROE error without verification

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/actioning_the_roe_error_without_verification_level_1.dita`

- In RCM, estimate the information required to correct the ROE using all available information on file, correct the ROE and do the following:

- Additional information: Type “Unable to verify changes to block [X] with employer or client.”

- In ACS, create and send the Z-02-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805):

- Multiple Changes to ROE or

- A Single Change to ROE

- List of the change

- Attached INS 3413

- Create and send the N-06-0-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Various reasons - No ROE - Clm Approved / Clm Not Est'd (2699)

- Claim approved-Unverified / Interim ROE(s)

- Unverified ROE / unverified ROEs / Interim ROE / Interim ROEs (2502)

- Unverified ROE or unverified ROE(s)

- Receive ROE(s)/Receive additional info about ROE(s) (2503)

- Receive additional info about ROE(s)

- In NWS, complete the ASMT ROE Correction WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4052.dita`

Note:

Refer to the

     [ROE: RCM validation error correction for a fishing ROE — Instructions](/en/procedure/generic/correction_fishing_1.shtml) 

table first. If the solution is not found, refer to the

     [ROE: RCM validation error correction for a fishing ROE (employer not reached) — Instructions](/en/procedure/generic/correction_fishing_2.shtml) 

table before moving on.

     [ROE: RCM validation error correction for a fishing ROE — Instructions](/en/procedure/generic/correction_fishing_1.shtml) 
     [ROE: RCM validation error correction for a fishing ROE (employer not reached) — Instructions](/en/procedure/generic/correction_fishing_2.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_4053.dita`

Note:

If the employer cannot be reached on the first attempt, leave a message. If unable to leave a message on the first attempt or if the employer does not call back within 24 hours, make one more attempt by phone but do not leave a message on the second attempt. Document the attempts in a draft SROC per usual procedures. 

#### Note

Source topic: `en_EN/common_notes/note_c_4054.dita`

Note:

If the employer provides information related to the reason for separation (RFS) during fact-finding, document the information on an SROC. Document all other changes in RCM. 

#### Note

Source topic: `en_EN/common_notes/note_c_4055.dita`

Note:

If unable to reach the client on the first attempt, leave a message and send an email (if the client provided an email address). If the client does not call back within 24 hours and did not provide an email address, make one more attempt by phone but do not leave a message. Document the attempts in a draft SROC per usual procedures. Refer to fact-finding for email instructions.
       [fact-finding](/en/procedure/task/fact_find.shtml)

     [fact-finding](/en/procedure/task/fact_find.shtml) 

## Policy reference

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__d0072767/policy_reference.dita`

- How to complete a ROE (employer’s guide)
         [How to complete a ROE (employer’s guide)](http://www.esdc.gc.ca/en/reports/ei/roe_guide/index.page) 
