# Adjudicating an Integrity case — Dismissal or suspension

Source map: `en_EN/task/aic_dismissal/aic_dismissal.ditamap`

## Summary

Source topic: `en_EN/task/aic_dismissal/summary.dita`

Summary: Investigators inform us of the results of an investigation in which they find that clients have not properly declared that they were dismissed or suspended from their employment. 

## What you need to know

Source topic: `en_EN/task/aic_dismissal/what_you_need_to_know.dita`

### Processing an Integrity claim review

Source topic: `en_EN/task/aic_dismissal/processing_an_integrity_claim_review.dita`

Below are the main processing steps for this activity. If the officer determines that the client knowingly made a false or misleading statement, the officer must adjudicate the dismissal or suspension, complete the record of decision (ROD), and refer to Misrepresentation to determine the type of sanction to impose. The officer must input the complete decision after determining the sanctions.
       [Misrepresentation](/en/procedure/activity/misrepresentation.shtml)

**Reconsidering a decision**

EIA 52 states that a claim for benefits may be reconsidered as long as it results in an overpayment (OP) or an underpayment (UP). The time limit for reconsidering a claim is 36 months from the week benefits were paid or payable. This period is extended to 72 months if there is a false or misleading statement.
       [EIA 52](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-13.html)

```text
| No false statement on file | False statement on file |

| Current week – 155 weeks (36 months) | Current week – 311 weeks (72 months) |
```

**Determining if a false statement was made**

A false statement is a statement that is incorrect or untrue. It can be the result of an intentional or negligent action, or it can be the result of an honest mistake.

For example, a client declared earnings of $250.00 on the claimant’s report. However, the client responded No to the question “Have you stopped working for any employer?” Following an investigation, it is revealed that the client was dismissed from the employment.

At this point, the officer only knows that the information provided by the client is incorrect. Without an explanation from the client, it cannot be determined if the client intentionally or knowingly failed to provide this information. Regardless of whether it was intentional or an honest mistake, the client did not report the dismissal from employment; therefore the reconsideration timeframe can be extended to 72 months.

**Determining if a false statement was knowingly made**

Knowingly means the officer can reasonably conclude that clients knew the information provided was untrue when they provided or did not report that information. There is no element of intent in this consideration. It is not necessary to determine a degree of fault. The officer must only establish that it is more likely that client understood the information provided and did not accurately portray the facts.

If the client received payments by paper cheque, each cheque cashed can be considered a misrepresentation under EIA 38(1)(e). If the client received payments by direct deposit, each direct deposit payment or any excess amount the client received and did not return can be considered a misrepresentation under EIA 38(1)(f).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1670.dita) 

**Reviewing a potential case of voluntary disclosure**

The National Policy on Voluntary Disclosure encourages clients, employers and third parties to come forward and voluntarily disclose misrepresentations. According to this policy, voluntary disclosure occurs when a person admits to having knowingly made a false statement.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

An investigator may recommend that the file be reconsidered in light of the National Policy on Voluntary Disclosure .
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

There are 2 essential conditions for approving the voluntary disclosure:

- There is no investigation under way in relation to the voluntary disclosure when a client admits to making a false statement.

- The false statement would have resulted in punitive measures such as a penalty, a warning or prosecution had there been no voluntary disclosure.

According to the National Policy on Voluntary Disclosure , there is no limit to the number of times that a client can voluntarily disclose misrepresentations.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 

### Reviewing an undeclared reason for separation (RFS)

Source topic: `en_EN/task/aic_dismissal/reviewing_an_undeclared_reason_for_sepa_2f26b5ef.dita`

**Reconsideration timeframes**

Under EIA 52(5), a false or misleading statement made in connection with a claim must have been made to extend the reconsideration timeframe. A false statement made regarding any contentious issue allows the extension of the reconsideration timeframe to 72 months for all contentious issues on a claim. For example, in situations in which a client did not correctly report earnings on a claimant’s report or failed to declare employment on the EI application, it is considered that the client made a false statement. Therefore, the reconsideration timeframe is extended for all issues detected, including the contentious RFS.

**Misrepresentation**

When submitting an EI application, clients are asked to declare all employment in the last 52 weeks. When declaring employment, clients are asked for the RFS. Similarly, clients who report earnings on their electronic claimant’s reports are asked if they stopped working for the employer during the reporting period. Clients who answer yes are then asked if they stopped working for a reason other than a layoff. Clients who provide incorrect information knowingly when answering questions about the RFS are making misrepresentations that warrant consideration of a sanction under EIA 38(1).

Clients who do not report earnings are not asked any questions about the RFS from employment. In these cases, the officer cannot show that clients made a false statement constituting misrepresentation. The officer may find misrepresentation only when there is other evidence showing a knowingly made false statement or omission for the issue. 

### Returning a file to Integrity

Source topic: `en_EN/task/aic_dismissal/returning_a_file_to_integrity.dita`

After conducting a full review of the investigation, if the Level 2 officer determines that facts are missing, the officer must return the file to the investigator for further fact-finding and indicate the information that is missing but necessary to adjudicate the file. The Level 2 officer must not adjudicate the issue if facts are missing or incomplete.

Facts are not considered missing or incomplete if the investigator has followed up with the client when the client fails to report for an interview or fails to reply to a request for information. The investigator is not required to send a follow-up letter but must make 2 attempts on 2 different days to contact the client by telephone. If the investigator leaves a message on a voicemail, only one attempt is required and they must allow 48 hours for the client to respond.

If the investigator recommends that the Integrity case be considered as voluntary disclosure, but the investigation type is not 70 in NIIS, the officer returns the file to Integrity.

The Integrity Services Branch does not verify the employer’s or third party’s version against the client’s version in the following situations:

- The investigation results in an actual or potential OP of less than the Integrity investigative threshold.

- There is no other active investigation.

In these situations, the officer does not return the case to Integrity because the employer’s or the third party’s version is missing. The officer is not required to validate the threshold. 

### Sending a claim for recalculation

Source topic: `en_EN/task/aic_dismissal/sending_a_claim_for_recalculation.dita`

When a new ROE must be included in the rate calculation, a retroactive review of the claim calculation is required, regardless of the impact (creation of an OP or a UP) that this ROE has on the benefit rate and the duration of the claim.
       [a retroactive review](/en/policy/bememo/be2007-04.shtml)

In this situation, the Level 2 officer adjudicates the unreported dismissal and completes all the necessary actions relating to the Claim Review (CR) Integrity WI. Regardless of whether or not there is a pending or unassigned CR Recalculation WI on file, the Level 2 officer creates an Action Item (AI) WI for Level 1 for a claim recalculation. 

### Communicating with the employer

Source topic: `en_EN/task/aic_dismissal/communicating_with_the_employer.dita`

The employer must be notified in writing of the decision and provided with the right to request reconsideration in cases where misconduct was not proven unless the employer reports that the client was dismissed for unsuitability. In that case, no misconduct is alleged and therefore no notification is required. 

### Defining claim status (CS)

Source topic: `en_EN/task/aic_dismissal/defining_claim_status_cs.dita`

A claim can be active, terminated, blocked or archived. The CS impacts which transactions can be input and when the letter of decision is sent:

    Active: 
      The active claim is established and is currently displayed automatically in FTS. It is a claim for which benefits are still payable and that has not been terminated. 
      Terminated: 
      A terminated claim appears on the

Dormant

tab in FTS. It has ended but can be reactivated. Once the transaction to reactivate the claim has been processed, all inputs for the claim must be done the same as for an active claim. 
      Blocked: 
      In some cases, the claim that the officer must reconsider is on the

Dormant

tab in FTS, but there is a new active claim established and displayed on the

Summary

screen. The officer makes adjustments to this type of claim using BCS if the blocked CS shows

1 - Updateable

. Otherwise, IPOC intervention is required. 
      Archived: 
      Claims that are more than 7 years old are moved from the

Dormant

tab to the

Archived

tab. The officer can view an archived claim by changing the status of the archived claim from

1 - Non-Viewable

to

2 - Viewable

in FTS. Once the officer requests to make the claim viewable, the status field immediately displays

2 - Viewable

and the claim becomes viewable the next business day for 2 weeks. Adjustments to this type of claim are processed with IPOC intervention. 

### Determining the order of FTS inputs

Source topic: `en_EN/task/aic_dismissal/determining_the_order_of_fts_inputs.dita`

Controlled, multiple-day inputs in FTS are required to establish separate OPs for each decision, such as unreported earnings and RFS. When there is more than one reconsideration decision that results in an OP, the decisions must be input in the following order:

**Determining the input order for multiple transactions**

- full disentitlement

- partial disentitlement

- unreported earnings or unreported allocation of earnings

- indefinite disqualification

- definite disqualification

Controlled inputs in FTS are also required for UP and OP situations. The officer processes the inputs resulting in the OP first. Once the OP is established, the officer inputs an agreed deduction equal to the benefit rate amount. For more information, the officer refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

### Imposing a disqualification or a disentitlement

Source topic: `en_EN/task/aic_dismissal/imposing_a_disqualification_or_a_disentitlement.dita`

Once it is determined that the client was dismissed for misconduct, the officer must determine whether an indefinite disqualification or disentitlement applies.

If it is determined that the client lost the employment due to misconduct, the officer imposes an indefinite disqualification on the claim for regular benefits beginning the Sunday of the week the event took place, unless the client has worked enough insurable hours since the misconduct to establish a new claim.

There may be situations where the employee is suspended from his duties for having acted in a way that resembles misconduct. The employer generally uses that suspension to review the evidence and determine if a disciplinary measure is sufficient or if a definitive dismissal is appropriate. If a client is suspended because of misconduct, the officer imposes a 42 - Suspension from employment disentitlement (D42) for the period of the suspension.

If a client is dismissed because of misconduct within 3 weeks of an anticipated layoff or end of term of employment, the officer imposes a 44 - Loss of employment in anticipation of layoff disentitlement (D44). The D44 is imposed for a definite period only (maximum 3 weeks).

In all other case of misconduct, the officer imposes a 10 - Dismissal - misconduct proven indefinite disqualification (D10). 

### BCS

Source topic: `en_EN/task/aic_dismissal/bcs.dita`

BCS allows certain types of transactions to be processed on blocked dormant claims. There are 2 options available: Estimate and Claim update .

**Claim update function**

When transactions must be input on a blocked claim, the officer reviews the Blocked Claims System tab in FTS to determine the CS in BCS. If the CS is 1 - Updateable , the officer requests an update using BCS and processes the transactions.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1795.dita) 

An update in BCS can only be done on one BPC at a time. When transactions are input but not processed, Yes appears in the Block Action Pending column and access is denied for input on all other BPCs until the requested transactions are processed. Access to a BPC with a pending action is limited to the officer who initiated that action.

If an update is requested by the officer but cannot be completed by BCS, on the next processing day, the “Blocked claim not updated or not calculated” message is displayed along with the exception, error or warning on the MR05 screen.

Officers review the exception, error or warning on the Results tab in BCS for further action. If the update cannot be completed using BCS, the system presents an estimate result. The decision can be sent to IPOC using the Forward via MM06 link, which creates the prefilled M106 and MM06.

**Estimate function**

The Estimate function in BCS allows officers to view and evaluate the end results without processing the transactions. Estimates are possible for blocked claims with a CS 1 - Updateable as well as unblocked dormant claims, provided the CS is 05 (inactive) or 06 (terminated) .

BCS Estimate transactions are processed overnight and the results are available on the Results tab the next day. Officers that have requested an estimate can view the end result and forward the request for IPOC intervention using the prefilled MM06 available on the Results tab. 

### Creating an Operational Centre Memo (MM06) transaction for multiple issues

Source topic: `en_EN/task/aic_dismissal/creating_an_operational_centre_memo_mm0_12498087.dita`

When the MM06 includes multiple issues, if at least one issue is deemed to be a misrepresentation whereas at least another one is not, the officer ensures to include the appropriate OP message code for each issue in the Remarks section. 

### Record of decision (ROD)

Source topic: `en_EN/task/aic_dismissal/record_of_decision_rod.dita`

The Level 2 officer must record and document each decision in a separate ROD. 

### Note

Source topic: `en_EN/common_notes/note_c_1670.dita`

Note:

A false statement knowingly made does not always result in an OP of benefits. Since a monetary penalty is calculated based on the OP resulting from the misrepresentation, the officer can consider sending a warning letter if the client knowingly made a false statement but the misrepresentation did not result in an OP. 

### Note

Source topic: `en_EN/common_notes/note_c_1795.dita`

Note:

At this time, BCS cannot process a benefit period extension, the recalculation of a claim, the removal of a manual action (MA) or a change in the full work week code for a week of special benefits. The officer must send an Operational Centre Memo (MM06) transaction asking IPOC to process these transactions. 

## Regional considerations

Source topic: `en_EN/task/aic_dismissal/regional_considerations.dita`

**Quebec — Returning the file to Integrity**

In addition to the information already indicated in this procedure, return the file to Integrity as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a Cc.

- In NWS, create a client Note and type “Measure — returned to Integrity” and include the date (YYYY-MM-DD). 

## What you need to look for

Source topic: `en_EN/task/aic_dismissal/what_you_need_to_look_for.dita`

### In NIIS:

Source topic: `en_EN/task/aic_dismissal/in_niis.dita`

- Review the IC07 Subject Enquiry screen for all active and prior cases.

- Review the IC04 Observation screen for a computer generated investigation.

- Review the IC08 Case Summary screen to determine the actions taken on the case.

- Review the IC56 Case Notes screen to ensure you have the complete case.

- Review the IC50 Report of Clerical Investigation or IC70 Report of Investigation screen.

- Is there an Integrity Investigation Sheet?

- Is there a Report of Interview? 

### In Imaging:

Source topic: `en_EN/task/aic_dismissal/in_imaging.dita`

- Are there any documents that are relevant to the case? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/aic_dismissal/in_integrity_investigations_document_up_6a8da64b.dita`

- Are there any documents that are relevant to the case? 

### In NWS:

Source topic: `en_EN/task/aic_dismissal/in_nws.dita`

- Review the EI application.

- Review SROCs, RODs, AI and Call Back (CB) WIs for information relevant to the case.

- Are there documents related to the issue? 

### In FTS:

Source topic: `en_EN/task/aic_dismissal/in_fts.dita`

- If necessary, review the claimant’s reports for the weeks under investigation.

- Is there an exemption from reporting?

- If yes, did the client receive payments by direct deposit?

- What is the CS (active, terminated, blocked or archived)

- If the claim is blocked, what is the CS in BCS? 

## Step by step

Source topic: `en_EN/task/aic_dismissal/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/aic_dismissal/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/aic_dismissal/reviewing_the_file_level_2.dita`

- Determine if there is a false statement:

- If no, go to step 2.

- If yes, go to step 3.

- Determine if the request for reconsideration was made within the 36 month time limit:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe.
               [Not within reconsideration timeframe.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_dismissal#notwithinreconsiderationperiod)

- Determine if the request for reconsideration is within the maximum reconsideration timeframe of 72 months:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_dismissal#notwithinreconsiderationperiod)

- Determine if the information gathered by Integrity is complete:

- If the information is complete, go to step 5.

- If the information is incomplete, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_dismissal#referringthefiletointegrity)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1667.dita)

- In NWS, create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction ):

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Adjudicate the dismissal using all the information provided by the client and the employer (if necessary, refer to Dismissal or Digest 7 — Misconduct ):

- If misconduct is proven, go to step 7.

- If misconduct is not proven, go to Dismissal — Misconduct not proven .
               [Dismissal — Misconduct not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_dismissal#notproven)

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — dismissal [name of the employer] — [last day worked] — misconduct proven.”

- Details: Document the decision and justification according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if the client knowingly made a false or misleading statement on the RFS, as described in Digest 18.3.1.5 — Knowingly and Digest 18.3.1.4 — Misleading :

- If there is a false statement that is knowingly made, go to step 9.

- If there is a false statement that is not knowingly made, go to step 11.

- If there is no false statement, go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_dismissal#reconsiderationwithin36months)

- Determine if the investigator recommends that the file be reconsidered in light of a voluntary disclosure, as described in National Policy on Voluntary Disclosure :

- If the voluntary disclosure criteria are not met, go to step 10.

- If the voluntary disclosure criteria are met but the investigation type in NIIS is not 70, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_dismissal#referringthefiletointegrity)

- If the voluntary disclosure criteria are met and the investigation type in NIIS is 70, go to Voluntary disclosure approved .
               [Voluntary disclosure approved](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_dismissal#voluntarydisclosureapproved)

- Continue with Adjudicating client or third party misrepresentation — Monetary penalty or warning letter to determine the appropriate sanctions and input all the decisions.

- For the false or misleading statements not knowingly made, determine the period in which the weeks under reconsideration fall:

- If all weeks reconsidered fall entirely within the prescribed period of 36 months , go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_dismissal#reconsiderationwithin36months)

- If any week reconsidered falls within the extended period of 72 months , go to Reconsideration after 36 months .
               [Reconsideration after 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_dismissal#reconsiderationwithin36to72) 

#### Not within reconsideration timeframe

Source topic: `en_EN/task/aic_dismissal/not_within_reconsideration_timeframe_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — EIA 52 — not within reconsideration timeframe.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Not within reconsideration timeframe, no adjudication on the unreported dismissal.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Returning the file to Integrity

Source topic: `en_EN/task/aic_dismissal/returning_the_file_to_integrity_level_2.dita`

- In NIIS, from the Document tab, select IC70 Report of Investigation or IC50 Report of Clerical Investigation , depending on the case and complete the following fields:

- Select Recommendation .

- Refer the file to Integrity as follows:

- Select Yes (IC70) .

- Check the box (IC50) .

- Enter the missing or additional information required in the text area.

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1796.dita)

- In FTS, select the Outstanding Registrations link to cancel the registration number as follows:

- Select Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Select Update .

- Return the paper documents relating to the investigation to the investigator who signed the Report of Investigation.

- In NWS, complete the CR Integrity WI. 

#### Dismissal — Misconduct not proven

Source topic: `en_EN/task/aic_dismissal/dismissal__misconduct_not_proven_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — dismissal — [name of the employer] — [last day worked] misconduct not proven.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if an MA is imposed to stop payments for the dismissal issue:

- If yes, go to step 3.

- If no, go to step 4.

- Select the Renewal/Revised (M106) transaction to remove the MA as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 5.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, in cases of alleged misconduct, inform the employer of the decision by sending a Z-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Advising Employer that Claim Approved (2775): Select Approved reason for separation .

- Reason for Claim Approval (2783):

- If fact-finding determined that misconduct was not proven, select No Misconduct .

- If the employer failed to provide information regarding the dismissal, select Insufficient information to prove Misconduct .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Misconduct not proven.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- Determine if the ROE is on file:

- If no, go to step 8.

- If yes, in RCM, update the Special condition field to reflect the reconsideration decision on the RFS. Go to step 8.

- Determine if a recalculation is required:

- If no, go to step 9.

- If yes, go to step 10.

- In NWS, determine if there is a CR WI Recalculation pending or unassigned in the related WIs for this BPC:

- If yes, go to step 10.

- If no, go to step 11.

- In NWS, create an AI WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select Revised .

- Destination — Level: Select EI Processing .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- Comments: Type the appropriate option:

- If a recalculation is required, type “Level 1 recalculation required — Integrity case [Integrity case number].

- If a recalculation is not required, type “Claim Review Recalculation WI — Integrity case [Integrity case number].”

- Details: Type the appropriate option:

- If a recalculation is required, type “A recalculation of BPC [DD-MM-YYYY] is required due to the adjudication of ROE [serial number]. A Level 2 ROD is on file and the reconsideration timeframe ends on [DD-MM-YYYY]. Recalculation inputs and notification to the client must be completed no later than this date.” If there is a CR Recalculation WI for the ROE under reconsideration, also type “Complete the Claim Review Recalculation work item related to this benefits period.”

- If a recalculation is not required, type “A recalculation of BPC [DD-MM-YYYY] is not required. Complete the Claim Review recalculation work item related to this benefits period.”

- Complete the CR Integrity WI. 

#### Voluntary disclosure approved

Source topic: `en_EN/task/aic_dismissal/voluntary_disclosure_approved_level_2.dita`

- Create a ROD for the voluntary disclosure issue as follows:

- Comments: Type “[Integrity case number] — voluntary disclosure approved.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain that the client meets the 2 conditions for the National Policy on Voluntary Disclosure .
               [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 3.

- If the claim is terminated, but may be reactivated:

- On the Terminated tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 3.

- If the claim is blocked or archived, go to step 6.

- Determine if an MA is imposed to stop payments for the unreported dismissal:

- If yes, go to step 4.

- If no, go to step 5.

- Select the Renewal/Revised (M106) transaction to remove the MA and input the D10 as follows:

- Registration number: Select the appropriate registration number.

- Manual action: Select the appropriate MA.

- Rescind: Check the box.

- Action: Select Add .

- Disqualification: Select 10 - Dismissal - misconduct proven .

- Effective: Enter the w/c for the dismissal.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 16.

- Select the Disqualifications/Disentitlements (M161) transaction and input the D10 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disqualification: Select 10 - Dismissal - misconduct proven .

- Effective: Enter the w/c for the dismissal.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 16.

- Determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 2 - Not blocked is displayed, return to step 2.

- If 1 - Updateable is displayed , go to step 7.

- If any other CS is displayed, go to step 14.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 8.

- If all rows are blank, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 8.

- If all rows are blank, go to step 10.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following fields:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- On the Disqualifications tab, input the D10 on the Disqualifications section as follows (up to 3 disqualifications in BCS can be imposed or rescinded):

- Action: Select A - Add .

- Type: Select 10 - Dismissal - misconduct proven .

- Effective Week: Select the disqualification start date.

- Number of Weeks: 9999 is prefilled.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 13.

- If the transaction shown is correct, select Close and go to step 16.

- Delete the incorrect transaction as follows.

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 11.

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the unreported dismissal.

- Work item: Select 91 - Overpayment .

- Work type: Select 1 - Misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D10 from w/c [XXXX].”

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Misconduct - Post audit

- We /We have re-reconsidered (2916)

- Start date of disqualification - Sunday’s date (1294)

- Text-Name of Employer(s) (1502)

- Date of Event (1292)

- No reply from client / reply received with an explanation / reply received with no explanation (2938)

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim

- Overpayment – No misrepresentation and  inactive claim

- In ACS, create and send the D-70-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Voluntary disclosure / Administrative Rule - Undeclared Earnings(2664)

- Voluntary disclosure of information

- Subjects of the voluntary disclosure (2665)

- Option #7: Text-Insert appropriate reason(s) (1618): Type “your dismissal from employment with [name of employer]”

- Blank/Reminder: Provide information on report (2667)

- Provide full and accurate information on each report and correct any incorrect reports as soon as possible .

- Overpayment messages (2452): Select the appropriate option

- Right to Request a Reconsideration (4169)

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other and type “Misconduct proven — voluntary disclosure.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- Determine if the ROE is on file:

- If no, go to step 20.

- If yes, in RCM, update the Special condition field to reflect the reconsideration decision on the RFS. Go to step 20.

- Determine if a recalculation is required :

- If no, go to step 21.

- If yes, go to step 22.

- Determine if a CR Recalculation WI pending or unassigned in the related WIs for this BPC:

- If yes, go to step 22.

- If no, go to step 23.

- Create an AI WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select Revised .

- Destination — Level: Select EI Processing .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- Comments: Type the appropriate option:

- If a recalculation is required, type “Level 1 recalculation required — Integrity case [Integrity case number].”

- If a recalculation is not required, type “Claim Review Recalculation WI — Integrity case [Integrity case number].”

- Details: Type the appropriate option:

- If a recalculation is required, type “A recalculation of BPC [DD-MM-YYYY] is required due to the adjudication of ROE [serial number]. A Level 2 ROD is on file and the reconsideration timeframe ends on [DD-MM-YYYY]. Recalculation inputs and notification to the client must be completed no later than this date.” If there is a CR Recalculation WI for the ROE under reconsideration, also type “Complete the Claim Review Recalculation work item related to this benefits period.”

- If a recalculation is not required, type  “Complete the Claim Review Recalculation work item related to this benefits period.”

- Complete the CR Integrity WI. 

#### Reconsideration within 36 months

Source topic: `en_EN/task/aic_dismissal/reconsideration_within_36_months_level_2.dita`

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 2.

- If the claim is terminated, but may be reactivated:

- On the Terminated tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 2.

- If the claim is blocked or archived, go to step 5.

- Determine if an MA is imposed to stop payments for the unreported dismissal :

- If yes, go to step 3.

- If no, go to step 4.

- In FTS, select the Renewal/Revised (M106) transaction to remove the MA and input the D10 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Action: Select Add .

- Disqualification: Select 10 - Dismissal - misconduct proven .

- Effective: Enter the w/c for the dismissal.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 15.

- Select the Disqualifications/Disentitlements (M161) transaction and input the D10 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disqualification: Select 10 - Dismissal - misconduct proven .

- Effective: Enter the w/c for the dismissal.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Go to step 15.

- Determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 2 - Not blocked is displayed, return to step 1.

- If 1 - Updateable is displayed, go to step 6.

- If any other CS is displayed, go to step 13.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 7.

- If all rows are blank, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 7.

- If all rows are blank, go to step 9.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following fields:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- On the Disqualifications tab, input the D10 on the Disqualifications section as follows (up to 3 disqualifications in BCS can be imposed or rescinded):

- Action: Select A - Add .

- Type: Select 10 - Dismissal - misconduct proven .

- Effective Week: Select the disqualification start date.

- Number of Weeks: 9999 is prefilled.

- Infraction: Select F - Non-fraud - Other.

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 12.

- If the transaction shown is correct, select Close and go to step 15.

- Delete the incorrect transaction as follows.

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 10.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the request for the unreported dismissal.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D10 from w/c [XXXX].”

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Misconduct - Post audit

- We /We have reconsidered (2916)

- Start date of disqualification - Sunday’s date (1294)

- Text-Name of Employer(s) (1502)

- Date of Event (1292)

- No reply from client / reply received with an explanation / reply received with no explanation

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim

- Overpayment – No misrepresentation and  inactive claim

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other and type “Misconduct proven.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- Determine if the ROE is on file:

- If no, go to step 18.

- If yes, in RCM, update the Special condition field to reflect the reconsideration decision on the RFS. Go to step 18.

- Determine if a recalculation is required:

- If no, go to step 19.

- If yes, go to step 20.

- In NWS, determine if there is a CR Recalculation WI pending or unassigned in the related WIs for this BPC:

- If yes, go to step 20.

- If no, go to step 21.

- Create an AI WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select Revised .

- Destination — Level: Select EI Processing .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- Comments: Type the appropriate option:

- If a recalculation is required, type “Level 1 recalculation required — Integrity case [Integrity case number].”

- If a recalculation is not required, type “Claim Review Recalculation WI — Integrity case [Integrity case number].”

- Details: Type the appropriate option:

- If a recalculation is required, type “A recalculation of BPC [DD-MM-YYYY] is required due to the adjudication of ROE [serial number]. A Level 2 ROD is on file and the reconsideration timeframe ends on [DD-MM-YYYY]. Recalculation inputs and notification to the client must be completed no later than this date.” If there is a CR Recalculation WI for the ROE under reconsideration, also type “Complete the Claim Review Recalculation work item related to this benefits period.”

- If a recalculation is not required, type  “Complete the Claim Review Recalculation work item related to this benefits period.”

- Complete the CR Integrity WI. 

#### Reconsideration after 36 months

Source topic: `en_EN/task/aic_dismissal/reconsideration_after_36_months_level_2.dita`

- In FTS, determine the blocked claim’s CS by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed, go to step 2.

- If any other CS is displayed, go to step 9.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 3.

- If all rows are blank, go to step 5.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 3.

- If all rows are blank, go to step 5.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following fields:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to complete the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- On the Disqualifications tab, input the D10 on the Disqualifications section as follows (up to 3 disqualifications in BCS can be imposed or rescinded):

- Action: Select A - Add .

- Type: Select 10 - Dismissal - misconduct proven .

- Effective Week: Select the disqualification start date.

- Number of Weeks: 9999 is prefilled.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 8.

- If the transaction shown is correct, select Close and go to step 11.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 6.

- Select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the request for the unreported dismissal.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D10 from w/c [XXXX].”

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Decision reconsidered beyond 36 months (2595): Select Decision reconsidered beyond 36 months due to false representations

- Indefinite disqualification - D11 or D10 - Post audit (2915)

- Misconduct - Post audit

- We /We have reconsidered (2916)

- Start date of disqualification - Sunday’s date (1294)

- Text-Name of Employer(s) (1502)

- Date of Event (1292)

- No reply from client / reply received with an explanation / reply received with no explanation

- False representation message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment – No misrepresentation and active claim

- Overpayment – No misrepresentation and  inactive claim

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other and type “Misconduct proven.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- Determine if the ROE is on file:

- If no, go to step 14.

- If yes, in RCM, update the Special condition field to reflect the reconsideration decision on the RFS. Go to step 14.

- Determine if a recalculation is required:

- If no, go to step 15.

- If yes, go to step 16.

- In NWS, determine if there is a CR Recalculation WI pending or unassigned in the related WIs for this BPC:

- If yes, go to step 16.

- If no, go to step 17.

- Create an AI WI as follows:

- Urgent: Check the box.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select Revised .

- Destination — Level: Select EI Processing .

- End User: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- Comments: Type the appropriate option:

- If a recalculation is required, type “Level 1 recalculation required — Integrity case [Integrity case number].”

- If a recalculation is not required, type “Claim Review Recalculation WI — Integrity case [Integrity case number].”

- Details: Type the appropriate option:

- If a recalculation is required, type “A recalculation of BPC [DD-MM-YYYY] is required due to the adjudication of ROE [serial number]. A Level 2 ROD is on file and the reconsideration timeframe ends on [DD-MM-YYYY]. Recalculation inputs and notification to the client must be completed no later than this date.” If there is a CR Recalculation WI for the ROE under reconsideration, also type “Complete the Claim Review Recalculation work item related to this benefits period.”

- If a recalculation is not required, type  “Complete the Claim Review Recalculation work item related to this benefits period.”

- Complete the CR Integrity WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1667.dita`

Note:

Cases with an OP below the Integrity investigative threshold are referred for adjudication only when specific exceptions are met (voluntary disclosure or impact on an active claim). In these cases, the employer’s or any other party’s version does not have to be verified and the file must not be returned to Integrity. 

#### Note

Source topic: `en_EN/common_notes/note_c_1796.dita`

Note:

The regional consideration for officers in the Quebec region is as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD as a Cc.

- In NWS, create a client Note and type “Measure — returned to Integrity” and include the date (YYYY-MM-DD). 

#### Note

Source topic: `en_EN/common_notes/note_c_1791.dita`

Note:

An update in BCS can only be done on one BPC at a time. 

## Policy reference

Source topic: `en_EN/task/aic_dismissal/policy_reference.dita`

- Digest 7 - Dismissal
         [Digest 7 - Dismissal](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-7/table-of-contents.html)

- Digest 17 - Reconsideration, Amendment of a Decision, and Error Correction
         [Digest 17 - Reconsideration, Amendment of a Decision, and Error Correction](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/table-of-contents.html)

- Digest 18 - Policy on Penalties
         [Digest 18 - Policy on Penalties](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/table-of-contents.html)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- EIA 38
         [EIA 38](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-11.html)

- EIA 52
         [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 
