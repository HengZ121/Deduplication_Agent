# Converting a claim from regular to maternity benefits while the client is referred under EIA 25 — Continuing claim

Source map: `en_EN/task/conv_regmat_eia25/conv_regmat_eia25.ditamap`

## Summary

Source topic: `en_EN/task/conv_regmat_eia25/summary.dita`

Summary: A client receiving regular benefits who reports that she is pregnant and provides an expected date of birth (DOB) or an actual DOB can request to have their claim converted to maternity benefits while also being referred under EIA 25. 

## What you need to know

Source topic: `en_EN/task/conv_regmat_eia25/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/conv_regmat_eia25/untitled_section.dita`

Maternity benefits are available to people who are pregnant or have given birth. Maternity benefits provide income support during a leave due to a pregnancy or childbirth and can be paid up to 12 weeks before the expected DOB.

A client who wants to receive parental benefits immediately after maternity benefits can apply for maternity and parental benefits at the same time. This allows the system to automatically convert the claim to parental benefits immediately after the maternity benefits are paid in full or the maternity end week is reached. If necessary, the system splits the last claimant’s report and continues to pay benefits without any interruption.

When maternity benefits are paid in full or the maternity end week is reached, the system automatically changes the sex code to 8 and displays both the exact parental start week and the parental end week.

If the client completes both forms at the same time but there is an interruption between the 2 types of benefits, ignore the date provided by the client and process the claims simultaneously. If the client requests to modify the start date of maternity benefits, before converting the claim, the officer must determine the impact a modification would have on the claim and communicates with the client to explain the impact on the claim. 

### Qualifying for maternity benefits

Source topic: `en_EN/task/conv_regmat_eia25/qualifying_for_maternity_benefits.dita`

Maternity benefits can be paid if one of the following conditions is met:

- The client is major attached (has accumulated at least 600 hours of insurable employment).
         [major attached](/en/procedure/generic/knowledge.shtml#Major_or_minor_attached_client)

- The BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2763.dita) 

**Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)**

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits, regardless of the conversion date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to maternity benefits

Source topic: `en_EN/task/conv_regmat_eia25/entitlement_to_maternity_benefits.dita`

To be entitled to maternity benefits, a client must meet both of the following conditions:

- The client must provide proof of the pregnancy.

- The client must request benefits during the maternity window. 

### Proof of pregnancy

Source topic: `en_EN/task/conv_regmat_eia25/proof_of_pregnancy.dita`

As proof of the pregnancy, the client must provide a signed statement attesting the pregnancy and the expected DOB. The attestation at the end of an EI application is accepted as a signed statement. A completed and signed Maternity and/or Parental Benefits - Annex 3 (INS5168) form is also accepted as proof of pregnancy. If the officer completes the INS5168 form with the client, a verbal attestation is not acceptable. The officer mails the INS5168 form to the client to sign and return. The client can also download the form and return it by mail or upload it in MSCA. When the client fills in the online form using an electronic signature, it is a signed statement. The client must also provide the actual DOB as soon as possible.
       [Maternity and/or Parental Benefits - Annex 3 (INS5168)](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5168.pdf) 
       [INS5168](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Maternity_Parental-INS5168_Annex_3_transcript-Form.doc) 

### Weeks of entitlement

Source topic: `en_EN/task/conv_regmat_eia25/weeks_of_entitlement.dita`

Up to 15 weeks of maternity benefits may be paid in a benefit period (BP). The 15 weeks payable for a single pregnancy may be paid over 2 BPs. A client does not have to collect maternity benefits successively. Payments of maternity benefits can alternate with the payment of another benefits type (BT). Once a claim has been established, a client may receive a combination of regular and special benefits within the BP. The maximum entitlement to benefits varies based on the BT received. The maximum number of weeks payable for each BT cannot be exceeded.
       [maximum entitlement to benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2653.dita) 

### Extending benefit period (BP)

Source topic: `en_EN/task/conv_regmat_eia25/extending_benefit_period_bp.dita`

Under certain conditions, the BP can be extended to allow clients more time to receive the benefits to which they are entitled. The BP can be extended for a maximum of 104 weeks to pay additional weeks of benefits when all of the conditions are met before the BP ends. For more information, the officer refers to Extension of the benefit period .
       [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Maternity window

Source topic: `en_EN/task/conv_regmat_eia25/maternity_window.dita`

The maternity window is defined as the period in which maternity benefits are payable. It starts on the earlier of the following dates:

- 12 weeks before the expected DOB (expected DOB – 12 weeks)

- the actual DOB.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2764.dita) 

The maternity window ends on the latter of the following dates:

- 17 weeks after the expected DOB (expected DOB + 17 weeks)

- 17 weeks after the actual DOB (actual DOB + 17 weeks).

To provide the client with the most advantageous maternity window, the actual DOB must be provided as soon as possible after the birth.

The expected or actual DOB can be used to determine the period during which maternity benefits are payable. The expected or actual DOB is input on the Renewal/Revised (M106) transaction at the same time as the data required to establish the maternity claim.

**Actual date of birth (DOB) provided**

If the client provides both the expected DOB and the actual DOB, the officer determines which date will provide the longest maternity window for the client and enters it in the Confinement field during the conversion.

**Extending the maternity window**

To allow the client more time to collect maternity benefits to which they are entitled, the maternity window can be extended by one week for each week that a newborn is hospitalized within that period. The maximum extension of the maternity window is 52 weeks after the actual DOB (actual DOB + 52 weeks). The number of weeks of maternity entitlement remains the same. The officer extends the maternity window by inputting an external maternity end week. The officer calculates the extended maternity window by adding the number of full or partial weeks of hospitalization to the initial maternity end week. 

### Termination of pregnancy

Source topic: `en_EN/task/conv_regmat_eia25/termination_of_pregnancy.dita`

If benefits are requested when a pregnancy is terminated within the first 19 weeks, the claim must be treated as a sickness claim. The officer must refer to Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim .
       [Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim](/en/procedure/task/conv_regsick_eia25.shtml)

If benefits are requested when a pregnancy is terminated after the nineteenth week, the claim must be treated as a maternity claim.

If clients requests maternity benefits before the start of the maternity window and states that they are not available for or actively seeking employment due to the pregnancy, the officer enters claim type (CT) 2 - Regular and inputs a 3 - Not Available disentitlement (D3) on the Renewal/Revised (M106) transaction. 

### Disentitlements

Source topic: `en_EN/task/conv_regmat_eia25/disentitlements.dita`

The following disentitlements related to maternity benefits are imposed when the client does not meet the entitlement conditions:

- A 25 - Maternity benefits - Minor attached disentitlement (D25) is imposed if the client has not accumulated at least 600 insurable hours.

- A 27 - Maternity benefits (maximum special benefits paid) or outside range disentitlement (D27) is imposed when a client requests maternity benefits but the maximum combination of regular and special benefits has already been paid or the request falls outside the maternity window.
         [maximum combination of regular and special benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

- A 36 - Maternity not eligible - 15 weeks paid per pregnancy disentitlement (D36) is imposed when a client requests maternity benefits and the maximum 15 weeks of maternity benefits have already been paid.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2756.dita) 

### Outstanding disentitlements

Source topic: `en_EN/task/conv_regmat_eia25/outstanding_disentitlements.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies to the conversion. A Level 1 officer can terminate or rescind the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . If the information on file allows for the disentitlement to be terminated, it is terminated on the Friday of the week before the conversion week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer reassigns the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Allocation of separation monies

Source topic: `en_EN/task/conv_regmat_eia25/allocation_of_separation_monies.dita`

If a client loses their employment after the start of the BP and receives separation monies, the officer allocates the separation monies.

For more information about allocating monies on separation, the officer refers to Allocating separation monies and Digest 5.12 — Moneys paid or payable by reason of a lay-off or separation .
       [Allocating separation monies and Digest 5.12 — Moneys paid or payable by reason of a lay-off or separation](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/moneys-paid-layoff-separation.html#a5_12_0) 

### Effective date of a conversion

Source topic: `en_EN/task/conv_regmat_eia25/effective_date_of_a_conversion.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer can refer to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Return to work (RTW)

Source topic: `en_EN/task/conv_regmat_eia25/return_to_work_rtw.dita`

If there is an RTW on the claim that is on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer reassigns the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### Processing claimant’s reports

Source topic: `en_EN/task/conv_regmat_eia25/processing_claimants_reports.dita`

Before the officer can input the conversion transactions, the last week of regular benefits must be paid. If claimant’s reports have not yet been processed for the regular benefits period, they must be processed before inputting the conversion. This requires a 2-day input. 

### Adjudicating new contentious issues

Source topic: `en_EN/task/conv_regmat_eia25/adjudicating_new_contentious_issues.dita`

When converting a continuing claim, a client may report a new contentious issue (e.g. reason for separation [RFS], farming or availability) that must be adjudicated. If there is no existing WI for this issue, the Level 1 officer creates a Claim Review (CR) WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision. If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated. 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/task/conv_regmat_eia25/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular . The officer manually updates this field by choosing the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For a conversion request on a continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an Action Item (AI), Call Back (CB), Assessment Issue (ASMT) or Reminder (REM) WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### ACS letters

Source topic: `en_EN/task/conv_regmat_eia25/acs_letters.dita`

Communication of the conversion decision is not necessary when the only transaction input is the conversion transaction. When another decision is input at the time of the conversion (disentitlement, disqualification or allocation of earnings), communication of the decision is necessary.

Written communication of the decision is usually done by officers who are responsible for sending the appropriate letter. 

### Client referred under EIA 25

Source topic: `en_EN/task/conv_regmat_eia25/client_referred_under_eia_25.dita`

Generally, it is assumed that clients who are receiving special benefits are on a leave of absence and would not be referred to training under EIA 25 as they have a job to return to. However, regardless of an individual’s attachment to the labour force, it is the referring authority’s decision to refer a client. If a referral is made for a client claiming special benefits, as long as the eligible client meets the entitlement conditions for the BT claimed, special benefits can be paid. The claim type must not be changed to regular benefits. However, the claim is processed in MPS.

If there is a D3 imposed on the claim because the client did not prove availability while attending a training course, and the client is referred to training under EIA 25, this disentitlement is terminated on the day before the training begins. If the client did not obtain approval before the training course start date, the D3 is terminated on the day before the approval date.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2765.dita) 

### Authorization to voluntarily leave employment for referred training

Source topic: `en_EN/task/conv_regmat_eia25/authorization_to_voluntarily_leave_empl_2a0344fd.dita`

If the client is referred to training by a designated authority before voluntarily leaving a job, the officer must follow the Adjudicating voluntary leaving (Level 1) — Course of instruction procedure to determine if the voluntary leaving is authorized. The voluntary leaving and the confirmation of the referred training are separate issues.
       [Adjudicating voluntary leaving (Level 1) — Course of instruction](/en/procedure/activity/voluntary_leaving.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2763.dita`

Note:

If a client has been found responsible for a violation for an earlier claim, an increased number of hours may be needed to qualify for maternity benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_2653.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_2764.dita`

Note:

Prior to December 3, 2017, the start date of the maternity window was 8 weeks before the expected DOB or the actual DOB. 

### Note

Source topic: `en_EN/common_notes/note_c_2756.dita`

Note:

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure. As a result, the officer does not impose a D25 on claims with a BPC between w/c 2310 and w/c 2361. 

### Note

Source topic: `en_EN/common_notes/note_c_2765.dita`

Note:

For more information and instructions on conversions to special benefits and referred training, refer to Confirming referred training: Conversion from regular to special benefits — Continuing claim .
       [Confirming referred training: Conversion from regular to special benefits — Continuing claim](/en/procedure/task/training_cc_rsb.shtml)

     [Confirming referred training: Conversion from regular to special benefits — Continuing claim](/en/procedure/task/training_cc_rsb.shtml) 

## Regional considerations

Source topic: `en_EN/task/conv_regmat_eia25/regional_considerations.dita`

**Quebec region**

Clients who live in Quebec and who request benefits due to a pregnancy, birth or adoption must apply to QPIP . The Quebec government pays these benefits to Quebec residents. In some cases, the Quebec government also pays QPIP benefits to a parent living outside of Quebec if both parents lived in Quebec when the initial claim for maternity or parental benefits for the birth or adoption of the same child was made. When a client applying for EI benefits lives in Quebec or indicates that the other parent is entitled to QPIP benefits, the officer on the specialized team that is responsible for liaising with QPIP determines whether the client is entitled to the requested EI benefits.
       [QPIP](/en/procedure/generic/additionalresources/qpip_knowledge.shtml)

When a client living in Quebec is entitled to receive QPIP benefits, an officer from the specialized QPIP team imposes an indefinite 57 - E.I.Maternity or Parental benefits denied, benefits are payable by the province disentitlement (D57). 

## What you need to look for

Source topic: `en_EN/task/conv_regmat_eia25/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/conv_regmat_eia25/in_nws.dita`

- Has the client worked since the last week paid?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies, workers’ compensation benefits (WCB), motor vehicle accident compensation or wage loss insurance (WLI) payments to consider or allocate?

- What is the expected DOB or the actual DOB?

- Is there information about referred training on file?

- Is there a completed electronic questionnaire? 

### In FTS:

Source topic: `en_EN/task/conv_regmat_eia25/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the last renewable week (LRW) been reached?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Is there an RTW on the claim?

- Are there any pending claimant’s reports or claimant’s reports to be processed before the conversion?

- Is there a registration number?

- Is there information about referred training on file?

- Has referred training information been input on the Project tab for the training period (codes 9, 35, 53, 95, 97 and 98)?

- Is the client exempt from completing claimant’s reports? 

### In RCM:

Source topic: `en_EN/task/conv_regmat_eia25/in_rcm.dita`

- Has an ROE been submitted?

- Are there earnings, separation monies, WCB, motor vehicle accident compensation or WLI payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/conv_regmat_eia25/in_imaging.dita`

- Is there proof of the pregnancy on file?

- What is the expected DOB or the actual DOB?

- Is there any referred training information from the client, the province or territory, or another designated authority?

- Is there any other documentation which may impact the conversion claim? 

## Step by step

Source topic: `en_EN/task/conv_regmat_eia25/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/conv_regmat_eia25/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/conv_regmat_eia25/reviewing_the_file_level_1.dita`

- Determine if the training information is on file:

- If no, refer to Confirming referred training — Conversion to special benefits on a continuing claim .
               [Confirming referred training — Conversion to special benefits on a continuing claim](/en/procedure/task/training_cc_rsb.shtml)

- If yes, go to step 2.

- Determine if one of the following situations applies:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2766.dita) 

- If no, go to step 3.

- If yes, go to Reassigning the WI .
               [Reassigning the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regmat_eia25#level1_item_8)

- In FTS, determine if a registration number related to the conversion is on file:

- If yes, go to step 4.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Go to step 4.

- Determine if the pregnancy was terminated within the first 19 weeks:

- If yes, the client may be entitled to sickness benefits. Refer to Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim .
               [Converting a claim from regular to sickness benefits while the client is referred under EIA 25 — Continuing claim](/en/procedure/task/conv_regsick_eia25.shtml)

- If no , go to step 5.

- In FTS, determine if the maximum combination of regular and special benefits has been paid:

- If yes, go to Maximum combination of regular and special benefits paid .
               [Maximum combination of regular and special benefits paid](/en/procedure/generic/additionalresources/max_ent_ben.shtml)

- If no, determine if 15 weeks of maternity benefits have been paid:

- If no, go to step 6.

- If yes, go to Maximum maternity benefits paid .
                   [Maximum maternity benefits paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regmat_eia25#maxsick)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- In FTS, on the Rate/Duration tab, determine if the client is minor attached:

- If the BPC is between w/c 2310 to w/c 2361 and the Major Attached box is checked, go to step 7.

- If the client has 600 hours or more , or the Major Attached box is checked, go to step 7.

- If the client has fewer than 600 hours and the Major Attached box is not checked, go to Minor attached .
               [Minor attached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regmat_eia25#minorattached)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2757.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2758.dita)

- Determine if the client reports having received monies and whether they have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings and go to step 8.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 8.

- If no monies were received, go to step 8.

- In NWS and in FTS, determine if one of the following conditions to extend the BP is met

- The client was incarcerated and has since been tried and has not been found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- If one of the conditions is met, refer to Extension of the benefit period and go to step 9.
               [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions is met, go to step 9.

- Based on the Claim duration section of the Rate/Duration tab in FTS, determine if one of the following conditions is met:

- The client is requesting benefits before the end of the week displayed in the Latest renewable week field.

- The client is requesting special benefits before the end of the week displayed in the End of the initial benefit period field.

- The client is requesting special benefits after the end of the week displayed in the End of the initial benefit period field, but is entitled to an automatic extension of the BP and is requesting special benefits before the end of the extended BP.

- If any condition is met, go to step 10.

- If none of the conditions is met, go to Last renewable week (LRW) has been reached .
                   [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regmat_eia25#lrw)

               [extension of the BP](/en/procedure/activity/extension_benefit_period.shtml)

- Determine if, on the initial EI application for benefits, the client indicated when maternity benefits should start or if there is a signed Maternity or parental: INS5168 Annex 3 — Form on file:

- If no, go to step 11.

- If yes, go to step 17.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2755.dita) 

#### Determining the expected or actual date of birth (DOB)

Source topic: `en_EN/task/conv_regmat_eia25/determining_the_expected_or_actual_date_d738715e_level_1.dita`

- Fact-find with the client to determine the expected or actual DOB using the INS5168 form. Mail a copy of the INS5168 form for the client to sign and return. The client can also download the form and return it by mail or upload it in MSCA. Refer to the National Fact-Finding and Documentation Policy if needed.

- Determine if the client was reached during fact-finding or if the client responded to the N-10-00-00 letter:

- If the client was reached, go to step 13.

- If the client was not reached or did or did not reply to the N-10-00-00 letter, go to step 14.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Conversion .

- Comments: Type “Conversation with the client — [INS5168 form information].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client was asked to provide the INS5168 form:

- If the INS5168 form was requested but is not on file, go to step 26.

- If the INS5168 form was requested and is on file, go to step 28.

- If the client was not reached and the INS5168 form is not on file, go to INS5168 form not provided .
               [INS5168 form not provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regmat_eia25#annex3)

- If the client was not reached and the INS5168 form is on file, go to step 28.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact-Finding client .

- Comments: Type “Awaiting the INS5168 form.”

- Bring forward date: Enter the current date + 10 business days.

- When the WI moves to the current workload, determine if the INS5168 form3 is on file :

- If no, go to INS5168 form not provided .
               [INS5168 form not provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regmat_eia25#annex3)

- If yes, go to step 17. 

#### Reviewing existing disentitlements

Source topic: `en_EN/task/conv_regmat_eia25/reviewing_existing_disentitlements_level_1.dita`

- Determine if a D3 has been imposed as a result of the client not being available while attending a course of instruction:

- If no, go to step 18.

- If yes, note that the D3 must be terminated on the day before the referred training begins and go to step 18.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2767.dita)

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 19.

- If no, go to step 21.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, go to step 20.

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 21.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine the CT:

- If it is a conversion on a continuing claim, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 21.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If it is a conversion on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Next Available User .

- Issue: Select Availability .

- Details: Type “Outstanding D15 for a missed client information session, Level 2 review required.”

- Select Save .

- Go to step 21.

- Determine if there are any other outstanding disentitlements on file:

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue: Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 22.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue: Select the appropriate option.

- Details: Type “Outstanding [type of disentitlement] disentitlement.”

- Select Save .

- Refer to the appropriate procedure and go to step 22.

- If no, go to step 23.

- Determine if the conditions are met to terminate or rescind the disentitlement at Level 1 according to the National Policy on Levels of Decision :

- If yes, terminate or rescind the disentitlement and go to step 23.

- If no, create a client Note and type “Outstanding [type of disentitlement] disentitlement on file for review by Level 2.” Go to step 23.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita) 

#### Reviewing outstanding issues

Source topic: `en_EN/task/conv_regmat_eia25/reviewing_outstanding_issues_level_1.dita`

- Determine if there are any outstanding issues that require adjudication that do not have a related WI:

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue(s): Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 24.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Details: Indicate the reason the WI is being created.

- Select Save .

- Refer to the appropriate procedure and go to step 24.

- If no, go to step 25.

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If no, reassign the WI to Level 2 and go to step 25.

- If yes, complete the steps from the appropriate procedure and go to step 25.

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine if the conversion week is during the maternity window:

- If yes, go to step 27.

- If no , go to Outside of the maternity window .
               [Outside of the maternity window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regmat_eia25#outsidematwindow)

- In FTS, determine if there is a pending electronic claimant’s report on the E-Report tab for the period before the conversion:

- If there is no pending electronic claimant’s report, go to step 28.

- If there is a pending electronic claimant’s report for the period, refer to Actioning a pending claimant’s report and go to step 28.
               [Actioning a pending claimant’s report](/en/procedure/task/pending_cr.shtml)

- Determine if there are any rejected electronic claimant’s reports on the Pending/Reject tab for the period before the conversion:

- If no, go to step 29.

- If yes, re-input the claimant’s reports. Refer to Actioning a rejected claimant’s report and go to step 29.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml) 

#### Updating training information

Source topic: `en_EN/task/conv_regmat_eia25/updating_training_information_level_1.dita`

- Determine if the referred training information is displayed on the Project tab:

- If the referred training information is displayed on the Project tab, go to step 30.

- If the referred training information is not displayed on the Project tab, go to step 32.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 36 - Special benefits on Fishing claims or other complex claim conditions .

- Remarks Line 1: Type “EIA 25 — Special benefits.”

- Remarks Line 2: Type “REN WK [XXXX], EXT-MSW [XXXX], EXT-MEW [XXXX], CNF WK [XXXX].”

- Remarks Line 3: If applicable, type “[NO-CR], [claimant’s report information], [MA rescind information], [D3 termination information.]”

- Remarks Line 4: Enter the appropriate information.

- Remarks Line 5: Enter your first name and last name.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 34.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 36 - Special benefits on Fishing claims or other complex claim conditions .

- Remarks Line 1: Type “EIA 25 — Special benefits.”

- Remarks Line 2: Type “REN WK [XXXX], EXT-MSW [XXXX], EXT-MEW [XXXX], CNF WK [XXXX].”

- Remarks Line 3: If applicable, type “[NO-CR], [claimant’s report information], [MA rescind information], or [D3 termination information].”

- Remarks Line 4: Type “T171 — STRT-WK/DY [the course start w/c], END-WK-DY [the course end w/c], PROJ-HRRC [the Responsibility Centre code or institution code, if applicable], PROJ-NO [the 10-digit agreement number; use preceding zeros if the number is less than 10 digits], TRAIN-ID [the training ID code], BREAK START/END WK [the w/c code, of any break weeks].”

- Remarks Line 5: Enter your first name and last name.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction to transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update . 

#### Communication

Source topic: `en_EN/task/conv_regmat_eia25/communication_level_1.dita`

- Determine if there are decisions that must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement is being imposed.

- If there are decisions that must be communicated to the client, go to step 36.

- If there are no decisions that must be communicated to the client, go to step 37.

- In ACS, create and save or add to the saved N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Select Antedate denied or postdate Message - Initial/Renewal/Continuing claim (2481) .

- Select Antedate denied (2483) .

- Special benefits approved (3046): Select Maternity and/or parental benefits (standard/extended) approved or denied with sickness options (3054) .

- If there is an allocation: Select Allocation of Earnings (2516):

- Waiting period messages (2445): Select the appropriate option.

- Complete a report – General message or for sickness benefits (3091) .

- Determine if Level 2 adjudication is required:

- If yes, in NWS, create a client Note and type “Send the N-00-00-00 letter” and go to step 38.

- If no, send the saved N-00-00-00 letter and go to step 39.

- In NWS, reassign any CR WI for the contentious issue to Level 2 as follows:

- Destination — SCC: Select the SCC as shown in FTS.

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Not within Level 1 authority.”

- Go to step 39.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- In NWS, complete the Conversion WI. 

#### Maximum combination of regular and special benefits already paid

Source topic: `en_EN/task/conv_regmat_eia25/maximum_combination_of_regular_and_spec_5cf2309f_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for maternity and parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a record of decision (ROD) as follows:

- Comments : Type “D27 imposed — maximum combination of benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum combination of weeks of regular and special benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC. D27 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum combination of weeks of regular and special benefits. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. D27 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D27 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim Type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 27 - Maternity benefits (maximum special benefits paid) or outside range .

- Start: Select the Monday of the week in which the client wants maternity benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all the required attributes, including the following:

- Special benefits denied (3065): Select Maternity benefits denied: D25/D27/D36/Free text (3070) .

- Text - Explain why maternity benefits are not payable .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Text - Insert appropriate reason(s) (1618): Type “you have received the maximum number of benefit weeks payable to you during this benefit period. The maximum number of benefit weeks paid on this claim cannot exceed a total of [maximum number of regular and special benefit weeks that can be paid] weeks. To receive benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you must apply for a new claim.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Maximum maternity benefits already paid

Source topic: `en_EN/task/conv_regmat_eia25/maximum_maternity_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for maternity and parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D36 imposed. Not eligible to maternity benefits — 15 weeks of maternity benefits have already been paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum amount of maternity benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC. D36 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum amount of maternity benefits. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. D36 imposed.”

- Select the Renewal/Revised (M106) transaction and impose the D36 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the Sunday of the week the client wants maternity benefits to start being paid.

- Action: Select Add .

- Disentitlement: Select 36 - Maternity Benefits not eligible - 15 weeks paid per pregnancy .

- Start: Enter the Monday of the week the client wants maternity benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Maternity benefits denied: D25/D27/D36/Free text (3070) .

- Select D36 - Max 15 weeks paid per pregnancy or per claim - Fails to prove pregnancy (3073) .

- Select D36 - Max 15 weeks maternity already paid on this claim .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Client is minor attached

Source topic: `en_EN/task/conv_regmat_eia25/client_is_minor_attached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no , go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for maternity and parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D25 imposed. Maternity benefits — minor attached.”

- Details: Type “The client is not entitled to maternity benefits. D25 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction and impose the D25 as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the Sunday of the week the client wants maternity benefits to start being paid.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 25 - Maternity Benefits - Minor Attached .

- Start: Enter the Monday of the week the client wants maternity benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Maternity benefits denied: D25/D27/D36/Free text (3070) .

- Select D25 - Does not qualify – Not enough hours or earnings (3071) .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select Indefinite disentitlement dates and enter the start date.

- Enter the Number of insurable employment hours accumulated (1366) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/conv_regmat_eia25/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for maternity and parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “Last renewable week reached — maternity benefits requested.”

- Details: Type the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as no hours were accumulated after the BPC.”

- If the client has worked since the BPC , type “No conversion is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as [hours] were accumulated after the BPC. The client needed [hours] to qualify.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612): Type “We cannot reactivate your claim for Employment Insurance benefits starting (Renewal week - Sunday’s date . Please note that we are required to advise you of all decisions made on your claim. No maternity benefits are payable to you on this claim because the last renewable week has been reached on this benefit period. To receive maternity benefits, you must work the required minimum number of insurable employment hours. If you want to receive maternity benefits in the future, you must apply for a new claim.”

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- In NWS, complete the WI. 

#### INS5168 form not provided

Source topic: `en_EN/task/conv_regmat_eia25/ins5168_form_not_provided_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Awaiting Annex 3 — D15 from w/c [XXXX-X] to [9999-9].”

- Details: Type “The client was advised to provide the Annex 3 form. As of today, it still has not been provided. Indefinite D15 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction and impose the 15 - Claim procedure disentitlement (D15) as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the Sunday of the week the client wants maternity benefits to start being paid.

- Earnings week 1: Enter the amount (if applicable).

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 15 - Claim procedure .

- Start: Enter the Monday of the week in which the client wants the maternity benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Determine if the referred training information is displayed on the Project tab:

- If no , go to step 4.

- If yes, go to step 5.

- Select the Project Data - Training (M171, M107) transaction and enter the following training information as indicated on the referred training documentation or as instructed by your business expertise advisor:

- Start date: Enter the course start week.

- End date: Enter the course end week.

- Project SCC: Enter the appropriate code.

- Project number: Enter the agreement number with preceding zeroes so that there is a total of 10 numeric digits (e.g. agreement number 123456 must be entered as 0000123456).

- Training identification: Select the appropriate code (9, 35, 53, 95, 97 or 98).

- Break Period: Enter the start and end dates, if provided by the referring authority.

- Institution code: Enter the appropriate code.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Maternity benefits denied: D25/D27/D36/Free text (3070) .

- Select D36 - Max 15 weeks paid per pregnancy or per claim - Fails to prove pregnancy (3073) .

- Select D36 - Fails to prove pregnancy .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Select Indefinite disentitlement dates and enter the start date.

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Benefits requested outside of the maternity window

Source topic: `en_EN/task/conv_regmat_eia25/benefits_requested_outside_of_the_mater_214d8489_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Maternity benefits outside of the maternity window.”

- Details: Type “The client wants maternity benefits to start outside of the maternity window. No conversion.”

- In FTS, select the Renewal/Revised (M106) transaction and impose the D27 as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Enter the Monday of the week the client wants maternity benefits to start being paid.

- Earnings week 1: Enter the amount (if applicable).

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 27 - Maternity benefits (maximum special benefits paid) or outside range .

- Start: Enter the Monday of the week in which the client wants maternity benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

- Determine if the referred training information is displayed on the Project tab:

- If no, go to step 4.

- If yes, go to step 5.

- Select the Project Data - Training (M171, M107) transaction and enter the following training information as indicated on the referred training documentation or as instructed by your business expertise advisor:

- Start date: Enter the course start week.

- End date: Enter the course end week.

- Project SCC: Enter the appropriate code.

- Project number: Enter the agreement number with preceding zeroes so that there is a total of 10 numeric digits (e.g. agreement number 123456 must be entered as 0000123456).

- Training identification: Select the appropriate code (9, 35, 53, 95, 97 or 98).

- Break Period: Enter the start and end dates, if provided by the referring authority.

- Institution code: Enter the appropriate code.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065):

- Select Maternity benefits denied: D25/D27/D36/Free text (3070) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Reassigning the WI

Source topic: `en_EN/task/conv_regmat_eia25/reassigning_the_wi.dita`

- In NWS, reassign the WI related to the conversion and the following related WIs, if necessary (CB, AI and REM), as follows:

- Destination: Select Level 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC/QPIP .

- Reason: Select Unable to complete .

- Details: Type “Decision required to determine whether EI or QPIP applies.”

- Select OK .

- No further action is required. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2766.dita`

- In FTS, the client’s residential address is in Quebec and no EI maternity benefits have been paid for the same BPC.

- The client indicated on the EI application, on the Maternity or parental: INS5168 Annex 3 — Form or in the details on file one of the following:

- She received QPIP benefits in the last 2 years or will receive QPIP benefits.

- The other parent has received, is receiving or will receive QPIP benefits.

         [Maternity or parental: INS5168 Annex 3 — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5168.pdf) 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Note

Source topic: `en_EN/common_notes/note_c_2757.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, 420 hours of insurable employment is required to establish a claim for regular or special benefits, regardless of the conversion date. If the client has 420 or more insurable hours, select the major attached option. 

#### Note

Source topic: `en_EN/common_notes/note_c_2758.dita`

Note:

The system codes claims with a BPC from September 27, 2020 to September 19, 2021 that received a credit of 300 insurable hours as major attached. This means that clients transitioning from the EI Emergency Response Benefit (EI ERB) who have fewer than 600 hours may also qualify for special benefits. 

#### Note

Source topic: `en_EN/common_notes/note_c_2755.dita`

Note:

When maternity benefits are requested, if an RFS indicated on the related ROE or declared by the client in the EI application is P - Parental , additional fact-finding is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2767.dita`

Note:

If the client did not obtain approval before the training course start date, the D3 is terminated on the day before the approval date. 

#### Note

Source topic: `en_EN/common_notes/note_c_2721.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose an MA1 to stop payment. 

## Policy reference

Source topic: `en_EN/task/conv_regmat_eia25/policy_reference.dita`

- BE 2015-05—Section 25 training while in receipt of Special Benefits
         [BE 2015-05—Section 25 training while in receipt of Special Benefits](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2015-05.shtml)

- EIA 22(1)
         [EIA 22(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-22.html) 
