# Adjudicating voluntary leaving (Level 1): Referred training or employment activity — Initial claim

Source map: `en_EN/task/vl_course_ic/vl_course_ic.ditamap`

## Summary

Source topic: `en_EN/task/vl_course_ic/summary.dita`

Summary: When clients voluntarily leave employment to attend referred training or an employment activity, their entitlement to regular benefits on an initial claim may be affected. Adjudication is required to determine if there is just cause for leaving the employment. 

## What you need to know

Source topic: `en_EN/task/vl_course_ic/what_you_need_to_know.dita`

### Adjudicating voluntary leaving to attend referred training or an employment activity

Source topic: `en_EN/task/vl_course_ic/adjudicating_voluntary_leaving_to_atten_8b0bb5f9.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4922.dita) 

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave the employment. If it is determined that the client left the employment without just cause, a disqualification is imposed on the claim for regular benefits, unless there are enough insurable hours since the voluntary leaving to establish a new claim. In this case, the ROE with the voluntary leaving is excluded from the calculation of the claim.

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is only required on the most recent ROE in the QP, if the RFS is contentious. In addition, the common entrance requirement of 420 hours of insurable employment is not used to determine if the client requalifies after a disqualifying event. Instead, the client needs to have worked at least one hour in insurable employment since the disqualifying event and to have filed an EI application.

If the RFS since the disqualifying event on claims with a BPC between w/c 2310 and w/c 2361 is either non-contentious or is adjudicated and allowed, the officer can establish a new claim without a disqualification using the hours from all the ROEs in the QP.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0164.dita) 

A designated authority may authorize clients to leave their employment in order to attend referred training or an employment activity under EIA 25 . In that situation, clients have just cause for leaving their employment, provided they do so in the 2 weeks before the start of the program.
       [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

To confirm that the client has been authorized to leave the employment, the designated authority gives the client an official document sometimes referred to as an authorization to quit or a counsel to leave employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4923.dita) 

### Authorization to quit employment

Source topic: `en_EN/task/vl_course_ic/authorization_to_quit_employment.dita`

Each region has specific procedures in place for submitting the document authorizing the client to quit their employment. In some regions, the client is responsible for submitting a copy to Service Canada. In other regions, the designated authority submits it directly to Service Canada.

When the information is not on file, the officer fact-finds to complete the WI related to the voluntary leaving. When clients state that they have been authorized to quit, but a copy of the authorization is not on file, the officer advises the clients to ask the designated authority to provide it. If the authorization is not submitted, the officer adjudicates the voluntary leaving based on the information on file.

Agreements with the provinces, territories and indigenous groups exist for implementing programs that are similar to Service Canada’s employment programs. These include:

- Labour Market Development Agreements for training-related employment measures managed by the provinces and territories.

- Indigenous Skills and Employment Training Program for training-related employment measures managed by various indigenous groups for indigenous individuals.

Sometimes an unemployed client is referred to training that starts at a future date and the client becomes employed before the training begins. If the client leaves this employment to attend the training, the issue is referred to Level 2 since the voluntary leaving has not been recommended or approved by the designated authority. 

### ROE

Source topic: `en_EN/task/vl_course_ic/roe.dita`

An ROE is not required to adjudicate voluntary leaving.

In NWS, there may be a New ROE message displayed on the ADJ WI for the voluntary leaving issue. The message indicates that a new ROE has been received with a RFS that must be reviewed. The ROE may match the period of employment for that or another outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4924.dita) 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/vl_course_ic/determining_if_the_file_must_be_referre_f4ff817e.dita`

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Automated adjudication

Source topic: `en_EN/task/vl_course_ic/automated_adjudication.dita`

ACP does not automate a decision for voluntary leaving to attend referred training or an employment activity.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3239.dita) 

### Levels of decision

Source topic: `en_EN/task/vl_course_ic/levels_of_decision.dita`

The Level 1 officer may adjudicate and allow benefits when the client’s reason for voluntarily leaving employment is to attend referred training or an employment activity and all of the following conditions are met:

- the client was referred by an authority designated by the Commission prior to the voluntary leave;

- the voluntary leave was approved by the designated authority;

- the referred training or employment activity started within 2 weeks of the date of the voluntary leave

- the BPC or renewal week is equal to or after the week of voluntary leaving.

When the Level 1 officer cannot adjudicate the issue, the facts are documented and the voluntary leaving is referred to Level 2 for adjudication. 

### Claim action status and processing the claim

Source topic: `en_EN/task/vl_course_ic/claim_action_status_and_processing_the_claim.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can process the claim. There is Resolve Issue tab for ADJ Voluntary leaving WIs has a Resolve Issue tab which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a ROD based on the Resolve Issue screens. Before the claim is calculated, the system updates the ROE based on the Resolve Issue screens. No letter is sent when the client is allowed to voluntarily leave an employment to attend an approved course of instruction. 

### Previously adjudicated voluntary leaving

Source topic: `en_EN/task/vl_course_ic/previously_adjudicated_voluntary_leaving.dita`

In some cases, the ADJ WI may be for a voluntary leaving issue that was previously adjudicated. The officer indicates on the Resolve Issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the appropriate special condition based on the previous decision. The system updates the ROE when the ADJ WI is completed. 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/vl_course_ic/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the voluntary leaving is not required if the employment is not insurable either because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, the ADJ WI must not be completed. The officer follows the procedures and conditions for removal of claims from ACP process . The officer moves the ADJ WI to Pending until the Claim Assessment (CA) or Specialized Application (SA) WI is created. An authorized user must then delete the ADJ WI.
       [procedures and conditions for removal of claims from ACP process](https://esdc.prv/en/service-canada/ei/technologies/acp/index.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4925.dita) 

### Reason for separation (RFS) — Temporary Budget measures

Source topic: `en_EN/task/vl_course_ic/reason_for_separation_rfs__temporary_bu_7d536726.dita`

**Adjudicating the last employment in the qualifying period (QP) — BPCs between w/c 2310 and w/c 2361**

Budget 2021 has introduced a temporary simplification measure starting September 26, 2021. For claims with a BPC between w/c 2310 and w/c 2361, the officer will only adjudicate the last period of employment in the QP if it is contentious. If the officer allows the last RFS, all other ROEs in the QP, even if they are contentious, are used to calculate the claim. If, however, the officer does not allow the RFS on the last ROE in the QP, the claim is calculated with a disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 

This new measure does not apply to fishing claims and claims from self-employed people. Instead, if clients have insurable employment in the QP with a contentious RFS and a BPC between w/c 2310 and w/c 2361 when they apply for self-employment (SE) or fishing benefits, the officer must adjudicate the contentious RFS following normal adjudication procedures.

When the client declares other employers with a contentious RFS on the same application, if ACP does not allow the issue under auto-adjudication rules, the issue is automatically resolved and ACP creates a record of decision (ROD) that shows Adjudication not Required . The Special condition field on the ROE is not updated, and the ROE is included in the calculation. An Adjudication Issue (ADJ) WI is not created for the RFS.

ACP does not always automatically create an ADJ WI when the application is received. However, if an ROE with a contentious RFS is received during the automation process, ACP may create an ADJ WI or ROE Issue (ROE) RFS Action WI.

When there is more than one ROE with the same last day paid (LDP), and one of the ROEs is contentious while the other ROE is not, adjudication is not required and both ROEs are included in the calculation.

     [Example 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4926.dita) 
     [Example 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4927.dita) 

### Adjudication not required — Reason for separation (RFS) beyond 12 weeks – BPCs between w/c 2258 and w/c 2309

Source topic: `en_EN/task/vl_course_ic/adjudication_not_required__reason_for_s_16642296.dita`

Adjudication principles on initial claims or recalculations with a BPC between w/c 2258 and w/c 2309 only apply to the RFS on the last employment in the QP and to contentious RFS issues that fall in the 12-week period before the I of E used to establish the claim.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3263.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4922.dita`

Note:

If the adjudication of the voluntary leaving is part of a recalculation, the officer must refer to Adjudicating voluntary leaving (Level 1): Course of instruction — Continuing claim.
       [Adjudicating voluntary leaving (Level 1): Course of instruction — Continuing claim.](/en/procedure/task/voluntary_leaving_course_l1.shtml)

     [Adjudicating voluntary leaving (Level 1): Course of instruction — Continuing claim.](/en/procedure/task/voluntary_leaving_course_l1.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0164.dita`

Note:

For claims with BPCs between w/c 2310 and w/c 2361 excluded ROEs only apply to SE benefits and fishing claims. 

### Note

Source topic: `en_EN/common_notes/note_c_4923.dita`

Note:

In exceptional cases, a Level 2 officer can consider a longer period of up to 4 weeks as just cause if the client provides a reasonable and credible explanation for leaving employment early (e.g. relocating to attend school). 

### Note

Source topic: `en_EN/common_notes/note_c_4924.dita`

Note:

The client may report voluntary leaving on the EI application but the ROE indicates a non-contentious RFS. In this situation, fact-finding is required. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the WI is completed indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_3239.dita`

Note:

If a claim is between w/c 2310 and w/c 2361 and all ROEs are on file, ACP may automatically resolve ADJ RFS WIs for periods of employment other than the last. 

### Note

Source topic: `en_EN/common_notes/note_c_4925.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Example 1

Source topic: `en_EN/common_notes/note_c_4926.dita`

Example 1:

Peter’s LDP was September 28, 2021 (w/c 2310) with 2 employers. Three periods of employment are provided on his EI application. Peter declared Employer 1 as his last employer and the RFS is shortage of work. In the Other Employers section of the application, Peter declared Employer 2 and the RFS is Voluntary leaving. He also declared Employer 3 and the RFS is dismissal. The interruption of earnings (I of E) is in w/c 2310, and he applied for benefits on September 29, 2021. His BPC is September 26, 2021 (w/c 2310).

There are 2 contentious ROEs on Peter’s file:

- Employer 1: The LDP is September 28, 2021 (w/c 2309). The RFS is A .

- Employer 2: The LDP is September 28, 2021 (w/c 2309). The RFS is E .

- Employer 3: The LDP is May 19, 2021 (w/c 2291). The RFS is M .

Employer 1 and Employer 2 have the same LDP. The RFS with Employer 1 is a non-contentious, so adjudication is not required for Employer 2. ACP automatically resolves the RFS for Employer 2 and creates a ROD that shows Adjudication not required .

The RFS with Employer 3 is a contentious and is in the QP. However, because it is not the last employer in the QP, adjudication is not required. ACP creates a ROD that shows Adjudication not required .

All ROEs are included in the calculation of the claim. 

### Example 2

Source topic: `en_EN/common_notes/note_c_4927.dita`

Example 2:

Abdul’s LDP was September 24, 2021 (w/c 2309) with both of his employers. He declared Employer 1 as his last employer and the RFS is voluntary leaving. In the Other Employers section of the application, Abdul declared Employer 2 and the RFS is dismissal. The I of E is in w/c 2309, and he applied for benefits on September 26, 2021. His BPC is September 26, 2021 (w/c 2310).

- Employer 1: The LDP is September 24, 2021 (w/c 2309). The RFS is E .

- Employer 2: The LDP is September 24, 2021 (w/c 2309). The RFS is M .

Employer 1 and 2 have the same LDP and the RFS with both employers are contentious. ACP creates an ADJ WI for Employer 1, automatically resolves the RFS issue for Employer 2 and creates a ROD that shows Adjudication not required . If the leave of absence with Employer 1 is not allowed, the RFS with Employer 2 must be adjudicated. 

### Example

Source topic: `en_EN/common_notes/note_c_3263.dita`

Example:

Mary’s LDP was September 25, 2020 (w/c 2257). Her I of E is in w/c 2257, she submitted her EI application on September 26, 2020, and her BPC will be September 27, 2020 (w/c 2258).

There are 3 contentious ROEs on Mary’s file:

ROE 1: LDP September 25, 2020 (w/c 2257).

ROE 2: LDP July 17, 2020 (w/c 2247).

ROE 3: LDP May 31, 2020 (w/c 2241).

To determine which RFS to adjudicate, the officer subtracts 12 weeks from w/c 2257 (week of the I of E). For the example above, the formula is as follows: w/c 2257 (I of E) – 12 = w/c 2245. This determines a 12-week period falling before the Sunday of the I of E that encompasses the weeks from w/c 2245 to w/c 2256. The officer follows normal procedures and adjudicates ROE 1, which is the most recent ROE in the QP, and ROE 2, as it falls between w/c 2245 and w/c 2256, the 12-week period.

The officer allows any contentious RFS that occurs before the 12-week period. ROE 3 is before the 12-week period, so the officer allows the RFS by following the steps of Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
       [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#beyond_12_wks)

     [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#beyond_12_wks) 

## Regional considerations

Source topic: `en_EN/task/vl_course_ic/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/vl_course_ic/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/vl_course_ic/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a prior application?

- What is the client’s statement in the Voluntary Leave section of this or a prior application?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the voluntary leaving on this or a prior application?

- Is the appropriate ROE linked to the period of employment for the voluntary leaving issue? 

### In Imaging:

Source topic: `en_EN/task/vl_course_ic/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving? (Documents may have been received before the most recent application.) 

### In RCM:

Source topic: `en_EN/task/vl_course_ic/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving? 

## Step by step

Source topic: `en_EN/task/vl_course_ic/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/vl_course_ic/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/vl_course_ic/reviewing_the_file_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, determine if the appropriate ROE is linked to the period of employment:

- If yes, go to step 2.

- If no, select the appropriate ROE in the list and select Save to create a link.

- If the ROE is not on file, go to step 2.

- Determine if there is a ROD for the voluntary leaving issue on file:

- If there is a ROD for the voluntary leaving issue, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#DecisionOnFile)

- If there is no ROD for the voluntary leaving issue, go to step 3.

- Determine if the voluntary leaving occurred before the QP:

- If no, go to step 4.

- If yes, go to Reason for separation (RFS) occurred before the qualifying period (QP) .
               [Reason for separation (RFS) occurred before the qualifying period (QP)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#RFSB4QP)

- In FTS, determine if the BPC falls in a period where special measures apply:

- If the BPC is between w/c 2258 and w/c 2309, go to step 5.

- If the BPC is between w/c 2310 and w/c 2360, go to step 7.

- If the BPC is not in either of the periods, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita)

- Determine if the voluntary leaving occurred on the most recent ROE:

- If no, go to step 6.

- If yes, go to step 9.

- Determine if the voluntary leaving occurred within the 12-week period before the I of E:

- If yes, go to step 9.

- If no, go to Adjudication not required — Reason for separation (RFS) beyond 12 weeks .
               [Adjudication not required — Reason for separation (RFS) beyond 12 weeks](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#beyond_12_wks)

- Determine if the claim is for SE benefits or Fishing:

- If no, go to step 8.

- If yes, go to step 9.

- Determine if the voluntary leaving occurred on the most recent ROE:

- If yes, go to step 9.

- If no, go to Adjudication not required – Budget 2021 Simplification measures.
               [Adjudication not required – Budget 2021 Simplification measures.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#adj_not_required_budget_2021)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 10.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if the employment is not insurable because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 12.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if there is enough information to adjudicate the voluntary leaving based on the National Policy on Levels of Decision:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4928.dita) 

- If no, go to step 13.

- If yes, go to step 20.

- If the information on file shows that the client was not referred, Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#reassigntol2) 

#### Fact-finding

Source topic: `en_EN/task/vl_course_ic/fact-finding_level_1.dita`

- Fact-find with the client to obtain the required information.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4929.dita)

- Determine if the client was reached during fact-finding, or if the client responded to the N-10-00-00 letter:

- If the client was reached, go to step 15.

- If the client was not reached or did not reply to the N-10-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#reassigntol2)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Voluntary leaving — [employer’s name] — [LDW] — client.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client was reminded during fact-finding to submit the missing document that provides the authorization to quit employment.

- If yes, go to step 17.

- If no, go to step 19.

- In NWS, move the WI related to the missing document that provides the authorization to quit employment to Pending as follows:

- Pending reason: Select Fact finding client .

- Bring forward date : Enter the date of the most recent contact + 10 business days.

- When the WI moves to the current workload, determine if the document that provides the authorization to quit employment is on file:

- If yes, go to step 19.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#reassigntol2)

- Determine if the information on file shows that a designated authority authorized the client to quit the employment to participate in an employment activity.

- If yes, go to step 20.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#reassigntol2) 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/vl_course_ic/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the RFS is contentious:

- If the RFS is voluntary leaving go to step 21.

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS) .
               [Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#RFSVL)

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if the conditions are met to adjudicate the issue at Level 1 by referring to the appropriate situation below.

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4930.dita) 

- If all the conditions are met, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#RFSallowed)

- If any of the conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vl_course_ic#reassigntol2) 

#### Adjudication not required – Budget 2021 Simplification measures

Source topic: `en_EN/task/vl_course_ic/adjudication_not_required__budget_2021__620824ac_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Resolve issue: Select Adjudication not required – Budget 2021 EI Simplification Measures .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/vl_course_ic/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Select To attend a course of instruction .

- Verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/vl_course_ic/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [LDW] — adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed people). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Determine the Claim action status:

- If the status is Initial — In Progress (Automation) , go to step 3.

- If the status is Initial — In Progress (Manual) , go to step 6.

- In NWS, create a Reminder WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Other .

- Comments: Type “ACP.”

- Due date: Enter today’s date.

- Language: Select the appropriate option.

- Details: Type “2” and “Processing — [unallocated or user name to whom the CA or SA WI is to be assigned].”

- Destination: Select Level and Canada .

- End User: Select Specific user . Type “SV-ADMIN, ACP-TAD” and select Find User .

- Select Save .

- Move the ADJ WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting removal of claim from automation process. Employment not insurable. This WI must be deleted once CA or SA WI is created.”

- Bring forward date: Enter today’s date + 2 business days.

- Select OK .

- When the ADJ WI moves to the current workload, confirm that the Claim action status is Initial — In Progress (Manual) and a CA or SA WI was created.

- Contact an authorized user (team leader or Business Expertise Advisor) to delete the ADJ WI. 

#### Adjudication not required — Reason for separation (RFS) beyond 12 weeks

Source topic: `en_EN/task/vl_course_ic/adjudication_not_required__reason_for_s_d81cc200_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [LDW] — adjudication not required.”

- Details: Type “Post-Employment Insurance Emergency Response Benefit transitional measure — reason for separation beyond 12 weeks. EIA 153.194.”

- Select Save.

- On the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Is the decision for this issue already on file?: Select Yes .

- Select Decision not in the list .

- Special Condition: Select Voluntary Leaving - Just cause shown .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/vl_course_ic/non-contentious_reason_for_separation_rfs_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The reason for separation is not voluntary leaving .

- Select Continue .

- Complete the Not voluntary leaving screen as follows:

- Select the appropriate RFS.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Reason for separation (RFS) occurred before the qualifying period (QP)

Source topic: `en_EN/task/vl_course_ic/reason_for_separation_rfs_occurred_befo_370bd688_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The period of employment falls prior to the qualifying period .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/vl_course_ic/decision_already_on_file_level_1.dita`

- Determine if the appropriate decision is listed:

- If yes, on the list, select the appropriate ROD and select Save . Go to step 4.

- If no, select Decision not in the list .

- Select the appropriate special condition based on the decision on file and select Continue .

- Verify the information on the Record of Decision screen:

- Select I agree .

- Complete the ADJ WI. 

#### Reassigning the WI issue to Level 2

Source topic: `en_EN/task/vl_course_ic/reassigning_the_wi_issue_to_level_2_level_1.dita`

- In NWS, reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Client quit [his/her] job and [provide a brief reason for the referral, e.g. not a referred course] — unable to complete at Level 1.”

- Select OK .

- When the Warning window is displayed, select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4928.dita`

Required information:

- start and end dates of the referred training or employment activity

- client’s statement about the reason for leaving the employment to attend training

- name of the referred training or employment activity

- name of the institution or school and the location

- document completed by a designated authority that provides authorization to quit employment

- name and contact information of the training counselor 

#### Note

Source topic: `en_EN/common_notes/note_c_4929.dita`

Note:

If clients state that they were referred by a designated authority but the document that provides the authorization to quit employment is not on file, advise them to submit it as soon as possible. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4930.dita`

Voluntary leaving to attend referred training or an employment activity — Conditions to adjudicate the issue at Level 1 (all conditions must be met)

- The client was referred to the training or employment activity by an authority designated by the Commission before the voluntary leave;

- The voluntary leave was approved by the designated authority;

- The referred training or employment activity started in the 2 weeks following the date of the voluntary leave;

- The BPC or renewal week is equal to or after the week of voluntary leaving. 

## Policy reference

Source topic: `en_EN/task/vl_course_ic/policy_reference.dita`

- Digest 6 — Voluntarily leaving employment
         [Digest 6 — Voluntarily leaving employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/table-of-contents.html)

- BE 2010-12 — Voluntary Leaving to Attend Approved Training
         [BE 2010-12 — Voluntary Leaving to Attend Approved Training](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2010-12.shtml)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html) 
