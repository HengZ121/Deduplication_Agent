# Actioning an Adjudication Issue Child care WI

Source map: `en_EN/task/actioning_adj_cc_wi/actioning_adj_cc_wi.ditamap`

## Summary

Source topic: `en_EN/task/actioning_adj_cc_wi/summary.dita`

Summary: The system creates an Adjudication Issue (ADJ) Child care WI when a client applies for regular or fishing benefits and indicates that she gave birth in the last 17 weeks and does not have child care arrangements. 

## What you need to know

Source topic: `en_EN/task/actioning_adj_cc_wi/what_you_need_to_know.dita`

### Temporary process is no longer in effect — Relaxed requirements

Source topic: `en_EN/task/actioning_adj_cc_wi/temporary_process_is_no_longer_in_effec_dc8cd340.dita`

The simplification measure for relaxed requirements ends September 25, 2021. Effective September 26, 2021, the agent follows normal procedures to adjudicate all availability issues. 

### Adjudication Issue (ADJ) Child care WI

Source topic: `en_EN/task/actioning_adj_cc_wi/adjudication_issue_adj_child_care_wi.dita`

The system creates the ADJ Child care WI for a Level 1 agent to verify that the client indicated the correct benefit type (BT) on the application. If the client meant to apply for special benefits, the lack of child care arrangements is not an issue.

If the client confirms that she wants regular or fishing benefits, a Level 2 agent must adjudicate the client’s availability for work. 

### Claim action status and processing an initial or renewal claim

Source topic: `en_EN/task/actioning_adj_cc_wi/claim_action_status_and_processing_an_i_f11ddadd.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When there is an outstanding adjudication issue on a renewal claim , the Claim action status is In Progress (Automation) .

When the Claim action status is In Progress , all ADJ WIs must be completed before the system can calculate the initial claim or finalize the renewal claim. The MA02 stop payment on a renewal claim is removed by the system. 

### Communicating the decision

Source topic: `en_EN/task/actioning_adj_cc_wi/communicating_the_decision.dita`

If a letter of decision is required on an initial or renewal claim, before completing the ADJ WI, the agent creates a Correspondence (COR) Manual Decision WI indicating the details of the required letter. If a letter of decision is required on a continuing claim, the agent sends the letter before completing the WI. 

## Regional considerations

Source topic: `en_EN/task/actioning_adj_cc_wi/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actioning_adj_cc_wi/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/actioning_adj_cc_wi/in_nws.dita`

- Is there an SROC or other WIs containing additional information about the BT?

- Are there documents related to the issue? 

### In Imaging:

Source topic: `en_EN/task/actioning_adj_cc_wi/in_imaging.dita`

- Are there any imaged documents containing additional information about the BT? 

## Step by step

Source topic: `en_EN/task/actioning_adj_cc_wi/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/actioning_adj_cc_wi/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_adj_cc_wi/reviewing_the_file_level_1.dita`

- Determine if there is any indication on file that the client applied for regular or fishing benefits in error:

- If no, go to step 2.

- If yes, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/actioning_adj_cc_wi/fact-finding_level_1.dita`

- Fact-find with the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_adj_cc_wi#reassign)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Benefit type clarification.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save . 

#### Actioning the WI

Source topic: `en_EN/task/actioning_adj_cc_wi/actioning_the_wi_level_1.dita`

- Determine if the correct BT is regular or fishing:

- If no, go to step 6.

- If yes, reassign the WI to Level 2 to adjudicate the availability issue.
               [reassign the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_adj_cc_wi#reassign)

- In NWS, on the Specific Details tab of the ADJ WI, change the BT as follows:

- Benefit Type: Select the BT the client intended to apply for.

- Click Save .

- Complete the ADJ Child care WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/actioning_adj_cc_wi/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type the appropriate option:

- “Unable to contact client for fact-finding.”

- “Not within Level 1 authority.” 

### Level 2

Source topic: `en_EN/task/actioning_adj_cc_wi/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_adj_cc_wi/reviewing_the_file_level_2.dita`

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if there is enough information on file to adjudicate the availability issue:

- If additional details are needed, go to step 3.

- If additional details are not needed, go to step 9. 

#### Fact-finding

Source topic: `en_EN/task/actioning_adj_cc_wi/fact-finding_level_2.dita`

- Fact-find with the client. Refer to the Fact-finding Guide to determine which questions to ask the client.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 5.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Client not contacted .
               [Client not contacted](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_adj_cc_wi#noclientcontact)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Availability .

- Comments: Type “Child care arrangements.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Click Save . 

#### Amending the benefit type (BT)

Source topic: `en_EN/task/actioning_adj_cc_wi/amending_the_benefit_type_bt_level_2.dita`

- Determine if the correct BT is regular or fishing:

- If no, go to step 7.

- If yes, go to step 9.

- In NWS, on the Specific Details tab of the ADJ WI, change the BT as follows:

- Benefit Type: Select the BT the client intended to apply for.

- Click Save .

- Complete the ADJ Child care WI. 

#### Adjudicating availability

Source topic: `en_EN/task/actioning_adj_cc_wi/adjudicating_availability_level_2.dita`

- Adjudicate the client’s availability based on the entitlement principles in Digest 10 — Availability .

- If the client has not proven availability, go to Availability not in order .
               [Availability not in order](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_adj_cc_wi#Availability_not)

- If the client has proven availability, go to Availability in order .
               [Availability in order](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_adj_cc_wi#availinorder) 

#### Availability not in order

Source topic: `en_EN/task/actioning_adj_cc_wi/availability_not_in_order_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Availability — no child care — 3 - Not available disentitlement from w/c [XXXX] to w/c [XXXX].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- If fact-finding by telephone was not attempted, click Draft .

- If the client was reached by telephone during fact-finding, click Draft .

- If the client was not reached by telephone during fact-finding, click Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1351.dita)

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding or if there was no attempt to fact-find with the client by telephone, go to step 3.

- If the client was not reached by telephone during fact-finding, go to step 4.

- Verbally communicate the decision to the client .

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose a 3 - Not available disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Select the appropriate option:

- BPC date: If the disentitlement begins at BPC, check the box.

- If the disentitlement begins after BPC, enter the disentitlement start date.

- End date: Select the appropriate end date as follows:

- For a definite disentitlement, select the disentitlement end date.

- For an indefinite disentitlement, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Choose one of the following options:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes

- Complete: Select D - No .

- Click Update .

- In ACS, create and save the D-01-00-00 letter . Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- Select D3 Not available – Various reasons (2986) .

- Select D3 – No child care arrangements – RFS was family responsibilities – Family responsibilities prevent client from working (2989) .

- Select the most appropriate option.

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 8.

- If yes, go to step 10.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 9.

- If yes, go to step 10.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — availability issue.”

- Click Save .

- Complete the ADJ Child care WI. 

#### Client not contacted

Source topic: `en_EN/task/actioning_adj_cc_wi/client_not_contacted_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Availability — no child care — 3 - Not available disentitlement from w/c [XXXX] to 9999.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose a 3 - Not available disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Select the appropriate option:

- BPC date: If the disentitlement begins at the BPC, check the box.

- If the disentitlement starts after the BPC, enter the disentitlement start date.

- End date: Select the appropriate disentitlement end date as follows:

- For a definite disentitlement, select the disentitlement end date.

- For an indefinite disentitlement, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select one of the following:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Click Update .

- In ACS, create and save the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976):

- Select D3 Not available - various reasons (2986) .

- Select D3 - No child care arrangements – RFS was family responsibilities – Family responsibilities prevent client from working .

- Select the most appropriate option.

- Right to Request a Reconsideration (with Blank option)(4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note and type “Send the saved ACS letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 6.

- If yes, go to step 8.

- Determine if there is a system-generated ROD with a negative decision:

- If no, go to step 7.

- If yes, go to step 8.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — availability issue.”

- Click Save .

- Complete the ADJ Child care WI. 

#### Availability in order

Source topic: `en_EN/task/actioning_adj_cc_wi/availability_in_order_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Availability in order.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Complete the ADJ Child care WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1351.dita`

Note:

If fact-finding by telephone was attempted but was not successful, click Save regardless of the decision, because verbal communication of the decision is not required. 

## Policy reference

Source topic: `en_EN/task/actioning_adj_cc_wi/policy_reference.dita`

- Digest 10 — Availability
         [Digest 10 — Availability](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/table-of-contents.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIR 32
         [EIR 32](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-32.html) 
