# Actioning an E-report notification — Messages (MD51)

Source map: `en_EN/task/actioning_md51/actioning_md51.ditamap`

## Summary

Source topic: `en_EN/task/actioning_md51/summary.dita`

Summary: When a completed electronic claimant’s report raises issues that may affect payments, a message is sent to the Service Canada Center (SCC). The officer reviews the information and takes the appropriate action. 

## What you need to know

Source topic: `en_EN/task/actioning_md51/what_you_need_to_know.dita`

### SCC E-Report — Messages (MD51) screen

Source topic: `en_EN/task/actioning_md51/scc_e-report__messages_md51_screen.dita`

When a completed claimant’s report raises questions or issues that impact payments, the client’s SIN is displayed in the SCC E-Report — Messages (MD51 ) search results in FTS. Although the claimant’s report has been processed or eliminated, the MD51 warns that the information must be reviewed for any impact to weeks processed. This usually happens when a claimant’s report “trips down” to the call centre and an officer completes the report with the client. The call centre officer can then send a message to the SCC to review an issue that was raised while completing the report.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1446.dita) 

### Actions required

Source topic: `en_EN/task/actioning_md51/actions_required.dita`

The officer reviews the information on the MD51 to determine the reason the claimant’s report was referred and the action required. The issue may relate to the reason for separation (RFS), availability or earnings. 

### Claim action status and processing of the claim

Source topic: `en_EN/task/actioning_md51/claim_action_status_and_processing_of_the_claim.dita`

During processing, an initial or renewal claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

- Finalized - Pending LREM 

### Info

Source topic: `en_EN/common_notes/note_c_1446.dita`

**Example**

The client declares a vacation pay or bonus that should have been declared in a previous week. As these earnings do not relate to the current reporting period, this claimant’s report is processed. However, the officer must review the information and allocate the monies. 

## Regional considerations

Source topic: `en_EN/task/actioning_md51/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actioning_md51/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/actioning_md51/in_nws.dita`

- What is the Claim action status?

- Are there SROCs or WIs relating to the issue? 

### In Imaging:

Source topic: `en_EN/task/actioning_md51/in_imaging.dita`

- Are there are any imaged documents relating to the issue? 

## Step by step

Source topic: `en_EN/task/actioning_md51/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/actioning_md51/level_1.dita`

#### Determining the claim type (CT)

Source topic: `en_EN/task/actioning_md51/determining_the_claim_type_ct_level_1.dita`

- Determine if the Claim action status is one of the following:

- In Progress (Manual)

- In Progress (Automation)

- Finalized - Pending LREM

- If yes, go to Initial or renewal claim .
               [Initial or renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_md51#InitialRenewalClaim)

- If no, go to Continuing claim .
               [Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_md51#ContinuingClaim) 

#### Actioning the SCC E-Report — Messages (MD51) screen — Initial or renewal claim

Source topic: `en_EN/task/actioning_md51/actioning_the_scc_e-report__messages_md_4f621b4d_level_1.dita`

- In FTS, select Messages (MD51) from the SCC E-Report search.

- In the MD51 results window, click the first SIN to review the claimant’s report.

- Message 1 and Message 2: Click the 3-digit message code to view a description of the issue.

- Click on the SIN line to open the claimant’s report. Review the information and click on the termination code to open the Web Error Code System (WECS) and provide a detail description of the error.
               [Web Error Code System (WECS)](http://wecs-siew.prv/wecs-siew/lookup_e.aspx)

- Determine the issue that requires review:

- If the issue is RFS or availability, go to step 5.

- If the issue is earnings, go to step 6.

- In NWS, create an Adjudication Issue (ADJ) WI as follows:

- Complexity: Select Level 1 .

- Destination: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Details: Indicate the reason the WI is being created.

- Click Save .

- Go to step 7.

- In NWS, create an Action Item (AI) WI as follows:

- Complexity: Select Level 1 .

- Destination : Enter the S CC as shown in FTS.

- End User: Select Myself .

- Category: Select the appropriate option:

- Pay affected .

- Not pay affected .

- Issue(s): Select Earnings .

- Comments: Enter the appropriate information.

- Details: Indicate the reason the WI is being created.

- Obtained on: Indicate the date the document was received, if received before the date entered.

- Review the issue. If necessary, refer to the appropriate procedure to resolve the issue. For example if the issue is voluntary leaving, refer to the appropriate Voluntary leaving task.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1447.dita)

- In FTS, remove the SIN from the MD51 as follows:

- Actioned: Check the box next to the appropriate SIN.

- Click Update . 

#### Actioning the SCC E-Report — Messages (MD51) screen — Continuing claim

Source topic: `en_EN/task/actioning_md51/actioning_the_scc_e-report__messages_md_996c6fd0_level_1.dita`

- In FTS, select Messages (MD51) from the SCC E-Report search.

- In the MD51 results window, click the first SIN to review the claimant’s report.

- Message 1 and Message 2: Click the 3-digit message code to view a description of the issue.

- Click on the SIN line to open the claimant’s report. Review the information and click on the termination code to open the Web Error Code System (WECS) and provide a detail description of the error.
               [Web Error Code System (WECS)](http://wecs-siew.prv/wecs-siew/lookup_e.aspx)

- In FTS, determine if there is an outstanding registration number for the issue:

- If there is an outstanding registration number, go to step 6.

- If there is no outstanding registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Create Work Item: Check the box.

- Click Update .

- In NWS, open the newly created Claim Review (CR) Revised WI and modify it as follows:

- Issue: Select the appropriate option.

- Click Save .

- Go to step 7.

- In NWS, determine if there is an outstanding WI for the issue:

- If yes, go to step 7.

- If no, create a CR WI as follows:

- Type: Select Revised .

- Issue: Select the appropriate option.

- Registration number: Type “999999.”

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- Date of registration: Enter today’s date.

- Review the issue. If necessary, refer to the appropriate procedure to resolve the issue. For example if the issue is voluntary leaving, refer to the appropriate Voluntary leaving task.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1447.dita)

- In FTS, remove the SIN from the MD51 as follows:

- Actioned: Check the box next to the appropriate SIN.

- Click Update . 

#### Note

Source topic: `en_EN/common_notes/note_c_1447.dita`

Note:

After you have completed the referred task, go to step 8. 

## Policy reference

Source topic: `en_EN/task/actioning_md51/policy_reference.dita`

 
