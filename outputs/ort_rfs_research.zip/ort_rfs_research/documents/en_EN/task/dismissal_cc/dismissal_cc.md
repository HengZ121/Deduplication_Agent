# Adjudicating a dismissal for unsuitability — Continuing claim

Source map: `en_EN/task/dismissal_cc/dismissal_cc.ditamap`

## Summary

Source topic: `en_EN/task/dismissal_cc/summary.dita`

Summary: The Level 1 officer adjudicates cases of dismissal only when clients are dismissed because they were not suitable, did not pass training or were terminated within the probationary period, and not for any ill-intentioned action. 

## What you need to know

Source topic: `en_EN/task/dismissal_cc/what_you_need_to_know.dita`

### Adjudicating a dismissal for unsuitability

Source topic: `en_EN/task/dismissal_cc/adjudicating_a_dismissal_for_unsuitability.dita`

Clients may be dismissed for unsuitability during the probationary period or if they do not pass the probationary period or they do not meet the job requirements. 

### Levels of decision

Source topic: `en_EN/task/dismissal_cc/levels_of_decision.dita`

A Level 1 officer can render the decision to allow a dismissal on all claim types (CTs) when:

- the client indicates being dismissed due to unsuitability or due to a shortage of work; and

- the employer, when contacted, confirms that the client was not suitable for the position and there was no misconduct; or

- a comment on the ROE confirms the dismissal is due to the client being unsuitable, not passing training or being terminated within the probationary period; and

- there are no other contentious issues related to the dismissal that would prevent the Level 1 officer from allowing the reason for separation (RFS).

If a checklist or questionnaire was completed, the officer must review the client’s statement to determine if the client indicated being dismissed for being unsuitable.

The officer reviews the ROE to determine if there are comments showing that the client was dismissed for unsuitability or if the client’s employment was terminated in the probationary period. On a Web ROE, the employer can select the Terminated within probationary period field. If there are no comments on the ROE or if there is no ROE in the file, the officer contacts the employer for fact-finding.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3226.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3227.dita) 

### ROE error on a continuing claim

Source topic: `en_EN/task/dismissal_cc/roe_error_on_a_continuing_claim.dita`

If the ROE is present, the officer must update the Special condition field in RCM in order for ACP to automate any future claims. When this is done, the ROE may present an error. On a continuing claim, it is not necessary to correct these errors. If the client submits another claim, the ROE is corrected at that time. 

### Previously deferred decision

Source topic: `en_EN/task/dismissal_cc/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred reason for separation (RFS) must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 10 - Dismissal – misconduct proven (D10) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D10 that is on file and update the Special Condition field on the ROE in RCM. 

### Employment is not insurable

Source topic: `en_EN/task/dismissal_cc/employment_is_not_insurable.dita`

Adjudication of the dismissal or suspension is required when the employment is not insurable due to a non-arm’s length issue. Adjudication of the dismissal or suspension is not required if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. 

### Actions required following adjudication

Source topic: `en_EN/task/dismissal_cc/actions_required_following_adjudication.dita`

When the dismissal is adjudicated and the ROE is received, the Special condition field of the ROE must be updated to show either Misconduct – Not proven or Misconduct - Proven . 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/dismissal_cc/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/fr/procedure/task/determining_issue_referred_integrity.shtml)

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Previously deferred decision

Source topic: `en_EN/task/dismissal_cc/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred reason for separation (RFS) must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 10 - Dismissal – misconduct proven (D10) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D10 that is on file and update the Special Condition field on the ROE in RCM. 

### Note

Source topic: `en_EN/common_notes/note_c_3226.dita`

Note:

On a Web ROE, the employer can select the code M - Dismissal or suspension / Terminated within the probationary period in block 16 - Reason for Issuing the ROE , which is equivalent to comments in block 18 indicating that the client was dismissed due to unsuitability, not passing training or being terminated within the probationary period. 

### Note

Source topic: `en_EN/common_notes/note_c_3227.dita`

Note:

The statement that the client was dismissed “without cause” is not sufficient to conclude that the client was dismissed for unsuitability. The officer must fact-find with the employer to determine the cause of the dismissal.

Confirmation of the reason for dismissal with the employer is not required if the comment on the ROE shows one of the following reasons:

- Not suitable;

- Did not pass training;

- Terminated within the probationary period. . 

## Regional considerations

Source topic: `en_EN/task/dismissal_cc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/dismissal_cc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/dismissal_cc/in_nws.dita`

- Is there a ROD for the dismissal on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Dismissed section of this or a previous EI application?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the dismissal? 

### In FTS:

Source topic: `en_EN/task/dismissal_cc/in_fts.dita`

- Is there a 75 - Verification of reason for termination of Employment manual action (MA75) imposed to stop payments?

- Is there a registration number? 

### In Imaging:

Source topic: `en_EN/task/dismissal_cc/in_imaging.dita`

- Are there any imaged documents relating to the dismissal? 

### In RCM:

Source topic: `en_EN/task/dismissal_cc/in_rcm.dita`

- Is there an ROE for the dismissal?

- If yes, is the reason for separation (RFS) K or M in block 16 of the ROE?

- Are there any comments related to the dismissal? 

## Step by step

Source topic: `en_EN/task/dismissal_cc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/dismissal_cc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/dismissal_cc/reviewing_the_file_level_1.dita`

- Determine if the facts on file clearly indicate that the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_cc#NotInsurable)

- If neither of these reasons applies, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring to Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting Deferring adjudication . 

#### Fact-finding

Source topic: `en_EN/task/dismissal_cc/fact-finding_level_1.dita`

- Determine if there is enough information to adjudicate the dismissal based on the National Policy on Levels of Decision :

- If additional details are needed, fact-find with the client or employer and go to step 5.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If additional details are not needed, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3228.dita)

- Determine if the client or employer was contacted during fact-finding:

- If the client or employer was not contacted or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_cc#level2)

- If the client or employer was contacted, go to step 6.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Dismissal — [employer’s name] — [last day worked] — [client or employer].”

- Details: Document the fact-finding details according to Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/dismissal_cc/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if all conditions are met to allow adjudication at Level 1:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3229.dita) 

- If all conditions are met, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_cc#rfs)

- If all conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_cc#level2) 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/dismissal_cc/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, create a ROD as follows:

- BPC: Enter the BPC of the claim.

- Comments: Type “Dismissal — [employer name] — [last day worked] — misconduct not proven.”

- Details: Type “Based on the information on file, the criteria to allow the decision at Level 1 have been met. The employer confirms the reason for separation was due to unsuitability and not related to any wrongdoing on the part of the client. (National Policy on Levels of Decision).”

- In RCM, verify that the ROE was received for which the client was dismissed and do one of the following:

- If yes, go to step 10.

- If no, go to step 11.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select M - Dismissal .

- Special condition: Select the appropriate option:

- If a previous ROD indicates that misconduct was proven, select Misconduct proven .

- For all other situations, select Misconduct not proven .

- Cut and paste any comments related to misconduct from block 18 to the Additional Information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3230.dita)

- In FTS, determine if a D10 was imposed because this RFS adjudication was previously deferred:

- If yes, go to step 12.

- If no, go to step 14.

- Determine if the D10 was only imposed due to this previously deferred RFS issue and if other issues must be adjudicated:

- If no other issues must be adjudicated, go to step 13.

- If other issues must be adjudicated refer to the appropriate tasks for instructions. Then go to step 13.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F – Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In FTS, determine if an MA75 is imposed and if there is a registration number for the dismissal:

- If an MA75 is imposed but there is no registration number, go to step 15.

- If an MA75 is imposed and there is a registration number, go to step 16.

- If an MA75 is not imposed but there is a revised registration number, go to step 17.

- If none of the above applies, go to step 18.

- Select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and remove the MA75 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 75 - Verification of reason for termination of Employment .

- Rescind: Check the box.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 18.

- Select the Renewal/Revised (M106) transaction to clear the outstanding registration number as follows:

- Claim allowed: Select NCA - No change to the claim .

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Complete the WI for the dismissal. 

#### Employment is not insurable

Source topic: `en_EN/task/dismissal_cc/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Dismissal or suspension — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the dismissal or suspension is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the dismissal or suspension is therefore not required.”

- Complete the WI related to the dismissal or suspension. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/dismissal_cc/reassigning_the_issue_to_level_2_level_1.dita`

- In FTS, on the Summary tab, determine if an MA75 has been imposed:

- If yes, go to step 2.

- If no and the client is requesting special benefits, go to step 2.

- If no and the client is requesting regular benefits, select the Renewal/Revised (M106) transaction and impose the MA75 as follows:

- Registration number: Leave the field blank. If a number is displayed, remove it.

- Manual Action: Select 75 - Verification of reason for separation of employment .

- Select Update .

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select the Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “client dismissed for reasons other than unsuitable. Not within Level 1 authority.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_3228.dita`

Note:

If fact-finding with the employer is required to confirm that the client was dismissed for unsuitability, ask the employer to provide more details regarding why the client was dismissed.

For example, was the client unsuitable because they were unable to perform the tasks required or was the client considered unsuitable because they were late to work every day? The client being unable to perform the tasks required requires Level 1 adjudication, but being late requires Level 2 adjudication. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3229.dita`

- the client indicates they were dismissed due to unsuitability or due to a shortage of work; and

- the employer has confirmed the client was not suitable for the position and there was no misconduct; or

- a comment on the ROE confirms the dismissal is due to the client being unsuitable, not passing training or being terminated within the probationary period; and

- there are no other contentious issues related to the dismissal that would prevent Level 1 from allowing the RFS. 

#### Note

Source topic: `en_EN/common_notes/note_c_3230.dita`

Note:

Selecting Validate may cause the ROE to be flagged with an error. If this occurs, no further action is required. If the client submits another claim, the ROE is corrected at that time. 

## Policy reference

Source topic: `en_EN/task/dismissal_cc/policy_reference.dita`

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- National Policy on Levels of Decision—Not Misconduct
         [National Policy on Levels of Decision—Not Misconduct](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
