# Archived: Processing an EI ERB repayment

Source map: `en_EN/task/actioning_erb_repayment/actioning_erb_repayment.ditamap`

## Summary

Source topic: `en_EN/task/actioning_erb_repayment/summary.dita`

[Warning](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1386.dita) 

Archived

This page has been archived on the Web.
       [This page has been archived on the Web.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_erb_repayment#archived)

Summary: When a client repays an EI Emergency Response Benefit (EI ERB) payment, the officer reviews the client’s eligibility and creates an overpayment (OP), if necessary, without exceeding the total amount repaid by the client. 

### Warning

Source topic: `en_EN/common_notes/note_c_1386.dita`

**This page has been archived on the Web**

UPDATED: 2026-02-23 — This page has been archived because the information is outdated.

Information identified as archived is provided for reference, research or recordkeeping purposes. It is not subject to the Government of Canada Web Standards and has not been altered or updated since it was archived. Please contact us to request a format other than those available. 

## What you need to know

Source topic: `en_EN/task/actioning_erb_repayment/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/actioning_erb_repayment/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1387.dita) 

### Processing an EI Emergency Response Benefit (EI ERB) repayment

Source topic: `en_EN/task/actioning_erb_repayment/processing_an_ei_emergency_response_ben_65677c11.dita`

The officer reviews the EI ERB claim under EIA 44 which allows the Commission to accept and retain benefit payments that the client voluntarily repaid. The officer creates an OP for periods in which the client was not eligible. The officer imposes an OP only for the weeks in which the client was not eligible, up to a maximum amount that equals the total amount repaid by the client.

To process an EI ERB repayment, the officer:

- determines the total amount repaid by the client, the reason for the repayment, and the weeks of benefits paid that are affected by the repayment;

- determines if the $2 000 EI ERB advance payment was issued to the client, if the advance payment was already repaid and if the client was eligible;

- verifies if part of the repayment has already been reconciled or if an Integrity investigation has been completed and validates the pending repayment amount;

- calculates the real amount overpaid to the client and compares it to the amount repaid;

- creates an OP, by imposing a disentitlement for the periods in which the client is not eligible, up to an amount that does not exceed the total amount repaid;

- determines if the payments were repaid in excess or in error and takes the appropriate action.

Once the OP is created, NAR matches it to the pending repayment amount. The transactions related to the OP being established and to the repayment being applied are displayed in PSCD. 

### Reconciliation processing

Source topic: `en_EN/task/actioning_erb_repayment/reconciliation_processing.dita`

The entire process to reconcile the amount repaid by the client can take some time, because it includes many steps taken by different actors:

- The officer creates the OP.

- NAR applies the pending repayment to the OP.

- An amended T4E is issued, when required.

- The amended T4E is uploaded to MSCA and transmitted to the Canada Revenue Agency (CRA) and Revenu Québec, as required. If the client chose to receive a paper copy of the T4E in the Income Tax Information section of the application for benefits, a copy of the amended T4E is also mailed to the client. 

### Processing WIs

Source topic: `en_EN/task/actioning_erb_repayment/processing_wis.dita`

WIs are created because clients contacted Service Canada about their repayments. 

### EI Emergency Response Benefit (EI ERB) repayments and overpayments (OPs) found in PSCD and DARS

Source topic: `en_EN/task/actioning_erb_repayment/ei_emergency_response_benefit_ei_erb_re_dbbc7348.dita`

In DARS: The officer reviews various screens and codes to determine if any EI ERB repayments were made before April 2021, and if yes, which OP the repayment was applied to.

DARS codes and screens commonly used for the EI ERB:

- Frequently used screens

- DC001 Accounts summary

- DC002 Account history by transaction

- DC006 Client summary

- Account type for the EI ERB

- 1345 - EI Emergency Response Benefits

- 1346 - CERB Advance payment

- Transaction codes

- TC10 - Establishment of an overpayment account

- TC20 - Overpayment account adjustment (Increase or Decrease)

- TC40 - Change the status of Account

- TC50 - Payment

- TC51 - Reversal of payment

- Status Code

- DF19 - EI: Emergency Response Benefits

- DF94 - EI: Non-misrepresentation establishments

- DL — Deleted

- PD — Account paid

- WO — Write Off - Debtor’s account written off

In PSCD: The officer first reviews the business partner account using the client’s SIN and then expands the section Debt Information - Account balance . If the amount shown is negative, it is a credit. The officer can select Cleared items to review any previous transactions to see what debts were repaid. The contract object type ERB2 is for the advance payment and the contract object type ERB1 code is for other EI ERB transactions. 

### Reason for repayment

Source topic: `en_EN/task/actioning_erb_repayment/reason_for_repayment.dita`

The reason for repayment of benefits determines which instructions the officer follows in the Step by step section.

**$2 000 EI Emergency Response Benefit (EI ERB) advance payment repaid**

If the client repaid only the $2 000 advance payment, in whole or in part, and the OP amount must be adjusted, the officer creates an Operational Centre Memo (MM06) transaction. If the client repaid other weeks of benefits along with the advance payment, the officer processes any inputs in BCS when the Blocked Status column shows 1 - Updateable . If the Blocked Status column shows any other status besides 1 - Updateable , the officer sends an MM06 with a request to complete the transactions.

**Client not eligible for the EI Emergency Response Benefit (EI ERB)**

If the client is not eligible for the EI ERB and has repaid all or part of the amount received, the Level 1 officer imposes a disentitlement on the appropriate 2-week periods to create an OP amount that does not exceed the total amount repaid. If the client clearly refuses the weeks to which the client is eligible for personal or moral reasons, or if there is a contentious reason for separation (RFS) that requires adjudication, a Level 2 officer from the specialized team reviews the claim and determines if a disentitlement must be imposed.
       [eligible for the EI ERB](/en/policy/generic/ei_erb_digest.shtml#ch_4)

**EI Emergency Response Benefit (EI ERB) and the Canada Emergency Response Benefit (CERB) received for the same period**

If the client received the CERB from the CRA and the EI ERB for the same weeks, the CRA is responsible for the collection of the OP. If an OP is created by the CRA, the client will receive a Notice of Redetermination about the amount that the client needs to repay.

If the repayment was initially sent to EI, NAR has usually already transferred the amount to the CRA. However, the officer confirms if a pending repayment is still with EI by checking the payment in suspense list and PSCD.

If the client has a repayment amount with EI, but the OP is with the CRA, the officer submits an iService request to NAR requesting to send the amount to the CRA.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1388.dita) 

**EI Emergency Response Benefit (EI ERB) received instead of the Canada Emergency Student Benefit (CESB)**

If the EI ERB was repaid because the client wanted the CESB instead, the officer reviews the EI ERB eligibility criteria with the client to determine if an OP applies. Under EIA 44, an OP is imposed on any week of EI ERB for which the client was not eligible, up to a maximum amount that equals the total amount repaid by the client.

If the client requests additional information on the CESB or the CERB student debt reduction once the officer has reviewed the client’s eligibility to the EI ERB, the officer advises the client to contact the CRA at 1-800-959-8281. 

### Reviewing eligibility and earnings on an EI Emergency Response Benefit (EI ERB) claim

Source topic: `en_EN/task/actioning_erb_repayment/reviewing_eligibility_and_earnings_on_a_d4ba7c22.dita`

**Reviewing the EI Emergency Response Benefit (ERB) claim**

When processing a repayment, the officer must review the claim based on the weeks in which the EI ERB was paid to the client during the EI ERB period. These weeks are considered as being originally paid.

Eligibility is reviewed in periods of 2 weeks, starting from the beginning of the claim when the first week of the EI ERB was originally paid. If there is a gap in the payments of more than 2 weeks between the weeks of the EI ERB that were originally paid, the 2-week periods restart on the renewal week in which the client was originally paid.

Sometimes, a 1-week period must be reviewed because of how the weeks fall. The week may be before or after a gap in the originally paid weeks, at the end of the claim, or due to a reported return to work (RTW) or because a renewal was processed.

Each 2-week period must be reviewed to see if the criteria are met. The eligibility of the 2-week period being reviewed does not impact any other 2-week periods.

**Determining eligibility**

The officer reviews the EI ERB claim to determine if the client was eligible for the weeks of EI ERB received. The officer considers the total amount that the client repaid before imposing any disentitlements. Under EIA 44, the OP must not exceed the total amount repaid.

The definition of claimant, found in EIA 153.5(2 ) must be used when reviewing eligibility for the EI ERB. The officer determines which definition of client is met and then reviews the related criteria under EIA 153.9(1). Clients are eligible for the EI ERB under EIA 153.9(1) :
       [EIA 153.5(2](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.5.html) 
       [EIA 153.9(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html#h-216637)

- if they meet the definition of a claimant referred to in 153.5(2)(a) and if they:

- reside in Canada,

- are at least 15 years of age,

- have insurable earnings of at least $5,000 in 2019 or in the 52 weeks preceding the day on which they make the claim under EIA 153.8 ,
             [153.8](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242461)

- whether employed or self employed, cease working for at least seven consecutive days within the two-week period for which they claimed benefits, and

- have no income from employment or self-employment for the consecutive days on which they cease working.

- if they are a claimant referred to in paragraph 153.5(2)(b) and they have no income from employment or self-employment for at least seven consecutive days within the two-week period for which they claimed the benefit; or
         [153.5(2)(b)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242461)

- if they are a claimant referred to in paragraph 153.5(2)(c) or (d) and they:

- reside in Canada,

- are at least 15 years of age,

- have insurable earnings of at least $5,000 in 2019 or within the 52 weeks preceding the day on which they make the claim under EIA 153.8 , and
             [153.8](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242461)

- have no income from employment or self-employment for the consecutive days on which they cease working.

         [153.5(2)(c)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242461) 
         [(d)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242461)

If the client meets the definition of a claimant and all of the related conditions under EIA 153.9(1) are met, the client is eligible for the 2-week period under review. This means that a client who meets 153.9(1) by having a 7 consecutive day break without work or income will be eligible to EI ERB regardless of the amount of their income.
       [EIA 153.9(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html#h-216637)

If the client does not meet the conditions of EIA 153.9(1)(a)(i), (ii) and (iii) or EIA 153.9(1)(c)(i), (ii) and (iii), the client is not eligible for EI ERB and a 31 - EI ERB – Entitlement conditions not met disentitlement (D31) can be imposed for each week in which these criteria were not met.

If client does not meet the conditions of EIA 153.9(1) (a)(iv) and (v) or EIA 153.9(1)b) or EIA 153.9(1)(c)(iv), the officer reviews the file to determine if the client is eligible under the exception in EIA 153.9(4) .
       [EIA 153.9(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html#h-216637) 
       [153.9(4)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#docCont)

**Eligibility exception under EIA 153.9(4)**

Under EIA 153.9(4) , a client who does not stop working and have a total loss of income over 7 consecutive days in the 2-week period under review may still be eligible for the EI ERB that was originally paid if the client had $1 000 or less in income over a 4-week period.
       [153.9(4)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#docCont)

The 4-week period considered includes any originally paid weeks in the 2-week period under review and the closest previous 2-week period in which the EI ERB was originally paid (this may not be a consecutive week as the EI ERB may not have been paid every week).

A week with a 65 - Lump Sum Payment ($2000) - Canadian Emergency Response code (D65) or a week used to reconcile the advance payment OP is considered a week in which the EI ERB was originally paid.

If the sum of the client’s income over 4 originally paid EI ERB weeks exceeds $1 000 (income of $1 001 or higher) over the 4-week period, the client is not eligible for the 2-week period being reviewed and an OP may be created for the period being reviewed.

When reviewing the first 2-week period of the EI ERB claim, since there are no previous weeks, only income in the 2-week period is considered in the calculation of the income over 4 weeks.

No OP is created for the previous weeks reviewed under EIA 153.9(4) for income over $1 000.

If the client’s income is $1 000 or less , the client is considered to have met the income loss requirement and is entitled to keep the EI ERB paid for the 2-week period being reviewed.

**Return to work (RTW) or full work week (FWW)**

RTW and FWW codes cannot be added on an EI ERB claim even though clients were able to report a RTW or an FWW on the original claimant’s reports. If the client reports an RTW or has an FWW, the officer obtains the income amounts and reviews the eligibility criteria to know if the client meets the income loss requirements in Chapter 4 of the EI Emergency Response Benefits Digest .
       [EI Emergency Response Benefits Digest](/en/policy/generic/ei_erb_digest.shtml)

If the client reported an RTW or an FWW and the other week in the period was originally paid and had no earnings, the period meets the eligibility requirements under EIA 153.9(1) because the client had a 7-day gap in earnings from employment or self-employment (SE). In this case, no further review of eligibility is required, and the client may be eligible to an underpayment (UP).

If the client reported a RTW or an FWW for one week and reported earnings the following originally paid week in the period, the period under review did not meet the requirement to have a 7-day gap in earnings under EIA 153.9(1) and the eligibility criteria under EIA 153.9(4) must be reviewed.

**Using the EI ERB repayment tool**

The officer first manually reviews the eligibility criteria based on the information that the client provided to determine if the definition of claimant under EIA 153.5(2) is met. Then, the officer determines if the related criteria under EIA 153.9(1)(a)(i), (ii) and (iii) or EIA153.9(1)(c)(i), (ii) and (iii) are met. If the client does not meet these criteria, a D31 may be imposed for the 2-week periods in which these criteria are not met.

But if the criteria of EIA 153.9(1)(a)(i), (ii) and (iii) or EIA153.9(1)(c)(i), (ii) and (iii) are met, the officer opens the EI ERB repayment tool . The officer inputs the EI ERB claim information into the tool and ensures that it is accurate. The tool determines a client’s eligibility under EIA 153.9(1)(a)(iv) and (v), EIA 153.9(1)(b), EIA 153.9(1)(c)(iv) and EIA153.9(4).
       [EI ERB repayment tool](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Template-EIERBRepaymentTool-Bil-Final.xlsx)

The tool indicates if a disentitlement (i.e. 47 - EI ERB – Earnings limit exceeded for the four week period disentitlement [D47]) may need to be imposed and if any FWW or RTW weeks that were originally reported need to have the coding removed and can be credited. Instructions on how to use the tool are provided in the Instructions box in the excel spreadsheet.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1389.dita) 
     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1390.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1391.dita) 

### Multiple reasons for repayment on the same file

Source topic: `en_EN/task/actioning_erb_repayment/multiple_reasons_for_repayment_on_the_same_file.dita`

When the client repays many weeks of benefits, different reasons for repayment can exist on the same file. The officer follows the appropriate instructions for each reason for repayment. If one of the reasons for repayment is within Level 2 authority, the officer reassigns the WI. 

### $2 000 EI Emergency Response Benefit (EI ERB) advance payment and 65 - Lump Sum Payment ($2000) Canadian Emergency Response code (D65)

Source topic: `en_EN/task/actioning_erb_repayment/2_000_ei_emergency_response_benefit_ei__d47d4bba.dita`

Clients whose claims have a BPC between w/c 2230 and w/c 2243 inclusively received a $2 000 advance payment as soon as their claims were established. However, clients who received the CERB from the CRA and clients who reported being pregnant on their applications did not receive the $2 000 payment. The payment is an advance payment equivalent to 4 weeks of the EI ERB.

Once 12 weeks of the EI ERB had been paid, the system automatically imposed a 2-week D65 to reconcile half of the $2 000 advance payment. Once 17 weeks of the EI ERB had been paid, a second 2-week D65 was imposed to reconcile the remaining $1 000. To be eligible for the entire $2 000 advance payment, clients must have served all 4 weeks of the D65.This means that the $2 000 EI ERB advance payment must be entirely repaid if the client stopped requesting the EI ERB before reaching the 13th week.

The 4 weeks of the advance payment are not counted in the Total weeks paid field on the Summary tab in FTS. To determine if the $2 000 advance payment was issued to the client, the officer refers to the EI ERB $2000 section on the Emergency Response Benefits screen in FTS.

The D65 was created to account for the 4 weeks of benefits corresponding to the $2 000 advance payment, and to ensure that the client does not receive more than 28 weeks of the EI ERB. The system imposed the D65 2 weeks at a time:

- D65 start date: day 1 of the week immediately following the 12th and the 17th weeks paid.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1392.dita) 

### Lump-sum payment modification codes

Source topic: `en_EN/task/actioning_erb_repayment/lump-sum_payment_modification_codes.dita`

In FTS, the Emergency Response Benefits screen displays information related to the $2 000 advance payment, including a lump-sum payment modification code indicating when a change to the $2 000 advance payment is required.

Lump-sum payment modification codes that can impact EI ERB repayments include the following:

- C - Cancelled

- D - Established as overpayment

- N - $1500 established as overpayment

- A utility run has established part of the $2 000 advance payment as an OP.

- P - $1000 established as overpayment

- Q - $500 established as overpayment

- The Lump sum modification code field is blank

The modification code and weeks with a D65 can affect the inputs in BCS. If the officer gets a B112 or B100 error code the day after BCS inputs, the officer uses the Forward via MM06 link found on the Results tab of BCS to send the transaction to IPOC for processing. 

### Repayment made in error, in excess or to the wrong government authority

Source topic: `en_EN/task/actioning_erb_repayment/repayment_made_in_error_in_excess_or_to_af30fdc3.dita`

The client may have repaid an amount in error, repaid an amount that is larger than the one received, or repaid an amount to the wrong government authority. For example:

- If the client repaid the $2 000, advance payment and doubted eligibility to receive it, the officer reviews the client’s eligibility. If the client served any weeks of D65, the officer may need to return all, or a portion of the repayment to the client.

- The client repaid $1 000, but the OP on file was only $500.

- The client repaid Service Canada but should have repaid the CRA.

- A recoupment or set-off from the CRA is displayed in PSCD and must be credited back to the client.

When an OP is imposed and a credit balance of $500 or more will remain, the officer moves the WI to Pending to confirm the processed transactions in PSCD. When the amount remaining in PSCD is only the expected credit balance, the officer sends a request using the iService Catalogue by completing the Request for Refund on Accounts Receivable template to repay the client. Before sending the request for refund, the officer reviews the client’s address and direct deposit information and makes any necessary updates.
       [Request for Refund on Accounts Receivable](https://dialogue.spprod.service.gc.ca/grp/CR-AR/Lists/NCFOBGRequestsGateType10/NewForm.aspx?Source=https://dialogue.spprod.service.gc.ca/grp/CR-AR/SitePages/Merci-ThankYou.aspx)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1393.dita) 

### T4Es

Source topic: `en_EN/task/actioning_erb_repayment/t4es.dita`

Clients may request information or an explanation of their T4Es which are amended after a repayment is applied to an OP on their claims. The officer reviews the file and explains that the T4E corresponds to the year in which the repayment was received. The officer refers to Actioning a request for T4E clarification for more information.
       [Actioning a request for T4E clarification](/en/procedure/task/t4e_clarification.shtml) 

### Inputs on a blocked claim — BCS

Source topic: `en_EN/task/actioning_erb_repayment/inputs_on_a_blocked_claim__bcs.dita`

BCS allows certain transactions to be processed on an inactive blocked claim. If the blocked status is 1 - Updateable in the Blocked Status column on the Blocked tab, the officer can request an update and the transaction can be processed in BCS.

If the Blocked Status column shows any other status besides 1 - Updateable , the officer sends an MM06 with a request to complete transactions. If the client repaid only the $2 000 advance payment, and the OP amount must be adjusted, the officer creates an MM06 transaction. If a found work code needs to be removed from a week to apply a credit, the officer sends an MM06. The officer processes all other transactions in BCS when the Blocked Status column shows 1 - Updateable .

Only one BPC can be updated at a time in BCS. When a transaction is input without being processed, Yes shows in the Block Action Pending column, and any input on another BPC is rejected until the required transactions are processed. Access to a BPC with pending action is limited to the officer who initiated this action.

If an officer requests an update that BCS is unable to complete, the next processing day, the message Blocked claim not updated or not calculated , as well as the exceptions, errors or warnings show on the Rejected Transactions Retrieval (MR05) screen. The officer verifies whether other action must be taken on the exceptions, errors or warnings shown on the Results tab in BCS. If BCS cannot process the requested update, the system generates an estimate of the results. The transaction can then be sent to IPOC using the Forward via MM06 link, which creates prefilled Renewal/Revised (M106) and MM06 transactions.

The officer inputs all disentitlements in BCS and moves the WIs to Pending to verify if a B112 or B100 error code is displayed. If the inputs were not completed because of an error, the officer forwards the transaction as an MM06 to IPOC. 

### Fact-finding

Source topic: `en_EN/task/actioning_erb_repayment/fact-finding.dita`

The officer conducts fact-finding according to regular procedures. If the client is not reached, the officer imposes a D21 for the number of weeks to equal the repayment amount if the required criteria listed in the Levels of Decision section below are met.
       [fact-finding](/en/procedure/task/fact_find.shtml) 
       [Levels of Decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_erb_repayment#lod)

When conducting fact-finding related to the repayment, the officer reviews the eligibility criteria with the client. If the client reports an FWW or RTW, the officer only asks for the earnings amounts. The FWW and RTW codes do not apply to EI ERB claims, except if the client originally reported them. 

### Levels of decision

Source topic: `en_EN/task/actioning_erb_repayment/levels_of_decision.dita`

The reason for repayment determines if the case is within Level 1 or Level 2 authority:

**Level 1**

- The client earned more than $1 000 over 4 weeks in total , including earnings received from the CEWS.

- The client wants to repay the $2 000 advance payment that was overpaid, because the client received the EI ERB for fewer than 13 weeks.

- The client is not eligible for one or more 2-week periods and a D31 or D47 must be imposed. An OP may only be imposed for an amount that does not exceed the total amount repaid by the client.

- The client received the EI ERB and the CERB from the CRA at the same time.

- The client should have received the CESB instead of the EI ERB.

- The client did not respond to fact-finding attempts, there is not enough information on file related to eligibility or earnings, and a D21 must be imposed.

**Level 2**

- The client voluntarily left employment, refused to return to work or retired, and later received the EI ERB.

- The client is unsure about being eligible for the EI ERB and the reason for repayment falls within Level 2 authority.

- The client clearly refuses the weeks to which the client is eligible for personal or moral reasons.

- The client wants to repay the $2 000 EI ERB advance payment that was overpaid for a reason that falls within Level 2 authority.

If multiple weeks of benefits were repaid, many reasons for repayment can exist on the same file. If at least one of these reasons for repayment is within Level 2 authority, the officer reassigns the WI. When the Level 1 officer cannot adjudicate the issue, the officer documents all the information obtained on the file, then reassigns the WI to Level 2. If the client’s eligibility for the EI ERB must be adjudicated at Level 2, the Level 1 officer documents all the relevant information that will allow the Level 2 officer to adjudicate the client’s eligibility for the EI ERB period.

A Level 1 officer has the authority to impose a D21 on an EI ERB claim when all of the following conditions are met:

- Two attempts have been made to contact the client to clarify the information the client previously provided, those attempts have been unsuccessful, and no return call has been received from the client; and

- There is insufficient information on the file to impose a disentitlement related to ERB eligibility or earnings during the ERB claim; and

- No other contentious issues have been identified that would prevent the Level 1 from imposing the D21. 

### Note

Source topic: `en_EN/common_notes/note_c_1387.dita`

Note:

This procedure applies only to officers trained to process EI ERB repayments.

In addition, this procedure applies only to repayments . It does not include instructions for returned payments, which are processed by specialized teams in each region. For more details on the difference between a repayment and a returned payment, the officer refers to Review of an EI ERB claim .
       [Review of an EI ERB claim](/en/procedure/activity/reviewing_an_ei_erb_claim.shtml)

     [Review of an EI ERB claim](/en/procedure/activity/reviewing_an_ei_erb_claim.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1388.dita`

Note:

The CRA payment information in FTS remains static and has not been updated since December 2020. 

### Note

Source topic: `en_EN/common_notes/note_c_1389.dita`

Note:

The officer uses the EI ERB repayment tool to calculate total income over each 4-week period in originally paid weeks for each 2-week period.
       [EI ERB repayment tool](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Template-EIERBRepaymentTool-Bil-Final.xlsx)

     [EI ERB repayment tool](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Template-EIERBRepaymentTool-Bil-Final.xlsx) 

### Example

Source topic: `en_EN/common_notes/note_c_1390.dita`

Example:

The client worked and had income in weeks in which they received EI ERB payments. The client was not sure of being eligible and repaid $1 500. The officer conducted fact-finding and requested the income amounts.

```text
| W/c | EI ERB Originally Paid | Earnings reported |

| 2230 | Yes | $0 |

| 2231 | Yes | $0 |

| 2232 | Yes | $100 |

| 2233 | Yes | $600 |

| 2234 | No | n/a |

| 2235 | No | n/a |

| 2236 | Yes | $100 |

| 2237 | Yes | $600 |

| 2238 | Yes | $0 |

| 2239 | Yes | $100 |

| 2240 | Yes | $800 |

| 2241 | Yes | $300 |
```

The officer reviews the claim starting from the first originally paid week (w/c 2230). In the first 2-week period (w/c 2230 and 2231), the client did not have any earnings. Therefore, the eligibility requirements under EIA 153.9(1) to have 7 days without work or earnings are met for this period.

- w/c 2230: The EI ERB was paid and the client reported no earnings.

- w/c 2231: The EI ERB was paid and the client reported no earnings.

- w/c 2232: The EI ERB was paid and the client reported earnings of $100.

- w/c 2233: The EI ERB was paid and the client reported earnings of $600.

The officer reviews the next 2-week period (w/c 2232 to 2233) and finds income of $700. Since this is less than the $1 000 threshold, and both weeks in the period were originally paid EI ERB weeks, the officer reviews the preceding originally paid weeks to determine if more income has been reported. The preceding 2-week period (w/c 2230 to 2231) has no income, so the client has met the income loss requirement exception under EIA 153.9(4). The officer does not impose a D47 and does not create an OP.

- w/c 2234: The EI ERB was not paid.

- w/c 2235: The EI ERB was not paid.

- w/c 2236: The EI ERB was paid and the client reported earnings of $100.

- w/c 2237: The EI ERB was paid and the client reported earnings of $600.

The officer does not review w/cs 2234 and 2235 to determine eligibility because these weeks were not originally paid EI ERB weeks.

The officer reviews the next 2-week period (w/c 2236 to 2237) and finds earnings of $700. Since this is less than the $1 000 threshold, the officer reviews the previous originally paid weeks. The EI ERB was not paid in the first previous period (w/c 2234 to 2235), so the officer omits those weeks. The officer reviews the previous weeks (w/c 2232 to 2233) in which there is income of $700.

The total earnings amount is now $1 400. Since this total exceeds $1 000, the officer may need to impose a D47 in the 2-week period under review (w/c 2236 to 2237) to create an OP. The officer does not impose a D47 on the previous 2 weeks that were used in the total earnings in the review (w/c 2232 to 2233) because the period under review is w/cs 2236 and 2237.

- w/c 2238: The EI ERB was paid and the client reported no earnings.

- w/c 2239: The EI ERB was paid and the client reported earnings of $100.

The officer reviews a 2-week period (w/c 2238 to 2239) and finds one week without earnings, therefore the client meets the conditions of 153.9(1).

- w/c 2240: The EI ERB was paid and the client reported earnings of $800.

- w/c 2241: The EI ERB was paid and the client reported earnings of $300.

The officer reviews the 2-week period (w/c 2240 to 2241) and finds earnings of $1 100. Since this amount exceeds the $1 000 threshold, the officer may need to impose a D47 to create an OP. There is no need to review any previous weeks because the earnings have already exceeded the $1 000 threshold. Therefore, the condition under EIA 153.9(4) is not met.

In summary, the officer may need to impose a D47 on w/c 2236, 2237, 2240 and 2241 as these were the 2-week periods under review, and the officer determined that the client did not meet the income loss requirements under EIA 153.9(4) for these periods (i.e. having earnings less than $1 000 in a 4-week period).

Since the client repaid $1 500, which is equal to 3 weeks of the EI ERB, the officer only imposes a D47 on 3 weeks. The officer does not impose the D47 on all 4 weeks in which the client was not eligible to receive the EI ERB. An officer can only create an OP that does not exceed the total amount repaid under EIA 44 to review a repayment made when more than 36 months have elapsed. 

### Note

Source topic: `en_EN/common_notes/note_c_1391.dita`

Note:

For more information and examples related to processing earnings during the EI ERB period, the officer refers to the EI Emergency Response Benefits Digest .
       [EI Emergency Response Benefits Digest](/en/policy/generic/ei_erb_digest.shtml)

     [EI Emergency Response Benefits Digest](/en/policy/generic/ei_erb_digest.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_1392.dita`

Note:

Some clients received the $2 000 EI ERB advance payment, but this payment was never recouped by imposing a D65 on 4 weeks. To create the OPs for this situation, reconciliation utilities for the $2 000 EI ERB advance payment have been run on claims for the EI ERB. 

### Note

Source topic: `en_EN/common_notes/note_c_1393.dita`

Note:

If, after the repayment has been applied to the client’s account, a credit of less than $500 remains, this credit is automatically paid to the client. No further action is required. 

## Regional considerations

Source topic: `en_EN/task/actioning_erb_repayment/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actioning_erb_repayment/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/actioning_erb_repayment/in_nws.dita`

- Is there a WI for the repayment or for the T4E?

- Is there an SROC, a record of decision (ROD) or another document for the repayment or the T4E that provides information about the repayment? 

### In FTS:

Source topic: `en_EN/task/actioning_erb_repayment/in_fts.dita`

- Is there already an OP?

- What is the claim status (CS)?

- For which weeks did the client receive the EI ERB?

- Is the number of payable weeks of the EI ERB fewer than 13?

- Is there information on the $2 000 EI ERB advance payment in the EI ERB $2000 section of the Emergency Response Benefits screen?

- Which code shows in the Lump sum payment modification field in the EI ERB $2000 section of the Emergency Response Benefits screen?

- Did the client receive payments from the CRA? 

### In DARS:

Source topic: `en_EN/task/actioning_erb_repayment/in_dars.dita`

- Is there a transaction with account type 1345 - EI Emergency response Benefits or 1346 - CERB Advance Payment ? 

### In PSCD:

Source topic: `en_EN/task/actioning_erb_repayment/in_pscd.dita`

- Is there a contract object ERB1 - Emergency Response Benefits or ERB2 - CERB Advance payment ? 

## Step by step

Source topic: `en_EN/task/actioning_erb_repayment/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/actioning_erb_repayment/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_erb_repayment/reviewing_the_file_level_1.dita`

- In NWS, determine if there is any other outstanding WI related to the repayment:

- If no, go to step 2.

- If yes, assign the WI to yourself and go to step 2.

- Determine if all required information to determine eligibility is on file, if fact-finding was already completed and if all of the following required information is documented:

- the amount and reason for repayment;

- the weeks the client repaid or reports not being eligible for;

- the earnings in the period under review;

- the client’s current address and direct deposit information are confirmed in case they repaid in excess or in error.

- If no, go to step 3.

- If yes, go to step 6. 

#### Fact-finding

Source topic: `en_EN/task/actioning_erb_repayment/fact-finding_level_1.dita`

- Fact-find with the client.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 5.

- If the client was not reached, go to step 6.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “EI ERB repayment.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the claim can be processed with the information on file:

- If yes, go to step 7.

- If no and the client was not reached for fact-finding, go to Client was not reached .
               [Client was not reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_erb_repayment#level1_item_5) 

#### Reviewing the repayment

Source topic: `en_EN/task/actioning_erb_repayment/reviewing_the_repayment.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1394.dita) 

#### Reviewing eligibility

Source topic: `en_EN/task/actioning_erb_repayment/reviewing_eligibility_level_1.dita`

- Examine each 2-week EI ERB period. Determine if the client meets one of the definitions of claimant under EIA 153.5 (2) for each period:

- If yes, go to step 11.

- If no, note any period in which a D31 may apply for the claim under review. Go to Imposing a disentitlement .
               [Imposing a disentitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_erb_repayment#_Imposing_a_disentitlement)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1395.dita)

- Review Chapter 4 - Eligibility in the EI Emergency Response Benefit Digest to determine if, for each 2-week period, the client meets the eligibility criteria related to the corresponding definition of a claimant under EIA 153.9 (1) (a)(i), (ii) and (iii) or EIA 153.9(1)(c)(i), (ii) and (iii):

- If yes, go to step 12.

- If no, a D31 may be required. Take note of the 2-week periods in which a D31 may be imposed and go to step 12.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1396.dita)

- Open the EI ERB Repayment tool and enter the information in the appropriate fields (BPC, last week of the EI ERB paid, D31 weeks, unpaid FWW or RTW weeks, weeks originally reported and earnings). The tool identifies each 2-week period under review and the corresponding total earnings for that period to determine if there are periods in which a D47 may be required when the criteria of the EIA 153.9(4) are not met.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1397.dita)

- Based on the EI ERB repayment tool information for each 2-week period, determine if the client meets the eligibility requirements related to work and earnings under EIA 153.9(1) (a)(iv), (v), EIA 153.9(1)(b) or 153.9(1)(c)(iv):

- If the client does not meet all requirements in any 2-week period, go to step 14.

- If the client meets all requirements in all the 2-week periods, go to step 15.

- Based on the EI ERB repayment tool information, determine if the client meets the income loss exception for any of the 2-week periods under EIA 153.9(4) and had $1 000 or less in earnings over a 4-week period:

- If the client meets the income loss exception, go to step 16.

- If the client does not meet the income loss exception, a D47 may be required. Take note of the D47 periods and go to step 15.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1398.dita)

- Determine if a D31 or D47 must be input:

- If no, go to step 16.

- If yes, go to Imposing a disentitlement .
               [Imposing a disentitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_erb_repayment#level1_item_6)

- Determine if a credit of $500 or more will remain in PSCD after the repayment is applied to the client’s account:

- If no, go to step 17.

- If yes, go to Repayment made in excess or in error .
               [Repayment made in excess or in error](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_erb_repayment#level1_item_9)

- Complete the WI. No further action is required. 

#### Client was not reached

Source topic: `en_EN/task/actioning_erb_repayment/client_was_not_reached_level_1.dita`

- In NWS, add details to the draft SROC as follows:

- Details: Type “No return call from the client.”

- Select Save .

- Create a ROD as follows:

- Comments: Type “Unable to reach client — 21 - Claimant refuses payment disentitlement (D21) imposed from w/c [XXXX-X] to [XXXX-X].”

- Details: Choose the appropriate option:

- If a D21 is imposed for a period equal to the repayment amount, type: “Attempts to reach the client were made on [date and time] and [date and time of second call or date the letter or email was sent]. Client did not contact Service Canada and additional information is required. A 21 - Claimant refuses payment disentitlement (D21) is imposed from w/c [XXXX] to w/c [XXXX] / [add other periods, if necessary]. The D21 imposed equals the amount repaid by the client. The client’s eligibility for the EI ERB has not been evaluated. This repayment was accepted under the authority provided under EIA 44. An amended T4E will be issued to the client.”

- If an amount of the repayment remains and must be returned to the client, type: “Attempts to reach the client were made on [date and time] and [date and time of second call or date the letter or email wase sent]. Client did not contact Service Canada and additional information is required. A 21 - Claimant refuses payment disentitlement (D21) is imposed from w/c [XXXX] to w/c [XXXX] / [add other periods, if necessary]. The D21 imposed does not equal the amount repaid by the client. Any amount repaid in excess will be credited to the client. The client’s eligibility for the EI ERB has not been evaluated. This repayment was accepted under the authority provided under EIA 44. An amended T4E will be issued to the client.”

- Select Save .

- In FTS, determine the blocked status by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed, go to step 10.

- If any other status is displayed, go to step 21.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 11.

- If all rows are blank, go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1399.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable status in BCS.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 11.

- If all rows are blank, go to step 13.

- Select the BPC that must be updated from the Benefit Period Commencement column. When the Blocked Claim screen opens, complete the following fields:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised (or 2 - Renewal , if necessary).

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- In BCS, on the Disentitlements tab, in the Disentitlements section, enter the D21 as follows:

- Action: Select A - Add .

- Type: Select 21 - Claimant refuses payment .

- Start Date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or type “ 9999” if the end date is indefinite.

- Detection: Select 31 - Other new facts entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Complete: Select D - No

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1400.dita)

- On the Pending Transactions tab, review the transaction:

- If the transaction displayed is incorrect, go to step 16.

- If the transaction displayed is correct, select Close and go to step 17.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Select Close .

- Return to step 13.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Moved to Pending to check for BCS reject.”

- Bring forward date: Enter the next business day.

- In FTS, when the WI moves to the current workload, determine if there is a B112 or B100 error code for the BCS inputs:

- If yes, go to step 19.

- If no go to step 24.

- In BCS, select the appropriate BPC that shows Yes in the Results column and do the following:

- Select the Results tab.

- Select the BPC with the estimated result that must be sent to IPOC and select the Forward via MM06 link.

- When the Renewal/Revised (M106) screen opens, do the following:

- Registration number: Select the appropriate registration number.

- Contentious: Select 1 - No .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Complete: Select D - No .

- Select Update .

- When the pre-filled Operational Centre Memo (MM06) transaction opens, do the following:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 92 - Purge and Recreate .

- Work type: Select 59 - Legislative interim measures .

- Remarks line 1–4: After the pre-filled information, type: “[B112 or B100] error. EI ERB repayment of $[amount repaid].”

- Select Update .

- Go to step 23.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: select 92 - Purge and Recreate .

- Work type: select 59 - Legislative interim measures .

- Remarks line 1: Type “Client not reached — Repayment of $[total repayment amount].”

- Remarks lines 2–4: Type “Impose D21 from w/c [XXXX] to w/c [XXXX].” If there are other periods of D21, add the information for each period in the same way.

- Remarks line 5: Enter your first name and last name.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- Determine if a credit of $500 or more will remain in PSCD after the repayment is applied to the client’s account:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1401.dita)

- In NWS, move the WI to Pending as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1402.dita)

- When the WI moves to the current workload, determine if the client’s account in PSCD shows the processed transactions, and if only the credit balance remains on file:

- If no, repeat step 25.

- If yes, go to step 27.

- Determine if a new address for the client has been documented on the file:

- If yes, refer to Change of address and then go to step 28 of this procedure.
               [Change of address](/en/procedure/activity/change_address.shtml)

- If no, go to step 28.

- Determine if the client has provided new direct deposit information:

- If yes, refer to Direct deposit and then go to step 29 of this procedure.
               [Direct deposit](/en/procedure/activity/direct_deposit.shtml)

- If no, go to step 29.

- Send a request to NAR using the iService Catalogue by completing the National Accounting Operations - Request for Refund on Accounts Receivable template as follows:

- Preferred Language: Select the client’s preferred language.

- Request type: Select the appropriate option:

- Select Request from Member of Parliament if any of the following are on file:

- an enquiry from a member of Parliament;

- a request from the Office for Client Satisfaction;

- a dire needs situation in which the delay in obtaining the T4E is leading to dire financial difficulties (e.g. obtaining food or lodging, repaying an incorrect tax amount, or because a large amount is owed to the client).

- Select Payment received in error by our department in all other situations.

- Origin of the request: Select Citizen (call-center, in-person…) .

- Program: Select EI - Employment Insurance .

- ID Type: Select Social Insurance Number (SIN) .

- ID Number: Enter the client’s SIN.

- Address to refund: Select Other (please specify in Additional information field) .

- Amount: Enter the amount that the client repaid in error, the remaining amount or the amount to send to the CRA.

- Additional information: Enter the appropriate information:

- For a repayment made in excess or in error of $500 or more, do the following:

- Type “Officer authorized to process benefit repayments [client’s address as shown in FTS] — the client repaid the EI ERB, but after verification, the client was eligible during this period. No other OP must be created on file. Repay $[XXX] to the client.”

- If the direct deposit information in FTS is up to date, also type “Issue the payment by direct deposit.”

- If, in addition to repaying the client, IPOC must create an OP on the file, also type “IPOC must create an OP of $[XXX].”

- For a repayment made in error to Service Canada instead of to the CRA or when the OP is or will be created with the CRA, do the following:

- Type “Officer authorized to process benefit repayments [client’s address as shown in FTS] — the client repaid an amount of $[amount] to Service Canada, but after verification, the repayment must be transferred to the CRA. No other OP on file. Transfer the pending amount of $[amount] to the CRA.”

- If the request type chosen is Request from Member of Parliament , also type “[Request from member of Parliament, Request from Office for Client Satisfaction or Dire needs]. Process urgently and submit SOBR to IPOC as a priority.”

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main issue: Select Other .

- Comments: Type “Request to reimburse the client sent to National Accounts Receivable.”

- Details: Enter the appropriate details:

- For a repayment made in excess or in error, type “EI Emergency Response Benefit repayment made in excess or in error by the client. The client must be repaid. A request for refund was sent to National Accounts Receivable. iService reference number [XXXX].”

- For a repayment made in error to Service Canada instead of the CRA, type “EI ERB repayment made in error to Service Canada instead of the Canada Revenue Agency. The monies must be transferred to the Canada Revenue Agency. A request for refund was sent to National Accounts Receivable. iService reference number [XXXX].”

- Select Save .

- Complete the WI. 

#### Imposing a disentitlement

Source topic: `en_EN/task/actioning_erb_repayment/imposing_a_disentitlement_level_1.dita`

- Determine if the amount of the OP to impose is more than the amount repaid by the client:

- If yes, use the EI ERB repayment tool or calculate the number of weeks for which the OP can be imposed without exceeding the amount repaid and go to step 2.
               [EI ERB repayment tool](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Template-EIERBRepaymentTool-Bil-Final.xlsx)

- If no, go to step 2.

- In NWS, document the decision based on which disentitlement is required:

- If a D31 is required input, go to step 3.

- If only a D47 is required, go to step 4.

- Create a ROD for the period for which the client was not eligible for the EI ERB as follows:

- Comments: If a D31 was imposed, type “31 - EI ERB entitlement conditions not met. Disentitlement imposed from w/c [XXXX] to w/c [XXXX].”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy . Type:
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1403.dita) 
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- If a D47 is required, go to step 4.

- If no other ROD is required, go to step 5.

- In NWS, create a ROD for the periods under review. Each 2-week period that requires a D47 must be detailed:

- Comments: Type “Earnings reviewed for w/cs [XXXX] to [XXXX].”

- Details: Document any additional information along with the decision and rationale according to the National Fact-Finding and Documentation Policy . Type:
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1404.dita) 
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if a found work code needs to be removed from the client’s original claimant’s reports to apply a credit:

- If no, go to step 6.

- If yes, go to step 18.

- In FTS, determine the blocked status by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed go to step 7.

- If any other status is displayed, go to step 18.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 8.

- If all rows are blank, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1399.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable status in BCS.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 8.

- If all rows are blank, go to step 10.

- Select the BPC that must be updated from the Benefit Period Commencement column. When the Blocked Claim screen opens, complete the following fields:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1405.dita)

- In BCS, on the Disentitlements tab, in the Disentitlements section, enter the disentitlement as follows:

- Action: Select A - Add .

- Type: Select the appropriate option:

- 31 - EI ERB entitlement conditions not met

- 47 - EI ERB - Earnings limit exceeded for the four week period

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Select Update .

- Rescind any FWW and remove earnings from the claimant’s reports if there is a credit.

- Repeat, if necessary, and impose up to 4 required disentitlements per day.

- In BCS, on the Pending Transactions tab, review the transaction:

- If the transaction displayed is incorrect, go to step 13.

- If the transaction displayed is correct, select Close and go to step 14.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Select Close .

- Return to step 10.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Moved to Pending to check for BCS reject.”

- Bring forward date: Enter the next business day.

- In FTS, when the WI moves to the current workload, determine if there is a B112 or B100 error code for the BCS inputs:

- If yes, go to step 16.

- If no go to step 21.

- In BCS, select the appropriate BPC that shows Yes in the Results column and do the following:

- Select the Results tab.

- Select the estimated result that must be sent to IPOC and select the Forward via MM06 link.

- When the Renewal/Revised (M106) screen opens, do the following:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Complete: Select D - No .

- Select Update .

- When the pre-filled Operational Centre Memo (MM06) transaction opens, do the following:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 92 - Purge and Recreate .

- Work type: Select 59 - Legislative interim measures .

- Remarks line 1-4: After the pre-filled information, type “[B112 or B100] error. EI ERB repayment of $[amount repaid].” If an FWW must be removed, also type “Apply UP to OP.”

- Select Update .

- Go to step 20.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: select 92 - Purge and Recreate .

- Work type: select 59 - Legislative interim measures .

- Remarks line 1: Type “Client not eligible — EI ERB Repayment of $[repayment amount].”

- Remarks lines 2–4: Type “Impose [D47 or D31] from w/c [XXXX] to w/c [XXXX].” If there are other periods that require a D47 or D31, add the information for each period in the same way.

- If an FWW must be removed, also type “Remove FWW from w/c [XXXX]. Apply UP to OP.”

- If a found work code must be removed, also type “Remove found work code from w/c [XXXX]. Apply UP to OP.”

- Remarks line 5: Enter your first name and last name.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and send the F-00-00-01 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Text: Free text (1612): Type “We are writing concerning the Canada Emergency Response Benefit (CERB) you received from Service Canada.”

- If a D31 was imposed , type “You have indicated not being eligible for [X] week[s] of the CERB by repaying some or all of the amount received. As a result, we have created an overpayment on your claim from [DD-MM-YYYY] to [DD-MM-YYYY].” If there is more than one D31 period , also type: “and from [DD-MM-YYYY] to [DD-MM-YYYY].” For all D31 cases , also type: “The amount of $[XXXX] you repaid will be used to cover this overpayment, so you will not owe anything further.”

- If a D47 was imposed , type: “According to subsection 153.9(1) of the Employment Insurance Act (EIA), to be eligible for the CERB, you must have had at least seven consecutive days with no income from employment or self-employment within the two-week period you claimed the benefit. If this condition was not met, then according to subsection 153.9(4) of the EIA, you could have been eligible for the CERB if you did not earn more than $1,000 over a four-week period, even if those weeks were not consecutive. We have determined you were not eligible for the CERB payments you received from [DD-MM-YYYY] to [DD-MM-YYYY].” If there is more than one D47 period , also type: “and from [DD-MM-YYYY] to [DD-MM-YYYY].” For all D47 cases, also type: “As a result, we have created an overpayment on your claim. The amount of $[XXXX] you repaid will be used to cover this overpayment, so you will not owe anything further.”

- For all cases , also type “If you made CERB repayments in previous years, an amended T4E slip will be issued for the year in which the repayment was made. You may have to request a reassessment of that year's income tax return because of the amended T4E slip. For information on how to change your tax return, visit canada.ca/change-tax-return. For any questions on your T4E, visit canada.ca/ei and consult Employment Insurance Tax Slips (T4Es) . If you are filing an income tax return with Revenu Québec, visit revenuquebec.ca.”

- Right to Request a Reconsideration (4169): Select Right to Request a Reconsideration .

- Determine if a credit of $500 or more will remain in PSCD after the repayment is applied to the client’s account:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1401.dita)

- In NWS, move the WI to Pending as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1402.dita)

- When the WI moves to the current workload, determine if the client’s account in PSCD shows the processed transactions, and if only the credit balance remains on file:

- If no, repeat step 23.

- If yes, go to step 25.

- Determine if a new address for the client has been documented on the file:

- If yes, refer to Change of address and then go to step 26 of this procedure.
               [Change of address](/en/procedure/activity/change_address.shtml)

- If no, go to step 26.

- Determine if the client has provided new direct deposit information:

- If yes, refer to Direct deposit and then go to step 27 of this procedure.
               [Direct deposit](/en/procedure/activity/direct_deposit.shtml)

- If no, go to step 27.

- Send a request to NAR using the iService Catalogue by completing the National Accounting Operations - Request for Refund on Accounts Receivable template as follows:

- Preferred Language: Select the client’s preferred language.

- Request type: Select the appropriate option:

- Select Request from Member of Parliament if any of the following are on file:

- an enquiry from a member of Parliament;

- a request from the Office for Client Satisfaction;

- a dire needs situation in which the delay in obtaining the T4E is leading to dire financial difficulties (e.g. obtaining food or lodging, repaying an incorrect tax amount, or because a large amount is owed to the client).

- Select Payment received in error by our department in all other situations.

- Origin of the request: Select Citizen (call-center, in-person…) .

- Program: Select EI - Employment Insurance .

- ID Type: Select Social Insurance Number (SIN) .

- ID Number: Enter the client’s SIN.

- Address to refund: Select Other (please specify in Additional information field) .

- Amount: Enter the amount that the client repaid in error, the remaining amount or the amount to send to the CRA.

- Additional information: Enter the appropriate information:

- For a repayment made in excess or in error of $500 or more, do the following:

- Type “Officer authorized to process benefit repayments [client’s address as shown in FTS] — the client repaid the EI ERB, but after verification, the client was eligible during this period. No other OP must be created on file. Repay $[XXX] to the client.”

- If the direct deposit information in FTS is up to date, also type “Issue the payment by direct deposit.”

- If, in addition to repaying the client, IPOC must create an OP on the file, also type “IPOC must create an OP of $[XXX].”

- For a repayment made in error to Service Canada instead of to the CRA or when the OP is or will be created with the CRA, do the following:

- Type “Officer authorized to process benefit repayments [client’s address as shown in FTS] — the client repaid an amount of $[amount] to Service Canada, but after verification, the repayment must be transferred to the CRA. No other OP on file. Transfer the pending amount of $[amount] to the CRA.”

- If the request type chosen is Request from Member of Parliament , also type “[Request from member of Parliament, Request from Office for Client Satisfaction or Dire needs]. Process urgently and submit SOBR to IPOC as a priority.”

- Select Save .

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main issue: Select Other .

- Comments: Type “Request to reimburse the client sent to National Accounts Receivable.”

- Details: Enter the appropriate details:

- For a repayment made in excess or in error, type “EI Emergency Response Benefit repayment made in excess or in error by the client. The client must be repaid. A request for refund was sent to National Accounts Receivable. iService reference number [XXXX].”

- For a repayment made in error to Service Canada instead of the CRA, type “EI ERB repayment made in error to Service Canada instead of the Canada Revenue Agency. The monies must be transferred to the Canada Revenue Agency. A request for refund was sent to National Accounts Receivable. iService reference number [XXXX].”

- Select Save .

- Complete the WI. 

#### Modifying the advance payment overpayment (OP)

Source topic: `en_EN/task/actioning_erb_repayment/modifying_the_advance_payment_overpayment_op_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Establish advance payment OP] or [Modify advance payment OP].”

- Details: Select the appropriate option:

- Option 1: Type “The client has repaid the $2 000 advance payment. The client was eligible during w/c [XXXX] to [XXXX] and [XXXX] to [XXXX] when the 65 - Lump Sum Payment ($2000) - Canadian Emergency Response code (D65) was imposed on the claim. The client is eligible for [$ XXX] of the advance payment. An Operational Centre Memo (MM06) has been sent to IPOC to have the overpayment (OP) established.”

- Option 2: Type “The client has repaid the $2 000 advance payment. The client was eligible during w/c [XXXX] to [XXXX] and [XXXX] to [XXXX] when the 65 - Lump Sum Payment ($2000) - Canadian Emergency Response code (D65) was imposed on the claim. The client is eligible for $[XXX] of the advance payment. The existing advance payment overpayment (OP) is incorrect and requires modification. An Operational Centre Memo (MM06) has been sent to IPOC to establish the correct OP.

- Select Save .

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 45 - You are not entitled to EI Emergency Response Benefits, this caused an overpayment .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 92 - Purge and Recreate .

- Work type: Select 59 - Legislative interim measures .

- Remarks line 1: Type “Client not eligible for $2 000 advance payment.”

- Remarks lines 2–4: Do the following:

- To establish an advance payment OP, type “EI ERB Repayment of $[repayment amount] received by NAR . Establish ERB2 OP for unserved D65 for $[XXXX] as an OP. 31-F-46.”

- To establish the missing portion of the advance payment OP, type “ERB2 repayment of $[repayment amount] received by NAR. Establish missing portion of ERB 2 OP for unserved D65 for $[amount of missing portion] and update lump sum modification code 31-F-46.”

- Remarks line 5: Enter your first name and last name.

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and send the F-00-00-01 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Text: Free text (1612): Type “We are writing concerning the Canada Emergency Response Benefit (CERB) you received from Service Canada. You have indicated not being eligible for [X] week[s] of the CERB by repaying some or all of the amount received. As a result, we have created an overpayment on your claim. The amount of $[XXXX] you repaid will be used to cover this overpayment, so you will not owe anything further. If you made CERB repayments in previous years, an amended T4E slip will be issued for the year in which the repayment was made. You may have to request a reassessment of that year's income tax return because of the amended T4E slip. For information on how to change your tax return, visit canada.ca/change-tax-return. For any questions on your T4E, visit canada.ca/ei and consult Employment Insurance Tax Slips (T4Es) . If you are filing an income tax return with Revenu Québec, visit revenuquebec.ca.”

- Right to Request a Reconsideration (4169): Select Right to Request a Reconsideration .

- Determine if a credit of $500 or more will remain in PSCD after the repayment is applied to the client’s account:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1401.dita)

- In NWS, move the WI to Pending as follows:

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1402.dita)

- When the WI moves to the current workload, determine if the client’s account in PSCD shows the processed transactions, and if only the credit balance remains on file:

- If no, repeat step 16.

- If yes, go to step 18.

- Determine if a new address for the client has been documented on the file:

- If yes, refer to Change of address and then go to step 19 of this procedure.
               [Change of address](/en/procedure/activity/change_address.shtml)

- If no, go to step 19.

- Determine if the client has provided new direct deposit information:

- If yes, refer to Direct deposit and then go to step 20 of this procedure.
               [Direct deposit](/en/procedure/activity/direct_deposit.shtml)

- If no, go to step 20.

- Send a request to NAR using the iService Catalogue by completing the National Accounting Operations - Request for Refund on Accounts Receivable template as follows:

- Preferred Language: Select the client’s preferred language.

- Request type: Select the appropriate option:

- Select Request from Member of Parliament if any of the following are on file:

- an enquiry from a member of Parliament;

- a request from the Office for Client Satisfaction;

- a dire needs situation in which the delay in obtaining the T4E is leading to dire financial difficulties (e.g. obtaining food or lodging, repaying an incorrect tax amount, or because a large amount is owed to the client).

- Select Payment received in error by our department in all other situations.

- Origin of the request: Select Citizen (call-center, in-person…) .

- Program: Select EI - Employment Insurance .

- ID Type: Select Social Insurance Number (SIN) .

- ID Number: Enter the client’s SIN.

- Address to refund: Select Other (please specify in Additional information field) .

- Amount: Enter the amount that the client repaid in error, the remaining amount or the amount to send to the CRA.

- Additional information: Enter the appropriate information:

- For a repayment made in excess or in error of $500 or more, do the following:

- Type “Officer authorized to process benefit repayments [client’s address as shown in FTS] — the client repaid the EI ERB, but after verification, the client was eligible during this period. No other OP must be created on file. Repay $[XXX] to the client.”

- If the direct deposit information in FTS is up to date, also type “Issue the payment by direct deposit.”

- If, in addition to repaying the client, IPOC must create an OP on the file, also type “IPOC must create an OP of $[XXX].”

- For a repayment made in error to Service Canada instead of to the CRA or when the OP is or will be created with the CRA, do the following:

- Type “Officer authorized to process benefit repayments [client’s address as shown in FTS] — the client repaid an amount of $[amount] to Service Canada, but after verification, the repayment must be transferred to the CRA. No other OP on file. Transfer the pending amount of $[amount] to the CRA.”

- If the request type chosen is Request from Member of Parliament , also type “[Request from member of Parliament, Request from Office for Client Satisfaction or Dire needs]. Process urgently and submit SOBR to IPOC as a priority.”

- Select Save .

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main issue: Select Other .

- Comments: Type “Request to reimburse the client sent to National Accounts Receivable.”

- Details: Enter the appropriate details:

- For a repayment made in excess or in error, type “EI Emergency Response Benefit repayment made in excess or in error by the client. The client must be repaid. A request for refund was sent to National Accounts Receivable. iService reference number [XXXX].”

- For a repayment made in error to Service Canada instead of the CRA, type “EI ERB repayment made in error to Service Canada instead of the Canada Revenue Agency. The monies must be transferred to the Canada Revenue Agency. A request for refund was sent to National Accounts Receivable. iService reference number [XXXX].”

- Select Save .

- Complete the WI. 

#### Completing the WI

Source topic: `en_EN/task/actioning_erb_repayment/completing_the_wi_level_1.dita`

- Determine if a credit of $500 or more will remain in PSCD after the repayment is applied to the client’s account:

- If no, complete the WI. No further action is required.

- If yes, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1401.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for OP and repayment to be applied in PSCD. Credit of $ [XXXX] should remain on file.”

- Bring forward date: Enter [today’s date + 7 business days].

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1402.dita)

- When the WI moves to the current workload, determine if the client’s account in PSCD shows the processed transactions, and if only the credit balance remains on file:

- If no, repeat step 2.

- If yes, go to step 4.

- Determine if a new address for the client has been documented on the file:

- If yes, refer to Change of address and then go to step 5 of this procedure.
               [Change of address](/en/procedure/activity/change_address.shtml)

- If no, go to step 5.

- Determine if the client has provided new direct deposit information:

- If yes, refer to Direct deposit and then go to step 6 of this procedure.
               [Direct deposit](/en/procedure/activity/direct_deposit.shtml)

- If no, go to step 6.

- Send a request to NAR using the iService Catalogue by completing the National Accounting Operations - Request for Refund on Accounts Receivable template as follows:

- Preferred Language: Select the client’s preferred language.

- Request type: Select the appropriate option:

- Select Request from Member of Parliament if any of the following are on file:

- an enquiry from a member of Parliament;

- a request from the Office for Client Satisfaction;

- a dire needs situation in which the delay in obtaining the T4E is leading to dire financial difficulties (e.g. obtaining food or lodging, repaying an incorrect tax amount, or because a large amount is owed to the client).

- Select Payment received in error by our department in all other situations.

- Origin of the request: Select Citizen (call-center, in-person…) .

- Program: Select EI - Employment Insurance .

- ID Type: Select Social Insurance Number (SIN) .

- ID Number: Enter the client’s SIN.

- Address to refund: Select Other (please specify in Additional information field) .

- Amount: Enter the amount that the client repaid in error, the remaining amount or the amount to send to the CRA.

- Additional information: Enter the appropriate information:

- For a repayment made in excess or in error of $500 or more, do the following:

- Type “Officer authorized to process benefit repayments [client’s address as shown in FTS] — the client repaid the EI ERB, but after verification, the client was eligible during this period. No other OP must be created on file. Repay $[XXX] to the client.”

- If the direct deposit information in FTS is up to date, also type “Issue the payment by direct deposit.”

- If, in addition to repaying the client, IPOC must create an OP on the file, also type “IPOC must create an OP of $[XXX].”

- For a repayment made in error to Service Canada instead of to the CRA or when the OP is or will be created with the CRA, do the following:

- Type “Officer authorized to process benefit repayments [client’s address as shown in FTS] — the client repaid an amount of $[amount] to Service Canada, but after verification, the repayment must be transferred to the CRA. No other OP on file. Transfer the pending amount of $[amount] to the CRA.”

- If the request type chosen is Request from Member of Parliament , also type “[Request from member of Parliament, Request from Office for Client Satisfaction or Dire needs]. Process urgently and submit SOBR to IPOC as a priority.”

- Select Save .

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main issue: Select Other .

- Comments: Type “Request to reimburse the client sent to National Accounts Receivable.”

- Details: Enter the appropriate details:

- For a repayment made in excess or in error, type “EI Emergency Response Benefit repayment made in excess or in error by the client. The client must be repaid. A request for refund was sent to National Accounts Receivable. iService reference number [XXXX].”

- For a repayment made in error to Service Canada instead of the CRA, type “EI ERB repayment made in error to Service Canada instead of the Canada Revenue Agency. The monies must be transferred to the Canada Revenue Agency. A request for refund was sent to National Accounts Receivable. iService reference number [XXXX].”

- Select Save .

- Complete the WI. 

#### Repayment made in excess or in error

Source topic: `en_EN/task/actioning_erb_repayment/repayment_made_in_excess_or_in_error_level_1.dita`

- Determine if the client repaid Service Canada instead of the CRA:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the repayment is displayed on the payment in suspense list or as a credit in PSCD:

- If yes, go to 7.

- If no, the repayment was already transferred to the CRA. Complete the WI.

- Determine if a credit of $500 or more will remain in PSCD after the repayment is applied to the client’s account:

- If no, complete the WI. No further action is required.

- If yes, go to step 4.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1401.dita)

- In PSCD, determine if the client’s account shows the processed transactions, and if only the credit balance of $500 or more remains on file:

- If no, go to step 5.

- If yes, go to step 7.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for OP and repayment to be applied in PSCD. Credit of $ [XXXX] should remain on file.”

- Bring forward date: Enter [today’s date + 7 business days].

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1402.dita)

- When the WI moves to the current workload, determine if the client’s account in PSCD shows the processed transactions, and if only the credit balance remains on file:

- If no, repeat step 5.

- If yes, go to step 7.

- Determine if a new address for the client has been documented on the file:

- If yes, refer to Change of address and then go to step 8 of this procedure.
               [Change of address](/en/procedure/activity/change_address.shtml)

- If no, go to step 8.

- Determine if the client has provided new direct deposit information:

- If yes, refer to Direct deposit and then go to step 9 of this procedure.
               [Direct deposit](/en/procedure/activity/direct_deposit.shtml)

- If no, go to step 9.

- Send a request to NAR using the iService Catalogue by completing the National Accounting Operations - Request for Refund on Accounts Receivable template as follows:

- Preferred Language: Select the client’s preferred language.

- Request type: Select the appropriate option:

- Select Request from Member of Parliament if any of the following are on file:

- an enquiry from a member of Parliament;

- a request from the Office for Client Satisfaction;

- a dire needs situation in which the delay in obtaining the T4E is leading to dire financial difficulties (e.g. obtaining food or lodging, repaying an incorrect tax amount, or because a large amount is owed to the client).

- Select Payment received in error by our department in all other situations.

- Origin of the request: Select Citizen (call-center, in-person…) .

- Program: Select EI - Employment Insurance .

- ID Type: Select Social Insurance Number (SIN) .

- ID Number: Enter the client’s SIN.

- Address to refund: Select Other (please specify in Additional information field) .

- Amount: Enter the amount that the client repaid in error, the remaining amount or the amount to send to the CRA.

- Additional information: Enter the appropriate information:

- For a repayment made in excess or in error of $500 or more, do the following:

- Type “Officer authorized to process benefit repayments [client’s address as shown in FTS] — the client repaid the EI ERB, but after verification, the client was eligible during this period. No other OP must be created on file. Repay $[XXX] to the client.”

- If the direct deposit information in FTS is up to date, also type “Issue the payment by direct deposit.”

- If, in addition to repaying the client, IPOC must create an OP on the file, also type “IPOC must create an OP of $[XXX].”

- For a repayment made in error to Service Canada instead of to the CRA or when the OP is or will be created with the CRA, do the following:

- Type “Officer authorized to process benefit repayments [client’s address as shown in FTS] — the client repaid an amount of $[amount] to Service Canada, but after verification, the repayment must be transferred to the CRA. No other OP on file. Transfer the pending amount of $[amount] to the CRA.”

- If the request type chosen is Request from Member of Parliament , also type “[Request from member of Parliament, Request from Office for Client Satisfaction or Dire needs]. Process urgently and submit SOBR to IPOC as a priority.”

- Select Save .

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main issue: Select Other .

- Comments: Type “Request to reimburse the client sent to National Accounts Receivable.”

- Details: Enter the appropriate details:

- For a repayment made in excess or in error, type “EI Emergency Response Benefit repayment made in excess or in error by the client. The client must be repaid. A request for refund was sent to National Accounts Receivable. iService reference number [XXXX].”

- For a repayment made in error to Service Canada instead of the CRA, type “EI ERB repayment made in error to Service Canada instead of the Canada Revenue Agency. The monies must be transferred to the Canada Revenue Agency. A request for refund was sent to National Accounts Receivable. iService reference number [XXXX].”

- Select Save .

- Complete the WI. 

#### Reassigning the file to Level 2

Source topic: `en_EN/task/actioning_erb_repayment/reassigning_the_file_to_level_2_level_1.dita`

- In NWS, reassign the WI as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Enter the reason for reassigning to Level 2.

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1394.dita`

Note:

If the client repaid the CRA in error, the client must contact the CRA directly, as only the CRA has the authority and access to information about this repayment. 

#### Note

Source topic: `en_EN/common_notes/note_c_1395.dita`

Note:

Review all 2-week periods included in the EI ERB claim to determine if the eligibility criteria are met for each period and note if a disentitlement may apply. 

#### Note

Source topic: `en_EN/common_notes/note_c_1396.dita`

Note:

Clients may fail to meet the eligibility criteria for one or more 2-week periods but may successfully meet the eligibility criteria in other 2-week periods. For example, a client who is 14 years old in w/c 2230 is ineligible. However, if the client turns 15 in w/c 2233, the client would meet the age criteria. In this situation, impose a D31 for any weeks in which the client did not meet the eligibility criteria before w/c 2233. 

#### Note

Source topic: `en_EN/common_notes/note_c_1397.dita`

Note:

When using the EI ERB repayment tool , review the instructions found in the blue box to ensure that information is input accurately and that the results are interpreted correctly.
       [EI ERB repayment tool](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Template-EIERBRepaymentTool-Bil-Final.xlsx)

     [EI ERB repayment tool](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Template-EIERBRepaymentTool-Bil-Final.xlsx) 

#### Note

Source topic: `en_EN/common_notes/note_c_1398.dita`

Note:

The 4-week period being examined for earnings exceeding $1 000 includes the 2-week period currently under review and the closest previous weeks for which the EI ERB was originally paid. When earnings in the 4-week period exceed $1 000, impose the disentitlement to the 2-week period under review only. A week with a D65 or a week used to reconcile the advance payment OP is considered a week in which the EI ERB was originally paid. 

#### Note

Source topic: `en_EN/common_notes/note_c_1399.dita`

Note:

In BCS, only one BPC can be updated at a time. 

#### Note

Source topic: `en_EN/common_notes/note_c_1400.dita`

Note:

In BCS, up to 4 disentitlements can be imposed, rescinded or terminated each day. 

#### Note

Source topic: `en_EN/common_notes/note_c_1401.dita`

Note:

When a credit of less than $500 remains in PSCD after the repayment is applied to the client’s account, the credit is automatically paid to the client and no further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_1402.dita`

Note:

When an OP has been imposed on the EI ERB claim and a credit of $500 or more will remain on file, move the WI to Pending for 7 business days or until the transactions have processed. Confirm that only the credit balance remains in PSCD before sending an iService request to return a credit of $500 or more to the client. 

#### Callout

Source topic: `en_EN/common_notes/note_c_1403.dita`

“ RELEVANT FACTS:

The client, of [their own initiative, repaid the amount of $[XXX] to the Commission. This amount corresponds to [X] week[s] of the EI Emergency Response Benefit received.

The client repaid this amount because [reason for repayment and additional details, if necessary].

DECISION AND REASONING:

The client is not eligible for the EI Emergency Response Benefit from [DD-MM-YYYY] to [DD-MM-YYYY] under Employment Insurance Act 153.9. Since the client repaid [X] week[s] of benefits of [their own initiative, the client is considered to have automatically identified [themselves, himself or herself] as not eligible for benefits for this period. A 31 - EI ERB entitlement conditions not met disentitlement has been imposed from [DD-MM-YYYY] to [DD-MM-YYYY].

A written notice was sent to advise the client that an overpayment was created, and that the repayment was applied against it.”

- If the client repaid the entire amount of benefits except for the $2 000 advance payment , in the Relevant Facts section, type “The client did not repay the $2 000 advance benefits payment. This amount is therefore not included in this decision.” 

#### Callout

Source topic: `en_EN/common_notes/note_c_1404.dita`

“ RELEVANT FACTS:

The client, of [their own initiative, repaid the amount of $[XXX] to the Commission. This amount corresponds to [X] week[s] of the EI Emergency Response Benefit received.

The client repaid this amount because [reason for repayment and additional details, if necessary].

DECISION AND REASONING:

Earnings exceed $1 000 in the 4-week period of the EI Emergency Response Benefit paid from w/c [XXXX] to w/c [XXXX] [other consecutive periods, if necessary]. A 47 - EI ERB - Earnings limit exceeded for the 4-week period disentitlement has been imposed from w/c [XXXX] to w/c [XXXX].

A written notice was sent to advise the client that an overpayment was created, and that the repayment was applied against it.” 

#### Note

Source topic: `en_EN/common_notes/note_c_1405.dita`

Note:

If disentitlements apply for consecutive periods, impose only one disentitlement for the entire period. The start date of the disentitlement is day 1 of the first week of the consecutive period, and the end date is day 5 of the last week of the consecutive period. Document the modified disentitlement dates and rationale for imposing one disentitlement for the consecutive periods on a ROD. In BCS, up to 4 disentitlements can be imposed, rescinded or terminated. 

## Policy reference

Source topic: `en_EN/task/actioning_erb_repayment/policy_reference.dita`

 
