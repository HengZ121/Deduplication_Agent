# Adjudicating incarceration

Source map: `en_EN/task/incarcerationadjudicating/incarcerationadjudicating.ditamap`

## Summary

Source topic: `en_EN/task/incarcerationadjudicating/summary.dita`

Summary: When information is received that a client who is an inmate of a penal institution is receiving EI benefits, a disentitlement is imposed for the period of incarceration. 

## What you need to know

Source topic: `en_EN/task/incarcerationadjudicating/what_you_need_to_know.dita`

### Imposing a disentitlement for a period of incarceration

Source topic: `en_EN/task/incarcerationadjudicating/imposing_a_disentitlement_for_a_period__43bde172.dita`

A 12 - Inmate of penal institution disentitlement (D12) must be imposed for the whole period of incarceration in a prison or similar establishment.

Disentitlements for being an “inmate of a prison or similar institution” include:

- pre-trial and post-trial custody

- incarceration by court order in order to undergo treatment

- authorized absence from a detention centre or prison in order to undergo treatment at another facility or to undergo an evaluation at another facility 

### Sentence is served in the community

Source topic: `en_EN/task/incarcerationadjudicating/sentence_is_served_in_the_community.dita`

To be entitled to EI benefits, the client must provide a certificate of availability for the purpose of seeking and accepting employment in the community, or the client must be eligible for parole, day parole or temporary absence. For information on the different types of release, see the Fact Sheet .
       [Fact Sheet](https://www.canada.ca/en/parole-board/corporate/publications-and-forms/types-of-release-fact-sheet.html)

A client who is on parole or on an approved temporary absence must also meet the entitlement conditions based on the type of benefit claim (e.g. clients claiming regular EI benefits must prove that they are available for work for all hours of employment that are available in the labour market).

Hours of work outside daytime hours cannot be accepted by those on day parole, and are therefore not considered suitable. This condition reduces the client’s chance of finding suitable employment.

Permission to be absent must be actually granted. The fact that it could have been granted if work had been available is not sufficient. Even if a temporary absence has been granted, the client must be physically absent from the institution for the disentitlement to be avoided.

A disentitlement is not imposed for being an “inmate of a prison or similar institution” on the working day of arrest, or on the working day of release from custody, if the client is available for at least half of that day. 

### Determining if the issue must be referred to Integrity

Source topic: `en_EN/task/incarcerationadjudicating/determining_if_the_issue_must_be_referr_33e59f9c.dita`

When a client comes forward to correct previously provided information or provides unreported information, the agent determines if the information can be considered an error correction or if it must be referred to Integrity.

For more information on determining the error correction timeframe, agents refer to the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

To determine if the new information can be considered an error correction or must be referred to Integrity, the agent refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Levels of decision

Source topic: `en_EN/task/incarcerationadjudicating/levels_of_decision.dita`

Level 1 agents can impose a D12 when all the following conditions are met:

- The client is an inmate of a penal institution.

- There are no conditions allowing the client to be away from the institution.

- No benefits have been paid for the period of incarceration or, if benefits have been paid, the client contacts Service Canada within 6 weeks of having made the original report covering the period of incarceration .

If none of the criteria above are met, a Level 2 agent adjudicates the claim.

If the client lost his or her employment because of incarceration, a Level 2 agent must adjudicate the incarceration and the reason for separation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3519.dita) 

### Disentitlement dates

Source topic: `en_EN/task/incarcerationadjudicating/disentitlement_dates.dita`

Disentitlement start and end dates are from Monday to Friday only. If the absence starts on a Saturday or Sunday, the following Monday is used as the disentitlement start date. If the absence ends on a Saturday or Sunday, the previous Friday is used as the disentitlement end date.

The disentitlement applies if the client is incarcerated for at least half of that day.

Statutory holidays that fall between Monday and Friday are treated as any other weekday and are included in the disentitlement.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3520.dita) 

### Processing an initial or renewal claim

Source topic: `en_EN/task/incarcerationadjudicating/processing_an_initial_or_renewal_claim.dita`

During processing, an initial claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) .

When the Claim action status is In Progress , all Adjudication Issue (ADJ) WIs must be completed before the system can calculate the initial claim or finalize the renewal claim. The MA02 stop payment is removed by the system.

If a letter of decision is required on an initial or renewal claim, before completing the Adjudication Issue (ADJ) WI, the agent creates a Correspondence (COR) Manual Decision WI indicating the details of the required letter. If a letter of decision is required on a continuing claim, the agent sends the letter before completing the ADJ WI. 

### Note

Source topic: `en_EN/common_notes/note_c_3519.dita`

Note:

The agent must enter the claimant’s reports for the period before the date of the disentitlement.
       [claimant’s reports](/en/procedure/activity/claimant_report.shtml)

     [claimant’s reports](/en/procedure/activity/claimant_report.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3520.dita`

Note:

In certain conditions, the benefit period (BP) can be extended because of a period of incarceration. Extension of the BP allows clients to receive their benefit entitlement for a longer period. Extension of the BP does not change the number of weeks of entitlement. Refer to Extending the benefit period — Incarceration .
       [Extending the benefit period — Incarceration](/en/procedure/task/ebp_incarceration.shtml)

     [Extending the benefit period — Incarceration](/en/procedure/task/ebp_incarceration.shtml) 

## Regional considerations

Source topic: `en_EN/task/incarcerationadjudicating/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/incarcerationadjudicating/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/incarcerationadjudicating/in_fts.dita`

- What is the claim type (CT): initial, continuing or renewal?

- Is there a registration number for the incarceration period?

- Are there any pending claimant’s reports?

- Is there a manual action (MA01) to stop payment imposed on the claim for this issue?

- Have claimant’s reports been processed for the period in question?

- If yes, when was the original statement made? 

### In NWS:

Source topic: `en_EN/task/incarcerationadjudicating/in_nws.dita`

- Is there information on the Specific Details tab about the ADJ WI, Action Item (AI) WI, Claim Review (CR) WI or Call Back (CB) WI?

- Are there SROCs, other WIs containing checklists or other details relating to the incarceration?

- Is there an Incarceration - Contact Made Prior , Incarceration - Contact Made During or Incarceration -Contact Made After checklist on the claim?
         [Incarceration - Contact Made Prior](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Incarceration-Contact_made_before_the_incarceration_period-Checklist.doc) 
         [Incarceration - Contact Made During](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Incarceration-Contact_made_during_the_incarceration_period-Checklist.doc) 
         [Incarceration -Contact Made After](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Incarceration-Contact_made_after_the_incarceration_period-Checklist.doc)

- Are there documents relating to the incarceration? 

### In Imaging:

Source topic: `en_EN/task/incarcerationadjudicating/in_imaging.dita`

- Are there imaged documents relating to the incarceration? 

## Step by step

Source topic: `en_EN/task/incarcerationadjudicating/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/incarcerationadjudicating/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/incarcerationadjudicating/reviewing_the_file_level_1.dita`

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if benefits have been paid for the period of incarceration or if the information may impact the client’s entitlement to benefits previously paid:

- If yes, go to step 3.

- If no, go to step 4.

- Determine if the client contacts Service Canada within 6 weeks of having made the report covering the period of incarceration:

- If yes, go to step 4

- If no, go to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- In NWS, determine if there is enough information to adjudicate the issue:

- If additional details are required, go to step 5.

- If no additional details are required, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/incarcerationadjudicating/fact-finding_level_1.dita`

- Fact-find with the client using the checklist Incarceration - Contact Made Prior , Incarceration - Contact Made During or Incarceration - Contact Made After .

- In NWS, determine if the client was contacted during fact-finding:

- If yes, go to step 7.

- If no , go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#ReassignLevel2)

- Add details to the draft SROC created during fact-finding or create a new SROC as follows :

- Issue: Select Availability .

- Comments: Type “Client declares incarceration.”

- Details: Copy and paste the Incarceration checklist if it was completed during fact-finding. Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- Click Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/incarcerationadjudicating/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the client lost his or her employment because of incarceration:

- If yes, document the details and go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#ReassignLevel2)

- If no, go to step 9.

- Determine if all of the following conditions are met:

- The client is an inmate of a penal institution.

- There are no condition allowing the client to be away from the institution.

- No benefits have been paid for the period of the incarceration or , if benefits have been paid, the client contacts Service Canada within 6 week of having made the report covering the period of incarceration.

- If all conditions are met, go to step 10.

- If the client was not an inmate of a penal institution or if the client could be absent from the institution, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#ReassignLevel2) 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/incarcerationadjudicating/record_of_decision_rod__creation_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Incarceration — D12 from w/c [XXXX] to [XXXX].”

- Details: Type “Not entitled to benefits, based on client’s own report [day/month/year] to [day/month/year] — within Level 1 authority.” 

#### Inputs and communication

Source topic: `en_EN/task/incarcerationadjudicating/inputs_and_communication_level_1.dita`

- Complete the applicable procedures according to the CT:

- Disentitlement applies — Initial claim
               [Disentitlement applies — Initial claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#disentitlement_initial)

- Disentitlement applies — Renewal claim
               [Disentitlement applies — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#disentitlement_renewal)

- Disentitlement applies — Continuing claim
               [Disentitlement applies — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#disentitlement_continuing) 

#### Disentitlement applies — Initial claim

Source topic: `en_EN/task/incarcerationadjudicating/disentitlement_applies__initial_claim_level_1.dita`

- In FTS. select the Disqualifications/Disentitlements (M161) and impose the disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 12 - Inmate of penal institution disentitlement .

- Start date: Select the appropriate option:

- BPC date: Check the box if the disentitlement begins at the BPC.

- Enter the disentitlement start date if the disentitlement begins after the BPC.

- End date: Enter the disentitlement end date as follows:

- If the period of incarceration is definite, enter the disentitlement end date.

- If the period of incarceration is not definite, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option :

- 3 - An overpayment resulted due to a definite disentitlement.

- 4 - An overpayment resulted due to an indefinite disentitlement.

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In ACS, create and save the letter D-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D5, D12, D13, D14, D23 .

- D12 - In prison or similar institution .

- In NWS, create a client Note and type “Send the D-01-00-00 draft letter.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 5.

- If yes, go to step 7.

- Determine if there is a system generated ROD with a negative decision:

- If no, go to step 6.

- If yes, go to step 7.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — incarceration issue.”

- Click Save.

- Complete the ADJ WI for the incarceration issue. 

#### Disentitlement applies — Renewal claim

Source topic: `en_EN/task/incarcerationadjudicating/disentitlement_applies__renewal_claim_level_1.dita`

- In FTS, select the Disqualifications/Disentitlements (M161) and impose the disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 12 - Inmate of penal institution.

- Start date: Enter the disentitlement start date.

- End date: Enter the disentitlement end date as follows:

- If the period of incarceration is definite, enter the disentitlement end date.

- If the period of incarceration is not definite, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option :

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In ACS, create and save the letter D-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D5, D12, D13, D14, D23 .

- D12 - In prison or similar institution .

- In NWS, create a client Note and type “Send the draft letter D-01-00-00.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 5.

- If yes, go to step 7.

- Determine if there is a system generated ROD with a negative decision:

- If no, go to step 6.

- If yes, go to step 7.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — incarceration issue.”

- Click Save.

- Complete the ADJ WI for the incarceration issue. 

#### Disentitlement applies — Continuing claim

Source topic: `en_EN/task/incarcerationadjudicating/disentitlement_applies__continuing_claim_level_1.dita`

- In FTS, determine if there is a registration number:

- If there is a registration number, go to step 2.

- If there is no registration number , select the Registration Number (M025, M030, M035) and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- Determine if there is an MA 01 - General suspension of benefits (stop payment) (MA01) imposed :

- If there is an MA01, go to step 3.

- If there is no MA01 , go to step 4.

- Select the Renewal/Revised (M106) transaction and remove the MA01 as follows :

- Registration number: Select the applicable registration number.

- Manual Action: Select 1 - General suspension of benefits .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 12 - Inmate of penal institution disentitlement .

- Start date: Select the disentitlement start date.

- End date: Select the disentitlement end date as follows:

- The period of incarceration is definite, select the disentitlement end date.

- The period of incarceration is not definite, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option :

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement.

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Click Update .

- Go to step 5.

- Select the Disqualifications/Disentitlements (M161) and impose the disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 12 - Inmate of penal institution disentitlement .

- Start date: Select the disentitlement start date.

- End date: Select the disentitlement end date as follows:

- If the period of incarceration is definite, select the disentitlement end date.

- If the period of incarceration is not definite, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option :

- 3 - An overpayment resulted due to a definite disentitlement.

- 4 - An overpayment resulted due to an indefinite disentitlement.

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Click Update .

- In ACS, create and send the letter D-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D5, D12, D13, D14, D23 .

- D12-In prison or similar institution .

- Complete the WI for the incarceration issue. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/incarcerationadjudicating/reassigning_the_issue_to_level_2_level_1.dita`

- Determine the CT:

- If this is a continuing claim, go to step 2.

- If this is an initial or renewal claim, go to step 3.

- In FTS, determine if an MA01 is imposed:

- If an MA01 is imposed, go to step 3.

- If an MA01 is not imposed , select the Renewal/Revised (M106) transaction and impose an MA01 as follows:

- Registration Number: Leave blank. If a number is showing, remove it.

- Manual action: Select 01 - General suspension of benefits (stop payment) .

- Click Update .

- In NWS, reassign the WI as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Issue: Select Unable to complete .

- Details: Type one of the following:

- “Not able to contact the client for fact-finding”

- “Not within Level 1 authority.”

- Click Update . 

### Level 2

Source topic: `en_EN/task/incarcerationadjudicating/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/incarcerationadjudicating/reviewing_the_file_level_2.dita`

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if benefits have been paid for the period of incarceration or if the information may impact the client’s entitlement to benefits previously paid:

- If yes, go to step 3

- If no, go to step 4

- Determine if the client contacts Service Canada within 6 week of having made the report covering the period of incarceration:

- If yes, go to step 4.

- If no, go to Creating or reassigning a WI — Integrity
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- In NWS, determine if the file contains all the information required to adjudicate the issue:

- If additional details are required, go to step 5.

- If no additional details are required, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/incarcerationadjudicating/fact-finding_level_2.dita`

- Fact-find with the client.

- In NWS, determine if the client was contacted during fact-finding :

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Missing information .
               [Missing information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#missing_information)

- If the client was contacted, go to step 7.

- Add details to the draft SROC created during fact-finding or create a new SROC as follows :

- Issue: Select Availability .

- Comments: Type “Client reports incarceration.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- Click Update . 

#### Adjudicating the incarceration

Source topic: `en_EN/task/incarcerationadjudicating/adjudicating_the_incarceration_level_2.dita`

- To adjudicate the incarceration, refer to Digest 10 :

- If no disentitlement for incarceration is applicable, go to No disentitlement applicable — All claim types (CTs).
               [No disentitlement applicable — All claim types](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#noDErequiredallclaimtype)

- If a disentitlement for incarceration is applicable, go to step 9. 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/incarcerationadjudicating/record_of_decision_rod__creation_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Incarceration — D12 from w/c [XXXX] to [XXXX].”

- Details: Document the details according to the National Fact-Finding, Documentation and Retention Policy.
               [National Fact-Finding, Documentation and Retention](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4) 

#### Inputs and communication

Source topic: `en_EN/task/incarcerationadjudicating/inputs_and_communication_level_2.dita`

- Follow the appropriate procedure based on the CT:

- Disentitlement applies — Initial claim
               [Disentitlement applies — Initial claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#disentitlement_initial_L2)

- Disentitlement applies — Renewal claim
               [Disentitlement applies — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#disentitlement_renewal_L2)

- Disentitlement applies — Continuing claim
               [Disentitlement applies — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/incarcerationadjudicating#disentitlement_continuing_L2) 

#### Disentitlement applies — Initial claim

Source topic: `en_EN/task/incarcerationadjudicating/disentitlement_applies__initial_claim_level_2.dita`

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose the disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 12 - Inmate of penal institution .

- Start date: Enter the disentitlement start date.

- End date: Enter the disentitlement end date as follows:

- If the incarceration period is definite, select the disentitlement end date.

- If the incarceration period is not definite, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In ACS, create and save the letter D-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D5, D12, D13, D14, D23 .

- D12 - In prison or similar institution .

- In NWS, create a client Note and type “Send the draft letter D-01-00-00.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 5.

- If yes, go to step 7.

- Determine if there is a system generated ROD with a negative decision:

- If no, go to step 6.

- If yes, go to step 7.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — incarceration issue.”

- Click Save .

- Complete the ADJ WI for the incarceration issue. 

#### Disentitlement applies — Renewal claim

Source topic: `en_EN/task/incarcerationadjudicating/disentitlement_applies__renewal_claim_level_2.dita`

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose the disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 12 - Inmate of penal institution .

- Start date: Select the disentitlement start date.

- End date: Enter the disentitlement end date as follows:

- If the incarceration period is definite, enter the disentitlement end date.

- If the incarceration period is not definite, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement.

- 4 - An overpayment resulted due to an indefinite disentitlement.

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Click Update .

- In ACS, create and save the letter D-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D5, D12, D13, D14, D23 .

- D12 - In prison or similar institution .

- In NWS, create a client Note and type “Send the draft letter D-01-00-00.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 5.

- If yes, go to step 7.

- Determine if there is a system generated ROD with a negative decision:

- If no, go to step 6.

- If yes, go to step 7.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — Incarceration issue.”

- Click Save .

- Complete the ADJ WI for the incarceration issue. 

#### Disentitlement applies — Continuing claim

Source topic: `en_EN/task/incarcerationadjudicating/disentitlement_applies__continuing_claim_level_2.dita`

- In FTS, determine if there is a registration number for the incarceration period:

- If there is a registration number, go to step 2.

- If there is no registration number , select the Registration Number (M025, M030, M035) and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- Determine if there is an MA 1 - General suspension of benefits (MA01) imposed for the incarceration period:

- If there is an MA01, go to step 3.

- If there is no MA01 , go to step 4.

- Select the Renewal/Revised (M106) transaction and remove the MA01 as follows:

- Registration number: Select the applicable registration number.

- Manual action: Select 1 - General suspension of benefits .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 12 - Inmate of penal institution disentitlement .

- Start: Enter the disentitlement start date.

- End: Enter the disentitlement end date as follows:

- If the period of incarceration is definite, enter the disentitlement end date.

- If the period of incarceration is not definite, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number .

- Click Update .

- Go to step 5.

- Select the Disqualifications/Disentitlements (M161) and impose the disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select - Add .

- Disentitlement: Select 12 - Inmate of penal institution .

- Start date: Enter the disentitlement start date.

- End date: Enter the disentitlement end date as follows:

- If the period of incarceration is definite, enter the disentitlement end date.

- if the period of incarceration is not definite, click Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number .

- Click Update .

- In ACS, create and send the letter D-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D5, D12, D13, D14, D23 .

- D12 - In prison or similar institution .

- In NWS, complete the ADJ WI for the incarceration issue. 

#### Missing information

Source topic: `en_EN/task/incarcerationadjudicating/missing_information_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Incarceration — D12 from w/c [XXXX] to 9999.”

- Details: Document the details according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- In FTS, determine if there is a registration number for the incarceration period :

- If there is no registration number, go to step 3.

- If there is a registration number, go to step 4.

- Select the Registration Number (M025, M030, M035) and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- Select the Disqualifications/Disentitlements (M161) and impose the disentitlement as follows:

- Registration number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 12 - Inmate of penal institution disentitlement .

- Start date: Enter the disentitlement start date.

- End date: Click indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number .

- Click Update .

- Determine if the CT:

- If the claim is an initial or a renewal claim, go to step 6.

- If the claim is a continuing claim, go to step 11.

- In ACS, create and save the letter D-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D5, D12, D13, D14, D23 .

- D12 - In prison or similar institution .

- In NWS, create a client Note and type “Send the draft letter D-01-00-00.”

- Determine if there is an outstanding COR Manual Decision WI:

- If no, go to step 9.

- If yes, go to step 12.

- Determine if there is a system generated ROD with a negative decision:

- If no, go to step 10.

- If yes, go to step 12.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “D-01-00-00 letter required — incarceration issue.”

- Click Save .

- Go to step 11.

- In ACS, create and send the letter D-01-00-00. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D5, D12, D13, D14, D23 .

- D12 - In prison or similar institution .

- In FTS, input the pending claimant’s reports, if applicable. Refer to Claimant’s report .

- Complete the ADJ WI for the incarceration issue. 

#### No disentitlement applies — All claim types (CTs)

Source topic: `en_EN/task/incarcerationadjudicating/no_disentitlement_applies__all_claim_types_cts_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “No disentitlement applies for incarceration.”

- Details: Document the fact-finding details according to the National Fact-Finding, Documentation and Retention Policy .
               [National Fact-Finding, Documentation and Retention Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- In FTS, determine if an MA01 is imposed and if there is a registration number for the incarceration period:

- If an MA01 is imposed but there is no registration number, go to step 3.

- If an MA01 is imposed and there is a registration number, go to step 4.

- If an MA01 is not imposed but there is a registration number, go to step 5.

- If none of the above applies, go to step 6.

- Select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Click Update .

- Select the Renewal/Revised (M106) transaction and remove the MA01 as follows:

- Registration number: Select the applicable registration number.

- Manual action: Select 1 - General suspension of benefits .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number .

- Click Update .

- Go to step 6.

- If an MA01 is not imposed but there is a revised registration number, select the Renewal/Revised (M106) and complete the following fields:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number .

- Click Update .

- Input the pending claimant’s reports, if applicable. Refer to Claimant’s report .

- Complete the ADJ WI for the incarceration issue. 

## Policy reference

Source topic: `en_EN/task/incarcerationadjudicating/policy_reference.dita`

- Digest 10 — Availability
         [Digest 10 — Availability](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 37
         [EIA 37](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-37.html)

- EIR 54
         [EIR 54](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-54.html)

- National Policy on Levels of Decision — Inmate of a Prison
         [National Policy on Levels of Decision — Inmate of a Prison](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
