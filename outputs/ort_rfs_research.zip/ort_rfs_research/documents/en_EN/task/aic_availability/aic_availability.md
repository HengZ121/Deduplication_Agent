# Adjudicating an Integrity case — Availability

Source map: `en_EN/task/aic_availability/aic_availability.ditamap`

## Summary

Source topic: `en_EN/task/aic_availability/summary.dita`

Summary: Investigators inform us of the results of an investigation when it is discovered that a client was not available for work. 

## What you need to know

Source topic: `en_EN/task/aic_availability/what_you_need_to_know.dita`

### Processing an Integrity claim review

Source topic: `en_EN/task/aic_availability/processing_an_integrity_claim_review.dita`

Below are the main processing steps for this activity. If the officer determines that the client knowingly made a false or misleading statement, the officer must adjudicate the availability issue, complete the record of decision (ROD), and refer to Misrepresentation to determine the type of sanction to impose. The officer must input the complete decision after determining the sanctions.
       [Misrepresentation](/en/procedure/activity/misrepresentation.shtml) 

### Reconsidering a decision

Source topic: `en_EN/task/aic_availability/reconsidering_a_decision.dita`

EIA 52 states that a claim for benefits may be reconsidered if it results in an overpayment (OP) or an underpayment (UP). The time frame for reconsidering a claim is 36 months from the week benefits were paid or payable. This period is extended to 72 months if there is a false or misleading statement.
       [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-26.html#docCont) 

### Determining if a false statement was made

Source topic: `en_EN/task/aic_availability/determining_if_a_false_statement_was_made.dita`

A false statement is a statement that is incorrect or untrue. It can be the result of an intentional or negligent action, or it can be the result of an honest mistake.

For example, on the claimant’s report, a client answered Yes to the question “Were you ready, willing and capable of working each day, Monday through Friday during each week of this report?” An investigation reveals that the client was not available for work and had not been seeking work for the period covered by the report, because the client was on vacation within Canada.

At this point, the officer only knows that the information provided by the client is incorrect. Without an explanation from the client, it cannot be determined if the client intentionally or knowingly failed to provide the correct information. Regardless of whether it was intentional or an honest mistake, a client cannot report being available during a vacation period; therefore, the reconsideration timeframe can be extended to 72 months.

**Determining if a false statement was knowingly made**

Knowingly means the officer can reasonably conclude that clients knew the information provided was untrue when they provided or did not report that information. There is no element of intent in this consideration. It is not necessary to determine a degree of fault. The officer must only establish that it is more likely the client understood the information provided did not accurately portray the facts.

If the client received payments by paper cheque, each cheque cashed can be considered a misrepresentation under EIA 38(1)(e). If the client received payments by direct deposit, each direct deposit payment or any excess amount the client received and did not return can be considered a misrepresentation under EIA 38(1)(f).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1787.dita) 

**Reviewing a potential case of voluntary disclosure**

The National Policy on Voluntary Disclosure encourages clients, employers and third parties to come forward and voluntarily disclose misrepresentations. According to this policy, voluntary disclosure occurs when a person admits to having knowingly made a false statement.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

An investigator may recommend that the file be reconsidered in light of the National Policy on Voluntary Disclosure .
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

There are 2 essential conditions for approving the voluntary disclosure:

- There is no investigation under way in relation to the voluntary disclosure when a client admits to making a false statement.

- The false statement would have resulted in punitive measures such as a penalty, a warning or prosecution had there been no voluntary disclosure.

According to the National Policy on Voluntary Disclosure , there is no limit to the number of times that a client can voluntarily disclose misrepresentations.
       [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 

### Assessing retroactive availability

Source topic: `en_EN/task/aic_availability/assessing_retroactive_availability.dita`

Availability for work is primarily a subjective matter which must be considered in the light of the client’s intentions, which is why it is often difficult to retroactively change a prior period. If the post-audit file is related to a job search compliance review, refer to Adjudicating an Integrity case — Job search compliance review .
       [Adjudicating an Integrity case — Job search compliance review](/en/procedure/task/aic_ccaj.shtml) 

### Client is available

Source topic: `en_EN/task/aic_availability/client_is_available.dita`

Some clients are deemed unemployed, capable of and available for work without having to prove their availability:

- clients who are referred to a training, a program of instruction or employment activity;

- clients who are employed under a work-sharing program;

- fishers (in certain situations).

Clients who establish a fishing benefit period, whether for winter or for summer fishing, are considered available for work with regard to their fishing activities . During the periods mentioned below, a 3 - Not available (D3) disentitlement is not imposed for the sole reason that the client took part in fishing activities:

- Summer fishing: starting the week in which October 1 falls to the week in which the following June 15 falls.

- Winter fishing: starting the week in which April 1 falls to the week in which the following December 15 falls. 

### Imposing a disentitlement for non-availability

Source topic: `en_EN/task/aic_availability/imposing_a_disentitlement_for_non-availability.dita`

When clients do not prove their availability, a D3 disentitlement may be imposed.

The D3 starts and ends during one of the 5 business days (Monday to Friday), including statutory holidays. It is impossible to declare a client unavailable for a half-day and the officer does not consider mitigating circumstances to reduce the duration of the disentitlement. 

### Returning a file to Integrity

Source topic: `en_EN/task/aic_availability/returning_a_file_to_integrity.dita`

After conducting a full review of the investigation, if the Level 2 officer determines that facts are missing, the officer must return the file to the investigator for further fact-finding and indicate the information that is missing but necessary to adjudicate the issue. The Level 2 officer must not adjudicate the issue if facts are missing or incomplete.

Facts are not considered missing or incomplete if the investigator has followed up with the client when the client fails to report for an interview or fails to reply to a request for information. The investigator is not required to send a follow-up letter but must make 2 attempts on 2 different days to contact the client by telephone. If the investigator leaves a message on a voicemail, only one attempt is required and they must allow 48 hours for the client to respond.

If the investigator recommends that the Integrity case be considered as voluntary disclosure, but the investigation type is not 70 in NIIS, the officer returns the file to Integrity.

The Integrity Services Branch does not verify the employer’s or third party’s version against the client’s version in the following situations:

- The investigation results in an actual or potential OP of less than the Integrity investigative threshold.

- There is no other active investigation.

In these situations, the officer does not return the case to Integrity because the employer’s or the third party’s version is missing. The officer is not required to validate the threshold. 

### Defining claim status (CS)

Source topic: `en_EN/task/aic_availability/defining_claim_status_cs.dita`

A claim can be active, terminated, blocked or archived. The CS impacts which transactions can be input and when the letter of decision is sent:

    Active: 
      The active claim is established and is currently displayed automatically in FTS. It is a claim for which benefits are still payable and that has not been terminated. 
      Terminated: 
      A terminated claim appears on the

Dormant

tab in FTS. It has ended but can be reactivated. Once the transaction to reactivate the claim has been processed, all inputs for the claim must be done the same as for an active claim. 
      Blocked: 
      In some cases, the claim that the officer must reconsider is on the

Dormant

tab in FTS, but there is a new active claim established and displayed on the

Summary

screen. The officer makes adjustments to this type of claim using BCS if the blocked CS shows

1 - Updateable

. Otherwise, IPOC intervention is required. 
      Archived: 
      Claims that are more than 7 years old are moved from the

Dormant

tab to the

Archived

tab. The officer can view an archived claim by changing the status of the archived claim from

1 - Non-Viewable

to

2 - Viewable

in FTS. Once the officer requests to make the claim viewable, the status field immediately displays 2 and the claim becomes viewable the next business day for 2 weeks. Adjustments to this type of claim are processed with IPOC intervention. 

### Determining the order of FTS inputs

Source topic: `en_EN/task/aic_availability/determining_the_order_of_fts_inputs.dita`

Controlled, multiple-day inputs in FTS are required to establish separate OPs for each decision, such as unreported earnings and reason for separation (RFS). When there is more than one reconsideration decision that results in an OP, the decisions must be input in the following order:

**Determining the input order for multiple transactions**

- full disentitlement

- partial disentitlement

- unreported earnings or unreported allocation of earnings

- indefinite disqualification

- definite disqualification

Controlled inputs in FTS are also required for UP and OP situations. The officer processes the inputs resulting in the OP first. Once the OP is established, the officer inputs an agreed deduction equal to the benefit rate amount. For more information, the officer refers to Applying an agreed deduction in PSCD .
       [Applying an agreed deduction in PSCD](/en/procedure/task/applying_an_agreed_deduction_pscd.shtml) 

### BCS

Source topic: `en_EN/task/aic_availability/bcs.dita`

BCS allows certain types of transactions to be processed on blocked dormant claims. There are 2 options available: Estimate and Claim update .

**Claim update function**

When transactions must be input on a blocked claim, the Blocked Claims System tab in FTS must be reviewed to determine the CS in BCS. If the CS is 1, an update is requested using BCS and the transactions can be processed.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1788.dita) 

An update in BCS can only be done on one BPC at a time. When transactions are input but not processed, Yes appears in the Block Action Pending column and access is denied for input on all other BPCs until the requested transactions are processed. Access to a BPC with a pending action is limited to the officer who initiated that action.

If an update is requested by the officer but cannot be completed by BCS, on the next processing day, the “Blocked claim not updated or not calculated” message is displayed along with the exception, error or warning on the MR05 screen.

Officers review the exception, error or warning on the Results tab in BCS for further action. If the update cannot be completed using BCS, the system presents an estimate result. The decision can be sent to IPOC using the Forward via MM06 link, which creates the prefilled M106 and MM06.

**Estimate function**

The Estimate function in BCS allows officers to view and evaluate the end results without processing the transactions. Estimates are possible for blocked claims with a CS 1 as well as unblocked dormant claims, provided the CS is 05 (inactive) or 06 (terminated) .

BCS Estimate transactions are processed overnight and the results are available on the Results tab the next day. Officers that have requested an estimate can view the end result and forward the request for IPOC intervention using the prefilled MM06 available on the Results tab. 

### Creating an Operation Centre Memo (MM06) transaction for multiple issues

Source topic: `en_EN/task/aic_availability/creating_an_operation_centre_memo_mm06__c1105b1f.dita`

When the MM06 includes multiple issues, if at least one issue is deemed to be a misrepresentation whereas at least another one is not, the officer ensures to include the appropriate OP message code for each issue in the Remarks section. 

### Record of decision (ROD)

Source topic: `en_EN/task/aic_availability/record_of_decision_rod.dita`

The Level 2 officer must record and document each decision in a separate ROD. 

### Note

Source topic: `en_EN/common_notes/note_c_1787.dita`

Note:

A false statement knowingly made does not always result in an OP of benefits. Since a monetary penalty is calculated based on the OP resulting from the misrepresentation, the officer can consider sending a warning letter if the client knowingly made a false statement, but this misrepresentation does not result in an OP. 

### Note

Source topic: `en_EN/common_notes/note_c_1788.dita`

Note:

At this time, BCS cannot process a benefit period extension, a recalculation of a claim or the removal of a manual action (MA). The officer must send an Operation Centre Memo ( MM06) transaction asking IPOC to process these transactions. 

## Regional considerations

Source topic: `en_EN/task/aic_availability/regional_considerations.dita`

**Quebec — Returning the file to Integrity**

In addition to the information already indicated in this procedure, return the file to Integrity as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address qc-dgsi-isb-retour@servicecanada.gc.ca as a Cc.
             [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca)

- In NWS, create a client Note and type “Measure — returned to Integrity” and include the date (YYYY-MM-DD). 

## What you need to look for

Source topic: `en_EN/task/aic_availability/what_you_need_to_look_for.dita`

### In NIIS:

Source topic: `en_EN/task/aic_availability/in_niis.dita`

- Review the IC07 Subject Enquiry screen for all active and prior cases.

- Review the IC04 Observation screen for a computer generated investigation.

- Review the IC08 Case Summary screen to see the actions taken on the case.

- Review the IC56 Case Notes screen to ensure you have the complete case.

- Review the IC50 Report of Clerical Investigation or IC70 Report of Investigation screen.

- Is there an Integrity Investigation Sheet?

- Is there a Report of Interview? 

### In Imaging:

Source topic: `en_EN/task/aic_availability/in_imaging.dita`

- Are there any documents that are relevant to the case? 

### In Integrity Investigations Document Upload System:

Source topic: `en_EN/task/aic_availability/in_integrity_investigations_document_up_6a8da64b.dita`

- Are there any documents that are relevant to the case? 

### In NWS:

Source topic: `en_EN/task/aic_availability/in_nws.dita`

- Review the application for benefits.

- Review SROCs, RODs, Action Item (AI) and Call Back (CB) WIs for information relevant to the case. 

### In FTS:

Source topic: `en_EN/task/aic_availability/in_fts.dita`

- If necessary, review the claimant reports for the weeks under investigation.

- Is there an exemption from reporting?

- If yes, did the client receive payments by direct deposit?

- What is the CS (active, terminated, blocked or archived)?

- If the claim is blocked, what is the CS in BCS? 

### In ACS:

Source topic: `en_EN/task/aic_availability/in_acs.dita`

- Was a request for information sent to the client by Integrity? 

## Step by step

Source topic: `en_EN/task/aic_availability/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/aic_availability/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/aic_availability/reviewing_the_file_level_2.dita`

- Determine if there is a false statement:

- If no, go to step 2.

- If yes, go to step 3.

- Determine if the request for reconsideration was made within the 36-month time limit:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_availability#Not)

- Determine if the request for reconsideration is within the maximum reconsideration period of 72 months:

- If yes, go to step 4.

- If no, go to Not within reconsideration timeframe .
               [Not within reconsideration timeframe](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_availability#Not)

- Determine if the information gathered by Integrity is complete:

- If the information is complete, go to step 5.

- If the information is incomplete, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_availability#refering)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1667.dita)

- In NWS, create a ROD for the reconsideration under EIA 52 as follows (if necessary, refer to Reconsideration, amendment of a decision and error correction ):

- Comments: Type “[Integrity case number] — EIA 52 reconsideration.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Adjudicate the client’s availability situation.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1789.dita) 

- If the client does not show that he is available, go to step 7.

- If the client shows that he is available, go to Availability in order .
               [Availability in order](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_availability#AvailInOrder)

- Determine if the client knowingly made a false or misleading statement as described in Digest 18.3.1.4 — Misleading and Digest 18.3.1.5 — Knowingly :

- If there is a false statement that is knowingly made, go to step 8.

- If there is a false statement that is not knowingly made, go to step 11.

- If there is no false statement, go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_availability#Recon36)

- Determine if the investigator recommends that the file be reconsidered in light of a voluntary disclosure, as described in National Policy on Voluntary Disclosure :

- If the voluntary disclosure criteria are not met, go to step 9.

- If the voluntary disclosure criteria are met but the investigation type in NIIS is not 70, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_availability#refering)

- If the voluntary disclosure criteria are met and the investigation type in NIIS is 70, go to Voluntary disclosure approved .
               [Voluntary disclosure approved](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_availability#VLDis)

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — availability not proven — D3 from XXXX to XXXX.”

- Details: Document the decision and rationale for the non-availability issue according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Continue with Adjudicating client or third party misrepresentation — Monetary penalty or warning letter to determine the appropriate sanctions and input all the decisions.

- Determine the reconsideration timeframe for the false or misleading statement not knowingly made:

- If the false statement was made within the prescribed period of 36 months , go to Reconsideration within 36 months .
               [Reconsideration within 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_availability#Recon36)

- If the false statement was made within the extended period of 72 months , go to Reconsideration after 36 months .
               [Reconsideration after 36 months](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/aic_availability#reconsideration37) 

#### Not within reconsideration timeframe

Source topic: `en_EN/task/aic_availability/not_within_reconsideration_timeframe_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — EIA 52 — not within reconsideration timeframe.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, select the Renewal/Revised (M106) transaction and clear the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, from the Report for Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Not within reconsideration timeframe, no decision on the availability.”

- Penalty: Select No .

- Warming: Select No .

- Violation: Select No .

- Select Ok .

- In NWS, complete the Claim Review (CR) Integrity WI. 

#### Returning the file to Integrity

Source topic: `en_EN/task/aic_availability/returning_the_file_to_integrity_level_2.dita`

- In NIIS, from the Document tab, select IC70 Report of Investigation or IC50 Report of Clerical Investigation , depending on the case, and complete the following fields:

- Select Recommendation .

- Refer the file to Integrity as follows:

- Select Yes (IC70) .

- Check the box (IC50) .

- Enter the missing or additional information required in the text area.

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1790.dita)

- In FTS, select the Outstanding Registrations link to cancel the registration number as follows:

- Select Modify .

- In the appropriate registration section:

- Action: Select Cancel .

- Select Update .

- If necessary, return the paper documents relating to the investigation to the investigator who signed the Report of Investigation.

- In NWS, complete the CR Integrity WI. 

#### Availability in order

Source topic: `en_EN/task/aic_availability/availability_in_order_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — availability — in order.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain why availability is considered in order.

- In FTS, determine if an MA is imposed to stop payments for the availability issue:

- If an MA is imposed, go to step 3.

- If an MA is not imposed, go to step 4.

- Select the Renewal/Revised (M106) transaction to remove the MA as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- Go to step 5.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Case in order.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Voluntary disclosure approved

Source topic: `en_EN/task/aic_availability/voluntary_disclosure_approved_level_2.dita`

- In NWS, create a ROD for the availability issue as follows:

- Comments: Type “[Integrity case number] — availability not proven — D3 from XXXX to XXXX.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Create a ROD for the voluntary disclosure issue as follows:

- Comments: Type “[Integrity case number] — voluntary disclosure approved.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Explain that the client meets the 2 conditions for the use of the National Policy on Voluntary Disclosure .
               [National Policy on Voluntary Disclosure](/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 4.

- If the claim is terminated, but can be reactivated:

- On the Terminated tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 4.

- If the claim is blocked or archived, go to step 7.

- Determine if an MA is imposed to stop payments for the availability issue:

- If an MA is imposed, go to step 5.

- If an MA is not imposed, go to step 6.

- Select the Renewal/Revised (M106) transaction to remove the MA and input the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Enter the disentitlement start date.

- End date: Enter the appropriate end date as follows:

- For a definite disentitlement, select the disentitlement end date.

- For an indefinite disentitlement, select Indefinite .

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number

- D - No to leave the registration number open

- Select Update .

- Go to step 17.

- Select the Disqualifications/Disentitlements (M161) transaction and input the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Enter the disentitlement start date.

- End date: Select the appropriate option:

- For a definite disentitlement, select the disentitlement end date.

- For an indefinite disentitlement, select Indefinite .

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Go to step 17.

- Determine the blocked CS by reviewing the Blocked Status column on the Blocked tab:

- If 2 - Not blocked is displayed, return to step 3.

- If 1 - Updateable is displayed , go to step 8.

- If any other CS is displayed, go to step 15.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 9.

- If all rows are blank, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, in FTS, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 9.

- If all rows are blank, go to step 11.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- On the Disentitlements tab, input the disentitlement on the Disentitlements section as follows (up to 4 disentitlements in BCS can be imposed, rescinded or terminated):

- Action: Select A - Add .

- Type: Select 3 - Not available .

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 14.

- If the transaction shown is correct, select Close and go to step 17.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 12.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Detection: Select the investigation type as displayed in NISS.

- Infraction: Select T - Disclosure .

- Message: Select 71 - Information you disclosed caused an overpayment .

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the unavailability period.

- Work item: Select 91 - Overpayment .

- Work type: Select 1 - Misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D3 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Various reasons for penalty and violation (2935)

- Failed to provide information

- According to our records / In addition, according to our records (2936)

- one occasion / Text: number of occasions (2937)

- Text - Specify what we have learned (1628): Type “were [are] not available for work for the period from [first day not available] to [last day not available or indefinite].”

- No reply from client / reply received with an explanation / reply received with no explanation (2938)

- False representations message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment - No misrepresentation and active claim

- Overpayment - No misrepresentation and inactive claim

- In ACS, create and send the D-70-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Voluntary disclosure / Administrative Rule - Undeclared Earnings(2664): Voluntary disclosure of information (2694) .

- Subjects of Voluntary Disclosure (2665) .

- Option #3: Your availability for work .

- Blank/Reminder: Provide information on report (2667)

- Provide full and accurate information on each report and correct any incorrect reports as soon as possible .

- Overpayment messages (2452) .

- Right to request a reconsideration (4169) .

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other and type “D3 — not available.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select Ok .

- In NWS, complete the CR Integrity WI. 

#### Reconsideration within 36 months

Source topic: `en_EN/task/aic_availability/reconsideration_within_36_months_level_2.dita`

- In NWS, create a ROD for the availability issue as follows:

- Comments: Type “[Integrity case number] — availability not proven — D3 from XXXX to XXXX.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the claim for benefits is active, terminated, blocked or archived:

- If the claim is active, go to step 3.

- If the claim is terminated, but may be reactivated:

- On the Terminated tab, select the appropriate BPC.

- Select Reactivate .

- Go to step 3.

- If the claim is blocked or archived, go to step 6.

- Determine if an MA is imposed to stop payments for the availability issue:

- If an MA is imposed, go to step 4.

- If an MA is not imposed, go to step 5.

- In FTS, select the Renewal/Revised (M106) transaction to remove the MA and input the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select the appropriate MA.

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Enter the disentitlement start date.

- End date: Select the appropriate option:

- If the unavailability period is definite, select the disentitlement end date.

- If the unavailability period is not definite, Select Indefinite .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Go to step 16.

- Select the Disqualifications/Disentitlements (M161) transaction to input the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Start date: Enter the disentitlement start date.

- End date: Select the appropriate option:

- If the unavailability period is definite, select the disentitlement end date.

- If the unavailability period is not definite, select Indefinite .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement

- 4 - An overpayment resulted in an indefinite disentitlement

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- Go to step 16.

- Determine the blocked CS by reviewing the Blocked Status column on the Blocked tab:

- If 2 - Not blocked is displayed, return to step 2.

- If 1 - Updateable is displayed, go to step 7.

- If any other CS is displayed, go to step 14.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 8.

- If all rows are blank, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter [the next working day].

- When the WI moves to the current workload, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 8.

- If all rows are blank, go to step 10.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- On the Disentitlements tab, input the disentitlement on the Disentitlements section as follows (up to 4 disentitlements in BCS can be imposed, rescinded or terminated):

- Action: Select A - Add .

- Type: Select 3 - Not available .

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 13.

- If the transaction shown is correct, select Close and go to step 16.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 11.

- In FTS, select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted in an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the unavailability period.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D3 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Various reasons for penalty and violation (2935)

- Failed to provide information

- According to our records / In addition, according to our records (2936)

- one occasion / Text: number of occasions (2937)

- Text - Specify what we have learned (1628): Type “were [are] not available for work for the period from [first day not available] to [last day not available or indefinite].”

- No reply from client / reply received with an explanation / reply received with no explanation (2938)

- False representations message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment - No misrepresentation and active claim

- Overpayment - No misrepresentation and inactive claim

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other and type “D3 — not available.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select Ok .

- In NWS, complete the CR Integrity WI. 

#### Reconsideration after 36 months

Source topic: `en_EN/task/aic_availability/reconsideration_after_36_months_level_2.dita`

- In NWS, create a ROD for the availability issue as follows:

- Comments: Type “[Integrity case number] — availability not proven — D3 from XXXX to XXXX.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine the blocked CS by reviewing the Blocked Status column on the Blocked tab:

- If 1 - Updateable is displayed, go to step 3.

- If any other CS is displayed, go to step 10.

- Review the Blocked Action Pending column:

- If Yes is displayed in one of the rows, go to step 4.

- If all rows are blank, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1791.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Waiting for an updateable CS in BCS.”

- Bring forward date: Enter the next working day.

- When the WI moves to the current workload, review the Blocked Action Pending column on the Blocked tab:

- If Yes is displayed in one of the rows, return to step 4.

- If all rows are blank, go to step 6.

- In FTS, select the BPC you want to update from the Blocked Status column. When the Blocked Claim screen opens, complete the following:

- Action required: Select Claim update .

- Agreed deduction: Select (100%) Blocked claim system default .

- Registration number: Select the appropriate registration number.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- To complete the registration number, select C - Yes .

- To leave the registration number open for subsequent transactions, select D - No .

- Select Update .

- On the Disentitlements tab, input the disentitlement on the Disentitlements section as follows (up to 4 disentitlements in BCS can be imposed, rescinded or terminated):

- Action: Select A - Add .

- Type: Select 3 - Not available .

- Start date: Enter the start date of the disentitlement.

- End date: Enter the end date of the disentitlement or 9999 if the end date is indefinite.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Update .

- On the Pending Transactions tab, review the transaction:

- If the transaction shown is incorrect, go to step 9.

- If the transaction shown is correct, select Close and go to step 12.

- Delete the incorrect transaction as follows:

- Delete: Check the box next to the incorrect transaction.

- Select Update .

- Return to step 7.

- Select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) transaction as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement

- 4 - An overpayment resulted in an indefinite disentitlement

- Contentious: Select 2 - Yes .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the BPC of the claim with the unavailability period.

- Work item: Select 91 - Overpayment .

- Work type: Select 2 - Non-misrepresentation .

- Earnings to be allocated: Leave the field blank.

- Remarks line 1: Type “D3 from w/c [XXXX-X] to [XXXX-X].”

- Remarks line 2: Type “ACS letter already sent.”

- Remarks line 3: Leave the field blank.

- Remarks line 4: Leave the field blank.

- Remarks line 5: Enter your first name and last name.

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the D-91-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Date claimant called or information sent (1542)

- Decision reconsidered beyond 36 months (2595): Select Decision reconsidered beyond 36 months due to false representations

- Various reasons for penalty and violation (2935)

- Failed to provide information

- According to our records / In addition, according to our records (2936)

- one occasion / Text: number of occasions (2937)

- Text - Specify what we have learned (1628): Type “were not available for work for the period from [first day not available] to [last day not available or indefinite].”

- No reply from client / reply received with an explanation / reply received with no explanation (2938)

- False representations message / Number of omissions or false representations (2941): Select Blank .

- Levels of misrepresentation (12292): Select Blank .

- Penalty message / Warning message (2950): Select Blank .

- Overpayment Messages (2452): Select the appropriate option:

- Blank if there is no resulting overpayment

- Overpayment - No misrepresentation and active claim

- Overpayment - No misrepresentation and inactive claim

- In NIIS, from Report of Investigation , select the Decision tab and complete the following fields:

- Disentitlement: Select Yes .

- Reason: Select Other and type “D3 — not available.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1667.dita`

Note:

Cases with an OP below the Integrity investigative threshold are referred for adjudication only when specific exceptions are met (voluntary disclosure or impact on an active claim). In these cases, the employer’s or any other party’s version does not have to be verified and the file must not be returned to Integrity. 

#### Note

Source topic: `en_EN/common_notes/note_c_1789.dita`

Note:

If it is necessary to adjudicate the issue, refer to Availability or Digest 10 — Availability .
       [Availability](/en/procedure/activity/availability.shtml) 
       [Digest 10 — Availability](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/table-of-contents.shtml)

In cases of vacation in Canada, the officer imposes a 38 - On vacation in Canada disentitlement (D38) instead of a D3.

     [Availability](/en/procedure/activity/availability.shtml) 
     [Digest 10 — Availability](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/table-of-contents.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_1790.dita`

Note:

The regional consideration for officers in the Quebec region is as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Add GD mailbox address qc-dgsi-isb-retour@servicecanada.gc.ca as a c.c.
             [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca)

- In NWS, create a client Note and type “Measure — returned to Integrity” and include the date (YYYY-MM-DD).

     [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca) 

#### Note

Source topic: `en_EN/common_notes/note_c_1791.dita`

Note:

An update in BCS can only be done on one BPC at a time. 

## Policy reference

Source topic: `en_EN/task/aic_availability/policy_reference.dita`

- Digest chapter 10 — Availability
         [Digest chapter 10 — Availability](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/table-of-contents.html)

- Digest chapter 17 — Reconsideration, Amendment of a Decision, and Error Correction
         [Digest chapter 17 — Reconsideration, Amendment of a Decision, and Error Correction](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/table-of-contents.html)

- Digest chapter 18 — Policy on Penalties
         [Digest chapter 18 — Policy on Penalties](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-18/table-of-contents.html)

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 32
         [EIA 32](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-32.html)

- EIA 52
         [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- EIA 38
         [EIA 38](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-11.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml) 
