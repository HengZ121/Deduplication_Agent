# Actioning a Correspondence Disqualification/Disentitlement WI

Source map: `en_EN/task/cor_disq_disent/cor_disq_disent.ditamap`

## Summary

Source topic: `en_EN/task/cor_disq_disent/summary.dita`

Summary: To ensure that the client is notified in writing of all negative decisions made on an initial or renewal claim, the system creates a Correspondence (COR) Disqualification/Disentitlement WI. 

## What you need to know

Source topic: `en_EN/task/cor_disq_disent/what_you_need_to_know.dita`

### Notifying clients of decisions

Source topic: `en_EN/task/cor_disq_disent/notifying_clients_of_decisions.dita`

When adjudication of a contentious issue results in a negative decision, the client must be notified in writing of the decision.

The adjudicating officer is responsible for creating and saving the ACS letter and creating a client Note indicating that a letter needs to be sent on an initial or renewal claim. Notices must be in the client’s preferred official language, as indicated on the application for benefits.

When the claim is finalized, the system creates a COR Disqualification/Disentitlement WI to ensure that the client is notified in writing of a negative decision. The COR WI displays the name of the letter to be sent and identifies what caused the creation of the COR WI, listed below:

- anticipated loss of employment (D44)

- authorized period of leave (D43)

- misconduct proven (D10)

- ROE excluded from calculation for all claim types when there is more than one negative decision to be communicated (D10 or D11)

- self-employment or farming (D01)

- suspension (D42)

- training not allowed (D03)

- voluntary leaving and dismissal: no relief from previous disqualification (D10 or D11)

- voluntary leaving, no just cause (D11)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2900.dita) 

### Communicating multiple decisions

Source topic: `en_EN/task/cor_disq_disent/communicating_multiple_decisions.dita`

ACS is used to send correspondence to clients. One of the main features of ACS is that when more than one decision is present on the file, the system can send the client one single letter that includes all the decisions (e.g. an initial claim for which there are both Level 1 and Level 2 decisions), instead of one letter for each decision. When possible, all decisions to be communicated to the client must be included in one letter.

**Communicating a decision about allocation of earnings**

When the system carries out an allocation of earnings, the information is not transmitted to ACS. When there is an allocation to be communicated to the client, the Non-complex officer reassigns the file to a Level 1 officer.

The officer responsible for sending the letter must add the appropriate attributes to the draft letter. To determine the attributes to add, the officer can refer to the appropriate Earnings task.
       [Earnings](/en/procedure/activity/earnings.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2900.dita`

Note:

On a renewal claim, if it is determined the client left the employment without just cause or was dismissed due to misconduct; an indefinite disqualification is imposed on the claim for regular benefits. This prompts the creation of the COR WI. In certain situations, the officer manually rescinds this particular disqualification and leaves a client note stating that no ACS letter is required. 

## Regional considerations

Source topic: `en_EN/task/cor_disq_disent/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/cor_disq_disent/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/cor_disq_disent/in_nws.dita`

- Is there a client Note ?

- Are there other outstanding COR WIs?

- What are the details of the COR WI?

- What is the template number?

- What is the Disentitlement/Disqualification? 

### In FTS:

Source topic: `en_EN/task/cor_disq_disent/in_fts.dita`

- Is there an allocation of earnings?

- Is there a disqualification on file?

- If yes, what is the start date?

- Is there a disentitlement on file?

- If yes, what is the start date?

- If yes, what is the end date? 

### In RCM:

Source topic: `en_EN/task/cor_disq_disent/in_rcm.dita`

- Is there an ROE with a reason for separation (RFS) showing E, M or N?

- If yes, what is the last day paid? 

### In ACS:

Source topic: `en_EN/task/cor_disq_disent/in_acs.dita`

- Is there a draft letter?

- Was a letter sent for the decision under review?

- If yes, is the decision related to a disqualification that has already been communicated to the client on a previous claim? 

## Step by step

Source topic: `en_EN/task/cor_disq_disent/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/cor_disq_disent/non-complex.dita`

#### Reviewing the decision

Source topic: `en_EN/task/cor_disq_disent/reviewing_the_decision_non-complex.dita`

- In ACS, determine if there is a D-01-00-00 or N-00-00-00 letter:

- If no, go to step 2.

- If yes and the status is Draft , go to step 3.

- If yes and the status is Sent to , go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#rtitl1)

- If yes and the status is Incomplete , go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#rtitl2)

- In NWS, determine if there is a client Note indicating that a letter must be sent for an initial or renewal claim:

- If there is no client Note , go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#rtitl1)

- If there is a client Note indicating that a letter must be sent, Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#rtitl1)

- If there is a client Note indicating that a letter is not required, go to Communication not required .
               [Communication not required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#cnr)

- In NWS, determine if there are any other outstanding COR WIs:

- If no , go to step 4.

- If yes, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#rtitl1)

- In FTS, under the Summary tab, determine if there is an allocation on file by clicking the Allocations link.

- If there is an allocation and the claim is a renewal claim, go to step 5.

- If there is an allocation and the claim is an initial claim, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#rtitl1)

- If there is no allocation, go to step 6.

- Determine the start date of the allocation:

- If the start date is the renewal date or later, there is an allocation to communicate, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#rtitl1)

- If the start date is before the renewal date and the end date is after the renewal date, there is an allocation to communicate, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#rtitl1)

- If the start and end dates are both before the renewal date, there is no allocation to communicate, go to step 6.

- Review the Details section of the COR WI.

- If the Details section displays a combination of a D10 or a D11 with a D46, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#rtitl1)

- If the Details section displays any other information, go to step 7.

- In FTS, note the BPC or renewal date.

- Select the Disqualifications/Disentitlements link and note the start date of the disqualification or disentitlement, if necessary.

- Determine if there is a D10 or D11 on file.

- If yes, go to step 10.

- If no, go to step 11.

- In RCM, identify the ROE that led to the disqualifying event (RFS code E, M or N) by looking at the special condition field, and note the employer’s name and the last day paid.

- In ACS, open the draft letter to review the content:

- If the content matches the information to be communicated, go to Communicating the decision .
               [Communicating the decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#cd)

- If the content does not match the information to be communicated, go to Reassigning the issue to Level 1 .
               [Reassigning the issue to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#rtitl1) 

#### Communicating the decision

Source topic: `en_EN/task/cor_disq_disent/communicating_the_decision_non-complex.dita`

- In ACS, send the draft letter.

- In NWS, clear the client Note and complete the COR WI. 

#### Communication not required

Source topic: `en_EN/task/cor_disq_disent/communication_not_required_non-complex.dita`

- In NWS, clear the client Note and complete the COR WI. 

#### Reassigning the issue to Level 1

Source topic: `en_EN/task/cor_disq_disent/reassigning_the_issue_to_level_1_non-complex.dita`

- In NWS, reassign the WI to Level 1 as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 1 .

- Reason: Select Unable to Complete .

- Details: Type “Unable to complete at Non-complex level.” 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/cor_disq_disent/reassigning_the_issue_to_level_2_non-complex.dita`

- Reassign the WI as follows:

- Destination: Select the appropriate option:

- If the adjudicating officer is available, select Specific user and enter the last and first name of the adjudicating officer.

- If the adjudicating officer is not available, select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type “ACS draft letter is incomplete — unable to complete at Non-complex Level.” 

### Level 1

Source topic: `en_EN/task/cor_disq_disent/level_1.dita`

#### Reviewing the decision

Source topic: `en_EN/task/cor_disq_disent/reviewing_the_decision_level_1.dita`

- In NWS, determine if there are multiple outstanding COR WIs on file.

- If yes, go to step 2.

- If no, go to step 4.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2901.dita)

- Determine if the COR WI is unassigned:

- If the COR WI is unassigned, go to step 3.

- If the COR WI is assigned to another officer and it is in the officer’s Pending workload, go to step 3.

- If the WI is assigned to another officer but it is in the officer’s Active workload, ask your Team Leader to reassign the WI to you. Then go to step 4.

- Reassign the WI to yourself as follows:

- Destination: Select Myself .

- Complexity: Select Level 1 .

- Reason: Select Other .

- Details: Type “Multiple COR WI. Letter to be sent.”

- Select OK .

- To determine the decisions to be communicated to the client, review the information on the COR WI.

- In FTS, determine if there is an allocation of earnings that has not been communicated to the client.

- If no, go to step 6.

- If yes, to determine the attributes to add to the letter, refer to the appropriate Earnings task, and go to step 6.
               [Earnings](/en/procedure/activity/earnings.shtml)

- Note the BPC or renewal date.

- Select the Disqualifications/Disentitlements link and note the start date of the disqualification or disentitlement, if necessary.

- Determine if there is a D10 or D11 on file.

- If yes, go to step 9.

- If no, go to step 10.

- In RCM, identify the ROE that led to the disqualifying event (RFS code E, M or N) and note the employer’s name and the last day paid. Go to step 10.

- Determine if the decision is related to a disqualification that has already been communicated to the client on a previous claim:

- If no, go to step 11.

- If yes, go to Communicating a decision made on a previous claim .
               [Communicating a decision made on a previous claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#level1_item_3) 

#### Communicating the decision

Source topic: `en_EN/task/cor_disq_disent/communicating_the_decision_level_1.dita`

- In ACS, open the draft letter, make the necessary changes and send the letter.

- In NWS, if necessary, clear the client Note and complete the COR WI. 

#### Communicating a decision made on a previous claim

Source topic: `en_EN/task/cor_disq_disent/communicating_a_decision_made_on_a_prev_1eb8a29e_level_1.dita`

- Determine the requested benefit type (BT):

- For regular benefits, go to step 2.

- For special benefits, go to step 3.

- In ACS, create and send the D-01-00-00 letter. If required, refer to the appropriate procedure for the attributes to include. Based on the claim information, select all of the required attributes, including the following:

- Disqualifications - Definite/indefinite - Previous/current/revision (2970): Select D11 / D10 / Both / Previous disqualification / Revision (Initial/Renewal or Revision) .

- D11 / D10 / Both / Previous disqualification / Revision (Initial/Renewal or Revision) (2542): Select Disqualification message .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In ACS, create and send the N-00-00-00 letter. If required, refer to the appropriate procedure for the attributes to include. Based on the claim information, select all of the required attributes, including the following:

- Not entitled to regular after special - D10/D11 or claim is BPNE - Initial or renewal claim or D42 - D43 (2540): Select D11/D10 imposed - Only special benefits allowed (2491) .

- D11/D10 imposed - Only special benefits allowed (2491): Select the appropriate attributes:

- D10 imposed - Special benefits allowed .

- D11 imposed - Special benefits allowed .

- Text - Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the COR WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_2901.dita`

Note:

The presence of multiple COR WIs indicates that more than one decision needs to be communicated to the client. If possible, include all decision attributes in one letter. 

### Level 2

Source topic: `en_EN/task/cor_disq_disent/level_2.dita`

#### Reviewing the decision

Source topic: `en_EN/task/cor_disq_disent/reviewing_the_decision_level_2.dita`

- In NWS, determine if there are multiple outstanding COR WIs on file.

- If yes, go to step 2.

- If no, go to step 4.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2901.dita)

- Determine if the COR WI is unassigned:

- If the COR WI is unassigned, go to step 3.

- If the COR WI is assigned to another officer and it is in the officer’s Pending workload, go to step 3.

- If the WI is assigned to another officer but it is in the officer’s Active workload, ask your Team Leader to reassign the WI to you. Then go to step 4.

- Reassign the WI to yourself as follows:

- Destination: Select Myself .

- Complexity: Select Level 2 .

- Reason: Select Other .

- Details: Type “Multiple COR WI. Letter to be sent.”

- Select OK .

- Review the information on the COR WI to determine the decisions to be communicated to the client.

- Determine if the decision is related to a disqualification that has already been communicated to the client on a previous claim:

- If no, go to step 6.

- If yes, go to Communicating a decision made on a previous claim .
               [Communicating a decision made on a previous claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/cor_disq_disent#level2_item_3)

- In FTS, determine if there is an allocation of earnings that has not been communicated to the client.

- If yes, to determine the attributes to add to the letter, refer to the appropriate Earnings task, and go to step 7.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If no, go to step 7. 

#### Communicating the decision

Source topic: `en_EN/task/cor_disq_disent/communicating_the_decision_level_2.dita`

- In ACS, send the letter.

- In NWS, clear the client Note and complete the COR WI. 

#### Communicating a decision made on a previous claim

Source topic: `en_EN/task/cor_disq_disent/communicating_a_decision_made_on_a_prev_1eb8a29e_level_2.dita`

- Determine the requested benefit type (BT):

- For regular benefits, go to step 2.

- For special benefits, go to step 3.

- In ACS, create and send the D-01-00-00 letter. If required, refer to the appropriate procedure for the attributes to include. Based on the claim information, select all of the required attributes, including the following:

- Disqualifications - Definite/indefinite - Previous/current/revision (2970): Select D11 / D10 / Both / Previous disqualification / Revision (Initial/Renewal or Revision) .

- D11 / D10 / Both / Previous disqualification / Revision (Initial/Renewal or Revision) (2542): Select Disqualification message .

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In ACS, create and send the N-00-00-00 letter. If required, refer to the appropriate procedure for the attributes to include. Based on the claim information, select all of the required attributes, including the following:

- Not entitled to regular after special - D10/D11 or claim is BPNE - Initial or renewal claim or D42 - D43 (2540): Select D11/D10 imposed - Only special benefits allowed (2491) .

- D11/D10 imposed - Only special benefits allowed (2491): Select the appropriate attributes:

- D10 imposed - Special benefits allowed .

- D11 imposed - Special benefits allowed .

- Text - Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, complete the COR WI. 

## Policy reference

Source topic: `en_EN/task/cor_disq_disent/policy_reference.dita`

 
