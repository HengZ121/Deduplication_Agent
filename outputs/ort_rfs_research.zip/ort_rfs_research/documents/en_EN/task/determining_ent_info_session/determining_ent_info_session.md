# Reviewing a 15 - Claim Procedure disentitlement — Failure to attend a client information session

Source map: `en_EN/task/determining_ent_info_session/determining_ent_info_session.ditamap`

## Summary

Source topic: `en_EN/task/determining_ent_info_session/summary.dita`

Summary: If a client fails to attend a mandatory client information session or, in the Quebec region, an appointment at a local employment centre, the officer determines if the client is entitled to benefits. 

## What you need to know

Source topic: `en_EN/task/determining_ent_info_session/what_you_need_to_know.dita`

### Client information sessions

Source topic: `en_EN/task/determining_ent_info_session/client_information_sessions.dita`

While receiving benefits, clients may be directed to attend a client information session. The client information session is provided jointly by the Citizen Services and Integrity Services branches. In the Quebec region, employees in local employment centres are responsible for providing the information sessions.

The client information session aims to provide information about EI as well as clarify the client’s obligations during the benefit period (BP). The appointments set up by the local employment centre in the Quebec region are intended to improve employability and facilitate a client’s return to work (RTW). A client from the Quebec region could be instructed to attend a client information session, an appointment at a local employment centre, or both. When directed to attend either the session or the appointment, the client must attend. Failure to attend the session or the appointment can affect entitlement to benefits.

Clients are notified in writing in the Direction to Report letter of the requirement to attend a mandatory client information session or an appointment with the local employment centre. If a client cannot attend, the Direction to Report letter provides the client with instructions on who to contact. 

### Failure to report

Source topic: `en_EN/task/determining_ent_info_session/failure_to_report.dita`

Failure to report is a term used to describe the situation where a client has been directed to attend a client information session or an appointment at a local employment centre, but does not attend. Clients are notified in the Direction to Report letter of the consequences of not attending the session. If the Integrity officer is unable to contact a client who has failed to attend a client information session or an appointment at a local employment centre, the Integrity officer imposes a 15 - Claim procedure disentitlement (D15) from the latest of the following dates:

- the client information session;

- the appointment;

- the business day following the last processed claimant’s report.

The disentitlement is not removed until the client contacts Service Canada and provides an explanation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3145.dita) 

If a renewal application is outstanding, the officer creates an Adjudication Issue (ADJ) WI for Level 2. 

### Determining the reason for the disentitlement

Source topic: `en_EN/task/determining_ent_info_session/determining_the_reason_for_the_disentitlement.dita`

Based on the ACS letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Level 1 officer responsibilities

Source topic: `en_EN/task/determining_ent_info_session/level_1_officer_responsibilities.dita`

The Level 1 officer does not render a decision or remove the D15. If the client contacts Service Canada about a missed client information session or appointment, the Level 1 officer reassigns the WI to Level 2 if there is an outstanding renewal application on the client’s file.

Otherwise, WIs are reassigned to the appropriate Integrity unit. For more information, the officer can refer to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Integrity officer responsibilities

Source topic: `en_EN/task/determining_ent_info_session/integrity_officer_responsibilities.dita`

The National Policy on Levels of Decision specifies that an Integrity officer can rescind a D15 for failing to report to a client information session or appointment.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

When the Integrity officer cannot render a decision because the case requires Level 2 review, the facts are documented and the file is referred to an investigator. 

### Level 2 officer responsibilities

Source topic: `en_EN/task/determining_ent_info_session/level_2_officer_responsibilities.dita`

When a client contacts Service Canada after Integrity imposes a D15 due to a missed client information session, and there is an outstanding renewal application on file, the WI to review the D15 is assigned to Level 2, regardless of the amount of time that has passed since the missed session. When the client contacts Service Canada more than 6 weeks after the missed session, the Level 2 officer determines whether the client had good cause for the delay in contacting Service Canada.

For more information on good cause, the officer can refer to Good cause: Adjudication of a delay — Knowledge .
       [Good cause: Adjudication of a delay — Knowledge](/en/procedure/generic/additionalresources/good_cause.shtml) 

### Client unable to attend due to work

Source topic: `en_EN/task/determining_ent_info_session/client_unable_to_attend_due_to_work.dita`

In some cases, clients are unable to attend a session because they are working that day.

Clients who are unable to attend a session because they are working must be contacted and asked to provide the following information:

- start date of work

- employer’s name, address and telephone number

- type of work (occupation)

- whether the work is full-time or part-time

- expected duration of the employment

- total number of hours of work each week

The officer verifies this information in FTS to make sure the client has correctly reported the work and earnings. If claimant’s reports for the period involved have not yet been processed, the officer examines the file to verify that the work and earnings were correctly reported.

The officer advises clients who are working part-time and still receiving benefits that they must continue to prove entitlement to benefits. The officer obtains, verifies and documents information about the client’s employment. The officer gathers additional information and reviews the client’s entitlement in order to determine whether the client is still available and whether the client is prepared to accept additional work (either full-time or part-time).

Further fact-finding may reveal the client is not looking for other employment, is not prepared to accept other employment, and is placing restrictions on accepting employment. In these cases, the officer must determine the client’s intention. If the client is not seeking other work, a disentitlement may be imposed due to restricted availability or non-availability.

During fact-finding, other contentious issues may be uncovered, such as not reporting or under-reporting earnings, a contentious reason for separation (RFS) or availability. If a disentitlement may be warranted, the contentious issue must also be adjudicated. 

### Note

Source topic: `en_EN/common_notes/note_c_3145.dita`

Note:

Investigators direct the client to attend a fact-finding interview or to reply to a request for information related to the current claim for benefits. Investigators also impose a D15 when a client fails to report to a fact-finding interview or fails to reply to a request for information.

When the D15 is imposed for one of these reasons, it is sent to Integrity for review unless the client files a reconsideration under EIA 112 for the D15 issue. 

## Regional considerations

Source topic: `en_EN/task/determining_ent_info_session/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/determining_ent_info_session/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/determining_ent_info_session/in_fts.dita`

- Is there an indefinite D15?

- Are there earnings declared? 

### In ACS:

Source topic: `en_EN/task/determining_ent_info_session/in_acs.dita`

- Has Integrity sent a letter beginning with C-72, C-73 or C-88? 

### In Imaging:

Source topic: `en_EN/task/determining_ent_info_session/in_imaging.dita`

- Are there any imaged documents relating to the reason the client failed to attend the client information session? 

### In NWS:

Source topic: `en_EN/task/determining_ent_info_session/in_nws.dita`

- What is the date of the client information session?

- Is there an SROC or a WI related to this issue?

- Is there a ROD for the D15? 

## Step by step

Source topic: `en_EN/task/determining_ent_info_session/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/determining_ent_info_session/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/determining_ent_info_session/reviewing_the_file_level_1.dita`

- Determine if the D15 was imposed by Integrity due to a missed client information session:

- If yes, go to step 2.

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- In NWS, determine if there is an outstanding renewal application on the client’s file:

- If yes, go to step 3.

- If no, the D15 issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity .
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml) 

#### Assigning the WI to Level 2

Source topic: `en_EN/task/determining_ent_info_session/assigning_the_wi_to_level_2_level_1.dita`

- Determine if there is an outstanding ADJ Availability WI on the client’s file:

- If yes, go to step 4.

- If no, go to step 5.

- Reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Issue: Select Unable to complete .

- Details: Type “Missed client information session, outstanding renewal application on file.”

- Select Update .

- In NWS, create an ADJ WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next Available User .

- Issue: Select Availability .

- Details: Type “Outstanding D15 for a missed client information session, Level 2 review required.” 

### Level 2

Source topic: `en_EN/task/determining_ent_info_session/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/determining_ent_info_session/reviewing_the_file_level_2.dita`

- In NWS, determine if the file contains all the information required to adjudicate the client’s failure to attend a client information session:

- If no, go to step 2.

- If yes, go to step 5. 

#### Fact-finding

Source topic: `en_EN/task/determining_ent_info_session/fact-finding_level_2.dita`

- Fact-find with the client.

- Determine if the client was reached during fact-finding:

- If the client was reached, go to step 4.

- If the client could not be reached or did not reply to the N-10-00-00 letter, go to Unable to contact the client for missing information .
               [Unable to contact the client for missing information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_ent_info_session#uccmi)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Other .

- Comments: Type “Failed to report.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating good cause

Source topic: `en_EN/task/determining_ent_info_session/adjudicating_good_cause_level_2.dita`

- In NWS, determine if more than 6 weeks have passed since the date of the missed client information session or appointment:

- If it has been more than 6 weeks, go to step 6.

- If it has been 6 weeks or less, go to Adjudication not required — No delay .
               [Adjudication not required — No delay](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_ent_info_session#anrnd)

- Adjudicate the reason for the client’s delay in providing the information about the failure to attend a client information session according to Digest 3 — Antedate and the Good cause job aid .

- Determine if the client shows good cause for the delay in providing the information:

- If yes, go to Good cause shown.
               [Good cause shown.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_ent_info_session#Good_cause_shown)

- If no, go to Good cause not shown .
               [Good cause not shown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_ent_info_session#Good_cause_not) 

#### Adjudication not required — No delay

Source topic: `en_EN/task/determining_ent_info_session/adjudication_not_required__no_delay_level_2.dita`

- In FTS, select the Disqualifications/Disentitlements link to rescind the D15 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI for the D15 issue. 

#### Unable to contact the client for missing information

Source topic: `en_EN/task/determining_ent_info_session/unable_to_contact_the_client_for_missin_7c18738d_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Claim procedure — 15 - Claim procedure disentitlement maintained.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if there is an outstanding registration number:

- If yes, go to step 3.

- If no, go to step 4.

- Select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Decision type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In NWS, complete the WI. 

#### Good cause shown

Source topic: `en_EN/task/determining_ent_info_session/good_cause_shown_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Claim procedure — good cause shown for delay.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if there is an outstanding registration number:

- If yes, go to step 3.

- If no, select the Registration Number(M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Go to step 3.

- In FTS, select the Disqualifications/Disentitlements (M161) link and rescind the D15 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In NWS, complete the WI. 

#### Good cause not shown

Source topic: `en_EN/task/determining_ent_info_session/good_cause_not_shown_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Claim procedure — no good cause for delay.”

- Details: Document the decision and rationale according to Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if there is an outstanding registration number:

- If yes, go to step 3.

- If no, select the Registration Number(M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Go to step 3.

- In FTS, select the Disqualifications/Disentitlements (M161) link and terminate the D15 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualifications/Disentitlements screen opens, complete the following:

- Registration number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate option:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- Verbally communicate the decision to the client.

- In ACS, create and send the A-01-00-00 letter to inform the client that the disentitlement has been terminated. Based on the claim information, select all of the required attributes, including the following:

- Disentitlement terminated and/or removed (2591):

- Select Disentitlement terminated - benefits payable :

- Definite disentitlement end date (1274) .

- Text - Specify reason(s) disentitled (1482) .

- Right to request a Reconsideration (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI. 

## Policy reference

Source topic: `en_EN/task/determining_ent_info_session/policy_reference.dita`

- EIA 48
         [EIA 48](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-48.html)

- EIA 50
         [EIA 50](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-50.html)

- EIA 52
         [EIA 52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
