# Reviewing a Reminder WI to follow up on an interim ROE

Source map: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8.ditamap`

## Summary

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/summary.dita`

Summary : When an interim ROE is created, the officer ensures the employer issues the ROE and if necessary, follows up with the employer to request it. 

## What you need to know

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/untitled_section.dita`

When reviewing the Reminder (REM) WI, the officer determines if the ROE was submitted to Service Canada or if the client received a paper ROE. When there is no indication that the ROE has been issued, the officer follows up with the employer by sending a second Z-02-00-00 letter and creates a new REM WI.

After 2 attempts to contact the employer by mail, if no response is received, the officer refers the file to Integrity, and completes the REM WI. 

## Regional considerations

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/what_you_need_to_look_for.dita`

### In RCM

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/in_rcm.dita`

- Is there an ROE from the employer for the same period of the interim ROE? 

### In NWS

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/in_nws.dita`

- Is there any uploaded document related to the ROE from the employer? 

## Step by step

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/reviewing_the_file_level_1.dita`

- Determine if the ROE for the period covered by the interim ROE has been received:

- If no, go to step 2.

- If yes, go to step Employer provided the ROE .
               [Employer provided the ROE](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8#level1_item_4)

- Determine if the REM WI indicates follow up with the client is required.

- If yes, go to step 3.

- If no, go to step 6.

- Fact-find with the client to determine if the paper ROE was received.

- In NWS, create a new SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “Missing ROE from [employer name].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client received the ROE:

- If no, go to step 6.

- If yes and the client did not submit the ROE, go to Claim procedure .
               [Claim procedure](https://ort-orl.esdc-edsc.canada.ca/en/procedure/activity/claim_procedure.shtml)

- Determine if the employer has been sent 2 Z-02-00-00 letters:

- If no, go to Sending a follow-up letter .
               [Sending a follow-up letter](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8#level1_item_2)

- If yes, go to step Employer was not reached by mail .
               [Employer was not reached by mail](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8#level1_item_5) 

#### Sending a follow-up letter

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/sending_a_follow-up_letter_level_1.dita`

- In ACS, create and send the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Opening Sentence to ER to Request or Clarify ROE/RFS (2794): Select Request ROE Opening Sentence - claimant .

- Request for Record of Employment (2797): Select Follow up request for ROE .

- Previously requested by mail (2799)

- Date ROE requested: Enter the date the original letter was sent.

- End date of period of employment: Enter the employment end date.

- Date of BF: Enter the date the letter is sent + 10 business days.

- Attachments List for Z-02-00-00 (3133):

- Copy of original letter.

- Indicate on letter how letter mailed (2804):

- Sent by registered mail .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1564.dita) 

#### Creating a follow-up Reminder (REM) WI

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/creating_a_follow-up_reminder_rem_wi_level_1.dita`

- In NWS, create a REM WI as follows:

- Complexity: Select Level 1 .

- Reason: Select Missing ROE .

- Comments: Enter the employer’s name.

- Due Date: Enter today’s date + 10 business days.

- Language: Select the appropriate option.

- Details: Type “Follow-up with the employer is required for the missing ROE request. If the employer does not respond to the second letter, refer the file to Integrity.”

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End user: Select Myself and complete the following fields:

- Send to my pending workload: Check the box.

- Reason: Select Fact finding employer .

- Comments: Type “Missing ROE, second letter sent.”

- Bring forward date: Enter today’s date + 10 business days.

- Select Save .

- Add details to the draft SROC, or create a new SROC as follows:

- Details: Type “The employer did not respond to the first letter — a second letter was sent. A Reminder work item was created for follow-up.”

- Select Draft .

- Complete the initial REM WI. No further action is required. 

#### Employer provided the ROE

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/employer_provided_the_roe_level_1.dita`

- In RCM, delete the interim ROE.

- Complete the REM WI. No further action is required. 

#### Employer was not reached by mail

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/employer_was_not_reached_by_mail_level_1.dita`

- Refer to Creating or reassigning a WI — Integrity .

- In NWS, add details to the draft SROC created during fact-finding as follows:

- Details: Type “The employer did not respond to the first or second letter. The file is referred to Integrity for employer non-compliance.”  Select Save .

- Complete the follow-up REM WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1564.dita`

Note:

When sending a copy of an original letter, print the letter locally. For instructions on printing locally while teleworking, refer to Telework: Printing documents locally — Instructions .
       [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml)

     [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml) 

## Policy reference

Source topic: `en_EN/task/reviewing_a_reminder_wi_follow_up_on_an_47eb7ee8/policy_reference.dita`

 
