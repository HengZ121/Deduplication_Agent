# Terminating a D43 disentitlement

Source map: `en_EN/task/terminating_d43/terminating_d43.ditamap`

## Summary

Source topic: `en_EN/task/terminating_d43/summary.dita`

Summary: When clients on a leave of absence voluntarily leave their employment, are dismissed or laid off, the disentitlement for being on a leave from employment without just cause is terminated. 

## What you need to know

Source topic: `en_EN/task/terminating_d43/what_you_need_to_know.dita`

### Leave of absence

Source topic: `en_EN/task/terminating_d43/leave_of_absence.dita`

When clients on a leave of absence decide to voluntarily leave their employment, are dismissed or laid off due to a shortage of work, the 43 - Leave from employment without just cause disentitlement (D43) is terminated on the date before the date the relationship between employer and employee ceased to exist.

The officer must adjudicate the reason for separation (RFS) issue before terminating the D43 disentitlement.

A Level 1 officer can terminate a disentitlement for a leave of absence on a renewal claim when the following conditions are met:

- the client is renewing the claim; and

- the client resumed employment with the same employer after the period of leave of absence and was then laid off or stopped working for a reason that can be allowed at Level 1; or

- the client did not resume the employment for a reason that can be allowed at Level 1; or

- the client accumulated enough insured hours with another employer after the beginning of the period of leave to qualify for benefits.

Continuing claims must be reassigned to Level 2. 

### Processing a renewal claim

Source topic: `en_EN/task/terminating_d43/processing_a_renewal_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . When the claim action status shows In Progress , all Adjudication Issue (ADJ) WIs must be completed before the system can calculate the initial claim or finalize the renewal claim. The MA02 stop payment is removed by the system. 

### Communicating the decision

Source topic: `en_EN/task/terminating_d43/communicating_the_decision.dita`

If a letter of decision is required on an initial or renewal claim, before completing the ADJ WI, the officer creates a Correspondence (COR) Manual decision WI indicating the details of the required letter. If a letter of decision is required on a continuing claim, the officer sends the letter before completing the ADJ WI. 

## Regional considerations

Source topic: `en_EN/task/terminating_d43/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/terminating_d43/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/terminating_d43/in_nws.dita`

- Is there a ROD for the RFS? 

### In FTS:

Source topic: `en_EN/task/terminating_d43/in_fts.dita`

- Is there a 75 - Verification of reason for termination of Employment manual action (MA75) imposed?

- Is there a registration number? 

## Step by step

Source topic: `en_EN/task/terminating_d43/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/terminating_d43/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/terminating_d43/reviewing_the_file_level_1.dita`

- Determine if the claim type is renewal:

- If yes, go to step 2.

- If no, go to Reassigning the WI to Level 2 .
               [Reassigning the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d43#reassignL2)

- Determine if the client is capable and available for work:

- If yes, go to step 3.

- If no, go to Reassigning the WI to Level 2 .
               [Reassigning the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d43#reassignL2)

- Referring to the appropriate set of conditions below, determine if there is enough information to terminate the disentitlement at Level 1, or if additional fact-finding is required.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4783.dita) 

- If additional fact-finding is required, go to step 4.

- If additional fact-finding is not required, go to step 7. 

#### Fact-finding

Source topic: `en_EN/task/terminating_d43/fact-finding_level_1.dita`

- Fact-find with the client to obtain the required information.

- Determine if the client or employer was contacted during fact-finding:

- If the client or employer was not contacted or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to Reassigning the WI to Level 2 .
               [Reassigning the WI to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d43#reassignL2)

- If the client or employer was contacted, go to step 6.

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Leave of absence — [employer’s name] — [last day worked] — [client or employer].”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- Select Save . 

#### Determining if the conditions to allow at Level 1 are met

Source topic: `en_EN/task/terminating_d43/determining_if_the_conditions_to_allow__2ac9dc0f_level_1.dita`

- Determine if all the conditions to terminate the disentitlement are met. Refer to National Policy on Levels of Decision — Section 14 :

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1755.dita) 

#### Conditions to allow at Level 1 met

Source topic: `en_EN/task/terminating_d43/conditions_to_allow_at_level_1_met_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Leave of absence/disentitlement terminated.”

- Details: Type the appropriate option:

- “The client was laid off due to a shortage of work while on a leave of absence. Disentitlement terminated as of XXXX-X.”

- “The client voluntarily left his or her employment while on a leave of absence. Disentitlement terminated as of XXXX-X.”

- “The client was dismissed while on a leave of absence. Disentitlement terminated as of XXXX-X.”

- “The client accumulated enough insured hours with another employer after the beginning of the period of leave to qualify for benefits. Disentitlement terminated as of XXXX-X.”

- References: EIA 32, Digest 6.6.2 — Authorized period of leave - Section 32 and the National Policy on the Levels of Decision.

- In FTS, determine if a D43 is imposed:

- If yes, go to step 10.

- If no, go to step 16.

- Select the Disqualifications/Disentitlements link and terminate the D43 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualification/Disentitlements (M161) transaction opens, complete the following fields:

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End Date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration open for subsequent transactions.

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements terminated and/or removed (2591) .

- Overpayment messages (2452) .

- Right to Request a Reconsideration (with blank option) (4169) .

- In NWS, create a client Note and type “Send the A-01-00-00 letter.”

- Determine if there is an outstanding COR Manual decision WI:

- If no, go to step 14.

- If yes, go to step 16.

- Determine if the system generated a ROD with a negative decision:

- If no, go to step 15.

- If yes, go to step 16.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the Service Canada centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-00 letter required — leave of absence issue.”

- In NWS, complete the WI for the RFS issue. 

#### Reassigning the WI to Level 2

Source topic: `en_EN/task/terminating_d43/reassigning_the_wi_to_level_2_level_1.dita`

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type “not within Level 1 authority.” 

#### Note

Source topic: `en_EN/common_notes/note_c_4783.dita`

Note:

The D43 can be terminated at Level 1 when any one of the following set of conditions is met.

The client resumed employment with the same employer after the leave of absence and then is laid off or stops working for a reason that can be allowed at Level 1 — Conditions to terminate the D43 at Level 1 (all conditions must be met)

- The start and end dates of the leave of absence are available.

- The client returned to work for the same employer after the leave of absence. The RFS for the period of employment occurring after the leave of absence is A - Shortage of work or any other RFS that can be allowed at Level 1. Refer to Voluntary leaving or Dismissal as appropriate to determine what information is needed and if it can be allowed at Level 1.
         [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml) 
         [Dismissal](/en/procedure/activity/dismissal.shtml)

The client did not resume the employment for one of the reasons that can be allowed at Level 1 — Conditions to terminate the D43 at Level 1 (all conditions must be met)

- The start and end dates of the leave of absence are available.

- The client did not return to work after the leave of absence for one of the reasons that can be allowed at Level 1. Refer to Voluntary leaving or Dismissal as appropriate to determine what information is needed and if it can be allowed at Level 1.
         [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml) 
         [Dismissal](/en/procedure/activity/dismissal.shtml)

After the start of the leave of absence, the client accumulated enough hours of insurable employment with one or several other employers to qualify for benefits — Conditions to terminate the D43 at Level 1 (all conditions must be met)

- The start and end dates of the leave of absence are available.

- The client accumulated enough hours of insurable employment with one or more employers since the leave of absence to qualify for benefits. Refer to Calculating a claim for regular benefits to determine if the client is a re-qualifier.
         [Calculating a claim for regular benefits](/en/procedure/activity/calculation.shtml)

     [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml) 
     [Dismissal](/en/procedure/activity/dismissal.shtml) 
     [Voluntary leaving](/en/procedure/activity/voluntary_leaving.shtml) 
     [Dismissal](/en/procedure/activity/dismissal.shtml) 
     [Calculating a claim for regular benefits](/en/procedure/activity/calculation.shtml) 

#### Callout

Source topic: `en_EN/common_notes/note_c_1755.dita`

- the client is renewing the claim; and

- the client resumed employment with the same employer after the period of leave of absence and was then laid off or stopped working for a reason that can be allowed at Level 1; or

- the client did not resume the employment for a reason that can be allowed at Level 1; or

- the client accumulated enough insured hours with another employer after the beginning of the period of leave to qualify for benefits. 

### Level 2

Source topic: `en_EN/task/terminating_d43/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/terminating_d43/reviewing_the_file_level_2.dita`

- Determine if there is a ROD on file for the RFS issue:

- If there is no ROD, go to step 2.

- If there is a ROD, go to step 3. 

#### Adjudicating the reason for separation (RFS)

Source topic: `en_EN/task/terminating_d43/adjudicating_the_reason_for_separation_rfs_level_2.dita`

- Determine why the client is no longer on a leave of absence:

- If the client voluntarily left, refer to Voluntary Leaving and return to step 3.
               [Voluntary Leaving](/en/procedure/activity/voluntary_leaving.shtml)

- If the client was dismissed, refer to Dismissal and return to step 3.
               [Dismissal](/en/procedure/activity/dismissal.shtml) 

#### Record of decision (ROD) — Creation

Source topic: `en_EN/task/terminating_d43/record_of_decision_rod__creation_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Leave of absence/disentitlement terminated.”

- Details: Type the appropriate option:

- “The client voluntarily left his or her employment while on a leave of absence. Disentitlement terminated as of XXXX-X.”

- “The client was dismissed while on a leave of absence. Disentitlement terminated as of XXXX-X.”

- References: EIA 32, Digest 6.6.2 — Authorized period of leave - Section 32 and the National Policy on the Levels of Decision. 

#### Inputs and communication

Source topic: `en_EN/task/terminating_d43/inputs_and_communication_level_2.dita`

- Follow the applicable procedure based on your decision and the status of the claim:

- Disentitlement terminated — Renewal claim
               [Disentitlement terminated — Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d43#DEterm)

- Disentitlement terminated — Continuing claim
               [Disentitlement terminated — Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/terminating_d43#DEtermCont) 

#### Disentitlement terminated — Renewal claim

Source topic: `en_EN/task/terminating_d43/disentitlement_terminated__renewal_claim_level_2.dita`

- In FTS, determine if a D43 is imposed:

- If yes, go to step 6.

- If no, go to step 12.

- Select the Disqualifications/Disentitlements link and terminate the D43 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualification/Disentitlements (M161) transaction opens, complete the following fields:

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End Date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration open for subsequent transactions.

- Select Update .

- In ACS, create and save the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements terminated and/or removed (2591).

- Overpayment messages (2452) .

- Right to Request a Reconsideration (with blank option) (4169) .

- In NWS, create a client Note and type “Send the A-01-00-00 letter.”

- Determine if there is an outstanding COR Manual decision WI:

- If no, go to step 10.

- If yes, go to step 12.

- Determine if the system generated a ROD with a negative decision:

- If no, go to step 11.

- If yes, go to step 12.

- Create a COR WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select the appropriate option.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select Manual decision .

- Details: Type “A-01-00-00 letter required — leave of absence issue.”

- In NWS, complete the WI for the RFS issue. 

#### Disentitlement terminated — Continuing claim

Source topic: `en_EN/task/terminating_d43/disentitlement_terminated__continuing_claim_level_2.dita`

- Determine if there is an outstanding registration number for the voluntary leaving issue:

- If there is an outstanding registration number, go to step 6.

- If there is no outstanding registration number, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if there is an MA75 on file:

- If yes, go to step 7.

- If no, go to step 8.

- Select the Renewal/Revised (M106) transaction to remove the MA75 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 75 — Verification of reason for termination of Employment .

- Rescind: Check the box.

- Decision Type: Select 3 — Revised .

- Contentious: Select 1 — No .

- Complete: Select C — Yes to complete the registration number.

- Select Update .

- In FTS, determine if a D43isimposed:

- If yes, go to step 9.

- If no, go to step 11.

- Select the Disqualifications/Disentitlements link and terminate the D43 as follows:

- Select the original disentitlement.

- Select Modify .

- When the Disqualification/Disentitlements (M161) transaction opens, complete the following fields:

- Registration Number: Select the appropriate registration number.

- Action: Select T - Terminate/Modify .

- End Date: Enter the disentitlement end date.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 3 - An overpayment resulted due to a definite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration open for subsequent transactions.

- Select Update .

- In ACS, create and send the A-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements terminated and/or removed (2591).

- Overpayment messages (2452) .

- Right to Request a Reconsideration (with blank option) (4169) .

- In NWS, complete the WI for the RFS issue. 

## Policy reference

Source topic: `en_EN/task/terminating_d43/policy_reference.dita`

- EIA 32
         [EIA 32](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-32.html)

- Digest 6.6.2 — Authorized period of leave - Section 32
         [Digest 6.6.2 — Authorized period of leave - Section 32](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/periods-of-leave.html#a6_6_2)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
