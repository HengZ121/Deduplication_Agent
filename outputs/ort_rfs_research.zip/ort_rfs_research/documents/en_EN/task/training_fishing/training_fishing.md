# Adjudicating non-referred training: Regular or fishing benefits — Continuing claim

Source map: `en_EN/task/training_fishing/training_fishing.ditamap`

## Summary

Source topic: `en_EN/task/training_fishing/summary.dita`

Summary: When clients receiving regular benefits decide to take non-referred training, adjudication is required to determine if they are entitled to benefits during the training period. 

## What you need to know

Source topic: `en_EN/task/training_fishing/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 25, 2021

Source topic: `en_EN/task/training_fishing/training_reported_between_september_27__795a0aca.dita`

A transitional measure under which ACP automatically adjudicated and allowed all training effective September 27, 2020, ended on September 11, 2021. The intent of this measure was to prevent any delay in payment to clients who reported training. To receive regular benefits, clients must still be able to prove that they are capable of and available for work while attending non-referred training.

The Commission has the authority to impose a retroactive 3 - Not available disentitlement (D)3 if the client is unable to prove availability, even if ACP initially allowed the training. Therefore, if the client reports not being available while attending non-referred training, and benefits were previously paid for this period, the officer reviews the client’s availability. When the Level 2 officer determines that the client has not proven availability from the start date of the course, the officer imposes a retroactive D3. For more information on availability, the officer refers to BE 2020-05 — Emergency Response Benefit Transition Provisions , Digest 10.3 — Credibility and 10.12 — Courses of instruction/employment measures .
       [BE 2020-05 — Emergency Response Benefit Transition Provisions](/en/policy/bememo/be2020-05.shtml) 
       [10.3 — Credibility](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/credibility.shtml#a10_3_0) 
       [10.12 — Courses of instruction/employment measures](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_0) 

### Impact of training on regular or fishing benefits

Source topic: `en_EN/task/training_fishing/impact_of_training_on_regular_or_fishin_e0a51eda.dita`

Taking a training course on one’s own initiative creates an availability issue. When clients are receiving regular benefits, they must be available for and actively seeking employment. Training should not limit a client’s employment opportunities. A client receiving fishing benefits may also take training. The adjudication and inputs are the same whether the claim is for regular or fishing benefits.

This includes clients who are attending short-term training courses and targeted initiatives. For a complete list of non-referred short-term courses and targeted initiatives, the officer refers to the job aid .
       [job aid](/en/procedure/generic/additionalresources/shortterm_courses_ti.shtml)

Before adjudicating availability during non-referred training, it is important to first consider whether the client could be referred to the course under EIA 25 . This step ensures that entitlement to benefits is correctly determined. Clients are considered unemployed and capable of and available for work when attending referred training.
       [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-16.html#h-16)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4804.dita) 

**Long-tenured workers**

A client who reports attending full-time training may be identified as a long-tenured worker. If the conditions are met, a client who is identified as a long-tenured worker and who wishes to attend self-funded full-time training can be referred to that training by Service Canada.

To be considered a long-tenured worker, a client must meet the following 2 conditions:

- have paid at least 30% of the maximum EI premiums for at least 7 of the last 10 years;

- not have received more than 35 weeks of regular benefits in the last 156 weeks (3 years) before the BPC of the current claim.

Service Canada has the authority to approve full-time training for a long-tenured worker. However, before adjudicating training, the officer adjudicates other contentious issues to determine if the client is entitled to benefits. This can help the client better understand the decision-making process, as the client may assume that for a referred training situation, contentious issues are automatically allowed.

When a client is identified as a long-tenured worker, the officer refers to Adjudicating training for a long-tenured worker — Continuing claim .
       [Adjudicating training for a long-tenured worker — Continuing claim](/en/procedure/task/rend-dec-form-ld-con-adj-tra-lt-worker-con.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0159.dita) 

### Availability during non-referred training

Source topic: `en_EN/task/training_fishing/availability_during_non-referred_training.dita`

When clients report that they are attending full-time training on their own initiative, the officer refers to BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training and the Digest of Benefit Entitlement Principles 10.12.2.8 — Hours of work . Both the BE Memo and the Digest explain that, under FCA A-29-22 , when adjudicating availability, the officer must consider the clients’ work history while attending training, in addition to other factors (i.e. the number of hours clients are attending training). Clients can rebut the presumption of non-availability if they can demonstrate having a regular work history outside of the training hours while taking full-time training. Using any previous ROEs, the officer reviews the number of hours the client worked while attending training to determine if the client can rebut the presumption of non-availability. Clients must also demonstrate a willingness and ability to remain available for a similar work schedule. Clients must not reduce or restrict their available hours of work beyond what is reasonable, given their work history, while attending training.
       [BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training](/en/policy/bememo/be2023-05.shtml) 
       [Digest of Benefit Entitlement Principles 10.12.2.8 — Hours of work](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2_8) 
       [FCA A-29-22](https://www.canlii.org/en/ca/fca/doc/2023/2023fca169/2023fca169.html)

The officer determines the total number of hours per week that is being spent on the training, including :

- class time

- study time

- time spent working on assignments

- time spent doing research

Additional fact-finding or follow-up is not required when a client reports training of up to 9 hours per week.

Clients attending a training course equal to or greater than 10 hours per week must be willing to seek and accept all hours of work that are available to them in the labour market, including evenings, nights, shift work, inconvenient or long hours and overtime. A client who is unwilling or unable to quit the course in order to accept these hours of work, or whose job search efforts demonstrate such an unwillingness or inability, may not be able to prove availability for work.

The client’s individual circumstances must be examined to determine if the client is avoiding suitable employment because of an unwillingness or inability to work certain hours. If so, a disentitlement may be imposed.

Correspondence courses are treated the same as any other training. 

### Checklists

Source topic: `en_EN/task/training_fishing/checklists.dita`

When clients report that they are participating in a short-term course or targeted initiative, the officer completes the appropriate checklist:

- For clients participating in a program with Women in Science and Engineering, the officer completes the Training: Women in Science and Engineering — Checklist .
         [Training: Women in Science and Engineering — Checklist](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Training-Women_in_Science_and_Engineering-Checklist.doc)

- For clients taking a short-term training course or participating in Employment Assistance Services, the officer completes the Training: Short-term or employment assistance services — Checklist .
         [Training: Short-term or employment assistance services — Checklist](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Training-Short-term_or_employment_assistance_services-Checklist.doc)

- For clients taking regular non-referred training, the officer completes the Training: Non-referred training for regular benefits — Checklist .
         [Training: Non-referred training for regular benefits — Checklist](https://014gc.sharepoint.com/:w:/r/sites/94714/checklists/Training-Non-referred_training_for_regular_benefits-Checklist.doc) 

### Automated decisions

Source topic: `en_EN/task/training_fishing/automated_decisions.dita`

When a client reports non-referred training in a claimant’s report or on MSCA, an electronic questionnaire is created and can be accessed in NWS. If the electronic questionnaire meets the Levels of Decision criteria for Level 1 adjudication, ACP can automate the adjudication of the non-referred training. In this case, ACP creates a record of decision (ROD) and inputs the training project data in FTS.

When ACP cannot adjudicate the non-referred training issue, a Level 2 officer must adjudicate the decision. When the claim is established, ACP creates a Claim Review (CR) WI, obtains a revised registration number and imposes a manual action (MA72). 

### Information reported after claimant’s reports have been processed

Source topic: `en_EN/task/training_fishing/information_reported_after_claimants_re_82afb561.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4804.dita`

Note:

If a client quits employment or refuses an offer of employment to attend a non-referred training course, a non-referred short-term training course or a targeted initiative, the officers adjudicates the reason for separation on a separate WI. 

### Note

Source topic: `en_EN/common_notes/note_c_0159.dita`

Note:

To determine if a client is a long-tenured worker, the officer refers to Determining if a client is a long-tenured worker .
       [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml)

     [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml) 

## Regional considerations

Source topic: `en_EN/task/training_fishing/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/training_fishing/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/training_fishing/in_fts.dita`

- Is there a registration number for the non-referred training issue?

- Is there a stop payment (MA72) for the non-referred training issue?

- Have claimant’s reports been processed for the period in question?

- If yes, when was the original statement made?

- Is there a pending claimant’s report?

- Is there training information on the Project tab?

- Is it non-referred training (code 90) or referred training (codes 9, 35, 53, 95, 97 and 98)? 

### In NWS:

Source topic: `en_EN/task/training_fishing/in_nws.dita`

- Has the training questionnaire been completed?

- Is there a ROD for the non-referred training issue?

- Is there an SROC or an Action Item (AI) WI with the training information, from either the Training: Non-referred part-time training — Checklist or the Training: INS3141 Training course information — Form ?
         [Training: Non-referred part-time training — Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Training-Non-referred_part-time_training-Checklist.doc) 
         [Training: INS3141 Training course information — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ESDC-INS3141.pdf) 

### In Imaging:

Source topic: `en_EN/task/training_fishing/in_imaging.dita`

- Is there non-referred training information or the INS3141 form? 

## Step by step

Source topic: `en_EN/task/training_fishing/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/training_fishing/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_fishing/reviewing_the_file_level_1.dita`

- In NWS, determine if there is an existing ROD for the non-referred training issue:

- If no , go to step 2.

- If yes and ACP allowed training reported between September 27, 2020 and September 11, 2021, but new information indicates that the client is not available, go to step 6.

- If yes, and it is any other situation, go to Automated decision .
               [Automated decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_fishing#auto_decision)

- In FTS, determine if there is referred training information displayed on the Project tab:

- If no , go to step 3.

- If yes, refer to Confirming referred training: Regular or fishing benefits — Continuing claim .
               [Confirming referred training: Regular or fishing benefits — Continuing claim](/en/procedure/task/training_cc.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2699.dita)

- In FTS, in the Claimaint category field in the Special Coding tab, determine if the client has been categorized:

- If the Claimaint category field is blank, refer to Determining if a client is a long-tenured worker :

- If the client is identified as a long-tenured worker, go to step 4.

- If the client is not identified as a long-tenured worker, go to step 5.

               [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml)

- In NWS, review the training questionnaire from the application or the training checklist on file and determine if the client reports attending full-time training:

- If no, go to step 5.

- If yes, adjudicate the claim as referred training. Refer to Adjudicating training for a long-tenured worker — Continuing claims .
               [Adjudicating training for a long-tenured worker — Continuing claims](/en/procedure/task/rend-dec-form-ld-con-adj-tra-lt-worker-con.shtml)

- If the client is correcting previously provided information or providing previously omitted information, determine if the information may impact the client’s entitlement to previously paid benefits:

- If no, go to step 6.

- If yes, and the issue is availability while the client is attending non-referred training that was reported between September 27, 2020 and September 25, 2021, go to step 6.

- If yes, and it is any other issue, determine if the issue should be referred to Integrity by consulting Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine, if there is enough information to adjudicate the non-referred training:

- If no, go to step 7.

- If yes, go to step 10. 

#### Fact-finding

Source topic: `en_EN/task/training_fishing/fact-finding_level_1.dita`

- Fact-find with the client. If not already on file, complete the appropriate Checklist .

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 9.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_fishing#ReassignWI)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training–regular benefits.”

- Details: If completed during fact-finding, copy and paste the checklist. Document additional fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/training_fishing/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine the type of training the client is attending:

- If the client is attending regular non-referred training, go to step 11.

- If the client is attending a short-term training course or a targeted initiative, go to step 12.

- Determine the number of hours per week spent on the non-referred training:

- If the number of hours is 10 to 14 , go to step 12.

- If the number of hours is 15 or more , go to step 13.

- If the number of hours is 9 or less , go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_fishing#condition_met)

- Determine if the following conditions are met for the regular non-referred training of 10 to 14 hours per week, for the short-term training course or for the targeted initiative:

- The client is available and capable of working and is not limiting the acceptance of employment (or the hours or days of availability) because of the training.

- If the course conflicts with a full-time job, the client is willing to quit or change the course schedule to accept the full-time employment.

- If both conditions are met, go to Entitlement conditions met .
                   [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_fishing#condition_met)

- If either condition is not met, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_fishing#ReassignWI)

- Determine if the following conditions are met for the regular non-referred training:

- All of the course obligations occur outside the normal work hours of their usual occupation.

- The client is willing to quit the course or change the course schedule to accept full-time employment.

- The client is available and capable of working and is not limiting acceptance of employment.

- If all of the conditions are met, go to Entitlement conditions met .
                   [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_fishing#condition_met)

- If any of the conditions are not met, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_fishing#ReassignWI)

- If both conditions are met, go to Entitlement conditions met .

- If either condition is not met, go to Reassigning the issue to Level 2 .

- If all of the conditions are met, go to Entitlement conditions met .

- If any of the conditions are not met, go to Reassigning the issue to Level 2 . 

#### Automated decision

Source topic: `en_EN/task/training_fishing/automated_decision_level_1.dita`

- Determine if an MA72 is imposed and if there is an outstanding registration number for the non-referred training issue:

- If an MA72 is imposed but there is no registration number, go to step 2.

- If an MA72 is imposed and there is a registration number, go to step 3.

- If no MA72 is imposed but there is a revised registration number, go to step 4.

- If none of the above applies, go to step 5.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: C - Yes .

- Select Update .

- Go to step 5.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Entitlement conditions met

Source topic: `en_EN/task/training_fishing/entitlement_conditions_met_level_1.dita`

- In NWS, create a ROD with the following information:

- Comments: Type “Non-referred training — availability in order.”

- Details: Type “Meets Levels of Decision criteria to allow non-referred training at Level 1.” Document any additional details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the non-referred training information has been input on the Project tab:

- If the non-referred training information has been input, go to step 3.

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Determine if there is a pending claimant’s report:

- If there is a pending claimant’s report, update the outstanding claimant’s report and go to step 4.
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 4.

- Determine if an MA72 is imposed and if there is an outstanding registration number for the non-referred training issue:

- If an MA72 is imposed but there is no registration number, go to step 5.

- If an MA72 is imposed and there is a registration number, go to step 6.

- If no MA72 is imposed but there is a revised registration number, go to step 7.

- If none of the above applies, go to step 8.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: C - Yes .

- Select Update .

- Go to step 8.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/training_fishing/reassigning_the_issue_to_level_2_level_1.dita`

- In FTS, determine if the non-referred training information has been input in the Project tab:

- If the non-referred training information has been input, go to step 2.

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input in as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select — 90 - Non-referred claimant .

- Select Update .

- Determine if there are full weeks of benefits payable before the non-referred training start date:

- If there are full weeks of benefits payable, go to step 3.

- If there are no full weeks of benefits payable prior, go to step 4.

- In FTS, input or update any outstanding claimant’s reports for the period before the training start date.

- In FTS, select the Renewal/Revised (M106) transaction and input an MA72 as follows:

- Manual action: Select 72 - Additional Training information required .

- Select Update .

- In NWS, reassign the WI as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type the appropriate reason:

- “Unable to contact client for fact-finding.”

- “Not within Level 1 authority.” 

#### Note

Source topic: `en_EN/common_notes/note_c_2699.dita`

Note:

For subsequent claims, the referred training information may be displayed on the Project tab of the previous BPC. In FTS, review the previous BPC on the Dormant tab. 

### Level 2

Source topic: `en_EN/task/training_fishing/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_fishing/reviewing_the_file_level_2.dita`

- In NWS, determine if there is an existing ROD for the training issue:

- If no , go to step 2.

- If yes and ACP allowed training reported between September 27, 2020 and September 11, 2021, but new information indicates that the client is not available, go to step 6.

- If yes, and it is any other situation, complete the non-referred training WI.

- In FTS, determine if there is referred training information displayed on the Project tab:

- If there is no referred training information displayed on the Project tab, go to step 3

- If there is referred training information displayed on the Project tab, refer to Confirming referred training: Regular or fishing benefits — Continuing claim .
               [Confirming referred training: Regular or fishing benefits — Continuing claim](/en/procedure/task/training_cc.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2699.dita)

- In FTS, in the Claimant category field in the Special Coding tab, determine if the client has been categorized:

- If the Claimant category field is blank, refer to Determining if a client is a long-tenured worker :

- If the client is identified as a long-tenured worker, go to step 4.

- If the client is not identified as a long-tenured worker, go to step 5.

               [Determining if a client is a long-tenured worker](/en/procedure/task/det_client_ltw.shtml)

- In NWS, review the training questionnaire from the application or the training checklist on file and determine if the client states to attend full-time training:

- If no, go to step 5.

- If yes, adjudicate the claim as referred training. Refer to Adjudicating training for a long-tenured worker — Continuing claims .
               [Adjudicating training for a long-tenured worker — Continuing claims](/en/procedure/task/rend-dec-form-ld-con-adj-tra-lt-worker-con.shtml)

- If the client is correcting previously provided information or providing previously omitted information, determine if the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 6.

- If yes, and the issue is availability while the client is attending non-referred training that was reported between September 27, 2020 and September 11, 2021, go to step 6.

- If yes, and it is any other issue, determine if the issue should be referred to Integrity by consulting Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4805.dita)

- Determine if there is enough information to adjudicate the non-referred training issue:

- If no, go to step 7.

- If yes, go to step 10. 

#### Fact-finding

Source topic: `en_EN/task/training_fishing/fact-finding_level_2.dita`

- Fact-find with the client. If not already on file, use the appropriate Checklist .

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 9.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 10.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — regular benefits.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating non-referred training

Source topic: `en_EN/task/training_fishing/adjudicating_non-referred_training_level_2.dita`

- Adjudicate the non-referred training according to the entitlement principles of Digest 10.12.2 — Persons attending courses on their own initiative and BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training and determine if the client has proven being available:

- If the client has proven being available, go to Entitlement conditions met .
               [Entitlement conditions met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_fishing#condition_met_l2)

- If the client has not proven being available, go to Entitlement conditions not met .
               [Entitlement conditions not met](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_fishing#conditions_not_met_l2) 

#### Entitlement conditions met

Source topic: `en_EN/task/training_fishing/entitlement_conditions_met_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — availability in order.”

- Details: Document the decision and rationale. Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the non-referred training information has been input in the Project tab:

- If the non-referred training information has been input, go to step 3.

- If the non-referred information has not been input, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select New – 90 - Non-referred claimant .

- Select Update .

- Determine if there is a pending claimant report:

- If there is a pending claimant report, update the outstanding claimant’s report and go to step 4.
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant report, go to step 4.

- Determine if an MA72 is imposed and if there is an outstanding registration number for the non-referred training issue:

- If an MA72 is imposed but there is no registration number, go to step 5.

- If an MA72 is imposed and there is a registration number, go to step 6.

- If no MA72 is imposed but there is a revised registration number, go to step 7.

- If none of the above applies, go to step 8.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3- Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 2 - Yes .

- Complete: C - Yes .

- Select Update .

- Go to step 8.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Entitlement conditions not met

Source topic: `en_EN/task/training_fishing/entitlement_conditions_not_met_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — not available — D3 from w/c XXXX-X to XXXX-X.”

- Details: Document the decision and rationale according to Digest Chapter 10.12.2 . Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Digest Chapter 10.12.2](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2) 
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- If fact-finding by telephone was not attempted, select Draft and go to step 2.

- If the client was reached by telephone during fact-finding, select Draft and go to step 2.

- If the client was not reached by telephone during fact-finding, select Save and go to step 3.

- Verbally communicate the decision to the client.

- In FTS, determine if there is an outstanding registration number for the non-referred training issue:

- If there is an outstanding registration number, go to step 4.

- If there is no outstanding registration number, assign one on the Registration Number (M025, M030, M035) transaction as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if an MA72 is imposed for the non-referred training issue:

- If an MA72 is imposed, go to step 5.

- If an MA72 is not imposed, go to step 6.

- Select the Renewal/Revised (M106) transaction to remove the MA72 and input the disentitlement as follows:

- Registration number: Select the related registration number.

- Manual action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Disentitlement start date (DD/MM/YYYY): Enter the start date of the disentitlement (Monday to Friday).

- Disentitlement end: Select the appropriate option:

- If the end date of the course has not been reached or is unknown, select Indefinite .

- If the training has ended, select Specific date and enter the end date of the course.

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate message:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Update .

- Go to step 7.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the disentitlement as follows:

- Registration Number: Select the applicable registration number.

- Action: Select Add .

- Disentitlement: Select 3 - Not available .

- Disentitlement start date (DD/MM/YYYY): Enter the start date of the disentitlement (Monday to Friday).

- Disentitlement end: Select the appropriate option:

- If the end date of the course has not been reached or is unknown, select Indefinite .

- If the training has ended, select Specific date and enter the end date of the course.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate message:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4806.dita)

- Determine if the non-referred training information has been input in the Project tab:

- If the non-referred training information has been input, go to step 8.

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Update any outstanding claimant’s report .

- Determine the type of training the client is attending:

- If the client is attending regular non-referred training, go to step 10.

- If the client is attending a short-term course or a targeted initiative, go to step 11.

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D3 - Not available - Various Reasons (2986) .

- Select D3 - On a non-approved training course – Availability not proven/Restrictions while on a training course/ Not looking for work (2987) .

- We / In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Right to Request a Reconsideration (with blank option) (4169) : Select Right to Request a Reconsideration .

- Go to step 12.

- In ACS, create and send the D-01-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Disentitlements (2976): Select D3 - Not available - Various Reasons (2986) .

- Select D3 - No reply to written request/text: Why not available/text: Why not available for only ONE day (2992) .

- Select D3 - Text : Indicate reason why client not available .

- We / In addition, we (2687) .

- Indefinite / Definite disentitlement dates / Date being disentitled (13020) .

- Text - Specify reason(s) disentitled (1482): Type “you are participating in a short-term course [or the type of initiative] on your own initiative.”

- Right to Request a Reconsideration (with blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4805.dita`

Note:

If the client reports not being available while attending non-referred training and benefits were previously paid for this period, refer to BE 2020-05 — Emergency Response Benefit Transition Provisions to determine whether a retroactive D3 must be imposed on the claim.
       [BE 2020-05 — Emergency Response Benefit Transition Provisions](/en/policy/bememo/be2020-05.shtml)

     [BE 2020-05 — Emergency Response Benefit Transition Provisions](/en/policy/bememo/be2020-05.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_4806.dita`

Note:

Even though ACP initially allowed the training, impose the disentitlement retroactively if the client has not proven availability from the start date of the course. 

## Policy reference

Source topic: `en_EN/task/training_fishing/policy_reference.dita`

- EIA 18
         [EIA 18](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-18.html)

- EIA 25
         [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- EIR 9.002
         [EIR 9.002](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-9.002.html)

- Digest 10.12.2 — Persons attending courses on their own initiative
         [Digest 10.12.2 — Persons attending courses on their own initiative](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training
         [BE 2023-05 — Federal Court of Appeal decision: William Page (A-29-22) and availability for students on full-time training](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2023-05.shtml) 
