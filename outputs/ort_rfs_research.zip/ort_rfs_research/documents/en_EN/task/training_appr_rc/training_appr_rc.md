# Confirming apprenticeship training — Renewal claim

Source map: `en_EN/task/training_appr_rc/training_appr_rc.ditamap`

## Summary

Source topic: `en_EN/task/training_appr_rc/summary.dita`

Summary: When clients attending an apprenticeship course apply to renew their claim, the officer determines if they were referred to the apprentice course by a designated authority. 

## What you need to know

Source topic: `en_EN/task/training_appr_rc/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 21, 2021

Source topic: `en_EN/task/training_appr_rc/training_reported_between_september_27__5271b231.dita`

A transitional measure, under which ACP adjudicated and allowed all training effective September 27, 2020 has ended on September 11, 2021. If there is a WI in NWS to confirm referred training, the officer follows the steps to confirm that the client is participating in referred training. If after fact-finding the officer cannot confirm that the training was referred, the officer consults the appropriate non-referred training task. 

### Adjudication required on manually registered claims

Source topic: `en_EN/task/training_appr_rc/adjudication_required_on_manually_regis_d5cd9e4c.dita`

Training was automatically adjudicated and electronic records of decision (RODs) were created only on claims that were automated in ACP.

The officer manually registers claims that are not automated through ACP. Training is not automatically adjudicated on manually registered claims. Instead, ACP assigns an Adjudication Issue (ADJ) WI to an officer because it could not automate the decision. Adjudication of these training ADJ WIs is required , and the officer follows the appropriate procedures to resolve them. Even if ACP initially allowed training, when a training ADJ WI is assigned (e.g. upon renewal), the officer must adjudicate. Additionally, if it is determined that a disentitlement applies from the start date of the training course, the Level 2 officer imposes a retroactive D3. 

### Apprenticeship training

Source topic: `en_EN/task/training_appr_rc/apprenticeship_training.dita`

An apprenticeship is a formal program of skills acquisition in a trade, consisting of alternating periods of on-the-job and classroom training, and leading to certification.

Clients who register for apprenticeship training receive an information package from a Service Canada Centre (SCC), the province or the territory, depending on the region. Clients receive the package 3 to 6 weeks before the training begins and it contains the following information:

- instructions on how to file an EI claim

- a reference code (in most cases) to use when applying online using AW

- details about exemption reporting and advance payment 

### Determining if the client was referred to the apprenticeship course

Source topic: `en_EN/task/training_appr_rc/determining_if_the_client_was_referred__0acbcd90.dita`

When applying for EI benefits, clients are asked if they are part of a group of employees in an apprenticeship program and if they were given a reference code to submit their application. If they answer “yes”, they are prompted to enter the 16-digit code. When they enter the reference code, a specialized EI application is presented. If they answer “no”, they are presented with a regular EI application. The reference code contains the following information:

- Service Canada Processing Centre (digits 1 to 4)

- Apprenticeship application form type (02) (digits 5 and 6)

- Year (digits 7 to 10)

- Identifier (digits 11 to 16)

Clients may indicate on the EI application that they do not have a reference code, but later indicate that they are an apprentice and attending a full-time course of instruction to which they were referred by a designated authority. In this situation, clients must provide proof of the referral to the apprenticeship course. As proof, clients may provide one of the following:

- the reference code they were given

- a copy of the training documentation given to them by the provincial program officer when they registered for the course.

If clients provide proof of the referral to the apprenticeship course, the system uses the reference code provided to input the training information when the renewal claim is finalized. If clients do not provide proof of the referral, the client’s attendance at the course of instruction must be adjudicated as non-referred training.

The reference code serves only as proof of referral to the course, and clients are considered available for work while attending the course. The reference code does not authorize clients to quit their employment to attend the approved training course. A contentious reason for separation (RFS) requires adjudication. 

### Adjudicating voluntary leaving

Source topic: `en_EN/task/training_appr_rc/adjudicating_voluntary_leaving.dita`

If a designated authority refers a client to an apprenticeship before voluntarily leaving a job, the officer must follow the Adjudicating voluntary leaving (Level 1) — Course of instruction procedure to determine if the voluntary leaving is authorized. The voluntary leaving and the confirmation of the referred apprenticeship are separate issues.
       [Adjudicating voluntary leaving (Level 1) — Course of instruction](/en/procedure/activity/voluntary_leaving.shtml) 

### Exemption from completing claimant’s reports

Source topic: `en_EN/task/training_appr_rc/exemption_from_completing_claimants_reports.dita`

Unless there is a situation that may affect their EI payments, apprentice trainees are not required to complete claimant’s reports during the training period. When a client applies for a renewal claim with a reference code, the specialized apprenticeship application displays the exemption declaration. If the client requests exemption from completing claimant’s reports, the system automatically inputs the NO-CR-CODE on the Project Data - Training (M171) transaction. If the client submits the Claimant's report: INS5173 Request for exemption from reporting — Form form (INS5173), the officer must refer to Exemption from reporting .
       [Claimant's report: INS5173 Request for exemption from reporting — Form](http://forms-formulaires.prv/lc/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5173.pdf) 
       [Exemption from reporting](/en/procedure/activity/exemption_reporting.shtml) 

### Apprentice indicator

Source topic: `en_EN/task/training_appr_rc/apprentice_indicator.dita`

The RFS on the client’s last ROE are used to determine the Apprentice indicator code on the M171 . The apprentice indicator code indicates if benefits can continue to be paid after the apprenticeship period and if the client requested advance pay. All apprenticeship claims display a no advance pay indicator, except when advance pay requested by the client is documented on the claim.
       [no advance pay](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#_No_advance_pay) 
       [advance pay requested by the client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#_Advance_Pay_requested)

**No advance pay**

If the client does not request advance pay, the Apprentice indicator code on the M171 is determined as follows:

- When the RFS is J - Apprenticeship Training:

- When the RFS is not J - Apprenticeship Training:

**Advance pay requested by the client**

Advance pay is an option available to a client enrolled in apprenticeship training. It is not promoted or presented as an option on the EI application, however, clients can request advance pay. Any request for advance pay is documented on the claim. If the client requests advance pay, the Apprentice indicator code on the M171 is determined as follows:

- When the RFS is J - Apprenticeship Training:

- When the RFS is not J - Apprenticeship Training:

Advance pay is normally made for the period of a claimant’s report. Payments are made at the beginning of that period instead of at the end of it. Even if the payment is issued in advance, the client is still required to complete the related claimant’s reports. If the client does not complete the claimant’s reports, the officer imposes a 37 - Advance pay apprentice - entitlement conditions not met or claimant failed to return reports disentitlement (D37). 

### Outstanding disentitlements

Source topic: `en_EN/task/training_appr_rc/outstanding_disentitlements.dita`

If there is an existing 3 - Not available disentitlement (D3) imposed and the client is referred to training under EIA 25, the disentitlements are terminated on the day before the training starts. 

### Processing the claim

Source topic: `en_EN/task/training_appr_rc/processing_the_claim.dita`

During processing, a renewal claim displays one of the following statuses:

- In Progress (Automation)

- In Progress (Manual)

If the client provided a reference code in the application, the system creates a SA WI. No Adjudication Issue (ADJ) WI is created for the apprentice issue. Officers are responsible for completing the M171 .

If the client did not provide a reference code on the application, the system creates a CA WI. For the apprentice issue, the system creates an ADJ WI. When the Claim action status is In Progress all ADJ WIs must be completed before the system can finalize the renewal. There is a Resolve Issue tab for ADJ Training WIs which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a record of decision (ROD) based on the Resolve Issue screens. When the renewal is finalized, the system also generates the required transactions (e.g. training information, disentitlement) based on the Resolve Issue screens. 

### Communicating the decision

Source topic: `en_EN/task/training_appr_rc/communicating_the_decision.dita`

No letter is sent when the training is allowed. 

## Regional considerations

Source topic: `en_EN/task/training_appr_rc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/training_appr_rc/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/training_appr_rc/in_fts.dita`

- Is there a D3 preventing payment during the apprenticeship period?

- Is there apprenticeship information on the Project tab for the training period?

- If the client is requesting advance payment:

- is the benefit rate greater than 0?

- is the advance payment request within the start and end weeks of the course?

- is the requested week of payment later than the last week processed? 

### In RCM:

Source topic: `en_EN/task/training_appr_rc/in_rcm.dita`

- Is the RFS on the last ROE J - Apprenticeship Training ? 

### In NWS:

Source topic: `en_EN/task/training_appr_rc/in_nws.dita`

- Is there any documentation (SROC, Action Item [AI] or Call Back [CB] WI) indicating that the client was asked to provide the reference code or a copy of the training documentation for the apprenticeship program?

- Is there any documentation (SROC, AI or CB WI) indicating the client’s reference code for the apprenticeship program?

- Is the client requesting advance payment?

- Is there information on file (SROCs or AI WIs) indicating that the client requests exemption from completing claimant’s reports during the apprenticeship training period? 

### In Imaging:

Source topic: `en_EN/task/training_appr_rc/in_imaging.dita`

- Is there a copy of the client’s apprenticeship training documentation? 

## Step by step

Source topic: `en_EN/task/training_appr_rc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/training_appr_rc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_appr_rc/reviewing_the_file_level_1.dita`

- Determine if the reference code or training documents for the client’s apprenticeship program are on file:

- If proof of the apprenticeship program is not on file, go to step 2.

- If proof of the apprenticeship program is on file, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/training_appr_rc/fact-finding_level_1.dita`

- Fact-find with the client and ask the client to provide the reference code or a copy of the training documents for the apprenticeship program.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4794.dita)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not respond to the N-10-00-00 letter, go to Referral for apprenticeship course not confirmed .
               [Referral for apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#Valid_reference_code)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Apprenticeship training.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Moving the training information WI to Pending

Source topic: `en_EN/task/training_appr_rc/moving_the_training_information_wi_to_pending_level_1.dita`

- Determine if the client stated the reference code or training documents would be provided at a later time:

- If the client stated the reference code or training documents would be provided at a later time, go to step 6.

- If the client provided the reference code, go to step 9.

- In NWS, move the ADJ WI to Pending as follows:

- Pending reason: Select Fact-finding client .

- Comments: Type “Waiting for proof of apprenticeship program.”

- Bring forward date: Enter the date proof was requested + 10 working days.

- Select OK .

- When the ADJ WI moves to the current workload, determine if proof was provided:

- If proof was provided, go to step 8.

- If no proof was provided, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#Valid_reference_code) 

#### Determining if the client was referred to the apprenticeship course

Source topic: `en_EN/task/training_appr_rc/determining_if_the_client_was_referred__0acbcd90_level_1.dita`

- Determine if the client provided a reference code:

- If yes, go to step 9.

- If no, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#Valid_reference_code)

- Validate the reference code provided as follows:

- Under the Search tab, select Search Reference Code .

- Search SCC: Enter the first 4 numbers of the reference code.

- Compare the reference code provided to those in the list and determine if it is still valid.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4793.dita)

- Determine if the client provided a valid reference code:

- If the reference code is invalid , return to step 2.

- If the code is invalid and step 2 has already been repeated, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#Valid_reference_code)

- If the reference code is valid, go to Referred apprenticeship course confirmed .
               [Referred apprenticeship course confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#Valid_reference_code_1) 

#### Referred apprenticeship course not confirmed

Source topic: `en_EN/task/training_appr_rc/referred_apprenticeship_course_not_confirmed_level_1.dita`

- Refer to Training — Non-referred . 

#### Referred apprenticeship course confirmed

Source topic: `en_EN/task/training_appr_rc/referred_apprenticeship_course_confirmed_level_1.dita`

- Determine if there is a SA WI on file:

- If yes, go to step 2.

- If no, go to step 3.

- In FTS, select the Project Data - Training (M171) transaction and input the apprenticeship training information as follows:

- Start date: Enter the start date of the training.

- End date: Enter the end date of the training.

- Project SCC: Enter the first 4 digits of the reference code.

- Project number: Enter the first 10 digits of the reference code

- Training identification: Select 21 - Apprentice full-transfer labour market agreement .

- Apprentice indicator: Determine if there is an advance payment request :

- If there is no advance payment request and the RFS is J - Apprenticeship Training , select 1 - No advance pay, stop claimant's report at course end week .

- If there is no advance payment request and the RFS is not J - Apprenticeship Training , select 2 - No advance pay, continue claimant's report beyond course end week .

- If there is an advance payment request and the RFS is J - Apprenticeship Training , select 3 - Advance pay, stop claimant’s report at course end week .

- If there is an advance payment request and the RFS is not J - Apprenticeship Training , select 4 - Advance pay, continue claimant’s report at course end week .

- Claimant’s report: Determine if the client’s request for exemption from reporting is on file:

- If the client’s request is on file, select No .

- If the client’s request is not on file, leave blank.

- Institution code: Type the first 6 digits of the reference code.

- Select Update .

- Go to the originating task.

- In NWS, create a client Note and type “Apprenticeship granted. M171 to be input. Apprenticeship indicator: [code from 1 to 4]”. If the client requested an exemption from report type “claimant’s report exempted”.

- On the Resolve Issue tab of the ADJ WI, complete the Level 1 Training screen as follows:

- Select A valid reference code has been provided for apprenticeship training .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start date (DD/MM/YYYY): Enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Select Continue .

- Complete the Apprenticeship screen as follows:

- Provide the apprenticeship reference code (without spaces or hyphens): Enter the reference code provided by the client.

- Do you wish to terminate a disentitlement (D3, Not available)?: Select the appropriate option and, if required, complete the additional fields:

- Terminate Disentitlement:

- Disentitlement start date (DD/MM/YYYY): Enter the start date.

- Disentitlement end date (DD/MM/YYYY): Enter the end date.

- Overpayment: Review and, if required, modify the prefilled codes in the Detection , Infraction and Message fields.

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4794.dita`

Note:

If the client requests exemption from completing claimant’s reports, complete the Claimant’s report: Declaration for the exemption from completing claimant reports — Checklist . The checklist is copied into a separate SROC.
       [Claimant’s report: Declaration for the exemption from completing claimant reports — Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Declaration_for_the_exemption_from_completing_claimant_reports-Checklist.doc)

     [Claimant’s report: Declaration for the exemption from completing claimant reports — Checklist](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Claimants_report-Declaration_for_the_exemption_from_completing_claimant_reports-Checklist.doc) 

#### Note

Source topic: `en_EN/common_notes/note_c_4793.dita`

Note:

If there is no SCC that matches those numbers, it is an invalid code. 

### Level 2

Source topic: `en_EN/task/training_appr_rc/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/training_appr_rc/reviewing_the_file_level_2.dita`

- Determine if the reference code or training documents for the client’s apprenticeship program are on file:

- If proof of the apprenticeship program is not on file, go to step 2.

- If proof of the apprenticeship program is on file, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/training_appr_rc/fact-finding_level_2.dita`

- Fact-find with the client and ask him or her to provide the reference code or a copy of the training documents for the apprenticeship program.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4794.dita)

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 4.

- If the client was not contacted or did not respond to the N-10-00-00 letter, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#Apprenticeship_training_not)

- In NWS, add to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Apprenticeship training.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Moving the training information WI to Pending

Source topic: `en_EN/task/training_appr_rc/moving_the_training_information_wi_to_pending_level_2.dita`

- Determine if the client stated the reference code or training documents would be provided at a later time:

- If the client stated the reference code or training documents would be provided at a later time, go to step 6.

- If the client provided the reference code, go to step 8.

- In NWS, move the ADJ WI to Pending as follows:

- Pending reason : Select Fact-finding client .

- Comments : Type “Waiting for proof of apprenticeship program.”

- Bring forward date : Enter the date proof was requested + 10 working days.

- Select OK .

- When the ADJ WI moves to the current workload, determine if proof was provided:

- If proof was provided, go to step 8.

- If no proof was provided, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#Apprenticeship_training_not) 

#### Determining if the client was referred to the apprenticeship course

Source topic: `en_EN/task/training_appr_rc/determining_if_the_client_was_referred__0acbcd90_level_2.dita`

- Determine if the client provided a reference code:

- If yes, go to step 9.

- If no, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#Apprenticeship_training_not)

- Validate the reference code provided as follows:

- Under the Search tab, select Search Reference Code .

- Search SCC: Enter the first 4 numbers of the reference code.

- Compare the reference code provided to those in the list and determine if it is still valid.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4793.dita)

- Determine if the client provided a valid reference code:

- If the reference code is invalid , return to step 2.

- If the code is invalid and step 2 has already been repeated, go to Referred apprenticeship course not confirmed .
               [Referred apprenticeship course not confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#Apprenticeship_training_not)

- If the reference code is valid, go to Referred apprenticeship course confirmed .
               [Referred apprenticeship course confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/training_appr_rc#Apprenticeship_training_confirmed) 

#### Referred apprenticeship course not confirmed

Source topic: `en_EN/task/training_appr_rc/referred_apprenticeship_course_not_confirmed_level_2.dita`

- Go to Training — Non-referred . 

#### Referred apprenticeship course confirmed

Source topic: `en_EN/task/training_appr_rc/referred_apprenticeship_course_confirmed_level_2.dita`

- In NWS, create a client Note and type “Apprenticeship granted. M171 to be input. Apprenticeship indicator: [enter code from 1 to 4]”. If the client requested an exemption from report, type “Claimant’s report exempted”.

- On the Resolve Issue tab of the ADJ WI, complete the Level 2 Training screen as follows:

- Select A valid reference code has been provided for apprenticeship training .

- Select Continue .

- Complete the Training Dates screen as follows:

- Training start date (DD/MM/YYYY): Enter the start date.

- Training end date (DD/MM/YYYY): Enter the end date.

- Select Continue .

- Complete the Apprenticeship screen as follows:

- Provide the apprenticeship reference code (without spaces or hyphens): Enter the reference code provided by the client.

- Do you wish to terminate a disentitlement (D3, Not available)?: Select the appropriate option and, if required, complete the additional fields:

- Terminate Disentitlement:

- Disentitlement start date (DD/MM/YYYY): Enter the start date.

- Disentitlement end date (DD/MM/YYYY): Enter the end date.

- Overpayment: Review and, if required, modify the prefilled codes in the Detection , Infraction and Message fields.

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

## Policy reference

Source topic: `en_EN/task/training_appr_rc/policy_reference.dita`

- EIA 25
         [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- EIA 28
         [EIA 28](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-28.html)

- EIA 48, 49, 50
         [EIA 48, 49, 50](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-48.html)

- EIR 26
         [EIR 26](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-26.html)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

- Digest 16.2.0 — Claim required—EIA 48
         [Digest 16.2.0 — Claim required—EIA 48](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-16/introduction.html#a16_2_0)

- Digest 16.3.0 — Proof required—EIA 49
         [Digest 16.3.0 — Proof required—EIA 49](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-16/introduction.html#a16_3_0)

- Digest 16.4.0 — Entitlement to benefits—EIA 50
         [Digest 16.4.0 — Entitlement to benefits—EIA 50](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-16/introduction.html#a16_4_0)

- Digest 19.2.15 — Apprentices
         [Digest 19.2.15 — Apprentices](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-19/referred-claimants.html#a19_2_15) 
