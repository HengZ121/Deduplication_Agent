# Determining if a medical certificate must be submitted — Renewal and continuing claims

Source map: `en_EN/task/determining_med_cert_req/determining_med_cert_req.ditamap`

## Summary

Source topic: `en_EN/task/determining_med_cert_req/summary.dita`

Summary: Clients applying for sickness benefits must always obtain a medical certificate that proves their inability to work due to illness. In some cases, clients must submit the medical certificate before benefits can be paid. 

## What you need to know

Source topic: `en_EN/task/determining_med_cert_req/what_you_need_to_know.dita`

### Applying for sickness benefits

Source topic: `en_EN/task/determining_med_cert_req/applying_for_sickness_benefits.dita`

An acceptable medical certificate completed by a doctor or by another approved medical practitioner confirming the client’s sickness must be obtained for each week the client requests sickness benefits.
       [acceptable](/en/procedure/task/determining_med_cert_valid.shtml)

Clients applying for sickness benefits using a paper application are advised to submit a medical certificate with the application.

Clients applying for sickness benefits using AW can upload the medical certificate immediately. If clients do not submit the medical certificate and the last RFS is illness, clients are advised that it must be submitted if the duration of the illness or injury is greater than 9 weeks. Otherwise, clients are advised to keep the medical certificate for 6 years since it can be requested at a later date. Clients applying for sickness benefits using AW who indicate an RFS other than illness are advised to submit the medical certificate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0045.dita) 

### Determining if a medical certificate must be submitted

Source topic: `en_EN/task/determining_med_cert_req/determining_if_a_medical_certificate_mu_d4cdaa5c.dita`

It is not always necessary for a client to submit a medical certificate. The officer must request a medical certificate only when the client is required to submit it. However, if the client submits one, the officer must review it to ensure it is acceptable and use it to determine the recovery week.

To determine if the client has submitted a medical certificate, the officer reviews the file for uploaded or transcribed documents in NWS and imaged documents in Imaging.

Linguistic Services must translate medical certificates that are completed in a language other than English or French to be considered acceptable. 

### Renewal claims

Source topic: `en_EN/task/determining_med_cert_req/renewal_claims.dita`

When clients complete a renewal application for sickness benefits, they must obtain an acceptable medical certificate . The medical certificate must attest to their incapacity. When the RFS is illness and the medical certificate has not been submitted with the EI application, the client is advised it must be submitted if the duration of the illness or injury is greater than 9 weeks. Otherwise, the client must keep the medical certificate for 6 years and submit it, if requested at a later date.
       [acceptable medical certificate](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

The client must submit the medical certificate in any of the following situations:

- The RFS for the most recent period of employment is not D - Illness or injury .

- The client is minor attached (i.e. the client has fewer than 600 insurable hours) and the RFS for the most recent period of employment is not D.

- One of the following disqualifications or disentitlements applies to the claim, regardless of whether it was imposed due to the adjudication or the deferral of a contentious RFS:

- Entitlement to regular benefits is exhausted and the client has requested sickness benefits.

- A 16 - No medical certificate submitted disentitlement (D16) is imposed on the claim because a medical certificate was requested but has not been submitted.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0878.dita) 

### Conversions on continuing claims

Source topic: `en_EN/task/determining_med_cert_req/conversions_on_continuing_claims.dita`

**Conversion when casual sickness benefits have been paid**

A client who is receiving regular benefits, including fishing benefits, can declare up to 4 consecutive weeks of casual sickness benefits. If the client declares a fifth week of casual sickness, the claimant’s report is rejected with the error code C465. If the client requests additional sickness benefits after declaring 4 consecutive weeks, whether benefits have been paid or not, a conversion to a claim for sickness benefits is required.

A maximum of 8 weeks of casual sickness benefits in total can be paid in a benefit period (BP). If the client declares a ninth week of casual sickness, the claimant’s report is rejected with the error code C484. A client who has already received 8 weeks of casual sickness benefits and is still incapable of working must submit a medical certificate and request a conversion to a claim for sickness benefits.

The officer determines the number of weeks of casual sickness benefits paid in a BP by referring to the Casual sickness weeks field on the Summary or Special Benefits tab in FTS. When determining the recovery week, the officer must use only the casual sickness weeks counter to obtain the number of weeks of casual sickness benefits paid.

**Medical certificate must be submitted**

A medical certificate must be submitted for a client requesting a conversion to sickness benefits or an extension of a period of sickness, if any of the following conditions is met:

- The sickness period is being extended when the initial period of sickness was granted without submitting a medical certificate.

- The maximum of 8 weeks of casual sickness benefits has been paid.

- One of the following disqualifications or disentitlements applies to the claim, regardless of whether it was imposed due to the adjudication or the deferral of a contentious RFS:

- D10

- D11

- D42

- D43

- D44

- The client is requesting sickness benefits during or after receiving maternity, parental, QPIP, CCB, or family caregiver benefits.

- Entitlement to regular benefits is exhausted and the client has requested sickness benefits.

- The client is minor attached (i.e. the client has fewer than 600 insurable hours) and the RFS for the most recent period of employment is not D .

- A D16 is imposed on the claim because a medical certificate was requested but has not been submitted.

**Common entrance requirement (CER) — Temporary measure (from w/c 2310 to w/c 2361)**

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, the definitions of major and minor attached do not apply. For the duration of the measure, clients whose claim is established with 420 hours of insurable employment or more qualify for special benefits. The officer ensures that all other qualifying and entitlement conditions are met. 

### Early recovery

Source topic: `en_EN/task/determining_med_cert_req/early_recovery.dita`

A client may recover from the illness faster than anticipated.

When stating being capable of working before the recovery date and requesting regular benefits, the client must submit proof of the early recovery if any of the following conditions are met:

- The medical certificate indicates terminal or palliative.

- The recovery date on the medical certificate is after the date on which the client reports being capable of working.

- The client is minor attached and a 2 - Minor attached, reason for separation illness disentitlement (D2) has been imposed.

- The maximum entitlement to sickness benefits has been paid.

In all other cases, the client’s statement regarding the early recovery date is accepted. 

### Gradual return to work (RTW)

Source topic: `en_EN/task/determining_med_cert_req/gradual_return_to_work_rtw.dita`

A client who has not completely recovered but has been authorized by a doctor or other medical practitioner to gradually return to work may receive sickness or regular benefits depending on how many weeks of entitlement remain.

The client must submit a medical certificate proving a doctor or other medical practitioner’s authorization to return to work and stating any limitations for the gradual RTW. The client’s medical certificate must include details such as the duration of the gradual RTW, the days or hours the client can work and the client’s abilities or lack thereof.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3182.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0045.dita`

Note:

When a medical certificate is uploaded, the officer or the client must complete a Medical Certificate electronic questionnaire. The electronic questionnaire is not medical proof. The officer does not use it to determine a recovery week or period of incapacity. 

### Note

Source topic: `en_EN/common_notes/note_c_0878.dita`

Note:

Even if the RFS on the last ROE is sickness, if any of the disqualifications or disentitlements above apply to the claim, or the medical certificate is not acceptable, the client must submit an acceptable medical certificate. 

### Note

Source topic: `en_EN/common_notes/note_c_3182.dita`

Note:

When an allocation of earnings (e.g. paid sick leave [PSL], wage loss insurance [WLI], or severance pay) prevents payment until after the recovery week that would have been allowed had there not been an allocation of earnings, the required medical certificate is not requested. 

## Regional considerations

Source topic: `en_EN/task/determining_med_cert_req/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/determining_med_cert_req/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/determining_med_cert_req/in_fts.dita`

- Are there weeks of regular benefits remaining?

- Are there any disqualifications or disentitlements on file?

- Does the client qualify for special benefits but not for regular benefits?

- Is the client minor attached?

- Is there a recovery week on file?

- Has the client previously received sickness benefits in the current BP?

- Is the client currently receiving parental benefits or CCB? 

### In NWS:

Source topic: `en_EN/task/determining_med_cert_req/in_nws.dita`

- Is the client reporting early recovery from the injury or illness?

- Is the client reporting a gradual RTW or limited capabilities?

- Is this a renewal or a continuing claim?

- Is there an ROE on file to review?

- If yes, is it for the most recent period of employment?

- Did the client declare that the RFS for the most recent period of employment was illness or injury?

- Has a medical certificate or a Sickness: INS5140 Medical certificate — Form been uploaded?

- Is there an SROC or Action Item (AI) WI with a medical certificate transcribed?

- Is there a medical certificate on file or has one been uploaded for a previous period of sickness benefits in the current BP? 

### In Imaging:

Source topic: `en_EN/task/determining_med_cert_req/in_imaging.dita`

- Was a medical certificate submitted for a previous period of sickness benefits in the current BP? 

## Step by step

Source topic: `en_EN/task/determining_med_cert_req/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/determining_med_cert_req/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/determining_med_cert_req/reviewing_the_file_level_1.dita`

- Select the client’s situation:

- Gradual return to work (RTW) or limited capability
               [Gradual return to work (RTW) or limited capability](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_med_cert_req#Gradual_return_to)

- Early recovery
               [Early recovery](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_med_cert_req#Early_Recovery)

- Renewal claim
               [Renewal claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_med_cert_req#Renewal_Claim)

- Continuing claim
               [Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/determining_med_cert_req#Continuing_Claim) 

#### Gradual return to work (RTW) or limited capability

Source topic: `en_EN/task/determining_med_cert_req/gradual_return_to_work_rtw_or_limited_capability_level_1.dita`

- If the client is in a gradual RTW or limited capability situation, the client must submit a medical certificate.

- Return to the previous task. 

#### Early recovery

Source topic: `en_EN/task/determining_med_cert_req/early_recovery_level_1.dita`

- Determine if any of the following conditions apply:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3183.dita)

- Return to the previous task. 

#### Renewal claim

Source topic: `en_EN/task/determining_med_cert_req/renewal_claim_level_1.dita`

- Determine if any of the following conditions apply:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3184.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0878.dita)

- Return to the previous task. 

#### Continuing claim

Source topic: `en_EN/task/determining_med_cert_req/continuing_claim_level_1.dita`

- Determine if any of the following conditions apply:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3185.dita)

- Return to the appropriate task. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3183.dita`

- The medical certificate indicates terminal or palliative.

- The recovery date on the medical certificate is after the date on which the client reports being capable of working.

- The client is minor attached and a D2 has been imposed.

- The maximum entitlement to sickness benefits has been paid.

- If none of the conditions apply, the client does not need to submit a medical certificate.

- If any of the conditions apply, the client must submit a medical certificate. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3184.dita`

- The RFS for the most recent period of employment is not illness or injury.

- The client is minor attached and the RFS for the most recent period of employment is not D .

- One of the following disqualifications or disentitlements applies to the claim, regardless of whether it was imposed due to the adjudication or the deferral of a contentious RFS:

- D10

- D11

- D42

- D43

- D44

- Entitlement to regular benefits is exhausted and the client has requested sickness benefits.

- A D16 is imposed on the claim because a medical certificate was requested but has not been submitted.

- If none of the conditions apply, the client does not need to submit a medical certificate.

- If any of the conditions apply, the client must submit a medical certificate. 

#### Callout

Source topic: `en_EN/common_notes/note_c_3185.dita`

- The maximum of 8 weeks of casual sickness benefits has been paid.

- The client is requesting an extension of sickness benefits when the initial period was granted without submitting a medical certificate.

- One of the following disqualifications or disentitlements applies to the claim, regardless of whether it was imposed due to the adjudication or the deferral of a contentious RFS:

- D10

- D11

- D42

- D43

- D44

- The client is requesting sickness benefits during or after receiving maternity, parental, QPIP, CCB or family caregiver benefits.

- Entitlement to regular benefits is exhausted and the client has requested sickness benefits.

- The client is minor attached and the RFS for the most recent period of employment is not D.

- A D16 is imposed on the claim because a medical certificate was requested but has not been submitted.

- If none of the conditions apply, the client does not need to submit a medical certificate.

- If any of the conditions apply, the client must submit a medical certificate. 

## Policy reference

Source topic: `en_EN/task/determining_med_cert_req/policy_reference.dita`

- EIR 40 (1)
         [EIR 40 (1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-40.html) 
