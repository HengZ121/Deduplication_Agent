# Completing an ROE Correction WI — Regular ROE

Source map: `en_EN/task/completing_roe_correction_regular/completing_roe_correction_regular.ditamap`

## Summary

Source topic: `en_EN/task/completing_roe_correction_regular/summary.dita`

Summary: ROE Issue (ROE) Correction WIs are created on initial claims during the ACP wait process when ROEs have errors that prevent calculation. They can also be manually created by an officer when errors are identified during another task. When fraud indicators are present and the file is not already under investigation, the officer refers the file to Integrity. 

## What you need to know

Source topic: `en_EN/task/completing_roe_correction_regular/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/completing_roe_correction_regular/untitled_section.dita`

In NWS :

- What is the name of the employer declared on the application?

- Are there documents (e.g. SROC, other WIs) containing information to correct the ROE?

In RCM :

- Which error messages are displayed when attempting to validate the ROE?

- Is there information in the Comments or Additional information field of the ROE?

- If this ROE is the last ROE, what is the last day paid?

In Imaging :

- Are there any documents that may provide information to correct the ROE?

In the employer database :

- Is there any information about this employer?

- Is there any information about the ROE error in question? 

### Data entry errors on an ROE

Source topic: `en_EN/task/completing_roe_correction_regular/data_entry_errors_on_an_roe.dita`

Procedures related to the data entry of an ROE or the review of ROE comments sometimes create an error on the ROE (e.g. a change was made to the original ROE but was not initialled by the employer). When this occurs, the discrepancy is indicated in the Additional information field of the ROE. 

### Identifying ROE errors

Source topic: `en_EN/task/completing_roe_correction_regular/identifying_roe_errors.dita`

In RCM, an ROE error message is displayed in red beside the blocks in error. When an ROE is corrected, the changes require validation to determine if errors are still present or if new ones have occurred. Only when no error messages remain is the ROE considered successfully corrected and available for use in the claim assessment.

**Duplicate ROEs**

If the ROE displays an error message stating that a serial number has already been entered for another SIN, the officer refers to Correcting an ROE flagged as a duplicate ROE with a different SIN .
       [Correcting an ROE flagged as a duplicate ROE with a different SIN](/en/procedure/task/duplicate_correcting_roe.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0077.dita) 

**ROEs with a serial number status problem**

If the ROE displays an error message stating that a problem with the status of the serial number was detected, the officer refers to Correcting an ROE flagged with a serial number problem .
       [Correcting an ROE flagged with a serial number problem](/en/procedure/task/lms_correcting_roe.shtml) 

### Fraudulent web ROEs

Source topic: `en_EN/task/completing_roe_correction_regular/fraudulent_web_roes.dita`

Fraudulent ROEs have been issued through ROE Web, or the potential exists for future fraudulent ROEs to be issued. There are also reasons to suspect that some of the business numbers (BNs) associated with these suspicious ROEs may be fraudulent.

When Integrity identifies a fraudulent BN, an Integrity officer deletes the associated Web ROEs in RCM if they were not used to calculate a claim. The Integrity officer enters the following note in the Additional information section of the ROE:

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1569.dita) 

When correcting an ROE deleted by Integrity, the officer suspends the application process, if necessary, and completes the ROE Correction WI if the WI status has not been changed to Deleted in NWS. 

### Fraudulent paper ROEs

Source topic: `en_EN/task/completing_roe_correction_regular/fraudulent_paper_roes.dita`

Fraudulent paper ROEs were created without the knowledge of the true SIN-holder and the employer associated with the Canada Revenue Agency (CRA) BN indicated in block 5 of the ROE. There are also instances where there are reasons to suspect that the business identified on the ROE is illegitimate or suspicious and was created to issue fraudulent ROEs. These fraudulent ROEs were sent to Service Canada and scanned as documents in support of fraudulent EI applications or uploaded in AW or MSCA.

A close examination may reveal a difference in the font and size of the characters in the serial number of these ROEs when compared to the normal format. In some cases, RCM validates the serial number and does not signal the ROE as a duplicate, because that serial number was used to establish an EI claim more than 11 years ago. In other situations, the serial number has been issued within the last 11 years to a different BN than the one used on the fraudulent ROE, and RCM validates the serial number but does not flag it as a duplicate because the ROE was never used to establish a claim.

When correcting an ROE, officers may suspect that an ROE is fraudulent even if no error message is displayed about the status of the serial number. Officers actioning ROE Correction WIs do not fact-find with the employer. Officers delete the ROE in RCM, suspend the application process and refer the file to Integrity, if the file is not already under investigation.

For more information, officers refer to Fraud indicators: Identifying potentially fraudulent claims — Knowledge .
       [Fraud indicators: Identifying potentially fraudulent claims — Knowledge](/en/procedure/generic/additionalresources/fraud_indicator.shtml) 

### Fraud indicators

Source topic: `en_EN/task/completing_roe_correction_regular/fraud_indicators.dita`

Before taking any actions, officers determine if the application is already under investigation for potential fraud. Officers can determine that there is an ongoing Integrity investigation for this application if:

- a 71 - Integrity Services case manual action (MA71) or 71 - Integrity Services case disentitlement (D71) is imposed;

- an SROC created by Integrity is on file;

- an Action Item (AI) WI is assigned to Integrity;

- a Call Back (CB) WI is assigned to Integrity.

If none of these are on the file, officers review the file to determine if fraud indicators are present. If yes, officers:

- determine if the banking information has been changed in FTS and, if so, terminate the direct deposit;

- impose a D71 on skeleton and BPNE 1, 2 or 7 claims or an MA71 on established claims, if necessary;

- complete the registration number to suspend the initial application process to prevent the claim from establishing until an investigation is completed;

- refer the issue to Integrity for investigation;

- complete the Claim Set-Up (CS) WI.

If the only fraud indicator is the fraud warning highlighted in red in FTS, the officers do not refer the issue to Integrity.

For more information, officers refer to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml) 

### Correcting ROE errors

Source topic: `en_EN/task/completing_roe_correction_regular/correcting_roe_errors.dita`

Guides are available to help employers correctly complete an ROE. When errors are present and the officer must contact the employer, the officer can also use these guides to teach the employer how to correctly complete an ROE.

The officer must consider that changing one field may affect other information. The types of questions to ask include the following:

- If the first day worked changes, are the total insured hours still correct?

- If the other monies on separation are changed, are the total insured earnings still correct?

- If the pay period type changes, is the pay period end date still correct?

The officer processing the ROE Correction WI must review the application and the previous claims before contacting the employer to obtain the necessary information.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2669.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_2665.dita`

Note:

This task only applies to an ROE Correction WI in the normal ACP process. To correct an ROE error in the specialized ACP process, refer to Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE .
       [Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE](/en/procedure/task/post_eierb_completing_assessment_issue_roe_correction_wi_regular_roe.shtml)

     [Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Regular ROE](/en/procedure/task/post_eierb_completing_assessment_issue_roe_correction_wi_regular_roe.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2666.dita`

Note:

For validation errors on an ROE Correction WI, the officer refers to Major Employer Events (MEE) — Information Bulletin .
       [Major Employer Events (MEE) — Information Bulletin](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68)

     [Major Employer Events (MEE) — Information Bulletin](https://apps.powerapps.com/play/e/649eba73-ea42-e150-946a-78d374a4caf0/a/c43c87f7-c906-48c2-8251-0c98b7cb8a68) 

### Note

Source topic: `en_EN/common_notes/note_c_2667.dita`

Note:

For an ROE Correction WI for a Government of Canada ROE, refer to ROE issued by the Government of Canada — Instructions .
       [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

     [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2668.dita`

Note:

Level 1 officers completing an ROE Correction WI refer to Correcting an error during calculation or recalculation — Regular ROE task .
       [Correcting an error during calculation or recalculation — Regular ROE task](/en/procedure/task/correcting_roe_error_calculation_regular.shtml)

     [Correcting an error during calculation or recalculation — Regular ROE task](/en/procedure/task/correcting_roe_error_calculation_regular.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0077.dita`

Note:

Although there is a function to override this error in RCM, this function must only be used following an Integrity investigation when it is determined that the ROE is valid and is required to calculate a claim. 

### Callout

Source topic: `en_EN/common_notes/note_c_1569.dita`

“Suspicious ROE. ROE has been deleted to prevent it from being used in benefits calculation until an investigation is completed. It can be restored if its legitimacy is confirmed.” 

### Note

Source topic: `en_EN/common_notes/note_c_2669.dita`

Note:

The employer must be contacted as soon as possible for clarification when the ROE is the last ROE and the difference between the last day worked and the last day paid is equal to or greater than 14 days. 

## Regional considerations

Source topic: `en_EN/task/completing_roe_correction_regular/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/completing_roe_correction_regular/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/completing_roe_correction_regular/untitled_section.dita`

In NWS :

- What is the name of the employer declared on the application?

- Are there documents (e.g. SROC, other WIs) containing information to correct the ROE?

In RCM :

- Which error messages are displayed when attempting to validate the ROE?

- Is there information in the Comments or Additional information field of the ROE?

- If this ROE is the last ROE, what is the last day paid?

In Imaging :

- Are there any documents that may provide information to correct the ROE?

In the employer database :

- Is there any information about this employer?

- Is there any information about the ROE error in question? 

## Step by step

Source topic: `en_EN/task/completing_roe_correction_regular/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/completing_roe_correction_regular/non-complex.dita`

#### Reviewing the file for fraud indicators

Source topic: `en_EN/task/completing_roe_correction_regular/reviewing_the_file_for_fraud_indicators_non-complex.dita`

- In NWS, determine if there is documentation on file indicating that the application is under investigation for potential fraud:

- If no, go to step 2.

- If yes, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_roe_correction_regular#nc_item_4)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1527.dita)

- Determine if known fraud indicators are present and if fraud is suspected by referring to Fraud indicators: Identifying potentially fraudulent claims — Knowledge and reviewing the file:

- If yes, go to step 3.

- If no, go to step 4.

- In FTS, determine if the banking information has been changed to the banking information on the potentially fraudulent application:

- If no, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_roe_correction_regular#nc_item_4)

- If yes, terminate the banking information by referring to Ending a direct deposit and go to Fraud indicators are present .
               [Ending a direct deposit](/en/procedure/task/ending_dd.shtml) 
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_roe_correction_regular#nc_item_4) 

#### Reviewing the ROE

Source topic: `en_EN/task/completing_roe_correction_regular/reviewing_the_roe_non-complex.dita`

- In RCM, determine if an error states that the serial number has already been entered for another SIN:

- If yes, go to Reassign the WI to Level 1 .
               [Reassign the WI to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_roe_correction_regular#Reassign)

- If no, go to step 5.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0077.dita)

- Determine if an error states that a problem with the status of the serial number was detected:

- If yes, go to Correcting an ROE flagged with a serial number problem .
               [Correcting an ROE flagged with a serial number problem](/en/procedure/task/lms_correcting_roe.shtml)

- If no, go to step 6. 

#### Correcting the ROE

Source topic: `en_EN/task/completing_roe_correction_regular/correcting_the_roe_non-complex.dita`

- Determine which blocks of the ROE are in error and consult ROE: RCM validation error correction for a regular ROE — Instructions to determine how to correct the ROE:

- If the table indicates that corrections can be made with the information on file, go to step 7.

- If the table indicates to contact the employer, go to step 8.

- If the table does not indicate that corrections can be made at your level and does not indicate to contact the employer, go to Reassigning the WI to Level 1 .
               [Reassigning the WI to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_roe_correction_regular#Reassign)

- In RCM, correct the errors and do the following:

- Additional information: Type “Changes made to blocks [XX] in accordance with the EI Online Reference Tool (ORT).”

- Select Validate:

- If error messages are displayed for any block, repeat step 6.

- If no error message is displayed, select Submit and go to step 19. 

#### Fact-finding

Source topic: `en_EN/task/completing_roe_correction_regular/fact-finding_non-complex.dita`

- Fact-find with the person who issued the ROE to obtain the missing information.

- Determine if the person who issued the ROE was contacted.

- If yes, go to step 10.

- If no, go to step 12.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select ROE .

- Comments: Type “ROE correction.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the information has been obtained:

- If no, go to step 12.

- If yes, go to step 17.

- In ACS, send a registered copy of the Z-02-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Request for a Record of Employment (2797)

- Follow-up Request for ROE Additional Information

- Date contacted employer (1556)

- Enclosing a copy of letter (2800)

- Date of BF (1540): Select 10 business days from the date the letter is sent.

- Blank / Contact agent / Contact by phone or mail (11326)

- Attachment List for Z-02-00-00 letter (3133) :

- Copy of original letter

- Indicate on letter how letter mailed (2804)

- Sent by Registered mail.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1564.dita)

- In NWS, move the WI to Pending as follows:

- Pending reason : Select Other .

- Comments : Type “Z-02-00-00 letter sent.”

- Bring forward date : Enter 10 business days from the day the letter is sent.

- When WI moves to the current workload, determine if the information was obtained:

- If no , go to step 15.

- If yes, go to step 17.

- Determine if a CA WI has been created.

- If yes, go to step 16.

- If no, go to Reassigning the WI to Level 1 .
               [Reassigning the WI to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_roe_correction_regular#Reassign)

- Create an SROC and complete the following fields:

- Issue : Select ROE .

- Comments: Type “Employer non-compliance — ROE [insert serial number].”

- Details : Type “Employer did not respond to the Z-02-00-00 letter by response date of [DD-MM-YYYY]. Work item closed without corrections being made.”

- Select Save .

- Go to step 19. 

#### Updating the ROE after fact-finding

Source topic: `en_EN/task/completing_roe_correction_regular/updating_the_roe_after_fact-finding_non-complex.dita`

- In RCM, correct the ROE and do the following:

- Additional information : Type “Changes to Block #[XX] confirmed with [client or employer (including the name of the person reached)]”.

- Select Validate :

- If an error message is displayed and the table does not indicate to check the Override-able errors box next to the error message, go to step 18 to determine how to correct the error.

- If error messages are displayed and the table indicates to check the Override-able errors box next to each error message, check the applicable boxes and select Submit . Go to step 19.

- If no error message is displayed, select Submit and go to step 19.

- Determine which blocks of the ROE are in error and consult ROE: RCM validation error correction for a regular ROE — Instructions to determine how to correct the ROE:

- If the table indicates that corrections can be made, repeat step 17.

- If the table does not indicate that corrections can be made at your level, go to Reassigning the WI to Level 1 .
               [Reassigning the WI to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/completing_roe_correction_regular#Reassign)

- In NWS, complete the ROE Correction WI. 

#### Reassigning the WI to Level 1

Source topic: `en_EN/task/completing_roe_correction_regular/reassigning_the_wi_to_level_1_non-complex.dita`

- In NWS, reassign the WI to Level 1 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 1 .

- Reason: Select Unable to complete .

- Details: Type the appropriate option:

- “Unable to make ROE corrections to ROE block [XX].”

- “The serial number is already in use for another SIN.”

- Select OK . 

#### Fraud indicators are present

Source topic: `en_EN/task/completing_roe_correction_regular/fraud_indicators_are_present_non-complex.dita`

- In NWS, determine if any of the following WIs are on file:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2661.dita) 

- If no, go to step 2.

- If yes, go to step 19.

- Determine if any of the following are on file and directly related to the potentially fraudulent application:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2662.dita) 

- If no, go to step 3.

- If yes, go to step 6.

- In NWS, determine if a suspected fraud has previously been referred to Integrity in an AI WI that has not been completed:

- If yes, go to step 4.

- If no, go to step 5.

- Add the information related to the potentially fraudulent application to the existing Integrity AI WI as follows:

- Right-click and select Add details/Further inquiry .

- Action: Select Additional Information .

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the processing unit in the region where the client lives:

- Atlantic: Processing - ATL

- Quebec: Processing - QC

- Ontario: Processing - ON

- Western Canada and Territories: Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue(s): Select ROE .

- Comments: Type “Fraud suspected — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file].” If the ROE is potentially fraudulent, also type “ROE [serial number] with business number [CRA business number] is potentially fraudulent.” If the application process is being suspended, also type “The application process has been suspended until the investigation ends.”

- Select Save .

- Go to step 6

- In FTS, determine if the initial claim has already been calculated:

- If yes, go to step 7.

- If no, go to step 10.

- In NWS, determine if the calculated claim is potentially fraudulent:

- If yes, go to step 8.

- If no, go to step 16.

- Determine if an MA71 has already been imposed:

- If no, go to step 9.

- If yes, go to step 16.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 16.

- Determine if there is an outstanding initial registration number related to the fraudulent application:

- If yes, go to step 11.

- If no, go to step 16.

- Determine if a D71 has already been imposed:

- If no, go to step 12.

- If yes, go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2663.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

- Go to step 13.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2664.dita)

- In NWS, determine if the Claim Status is Finalized - Pending LREM :

- If yes, go to step 14.

- If no, go to step 15.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- Go to step 16.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1576.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the initial registration number as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 16.

- Determine if the ROE to be corrected is potentially fraudulent:

- If yes, go to step 17.

- If no, go to step 19.

- In RCM, determine if the ROE has been deleted:

- If no, go to step 18.

- If yes, go to step 19.

- In RCM, open the ROE and delete it as follows:

- Delete: Check the box.

- Additional information : Type “Suspicious ROE. ROE has been deleted to prevent it from being used in benefits calculation until an investigation is completed. It can be restored if its legitimacy is confirmed.”

- Select Validate .

- Select Submit .

- Go to step 19.

- In NWS, determine if there is a related ROE Correction WI:

- If yes, go to step 20.

- If no, no further action is required.

- Determine if the status of the ROE Correction WI is Assigned-Active :

- If yes, complete the WI.

- If no, no further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_1527.dita`

Note:

If the only fraud indicator is the fraud warning highlighted in red in FTS, go to step 2. 

#### Note

Source topic: `en_EN/common_notes/note_c_1564.dita`

Note:

When sending a copy of an original letter, print the letter locally. For instructions on printing locally while teleworking, refer to Telework: Printing documents locally — Instructions .
       [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml)

     [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml) 

#### Callout

Source topic: `en_EN/common_notes/note_c_2661.dita`

- a Claim Review (CR) Integrity ERB-EI Transition WI related to the potentially fraudulent application;

- an AI WI from Integrity indicating that the claim can be established;

- a CB WI about the potentially fraudulent application. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2662.dita`

- an Integrity AI WI;

- an Integrity SROC;

- a D71 or an MA71 is imposed;

- in RMDS, on the Employer profile screen, the Under investigation box is checked. 

#### Note

Source topic: `en_EN/common_notes/note_c_2663.dita`

Note:

Before imposing a D71, confirm that the file does not already include one. In such cases, if a transaction is input to impose a D71, the existing D71 is cancelled. 

#### Note

Source topic: `en_EN/common_notes/note_c_2664.dita`

Note:

If error code C072: Invalid Claim action or Action field (C072) is displayed when inputting the Renewal/Revised (M106) transaction, the D71 cannot be imposed. Go to step 13. 

#### Note

Source topic: `en_EN/common_notes/note_c_1576.dita`

Note:

If error code 836: WARNING - Flag 33 claim (Last Record of Employment Missing), claim is still polling for the last record of employment is displayed when attempting to clear the registration number, check the Override box to process the transaction. 

## Policy reference

Source topic: `en_EN/task/completing_roe_correction_regular/policy_reference.dita`

- How to complete a ROE (employer’s guide)
         [How to complete a ROE (employer’s guide)](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/roe-guide.html)

- ROE SAT user guide
         [ROE SAT user guide](http://www.esdc.gc.ca/en/reports/ei/ROE_secure_transfer.page) 
