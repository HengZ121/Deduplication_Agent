# Reviewing a Medical Certificate Validation WI

Source map: `en_EN/task/examiner_validation-reviewing_validation/examiner_validation-reviewing_validation.ditamap`

## Summary

Source topic: `en_EN/task/examiner_validation-reviewing_validation/summary.dita`

Summary: When a client applies for sickness benefits and uploads a medical certificate, NWS creates a WI if necessary for an officer to review and validate the medical certificate and recovery week after ACP finalizes an initial or renewal claim. 

## What you need to know

Source topic: `en_EN/task/examiner_validation-reviewing_validation/what_you_need_to_know.dita`

### Applying for sickness benefits

Source topic: `en_EN/task/examiner_validation-reviewing_validation/applying_for_sickness_benefits.dita`

The client must obtain a medical certificate completed by a doctor or another medical professional confirming the client’s sickness for each week the client requests sickness benefits ( EIR 40(1) ). The medical certificate must include the client’s name, attest to the client’s inability to work and state the probable duration of the illness, injury, or quarantine.
       [EIR 40(1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-40.html)

A client applying for sickness benefits using a paper application is advised to submit a medical certificate with the application. A client applying for sickness benefits using the online application is provided with the option to upload a medical certificate, regardless of the reason for separation (RFS) or the probable duration of the incapacity.

A client who indicates the last RFS is illness but does not upload a medical certificate with the application is advised to submit the medical certificate if it indicates that the period the client must be off work is more than 9 weeks. Additionally, the client is advised to keep the medical certificate for 6 years because it may be requested at a later date. A client who indicates an RFS other than illness and does not upload a medical certificate with the application is advised to submit the medical certificate.

It is not always necessary for a client to submit a medical certificate. However, if the client submits one, it is used to determine the recovery week. 

### Receiving an uploaded medical certificate

Source topic: `en_EN/task/examiner_validation-reviewing_validation/receiving_an_uploaded_medical_certificate.dita`

A client can upload a medical certificate in AW or MSCA, or provide it to Service Canada for an officer to upload it in NWS. All uploaded medical certificates are available to any officer for review in NWS with View Documents .

**Medical Certificate electronic questionnaire**

The medical certificate upload process requires the officer or the client to complete a Medical Certificate electronic questionnaire. The uploaded medical certificate information is input into the Medical Certificate electronic questionnaire to make the information accessible to ACP during automation.

Receipt of a Medical Certificate electronic questionnaire triggers ACP to do at least one of the following:

- no action;

- automating a claim;

- creating a WI;

- creating a notification to an existing WI.

The officer can review the Medical Certificate electronic questionnaire:

- within the application, if the client submitted the questionnaire in AppliWeb;

- by selecting View Questionnaire in the Systems section in NWS, if the questionnaire was completed in MSCA or NWS.

The Medical Certificate electronic questionnaire is not a medical proof. When the recovery date on file is not supported, the officer reviews the electronic questionnaire information to understand why the system generated a specific recovery date and to identify the error that occurred.

**Documents uploaded by Service Canada**

The Medical Certificate electronic questionnaire is presented to the officer when a Sickness: INS5140 Medical certificate — Form (INS5140) or other medical certificate is selected when uploading a document in NWS.
       [Sickness: INS5140 Medical certificate — Form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=SC-INS5140.pdf)

The officer with a Medical Certificate Validation WI follows the same validation process, regardless of whether the documents were uploaded in NWS or by the client in MSCA. 

### Automation when a Medical Certificate electronic questionnaire is received — Initial and renewal claim

Source topic: `en_EN/task/examiner_validation-reviewing_validation/automation_when_a_medical_certificate_e_5a9e29fc.dita`

When the client submitted a medical certificate and Medical Certificate electronic questionnaire in AW , and a Claim Assessment (CA) or Specialized Application (SA) WI is on file, ACP does not create a Claim Review (CR) Medical Certificate Validation WI or take any other action. The officer processing the CA or SA WI reviews all information on file and takes the necessary actions.

When the uploaded medical certificate and Medical Certificate electronic questionnaire are received in MSCA or NWS , and a CA or SA WI is present, ACP does not create a CR Medical Certificate Validation WI. Instead, it generates a notification to the CA or SA WI.

When conditions are met for ACP to automate an initial or renewal claim for sickness benefits, ACP uses the recovery date from the Medical Certificate electronic questionnaire submitted in AW, MSCA or NWS. ACP uses information from a Medical Certificate electronic questionnaire if it is within 10 weeks of the date the application was submitted.

When multiple medical certificates are received, ACP uses the latest one based on the signature date on the Medical Certificate electronic questionnaire.

**ACP inputs — Recovery week**

When no relevant Medical Certificate electronic questionnaire is on file and conditions are met for automation, ACP determines the recovery week as follows:

- On an initial claim, ACP inputs the recovery week as BPC + 8 weeks.

- On a renewal claim, ACP inputs the recovery week as the renewal week + 8 weeks.

When a relevant Medical Certificate electronic questionnaire is on file, ACP does the following based on the information the client provided:

- When the client is in palliative care or terminally ill, ACP inputs the recovery week as indefinite (9999).

- When the client has stopped working for an unknown period:

- On an initial claim, ACP inputs the recovery week as BPC + 8 weeks.

- On a renewal claim, ACP inputs the recovery week as the renewal week + 8 weeks.

- When the client has stopped working until a specific recovery date, ACP inputs the recovery date the client provided, unless this date is a Sunday or Monday. In this situation, ACP determines the previous w/c as the recovery week.

When ACP finalizes the claim, it generates a CR Medical Certificate Validation WI in NWS when the date is not within the accepted risk threshold as defined by the system. In these situations, an officer reviews the recovery date on the claim. 

### Reviewing a Claim Review (CR) Medical Certificate Validation WI

Source topic: `en_EN/task/examiner_validation-reviewing_validation/reviewing_a_claim_review_cr_medical_cer_f9e8102e.dita`

The WI details indicate Recovery date requires validation when the recovery week is determined with a specific recovery date and is greater than the risk threshold. Indefinite recovery requires validation is indicated on the WI details when the recovery week is indefinite (9999). While the recovery date on the latest Medical Certificate electronic questionnaire determines if ACP creates a CR Medical Certificate Validation WI in NWS, the officer assigned to the CR Medical Certificate Validation WI reviews all the medical information on file. The officer must ensure the recovery week on the claim is accurate, or take the required actions to correct it.

An incorrect recovery date may be due to various reasons. Some examples include:

- The medical certificate is not acceptable (e.g. the certificate is not signed by a doctor or a medical professional). To determine if a medical certificate is acceptable, the officer refers to Determining if a medical certificate is acceptable and Medical certificate: Conditions to be accepted — Knowledge .
         [Determining if a medical certificate is acceptable](/en/procedure/task/determining_med_cert_valid.shtml) 
         [Medical certificate: Conditions to be accepted — Knowledge](/en/procedure/generic/additionalresources/conditions_medical_certificate_ca.shtml)

- The client made an error inputting the recovery date or signature date on the Medical Certificate electronic questionnaire.

- The client submitted multiple Medical Certificate electronic questionnaires, and an error prevents ACP from recognizing the latest one.

- The client selected an option that does not apply to the medical certificate (e.g. the client selected terminally ill option when the medical certificate indicates the client has stopped working for an unknown period).

**Requesting translation of a medical certificate**

When a medical certificate is completed in a language other than English or French, the officer refers to Sending a medical certificate for translation .
       [Sending a medical certificate for translation](/en/procedure/task/med_cert_translation.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3406.dita) 

**Determining the period of incapacity**

The period of incapacity is the period during which the client is incapable of working and sickness benefits can be paid. When a client submits an acceptable medical certificate as proof of incapacity for sickness benefits, the officer must review the medical certificate and determine the period of incapacity.

**Receiving proof of a gradual return to work (RTW) or limited capacity**

A client may mistakenly upload a proof of a gradual RTW or of limited capacity under Medical Certificates, instead of under Other Medical Documention If the medical document is for one of these situations, a WI is created to review the availability. If the medical certificate is proof of a gradual RTW, the officer creates a CR Revised Availability WI for Level 1. If the medical certificate indicates that the client has limited capacity (other than gradual RTW), the officer creates a CR Revised Availability WI for Level 2. For more information, the officer refers to Adjudicating availability — Gradual return to work and Adjudicating availability — Preference or restriction and reasonable period .
       [Adjudicating availability — Gradual return to work](/en/procedure/task/availability_adj_rw.shtml) 
       [Adjudicating availability — Preference or restriction and reasonable period](/en/procedure/task/availability_adj_res.shtml)

**Validating the recovery week**

The recovery date is the first day the client is capable of working.

The recovery week is the week up to which sickness benefits are payable.

Sickness benefits can be paid up to and including the recovery week.

The officer processing the CR Medical Certificate Validation WI reviews the medical certificate to determine the recovery week. The officer compares it to the recovery week in FTS that was input by ACP during automation. If the dates match, the recovery is valid. If the dates do not match, the recovery week is invalid and the officer does the following:

- If the recovery week determined by the officer is before the recovery week in FTS, and sickness benefits have not yet been paid for the period between the valid recovery date and the invalid recovery date, the officer updates the recovery week in FTS to prevent the payment of sickness benefits for the period for which there is no acceptable medical certificate .

- If the recovery week determined by the officer is before the recovery week in FTS, and sickness benefits have already been paid for the period after the valid recovery week, the officer fact-finds with the client:

- If the client confirms incapacity for the period, the officer asks the client to submit a medical certificate for the period with no acceptable medical certificate.

- If the client does not submit a medical certificate or the client is not reached, or the client confirms a recovery date corresponding with the medical certificate, the officer imposes a 16 - No medical certificate submitted disentitlement (D16) from the first Monday following the valid recovery week.

- If the recovery week is not supported because the medical certificate is not acceptable, the officer fact-finds with the client to obtain an acceptable medical certificate.

To determine the recovery week, the officer refers to Determining the recovery week — Instructions .
       [Determining the recovery week — Instructions](/en/procedure/generic/determing_the_recovery_week_instruction.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3406.dita`

Note:

A client is not required to demonstrate good cause for a delay when submitting a medical certificate. The Level 1 officer can modify or rescind a disentitlement related to a missing medical certificate for special benefits, regardless of the length of delay, if all other conditions are met for the requested benefit type (BT). 

## Regional considerations

Source topic: `en_EN/task/examiner_validation-reviewing_validation/regional_considerations.dita`

Each regional processing centre has a different procedure for sorting paper documents. Paper medical certificate documents submitted in some regions are uploaded into NWS by a Non-complex officer.

**Ontario**

Officers in mail processing centres or Service Canada Centre (SCC) upload medical certificate documents to clients’ files and complete the Medical Certificate electronic questionnaire. Officers review the documents uploaded in NWS the same way as those uploaded by the client in MSCA.

**Quebec — Rapport médical (SR-2100) form**

A client could submit the Rapport médical (SR-2100) form. Box A of this form allows the doctor or medical professional to indicate if the patient can participate in work skills development sessions regardless of the illness or incapacity. If the medical professional selected Non in box A , the medical certificate is allowed at Level 1. However, if the medical professional selected Oui , the Level 1 officer creates an Action Item (AI) WI for Level 2 for adjudication of the client’s limited or reduced capacity to work. For English guidance, the officer refers to Medical report SR-2100 Guide .
       [Rapport médical (SR-2100)](https://cdn-contenu.quebec.ca/cdn-contenu/adm/min/emploi-solidarite-sociale/aide-sociale-solidarite-sociale/FO-SR-2100-rapport-medical.pdf) 
       [Medical report SR-2100 Guide](https://cdn-contenu.quebec.ca/cdn-contenu/adm/min/emploi-solidarite-sociale/aide-sociale-solidarite-sociale/FO-SR-2100A-SP-medical-report.pdf) 

## What you need to look for

Source topic: `en_EN/task/examiner_validation-reviewing_validation/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/examiner_validation-reviewing_validation/in_nws.dita`

- Has a medical certificate or an INS5140 form been uploaded?

- Has a Medical Certificate electronic questionnaire been completed?

- Is there an SROC or AI WI with a transcribed medical certificate? 

### In Imaging:

Source topic: `en_EN/task/examiner_validation-reviewing_validation/in_imaging.dita`

Is there a medical certificate? 

## Step by step

Source topic: `en_EN/task/examiner_validation-reviewing_validation/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/examiner_validation-reviewing_validation/level_1.dita`

#### Procedure

Source topic: `en_EN/task/examiner_validation-reviewing_validation/procedure.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3407.dita) 

#### Reviewing the file

Source topic: `en_EN/task/examiner_validation-reviewing_validation/reviewing_the_file_level_1.dita`

- Review the medical certificates and Medical Certificate electronic questionnaires on file.

- Determine if the medical certificate is completed in English or French:

- Determine if an acceptable medical certificate is on file. Refer to Medical certificate: Conditions to be accepted — Knowledge , if necessary:

- In NWS, create a new SROC as follows: 

#### Fact-finding

Source topic: `en_EN/task/examiner_validation-reviewing_validation/fact-finding_level_1.dita`

- Fact-find with the client to obtain an acceptable medical certificate:

- Determine if the client was contacted during fact-finding:

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows: 

#### Moving the WI to Pending

Source topic: `en_EN/task/examiner_validation-reviewing_validation/moving_the_wi_to_pending_level_1.dita`

- Determine if the client intends to submit a new medical certificate:

- In NWS, move the WI to Pending as follows:

- When the WI moves to the current workload, determine if an acceptable medical certificate is on file: 

#### Determining if the medical certificate is proof of incapacity

Source topic: `en_EN/task/examiner_validation-reviewing_validation/determining_if_the_medical_certificate__761e8dff_level_1.dita`

- Determine if the medical certificate indicates the client is unable to work:

- Determine if the medical certificate indicates any of the following conditions:

- Determine if there is an SROC for the medical certificate validation on file:

- In NWS, create a new SROC as follows:

- Main Issue: Select Medical Proof .

- Comments: Type “Medical certificate validation — Limited capacity.”

- Details: Type “The medical certificate is proof of limited capacity. Review of availability required to determine the client’s inability to work and entitlement to benefits.”

- Select Save .

- Create a CR Revised - Availability WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Benefit type: Select Sickness .

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue(s): Select Availability .

- Go to step 19.

- Determine if there is an SROC for the medical certificate validation on file:

- In NWS, create a new SROC as follows:

- Main Issue: Select Medical Proof .

- Comments: Type “Medical certificate validation — Gradual return to work.”

- Details: Type “The medical certificate is proof of gradual return to work. Review of availability required to determine the client’s entitlement to benefits.”

- Select Save .

- Create a CR Revised - Availability WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Benefit type: Select Sickness .

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select Availability .

- Details: Type “Adjudication of gradual return to work required.”

- Complete the CR Revised - Medical Certificate Validation WI. 

#### Determining the period of incapacity

Source topic: `en_EN/task/examiner_validation-reviewing_validation/determining_the_period_of_incapacity_level_1.dita`

- Determine the recovery week by referring to Determining the recovery week — Instructions . Go to step 2. 

#### Determining if changing the recovery week is required

Source topic: `en_EN/task/examiner_validation-reviewing_validation/determining_if_changing_the_recovery_we_18bd8dbb_level_1.dita`

- Compare the recovery week determined in the prior step to the recovery week in FTS:

- Determine if the client has been paid sickness benefits after the recovery week supported by the medical certificate:

- In NWS, create a new SROC as follows:

- Fact-find with the client to determine if the client has recovered:

- Determine if the client was contacted during fact-finding:

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Determine the appropriate action:

- In NWS, move the WI to Pending as follows:

- When the WI moves to the current workload, determine if an acceptable medical certificate has been submitted for the period of sickness benefits paid without a medical certificate: 

#### Period of incapacity not supported by a medical certificate

Source topic: `en_EN/task/examiner_validation-reviewing_validation/period_of_incapacity_not_supported_by_a_97d16bde_level_1.dita`

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type the appropriate option:

- “D16 imposed — Medical certificate does not support the period of incapacity.”

- “D16 - No medical certificate submitted disentitlement imposed — Medical certificate not submitted.”

- Details: Do the following:

- Type the appropriate option:

- Indicate which medical certificate is related to the decision (e.g. the date of upload, the date of signature).

- Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
                   [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- Select Save .

- In FTS, determine if an outstanding registration number related to the new medical certificate is on file:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Disqualifications/Disentitlement (M161) transaction and impose the D16 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select - Add .

- Disentitlement: Select 16 - No medical certificate submitted .

- Start date: Enter the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- D16 - No medical certificate provided / incapacity ended / gradual return (3068) .

- Overpayment Messages (2452): Select one of the following:

- Overpayment - No misrepresentation and active claim

- Overpayment - No misrepresentation and inactive claim

- Text - Footnote (11745): Type the following, if it applies:

- “The medical certificate you have submitted is not acceptable because [reason why the medical certificate is not acceptable].”

- In NWS, complete the CR Medical Certificate Validation WI. 

#### Change to recovery week required

Source topic: `en_EN/task/examiner_validation-reviewing_validation/change_to_recovery_week_required_level_1.dita`

- Determine if there is an SROC for the CR Revised - Medical Certificate Validation WI on file:

- If no, go to step 2.

- If yes, go to step 3.

- In NWS, create a new SROC as follows:

- In FTS, determine if an outstanding registration number related to the new medical certificate is on file:

- Determine if the recovery week must be changed to an earlier or later date:

- Determine if the client can receive additional weeks of sickness benefits on this claim:

- Determine if the client requests sickness benefits in the maternity window :

- Determine if the claimant’s report for the existing recovery week has been processed:

- Select the Renewal/Revised (M106) transaction and input the new recovery week as follows:

- Select the Special Benefits (M106) transaction and input the new recovery week as follows:

- In ACS, add details to the saved N-00-00-00 letter or create the N-00-00-00 letter and send it. Based on the claim information, select all of the required attributes, including the following:

- In NWS, complete the CR Revised - Medical Certificate Validation WI. 

#### No change to the recovery week

Source topic: `en_EN/task/examiner_validation-reviewing_validation/no_change_to_the_recovery_week_level_1.dita`

- Determine if there is an SROC for the CR Medical Certificate Validation WI on file:

- If no, go to step 2.

- If yes, go to step 3.

- In NWS, create a new SROC as follows:

- Main Issue: Select Medical Proof .

- Comments: Type “Medical certificate validation — Valid recovery.”

- Details: Type “The medical certificate supports the recovery week on file.”

- Select Save .

- In NWS, complete the CR Revised - Medical Certificate Validation WI. 

#### Maximum sickness or special benefits paid

Source topic: `en_EN/task/examiner_validation-reviewing_validation/maximum_sickness_or_special_benefits_paid_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “No weeks of sickness benefits remaining.”

- Details: Do the following:

- Type “A 22 - Illness (maximum sickness/special benefits paid) disentitlement is imposed as of [date] as the client is not entitled to additional weeks of sickness benefits due to [reason].”

- Indicate which medical certificate is related to the decision (e.g. the date of SROC, an AI WI, an imaged document, the date of signature).

- Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
                   [National Fact-Finding and Documentation Policy](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/national_policy_factfinding.shtml#5.4)

- Select Save .

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and impose the 22 - Illness (maximum sickness/special benefits paid) disentitlement (D22) as follows:

- Registration number: Select the appropriate registration number.

- Action: Select - Add .

- Disentitlement: Select 22 - Illness (maximum sickness/special benefits paid) .

- Start date: Enter the disentitlement start date.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select Sickness benefits denied - D2/D16/D22/D33/Free text (3066) .

- D22 - max sickness paid/max sickness paid but approved regular or maternity benefits/max combination of special benefits reached (3069) .

- Text - Footnote (11745): Type “If you have worked since establishing your claim and are incapable of working, you should complete a new application for benefits as you may be entitled to establish a new claim for sickness benefits.”

- In NWS, complete the CR Medical Certificate Validation WI. 

#### Sickness benefits requested in the maternity window

Source topic: `en_EN/task/examiner_validation-reviewing_validation/sickness_benefits_requested_in_the_mate_a0e3373f_level_1.dita`

- In NWS, determine if the otherwise available in the maternity window issue has been adjudicated for the period within the maternity window for which the client is requesting sickness benefits:

- If no, go to step 2.

- If yes, go to step 9.

- Determine if there is an outstanding WI for the otherwise available in the maternity window issue:

- If no, go to step 3.

- If yes and the WI is within Level 1 authority, go to step 4.

- If yes and the WI is within Level 2 authority, go to step 7.

- Create a CR Revised WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Benefit type: Select Sickness .

- Destination — SCC : Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue(s): Select the appropriate option.

- Complete the mandatory fields required for the issue.

- Details: Indicate the reason the WI is being created.

- Go to step 6.

- Determine if the WI for the otherwise available in the maternity window issue is assigned:

- If the WI is unassigned, go to step 5.

- If the WI is assigned to you, go to step 6.

- If the WI is assigned to another user or is unassigned and is within Level 2 authority, go to step 7.

- Reassign the WI for the otherwise available in the maternity window issue as follows:

- End User: Select Myself .

- Determine if the otherwise available in the maternity window issue can be adjudicated at Level 1 by referring to Adjudicating otherwise available issues — Continuing claim :

- If no, refer to Adjudicating otherwise available issues — Continuing claim to reassign the WI for the otherwise available in the maternity window issue and go to step 7.
               [Adjudicating otherwise available issues — Continuing claim](/en/procedure/task/no_available_cc.shtml)

- If yes, refer to Adjudicating otherwise available issues — Continuing claim to adjudicate the issue and go to step 9.
               [Adjudicating otherwise available issues — Continuing claim](/en/procedure/task/no_available_cc.shtml)

- Move the CR Revised - Medical Certificate Validation WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Adjudication of sickness in the maternity window required.”

- Bring forward date: Enter today’s date + 10 business days.

- When the WI moves to the current workload, determine if the otherwise available in the maternity window issue has been adjudicated for the period within the maternity window for which the client is requesting sickness benefits:

- If no, return to step 7.

- If yes, go to step 9.

- Determine if sickness benefits are allowed in the maternity window:

- If yes, go to step 10.

- If no, go to step 11.

- In FTS, select the Additional Data (M107) transaction and input the external maternity start date as follows:

- Registration number: Select the appropriate registration number.

- External Maternity — Start week: Enter the maternity benefits start date.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- Determine if the claimant’s report for the existing recovery week has been processed:

- If yes, note the first week of the next claimant’s report to be processed and go to step 12.

- If no, go to step 13.

- Select the Renewal/Revised (M106) transaction and input the new recovery week as follows:

- Revival: Enter the Sunday of the first week of the next claimant’s report to be processed.

- Select the Special Benefits (M106) link and enter the following information under Sickness :

- Recovery week: Select the appropriate Saturday.

- Select Save .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 14.

- Select the Special Benefits (M106) transaction and input the new recovery week as follows:

- Recovery week: Select the appropriate Saturday.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the CR Revised - Medical Certificate Validation WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_3407.dita`

Note:

If at any time the authenticity of a medical certificate or the signature of the doctor raises doubts, refer the medical certificate to Integrity for review. In this case, refer to Creating or reassigning a WI — Integrity .
       [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

     [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml) 

## Policy reference

Source topic: `en_EN/task/examiner_validation-reviewing_validation/policy_reference.dita`

- Digest 11 — Sickness benefits
         [Digest 11 — Sickness benefits](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-11/table-of-contents.html)

- EIR 40 (1)
         [EIR 40 (1)](http://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-40.html) 
