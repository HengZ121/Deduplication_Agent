# Actioning the receipt of undeliverable mail

Source map: `en_EN/task/actioning_receipt_un_mail/actioning_receipt_un_mail.ditamap`

## Summary

Source topic: `en_EN/task/actioning_receipt_un_mail/summary.dita`

Summary: When undeliverable mail is received, the officer tries to obtain a new address so that the undeliverable mail can be resent to the client. 

## What you need to know

Source topic: `en_EN/task/actioning_receipt_un_mail/what_you_need_to_know.dita`

### Receiving undeliverable mail

Source topic: `en_EN/task/actioning_receipt_un_mail/receiving_undeliverable_mail.dita`

Undeliverable mail is any document, other than a Notice of Debt, returned to Service Canada because the recipient does not reside or no longer resides at that address. The Non-complex officer reviews the returned paper document and conducts an address search to determine if the document must be resent, destroyed or imaged for further action. 

### Fraud indicators

Source topic: `en_EN/task/actioning_receipt_un_mail/fraud_indicators.dita`

Before contacting clients to validate their address, the officer determines if the claim is already under investigation for potential fraud. Officers can determine that there is an ongoing Integrity investigation for this application if:

- a 71 - Integrity Services case manual action (MA71) or a 71 - Integrity Services case disentitlement (D71) is imposed;

- an SROC created by Integrity is on file;

- an Action Item (AI) WI is assigned to Integrity;

- a Call Back (CB) WI is assigned to Integrity;

- a Claim Review (CR) WI created by Integrity is on file.

If none of these is on file, the officer reviews the claim to determine if there are any fraud indicators by referring to Fraud indicators: Identifying potentially fraudulent claims — Knowledge . If there are fraud indicators, the officer:
       [Fraud indicators: Identifying potentially fraudulent claims — Knowledge](/en/procedure/generic/additionalresources/fraud_indicator.shtml)

- determines if the banking information has been changed in FTS and, if so, terminate the direct deposit;

- imposes a D71 on skeleton and BPNE N1, N2 or N7 claims, or an MA71 on established claims, if necessary;

- completes the registration number to suspend the application process to prevent the claim from being established or to prevent payments on the renewal claim until the investigation is complete;

- refers the claim to Integrity for investigation.

For more information, the officer refers to Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions .
       [Referral to Integrity: Temporary measures and fraudulent EI and EI ERB claims — Instructions](/en/procedure/generic/referral_to_integrity_temp_measures_fraudulent_ei_and_eierb_claim.shtml)

**Obtaining the address from a third party**

It is sometimes possible to obtain a more recent address from a third-party source such as:

- PSCD

- the directory assistance (i.e. Canada411.ca or by telephone 411)
         [Canada411.ca](http://www.canada411.ca/)

- the telephone book

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1516.dita) 

**Obtaining the address from the client**

When a new address is obtained from the client, the officer refers to Change of Address and then resends the undeliverable mail to the client’s new address.
       [Change of Address](/en/procedure/activity/change_address.shtml)

**Undeliverable privacy letters**

The following ACS letters are privacy letters:

- A-00-00-11

- A-00-00-13

- A-00-00-14

- P-02-00-00

- P-03-00-00

- P-04-00-00

When the undeliverable mail is a privacy letter and a new address is not confirmed, the Non-complex officer emails the Incident Management and Legislative Disclosures unit providing the client’s name and the file number of the letter returned as undeliverable. The file number is located on the top of the letter and begins with CAS or PRV . The Non-complex officer marks the letter as undeliverable in ACS, shreds the letter and sends the envelope for imaging. The Level 1 officer imposes the appropriate stop pay or disentitlement on the claim. The Incident Management and Legislative Disclosures unit tracks the undeliverable letters and follows up as required.

**Imposing a disentitlement when a new address cannot be obtained**

When undeliverable mail is returned on a skeleton, active or renewable claim and a new address is not obtained, the payment of benefits is suspended, even when the undeliverable mail applies to a benefit period (BP) before the skeleton, active or renewable claim. Benefits remain suspended until the client provides a new address.

To suspend benefits because of undeliverable mail, the Level 1 officer imposes an indefinite 48 Moved - address unknown disentitlement (D48). The Integrity or IPOC officer imposes a 48 - Moved - address unknown manual action (MA48).

If a 3 - Skeleton claim manual action (MA03) is imposed on the claim, the officer cannot impose a D48 or MA48. The Level 1 officer imposes an administrative indefinite 15 - Claim Procedure disentitlement (D15). 

### Resending undeliverable mail

Source topic: `en_EN/task/actioning_receipt_un_mail/resending_undeliverable_mail.dita`

When a new address is obtained and there is undeliverable mail, the officer resends the mail.

**Resending a warning letter that includes an unclassified violation**

If the undeliverable mail is a D-91-00-00 warning letter (i.e. a non-monetary penalty) that includes an unclassified violation (in FTS, on the Violation History (ML02) screen, 1 - Violation - warning letter issued is displayed in the Warning Letter field), the Non-complex officer images the envelope for further action by a Level 1 officer.

The Level 1 officer determines if an overpayment (OP) is associated with the D-91-00-00 letter and if the Notice of Debt was returned as undeliverable. If no OP is associated with the D-91-00-00 warning letter that includes an unclassified violation, the Level 1 officer creates and sends a new notice of decision containing the same information as the original notice of decision. In addition, the Level 1 officer inputs a new notification week on the Violation (ML01) screen in FTS and rescinds the original notification week.

**Resending a warning letter that does not include an unclassified violation**

If the undeliverable mail is a D-91-00-00 warning letter that does not include an unclassified violation (i.e. non-monetary penalty), the Non-complex officer addresses an envelope with the client’s new address, encloses the undeliverable mail and sends it to the client.

**Resending a notice of decision unrelated to a Notice of Debt**

If the undeliverable mail is a notice of decision that is unrelated to a Notice of Debt, the Non-complex officer addresses an envelope with the client’s new address, encloses the undeliverable mail and sends it to the client.

**Resending a notice of decision resulting in an overpayment (OP)**

If the undeliverable mail is a notice of decision that set up an OP or a penalty, and the Notice of Debt was not returned as undeliverable, the Non-complex officer addresses an envelope with the client’s new address, encloses the undeliverable mail and sends it to the client. Since the Notice of Debt was delivered, the client was notified of the debt and therefore is not entitled to a new right to request a reconsideration timeframe.

**Resending a letter that is not a notice of decision**

If the undeliverable mail is an ACS letter that is not a notice of decision (e.g. a questionnaire), the Non-complex officer addresses an envelope with the client’s new address, encloses the undeliverable mail and sends it to the client.

**Issuing a new notice of decision when the Notice of Debt is actioned**

If the undeliverable mail is a notice of decision that set up an OP or a penalty, and the Notice of Debt was also returned as undeliverable, the new notice of decision will be sent at the time the Notice of Debt is actioned.

**Resending a benefit statement**

If the undeliverable mail is a benefit statement, it may contain an access code. A 4-digit Responsibility Centre code is displayed in the top left of the address window. When the benefit statement also contains an access code, only the letter P is displayed after the Responsibility Centre code. The Non-complex officer does not open the envelope containing the benefit statement and access code since the officer must not see the client’s full access code. If the undeliverable mail is a benefit statement with an access code, the Non-complex or Level 1 officer determines if the access code has been reissued. If the access code has not been reissued and a new address is obtained, the Non-complex officer addresses an envelope with the client’s new address, encloses the undeliverable mail and sends it to the client. The Level 1 officer reissues the access code through FTS.

For claims in Cúram, no Responsibility Centre code is displayed. However, the letter P is displayed on the return address before Service Canada.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1517.dita) 

**T4E**

If the undeliverable mail is a T4E, the envelope must not be opened because that would constitute a breach of privacy. Therefore, all mail that contains a T4E must be destroyed. Mail that contains a T4E can be identified by a bracket (┌ ) in the left-hand corner of the address window.

**Resending another document**

If the undeliverable mail is not one of the above, the Non-complex officer addresses an envelope with the client’s new address, encloses the undeliverable mail and sends it to the client. 

### Note

Source topic: `en_EN/common_notes/note_c_1516.dita`

Note:

When a new address is obtained from a third-party source, the officer does not update the client’s address in FTS, unless the new address is verified with the client. 

### Note

Source topic: `en_EN/common_notes/note_c_1517.dita`

Note:

Benefit statements are produced when:

- it is the first benefit statement for the claim;

- claims are processed in MPS;

- claimant’s reports are sent by mail;

- an access code is issued;

- a message is sent to a client who was previously receiving a benefit type (BT) that did not require reporting (e.g. maternity benefits). 

## Regional considerations

Source topic: `en_EN/task/actioning_receipt_un_mail/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/actioning_receipt_un_mail/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/actioning_receipt_un_mail/in_nws.dita`

- Is there an SROC related to the undeliverable mail?

- Is there a WI related to the undeliverable mail? 

### In Imaging:

Source topic: `en_EN/task/actioning_receipt_un_mail/in_imaging.dita`

- Is there information indicating a new address is available? 

### In FTS:

Source topic: `en_EN/task/actioning_receipt_un_mail/in_fts.dita`

- Has a new address been input?

- Has a D48 or MA48 been imposed? 

### In PSCD:

Source topic: `en_EN/task/actioning_receipt_un_mail/in_pscd.dita`

- Is a new address available? 

### From directory assistance or the telephone book:

Source topic: `en_EN/task/actioning_receipt_un_mail/from_directory_assistance_or_the_telephone_book.dita`

- Is a new address available? 

## Step by step

Source topic: `en_EN/task/actioning_receipt_un_mail/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/actioning_receipt_un_mail/non-complex.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_receipt_un_mail/reviewing_the_file_non-complex.dita`

- Determine if the undeliverable mail is for a claim in Cúram:

- If no, go to step 2.

- If yes, go to Correspondence failed — Undeliverable mail .
               [Correspondence failed — Undeliverable mail](/en/procedure/task/echec-lie-corres-cour-nl-corresp-failed-um.shtml)

- Determine if the undeliverable mail is a T4E:

- If no, go to step 3.

- If yes, shred it. No further action is required.

- In NWS, determine if there is documentation on file indicating that the application is under investigation for potential fraud:

- If no, go to step 4.

- If yes, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_Fraud_indicators_are)

- Determine if there are known fraud indicators and if fraud is suspected by referring to Fraud indicators: Identifying potentially fraudulent claims — Knowledge and reviewing the file:

- If yes, go to step 5.

- If no, go to step 6.

- In FTS, determine if the banking information has been changed to the banking information on the potentially fraudulent application:

- If no, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_Fraud_indicators_are)

- If yes, terminate the direct deposit by referring to Ending a direct deposit and go to Fraud indicators are present .
               [Ending a direct deposit](/en/procedure/task/ending_dd.shtml) 
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_Fraud_indicators_are)

- In FTS, determine if a new address for the client is available:

- If yes, go to step 7.

- If no, go to step 8.

- In NWS, create a new SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “address search.”

- Details: Type “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] — new address on file.”

- Select Save .

- Go to New address confirmed .
               [New address confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_New_address_confirmed_nc)

- In PSCD, determine if the client’s new address is available as follows:

- Select Review BP Account .

- On the Debtor Overview - BP search screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Select Search .

- If the client’s new address is not available, go to step 9. If the client’s new address is available, go to step 10.

- Determine if a new address for the client is available from a third-party source (e.g. directory assistance or the telephone book).

- If yes, go to step 10.

- If no, fact-find with the client to obtain a new address. Go to step 11.
               [fact-find](/en/procedure/task/fact_find.shtml)

- Fact-find with the client to verify the address from the third-party source. Go to step 11.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1516.dita)

- Determine if the client was contacted during fact-finding:

- If yes, refer to Change of address and go to step 12.
               [Change of address](/en/procedure/activity/change_address.shtml)

- If no, go to New address unconfirmed or unknown .
               [New address unconfirmed or unknown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#UnconfirmedUnknown)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “Address search.”

- Details: Type “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] — client stated the new address is [new address].”

- Select Save .

- Go to New address confirmed .
               [New address confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_New_address_confirmed_nc) 

#### New address confirmed

Source topic: `en_EN/task/actioning_receipt_un_mail/new_address_confirmed_non-complex.dita`

- Determine what type of undeliverable mail was returned:

- If the undeliverable mail is a D-91-00-00 warning letter that includes an unclassified violation, go to step 2.

- If the undeliverable mail is a notice of decision that set up an OP or a penalty, go to step 3.

- If the undeliverable mail is a benefit statement with an access code, go to step 4.

- If the undeliverable mail is a D-91-00-00 letter that does not include an unclassified violation, go to step 3.

- If the undeliverable mail is a notice of decision unrelated to a Notice of Debt, go to step 5.

- If the undeliverable mail is any other ACS letter, go to step 5.

- If the undeliverable mail is none of the above, go to step 5.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1518.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1519.dita)

- In ACS, set the original letter to “undeliverable.” Shred the letter and image the envelope. To image the envelope, refer to Preparing documents for imaging . No further action is required.

- Determine if the Notice of Debt that is related to the undeliverable notice of decision was returned as undeliverable:

- If the Notice of Debt was not returned as undeliverable, go to step 5.

- If the Notice of Debt was returned as undeliverable, in ACS, indicate that the original letter is “undeliverable.” Shred the letter and image the envelope. To image the envelope, refer to Preparing documents for imaging . Go to step 6.
               [Preparing documents for imaging](/en/procedure/task/prep_docs_imaging.shtml)

- In FTS, determine if the access code has been reissued:

- If no, go to step 5.

- If yes, shred the unopened envelope containing the benefit statement. No further action is required.

- Address an envelope with the client’s new address, enclose the undeliverable mail and send it to the client. Go to step 6.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1520.dita)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “Insurance.”

- Details: Type one of the following options:

- “[Type of undeliverable mail] originally sent [date] received as undeliverable on [date] — resent to the client’s new address.”

- “Notice of decision not resent to the client’s new address as the Notice of Debt was also undeliverable.”

- Select Save . 

#### New address unconfirmed or unknown

Source topic: `en_EN/task/actioning_receipt_un_mail/new_address_unconfirmed_or_unknown_non-complex.dita`

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “Address search.”

- Details: Type the appropriate option:

- “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] — unable to reach client to obtain new address.”

- “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] — unable to reach client to confirm address obtained from [third-party source].”

- Select Save .

- Determine if the new address for the client is unconfirmed or unknown.

- If the new address is unconfirmed, go to step 3.

- If the new address is unknown, go to step 4.

- In ACS, create and send the Q-01-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Information Requested Re: ROE / RFS / Undeliverable Mail / Additional Info required (2876)

- Undeliverable Mail Active/Inactive claim (2878): Select Undeliverable Mail inactive claim .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1521.dita)

- In FTS, determine if there is a skeleton claim:

- If no, go to step 5.

- If yes, go to step 7.

- Determine if an active claim is displayed on the Summary screen or a renewable claim is displayed on the Dormant tab:

- If yes, go to step 6.

- If no, go to step 12.

- In FTS, determine if a D48 or an MA48 is imposed:

- If no, go to step 7.

- If yes, go to step 12.

- Determine what type of undeliverable mail was returned:

- If the undeliverable mail is an A-00-00-11, A-00-00-13, A-00-00-14, P-02-00-00, P-03-00-00 or P-04-00-00, ACS letter, go to step 8.

- If the undeliverable mail is another type of ACS letter, go to step 9.

- If the undeliverable mail is a T4E, shred it. No further action is required.

- If the undeliverable mail is a benefit statement with an access code, go to step 10.

- If the undeliverable mail is none of the above, go to step 11.

- Send an email to the Incident Management and Legislative Disclosures unit as follows:

- Subject: Type “Undeliverable privacy letter.”

- Body: Enter the client’s name and the file number of the letter returned as undeliverable.

- Go to step 9.

- In ACS, set the original letter to “undeliverable.” Shred the letter and image the envelope. To image the envelope, refer to Preparing documents for imaging .

- Image the unopened envelope containing the benefit statement. To image the envelope, refer to Preparing documents for imaging .

- Prepare the undeliverable mail for imaging. Refer to Preparing documents for imaging .

- Determine what type of undeliverable mail was returned:

- If the undeliverable mail is an ACS letter, go to step 13.

- If the undeliverable mail is a document that can be obtained from an internal system (e.g. FTS, PSCD, NWS), go to step 14.

- If the undeliverable mail is none of the above, go to step 15.

- In ACS, indicate that the original letter is “undeliverable.” Shred the letter and image the envelope. To image the envelope, refer to Preparing documents for imaging . No further action is required.

- Shred the undeliverable mail. No further action is required.

- Write PA on the document and send it for imaging. Refer to Preparing documents for imaging . 

#### Fraud Indicators are present

Source topic: `en_EN/task/actioning_receipt_un_mail/fraud_indicators_are_present_non-complex.dita`

- In FTS, determine if the claim is established:

- If yes, go to Presence of fraud indicators — Renewal or continuing claim .
               [Presence of fraud indicators — Renewal or continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_Presence_of_fraud_1)

- If no, go to Presence of fraud indicators — Initial claim .
               [Presence of fraud indicators — Initial claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_Presence_of_fraud_2) 

#### Fraud indicators are present — Renewal or continuing claim

Source topic: `en_EN/task/actioning_receipt_un_mail/fraud_indicators_are_present__renewal_o_cfa058e5_non-complex.dita`

- In NWS, determine if there is a CR Integrity ERB-EI Transition WI related to the potentially fraudulent claim:

- If no, go to step 2.

- If yes, go to step 9.

- Determine if there is a CB or AI WI from Integrity related to the potentially fraudulent claim:

- If no, go to step 3.

- If yes, go to step 9.

- Determine if an MA71 is already imposed:

- If no, go to step 4.

- If yes, go to step 5.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 5.

- Determine if there is an outstanding registration number related to the fraudulent application:

- If yes, go to step 6.

- If no, go to step 7.

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the registration number related to the fraudulent application as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 7.

- In NWS, determine if there is documentation on file indicating that the application is already under investigation for potential fraud:

- If no, go to step 8.

- If yes, go to step 9.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the region where the client lives:

- Processing - ATL

- Processing - QC

- Processing - ON

- Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue: Select Undeliverable mail .

- Comments: Type “Suspected fraud — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file]. No attempt was made to contact the client due to the presence of fraud indicators. The application process is suspended until the end of the investigation.”

- Select Save .

- Determine what type of undeliverable mail was returned:

- If the undeliverable mail is an ACS letter, go to step 10.

- If the undeliverable mail is a statement of benefits with an access code, a document that can be obtained from an internal system (e.g. FTS, PSCD, NWS) or any other type of mail, shred the undeliverable mail and go to step 11.

- In ACS, indicate that the original letter is “undeliverable.” Shred the letter and image the envelope. To image the envelope, refer to Preparing documents for imaging .

- In NWS, create a new SROC as follows:

- Main Issue: Select Undeliverable mail .

- Comments: Type “Referral to Integrity.”

- Details: Type “[Type of undeliverable mail] initially sent on [DD-MM-YYYY] was received as undeliverable on [DD-MM-YYYY] — ongoing investigation.”

- Select Save .

- No further action is required. 

#### Fraud Indicators are present — Initial claim

Source topic: `en_EN/task/actioning_receipt_un_mail/fraud_indicators_are_present__initial_claim_non-complex.dita`

- In NWS, determine if there is a CR Integrity ERB-EI Transition WI related to the potentially fraudulent claim:

- If no, go to step 2.

- If yes, go to step 10.

- Determine if there is a CB or AI WI from Integrity related to the potentially fraudulent claim:

- If no, go to step 3.

- If yes, go to step 10.

- In FTS, determine if there is an outstanding initial registration number related to the fraudulent claim:

- If yes, go to step 4.

- If no, go to step 9.

- Determine if a D71 is already imposed:

- If no, go to step 5.

- If yes, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1522.dita)

- Select the Renewal/Revised (M106) transaction to impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

- Go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1523.dita)

- In NWS, determine if the CS is Finalized - Pending LREM :

- If yes, go to step 7.

- If no, go to step 8.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- Go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1524.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the initial registration number as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 9.

- In NWS, refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the region where the client lives:

- Processing - ATL

- Processing - QC

- Processing - ON

- Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue: Select Undeliverable mail .

- Comments: Type “Suspected fraud — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file]. The application process is suspended until the end of the investigation.”

- Select Save .

- Determine what type of undeliverable mail was returned:

- If the undeliverable mail is an ACS letter, go to step 11.

- If the undeliverable mail is a statement of benefits with an access code, a document that can be obtained from an internal system (e.g. FTS, PSCD, NWS) or any other type of mail, shred the undeliverable mail and go to step 12.

- In ACS, indicate that the original letter is “undeliverable.” Shred the letter and image the envelope. To image the envelope, refer to Preparing documents for imaging .

- In NWS, create a new SROC as follows:

- Main Issue: Select Undeliverable mail .

- Comments: Type “Referral to Integrity.”

- Details: Type “[Type of undeliverable mail] initially sent on [DD-MM-YYYY] was received as undeliverable on [DD-MM-YYYY] — ongoing investigation.”

- Select Save .

- No further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_1518.dita`

Note:

A D-91-00-00 letter that includes an unclassified violation will indicate the following:

“We will not ask you to pay a monetary penalty given the circumstances surrounding [this false statement/these false statements].” 

#### Note

Source topic: `en_EN/common_notes/note_c_1519.dita`

Note:

Do not open the envelope containing the benefit statement and the access code. The envelope contains an access code if the letter P follows the 4-digit Responsibility Centre code. The letters NP mean there is no access code in the envelope.

Example:

With access code: 1234 P21

Without access code: 1234NP21. 

#### Note

Source topic: `en_EN/common_notes/note_c_1520.dita`

Note:

If working from home, refer to Telework: Printing documents locally — Instructions to reprint the letter and send it in an envelope addressed to the client’s new address.
       [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml)

     [Telework: Printing documents locally — Instructions](/en/procedure/generic/additionalresources/telework_print_documents_locally_instruction.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_1521.dita`

Note:

Regardless of the claim status (CS), do not select Undeliverable Mail active claim. If Undeliverable Mail active claim is selected, ACS advises the client that a copy of the undeliverable mail is attached. However, when the address is unconfirmed, shred the undeliverable mail instead of attaching it to the Q-01-00-00 letter. 

#### Note

Source topic: `en_EN/common_notes/note_c_1522.dita`

Note:

Before imposing a D71, always confirm that one is not already imposed. If there is an existing D71, do not input a new one. Inputting a Renewal/Revised (M106) transaction to impose a D71 when one is already on file will cancel the existing disentitlement. 

#### Note

Source topic: `en_EN/common_notes/note_c_1523.dita`

Note:

If the error code C072 appears when inputting the Renewal/Revised (M106) transaction, the D71 cannot be imposed. Continue with next step. 

#### Note

Source topic: `en_EN/common_notes/note_c_1524.dita`

Note:

If the error code 836 appears when trying to clear the registration number, check the Ignore box to process the transaction. 

### Level 1

Source topic: `en_EN/task/actioning_receipt_un_mail/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/actioning_receipt_un_mail/reviewing_the_file_level_1.dita`

- In NWS, determine if there is documentation on file indicating that the application is under investigation for potential fraud:

- If no, go to step 2.

- If yes, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_Presence_of_fraud_3)

- Determine if there are known fraud indicators and if fraud is suspected by referring to Fraud indicators: Identifying potentially fraudulent claims — Knowledge and reviewing the file:

- If yes, go to step 3.

- If no, go to step 4.

- In FTS, determine if the banking information has been changed to the banking information from the potentially fraudulent application:

- If no, go to Fraud indicators are present .
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_Presence_of_fraud_3)

- If yes, terminate the direct deposit by referring to Ending a direct deposit . Go to Fraud indicators are present .
               [Ending a direct deposit](/en/procedure/task/ending_dd.shtml) 
               [Fraud indicators are present](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_Presence_of_fraud_3)

- In FTS, determine if a new address for the client is available:

- If no, go to step 5.

- If yes, go to New address confirmed .
               [New address confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#new_address_confirmed_l1)

- Determine if a new address for the client is available from a third-party source (e.g. directory assistance or the telephone book).

- If no, go to New address unconfirmed or unknown .
               [New address unconfirmed or unknown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#UnconfirmedUnknownL1)

- If yes, fact-find with the client to verify the address from the third-party source and go to step 6.
               [fact-find](/en/procedure/task/fact_find.shtml)

- In PSCD, determine if the client’s new address is available as follows:

- Select Review BP Account .

- On the Debtor Overview - BP search screen, do the following:

- Social Insurance Number: Enter the client’s SIN.

- Select Search .

- If the client’s new address is not available, go to step 7. If the client’s new address is available, go to step 8.

- Determine if the client was contacted during fact-finding:

- If yes, refer to Change of address and go to step 8.
               [Change of address](/en/procedure/activity/change_address.shtml)

- If no, go to New address unconfirmed or unknown .
               [New address unconfirmed or unknown](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#UnconfirmedUnknownL1)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “New address.”

- Details: Type “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] — client stated the new address is [new address].”

- Select Save .

- Go to New address confirmed .
               [New address confirmed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#new_address_confirmed_l1)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1516.dita) 

#### New address confirmed

Source topic: `en_EN/task/actioning_receipt_un_mail/new_address_confirmed_level_1.dita`

- Determine the type of undeliverable mail that was returned:

- If the undeliverable mail is a D-91-00-00 warning letter that includes an unclassified violation (in FTS, on the Violation History [ML02] screen, 1 - Violation - warning letter issued is displayed in the Warning Letter field), go to step 2.

- If the undeliverable mail is a notice of decision that set up an OP or a penalty, go to step 5.

- If the undeliverable mail is a D-91-00-00 letter that does not include an unclassified violation (in FTS, on the Violation History [ML02] screen, the Warning Letter field is blank), go to step 5.

- If the undeliverable mail is a notice of decision unrelated to a Notice of Debt, go to step 6.

- If the undeliverable mail is any other ACS letter, go to step 6.

- If the undeliverable mail is a benefit statement with an access code, go to step 8.

- If the undeliverable mail is none of the above, go to step 7.

- Determine if there is an OP related to the D-91-00-00 warning letter that includes an unclassified violation:

- If no, go to step 3.

- If yes, go to step 5.

- In FTS, from the Violation (ML01) screen, add a new notification week and rescind the one that was initially entered as follows:

- To add the new notification week:

- Action: Select Add .

- Notification week: Select the current w/c.

- BPC: Select the same BPC as initially selected.

- Imposed by: Select 1 - Officer .

- Warning Letter: Select 1 - Violation - warning letter issued .

- Actual OP: Enter the potential OP as initially entered, if necessary.

- Potential OP: Enter the potential OP as initially entered, if necessary.

- Select Update .

- To rescind the original notification week:

- Select the original violation.

- Action: Select Rescind.

- Select Update .

- In ACS, create and send a new D-91-00-00 decision letter with the same information as the original decision. Go to step 10.

- Determine if the Notice of Debt that is related to the undeliverable notice of decision was returned as undeliverable:

- If the Notice of Debt was not returned as undeliverable, go to step 6.

- If the Notice of Debt was returned as undeliverable, go to step 10.

- From the appropriate electronic system (i.e. ACS, FTS, Imaging) print a copy of the undeliverable mail.

- Address an envelope with the client’s new address, enclose the undeliverable mail and send it to the client. Go to step 10.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1520.dita)

- In FTS, determine if the access code has been reissued:

- If no, go to step 9.

- If yes, go to step 11.

- In FTS, reissue the access code .

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Undeliverable Mail .

- Comments: Type “Insurance.”

- Details: Type one of the following options:

- “[Type of undeliverable mail] originally sent [date] received as undeliverable on [date] — resent to the client’s new address.”

- “Notice of decision not resent to the client’s new address as the Notice of Debt was also undeliverable.”

- “Access code reissued.”

- Select Save .

- In NWS, complete the AI WI. 

#### New address unconfirmed or unknown

Source topic: `en_EN/task/actioning_receipt_un_mail/new_address_unconfirmed_or_unknown_level_1.dita`

- Determine if a new address for the client is unconfirmed or unknown:

- If the new address is unconfirmed, go to step 2.

- If the new address is unknown, go to step 3.

- In ACS, create and send the Q-01-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Information Requested Re: ROE / RFS / Undeliverable Mail / Additional Info required (2876)

- Undeliverable Mail Active/Inactive claim (2878): Select the appropriate option:

- Undeliverable Mail active claim

- Undeliverable Mail inactive claim

- In FTS, determine if there is a skeleton claim:

- If no, go to step 4.

- If yes, go to step 9.

- Determine if an active claim is displayed on the Summary screen or a renewable claim is displayed on the Dormant tab:

- If yes, go to step 5.

- If no, go to step 13.

- In FTS, determine if a D48 or an MA48 is imposed:

- If no, go to step 6.

- If yes, go to step 13.

- If there is no revised registration number, select the Registration Number (M025, M030, M035) transaction and obtain a registration number as follows:

- Action: Select Assign .

- Claim source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and impose a D48 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 48 - Moved - address unknown .

- Start date: Select the Monday of the next claimant’s report period.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “Undeliverable mail — D48 imposed.”

- Details: Type “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] and the new address is [unconfirmed or unknown]. A valid address is required to maintain entitlement to benefits. A D48 will be imposed on [date]. Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Go to step 13.

- In FTS, determine if a D15 is imposed:

- If no, go to step 10.

- If yes, go to step 13.

- If there is no revised registration number, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and impose an administrative D15 as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 15 - Claim Procedure .

- Start date: Select the Monday of the next claimant’s report period.

- End date: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Decision type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- In NWS, create a ROD as follows:

- Comments: Type “Undeliverable mail — D15 imposed.”

- Details: Type “[Type of undeliverable mail] initially sent on [date] was received as undeliverable on [date] and the new address is [unconfirmed or unknown]. A valid address is required to maintain entitlement to benefits. A D15 will be imposed on [date]. Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Determine if the undeliverable mail is an ACS letter:

- If yes, in ACS, set the original letter to “undeliverable.” Go to step 14.

- If no, go to step 14.

- In NWS, complete the AI WI. 

#### Fraud indicators are present

Source topic: `en_EN/task/actioning_receipt_un_mail/fraud_indicators_are_present_level_1.dita`

- In FTS, determine if the claim is established:

- If yes, go to Presence of fraud indicators — Renewal or Continuing claim .
               [Presence of fraud indicators — Renewal or Continuing claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_Presence_of_fraud_l1_continue)

- If no, go to Presence of fraud indicators — Initial claim .
               [Presence of fraud indicators — Initial claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/actioning_receipt_un_mail#_Presence_of_fraud_l1_initial) 

#### Fraud indicators are present — Renewal or Continuing claim

Source topic: `en_EN/task/actioning_receipt_un_mail/fraud_indicators_are_present__renewal_o_cfa058e5_level_1.dita`

- In NWS, determine if there is a CR Integrity ERB-EI Transition WI related to the potentially fraudulent claim:

- If no, go to step 2.

- If yes, go to step 9.

- Determine if there is a CB or AI WI from Integrity related to the potentially fraudulent claim:

- If no, go to step 3.

- If yes, go to step 9.

- Determine if an MA71 is already imposed:

- If no, go to step 4.

- If yes, go to step 5.

- Select the Renewal/Revised (M106) transaction and impose an MA71 as follows:

- Registration number: Leave this field blank.

- Manual action: Select 71 - Integrity Services case .

- Select Update .

- Go to step 5.

- Determine if there is an outstanding registration number related to the fraudulent application:

- If yes, go to step 6.

- If no, go to step 7.

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the registration number related to the fraudulent application as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 7.

- In NWS, determine if there is documentation on file indicating that the application is already under investigation for potential fraud:

- If no, go to step 8.

- If yes, go to step 9.

- Refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the region where the client lives:

- Processing - ATL

- Processing - QC

- Processing - ON

- Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue: Select Undeliverable mail .

- Comments: Type “Suspected fraud — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file]. No attempt was made to contact the client due to the presence of fraud indicators. The application process is suspended until the end of the investigation.”

- Select Save .

- Determine what type of undeliverable mail was returned:

- If the undeliverable mail is an ACS letter, go to step 10.

- If the undeliverable mail is a statement of benefits with an access code, a document that can be obtained from an internal system (e.g. FTS, PSCD, NWS) or any other type of mail, go to step 11.

- In ACS, indicate that the original letter is undeliverable, if necessary.

- In NWS, create a new SROC as follows:

- Main Issue: Select Undeliverable mail .

- Comments: Type “Referral to Integrity.”

- Details: Type “[Type of undeliverable mail] initially sent on [DD-MM-YYYY] was received as undeliverable on [DD-MM-YYYY] — ongoing investigation.”

- Select Save .

- No further action is required. 

#### Fraud indicators are present — Initial claim

Source topic: `en_EN/task/actioning_receipt_un_mail/fraud_indicators_are_present__initial_claim_level_1.dita`

- In NWS, determine if there is a CR Integrity ERB-EI Transition WI related to the potentially fraudulent claim:

- If no, go to step 2.

- If yes, go to step 10.

- Determine if there is a CB or AI WI from Integrity related to the potentially fraudulent claim:

- If no, go to step 3.

- If yes, go to step 10.

- In FTS, determine if there is an outstanding initial registration number related to the fraudulent claim:

- If yes, go to step 4.

- If no, go to step 9.

- Determine if a D71 is already imposed:

- If no, go to step 5.

- If yes, go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1522.dita)

- Select the Renewal/Revised (M106) transaction and impose a D71 as follows:

- Registration number: Leave this field blank.

- Claim action: Select F - Integrity Services case .

- Select Update .

- Go to step 6.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1525.dita)

- In NWS, determine if the CS is Finalized - Pending LREM :

- If yes, go to step 7.

- If no, go to step 8.

- In FTS, select the Registration number (M025, M030, M035) transaction and clear the initial registration number as follows:

- Action: Select Clear .

- Select Update .

- Go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1524.dita)

- In FTS, select the Registration number (M025, M030, M035) transaction and cancel the initial registration number as follows:

- Action: Select Cancel .

- Select Update .

- Go to step 9.

- In NWS, refer the file to Integrity by creating an AI WI as follows:

- Complexity: Select Level 2 .

- Destination — Level: Under level 4 - National Integrity (ISB) , at level 2 - ID Validation , select the region where the client lives:

- Processing - ATL

- Processing - QC

- Processing - ON

- Processing - WT

- End User: Select Next available user .

- Category: Select Not pay affected .

- Issue: Select Undeliverable mail .

- Comments: Type “Suspected fraud — indicators present.”

- Details: Type “The application dated [DD-MM-YYYY] is potentially fraudulent due to the presence of the following indicators: [fraud indicators on file]. The application process is suspended until the end of the investigation.”

- Select Save .

- Determine what type of undeliverable mail was returned:

- If the undeliverable mail is an ACS letter, go to step 11.

- If the undeliverable mail is a statement of benefits with an access code, a document that can be obtained from an internal system (e.g. FTS, PSCD, NWS) or any other type of mail, go to step 12.

- In ACS, indicate that the original letter is undeliverable, if necessary.

- In NWS, create a new SROC as follows:

- Main Issue: Select Undeliverable mail .

- Comments: Type “Referral to Integrity.”

- Details: Type “[Type of undeliverable mail] initially sent on [DD-MM-YYYY] was received as undeliverable on [DD-MM-YYYY] — ongoing investigation.”

- Select Save .

- No further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_1525.dita`

Note:

If the error code

C072

appears when inputting the

Renewal/Revised (M106)

transaction, the D71 cannot be imposed. Continue with the next step. 

## Policy reference

Source topic: `en_EN/task/actioning_receipt_un_mail/policy_reference.dita`

 
