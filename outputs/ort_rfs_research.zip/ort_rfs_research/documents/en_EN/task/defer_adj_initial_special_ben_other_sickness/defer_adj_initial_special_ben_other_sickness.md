# Deferring adjudication: Initial claim — Special benefits (other than sickness)

Source map: `en_EN/task/defer_adj_initial_special_ben_other_sickness/defer_adj_initial_special_ben_other_sickness.ditamap`

## Summary

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/summary.dita`

Summary: In certain situations, adjudication of a contentious issue can be deferred on initial claims for special benefits. 

## What you need to know

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/what_you_need_to_know.dita`

### Conditions

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/conditions.dita`

To determine entitlement to benefits when an Adjudication Issue (ADJ) WI is assigned, the officer fact-finds and adjudicates the issue, regardless of whether the ROEs have been received.

On initial claims for maternity or parental benefits, or for CCB or family caregiver benefits, the officer can defer adjudication in the following situations:

- any adjudication issue when the claim is automated BPNE 1;

- any adjudication issue when the claim is automated BPNE 2;

- any adjudication issue when the claim is a manual BPNE 2 at day 27

- any adjudication issue on claims when the client has fewer than 600 insurable hours in the qualifying period (QP );

- the reason for separation (RFS) is B - Strike or lockout (labour dispute) and the claim is BPNE;

- a contentious RFS on claims with a BPC between w/c 2258 and w/c 2309 when the last ROE is the only ROE with a contentious RFS in the 12-week period before the client’s most recent interruption of earnings (I of E) and the client qualifies for special benefits;

- for a contentious RFS when the last ROE is the only ROE with a contentious RFS in the QP and the client qualifies for special benefits

- for a contentious RFS before a disqualifying event that results in an indefinite disqualification when the client qualifies for special benefits

- A leave of absence when the following conditions are met:

- The leave is not the RFS on the last ROE.

- The client started new employment while on a leave of absence from the previous employment.

- The client has stopped working for reasons related to the requested benefit type (BT).

- The RFS on the last ROE is F , P or Z .

- The client qualifies for special benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3042.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3048.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0080.dita) 
     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3049.dita) 

### Claim action status and processing the claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/claim_action_status_and_processing_the_claim.dita`

During processing, an initial claim displays one of the following claim action statuses:

- In Progress (Automation)

- In Progress (Manual)

- Recalculation - In Progress (Automation)

- Recalculation - In Progress (Manual)

- Finalized - Pending LREM

When the Claim action status shows In Progress , all ADJ WIs must be completed before the system can calculate the initial claim. However, in some cases, when the system automates a claim, the adjudication is automatically deferred as well. 

### Deferring adjudication on an automated BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_an_automated__817fd17b.dita`

Claims are automated BPNE 2 and the Claim action status changes to Finalized - Pending LREM when the last ROE is not received by the end of the initial wait process (day 27). The officer moves all ADJ WIs to Pending when the status shows Finalized - Pending LREM . If the last ROE is still missing at the end of the extended initial wait process (day 46), adjudication of any issue is deferred by the system when it sets the claim status to Finalized . A record of decision (ROD) is created automatically. The Last record of employment missing option on the Resolve Issue screen must never be used while the claim is still in automation. 

### Deferring adjudication on a manual BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_a_manual_bpne_2_claim.dita`

When the claim action status is In Progress (Manual) and the last ROE is missing at day 27, the officer with the Claim Assessment (CA) WI can only finalize the claim BPNE 2 after all ADJ WIs are completed. The officer with the ADJ WI can defer adjudication of any issue so the officer with the CA WI can complete it. 

### Deferring adjudication on an automated BPNE 1 claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_an_automated__bbd0b525.dita`

Claims are automated BPNE 1 when clients did not accumulate enough insurable hours to establish a claim for regular or special benefits. The system defers adjudication on any issue when a claim has been automated BPNE 1. A ROD is created automatically. 

### Deferring adjudication on an obvious BPNE claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_an_obvious_bpne_claim.dita`

When reviewing a claim, it may be obvious that clients did not accumulate enough hours of insurable employment to establish a claim for special benefits. This occurs when clients with a BPC of w/c 2309 or earlier have accumulated less than 600 insurable hours in the QP and all ROEs included in the QP are on file. As there is no potential for recalculation, adjudication of any issue is deferred.

A Budget 2021 temporary measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, it may be obvious that clients did not accumulate enough hours of insurable employment to establish a claim for special benefits because they have accumulated fewer than 420 hours of insurable employment in the QP and all ROEs in the QP are on file. 

### Deferring adjudication on the last ROE

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_the_last_roe.dita`

A minimum of 600 insurable hours in the QP are required to qualify for special benefits. Clients with at least 600 insurable hours in the QP are considered major attached. Some major attached clients may qualify for special benefits but would be BPNE for regular benefits. In these cases, the claim is established and an administrative disentitlement is imposed accordingly to prevent payment of regular benefits and allow payment of special benefits.

If the last ROE is the only ROE with a contentious RFS in the QP, adjudication of a contentious RFS can be deferred when clients qualify for special benefits.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3050.dita) 

### Deferring adjudication before a disqualifying event

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_before_a_disqual_7216ebc7.dita`

When there is one or more voluntary leaving or dismissal in the QP, any one of these events can prevent payment of regular benefits in the benefit period (BP). The disqualification is suspended to allow payment of special benefits. Adjudication is deferred on any contentious RFS before a disqualifying event that results in an indefinite disqualification 10 - Dismissal - misconduct proven (D10) or 11 - Voluntary leaving - Just cause not proven (D11).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3040.dita) 

To determine a disqualifying event, the officer must first consider the most recent event of voluntary leaving or dismissal in the QP. The most recent event is not always equal to the last employment and can fall anywhere in the QP. If the officer determines that there is no disqualification for that event, fact-finding and adjudication are completed for the preceding voluntary leaving or dismissal in the QP. The officer continues to work in reverse chronological order until:

- an indefinite disqualification is imposed;

- the beginning of the QP is reached; or

- no event results in an indefinite disqualification.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3038.dita) 
     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3039.dita) 

### Deferring adjudication on a labour dispute

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_a_labour_dispute.dita`

When the RFS is B, the officer can defer a decision on an initial claim for special benefits (other than sickness) if the claim is or will be finalized BPNE and no benefits will be paid. When the claim can be established, deferral is impossible. 

### Deferring adjudication on a leave of absence

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_a_leave_of_absence.dita`

A decision on a leave of absence can be deferred on an initial or renewal claim for special benefits (other than sickness) when all of the following conditions are met:

- the leave of absence is not the RFS on the last ROE; and

- the client started new employment while on a leave of absence from the previous employment; and

- the client has stopped working for the new employer for reasons related to the requested BT; and

- the RFS on the last ROE is F , P or Z .

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3051.dita) 

### Record of decision (ROD) — Creation

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/record_of_decision_rod__creation.dita`

When adjudication is being deferred on issues that do not display a Resolve Issue tab on the ADJ WI, the officer is responsible for creating a ROD for the issue that is being deferred. If a Resolve Issue tab is displayed on the ADJ WI, the officer is responsible for completing all screens. Once the screens are completed, the system automatically creates a ROD. 

### Special condition field in RCM

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/special_condition_field_in_rcm.dita`

There is no Resolve Issue tab on the ADJ WI for leave of absence and strike or lockout (labour dispute) issues. Therefore, when adjudication is deferred, the officer must select Adjudication deferred in the Special condition field of the appropriate ROE in RCM. For all other RFS issues with a Resolve Issue tab on the ADJ WI, the system updates the Special condition field. 

### Deferring adjudication when the ROE is not on file

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_when_the_roe_is__0f07e548.dita`

When all conditions to defer are met, adjudication on a contentious RFS can be deferred even if the ROE is not on file. When the ROE is received, the system attempts to locate an electronic decision to update the Special condition field. If it cannot locate one, a ROE RFS WI is created. 

### Communicating the decision

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/communicating_the_decision.dita`

There is no requirement to notify the client of a deferral. 

### Note

Source topic: `en_EN/common_notes/note_c_3042.dita`

Note:

A transitional measure was implemented on September 27, 2020 for claims with a BPC between w/c 2258 and w/c 2309. Due to this transitional measure, the officer allows any contentious RFS that occurs more than 12 weeks before the client’s most recent I of E. To calculate the 12-week period, the officer subtracts 12 weeks from the week of the most recent I of E. If there are no other contentious issues in the 12-week period before the client’s most recent I of E, the officer can defer adjudication on the most recent RFS. The officer considers any contentious RFS issues that occurred before the 12-week period as non-contentious. 

### Note

Source topic: `en_EN/common_notes/note_c_3048.dita`

Note:

On an initial claim for maternity or parental benefits, for CCB or for family caregiver benefits, with a BPC between w/c 2310 and w/c 2361, the officer can defer adjudication of the RFS for the last period of employment in the QP, even when there are contentious RFSs on other ROEs in the QP. The officer continues to follow all other deferral conditions noted above, except those for specific BPC ranges. This measure does not apply to claims for self-employment (SE) or fishing benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_0080.dita`

Note:

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Note

Source topic: `en_EN/common_notes/note_c_3049.dita`

Note:

The adjudication of an antedate request can never be deferred. Antedate requests must be adjudicated even if the claim results in a BPNE 1 or 5. The insurability ruling is not made by Service Canada and can also never be deferred. 

### Note

Source topic: `en_EN/common_notes/note_c_3050.dita`

Note:

A Budget 2021 temporary measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure. 

### Note

Source topic: `en_EN/common_notes/note_c_3040.dita`

Note:

On claims with a BPC between w/c 2310 and w/c 2361, adjudication is only required on the last RFS. Therefore, adjudication deferral before a disqualifying event no longer applies. This measure does not apply on claims for SE or fishing benefits.

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Info

Source topic: `en_EN/common_notes/note_c_3038.dita`

**Example 1**

```text
| Cut-off date | 700 hours | 500 hours | 300 hours | BPC |

| | ROE 3 - RFS | ROE 2 - RFS | ROE 1 - RFS | |

| | Layoff | Voluntary leaving | Misconduct proven | |
```

- The last employment or most recent disqualifying event is ROE 1. Since misconduct was proven, a disqualification will result. Because a D10 disqualification is being imposed for ROE 1, the adjudication of the RFS on ROE 2 can be deferred. All the hours in the QP are used to calculate the claim. 

### Info

Source topic: `en_EN/common_notes/note_c_3039.dita`

**Example 2**

```text
| Cut-off date | 700 hours | 300 hours | 600 hours | BPC |

| | ROE 3 - RFS | ROE - 2 RFS | ROE 1 - RFS | |

| | Dismissal | Voluntary Leaving — No just cause | Lay-off | |

| | VER = 595 | | | |
```

- The last employment or most recent disqualifying event is ROE 2. The client has worked enough insurable hours after the voluntary leaving for a claim to be established solely based on the hours of ROE 1. Because the client has sufficient insurable hours since the disqualifying event, a D11 disqualification is not imposed. The 300 hours from ROE 2 are excluded from calculation. The RFS on ROE 3 cannot be deferred. The RFS on ROE 3 must be adjudicated to determine whether that ROE is used in the calculation. 

### Example

Source topic: `en_EN/common_notes/note_c_3051.dita`

Example:

**ROE 1**

Costco — first day of work: December 5, 2021. Last day worked (LDW): June 12, 2022. RFS: N - Leave of absence .

**ROE 2**

General Motors — first day worked: August 1, 2022.LDW: September 15, 2022. RFS: P - Parental.

- The client takes a leave of absence from his employment with Costco on June 12, 2022. While on leave, the client begins work for a new employer, General Motors, on August 1, 2022.

- The client stops working for General Motors to take parental leave. The ROE indicates that the RFS is P - Parental and the LDW is September 15, 2022.

- The client requests a renewal for special benefits from the date that he stopped working for General Motors (September 15, 2022). The client meets the entitlement requirements for special benefits so the client’s leave of absence from Costco can be deferred.

- The officer manually imposes an indefinite 43 - Leave from employment without just cause disentitlement (D43) from the date the leave began (June 12, 2022). This prevents the payment of regular benefits from the BPC or date of renewal. 

## Regional considerations

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/what_you_need_to_look_for.dita`

### In FTS:

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/in_fts.dita`

- Has the claim been automated BPNE 2? 

### In NWS:

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/in_nws.dita`

- What is the Claim action status?

- Is there more than one employer in the QP? 

### In RCM:

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/in_rcm.dita`

- Is there more than one ROE for the QP?

- If yes, is there more than one ROE with a contentious RFS on file?

- Are all ROEs for the QP on file?

- What is the total number of insurable hours in the QP? 

## Step by step

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/reviewing_the_file_level_1.dita`

- In RCM, determine if the last ROE is missing:

- If yes, go to step 2.

- If no, go to step 5.

- In NWS, determine if the Claim action status is Finalized - Pending LREM :

- If yes, go to Deferring adjudication on an automated BPNE 2 claim .
               [Deferring adjudication on an automated BPNE 2 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#L1AutomatedN2)

- If no , go to step 3.

- Determine if the claim action status is In Progress (Manual):

- If yes, go to step 4.

- If no, go to step 5.

- Determine if more than 26 days have passed since the date the application was filed:

- If yes, go to Deferring adjudication on a manual BPNE claim .
               [Deferring adjudication on a manual BPNE claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#L1ManualN2)

- If no, go to step 5.

- In RCM, determine the total number of hours of insurable employment for all ROEs in the QP, including any interim ROEs and ROE: INS3166 Request for missing ROE — Forms on file:

- For a claim with a BPC between w/c 2310 and w/c 2361:

- If the total number of hours is 419 or less, go to step 6.

- If the total number of hours is 420 or greater, go to Deferring adjudication in any other situation .
                   [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#Defer_any_other)

- For a claim with a BPC of w/c 2309 or earlier, or w/c 2362 or later:

- If the total number of hours is 599 or less, go to step 6.

- If the total number of hours is 600 or more, go to Deferring adjudication in any other situation .
                   [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#Defer_any_other)

- Determine if the ROEs, interim ROEs or any INS3166 forms are on file for all employers listed on the application for benefits:

- If all ROEs, interim ROE and INS3166 forms are on file, go to Deferring adjudication on an obvious BPNE claim. .
               [Deferring adjudication on an obvious BPNE claim.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#ObviousLevel1)

- If all ROEs, interim ROE and INS3166 forms are not on file and the issue is not a contentious RFS, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- If all ROEs, interim ROE and INS3166 forms are not on file and the issue is a contentious RFS on the last ROE, go to Deferring adjudication in any other situation .
               [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#Defer_any_other) 

#### Deferring adjudication on an automated BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_an_automated__817fd17b_level_1.dita`

- Determine if the client clearly indicates that the missing ROE will not be provided and no interim ROE can be created:

- If the client did not clearly indicate that the missing ROE will not be provided and an interim ROE can be created, go to step 2.

- If the client clearly indicates that the missing ROE will not be provided and no interim ROE can be created, go to step 4.

- In NWS, move the WI for the issue being deferred to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “awaiting last ROE.”

- Bring forward date: Enter the date of application + 45 days.

- When the WI moves to the current workload, determine if the last ROE, including any interim ROE or INS3166 forms for the last ROE is on file:

- If no and the bring forward date has not been reached, repeat step 2.

- If no and the bring forward date has been reached, go to step 4.

- If yes, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI.

- If yes, go to step 5.

- If no, go to step 7.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 8.

- In NWS. for the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on a manual BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_a_manual_bpne_2_claim_level_1.dita`

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI.

- If yes, go to step 2.

- If no, go to step 4.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 5.

- For the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on an obvious BPNE claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_an_obvious_bpne_claim_level_1.dita`

- In NWS, determine if you have a Resolve Issue tab for the ADJ WI:

- If yes, go to step 2.

- If no, go to step 4.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Obviously BPNE .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 9.

- In NWS, for the contentious issue being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — obvious BPNE

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is obviously BPNE.”

- Select Save .

- Determine if adjudication is being deferred for a leave of absence or a strike or lockout issue:

- If yes, go to step 6.

- If no , go to step 9.

- In RCM, update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If the validation causes an ROE error, go to step 8.

- If the validation does not cause an ROE error, go to step 9.

- In NWS, determine if there is an ROE Correction WI or CA WI for this ROE:

- If there is an ROE Correction or CA WI, go to step 9.

- If there is no ROE Correction or CA WI, create an ROE Correction WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Serial Number: Enter the serial number of the ROE.

- Issue: Select Correction .

- In NWS, complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication in any other situation

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_in_any_other_situation_level_1.dita`

- In FTS, determine the BPC:

- If the BPC is between w/c 2258 and w/c 2309, go to step 2.

- If the BPC is between w/c 2310 and w/c 2361, go to step 9.

- If the BPC is not in either of these periods, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3052.dita)

- Determine if the RFS is N – Leave of absence :

- If yes, go to step 3.

- If no, go to step 4.

- Determine if all conditions are met to defer adjudication on the leave of absence at Level 1:

- leave of absence is not the RFS on the last ROE; and

- the client started new employment while on a leave of absence from the previous employment; and

- the client has stopped working for the new employer for reasons related to the requested BT; and

- the RFS on the client’s last ROE is F , P or Z .

- If all conditions are met, go to step 12.

- If all conditions are not met, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the RFS is B - Strike or lockout :

- If no, go to step 5.

- If yes, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious issue.

- Determine if the last ROE is the only ROE with a contentious RFS in the QP:

- If no , go to step 6.

- If yes, go to step 9.

- Determine if the last contentious RFS has been adjudicated:

- If yes, go to step 7.

- If no , deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the adjudication of any contentious RFS in the QP resulted in an indefinite disqualification (D10 or D11):

- If yes, go to step 8.

- If no , deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the RFS that must be adjudicated occurred before the event that resulted in a D10 or D11:

- If yes, go to step 9.

- If no , deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI of the RFS.

- If yes, go to step 10.

- If no, go to step 12.

- On the Resolve Issue tab of the ADJ WI of the RFS, complete the screen as follows:

- Select The adjudication has been deferred because the client meets the qualifying conditions for special benefits and the conditions to defer have been met .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 17.

- In NWS, for the contentious issue being deferred, create a ROD as follows. Select the most appropriate option:

- Comments: Type “Leave of absence deferred — employer — LDW [DD-MM-YYYY].”

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of ROE] is deferred. It is the last ROE and the only one with a contentious RFS in the QP. The client qualifies for special benefits.” or

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of ROE] is deferred because it occurred before a disqualifying event. The client qualifies for [insert the appropriate type of benefits] benefits.” or

- Details: Type “Adjudication of leave of absence from (full name of the employer, LDW for the employer and ROE serial number) is deferred because the client has worked since the leave of absence and has stopped working for a reason related to special benefits. The RFS on the ROE is F , P or Z .

- Select Save .

- In RCM, determine if the ROE is on file:

- If yes, go to step 14.

- If no, go to step 17.

- Update the ROE for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If the validation causes an ROE error, go to step 16.

- If the validation does not cause an ROE error, go to step 17.

- In NWS, determine if there is an ROE Issue (ROE) Correction WI or CA WI for this ROE:

- If yes, go to step 17.

- If no, create an ROE Correction WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Myself .

- Serial Number: Enter the serial number of the ROE.

- Issue: Select Correction .

- Complete the ADJ WI of the RFS for the adjudication issue being deferred. 

#### Note

Source topic: `en_EN/common_notes/note_c_3052.dita`

Note:

If the BPC is between w/c 2258 and w/c 2309, calculate the 12-week period before the most recent I of E. When answering question 5, consider any contentious RFS issues that occurred before the 12-week period as not being in the QP.

On claims with a BPC between w/c 2310 and w/c 2361, adjudication is only required on the last RFS. Even if there are other contentious ROEs in the QP, the officer can defer adjudication on the client’s most recent I of E. Therefore, adjudication deferral before a disqualifying event no longer applies. This measure does not apply on claims for SE or fishing benefits.

For all claims with a tentative BPC of w/c 2361, ADJ WIs are created for the last period of employment and for any other contentious periods of employment in the QP. Officers follow normal procedures to adjudicate those WIs because the final BPC can be w/c 2362 or later. However, if the final BPC is between w/c 2310 and w/c 2361, the system applies the Budget 2021 temporary measures. 

### Level 2

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/reviewing_the_file_level_2.dita`

- In RCM, determine if the last ROE is missing:

- If yes, go to step 2.

- If no, go to step 5.

- In NWS, determine if the Claim action status is Finalized – Pending LREM :

- If yes, go to Deferring adjudication on an automated BPNE 2 claim .
               [Deferring adjudication on an automated BPNE 2 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#L2AutomatedN2)

- If no, go to step 3.

- Determine if the Claim action status is In Progress (Manual) :

- If yes, go to step 4.

- If no, go to step 5.

- Determine if more than 26 days have passed since the date the application was filed:

- If yes, go to Deferring adjudication on a manual BPNE 2 claim .
               [Deferring adjudication on a manual BPNE 2 claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#L2manualN2)

- If no, go to step 5.

- In RCM, determine the total number of insurable hours for all ROEs in the QP, including any interim ROE and INS3166 form on file:

- For a claim with a BPC between w/c 2310 and w/c 2361:

- If the total number of hours is 419 or less, go to step 6.

- If the total number of hours is 420 or greater, go to Deferring adjudication in any other situation .
                   [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#Defer_any_other)

- For a claim with a BPC of w/c 2309 or earlier, or w/c 2362 or later:

- If the total number of hours is 599 or less, go to step 6.

- If the total number of hours is 600 or greater, go to Deferring adjudication in any other situation .
                   [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#defer_any_other_level2)

- Determine if the ROEs, any interim ROEs or INS3166 forms are on file for all employers listed on the application for benefits:

- If all ROEs, interim ROEs and INS3166 forms are on file, go to Deferring adjudication on an obvious BPNE claim .
               [Deferring adjudication on an obvious BPNE claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#ObviousLevel2)

- If all ROEs, interim ROEs and INS3166 forms are not on file and the issue is not a contentious RFS, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- If all ROEs, interim ROEs and INS3166 forms are not on file and the issue is a contentious RFS on the last ROE, go to Deferring adjudication in any other situation .
               [Deferring adjudication in any other situation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/defer_adj_initial_special_ben_other_sickness#defer_any_other_level2) 

#### Deferring adjudication on an automated BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_an_automated__817fd17b_level_2.dita`

- Determine if the client clearly indicated that the missing ROE will not be provided and no interim ROE can be created.

- If the client did not clearly indicate that the missing ROE will not be provided or if an interim ROE can be created, go to step 2.

- If the client clearly indicated that the missing ROE will not be provided and no interim ROE can be created, go to step 4.

- Move the WI for each RFS issue being deferred to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “awaiting ROE.”

- Bring forward date: Enter the date of application + 45 days.

- When the WI moves to the current workload, determine if the last ROE, including any interim ROE or INS3166 forms for the last ROE is on file:

- If no and the bring forward date has not been reached, repeat step 2.

- If no and the bring forward date has been reached, go to step 4.

- If yes, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI.

- If yes, go to step 5.

- If no, go to step 7.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 8.

- In NWS, for the contentious issue being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on a manual BPNE 2 claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_a_manual_bpne_2_claim_level_2.dita`

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI.

- If yes, go to step 2.

- If no, go to step 4.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Last record of employment missing .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 5.

- For the contentious issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — BPNE 2

- Details: Type “Adjudication of [contentious issue, full name of the employer (if the issue is a contentious RFS), last day worked for the employer or serial number of ROE (if the issue is a contentious RFS)] is deferred because the claim is BPNE 2.”

- Select Save .

- Complete the ADJ WI for the adjudication issue being deferred. 

#### Deferring adjudication on an obvious BPNE claim

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_on_an_obvious_bpne_claim_level_2.dita`

- In NWS, determine if you have a Resolve Issue tab for the ADJ WI:

- If yes, go to step 2.

- If no, go to step 4.

- On the Resolve Issue tab of the ADJ WI, complete the screen as follows:

- Select Obviously BPNE .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 9.

- In NWS, for the issue that is being deferred, create a ROD as follows:

- Comments: Enter the following information:

- contentious issue

- name of the employer (if the issue is a contentious RFS)

- last day worked for the employer (if the issue is a contentious RFS)

- deferred adjudication — obvious BPNE

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of ROE] is deferred because the claim is obviously BPNE.”

- Select Save .

- Determine if adjudication is being deferred for a leave of absence issue or a strike or lockout issue:

- If yes, go to step 6.

- If no , go to step 9.

- In RCM, update each of the ROEs for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If the validation causes an ROE error, go to step 8.

- If the validation does not cause an ROE error, go to step 9.

- In NWS, determine if there is an ROE Correction WI or CA WI for this ROE:

- If yes, go to step 9.

- If no, create an ROE Correction WI as follows:

- Complexity: Select Non Complex .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Serial Number: Enter the serial number of the ROE.

- Issue: Select Correction .

- In NWS, complete the ADJ WIs for the adjudication issues being deferred. 

#### Deferring adjudication in any other situation

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/deferring_adjudication_in_any_other_situation_level_2.dita`

- In FTS, determine the BPC:

- If the BPC is between w/c 2258 and w/c 2309, go to step 2.

- If the BPC is between w/c 2310 and w/c 2361, go to step 9.

- If the BPC is not in either of these periods, go to step 2.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3052.dita)

- Determine if the RFS is for a leave of absence:

- If yes, go to step 3.

- If no, go to step 4.

- Determine if all conditions are met to defer the leave of absence:

- leave of absence is not the RFS on the last ROE; and

- the client started new employment while on a leave of absence from the previous employment; and

- the client has stopped working for the new employer for reasons related to the requested BT; and

- the RFS on the client’s last ROE is F , P or Z .

- If all conditions are met, go to step 12.

- If all conditions are not met, deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the RFS is B - Strike or lockout:

- If no, go to step 5.

- If yes, adjudication cannot be deferred. Return to the previous task to adjudicate the contentious issue.

- Determine if the last ROE is the only ROE with a contentious RFS in the QP:

- If no , go to step 6.

- If yes, go to step 9.

- Determine if the last contentious RFS has been adjudicated:

- If yes, go to step 7.

- If no , deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the adjudication of any contentious RFS in the QP resulted in an indefinite disqualification (D10 or D11):

- If yes, go to step 8.

- If no , deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- Determine if the RFS that must be adjudicated occurred before the event that resulted in a D10 or D11:

- If yes, go to step 9.

- If no , deferral is not possible. Return to the previous task to adjudicate the contentious issue.

- In NWS, determine if there is a Resolve Issue tab on the ADJ WI of the RFS.

- If yes, go to step 10.

- If no, go to step 12.

- On the Resolve Issue tab of the ADJ WI of the RFS, complete the screen as follows:

- Select The adjudication has been deferred because the client meets the qualifying conditions for special benefits and has not requested regular benefits at this time .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Go to step 15.

- In NWS, for the contentious issue being deferred, create a ROD as follows. Select the most appropriate option:

- Comments: Enter the following information:

- contentious issue

- name of the employer

- last day worked for the employer

- deferred adjudication — special benefits

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of ROE] is deferred. It is the last ROE and the only one with a contentious RFS in the QP. The client qualifies for special benefits.” or

- Details: Type “Adjudication of [contentious issue, full name of the employer, last day worked for the employer or serial number of ROE] is deferred because it occurred before a disqualifying event. The client qualifies for [insert the appropriate type of special benefits]”. or

- Details: Type “Adjudication of leave of absence from (full name of the employer, last day worked for the employer and serial number of ROE) is deferred because the client has worked since the leave of absence and has stopped working for a reason related to special benefits. The RFS on the ROE is F, P or Z.”

- Select Save .

- In RCM, determine if the ROE is on file:

- If yes, go to step 14.

- If no, go to step 17.

- Update each of the ROEs for which the adjudication is deferred as follows:

- Special condition: Select Adjudication deferred .

- Select Submit .

- Determine if the ROE is flagged in error after validation:

- If yes, go to step 16.

- If no, go to step 17.

- In NWS, determine if there is an ROE Correction WI or CA WI for this ROE:

- If there is an ROE Correction or CA WI, go to step 16.

- If there is no ROE Correction or CA WI, create an ROE Correction WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option based on the employer’s language.

- Destination: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Serial Number: Enter the serial number of the ROE.

- Issue: Select Correction .

- Complete the ADJ WI of the RFS for the adjudication issue being deferred. 

## Policy reference

Source topic: `en_EN/task/defer_adj_initial_special_ben_other_sickness/policy_reference.dita`

 
