# Processing the notification of a Social Security Tribunal-Appeal Division decision

Source map: `en_EN/task/processing_notification_sst_appeal_division/processing_notification_sst_appeal_division.ditamap`

## Summary

Source topic: `en_EN/task/processing_notification_sst_appeal_division/summary.dita`

Summary: Once the Social Security Tribunal (SST)-Appeal Division makes a decision on an appeal, the Commission is notified. 

## What you need to know

Source topic: `en_EN/task/processing_notification_sst_appeal_division/what_you_need_to_know.dita`

### Receiving a decision from the Social Security Tribunal-Appeal Division decision

Source topic: `en_EN/task/processing_notification_sst_appeal_division/receiving_a_decision_from_the_social_se_2a37f72a.dita`

The following interested parties can appeal a decision of the SST-General Division or Employment Insurance Board of Appeal (EI BOA) to the SST-Appeal division:

- the client;

- the Commission;

- any person who is the subject of a Commission decision, including associations of which the employer or the client is a member.

The SST-Appeal Division no longer decides whether leave to appeal may be granted, as the requirement for leave to appeal has been eliminated. Leave to appeal is not required to appeal EI BOA decisions, and is no longer required to appeal SST-General Division decisions to the SST-Appeal Division. Effective April 1, 2026, any outstanding application for leave to appeal with the SST-Appeal Division becomes a notice of appeal.

The SST-Appeal Division may dismiss the appeal, render the decision that the EI BOA or SST-General Division should have rendered or confirm, rescind or modify the decision in whole or in part. The SST-Appeal Division may also refer the matter back for reconsideration to be heard anew (de novo) in accordance with any directions it considers appropriate. The SST-Appeal Division refers these cases to the EI BOA, including decisions originally heard by the SST-General Division.

Regardless of the outcome, the SST-Appeal Division sends paper copies of the decision to all interested parties except for the Commission. The SST-Appeal Division notifies the Commission by sending an email to the GD mailbox of the National Headquarters EI Appeals Division. The SST-Appeal Division sends an electronic copy of the decision to the Commission through the 5. SST folder in the Common Document Share. A copy of the decision is also placed in ADMS and can be viewed by selecting View Decision on the Review Decision tab. The ADMS appeal log is updated to show Decision/withdrawal received at APC . 

### Sharing information using the Common Document Share

Source topic: `en_EN/task/processing_notification_sst_appeal_division/sharing_information_using_the_common_do_72630bec.dita`

The SST and Commission share information not only through Atrium and ADMS, but also through the Common Document Share. The folder titled 5. SST is used for this purpose and acts like a drop box for each party. The SST puts any documents that must be shared with the Commission in this folder for pick-up, and the Commission does the same when sending documents to the SST. Documents must not be housed in this folder. They are moved to the related SIN subfolder in the regional 3.SST-AD-TSS-DA folder of the Common Document Share and kept there. 

### Implementing a Social Security Tribunal (SST)-Appeal Division decision

Source topic: `en_EN/task/processing_notification_sst_appeal_division/implementing_a_social_security_tribunal_b4b470d3.dita`

On the same day the notification is received, the National Headquarters appeals clerk retrieves the SST-Appeal Division decision from the 5. SST exchange folder and moves it to the client’s Record-XXXXXX folder in the 3. SST-AD-TSS-DA regional folder of the Common Document Share. The National Headquarters appeals officer reviews the SST-Appeal Division decision, enters the result of this decision in ADMS and provides any additional guidance. When appeals officers are assigned a file, they review the information provided by National Headquarters and implement the decision. 

### Employer appeal allowed by the Social Security Tribunal (SST)-Appeal Division

Source topic: `en_EN/task/processing_notification_sst_appeal_division/employer_appeal_allowed_by_the_social_s_48434674.dita`

- If the SST-Appeal Division allowed an appeal filed by an employer against a decision to pay benefits to a current or former employee, the action to be taken depends on the claim status (CS).

- If the claim is terminated, no further action is required because any benefits paid are not recoverable from the client according to EIA 114(1) . The officer records the decision on a record of decision (ROD) in NWS and completes the appropriate ADMS fields.
             [EIA 114(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html?txthl=114#s-114)

- If the claim is active and the SST-Appeal Division decision prevents further payment, the decision is implemented as of the next week to be paid.
             [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4187.dita)

- If the SST-Appeal Division dismissed an appeal filed by an employer against a decision to pay benefits to a current or former employee, no further action is required. The officer records the decision on a ROD in NWS and completes the appropriate ADMS fields. 

### Social Security Tribunal (SST)-Appeal Division recommendations

Source topic: `en_EN/task/processing_notification_sst_appeal_division/social_security_tribunal_sst-appeal_div_54fe1df8.dita`

The Commission’s refusal to write off an OP or penalty is not a decision that can be appealed under the EIA, but rather a financial and administrative matter to be resolved by the Chief Financial Officer Branch of the Department for which there is no appeal rights. If a client is disputing the Commission’s decision not to write off the OP, the client must file an application for judicial review with the Federal Court.

However, if an appellant files an appeal with the SST-Appeal Division on the Commission’s decision that caused an OP or penalty, the SST-Appeal Division can recommend that the Commission make suitable arrangements to recover the debt in instalments, or even to write it off. In these cases, the officer goes to Processing an Employment Insurance Board of Appeal or Social Security Tribunal-General or Appeal Division recommendation about a debt (Task) after processing the notification of the SST-Appeal Division decision.
       [Processing an Employment Insurance Board of Appeal or Social Security Tribunal-General or Appeal Division recommendation about a debt (Task)](/en/procedure/task/proc_sst_debt.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4078.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4187.dita`

Note:

The officer does not establish a retroactive overpayment (OP). 

### Note

Source topic: `en_EN/common_notes/note_c_4078.dita`

Note:

A recommendation from a Tribunal to write off a debt is not an appeal or a review of a decision that establishes the debt as stated in EIA 47(4) . Therefore, collection is reinstated in PSCD.
       [EIA 47(4)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-47.html)

     [EIA 47(4)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-47.html) 

## Regional considerations

Source topic: `en_EN/task/processing_notification_sst_appeal_division/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/processing_notification_sst_appeal_division/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/processing_notification_sst_appeal_division/untitled_section.dita`

In ADMS:

- What is the decision of the SST-Appeal Division member?

- Was collection of a debt suspended due to the appeal?

In the Common Document Share:

- What is the decision of the SST-Appeal Division member?

- Is there a memo from National Headquarters?

In PSCD:

- Was collection of a debt suspended due to the appeal?

In NWS:

- Was the issue under appeal an adjudication issue that was automatically resolved ( Resolve Issue screen) or automatically adjudicated? 

## Step by step

Source topic: `en_EN/task/processing_notification_sst_appeal_division/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/processing_notification_sst_appeal_division/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/processing_notification_sst_appeal_division/reviewing_the_file_level_2.dita`

- In ADMS, review the entire SST-Appeals division decision in View Decision and review the information in the Notes field to determine if any particular action is required to implement the decision. Consider this when implementing the decision.

- In the Common Document Share, check for a memo from National Headquarters. If there is a memo, determine if any particular steps are required to implement the decision. Consider this accordingly when implementing the decision.

- Determine the result and do the following:

- If the result is favourable to the client, go to step 4.

- If the result is favourable to the employer, go to Result favourable to the employer .
               [Result favourable to the employer](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/processing_notification_sst_appeal_division#_Favourable_to_the)

- If the result is favourable to the Commission or leave to appeal is denied, go to Result favourable to the Commission .
               [Result favourable to the Commission](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/processing_notification_sst_appeal_division#_Favourable_to_the_1)

- If the result is withdrawn, go to Withdrawn .
               [Withdrawn](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/processing_notification_sst_appeal_division#_Withdrawn)

- If the result is returned to the EI BOA, go to Returned to the Employment Insurance Board of Appeal (EI BOA) .
               [Returned to the Employment Insurance Board of Appeal (EI BOA)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/processing_notification_sst_appeal_division#_Returned_to_the)

- In NWS, determine if the adjudication issue under appeal was automatically resolved ( Resolve Issue screen) or automatically adjudicated:

- If yes, go to step 5.

- If no, go to step 6.

- In NWS, invalidate the original decision as follows:

- Double-click the resolved issue in the Client information tree .

- Under Decision Options , select Decision no longer valid .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4188.dita)

- Create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)] — [allowed, conceded or allowed with modifications].”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- the action taken for the implementation;

- any impact on a previous decision or claim.

- Determine if an appeal lock was applied to an OP or penalty while the SST reviewed the appeal:

- If no, go to step 8.

- If yes, refer to Reinstating the collection of a debt and go to step 8.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4189.dita)

- To implement the decision, make the necessary changes in the appropriate systems:

- If Level 1 support is necessary, go to step 9.

- If Level 1 support is not necessary, go to step 12.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4085.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4086.dita)

- In NWS, create an Action Item (AI) WI as follows:

- Complexity: Select Level 1 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 1 support required.”

- Details: Enter the ADMS record number and the details of the required actions.

- Obtained on: Select today’s date.

- Source Details: Type “SST decision.”

- Urgent: Check the box.

- Move the initial AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting actions from the Level 1 officer.”

- Bring forward date: Enter the appropriate date.

- When the AI WI moves to the current workload, verify if the actions were taken:

- If no, return to step 10.

- If yes, go to step 12.

- In ADMS, on the Review Decision tab, complete the following fields:

- Decision/withdrawal received at APC: Select the date the file was transferred to the Appeal Processing Centre (APC).

- Date decision implemented: Select today’s date. 

#### Result favourable to the employer

Source topic: `en_EN/task/processing_notification_sst_appeal_division/result_favourable_to_the_employer_level_2.dita`

- In NWS, determine if the adjudication issue under appeal was automatically resolved ( Resolve Issue screen) or automatically adjudicated:

- If yes, go to step 2.

- If no, go to step 3.

- In NWS, invalidate the original decision as follows:

- Double-click the resolved issue in the Client information tree .

- Under Decision Options , select Decision no longer valid .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4188.dita)

- Create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)] — [allowed or allowed with modifications].”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- any impact on a previous decision or claim.

- Determine if an appeal lock was applied to an OP or penalty while the SST reviewed the appeal:

- If no, go to step 5.

- If yes, refer to Reinstating the collection of a debt and go to step 5.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

- To implement the decision, make the necessary changes in the appropriate systems:

- If Level 1 support is necessary, go to step 6.

- If Level 1 support is not necessary, go to step 9.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4190.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4086.dita)

- In NWS, create an AI WI as follows:

- Complexity: Select Level 1 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 1 support required.”

- Details: Enter the ADMS record number and the details of the required actions.

- Obtained on: Select today’s date.

- Source Details: Type “SST decision.”

- Urgent: Check the box.

- Move the initial AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting actions from the Level 1 officer.”

- Bring forward date: Enter the appropriate date.

- When the AI WI moves to the current workload, verify if the actions were taken:

- If no, return to step 7.

- If yes, go to step 9.

- In ADMS, on the Review Decision tab, complete the following fields:

- Decision/withdrawal received at APC: Select the date the file was transferred to the APC.

- Date decision implemented: Select today’s date. 

#### Result favourable to the Commission:

Source topic: `en_EN/task/processing_notification_sst_appeal_division/result_favourable_to_the_commission_level_2.dita`

- Create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)] — [dismissed].”

- Details: Document the following:

- the issues that were appealed;

- the decisions;

- any impact on a previous decision or claim.

- Determine if an appeal lock was applied to an OP or penalty while the SST reviewed the appeal:

- If no, go to step 3.

- If yes, refer to Reinstating the collection of a debt and go to step 3.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

- To implement the decision, make the necessary changes in the appropriate systems:

- If Level 1 support is necessary, go to step 4.

- If Level 1 support is not necessary, go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4190.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4086.dita)

- In NWS, create an AI WI as follows:

- Complexity: Select Level 1 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 1 support required.”

- Details: Enter the ADMS record number and the details of the required actions.

- Obtained on: Select today’s date.

- Source Details: Type “SST decision.”

- Urgent: Check the box.

- Move the initial AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting actions from the Level 1 officer.”

- Bring forward date: Enter the appropriate date.

- When the AI WI moves to the current workload, verify if the actions were taken:

- If no, return to step 5.

- If yes, go to step 7.

- In ADMS, on the Review Decision tab, complete the following fields:

- Decision/withdrawal received at APC: Select the date the file was transferred to the APC.

- Date decision implemented: Select today’s date. 

#### Withdrawn

Source topic: `en_EN/task/processing_notification_sst_appeal_division/withdrawn_level_2.dita`

- Determine if the EI BOA or SST-General Division decision was already implemented:

- If no, go to step 2.

- If yes, go to step 4.

- In NWS, determine if the adjudication issue under appeal was automatically resolved ( Resolve Issue screen) or automatically adjudicated:

- If yes, go to step 3.

- If no, go to step 4.

- In NWS, invalidate the original decision as follows:

- Double-click the resolved issue in the Client information tree .

- Under Decision Options , select Decision no longer valid .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4188.dita)

- Create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)] — [ withdrawn].”

- Details: Document the following:

- the issues that were appealed;

- the decisions.

- Determine if an appeal lock was applied to an OP or penalty while the SST reviewed the appeal:

- If no, go to step 6.

- If yes, refer to Reinstating the collection of a debt and go to step 6.
               [Reinstating the collection of a debt](/en/procedure/task/reinstcoll.shtml)

- To implement the decision, make the necessary changes in the appropriate systems:

- If Level 1 support is necessary, go to step 7.

- If Level 2 support is not necessary, go to step 10.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4190.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4086.dita)

- In NWS, create an AI WI as follows:

- Complexity: Select Level 1 .

- Destination: Select the appropriate option based on the client’s current address:

- Atlantic: Select 7 - National RFR and Appeals / RFRA-ATL .

- Quebec: Select 7 - National RFR and Appeals / RFRA-QC .

- Ontario: Select 7 - National RFR and Appeals / RFRA-ON .

- Western Canada and Territories: Select 7 - National RFR and Appeals / RFRA-WT .

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Other .

- Comments: Type “Level 1 support required.”

- Details: Enter the ADMS record number and the details of the required actions.

- Obtained on: Select today’s date.

- Source Details: Type “SST decision.”

- Urgent: Check the box.

- Move the initial AI WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting actions from the Level 1 officer.”

- Bring forward date: Enter the appropriate date.

- When the AI WI moves to the current workload, verify if the actions were taken:

- If no, return to step 8.

- If yes, go to step 10.

- In ADMS, on the Review Decision tab, complete the following fields:

- Decision/withdrawal received at APC: Select the date the file was transferred to the APC.

- Date decision implemented: Select today’s date. 

#### Returned to the Employment Insurance Board of Appeal (EI BOA) (de novo)

Source topic: `en_EN/task/processing_notification_sst_appeal_division/returned_to_the_employment_insurance_bo_211a6cfe_level_2.dita`

- Create a ROD as follows:

- Comments: Type “Appeal [ADMS record number] — [issue] — [employer name and last day worked (if necessary)] — [returned to the Employment Insurance Board of Appeal (de novo)].”

- Details: Document the following:

- the issues that were appealed;

- the decisions.

- In the Common Document Share, create a record folder using the original record number.

- Copy the EI BOA or SST-General Division decision and only the additional documentation related to the EI BOA or SST-General division decision from the ToHRSDC-ADRHCC folder in the 5. SST exchange folder and paste them in a Record folder in the 2. SST-GD-TSS-DG / BOA-CA regional folder.

- Once the record is successfully copied and pasted into the 2.SST-GD-TSS-DG / BOA-CA folder, delete the duplicate documentation in the 3.SST -AD-TSS-DA folder.

- Determine if an appeal lock was applied to an OP or penalty while the SST reviewed the appeal:

- If yes, go to step 6.

- If no, go to step 7.

- In ADMS, on the Review Decision tab, complete the Collection action section as follows:

- Collection Action: Select Reinstate Collection .

- Select I certify that I implemented the decision in PSCD .

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4191.dita)

- Complete the following fields:

- Decision/withdrawal received at APC: Select the date the file was transferred to the APC.

- Date decision implemented: Select today’s date.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4192.dita) 

#### Note

Source topic: `en_EN/common_notes/note_c_4188.dita`

Note:

The initial ROD must be invalidated in NWS because the ROE and the automatically resolved or automatically adjudicated ROD can be used when a claim is recalculated or when a new BPC is established. If the ROD is not changed, benefits could be paid incorrectly during automation. 

#### Note

Source topic: `en_EN/common_notes/note_c_4189.dita`

Note:

If the decision results in the need to send an Operational Centre Memo (MM06) transaction to IPOC and if a related OP is suspended, do not reinstate the collection action. In the MM06, advise IPOC to terminate the lock on the date of the SST decision and apply any underpayments (UPs) to the OP. This ensures that when IPOC processes the decision, the debt is recovered from any potential monies payable. 

#### Note

Source topic: `en_EN/common_notes/note_c_4085.dita`

Note:

When a decision about a reason for separation (RFS) is changed, in addition to invalidating any automated RODs, change the Special Condition field on the ROE in RCM to reflect the correct decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_4086.dita`

Note:

If necessary, contact the client to obtain the information required to implement the decision (e.g. claimant’s reports). 

#### Note

Source topic: `en_EN/common_notes/note_c_4190.dita`

Note:

When a decision about an RFS is changed, in addition to invalidating any automated RODs, change the Special Condition field on the ROE in RCM to reflect the correct decision. 

#### Note

Source topic: `en_EN/common_notes/note_c_4191.dita`

Note:

It is necessary to complete these fields in order to complete the inputs in ADMS. However, because the issue is being returned to the EI BOA , do not actually reinstate collection action in PSCD. 

#### Note

Source topic: `en_EN/common_notes/note_c_4192.dita`

Note:

For more information on de novo cases, refer to Processing the notification of a de novo decision .
       [Processing the notification of a de novo decision](/en/procedure/task/proc_de_novo.shtml)

     [Processing the notification of a de novo decision](/en/procedure/task/proc_de_novo.shtml) 

## Policy reference

Source topic: `en_EN/task/processing_notification_sst_appeal_division/policy_reference.dita`

- Department of Employment and Social Development Act 53(1)
         [Department of Employment and Social Development Act 53(1)](https://laws-lois.justice.gc.ca/eng/acts/H-5.7/section-53.html) 
